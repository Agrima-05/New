SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE procedure [zCust_USBANK_USSPD].[dbo].[usp_213_Update_z_Images_To_Pull_CMTID]
as
BEgin

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '25025' and XosStatus not like 'Completed' and DocumentNbr like '%.%' then '2345'
when FIPS = '25009' and XosStatus not like 'Completed' then '1113'
when FIPS = '36027' and XosStatus not like 'Completed' then '1463'
when FIPS = '36087' and XosStatus not like 'Completed' then '1463'
when FIPS = '39093' and XosStatus not like 'Completed' then '14403'
when FIPS = '17197' and XosStatus not like 'Completed' then '23946'
when FIPS = '12081' and XosStatus not like 'Completed' and CMTID not in ('521','522') then '521'
Else CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and FIPS in ('36027','39093')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23946'
,DocumentNbr = left(REPLACE(DocumentNbr,'R',''),4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(REPLACE(DocumentNbr,'R',''),4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%' and DocumentNbr like 'R%'
and left(REPLACE(DocumentNbr,'R',''),4) = left(recordingdate,4) 
and FIPS in ('17197')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '455'
,DocumentNbr = CASE 
WHEN  left(documentNbr,10) = left(recordingdate,4) + '.' + left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' + Right(DocumentNbr,len(Documentnbr)-10) 
WHEN  left(documentNbr,10) <> left(recordingdate,4) + '.' + left(recordingdate,4) + '.' and left(documentNbr,9) = left(recordingdate,4) + '.' + left(recordingdate,4) 
then  left(recordingdate,4) + '.' + Right(DocumentNbr,len(Documentnbr)-9) ELSE documentNbr END
------,----ImageName =  CASE 
--WHEN  left(documentNbr,10) = left(recordingdate,4) + '.' + left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' + Right(DocumentNbr,len(Documentnbr)-10) 
--WHEN  left(documentNbr,10) <> left(recordingdate,4) + '.' + left(recordingdate,4) + '.' and left(documentNbr,9) = left(recordingdate,4) + '.' + left(recordingdate,4) 
--then  left(recordingdate,4) + '.' + Right(DocumentNbr,len(Documentnbr)-9) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('04013')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1553'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('01003')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '38'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('06083')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '28'
,DocumentNbr = left(recordingdate,4) + '.'  + right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.'  + right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('06111')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '545'
--,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and left(recordingdate,4) >= 2000
and FIPS in ('12011')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13099'
--,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and ImageName like '%Release%'
and FIPS in ('47085')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8471'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) AND left(documentNbr,2) like 'E.' THEN left(recordingdate,4) + '.' + Right(Documentnbr,len(DocumentNbr)-2) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) AND left(documentNbr,2) like 'E.' THEN left(recordingdate,4) + '.' + Right(Documentnbr,len(DocumentNbr)-2) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('47123')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3549'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('08067')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '636'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + DocumentNbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + DocumentNbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48141')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '465'
,DocumentNbr = left(recordingdate,4) + '.' + Right(documentNbr,6) 
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + Right(documentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('17089')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1616'
,DocumentNbr = left(recordingdate,4) + '.' + Right(documentNbr,6)  
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + Right(documentNbr,6)  
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('10003')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1111'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + right(documentNbr,5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + right(documentNbr,5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('12089')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14008'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + right(documentNbr,5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + right(documentNbr,5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('05063')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2066'
,DocumentNbr =  case when left(documentnbr,5) <> left(recordingdate,4) + '.'  then left(recordingdate,4) + '.' + left(documentnbr,PATINDEX('%[a-Z]%',Documentnbr)-1) +  '.' + right(documentnbr,len(documentnbr)-PATINDEX('%[a-Z]%',Documentnbr))
else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) <> left(recordingdate,4) + '.'  then left(recordingdate,4) + '.' + left(documentnbr,PATINDEX('%[a-Z]%',Documentnbr)-1) +  '.' + right(documentnbr,len(documentnbr)-PATINDEX('%[a-Z]%',Documentnbr))
--else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('47059')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1766'
,DocumentNbr =  left(recordingdate,4) + '.'  + right(left(convert(varchar(10),recordingdate,112),6),2)   + '.' +  right(documentNbr,4) 
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  left(recordingdate,4) + '.'  + right(left(convert(varchar(10),recordingdate,112),6),2)   + '.' + right(documentNbr,4) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('53073')










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3089'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('05045')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3475'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('12037')








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8022'
,DocumentNbr =  left(recordingdate,4)  +  Right(left(Documentnbr,5),1) + '.' + Right(documentnbr,4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4)  +  Right(left(Documentnbr,5),1) + '.' + Right(documentnbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('29091')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3203'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('12129')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14345'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('21197')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13900'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('21101')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '24771'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,4) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,4) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('05005')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2470'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('06051')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '15325'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(('0' + Documentnbr),5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + right(Documentnbr,5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('21179')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2775'
--,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('41067')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1208'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('24009')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '787'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('24031')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1276'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('32019')










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3534'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('08077')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8757'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48007')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '522'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'
and FIPS in ('12081')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3038'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and recordingdate <= '2006-12-08'
and FIPS in ('48497')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8870'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and recordingdate > '2006-12-08'
and FIPS in ('48497')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '16997'
--,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('42083')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '948'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('24005')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4391'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + documentNbr ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('37009')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '24646'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and A.FIPS in ('36001')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3099'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('12133')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1022'
,DocumentNbr = left(recordingdate,4) + '.'  + Right(documentNbr,6) 
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.'  + Right(documentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('39049')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27809'
--,DocumentNbr = left(recordingdate,4) + '.'  + Right(documentNbr,6) 
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.'  + Right(documentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('05031')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3162'
--,DocumentNbr = left(recordingdate,4) + '.'  + Right(documentNbr,6) 
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.'  + Right(documentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and left(documentnbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('05031')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8524'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('37195')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4344'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('37125')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27532'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('41015')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '625'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('08013')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7497'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('35027')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7248'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN right(documentNbr,len(documentNbr)-5) else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN right(documentNbr,len(documentNbr)-5) else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48361')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8919'
--,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('01115')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8474'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.'  + documentNbr else documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('47145')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7530'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('08103')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '514'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN  left(recordingdate,4) + '.' + Right(documentNbr,6) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN  left(recordingdate,4) + '.' + Right(documentNbr,6) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('12057')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2384'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('53015')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1841'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('47113')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2934'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('47165')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6233'
,DocumentNbr = CASE WHEN  recordingdate <= '2014-01-31' and left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  recordingdate <= '2014-01-31' and left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48451')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6985'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48005')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4802'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' = left(documentNbr,5) THEN Right(documentNbr,LEN(documentNbr)-5) ELSE documentNbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('48479')








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5598'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('04023')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '432'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('06023')










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '560'
,DocumentNbr =  left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSStatus is null)
and FIPS in ('53035')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '28144'
,DocumentNbr =  left(recordingdate,4) + '.' +  Right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('42119')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27154'
,DocumentNbr =    Right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('47097')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '15298'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('42009')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3281'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('42017')








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1387'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('26081')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '139'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('06113')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1476'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('53077')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7224'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('08001')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2814'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('05007')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2174'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('01097')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2822'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and A.FIPS in ('05051')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '26417'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('06009')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '430'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('06009')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7991'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('48441')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7672'
,DocumentNbr =  left(recordingdate,4) + '.' + left(Right(documentNbr,len(documentNbr)-5),4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + left(Right(documentNbr,len(documentNbr)-5),4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('02110')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4363'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('08107')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1590'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('12083')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '552'
,DocumentNbr = left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,2)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,2)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) = left(recordingdate,4) 
and FIPS in ('29510')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '990'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('34029')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14401'
,DocumentNbr = left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('29510')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3237'
,DocumentNbr = left(recordingdate,4) + '.' +  Right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('39097')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '22802'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('16057')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27908'
,DocumentNbr =  Right(documentNbr,len(documentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + Right(documentNbr,len(documentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('05059')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2958'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('37159')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3531'
,DocumentNbr = case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('08029')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5133'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('37109')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2023'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + REPLACE(Documentnbr,'T','') else Documentnbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + REPLACE(Documentnbr,'T','') else Documentnbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('47051')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '204'
,DocumentNbr = CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  CASE WHEN  left(recordingdate,4) + '.' <> left(documentNbr,5) THEN left(recordingdate,4) + '.' + Documentnbr else Documentnbr END
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('48121')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1255'
,DocumentNbr = left(recordingdate,4) + '.' + DocumentNbr
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + DocumentNbr
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('12091')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1546'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('48485')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '52'
,DocumentNbr = case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then DocumentNbr else   left(recordingdate,4) + '.' + right(DocumentNbr,6) end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then DocumentNbr else   left(recordingdate,4) + '.' + right(DocumentNbr,6) end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSStatus is null)
and FIPS in ('06001')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1212'
,DocumentNbr = case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
when left(documentNbr,4) = left(recordingdate,4) and documentnbr not like  '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
--when left(documentNbr,4) = left(recordingdate,4) and documentnbr not like  '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('05119')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14003'
,DocumentNbr = right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('01095')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5680'
,DocumentNbr = case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
when left(documentNbr,4) =  left(recordingdate,4) and documentnbr not like '%.%' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
Else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
--when left(documentNbr,4) =  left(recordingdate,4) and documentnbr not like '%.%' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
--Else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('08037')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2940'
,DocumentNbr = case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
when left(documentNbr,4) =  left(recordingdate,4) and documentnbr not like '%.%' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
Else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
--when left(documentNbr,4) =  left(recordingdate,4) and documentnbr not like '%.%' then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
--Else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTatus is null)
and FIPS in ('37129')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9754'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('37011')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '114'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('06079')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5225'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('08015')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '264'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('12095')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '263'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('12095')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6479'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('53007')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6479'
,DocumentNbr = right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('53007')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3540'
,DocumentNbr =  case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('08093')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5454'
,DocumentNbr = right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('55055')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7171'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('08105')









--Update [dbo].[z_Images_To_Pull]
--Set CMTID = '783'
--,DocumentNbr = left(recordingdate,4) + '.' + DocumentNbr
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + DocumentNbr
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL
--where XosStatus not like 'Completed' and DocumentNbr not like '%.%' 
--and left(DocumentNbr,4) <> left(recordingdate,4) 
--and FIPS in ('25009')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1068'
,DocumentNbr = right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr  like '%.%' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('24035')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1463'
,DocumentNbr = left(recordingdate,4) + '.' + right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XosStatus is null) and DocumentNbr  like '%.%' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('36047')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '90'
,DocumentNbr = left(recordingdate,4) + '.' + right(DocumentNbr,7)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,7)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr  like '%.%' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('06095')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2069'
,DocumentNbr = case when left(DocumentNbr,5) <> left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) <> left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('47119')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '637'
,DocumentNbr = case when left(documentNbr,5) <> left(recordingdate,4) + '.' then   left(recordingdate,4) + '.' + REPLACE(DocumentNbr,'F','') 
when left(documentNbr,9) = left(recordingdate,4) + '.' + left(recordingdate,4) then   left(recordingdate,4) + '.' + RIGHT(REPLACE(DocumentNbr,'F',''),LEN(REPLACE(DocumentNbr,'F',''))-9)
else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) <> left(recordingdate,4) + '.' then   left(recordingdate,4) + '.' + REPLACE(DocumentNbr,'F','') 
--when left(documentNbr,9) = left(recordingdate,4) + '.' + left(recordingdate,4) then   left(recordingdate,4) + '.' + RIGHT(REPLACE(DocumentNbr,'F',''),LEN(REPLACE(DocumentNbr,'F',''))-9)
--else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('08059')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1511'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and left(documentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('53005')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '908'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr  like '%.%' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('26025')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23946'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and DocumentNbr not like 'R%'
and left(DocumentNbr,4) = left(recordingdate,4) 
and Convert(datetime,recordingdate) > '20150630'
and FIPS in ('17197')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '10489'
,DocumentNbr =  left(DocumentNbr,4) + '.' + right(DocumentNbr,4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XOSStatus is null) 
and left(DocumentNbr,4) = left(recordingdate,4) 
and FIPS in ('37081')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14312'
,DocumentNbr = left(DocumentNbr,4) + '.' + right(DocumentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('33013')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5100'
,DocumentNbr = left(Recordingdate,4) + '.' + right(DocumentNbr,9)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(Recordingdate,4) + '.' + right(DocumentNbr,9)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('34017')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '28134'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('42001')








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1141'
,DocumentNbr =  left(recordingdate,4) + '.' + Right(DocumentNbr,5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + Right(DocumentNbr,5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and FIPS in ('41071')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27259'
,DocumentNbr =  right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('47133')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8498'
,DocumentNbr =  left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,3)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,3)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('53055')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3641'
,DocumentNbr =   Right(documentNbr,len(documentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  Right(documentNbr,len(documentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('55063')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27211'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'
and left(DocumentNbr,5) <> left(recordingdate,4) + '.'
and FIPS in ('47141')







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '22777'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) <> left(recordingdate,4) 
and FIPS in ('01101')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3542'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) = left(recordingdate,4) 
and FIPS in ('08097')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '22708'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) = left(recordingdate,4) 
and FIPS in ('41045')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14735'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,4) = left(recordingdate,4) 
and FIPS in ('17201')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2992'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('41007')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8102'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('42095')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '436'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('06087')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3550'
,DocumentNbr =  right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('08085')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1289'
,DocumentNbr =  left(recordingdate,4) + '.' + right(DocumentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XOSSTatus is null)
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('01117')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9569'
,DocumentNbr =  left(recordingdate,4) + '.' + right(DocumentNbr,5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XOSSTatus is null)
and DocumentNbr like '%.%'
and FIPS in ('01103')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '65'
,DocumentNbr =  right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('06085')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3779'
,DocumentNbr =  right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr  like '%.%' 
and left(DOcumentNbr,4) = left(recordingdate,4) 
and FIPS in ('08045')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '287'
,DocumentNbr =  REPLACE(DocumentNbr,'_','.')
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE(DocumentNbr,'_','.')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr  like '%-%' 
and left(DOcumentNbr,4) = left(recordingdate,4) 
and FIPS in ('12127')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9779'
,DocumentNbr =  left(recordingdate,4) + '.' + Right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DOcumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('47011')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1855'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DOcumentNbr,5) = left(recordingdate,4) + '.'
and Documentnbr like '%.%.%'
and FIPS in ('47011')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '287'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and CMTID = '286'
and left(DOcumentNbr,4) = left(recordingdate,4) 
and FIPS in ('12127')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1148'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('36027')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1576'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('12033')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8194'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('36093')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9514'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and left(DocumentNbr,5) = left(recordingdate,4) + '.'
and FIPS in ('36111')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13797'
--,DocumentNbr =  case when documentNbr like '%_%' and charindex('_',documentNbr) > 4 then left(documentNbr,charindex('_',documentNbr)-1) + '.' + right(documentNbr,4)
--when documentNbr like '%_%' and charindex('_',documentNbr) <= 4 then left(documentNbr,charindex('_',documentNbr)) + '.' + right(documentNbr,4)
--Else documentNbr end
--------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when documentNbr like '%_%' and charindex('_',documentNbr) > 4 then left(documentNbr,charindex('_',documentNbr)-1) + '.' + right(documentNbr,4)
--when documentNbr like '%_%' and charindex('_',documentNbr) <= 4 then left(documentNbr,charindex('_',documentNbr)) + '.' + right(documentNbr,4)
--Else documentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,4) <> left(recordingdate,4)
and A.FIPS in ('37147')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7113'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,4) = left(recordingdate,4)
and A.FIPS in ('37181')









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '6037' and XosStatus not like 'Completed' and DocumentNbr like '17.%' then '14219'
Else CMTID end
,[DocumentNbr] = '20' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + '20' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '17.%'
and FIPS in ('6037')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '661'
,[DocumentNbr] = left(recordingdate,4) + '.' + Right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  left(recordingdate,4) + '.' + Right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' --and DocumentNbr not like '%.%'
and FIPS in ('11001')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1403'
,[DocumentNbr] = case when left([DocumentNbr],5) <> left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) <> left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37119')
and left([DocumentNbr],5) = left(recordingdate,4) + '.'  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7143'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left([DocumentNbr],4) = left(recordingdate,4)
and FIPS in ('37155')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1608'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left([DocumentNbr],4) = left(recordingdate,4)
and FIPS in ('39099')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1692'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left([DocumentNbr],4) = left(recordingdate,4)
and FIPS in ('39139')







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1031'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left([DocumentNbr],4) <> left(recordingdate,4)
and A.FIPS in ('37119') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5367'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37119')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3027'
,[DocumentNbr] = left(recordingdate,4) + '.' + case when left(right([DocumentNbr],len([DocumentNbr])-5),4) = left(recordingdate,4) then Right([DocumentNbr],len([DocumentNbr])-9) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + case when left(right([DocumentNbr],len([DocumentNbr])-5),4) = left(recordingdate,4) then Right([DocumentNbr],len([DocumentNbr])-9) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left(right([DocumentNbr],len([DocumentNbr])-5),4) = left(recordingdate,4)
and A.FIPS in ('39057')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4700'
,[DocumentNbr] = left(recordingdate,4) + '.' + Right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + Right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left([DocumentNbr],5) = left(recordingdate,4) + '.'
and A.FIPS in ('39063')


--Update [dbo].[z_Images_To_Pull]
--Set CMTID = '14219'
--,[DocumentNbr] = REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL
--FROM [dbo].[z_Images_To_Pull] as A join X_Custom_Output as B on 
--A.Inputkey = B.[INPUT Ref#]
--where (XosStatus not like 'Completed' or XosStatus is null) --and left([DocumentNbr],5) <> left(recordingdate,4) + '.'
--and A.FIPS in ('06037')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '11'
,[DocumentNbr] = REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null) --and left([DocumentNbr],5) <> left(recordingdate,4) + '.'
and A.FIPS in ('06037')

--UPdate A
--Set A.Doc_Src_IND = B.Doc_Src_IND
--Select  A.STATIC_DOCNUM, A.XosStatus, A.CmtId, B.CmtId, B.Doc_Src_Ind, A.StatusCheckDate
--From [z_Images_To_Pull] as A join 
--w_TRanshist_III as B on 
--A.INPUTKey = B.Raw_ID
--and A.STATIC_DOCNUM = B.DocumentNbr
--where A.FIPS in ('06037')
--Order by A.StatusCheckDate desc


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '108'
--,[DocumentNbr] = REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],7),'..','.')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null) --and left([DocumentNbr],5) <> left(recordingdate,4) + '.'
and A.FIPS in ('06039')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '540'
,[DocumentNbr] = REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],5),'..','.')
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE(left(recordingdate,4) + '.' + right([DocumentNbr],5),'..','.')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null) --and left([DocumentNbr],5) <> left(recordingdate,4) + '.'
and A.FIPS in ('06105')




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1975'
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' --and left([DocumentNbr],5) <> left(recordingdate,4) + '.'
and A.FIPS in ('47025')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5452'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('55027')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4447'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('55139')







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1486'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('35001')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '151'
,[DocumentNbr] = left(recordingdate,4) + '.' + right(documentnbr,5) 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(documentnbr,5) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06057')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2818'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left([DocumentNbr],5) = left(recordingdate,4) + '.'
and A.FIPS in ('45079')








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '12087' and XosStatus not like 'Completed' and DocumentNbr not like '%.%' then '526'
Else CMTID end
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%'
and FIPS in ('12087')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '526'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(DocumentNbr,5) = Left(recordingdate,4) + '.'
and FIPS in ('12087')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '8938'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(DocumentNbr,5) = Left(recordingdate,4) + '.'
and FIPS in ('48073')







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '12099' and XosStatus not like 'Completed' and DocumentNbr not like '%.%' 
and left(DocumentNbr,4) = left(recordingdate,4) then '270'
Else CMTID end
,[DocumentNbr] = left([DocumentNbr],4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%'
and FIPS in ('12099') and left(DocumentNbr,4) = left(recordingdate,4)



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '17043' and XosStatus not like 'Completed' and DocumentNbr not like '%.%' then '290'
Else CMTID end
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%'
and FIPS in ('17043')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '17043' and XosStatus not like 'Completed' and DocumentNbr like '%.%' and CMTID = '0' then '290'
Else CMTID end
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and CMTID = '0' 
and FIPS in ('17043')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '17043' and XosStatus not like 'Completed' and DocumentNbr like '%.%' and CMTID = '290' then '290'
Else CMTID end
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and CMTID = '290' 
and FIPS in ('17043')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '2204'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('37021') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '5074'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' <> left(documentNbr,5)  
and FIPS in ('37025') and CMTID = 0



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '2204'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' <> left(documentNbr,5)  
and FIPS in ('37021') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '3546'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('08039') and CMTID = 0





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '8222'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('47047') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '642'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('06109') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1574'
,[DocumentNbr] =  case when left(DocumentNbr,4) = left(recordingdate,4) and DocumentNbr not like '%.%' then  left(recordingdate,4) + '.'+ right([DocumentNbr],len([DocumentNbr])-4)
when left(DocumentNbr,5) = left(recordingdate,4) + '.' then DocumentNbr else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,4) = left(recordingdate,4) and DocumentNbr not like '%.%' then  left(recordingdate,4) + '.'+ right([DocumentNbr],len([DocumentNbr])-4)
--when left(DocumentNbr,5) = left(recordingdate,4) + '.' then DocumentNbr else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSSTATUS is null)
and FIPS in ('12005') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '518'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('12069') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '14151'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('36023') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1578'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('12035') and CMTID = 0


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1584'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and left(recordingdate,4) + '.' <> left(documentNbr,5)  
and FIPS in ('12055') and CMTID = 0








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '3279'
,[DocumentNbr] = left(recordingdate,4) + '.' + left(right([DocumentNbr],len([DocumentNbr])-5),4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + left(right([DocumentNbr],len([DocumentNbr])-5),4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('02122')  and CMTID = '3279'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '2247'
,[DocumentNbr] = case when left(documentnbr,10) = left(recordingdate,4) + '.' +  left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr) - 5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,10) = left(recordingdate,4) + '.' +  left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr) - 5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%'
and FIPS in ('19181')  






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '524'
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr not like '%.%' and left(recordingdate,4) <> left(documentNbr,4)  
and FIPS in ('12085')  and CMTID = '0'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '27190'
,[DocumentNbr] =  right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5)  
and FIPS in ('47121')  



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1069'
,[DocumentNbr] =  left([DocumentNbr],5) +  left(right([DocumentNbr],len([DocumentNbr])-5),3) + '.' +   right([DocumentNbr],len([DocumentNbr])-8)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],5) +  left(right([DocumentNbr],len([DocumentNbr])-5),3) + '.' +   right([DocumentNbr],len([DocumentNbr])-8)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5) 
and right( documentNbr,len(documentNbr)-5) not like '%.%'
and FIPS in ('04019')  and CMTID = '1069'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '393'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' and DocumentNbr like '%.%' and left(recordingdate,4) + '.' = left(documentNbr,5) 
and FIPS in ('06077')  and CMTID = '0'










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1217'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then  [DocumentNbr] else left(recordingdate,4) + '.' + [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then  [DocumentNbr] else left(recordingdate,4) + '.' + [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('26125')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '12081' and XosStatus not like 'Completed' and DocumentNbr like '2017.410%' then '522'
Else CMTID end
,[DocumentNbr] = REPLACE([DocumentNbr],'410','')
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE([DocumentNbr],'410','')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and DocumentNbr like '2017.410%'
and FIPS in ('12081')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '5193'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('48113') and recordingdate > '2005-09-23'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '414'
,[DocumentNbr] = left(recordingdate,4) + '.' + right(left(STATIC_DOCNUM,7),3) + '.' + Right(STATIC_DOCNUM,4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' 
+ right(left(STATIC_DOCNUM,7),3) + '.' + Right(STATIC_DOCNUM,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XosStatus is null)
and FIPS in ('48113')  and recordingdate <= '2005-09-23'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '53029' and XosStatus not like 'Completed' and CMTID = '0' then '4153'
Else CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and CMTID = '0'
and FIPS in ('53029')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '27433'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'  
and A.FIPS in ('37141')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '12086' and XosStatus not like 'Completed' and DocumentNbr like '2017.R%' then '507'
Else CMTID end
,[DocumentNbr] = REPLACE([DocumentNbr],'R','')
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE([DocumentNbr],'R','')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XosStatus is null)  and DocumentNbr like '2017.R%'
and FIPS in ('12086')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case when  DocumentNbr like '%R.%' then '6932'
Else CMTID end
,[DocumentNbr] = REPLACE([DocumentNbr],'R','')
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + REPLACE([DocumentNbr],'R','')
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and  DocumentNbr like '%R.%'
and FIPS in ('18091')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case 
when FIPS = '12086' and XosStatus not like 'Completed' and DocumentNbr not like '2017.R%' then '506'
Else CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and DocumentNbr not like '2017.R%'
and FIPS in ('12086')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '507'
,[DocumentNbr] = left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed'  and DocumentNbr like 'R2017%'
and FIPS in ('12086')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1106'
,[DocumentNbr] = case when left(DocumentNbr,5) =  left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) =  left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XosStatus is null)
and FIPS in ('12109')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '8920'
--,[DocumentNbr] = case when left(DocumentNbr,5) =  left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) =  left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XosStatus is null)
and FIPS in ('48339')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '4121'
,[DocumentNbr] = left(recordingdate,4) + '.' +  right(DocumentNbr,6) 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  right(DocumentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XosStatus is null)
and FIPS in ('48423')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1735'
--,[DocumentNbr] = left(recordingdate,4) + '.' +  right(DocumentNbr,6) 
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  right(DocumentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XosStatus is null)
and FIPS in ('49045')






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '2661'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('17099')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '4368'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('37127')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1376'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('37051')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '3023'
,[DocumentNbr] = case when left(documentNbr,4) <> Left(recordingdate,4) then left(recordingdate,4) + '.' + documentNbr else documentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,4) <> Left(recordingdate,4) then left(recordingdate,4) + '.' + documentNbr else documentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XOSStatus is null)
and FIPS in ('17113')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '2361'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('17179')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '26665'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed'  or XOSStatus is null)
and FIPS in ('19013')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID =  '1005'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XosStatus is null)
and FIPS in ('18003')











Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '24582'
,A.[DocumentNbr] = left(B.RecordingDate,4) + '.' + B.DocumentNbr
--,[----ImageName] = RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + left(B.RecordingDate,4) + '.' + B.DocumentNbr
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on A.[INPUTKey] = B.RAW_ID
and A.[DocumentNbr]  = B.DocumentNbr

where A.FIPS in ('12107') and (XosStatus not like 'COmpleted' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
CMTID = '783'
--,[DocumentNbr] = case when left(documentnbr,5) <> left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
--,[----ImageName] = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) <> left(recordingdate,4) + '.' then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] A
where A.FIPS in ('25009') and (XosStatus not like 'COmpleted' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.[DocumentNbr] = case 
when B.REF_ID like '33414298' then '2636.1'
when B.REF_ID like '34312545' then '2638.4226'
when B.REF_ID like '33869518' then '2642.4938'
when B.REF_ID like '32295217' then '2643.558'
else A.[DocumentNbr] end
--,[----ImageName] = 
--case 
--when B.REF_ID like '33414298' then RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + '2636.1'
--when B.REF_ID like '34312545' then RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + '2638.4226'
--when B.REF_ID like '33869518' then RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + '2642.4938'
--when B.REF_ID like '32295217' then RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + '2643.558'

--else [----ImageName] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where  B.REF_ID like '33414298'
or B.REF_ID like '34312545'
or B.REF_ID like '33869518'
or B.REF_ID like '32295217'


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.[DocumentNbr] = left(B.RecordingDate,4) + '.' + substring(Right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr)-2), patindex('%[^0]%',Right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr)-2)),250)
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  left(B.RecordingDate,4) + '.' + substring(Right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr)-2), patindex('%[^0]%',Right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr)-2)),250)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '12081' and (XosStatus not like 'Completed' or XosStatus is null)




Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.FIPS = '36003' and B.Doc_Src_Ind in ('D','M') then '15059'
when A.FIPS = '36003' and B.Doc_Src_Ind like 'REL' then '22667'

when A.FIPS = '36033' and B.Doc_Src_Ind in ('D','M') then '14610'

when A.FIPS = '36053' and B.Doc_Src_Ind in ('D','M') then '14651'

when A.FIPS = '36123' and B.Doc_Src_Ind like 'D' then '22898'
when A.FIPS = '36123' and B.Doc_Src_Ind like 'M' then '22904'

when A.FIPS = '37031' and B.Doc_Src_Ind in ('D','M') then '14245'

else A.CMTID end

,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('36003','36033','36123','37031') and (XosStatus not like 'Completed' or XosStatus is null)
and (A.CMTID = 0 or A.CMTID is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when B.Doc_Src_Ind like 'D' and B.RecordingDate > '2015-10-30' then '24645'
when B.Doc_Src_Ind like 'M' and B.RecordingDate > '2015-10-30' then '24646'
else A.CMTID end
,DocumentNbr = left(A.recordingdate,4) + '.' + A.DocumentNbr 
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  left(A.recordingdate,4) + '.' + A.DocumentNbr 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('36001') and (XosStatus not like 'Completed' or XosStatus is null)
and B.RecordingDate > '2015-10-30'
--and (A.CMTID = 0 or A.CMTID is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when B.Doc_Src_Ind like 'D' and B.RecordingDate < '2015-10-30' then '6313'
when B.Doc_Src_Ind like 'M' and B.RecordingDate < '2015-10-30' then '6314'
else A.CMTID end
,A.[DocumentNbr] = case when charindex('.',B.DocumentNbr) > 0
			Then 
			 right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr))
			else B.DocumentNbr end
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  case when charindex('.',B.DocumentNbr) > 0
--			Then 
--			 right(B.DocumentNbr,len(B.DocumentNbr)-charindex('.',B.DocumentNbr))
--			else B.DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('36001') and (XosStatus not like 'Completed' or XosStatus is null)
and B.RecordingDate < '2015-10-30'



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  '14894'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '37107' and A.CMTID like '13959' and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case 
when A.FIPS = '38015' then '8853'
when A.FIPS = '38017' then '22871'
else A.CMTID end
,A.[DocumentNbr] = Right(substring(B.DocumentNbr, patindex('%.%',B.DocumentNbr), 250),len(substring(B.DocumentNbr, patindex('%.%',B.DocumentNbr), 250))-1)
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  Right(substring(B.DocumentNbr, patindex('%.%',B.DocumentNbr), 250),len(substring(B.DocumentNbr, patindex('%.%',B.DocumentNbr), 250))-1)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('38015','38017')  and (XosStatus not like 'Completed' or XosStatus is null)
and patindex('%.%',B.DocumentNbr) > 0
and (A.CMTID = 0 or A.CMTID is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case when A.CMTID = '995' then '17233' else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '34003' and A.CMTID like '995' and (XosStatus not like 'Completed' or XosStatus is null)

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =   '17234' 
,DocumentNbr = left(A.recordingdate,4) + '.' + right(A.DocumentNbr,5)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  left(A.recordingdate,4) + '.' + right(A.DocumentNbr,5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('34003') and (XosStatus not like 'Completed' or XosStatus is null)
and A.CMTID not like '995'






Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case when A.CMTID = '0' then '9345' else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '45019' and A.CMTID like '0' and (XosStatus not like 'Completed' or XosStatus is null)


--Update A
--Set 
--A.CMTID =  case when A.CMTID = '0' then '15063' else A.CMTID end
--,A.[DocumentNbr] = REPLACE(A.[DocumentNbr],'M','')
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  REPLACE(A.[DocumentNbr],'M','')
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL
--From [dbo].[z_Images_To_Pull] as A 
--join w_TransHist_II as B on 
--A.[INPUTKey] = B.RAW_ID
--and A.FIPS = B.FIPS
--and A.[DocumentNbr]  = B.DocumentNbr
--where A.FIPS = '36013' and A.CMTID like '0' and (XosStatus not like 'Completed' or XosStatus is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  '15063'
,[DocumentNbr] = left(A.recordingdate,4) + '.' +  Right(documentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(A.recordingdate,4) + '.' +  Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
where A.FIPS = '36013'  and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'



------26075---Year.Doc
Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case when A.CMTID = '0' then '22838' else A.CMTID end
,A.[DocumentNbr] = Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '26075' and A.CMTID like '0' and (XosStatus not like 'Completed' or XosStatus is null)


------26005---Year.DocID
Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case when A.CMTID = '0' or A.CMTID is null then '9768' else A.CMTID end
,A.[DocumentNbr] = left(B.RecordingDate,4) + '.' + SUBSTRING(B.[DocumentNbr], PATINDEX('%[^0]%', B.[DocumentNbr]), LEN(B.[DocumentNbr]))
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  left(B.RecordingDate,4) + '.' + SUBSTRING(B.[DocumentNbr], PATINDEX('%[^0]%', B.[DocumentNbr]), LEN(B.[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '26005' and (A.CMTID like '0' or A.CMTID is null) and (XosStatus not like 'Completed' or XosStatus is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  '1221' 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
where A.FIPS = '26005' and 
 (XosStatus not like 'Completed' or XosStatus is null)
 and left(documentnbr,5) <> left(recordingdate,4) + '.'


------17023----
Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case 
when A.CMTID = '22814' then '22815'
When A.CMTID = '22813' then '22816'
 else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '17023' and (A.CMTID in ('22814','22813')) and (XosStatus not like 'Completed' or XosStatus is null)


------17019----
Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case 
when A.CMTID = '3104' then '15088' else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '17019' and A.CMTID like '3104' and (XosStatus not like 'Completed' or XosStatus is null)


------17029---Year.DocID
Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  case when A.CMTID = '0' then '22838' else A.CMTID end
,A.[DocumentNbr] = Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS = '17029' and (A.CMTID like '0' or A.CMTID is null) and (XosStatus not like 'Completed' or XosStatus is null)




Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '2950' then '24562'
when A.CMTID = '2951' then '24563'
else A.CMTID end
,[DocumentNbr] = left(A.recordingdate,4) + '.' + Right(A.DocumentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(A.recordingdate,4) + '.' + Right(A.DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]

where A.FIPS in ('45015') and (XosStatus not like 'Completed' or XosStatus is null)
and A.RecordingDate >= '2015-09-11'



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1223'
,[DocumentNbr] = left(A.recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(A.recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('53033') and (XosStatus not like 'Completed' or XosStatus is null)

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1017'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.' then right(documentNbr,len(documentNbr)-5) else documentNbr end 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then right(documentNbr,len(documentNbr)-5) else documentNbr end 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('24013') and (XosStatus not like 'Completed' or XosStatus is null)







Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1557'
,[DocumentNbr] = left(A.recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(A.recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + Right(documentNbr,4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('53061') and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '13835'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('37049') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) <> left(recordingdate,4) + '.'




Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '6302'
,[DocumentNbr] = left(A.recordingdate,4) + '.' +  Right(documentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(A.recordingdate,4) + '.' +  Right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('36005') and (XosStatus not like 'Completed' or XosStatus is null)




Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '3600'
,[DocumentNbr] = case when left(documentNbr,5) = left(A.recordingdate,4) + '.' then Right(documentNbr,len(documentNbr)-5) else documentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(A.recordingdate,4) + '.' then Right(documentNbr,len(documentNbr)-5) else documentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('55025') and (XosStatus not like 'Completed' or XosStatus is null)
and A.recordingdate < '2013-02-01'



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '14353'
--,[DocumentNbr] = Right(documentNbr,len(documentNbr)-5)
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + Right(documentNbr,len(documentNbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('55025') and (XosStatus not like 'Completed' or XosStatus is null)
and A.recordingdate >= '2013-02-01'





Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '8485'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('08071') and (XosStatus not like 'Completed' or XosStatus is null)

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '14651'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('36053') and (XosStatus not like 'Completed' or XosStatus is null)
and left(recordingdate,4) + '.' = left(documentnbr,5)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '3031'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('36071') and (XosStatus not like 'Completed' or XosStatus is null)
and left(recordingdate,4) + '.' <> left(documentnbr,5)

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '8037'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('10001') and (XosStatus not like 'Completed' or XosStatus is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1032'
,[DocumentNbr] = right(documentnbr,len(documentnbr)-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(documentnbr,len(documentnbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('17163') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1139'
,[DocumentNbr] = left(documentnbr,5) + '.' + right(documentnbr,len(documentnbr)-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(documentnbr,5) + '.' + right(documentnbr,len(documentnbr)-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('29095') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,4) = left(recordingdate,4)

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1078'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('31109') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '3124'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('35005') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) <> left(recordingdate,4) + '.'









Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '1334'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('18057') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'










Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '0' then '25771'
else A.CMTID end
,A.[DocumentNbr] = Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
--,[----ImageName] = 
-- RAW_ID + '_' + 
--	  case when ltrim(rtrim([DocumentType])) is null or ltrim(rtrim([DocumentType])) like '' then 'TR' else  ltrim(rtrim([DocumentType])) end
--	  + '_' + 
--	  Right(B.[DocumentNbr],len(B.[DocumentNbr])-Charindex('.',B.[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('47147') and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '25771'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
where A.FIPS in ('47147') and (XosStatus not like 'Completed' or XosStatus is null)
and CMTID = '0'



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '28736'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
where A.FIPS in ('54049') and (XosStatus not like 'Completed' or XosStatus is null)
and CMTID = '0'






Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '190'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
--join w_TransHist_II as B on 
--A.[INPUTKey] = B.RAW_ID
--and A.FIPS = B.FIPS
--and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('32031') and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  '190' 
,[DocumentNbr] =  right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
 join [zCust_USBANK_USSPD].[dbo].[x_custom_OUTPUT] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('32031') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID =  '9438' 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
 join [zCust_USBANK_USSPD].[dbo].[x_custom_OUTPUT] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48325') and (XosStatus not like 'Completed' or XosStatus is null)
and left(documentnbr,5) = left(recordingdate,4) + '.'




--Update A
--Set 
--A.CMTID = case 
--when A.CMTID = '0' then '14422'
--else A.CMTID end
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL

--From [dbo].[z_Images_To_Pull] as A 
--join w_TransHist_II as B on 
--A.[INPUTKey] = B.RAW_ID
--and A.FIPS = B.FIPS
--and A.[DocumentNbr]  = B.DocumentNbr
--where A.FIPS in ('18141') and (XosStatus not like 'Completed' or XosStatus is null)


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '0' then '6268'
else A.CMTID end
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
 join [zCust_USBANK_USSPD].[dbo].[x_custom_OUTPUT] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53017') and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '0' then '474'
else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
 join [zCust_USBANK_USSPD].[dbo].[x_custom_OUTPUT] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53067') and (XosStatus not like 'Completed' or XosStatus is null)









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7876'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where XosStatus not like 'Completed' 
and FIPS in ('53047')




Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '0' then '23067'
else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('48465') and (XosStatus not like 'Completed' or XosStatus is null)



Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = case 
when A.CMTID = '0' then '17352'
else A.CMTID end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL

From [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A 
join [zCust_USBANK_USSPD].[dbo].[w_TransHist_II] as B on 
A.[INPUTKey] = B.RAW_ID
and A.FIPS = B.FIPS
and A.[DocumentNbr]  = B.DocumentNbr
where A.FIPS in ('39029') and (XosStatus not like 'Completed' or XosStatus is null)




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1091'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('17031') and 
convert(date,A.RecordingDate) > convert(date,'20030414') and DocumentNbr like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3106'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('29097') and 
left(DocumentNbr,5) = left(recordingdate,4) + '.'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '80'
,[DocumentNbr] = case when left(documentnbr,5) <> left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' +   right([DocumentNbr],6) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) <> left(recordingdate,4) + '.' then  left(recordingdate,4) + '.' +   right([DocumentNbr],6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('06075') 





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '270'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12099') and 
CMTID = '269'
and left(documentnbr,4) = left(recordingdate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '269'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12099')  
and left(documentnbr,4) <> left(recordingdate,4)
and documentnbr like '%.%'











Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1091'
,[DocumentNbr] = left(REcordingdate,4) + '.' + convert(varchar(3),datediff("DD",left(recordingdate,4) + '-01-01',REcordingdate) )+ '.' + right([DocumentNbr],5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(REcordingdate,4) + '.' + convert(varchar(3),datediff("DD",left(recordingdate,4) + '-01-01',REcordingdate) )+ '.' + right([DocumentNbr],5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('17031') and [DocumentNbr] not like '%.%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1498'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(recordingdate,4) then left(REcordingdate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(recordingdate,4) then left(REcordingdate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('17093') 





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7116'
,[DocumentNbr] =  left(REcordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(REcordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('37175') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5709'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26045') and A.recordingdate < '2012-07-06'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13632'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('26045')  and A.recordingdate >= '2012-07-06'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '26602'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(recordingdate,4) + '.' then  right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('22079') 








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '17234'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('34003') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1336'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('34025') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '630'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left(documentNbr,5) = Left(recordingdate,4) + '.'
and A.FIPS in ('08035') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5592'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left(documentNbr,5) = Left(recordingdate,4) + '.'
and A.FIPS in ('41043') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9552'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('36063') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '592'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('24003') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4374'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55071')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '879'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('24033')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '879'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' and left(documentNbr,4) <> left(recordingdate,4)
and A.FIPS in ('24033')


Update [zCust_USBANK_USSPD].[dbo].[A]
Set 
A.CMTID = '879'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.' then right(documentNbr,len(documentNbr)-5) else documentNbr end 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then right(documentNbr,len(documentNbr)-5) else documentNbr end 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where A.FIPS in ('24033') and (XosStatus not like 'Completed' or XosStatus is null)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1207'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('24037') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7858'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('35015') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '817'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39153') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13191'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('40143') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5890'
,[ImageLink] = NULL
,[DocumentNbr] = left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('45041') 
and LTRIM(RTRIM([DocumentNbr]))   like '[a-Z]%'
and RIght(left([DocumentNbr],2),1) <> '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5890'
,[ImageLink] = NULL
,[DocumentNbr] = LTRIM(RTRIM([DocumentNbr]))
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + LTRIM(RTRIM([DocumentNbr]))
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('45041') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '207'
,[ImageLink] = NULL
,[DocumentNbr] = left(recordingdate,4) + '.' + right(documentnbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(documentnbr,6)
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48085') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9843'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47073') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1661'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and DocumentNbr like '%.%.%'
and A.FIPS in ('47073') 







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9957'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47179') 



















Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27253'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('05131') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27253'
,[DocumentNbr] = left(recordingdate,4) + '.' +  right(documentnbr,len(documentnbr)-7) 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  right(documentnbr,len(documentnbr)-7) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('05131') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1570'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12001') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '982'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('01073') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3481'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentnbr,len(documentnbr)-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('08117') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = 
case when left(documentnbr,5) = left(recordingdate,4) + '.' then '3132' else '3130'end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('37179') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1859'
,[DocumentNbr] = left(RecordingDate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47001') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9744'
--,[DocumentNbr] = left(RecordingDate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('25025')  and [DocumentNbr] not like '%.%'








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7605'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('34013') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7605'
,[DocumentNbr] = left(RecordingDate,4) + '.' + Right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + Right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and  left(documentNbr,5) = left(RecordingDate,4) + '.'
and A.FIPS in ('34013') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '22893'
,[DocumentNbr] = case when left(RecordingDate,4) + '.'  <> left(documentnbr,5) then left(RecordingDate,4) + '.' + Right([DocumentNbr],6) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(RecordingDate,4) + '.'  <> left(documentnbr,5) then left(RecordingDate,4) + '.' + Right([DocumentNbr],6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('35045') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1613'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('41051') 








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2345'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('25025')  and left(recordingdate,4) < '2009'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '781'
,DocumentNbr = case when left(DocumentNbr,4) = left(recordingdate,4) then DocumentNbr else  left(REcordingDate,4) + '.' + DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('25025')  and left(recordingdate,4) >= '2009'





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '238'
,[DocumentNbr] = left(RecordingDate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12021') 
and A.[DocumentNbr] not like '%.%'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1468'
,[DocumentNbr] = left(RecordingDate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39017') 
and A.[DocumentNbr] not like '%.%'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1361'
,[DocumentNbr] = case when left(documentnbr,5) = left(RecordingDate,4) + '.' then [DocumentNbr] else left(RecordingDate,4) + '.' + [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(RecordingDate,4) + '.' then [DocumentNbr] else left(RecordingDate,4) + '.' + [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('49005') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5681'
,[DocumentNbr] = case when left(documentnbr,5) = left(RecordingDate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else  [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(RecordingDate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else  [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53063') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1158'
,[DocumentNbr] = left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],7)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],7)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47037') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3509'
,[DocumentNbr] = left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],7)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],7)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('42129') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1732'
,[DocumentNbr] = left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('20091') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5908'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('20173') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2072'
,[DocumentNbr] = left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('26049') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '199'
,[DocumentNbr] = left(RecordingDate,4) + '.' +  right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' +  right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('48439') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2719'
,[DocumentNbr] =  right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('49021') 
and left([DocumentNbr],5) = left(recordingdate,4) + '.'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '841'
,[DocumentNbr] = left(RecordingDate,4) + '.' +  right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' +  right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('48453') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27571'
,[DocumentNbr] = left(RecordingDate,4) + '.' +  right([DocumentNbr],5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' +  right([DocumentNbr],5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('48473') 










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27162'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-charindex('.',[DocumentNbr]))
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-charindex('.',[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47107')  and left([DocumentNbr],4) = left(RecordingDate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8107'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('42133') and left([DocumentNbr],4) = left(RecordingDate,4)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27204'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-charindex('.',[DocumentNbr]))
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-charindex('.',[DocumentNbr]))
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47125')  and left([DocumentNbr],4) = left(RecordingDate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5596'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('45003')  and left([DocumentNbr],4) = left(RecordingDate,4)
and [DocumentNbr] not like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '713'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48167')  and left([DocumentNbr],4) = left(RecordingDate,4)
and [DocumentNbr] not like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '713'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48167') and left([DocumentNbr],5) = left(RecordingDate,4) + '.'
and [DocumentNbr]  like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6877'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48201') and left([DocumentNbr],4) = left(RecordingDate,4)
and [DocumentNbr] not like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7906'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('51710')  and left([DocumentNbr],4) = left(RecordingDate,4)
and [DocumentNbr]  like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1765'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + [DocumentNbr]
when left([DocumentNbr],4) = left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + [DocumentNbr]
--when left([DocumentNbr],4) = left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53031') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '28665'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + [DocumentNbr]
when left([DocumentNbr],4) = left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + [DocumentNbr]
--when left([DocumentNbr],4) = left(RecordingDate,4)  and [DocumentNbr] not like '%.%' then  left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-4) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53031') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7604'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(DocumentNbr,5) = Left(recordingdate,4) + '.'
and A.FIPS in ('53065') 











Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '583'
,[DocumentNbr] =   left(recordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48029') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1115'
,[DocumentNbr] =   left(recordingdate,4) + '.' + right([DocumentNbr],4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48245') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7988'
,[DocumentNbr] =   left(recordingdate,4) + '.' + right([DocumentNbr],5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48471') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '999'
,[DocumentNbr] =   case when right([DocumentNbr],4)  = left(recordingdate,4) then left(recordingdate,4) + '.' + '.' + left([DocumentNbr],len([DocumentNbr])-6) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when right([DocumentNbr],4)  = left(recordingdate,4) then left(recordingdate,4) + '.' + '.' + left([DocumentNbr],len([DocumentNbr])-6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('49049') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4376'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55135') 













Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3513'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-9)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-9)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('34037')  and left([DocumentNbr],9) = left(convert(varchar(10),RecordingDate,112),4) + '.' + right(convert(varchar(10),RecordingDate,112),4)



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2968'
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('36079')  and left([DocumentNbr],4) <> left(RecordingDate,4) 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1611'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39133')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3404'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('42091')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3405'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('42091')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13071'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47099')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '26439'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47185')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6892'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53003')  and left([DocumentNbr],5) <> left(RecordingDate,4) + '.'








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2967'
,[DocumentNbr] = Right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + Right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('36079')  and left([DocumentNbr],4) = left(RecordingDate,4) 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = case when recordingdate < '2005-04-20' then  '956' else  '3024' end
,[DocumentNbr] =  case when recordingdate < '2005-04-20' then  [DocumentNbr] else  left(recordingdate,4) + '.' + [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when recordingdate < '2005-04-20' then  [DocumentNbr] else  left(recordingdate,4) + '.' + [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('36085')  and left([DocumentNbr],4) <> left(RecordingDate,4) 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6298'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('37115')  and left([DocumentNbr],4) <> left(RecordingDate,4) 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7757'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('41059')  and left([DocumentNbr],4) = left(RecordingDate,4) 









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4430'
,[DocumentNbr] = Right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + Right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55015')  and left([DocumentNbr],5) = left(RecordingDate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1179'
,[DocumentNbr] = case when left(documentnbr,5) = left(RecordingDate,4) + '.' then   Right([DocumentNbr],len([DocumentNbr])-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(RecordingDate,4) + '.' then   Right([DocumentNbr],len([DocumentNbr])-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55079')  



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1405'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then Right([DocumentNbr],len([DocumentNbr])-5) ELSE [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then Right([DocumentNbr],len([DocumentNbr])-5) ELSE [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55101')  
--and left([DocumentNbr],5) = left(RecordingDate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1252'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then Right([DocumentNbr],len([DocumentNbr])-5) else right(DocumentNbr,7) end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then Right([DocumentNbr],len([DocumentNbr])-5) else right(DocumentNbr,7) end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55133') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1205'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTatus is null)
and A.FIPS in ('24029')  and left([DocumentNbr],4) <> left(RecordingDate,4)















Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1241'
,[DocumentNbr] = left([DocumentNbr],2) + '.' + right(left([DocumentNbr],5),2) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],2) + '.' + right(left([DocumentNbr],5),2) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('36119')  and [DocumentNbr] not like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1241'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.' then Right(left([DocumentNbr],7),2) + '.' + right(left([DocumentNbr],10),3) + '.' + right([DocumentNbr],len([DocumentNbr])-10)
else left([DocumentNbr],2) + '.' + right(left([DocumentNbr],6),3) + '.' + right([DocumentNbr],len([DocumentNbr])-7) end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then Right(left([DocumentNbr],7),2) + '.' + right(left([DocumentNbr],10),3) + '.' + right([DocumentNbr],len([DocumentNbr])-10)
--else left([DocumentNbr],2) + '.' + right(left([DocumentNbr],6),3) + '.' + right([DocumentNbr],len([DocumentNbr])-7) end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('36119')  and [DocumentNbr] like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1690'
,[DocumentNbr] = left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39151')  and left([DocumentNbr],9) <> left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4)
and left(recordingdate,4) > '2002'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1690'
,[DocumentNbr] = left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4) + '.' + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39151')  and left([DocumentNbr],9) = left(recordingdate,4) + '.' + right(convert(varchar(10),recordingdate,112),4)
and left(recordingdate,4) > '2002'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '15037'
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('39165')  and left([DocumentNbr],5) <> left(recordingdate,4) + '.' 
and left(recordingdate,4) > '2013'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2176'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('45013')  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9802'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47031')  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9911'
,[DocumentNbr] = left(recordingdate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47031')  
and left(recordingdate,4) <> left(documentnbr,4)





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '843'
,[DocumentNbr] = case when left([DocumentNbr],2) = right(left(recordingdate,4),2) then left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-2) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],2) = right(left(recordingdate,4),2) then left(recordingdate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-2) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47157')  --and left([DocumentNbr],2) = right(left(recordingdate,4),2)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27216'
,[DocumentNbr] = right(documentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47167')  


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1128'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48091')  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '589'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48157')  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1220'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48367')  


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '127'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('06097')  

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1257'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12017')  























Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2704'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47149')  and [DocumentNbr] not like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7711'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26147') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '586'
,[DocumentNbr] = right(documentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('32510') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '22707'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('35053') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9792'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentNbr,6) else documentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right(documentNbr,6) else documentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('36011') 









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1820'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('42003')  and left(RecordingDate,4) = left([DocumentNbr],4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2447'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26091')  and convert(datetime,RecordingDate) <= convert(datetime,'2006-10-31')


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7838'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26091')  and convert(datetime,RecordingDate) > convert(datetime,'2006-10-31')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1053'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26139') 
and left(recordingdate,4) + '.' <> left(documentnbr,5)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8155'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26139') 
and left(recordingdate,4) + '.' = left(documentnbr,5)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5354'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('48257') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5458'
,[DocumentNbr] = case when left(documentNbr,5) like '00000' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) like '00000' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55111') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '520'
,[DocumentNbr] = case when left(documentNbr,4) like left(RecordingDate,4) and Documentnbr not like '%.%' and RIght(left(documentNbr,8),4) like '0000' 
then left(documentNbr,4) + '.' + right([DocumentNbr],len([DocumentNbr])-8) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,4) like left(RecordingDate,4) and Documentnbr not like '%.%' and RIght(left(documentNbr,8),4) like '0000' 
--then left(documentNbr,4) + '.' + right([DocumentNbr],len([DocumentNbr])-8) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12071') 









Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '213'
,[DocumentNbr] = case when left(documentNbr,4) = left(recordingdate,4) and documentnbr not like '%.%' then left(documentNbr,4) + '.' + right(documentnbr,len(documentnbr)-4) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,4) = left(recordingdate,4) and documentnbr not like '%.%' then left(documentNbr,4) + '.' + right(documentnbr,len(documentnbr)-4) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTatus is null)
and A.FIPS in ('48491') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '26929'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('55095') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5612'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26021') --

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1034'
,[DocumentNbr] = case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26037')  





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2952'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('29077') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2952'
,[DocumentNbr] = left(recordingdate,4) + '.' + left(DocumentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + left(DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('29077')  and left(documentNbr,4) <> left(recordingdate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7456'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('34031')  and left(documentNbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6305'
,DocumentNbr = case when left(documentNbr,5) not like left(recordingdate,4) + '.' 
	then left(recordingdate,4) + '.' + documentNbr else documentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) not like left(recordingdate,4) + '.' 
	--then left(recordingdate,4) + '.' + documentNbr else documentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('36061') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1463'
,DocumentNbr = left(recordingdate,4) + '.' + right(documentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(documentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('36081')  and left(documentNbr,5) = left(recordingdate,4) + '.'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2163'
,DocumentNbr = case when left(DocumentNbr,4) like left(RecordingDate,4) and left(DocumentNbr,9) <> left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4) 
then left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4)  + '.' + right(DocumentNbr,3) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,4) like left(RecordingDate,4) and left(DocumentNbr,9) <> left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4) 
--then left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4)  + '.' + right(DocumentNbr,3) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('53053')  and left(documentNbr,5) = left(recordingdate,4) + '.'







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4251'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('34021') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4311'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('34021') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '25972'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('37001') --


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5510'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) <> left(recordingdate,4) + '.'
and A.FIPS in ('37001') --



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9962'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('47063') --






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27656'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('37089') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27661'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.'  THEN right(documentnbr,len(documentnbr)-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.'  THEN right(documentnbr,len(documentnbr)-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('37089') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8445'
,[DocumentNbr] = case when left(documentNbr,5) <> left(recordingdate,4) + '.'  THEN left(recordingdate,4) + '.' + documentNbr else   documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) <> left(recordingdate,4) + '.'  THEN left(recordingdate,4) + '.' + documentNbr else   documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('40021') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23631'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.'  THEN right(documentNbr,len(documentNbr)-5) else   documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.'  THEN right(documentNbr,len(documentNbr)-5) else   documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('47021') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '511'
,DocumentNbr = case when left(DocumentNbr,4) like left(RecordingDate,4) and DocumentNbr not like '%.%' then left(DocumentNbr,4) + '.' + Right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,4) like left(RecordingDate,4) and DocumentNbr not like '%.%' then left(DocumentNbr,4) + '.' + Right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12031') --


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27230'
,DocumentNbr = left(recordingdate,4) + '.' + DocumentNbr
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + DocumentNbr
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentnbr,5) <> left(recordingdate,4) + '.'
and A.FIPS in ('37193') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1216'
,DocumentNbr = left(recordingdate,4) + '.' + right(DocumentNbr,6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and left(documentnbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('26099') --


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2954'
,DocumentNbr = case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('30031') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1588'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('12073') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5669'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26065')  and convert(datetime,recordingdate) > convert(datetime,'2005-12-30')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4559'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'
and A.FIPS in ('26065')  and convert(datetime,recordingdate) <= convert(datetime,'2005-12-30')



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13191'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('40143') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '482'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('40143') 
and left(recordingdate,4) <> left(documentNbr,4)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2599'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('41011') 
and left(recordingdate,4) = left(documentNbr,4)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7045'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('41035') 
and left(recordingdate,4) = left(documentNbr,4)










Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2600'
,DocumentNbr = case when left(DocumentNbr,5) like left(RecordingDate,4) + '.' then right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) like left(RecordingDate,4) + '.' then right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48259') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '334'
,DocumentNbr = left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4)  + '.' + right(DocumentNbr,4) 
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + right(convert(varchar(10),RecordingDate,112),4)  + '.' + right(DocumentNbr,4) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XosStatus is null)
and A.FIPS in ('32003') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8473'
,DocumentNbr = left(RecordingDate,4) + '.' + DocumentNbr
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + DocumentNbr
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('47143') 
and 
left(DocumentNbr,4) <> left(RecordingDate,4) and DocumentNbr like '%.%'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2663'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48213') 
and 
left(DocumentNbr,4) = left(RecordingDate,4) and DocumentNbr like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6171'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('49053') 
and 
left(DocumentNbr,4) = left(RecordingDate,4) and DocumentNbr like '%.%'








Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '24088'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('06089') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9345'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('45019') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '639'
,[DocumentNbr] = case when left([DocumentNbr],5) <> left(RecordingDate,4) + '.' then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) <> left(RecordingDate,4) + '.' then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('08123') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '11597'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then right(documentnbr,len(documentnbr)-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then right(documentnbr,len(documentnbr)-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('15003') 





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3228'
,DocumentNbr = case when DocumentNbr not like '%.%' and left(DocumentNbr,4) = left(recordingdate,4) then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  case when DocumentNbr not like '%.%' and left(DocumentNbr,4) = left(recordingdate,4) then left(recordingdate,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSStatus is null)
and A.FIPS in ('48183') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '500'
,DocumentNbr = case when DocumentNbr not like '%.%' and left(DocumentNbr,4) = left(recordingdate,4) then left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else DocumentNbr end
------,----ImageName =  case when DocumentNbr not like '%.%' and left(DocumentNbr,4) = left(recordingdate,4) then left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4) else ----ImageName end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('12009')  




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '28258'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('17091') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3151'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('29047') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13299'
,DocumentNbr = case when (SELECT LEN(DocumentNbr) - LEN(REPLACE(DocumentNbr, '.', ''))) = '2' and left(DocumentNbr,4) = left(recordingdate,4)  then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when (SELECT LEN(DocumentNbr) - LEN(REPLACE(DocumentNbr, '.', ''))) = '2' and left(DocumentNbr,4) = left(recordingdate,4)  then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('34005') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27496'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('34027') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14407'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('34035') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1171'
,DocumentNbr = case when left(documentNbr,4) <> left(recordingdate,4) then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,4) <> left(recordingdate,4) then left(recordingdate,4) + '.' + DocumentNbr else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('42011') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '10155'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('42055') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3832'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('45083') 
and left(recordingdate,4) = left(documentnbr,4)





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '17004'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('42121') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9965'
,DocumentNbr =  left(recordingdate,4) + '.' + right(DocumentNbr,6) 
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  left(recordingdate,4) + '.' + right(DocumentNbr,6) 
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed'  
and A.FIPS in ('47105') 




--Update [dbo].[z_Images_To_Pull]
--Set CMTID = '2967'
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL
--FROM [dbo].[z_Images_To_Pull] as A join X_Custom_Output as B on 
--A.Inputkey = B.[INPUT Ref#]
--where XosStatus not like 'Completed' 
--and A.FIPS in ('36079') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14924'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37053') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1743'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37183') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7752'
,[DocumentNbr] = case when left([DocumentNbr],4) = left(RecordingDate,4) then left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],6) else [DocumentNbr] end
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) = left(RecordingDate,4) then left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('01089') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3216'
,[DocumentNbr] = left(RecordingDate,4) + '.' + right(left(documentnbr,8),3) + '.' +  right([DocumentNbr],5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + right(left(documentnbr,8),3) + '.' +  right([DocumentNbr],5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XosStatus is null)
and left(RecordingDate,4) + '.' = left(documentnbr,5) and documentnbr  like '%.%'
and A.FIPS in ('30029') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3020'
,[DocumentNbr] = case when left([DocumentNbr],4) = left(RecordingDate,4) then left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],4) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) = left(RecordingDate,4) then left(RecordingDate,4) + '.' + Right(convert(varchar(8),RecordingDate,112),4) + '.' + right([DocumentNbr],4) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('47065') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '5647'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then  right([DocumentNbr],6) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then  right([DocumentNbr],6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('08091') 





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '60'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06013') 
and left([DocumentNbr],4) <> left(RecordingDate,4) 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '280'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('12111') 
and left([DocumentNbr],4) <> left(RecordingDate,4) 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '631'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('08031') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '595'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('25017') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '4106'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37019') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1544'
,[DocumentNbr] = case when left(RecordingDate,4) <> left([DocumentNbr],4) + '.' then left(RecordingDate,4) + '.' + right([DocumentNbr],5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(RecordingDate,4) <> left([DocumentNbr],4) + '.' then left(RecordingDate,4) + '.' + right([DocumentNbr],5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48061') 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '596'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) then left(RecordingDate,4) + '.' + [DocumentNbr] else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTATUS is null)
and A.FIPS in ('25027') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2364'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) and left(documentNbr,2) like '17' then  left(RecordingDate,4) + '.' + Right([DocumentNbr],len([DocumentNbr])-2) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) and left(documentNbr,2) like '17' then  left(RecordingDate,4) + '.' + Right([DocumentNbr],len([DocumentNbr])-2) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTATUS is null)
and A.FIPS in ('47187') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2363'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTATUS is null)
and A.FIPS in ('47187') 
and left(recordingdate,4) = '2006'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '202'
,[DocumentNbr] = case when left([DocumentNbr],4) <> left(RecordingDate,4) and left(documentNbr,2) like '17' then  left(RecordingDate,4) + '.' + Right([DocumentNbr],len([DocumentNbr])-2) 
when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then left(RecordingDate,4) + '.' + Right([DocumentNbr],6) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],4) <> left(RecordingDate,4) and left(documentNbr,2) like '17' then  left(RecordingDate,4) + '.' + Right([DocumentNbr],len([DocumentNbr])-2) 
--when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then left(RecordingDate,4) + '.' + Right([DocumentNbr],6) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or XOSSTATUS is null)
and A.FIPS in ('48209') 













Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2806'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('05085') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '113'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06017') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3635'
,[DocumentNbr] = case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left([DocumentNbr],5) = left(RecordingDate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('08087') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8425'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('12013') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1686'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37063')  and left(documentNbr,4) <> left(recordingdate,4)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6434'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37105')  and left(documentNbr,4) = left(recordingdate,4)




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1985'
,[DocumentNbr] = left(RecordingDate,4) + '.' + [DocumentNbr]
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + [DocumentNbr]
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('47103')  and left(documentNbr,4) <> left(recordingdate,4)



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1025'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24017')  and left(documentNbr,5) = left(recordingdate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1026'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24027')  and left(documentNbr,5) = left(recordingdate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1202'
,[DocumentNbr] = case when documentnbr like '%.%.%' and left(documentnbr,5) = left(recordingdate,4) + '.' then   right([DocumentNbr],len([DocumentNbr])-5) else documentnbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when documentnbr like '%.%.%' and left(documentnbr,5) = left(recordingdate,4) + '.' then   right([DocumentNbr],len([DocumentNbr])-5) else documentnbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24041') -- 





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1026'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24027')  and left(documentNbr,5) <> left(recordingdate,4) + '.' and documentnbr like '%.%'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1623'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24047')  


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9773'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('26161')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1213'
--,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('41039')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '10124'
--,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
--------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('42025')





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '771'
,[DocumentNbr] = case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24510') --







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '105'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06107') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1159'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSStatus is null)
and A.FIPS in ('26077') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2936'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSStatus is null) and left(documentNbr,5) <> left(recordingdate,4) + '.'
and A.FIPS in ('37071') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1192'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24025') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '588'
,[DocumentNbr] = left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48201')  and [DocumentNbr] not like '%.%'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6071'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48469') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3991'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('08049') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '277'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('12105') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2483'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('12131') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '15041'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('16001') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14642'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('18127') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23923'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20177') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6553'
,DocumentNbr = Left(recordingdate,4) + '.' + Right(DocumentNbr,5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + Left(recordingdate,4) + '.' + Right(DocumentNbr,5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20177')  and left(documentNbr,4) = Left(recordingdate,4) and DocumentNbr not like '%.%'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23923'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20177')  and left(documentNbr,5) = Left(recordingdate,4) + '.'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1163'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20209')  and left(DocumentNbr,4) = left(recordingdate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1164'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20209')  and left(DocumentNbr,4) <> left(recordingdate,4)




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '7794'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('21111') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1205'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('23005')  and left(documentnbr,5) <> left(recordingdate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '13614'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('23005')  and left(documentnbr,5) = left(recordingdate,4) + '.'




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2248'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('26017') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6438'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('37197') 




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '592'
,DocumentNbr = case when left(documentnbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then Right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('24003') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2804'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('05143') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6939'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('18141') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '14422'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and left(documentNbr,5) = left(recordingdate,4) + '.'
and A.FIPS in ('18141') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2527'
,DocumentNbr = case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentnbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('20045') --




Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '126'
,DocumentNbr = left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06053') 
and left(documentNbr,4) = left(recordingdate,4) and documentnbr not like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '191'
,DocumentNbr =  case when left(documentNbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  case when left(documentNbr,5) = left(recordingdate,4) + '.' then  right(DocumentNbr,len(DocumentNbr)-5) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('49035') 





--Update [dbo].[z_Images_To_Pull]
--Set CMTID = '2457'
--,[ImageLink] = NULL
--,[XosRequestId] = NULL
--,[ServerUrl] = NULL
--,[XosStatus] = NULL
--,[FilePath] = NULL
--,[SubmissionDate] = NULL
--,[StatusCheckDate] = NULL
--,[ProcessingStatus] = NULL
--,[RequestXml] = NULL
--,[ResponseXml] = NULL
--,[StatusCheckRequestXml] = NULL
--,[StatusCheckResponseXml] = NULL
--FROM [dbo].[z_Images_To_Pull] as A join X_Custom_Output as B on 
--A.Inputkey = B.[INPUT Ref#]
--where XosStatus not like 'Completed' 
--and A.FIPS in ('47189') 
--and left(recordingdate,4) <> left(documentNbr,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9636'
,DocumentNbr = left(recordingdate,4) + '.' + right(DocumentNbr,6)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right(DocumentNbr,6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSStatus is null)
and A.FIPS in ('47189') 
--and left(recordingdate,4) <> left(documentNbr,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3227'
,DocumentNbr =  right(DocumentNbr,7)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) +  right(DocumentNbr,7)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSStatus is null)
and A.FIPS in ('48041') 







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '23056'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed'  or XOSStatus is null)
and A.FIPS in ('48407') 
and left(recordingdate,4) = left(documentNbr,4)



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8804'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('48027') 
and left(recordingdate,4) = left(documentNbr,4)






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '6'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('06071') 

















Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set 
CMTID = '8406'
,DocumentNbr = left(DocumentNbr,4) + '.' + right(left(DocumentNbr,8),4) + '.' + right(DocumentNbr,len(DocumentNbr)-8)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(left(DocumentNbr,8),4) + '.' + right(DocumentNbr,len(DocumentNbr)-8)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
--Select right(convert(varchar(10),recordingdate,112),4)
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
AND A.FIPS like '47093' 
and left(DocumentNbr,4) = left(RecordingDate,4)
and right(left(DocumentNbr,8),4)    = right(convert(varchar(10),recordingdate,112),4)
and DocumentNbr not like '%.%'





Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '627'
,[DocumentNbr] = left(RecordingDate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-3)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(RecordingDate,4) + '.' + right([DocumentNbr],len([DocumentNbr])-3)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where XosStatus not like 'Completed' 
and A.FIPS in ('08041')  and left(documentNbr,3) like '217' and left(recordingdate,4) = '2017'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1127'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('26121')  and left(documentNbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1127'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('26121')  and left(documentNbr,5) <> left(recordingdate,4) + '.'
and documentNbr not like '%.%'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '9065'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('26159') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1218'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('26163') 

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '8146'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('28089') 
and left(documentNbr,5) = left(recordingdate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3172'
,[DocumentNbr] = case when left(documentNbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(documentNbr,5) = left(recordingdate,4) + '.' then right([DocumentNbr],len([DocumentNbr])-5) else [DocumentNbr] end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('29037') 



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2153'
,[DocumentNbr] = left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left([DocumentNbr],1) + '.' + right([DocumentNbr],len([DocumentNbr])-1)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('29047') 
and documentNbr not like '%.%' and left(documentNbr,4) <> left(recordingdate,4)


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3151'
,[DocumentNbr] = left(recordingdate,4) + '.' +  right([DocumentNbr],len([DocumentNbr])-4)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' +  right([DocumentNbr],len([DocumentNbr])-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('29047') 
and documentNbr not like '%.%' and left(documentNbr,4) = left(recordingdate,4)

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '2839'
,[DocumentNbr] = right([DocumentNbr],len([DocumentNbr])-5)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + right([DocumentNbr],len([DocumentNbr])-5)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('35049') 
and documentNbr  like '%.%' and left(documentNbr,5) = left(recordingdate,4) + '.'


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '1378'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('39095') 
and documentNbr  like '%.%' and left(documentNbr,5) = left(recordingdate,4) + '.'

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '3863'
,[DocumentNbr] = left(recordingdate,4) + '.' + right([DocumentNbr],6)
------,----ImageName = left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(recordingdate,4) + '.' + right([DocumentNbr],6)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('39169') 
and documentNbr  not like '%.%' and left(documentNbr,4) = left(recordingdate,4) 






Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '10650'
,DocumentNbr = case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' +  right(convert(varchar(10),recordingdate,112),4) + '.' + Right(DocumentNbr,4) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' +  right(convert(varchar(10),recordingdate,112),4) + '.' + Right(DocumentNbr,4) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('34023') 


Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '10650'
,DocumentNbr = case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' +  right(convert(varchar(10),recordingdate,112),4) + '.' + Right(DocumentNbr,4) else DocumentNbr end
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + case when left(DocumentNbr,5) = left(recordingdate,4) + '.' then left(recordingdate,4) + '.' +  right(convert(varchar(10),recordingdate,112),4) + '.' + Right(DocumentNbr,4) else DocumentNbr end
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('34023') 







Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set CMTID = '27493'
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
FROM [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull] as A join [zCust_USBANK_USSPD].[dbo].[X_Custom_Output] as B on 
A.Inputkey = B.[INPUT Ref#]
where (XosStatus not like 'Completed' or xosstatus is null)
and A.FIPS in ('39109') 














Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set 
DocumentNbr = left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
------,----ImageName =  left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
,[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or XosStatus is null)
and left(DocumentNbr,4) in ('2015','2016','2017')
and DocumentNbr not like '%.%'


--Select DocumentNbr,----ImageName,
--left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
--, left(----ImageName,len(----ImageName)-charindex('_',REVERSE(----ImageName))+1) + left(DocumentNbr,4) + '.' + right(DocumentNbr,len(DocumentNbr)-4)
--From [dbo].[z_Images_To_Pull]
--where XosStatus not like 'Completed'
--and left(DocumentNbr,4) in ('2015','2016','2017')
--and DocumentNbr not like '%.%'



Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set DocumentNbr = REPLACE(REPLACE(DocumentNbr,'..','.'),'-','.')

Update [zCust_USBANK_USSPD].[dbo].[z_Images_To_Pull]
Set --CMTID = '1005',
[ImageLink] = NULL
,[XosRequestId] = NULL
,[ServerUrl] = NULL
,[XosStatus] = NULL
,[FilePath] = NULL
,[SubmissionDate] = NULL
,[StatusCheckDate] = NULL
,[ProcessingStatus] = NULL
,[RequestXml] = NULL
,[ResponseXml] = NULL
,[StatusCheckRequestXml] = NULL
,[StatusCheckResponseXml] = NULL
where (XosStatus not like 'Completed' or xosStatus is null ) 





--Delete from [dbo].[z_Images_To_Pull]
--where CMTID = 0

END

