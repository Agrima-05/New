SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- Create date: 20151215
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_502_Pull_DTDB_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    EXEC [zCust_ServiceMac].[dbo].[usp_201_CreateUniqueRefId]

    EXEC [zCust_ServiceMac].[dbo].[usp_202_Get_AVM]


END


