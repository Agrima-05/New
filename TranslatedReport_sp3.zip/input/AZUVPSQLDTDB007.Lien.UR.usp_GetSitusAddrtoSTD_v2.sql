/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_GetSitusAddrtoSTD_v2 | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================  
-- Author:  <Author,,Name>  
-- Create date Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
create PROCEDURE [Lien].[UR].[usp_GetSitusAddrtoSTD_v2] @fileid INT
AS
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_GetSitusAddrtoSTD_v2'
	,N'Started'

-- real code begins
--DECLARE @fileid INT = 50
DROP TABLE

IF EXISTS [lien].[lien_tmp].[usp_GetSitusAddrtoSTD_v2_prop_id]
	SELECT a.property_id
	INTO [lien].[lien_tmp].[usp_GetSitusAddrtoSTD_v2_prop_id]
	FROM [Lien].[UR].[PROPERTY] a WITH (
			NOLOCK
			,INDEX (PK_PROPERTY)
			)
	LEFT JOIN [Lien].[UR].[PROPERTY_Std_Address] p WITH (
			NOLOCK
			,INDEX (ix_PropIDREfidMatchCode)
			) ON p.Property_id = a.Property_id
	WHERE a.legal_desc_address IS NOT NULL
		AND p.property_id IS NULL
	OPTION (
		RECOMPILE
		,MAXDOP 16
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

--select * from lien.lien_tmp.usp_GetSitusAddrtoSTD_v2_prop_id
--declare  @fileid int = 29
/*IF object_id('lien.tmp.Property_Addr_match') IS NOT NULL
	*/
DROP TABLE IF EXISTS [lien].[tmp].[Property_Addr_match];

SELECT b.Property_id
	,aa.legal_desc_address
	,b.legal_desc_address_city
	,b.legal_desc_address_state
	,b.legal_desc_address_zip
	,b.Fips
	,b.legal_desc_map_unit_low
	,b.Ref_id
	,b.Match_code
	,b.Apn
	,b._apn
	,b.Raw_Address
	,b.Use_Actual_Fips
INTO [lien].[tmp].[Property_Addr_match]
FROM (
	SELECT a.Property_id
		,a.[legal_desc_address]
		,a.[legal_desc_address_city]
		,a.[legal_desc_address_state]
		,a.[legal_desc_address_zip]
		--,d.[fips_code] AS Fips  
		,pp._new_fips_code AS Fips
		,a.[legal_desc_map_unit_low]
		,cast(0 AS INT) AS Ref_id
		,'    ' AS Match_code
		,cast(substring(a.legal_desc_apn, 1, 60) AS VARCHAR(60)) AS Apn
		,cast(REplace(replace(legal_desc_apn, ' ', ''), '.', '') AS VARCHAR(60)) AS _apn
		,substring(replace(Replace(a.legal_desc_address + ' ,' + isnull(a.legal_desc_address_city, '') + ' ,' + isnull(a.legal_desc_address_state, '') + ' ,' + isnull(a.legal_desc_address_zip, ''), 'NUll', ''), '  ', ''), 1, 60) AS Raw_Address
		,pp.Use_Actual_Fips
		,p.property_id AS std_property_id
	FROM [Lien].[UR].[PROPERTY] a WITH (
			NOLOCK
			,INDEX (PK_PROPERTY)
			)
	LEFT JOIN [Lien].[UR].[DOCUMENT] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			) ON d.doc_id = a.doc_id
	LEFT JOIN [Lien].[UR].[PROPERTY_Std_Address] p WITH (
			NOLOCK
			,INDEX (ix_PropIDREfidMatchCode)
			) ON p.Property_id = a.Property_id
	OUTER APPLY (
		SELECT CASE 
				WHEN substring(a.legal_desc_apn, 1, 1) = '('
					AND d.fips_code BETWEEN '15000'
						AND '16000'
					THEN substring(a.legal_desc_apn, 2, 1)
				WHEN (
						substring(a.legal_desc_apn, 2, 1) IN ('/')
						OR len(a.legal_desc_apn) = 18
						)
					AND d.fips_code BETWEEN '15000'
						AND '16000'
					THEN substring(a.legal_desc_apn, 1, 1)
				ELSE NULL
				END AS _island
		) d1
	OUTER APPLY (
		SELECT ltrim(rtrim(LEFT(a.legal_desc_apn, 60))) AS apn
			,CASE 
				WHEN d1._island = '1'
					THEN '15003'
				WHEN d1._island = '2'
					THEN '15009'
				WHEN d1._island = '3'
					THEN '15001'
				WHEN d1._island = '4'
					THEN '15007'
				WHEN a.legal_desc_district = '1'
					THEN '36061' -- New York / Manhattan  
				WHEN a.legal_desc_district = '2'
					THEN '36005' -- Bronx  
				WHEN a.legal_desc_district = '3'
					THEN '36047' -- Kings / Brooklyn  
				WHEN a.legal_desc_district = '4'
					THEN '36081' -- Queens  
						--WHEN ct.Fips_code IS NOT NULL
						--	THEN ct.FIPS_CODE
				ELSE d.fips_code
				END AS _new_fips_code
			,CASE 
				WHEN d1._island IN (
						'1'
						,'2'
						,'3'
						,'4'
						)
					OR a.legal_desc_district IN (
						'1'
						,'2'
						,'3'
						,'4'
						)
					--or ct.Fips_code IS NOT NULL
					THEN 1
				ELSE 0
				END AS Use_Actual_Fips
		) pp
	WHERE a.property_id IN (
			SELECT Property_id
			FROM [lien].[lien_tmp].[usp_GetSitusAddrtoSTD_v2_prop_id]
			)
		--		AND a.[legal_desc_address] IS NOT NULL
	) b
OUTER APPLY (
	SELECT CASE 
			WHEN b.Fips IN (
					'36150'
					,'36005'
					,'36047'
					,'36061'
					,'36081'
					)
				AND isnull(b.legal_desc_map_unit_low, '') > ''
				AND b.legal_desc_address NOT LIKE '%' + b.legal_desc_map_unit_low + '%'
				THEN substring(Replace(ltrim(rtrim(b.legal_desc_address + ' #' + b.legal_desc_map_unit_low)), '  ', ' '), 1, 200)
			ELSE b.legal_desc_address
			END AS legal_desc_address
	) aa
--WHERE 
--		b.legal_desc_address IS not NULL
--		and b.std_property_id is null
--NOT (
--		b.legal_desc_address IS NULL
--		AND b.legal_desc_address_city IS NULL
--		AND b.Legal_desc_address_state IS NULL
--		AND b.legal_desc_address_zip IS NULL
--		AND b.Apn IS NULL
--		)
OPTION (
	RECOMPILE
	,MAXDOP 16
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

-- select * from lien.[tmp].[Property_Addr_match]   
CREATE UNIQUE CLUSTERED INDEX ix_id ON [lien].[tmp].[Property_Addr_match] (Property_id)

CREATE INDEX ix_Fips ON [lien].[tmp].[Property_Addr_match] (Fips)

CREATE NONCLUSTERED INDEX ix_state ON [lien].[tmp].[Property_Addr_match] ([legal_desc_address_state]) INCLUDE (
	[Property_id]
	,[legal_desc_address]
	,[legal_desc_address_city]
	,[legal_desc_address_zip]
	,[Fips]
	)

--declare  @fileid int = 29
DROP TABLE

IF EXISTS #fips
	SELECT cast(c.[FIPS] AS VARCHAR(200)) AS fips
		,c.[State]
	INTO #fips
	FROM [Assr].[dbo].[CountyCodes] c

CREATE CLUSTERED INDEX ixa ON #fips (Fips)

UPDATE [Lien].[UR].[a]
SET a.legal_desc_address_state = f.[State]
	,a.Raw_Address = substring(replace(Replace(a.legal_desc_address + ' ,' + isnull(a.legal_desc_address_city, '') + ' ,' + isnull(f.STATE, '') + ' ,' + isnull(a.legal_desc_address_zip, ''), 'NUll', ''), '  ', ''), 1, 60)
FROM [lien].[tmp].[Property_Addr_match] a
INNER JOIN #fips f ON f.fips = a.fips
OUTER APPLY (
	SELECT coalesce(a.legal_desc_address_state, F.[State]) AS legal_desc_address_state
	) c
WHERE a.legal_desc_address_state IS NULL

-- SELECT Count(1) AS cnt FROM lien.tmp.Property_Addr_match  
--  
--Situs match   
--  
--select top 100 * from [Lien].[tmp].Situs_Std_Address 
--select top 10 *  from [Lien].[dbo].[lien_Std_Address]
--select top 100 * from [Lien].[dbo].[lien_Std_Address]
TRUNCATE TABLE [Lien].[dbo].[lien_Std_Address]

INSERT INTO [Lien].[dbo].[lien_Std_Address] (
	[ID]
	,[FIPS]
	,[HouseNumber]
	,[Street_Number]
	,[Direction]
	,[Street_Name]
	,[Street_Type]
	,[Post_Direction]
	,[Unit_Type]
	,[Unit]
	,[City]
	,[State]
	,[Zip]
	,[Plus4]
	,[CRRT]
	,[CountyName]
	,[PMB]
	,[PMSA]
	,[MSA]
	,[ZipType]
	,[Urbanization]
	,[CongressionalDistrict]
	,[CountryCode]
	,[CityAbbreviation]
	,[AddressTypeCode]
	,[AddressTypeString]
	,[DPV_Count]
	,[DPV_Footnotes]
	,[CMRA]
	,[ELOT_Number]
	,[ELOT_Order]
	,[LACS]
	,[LACS_LinkIndicator]
	,[EWS_Flag]
	,[RBDI]
	,[SuiteLinkReturnCode]
	,[DeliveryPointCheckDigit]
	,[DeliveryPointCode]
	,[CensusBlock]
	,[CensusTract]
	,[PlaceCode]
	,[PlaceName]
	,[CBSACode]
	,[CBSALevel]
	,[CBSATitle]
	,[CBSADivisionCode]
	,[CBSADivisionLevel]
	,[CBSADivisionTitle]
	,[Latitude]
	,[Longitude]
	,[Verified]
	,[Geocoded]
	,[AddressMatchResults]
	,[GeoErrorCode]
	,[GeoStatusCode]
	,[AddressType]
	)
OUTPUT NULL AS Doc_id
	,NULL AS Name_id
	,Inserted.id AS property_id
	,NULL AS reference_id
	,getdate()
	,'usp_GetSitusAddrtoSTD' AS Process_name
INTO [lien].[ur].[document_transaction_log]
SELECT k.Property_id
	,k.Fips
	----,NULL AS Ref_id
	------,substring(k.Match_code,1,4) as Match_code
	----,NULL AS Match_code
	------,substring(' ',1,60) as Apn    
	----,NULL AS Apn
	,substring(k.Street_Number, 1, 30) AS HouseNumber
	,substring(k.Street_Number, 1, 50) AS Street_Number
	,substring(k.Direction, 1, 2) AS Direction
	,substring(k.Street_Name, 1, 60) AS Street_Name
	,substring(k.Street_Type, 1, 4) AS Street_Type
	,substring(k.Post_Direction, 1, 2) AS Post_Direction
	,substring(k.Unit_Type, 1, 50) AS Unit_Type
	,substring(k.Unit, 1, 11) AS Unit
	,substring(k.City, 1, 55) AS City
	,substring(k.STATE, 1, 2) AS STATE
	,substring(k.Zip, 1, 50) AS Zip
	,substring(k.Plus4, 1, 4) AS Plus4
	,substring(k.CRRT, 1, 4) AS CRRT
	,substring(k.CountyName, 1, 50) AS CountyName
	,substring(k.PMB, 1, 30) AS PMB
	,substring(k.PMSA, 1, 2) AS PMSA
	,substring(k.MSA, 1, 70) AS MSA
	,substring(k.ZipType, 1, 2) AS ZipType
	,substring(k.Urbanization, 1, 6) AS Urbanization
	,substring(k.CongressionalDistrict, 1, 2) AS CongressionalDistrict
	,substring(k.CountryCode, 1, 50) AS CountryCode
	,substring(k.CityAbbreviation, 1, 50) AS CityAbbreviation
	,substring(k.AddressTypeCode, 1, 1) AS AddressTypeCode
	,substring(k.AddressTypeString, 1, 60) AS AddressTypeString
	,substring(k.DPV_Count, 1, 5) AS DPV_Count
	,substring(k.DPV_Footnotes, 1, 4) AS DPV_Footnotes
	,substring(k.CMRA, 1, 1) AS CMRA
	,substring(k.ELOT_Number, 1, 5) AS ELOT_Number
	,substring(k.ELOT_Order, 1, 2) AS ELOT_Order
	,substring(k.LACS, 1, 1) AS LACS
	,substring(k.LACS_LinkIndicator, 1, 1) AS LACS_LinkIndicator
	,substring(k.EWS_Flag, 1, 1) AS EWS_Flag
	,substring(k.RBDI, 1, 1) AS RBDI
	,substring(k.SuiteLinkReturnCode, 1, 1) AS SuiteLinkReturnCode
	,substring(k.DeliveryPointCheckDigit, 1, 1) AS DeliveryPointCheckDigit
	,substring(k.DeliveryPointCode, 1, 2) AS DeliveryPointCode
	,substring(k.CensusBlock, 1, 4) AS CensusBlock
	,substring(k.CensusTract, 1, 6) AS CensusTract
	,substring(k.PlaceCode, 1, 7) AS PlaceCode
	,substring(k.PlaceName, 1, 60) AS PlaceName
	,substring(k.CBSACode, 1, 5) AS CBSACode
	,substring(k.CBSALevel, 1, 50) AS CBSALevel
	,substring(k.CBSATitle, 1, 50) AS CBSATitle
	,substring(k.CBSADivisionCode, 1, 5) AS CBSADivisionCode
	,substring(k.CBSADivisionLevel, 1, 50) AS CBSADivisionLevel
	,substring(k.CBSADivisionTitle, 1, 50) AS CBSADivisionTitle
	,k.Latitude
	,k.Longitude
	,k.Verified
	,k.Geocoded
	,substring(k.AddressMatchResults, 1, 50) AS AddressMatchResults
	,substring(k.GeoErrorCode, 1, 1) AS GeoErrorCode
	,substring(k.GeoStatusCode, 1, 1) AS GeoStatusCode
	,substring(k.AddressType, 1, 1) AS AddressType
FROM (
	SELECT a.*
		,s.*
	FROM [lien].[tmp].[Property_Addr_match] a
	OUTER APPLY (
		SELECT PreDir AS Direction
			,StreetNumber AS Street_Number
			,StreetName AS Street_Name
			,PostDir AS Post_Direction
			,StreetType AS Street_Type
			,s1.SuiteType AS Unit_Type
			,s1.Suite AS Unit
			,City
			,STATE
			,Zip
			,Plus4
			,PrivateMailbox AS PMB
			,Pmsa
			,Msa
			,ZipType
			,Urbanization
			,TimeZoneCode
			,TimeZone
			,CongressionalDistrict
			,CountryCode
			,CountyFips
			,CountyName
			,CityAbbreviation
			,AddressTypeString
			,AddressTypeCode AS AddressTypeCode
			,'' AS AddressType
			,DPVFootNotes AS DPV_Footnotes
			,'' AS DPV_Count
			,CarrierRoute AS CRRT
			,ELotOrder AS ELOT_Order
			,ELotNumber AS ELOT_Number
			,Lacs
			,LACSLinkIndicator AS LACS_LinkIndicator
			,LACSLinkReturnCode
			,EWSFlag AS EWS_Flag
			,RBDI
			,SuiteLinkReturnCode
			,AddressMatchResults
			,AddressMatchResultString
			,DeliveryPointCheckDigit
			,DeliveryPointCode
			,Latitude
			,Longitude
			,GeoErrorCode
			,GeoStatusCode
			,GeoCodeResults
			,CensusTract
			,CensusBlock
			,PlaceCode
			,PlaceName
			,CBSACode
			,CBSALevel
			,CBSATitle
			,CBSADivisionCode
			,CBSADivisionTitle
			,CBSADivisionLevel
			,CMRA
			,Verified
			,Geocoded
			,LoadDate
			,DsfNoStats
			,DsfVacant
			,DsfDNA
			,AddressKey
			,Company
			,MelissaAddressKey
			,MelissaAddressKeyBase
			,SuiteStatus
			,GeoDbLoadDate
			,AddrBuildNumber
			,GeoBuildNumber
			,FaAddrBuildDate
		FROM [spdb].[dbo].[StandardizeAddress](0, 1, a.legal_desc_address, a.legal_desc_address_city, a.legal_desc_address_state, legal_desc_address_zip)
		OUTER APPLY (
			SELECT CASE 
					WHEN isnull(Suite, '') = ''
						AND isnull(PrivateMailbox, '') > ''
						AND AddressMatchResults LIKE '%AS10%'
						AND len(ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''), '#', '')))) <= 6
						--THEN ltrim(replace(PrivateMailbox, 'PMB', ''))
						THEN ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''), '#', '')))
					ELSE Suite
					END AS Suite
				,CASE 
					WHEN isnull(Suite, '') = ''
						AND isnull(PrivateMailbox, '') > ''
						AND AddressMatchResults LIKE '%AS10%'
						AND len(ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''), '#', '')))) <= 6
						THEN 'PMB'
					ELSE SuiteType
					END AS SuiteType
			) s1
		) s
	) k

--declare  @fileid int = 29
DELETE
FROM [lien].[tmp].[Situs_Std_Address_Result]
WHERE fileid = @fileid

DELETE
FROM [lien].[tmp].[Situs_Std_Address]
WHERE fileid = @fileid

--'NORTHEAST '
--0123456789012345678901234567890123456789012345678901234567890
--	      1         2         3         4         5         6
--Msg 2628, Level 16, State 1, Line 492
--String or binary data would be truncated in table 'Lien.tmp.Situs_Std_Address', column 'Unit'. Truncated value: 'NORTHEAST '.
--select * 
-- select  format(count(*), '##,##0') as cnt from lien.tmp.Situs_Std_Address 
TRUNCATE TABLE [lien].[tmp].[Situs_Std_Address]

TRUNCATE TABLE [lien].[tmp].[Situs_Std_Address_Result]

INSERT INTO [lien].[tmp].[Situs_Std_Address] (
	[FileId]
	,[ID]
	,[FIPS]
	,apn
	,[legal_desc_address]
	,[legal_desc_address_city]
	,[legal_desc_address_state]
	,[legal_desc_address_zip]
	,[legal_desc_map_unit_low]
	,[Raw_Address]
	,[HouseNumber]
	,[Street_Number]
	,[Direction]
	,[Street_Name]
	,[Street_Type]
	,[Post_Direction]
	,[Unit_Type]
	,[Unit]
	,[City]
	,[STATE]
	,[Zip]
	,[Plus4]
	,[CRRT]
	,[CountyName]
	,[PMB]
	,[PMSA]
	,[MSA]
	,[ZipType]
	,[Urbanization]
	,[CongressionalDistrict]
	,[CountryCode]
	,[CityAbbreviation]
	,[AddressTypeCode]
	,[AddressTypeString]
	,[DPV_Count]
	,[DPV_Footnotes]
	,[CMRA]
	,[ELOT_Number]
	,[ELOT_Order]
	,[LACS]
	,[LACS_LinkIndicator]
	,[EWS_Flag]
	,[RBDI]
	,[SuiteLinkReturnCode]
	,[DeliveryPointCheckDigit]
	,[DeliveryPointCode]
	,[CensusBlock]
	,[CensusTract]
	,[PlaceCode]
	,[PlaceName]
	,[CBSACode]
	,[CBSALevel]
	,[CBSATitle]
	,[CBSADivisionCode]
	,[CBSADivisionLevel]
	,[CBSADivisionTitle]
	,[Latitude]
	,[Longitude]
	,[Verified]
	,[Geocoded]
	,[AddressMatchResults]
	,[GeoErrorCode]
	,[GeoStatusCode]
	,[AddressType]
	,[sf_address]
	,[Ref_id]
	,[Match_fips]
	,[Match_code]
	,[Use_Actual_Fips]
	)
SELECT @fileid AS [FileId]
	,a.property_id AS [ID]
	,a.FIPS
	,NULL AS apn
	,a.[legal_desc_address]
	,a.[legal_desc_address_city]
	,a.[legal_desc_address_state]
	,a.[legal_desc_address_zip]
	,a.[legal_desc_map_unit_low]
	,NULL AS [Raw_Address]
	,b.[HouseNumber]
	,b.[Street_Number]
	,b.[Direction]
	,b.[Street_Name]
	,b.[Street_Type]
	,b.[Post_Direction]
	,b.[Unit_Type]
	,substring(b.[Unit], 1, 11) AS Unit
	,b.[City]
	,b.[STATE]
	,b.[Zip]
	,b.[Plus4]
	,b.[CRRT]
	,b.[CountyName]
	,b.[PMB]
	,b.[PMSA]
	,b.[MSA]
	,b.[ZipType]
	,b.[Urbanization]
	,b.[CongressionalDistrict]
	,b.[CountryCode]
	,b.[CityAbbreviation]
	,b.[AddressTypeCode]
	,b.[AddressTypeString]
	,b.[DPV_Count]
	,b.[DPV_Footnotes]
	,b.[CMRA]
	,b.[ELOT_Number]
	,b.[ELOT_Order]
	,b.[LACS]
	,b.[LACS_LinkIndicator]
	,b.[EWS_Flag]
	,b.[RBDI]
	,b.[SuiteLinkReturnCode]
	,b.[DeliveryPointCheckDigit]
	,b.[DeliveryPointCode]
	,b.[CensusBlock]
	,b.[CensusTract]
	,b.[PlaceCode]
	,b.[PlaceName]
	,b.[CBSACode]
	,b.[CBSALevel]
	,b.[CBSATitle]
	,b.[CBSADivisionCode]
	,b.[CBSADivisionLevel]
	,b.[CBSADivisionTitle]
	,b.[Latitude]
	,b.[Longitude]
	,b.[Verified]
	,b.[Geocoded]
	,b.[AddressMatchResults]
	,b.[GeoErrorCode]
	,b.[GeoStatusCode]
	,b.[AddressType]
	,NULL AS sf_address
	,NULL AS [Ref_id]
	,NULL AS [Match_fips]
	,NULL AS [Match_code]
	,a.[Use_Actual_Fips]
-- select top 10 * 
FROM [lien].[tmp].[Property_Addr_match] a
LEFT JOIN [Lien].[dbo].[Lien_Std_Address] b ON b.id = a.property_id

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_GetSitusAddrtoSTD_v2'
	,N'Ended'


