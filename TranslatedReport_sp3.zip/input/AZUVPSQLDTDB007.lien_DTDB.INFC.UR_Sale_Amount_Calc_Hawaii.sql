/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Sale_Amount_Calc_Hawaii | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Sale_Amount_Calc_Hawaii] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc_Hawaii'
		,N'Started'

	BEGIN
		/*IF object_id('lien_DTDB.infc.UR_Hawaii_Sale_Amount_TBL') IS NOT NULL
			*/
DROP TABLE IF EXISTS [lien_DTDB].[infc].[UR_Hawaii_Sale_Amount_TBL]

		SELECT DISTINCT FIPS
			,CLGX_UNIQUE_ID
		INTO [lien_DTDB].[infc].[UR_Hawaii_Sale_Amount_TBL]
		FROM [lien_DTDB].[infc].[deed_work](NOLOCK)
		WHERE Fips IN (
				15001
				,15003
				,15005
				,15007
				,15009
				)
			AND (
				ISNULL(SALE_AMOUNT, 0) = 0
				--OR SALE_AMOUNT IS NULL
				)
			AND DOC_TRANSFER_TAX IS NOT NULL
	END

	-- verify that this code is handeles in infc.usp_Extract_Document
	--BEGIN
	--	UPDATE d
	--	SET d.sale_amount = Round(CASE 
	--			WHEN doc_transfer_tax <= TaxAmtTo
	--				AND doc_transfer_tax > TaxAmtFrom
	--				THEN (doc_transfer_tax * 100 / .1)
	--			WHEN doc_transfer_tax <= 899
	--				AND doc_transfer_tax > 599
	--				THEN (doc_transfer_tax * 100 / .15)
	--			WHEN doc_transfer_tax <= 1999
	--				AND doc_transfer_tax > 899
	--				THEN (doc_transfer_tax * 100 / .2)
	--			WHEN doc_transfer_tax < = 2999
	--				AND doc_transfer_tax > 1999
	--				THEN (doc_transfer_tax * 100 / .25)
	--			WHEN doc_transfer_tax <= 4999
	--				AND doc_transfer_tax > 2999
	--				THEN (doc_transfer_tax * 100 / .3) --- change limit to 4999 instead of 7999
	--			WHEN doc_transfer_tax <= 7999
	--				AND doc_transfer_tax > 4999
	--				THEN (doc_transfer_tax * 100 / .4) --- new -- adding this break out
	--			WHEN doc_transfer_tax <= 11999
	--				AND doc_transfer_tax > 7999
	--				THEN (doc_transfer_tax * 100 / .5) --- change to limit to 11999 instead of 23999
	--			WHEN doc_transfer_tax <= 23999
	--				AND doc_transfer_tax > 11999
	--				THEN (doc_transfer_tax * 100 / .6) --- new -- adding this break out
	--			WHEN doc_transfer_tax <= 50574
	--				AND doc_transfer_tax > 23999
	--				THEN (doc_transfer_tax * 100 / .7)
	--			WHEN doc_transfer_tax > 50574
	--				THEN (doc_transfer_tax * 100 / .9) ---- new Default
	--			ELSE NULL
	--			END,0)
	--		,d.sale_code = 'E'
	--	FROM lien_DTDB.infc.deed_work d
	--	INNER JOIN lien_DTDB.infc.UR_Hawaii_Sale_Amount_TBL t ON d.fips = t.fips
	--		AND d.clgx_unique_id = t.clgx_unique_id
	--END
	BEGIN
		UPDATE [lien_DTDB].[INFC].[d]
		SET d.TRANSACTION_TYPE = CASE 
				WHEN convert(BIGINT, SALE_AMOUNT) > 3000
					THEN '1'
				WHEN convert(BIGINT, isnull(SALE_AMOUNT, 0)) <= 3000
					THEN '9'
				WHEN convert(BIGINT, isnull(MTG1_MTG_AMOUNT, 0)) = 0
					AND convert(BIGINT, isnull(SALE_AMOUNT, 0)) = 0
					AND SELLER_NAME_PLAINTIFF_1 != BYR1_OWN_NAME
					THEN '1'
				WHEN convert(BIGINT, MTG1_MTG_AMOUNT) > 0
					AND convert(BIGINT, isnull(SALE_AMOUNT, 0)) = 0
					AND SELLER_NAME_PLAINTIFF_1 = BYR1_OWN_NAME
					THEN '1'
				WHEN convert(BIGINT, isnull(MTG1_MTG_AMOUNT, 0)) = 0
					AND convert(BIGINT, isnull(SALE_AMOUNT, 0)) = 0
					AND SELLER_NAME_PLAINTIFF_1 = BYR1_OWN_NAME
					THEN '9'
				ELSE NULL
				END
		FROM [lien_DTDB].[infc].[deed_work] d
		INNER JOIN [lien_DTDB].[infc].[UR_Hawaii_Sale_Amount_TBL] t ON d.fips = t.fips
			AND d.clgx_unique_id = t.clgx_unique_id
			AND d.sale_code = 'E'
	END

	--begin
	--update b
	--set b.PRI_CAT_CODE=
	--case when LTRIM(RTRIM(a.SalesPriceCode)) in ('Q','0','2','5','7','9','A','C','D','F','H','V') AND convert(int,b.SALE_AMOUNT)>0 then 'A'
	--when LTRIM(RTRIM(a.DocumentTypeCode))='IT' AND convert(int,b.SALE_AMOUNT)=0 AND convert(int,a.LoanAmount1stTD)=0 then 'B'
	--when LTRIM(RTRIM(a.DocumentTypeCode))='IT' AND convert(int,b.SALE_AMOUNT)=0 AND convert(int,a.LoanAmount1stTD)>0 then 'C'
	--when convert(int,b.SALE_AMOUNT)>0 AND convert(int,a.LoanAmount1stTD)>0 AND (b.OLTV>1 AND b.OLTV<=135) then 'A'
	--when convert(int,b.SALE_AMOUNT)>0 AND convert(int,a.LoanAmount1stTD)>0 AND (b.OLTV<1 OR b.OLTV>135) then 'B'
	--when convert(int,b.SALE_AMOUNT)>15000 AND (convert(int,a.LoanAmount1stTD)=0  OR len(ltrim(ISNULL(a.LoanAmount1stTD,' ')))=0) then 'A'
	--when convert(int,b.SALE_AMOUNT)<=15000 AND (convert(int,a.LoanAmount1stTD)=0  OR len(ltrim(ISNULL(a.LoanAmount1stTD,' ')))=0)then 'B'
	--when b.MTG1_MTG_AMOUNT > 0 AND convert(int,isnull(b.SALE_AMOUNT,0))<=15000  then 'C'
	--when isnull(b.MTG1_MTG_AMOUNT,0) = 0 AND convert(int,isnull(b.SALE_AMOUNT,0))<=15000 then'B'
	--when convert(int,b.SALE_AMOUNT)>15000 then 'A' else NULL end 
	--from
	--adb..MD_Deed_Daily a
	--inner join
	--(select x.fips, x.clgx_unique_id, x.sale_amount, x.sale_code, x.mtg1_mtg_amount, x.PRI_CAT_CODE, 
	--convert(decimal,case when isnull(x.sale_amount,0)>0 and (isnull(x.MTG1_MTG_AMOUNT,0)>0 or isnull(x.MTG2_MTG_AMOUNT,0)>0 or isnull(x.MTG3_MTG_AMOUNT,0)>0 or isnull(x.MTG4_MTG_AMOUNT,0)>0)
	--then ((isnull(x.MTG1_MTG_AMOUNT,0)+isnull(x.MTG2_MTG_AMOUNT,0)+isnull(x.MTG3_MTG_AMOUNT,0)+isnull(x.MTG4_MTG_AMOUNT,0))/isnull(x.sale_amount,0))*100 else null end) as OLTV
	--FROM lien_DTDB.infc.MD_Deed_Inc x
	--inner join
	--lien_DTDB.infc.UR_Hawaii_Sale_Amount_TBL t
	--on x.fips = t.fips
	--and x.clgx_unique_id = t.clgx_unique_id
	--and x.src_tbl = t.src_tbl) b
	--on convert(int,a.fips) = b.fips
	--and a.pid = b.clgx_unique_id
	--and b.sale_code='E'
	--end
	BEGIN
		UPDATE [lien_DTDB].[INFC].[d]
		SET d.sale_code = NULL
		FROM [lien_DTDB].[infc].[deed_work] d
		INNER JOIN [lien_DTDB].[infc].[UR_Hawaii_Sale_Amount_TBL] t ON d.fips = t.fips
			AND d.clgx_unique_id = t.clgx_unique_id
		WHERE d.sale_code = 'E'
			AND ISNULL(d.sale_amount, 0) = 0
	END

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc_Hawaii'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


