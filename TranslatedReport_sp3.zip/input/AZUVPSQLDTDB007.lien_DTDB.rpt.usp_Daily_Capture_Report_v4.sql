/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | rpt.usp_Daily_Capture_Report_v4 | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Changes
--  1. Break out status
--  2. Break out Source
--  3. Header records only
--  4. Duplicate Deed records rejected
--  5. Duplicate Mortgage records rejected
--CREATE TABLE Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals (
--	[Process] [varchar](100) NOT NULL,
--	[Record_Count] [int] NULL,
--	[Seq] [int] NOT NULL
--	)
-- =============================================
create PROCEDURE [lien_DTDB].[rpt].[usp_Daily_Capture_Report_v4]
AS
DECLARE @Email_To VARCHAR(800) = 'epretorius@firstam.com;pspanjer-furstenburg@firstam.com'
	,@Email_CC VARCHAR(800) = NULL
	,@Email_Bcc VARCHAR(800) = NULL
	,@Subject VARCHAR(200) = CASE 
		WHEN @@servername = N'AZUVNSQLDTDB003'
			THEN 'Stage - Lien UR Daily Capture Report'
		ELSE 'Prod - Lien UR Daily Capture Report'
		END
	,@Body VARCHAR(MAX)
	,@Format VARCHAR(200) = 'html'
	,@BodyContent VARCHAR(max)
	,@TableHeader VARCHAR(max)
	,@TableFooter VARCHAR(max)

BEGIN
	 


	TRUNCATE TABLE [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]

	INSERT INTO [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals] (
		Process
		,Record_Count
		,Seq
		)
	SELECT 'All Docids Changed From Lien, Including Fixes' AS Process
		--,format(count(*), '##,##0') AS Record_Count
		,count(*) AS Record_Count
		,100 AS Seq
	FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report]  d


	

	INSERT INTO [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals] (
		Process
		,Record_Count
		,Seq
		)
	SELECT a.*
	FROM (
		SELECT '    Non DTDB doc_type' AS Process
			,count(1) AS Record_Count
			,101 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		WHERE non_dtdb_doctype = 1
		 
		
		UNION ALL
		
		SELECT '    hoa' AS Process
			,count(1) AS Record_Count
			,102 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where HOA_input = 1
		
		UNION ALL
		
		SELECT '    leap' AS Process
			,count(1) AS Record_Count
			,103 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where Leap_input = 1
		
		UNION ALL
		
		SELECT '    pace' AS Process
			,count(1) AS Record_Count
			,104 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where Pace_input = 1

		UNION ALL
			
			SELECT '    Fips not deployed' AS Process
			,count(1) AS Record_Count
			,105 AS Seq
			FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where Fips_not_deployed = 1

		UNION ALL
		
		SELECT '    M_status_id_3' AS Process
			,count(1) AS Record_Count
			,106 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where M_status_id_3 = 1

		UNION ALL
		
		SELECT '    M_status_id_4' AS Process
			,count(1) AS Record_Count
			,107 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where M_status_id_4 = 1

		UNION ALL
		
		SELECT '    M_status_id_5' AS Process
			,count(1) AS Record_Count
			,108 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where M_status_id_5 = 1

		UNION ALL
		
		SELECT '    M_status_id_6: '  AS Process
			,count(1) AS Record_Count
			,109 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where d.M_status_id_6 = 1

		UNION All

		SELECT '       - '  + b.Process_name AS Process
			,count(1) AS Record_Count
			,109 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		OUTER APPLY (
			SELECT TOP 1 Process_name
			FROM [lien].[ur].[document_transaction_log] b WITH (NOLOCK,INDEX (idx_doc))
			WHERE b.doc_id = d.doc_id
				AND d.m_status_id = 6
				and b.process_name <> 'import_from_staging_to_UR'
			ORDER BY d.m_update_date DESC
			) b
		where d.M_status_id_6 = 1
		group by b.Process_name

		UNION ALL
		
		SELECT '    M_status_id_7' AS Process
			,count(1) AS Record_Count
			,110 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_doc_ids_Report] d
		where M_status_id_7 = 1


		) a
select * from [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]

TRUNCATE TABLE [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]

	INSERT INTO [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals] --[Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]
		(
		[Process]
		,[Record_Count]
		,[Seq]
		)
	SELECT 'All Doc_ids after invalid doctype exclusion' AS Process
		,count(*) AS Record_Count
		,200 AS Seq

	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	----
	
	INSERT INTO [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals] (
		Process
		,Record_Count
		,Seq
		)
	SELECT a.*
	FROM (
		SELECT '    Non DTDB doc_type' AS Process
			,count(1) AS Record_Count
			,201 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		WHERE non_dtdb_doctype = 1
		 
		
		UNION ALL
		
		SELECT '    hoa' AS Process
			,count(1) AS Record_Count
			,202 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		where HOA_input = 1
		
		UNION ALL
		
		SELECT '    leap' AS Process
			,count(1) AS Record_Count
			,203 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		where Leap_input = 1
		
		UNION ALL
		
		SELECT '    pace' AS Process
			,count(1) AS Record_Count
			,204 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		where Pace_input = 1

		UNION ALL
			
			SELECT '    Fips not deployed' AS Process
			,count(1) AS Record_Count
			,205 AS Seq
			FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		where Fips_not_deployed = 1

		--UNION ALL
		
		--SELECT '    M_status_id_3' AS Process
		--	,count(1) AS Record_Count
		--	,206 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--where M_status_id_3 = 1

		--UNION ALL
		
		--SELECT '    M_status_id_4' AS Process
		--	,count(1) AS Record_Count
		--	,207 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--where M_status_id_4 = 1

		--UNION ALL
		
		--SELECT '    M_status_id_5' AS Process
		--	,count(1) AS Record_Count
		--	,208 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--where M_status_id_5 = 1

		--UNION ALL
		
		--SELECT '    M_status_id_6' AS Process
		--	,count(1) AS Record_Count
		--	,209 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--where d.M_status_id_6 = 1

		--UNION All

		--SELECT '       - '  + b.Process_name AS Process
		--	,count(1) AS Record_Count
		--	,210 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--OUTER APPLY (
		--	SELECT TOP 1 Process_name
		--	FROM lien.ur.document_transaction_log b WITH (NOLOCK,INDEX (idx_doc))
		--	WHERE b.doc_id = d.doc_id
		--		AND d.m_status_id = 6
		--	ORDER BY d.m_update_date DESC
		--	) b
		--where d.M_status_id_6 = 1
		--group by b.Process_name

		--UNION ALL
		
		--SELECT '    M_status_id_7' AS Process
		--	,count(1) AS Record_Count
		--	,211 AS Seq
		--FROM LIEN_DTDB.rpt.lien_dtdb_doc_ids_Report d
		--where M_status_id_7 = 1


		) a
	
	INSERT INTO [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals] --[Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]
		(
		[Process]
		,[Record_Count]
		,[Seq]
		)
	SELECT 'All Doc_ids For Deployed Fips' AS Process
		,count(*) AS Record_Count
		,212 AS Seq
		FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
		and Fips_not_deployed = 0
	
	
Union all
	SELECT 'All Docids From Lien with Active Status' AS Process
		,count(*) AS Record_Count
		,300 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
		and Fips_not_deployed = 0
		and Relative_included = 0

Union all
	SELECT DISTINCT 'All Related DocIds for incomming Lien doc_ids' AS Process
		,count(*) AS Record_Count
		,400 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
		and Fips_not_deployed = 0
		and Relative_included = 1

 Union all
	SELECT 'Docids with Property, Reference or Names' AS Process
		,count(*) AS Record_Count
		,500 AS seq

	from 
	
	[LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
 	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
		and Fips_not_deployed = 0
		and Docid_with_Prop_Ref_Name = 1

	
	UNION ALL
	
	SELECT 'Duplicate Deed:' AS Process
		,count(*) AS Record_Count
		,600 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
			and Fips_not_deployed = 0
	and Dupl_deed = 1
		and Docid_with_Prop_Ref_Name = 1
	
	UNION ALL
	
	SELECT 'Duplicate Mortgages:' AS Process
		,count(*) AS Record_Count
		,700 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	where (deed_input = 1
		or ras_input = 1
		or PFC_input = 1)
				and Fips_not_deployed = 0
		and Dupl_mtg = 1
			and Docid_with_Prop_Ref_Name = 1
	
	UNION ALL
	
	SELECT 'Deed Extract:' AS Process
		,0 AS Record_Count
		,800 AS seq
	
	UNION ALL
	
	SELECT '     Deed Extract: Deeds' AS Process
		,count(*) AS Record_Count
		,900 AS seq

	from [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] d
		where (deed_input = 1
		)
				and Fips_not_deployed = 0
		and DeedRecord = 1
			and Docid_with_Prop_Ref_Name = 1
	
	UNION ALL
	
	SELECT '     Deed Extract: Concurrent Mortgages' AS Process
		,count(*) AS Record_Count
		,1000 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE (deed_input = 1
		)
				and Fips_not_deployed = 0
		and Concurr_mtg = 1
			and Docid_with_Prop_Ref_Name = 1
	
	UNION ALL
	
	SELECT '     Deed Extract: Stand-Alone Mortgages' AS Process
		,count(*) AS Record_Count
		,2000 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE (deed_input = 1
		)
				and Fips_not_deployed = 0
		and Stand_alone_mtg = 1
			and Docid_with_Prop_Ref_Name = 1
	
	UNION ALL
	
	SELECT 'Pre-Foreclosure Input' AS Process
		,count(*) AS Record_Count
		,3000 AS seq
	--select *
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE PFC_input = 1
			and Fips_not_deployed = 0
			--and PFC_extracted = 0
			and Docid_with_Prop_Ref_Name = 1

	UNION ALL

	SELECT 'Pre-Foreclosure Extract' AS Process
		,count(*) AS Record_Count
		,3001 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE PFC_extracted = 1
	and Fips_not_deployed = 0
		and Docid_with_Prop_Ref_Name = 1
			
	
	UNION ALL
	
	SELECT 'Ras Input' AS Process
		,count(*) AS Record_Count
		,4000 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE Ras_input = 1
	and Fips_not_deployed = 0
		and Docid_with_Prop_Ref_Name = 1
			
	
	UNION ALL
	
	SELECT 'Ras Extract' AS Process
		,count(*) AS Record_Count
		,4001 AS seq
	FROM [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]
	WHERE Ras_extracted = 1
	and Fips_not_deployed = 0
		and Docid_with_Prop_Ref_Name = 1
		



	
	UNION ALL
	
	SELECT 'Prior Stand-Alone Mortgages Now Merged into Deeds' AS Process
		,count(*) AS Record_Count
		,5000 AS seq
	FROM [lien_dtdb].[infc].[delete_standalone_mtg]
	
	UNION ALL
	
	SELECT 'Prior Stand-Alone Mortgages Deleted from NovaDimDoc' AS Process
		,count(*) AS Record_Count
		,6000 AS seq
	FROM [LIEN_DTDB].[tmp].[delete_nova_records]
	
	--/*====================================
 -- Update Totals 
 -- ====================================*/
	----DECLARE @total_Exclude INT = 0
	----SET @total_Exclude =
	----(SELECT sum(Record_Count) AS total_Exclude
	------FROM Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals
	----from Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals
	----WHERE process LIKE '%Exclude %')
	----update a
	----	set a.Record_Count = @total_Exclude
	------from Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals a
	----from Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals a
	----where process = 'Exlude:'
	----SET @total_Exclude =
	----(SELECT sum(Record_Count) AS total_Exclude
	------FROM Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals
	----from Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals
	----WHERE process LIKE '%Deed Extract:%')
	----update a
	----	set a.Record_Count = @total_Exclude
	------from Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals a
	----from Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals a
	----where process = 'Deed Extract:'
	--/*====================================
 -- Inserts Totals 
 -- ====================================*/
	--DROP TABLE

	--IF EXISTS #seq_2000
	--	SELECT a.*
	--	INTO #seq_2000
	--	FROM #seq_109 a
	--	LEFT JOIN #seq_110 b ON b.doc_id = a.doc_id
	--	WHERE b.doc_id IS NULL

	--CREATE INDEX idx_doc_id ON #seq_2000 (doc_id)

	--INSERT INTO Lien_DTDB.RPT.Lien_to_DTDB_Capture_Totals --[Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]
	--	(
	--	[Process]
	--	,[Record_Count]
	--	,[Seq]
	--	)
	--SELECT '     Exclude Header records' AS Proces
	--	,count(1) AS Record_Count
	--	,450 AS Seq
	--FROM #seq_2000 a --Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals a

	Select * from [Lien_dtdb].[rpt].[Lien_to_DTDB_Capture_Totals] order by seq 

--	select 714706

--	select 5165 + 237 + 535028 + 70350 + 18439 + 724 + 20643  = 650586

--	Select 714706 - 650586 -- 64120

-- select 61616 - 57 -68 == 61491
--select  16944 + 8749 + 9652 + 597 + 17448 == 53390

--select 61491 -  53390 == 8101


	SET @TableFooter = '</table></body></html>';
	SET @TableHeader = '<html><head>' + '<style>' + 'td {padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;font-family: Arial, Helvetica, sans-serif; font-size: 10pt;} ' + '</style>' + '</head>' + '<body><table cellpadding="5" cellspacing="0" border="1" bordercolor="#000000" style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; border-collapse:collapse;border-bottom-style:solid black;">' + '<tr bgcolor=#FFEFD8>
				   <td align=center style="background-color: #359AFF; color: black"><b>Process</b></td>' + '<td align=center style="background-color: #359AFF; color: black"><b>Record_Count</b></td>';

	SELECT @BodyContent = (
			SELECT Process AS [TD]
				--,Record_Count AS [TD]
				,format(Record_Count, '##,##0') AS [TD]
			FROM [Lien_DTDB].[RPT].[Lien_to_DTDB_Capture_Totals]
			FOR XML raw('tr')
				,Elements
			)

	SET @BodyContent = Replace(@BodyContent, '_x0020_', space(1))
	SET @BodyContent = Replace(@BodyContent, '_x003D_', '=')
	SET @BodyContent = Replace(@BodyContent, '<tr><ALTCOLOR>1</ALTCOLOR>', '<tr bgcolor=#DFFFDF>')
	SET @BodyContent = Replace(@BodyContent, '<ALTCOLOR>0</ALTCOLOR>', '')
		Select @BodyContent = @TableHeader + @BodyContent + @TableFooter
		exec  msdb.dbo.sp_send_dbmail
		   @recipients				= @Email_To
		   ,@copy_recipients		= @Email_Cc
		   ,@blind_copy_recipients	= @Email_Bcc
		   ,@subject				= @Subject
		   ,@body					= @BodyContent
		   ,@body_format			= @Format
		   ,@profile_name = 'Tree_Trace_DBA_Team'
END

-- 	Select * from Lien_dtdb.rpt.Lien_to_DTDB_Capture_Totals order by seq 
-- select 275720 - 984 - 83 = 274653
--select  274653 - 173651 - 24909 - 49750 = 26343

--select 26343 - 1223 - 26169 == -1049

--select 276724 - 275720 == 1004

