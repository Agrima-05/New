SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ReliantCapital].[dbo].[usp_100_GET_BankruptcyDATA]

AS
BEGIN

	SET NOCOUNT ON;

	
	--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MatchWork_I]') AND type in (N'U'))

	--DROP table dbo.MatchWork_I


	Truncate table MatchWork_I
	

	-----20240716 - Per EC
----Match Code "1" - LastName, FirstName, State, First 6 tokens of Address
----Match Code "2" - LastName, State, First 6 tokens of Address 
	
	  Insert into [zCust_ReliantCapital].[dbo].[MatchWork_I]
	  Select  a.[INPUTKEY], A.[Borrower Last Name], A.MAX_BKY_RECDATE, A.[Monitoring START DATE], A.[State]
	  , b.*,0 as RowNbr 
	  ,'1' as MATCHTYPE
	  --INTO dbo.MatchWork_I
	  FROM [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] a JOIN [BKY].[TR00].[BKY_History] b with(NOLOCK)
	  on ltrim(rtrim(BKY_DEF_NAME)) like '%' +  a.[Borrower Last Name] + '%' + a.[Borrower First Name] + '%'  
	  and LEFT(replace(A.[ADDRESS],'  ',' '),6) = LEFT(b.BKY_DEF_ST_ADD,6)
	  ------Added State match 20170502 KL---
	  AND LTRIM(RTRIM(A.[State])) = left(B.[BKY_COURT_ID],2)
	  WHERE ISNULL(A.[Borrower Last Name],'') not like ''
	  and ISNULL(a.[Borrower First Name],'') not like ''
	  and A.[Record Indicator] not like 'D'
	  and (convert(datetime,BKY_RECORD_DATE) > convert(datetime,A.MAX_BKY_RECDATE)
	  or A.MAX_BKY_RECDATE is null)
	  AND convert(datetime,BKY_RECORD_DATE) > convert(datetime,A.[Monitoring START DATE])

	 
	

	  Insert  INTO [zCust_ReliantCapital].[dbo].[MatchWork_I]
	   Select  a.[INPUTKEY], A.[Borrower Last Name], A.MAX_BKY_RECDATE, A.[Monitoring START DATE], A.[State]
	  , b.*,0 as RowNbr 
	  ,'2' as MATCHTYPE
	  FROM [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] a JOIN [BKY].[TR00].[BKY_History] b with(NOLOCK)
	  on ltrim(rtrim(BKY_DEF_NAME)) like '%' +  a.[Borrower Last Name] + '%' 
	  and LEFT(replace(A.[ADDRESS],'  ',' '),6) = LEFT(b.BKY_DEF_ST_ADD,6)
	  ------Added State match 20170502 KL---
	  AND LTRIM(RTRIM(A.[State])) = left(B.[BKY_COURT_ID],2)
	  WHERE ISNULL(A.[Borrower Last Name],'') not like ''
	  and A.[Record Indicator] not like 'D'
	  and (convert(datetime,BKY_RECORD_DATE) > convert(datetime,A.MAX_BKY_RECDATE)
	  or A.MAX_BKY_RECDATE is null)
	  AND convert(datetime,BKY_RECORD_DATE) > convert(datetime,A.[Monitoring START DATE])


	  --Select top 10000 * from  BKY.TR00.BKY_History b with(NOLOCK)
	  
	  


	  Delete from [zCust_ReliantCapital].[dbo].[MatchWork_I]
	  WHERE BKY_VALID_FLAG <> 1 


	  Update [zCust_ReliantCapital].[dbo].[MatchWork_I]
	  set RowNbr = NULL

	  UPDATE [zCust_ReliantCapital].[dbo].[t] SET RowNbr = RowNum
		FROM [zCust_ReliantCapital].[dbo].[MatchWork_I] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY BKY_FILING_DATE DESC) AS RowNum
			FROM 
		[zCust_ReliantCapital].[dbo].[MatchWork_I] t WHERE BKY_VALID_FLAG = 1 
		) r ON t.INPUTKEY = r.INPUTKEY and t.BKY_RMS_ID = r.BKY_RMS_ID


	 

			
			


END

