SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_TaxSource_Amrock].[dbo].[usp_300_Start_Output_AMROCK_UPDATE_DOC_STATUS]


AS
BEGIN
	
	SET NOCOUNT ON;

	

		UPdate [zCust_TaxSource_Amrock].[dbo].[C]
		Set C.DOCSTATUS = NULL
		--Select A.BatchID, A.ExternalKey, PropertyID, ReportName, ReportStatus, A.DOCSTATUS--, C.DocStatus
		FROM [TaxSourceAPI].[dbo].[OutputLayout4] as A with(NOLOCK)
		join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		join [TaxSourceAPI].[dbo].[Property] as C with(NOLOCK) on A.ExternalKey = C.ExternalKey
		and A.BatchId = C.BatchId
		where B.DATE_COMPLETED is null
		and ReportStatus like 'Ready'
		--and C.DocStatus is null
		AND (A.DOCSTATUS like 'Error%' or A.DocStatus is null)

		--AND A.Externalkey in ('69507475','69262289A','69207319','69416536')

		-----Image puller if needed (this is PROD puller)--
		---On server 192:
		---D:\SupportTools\TaxSourceAPIImagePuller\Release
		---TaxSourceAPIImagePull.exe 9  (replace the 9 with the Batch number needed to run!!)


		

		--Select A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and ReportStatus  like 'Ready'
		--AND DOCSTATUS like 'Error%'
		--Order by ReportStatus,DOCSTATUS



		--Select A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR_COMPLETED as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where ReportStatus like 'Ready'
		--AND DOCSTATUS like 'Err%'


		--Select Distinct A.BatchID
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--join TaxSourceAPI.[dbo].Property as C with(NOLOCK) on A.ExternalKey = C.ExternalKey
		--and A.BatchId = C.BatchId
		--where B.DATE_COMPLETED is null
		--and ReportStatus like 'Ready'
		--AND (A.DOCSTATUS like 'Error%' or A.DocStatus is null)

		
		
		


	 	
		
END





