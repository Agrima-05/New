SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_TaxSource_Amrock].[dbo].[usp_300_Start_Output_AMROCK_V2_UAT]


AS
BEGIN
	
	SET NOCOUNT ON;
	

	--------Per Giang - 
	----	Production Test Credentials
	----	User:  DTAPI_DataAcq_Prod
	----	PSWD:  DataAcqDTAPI1@Prod

	----	UAT Credentials
	----	User:DTAPI_DataAcq_UAT
	----	PSWD:DataAcqDTAPI1@UAT



	----Per GIANG - USE UAT CREDENTIALS & NOTIFY BRIAN DIXON & MICHAEL CLOOTEN that you have pushed records in Manual counties so they initiate the process!!
	
	----D:\SupportTools\TaxSourceApiExeUAT
	----TaxSourcePuller.exe 7 DTAPI_DataAcq_UAT DataAcqDTAPI1@UAT
	----7 is the Batch ID


		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
		[Id][int]NULL,
		[BatchId][int]NULL,
		[ExternalKey][varchar](10)NULL,
		[PropertyId][varchar](4000)NULL,
		[ReportName][varchar](4000)NULL,
		[ReportStatus][varchar](4000)NULL,
		[ReferenceId][varchar](4000)NULL,
		[OrderItemId][varchar](4000)NULL,
		[StreetAddress][varchar](4000)NULL,
		[City][varchar](4000)NULL,
		[State][varchar](4000)NULL,
		[Zip9][varchar](4000)NULL,
		[County][varchar](4000)NULL,
		[APN][varchar](4000)NULL,
		[StateFips][varchar](4000)NULL,
		[CountyFips][varchar](4000)NULL,
		[ReportAsOfDate][varchar](30)NULL,
		[AssessorsAlternateParcelIdentifier][varchar](4000)NULL,
		[ExtendedLegalDescription][varchar](4000)NULL,
		[LandUse][varchar](4000)NULL,
		[TraCode][varchar](4000)NULL,
		[TraName][varchar](4000)NULL,
		[OwnerNames][varchar](4000)NULL,
		[Errors][varchar](2000)NULL,
		[Message][varchar](4000)NULL,
		[Agency1_MismoAgencyCode][varchar](4000)NULL,
		[Agency1_Name][varchar](4000)NULL,
		[Agency1_AgencyType][varchar](4000)NULL,
		[Agency1_TaxCollectorUrl][varchar](4000)NULL,
		[Agency1_PhoneNumber][varchar](4000)NULL,
		[Agency1_FaxNumber][varchar](4000)NULL,
		[Agency1_Email][varchar](4000)NULL,
		[Agency1_MakePayableTo][varchar](4000)NULL,
		[Agency1_StreetAddress][varchar](4000)NULL,
		[Agency1_CityStateZip][varchar](4000)NULL,
		[Agency1_MailingStreet][varchar](4000)NULL,
		[Agency1_MailingCityStateZip][varchar](4000)NULL,
		[Agency1_TaxYearType][varchar](4000)NULL,
		[Agency1_TaxYearDates][varchar](4000)NULL,
		[Agency1_CurrentTaxYear][varchar](4000)NULL,
		[Agency1_CollectsInArrears][varchar](4000)NULL,
		[Agency1_DiscountAgency][varchar](4000)NULL,
		[Agency1_DuplicateBillRequired][varchar](4000)NULL,
		[Agency1_DuplicateBillFee][varchar](4000)NULL,
		[Agency1_ExternalAgencyNotes][varchar](4000)NULL,
		[TaxDetails_AsOfDate][varchar](30)NULL,
		[TaxDetails_SchoolDistrict][varchar](4000)NULL,
		[TaxDetails_TaxId][varchar](4000)NULL,
		[TaxDetails_DelinquentTaxes][varchar](4000)NULL,
		[TaxDetails_TaxReportStatus][varchar](4000)NULL,
		[TaxDetails_DelinquencyTaxSaleYear][varchar](4000)NULL,
		[TaxYear][varchar](4000)NULL,
		[TaxType][varchar](4000)NULL,
		[TaxSupplementalAPN][varchar](4000)NULL,
		[TotalTax][varchar](4000)NULL,
		[ImprovementValue][varchar](4000)NULL,
		[LandVal][varchar](4000)NULL,
		[AssessedTotalValue][varchar](4000)NULL,
		[AssessedYear][varchar](4000)NULL,
		[ExemptionType][varchar](4000)NULL,
		[ExemptionAmount][varchar](4000)NULL,
		[NetVal][varchar](4000)NULL,
		[CertificateOfPurchase][varchar](4000)NULL,
		[TaxInstallmentsMessage][varchar](4000)NULL,
		[TaxBillNumber][varchar](4000)NULL,
		[InstallmentDetail1_SequenceId][varchar](4000)NULL,
		[InstallmentDetail1_Amount][varchar](4000)NULL,
		[InstallmentDetail1_Status][varchar](4000)NULL,
		[InstallmentDetail1_PaymentDate][varchar](30)NULL,
		[InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[InstallmentDetail1_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail1_DueDate][varchar](30)NULL,
		[InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail1_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail1_DiscountDate][varchar](30)NULL,
		[InstallmentDetail1_Penalty][varchar](4000)NULL,
		[InstallmentDetail1_Interest][varchar](4000)NULL,
		[InstallmentDetail2_SequenceId][varchar](4000)NULL,
		[InstallmentDetail2_Amount][varchar](4000)NULL,
		[InstallmentDetail2_Status][varchar](4000)NULL,
		[InstallmentDetail2_PaymentDate][varchar](30)NULL,
		[InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[InstallmentDetail2_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail2_DueDate][varchar](30)NULL,
		[InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail2_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail2_DiscountDate][varchar](30)NULL,
		[InstallmentDetail2_Penalty][varchar](4000)NULL,
		[InstallmentDetail2_Interest][varchar](4000)NULL,
		[InstallmentDetail3_SequenceId][varchar](4000)NULL,
		[InstallmentDetail3_Amount][varchar](4000)NULL,
		[InstallmentDetail3_Status][varchar](4000)NULL,
		[InstallmentDetail3_PaymentDate][varchar](30)NULL,
		[InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[InstallmentDetail3_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail3_DueDate][varchar](30)NULL,
		[InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail3_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail3_DiscountDate][varchar](30)NULL,
		[InstallmentDetail3_Penalty][varchar](4000)NULL,
		[InstallmentDetail3_Interest][varchar](4000)NULL,
		[InstallmentDetail4_SequenceId][varchar](4000)NULL,
		[InstallmentDetail4_Amount][varchar](4000)NULL,
		[InstallmentDetail4_Status][varchar](4000)NULL,
		[InstallmentDetail4_PaymentDate][varchar](30)NULL,
		[InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[InstallmentDetail4_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail4_DueDate][varchar](30)NULL,
		[InstallmentDetail4_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail4_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail4_DiscountDate][varchar](30)NULL,
		[InstallmentDetail4_Penalty][varchar](4000)NULL,
		[InstallmentDetail4_Interest][varchar](4000)NULL,
		[OtherTaxDetails1_TaxYear][varchar](4000)NULL,

		[OtherTaxDetails1_TaxType][varchar](4000) NULL,


		[OtherTaxDetails1_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails1_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails1_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails1_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails1_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails2_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails2_TaxType][varchar](4000) NULL,

		[OtherTaxDetails2_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails2_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails2_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails2_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails2_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails3_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails3_TaxType][varchar](4000) NULL,

		[OtherTaxDetails3_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails3_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails3_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails3_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails3_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[AdditionalOtherTaxDetails][varchar](1)NULL,

		[RedemptionDetails1_Amount][varchar](30) NULL,
		[RedemptionDetails1_RedemptionDate][varchar](30) NULL,


		[RedemptionDetails1_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails2_Amount][varchar](30) NULL,
		[RedemptionDetails2_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails2_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails3_Amount][varchar](30) NULL,
		[RedemptionDetails3_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails3_PaymentGoodThrough][varchar](4000) NULL


			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		

	   INSERT INTO [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	   SELECT
		 REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') as Errors
		,REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
  
		--Select A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID
		FROM [TaxSourceAPIUAT].[dbo].[OutputLayout4] as A with(NOLOCK)
		join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_UAT] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
		and ReportStatus is not null and ReportStatus not like 'Processing'

		--Select * From TaxSourceAPIUAT.[dbo].[Property]
		--where BatchID = 7

		--Select * From TaxSourceAPIUAT.[dbo].[Batch]

		--Select BatchID, ExternalKey,ReportStatus, Errors , REFERENCEID  From  TaxSourceAPIUAT.[dbo].[OutputLayout4] as A with(NOLOCK)
		--where BatchID = 7

		--Select * From [TaxSourceAPI].[dbo].[Property]
		--where BatchId = 8

		--Delete from [TaxSourceAPI].[dbo].[Property]
		--where BatchId = 8

	
	
		--Select BATCHID,count(*) as TOTAL From INPUT_MONITOR_UAT
		--Group by BATCHID

		--Select count(*) as TOTAL From INPUT_MONITOR_UAT
		

	  Select count(*) From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]


	  UPdate [zCust_TaxSource_Amrock].[dbo].[A]
	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
	  From  [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_UAT] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT] as B on 
	  A.UniqueID = B.[ExternalKey]


	  Insert into [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED_UAT]
	  Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_UAT]
	  where DATE_COMPLETED is not null

	  --Select * From [INPUT_MONITOR_COMPLETED_UAT]


	  Delete from [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_UAT]
	  --Select * 
	  From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_UAT] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED_UAT] as B on 
	  A.UniqueID = B.UniqueID
	  and A.BatchID = B.BatchID
	  where B.DATE_COMPLETED is not null


	  -------Copy pdf reports-----
	Truncate table REPORTS_TO_COPY

	Insert into [zCust_TaxSource_Amrock].[dbo].[REPORTS_TO_COPY]

	Select  D.ImageFolderPath + '\' + B.ExternalKey + '.pdf' as IMAGEPATH,NULL as COPIED
	 --into zCust_TaxSource_Amrock.dbo.REPORTS_TO_COPY
	 From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED_UAT] as A 
	 join [zCust_TaxSource_Amrock].[dbo].[x_custom_OUTPUT] as B on 
	 A.UniqueID = B.[ExternalKey]
	 and A.BatchID = B.BatchID
	 join [TaxSourceAPIUAT].[dbo].[Property] as C on A.BatchID = C.BatchID
	 and A.UniqueID = C.ExternalKey
	 join [TaxSourceAPIUAT].[dbo].[Batch] as D on A.BATCHID = D.Id
	 where B.ReportStatus like 'Ready'

	


	 Select * From [zCust_TaxSource_Amrock].[dbo].[REPORTS_TO_COPY]

	 	
		

END





