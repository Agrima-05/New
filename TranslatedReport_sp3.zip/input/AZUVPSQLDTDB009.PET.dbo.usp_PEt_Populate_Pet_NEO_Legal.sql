/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_PEt_Populate_Pet_NEO_Legal | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
-- =====================================================================================================================
-- Author:		<Marie Pretorius>
-- Create date: <02/18/2022>
-- Description:	<Create Pet_NEO_Legal records>
--
-- Marie - 3/28/2022
--         Populate Neo_legal_Cnt on Pet.dbo.Pet table
-- =====================================================================================================================
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie   3/28/2022	Populate Neo_legal_Cnt on Pet.dbo.Pet table
paul	7/31/22		1. Add logical transaction logic
					2. Change the update of LEGAL count on pet -  make it 0 if no legals were found
paul	20230314	add the neo_legla cnt updates to this program
Marie	2023/05/19	Add Portion_Ind to Pet_Neo_legal Table
					Change Delete to Use Partition truncation
******************************************************************************************************************/
CREATE PROCEDURE [PET].[dbo].[usp_PEt_Populate_Pet_NEO_Legal] @Fips INT = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY
		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_PEt_Populate_Pet_NEO_Legal'
			,N'Started'

		--		DECLARE @Fips int = 12027
		DECLARE @InSert_DATE DATETIME = GETDATE()

		/*--------------------------------------------------------------------
   Determine which records to insert into Pet.dbo.PET_NEO_Legal
   Only records that has a Neo_Title_Legal and regardless if it matched
   ----------------------------------------------------------------------*/
		--DROP TABLE
		--IF EXISTS #Neo_Legal_Cnt
		--	SELECT DISTINCT Fips
		--		,Neo_APN AS DLX_DL_land_info
		--		,Neo_Land_Type AS dlp_DL_land_type
		--		,Neo_Title_Legal AS dlp_DL_land_info
		--	INTO #Neo_Legal_Cnt
		--	FROM pet.dbo.PET_NEO_Xref
		--	WHERE Fips = @Fips
		--	and Neo_Title_Legal is not null
		--DROP TABLE
		--IF EXISTS #Neo_Legal_Cnt2
		--	SELECT t.*
		--		,(
		--			SELECT [SPDB].[dbo].[find_RefId_with_Fips_and_APN](DLX_DL_land_info, @Fips)
		--			) AS ref_id
		--	INTO #Neo_Legal_Cnt2
		--	FROM #Neo_Legal_Cnt t
		--CREATE INDEX ixa ON #Neo_Legal_Cnt2 (
		--	Fips
		--	,REf_id
		--	)
		--CREATE INDEX ixb ON #Neo_Legal_Cnt2 (REf_id)
		--DROP TABLE
		--IF EXISTS #Neo_Legal_Cnt
		-- Commented out 9/13/2022 MP
		--DECLARE @translatedFips INT = (
		--		SELECT *
		--		FROM [SPDB].[dbo].[fnt_GetTranslatedFips](@fips)
		--		)
		TRUNCATE TABLE [pet].[tmp].[PET_NEO_LEGALS]

		INSERT INTO [pet].[tmp].[PET_NEO_LEGALS] (
			FIPS
			,REF_ID
			,NEO_LAND_TYPE
			,NEO_TITLE_LEGAL
			,NEO_APN
			,Legal_Dup_Ind
			,[created]
			,PORTION_IND
			)
		SELECT DISTINCT x.FIPS
			,p.Ref_id
			,Neo_Land_Type
			,Neo_Title_Legal
			,Neo_APN
			,0 AS Dup_Ind
			,@Insert_DAte AS Created
			,x.PORTION_IND
		FROM [pet].[dbo].[PET_NEO_Xref_Full] x WITH (INDEX (ix_fips_legal))
		INNER JOIN [pet].[dbo].[pet_apn] p ON p.fips = x.fips
			AND p.apn = x.NEO_APN
			AND p.APN_Type = 'NEOF'
		--INNER JOIN Pet.dbo.Pet_Fips_APN_Type f WITH (INDEX (fips_apn_type_NEO)) ON f.Fips = p.Fips
		--	AND f.Apn_type = p.Apn_type
		--	--AND f.NEO_PET = 1
		WHERE x.Fips = @Fips
			--AND x.Neo_Title_Legal IS NOT NULL

		--AND p.ref_id IS NOT NULL
		/*=====================================
  Populate NEO_Legal_Cnt on pet table
  =====================================*/
		DROP TABLE

		IF EXISTS #Neo_Legal_Cnt
			SELECT l.Fips
				,REF_ID
				,count(*) AS Neo_Legal_Cnt
			INTO #Neo_Legal_Cnt
			FROM [pet].[tmp].[PET_NEO_LEGALS] l
			--WHERE fips = @Fips
			GROUP BY Fips
				,ref_id

		CREATE UNIQUE INDEX idx ON #Neo_Legal_Cnt (
			fips
			,ref_id
			)

		DROP TABLE

		IF EXISTS #leg_dup
			SELECT fips
				,NEO_TITLE_LEGAL
				,count(1) AS cnt
			INTO #leg_dup
			FROM [pet].[tmp].[PET_NEO_LEGALS]
			--WHERE fips = @Fips
			GROUP BY fips
				,NEO_TITLE_LEGAL
			HAVING count(1) > 1

		CREATE INDEX ixa ON #leg_dup (
			FIPS
			,NEO_TITLE_LEGAL
			)

		UPDATE [PET].[dbo].[a]
		SET a.Legal_Dup_Ind = 1
		FROM [pet].[tmp].[PET_NEO_LEGALS] a
		INNER JOIN #leg_dup d ON d.fips = a.fips
			AND d.NEO_TITLE_LEGAL = a.NEO_TITLE_LEGAL

		DROP TABLE

		IF EXISTS #pet_Neo_land_type_counts
			SELECT FIPS
				,REF_ID
				,sum(CASE 
						WHEN NEO_LAND_TYPE = 'AN'
							THEN 1
						ELSE 0
						END) AS AN_cnt
				,sum(CASE 
						WHEN NEO_LAND_TYPE = 'AT'
							THEN 1
						ELSE 0
						END) AS AT_cnt
				,sum(CASE 
						WHEN NEO_LAND_TYPE = 'MC'
							THEN 1
						ELSE 0
						END) AS MC_cnt
				,sum(CASE 
						WHEN NEO_LAND_TYPE = 'SB'
							THEN 1
						ELSE 0
						END) AS SB_cnt
				,sum(CASE 
						WHEN NEO_LAND_TYPE = 'SC'
							THEN 1
						ELSE 0
						END) AS SC_cnt
			INTO #pet_Neo_land_type_counts
			FROM [pet].[tmp].[PET_NEO_LEGALS]
			WHERE fips = @fips
			GROUP BY FIPS
				,REF_ID
			OPTION (
				RECOMPILE
				,MAXDOP 12
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

		CREATE INDEX idx ON #pet_Neo_land_type_counts (
			Fips
			,ref_id
			) include (
			AN_cnt
			,AT_cnt
			,MC_cnt
			,SB_cnt
			,SC_cnt
			)

		BEGIN TRANSACTION

		/*--------------------------------------------------------------
   Delete all records for the county from pet.dbo.PET_NEO_Legals
   ------------------------------------------------------------*/
		--  declare @Fips int = 12027
		DELETE l
		FROM [pet].[dbo].[PET_NEO_Legals] l
		WHERE l.Fips = @Fips

		--DECLARE @partition_number INT = $PARTITION.PET_Partition_FipsPF(@Fips)
		--TRUNCATE TABLE pet.dbo.PET_NEO_Legals WITH (PARTITIONS (@partition_number))
		INSERT INTO [pet].[dbo].[PET_NEO_Legals] (
			FIPS
			,REF_ID
			,NEO_LAND_TYPE
			,NEO_TITLE_LEGAL
			,NEO_APN
			,Legal_Dup_Ind
			,created
			,PORTION_IND
			,Neo_title_legal_18
			)
		SELECT a.FIPS
			,a.REF_ID
			,a.NEO_LAND_TYPE
			,nullif(a.NEO_TITLE_LEGAL, '') AS NEO_TITLE_LEGAL
			,a.NEO_APN
			,a.Legal_Dup_Ind
			,a.created
			,a.PORTION_IND
			,SUBSTRING(a.Neo_title_legal, 1, 18) AS Neo_title_legal_18
		FROM [pet].[tmp].[PET_NEO_LEGALS] a WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		--LEFT JOIN #pet_Neo_land_type_counts b WITH (
		--		NOLOCK
		--		,INDEX (idx)
		--		) ON b.fips = a.fips
		--	AND b.REF_ID = a.REF_ID
		--LEFT JOIN #Neo_Legal_Cnt t WITH (
		--		NOLOCK
		--		,INDEX (idx)
		--		) ON t.fips = a.fips
		--	AND t.ref_id = a.ref_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		UPDATE [PET].[dbo].[p]
		SET p.Neo_Legal_Cnt = CASE 
				WHEN t.Neo_Legal_Cnt IS NOT NULL
					THEN t.Neo_Legal_Cnt
				ELSE 0
				END
			,p.NEO_LAND_TYPE_AN = b.AN_cnt
			,p.NEO_LAND_TYPE_AT = b.AT_cnt
			,p.NEO_LAND_TYPE_MC = b.MC_cnt
			,p.NEO_LAND_TYPE_SB = b.SB_cnt
			,p.NEO_LAND_TYPE_SC = b.SC_cnt
		FROM [pet].[dbo].[pet] p WITH (
				NOLOCK
				,INDEX (IDX_FIPS_REF_ID)
				)
		LEFT JOIN #Neo_Legal_Cnt t ON p.fips = t.fips
			AND p.ref_id = t.ref_id
		LEFT JOIN #pet_Neo_land_type_counts b ON b.fips = p.fips
			AND b.REF_ID = p.REF_ID
		WHERE p.fips = @fips
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		COMMIT

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_PEt_Populate_Pet_NEO_Legal'
			,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		--ROLLBACK
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


