SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	parse CoAgent data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_280_CoAgent]

AS
BEGIN


	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		TRUNCATE TABLE agent.CoAgent_Batch

		INSERT INTO [src_platlabs].[agent].[CoAgent_Batch]
		SELECT a.agentUID, a.mls_id,a.mls_listing_id,a.CoAgentName,a.FirstName,a.LastName,a.AgentEmail,a.AgentPhone,a.LicenseNumber,agentID
		,CoAgentOffice_Array.[id] as officeID,CoAgentOffice_Array.[name] officeName,CoAgentOffice_Array.[phone] officePhone,LoadDate
		FROM (
		Select [uid] agentUID,[mls_id],[mls_listing_id],[id] agentID,[name] as CoAgentName
		,first_name as FirstName
		,last_name as LastName
		,email as AgentEmail
		,phone as AgentPhone
		,license_number as LicenseNumber
		,office as Office
		,GetDate() as LoadDate
		 from (Select mls_id,mls_listing_id,[agents_co_listing_agent] from [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK) Where [agents_co_listing_agent] is not null) info
				CROSS APPLY OPENJSON([agents_co_listing_agent]) WITH(
					id varchar(50)
					  ,uid varchar(20)
					  ,name varchar(100)
					  ,first_name varchar(20)
					  ,last_name varchar(20)
					  ,email varchar(200)
					  ,phone varchar(20)
					  ,license_number varchar(20)
					  ,office nvarchar(max) AS JSON
					 ) as CoAgent_Array) a 
			CROSS APPLY OPENJSON([office]) WITH(
					id varchar(50) 
					  ,name varchar(100)
					  ,phone varchar(25)
					  ,uid varchar(20)
					 ) as CoAgentOffice_Array

		Delete from [src_PlatLabs].[dbo].[a] 
			FROM [src_PlatLabs].[agent].[CoAgent] a JOIN [src_PlatLabs].[agent].[CoAgent_Batch] b
			ON a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id

		insert into [src_PlatLabs].[agent].[CoAgent]
		Select * from [src_PlatLabs].[agent].[CoAgent_Batch] WITH(NOLOCK)

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




