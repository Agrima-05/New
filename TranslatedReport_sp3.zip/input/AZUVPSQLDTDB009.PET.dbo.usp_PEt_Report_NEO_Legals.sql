/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_PEt_Report_NEO_Legals | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie 	11/09/22	Crete report for NEO Legals that is not parsed
Marie	11/10/2022	Create a report where Neo Legals are missing
******************************************************************************************************************/

CREATE   PROCEDURE [PET].[dbo].[usp_PEt_Report_NEO_Legals] 
	@Email_To		varchar(800) = Null,
	@Email_CC		varchar(800) = Null,
	@Email_Bcc		varchar(800) = Null

AS

DECLARE
		@Body		 varchar(MAX),
		@Format		 varchar(200) = 'html',
		@Subject	 varchar(200),
		@BodyContent varchar(max),
		@TableHeader varchar(max),
		@TableFooter varchar(max),
		@Server		  varchar(10)

SET @Server = CASE WHEN @@ServerName  = 'AZUVNSQLDTDB003' THEN 'Stage' ELSE 'Prod' END


/*--------------------------------------
  Neo Legals Not Parsed
  --------------------------------------*/
DECLARE @Legals_Parsed INT
SET @Legals_Parsed = (Select count(*) from [PET].[dbo].[pet_neo_legals_parsed_cnt])

IF @Legals_Parsed > 0
BEGIN
	SET @Subject = @Server + ': Daily PET Report - Legals NOT Parsed' 

	Set @TableFooter = '</table></body></html>';
	Set @TableHeader = '<html><head>' +
					  '<style>' +
					  'td {padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;font-family: Arial, Helvetica, sans-serif; font-size: 10pt;} ' +
					  '</style>' +
					  '</head>' +
					  '<body><table cellpadding="5" cellspacing="0" border="1" bordercolor="#000000" style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; border-collapse:collapse;border-bottom-style:solid black;">' +
					  '<tr bgcolor=#FFEFD8>
					   <td align=center style="background-color: #359AFF; color: black"><b>Fips</b></td>' +
					  '<td align=center style="background-color: #359AFF; color: black"><b>Parse_Cnt</b></td>' ;
	Select @BodyContent = (
	SELECT   FIPS	As [TD]
			,Parse_Cnt As [TD]
	FROM [PET].[dbo].[pet_neo_legals_parsed_cnt]
		order by fips
			  For XML raw('tr'), Elements)
	
	Set @BodyContent = Replace(@BodyContent, '_x0020_', space(1))
	Set @BodyContent = Replace(@BodyContent, '_x003D_', '=')
	Set @BodyContent = Replace(@BodyContent, '<tr><ALTCOLOR>1</ALTCOLOR>', '<tr bgcolor=#DFFFDF>')
	Set @BodyContent = Replace(@BodyContent, '<ALTCOLOR>0</ALTCOLOR>', '')


	Select @BodyContent = @TableHeader + @BodyContent + @TableFooter

	exec  msdb.dbo.sp_send_dbmail
	   @recipients				= @Email_To
	   ,@copy_recipients		= @Email_Cc
	   ,@blind_copy_recipients	= @Email_Bcc
	   ,@subject				= @Subject
	   ,@body					= @BodyContent
	   ,@body_format			= @Format
END

/*--------------------------------------
  Neo Legals Missing
  --------------------------------------*/

DROP TABLE if exists #Temp
SELECT distinct [FIPS]
into #temp
FROM [PET].[dbo].[PET_NEO_Xref_Full]
order by fips

DROP TABLE if exists #temp_Legals_Missing
select t.fips
into #temp_Legals_Missing
from        #temp         t
outer apply (Select top 1 fips from [pet].[dbo].[pet_neo_Legals] where fips = t.fips ) p
where p.fips is null
order by fips

DECLARE @Neo_Missing_Cnt INT

SET @Neo_Missing_Cnt = (SELECT count(*) from #temp_Legals_Missing)

IF @Neo_Missing_Cnt > 0
BEGIN
 
	SET @Subject = @Server + ': Daily PET Report - NEO Legals Missing'

	Set @TableFooter = '</table></body></html>';
	Set @TableHeader = '<html><head>' +
					  '<style>' +
					  'td {padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;font-family: Arial, Helvetica, sans-serif; font-size: 10pt;} ' +
					  '</style>' +
					  '</head>' +
					  '<body><table cellpadding="5" cellspacing="0" border="1" bordercolor="#000000" style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; border-collapse:collapse;border-bottom-style:solid black;">' +
					  '<tr bgcolor=#FFEFD8>
					   <td align=center style="background-color: #359AFF; color: black"><b>Fips</b></td>';
	Select @BodyContent = (
	SELECT   FIPS	As [TD]
	FROM #temp_Legals_Missing
		order by fips
			  For XML raw('tr'), Elements)
	
	Set @BodyContent = Replace(@BodyContent, '_x0020_', space(1))
	Set @BodyContent = Replace(@BodyContent, '_x003D_', '=')
	Set @BodyContent = Replace(@BodyContent, '<tr><ALTCOLOR>1</ALTCOLOR>', '<tr bgcolor=#DFFFDF>')
	Set @BodyContent = Replace(@BodyContent, '<ALTCOLOR>0</ALTCOLOR>', '')


	Select @BodyContent = @TableHeader + @BodyContent + @TableFooter

	exec  msdb.dbo.sp_send_dbmail
	   @recipients				= @Email_To
	   ,@copy_recipients		= @Email_Cc
	   ,@blind_copy_recipients	= @Email_Bcc
	   ,@subject				= @Subject
	   ,@body					= @BodyContent
	   ,@body_format			= @Format
END

