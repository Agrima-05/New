/* Source: DWS-ETL02.DATATREE.LOCAL | EPR_VDB_TORTEE | dbo.LoadNewTorteeData_v6 | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

/* =================================================================================================
	Author:			?
	Create date:	08/14/2020
	Description:	This procedure will load the data from the tortee text files that are loaded in the
					xxx_table for processing 
					(xxx = Document, Name, Property and Reference)

	CHANGE LOG:    
	==========    
	WHO		DATE		CHANGE  
	+-------+-----------+---------------------------------------------------------------------------
	Henk	01/23/2025	Added recording document page count column
						Change logic to update page count if the record already exists
	Henk	05/15/2025	Add check on recording year
	Henk	08/25/2025	Change CountyCodes to synchronized table on EPR_VDB_TORTEE ftom VerifiedRecord
	Henk	09/05/2025	Add Legal_Desc_District to property table
	Henk	11/19/2025	Add Easement, Property_Type, Air_Rights, Subterranean_Rights, Street_Number, 
						Street_Name, Addr_Unit to property table
	Henk	03/10/2026	Clean up and add alt_cmt_id and alt_cmt_docnumber
	Henk	03/17/2026	Fix where clause with checks on NULL
	Henk	05/07/2026	Use computed hash lookups
	Henk	05/15/2026	Purge rows with invalid FIPS_Code (len <> 5) before staging;
					    caused by embedded CRLF in Legal_Desc_Tax_Assessor_Lot /
					    Legal_Desc_Extended splitting property rows in the SSIS flat
					    file parser
	Henk	05/21/2026	Create v6; use runtime-normalised NAME dedupe hash without changing
					    replicated persisted computed columns
==================================================================================================== */
CREATE   PROCEDURE [EPR_VDB_TORTEE].[dbo].[LoadNewTorteeData_v6]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Now DATETIME2(3) = SYSDATETIME();
    DECLARE @CurrentYear INT = YEAR(@Now);
    DECLARE @AppLockResult INT;

    EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info', N'LoadNewTorteeData_v6', N'Started';

    BEGIN TRY
        EXEC @AppLockResult = sys.sp_getapplock
            @Resource = N'EPR_VDB_Tortee.dbo.LoadNewTorteeData_v6',
            @LockMode = N'Exclusive',
            @LockOwner = N'Session',
            @LockTimeout = 0;

        IF @AppLockResult < 0
        BEGIN
            ;THROW 51000, 'LoadNewTorteeData_v6 is already running in another session.', 1;
        END;

        /*IF OBJECT_ID('tempdb..#DocumentStage') IS NOT NULL */
DROP TABLE IF EXISTS #DocumentStage;
        /*IF OBJECT_ID('tempdb..#PropertyStage') IS NOT NULL */
DROP TABLE IF EXISTS #PropertyStage;
        /*IF OBJECT_ID('tempdb..#NameStage') IS NOT NULL */
DROP TABLE IF EXISTS #NameStage;
        /*IF OBJECT_ID('tempdb..#ReferenceStage') IS NOT NULL */
DROP TABLE IF EXISTS #ReferenceStage;
        /*IF OBJECT_ID('tempdb..#DocumentInserted') IS NOT NULL */
DROP TABLE IF EXISTS #DocumentInserted;
        /*IF OBJECT_ID('tempdb..#PropertyInserted') IS NOT NULL */
DROP TABLE IF EXISTS #PropertyInserted;
        /*IF OBJECT_ID('tempdb..#NameInserted') IS NOT NULL */
DROP TABLE IF EXISTS #NameInserted;
        /*IF OBJECT_ID('tempdb..#ReferenceInserted') IS NOT NULL */
DROP TABLE IF EXISTS #ReferenceInserted;

        /* ============================================================
           Normalise all varchar columns before staging.

           The new hash calculation (v14) replaces CHAR(9) tab,
           CHAR(10) LF, CHAR(13) CR and CHAR(160) NBSP with a plain
           space before trimming.  We apply exactly the same
           normalisation to the raw column values here so that the
           stored data and the hash are always consistent.

           Root cause of bad FIPS_Code rows: the SSIS flat file
           parsers use CRLF as the row delimiter.  When a free-form
           text column (Legal_Desc_Tax_Assessor_Lot / Legal_Desc_Extended)
           contains an unquoted embedded CRLF, the parser splits the
           row early and the remainder lands in the next row's
           FIPS_Code.  After normalising, such a FIPS_Code will no
           longer be exactly 5 digits and is removed by the DELETEs
           below.
           ============================================================ */

        /* Helper macro (comment only):
           clean(col) =
             LTRIM(RTRIM(
               REPLACE(REPLACE(REPLACE(REPLACE(
                 ISNULL(col, ''),
                 CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' ')
             ))                                                              */

        /* ---- Document_table ------------------------------------------ */
        UPDATE [EPR_VDB_TORTEE].[dbo].[Document_table]
        SET
            FIPS_Code                       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(FIPS_Code,''),                       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_docnumber                   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_docnumber,''),                   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_id                          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_id,''),                          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_docnumber               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_docnumber,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_id                      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_id,''),                      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            COUNTY_recording_book           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(COUNTY_recording_book,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            COUNTY_recording_page           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(COUNTY_recording_page,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            COUNTY_document_number          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(COUNTY_document_number,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Year                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Year,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Doc_Number            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Doc_Number,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Doc_Number_Alternate  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Doc_Number_Alternate,''),  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Book                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Book,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Page                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Page,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Date                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Date,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Time                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Time,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Filing_Date                 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Filing_Date,''),                 CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Type                        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Type,''),                        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Title                       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Title,''),                       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Recording_Fee_1                 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Recording_Fee_1,''),                 CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Loan_Financed_Amount            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Loan_Financed_Amount,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Transfer_Sale_Purchase_Price    = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Transfer_Sale_Purchase_Price,''),    CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Case_Number                     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Case_Number,''),                     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Ordinance_Number                = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Ordinance_Number,''),                CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Resolution_Number               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Resolution_Number,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Tax_Account_Serial_Warrant_Number = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Tax_Account_Serial_Warrant_Number,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Water_Rights_Number             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Water_Rights_Number,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Remarks                         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Remarks,''),                         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_To_Name_Identifier       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_To_Name_Identifier,''),       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_To_Last_Company_Name     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_To_Last_Company_Name,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_To_First_Name            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_To_First_Name,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_To_Suffix                = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_To_Suffix,''),                CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_to_Address               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_to_Address,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_to_City                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_to_City,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_to_State                 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_to_State,''),                 CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_to_Zip                   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_to_Zip,''),                   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Return_to_Middle_Name           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Return_to_Middle_Name,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Transfer_Tax_county             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Transfer_Tax_county,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            MERS_Flag                       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(MERS_Flag,''),                       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Date                        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Date,''),                        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Amount_Due                      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Amount_Due,''),                      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Transfer_Tax                    = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Transfer_Tax,''),                    CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Transfer_Tax_State              = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Transfer_Tax_State,''),              CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Transfer_Tax_City               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Transfer_Tax_City,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' ')))
        WHERE m_status_id IS NULL;

        /* ---- Name_table ---------------------------------------------- */
        UPDATE [EPR_VDB_TORTEE].[dbo].[Name_table]
        SET
            FIPS_Code           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(FIPS_Code,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_docnumber       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_docnumber,''),       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_id              = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_id,''),              CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_docnumber   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_docnumber,''),   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_id          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_id,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Type            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Type,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            COUNTY_party_name   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(COUNTY_party_name,''),   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Role_Type           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Role_Type,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Sequence_Number     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Sequence_Number,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Name_Identifier     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Name_Identifier,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Last_Company_Name   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Last_Company_Name,''),   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            First_Name          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(First_Name,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Middle_Name         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Middle_Name,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Suffix              = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Suffix,''),              CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Name_Code           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Name_Code,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' ')))
        WHERE m_status_id IS NULL;

        /* ---- Property_table ------------------------------------------ */
        UPDATE [EPR_VDB_TORTEE].[dbo].[Property_table]
        SET
            FIPS_Code                       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(FIPS_Code,''),                       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_docnumber                   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_docnumber,''),                   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_id                          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_id,''),                          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_docnumber               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_docnumber,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_id                      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_id,''),                      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Type                        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Type,''),                        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Sequence_Number                 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Sequence_Number,''),                 CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Plat_Name        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Plat_Name,''),        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Block            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Block,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Lot_low          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Lot_low,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Plat_Type_Indicator = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Plat_Type_Indicator,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Plat_Book        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Plat_Book,''),        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Plat_Page        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Plat_Page,''),        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Plat_Number      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Plat_Number,''),      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Portion          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Portion,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Portion          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Portion,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Quarter          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Quarter,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Range            = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Range,''),            CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Section          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Section,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Township         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Township,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_APN                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_APN,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Address              = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Address,''),              CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Address_City         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Address_City,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Address_State        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Address_State,''),        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Address_Zip          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Address_Zip,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Abstract_Acreage     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Abstract_Acreage,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Abstract_Name        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Abstract_Name,''),        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Abstract_Number      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Abstract_Number,''),      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Abstract_Portion     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Abstract_Portion,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Lot_High         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Lot_High,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Map_Unit_low         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Map_Unit_low,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_STR_Government_Lot   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_STR_Government_Lot,''),   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Tax_Assessor_Block   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Tax_Assessor_Block,''),   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Tax_Assessor_Lot     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Tax_Assessor_Lot,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_APN_Portion          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_APN_Portion,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_Extended             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_Extended,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Legal_Desc_District             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Legal_Desc_District,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Easement                        = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Easement,''),                        CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Property_Type                   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Property_Type,''),                   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Air_Rights                      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Air_Rights,''),                      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Subterranean_Rights             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Subterranean_Rights,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Street_Number                   = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Street_Number,''),                   CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Street_Name                     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Street_Name,''),                     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Addr_Unit                       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Addr_Unit,''),                       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            legal_type                      = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(legal_type,''),                      CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            legal_type_sequence             = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(legal_type_sequence,''),             CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' ')))
        WHERE m_status_id IS NULL;

        /* ---- Reference_table ----------------------------------------- */
        UPDATE [EPR_VDB_TORTEE].[dbo].[Reference_table]
        SET
            FIPS_Code               = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(FIPS_Code,''),               CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_docnumber           = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_docnumber,''),           CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_id                  = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_id,''),                  CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_docnumber       = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_docnumber,''),       CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            alt_cmt_id              = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(alt_cmt_id,''),              CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Doc_Type                = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Doc_Type,''),                CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Sequence_Number         = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Sequence_Number,''),         CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Reference_Book          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Reference_Book,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Reference_Page          = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Reference_Page,''),          CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Reference_Recording_Year = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Reference_Recording_Year,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Reference_Recording_Date = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Reference_Recording_Date,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            Reference_Doc_Number    = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(Reference_Doc_Number,''),    CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            CMT_reference_doc_number = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CMT_reference_doc_number,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            cmt_Reference_Book_Page = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(cmt_Reference_Book_Page,''), CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' '))),
            reference_type_code     = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(reference_type_code,''),     CHAR(9),' '),CHAR(10),' '),CHAR(13),' '),CHAR(160),' ')))
        WHERE m_status_id IS NULL;

        /* ---- Delete rows whose FIPS_Code is still not exactly 5 chars - */
        DELETE FROM [EPR_VDB_TORTEE].[dbo].[Document_table]
        WHERE LEN(ISNULL(fips_code, '')) <> 5;

        DELETE FROM [EPR_VDB_TORTEE].[dbo].[Property_table]
        WHERE LEN(ISNULL(fips_code, '')) <> 5;

        DELETE FROM [EPR_VDB_TORTEE].[dbo].[Name_table]
        WHERE LEN(ISNULL(fips_code, '')) <> 5;

        DELETE FROM [EPR_VDB_TORTEE].[dbo].[Reference_table]
        WHERE LEN(ISNULL(fips_code, '')) <> 5;

        /* ============================================================
           Stage: DOCUMENT
           ============================================================ */
        -- Columns are already trimmed and control-char-free from the UPDATE above.
        -- Only type conversion, NULLIF(''->'NULL'), LEFT truncation and date
        -- reformatting are needed here.
        SELECT
            t.doc_id,
            t.doc_hash,
            t.row_hash,
            fips_code_n                      = ISNULL(TRY_CONVERT(INT, NULLIF(t.fips_code, '')), 0),
            cmt_docnumber_n                  = NULLIF(t.cmt_docnumber, ''),
            cmt_id_n                         = ISNULL(TRY_CONVERT(INT, NULLIF(t.cmt_id, '')), 0),
            doc_type_n                       = NULLIF(t.doc_type, ''),
            alt_cmt_docnumber_n              = NULLIF(t.alt_cmt_docnumber, ''),
            alt_cmt_id_n                     = ISNULL(TRY_CONVERT(INT, NULLIF(t.alt_cmt_id, '')), 0),

            recording_date_n =
                CASE
                    WHEN LEN(t.recording_date) >= 8
                        THEN SUBSTRING(t.recording_date, 5, 4) + SUBSTRING(t.recording_date, 1, 4)
                    ELSE NULL
                END,

            recording_time_n                 = TRY_CAST(NULLIF(t.recording_time, '') AS VARCHAR(200)),
            recording_book_n                 = LEFT(t.recording_book, 200),
            recording_page_n                 = LEFT(t.recording_page, 200),

            recording_year_n =
                CASE
                    WHEN PATINDEX('%[^0-9]%', LEFT(t.recording_year, 200)) = 0
                     AND TRY_CONVERT(INT, LEFT(t.recording_year, 200)) BETWEEN 1900 AND @CurrentYear
                        THEN LEFT(t.recording_year, 200)
                    WHEN ISDATE(SUBSTRING(t.recording_date, 5, 4) + SUBSTRING(t.recording_date, 1, 4)) = 1
                        THEN SUBSTRING(t.recording_date, 1, 4)
                    ELSE NULL
                END,

            recording_doc_number_n           = LEFT(t.recording_doc_number, 200),
            recording_doc_number_alternate_n = LEFT(t.recording_doc_number_alternate, 200),
            doc_title_n                      = LEFT(t.doc_title, 200),
            doc_date_n =
                CASE
                    WHEN LEN(t.doc_date) >= 8
                        THEN SUBSTRING(t.doc_date, 5, 4) + SUBSTRING(t.doc_date, 1, 4)
                    ELSE NULL
                END,
            doc_filing_date_n                = LEFT(t.doc_filing_date, 200),
            case_number_n                    = LEFT(t.case_number, 200),
            ordinance_number_n               = LEFT(t.ordinance_number, 200),
            resolution_number_n              = LEFT(t.resolution_number, 200),
            tax_account_serial_warrant_number_n = LEFT(t.tax_account_serial_warrant_number, 200),
            water_rights_number_n            = LEFT(t.water_rights_number, 200),

            loan_financed_amount_n           = TRY_CAST(NULLIF(REPLACE(REPLACE(t.loan_financed_amount, ' ', ''), ',', ''), '') AS DECIMAL(15,2)),
            recording_fee_1_n                = TRY_CAST(NULLIF(REPLACE(REPLACE(t.recording_fee_1,      ' ', ''), ',', ''), '') AS DECIMAL(15,2)),
            transfer_sale_purchase_price_n   = TRY_CAST(NULLIF(REPLACE(REPLACE(t.transfer_sale_purchase_price, ' ', ''), ',', ''), '') AS DECIMAL(15,2)),

            remarks_n                        = NULLIF(t.remarks, ''),
            Return_To_Name_Identifier_n      = LEFT(t.Return_To_Name_Identifier, 200),
            Return_To_Last_Company_Name_n    = LEFT(t.Return_To_Last_Company_Name, 200),
            Return_To_First_Name_n           = LEFT(t.Return_To_First_Name, 200),
            Return_To_Suffix_n               = LEFT(t.Return_To_Suffix, 200),
            Return_to_Address_n              = LEFT(t.Return_to_Address, 200),
            Return_to_City_n                 = LEFT(t.Return_to_City, 200),
            Return_to_State_n                = LEFT(t.Return_to_State, 200),
            Return_to_Zip_n                  = LEFT(t.Return_to_Zip, 200),
            Return_to_Middle_Name_n          = LEFT(t.Return_to_Middle_Name, 200),
            Transfer_Tax_county_n            = LEFT(t.Transfer_Tax_county, 200),
            MERS_Flag_n                      = LEFT(t.MERS_Flag, 200),

            Amount_Due_n                     = TRY_CAST(NULLIF(REPLACE(REPLACE(t.Amount_Due,           ' ', ''), ',', ''), '') AS DECIMAL(15,2)),
            Transfer_Tax_n                   = TRY_CAST(NULLIF(REPLACE(REPLACE(t.Transfer_Tax,         ' ', ''), ',', ''), '') AS DECIMAL(15,2)),
            Transfer_Tax_State_n             = TRY_CAST(NULLIF(REPLACE(REPLACE(t.Transfer_Tax_State,   ' ', ''), ',', ''), '') AS DECIMAL(15,2)),
            Transfer_Tax_City_n              = TRY_CAST(NULLIF(REPLACE(REPLACE(t.Transfer_Tax_City,    ' ', ''), ',', ''), '') AS DECIMAL(15,2)),

            recording_page_count_n           = t.recording_page_count
        INTO #DocumentStage
        FROM [EPR_VDB_TORTEE].[dbo].[Document_table] t
        WHERE t.m_status_id IS NULL
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        CREATE CLUSTERED INDEX CX_DocumentStage
        ON #DocumentStage
        (
            fips_code_n,
            cmt_docnumber_n,
            cmt_id_n,
            doc_type_n,
            alt_cmt_docnumber_n,
            alt_cmt_id_n,
            doc_id
        );

        CREATE NONCLUSTERED INDEX IX_DocumentStage_RowHash
        ON #DocumentStage(row_hash);

        /* ============================================================
           Stage: PROPERTY
           ============================================================ */
        SELECT
            p.Id,
            p.doc_hash,
            p.row_hash,
            fips_code_n                         = ISNULL(TRY_CONVERT(INT, NULLIF(p.fips_code, '')), 0),
            cmt_docnumber_n                     = NULLIF(p.cmt_docnumber, ''),
            cmt_id_n                            = ISNULL(TRY_CONVERT(INT, NULLIF(p.cmt_id, '')), 0),
            doc_type_n                          = NULLIF(p.doc_type, ''),
            alt_cmt_docnumber_n                 = NULLIF(p.alt_cmt_docnumber, ''),
            alt_cmt_id_n                        = ISNULL(TRY_CONVERT(INT, NULLIF(p.alt_cmt_id, '')), 0),

            p.Sequence_Number,
            legal_desc_abstract_portion_n       = LEFT(p.legal_desc_abstract_portion, 200),
            legal_desc_abstract_acreage_n       = LEFT(p.legal_desc_abstract_acreage, 200),
            legal_desc_abstract_name_n          = LEFT(p.legal_desc_abstract_name, 200),
            legal_desc_abstract_number_n        = LEFT(p.legal_desc_abstract_number, 200),
            legal_desc_address_n                = LEFT(p.legal_desc_address, 200),
            legal_desc_address_city_n           = LEFT(p.legal_desc_address_city, 200),
            legal_desc_address_state_n          = LEFT(p.legal_desc_address_state, 200),
            legal_desc_address_zip_n            = LEFT(p.legal_desc_address_zip, 200),
            legal_desc_apn_n                    = LEFT(p.legal_desc_apn, 200),
            legal_desc_map_portion_n            = LEFT(p.legal_desc_map_portion, 200),
            legal_desc_map_lot_low_n            = LEFT(p.legal_desc_map_lot_low, 200),
            legal_desc_map_block_n              = LEFT(p.legal_desc_map_block, 200),
            legal_desc_map_plat_name_n          = LEFT(p.legal_desc_map_plat_name, 200),
            legal_desc_map_plat_number_n        = LEFT(p.legal_desc_map_plat_number, 200),
            legal_desc_map_plat_type_indicator_n = LEFT(p.legal_desc_map_plat_type_indicator, 200),
            legal_desc_map_plat_book_n          = LEFT(p.legal_desc_map_plat_book, 200),
            legal_desc_map_plat_page_n          = LEFT(p.legal_desc_map_plat_page, 200),
            legal_desc_str_portion_n            = LEFT(p.legal_desc_str_portion, 200),
            legal_desc_str_quarter_n            = LEFT(p.legal_desc_str_quarter, 200),
            legal_desc_str_section_n            = LEFT(p.legal_desc_str_section, 200),
            legal_desc_str_township_n           = LEFT(p.legal_desc_str_township, 200),
            legal_desc_str_range_n              = LEFT(p.legal_desc_str_range, 200),
            Legal_Desc_Map_Lot_High_n           = LEFT(p.Legal_Desc_Map_Lot_High, 200),
            Legal_Desc_Map_Unit_low_n           = LEFT(p.Legal_Desc_Map_Unit_low, 200),
            Legal_Desc_STR_Government_Lot_n     = LEFT(p.Legal_Desc_STR_Government_Lot, 200),
            Legal_Desc_Tax_Assessor_Block_n     = LEFT(p.Legal_Desc_Tax_Assessor_Block, 200),
            Legal_Desc_Tax_Assessor_Lot_n       = LEFT(p.Legal_Desc_Tax_Assessor_Lot, 200),
            Legal_Desc_APN_Portion_n            = LEFT(p.Legal_Desc_APN_Portion, 200),
            Legal_Desc_District_n               = NULLIF(p.Legal_Desc_District, ''),
            Easement_n                          = NULLIF(p.Easement, ''),
            Property_Type_n                     = NULLIF(p.Property_Type, ''),
            Air_Rights_n                        = NULLIF(p.Air_Rights, ''),
            Subterranean_Rights_n               = NULLIF(p.Subterranean_Rights, ''),
            Street_Number_n                     = NULLIF(p.Street_Number, ''),
            Street_Name_n                       = NULLIF(p.Street_Name, ''),
            Addr_Unit_n                         = NULLIF(p.Addr_Unit, '')
        INTO #PropertyStage
        FROM [EPR_VDB_TORTEE].[dbo].[Property_table] p
        WHERE p.m_status_id IS NULL
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        CREATE CLUSTERED INDEX CX_PropertyStage
        ON #PropertyStage
        (
            fips_code_n,
            cmt_docnumber_n,
            cmt_id_n,
            doc_type_n,
            alt_cmt_docnumber_n,
            alt_cmt_id_n,
            Id
        );

        CREATE NONCLUSTERED INDEX IX_PropertyStage_Hashes
        ON #PropertyStage(doc_hash, row_hash);

        /* ============================================================
           Stage: NAME
           ============================================================ */
        SELECT
            n.Id,
            n.doc_hash,
            -- Runtime-normalised hash matches the NAME duplicate cleanup query.
            row_hash = CONVERT(BINARY(32), HASHBYTES('SHA2_256', CAST(CONCAT(
                RIGHT('00000' + ISNULL(LTRIM(RTRIM(CONVERT(VARCHAR(50), n.[FIPS_Code]))), ''), 5),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), n.[cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), n.[alt_cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(250), n.[Doc_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), n.[COUNTY_party_name]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), n.[Role_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), n.[Name_Identifier]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), n.[Name_Code]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '))
            ) AS VARCHAR(MAX)))),
            fips_code_n         = ISNULL(TRY_CONVERT(INT, NULLIF(n.fips_code, '')), 0),
            cmt_docnumber_n     = NULLIF(n.cmt_docnumber, ''),
            cmt_id_n            = ISNULL(TRY_CONVERT(INT, NULLIF(n.cmt_id, '')), 0),
            doc_type_n          = NULLIF(n.doc_type, ''),
            alt_cmt_docnumber_n = NULLIF(n.alt_cmt_docnumber, ''),
            alt_cmt_id_n        = ISNULL(TRY_CONVERT(INT, NULLIF(n.alt_cmt_id, '')), 0),

            sequence_number_n   = LEFT(n.sequence_number, 200),
            name_identifier_n   = LEFT(n.name_identifier, 1),
            name_code_n         = LEFT(n.name_code, 200),
            role_type_n         = LEFT(n.role_type, 200),
            COUNTY_party_name_n = LEFT(n.COUNTY_party_name, 300),
            last_company_name_n = LEFT(n.last_company_name, 200),
            first_name_n        = LEFT(n.first_name, 200),
            middle_name_n       = LEFT(n.middle_name, 200),
            suffix_n            = LEFT(n.suffix, 200)
        INTO #NameStage
        FROM [EPR_VDB_TORTEE].[dbo].[Name_table] n
        WHERE n.m_status_id IS NULL
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        CREATE CLUSTERED INDEX CX_NameStage
        ON #NameStage
        (
            fips_code_n,
            cmt_docnumber_n,
            cmt_id_n,
            doc_type_n,
            alt_cmt_docnumber_n,
            alt_cmt_id_n,
            Id
        );

        CREATE NONCLUSTERED INDEX IX_NameStage_Hashes
        ON #NameStage(doc_hash, row_hash);

        /* ============================================================
           Stage: REFERENCE
           ============================================================ */
        SELECT
            r.Id,
            r.doc_hash,
            r.row_hash,
            fips_code_n                = ISNULL(TRY_CONVERT(INT, NULLIF(r.fips_code, '')), 0),
            cmt_docnumber_n            = NULLIF(r.cmt_docnumber, ''),
            cmt_id_n                   = ISNULL(TRY_CONVERT(INT, NULLIF(r.cmt_id, '')), 0),
            doc_type_n                 = NULLIF(r.doc_type, ''),
            alt_cmt_docnumber_n        = NULLIF(r.alt_cmt_docnumber, ''),
            alt_cmt_id_n               = ISNULL(TRY_CONVERT(INT, NULLIF(r.alt_cmt_id, '')), 0),

            reference_book_n           = LEFT(r.reference_book, 200),
            reference_page_n           = LEFT(r.reference_page, 200),
            reference_recording_year_n = LEFT(r.reference_recording_year, 200),
            reference_doc_number_n     = LEFT(r.reference_doc_number, 200),
            reference_recording_date_n = LEFT(r.reference_recording_date, 200),
            CMT_reference_doc_number_n = LEFT(r.CMT_reference_doc_number, 200),
            cmt_Reference_Book_Page_n  = LEFT(r.cmt_Reference_Book_Page, 200)
        INTO #ReferenceStage
        FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] r
        WHERE r.m_status_id IS NULL
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        CREATE CLUSTERED INDEX CX_ReferenceStage
        ON #ReferenceStage
        (
            fips_code_n,
            cmt_docnumber_n,
            cmt_id_n,
            doc_type_n,
            alt_cmt_docnumber_n,
            alt_cmt_id_n,
            Id
        );

        CREATE NONCLUSTERED INDEX IX_ReferenceStage_Hashes
        ON #ReferenceStage(doc_hash, row_hash);

        CREATE TABLE #DocumentInserted
        (
            doc_id INT NOT NULL PRIMARY KEY,
            source_pk INT NOT NULL
        );

        CREATE TABLE #PropertyInserted
        (
            Id INT NOT NULL PRIMARY KEY,
            Doc_Id INT NOT NULL
        );

        CREATE TABLE #NameInserted
        (
            Id INT NOT NULL PRIMARY KEY,
            Doc_Id INT NOT NULL
        );

        CREATE TABLE #ReferenceInserted
        (
            Id INT NOT NULL PRIMARY KEY,
            Doc_Id INT NOT NULL
        );

        BEGIN TRANSACTION;

        /* ============================================================
           Insert DOCUMENT
           ============================================================ */
        INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT]
        (
            [doc_unique_id],
            [source_PK],
            [fips_code],
            [cmt_docnumber],
            [cmt_id],
            [source],
            [county],
            [state],
            [recording_date],
            [recording_time],
            [recording_book],
            [recording_page],
            [recording_year],
            [recording_doc_number],
            [recording_doc_number_alternate],
            [recording_doc_sequence_number],
            [doc_title],
            [doc_type],
            [doc_date],
            [doc_filing_date],
            [case_number],
            [ordinance_number],
            [resolution_number],
            [tax_account_serial_warrant_number],
            [water_rights_number],
            [loan_financed_amount],
            [recording_fee_1],
            [transfer_sale_purchase_price],
            [remarks],
            [alt_cmt_docnumber],
            [alt_cmt_id],
            [Return_To_Name_Identifier],
            [Return_To_Last_Company_Name],
            [Return_To_First_Name],
            [Return_To_Suffix],
            [Return_to_Address],
            [Return_to_City],
            [Return_to_State],
            [Return_to_Zip],
            [Return_to_Middle_Name],
            [Transfer_Tax_county],
            [MERS_Flag],
            [m_status_id],
            [m_create_date],
            [Amount_Due],
            [Transfer_Tax],
            [Transfer_Tax_State],
            [Transfer_Tax_City],
            [recording_page_count]
        )
        OUTPUT inserted.doc_id, inserted.source_PK
        INTO #DocumentInserted(doc_id, source_pk)
        SELECT
            NULL,
            s.doc_id,
            s.fips_code_n,
            s.cmt_docnumber_n,
            s.cmt_id_n,
            'FAI',
            LEFT(COALESCE(c.CountyName, ''), 200),
            LEFT(COALESCE(c.[State], ''), 200),
            s.recording_date_n,
            s.recording_time_n,
            s.recording_book_n,
            s.recording_page_n,
            s.recording_year_n,
            s.recording_doc_number_n,
            s.recording_doc_number_alternate_n,
            '1',
            s.doc_title_n,
            LEFT(COALESCE(s.doc_type_n, ''), 250),
            s.doc_date_n,
            s.doc_filing_date_n,
            s.case_number_n,
            s.ordinance_number_n,
            s.resolution_number_n,
            s.tax_account_serial_warrant_number_n,
            s.water_rights_number_n,
            s.loan_financed_amount_n,
            s.recording_fee_1_n,
            s.transfer_sale_purchase_price_n,
            s.remarks_n,
            s.alt_cmt_docnumber_n,
            s.alt_cmt_id_n,
            s.Return_To_Name_Identifier_n,
            s.Return_To_Last_Company_Name_n,
            s.Return_To_First_Name_n,
            s.Return_To_Suffix_n,
            s.Return_to_Address_n,
            s.Return_to_City_n,
            s.Return_to_State_n,
            s.Return_to_Zip_n,
            s.Return_to_Middle_Name_n,
            s.Transfer_Tax_county_n,
            s.MERS_Flag_n,
            1,
            @Now,
            s.Amount_Due_n,
            s.Transfer_Tax_n,
            s.Transfer_Tax_State_n,
            s.Transfer_Tax_City_n,
            s.recording_page_count_n
        FROM #DocumentStage s
        LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c
            ON c.Fips_Code = s.fips_code_n
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d WITH (UPDLOCK, HOLDLOCK)
            WHERE d.row_hash = s.row_hash
        )
          AND NOT EXISTS
        (
            SELECT 1
            FROM #DocumentStage prior
            WHERE prior.row_hash = s.row_hash
              AND prior.doc_id < s.doc_id
        )
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        /* ============================================================
           Update page count for existing docs
           ============================================================ */
        UPDATE [EPR_VDB_TORTEE].[dbo].[d]
           SET d.recording_page_count = s.recording_page_count_n
        FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
        JOIN #DocumentStage s
          ON d.row_hash = s.row_hash
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM #DocumentInserted i
            WHERE i.source_pk = s.doc_id
        )
          AND ISNULL(d.recording_page_count, 0) = 0
          AND ISNULL(s.recording_page_count_n, 0) > 0;

        /* ============================================================
           Insert PROPERTY
           ============================================================ */
        INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[PROPERTY]
        (
            [doc_id],
            [FIPS],
            [State],
            [County],
            [SSCC],
            [doc_unique_id],
            [cmt_docnumber],
            [cmt_id],
            [alt_cmt_docnumber],
            [alt_cmt_id],
            [doc_type],
            [property_id_sequence_number],
            [legal_type],
            [legal_type_sequence],
            [legal_desc_abstract_portion],
            [legal_desc_abstract_acreage],
            [legal_desc_abstract_name],
            [legal_desc_abstract_number],
            [legal_desc_address],
            [legal_desc_address_city],
            [legal_desc_address_state],
            [legal_desc_address_zip],
            [legal_desc_apn],
            [legal_desc_map_portion],
            [legal_desc_map_lot_low],
            [legal_desc_map_block],
            [legal_desc_map_plat_name],
            [legal_desc_map_plat_number],
            [legal_desc_map_plat_type_indicator],
            [legal_desc_map_plat_book],
            [legal_desc_map_plat_page],
            [legal_desc_str_portion],
            [legal_desc_str_quarter],
            [legal_desc_str_section],
            [legal_desc_str_township],
            [legal_desc_str_range],
            [property_sequence],
            [Legal_Desc_Map_Lot_High],
            [Legal_Desc_Map_Unit_low],
            [Legal_Desc_STR_Government_Lot],
            [m_status_id],
            [m_create_date],
            [Legal_Desc_Tax_Assessor_Block],
            [Legal_Desc_Tax_Assessor_Lot],
            [Legal_Desc_APN_Portion],
            [Source_PK],
            [Legal_Desc_District],
            [Easement],
            [Property_Type],
            [Air_Rights],
            [Subterranean_Rights],
            [Street_Number],
            [Street_Name],
            [Addr_Unit]
        )
        OUTPUT inserted.Source_PK, inserted.doc_id
        INTO #PropertyInserted(Id, Doc_Id)
        SELECT
            d.doc_id,
            RIGHT('00000' + CONVERT(VARCHAR(5), d.fips_code), 5),
            c.[State],
            c.CountyName,
            c.SSCC,
            NULL,
            p.cmt_docnumber_n,
            p.cmt_id_n,
            p.alt_cmt_docnumber_n,
            p.alt_cmt_id_n,
            LEFT(COALESCE(p.doc_type_n, ''), 250),
            p.Sequence_Number,
            NULL,
            NULL,
            p.legal_desc_abstract_portion_n,
            p.legal_desc_abstract_acreage_n,
            p.legal_desc_abstract_name_n,
            p.legal_desc_abstract_number_n,
            p.legal_desc_address_n,
            p.legal_desc_address_city_n,
            p.legal_desc_address_state_n,
            p.legal_desc_address_zip_n,
            p.legal_desc_apn_n,
            p.legal_desc_map_portion_n,
            p.legal_desc_map_lot_low_n,
            p.legal_desc_map_block_n,
            p.legal_desc_map_plat_name_n,
            p.legal_desc_map_plat_number_n,
            p.legal_desc_map_plat_type_indicator_n,
            p.legal_desc_map_plat_book_n,
            p.legal_desc_map_plat_page_n,
            p.legal_desc_str_portion_n,
            p.legal_desc_str_quarter_n,
            p.legal_desc_str_section_n,
            p.legal_desc_str_township_n,
            p.legal_desc_str_range_n,
            NULL,
            p.Legal_Desc_Map_Lot_High_n,
            p.Legal_Desc_Map_Unit_low_n,
            p.Legal_Desc_STR_Government_Lot_n,
            1,
            @Now,
            p.Legal_Desc_Tax_Assessor_Block_n,
            p.Legal_Desc_Tax_Assessor_Lot_n,
            p.Legal_Desc_APN_Portion_n,
            p.Id,
            p.Legal_Desc_District_n,
            p.Easement_n,
            p.Property_Type_n,
            p.Air_Rights_n,
            p.Subterranean_Rights_n,
            p.Street_Number_n,
            p.Street_Name_n,
            p.Addr_Unit_n
        FROM #PropertyStage p
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = p.doc_hash
        LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c
          ON c.Fips_Code = d.fips_code
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[PROPERTY] pn WITH (UPDLOCK, HOLDLOCK)
            WHERE pn.row_hash = p.row_hash
        )
          AND NOT EXISTS
        (
            SELECT 1
            FROM #PropertyStage prior
            WHERE prior.row_hash = p.row_hash
              AND prior.Id < p.Id
        )
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        /* ============================================================
           Insert NAME
           ============================================================ */
        INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[NAME]
        (
            [doc_id],
            [FIPS],
            [State],
            [County],
            [SSCC],
            [cmt_docnumber],
            [cmt_id],
            [alt_cmt_docnumber],
            [alt_cmt_id],
            [doc_type],
            [doc_unique_id],
            [sequence_number],
            [name_identifier],
            [name_code],
            [role_type],
            [COUNTY_party_name],
            [last_company_name],
            [first_name],
            [middle_name],
            [suffix],
            [m_status_id],
            [m_create_date],
            [Source_PK]
        )
        OUTPUT inserted.Source_PK, inserted.doc_id
        INTO #NameInserted(Id, Doc_Id)
        SELECT
            d.doc_id,
            RIGHT('00000' + CONVERT(VARCHAR(5), d.fips_code), 5),
            c.[State],
            c.CountyName,
            c.SSCC,
            n.cmt_docnumber_n,
            n.cmt_id_n,
            n.alt_cmt_docnumber_n,
            n.alt_cmt_id_n,
            LEFT(COALESCE(n.doc_type_n, ''), 250),
            NULL,
            n.sequence_number_n,
            n.name_identifier_n,
            n.name_code_n,
            n.role_type_n,
            n.COUNTY_party_name_n,
            n.last_company_name_n,
            n.first_name_n,
            n.middle_name_n,
            n.suffix_n,
            1,
            @Now,
            n.Id
        FROM #NameStage n
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = n.doc_hash
        LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c
          ON c.Fips_Code = d.fips_code
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[NAME] pn WITH (UPDLOCK, HOLDLOCK)
            CROSS APPLY (VALUES (CONVERT(BINARY(32), HASHBYTES('SHA2_256', CAST(CONCAT(
                RIGHT('00000' + ISNULL(LTRIM(RTRIM(CONVERT(VARCHAR(50), pn.[FIPS]))), ''), 5),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), pn.[cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), pn.[alt_cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(250), pn.[Doc_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), pn.[COUNTY_party_name]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), pn.[Role_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), pn.[Name_Identifier]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), pn.[Name_Code]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '))
            ) AS VARCHAR(MAX)))))) AS h(row_hash)
            WHERE h.row_hash = n.row_hash
        )
          AND NOT EXISTS
        (
            SELECT 1
            FROM #NameStage prior
            WHERE prior.row_hash = n.row_hash
              AND prior.Id < n.Id
        )
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        /* ============================================================
           Insert REFERENCE
           ============================================================ */
        INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[REFERENCE]
        (
            [doc_id],
            [FIPS],
            [State],
            [County],
            [SSCC],
            [doc_unique_id],
            [cmt_docnumber],
            [cmt_id],
            [alt_cmt_docnumber],
            [alt_cmt_id],
            [doc_type],
            [reference_id_sequence_number],
            [reference_type_code],
            [reference_book],
            [reference_page],
            [reference_recording_year],
            [reference_doc_number],
            [reference_recording_date],
            [CMT_reference_doc_number],
            [cmt_Reference_Book_Page],
            [m_status_id],
            [m_create_date],
            [Source_PK]
        )
        OUTPUT inserted.Source_PK, inserted.doc_id
        INTO #ReferenceInserted(Id, Doc_Id)
        SELECT
            d.doc_id,
            RIGHT('00000' + CONVERT(VARCHAR(5), d.fips_code), 5),
            c.[State],
            c.CountyName,
            c.SSCC,
            NULL,
            r.cmt_docnumber_n,
            r.cmt_id_n,
            r.alt_cmt_docnumber_n,
            r.alt_cmt_id_n,
            LEFT(COALESCE(r.doc_type_n, ''), 250),
            NULL,
            NULL,
            r.reference_book_n,
            r.reference_page_n,
            r.reference_recording_year_n,
            r.reference_doc_number_n,
            r.reference_recording_date_n,
            r.CMT_reference_doc_number_n,
            r.cmt_Reference_Book_Page_n,
            1,
            @Now,
            r.Id
        FROM #ReferenceStage r
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = r.doc_hash
        LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c
          ON c.Fips_Code = d.fips_code
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[REFERENCE] pn WITH (UPDLOCK, HOLDLOCK)
            WHERE pn.row_hash = r.row_hash
        )
          AND NOT EXISTS
        (
            SELECT 1
            FROM #ReferenceStage prior
            WHERE prior.row_hash = r.row_hash
              AND prior.Id < r.Id
        )
        OPTION (RECOMPILE, MAXDOP 12, USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

        /* ============================================================
           Update source staging tables
           ============================================================ */
        UPDATE [EPR_VDB_TORTEE].[dbo].[s]
           SET s.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[dbo].[Document_table] s
        JOIN #DocumentStage ds
          ON s.doc_id = ds.doc_id;

        UPDATE [EPR_VDB_TORTEE].[dbo].[p]
           SET p.doc_id = d.source_PK,
               p.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[dbo].[Property_table] p
        JOIN #PropertyStage ps
          ON p.Id = ps.Id
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = ps.doc_hash;

        UPDATE [EPR_VDB_TORTEE].[dbo].[n]
           SET n.doc_id = d.source_PK,
               n.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[dbo].[Name_table] n
        JOIN #NameStage ns
          ON n.Id = ns.Id
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = ns.doc_hash;

        UPDATE [EPR_VDB_TORTEE].[dbo].[r]
           SET r.doc_id = d.source_PK,
               r.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] r
        JOIN #ReferenceStage rs
          ON r.Id = rs.Id
        JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
          ON d.doc_hash = rs.doc_hash;

        /* ============================================================
           Update target tables for this batch only
           ============================================================ */
        UPDATE [EPR_VDB_TORTEE].[dbo].[d]
           SET d.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
        JOIN #DocumentInserted i
          ON d.doc_id = i.doc_id
        WHERE d.m_status_id = 1;

        UPDATE [EPR_VDB_TORTEE].[dbo].[p]
           SET p.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[ur_tortee].[PROPERTY] p
        JOIN #PropertyInserted i
          ON p.Source_PK = i.Id
         AND p.doc_id = i.Doc_Id
        WHERE p.m_status_id = 1;

        UPDATE [EPR_VDB_TORTEE].[dbo].[n]
           SET n.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[ur_tortee].[NAME] n
        JOIN #NameInserted i
          ON n.Source_PK = i.Id
         AND n.doc_id = i.Doc_Id
        WHERE n.m_status_id = 1;

        UPDATE [EPR_VDB_TORTEE].[dbo].[r]
           SET r.m_status_id = 2
        FROM [EPR_VDB_TORTEE].[ur_tortee].[REFERENCE] r
        JOIN #ReferenceInserted i
          ON r.Source_PK = i.Id
         AND r.doc_id = i.Doc_Id
        WHERE r.m_status_id = 1;

        /* ============================================================
           Delete source rows that now exist in the * tables
           ============================================================ */
        DELETE s
        FROM [EPR_VDB_TORTEE].[dbo].[Document_table] s
        JOIN #DocumentStage ds
          ON s.doc_id = ds.doc_id
        WHERE EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d
            WHERE d.row_hash = ds.row_hash
        );

        DELETE p
        FROM [EPR_VDB_TORTEE].[dbo].[Property_table] p
        JOIN #PropertyStage ps
          ON p.Id = ps.Id
        WHERE EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[PROPERTY] pn
            WHERE pn.row_hash = ps.row_hash
        );

        DELETE n
        FROM [EPR_VDB_TORTEE].[dbo].[Name_table] n
        JOIN #NameStage ns
          ON n.Id = ns.Id
        WHERE EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[NAME] nn
            CROSS APPLY (VALUES (CONVERT(BINARY(32), HASHBYTES('SHA2_256', CAST(CONCAT(
                RIGHT('00000' + ISNULL(LTRIM(RTRIM(CONVERT(VARCHAR(50), nn.[FIPS]))), ''), 5),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), nn.[cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(200), nn.[alt_cmt_docnumber]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(250), nn.[Doc_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), nn.[COUNTY_party_name]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), nn.[Role_Type]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), nn.[Name_Identifier]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ')),
                '|',
                UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(VARCHAR(2000), nn.[Name_Code]), ''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), CHAR(160), ' '))), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' '))
            ) AS VARCHAR(MAX)))))) AS h(row_hash)
            WHERE h.row_hash = ns.row_hash
        );

        DELETE r
        FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] r
        JOIN #ReferenceStage rs
          ON r.Id = rs.Id
        WHERE EXISTS
        (
            SELECT 1
            FROM [EPR_VDB_TORTEE].[ur_tortee].[REFERENCE] rn
            WHERE rn.row_hash = rs.row_hash
        );

        COMMIT;

        DECLARE @cnt INT =
            (SELECT COUNT(1) FROM #DocumentInserted) +
            (SELECT COUNT(1) FROM #PropertyInserted) +
            (SELECT COUNT(1) FROM #NameInserted) +
            (SELECT COUNT(1) FROM #ReferenceInserted);

        DECLARE @msg VARCHAR(100) = 'Ended - document Loaded: ' + CAST(@cnt AS VARCHAR(20));

        EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info', N'LoadNewTorteeData_v6', @msg;

        IF @AppLockResult >= 0
            EXEC sys.sp_releaseapplock
                @Resource = N'EPR_VDB_Tortee.dbo.LoadNewTorteeData_v6',
                @LockOwner = N'Session';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        IF @AppLockResult >= 0
            EXEC sys.sp_releaseapplock
                @Resource = N'EPR_VDB_Tortee.dbo.LoadNewTorteeData_v6',
                @LockOwner = N'Session';

        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrProc NVARCHAR(200) = ERROR_PROCEDURE();
        DECLARE @ErrLine INT = ERROR_LINE();
        DECLARE @FMsg NVARCHAR(200) = N'Failed: ' + ISNULL(@ErrProc, N'') + N' line ' + CAST(@ErrLine AS NVARCHAR(20)) + N' - ' + @ErrMsg
        EXEC [SPDB].[EPRVDB].[AddTorteeLog]
            N'error',
            N'LoadNewTorteeData_v6',
            @FMsg;

        THROW;
    END CATCH
END

