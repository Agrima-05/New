/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_Update_Pet_Counties | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
CREATE PROCEDURE [PET].[dbo].[usp_Update_Pet_Counties] @ERROR VARCHAR(500) OUTPUT
AS
-- declare @ERROR VARCHAR(500) 
BEGIN TRY
	DECLARE @Fips INT = 99999

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Update_Pet_Counties'
		,N'Started'

	DECLARE @SQL VARCHAR(max)
	DECLARE @Server VARCHAR(50) = CASE 
			WHEN @@SERVERNAME = 'AZUVNSQLDTDB003'
				THEN '[AZUVNSQLDTLM011.DATATRACE.LOCAL]'
			ELSE '[DTRA-DTS-NEO04.DATATRACE.LOCAL]'
			END
	DECLARE @connection VARCHAR(50) = CASE 
			WHEN @Server = '[AZUVNSQLDTLM011.DATATRACE.LOCAL]'
				THEN 'Stage_SSIS_connection'
			ELSE 'Prod_SSIS_connection'
			END
	DECLARE @Neo_db_stage_prod VARCHAR(50) = CASE 
			WHEN @Server = '[AZUVNSQLDTLM011.DATATRACE.LOCAL]'
				THEN 'Neo_db_stage'
			ELSE 'Neo_db_Prod'
			END

	--select @connection
	--select @Server
	SET @SQL = 'UPDATE n
SET n.' + @connection + ' = s.[IP]
	,' + @Neo_db_stage_prod + ' = CASE 
		WHEN @@SERVERNAME = ''AZUVNSQLDTDB003''
			THEN Substring(s.[IP], 14,2)
		ELSE Substring(s.[IP], 13, 2)
		END
FROM PET.dbo.PET_Counties n
INNER JOIN ' + @Server + '.[DTConfiguration].[dbo].[NeoPartitions] a ON a.STATE = n.STATE
	
	AND a.County = substring(cast(n.Neo_counties AS VARCHAR(5)), 3, 2)
INNER JOIN ' + @Server + '.[DTConfiguration].[dbo].NeoSqlInstances s ON s.id = a.NeoSqlInstancesId
WHERE n.' + @connection + ' <> s.[IP]
and n.' + @connection + ' is not null

'

	--select  @SQL
	EXEC (@SQL)

	--
	-- sync configuration tables
	--
	--BEGIN TRANSACTION
	SET @SQL = cast(N'


begin transaction
TRUNCATE TABLE [PET].[dbo].[Dynamic_format]

INSERT INTO [PET].[dbo].[Dynamic_format] (
	[FeatureId]
	,[ServiceId]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[DataType]
	,[Enumeration]
	,[FromField]
	,[Label]
	,[LongDesc]
	,[OutputField]
	,[Partner]
	,[PartnerType]
	,[Required]
	,[TabIndex]
	,[WildStart]
	,[DataTreeIndexes]
	,[FormatChar]
	,[MsgLabel]
	)
SELECT [FeatureId]
	,[ServiceId]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[DataType]
	,[Enumeration]
	,[FromField]
	,[Label]
	,[LongDesc]
	,[OutputField]
	,[Partner]
	,[PartnerType]
	,[Required]
	,[TabIndex]
	,[WildStart]
	,[DataTreeIndexes]
	,[FormatChar]
	,[MsgLabel]
FROM ' + @Server + '.DTConfiguration.dbo.Dynamic_format

commit
' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	SET @SQL = cast(
			N'
begin transaction
TRUNCATE TABLE [PET].[dbo].[County]

INSERT INTO [PET].[dbo].[County] (
	[CountyFips]
	,[StateFips]
	,[DtCountyId]
	,[CountyName]
	,[System]
	,[CrossReferenceType]
	,[MergeOutPutReport]
	,[TitleByAPNType]
	,[XRefTaxToComp]
	,[XRefTaxToProperty]
	,[XRefTaxToTitle]
	,[XRefTitleToTax]
	,[FormatFoundersReference]
	,[FormatHoaCollector]
	,[FormatManualTaxRequest]
	,[FormatPropCharacteristics]
	,[FormatPropInformation]
	,[FormatSectional]
	,[FormatSubdivided]
	,[SearchEngine]
	,[DisplayReportSummary]
	,[LabelArb]
	,[LabelInstrumentAliasSep]
	,[LabelInstrumentSep]
	,[LabelOrderComment]
	,[LabelPriorArb]
	,[LabelRefInstrumentAliasSep]
	,[LabelRefInstrumentSep]
	,[LabelPlat]
	,[PlantInfoTitleThruTime]
	,[SupportCaseLookup]
	,[PlantInfoCorpUpdateDate]
	,[PlantInfoLPLLCUpdateDate]
	,[PlantInfoNotaryUpdateDate]
	,[LabelAPN]
	,[TaxAssessmentCurrencyFormat]
	,[TaxInstallmentCurrencyFormat]
	,[QuickSearchSource]
	,[LabelHeader]
	,[TaxProceduresSuffix]
	,[CustomLabelARB]
	,[PenaltyPercentage]
	,[InterestPercentage]
	,[CostFee]
	,[RedemptionFee]
	,[SoldToStateFee]
	,[TaxServiceType]
	,[TreasurerName]
	,[TreasurerAddress]
	,[TreasurerPhone]
	,[InexEnabled]
	)
SELECT [CountyFips]
	,[StateFips]
	,[DtCountyId]
	,[CountyName]
	,[System]
	,[CrossReferenceType]
	,[MergeOutPutReport]
	,[TitleByAPNType]
	,[XRefTaxToComp]
	,[XRefTaxToProperty]
	,[XRefTaxToTitle]
	,[XRefTitleToTax]
	,[FormatFoundersReference]
	,[FormatHoaCollector]
	,[FormatManualTaxRequest]
	,[FormatPropCharacteristics]
	,[FormatPropInformation]
	,[FormatSectional]
	,[FormatSubdivided]
	,[SearchEngine]
	,[DisplayReportSummary]
	,[LabelArb]
	,[LabelInstrumentAliasSep]
	,[LabelInstrumentSep]
	,[LabelOrderComment]
	,[LabelPriorArb]
	,[LabelRefInstrumentAliasSep]
	,[LabelRefInstrumentSep]
	,[LabelPlat]
	,[PlantInfoTitleThruTime]
	,[SupportCaseLookup]
	,[PlantInfoCorpUpdateDate]
	,[PlantInfoLPLLCUpdateDate]
	,[PlantInfoNotaryUpdateDate]
	,[LabelAPN]
	,[TaxAssessmentCurrencyFormat]
	,[TaxInstallmentCurrencyFormat]
	,[QuickSearchSource]
	,[LabelHeader]
	,[TaxProceduresSuffix]
	,[CustomLabelARB]
	,[PenaltyPercentage]
	,[InterestPercentage]
	,[CostFee]
	,[RedemptionFee]
	,[SoldToStateFee]
	,[TaxServiceType]
	,[TreasurerName]
	,[TreasurerAddress]
	,[TreasurerPhone]
	,[InexEnabled]
FROM ' 
			+ @Server + '.DTConfiguration.dbo.County
commit
' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	SET @SQL = cast(N'
begin transaction
TRUNCATE TABLE [PET].[dbo].[Feature]

INSERT INTO [PET].[dbo].[Feature] (
	[FeatureId]
	,[Name]
	,[Sorting]
	)
SELECT [FeatureId]
	,[Name]
	,[Sorting]
FROM ' + @Server + '.DTConfiguration.dbo.Feature
commit
' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	SET @SQL = cast(N'
begin transaction
TRUNCATE TABLE [PET].[dbo].[Service]

INSERT INTO [PET].[dbo].[Service] (
	[ServiceId]
	,[FeatureId]
	,[Name]
	,[FeatureAlias]
	,[ServiceNameSpace]
	,[Sorting]
	,[SearchEngineUrl]
	)
SELECT [ServiceId]
	,[FeatureId]
	,[Name]
	,[FeatureAlias]
	,[ServiceNameSpace]
	,[Sorting]
	,[SearchEngineUrl]
FROM ' + @Server + '.DTConfiguration.dbo.[Service]
commit
' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	SET @SQL = cast(
			N'
begin transaction
TRUNCATE TABLE [PET].[TR00].[PL_PLANT_PARAM]

INSERT INTO [PET].[TR00].[PL_PLANT_PARAM] (
	[PPLNT_ST]
	,[PPLNT_CTY]
	,[PPLNT_PLNT_FROM_DT]
	,[PPLNT_CRT_THRU_DT]
	,[PPLNT_THRU_FULL_DT]
	,[PPLNT_THRU_INST_DT]
	,[PPLNT_THRU_INST_TM]
	,[PPLNT_THRU_INST]
	,[PPLNT_PLAT_ID_FRMT]
	,[PPLNT_SEC_HLF_SUPP]
	,[PPLNT_GOVT_LT_SUPP]
	,[PPLNT_SEC_ARB_SUPP]
	,[PPLNT_NKNM_SUPP]
	,[PPLNT_NKNM_TB_SUFX]
	,[PPLNT_PRCH_SUPP]
	,[PPLNT_ARB_APN_SUPP]
	,[PPLNT_MIN_SUPP]
	,[PPLNT_RAN_SUPP]
	,[PPLNT_BASE_RF_SUFX]
	,[PPLNT_SHIS_RF_SUFX]
	,[PPLNT_AUTO_AR_INST]
	,[PPLNT_REL_INST_TYP]
	,[PPLNT_SRCH_PF_SUFX]
	,[PPLNT_SECT_SUPP]
	,[PPLNT_INST_ALIAS]
	,[PPLNT_DCKT_ALIAS]
	,[PPLNT_RFINST_ALIAS]
	,[PPLNT_RFDCKT_ALIAS]
	,[PPLNT_SRCH_FMT_PGM]
	,[PPLNT_BASE_NM]
	,[PPLNT_IMAGE_ALIAS]
	,[PPLNT_ROLE_NM]
	,[PPLNT_OPROP_NM]
	,[PPLNT_PGM_SUFFIX]
	,[PPLNT_DSP_SUB_LOT]
	,[PPLNT_IMDCKT_ALIAS]
	,[PPLNT_CASE_SUPP]
	,[PPLNT_PLAT_THRU_DT]
	,[PPLNT_PLAT_ALIAS]
	,[PPLNT_AS_INST_TYPE]
	,[PPLNT_EAS_INST_TYP]
	,[PPLNT_TOR_TEE_IND]
	,[PPLNT_SOUNDEX]
	,[PPLNT_LIENS]
	,[PPLNT_VESTINGS]
	,[PPLNT_ENCUMBS]
	,[PPLNT_CENTS_IND]
	,[PPLNT_AUTO_AR_SRCH]
	,[PPLNT_MLLOAN_TYPE]
	,[PPLNT_MLINST_TYPE]
	,[PPLNT_NAME_ABBR]
	,[PPLNT_INST_FMT]
	,[PPLNT_INST_NM]
	,[PPLNT_INST_AL_FMT]
	,[PPLNT_INST_AL_NM]
	,[PPLNT_RFINST_FMT]
	,[PPLNT_RFINST_NM]
	,[PPLNT_RFINSTAL_FMT]
	,[PPLNT_RFINSTAL_NM]
	,[PPLNT_ARB_NM]
	,[PPLNT_CATG_TB_SUFX]
	,[PPLNT_ORD_EXT_DAYS]
	,[PPLNT_TTEE_ALPRTY]
	,[PPLNT_DOC_TB_SUFX]
	,[PPLNT_MAX_TORTEE]
	,[PPLNT_NM_LST_SUFX]
	,[PPLNT_TRACT_FMT]
	,[PPLNT_SUB_FMT]
	,[PPLNT_CONDO_FMT]
	,[PPLNT_TTL_APN_FMT]
	,[PPLNT_GI_FMT]
	,[PPLNT_CRTCS_RULE]
	,[PPLNT_PRO_PER_SUFF]
	,[PPLNT_GEO_FROM_DT]
	,[PPLNT_GEO_THRU_DT]
	,[PPLNT_TTEE_FROM_DT]
	,[PPLNT_TTEE_THRU_DT]
	,[PPLNT_GEO_TYP]
	,[PPLNT_LC_THRU_DT]
	,[PPLNT_GI_ALPRTY]
	,[PPLNT_USE_EXCULDE_IND]
	,[PPLNT_SHOW_CATEGORY_IND]
	,[PPLNT_STARTER_LOOKUP_IND]
	,[PPLNT_DISPLAY_LNBKY_IND]
	,[PPLNT_FED_BKY_THRU_DT]
	)

	' 
			AS NVARCHAR(max)) + cast(
			N'
SELECT [PPLNT_ST]
	,[PPLNT_CTY]
	,[PPLNT_PLNT_FROM_DT]
	,[PPLNT_CRT_THRU_DT]
	,[PPLNT_THRU_FULL_DT]
	,[PPLNT_THRU_INST_DT]
	,[PPLNT_THRU_INST_TM]
	,[PPLNT_THRU_INST]
	,[PPLNT_PLAT_ID_FRMT]
	,[PPLNT_SEC_HLF_SUPP]
	,[PPLNT_GOVT_LT_SUPP]
	,[PPLNT_SEC_ARB_SUPP]
	,[PPLNT_NKNM_SUPP]
	,[PPLNT_NKNM_TB_SUFX]
	,[PPLNT_PRCH_SUPP]
	,[PPLNT_ARB_APN_SUPP]
	,[PPLNT_MIN_SUPP]
	,[PPLNT_RAN_SUPP]
	,[PPLNT_BASE_RF_SUFX]
	,[PPLNT_SHIS_RF_SUFX]
	,[PPLNT_AUTO_AR_INST]
	,[PPLNT_REL_INST_TYP]
	,[PPLNT_SRCH_PF_SUFX]
	,[PPLNT_SECT_SUPP]
	,[PPLNT_INST_ALIAS]
	,[PPLNT_DCKT_ALIAS]
	,[PPLNT_RFINST_ALIAS]
	,[PPLNT_RFDCKT_ALIAS]
	,[PPLNT_SRCH_FMT_PGM]
	,[PPLNT_BASE_NM]
	,[PPLNT_IMAGE_ALIAS]
	,[PPLNT_ROLE_NM]
	,[PPLNT_OPROP_NM]
	,[PPLNT_PGM_SUFFIX]
	,[PPLNT_DSP_SUB_LOT]
	,[PPLNT_IMDCKT_ALIAS]
	,[PPLNT_CASE_SUPP]
	,[PPLNT_PLAT_THRU_DT]
	,[PPLNT_PLAT_ALIAS]
	,[PPLNT_AS_INST_TYPE]
	,[PPLNT_EAS_INST_TYP]
	,[PPLNT_TOR_TEE_IND]
	,[PPLNT_SOUNDEX]
	,[PPLNT_LIENS]
	,[PPLNT_VESTINGS]
	,[PPLNT_ENCUMBS]
	,[PPLNT_CENTS_IND]
	,[PPLNT_AUTO_AR_SRCH]
	,[PPLNT_MLLOAN_TYPE]
	,[PPLNT_MLINST_TYPE]
	,[PPLNT_NAME_ABBR]
	,[PPLNT_INST_FMT]
	,[PPLNT_INST_NM]
	,[PPLNT_INST_AL_FMT]
	,[PPLNT_INST_AL_NM]
	,[PPLNT_RFINST_FMT]
	,[PPLNT_RFINST_NM]
	,[PPLNT_RFINSTAL_FMT]
	,[PPLNT_RFINSTAL_NM]
	,[PPLNT_ARB_NM]
	,[PPLNT_CATG_TB_SUFX]
	,[PPLNT_ORD_EXT_DAYS]
	,[PPLNT_TTEE_ALPRTY]
	,[PPLNT_DOC_TB_SUFX]
	,[PPLNT_MAX_TORTEE]
	,[PPLNT_NM_LST_SUFX]
	,[PPLNT_TRACT_FMT]
	,[PPLNT_SUB_FMT]
	,[PPLNT_CONDO_FMT]
	,[PPLNT_TTL_APN_FMT]
	,[PPLNT_GI_FMT]
	,[PPLNT_CRTCS_RULE]
	,[PPLNT_PRO_PER_SUFF]
	,[PPLNT_GEO_FROM_DT]
	,[PPLNT_GEO_THRU_DT]
	,[PPLNT_TTEE_FROM_DT]
	,[PPLNT_TTEE_THRU_DT]
	,[PPLNT_GEO_TYP]
	,[PPLNT_LC_THRU_DT]
	,[PPLNT_GI_ALPRTY]
	,[PPLNT_USE_EXCULDE_IND]
	,[PPLNT_SHOW_CATEGORY_IND]
	,[PPLNT_STARTER_LOOKUP_IND]
	,[PPLNT_DISPLAY_LNBKY_IND]
	,[PPLNT_FED_BKY_THRU_DT]
FROM ' 
			+ @Server + '.MFSecurity.TR00.PL_PLANT_PARAM

commit
' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	SET @SQL = cast(
			N'
begin transaction
TRUNCATE TABLE [PET].[TR00].[TR_COUNTY]

INSERT INTO [PET].[TR00].[TR_COUNTY] (
	[TCNTY_ST]
	,[TCNTY_CTY]
	,[TCNTY_CTY_NM]
	,[TCNTY_CICS_REG_ID]
	,[TCNTY_TAX_SYS_ID]
	,[TCNTY_CMD_CTY_CD]
	,[TCNTY_INDX_RF_SUFX]
	,[TCNTY_IMAGE_SUFX]
	,[TCNTY_MENU_ID]
	,[TCNTY_CTY_IMG]
	,[TCNTY_SYSTEM_ID]
	,[TCNTY_CTY_SHORT_NM]
	,[TCNTY_ST_FIPS]
	,[TCNTY_CTY_FIPS]
	,[TCNTY_QUERY_SUFX]
	,[TCNTY_PRINT_SUFX]
	,[TCNTY_ROLLOUT_IND]
	,[TCNTY_FORA_IND]
	,[TCNTY_DD_ROUT_IND]
	,[TCNTY_MAX_TORTEE]
	,[TCNTY_MAINT_PLAT]
	,[TCNTY_MAINT_SETS]
	,[TCNTY_MAINT_TAX]
	,[TCNTY_FOUT_UPDATE_IND]
	,[TCNTY_USE_REDVISION_IND]
	,[TCNTY_USE_STR_XCHANGE_IND]
	)
SELECT [TCNTY_ST]
	,[TCNTY_CTY]
	,[TCNTY_CTY_NM]
	,[TCNTY_CICS_REG_ID]
	,[TCNTY_TAX_SYS_ID]
	,[TCNTY_CMD_CTY_CD]
	,[TCNTY_INDX_RF_SUFX]
	,[TCNTY_IMAGE_SUFX]
	,[TCNTY_MENU_ID]
	,[TCNTY_CTY_IMG]
	,[TCNTY_SYSTEM_ID]
	,[TCNTY_CTY_SHORT_NM]
	,[TCNTY_ST_FIPS]
	,[TCNTY_CTY_FIPS]
	,[TCNTY_QUERY_SUFX]
	,[TCNTY_PRINT_SUFX]
	,[TCNTY_ROLLOUT_IND]
	,[TCNTY_FORA_IND]
	,[TCNTY_DD_ROUT_IND]
	,[TCNTY_MAX_TORTEE]
	,[TCNTY_MAINT_PLAT]
	,[TCNTY_MAINT_SETS]
	,[TCNTY_MAINT_TAX]
	,[TCNTY_FOUT_UPDATE_IND]
	,[TCNTY_USE_REDVISION_IND]
	,[TCNTY_USE_STR_XCHANGE_IND]
FROM ' 
			+ @Server + '.MFSecurity.TR00.TR_COUNTY

COMMIT

' AS NVARCHAR(max))

	SELECT @SQL

	EXEC (@SQL)

	-- declare @ERROR VARCHAR(500) 
	IF (
			SELECT count(1) AS cnt
			FROM [Pet].[dbo].[Dynamic_format]
			) = 0
		OR (
			SELECT count(1) AS cnt
			FROM [Pet].[dbo].[County]
			) = 0
		OR (
			SELECT count(1) AS cnt
			FROM [Pet].[dbo].[Feature]
			) = 0
		OR (
			SELECT count(1) AS cnt
			FROM [Pet].[dbo].[Service]
			) = 0
		OR (
			SELECT count(1) AS cnt
			FROM [PET].[TR00].[PL_PLANT_PARAM]
			) = 0
		OR (
			SELECT count(1) AS cnt
			FROM [PET].[TR00].[TR_COUNTY]
			) = 0
	BEGIN
		SET @error = 'one or more configuration tables are empty'

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Update_Pet_Counties'
		,N'Ended'
END TRY

BEGIN CATCH
	IF @error IS NULL
	BEGIN
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
	END

	ROLLBACK

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

