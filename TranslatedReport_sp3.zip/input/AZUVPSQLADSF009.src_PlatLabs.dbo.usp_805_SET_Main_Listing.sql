SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [src_PlatLabs].[dbo].[usp_805_SET_Main_Listing]
AS
BEGIN

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

	UPDATE [src_PlatLabs].[dbo].[MainListingComplete]
	SET YesOrNo = 'N'

	DROP TABLE IF EXISTS #RunThese
	Select distinct FIPS,REF_ID INTO #RunThese FROM [src_PlatLabs].[listing].[listingFull] with(NOLOCK) where loadDate > GetDate()-1 and REF_ID is not null
	CREATE index ix_FIPSREFID on #RunThese(FIPS,REF_ID)

			/***** CLEAR OUT DATA ****/
			Update [src_PlatLabs].[listing].[listingFull] 
			set MainListing = NULL
			,MainListingDate = NULL
			FROM [src_PlatLabs].[listing].[listingFull] a JOIN #RunThese b
			on a.FIPS = b.FIPS
			and a.REF_ID = b.REF_ID
			
			
			/***** DROP working table ****/
			Drop table if exists [src_Platlabs].[dbo].[MainListing]

			/***** CREATE main listing working table using all available dates ****/
			SELECT mls_id,mls_listing_id,Platlabs_Listdate,a.Fips,a.REF_ID
			,ROW_NUMBER() OVER(PARTITION BY a.fips,a.REF_ID ORDER BY a.Fips,a.REF_ID,platlabs_listdate desc,mls_create_date,modified_date,loaddate,[created_date]) AS MainListing 
			,GETDATE() as MainListingDate
			INTO [src_Platlabs].[dbo].[MainListing]
			FROM [src_PlatLabs].[listing].[listingFull] a with(NOLOCK) JOIN #RunThese b
			on a.FIPS = b.FIPS
			and a.REF_ID = b.REF_ID
			WHERE a.REF_ID is not null
			ORDER BY a.FIPS,a.REF_id,Platlabs_Listdate desc

			CREATE INDEX ix_MLSIDListingID on [src_Platlabs].[dbo].[MainListing](mls_id,mls_listing_id)

			update [src_PlatLabs].[dbo].[a]
			SET a.MainListing = NULL
			,a.MainListingDate = NULL
			from [src_PlatLabs].[listing].[listingFull] a JOIN [src_Platlabs].[dbo].[MainListing] b
			on a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id
			where a.MainListing != b.MainListing


			/***** UPDATE with Platlabs calculated Main Listing ****/
			update [src_PlatLabs].[dbo].[a]
			SET a.MainListing = b.MainListing
			,a.MainListingDate = b.MainListingDate
			FROM [src_PlatLabs].[listing].[listingFull] a with(NOLOCK) join [src_Platlabs].[dbo].[MainListing] b
			on a.mls_id = b.mls_id 
			and a.mls_listing_id = b.mls_listing_id
			WHERE b.MainListing = 1


		DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_II]

		Select a.Fips,a.REF_ID,a.Platlabs_Listdate NewMain,b.Platlabs_Listdate OldMain,min(a.modified_date) as minModDt 
		INTO [src_Platlabs].[dbo].[MainListing_II]
		from [src_PlatLabs].[listing].[listingFull] a with(NOLOCK) JOIN (
		Select l.Fips,l.REF_ID,Platlabs_Listdate,mls_id,mls_listing_id,price from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1) b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing is null
			and a.mls_id != b.mls_id
			and a.Platlabs_Listdate < b.Platlabs_Listdate
			and a.Platlabs_Listdate > cast(b.Platlabs_Listdate as datetime)-15
			and a.price = b.price
		Group by a.Fips,a.REF_ID,a.Platlabs_Listdate ,b.Platlabs_Listdate 

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_II](FIPS,REF_ID)

		UPDATE [src_PlatLabs].[dbo].[a]
		SET a.MainListing = NULL
		,a.MainListingDate = NULL
		FROM [src_PlatLabs].[listing].[listingFull] a JOIN [src_Platlabs].[dbo].[MainListing_II] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID 
		WHERE a.Platlabs_Listdate = b.OldMain

		UPDATE [src_PlatLabs].[dbo].[a]
		SET a.MainListing = 1
		,a.MainListingDate = Getdate()
		FROM [src_PlatLabs].[listing].[listingFull] a JOIN [src_Platlabs].[dbo].[MainListing_II] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID 
		and a.modified_date = b.minModDt
		and a.Platlabs_Listdate = b.NewMain
 



		 DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_III]

		Select l.Fips,l.REF_ID,min(platlabs_listdate) as minListDt, min(modified_date) as MinModDt
		INTO [src_Platlabs].[dbo].[MainListing_III]
		from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1
		group by l.Fips,l.REF_ID
		having count(*) > 1

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_III](FIPS,REF_ID)

		update [src_PlatLabs].[dbo].[a]
		set a.MainListing = NULL
		,a.MainListingDate = Null
		from [src_PlatLabs].[listing].[listingFull] a join [src_Platlabs].[dbo].[MainListing_III] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing = 1
		and a.Platlabs_Listdate != b.minListDt
		and a.modified_date != b.MinModDt

		DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_IV]

		Select l.Fips,l.REF_ID,min(platlabs_listdate) as minListDt, min(modified_date) as MinModDt
		INTO [src_Platlabs].[dbo].[MainListing_IV]
		from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1
		group by l.Fips,l.REF_ID
		having count(*) > 1

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_IV](FIPS,REF_ID)

		update [src_PlatLabs].[dbo].[a]
		set a.MainListing = NULL
		,a.MainListingDate = Null
		from [src_PlatLabs].[listing].[listingFull] a join [src_Platlabs].[dbo].[MainListing_IV] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing = 1
		and a.modified_date != b.MinModDt

		DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_V]

		Select l.Fips,l.REF_ID,min(platlabs_listdate) as minListDt, min(modified_date) as MinModDt
		INTO [src_Platlabs].[dbo].[MainListing_V]
		from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1
		group by l.Fips,l.REF_ID
		having count(*) > 1

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_V](FIPS,REF_ID)

		update [src_PlatLabs].[dbo].[a]
		set a.MainListing = NULL
		,a.MainListingDate = Null
		from [src_PlatLabs].[listing].[listingFull] a join [src_Platlabs].[dbo].[MainListing_V] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing = 1
		and RowNum != 1

		DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_VI]

		Select l.Fips,l.REF_ID,min(mls_create_date) as minCreateDt
		INTO [src_Platlabs].[dbo].[MainListing_VI]
		from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1
		group by l.Fips,l.REF_ID
		having count(*) > 1

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_VI](FIPS,REF_ID)

		update [src_PlatLabs].[dbo].[a]
		set a.MainListing = NULL
		,a.MainListingDate = Null
		from [src_PlatLabs].[listing].[listingFull] a join [src_Platlabs].[dbo].[MainListing_VI] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing = 1
		and a.mls_create_date != minCreateDt

		DROP TABLE IF EXISTS [src_Platlabs].[dbo].[MainListing_VII]

		Select l.Fips,l.REF_ID,min(created_date) as minCreateDt
		INTO [src_Platlabs].[dbo].[MainListing_VII]
		from [src_PlatLabs].[listing].[listingFull] l with(NOLOCK) JOIN #RunThese b
					on l.FIPS = b.FIPS
					and l.REF_ID = b.REF_ID
		where MainListing = 1
		group by l.Fips,l.REF_ID
		having count(*) > 1

		create index ix_FipsREFID on [src_Platlabs].[dbo].[MainListing_VII](FIPS,REF_ID)

		update [src_PlatLabs].[dbo].[a]
		set a.MainListing = NULL
		,a.MainListingDate = Null
		from [src_PlatLabs].[listing].[listingFull] a join [src_Platlabs].[dbo].[MainListing_VII] b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID
		where a.MainListing = 1
		and a.mls_create_date != minCreateDt

		DROP TABLE IF EXISTS #RunThese

	UPDATE [src_PlatLabs].[dbo].[MainListingComplete]
	SET YesOrNo = 'Y'

	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END


