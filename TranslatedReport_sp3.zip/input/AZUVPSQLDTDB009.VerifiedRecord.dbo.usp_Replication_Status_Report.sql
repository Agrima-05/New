/* Source: AZUVNSQLDTDB003.datatree.local | VerifiedRecord | dbo.usp_Replication_Status_Report | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [VerifiedRecord].[dbo].[usp_Replication_Status_Report]
AS
DECLARE @SQL VARCHAR(MAX)
	,@qry VARCHAR(8000)
	,@subject VARCHAR(100) = 'Replication_Status - ' + format(getDate(), 'MM/dd/yyyy HH:mm:ss tt')
	,@recipients VARCHAR(100) = 'hdeweerdt@firstam.com'
DECLARE @tableHTML NVARCHAR(MAX);

SET @tableHTML = N'<H1>Replication Status report</H1>' + N'<table border="1">' + N'<tr><th>ReplicationDestTableName</th><th>ReplicationDestServer</th><th>ST_TotalRows</th><th>RD_TotalRows</th><th>rowDiff</th><th>ChecksumMatch</th><th>ST_Last_Updated</th><th>RD_Last_Updated</th><th>StatusDateTime</th></tr>' + CAST((
			SELECT td = ReplicationDestTableName
				,''
				,td = ReplicationDestServer
				,''
				,cast (case when rowDiff <> 0 then 'background-color:#f53110;text-align: center;color: white;' else 'background-color:#90EE90;text-align: center;' end as nvarchar(100)) as 'td/@style'
				,td = ST_TotalRows
				,''
				,cast (case when rowDiff <> 0 then 'background-color:#f53110;text-align: center;color: white;' else 'background-color:#90EE90;text-align: center;' end as nvarchar(100)) as 'td/@style'
				,td = RD_TotalRows
				,''
				,cast (case when rowDiff <> 0 then 'background-color:#f53110;text-align: center;color: white;' else 'background-color:#90EE90;text-align: center;' end as nvarchar(100)) as 'td/@style'
				,td = rowDiff
				,''
				,cast (case when ChecksumMatch = 0 then 'background-color:#f53110;text-align: center;color: white;' else 'background-color:#90EE90;text-align: center;' end as nvarchar(100)) as 'td/@style'
				,td = ChecksumMatch
				,''
				,td = coalesce(format(ST_Last_Updated, 'MM/dd/yyyy hh:mm:ss'), '')
				,''
				,td = coalesce(format(RD_Last_Updated, 'MM/dd/yyyy hh:mm:ss'), '')
				,''
				,td = coalesce(format(StatusDateTime, 'MM/dd/yyyy hh:mm:ss'), '')
			FROM (
				SELECT ROW_NUMBER() OVER (
						PARTITION BY ReplicationDestTableName
						,ReplicationDestServer ORDER BY ReplicationDestTableName
							,ReplicationDestServer
							,StatusDateTime DESC
						) AS ROW4
					,ReplicationDestTableName
					,ReplicationDestServer
					,ST_TotalRows
					,RD_TotalRows
					,rowDiff
					,ChecksumMatch
					,ST_Last_Updated
					,RD_Last_Updated
					,StatusDateTime
				FROM [VerifiedRecord].[dbo].[v_ReplicationStatus]
				) a
			WHERE row4 = 1
			ORDER BY ReplicationDestTableName
				,ReplicationDestServer
			FOR XML PATH('tr')
				,TYPE
			) AS NVARCHAR(MAX)) + N'</table>';

EXEC msdb.dbo.sp_send_dbmail @recipients = @recipients
	,@subject = @subject
	,@body = @tableHTML
	,@body_format = 'HTML';


