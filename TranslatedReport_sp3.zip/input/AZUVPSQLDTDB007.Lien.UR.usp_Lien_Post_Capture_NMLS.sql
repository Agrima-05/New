/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Lien_Post_Capture_NMLS | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		Marie Pretorius
-- Create date: 2023-04-04
-- Description:	Standardize NMLS Data
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_Lien_Post_Capture_NMLS] @ERROR VARCHAR(500) OUTPUT
AS
--/******************************************************************************************************************
--CHANGE LOG:
--==========
--who		date		change
--******************************************************************************************************************/
----declare @ERROR VARCHAR(500) 
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Lien_Post_Capture_NMLS'
		,N'Started'

	/*
--must be in ssis that copy from sql29 to etl01
--CREATE INDEX idx_NMLSAgentId_in ON Lien.nmls.NMLS_OCR_Individual (NMLSAgentId_in)

--CREATE INDEX idx_NMLSAgentName_in ON Lien.nmls.NMLS_OCR_Individual (NMLSAgentName_in)

--CREATE INDEX idx_NMLSLenderId_in ON Lien.nmls.NMLS_OCR_Company (NMLSLenderId_in)

--CREATE INDEX idx_NMLSLenderName_in ON Lien.nmls.NMLS_OCR_Company (NMLSLenderName_in)
*/
	--
	-- Select daily input and pull in missing names from input codes
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info]
		SELECT d.doc_id
			,d.fips_code
			,d.cmt_docnumber
			,d.source
			--,CASE 
			--	WHEN isnull(d.nmls_company1_orig, '') <> isnull(n1.NMLSLenderName_out, '')
			--		AND isnull(n1.NMLSLenderName_out, '') > ''
			--		THEN n1.NMLSLenderName_out
			--	ELSE d.nmls_company1_orig
			--	END AS nmls_company1_orig
			,CASE 
				WHEN d.nmls_company1_orig IS NULL
					THEN n1.NMLSLenderName_out
				ELSE d.nmls_company1_orig
				END AS nmls_company1_orig
			,d2.nmls_company1_id_orig
			,CASE 
				WHEN isnull(d.nmls_company2_orig, '') <> isnull(n2.NMLSLenderName_out, '')
					AND isnull(n2.NMLSLenderName_out, '') > ''
					THEN n2.NMLSLenderName_out
				ELSE d.nmls_company2_orig
				END AS nmls_company2_orig
			,d2.nmls_company2_id_orig
			,CASE 
				WHEN isnull(d.nmls_officer_orig, '') <> isnull(a3.NMLSLenderName_out, '')
					AND isnull(a3.NMLSLenderName_out, '') > ''
					THEN a3.NMLSLenderName_out
				ELSE d.nmls_officer_orig
				END AS nmls_officer_orig
			,d2.nmls_officer_id_orig -- for compare purposes
		INTO [Lien_dtdb].[tmp].[NMLS_Info] --FROM Lien_dtdb.tmp.reprocess_records_to_be_processed c WITH (INDEX (idx))
		FROM [lien].[tmp].[reprocess_records_to_be_processed] c WITH (INDEX (idx))
		INNER JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.Doc_id = c.Doc_id
		OUTER APPLY (
			SELECT try_cast(nmls_company1_id_orig AS INT) AS nmls_company1_id_orig
				,try_cast(nmls_company2_id_orig AS INT) AS nmls_company2_id_orig
				,try_cast(nmls_officer_id_orig AS INT) AS nmls_officer_id_orig
			) d2
		OUTER APPLY (
			SELECT TOP 1 *
			FROM (
				SELECT TOP 1 NMLSLenderName_out
				FROM [Lien].[nmls].[NMLS_OCR_Company] ni1 WITH (
						NOLOCK
						,INDEX (idx_NMLSLenderId_in)
						)
				WHERE ni1.NMLSLenderId_in = d2.nmls_company1_id_orig
				
				UNION ALL
				
				SELECT TOP 1 NMLSAgentName_out
				FROM [Lien].[nmls].[NMLS_OCR_Individual] ni2 WITH (
						NOLOCK
						,INDEX (idx_NMLSAgentId_in)
						)
				WHERE ni2.NMLSAgentId_in = d2.nmls_company1_id_orig
				) n11
			) n1
		OUTER APPLY (
			SELECT TOP 1 *
			FROM (
				SELECT TOP 1 NMLSLenderName_out
				FROM [Lien].[nmls].[NMLS_OCR_Company] ni1 WITH (
						NOLOCK
						,INDEX (idx_NMLSLenderId_in)
						)
				WHERE ni1.NMLSLenderId_in = d2.nmls_company2_id_orig
				
				UNION ALL
				
				SELECT TOP 1 NMLSAgentName_out
				FROM [Lien].[nmls].[NMLS_OCR_Individual] ni2 WITH (
						NOLOCK
						,INDEX (idx_NMLSAgentId_in)
						)
				WHERE ni2.NMLSAgentId_in = d2.nmls_company2_id_orig
				) n21
			) n2
		OUTER APPLY (
			SELECT TOP 1 *
			FROM (
				SELECT TOP 1 NMLSLenderName_out
				FROM [Lien].[nmls].[NMLS_OCR_Company] ni1 WITH (
						NOLOCK
						,INDEX (idx_NMLSLenderId_in)
						)
				WHERE ni1.NMLSLenderId_in = d2.nmls_officer_id_orig
				
				UNION ALL
				
				SELECT TOP 1 NMLSAgentName_out
				FROM [Lien].[nmls].[NMLS_OCR_Individual] ni2 WITH (
						NOLOCK
						,INDEX (idx_NMLSAgentId_in)
						)
				WHERE ni2.NMLSAgentId_in = d2.nmls_officer_id_orig
				) n21
			) a3
		WHERE (
				isnull(d.nmls_company1_orig, '') <> ''
				OR isnull(d2.nmls_company1_id_orig, '') <> ''
				OR isnull(d.nmls_company2_orig, '') <> ''
				OR isnull(d2.nmls_company2_id_orig, '') <> ''
				OR isnull(d.nmls_Officer_orig, '') <> ''
				OR isnull(d2.nmls_officer_id_orig, '') <> ''
				)
		--and d.doc_id = 383674045
		--ORDER BY d.doc_id DESC
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[tmp].[NMLS_Info] (doc_id)

	--SELECT TOP 100 'NMLS_Info' AS _NMLS_Info_before
	--	,*
	--FROM Lien_dtdb.tmp.NMLS_Info
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2_orig = NULL
		,a.nmls_company2_id_orig = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	WHERE (
			nmls_company1_orig = nmls_company2_orig
			AND nmls_company1_id_orig = nmls_company2_id_orig
			)

	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer_orig = NULL
		,a.nmls_officer_id_orig = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	WHERE (
			nmls_company1_orig = nmls_officer_orig
			AND nmls_company1_id_orig = nmls_officer_id_orig
			)

	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer_orig = NULL
		,a.nmls_officer_id_orig = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	WHERE (
			nmls_company2_orig = nmls_officer_orig
			AND nmls_company2_id_orig = nmls_officer_id_orig
			)

	--select top 100 * from Lien_dtdb.tmp.NMLS_Info
	--UPDATE a
	--SET a.nmls_company2_orig = NULL
	--FROM Lien_dtdb.tmp.NMLS_Info a
	--WHERE nmls_company1_orig = nmls_company2_orig
	--
	-- created table Lien_dtdb.tmp.NMLS_Info_pairs that indicate and extract names and ids from Corp and Indiv table
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_pairs]
		SELECT a.doc_id
			,a1.*
			,try_cast('' AS VARCHAR(200)) AS NMLSLenderName_out_p
		-- select top 10 * 
		INTO [Lien_dtdb].[tmp].[NMLS_Info_pairs]
		FROM [Lien_dtdb].[tmp].[NMLS_Info] a
		OUTER APPLY (
			SELECT try_cast(a.nmls_company1_id_orig AS INT) AS nmls_company1_id_orig
				,try_cast(a.nmls_company2_id_orig AS INT) AS nmls_company2_id_orig
				,try_cast(a.nmls_officer_id_orig AS INT) AS nmls_officer_id_orig
			) d2
		OUTER APPLY (
			--nmls1
			SELECT TOP 1 'nmls1' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'nmc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderName_in)
					)
			WHERE NMLSLenderName_in = a.nmls_company1_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls1' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'idc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderId_in)
					)
			WHERE NMLSLenderId_in = d2.nmls_company1_id_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls1' AS _col
				,NMLSID
				,[Name]
				,'idco' AS _from
			FROM [Lien].[NMLS].[NMLS_Src_Company] WITH (
					NOLOCK
					,INDEX (ix_NMLSID)
					)
			WHERE NMLSID_N = d2.nmls_company1_id_orig
			ORDER BY IsActive DESC
			--nmls2
			
			UNION ALL
			
			SELECT TOP 1 'nmls2' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'nmc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderName_in)
					)
			WHERE NMLSLenderName_in = a.nmls_company2_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls2' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'idc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderId_in)
					)
			WHERE NMLSLenderId_in = d2.nmls_company2_id_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls2' AS _col
				,NMLSID
				,[Name]
				,'idco' AS _from
			FROM [Lien].[NMLS].[NMLS_Src_Company] WITH (
					NOLOCK
					,INDEX (ix_NMLSID)
					)
			WHERE NMLSID_N = d2.nmls_company2_id_orig
			ORDER BY IsActive DESC
			--agent
			
			UNION ALL
			
			SELECT TOP 1 'agent' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'nmc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderName_in)
					)
			WHERE NMLSLenderName_in = a.nmls_officer_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'agent' AS _col
				,NMLSLenderId_out
				,NMLSLenderName_out
				,'idc' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Company] WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderId_in)
					)
			WHERE NMLSLenderId_in = d2.nmls_officer_id_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'Agent' AS _col
				,NMLSID_N
				,[Name]
				,'idco' AS _from
			FROM [Lien].[NMLS].[NMLS_Src_Company] WITH (
					NOLOCK
					,INDEX (ix_NMLSID)
					)
			WHERE NMLSID_N = d2.nmls_company2_id_orig
			ORDER BY IsActive DESC
			-- lookup by name
			-- indiv table
			
			UNION ALL
			
			SELECT TOP 1 'nmls1' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'nmi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentName_in)
					)
			WHERE NMLSAgentName_in = a.nmls_company1_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls1' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'idi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentId_in)
					)
			WHERE NMLSAgentId_in = d2.nmls_company1_id_orig
			ORDER BY [count] DESC
			--nmls2
			
			UNION ALL
			
			SELECT TOP 1 'nmls2' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'nmi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentName_in)
					)
			WHERE NMLSAgentName_in = a.nmls_company2_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'nmls2' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'idi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentId_in)
					)
			WHERE NMLSAgentId_in = d2.nmls_company2_id_orig
			ORDER BY [count] DESC
			--agent
			
			UNION ALL
			
			SELECT TOP 1 'agent' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'nmi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentName_in)
					)
			WHERE NMLSAgentName_in = a.nmls_officer_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'agent' AS _col
				,NMLSAgentId_out
				,NMLSAgentName_out
				,'idi' AS _from
			FROM [Lien].[nmls].[NMLS_OCR_Individual] WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentId_in)
					)
			WHERE NMLSAgentId_in = d2.nmls_officer_id_orig
			ORDER BY [count] DESC
			
			UNION ALL
			
			SELECT TOP 1 'agent' AS _col
				,NMLSID_N
				,[Name]
				,'idio' AS _from
			FROM [Lien].[NMLS].[NMLS_Src_Individual] WITH (
					NOLOCK
					,INDEX (ix_NMLSID)
					)
			WHERE NMLSID_N = d2.nmls_company2_id_orig
			ORDER BY IsActive DESC
			) a1

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[tmp].[NMLS_Info_pairs] (doc_id)

	-- SELECT TOP 100 * FROM Lien_dtdb.tmp.NMLS_Info_pairs
	--
	-- Update names from ID when Id was successfully found on corp and individ table
	--nmls_company1_orig
	--
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company1_orig = p.NMLSLenderName_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p.NMLSLenderId_out = a.nmls_company1_id_orig
			AND p._col = 'nmls1'
			AND p._from = 'idc'
		) p
	WHERE a.nmls_company1_id_orig IS NOT NULL

	--AND a.nmls_company1_orig <> p.NMLSLenderName_out
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company1_orig = p.NMLSLenderName_out
		,a.nmls_company1_id_orig = p.NMLSLenderId_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT TOP 1 *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p._col = 'nmls1'
			AND p._from IN (
				'nmc'
				,'idc'
				)
		ORDER BY p._from
		) p
	WHERE a.nmls_company1_orig IS NOT NULL

	--AND a.nmls_company1_orig <> p.NMLSLenderName_out
	--
	--nmls_company2_orig
	--
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2_orig = p.NMLSLenderName_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p.NMLSLenderId_out = a.nmls_company2_id_orig
			AND p._col = 'nmls2'
			AND p._from = 'idc'
		) p
	WHERE a.nmls_company2_id_orig IS NOT NULL

	--AND a.nmls_company2_orig <> p.NMLSLenderName_out
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2_orig = p.NMLSLenderName_out
		,a.nmls_company2_id_orig = p.NMLSLenderId_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT TOP 1 *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p._col = 'nmls2'
			AND p._from IN (
				'nmc'
				,'idc'
				)
		ORDER BY p._from
		) p
	WHERE a.nmls_company2_orig IS NOT NULL

	--AND a.nmls_company2_orig <> p.NMLSLenderName_out
	--
	--nmls_officer_orig
	--
	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer_orig = p.NMLSLenderName_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p.NMLSLenderId_out = a.nmls_officer_id_orig
			AND p._col = 'agent'
			AND p._from = 'idi'
		) p
	WHERE a.nmls_officer_orig IS NOT NULL

	--AND a.nmls_officer_orig <> p.NMLSLenderName_out
	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer_orig = p.NMLSLenderName_out
		,a.nmls_officer_id_orig = p.NMLSLenderId_out
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	CROSS APPLY (
		SELECT TOP 1 *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE p.doc_id = a.doc_id
			AND p._col = 'agent'
			AND p._from IN (
				'nmi'
				,'idi'
				)
		ORDER BY p._from
		) p
	WHERE a.nmls_officer_orig IS NOT NULL

	--AND a.nmls_officer_orig <> p.NMLSLenderName_out
	-- remove duplicates after pair updates
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2_orig = NULL
		,a.nmls_company2_id_orig = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_Info] a
	WHERE nmls_company1_orig = nmls_company2_orig
		AND nmls_company1_id_orig = nmls_company2_id_orig

	--SELECT TOP 100 '_NMLS_Info_after_update' AS _NMLS_Info_after_update
	--	,*
	--FROM Lien_dtdb.tmp.NMLS_Info
	--
	-- Create _p value to be used in comparisson
	--
	--SELECT TOP 100 *
	UPDATE [Lien].[UR].[a]
	SET a.NMLSLenderName_out_p = a3.NMLSLenderName_out_p
	FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] a
	OUTER APPLY (
		SELECT CASE 
				WHEN Charindex('DBA ', a.NMLSLenderName_out, 1) > 0
					THEN REPLACE(a.NMLSLenderName_out, SUBSTRING(a.NMLSLenderName_out, PATINDEX('%dba %', a.NMLSLenderName_out), 200), '')
				ELSE a.NMLSLenderName_out
				END AS NMLSLenderName_out_p
		) a1
	OUTER APPLY (
		SELECT REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(a1.NMLSLenderName_out_p, CHAR(10), ''), CHAR(13), ''), 'National Association', 'NA'), 'N.A.', 'NA'), '(NMLS', ''), 'Corporation', 'CORP'), 'Mortgage', 'MTG'), 'D/B/A', ''), 'D/B/', ''), 'Company', '') AS NMLSLenderName_out_p
		) a2
	OUTER APPLY (
		SELECT [SPDB].[dbo].[RegexReplace](a2.NMLSLenderName_out_p, '(\/| |-|\.|,|$|%|&|!)', '', 0) AS NMLSLenderName_out_p
		) a3

	--
	-- get lenders from lien.ur.name table 
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_lenders_a]
		SELECT n.doc_id
			,try_cast(substring(n.Last_company_name, 1, 200) AS VARCHAR(200)) AS Lender_name
		INTO [Lien_dtdb].[tmp].[NMLS_Info_lenders_a]
		FROM [lien].[ur].[Name] n WITH (
				NOLOCK
				,INDEX (Doc_ID)
				)
		WHERE n.doc_id IN (
				SELECT doc_id
				FROM [Lien_dtdb].[tmp].[NMLS_Info]
				)
			AND n.Role_Type IN (
				SELECT CodeValue
				FROM [Lien].[dbo].[CodeTable] WITH (INDEX (idx_Table_value))
				WHERE TableShortName = 'LenderRoleTypes'
				)
		ORDER BY sequence_number
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[tmp].[NMLS_Info_lenders_a] (doc_id)

	--
	-- Create table Lien_dtdb.tmp.NMLS_Info_lenders_1 to add the _p value for all 3 names
	--
	--select top 100 * from Lien_dtdb.tmp.NMLS_Info_pairs
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_lenders_1]
		SELECT a.doc_id
			,li.fips_code
			,li.cmt_docnumber
			,a.Lender_name
			,li.nmls_company1_orig
			,li.nmls_company2_orig
			,li.nmls_officer_orig
		INTO [Lien_dtdb].[tmp].[NMLS_Info_lenders_1]
		FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders_a] a WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		INNER JOIN [Lien_dtdb].[tmp].[NMLS_Info] li WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				) ON li.doc_id = a.doc_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--select top 100 * from Lien_dtdb.tmp.NMLS_Info
	--
	-- remove the 'DBA' from name
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_lenders_2]
		SELECT d.doc_id
			,d.fips_code
			,d.cmt_docnumber
			,d.Lender_name
			,d.nmls_company1_orig
			,d.nmls_company2_orig
			,d.nmls_officer_orig
			,CASE 
				WHEN Charindex('DBA ', d.Lender_name, 1) > 0
					THEN REPLACE(d.Lender_name, SUBSTRING(d.Lender_name, PATINDEX('%dba %', d.Lender_name), 200), '')
				ELSE d.Lender_name
				END AS Lender_name_p
			,CASE 
				WHEN Charindex('DBA ', d.nmls_company1_orig, 1) > 0
					THEN REPLACE(d.nmls_company1_orig, SUBSTRING(d.nmls_company1_orig, PATINDEX('%dba %', d.nmls_company1_orig), 200), '')
				ELSE d.nmls_company1_orig
				END AS nmls_company1_orig_p
			,CASE 
				WHEN Charindex('DBA ', d.nmls_company2_orig, 1) > 0
					THEN REPLACE(d.nmls_company2_orig, SUBSTRING(d.nmls_company2_orig, PATINDEX('%dba %', d.nmls_company2_orig), 200), '')
				ELSE d.nmls_company2_orig
				END AS nmls_company2_orig_p
			,CASE 
				WHEN Charindex('DBA ', d.nmls_officer_orig, 1) > 0
					THEN REPLACE(d.nmls_officer_orig, SUBSTRING(d.nmls_officer_orig, PATINDEX('%dba %', d.nmls_officer_orig), 200), '')
				ELSE d.nmls_officer_orig
				END AS nmls_officer_orig_p
		INTO [Lien_dtdb].[tmp].[NMLS_Info_lenders_2]
		FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders_1] d
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--
	-- remove keywords from names
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_lenders_3]
		SELECT d.doc_id
			,d.fips_code
			,d.cmt_docnumber
			,d.Lender_name
			,d.nmls_company1_orig
			,d.nmls_company2_orig
			,d.nmls_officer_orig
			,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Lender_name_p, CHAR(10), ''), CHAR(13), ''), 'National Association', 'NA'), 'N.A.', 'NA'), '(NMLS', ''), 'Corporation', 'CORP'), 'Mortgage', 'MTG'), 'D/B/A', ''), 'D/B/', ''), 'Company', '') AS Lender_name_p
			,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(nmls_company1_orig_p, CHAR(10), ''), CHAR(13), ''), 'National Association', 'NA'), 'N.A.', 'NA'), '(NMLS', ''), 'Corporation', 'CORP'), 'Mortgage', 'MTG'), 'D/B/A', ''), 'D/B/', ''), 'Company', '') AS nmls_company1_orig_p
			,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(nmls_company2_orig_p, CHAR(10), ''), CHAR(13), ''), 'National Association', 'NA'), 'N.A.', 'NA'), '(NMLS', ''), 'Corporation', 'CORP'), 'Mortgage', 'MTG'), 'D/B/A', ''), 'D/B/', ''), 'Company', '') AS nmls_company2_orig_p
			,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(nmls_officer_orig_p, CHAR(10), ''), CHAR(13), ''), 'National Association', 'NA'), 'N.A.', 'NA'), '(NMLS', ''), 'Corporation', 'CORP'), 'Mortgage', 'MTG'), 'D/B/A', ''), 'D/B/', ''), 'Company', '') AS nmls_officer_orig_p
		INTO [Lien_dtdb].[tmp].[NMLS_Info_lenders_3]
		FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders_2] d
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--
	-- Remove spaces and special characters from name_p
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_Info_lenders]
		SELECT d.doc_id
			,d.fips_code
			,d.cmt_docnumber
			,d.Lender_name
			,d.nmls_company1_orig
			,d.nmls_company2_orig
			,d.nmls_officer_orig
			,[SPDB].[dbo].[RegexReplace](Lender_name_p, '(\/| |-|\.|,|$|%|&|!)', '', 0) AS Lender_name_p
			,[SPDB].[dbo].[RegexReplace](nmls_company1_orig_p, '(\/| |-|\.|,|$|%|&|!)', '', 0) AS nmls_company1_orig_p
			,[SPDB].[dbo].[RegexReplace](nmls_company2_orig_p, '(\/| |-|\.|,|$|%|&|!)', '', 0) AS nmls_company2_orig_p
			,[SPDB].[dbo].[RegexReplace](nmls_officer_orig_p, '(\/| |-|\.|,|$|%|&|!)', '', 0) AS nmls_officer_orig_p
		INTO [Lien_dtdb].[tmp].[NMLS_Info_lenders]
		FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders_3] d
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_DocId ON [Lien_dtdb].[tmp].[NMLS_Info_lenders] (Doc_id) include (
		lender_name
		,lender_name_p
		)

	--
	-- Pivot the test data
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_document_pivot]
		SELECT a.doc_id
			,a.fips_code
			,a.cmt_docnumber
			,c.*
		INTO [Lien_dtdb].[tmp].[NMLS_document_pivot]
		--select top 10 * 
		FROM [Lien_dtdb].[tmp].[NMLS_Info] a WITH (
				NOLOCK
				,INDEX (idx_Doc_Id)
				)
		--inner join Lien_dtdb.tmp.NMLS_Info_lenders b with(nolock,index(idx_DocId)) on b.doc_id = a.doc_id
		OUTER APPLY (
			SELECT 'nmls1' AS _nmls
				,a.nmls_company1_orig
				,(
					SELECT TOP 1 b.nmls_company1_orig_p
					FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders] b WITH (
							NOLOCK
							,INDEX (idx_DocId)
							)
					WHERE b.doc_id = a.doc_id
					) AS nmls_company1_orig_p
				--,b.nmls_company1_orig_p as nmls_company1_orig_p
				,try_cast(a.nmls_company1_id_orig AS INT) AS nmls_company1_id_orig
			
			UNION ALL
			
			SELECT 'nmls2' AS _nmls
				,a.nmls_company2_orig
				,(
					SELECT TOP 1 b.nmls_company2_orig_p
					--select top 10 * 
					FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders] b WITH (
							NOLOCK
							,INDEX (idx_DocId)
							)
					WHERE b.doc_id = a.doc_id
					) AS nmls_company1_orig_p
				--select doc_id , count(1) as cnt from Lien_dtdb.tmp.NMLS_Info_lenders
				--group by doc_id
				--having count(1) > 1
				--,b.nmls_company2_orig_p as nmls_company1_orig_p
				,try_cast(a.nmls_company2_id_orig AS INT) AS nmls_company2_id_orig
			
			UNION ALL
			
			SELECT 'agent' AS _nmls
				,a.nmls_officer_orig
				,(
					SELECT TOP 1 b.nmls_officer_orig_p
					FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders] b WITH (
							NOLOCK
							,INDEX (idx_DocId)
							)
					WHERE b.doc_id = a.doc_id
					) AS nmls_company1_orig_p
				--,b.nmls_officer_id_orig_p as nmls_company1_orig_p
				,try_cast(a.nmls_officer_id_orig AS INT) AS nmls_officer_id_orig
			) c
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	-- 
	-- Update Pivot table with correct name and code pairs
	--
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company1_id_orig = b.NMLSLenderId_out
	FROM [Lien_dtdb].[tmp].[NMLS_document_pivot] a
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE b.doc_id = a.doc_id
			AND b.NMLSLenderName_out = a.nmls_company1_orig
			AND b._from IN (
				'idc'
				,'nmc'
				)
		ORDER BY _from
		) b
	WHERE b.doc_id IS NOT NULL

	UPDATE [Lien].[UR].[a]
	SET a.nmls_company1_orig = b.NMLSLenderName_out
		,a.nmls_company1_orig_p = b.NMLSLenderName_out_p
		,a.nmls_company1_id_orig = b.NMLSLenderId_out
	FROM [Lien_dtdb].[tmp].[NMLS_document_pivot] a
	OUTER APPLY (
		SELECT *
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE b.doc_id = a.doc_id
			AND b._from = 'idi'
		) b
	WHERE a._nmls = 'agent'
		AND a.nmls_company1_orig IS NULL
		AND b.NMLSLenderName_out IS NOT NULL
		AND isnull(a.nmls_company1_id_orig, 0) <> isnull(b.NMLSLenderId_out, 0)

	-- select * from  Lien_dtdb.tmp.NMLS_document_pivot
	--
	-- Set On_comp_tbl, On_Indiv_tbl , lndr and lender_conf and create table  Lien_dtdb.tmp.NMLS_document_lookup_results
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_document_lookup_results]
		SELECT a.*
			,'ni1' AS _ni1
			,ni1.*
			,'ni2' AS _ni2
			,ni2.*
			,'L' AS _l
			,l.*
			,'lndr' AS _lndr
			,lndr.*
		INTO [Lien_dtdb].[tmp].[NMLS_document_lookup_results]
		FROM [Lien_dtdb].[tmp].[NMLS_document_pivot] a
		OUTER APPLY (
			SELECT TOP 1 1 AS On_comp_tbl
				,NMLSLenderName_out
			FROM [Lien].[nmls].[NMLS_OCR_Company] ni1 WITH (
					NOLOCK
					,INDEX (idx_NMLSLenderId_in)
					)
			WHERE ni1.NMLSLenderId_in = a.nmls_company1_id_orig
				--AND ni1.NMLSLenderName_in = a.nmls_company1_orig --????????????????????????????????????????? marie is this ok
			) ni1
		OUTER APPLY (
			SELECT TOP 1 1 AS On_Indiv_tbl
				,NMLSAgentName_out
			FROM [Lien].[nmls].[NMLS_OCR_Individual] ni2 WITH (
					NOLOCK
					,INDEX (idx_NMLSAgentId_in)
					)
			WHERE ni2.NMLSAgentId_in = a.nmls_company1_id_orig
				--AND ni2.NMLSAgentName_in = a.nmls_company1_orig  --????????????????????????????????????????? marie is this ok
			) ni2
		OUTER APPLY (
			SELECT TOP 1 1 AS lndr
				,*
			FROM [lien].[dbo].[lender_cleanup] l WITH (
					NOLOCK
					,INDEX (idx_name)
					)
			WHERE l.name = a.nmls_company1_orig
				AND l.type = 'company'
			) l
		OUTER APPLY (
			SELECT TOP 1 nl.lender_name
				,nl.Lender_Name_p
				,CASE 
					WHEN a.nmls_company1_orig_p = nl.Lender_Name_p
						THEN 1
					ELSE 0
					END lender_conf
			-- we should take the std name
			FROM [Lien_dtdb].[tmp].[NMLS_Info_lenders] nl WITH (
					NOLOCK
					,INDEX (idx_DocId)
					)
			WHERE nl.doc_id = a.doc_id
			) lndr
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--
	-- sort results to determine nmls 1, 2 and agent
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_document_lookup_results_order]
		SELECT b.sort_seq
			--,a.lndr as lndr_paul
			--,case when lndr = 1 and On_comp_tbl = 1 then 1
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY b.sort_seq
					,CASE 
						WHEN _nmls = 'nmls1'
							THEN 1
						WHEN _nmls = 'nmls2'
							THEN 2
						ELSE 3
						END
				) AS update_seq
			,a.*
		INTO [Lien_dtdb].[tmp].[NMLS_document_lookup_results_order]
		FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results] a
		OUTER APPLY (
			SELECT CASE 
					--when not (a.nmls_company1_orig is not null or a.nmls_company1_orig_p is not null)
					--	then 200
					WHEN /*isnull(a.lndr, 0) = 1
					AND*/ isnull(a.On_Indiv_tbl, 0) = 0
						AND a.lender_conf = 1
						THEN CASE 
								WHEN a._nmls = 'nmls1'
									THEN 2
								ELSE 5
								END
					WHEN /*isnull(a.lndr, 0) = 1
					AND*/ isnull(a.On_Indiv_tbl, 0) = 0
						AND (
							a.nmls_company1_orig IS NOT NULL
							OR a.nmls_company1_orig_p IS NOT NULL
							)
						THEN CASE 
								WHEN a._nmls = 'nmls1'
									THEN 7
								ELSE 10
								END
					WHEN a._nmls = 'agent'
						AND (
							(
								isnull(a.On_comp_tbl, 0) = 0
								AND isnull(a.On_Indiv_tbl, 0) = 0
								--AND isnull(a.lndr, 0) = 0
								)
							OR isnull(a.On_Indiv_tbl, 0) = 1
							)
						THEN CASE 
								WHEN a._nmls = 'nmls1'
									THEN 104
								ELSE 105
								END
					WHEN isnull(a.On_comp_tbl, 0) = 1
						THEN CASE 
								WHEN a._nmls = 'nmls1'
									THEN 19
								ELSE 20
								END
					WHEN isnull(a.On_Indiv_tbl, 0) = 1
						THEN CASE 
								WHEN a._nmls = 'nmls1'
									THEN 29
								ELSE 30
								END
					ELSE CASE 
							WHEN a._nmls = 'nmls1'
								THEN 98
							ELSE 99
							END
					END AS sort_seq
			) b
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--where a.doc_id = 63412524
	--  select * from Lien_dtdb.tmp.NMLS_document_lookup_results_order where doc_id = 360024787
	--
	-- Unpivot to update
	--
	-- select * from Lien_dtdb.tmp.NMLS_document_lookup_results_order 
	----where On_Indiv_tbl = 1 and nmls_company1_orig <> NMLSAgentName_out
	----where On_comp_tbl = 1 and nmls_company1_orig <> NMLSLenderName_out
	--WHERE doc_id = 349999801
	--
	-- create Unpivot table to be used in Update back Lien.ur.Dcument
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot]
		SELECT doc_id
			,max(CASE 
					WHEN update_seq = 1
						THEN CASE 
								WHEN isnull(On_comp_tbl, 0) = 1
									THEN NMLSLenderName_out
								ELSE nmls_company1_orig
								END
					ELSE NULL
					END) AS nmls_company1
			,max(CASE 
					WHEN update_seq = 1
						THEN nmls_company1_id_orig
					ELSE NULL
					END) AS nmls_company1_id
			,max(CASE 
					WHEN update_seq = 2
						THEN CASE 
								WHEN isnull(On_comp_tbl, 0) = 1
									THEN NMLSLenderName_out
								ELSE nmls_company1_orig
								END
					ELSE NULL
					END) AS nmls_company2
			,max(CASE 
					WHEN update_seq = 2
						THEN nmls_company1_id_orig
					ELSE NULL
					END) AS nmls_company2_id
			,max(CASE 
					WHEN update_seq = 3
						THEN CASE 
								WHEN isnull(On_Indiv_tbl, 0) = 1
									THEN NMLSAgentName_out
								ELSE nmls_company1_orig
								END
					ELSE NULL
					END) AS nmls_officer
			,max(CASE 
					WHEN update_seq = 3
						THEN nmls_company1_id_orig
					ELSE NULL
					END) AS nmls_officer_id
		--,* 
		-- select top 10 * 
		INTO [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot]
		FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_order]
		--WHERE doc_id = 349999801
		GROUP BY doc_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] (doc_id)

	--
	-- remove nmls2 wher exactly same a nmls1
	--
	----SELECT TOP 100 *
	----FROM Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot a
	----SELECT TOP 100 *
	----FROM Lien_dtdb.tmp.NMLS_document_pivot
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company1_id = NULL
	-- select  format(count(*), '##,##0') as cnt
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	OUTER APPLY (
		SELECT NMLSLenderId_out
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b
		WHERE b.doc_id = a.doc_id
			AND b.NMLSLenderName_out = a.nmls_company1
			AND b._col IN (
				'NMLS1'
				,'nmls2'
				)
			AND b._from IN (
				'idc'
				,'idco'
				)
		) b
	WHERE b.NMLSLenderId_out IS NULL

	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2_id = NULL
	-- select  format(count(*), '##,##0') as cnt
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	OUTER APPLY (
		SELECT NMLSLenderId_out
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b
		WHERE b.doc_id = a.doc_id
			AND b.NMLSLenderName_out = a.nmls_company2
			AND b._col IN (
				'NMLS1'
				,'nmls2'
				)
			AND b._from IN (
				'idc'
				,'idco'
				)
		) b
	WHERE b.NMLSLenderId_out IS NULL

	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2 = NULL
		,a.nmls_company2_id = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	WHERE (
			isnull(nmls_company1, '') = isnull(nmls_company2, '')
			AND isnull(nmls_company1_id, 0) = isnull(nmls_company2_id, 0)
			)

	--OR (
	--	isnull(n1.nmls_company1_orig_p, '') = isnull(n2.nmls_company1_orig_p, '')
	--	AND isnull(a.nmls_company1_id, 0) = isnull(a.nmls_company2_id, 0)
	--	AND isnull(a.nmls_company1, '') > ''
	--	AND isnull(a.nmls_company2, '') > ''
	--	)
	UPDATE [Lien].[UR].[a]
	SET a.nmls_company2 = NULL
		,a.nmls_company2_id = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	WHERE a.nmls_company2 = a.nmls_officer
		AND a.nmls_company2_id = a.nmls_officer_id
		AND nmls_company2_id IN (
			SELECT NMLSLenderId_out
			FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b
			WHERE b.doc_id = a.doc_id
				AND b._col = 'agent'
				AND b._from IN (
					'nmi'
					,'idi'
					,'idio'
					)
			)

	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer = NULL
		,a.nmls_officer_id = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	WHERE a.nmls_company2 = a.nmls_officer
		AND a.nmls_company2_id = a.nmls_officer_id
		AND nmls_officer_id IN (
			SELECT NMLSLenderId_out
			FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b
			WHERE b.doc_id = a.doc_id
				AND b._col IN (
					'NMLS1'
					,'nmls2'
					)
				AND b._from IN (
					'nmc'
					,'idc'
					,'idco'
					)
			)

	UPDATE [Lien].[UR].[a]
	SET a.nmls_officer_id = NULL
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] a
	OUTER APPLY (
		SELECT NMLSLenderId_out
		FROM [Lien_dtdb].[tmp].[NMLS_Info_pairs] b
		WHERE b.doc_id = a.doc_id
			AND b._col IN ('agent')
			AND b._from IN ('nmI')
		) b
	WHERE b.NMLSLenderId_out IS NULL

	/*
	select *  from Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot 
*/
	--
	-- Update results back to Lien.ur.Document
	--
	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[d]
	SET d.NMLS_Company1 = m.NMLS_Company1
		,d.nmls_company1_id = try_cast(m.nmls_company1_id AS VARCHAR)
		,d.nmls_company2 = m.nmls_company2
		,d.nmls_company2_id = try_cast(m.nmls_company2_id AS VARCHAR)
		,d.nmls_Officer = m.nmls_Officer
		,d.nmls_Officer_id = try_cast(m.nmls_Officer_id AS VARCHAR)
	FROM [Lien_dtdb].[tmp].[NMLS_document_lookup_results_Unpivot] m WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			)
	INNER JOIN [Lien].[ur].[Document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = m.Doc_id
	WHERE isnull(d.NMLS_Company1, '') <> isnull(m.NMLS_Company1, '')
		OR isnull(d.nmls_company1_id, '') <> isnull(try_cast(m.nmls_company1_id AS VARCHAR), '')
		OR isnull(d.nmls_company2, '') <> isnull(m.nmls_company2, '')
		OR isnull(d.nmls_company2_id, '') <> isnull(try_cast(m.nmls_company2_id AS VARCHAR), '')
		OR isnull(d.nmls_Officer, '') <> isnull(m.nmls_Officer, '')
		OR isnull(d.nmls_Officer_id, '') <> isnull(try_cast(m.nmls_Officer_id AS VARCHAR), '')

	COMMIT

	/*

	select 'NMLS_Info' as _NMLS_Info ,* from Lien_dtdb.tmp.NMLS_Info where doc_id = 134727702
	select 'NMLS_Info_pairs' as _NMLS_Info_pairs ,* from  Lien_dtdb.tmp.NMLS_Info_pairs where doc_id = 134727702
	select 'NMLS_Info_lenders' as _NMLS_Info_lenders ,* from Lien_dtdb.tmp.NMLS_Info_lenders where doc_id = 134727702
	select 'NMLS_document_pivot' as _NMLS_document_pivot ,* from Lien_dtdb.tmp.NMLS_document_pivot where doc_id = 134727702
	select 'NMLS_document_lookup_results' as _NMLS_document_lookup_results ,* from Lien_dtdb.tmp.NMLS_document_lookup_results where doc_id = 134727702
	select 'NMLS_document_lookup_results_order' as _NMLS_document_lookup_results_order ,* from Lien_dtdb.tmp.NMLS_document_lookup_results_order where doc_id = 134727702
	select top 100 'NMLS_document_lookup_results_Unpivot' as _NMLS_document_lookup_results_Unpivot ,* from Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot  where doc_id = 134727702

*/
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Lien_Post_Capture_NMLS'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
END CATCH
	--DROP TABLE if exists Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot_after
	--select * into Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot_after from Lien_dtdb.tmp.NMLS_document_lookup_results_Unpivot 


