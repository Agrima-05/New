/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | LEAP.AddLeapLog | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
CREATE PROCEDURE [Lien].[LEAP].[AddLeapLog]
	@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [Lien].[LEAP].[LeapLog] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

