/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_Extract_Mortgage_work | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[usp_Extract_Mortgage_work] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change
Marie		1/10/2025	BUG769831 - Hawaii Land Court / Certificate missing Doc Numbers
******************************************************************************************************************/
BEGIN TRY
	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_Extract_Mortgage_work'
		,N'Started'

	--
	--create lien_DTDB.infc.Mortgage_work
	--
	-- create index idx_deedid on [lien_dtdb].[infc].[Mortgage_work] (deedid)
	TRUNCATE TABLE [lien_dtdb].[infc].[Mortgage_work]

	--
	INSERT INTO [lien_dtdb].[infc].[Mortgage_work] (
		[FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[DEED_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		--,[Link]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[UR_REMARKS]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[ORIG_MTG1_Lender_Name]
		,[ORIG_MTG2_Lender_Name]
		,[ORIG_MTG3_Lender_Name]
		,[ORIG_MTG4_Lender_Name]
		,[NMLSLenderName_1]
		,[NMLSLenderId_1]
		,[NMLSBrokerName_1]
		,[NMLSBrokerId_1]
		,[NMLSAgentName_1]
		,[NMLSAgentId_1]
		,[Attorney_Email]
		,[Attorney_Firm_Name]
		,Mtg1_Int_Source
		,Mtg2_Int_Source
		,Mtg3_Int_Source
		,Mtg4_Int_Source
		)
	-- we dont fill these field becase we extract one mortgagw
	--,[NMLSLenderName_2]
	--,[NMLSLenderId_2]
	--,[NMLSBrokerName_2]
	--,[NMLSBrokerId_2]
	--,[NMLSAgentName_2]
	--,[NMLSAgentId_2]
	--,[NMLSLenderName_3]
	--,[NMLSLenderId_3]
	--,[NMLSBrokerName_3]
	--,[NMLSBrokerId_3]
	--,[NMLSAgentName_3]
	--,[NMLSAgentId_3]
	--,[NMLSLenderName_4]
	--,[NMLSLenderId_4]
	--,[NMLSBrokerName_4]
	--,[NMLSBrokerId_4]
	--,[NMLSAgentName_4]
	--,[NMLSAgentId_4]
	SELECT [FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[DEED_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		--,[Link]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[UR_REMARKS]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[ORIG_MTG1_Lender_Name]
		,[ORIG_MTG2_Lender_Name]
		,[ORIG_MTG3_Lender_Name]
		,[ORIG_MTG4_Lender_Name]
		,[NMLSLenderName_1]
		,[NMLSLenderId_1]
		,[NMLSBrokerName_1]
		,[NMLSBrokerId_1]
		,[NMLSAgentName_1]
		,[NMLSAgentId_1]
		--,[NMLSLenderName_2]
		--,[NMLSLenderId_2]
		--,[NMLSBrokerName_2]
		--,[NMLSBrokerId_2]
		--,[NMLSAgentName_2]
		--,[NMLSAgentId_2]
		--,[NMLSLenderName_3]
		--,[NMLSLenderId_3]
		--,[NMLSBrokerName_3]
		--,[NMLSBrokerId_3]
		--,[NMLSAgentName_3]
		--,[NMLSAgentId_3]
		--,[NMLSLenderName_4]
		--,[NMLSLenderId_4]
		--,[NMLSBrokerName_4]
		--,[NMLSBrokerId_4]
		--,[NMLSAgentName_4]
		--,[NMLSAgentId_4]
		,[Attorney_Email]
		,Attorney_Firm_Name
		,Mtg1_Int_Source
		,Mtg2_Int_Source
		,Mtg3_Int_Source
		,Mtg4_Int_Source
	FROM (
		SELECT CASE 
				WHEN isnull(ph.fips, 0) > 0
					THEN ph.fips
				ELSE d1.fips
				END AS Fips
			,ph.Ref_id AS Ref_id
			,substring(d.STATE, 1, 2) AS US_STATE
			,substring(d.county, 1, 36) AS US_COUNTY
			,substring(ph.APN_unformatted, 1, 45) AS APN_unformatted
			,substring(ph.APN_formatted_UNIVERSAL, 1, 60) AS APN_formatted_UNIVERSAL
			,try_cast(ph.APN_SEQUENCE_NBR AS SMALLINT) AS APN_SEQUENCE_NBR
			,substring(ph.ORIGINAL_APN, 1, 45) AS ORIGINAL_APN
			,substring(ph.account_nbr, 1, 15) AS ACCOUNT_NBR
			,CASE 
				WHEN ISNULL(ph.ref_id, 0) = 0
					THEN 'Y'
				ELSE try_cast(NULL AS CHAR(1))
				END AS PENDING_TRANS
			,substring(nb.BYR1_CORP_IND, 1, 1) AS BYR1_CORP_IND
			,substring(nb.BYR1_OWN_NAME, 1, 60) AS BYR1_OWN_NAME
			,substring(nb.BYR1_OWN_ETAL_IND, 1, 1) AS BYR1_OWN_ETAL_IND
			,substring(nb.BYR1_CO_NAME, 1, 60) AS BYR1_CO_NAME
			,substring(nb.BYR1_OWNERSHIP_RIGHTS_CODE, 1, 2) AS BYR1_OWNERSHIP_RIGHTS_CODE
			,substring(nb.BYR1_OWN_RELATIONSHIP_TYPE, 1, 3) AS BYR1_OWN_RELATIONSHIP_TYPE
			,substring(nb.BYR1_OWNERSHIP, 1, 3) AS BYR1_OWNERSHIP
			,substring(nb.BYR2_CORP_IND, 1, 1) AS BYR2_CORP_IND
			,substring(nb.BYR2_OWN_NAME, 1, 60) AS BYR2_OWN_NAME
			,substring(nb.BYR2_OWNERSHIP_RIGHTS_CODE, 1, 2) AS BYR2_OWNERSHIP_RIGHTS_CODE
			,substring(nb.BYR2_OWN_RELATIONSHIP_TYPE, 1, 3) AS BYR2_OWN_RELATIONSHIP_TYPE
			,substring(nb.BYR2_OWNERSHIP, 1, 3) AS BYR2_OWNERSHIP
			,substring(nb.BYR3_CORP_IND, 1, 1) AS BYR3_CORP_IND
			,substring(nb.BYR3_OWN_NAME, 1, 60) AS BYR3_OWN_NAME
			,substring(nb.BYR3_OWNERSHIP_RIGHTS_CODE, 1, 2) AS BYR3_OWNERSHIP_RIGHTS_CODE
			,substring(nb.BYR3_OWN_RELATIONSHIP_TYPE, 1, 3) AS BYR3_OWN_RELATIONSHIP_TYPE
			,substring(nb.BYR3_OWNERSHIP, 1, 3) AS BYR3_OWNERSHIP
			,substring(nb.BYR4_CORP_IND, 1, 1) AS BYR4_CORP_IND
			,substring(nb.BYR4_OWN_NAME, 1, 60) AS BYR4_OWN_NAME
			,substring(nb.BYR4_OWNERSHIP_RIGHTS_CODE, 1, 2) AS BYR4_OWNERSHIP_RIGHTS_CODE
			,substring(nb.BYR4_OWN_RELATIONSHIP_TYPE, 1, 3) AS BYR4_OWN_RELATIONSHIP_TYPE
			,substring(nb.BYR4_OWNERSHIP, 1, 3) AS BYR4_OWNERSHIP
			,substring(Replace(nb.BYR1_LAST_NAME, '  ', ' '), 1, 30) AS BYR1_LAST_NAME
			,substring(nb.BYR1_FIRST_NAME, 1, 32) AS BYR1_FIRST_NAME
			,substring(nb.BYR1_MIDDLE_INITIAL, 1, 12) AS BYR1_MIDDLE_INITIAL
			,substring(nb.BYR1_SUFFIX, 1, 4) AS BYR1_SUFFIX
			,substring(Replace(nb.BYR2_LAST_NAME, '  ', ' '), 1, 30) AS BYR2_LAST_NAME
			,substring(nb.BYR2_FIRST_NAME, 1, 32) AS BYR2_FIRST_NAME
			,substring(nb.BYR2_MIDDLE_INITIAL, 1, 12) AS BYR2_MIDDLE_INITIAL
			,substring(nb.BYR2_SUFFIX, 1, 4) AS BYR2_SUFFIX
			,substring(Replace(nb.BYR3_LAST_NAME, '  ', ' '), 1, 30) AS BYR3_LAST_NAME
			,substring(nb.BYR3_FIRST_NAME, 1, 32) AS BYR3_FIRST_NAME
			,substring(nb.BYR3_MIDDLE_INITIAL, 1, 12) AS BYR3_MIDDLE_INITIAL
			,substring(nb.BYR3_SUFFIX, 1, 4) AS BYR3_SUFFIX
			,substring(Replace(nb.BYR4_LAST_NAME, '  ', ' '), 1, 30) AS BYR4_LAST_NAME
			,substring(nb.BYR4_FIRST_NAME, 1, 32) AS BYR4_FIRST_NAME
			,substring(nb.BYR4_MIDDLE_INITIAL, 1, 12) AS BYR4_MIDDLE_INITIAL
			,substring(nb.BYR4_SUFFIX, 1, 4) BYR4_SUFFIX
			--
			-- We need to borrow the mail address from the situs
			--
			----,nb.mA_HOUSE_NBR_PREFIX_1 AS MA_HOUSE_NBR_PREFIX
			----,substring(nb.mA_HOUSE_NBR_1, 1, 10) AS MA_HOUSE_NBR
			----,substring(nb.mA_HOUSE_NBR_SUFFIX_1, 1, 5) AS MA_HOUSE_NBR_SUFFIX
			----,nb.mA_STREET_DIRECTION_1 AS MA_STREET_DIRECTION
			----,substring(nb.mA_STREET_NAME_1, 1, 30) AS MA_STREET_NAME
			----,nb.mA_MODE_1 AS MA_MODE
			----,nb.mA_QUADRANT_1 AS MA_QUADRANT
			----,substring(nb.mA_APARTMENT_UNIT_1, 1, 6) AS MA_APARTMENT_UNIT
			----,substring(nb.mA_CITY_1, 1, 40) AS MA_CITY
			----,nb.mA_STATE_1 AS MA_STATE
			----,substring(nb.mA_ZIP_CODE_1, 1, 9) AS MA_ZIP_CODE
			----,nb.mA_CARRIER_CODE_1 AS MA_CARRIER_CODE
			----,substring(nb.mA_ORIGINAL_MAILING_ADDRESS_1, 1, 60) AS MA_ORIGINAL_MAILING_ADDRESS
			----,nb.mA_DO_NOT_PUBLISH_FLAG_1 AS MA_DO_NOT_PUBLISH_FLAG
			,substring(nba.MA_HOUSE_NBR_PREFIX_1, 1, 5) AS MA_HOUSE_NBR_PREFIX
			,substring(CASE 
					WHEN nba.mA_HOUSE_NBR_1 > ''
						THEN nba.mA_HOUSE_NBR_1
					WHEN nba.mA_HOUSE_NBR_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN ph.SITUS_HOUSE_NBR
					ELSE NULL
					END, 1, 10) AS MA_HOUSE_NBR
			,substring(nba.MA_HOUSE_NBR_SUFFIX_1, 1, 5) AS MA_HOUSE_NBR_SUFFIX
			,substring(CASE 
					WHEN nba.mA_STREET_DIRECTION_1 > ''
						THEN UPPER(LTRIM(RTRIM(substring(nb.mA_STREET_DIRECTION_1, 1, 2))))
					WHEN nba.mA_STREET_DIRECTION_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_DIRECTION, 1, 2)
					ELSE NULL
					END, 1, 2) AS MA_STREET_DIRECTION
			,substring(CASE 
					WHEN substring(nba.mA_STREET_NAME_1, 1, 30) > ''
						THEN substring(nba.mA_STREET_NAME_1, 1, 30)
					WHEN substring(nba.mA_STREET_NAME_1, 1, 30) = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_STREET_NAME, 1, 30)
					ELSE NULL
					END, 1, 30) AS MA_STREET_NAME
			,substring(CASE 
					WHEN nba.mA_MODE_1 > ''
						THEN substring(nba.mA_MODE_1, 1, 5)
					WHEN nba.mA_MODE_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_MODE, 1, 5)
					ELSE NULL
					END, 1, 5) AS MA_MODE
			,substring(CASE 
					WHEN nba.mA_QUADRANT_1 > ''
						THEN substring(nba.mA_QUADRANT_1, 1, 2)
					WHEN nba.mA_QUADRANT_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_POST_DIRECTION, 1, 2)
					ELSE NULL
					END, 1, 2) AS MA_QUADRANT
			,substring(CASE 
					WHEN substring(nba.mA_APARTMENT_UNIT_1, 1, 11) > ''
						THEN substring(nba.mA_APARTMENT_UNIT_1, 1, 11)
					WHEN substring(nba.mA_APARTMENT_UNIT_1, 1, 11) = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_UNIT_NBR, 1, 11)
					ELSE NULL
					END, 1, 11) AS MA_APARTMENT_UNIT
			,substring(CASE 
					WHEN nba.mA_CITY_1 > ''
						THEN nba.mA_CITY_1
					WHEN nba.mA_CITY_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN ph.SITUS_CITY
					ELSE NULL
					END, 1, 40) AS MA_CITY
			,substring(CASE 
					WHEN nba.mA_STATE_1 > ''
						THEN substring(nba.mA_STATE_1, 1, 2)
					WHEN nba.mA_STATE_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_STATE, 1, 2)
					ELSE NULL
					END, 1, 2) AS MA_STATE
			,substring(CASE 
					WHEN substring(nba.mA_ZIP_CODE_1, 1, 9) > ''
						THEN substring(nba.mA_ZIP_CODE_1, 1, 9)
					WHEN substring(nba.mA_ZIP_CODE_1, 1, 9) = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_ZIP_CODE, 1, 9)
					ELSE NULL
					END, 1, 9) AS MA_ZIP_CODE
			,substring(CASE 
					WHEN nba.mA_CARRIER_CODE_1 > ''
						THEN substring(nba.mA_CARRIER_CODE_1, 1, 4)
					WHEN nba.mA_CARRIER_CODE_1 = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.SITUS_CARRIER_CODE, 1, 4)
					ELSE NULL
					END, 1, 4) AS MA_CARRIER_CODE
			,substring(CASE 
					WHEN substring(nba.mA_ORIGINAL_MAILING_ADDRESS_1, 1, 60) > ''
						THEN substring(nba.mA_ORIGINAL_MAILING_ADDRESS_1, 1, 60)
					WHEN substring(nba.mA_ORIGINAL_MAILING_ADDRESS_1, 1, 60) = ''
						AND nba.address_same_as_property_address_flag_1 = 'Y'
						THEN substring(ph.ORIGINAL_SITE_ADDRESS, 1, 60)
					ELSE NULL
					END, 1, 60) AS MA_ORIGINAL_MAILING_ADDRESS
			,'' AS MA_DO_NOT_PUBLISH_FLAG
			--
			,substring(ph.SITUS_HOUSE_NBR, 1, 10) AS SITUS_HOUSE_NBR
			,substring(ph.SITUS_HOUSE_NBR2, 1, 10) AS SITUS_HOUSE_NBR2
			,substring(ph.SITUS_HOUSE_NBR_SUFFIX, 1, 10) AS SITUS_HOUSE_NBR_SUFFIX
			,substring(ph.SITUS_DIRECTION, 1, 2) AS SITUS_DIRECTION
			,substring(ph.SITUS_STREET_NAME, 1, 30) AS SITUS_STREET_NAME
			,substring(ph.SITUS_MODE, 1, 5) AS SITUS_MODE
			,substring(ph.SITUS_POST_DIRECTION, 1, 2) AS SITUS_POST_DIRECTION
			,substring(ph.SITUS_UNIT_NBR, 1, 11) AS SITUS_UNIT_NBR
			,substring(ph.SITUS_CITY, 1, 40) AS SITUS_CITY
			,substring(ph.SITUS_STATE, 1, 2) AS SITUS_STATE
			,substring(ph.SITUS_ZIP_CODE, 1, 9) AS SITUS_ZIP_CODE
			,substring(ph.SITUS_CARRIER_CODE, 1, 4) AS SITUS_CARRIER_CODE
			,substring(ph.ORIGINAL_SITE_ADDRESS, 1, 60) AS ORIGINAL_SITE_ADDRESS
			,NULL AS CLGX_UNIQUE_ID
			,d1.recording_date AS RECORDING_DATE
			--,d1.doc_date AS SALE_DATE
			-- B32463 Marie
			------,CASE 
			------	WHEN d1.doc_date IS NOT NULL
			------		THEN d1.Doc_date
			------	ELSE d1.Doc_Signed_date IS NOT NULL
			------	END AS SALE_DATE -- Marie Added 2024/08/21
			,CASE 
				WHEN d1.doc_date IS NOT NULL
					AND d1.Doc_date <= d1.Recording_date --- B32463 Marie
					THEN d1.Doc_date
				ELSE CASE 
						WHEN d1.Doc_Signed_date IS NOT NULL
							AND d1.Doc_Signed_date <= d1.Recording_date
							THEN d1.Doc_Signed_date
						END
				END AS SALE_DATE -- Marie Added 2024/08/21
			,d1._Recording_doc_number AS DOC_NBR
			,d1._Recording_book AS RECORDING_BOOK
			,d1._Recording_Page AS RECORDING_PAGE
			,substring(d.HAWAII_LAND_COURT_DOC_NBR, 1, 12) AS HAWAII_LAND_COURT_DOC_NBR
			,substring(d.HAWAII_TCT_CERTIFICATE_NBR, 1, 12) AS HAWAII_TCT_CERTIFICATE_NBR
			,NULL AS WA_EXCISE_NBR
			,substring(dt.DEED_TYPE, 1, 1) AS DEED_TYPE
			,substring(d1.DETAILED_DOC_TYPE, 1, 2) AS DETAILED_DOC_TYPE
			,NULL AS TRANSACTION_TYPE
			,substring(ns.SELLER_NAME_PLAINTIFF_1, 1, 60) AS SELLER_NAME_PLAINTIFF_1
			,substring(ns.SELLER_NAME_PLAINTIFF1_CORP_IND, 1, 1) AS SELLER_NAME_PLAINTIFF1_CORP_IND
			,substring(ns.SELLER_NAME_PLAINTIFF_2, 1, 60) AS SELLER_NAME_PLAINTIFF_2
			,substring(ns.SELLER_NAME_PLAINTIFF_2_CORP_IND, 1, 1) AS SELLER_NAME_PLAINTIFF_2_CORP_IND
			--,try_cast(d1.SALE_AMOUNT AS DECIMAL(13, 2)) AS SALE_AMOUNT
			,try_cast(NULL AS DECIMAL(13, 2)) AS SALE_AMOUNT
			,try_cast(d1.DOC_TRANSFER_TAX AS DECIMAL(13, 2)) AS DOC_TRANSFER_TAX
			,NULL AS SALE_CODE
			,NULL AS PARTIAL_INTEREST_IND
			--,CASE
			--	WHEN rider_construction_loan_flag = 'Y'
			--		THEN 'N'
			--	ELSE NULL
			--	END AS RESALE_NEW_CONSTRUCTION
			,NULL AS RESALE_NEW_CONSTRUCTION
			,NULL AS INTER_FAMILY
			,NULL AS FORCLOSURE
			,NULL AS REO_SALE
			,d1.recording_date AS MTG1_RECORDING_DATE
			--,d1.doc_date AS MTG1_DOC_DATE
			,CASE 
				WHEN d1.doc_date IS NOT NULL
					THEN d1.Doc_date
				ELSE d1.Doc_Signed_date
				END AS MTG1_DOC_DATE -- Marie Added 2024/08/21
			,d1._Recording_doc_number AS MTG1_DOC_NBR
			,d1._Recording_book AS MTG1_RECORDING_BOOK
			,d1._Recording_Page AS MTG1_RECORDING_PAGE
			,substring(d1.DETAILED_DOC_TYPE, 1, 2) AS MTG1_DETAILED_DOC_TYPE
			,CASE 
				WHEN ISNULL(d.loan_financed_amount, 0) = 0
					THEN FLOOR(d.loan_maximum_amount_credit_limit)
				ELSE FLOOR(d.loan_financed_amount)
				END AS MTG1_MTG_AMOUNT
			,substring(nl.BYR1_LAST_NAME, 1, 30) AS MTG1_LENDER_LAST_NAME
			,substring(nl.BYR1_FIRST_NAME, 1, 30) AS MTG1_LENDER_FIRST_NAME
			,substring(nl.address_1, 1, 60) AS MTG1_LENDER_ADDRESS
			,substring(nl.address_city_name_1, 1, 30) AS MTG1_LENDER_CITY
			,substring(nl.address_state_name_1, 1, 2) AS MTG1_LENDER_STATE
			,substring(nl.address_zip_code_1, 1, 9) AS MTG1_LENDER_ZIP
			,NULL AS MTG1_MTG_COMPANY_CODE ---------------????????????????????
			--,substring(CASE
			--		WHEN isnull(d2.MTG1_MTG_INTEREST_RATE_TYPE, '') = 'bal'
			--			THEN NULL
			--		ELSE d1.loan_type
			--		END, 1, 3) AS MTG1_MTG_LOAN_TYPE_CODE
			,d1.loan_type AS MTG1_MTG_LOAN_TYPE_CODE
			,CASE 
				WHEN d1.date_of_loan_maturity <> ''
					THEN 'Y'
				ELSE ''
				END AS MTG1_MTG_TERM_CODE
			--,case when d1.date_of_loan_maturity is not null and  d.recording_date_d is not null
			--then try_cast(datepart(year,d1.date_of_loan_maturity) - datepart(year, d.recording_date_d)as char(4))
			--else null end as MTG1_MTG_TERM_
			,substring(d1.MTG1_MTG_TERM_, 1, 4) AS MTG1_MTG_TERM_
			,d1.date_of_loan_maturity AS MTG1_MTG_DUE_DATE
			,d2.MTG1_MTG_INTEREST_RATE_TYPE AS MTG1_MTG_INTEREST_RATE_TYPE
			--,SPDB.dbo.RegexExtract(right(try_cast(FORMAT(try_Cast(d.Loan_Interest_Rate AS DECIMAL(7, 4)), '00.0000') AS VARCHAR), 7), '([^0]+.*)', '1', 0) AS MTG1_MTG_INTEREST_RATE
			,CASE 
				WHEN try_Cast(d.Loan_Interest_Rate AS DECIMAL(7, 4)) = 0.0000
					OR LEN(try_Cast(d.Loan_Interest_Rate AS DECIMAL(7, 4))) > 7
					THEN NULL
				ELSE try_Cast(d.Loan_Interest_Rate AS DECIMAL(7, 4))
				END AS MTG1_MTG_INTEREST_RATE
			,NULL AS MTG1_SELLER_CARRY_BACK -- Calculated Column
			,CASE 
				WHEN /*nl.BYR1_FIRST_NAME <> ''
					OR*/ nl.name_identifier_1 IN (
						'T'
						,'I'
						)
					THEN 'Y'
				ELSE ''
				END AS MTG1_PRIVATE_PARTY_LENDER
			,substring(d1.MTG1_CONSTRUCTION_LOAN, 1, 1) AS MTG1_CONSTRUCTION_LOAN
			,CASE 
				WHEN d.doc_type IN (
						'DOT2'
						,'DOT2WFX'
						,'MTG2'
						,'MTG2WFX'
						,'DTM2'
						,'DOT3'
						,'MTG3'
						)
					THEN NULL
				WHEN d.loan_type IN (
						'A'
						,'MA'
						,'FA'
						,'HA'
						,'VA'
						,'RA'
						)
					AND d.recording_date_d < '2019-01-01'
					THEN 'Y'
				ELSE NULL
				END AS MTG1_REFI_FLAG
			,CASE 
				WHEN d.loan_type IN (
						'R'
						,'MR'
						,'FR'
						,'HR'
						,'VR'
						--,'S'
						--,'FS'
						)
					OR d.loan_type LIKE '%s%'
					OR d1.DETAILED_DOC_TYPE = 'EQ'
					THEN 'Y'
				ELSE ''
				END AS MTG1_EQUITY_FLAG
			,CASE 
				WHEN d.rider_request_for_notice_flag <> ''
					THEN d.rider_request_for_notice_flag
				WHEN d.doc_type IN (
						'DOT2'
						,'DOT2WFX'
						,'MTG2'
						,'MTG2WFX'
						,'DTM2'
						,'DOT3'
						,'MTG3'
						)
					THEN 'Y'
				ELSE ''
				END AS MTG1_OTHER_SUBORDINATE_LOANS
			---
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,(
				SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](r.reference_recording_date)
				) AS ORIGINAL_RECORDED_DATE
			--,r.reference_recording_date AS ORIGINAL_RECORDED_DATE
			,CASE 
				WHEN isnull(r.reference_book, '') <> ''
					AND isnull(r.reference_page, '') <> ''
					THEN RIGHT('00000' + r.reference_book, 6) + RIGHT('000000' + r.reference_page, 6)
				ELSE ''
				END AS ORIGINAL_BKPG
			--,r.reference_doc_number AS ORIGINAL_DOC_NBR
			,CASE 
				WHEN isnull(r.reference_doc_number, '') <> ''
					THEN RIGHT('000000000000' + r.reference_doc_number, 12)
				END AS ORIGINAL_DOC_NBR
			,substring(ph.legal_desc_str_section, 1, 3) AS SECTION
			,substring(ph.legal_desc_str_township, 1, 3) AS TOWNSHIP
			,substring(ph.legal_desc_str_range, 1, 3) AS RANGE
			,substring(ph.legal_desc_district, 1, 8) AS DISTRICT_CODE
			,REPLACE(substring(ph.legal_desc_map_lot_low, 1, 6), ' ', '') AS LOT
			,substring(ph.legal_desc_map_block, 1, 6) AS BLOCK
			,substring(ph.legal_desc_map_plat_name, 1, 60) AS SUBDIVISION_NAME
			,REPLACE(substring(legal_desc_map_unit_low, 1, 20), ' ', '') AS UNIT
			,substring(ph.legal_desc_map_building, 1, 8) AS BUILDING
			,substring(ph.legal_desc_map_plat_book, 1, 6) AS PLAT_SUBD_MAP_BOOK
			,substring(ph.legal_desc_map_plat_page, 1, 6) AS PLAT_SUBD_MAP_PAGE
			,substring(ph.legal_desc_map_plat_type_indicator, 1, 3) AS MAP_TYPE_IND
			,substring(d.legal_desc_blob, 1, 250) AS EXPANDED_LEGAL
			,substring(ph.legal_desc_map_plat_number, 1, 30) AS TRACT_NBR
			--,REPLACE(ph.legal_desc_map_lot_low, ' ', '') AS LAND_LOT ------------- we commented this out because we can not find it populated anywhere
			,NULL AS LAND_LOT
			,substring(d.TITLE_COMPANY_NAME, 1, 60) AS TITLE_COMPANY_NAME
			,NULL AS TITLE_COMPANY_CODE
			,substring(ph.multi_apn, 1, 1) AS multi_apn
			,NULL AS SALES_SOURCE_IND
			,NULL AS TIMESTAMP_DATE
			,NULL AS RECORD_TYPE
			,NULL AS PRI_CAT_CODE
			,NULL AS CREATED
			,substring(ph.PREVIOUS_PARCEL_NBR, 1, 45) AS PREVIOUS_PARCEL_NBR
			,ph.PREVIOUS_PARCEL_SEQUENCE_NBR AS PREVIOUS_PARCEL_SEQUENCE_NBR
			,substring(d1.FMT_DOC_NBR, 1, 20) AS FMT_DOC_NBR
			,d1.CMT_ID_DOC_NBR
			,substring(d1.FMT_DOC_NBR, 1, 20) AS FMT_MTG1_DOC_NBR
			,d1.CMT_ID_DOC_NBR AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,substring(d1.FMT_Book_Page, 1, 20) AS FMT_Book_Page
			,d1.CMT_ID_Book_Page AS CMT_ID_Book_Page
			,substring(d1.FMT_Book_Page, 1, 20) AS FMT_MTG1_Book_Page
			,d1.CMT_ID_Book_Page AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,CASE 
				WHEN d.source = 'EPR'
					THEN 'E'
				WHEN d.source = 'REDX'
					THEN 'M'
				END AS Source_type
			,CASE 
				WHEN d.source = 'EPR'
					THEN 'EPM'
				WHEN d.source = 'REDX'
					THEN 'MDM'
				END AS SRC_TBL
			,NULL AS MOD_RAS_CLGX_UNIQUE_ID
			,substring(d.Doc_Unique_Id, 1, 200) AS UR_Doc_Unique_Id
			,d.Doc_Id AS UR_Doc_Id
			,NULL AS UR_Property_Id
			,coalesce(nb.Name_id_1, ns.Name_id_1) AS UR_Name_Id
			,r.reference_id AS UR_Reference_Id
			,NULL AS FORECLOSURE_FLAG
			,NULL AS REO_SALE_FLAG
			,NULL AS ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,substring(d1.DATA_SRC_IND, 1, 1) AS DATA_SRC_IND
			,ph.property_id_sequence_number AS UR_Prop_Seq_Num
			,d.reprocess_flag AS UR_Reprocess_Flag
			,substring(d.requested_prepared_by_attorney_name_identifier, 1, 1) AS Attorney_Name_identifier
			,substring(d.requested_prepared_by_Attorney_Last_Company_Name, 1, 60) AS Attorney_Last_Name
			,substring(d.requested_prepared_by_attorney_first_name, 1, 32) AS Attorney_First_Name
			,substring(d.requested_prepared_by_attorney_middle_initial, 1, 30) AS Attorney_Middle_Initial
			,substring(d.requested_prepared_by_attorney_suffix, 1, 5) AS Attorney_suffix
			,substring(d.requested_prepared_by_attorney_address, 1, 60) AS Attorney_address
			,substring(d.requested_prepared_by_attorney_address_city, 1, 30) AS Attorney_Address_City
			,substring(d.requested_prepared_by_attorney_address_state, 1, 4) AS Attorney_Address_State
			,substring(d.requested_prepared_by_attorney_address_zip, 1, 9) AS Attorney_Address_Zip
			,substring(d.requested_prepared_by_attorney_phone, 1, 15) AS Attorney_Phone
			--,substring(CASE 
			--		WHEN d.requested_prepared_by_attorney_name_identifier = 'C'
			--			----THEN requested_prepared_by_Attorney_Last_Company_Name
			--			THEN ltrim(d.Attorney_Firm_Name)
			--		ELSE requested_prepared_by_attorney_first_name + ' ' + requested_prepared_by_attorney_middle_initial + ' ' + requested_prepared_by_Attorney_Last_Company_Name + ' ' + requested_prepared_by_attorney_suffix
			--		END, 1, 60) AS Attorney_Full_Name
			,rtrim(replace(substring(CASE 
							--WHEN d.requested_prepared_by_attorney_name_identifier = 'C'
							--	--THEN ltrim(requested_prepared_by_attorney_last_company_name)
							--	THEN ltrim(d.Attorney_Firm_Name)
							WHEN d.requested_prepared_by_attorney_name_identifier = 'I'
								THEN ltrim(requested_prepared_by_attorney_first_name + ' ' + requested_prepared_by_attorney_middle_initial + ' ' + requested_prepared_by_attorney_last_company_name + ' ' + requested_prepared_by_attorney_suffix)
							ELSE NULL
							END, 1, 60), '  ', ' ')) AS Attorney_Full_Name
			,substring(d.Remarks, 1, 200) AS UR_REMARKS
			,substring(nl.orig_Mtg_Lender_Name_1, 1, 30) AS ORIG_MTG1_Lender_Name
			,NULL AS ORIG_MTG2_Lender_Name
			,NULL AS ORIG_MTG3_Lender_Name
			,NULL AS ORIG_MTG4_Lender_Name
			,0 AS ORIG_DEEDid
			,'New' AS Actions_reason
			,substring(nmls_company1, 1, 200) AS NMLSLenderName_1
			--,try_cast(nmls_company1_id as int) AS NMLSLenderId_1
			,CASE 
				WHEN try_cast(nmls_company1_id AS INT) IS NULL
					THEN ''
				ELSE nmls_company1_id
				END AS NMLSLenderId_1
			,substring(nmls_company2, 1, 200) AS NMLSBrokerName_1
			--,try_cast(nmls_company2_id as int) AS NMLSBrokerId_1
			,CASE 
				WHEN try_cast(nmls_company2_id AS INT) IS NULL
					THEN ''
				ELSE nmls_company2_id
				END AS NMLSBrokerId_1
			,substring(nmls_officer, 1, 200) AS NMLSAgentName_1
			--,try_cast(nmls_officer_id as int) AS NMLSAgentId_1
			,CASE 
				WHEN try_cast(nmls_officer_id AS INT) IS NULL
					THEN ''
				ELSE nmls_officer_id
				END AS NMLSAgentId_1
			,substring(d.requested_prepared_by_attorney_email, 1, 100) AS Attorney_Email
			,substring(d.Attorney_Firm_Name, 1, 60) AS Attorney_Firm_Name
			--,CASE 
			--	WHEN d.MTG1_MTG_INTEREST_RATE IS NOT NULL
			--		THEN 'PER DOC'
			--	ELSE NULL
			--	END AS Mtg1_Int_Source
			,CASE 
				WHEN d.Loan_Interest_Rate > 0
					THEN 'PER DOC'
				ELSE NULL
				END AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[tmp].[Document_ISNULL] d
		INNER JOIN [lien_dtdb].[tmp].[prop_name_cnt] v ON v.doc_id = d.doc_id
		INNER JOIN [lien_DTDB].[infc].[Document_DTDB_Transform_columns] d1 ON d1.doc_id = d.doc_id
		LEFT JOIN [lien_dtdb].[infc].[deed_buyer_names_pivot] nb ON nb.doc_id = d.doc_id
		OUTER APPLY (
			--SELECT TOP 1 a.*
			--FROM lien_dtdb.infc.deed_buyer_names_pivot nba
			--OUTER APPLY (
			SELECT TOP 1 b.*
			FROM (
				SELECT MA_HOUSE_NBR_PREFIX_1
					,MA_HOUSE_NBR_1
					,MA_HOUSE_NBR_SUFFIX_1
					,MA_STREET_DIRECTION_1
					,MA_STREET_NAME_1
					,MA_MODE_1
					,MA_QUADRANT_1
					,MA_APARTMENT_UNIT_1
					,MA_CITY_1
					,MA_STATE_1
					,MA_ZIP_CODE_1
					,MA_CARRIER_CODE_1
					,MA_ORIGINAL_MAILING_ADDRESS_1
					,MA_DO_NOT_PUBLISH_FLAG_1
					,address_same_as_property_address_flag_1
					,1 AS _seq
				WHERE MA_HOUSE_NBR_1 > ''
					OR MA_STREET_NAME_1 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_2
					,MA_HOUSE_NBR_2
					,MA_HOUSE_NBR_SUFFIX_2
					,MA_STREET_DIRECTION_2
					,MA_STREET_NAME_2
					,MA_MODE_2
					,MA_QUADRANT_2
					,MA_APARTMENT_UNIT_2
					,MA_CITY_2
					,MA_STATE_2
					,MA_ZIP_CODE_2
					,MA_CARRIER_CODE_2
					,MA_ORIGINAL_MAILING_ADDRESS_2
					,MA_DO_NOT_PUBLISH_FLAG_2
					,address_same_as_property_address_flag_2
					,2 AS _seq
				WHERE MA_HOUSE_NBR_2 > ''
					OR MA_STREET_NAME_2 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_3
					,MA_HOUSE_NBR_3
					,MA_HOUSE_NBR_SUFFIX_3
					,MA_STREET_DIRECTION_3
					,MA_STREET_NAME_3
					,MA_MODE_3
					,MA_QUADRANT_3
					,MA_APARTMENT_UNIT_3
					,MA_CITY_3
					,MA_STATE_3
					,MA_ZIP_CODE_3
					,MA_CARRIER_CODE_3
					,MA_ORIGINAL_MAILING_ADDRESS_3
					,MA_DO_NOT_PUBLISH_FLAG_3
					,address_same_as_property_address_flag_3
					,3 AS _seq
				WHERE MA_HOUSE_NBR_3 > ''
					OR MA_STREET_NAME_3 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_4
					,MA_HOUSE_NBR_4
					,MA_HOUSE_NBR_SUFFIX_4
					,MA_STREET_DIRECTION_4
					,MA_STREET_NAME_4
					,MA_MODE_4
					,MA_QUADRANT_4
					,MA_APARTMENT_UNIT_4
					,MA_CITY_4
					,MA_STATE_4
					,MA_ZIP_CODE_4
					,MA_CARRIER_CODE_4
					,MA_ORIGINAL_MAILING_ADDRESS_4
					,MA_DO_NOT_PUBLISH_FLAG_4
					,address_same_as_property_address_flag_4
					,4 AS _seq
				WHERE MA_HOUSE_NBR_4 > ''
					OR MA_STREET_NAME_4 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_5
					,MA_HOUSE_NBR_5
					,MA_HOUSE_NBR_SUFFIX_5
					,MA_STREET_DIRECTION_5
					,MA_STREET_NAME_5
					,MA_MODE_5
					,MA_QUADRANT_5
					,MA_APARTMENT_UNIT_5
					,MA_CITY_5
					,MA_STATE_5
					,MA_ZIP_CODE_5
					,MA_CARRIER_CODE_5
					,MA_ORIGINAL_MAILING_ADDRESS_5
					,MA_DO_NOT_PUBLISH_FLAG_5
					,address_same_as_property_address_flag_5
					,5 AS _seq
				WHERE MA_HOUSE_NBR_5 > ''
					OR MA_STREET_NAME_5 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_6
					,MA_HOUSE_NBR_6
					,MA_HOUSE_NBR_SUFFIX_6
					,MA_STREET_DIRECTION_6
					,MA_STREET_NAME_6
					,MA_MODE_6
					,MA_QUADRANT_6
					,MA_APARTMENT_UNIT_6
					,MA_CITY_6
					,MA_STATE_6
					,MA_ZIP_CODE_6
					,MA_CARRIER_CODE_6
					,MA_ORIGINAL_MAILING_ADDRESS_6
					,MA_DO_NOT_PUBLISH_FLAG_6
					,address_same_as_property_address_flag_6
					,6 AS _seq
				WHERE MA_HOUSE_NBR_2 > ''
					OR MA_STREET_NAME_6 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_7
					,MA_HOUSE_NBR_7
					,MA_HOUSE_NBR_SUFFIX_7
					,MA_STREET_DIRECTION_7
					,MA_STREET_NAME_7
					,MA_MODE_7
					,MA_QUADRANT_7
					,MA_APARTMENT_UNIT_7
					,MA_CITY_7
					,MA_STATE_7
					,MA_ZIP_CODE_7
					,MA_CARRIER_CODE_7
					,MA_ORIGINAL_MAILING_ADDRESS_7
					,MA_DO_NOT_PUBLISH_FLAG_7
					,address_same_as_property_address_flag_7
					,7 AS _seq
				WHERE MA_HOUSE_NBR_7 > ''
					OR MA_STREET_NAME_7 > ''
				
				UNION ALL
				
				SELECT MA_HOUSE_NBR_PREFIX_8
					,MA_HOUSE_NBR_8
					,MA_HOUSE_NBR_SUFFIX_8
					,MA_STREET_DIRECTION_8
					,MA_STREET_NAME_8
					,MA_MODE_8
					,MA_QUADRANT_8
					,MA_APARTMENT_UNIT_8
					,MA_CITY_8
					,MA_STATE_8
					,MA_ZIP_CODE_8
					,MA_CARRIER_CODE_8
					,MA_ORIGINAL_MAILING_ADDRESS_8
					,MA_DO_NOT_PUBLISH_FLAG_8
					,address_same_as_property_address_flag_8
					,8 AS _seq
				WHERE MA_HOUSE_NBR_8 > ''
					OR MA_STREET_NAME_8 > ''
				
				UNION ALL
				
				SELECT '' AS MA_HOUSE_NBR_PREFIX_8
					,'' AS MA_HOUSE_NBR_8
					,'' AS MA_HOUSE_NBR_SUFFIX_8
					,'' AS MA_STREET_DIRECTION_8
					,'' AS MA_STREET_NAME_8
					,'' AS MA_MODE_8
					,'' AS MA_QUADRANT_8
					,'' AS MA_APARTMENT_UNIT_8
					,'' AS MA_CITY_8
					,'' AS MA_STATE_8
					,'' AS MA_ZIP_CODE_8
					,'' AS MA_CARRIER_CODE_8
					,'' AS MA_ORIGINAL_MAILING_ADDRESS_8
					,'' AS MA_DO_NOT_PUBLISH_FLAG_8
					,'y' AS address_same_as_property_address_flag_8
					,9 AS _seq
				WHERE (
						SELECT count(1)
						FROM [lien_dtdb].[infc].[deed_buyer_names_pivot] aa
						WHERE aa.doc_id = nb.doc_id
							AND (
								isnull(aa.address_same_as_property_address_flag_1, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_2, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_3, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_4, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_5, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_6, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_7, '') = 'y'
								OR isnull(aa.address_same_as_property_address_flag_8, '') = 'y'
								)
						) > 0
				) b
			ORDER BY b._seq
				--	) a
				--WHERE nba.doc_id = nb.doc_id
			) nba
		LEFT JOIN [lien_dtdb].[infc].[deed_seller_names_pivot] ns ON ns.doc_id = d.doc_id
		LEFT JOIN [lien_dtdb].[infc].[deed_Lender_names_pivot] nl ON nl.doc_id = d.doc_id
		OUTER APPLY (
			SELECT CASE 
					WHEN d.adjustable_int_flag = 'A'
						AND nl.Role_Type_1 IN (
							'BENEFICIARY'
							,'BENEFICIARY/MORTGAGEE'
							,'LENDER'
							,'MORTGAGEE/LENDER'
							)
						THEN 'ADJ' -- 'PER DOC'
					WHEN d.adjustable_int_flag = 'V'
						AND nl.Role_Type_1 IN (
							'BENEFICIARY'
							,'BENEFICIARY/MORTGAGEE'
							,'LENDER'
							,'MORTGAGEE/LENDER'
							)
						THEN 'VAR'
					WHEN d.adjustable_int_flag = 'F'
						AND nl.Role_Type_1 IN (
							'BENEFICIARY'
							,'BENEFICIARY/MORTGAGEE'
							,'LENDER'
							,'MORTGAGEE/LENDER'
							)
						THEN 'FIX'
					WHEN (
							d.rider_balloon_payment_flag = 'Y'
							OR d.loan_balloon_payment_amount > 0.00
							)
						AND nl.Role_Type_1 IN (
							'BENEFICIARY'
							,'BENEFICIARY/MORTGAGEE'
							,'LENDER'
							,'MORTGAGEE/LENDER'
							)
						THEN 'BAL'
					ELSE NULL
					END AS mtg1_MTG_INTEREST_RATE_TYPE
			) d2
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [lien].[ur].[Reference] r
			WHERE r.doc_id = d.doc_id
			ORDER BY REFERENCE_id DESC
			) r
		OUTER APPLY (
			SELECT *
			FROM [lien_dtdb].[infc].[Property_extract] ph
			WHERE ph.doc_id = d.doc_id
			) ph
		OUTER APPLY (
			SELECT *
			FROM [Lien_dtdb].[dbo].[UR_Document_Types] dt
			WHERE dt.ur_value = d.doc_type
				AND isnull(dt.deed_type, '') <> 'Z'
				AND (
					dt.Delete_date IS NULL
					OR dt.Delete_date > D.Recording_Date_D
					)
				AND dt.DEED_TYPE = 'T'
				AND (
					(
						ph.fips IN (
							36005
							,36047
							,36061
							,36081
							,36085
							)
						AND (
							d.doc_type IN ('MTGSTT')
							OR (
								d.doc_type IN ('UCCOOP')
								AND (
									isnull(ph.land_use, '') = '111'
									OR isnull(ph.legal_desc_qualifier, '') > ''
									)
								)
							)
						)
					OR d.doc_type NOT IN (
						'MTGSTT'
						,'UCCOOP'
						)
					)
			) dt
		WHERE /* d.doc_id IN (
				SELECT doc_id
				FROM lien_dtdb.infc.DTDB_DocIdExtract_Process
				)
			AND */ ISNULL(dt.deed_type, '') = 't'
		) a
	WHERE a.fips IS NOT NULL

	--
	-- identify duplicate mortgages that needs to be deleted from deed, nova and friends
	-- and remove them from the mortgage_work table so that they can not be merged into a deed
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[mtg_delete_1]
		SELECT *
		INTO [lien_dtdb].[tmp].[mtg_delete_1]
		FROM (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY fips
					,ref_id
					,isnull(recording_date, '')
					,isnull(FMT_DOC_NBR, '')
					,isnull(FMT_Book_Page, '')
					,SRC_TBL ORDER BY ORIGINAL_SITE_ADDRESS DESC
						,UR_doc_id
					) AS ROW4
				,deedid
				,SRC_TBL
			FROM [lien_DTDB].[INFC].[Mortgage_work]
			WHERE REF_ID > 0
			) a
		WHERE row4 > 1

	--select * from  lien_dtdb.tmp.mtg_delete_1
	--where SRC_TBL <> 'MDM'
	--order by ROW4 desc
	--and deedid = 59065
	--select fips	,ref_id,recording_date ,FMT_DOC_NBR,FMT_Book_Page,SRC_TBL ,UR_doc_id ,* from lien_DTDB.INFC.Mortgage_work
	--where ref_id = 103374421
	--where deedid = 8367
	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[mtg_delete_1] (deedid)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[mtg_delete_2]
		SELECT *
		INTO [lien_dtdb].[tmp].[mtg_delete_2]
		FROM (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY fips
					,isnull(ORIGINAL_APN, '')
					,isnull(ORIGINAL_SITE_ADDRESS, '')
					,isnull(recording_date, '')
					,isnull(FMT_DOC_NBR, '')
					,isnull(FMT_Book_Page, '')
					,SRC_TBL ORDER BY UR_doc_id
					) AS ROW4
				,deedid
				,SRC_TBL
			FROM [lien_DTDB].[INFC].[mortgage_work]
			WHERE isnull(REF_ID, 0) = 0
			) a
		WHERE row4 > 1

	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[mtg_delete_2] (deedid)

	--select * from  lien_dtdb.tmp.mtg_delete_2
	--where SRC_TBL <> 'MDM'
	--select fips	,ref_id,recording_date ,FMT_DOC_NBR,FMT_Book_Page,SRC_TBL ,UR_doc_id ,* from lien_DTDB.INFC.Mortgage_work
	--where FMT_DOC_NBR = '16841'
	--where deedid = 39335
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[delete_duplicate_mtg]
		SELECT *
		INTO [lien_dtdb].[tmp].[delete_duplicate_mtg]
		FROM [lien_dtdb].[infc].[mortgage_work] WITH (
				NOLOCK
				,INDEX (idx_deedid)
				)
		WHERE deedid IN (
				SELECT deedid
				FROM [lien_dtdb].[tmp].[mtg_delete_1]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[mtg_delete_2]
				)

	CREATE INDEX idx_doc_id ON [lien_dtdb].[tmp].[delete_duplicate_mtg] (ur_doc_id)

	DELETE
	FROM [lien_DTDB].[INFC].[mortgage_work]
	WHERE deedid IN (
			SELECT deedid
			FROM [lien_dtdb].[tmp].[mtg_delete_1]
			
			UNION ALL
			
			SELECT deedid
			FROM [lien_dtdb].[tmp].[mtg_delete_2]
			)

	--
	-- B32658 Update Sales Price from NULL to $1 for HUD Rev Mtgs
	--
	--select * 
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.mtg1_mtg_amount = 1.00
	FROM [lien_dtdb].[infc].[mortgage_work] a
	WHERE a.mtg1_mtg_loan_type_code = 'REV'
		AND (
			a.mtg1_lender_last_name LIKE '%urban dev%'
			OR a.mtg1_lender_last_name = 'HUD'
			)

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_Extract_Mortgage_work'
		,N'Ended'
END TRY

BEGIN CATCH
	--SET @ERROR = ERROR_MESSAGE() + CHAR(10) + 'in Paul_2 - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--SELECT @ERROR AS N'@ERROR'
	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


