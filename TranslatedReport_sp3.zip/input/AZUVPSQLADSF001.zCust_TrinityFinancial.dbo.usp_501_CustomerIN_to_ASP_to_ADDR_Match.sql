SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- Create date: 20151215
-- Description:	Step 1 of Process, Address Standardization and Matching
-- =============================================
CREATE PROCEDURE [zCust_TrinityFinancial].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
	
AS
BEGIN

	SET NOCOUNT ON;

		SET CONCAT_NULL_YIELDS_NULL OFF


		----------Tax Eval----
		Truncate table INPUT_IN
		Insert into [zCust_TrinityFinancial].[dbo].[INPUT_IN](INPUTKEY,[INPUTAddress]      ,[INPUTCity]      ,[INPUTState]      ,[INPUTZip],INPUTAPN
		,INPUTBorrowerLastName)
		SELECT convert(bigint,[Unique ID] )    ,[Address]      ,[City]      ,[State]      ,[Zip]
         ,[APN]
		 --,[Borrower Name]
		 ,Right([Borrower Name],len([Borrower Name])-charindex(' ',[Borrower Name]))
         FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20200220]
		 

		 Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]


		 
		----------BK Eval----
		Truncate table INPUT_IN
		Insert into [zCust_TrinityFinancial].[dbo].[INPUT_IN](INPUTKEY,INPUTBorrowerLastName,INPUTBorrowerFirstName,INPUTSTATE,INPUTRECORDINGDATE
		,INputAddress,INPUTCity,INPUTZip)
		SELECT convert(bigint,[Unique ID] )    ,[Last Name]    ,[First Name]   ,[Property State],COnvert(date,[START DATE])
		,[Property Address]
      ,[Property City]
      ,[Property Zip]
       FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_BK_20200106]
		 

		 Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]


		 ----------PREFC Eval----
		Truncate table INPUT_IN
		Insert into [zCust_TrinityFinancial].[dbo].[INPUT_IN](INPUTKEY,[INPUTAddress]      ,[INPUTCity]      ,[INPUTState]      ,[INPUTZip],INPUTAPN,INPUTBorrowerLastName)
		SELECT convert(bigint,[Unique ID])    ,[Address]      ,[City]      ,[State]      ,[Zip]   ,[APN]
      ,[Last Name]
       FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_PREFC_20200106]
		 

		 Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]






		Truncate table INPUT_IN
		Insert into [zCust_TrinityFinancial].[dbo].[INPUT_IN](INPUTKEY,INPUTADDRESS,INPUTCITY,INPUTSTATE,INPUTZIP)
		SELECT convert(varchar(20),[User ID])    
		,REPLACE(([Address] + ' ' + convert(varchar(20),[Unit #]) ),'  ','')  
		,[City]      ,[State]     ,[Zip]      
		FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190828]

		Update [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190828]
		Set zip = '77058'
		where [User ID] = '8'

		Truncate table [INPUT_MONITOR]

		-------------Check to make sure Deletes Exist--
		Select A.* From  [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190611] as A left outer join 
		[zCust_TrinityFinancial].[dbo].[INPUT_MONITOR] as B on A.[User ID] = B.INPUTKEY
		where A.[Action] like 'D' and B.Inputkey is null


		Update [zCust_TrinityFinancial].[dbo].[A]
		Set A.DATE_DELETED = convert(date,Getdate())
		--Select *
		From [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR] as A join [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190611] as B on 
		A.INPUTKEY = B.[User ID]
		where B.[Action] like 'D'

		---ned to fix this
		--Insert into [INPUT_MONITOR_DELETED]
		--Select * From [INPUT_MONITOR]
		--where RecordType like 'D'


		Delete from [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR]
		where RecordType like 'D'


		

		-------------Check to make sure ADDS DO NOT Exist--
		Select * From  [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190611] as A  join 
		[zCust_TrinityFinancial].[dbo].[INPUT_MONITOR] as B on A.[User ID] = B.INPUTKEY
		where A.[Action] like 'A' 


		Insert into [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR]([INPUTKEY] ,[INPUTADDRESS]   ,[INPUTCITY]   ,[INPUTSTATE]   ,[INPUTZIP]   ,[RecordType]   ,[DATE_ADDED])
		Select convert(varchar(20),[User ID])    ,REPLACE(([Address] + ' ' + convert(varchar(20),[Unit #]) ),'  ','')  
		,[City]      ,[State]     ,[Zip]   ,'A',convert(date,getdate())
		FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190828] A
		where A.[Action (Add, Change, Delete)] like 'A' 

		SELECT convert(varchar(20),[User ID])    
		,REPLACE(([Address] + ' ' + convert(varchar(20),[Unit #]) ),'  ','')  
		,[City]      ,[State]     ,[Zip]      
		FROM [zCust_TrinityFinancial].[dbo].[INPUT_RAW_20190828]
  


		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR]




		Truncate table INPUT_IN

		INSERT INTO [zCust_TrinityFinancial].[dbo].[INPUT_IN](INPUTKEY,[INPUTAddress]      ,[INPUTCity]      ,[INPUTState]      ,[INPUTZip])
		Select  [INPUTKEY] ,[INPUTADDRESS]   ,[INPUTCITY]   ,[INPUTSTATE]   ,[INPUTZIP]
		From [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR] where [RecordType] not like 'D'
			


		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_MONITOR]
		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]

		

		Select INPUTKEY, count(*) From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
		Group by INPUTKEY
		having count(*) > 1

		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'

		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
		where INPUTAddress like '%  %'

		Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'
		

		UPDATE [zCust_TrinityFinancial].[dbo].[a] 
		SET a.INPUTState = b.[State]
		FROM [zCust_TrinityFinancial].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.INPUTState = b.[StateName]
		where len(a.INPUTState)>2 

			Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN]
			where len(INPUTState)>2
			and len(INPUTState)<4

			Update [zCust_TrinityFinancial].[dbo].[INPUT_IN]
			Set INPUTState = left(REPLACE(INPUTState,' ',''),2)
			where len(INPUTState)>2
			and len(INPUTState)<4

			Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN] where 
			len(INPUTState)>2

		UPDATE [zCust_TrinityFinancial].[dbo].[INPUT_IN] 
		SET INPUTState = NULL
		where len(INPUTState)>2


	Select * From [zCust_TrinityFinancial].[dbo].[INPUT_IN] where 
	len([INPUTZip])>10

	
	
		

    EXEC [zCust_TrinityFinancial].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 2 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_TrinityFinancial].[dbo].[TrinityFinancial_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_TrinityFinancial].[dbo].[TrinityFinancial_STD])
					END
			END


    EXEC [zCust_TrinityFinancial].[dbo].[usp_100c_sp_ASP_Cust_STD]




	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_TrinityFinancial'
	
	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_TrinityFinancial'


	Select CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_TrinityFinancial].[dbo].[a_PropMatch_WORK]
	group by CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END 

	Select CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_TrinityFinancial].[dbo].[a_PropMatch_WORK_FLANK]
	group by CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END 




	--Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.a_PropMatch_Work
	--Select * From a_PropMatch_Work

	--EXEC dbo.usp_211_Create_TransHist_Rev5

	EXEC [zCust_TrinityFinancial].[dbo].[usp_502_Pull_FLANK_DATA]

	EXEC [zCust_TrinityFinancial].[dbo].[usp_502_Pull_DTDB_DATA_V2]

	

	


	

END



