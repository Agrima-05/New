SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF




CREATE PROCEDURE [zCust_RenewFinancial].[dbo].[usp_350_Step2_Outstanding_Records] 
		
	
AS
BEGIN

	SET NOCOUNT ON;

				DECLARE @query NVARCHAR(MAX)
				DECLARE @RECCOUNT NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @body5 NVARCHAR(MAX)
				DECLARE @body6 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @xml3 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)

	IF(Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]) > 0

	BEGIN

	-----Create new BatchID & resubmit records to be sent
	EXEC [zCust_RenewFinancial].[dbo].[usp_501_STEP2_Taxsource_RESEND] 



				--DECLARE @query NVARCHAR(MAX)
				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @body1 NVARCHAR(MAX)
				--DECLARE @body2 NVARCHAR(MAX)
				--DECLARE @body3 NVARCHAR(MAX)
				--DECLARE @body4 NVARCHAR(MAX)
				--DECLARE @importance NVARCHAR(MAX)
				--DECLARE @xml NVARCHAR(MAX)
				--DECLARE @xml2 NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				--DECLARE @DATE VARCHAR(10)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				
				--DECLARE @RECCOUNT NVARCHAR(MAX)
				set @RECCOUNT  = (
				( (Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR])
				))
				--Print @RECCOUNT


				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'RenewFinancial - Taxsource Batch - Outstanding Record Count ' + @RECCOUNT + '!!!  BATCHID updated - RESUBMIT RECORDS!! - ' + @Date 
				
				SET @body1 = '<html><body><H3>RenewFinancial Taxsource Batch Count - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> FIPS  </th> <th> STATE </th> <th> COUNTY </th> <th> AUTOMATED   </th> <th> TOTAL  </th> <th> MATCHED_REF_ID  </th> <th> NOT_MATCHED  </th></tr>' 
				
			

				SET @xml = 
				CAST(( 
					Select FIPS as 'td','', State as 'td','', County as 'td','', AUTOMATED as 'td','', Total as 'td','', Matched_REF_ID as 'td','', NOT_MATCHED as 'td',''
					from (
					Select A.FIPS , B.State, B.[County Name] as COUNTY, count(*) as TOTAL
					,case when C.FIPSCODE is not null then 'Y' else 'N' end as AUTOMATED
					,sum(case when A.REF_ID is not null then 1 else 0 end) as MATCHED_REF_ID
					,sum(case when A.REF_ID is null then 1 else 0 end) as NOT_MATCHED
					from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A with(NOLOCK) 
					
					join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
					left outer join [zCust_AnchorLoans].[dbo].[TAXSOURCE_AUTOMATED] as C with(NOLOCK) on A.FIPS = C.FIPSCODE
					--where A.REF_ID is not null
					Group by  A.FIPS, B.State, B.[County Name], case when C.FIPSCODE is not null then 'Y' else 'N' end)A
					Order by  AUTOMATED,Total desc
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body2 = @body1 + @XML +'</table></body></html> <BR/><BR/>
				'
				

				SET @body3 = '<html><body><H3>RenewFinancial Taxsource Batch Count - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th>  AUTOMATED   </th> <th> TOTAL   </th></tr>' 
				
			

				SET @xml2 = 
				CAST(( 
					Select  AUTOMATED as 'td','', Total as 'td',''
					from (
					Select count(*) as TOTAL
					,case when C.FIPSCODE is not null then 'Y' else 'N' end as AUTOMATED
					from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A with(NOLOCK) 
					join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
					left outer join [zCust_AnchorLoans].[dbo].[TAXSOURCE_AUTOMATED] as C with(NOLOCK) on A.FIPS = C.FIPSCODE
					--where A.REF_ID is not null
					Group by   case when C.FIPSCODE is not null then 'Y' else 'N' end)A
					Order by  AUTOMATED,Total desc
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				SET @body5 = '<html><body><H3>RenewFinancial Taxsource Records Left - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th>  DATE_ADDED   </th> <th> TOTAL   </th></tr>' 

				

				SET @xml3 = 
				CAST(( 
					Select  DATE_ADDED as 'td','', Total as 'td',''
					from (
					Select DATE_ADDED,count(*) as TOTAL
					from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A with(NOLOCK) 
					Group by   DATE_ADDED)A
					Order by  DATE_ADDED
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body4 = 
				 @body5 + @XML3 +'</table></body></html> <BR/><BR/>
				' + @body3 + @XML2 +'</table></body></html> <BR/><BR/>
				' + @body2 + '</table></body></html> <BR/><BR/>
				'

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body4 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

		END


		ELSE


		BEGIN

				
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'RenewFinancial - Taxsource Batch - Complete.  All records returned!!!  - ' + @Date 
				
				SET @body1 = NULL
				Set @body2 = @body1 
			

			
				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body2 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

			END
		
		
END



