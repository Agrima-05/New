/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_PEt_Populate_Pet_NEO_Legal_INCR | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_PEt_Populate_Pet_NEO_Legal_INCR] @Fips INT = NULL  
 ,@Incremental_Flag BIT = 0  
 ,@ERROR VARCHAR(500) OUTPUT  
AS   
BEGIN  
 BEGIN TRY  
  EXEC [PET].[dbo].[AddPETLog] @Fips  
   ,N'info'  
   ,N'usp_PEt_Populate_Pet_NEO_Legal_INCR'  
   ,N'Started'  
  
  DECLARE @InSert_DATE DATETIME = GETDATE()  
  
  /*--------------------------------------------------------------------          
    Determine which records to insert into Pet.dbo.PET_NEO_Legal          
    Only records that has a Neo_Title_Legal and regardless if it matched          
    ----------------------------------------------------------------------*/  
  --DROP TABLE          
  --IF EXISTS #Neo_Legal_Cnt          
  -- SELECT DISTINCT Fips          
  --  ,Neo_APN AS DLX_DL_land_info          
  --  ,Neo_Land_Type AS dlp_DL_land_type          
  --  ,Neo_Title_Legal AS dlp_DL_land_info          
  -- INTO #Neo_Legal_Cnt          
  -- FROM pet.dbo.PET_NEO_Xref          
  -- WHERE Fips = @Fips          
  -- and Neo_Title_Legal is not null          
  --DROP TABLE          
  --IF EXISTS #Neo_Legal_Cnt2          
  -- SELECT t.*          
  --  ,(          
  --   SELECT [SPDB].[dbo].[find_RefId_with_Fips_and_APN](DLX_DL_land_info, @Fips)          
  --   ) AS ref_id          
  -- INTO #Neo_Legal_Cnt2          
  -- FROM #Neo_Legal_Cnt t          
  --CREATE INDEX ixa ON #Neo_Legal_Cnt2 (          
  -- Fips          
  -- ,REf_id          
  -- )          
  --CREATE INDEX ixb ON #Neo_Legal_Cnt2 (REf_id)          
  --DROP TABLE          
  --IF EXISTS #Neo_Legal_Cnt          
  -- Commented out 9/13/2022 MP          
  --DECLARE @translatedFips INT = (          
  --  SELECT *          
  --  FROM [SPDB].[dbo].[fnt_GetTranslatedFips](@fips)          
  --  )          
  TRUNCATE TABLE [pet].[tmp].[PET_NEO_LEGALS]  
  
  --grabs from only the pet incremental add table          
  INSERT INTO [pet].[tmp].[PET_NEO_LEGALS] (  
   FIPS  
   ,REF_ID  
   ,NEO_LAND_TYPE  
   ,NEO_TITLE_LEGAL  
   ,NEO_APN  
   ,Legal_Dup_Ind  
   ,[created]  
   ,PORTION_IND  
   )  
  SELECT DISTINCT x.FIPS  
   ,p.Ref_id  
   ,Neo_Land_Type  
   ,Neo_Title_Legal  
   ,Neo_APN  
   ,0 AS Dup_Ind  
   ,GETDATE() AS Created  
   ,x.PORTION_IND  
  FROM [pet].[pet_tmp].[Pet_Incremental_Add] x WITH (INDEX (idx_fips_legal))  
  LEFT JOIN [PET].[pet_tmp].[PET_APN_Inserts_Incremental] p ON p.fips = x.fips  
   AND p.apn = x.NEO_APN  
   AND p.APN_Type = 'NEOF'  
  WHERE x.NEO_TITLE_LEGAL IS NOT NULL  
   AND REF_ID IS NOT NULL --ref_id = 43960452--x.NEO_TITLE_LEGAL IS NOT NULL          
  
  --just added logic to populate [PET].[pet_tmp].[Pet_Incremental_REF_ID] without delete process    
  --this will have to change if we add back delete process    
  DROP TABLE  
  
  IF EXISTS #GetPetRefID  
   SELECT Pin.FIPS AS FIPS  
    ,Pin.NEO_APN AS NEO_APN  
    ,P.REF_ID AS REF_ID  
    ,P.APN_Type AS APN_Type  
    ,Pin.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL  
    ,Pin.PORTION_IND AS PORTION_IND  
   INTO #GetPetRefID  
   FROM [PET].[pet_tmp].[Pet_Incremental_Add] AS Pin WITH (  
     NOLOCK  
     ,INDEX (idx_fips_neoAPN)  
     )  
   INNER JOIN [PET].[pet_tmp].[PET_APN_Inserts_Incremental] AS P WITH (  
     NOLOCK  
     ,INDEX (ix)  
     ) ON P.FIPS = Pin.FIPS  
    AND P.APN = Pin.NEO_APN  
   WHERE (  
     P.APN_Type LIKE '%N_%'  
     OR P.APN_Type IN (  
      'NEO'  
      ,'NEOF'  
      )  
     )  
  
       
  --select * from #GetPetRefID     
  DROP TABLE  
  
  IF EXISTS [PET].[pet_tmp].[Pet_Incremental_REF_ID] --#testTable         
   SELECT DISTINCT n.NEO_TITLE_LEGAL  
    ,g.REF_ID  
    ,n.PORTION_IND  
    ,n.fips  
    ,n.NEO_APN  
   INTO [PET].[pet_tmp].[Pet_Incremental_REF_ID]  
   FROM [PET].[pet_tmp].[Pet_Incremental_Add] AS n  
   INNER JOIN #GetPetRefID AS g ON n.FIPS = g.FIPS  
    AND isnull(g.NEO_TITLE_LEGAL, '') = isnull(n.NEO_TITLE_LEGAL, '')  
    AND g.NEO_APN = n.NEO_APN  
   OPTION (  
    RECOMPILE  
    ,MAXDOP 12  
    ,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')  
    );  
  
  CREATE INDEX idx_fips_refID ON [PET].[pet_tmp].[Pet_Incremental_REF_ID] (FIPS, REF_ID);  
    --select * from [PET].[pet_tmp].[Pet_Incremental_REF_ID]    
  --new code ends here    
  EXEC [PET].[dbo].[AddPETLog] @Fips  
   ,N'info'  
   ,N'usp_PEt_Populate_Pet_NEO_Legal_INCR'  
   ,N'Ended'  
 END TRY  
  
 BEGIN CATCH  
  SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())  
  
  RAISERROR (  
    @ERROR  
    ,16  
    ,1  
    )  
 END CATCH  
END  
  

