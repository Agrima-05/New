SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Refresh DTDB data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_862_CreateDTDBPhotos]

AS
BEGIN


	SET NOCOUNT ON;

			DECLARE @MaxLoadDate as Datetime
			
			Select @MaxLoadDate = Max(LoadDate) FROM [DTDBListings].[dbo].[Photos]

			DELETE FROM [src_PlatLabs].[dbo].[p]
			FROM [DTDBListings].[dbo].[Photos] p 
				JOIN (Select mls_id,mls_listing_id from [src_PlatLabs].[dbo].[vPhotoLinks] WHERE LoadDate = @MaxLoadDate) b
			ON p.mls_id = b.mls_id
				and p.mls_listing_id = b.mls_listing_id

			INSERT INTO [DTDBListings].[dbo].[Photos] 
			SELECT * 
			FROM [src_PlatLabs].[dbo].[vPhotoLinks]
			WHERE mls_id in(Select mls_id from [src_PlatLabs].[dbo].[platlabs_update_config] where code like '%_39' and active = '1')
			and LoadDate > @MaxLoadDate


END




