/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | dbo.import_from_staging_to_UR | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Lien].[dbo].[import_from_staging_to_UR]
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who  date  change  
paul 12/14/21 Add the translated cmt to the code  
tdao    02/03/22    Add new fields from datalake  
tdao    06/06/22    Add new fields from datalake  
tdao    05/09/23    Add new fields from datalake  
tdao    08/01/23    Add new fields from datalake
Marie and Paul 
		20230907    move transfer_tax_misc to  transfer_tax for NC
Marie	11/06/23	For Reverse Mortgages
					- When Doc_title like '%Home Equity Conversion%' 
					  Set Loan_type:  
						IF Loan_Type IN ('','R') set to 'S'
					    IF Loan_Type IN ('F','FR' set to 'FS'
					    All Others set to 'S'
tdao	03/25/24	Add new fields from datalake
tdao    07/29/24    Add new fields from document to datalake i.e. requested_prepared_by_other_party
******************************************************************************************************************/
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'import_from_staging_to_UR'
	,N'Started'

DECLARE @epr_cnt INT = (
		SELECT count(1) AS cnt
		FROM [lien].[dbo].[staging_document] t
		)

SELECT @epr_cnt AS N'@epr_cnt'

IF @epr_cnt = 0
BEGIN
	RAISERROR (
			'No EPR data for today'
			,16
			,1
			)
END

BEGIN TRANSACTION

INSERT INTO [Lien].[UR].[DOCUMENT] (
	[doc_unique_id]
	,[source_PK]
	,[fips_code]
	,[apn_research_flag]
	,[vendor_code]
	,[cmt_docnumber]
	,[cmt_id]
	,[source]
	,[county]
	,[state]
	,[recording_date]
	,[recording_time]
	,[recording_book]
	,[recording_page]
	,[recording_doc_page_count]
	,[recording_year]
	,[recording_doc_number]
	,[recording_doc_number_alternate]
	,[recording_doc_sequence_number]
	,[accomodation_recording]
	,[electronic_recording]
	,[re_recording]
	,[doc_title]
	,[doc_type]
	,[doc_date]
	,[doc_filing_date]
	,[doc_signed_date]
	,[corrected_recording]
	,[retake_recording]
	,[doc_questionable_indicator]
	,[bankruptcy_case_number]
	,[bankruptcy_chapter]
	,[bankruptcy_type]
	,[bankruptcy_location]
	,[case_book]
	,[case_page]
	,[case_number]
	,[case_filed_in_county]
	,[case_court_type]
	,[case_original_number]
	,[case_original_court_type]
	,[case_status]
	,[death_certificate_number]
	,[county_of_death]
	,[city_village_town_of_death]
	,[loan_number]
	,[loan_numberoriginal_senior_loan]
	,[loan_type]
	,[loan_min_number]
	,[mers_flag]
	,[title_escrow_number]
	,[title_gf_number]
	,[title_misc_number]
	,[title_order_number]
	,[title_officer]
	,[title_company_name]
	,[title_company_code]
	,[account_number]
	,[amendment_number]
	,[attorney_bar_number]
	,[bond_number]
	,[lot_line_adjustment_number]
	,[certificate_number]
	,[claim_number]
	,[contract_number]
	,[corporation_number]
	,[estoppel_affidavit_county]
	,[estoppel_affidavit_state]
	,[excise_tax_number]
	,[federal_tax_lien_area]
	,[federal_tax_lien_area_phone]
	,[grantee_is_foreclosing_beneficiary]
	,[installment_judgment]
	,[interfamily_flag]
	,[license_number]
	,[lien_number]
	,[map_plat_id]
	,[mechanics_lien_number]
	,[ordinance_number]
	,[patent_number]
	,[permit_number]
	,[resolution_number]
	,[tax_account_serial_warrant_number]
	,[tax_type]
	,[trustees_sale_number]
	,[ucc_number]
	,[undersigned_same_as_borrower]
	,[water_rights_number]
	,[judgment_amount]
	,[judgment_grand_total]
	,[judgment_court_fees]
	,[judgment_attorney_fees]
	,[judgment_principal_fees]
	,[judgment_interest_fees]
	,[judgment_filing_fees]
	,[judgment_per_diem_fees]
	,[judgment_late_fees]
	,[judgment_tax_fees]
	,[judgment_insurance_fees]
	,[judgment_other_fees]
	,[loan_balloon_payment_amount]
	,[loan_financed_amount]
	,[loan_interest_rate]
	,[loan_advance_additional_new_amount]
	,[loan_maximum_amount_credit_limit]
	,[loan_modification_change_amount]
	,[loan_original_amount]
	,[loan_amount_of_in_favor_of_party]
	,[loan_amount_of_subordinating_party]
	,[loan_amount_subordinated_limit]
	,[recording_fee_1]
	,[recording_fee_2]
	,[recording_fee_3]
	,[recording_fee_4]
	,[recording_fee_5]
	,[recording_fee_6]
	,[recording_fee_7]
	,[recording_fee_total]
	,[transfer_sale_purchase_price]
	,[transfer_tax]
	,[transfer_tax_city]
	,[transfer_tax_county]
	,[transfer_tax_misc]
	,[transfer_tax_state]
	,[transfer_tax_town]
	,[transfer_tax_value_f_p]
	,[transfer_tax_number_non_disclosure_flag]
	,[amount_due]
	,[amount_of_default]
	,[bond_amount]
	,[cash_down_amount]
	,[contract_amount]
	,[collection_costs]
	,[foreclosure_filing_fee]
	,[ground_rent_amount]
	,[ground_rent_frequency]
	,[late_charges]
	,[minimum_bid_amount]
	,[support_arrears_amount]
	,[support_payment_amount]
	,[support_total_amount]
	,[tax_amount]
	,[tax_interest_amount]
	,[tax_penalty_amount]
	,[unpaid_balance]
	,[unpaid_balance_as_of_modification_date]
	,[unpaid_prinicipal_amount_due]
	,[date_bankruptcy_closed]
	,[date_bankruptcy_case_filed]
	,[date_bankruptcy_conversion]
	,[date_bankruptcy_discharged]
	,[date_bankruptcy_dismissed]
	,[date_bankruptcy_341_meeting]
	,[bankruptcy_341_meeting_time]
	,[date_of_birth_of_deceased]
	,[date_of_death]
	,[date_death_certificate_filed]
	,[date_physician_signed_death_certifate]
	,[date_of_divorce]
	,[date_of_marriage]
	,[date_of_separation]
	,[date_of_reconcilation]
	,[date_amount_due]
	,[date_of_assessment]
	,[date_of_auction]
	,[date_balloon_payment_due]
	,[date_of_birth_of_minor_child]
	,[date_of_cessation]
	,[date_of_commencement]
	,[date_of_completion]
	,[date_of_default]
	,[date_of_estoppel_affidavit]
	,[date_first_missed_payment]
	,[date_interest_accrued_to]
	,[date_interest_calculated_through]
	,[date_interest_started]
	,[date_of_judgment]
	,[date_of_lien_total_amount]
	,[date_of_loan_maturity]
	,[date_materials_first_delivered]
	,[date_materials_last_delivered]
	,[date_of_in_favor_of_loan]
	,[date_of_subordinated_loan]
	,[date_stay_ordered]
	,[date_surrendered_mobile_home]
	,[tax_last_day_for_refiling]
	,[tax_period_begin_date]
	,[tax_period_end_date]
	,[date_of_unpaid_balance]
	,[adjustable_int_flag]
	,[adjustable_int_negative_amortization_flag]
	,[adjustable_int_only_flag]
	,[adjustable_int_change_date]
	,[adjustable_int_change_frequency]
	,[adjustable_int_change_interval]
	,[adjustable_int_calculation_change]
	,[adjustable_int_maximum_perc]
	,[adjustable_int_index_type_code]
	,[adjustable_int_change_perc_limit]
	,[adjustable_int_first_int_rate_change_cap]
	,[adjustable_int_look_back_period]
	,[adjustable_int_rate_pay_option]
	,[rider_1_4_family_flag]
	,[rider_assumability_flag]
	,[rider_balloon_payment_flag]
	,[rider_biweekly_payment_flag]
	,[rider_condominium_flag]
	,[rider_conversion_flag]
	,[rider_construction_loan_flag]
	,[rider_demand_or_broker_call_loan_flag]
	,[rider_equity_loan_flag]
	,[rider_graduated_payment_flag]
	,[rider_growing_equity_loan_flag]
	,[rider_home_improvement_flag]
	,[rider_homestead_flag]
	,[rider_interest_only_loan_flag]
	,[rider_planned_unit_development_flag]
	,[rider_pre_payment_flag]
	,[rider_prime_equity_line_flag]
	,[rider_rate_improvement_flag]
	,[rider_request_for_notice_flag]
	,[rider_second_home_flag]
	,[rider_shared_appreciation_flag]
	,[rider_trust_revocable_trust_flag]
	,[rider_va_flag]
	,[auction_address]
	,[auction_city]
	,[auction_state]
	,[auction_zip]
	,[auction_time]
	,[judges_last_name]
	,[judges_first_name]
	,[judges_middle_initial]
	,[judges_suffix]
	,[judges_phone]
	,[judges_name_blob]
	,[nmls_company1]
	,[nmls_company1_id]
	,[nmls_company2]
	,[nmls_company2_id]
	,[nmls_officer]
	,[nmls_officer_id]
	,[notary_place_of_execution]
	,[notary_date_of_execution]
	,[notary_last_name]
	,[notary_first_name]
	,[notary_middle_name]
	,[notary_suffix]
	,[notary_commission_license_number]
	,[notary_commission_expiration_date]
	,[notary_vendor_number]
	,[notary_phone]
	,[notary_county_where_bond_is_filed]
	,[notary_state_where_bond_is_filed]
	,[notary_company_where_bond_is_insured]
	,[payment_address]
	,[payment_address_city]
	,[payment_address_state]
	,[payment_address_zip]
	,[payment_address_phone]
	,[place_of_filing_address]
	,[place_of_filing_address_city]
	,[place_of_filing_address_state]
	,[place_of_filing_address_zip]
	,[place_of_filing_phone]
	,[requested_prepared_by_attorney_name_identifier]
	,[requested_prepared_by_attorney_last_company_name]
	,[requested_prepared_by_attorney_first_name]
	,[requested_prepared_by_attorney_middle_initial]
	,[requested_prepared_by_attorney_suffix]
	,[requested_prepared_by_attorney_address]
	,[requested_prepared_by_attorney_address_city]
	,[requested_prepared_by_attorney_address_state]
	,[requested_prepared_by_attorney_address_zip]
	,[requested_prepared_by_attorney_phone]
	,[return_to_name_identifier]
	,[return_to_last_company_name]
	,[return_to_first_name]
	,[return_to_middle_name]
	,[return_to_suffix]
	,[return_to_address]
	,[return_to_city]
	,[return_to_state]
	,[return_to_zip]
	,[return_to_phone]
	,[legal_desc_multi_property_flag]
	,[legal_desc_blob]
	,[legal_desc_multi_apn_flag]
	,[remarks]
	,[lineage_file]
	,[md5]
	,[run_id]
	,[universal_document_identifier]
	,[pre_payment_interest]
	,[pre_payment_increments]
	,[concurrent_deed_flag]
	,[requested_prepared_by_attorney_contact_name]
	,[recording_thru_page_number]
	,[ur_matrix]
	,[batch]
	,[bucket]
	,[requested_prepared_by_attorney_email]
	,[alt_cmt_docnumber]
	,[alt_cmt_id]
	,[ur_json_version]
	,[property_override_type]
	,[pace_restriction_flag]
	,[timeshare_flag]
	,[reprocess_flag]
	,[mail_tax_bill_address]
	,[mail_tax_bill_city]
	,[mail_tax_bill_state]
	,[mail_tax_bill_zip]
	,[deed_type]
	,[owelty_flag]
	,[discriminatory_language_flag]
	,[loan_repayment_term]
	,[rider_renewal_extension_flag]
	,[entity_type]
	,[previous_doc_unique_id]
	,[update_type]
	,[new_title_company_name]
	,[transfer_fee_restriction_flag]
	,[tax_fiscal_year]
	,[mineral_type_blob]
	,[rider_tenancy_blob]
	,[original_doc_unique_id]
	,[eauction_website]
	,[filed_case_number]
	,[filed_case_number_sequence]
	,[waiver_number]
	,[notarized_name_blob]
	,[neo_impact_flag]
	,[requested_prepared_by_attorney_address_standardizedoutcome]
	,[group_classification]
	,[ur_matrix_version]
	,[requested_prepared_by_other_party_name_identifier]
	,[requested_prepared_by_other_party_last_company_name]
	,[requested_prepared_by_other_party_first_name]
	,[requested_prepared_by_other_party_middle_initial]
	,[requested_prepared_by_other_party_suffix]
	,[vendor_udi_reference]
	,[gchk_book_type]
	,[gchk_year]
	,[gchk_num]
	,[gchk_num_thru]
	,[neo_document_id]
	,[m_create_date]
	,[m_update_date]
	,nmls_company1_orig
	,nmls_company1_id_orig
	,nmls_company2_orig
	,nmls_company2_id_orig
	,nmls_officer_orig
	,nmls_officer_id_orig
	,Orig_Fips_Code
	,recording_district
	,names_extracted
	,ecrv_number
	,return_to_email
	,parent_fips_code
	,temp_document_flag
	)
OUTPUT inserted.Doc_id
	,NULL AS Name_id
	,NULL AS property_id
	,NULL AS reference_id
	,inserted.m_create_date
	,'import_from_staging_to_UR' AS Process_name
INTO [lien].[ur].[document_transaction_log]
SELECT d.[doc_unique_id]
	,0 AS source_PK
	,d.[fips_code]
	,d.[apn_research_flag]
	,d.[vendor_code]
	,d.[cmt_docnumber]
	,CASE 
		WHEN Output_CMT_ID IS NOT NULL
			THEN Output_CMT_ID
		ELSE d.[cmt_id]
		END AS cmt_id
	,d.[source]
	,d.[county]
	,d.[state]
	,d.[recording_date]
	,d.[recording_time]
	,d.[recording_book]
	,d.[recording_page]
	,d.[recording_doc_page_count]
	,d.[recording_year]
	,d.[recording_doc_number]
	,d.[recording_doc_number_alternate]
	--,d.[recording_doc_sequence_number]
	,try_cast(d.[recording_doc_sequence_number] AS INT) AS recording_doc_sequence_number
	,d.[accomodation_recording]
	,d.[electronic_recording]
	,d.[re_recording]
	,d.[doc_title]
	,d.[doc_type]
	,d.[doc_date]
	,d.[doc_filing_date]
	,d.[doc_signed_date]
	,d.[corrected_recording]
	,d.[retake_recording]
	,d.[doc_questionable_indicator]
	,d.[bankruptcy_case_number]
	,d.[bankruptcy_chapter]
	,d.[bankruptcy_type]
	,d.[bankruptcy_location]
	,d.[case_book]
	,d.[case_page]
	,d.[case_number]
	,d.[case_filed_in_county]
	,d.[case_court_type]
	,d.[case_original_number]
	,d.[case_original_court_type]
	,d.[case_status]
	,d.[death_certificate_number]
	,d.[county_of_death]
	,d.[city_village_town_of_death]
	,d.[loan_number]
	,d.[loan_numberoriginal_senior_loan]
	--,d.[loan_type]
	,CASE 
		WHEN ISNULL(d.doc_title, '') LIKE '%Home Equity Conversion%'
			THEN CASE 
					WHEN ISNULL(d.Loan_Type, '') IN (
							''
							,'R'
							)
						THEN 'S'
					WHEN ISNULL(d.Loan_Type, '') IN (
							'F'
							,'FR'
							)
						THEN 'FS'
					ELSE 'S'
					END
		ELSE d.Loan_Type
		END AS Loan_Type
	,d.[loan_min_number]
	,d.[mers_flag]
	,d.[title_escrow_number]
	,d.[title_gf_number]
	,d.[title_misc_number]
	,d.[title_order_number]
	,d.[title_officer]
	,LEFT(d.[title_company_name], 200)
	,d.[title_company_code]
	,d.[account_number]
	,d.[amendment_number]
	,d.[attorney_bar_number]
	,d.[bond_number]
	,d.[lot_line_adjustment_number]
	,d.[certificate_number]
	,d.[claim_number]
	,d.[contract_number]
	,d.[corporation_number]
	,d.[estoppel_affidavit_county]
	,d.[estoppel_affidavit_state]
	,d.[excise_tax_number]
	,d.[federal_tax_lien_area]
	,d.[federal_tax_lien_area_phone]
	,d.[grantee_is_foreclosing_beneficiary]
	,d.[installment_judgment]
	,d.[interfamily_flag]
	,d.[license_number]
	,d.[lien_number]
	,d.[map_plat_id]
	,d.[mechanics_lien_number]
	,d.[ordinance_number]
	,d.[patent_number]
	,d.[permit_number]
	,d.[resolution_number]
	,d.[tax_account_serial_warrant_number]
	,d.[tax_type]
	,d.[trustees_sale_number]
	,d.[ucc_number]
	,d.[undersigned_same_as_borrower]
	,d.[water_rights_number]
	,d.[judgment_amount]
	,d.[judgment_grand_total]
	,d.[judgment_court_fees]
	,d.[judgment_attorney_fees]
	,d.[judgment_principal_fees]
	,d.[judgment_interest_fees]
	,d.[judgment_filing_fees]
	,d.[judgment_per_diem_fees]
	,d.[judgment_late_fees]
	,d.[judgment_tax_fees]
	,d.[judgment_insurance_fees]
	,d.[judgment_other_fees]
	,d.[loan_balloon_payment_amount]
	,d.[loan_financed_amount]
	,d.[loan_interest_rate]
	,d.[loan_advance_additional_new_amount]
	,d.[loan_maximum_amount_credit_limit]
	,d.[loan_modification_change_amount]
	,d.[loan_original_amount]
	,d.[loan_amount_of_in_favor_of_party]
	,d.[loan_amount_of_subordinating_party]
	,d.[loan_amount_subordinated_limit]
	,d.[recording_fee_1]
	,d.[recording_fee_2]
	,d.[recording_fee_3]
	,d.[recording_fee_4]
	,d.[recording_fee_5]
	,d.[recording_fee_6]
	,d.[recording_fee_7]
	,d.[recording_fee_total]
	,d.[transfer_sale_purchase_price]
	,CASE 
		WHEN d.[fips_code] = '10003'
			AND d.[transfer_tax_state] IS NOT NULL
			THEN d.[transfer_tax_state]
		WHEN d.[transfer_tax_misc] IS NOT NULL
			AND (
				(
					d.[fips_code] BETWEEN '37000'
						AND '38000'
					)
				OR (d.fips_code = '53011')
				)
			AND d.[transfer_tax] IS NULL
			THEN d.[transfer_tax_misc]
		WHEN d.[fips_code] IN (
				'36150'
				,'36005'
				,'36047'
				,'36061'
				,'36081'
				)
			AND d.[transfer_tax] IS NULL
			AND d.TRANSFER_TAX_STATE IS NOT NULL
			THEN d.TRANSFER_TAX_STATE
		ELSE d.[transfer_tax]
		END AS transfer_tax
	,d.[transfer_tax_city]
	,d.[transfer_tax_county]
	,d.[transfer_tax_misc]
	,d.[transfer_tax_state]
	,d.[transfer_tax_town]
	,d.[transfer_tax_value_f_p]
	,d.[transfer_tax_number_non_disclosure_flag]
	,d.[amount_due]
	,d.[amount_of_default]
	,d.[bond_amount]
	,d.[cash_down_amount]
	,d.[contract_amount]
	,d.[collection_costs]
	,d.[foreclosure_filing_fee]
	,d.[ground_rent_amount]
	,d.[ground_rent_frequency]
	,d.[late_charges]
	,d.[minimum_bid_amount]
	,d.[support_arrears_amount]
	,d.[support_payment_amount]
	,CASE 
		WHEN d.[support_total_amount] <= 9999999999999.99
			THEN d.[support_total_amount]
		ELSE NULL
		END
	,d.[tax_amount]
	,d.[tax_interest_amount]
	,d.[tax_penalty_amount]
	,d.[unpaid_balance]
	,d.[unpaid_balance_as_of_modification_date]
	,d.[unpaid_prinicipal_amount_due]
	,d.[date_bankruptcy_closed]
	,d.[date_bankruptcy_case_filed]
	,d.[date_bankruptcy_conversion]
	,d.[date_bankruptcy_discharged]
	,d.[date_bankruptcy_dismissed]
	,d.[date_bankruptcy_341_meeting]
	,d.[bankruptcy_341_meeting_time]
	,d.[date_of_birth_of_deceased]
	,d.[date_of_death]
	,d.[date_death_certificate_filed]
	,d.[date_physician_signed_death_certifate]
	,d.[date_of_divorce]
	,d.[date_of_marriage]
	,d.[date_of_separation]
	,d.[date_of_reconcilation]
	,d.[date_amount_due]
	,d.[date_of_assessment]
	,d.[date_of_auction]
	,d.[date_balloon_payment_due]
	,d.[date_of_birth_of_minor_child]
	,d.[date_of_cessation]
	,d.[date_of_commencement]
	,d.[date_of_completion]
	,d.[date_of_default]
	,d.[date_of_estoppel_affidavit]
	,d.[date_first_missed_payment]
	,d.[date_interest_accrued_to]
	,d.[date_interest_calculated_through]
	,d.[date_interest_started]
	,d.[date_of_judgment]
	,d.[date_of_lien_total_amount]
	,d.[date_of_loan_maturity]
	,d.[date_materials_first_delivered]
	,d.[date_materials_last_delivered]
	,d.[date_of_in_favor_of_loan]
	,d.[date_of_subordinated_loan]
	,d.[date_stay_ordered]
	,d.[date_surrendered_mobile_home]
	,d.[tax_last_day_for_refiling]
	,d.[tax_period_begin_date]
	,d.[tax_period_end_date]
	,d.[date_of_unpaid_balance]
	,d.[adjustable_int_flag]
	,d.[adjustable_int_negative_amortization_flag]
	,d.[adjustable_int_only_flag]
	,d.[adjustable_int_change_date]
	,d.[adjustable_int_change_frequency]
	,d.[adjustable_int_change_interval]
	,d.[adjustable_int_calculation_change]
	,d.[adjustable_int_maximum_perc]
	,d.[adjustable_int_index_type_code]
	,d.[adjustable_int_change_perc_limit]
	,d.[adjustable_int_first_int_rate_change_cap]
	,d.[adjustable_int_look_back_period]
	,d.[adjustable_int_rate_pay_option]
	,d.[rider_1_4_family_flag]
	,d.[rider_assumability_flag]
	,d.[rider_balloon_payment_flag]
	,d.[rider_biweekly_payment_flag]
	,d.[rider_condominium_flag]
	,d.[rider_conversion_flag]
	,d.[rider_construction_loan_flag]
	,d.[rider_demand_or_broker_call_loan_flag]
	,d.[rider_equity_loan_flag]
	,d.[rider_graduated_payment_flag]
	,d.[rider_growing_equity_loan_flag]
	,d.[rider_home_improvement_flag]
	,d.[rider_homestead_flag]
	,d.[rider_interest_only_loan_flag]
	,d.[rider_planned_unit_development_flag]
	,d.[rider_pre_payment_flag]
	,d.[rider_prime_equity_line_flag]
	,d.[rider_rate_improvement_flag]
	,d.[rider_request_for_notice_flag]
	,d.[rider_second_home_flag]
	,d.[rider_shared_appreciation_flag]
	,d.[rider_trust_revocable_trust_flag]
	,d.[rider_va_flag]
	,d.[auction_address]
	,d.[auction_city]
	,d.[auction_state]
	,d.[auction_zip]
	,d.[auction_time]
	,d.[judges_last_name]
	,d.[judges_first_name]
	,d.[judges_middle_initial]
	,d.[judges_suffix]
	,d.[judges_phone]
	,d.[judges_name_blob]
	,d.[nmls_company1]
	,d.[nmls_company1_id]
	,d.[nmls_company2]
	,d.[nmls_company2_id]
	,d.[nmls_officer]
	,d.[nmls_officer_id]
	,d.[notary_place_of_execution]
	,d.[notary_date_of_execution]
	,d.[notary_last_name]
	,d.[notary_first_name]
	,d.[notary_middle_name]
	,d.[notary_suffix]
	,d.[notary_commission_license_number]
	,d.[notary_commission_expiration_date]
	,d.[notary_vendor_number]
	,d.[notary_phone]
	,d.[notary_county_where_bond_is_filed]
	,d.[notary_state_where_bond_is_filed]
	,d.[notary_company_where_bond_is_insured]
	,d.[payment_address]
	,d.[payment_address_city]
	,d.[payment_address_state]
	,d.[payment_address_zip]
	,d.[payment_address_phone]
	,d.[place_of_filing_address]
	,d.[place_of_filing_address_city]
	,d.[place_of_filing_address_state]
	,d.[place_of_filing_address_zip]
	,d.[place_of_filing_phone]
	,d.[requested_prepared_by_attorney_name_identifier]
	,d.[requested_prepared_by_attorney_last_company_name]
	,d.[requested_prepared_by_attorney_first_name]
	,d.[requested_prepared_by_attorney_middle_initial]
	,d.[requested_prepared_by_attorney_suffix]
	,d.[requested_prepared_by_attorney_address]
	,d.[requested_prepared_by_attorney_address_city]
	,d.[requested_prepared_by_attorney_address_state]
	,d.[requested_prepared_by_attorney_address_zip]
	,d.[requested_prepared_by_attorney_phone]
	,d.[return_to_name_identifier]
	,d.[return_to_last_company_name]
	,d.[return_to_first_name]
	,d.[return_to_middle_name]
	,d.[return_to_suffix]
	,d.[return_to_address]
	,d.[return_to_city]
	,d.[return_to_state]
	,d.[return_to_zip]
	,d.[return_to_phone]
	,d.[legal_desc_multi_property_flag]
	,d.[legal_desc_blob]
	,d.[legal_desc_multi_apn_flag]
	,d.[remarks]
	,d.[lineage_file]
	,d.[md5]
	,d.[run_id]
	,d.[universal_document_identifier]
	,d.[pre_payment_interest]
	,d.[pre_payment_increments]
	,d.[concurrent_deed_flag]
	,d.[requested_prepared_by_attorney_contact_name]
	,d.[recording_thru_page_number]
	,d.[ur_matrix]
	,d.[batch]
	,d.[bucket]
	,d.[requested_prepared_by_attorney_email]
	,d.[alt_cmt_docnumber]
	,d.[alt_cmt_id]
	,d.[ur_json_version]
	,d.[property_override_type]
	,d.[pace_restriction_flag]
	,d.[timeshare_flag]
	,d.[reprocess_flag]
	,d.[mail_tax_bill_address]
	,d.[mail_tax_bill_city]
	,d.[mail_tax_bill_state]
	,d.[mail_tax_bill_zip]
	,d.[deed_type]
	,d.[owelty_flag]
	,d.[discriminatory_language_flag]
	,d.[loan_repayment_term]
	,d.[rider_renewal_extension_flag]
	,d.[entity_type]
	,d.[previous_doc_unique_id]
	,d.[update_type]
	,d.[new_title_company_name]
	,d.[transfer_fee_restriction_flag]
	,d.[tax_fiscal_year]
	,d.[mineral_type_blob]
	,d.[rider_tenancy_blob]
	,d.[original_doc_unique_id]
	,d.[eauction_website]
	,d.[filed_case_number]
	,d.[filed_case_number_sequence]
	,d.[waiver_number]
	,d.[notarized_name_blob]
	,d.[neo_impact_flag]
	,d.[requested_prepared_by_attorney_address_standardizedoutcome]
	,d.[group_classification]
	,d.[ur_matrix_version]
	,d.[requested_prepared_by_other_party_name_identifier]
	,d.[requested_prepared_by_other_party_last_company_name]
	,d.[requested_prepared_by_other_party_first_name]
	,d.[requested_prepared_by_other_party_middle_initial]
	,d.[requested_prepared_by_other_party_suffix]
	,d.[vendor_udi_reference]
	,d.[gchk_book_type]
	,d.[gchk_year]
	,d.[gchk_num]
	,d.[gchk_num_thru]
	,d.[neo_document_id]
	,getdate() AS [m_create_date]
	,getdate() AS [m_update_date]
	,d.nmls_company1 AS nmls_company1_orig
	,d.nmls_company1_id AS nmls_company1_id_orig
	,d.nmls_company2 AS nmls_company2_orig
	,d.nmls_company2_id AS nmls_company2_id_orig
	,d.nmls_officer AS nmls_officer_orig
	,d.nmls_officer_id AS nmls_officer_id_orig
	,try_cast(right('00' + d.Fips_code, 5) AS CHAR(5)) AS Orig_Fips_Code
	,d.recording_district
	,d.names_extracted
	,d.ecrv_number
	,d.return_to_email
	,d.parent_fips_code
	,d.temp_document_flag
FROM [Lien].[dbo].[staging_document] d
OUTER APPLY (
	SELECT Output_CMT_ID
	FROM [Lien].[dbo].[Lien_CMT_Translation] b
	WHERE b.fips = cast(d.fips_code AS INT)
		AND b.Input_CMT_ID = d.cmt_id
	) b
LEFT JOIN [lien].[UR].[DOCUMENT] ud ON d.doc_unique_id = ud.doc_unique_id
	AND d.source = ud.source
WHERE ud.doc_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 16
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

INSERT INTO [Lien].[UR].[NAME] (
	[doc_id]
	,[doc_unique_id]
	,[sequence_number]
	,[name_identifier]
	,[name_code]
	,[last_company_name]
	,[first_name]
	,[middle_name]
	,[suffix]
	,[relate_to_name_id]
	,[party_type_code]
	,[relationship_code]
	,[vesting_code]
	,[percent_transferred]
	,[taxpayer_id_ssn_fein]
	,[spousal_information_flag]
	,[address_same_as_property_address_flag]
	,[address]
	,[address_city_name]
	,[address_state_name]
	,[address_zip_code]
	,[phone_number]
	,[email_website]
	,[foreign_address]
	,[foreign_address_country]
	,[questionable_indicator]
	,[role_blob]
	,[role_type]
	,[contact_name]
	,[name_sequence_id]
	,[birth_year]
	,[address_blob]
	,[date_of_birth]
	,[surname]
	,[signature_entity_name_blob]
	,[batch]
	,[bucket]
	,[address_standardizedoutcome]
	,[m_create_date]
	,[m_update_date]
	,[driver_license_number]
	,[driver_license_state]
	)
SELECT d.[doc_id]
	,n.[doc_unique_id]
	,n.[sequence_number]
	,n.[name_identifier]
	,n.[name_code]
	,ltrim(rtrim(n.[last_company_name])) AS last_company_name
	,n.[first_name]
	,n.[middle_name]
	,n.[suffix]
	,n.[relate_to_name_id]
	,n.[party_type_code]
	,n.[relationship_code]
	,n.[vesting_code]
	,n.[percent_transferred]
	,n.[taxpayer_id_ssn_fein]
	,n.[spousal_information_flag]
	,n.[address_same_as_property_address_flag]
	,n.[address]
	,n.[address_city_name]
	,n.[address_state_name]
	,n.[address_zip_code]
	,n.[phone_number]
	,n.[email_website]
	,n.[foreign_address]
	,n.[foreign_address_country]
	,n.[questionable_indicator]
	,n.[role_blob]
	,n.[role_type]
	,n.[contact_name]
	,n.[name_sequence_id]
	,n.[birth_year]
	,n.[address_blob]
	,n.[date_of_birth]
	,n.[surname]
	,n.[signature_entity_name_blob]
	,n.[address_standardizedoutcome]
	,n.[batch]
	,n.[bucket]
	,Getdate() AS [m_create_date]
	,getdate() AS [m_update_date]
	,n.[driver_license_number]
	,n.[driver_license_state]
FROM [Lien].[dbo].[staging_name] n
INNER JOIN [Lien].[UR].[DOCUMENT] d ON n.doc_unique_id = d.doc_unique_id
LEFT JOIN [Lien].[UR].[NAME] un ON un.doc_id = d.doc_id
WHERE un.Name_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 16
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

INSERT INTO [Lien].[UR].[PROPERTY] (
	[doc_id]
	,[doc_unique_id]
	,[property_id_sequence_number]
	,[legal_desc_abstract_portion]
	,[legal_desc_abstract_acreage]
	,[legal_desc_abstract_name]
	,[legal_desc_abstract_number]
	,[legal_desc_address]
	,[legal_desc_address_city]
	,[legal_desc_address_state]
	,[legal_desc_address_zip]
	,[legal_desc_apn_portion]
	,[legal_desc_apn]
	,[legal_desc_apn_split]
	,[legal_desc_apn_arb]
	,[legal_desc_apn_alternate]
	,[legal_desc_map_portion]
	,[legal_desc_map_unit_low]
	,[legal_desc_map_unit_high]
	,[legal_desc_map_lot_type]
	,[legal_desc_map_lot_type_low]
	,[legal_desc_map_lot_type_high]
	,[legal_desc_map_lot_low]
	,[legal_desc_map_lot_high]
	,[legal_desc_map_block]
	,[legal_desc_map_building]
	,[legal_desc_map_sublot]
	,[legal_desc_map_plat_subcode]
	,[legal_desc_map_plat_name]
	,[legal_desc_map_plat_number]
	,[legal_desc_map_plat_condo_id]
	,[legal_desc_map_plat_type_indicator]
	,[legal_desc_map_plat_book]
	,[legal_desc_map_plat_page]
	,[legal_desc_mine_mining_claim_lode]
	,[legal_desc_mine_mining_district]
	,[legal_desc_mine_mining_survey]
	,[legal_desc_rancho_portion]
	,[legal_desc_rancho_name_number]
	,[legal_desc_str_portion]
	,[legal_desc_str_government_lot]
	,[legal_desc_str_quarter]
	,[legal_desc_str_section]
	,[legal_desc_str_township]
	,[legal_desc_str_range]
	,[legal_desc_tct]
	,[legal_desc_timeshare_name]
	,[legal_desc_timeshare_inventory_control_number]
	,[legal_desc_timeshare_unit]
	,[legal_desc_timeshare_week]
	,[legal_desc_timeshare_season]
	,[legal_desc_timeshare_type]
	,[legal_desc_timeshare_map_plat_lot]
	,[legal_desc_timeshare_map_plat_block]
	,[legal_desc_timeshare_map_plat_id]
	,[legal_desc_timeshare_map_plat_type_indicator]
	,[legal_desc_timeshare_map_plat_book]
	,[legal_desc_timeshare_map_plat_page]
	,[legal_desc_district]
	,[legal_desc_municipality]
	,[legal_desc_swiss_code]
	,[legal_desc_project_name]
	,[legal_desc_easement_flag]
	,[legal_desc_easement_type]
	,[legal_desc_unincorporated_property_flag]
	,[legal_desc_property_questionable_indicator]
	,[legal_desc_timeshare_year_type]
	,[legal_desc_arb_portion]
	,[batch]
	,[bucket]
	,[legal_desc_arb]
	,[legal_type]
	,[legal_type_sequence]
	,[property_sequence]
	,[legal_desc_qualifier]
	,[legal_desc_timeshare_phase]
	,[legal_desc_map_city_block]
	,[legal_desc_application_number]
	,[legal_desc_tax_assessor_portion]
	,[legal_desc_tax_assessor_lot]
	,[legal_desc_tax_assessor_block]
	,[legal_desc_tax_assessor_section]
	,[legal_desc_arb_alternate]
	,[m_create_date]
	,[m_update_date]
	,[legal_desc_tax_assessor_lot_high]
	,[legal_desc_timeshare_map_plat_lot_high]
	,[legal_desc_map_portion_acreage]
	,[legal_desc_parcel_code]
	,[property_ref_id]
	,[legal_desc_timeshare_points]
	,[legal_desc_timeshare_unit_high]
	,[property_sequence_id]
	,[plat_name_lookup]
	,[property_ref_id_source]
	,[legal_desc_map_plat_year]
	,[legal_desc_address_standardizedoutcome]
	)
SELECT d.doc_id
	,p.[doc_unique_id]
	,p.[property_id_sequence_number]
	,p.[legal_desc_abstract_portion]
	,p.[legal_desc_abstract_acreage]
	,p.[legal_desc_abstract_name]
	,p.[legal_desc_abstract_number]
	,p.[legal_desc_address]
	,p.[legal_desc_address_city]
	,p.[legal_desc_address_state]
	,p.[legal_desc_address_zip]
	,p.[legal_desc_apn_portion]
	,p.[legal_desc_apn]
	,p.[legal_desc_apn_split]
	,p.[legal_desc_apn_arb]
	,p.[legal_desc_apn_alternate]
	,p.[legal_desc_map_portion]
	,p.[legal_desc_map_unit_low]
	,p.[legal_desc_map_unit_high]
	,p.[legal_desc_map_lot_type]
	,p.[legal_desc_map_lot_type_low]
	,p.[legal_desc_map_lot_type_high]
	,p.[legal_desc_map_lot_low]
	,p.[legal_desc_map_lot_high]
	,p.[legal_desc_map_block]
	,p.[legal_desc_map_building]
	,p.[legal_desc_map_sublot]
	,p.[legal_desc_map_plat_subcode]
	,p.[legal_desc_map_plat_name]
	,p.[legal_desc_map_plat_number]
	,p.[legal_desc_map_plat_condo_id]
	,p.[legal_desc_map_plat_type_indicator]
	,p.[legal_desc_map_plat_book]
	,p.[legal_desc_map_plat_page]
	,p.[legal_desc_mine_mining_claim_lode]
	,p.[legal_desc_mine_mining_district]
	,p.[legal_desc_mine_mining_survey]
	,p.[legal_desc_rancho_portion]
	,p.[legal_desc_rancho_name_number]
	,p.[legal_desc_str_portion]
	,p.[legal_desc_str_government_lot]
	,p.[legal_desc_str_quarter]
	,p.[legal_desc_str_section]
	,p.[legal_desc_str_township]
	,p.[legal_desc_str_range]
	,p.[legal_desc_tct]
	,p.[legal_desc_timeshare_name]
	,p.[legal_desc_timeshare_inventory_control_number]
	,p.[legal_desc_timeshare_unit]
	,p.[legal_desc_timeshare_week]
	,p.[legal_desc_timeshare_season]
	,p.[legal_desc_timeshare_type]
	,p.[legal_desc_timeshare_map_plat_lot]
	,p.[legal_desc_timeshare_map_plat_block]
	,p.[legal_desc_timeshare_map_plat_id]
	,p.[legal_desc_timeshare_map_plat_type_indicator]
	,p.[legal_desc_timeshare_map_plat_book]
	,p.[legal_desc_timeshare_map_plat_page]
	,p.[legal_desc_district]
	,p.[legal_desc_municipality]
	,p.[legal_desc_swiss_code]
	,p.[legal_desc_project_name]
	,p.[legal_desc_easement_flag]
	,p.[legal_desc_easement_type]
	,p.[legal_desc_unincorporated_property_flag]
	,p.[legal_desc_property_questionable_indicator]
	,p.[legal_desc_timeshare_year_type]
	,p.[legal_desc_arb_portion]
	,p.[batch]
	,p.[bucket]
	,p.[legal_desc_arb]
	,p.[legal_type]
	,p.[legal_type_sequence]
	,p.[property_sequence]
	,p.[legal_desc_qualifier]
	,p.[legal_desc_timeshare_phase]
	,p.[legal_desc_map_city_block]
	,p.[legal_desc_application_number]
	,p.[legal_desc_tax_assessor_portion]
	,p.[legal_desc_tax_assessor_lot]
	,p.[legal_desc_tax_assessor_block]
	,p.[legal_desc_tax_assessor_section]
	,p.[legal_desc_arb_alternate]
	,Getdate() AS [m_create_date]
	,getdate() AS [m_update_date]
	,p.[legal_desc_tax_assessor_lot_high]
	,p.[legal_desc_timeshare_map_plat_lot_high]
	,p.[legal_desc_map_portion_acreage]
	,p.[legal_desc_parcel_code]
	,p.[property_ref_id]
	,p.[legal_desc_timeshare_points]
	,p.[legal_desc_timeshare_unit_high]
	,p.[property_sequence_id]
	,p.[plat_name_lookup]
	,p.[property_ref_id_source]
	,p.[legal_desc_map_plat_year]
	,p.[legal_desc_address_standardizedoutcome]
FROM [Lien].[dbo].[staging_property] p
INNER JOIN [Lien].[UR].[document] d ON d.doc_unique_id = p.doc_unique_id
LEFT JOIN [Lien].[UR].[Property] up ON up.doc_id = d.doc_id
WHERE up.Property_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 16
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

INSERT INTO [Lien].[UR].[REFERENCE] (
	[doc_id]
	,[doc_unique_id]
	,[reference_id_sequence_number]
	,[reference_type_code]
	,[reference_book]
	,[reference_page]
	,[reference_recording_year]
	,[reference_doc_number]
	,[reference_recording_date]
	,[reference_questionable_indicator]
	,[batch]
	,[bucket]
	,[reference_book_type]
	,[reference_sequence_id]
	,[reference_reason]
	,[Updated]
	,[m_create_date]
	)
SELECT d.doc_id
	,substring(r.doc_unique_id, 1, 200) AS doc_unique_id
	,substring(r.reference_id_sequence_number, 1, 200) AS reference_id_sequence_number
	,substring(r.reference_type_code, 1, 200) AS reference_type_code
	,substring(r.reference_book, 1, 200) AS reference_book
	,substring(r.reference_page, 1, 200) AS reference_page
	,substring(r.reference_recording_year, 1, 200) AS reference_recording_year
	,substring(r.reference_doc_number, 1, 200) AS reference_doc_number
	,substring(r.reference_recording_date, 1, 200) AS reference_recording_date
	,substring(r.reference_questionable_indicator, 1, 200) AS reference_questionable_indicator
	,substring(r.batch, 1, 200) AS batch
	,substring(r.bucket, 1, 200) AS bucket
	,substring(r.reference_book_type, 1, 200) AS reference_book_type
	,r.reference_sequence_id AS reference_sequence_id
	,substring(r.reference_reason, 1, 200) AS reference_reason
	,getdate() AS Updated
	,getdate() AS m_create_date
FROM [Lien].[dbo].[staging_reference] r
INNER JOIN [Lien].[UR].[DOCUMENT] d ON d.doc_unique_id = r.doc_unique_id
LEFT JOIN [Lien].[UR].[REFERENCE] ur ON ur.doc_id = d.doc_id
WHERE ur.REFERENCE_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 16
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

COMMIT

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'import_from_staging_to_UR'
	,N'Ended'


