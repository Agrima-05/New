SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_PrimeChoiceFunding].[dbo].[usp_300_Start_Output_ASSR]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [varchar](250) NULL,
			[PROPERTY STATUS] [varchar](250) NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[In Coverage][varchar](250)NULL,
			[Status][varchar](250)NULL,
			[Owner Name][varchar](250)NULL,

			------Added 20230119 per NH----
			[Owner1LastName][varchar](250)NULL,
			[Owner1FirstName][varchar](250)NULL,
			[Owner1MiddleName][varchar](250)NULL,
			[Owner1Suffix][varchar](250)NULL,
			[Owner2CorpInd][varchar](250)NULL,
			[Owner2LastName][varchar](250)NULL,
			[Owner2FirstName][varchar](250)NULL,
			[Owner2MiddleName][varchar](250)NULL,
			[Owner2Suffix][varchar](250)NULL,
			[OwnerNAME1FULL][varchar](250)NULL,
			[OwnerNAME2FULL][varchar](250)NULL,



			[Owner Mailing Address][varchar](250)NULL,
			[Owner Mialing City][varchar](250)NULL,
			[Owner Mailing State][varchar](250)NULL,
			[Owner Mailing Zip Code][varchar](250)NULL,
			[BuildingArea][varchar](250)NULL,
			[BuildingAreaInd][varchar](250)NULL,
			[SumBuildingSqFt][varchar](250)NULL,
			[SumLivingAreaSqFt][varchar](250)NULL
			

		) ON [PRIMARY]

		

		INSERT INTO [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip])
		
	   	Select INPUTKey      
		,[INPUTAddress]      
		,[INPUTCity]      
		,[INPUTState]      
		,[INPUTZip]
		From [zCust_PrimeChoiceFunding].[dbo].[INPUT_IN]



	  Select * From [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
	  
	

		Update [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		Set [Run Date] = convert(date,GetDate())

		UPDATE [zCust_PrimeChoiceFunding].[dbo].[a] 
		SET a.PROPERTYID = c.PROPERTYID
		FROM [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] a JOIN 
		[zCust_PrimeChoiceFunding].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT KEY] = c.RAW_ID


		Update [zCust_PrimeChoiceFunding].[dbo].[a]
		SET 
		a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_PrimeChoiceFunding].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT KEY] = c.RAW_ID


		
		


		Update  [zCust_PrimeChoiceFunding].[dbo].[A]
		Set
		A.[Owner Name] = B.OwnerStdNAME1FULL
		,A.[Owner Mailing Address] = B.MailingStdFullStreetAddress
		,A.[Owner Mialing City] = B.MailingStdCity
		,A.[Owner Mailing State] = B.MailingStdState
		,A.[Owner Mailing Zip Code] = B.MailingStdZIP5
		,A.[BuildingArea] = B.BuildingArea
		,A.[BuildingAreaInd] = B.BuildingAreaInd
		,A.[SumBuildingSqFt] = B.SumBuildingSqFt
		,A.[SumLivingAreaSqFt] = B.SumLivingAreaSqFt

		,A.[Owner1LastName] = B.OwnerStd1LastName
		,A.[Owner1FirstName] = B.OwnerStd1FirstName
		,A.[Owner1MiddleName] = B.OwnerStd1MiddleName
		,A.[Owner1Suffix] = B.OwnerStd1Suffix
		,A.[Owner2CorpInd] = B.OwnerStd2CorpInd
		,A.[Owner2LastName] = B.OwnerStd2LastName
		,A.[Owner2FirstName] = B.OwnerStd2FirstName
		,A.[Owner2MiddleName] = B.OwnerStd2MiddleName
		,A.[Owner2Suffix] = B.OwnerStd2Suffix
		,A.[OwnerNAME1FULL] = B.OwnerStdNAME1FULL
		,A.[OwnerNAME2FULL] = B.OwnerStdNAME2FULL


		FROM [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] a JOIN [Data].[dbo].[Property] as B with(NOLOCK) 
		on A.PropertyID = B.PropertyID
		where A.PropertyID is not null


		Update [zCust_PrimeChoiceFunding].[dbo].[a]
		set [In Coverage] = TaxrollActive
		FROM [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] a JOIN [global].[dbo].[county] b  with(NOLOCK) ON a.FIPS = b.FIPSCODE

		

		Update [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] 
		SET [In Coverage] = CASE WHEN [In Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

	

		-------------------------------------------------------------------------------------------------------------------------------------------

		--Update  a
		--SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		--FROM x_Custom_OUTPUT a JOIN [dbo].a_ASP_IN_STD b
		--on a.[INPUT KEY] = b.Raw_ID


	

		Update [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_PrimeChoiceFunding].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		--Select * 
		FROM [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] a join [zCust_PrimeChoiceFunding].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT KEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M' and a.PROPERTYID is null

		
		

		UPDATE [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT] 
		Set  [Status] = NULL

	

		UPDATE [zCust_PrimeChoiceFunding].[dbo].[A] 
		Set  A.[Status] = case when ISNULL([Owner Name],'') not like '' 
		OR ISNULL([Owner Mailing Address],'') not like '' 
		then 'Event Found' ELSE 'Event Not Found' END
		From   [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		as A 
		
		
		
		--Select [AddressStandardization], count(*) From x_Custom_OUTPUT
		--Group by [AddressStandardization]
	

		Select [Status], count(*) From [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [Status]

		Select [Property Status], count(*) From [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

	
		Select [Status], count(*) from (
		Select [INPUT KEY],[Status], count(*) as TOTAL From [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [INPUT KEY],[Status])A
		Group  by [Status]

	
		--Select [HOA Lien Coverage], count(*) From x_Custom_OUTPUT
		--Group by [HOA Lien Coverage]

	

		Select * From [zCust_PrimeChoiceFunding].[dbo].[x_Custom_OUTPUT]
		Order by PROPERTYID



END



