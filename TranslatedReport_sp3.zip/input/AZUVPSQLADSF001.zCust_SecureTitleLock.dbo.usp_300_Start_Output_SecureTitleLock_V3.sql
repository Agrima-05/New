SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [zCust_SecureTitleLock].[dbo].[usp_300_Start_Output_SecureTitleLock_V3]


AS
BEGIN
	
	SET NOCOUNT ON;

	------20210823 - Notes per Convo with CR

----1.	There are preforeclosure doc types on the list, stand alone mortgage etc…  If a list of doc types are being provided to the customer as DEED types we will monitor for – all non-Deed doc types need to be removed from the list
	----a.	WHY are we giving them a list of Deed doc types?
	----KL – Ignore the Doc Type List per CR 
----2.	Billing/Populating Flag in output:
	----a.	Where is the billing info for the HOA Lien section (or is this being lumped into the INVL pricing)?
	----KL – Per CR – Yes – this was overlooked!!!!!!  She is bringing this back to Sales – but for now this will not be charged??????
----b.	New “for sale” listings - $2.50
	----i.	We are to populate Y only when a property that was previously off the market is now On the market
	----1.	Y will only be populated on the first extract sent to customer when property goes on the market (i.e. – not continually populating Y the whole time the property is on the market – only when it initially goes on the market)
	----2.	No monitor for when on market property goes off market
	----ii.	This Y flag is $2.50
	----KL – Per CR – She said loosely “yes”.  Correct on the Off market – no flag
----c.	Ownership changes - $2.50
	----i.	Is this based on at least one newly recorded Deed record?
	----ii.	Since we are returning the Doc Type & Recording Date for EACH Deed – are we charging them $2.50 for EACH DEED – or only ONCE regardless of how many Deeds returned?

	----KL – This section is potentially a build out
	----KL – Per CR – This is $2.50 PER TRANSACTION!!!


----d.	Tax mailing address change -$2.50
	----i.	There is no flag field for this?  Does this mean we are to track the Mailing Address provided & IF the Mailing Address changes then we charge them $2.50?
	----KL – This is Mailing Address!!!!
	----YES - $2.50 for change to Mailing Address
----e.	New loans - $2.50
	----i.	Since we are returning the Doc Type & Recording Date for EACH Mortgage – are we charging them $2.50 for EACH DEED – or only ONCE regardless of how many Mortgages returned?
	----KL – Per CR – This is $2.50 PER TRANSACTION!!!

----f.	Foreclosure (NOS) filings - $2.50
		----i.	Why is NOS called out (as there are other Preforeclosure doc types?)
		----ii.	ActiveFlag – Is this to be populated as Y ONLY when a property that was not in PFC moves into PFC?
			----1.	So the field will be Y on an initial extract after receiving a PFC record which causes a property that was currently not in PFC to be in PFC
			----2.	If we receive a subsequent PFC recording & the property is still in PFC – are we to flag the property again & count the transaction – or no because they already know the property is in PFC?
			----3.	If no new PFC records received on the property – the ActiveFlag field will be NULL on subsequent extracts for that property 
			----4.	If a Release/rescission is received & the property is no longer in PFC – the field will remain NULL?
				----a.	i.e. – they don’t need to know when a property comes out of PFC?
			----KL – Yes – this is a one time flag 
----g.	Any involuntary liens - $2.50
	----i.	InActiveFlag – This is transaction based - so are we only to include INVL transactions that are NOT INACTIVE (i.e. -this flag field will ALWAYS be NULL – even when there is a count of INVL transactions returned?)
	----ii.	If this was not the intended behavior of this field – perhaps we should rename the field to “New INVL Flag”?
	----KL – Change Field Name per CR - & only set to Y when new INVL & NOT INACTIVE!!
----3.	HOA Lien Section:
	----a.	Similar questions as in the INVL section:
		----i.	Are we only looking for HOA Lien records (NOT NOD/NOS for HOA Liens?)
		----ii.	Are we only counting Active records?
		----iii.	If so – the ActiveFlag field will be Y on the initial extract when we receive a new active HOA Lien for a property (the field will be NULL on subsequent extracts even if the HOA Lien is still active)
		----KL – ONLY Liens & Only new Active
----4.	Adding new records to portfolio
	----a.	We are ONLY searching for “new” events recorded after customers Monitoring Start Date provided – correct?
	----i.	So if property was already on the market BEFORE customers Monitoring Start Date – then we do NOT return property with Y in CurrentlyListedInd Field?
	----ii.	Are we populating the Owner Name & Mailing Address on ALL extracts (regardless of changes)?
	----KL – Populate Owner Name & Mailing address on ALL Extracts
	----KL – ONLY send them flags/info for when the recording/occurrence happened AFTER their input monitoring date!!


--------20210826 - Per CR - do NOT track the Tax/legal fields & DO populate the on EVERY extract.  Also - send ALL records on EVERY extract (not just the change records)!!



		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[WORK_REF_ID] [bigint] NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			-----Internal----
			[INPUTMonitorStartDate][varchar](250)NULL,
			[MAX_DEEDDATE][varchar](250)NULL,
			[MAX_MTGDATE][varchar](250)NULL,
			[MAX_INVLDATE][varchar](250)NULL,
			[MAX_HOALIENDATE][varchar](250)NULL,
			[MAX_PFCDATE][varchar](250)NULL,
			--[LISTINGTRACKINGID][varchar](250)NULL,
			--[MAX_LISTDATE][varchar](250)NULL,
			--[MAX_LISTPRICE][varchar](250)NULL,
			[LISTONMARKET][varchar](5)NULL,


			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,

			[OwnerFullName1][varchar](250)NULL,
			[OwnerFullName2][varchar](250)NULL,
			[MailingFullStreetAddress][varchar](250)NULL,
			[MailingCity][varchar](250)NULL,
			[MailingState][varchar](250)NULL,
			[MailingZIP5][varchar](250)NULL,
			[MailingZIP4][varchar](250)NULL,

			------Internal----
			[MailingFullStreetAddress_TRACKED][varchar](250)NULL,
			[DATE_ADDED][varchar](250)NULL,


			[Tax Year][varchar](250)NULL,
			[TaxAmt][varchar](250)NULL,
			[LEGAL DESCRIPTION][varchar](2000)NULL,

						
			[CurrentlyListedInd][varchar](250)NULL,
			--[List Date][varchar](250)NULL,
			--[List Price][varchar](250)NULL,

			--[# of Recordings][varchar](250)NULL
			[Nbr of Deed_MTG Transactions][varchar](250)NULL
							   		
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
	
	
	    INSERT INTO [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],[INPUT Address],[INPUT City],[INPUT State],[INPUT Zip]
		,[INPUTMonitorStartDate]
		,[MAX_DEEDDATE]
      ,[MAX_MTGDATE]
      ,[MAX_INVLDATE]
      ,[MAX_HOALIENDATE]
      --,[LISTINGTRACKINGID]
      --,[MAX_LISTDATE]
      --,[MAX_LISTPRICE]
	  ,FIPS
	  ,PROPERTYID
	  ,WORK_REF_ID
	  ,[MAX_PFCDATE]
	  ,[LISTONMARKET]
	  ,[MailingFullStreetAddress_TRACKED]
	  ,[DATE_ADDED]
	  )
		
		Select [INPUTKey]
      ,[INPUTAddress]
      ,[INPUTCity]
      ,[INPUTState]
      ,[INPUTZip]
      ,convert(date,[INPUTMonitorStartDate])
     
      ,convert(date,[MAX_DEEDDATE])
      ,convert(date,[MAX_MTGDATE])
      ,convert(date,[MAX_INVLDATE])
      ,convert(date,[MAX_HOALIENDATE])
      --,[LISTINGTRACKINGID]
      --,convert(date,[MAX_LISTDATE])
      --,[MAX_LISTPRICE]
	 ,FIPS
	 ,PROPERTYID
	 ,REF_ID
	  ,convert(date,[MAX_PFCDATE])
	  ,[LISTONMARKET]
	  ,MailingFullStreetAddress
	  ,[DATE_ADDED]
       From [zCust_SecureTitleLock].[dbo].[INPUT_MONITOR]
	   where RecordType not like 'D'

	  
	  

	
	  Select * From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]

	  ----20210325 NOtes:
	  -----Per CR - Coverage Status = Must be In Coverage for BOTH Deeds & MTGS!!  
	  ----Per CR - If ANY of the sections has New data - then Event Found
	  ----Per CR - REturn ALL input records in every extract.  
	  ----If no new data in a section then that section is to be left BLANK (do NOT need to retain & populate previously returned data)
	  ----Notifications are to go to Shawn only at this time
	  ----CR checking on if we need to return Inactive records on initial extracts 
	  ----AND CR checking if we return only Active & record then becomes Inactive - if we need to return same record again as Inactive

--	  BILLING:
--1.	$0.15 monthly for each record in the Input File that Data Tree is able to standardize and match, regardless of whether data is appended in the Output File.
--a.	Standardized & Matched are two different things.  We can potentially match a property that was not able to be standardized.  Are we only to count records that are BOTH standardized & matched?  I would think we would want to count ALL matched – regardless of standardization.

			--Per CR – MATCHED

--2.	Additionally:
--a.	$5.00 For each new deed recording
--b.	$5.00 For each new mortgage recording
--c.	$5.00 For each new listing - TRIGGER
--i.	We are not sending them Listings.  We are only providing a flag, list date & price.  So this goes back to questions in section 5 above.  What are the listing triggers/event?
--d.	$5.00 For each new involuntary lien recording
--i.	Same question on triggers.  If a previously sent INVL record had the Inactive flag as NULL – but is now set to Y (meaning it is inactive) – do they want it to be resent as Inactive?
--1.	Is this considered a trigger/event?
--e.	$5.00 for each new HOA lien recording
--i.	Same question on triggers.  If a previously sent HOA Lien record had the Active flag as Y – but is no longer active – do they want it to be resent as Inactive?
--1.	Is this considered a trigger/event?


---Per CR 20210415---
----Hi Charysse – 

----1.	For the Tax section – we are not monitoring these fields for changes – correct?  Just returning what we have on every extract? Correctomundo
----2.	We need a Nbr of Transactions Field in the Deed/Mtg section since we will potentially be returning more than one record in this section  oh boo, ok. We’ve already sent a revision,…
----3.	HOA Lien:
----a.	Since we are sending them the HOA Lien Releases – the HOA Lien section needs to include an ORIG HOA Lien Doc Number field (on Release records this will be populated with the original HOA Lien record document number so they know which HOA Lien is being released) OK
----b.	We need to add a Doc Type field so they know if the recording received is a Lien or a Release of a Lien


-----Changes to Flag fields ONLY per CR - 20210621

----	Hi Charysse – 

----1.	Are we populating the current Owner Name, Mailing Address and Assessor information on every run (regardless of changes)? Yes please
----		a.		Note – This would be the easiest method
----2.	The CurrentlyListed indicator will not be populated for records in CA  - Noted
----3.	The Deed/Mtg section will be a build out if there are multiple transactions recorded since the last extract: Correct

----4.	The INVL section will be a build out if there are multiple transactions recorded since the last extract and at least one is Inactive but at least one is not flagged as Inactive: Correct
----		b.	We are only looking for Newly recorded transactions – correct? Correct
----5.	The HOA Lien section will be a build out if there are multiple transactions recorded since the last extract and at least one is active but at least one is not: Correct

----b.Are we only looking for HOA Liens (not HOA related NOS / Releases etc)?  Correct
----		i.	Are we only looking for newly recorded ACTIVE HOA Liens?
----		c.	We are only looking for Newly recorded transactions – correct (not for when a currently active HOA lien record is set to Inactive)?
----6.	The PFC section will NOT be a build out as the “Active” flag is set on the Property as a whole rather than on each transaction (i.e. the Property is in preforeclosure as there has been one or more preforeclosure filings on at least one open mortgage on the property).  Noted

----		b.	Are we only looking for newly recorded PFC transactions on properties that are currently in PFC? Correct
----		c.	If we send them a record like the above – how will they know (or do they not care to know) if/when the property comes out of preforeclosure?

	 

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT a JOIN a_PropMatch_WORK_FLANK c on a.[INPUT KEY] = c.RAW_ID

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = case when ISNULL(a.[PROPERTYID],'') like '0' then c.[PROPERTYID] else a.[PROPERTYID] end
		--,a.WORK_REF_ID = case when ISNULL(a.WORK_REF_ID,'') like '0' then c.REF_ID else a.WORK_REF_ID end
		----,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		----Select * 
		--FROM x_Custom_OUTPUT a JOIN a_PropMatch_WORK c on a.[INPUT KEY] = c.RAW_ID
		

		

		Update [zCust_SecureTitleLock].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_SecureTitleLock].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT KEY] = c.RAW_ID


	
	
		
		-----Per  CR - Coverage = DEED AND MTG PER CR ---
				
		Update [zCust_SecureTitleLock].[dbo].[A]
		set [Coverage Status] = 1
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] a 
		JOIN [Global].[dbo].[COunty] as B on 
		A.FIPS = B.FIPSCODE
		where 	
		SAMActive like '1' 
		AND DeedActive like '1'


		--Update A
		--set [Coverage Status] = 1
		--FROM x_Custom_OUTPUT a 
		--	JOIN  [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] b  with(NOLOCK)
		--	ON convert(int,a.FIPs) = b.FIPs
		--where 	
		--M_FLag like '1' 
		--AND D_FLAG like '1'
		
		
		----Tax Info & Legal-----NOT MONITORING - Just returning what we have each time
		----20210621 - Added Current Owner Name, Mailing Address & Listing Ind
		-----20210823 - Populating Owner names & Mailing Addresses on every extract
		Update [zCust_SecureTitleLock].[dbo].[A]
		Set
		A.[Tax Year] = B.TaxYear
		,A.TaxAmt = B.TaxAmount
		,A.[Legal Description] = left(B.LegalDescription,2000)
		,A.OwnerFullName1 = B.OwnerStdName1Full
		,A.OwnerFullName2 = B.OwnerStdName2Full
		,A.MailingFullStreetAddress = B.MailingStdFullStreetAddress
		,A.MailingCity = B.MailingStdCity
		,A.MailingState = B.MailingStdState
		,A.MailingZIP5 = B.MailingStdZIP5
		,A.MailingZIP4 = B.MailingStdZIP4
		--Select B.TaxYear, B.TaxAmount, B.LegalDescription
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A 
		join [data].[dbo].[Property] as B with(NOLOCK) on 
		A.PropertyID = B.PropertyID
		where A.PropertyID is not null


		------Listing Info------ONLY monitoring for On Market vs Off Per CR!  
		-----Do NOT return anything if listing was on market & is still on market
		-----If listing was on market & is now Off Market - Return N in CurrentlyListedInd field
		----Do NOT return anything in CA because Owner name is on layout in HOA Lien section
		-----CHANGED 20210621 to FLAG only when On market (but not in CA)

		-----20210823 - Changed to ONLY populate the Flag ONCE - if still on the market on the next extract the field will be NULL
		Update [zCust_SecureTitleLock].[dbo].[A]
		Set 
		A.CurrentlyListedInd =  'Y'
		--,A.[List Price] = B.Current_Listing_Price
		--,A.[List Date] = convert(date,B.Current_Original_Listing_Date)
		--Select * 
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A 
		join [Listing].[dbo].[_LISTINGS_ALL_CURRENT] as B with(NOLOCK) on 
		A.PropertyID = B.PM_PropertyID
		where A.PropertyID is not null
		and (A.[LISTONMARKET] like 'N' or A.[LISTONMARKET] is null)
		and B.Status in ('Active','Pending','Contingent')
		and B.Current_Listing_Ind = 1
		and B.Add_Change_Delete_Indicator not like 'D'
		and A.FIPS not like '06%'


		Update [zCust_SecureTitleLock].[dbo].[A]
		Set 
		A.CurrentlyListedInd =  NULL
		--Select A.[INPUT KEY], A.LISTONMARKET,A.CurrentlyListedInd, B.LISTONMARKET
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A 
		join [zCust_SecureTitleLock].[dbo].[INPUT_MONITOR] as B  on 
		A.[INPUT KEY] = B.INPUTKey
		where B.[LISTONMARKET] like 'Y'
		
		
		--Update A
		--Set 
		--A.CurrentlyListedInd =  'N'
		--From x_Custom_OUTPUT as A 
		--join Listing.dbo._LISTINGS_ALL_CURRENT as B with(NOLOCK) on 
		--A.PropertyID = B.PM_PropertyID
		--where A.PropertyID is not null
		--and A.[LISTONMARKET] like 'Y'
		--and B.Status not in ('Active','Pending','Contingent')
		--and B.Current_Listing_Ind = 1
		--and A.FIPS not like '06%'

		
		



		------***********-------DTDB----***********---------------------------------------------------------------------
		
		Update [zCust_SecureTitleLock].[dbo].[w_TransHist] SET toUse = NULL

		Truncate table [w_TransHist_DEDUP]

		Insert into [zCust_SecureTitleLock].[dbo].[w_TransHist_DEDUP]
		Select [Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,REPLACE(REPLACE(REPLACE(REPLACE(DocumentNbr,'-','.'),'..','.'),' ',''),'/','.')
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      ,[BuyerBorrowerLastName]
      ,[BuyerBorrowerFirstName]
      ,[SellerLenderLastName]
      ,[SellerLenderFirstName]
      ,[TitleCompanyName]
      ,[Updated_Date]
      ,[MTG_Term]
      ,[MTG_TermType]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Rate_Type]
      ,[RAW_ID]
      ,[DocDate]
      ,[Assignor]
      ,[Assignee] From [zCust_SecureTitleLock].[dbo].[w_TransHist]


	  Truncate table [w_TransHist]

	  Insert into [zCust_SecureTitleLock].[dbo].[w_TransHist]
	  Select * From [zCust_SecureTitleLock].[dbo].[w_TransHist_DEDUP]
		

		-----------------------Deed & Mtg------------------------------------

		UPDATE [zCust_SecureTitleLock].[dbo].[w_TransHist]
		SET ToUse = 'Y' 
		--Select * 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] o Join [zCust_SecureTitleLock].[dbo].[w_TransHist] p
			ON O.[INPUT KEY] = P.RAW_ID
			WHERE 
			p.Doc_Src_Ind = 'M'
			AND Convert(date,P.RecordingDate) > Convert(date,O.INPUTMonitorStartDate)
			and (Convert(date,P.RecordingDate) > Convert(date,O.MAX_MTGDATE)
			OR O.MAX_MTGDATE is null)


		UPDATE [zCust_SecureTitleLock].[dbo].[w_TransHist]
		SET ToUse = 'Y' 
		--Select O.[INPUT KEY], O.INPUTMonitorStartDate, O.MAX_DEEDDATE, P.recordingdate, P.Doc_Src_Ind 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] o Join [zCust_SecureTitleLock].[dbo].[w_TransHist] p
			ON O.[INPUT KEY] = P.RAW_ID
			WHERE 
			p.Doc_Src_Ind = 'D'
			AND Convert(date,P.RecordingDate) > Convert(date,O.INPUTMonitorStartDate)
			and (Convert(date,P.RecordingDate) > Convert(date,O.MAX_DEEDDATE)
			OR O.MAX_DEEDDATE is null)
		
		----Moved down------
		--UPDATE w_TransHist
		--SET ToUse = 'Y' 
		----Select * 
		--FROM x_Custom_OUTPUT o Join w_TransHist p
		--	ON O.[INPUT KEY] = P.RAW_ID
		--	WHERE 
		--	p.Doc_Src_Ind = 'P'
		--	AND Convert(date,P.RecordingDate) > Convert(date,O.INPUTMonitorStartDate)
		--	and (Convert(date,P.RecordingDate) > Convert(date,O.MAX_PFCDATE)
		--	OR O.MAX_PFCDATE is null)
				


		Truncate table w_TransHist_II

		INSERT INTO [zCust_SecureTitleLock].[dbo].[w_TransHist_II]
		SELECT * 
		FROM [zCust_SecureTitleLock].[dbo].[w_TransHist]
		WHERE ToUSE = 'Y'


			UPDATE [zCust_SecureTitleLock].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_SecureTitleLock].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate ASC) AS RowNum
				FROM 
			[zCust_SecureTitleLock].[dbo].[w_TransHist_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID

		Select * FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_II]
		where RecordNumber is null

		
		Select RAW_ID,  count(*) FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_II]
		Group by RAW_ID
		having count(*) > 1



		Select RAW_ID, RecordNumber, count(*) FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_II]
		Group by RAW_ID, RecordNumber
		having count(*) > 1


		Select * From [zCust_SecureTitleLock].[dbo].[w_TransHist_II] as A join 
		[zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II] as B on A.RAW_ID = B.RAW_ID
		Order by A.RAW_ID
		
		
		 ------------------------BACKFILL W FLANK--------------------------------
		Update [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK] SET toUse = NULL

		Update [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK] SET DocumentNbr = REPLACE(REPLACE(REPLACE(REPLACE(DocumentNbr,'-','.'),'..','.'),' ',''),'/','.')

		
	
		UPDATE [zCust_SecureTitleLock].[dbo].[P]
		SET ToUse = 'Y' 
		--Select * 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] o Join [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK] p
			ON O.[INPUT KEY] = P.RAW_ID
			WHERE 
			p.Doc_Src_Ind = 'M'
			AND Convert(date,P.RecordingDate) > Convert(date,O.INPUTMonitorStartDate)
			and (Convert(date,P.RecordingDate) > Convert(date,O.MAX_MTGDATE)
			OR O.MAX_MTGDATE is null)


		UPDATE [zCust_SecureTitleLock].[dbo].[P]
		SET ToUse = 'Y' 
		--Select * 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] o Join [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK] p
			ON O.[INPUT KEY] = P.RAW_ID
			WHERE 
			p.Doc_Src_Ind = 'D'
			AND Convert(date,P.RecordingDate) > Convert(date,O.INPUTMonitorStartDate)
			and (Convert(date,P.RecordingDate) > Convert(date,O.MAX_DEEDDATE)
			OR O.MAX_DEEDDATE is null)


	

		Truncate table w_TransHist_FLANK_II

		INSERT INTO [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II]
		SELECT * 
		FROM [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK]
		WHERE ToUSE = 'Y'
		
		Update [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II]
		Set RecordNumber = null

			UPDATE [zCust_SecureTitleLock].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate ASC) AS RowNum
				FROM 
			[zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID

		Select * FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null

				
		Select RAW_ID,  count(*) FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID
		having count(*) > 1

		Select RAW_ID, RecordNumber, count(*) FRom [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, RecordNumber
		having count(*) > 1

	

		Truncate table w_TransHist_III

		INSERT INTO [zCust_SecureTitleLock].[dbo].[w_TransHist_III]
		SELECT * ,right(A.DocumentNbr,3)
		FROM [zCust_SecureTitleLock].[dbo].[w_TransHist_II] as A 
		WHERE ToUSE = 'Y'


		
	 INSERT INTO [zCust_SecureTitleLock].[dbo].[w_TransHist_III]([Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,[DocumentNbr]
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      
      ,[Loan_Type]
      
      ,[Raw_ID]
      ,[DocDate]
      ,[Assignor]
      ,[Assignee])
SELECT        
		A.[Fips]
      ,A.[REF_ID]
      ,A.[RecordNumber]
      ,A.[RecordingDate]
      ,A.[DocumentType]
      ,A.[DocumentNbr]
      ,A.[BuyerBorrower]
      ,A.[SellerLender]
      ,A.[Value]
      ,A.[OrigTransRecDate]
      ,A.[OrigTransDocNumber]
      ,A.[Lien_Pos]
      ,A.[CmtId]
      ,A.[Source_Type]
      ,A.[Doc_Id]
      ,A.[Doc_Src_Ind]
      ,A.[OrigDoc_Id]
      ,A.[DocumentTypeDesc]
      ,A.[ToUse]
    
          
      ,TRANSTYPE
     
      ,A.[Raw_ID]
      ,A.[DocDate]
      ,A.[OldLenderAssignor]
      ,A.[NewLenderAssignee]
	  --Select A.RAW_ID, A.DOcumentNbr, A.REcordingDate, B.DocumentNbr, B.REcordingDate,A.FA_BookPageFmt
FROM            [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK_II] as A
left outer join [zCust_SecureTitleLock].[dbo].[w_TransHist_III] as B on 
A.RAW_ID = B.RAW_ID
and 
		(
		(Right(A.Documentnbr,len((case when CHARINDEX('.',B.DocumentNbr) > 0 then Right(B.DOcumentNbr,Charindex('.',REVERSE(B.DocumentNbr))-1) else B.DocumentNbr end)))
		 = (case when CHARINDEX('.',B.DocumentNbr) > 0 then Right(B.DOcumentNbr,Charindex('.',REVERSE(B.DocumentNbr))-1) else B.DocumentNbr end))
		 OR
		 (A.FA_BookPageFmt = B.DocumentNbr)
		  OR
		 (A.recordingdate = B.recordingdate and  B.DocumentNbr like '%' + A.FA_DocnbrFmt)
		 )
where B.DocumentNbr is null
--and A.DocumentNbr is not null
--and A.DocumentNbr not like ''


	


	


		Update [zCust_SecureTitleLock].[dbo].[x_custom_OUTPUT]
		Set [Nbr of Deed_MTG Transactions] = NULL
		where convert(int,[Nbr of Deed_MTG Transactions]) > 0


		
		UPDATE [zCust_SecureTitleLock].[dbo].[a]
		SET a.[Nbr of Deed_MTG Transactions] =  b.NbrOfRecordings 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_SecureTitleLock].[dbo].[w_TransHist_III] GROUP BY RAW_ID) b
		on a.[INPUT KEY] = b.RAW_ID

		Select  MAX(convert(int,[Nbr of Deed_MTG Transactions])) FROM  [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		
		IF (Select count(*) from [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		where [Nbr of Deed_MTG Transactions] > 0 ) > 0

		BEGIN

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = MAX([Nbr of Deed_MTG Transactions]) FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT ADD [DocType_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Record #_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Document Type_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Document #_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Borrower/Assignor_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Lender/Assignee_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Value_' + @RecNbr + '] [varchar](250) NULL')


					EXEC('UPDATE a
					SET 
					--A.[Record #_' + @RecNbr + '] = b.REcordNumber
					--,
					A.[Recording Date_' + @RecNbr + '] = b.REcordingDate
					,A.[DocType_' + @RecNbr + '] = case when ISNULL(B.DocumentTypeDesc,'''') like '''' then  b.DocumentType 
							Else B.DocumentTypeDesc end
					--,A.[Document #_' + @RecNbr + '] = b.DocumentNbr
					--,A.[Borrower/Assignor_' + @RecNbr + '] = case when B.Doc_Src_INd like ''M'' then  b.BuyerBorrower else B.Assignor end
					--,A.[Lender/Assignee_' + @RecNbr + '] = case when B.Doc_Src_INd like ''M'' then  b.SellerLender else B.Assignee end
					--,A.[Value_' + @RecNbr + '] = b.Value
					--Select B.*					
					FROM x_Custom_OUTPUT a JOIN 
					w_Transhist_III as B on 
					a.[INPUT KEY] = b.RAW_ID
					where B.REcordNumber = ' + @BeginNbrOfTrans + ''
					)

					


						EXEC('Update A
							SET A.[DocType_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							from x_Custom_OUTPUT a join (SELECT distinct output_Code,Consolidated_Definition
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON A.[DocType_' + @RecNbr + '] = b.[output_Code]
							')

				
							EXEC('Update a
							SET A.[DocType_' + @RecNbr + '] = Upper(b.[Description])
							from x_Custom_OUTPUT a join (SELECT [Value]
							,[Code Description] as ''Description''
							,[Deed_Table_Column_name]
							,[Id]
							FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup]
							WHERE (Ltrim(Rtrim([Deed_Table_Column_name])) like ''DETAILED_DOC_TYPE''
							or [Deed_Table_Column_name] like ''DETAILED_DOC_TYPE '')
							) b
							ON A.[DocType_' + @RecNbr + '] = b.[Value]
							')

							EXEC('Update a
							SET A.[DocType_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							from x_Custom_OUTPUT a join (SELECT distinct output_Code,Consolidated_Definition
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON A.[DocType_' + @RecNbr + '] = b.[output_Code]
							')

					
					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END

		END

		ELSE
		---------Adding blank fields is there are no records

				BEGIN
	
					EXEC('ALTER Table x_Custom_OUTPUT ADD [DocType_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Recording Date] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Document Type] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Document #] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Borrower/Assignor] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Lender/Assignee] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [Value] [varchar](250) NULL')
									
				END


		

	Select * From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		



		----------------------INVL - USING FLANK ONLY!!!!------------------------------------------------------------------

		ALTER Table x_Custom_OUTPUT ADD [Nbr of INVL Transactions][varchar](250)NULL
		ALTER Table x_Custom_OUTPUT ADD [New_INVL_Flag][varchar](250)NULL
		
		UPdate [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		Set [Nbr of INVL Transactions] = NULL
		where [Nbr of INVL Transactions] > 0

		Truncate table dbo.[INVL]

		Insert into [zCust_SecureTitleLock].[dbo].[INVL]([INPUTKEY],RecordNumber,[Party1_Name1_FullName],
			[Party1_Name2_FullName],
			[DocumentYear],
			[Recordingdt],
			[DocumentDt],
			[doc_filing_date],
			[DocType],
			[DocumentTitle],
			[InActiveFlag])
			Select A.[INPUT KEY],
			ROW_NUMBER() OVER (Order by [Recordingdt] ASC),
			[Party1_Name1_FullName],
			[Party1_Name2_FullName],
			[DocumentYear],
			[Recordingdt],
			[DocumentDt],
			[doc_filing_date],
			[DocType],
			[DocumentTitle],
			[InActiveFlag]
			From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
			[data].[dbo].[v_INVL] as B with(NOLOCK) on 
			(A.PROPERTYID = B.PropertyID
			OR 
			A.PROPERTYID = B.Party1_Name1_MailPropertyID
			OR 
			A.PROPERTYID = B.Party2_Name1_MailPropertyID)
			where 
			A.PROPERTYID is not null 
			AND 
			Convert(date,B.Recordingdt) > Convert(date,A.INPUTMonitorStartDate)
			and (Convert(date,B.Recordingdt) > Convert(date,A.MAX_INVLDATE)
			OR A.MAX_INVLDATE is null)
			AND B.[InActiveFlag] is null



		UPdate [zCust_SecureTitleLock].[dbo].[A]
		Set [Nbr of INVL Transactions] = B.TOTAL
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
			(Select A.[INPUTKEY], count(*) as TOTAL From [zCust_SecureTitleLock].[dbo].[INVL]  A
			Group by A.[INPUTKEY])B
		on A.[INPUT KEY]=  B.[INPUTKEY]

		
		Select  MAX(convert(int,[Nbr of INVL Transactions])) FROM  [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]

		Update  [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		Set [New_INVL_Flag] = 'Y'
		where [Nbr of INVL Transactions] > 0
				

		--IF (Select count(*) from x_Custom_OUTPUT
		--where [Nbr of INVL Transactions] > 0 ) > 0

		--BEGIN

		--Declare @BeginNbrOfTrans2 int
		--Declare @EndNbrOfTrans2 int

		--SET @BeginNbrOfTrans2 = 1
		--Select @EndNbrOfTrans2 = MAX([Nbr of INVL Transactions]) FROM x_Custom_OUTPUT
		

		--	WHILE (@BeginNbrOfTrans2 <= @EndNbrOfTrans2)
		--		BEGIN
				 
		--			DECLARE @RecNbr2 as varchar(5)
		--			SET @RecNbr2 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans2),3)

					
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Nbr of Transactions] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Party1_Name1_FullName_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Party1_Name2_FullName_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentYear_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Recordingdt_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentDt_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_doc_filing_date_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocType_' + @RecNbr2 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentTitle_' + @RecNbr2 + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT ADD [New_INVL_Flag_' + @RecNbr2 + '] [varchar](250) NULL')



		--			EXEC('UPDATE a
		--			SET 
		--			--A.[INVL_Party1_Name1_FullName_' + @RecNbr2 + '] = b.[Party1_Name1_FullName]
		--			--,A.[INVL_Party1_Name2_FullName_' + @RecNbr2 + '] = b.[Party1_Name2_FullName]
		--			--,A.[INVL_DocumentYear_' + @RecNbr2 + '] = b.[DocumentYear]
		--			--,A.[INVL_Recordingdt_' + @RecNbr2 + '] = b.[Recordingdt]
		--			--,A.[INVL_DocumentDt_' + @RecNbr2 + '] = b.[DocumentDt]
		--			--,A.[INVL_doc_filing_date_' + @RecNbr2 + '] = b.[doc_filing_date]
		--			--,A.[INVL_DocType_' + @RecNbr2 + '] = b.[DocType]
		--			--,A.[INVL_DocumentTitle_' + @RecNbr2 + '] = b.[DocumentTitle]
		--			--,
		--			A.[INVL_InActiveFlag_' + @RecNbr2 + '] = b.[InActiveFlag]

		--			--Select B.*					
		--			FROM x_Custom_OUTPUT a JOIN 
		--			[INVL] as B on 
		--			a.[INPUT KEY] = b.[INPUTKEY]
		--			where B.REcordNumber = ' + @BeginNbrOfTrans2 + ''
		--			)

					
					
		--				--EXEC('Update A
		--				--	SET A.[INVL_DocType_' + @RecNbr2 + '] = Upper(b.[Description])
		--				--	from x_Custom_OUTPUT a join INVL_DocumentType b
		--				--	ON A.[INVL_DocType_' + @RecNbr2 + '] = b.[DocType]
		--				--	')

					
		--			SET @BeginNbrOfTrans2 = @BeginNbrOfTrans2 + 1
				
		--		END


		--		--EXEC(' 
		--		--Update x_Custom_OUTPUT
		--		--set [INVL_Nbr of Transactions] = sum(convert(int,[# of Recordings]))
		--		--')

		--END

		--ELSE
		-----------Adding blank fields is there are no records

		--		BEGIN
	
					
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Nbr of Transactions] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Party1_Name1_FullName] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Party1_Name2_FullName] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentYear] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_Recordingdt] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentDt] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_doc_filing_date] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocType] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_DocumentTitle] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT ADD [INVL_InActiveFlag] [varchar](250) NULL')
					
		--		END


		

	Select * From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]



	-----------------------------------------HOA LIen - Sending only HOA Lien & HOA Lien Releases-------
	--------********************NEED TO ADD HOA LIEN TRACKING*****************-------------------
		

		
		ALTER Table x_Custom_OUTPUT ADD [Nbr of HOALien Transactions][varchar](250)NULL
		ALTER Table x_Custom_OUTPUT ADD [HOALien ActiveFlag][varchar](250)NULL
		
		

		Truncate table dbo.[HOA_LIEN]

		Insert into [zCust_SecureTitleLock].[dbo].[HOA_LIEN](INPUTKEY,[RECORDNUMBER]
			,[Name1_FullName]
			,[Name2_FullName]
			,[HOA Lien Recording Date]
			,[HOA Lien Recorded Document Number]
			,[HOA Lien Amount]
			,[HOA Lien Name]
			,[HOA Lien Agency]
			,[ORIG HOA Lien Doc Number]
			,[ActiveFlag])
			Select A.[INPUT KEY],
			ROW_NUMBER() OVER (Order by B.[Recording Date] ASC)
			,OwnerNAME1FULL
			,OwnerNAME2FULL
			,B.[Recording Date]
			,DocumentNumber
			,[HOA Lien Amount]
			,[HOA Lien Name]
			,[HOA Lien Agency]
			,[HOA - Orig Doc Number]
			,case when [Open Lien Indicator] = 1 then 'Y' else NULL end
			From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
			[data].[dbo].[vHOA_LIEN] as B with(NOLOCK) on 
			A.PROPERTYID = B.PropertyID
			where 
			A.PROPERTYID is not null 
			AND 
			Convert(date,convert(varchar(10),B.[Recording Date])) > Convert(date,A.INPUTMonitorStartDate)
			and (Convert(date,convert(varchar(10),B.[Recording Date])) > Convert(date,A.MAX_HOALIENDATE)
			OR A.MAX_HOALIENDATE is null)
			AND [Open Lien Indicator] = 1
			and TransactionType = 'LN'

			--Select * From x_Custom_OUTPUT


		


			--Insert into [HOA_LIEN](INPUTKEY,[RECORDNUMBER]
			--,[Name1_FullName]
			--,[Name2_FullName]
			--,[HOA Lien Recording Date]
			--,[HOA Lien Recorded Document Number]
			--,[HOA Lien Amount]
			--,[HOA Lien Name]
			--,[HOA Lien Agency]
			--,[ORIG HOA Lien Doc Number]
			--,[ActiveFlag])
			--Select A.[INPUT KEY],
			--ROW_NUMBER() OVER (Order by B.[Recording Date] ASC)
			--,OwnerNAME1FULL
			--,OwnerNAME2FULL
			--,B.[Recording Date]
			--,DocumentNumber
			--,[HOA Lien Amount]
			--,[HOA Lien Name]
			--,[HOA Lien Agency]
			--,[HOA - Orig Doc Number]
			--,case when [Open Lien Indicator] = 1 then 'Y' else NULL end
			--From x_Custom_OUTPUT as A join 
			--data.dbo.vHOA_LIEN as B with(NOLOCK) on 
			--A.PROPERTYID = B.PropertyID
			--join [LIEN_TRACKING] as C on B.PropertyID = C.REF_ID
			--AND  B.[HOA - Orig Doc Number] = C.[LIEN_DOC_NUMBER]
			--where 
			--A.PROPERTYID is not null 
			--AND (B.[Doc Type] like '%RL%' 
			--OR B.[Doc Type] like '%REL%' )


			Update [zCust_SecureTitleLock].[dbo].[HOA_LIEN]
			Set RecordNumber = null

			UPDATE [zCust_SecureTitleLock].[dbo].[t] SET [RECORDNUMBER] = RowNum
			FROM [zCust_SecureTitleLock].[dbo].[HOA_LIEN] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY [HOA Lien Recording Date] ASC,[HOA Lien Recorded Document Number] ASC) AS RowNum
				FROM [zCust_SecureTitleLock].[dbo].[HOA_LIEN] t  ) r ON t.INPUTKEY = r.INPUTKEY AND t.[HOA Lien Recording Date] = r.[HOA Lien Recording Date]
				AND t.[HOA Lien Recorded Document Number] = r.[HOA Lien Recorded Document Number]


			Select  INPUTKEY, RecordNumber , count(*) as TOTAL  from [zCust_SecureTitleLock].[dbo].[HOA_LIEN]
			Group by INPUTKEY, RecordNumber
			having count(*) > 1


		
			UPdate [zCust_SecureTitleLock].[dbo].[A]
			Set [Nbr of HOALien Transactions] = B.TOTAL
			From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
				(Select A.[INPUTKEY], count(*) as TOTAL From [zCust_SecureTitleLock].[dbo].[HOA_LIEN]  A
				Group by A.[INPUTKEY])B
			on A.[INPUT KEY]=  B.[INPUTKEY]


					   			 		
		Select  MAX(convert(int,[Nbr of HOALien Transactions])) FROM  [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		
		Update [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		Set [HOALien ActiveFlag] = 'Y'
		where [Nbr of HOALien Transactions] > 0


		--IF (Select count(*) from x_Custom_OUTPUT
		--where [Nbr of HOALien Transactions] > 0 ) > 0

		--BEGIN

		--Declare @Beginnbroftrans3 int
		--Declare @Endnbroftrans3 int

		--SET @Beginnbroftrans3 = 1
		--Select @Endnbroftrans3 = MAX([Nbr of HOALien Transactions]) FROM x_Custom_OUTPUT
		

		--	WHILE (@Beginnbroftrans3 <= @Endnbroftrans3)
		--		BEGIN
				 
		--			DECLARE @RecNbr3 as varchar(5)
		--			SET @RecNbr3 = RIGHT('000' + convert(varchar(5),@Beginnbroftrans3),3)

		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Nbr of Transactions] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Name1_FullName_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Name2_FullName_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Recording Date_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Recorded Document Number_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_DocType_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Amount_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Name_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Agency_' + @RecNbr3 + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_ORIG HOA Lien Doc Number_' + @RecNbr3 + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_ActiveFlag_' + @RecNbr3 + '] [varchar](250) NULL')


		--			EXEC('UPDATE a
		--			SET 
		--			--A.[HOA_LIEN_Name1_FullName_' + @RecNbr3 + '] = b.[Name1_FullName]
		--			--,A.[HOA_LIEN_Name2_FullName_' + @RecNbr3 + '] = b.[Name2_FullName]
		--			--,A.[HOA_LIEN_HOA Lien Recording Date_' + @RecNbr3 + '] = b.[HOA Lien Recording Date]
		--			--,A.[HOA_LIEN_HOA Lien Recorded Document Number_' + @RecNbr3 + '] = b.[HOA Lien Recorded Document Number]
		--			--,A.[HOA_LIEN_DocType_' + @RecNbr3 + '] = B.DocType
		--			--,A.[HOA_LIEN_HOA Lien Amount_' + @RecNbr3 + '] = b.[HOA Lien Amount]
		--			--,A.[HOA_LIEN_HOA Lien Name_' + @RecNbr3 + '] = b.[HOA Lien Name]
		--			--,A.[HOA_LIEN_HOA Lien Agency_' + @RecNbr3 + '] = b.[HOA Lien Agency]
		--			--,A.[HOA_LIEN_ORIG HOA Lien Doc Number_' + @RecNbr3 + '] = B.[HOA - Orig Doc Number]
		--			--,
		--			A.[HOA_LIEN_ActiveFlag_' + @RecNbr3 + '] = b.[ActiveFlag]

		--			--Select B.*					
		--			FROM x_Custom_OUTPUT a JOIN 
		--			[HOA_LIEN] as B on 
		--			a.[INPUT KEY] = b.[INPUTKEY]
		--			where B.REcordNumber = ' + @Beginnbroftrans3 + ''
		--			)

					
					
					
		--				--EXEC('Update A
		--				--	SET A.[HOA_LIEN_DocType_' + @RecNbr3 + '] = Upper(b.[FULL_NAME])
		--				--	from x_Custom_OUTPUT a join HOA_LIEN_DOC_TYPE b
		--				--	ON A.[HOA_LIEN_DocType_' + @RecNbr3 + '] = b.[DocType]
		--				--	')

							
					
		--			SET @Beginnbroftrans3 = @Beginnbroftrans3 + 1
				
		--		END


		--		--EXEC(' 
		--		--Update x_Custom_OUTPUT
		--		--set [HOA_LIEN_Nbr of Transactions] = sum(convert(int,[# of Recordings]))
		--		--')

		--END

		--ELSE
		-----------Adding blank fields is there are no records

		--		BEGIN
	
					
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Nbr of Transactions] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Name1_FullName] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_Name2_FullName] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Recording Date] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Recorded Document Number] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_DocType] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Amount] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Name] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_HOA Lien Agency] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_ORIG HOA Lien Doc Number] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LIEN_ActiveFlag] [varchar](250) NULL')

					
		--		END

	
	Select * From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]



		----------------------PFC - USING FLANK ONLY!!!!------------------------------------------------------------------
		------Only looking for newly recorded PFC transactions on properties that are currently in PFC
		------Flag is on Property overall - not individual transactions
		-----Only populating flag hen Property that was NOT previously in PFC is now IN PFC & NOT monitoring for when property goes out of PFC!!!

		ALTER Table x_Custom_OUTPUT ADD [Nbr of PFC Transactions][varchar](250)NULL
		ALTER Table x_Custom_OUTPUT ADD [PFC ActiveFlag][varchar](250)NULL
	
	
	
		Update [zCust_SecureTitleLock].[dbo].[A]
		Set A.[PFC ActiveFlag] = 'Y'
		 From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A 
			join [data].[dbo].[vAssessor_PREMIUM_NEW] as C with(NOLOCK) on A.PropertyID = C.PropertyID
			join [zCust_SecureTitleLock].[dbo].[INPUT_MONITOR] as D with(NOLOCK) on A.[INPUT KEY] = D.INPUTKey
			where 
			A.PropertyID is not null AND A.PropertyID  not like '' and A.PropertyID  not like '0'
			AND C.[PFCFlag] like 'Y'
			AND D.[PFC ActiveFlag] is null
		

		IF (Select count(*) From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] where [PFC ActiveFlag] = 'Y') > 0

		BEGIN
			
			Update [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK]
			Set ToUse = NULL
			where ToUse is not null


			Update [zCust_SecureTitleLock].[dbo].[B]
			Set B.ToUse = 'Y'
			--Select B.* 
				From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
				[zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK] as B with(NOLOCK) on 
				A.[INPUT KEY] = B.RAW_ID
				where 
				A.PropertyID is not null AND A.PropertyID  not like '' and A.PropertyID  not like '0'
				AND A.[PFC ActiveFlag] like 'Y'
				AND B.Doc_Src_Ind like 'P'
				AND Convert(date,B.RecordingDate) > Convert(date,A.INPUTMonitorStartDate)
				and (Convert(date,B.RecordingDate) > Convert(date,A.MAX_PFCDAte)
				OR A.MAX_PFCDAte is null)



			UPdate [zCust_SecureTitleLock].[dbo].[A]
			Set [Nbr of PFC Transactions] = B.TOTAL
			From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A join 
				(Select A.RAW_ID, count(*) as TOTAL From [zCust_SecureTitleLock].[dbo].[w_TransHist_FLANK]  A
				where ToUse like 'Y'
				Group by A.RAW_ID)B
			on A.[INPUT KEY]=  B.RAW_ID

			

		END
	
		
		Select * From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
				----------------------

		Update [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_SecureTitleLock].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_SecureTitleLock].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT KEY] = b.Raw_ID

		Update [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_SecureTitleLock].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] a join [zCust_SecureTitleLock].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT KEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		
	

		----Event Status - Per CR - if any data element has changed.......
		----So have to Tax Year, Tax Amount & Currently Listed & then use the Nbr of Transactions for the other data sets
		-----20210823 - REMOVING Tax Year & Tax Amount from the criteria since these are not charged
		-----20210823 - ADDING Comparing Mailing Address info since this is a fee!!

		UPdate [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		Set [Event Status] = NULL


		Update [zCust_SecureTitleLock].[dbo].[A]
		Set A.[Event Status] = 'Event Found'
		--Select A.[INPUT KEY]
		--,A.LISTONMARKET, B.LISTONMARKET 
		--,A.[PFC ActiveFlag], B.[PFC ActiveFlag] 
		----,A.[Tax Year], B.[Tax Year] 
		----,A.TaxAmt, B.TaxAmt 
		--,A.[Nbr of Deed_MTG Transactions]
		--,A.[Nbr of INVL Transactions]
		--,A.[Nbr of PFC Transactions]
		--,A.[Nbr of HOALien Transactions]
		--,A.MailingFullStreetAddress, B.MailingFullStreetAddress
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT] as A 
		join [zCust_SecureTitleLock].[dbo].[INPUT_MONITOR] as B on A.[INPUT KEY] = B.INPUTKey
		where 
		ISNULL(A.LISTONMARKET,'') <> ISNULL(B.LISTONMARKET,'') OR
		ISNULL(A.[PFC ActiveFlag],'') <> ISNULL(B.[PFC ActiveFlag],'') OR
		--ISNULL(A.[Tax Year],'') <> ISNULL(B.[Tax Year],'') OR
		--ISNULL(A.TaxAmt,'') <> ISNULL(B.TaxAmt,'') OR
		A.[Nbr of Deed_MTG Transactions] > 0 OR
		A.[Nbr of INVL Transactions] > 0 OR
		A.[Nbr of PFC Transactions] > 0 OR
		A.[Nbr of HOALien Transactions] > 0 OR
		ISNULL(A.MailingFullStreetAddress,'') <> ISNULL(B.MailingFullStreetAddress,'')


		Update [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		Set [Event Status] = 'Event Not Found'
		where ISNULL([Event Status],'') like ''


	Select [AddressStandardization], count(*) From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
	Group by [AddressStandardization]

	Select [Property Status], count(*) From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
	Group by [Property Status]

	Select [Coverage Status], count(*) From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
	Group by [Coverage Status]

	Select [Event Status], count(*) From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
	Group by [Event Status]
	

		Select [INPUT KEY]
		,INPUTMonitorStartDate,	MAX_DEEDDATE,	MAX_MTGDATE	,MAX_INVLDATE	,MAX_HOALIENDATE	,MAX_PFCDATE,	LISTONMARKET
		,MailingFullStreetAddress,MailingFullStreetAddress_TRACKED,DATE_ADDED
		,CurrentlyListedInd, [Nbr of Deed_MTG Transactions], [Nbr of INVL Transactions],[New_INVL_Flag]
		,[Nbr of HOALien Transactions]	,[HOALien ActiveFlag]
		,[Nbr of PFC Transactions]	,[PFC ActiveFlag]
		From [zCust_SecureTitleLock].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event Found'


		

END





