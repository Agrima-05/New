SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


-- ================================================================================
-- Description:	parse CoAgent data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_300_CoSellingAgent]

AS
BEGIN

	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		TRUNCATE TABLE agent.CoSellingAgents_Batch

		INSERT INTO [src_platlabs].[agent].[CoSellingAgents_Batch]
			SELECT [coSellAgentID],coSellAgent_UID,[mls_id],[mls_listing_id],SellingAgentFullName,FirstName,LastName,Email,CoSellAgentPhone,LicenseNumber
			,CoSellingOffice_Array.id as OfficeID,CoSellingOffice_Array.name as OfficeName,CoSellingOffice_Array.phone as OfficePhone, CoSellingOffice_Array.[uid] as OfficeUID
			FROM 
			(Select [id] [coSellAgentID], [uid] coSellAgent_UID,[mls_id],[mls_listing_id],name as SellingAgentFullName
				,first_name as FirstName
				,last_name as LastName
				,email as Email
				,phone as CoSellAgentPhone
				,license_number as LicenseNumber
				,office
				,GetDate() as LoadDate
		 from (Select mls_id,mls_listing_id,[agents_co_selling_agent] from [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK) 
			Where [agents_co_selling_agent] is not null) info
				CROSS APPLY OPENJSON([agents_co_selling_agent]) WITH(
					[id] varchar(500)
					  ,[uid] varchar(20)
					  ,[name] varchar(100)
					  ,[first_name] varchar(20)
					  ,[last_name] varchar(20)
					  ,[email] varchar(200)
					  ,[phone] varchar(20)
					  ,[license_number] varchar(20)
					  ,[office] nvarchar(max) AS JSON
					 ) as CoSelling_Array) a
					 CROSS APPLY OPENJSON([office]) WITH(
						[id] varchar(500)
					  ,[name] varchar(100)
					  ,[phone] varchar(20)
					  ,[uid] varchar(20)
					  ) as CoSellingOffice_Array
	WHERE coSellAgent_UID is not null


		Delete from [src_PlatLabs].[dbo].[a] 
		FROM [src_PlatLabs].[agent].[CoSellingAgents] a JOIN [src_PlatLabs].[agent].[CoSellingAgents_Batch] b
			ON a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id

		insert into [src_PlatLabs].[agent].[CoSellingAgents]
		Select *,GetDate() from [src_PlatLabs].[agent].[CoSellingAgents_Batch] WITH(NOLOCK)

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




