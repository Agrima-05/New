SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Address Standardization and Property Matching
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_222_Post_ListingsJSON]

AS
BEGIN

	SET NOCOUNT ON;
		declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


	DELETE FROM [src_PlatLabs].[listing].[ListingsRaw_JSON]
	WHERE [uid] in(Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch])

	INSERT INTO [src_PlatLabs].[listing].[ListingsRaw_JSON]([normalized_address]
      ,[photos]
      ,[geo_data]
      ,[features]
      ,[agents_listing_agent]
      ,[agents_co_listing_agent]
      ,[agents_selling_agent]
      ,[agents_co_selling_agent]
      ,[mls_id]
      ,[mls_list_date]
      ,[mls_listing_id]
      ,[uid]
      ,[LoadDate])
	Select [normalized_address]
      ,[photos]
      ,[geo_data]
      ,[features]
      ,[agents_listing_agent]
      ,[agents_co_listing_agent]
      ,[agents_selling_agent]
      ,[agents_co_selling_agent]
      ,[mls_id]
      ,[mls_list_date]
      ,[mls_listing_id]
      ,[uid]
      ,[LoadDate] 
	FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] with (nolock)

EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

		
END




