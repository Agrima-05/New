SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- Create date: 20151215
-- Description:	Step 1 of Process, Address Standardization and Matching
-- =============================================
CREATE PROCEDURE [zCust_PennyMac].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
	
AS
BEGIN

		
		SET CONCAT_NULL_YIELDS_NULL OFF

		------CLEAR FOR TESTING----
		--Truncate table [INPUT_MONITOR]
		--Truncate table INPUT_MONITOR_COMPLETE
		--Truncate table INPUT_RAW_INTERNAL_TPS
		--Truncate table INPUT_RAW_INTERNAL_TPS_HIST
		--Truncate table X_CUSTOM_OUTPUT_ALL
		
		---Select * From ADS_COUNTS


		--Truncate table [INPUT_MONITOR]

	

		--Select * From [INPUT_MONITOR]
			
		Truncate table INPUT_IN

		INSERT INTO [zCust_PennyMac].[dbo].[INPUT_IN](INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZIP,InputBorrowerLastName)
		Select 
		convert(bigint,A.[LoanID])
        ,REPLACE(A.[Address],'  ',' ')
        ,REPLACE(A.[City],'  ',' ')
        ,REPLACE(A.[State],'  ',' ')
        ,REPLACE(A.[Zip],'  ',' ')
     --   ,[Original Loan Amount]
     --   ,[Investor Insurer Group]
	    --,[Borrower Name]
		,case when REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','') like '% %' 
		then right(REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','')
		,len(REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','')) - 
		Charindex(' ',REPLACE(REPLACE((A.[Borrower Name]),' JR',''),' SR','')))
		else REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','') end
		
		 FROM [zCust_PennyMac].[dbo].[INPUT_RAW_CUST] as A 
		 left outer join [zCust_PennyMac].[dbo].[INPUT_MONITOR] as B on 
		 convert(bigint,A.[LoanID]) = B.[Loan Number]
		 where isnull([LoanID],'') not like ''
		 and B.[Loan Number] is null



		-- Truncate table INPUT_IN

		--INSERT INTO INPUT_IN(INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZIP,InputBorrowerLastName)
		--Select 
		--convert(bigint,A.[Loan Number])
  --      ,REPLACE(A.[Address],'  ',' ')
  --      ,REPLACE(A.[City],'  ',' ')
  --      ,REPLACE(A.[State],'  ',' ')
  --      ,REPLACE(A.[Zip],'  ',' ')
  --   --   ,[Original Loan Amount]
  --   --   ,[Investor Insurer Group]
	 --   --,[Borrower Name]
		--,case when REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','') like '% %' 
		--then right(REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','')
		--,len(REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','')) - 
		--Charindex(' ',REPLACE(REPLACE((A.[Borrower Name]),' JR',''),' SR','')))
		--else REPLACE(REPLACE(A.[Borrower Name],' JR',''),' SR','') end
		
		-- FROM  [INPUT_MONITOR] as A
		-- where isnull([Loan Number],'') not like ''
		-- and Sent_To_TierII_YN is null
		 




		Insert into [zCust_PennyMac].[dbo].[INPUT_MONITOR](
		[Loan Number]
      ,[Borrower Name]
      ,[Second Borrower Name]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Original Loan Amount]
      ,[Origination Date]
      --,[Investor Insurer Group]
      ,[DATE_RECEIVED])

		Select 
	   convert(bigint,[LoanID])
      ,[Borrower Name]
      ,[Second Borrower Name]
      ,REPLACE([Address],'  ',' ')
      ,REPLACE([City],'  ',' ')
      ,REPLACE([State],'  ',' ')
      ,REPLACE([Zip],'  ',' ')
      ,[Original Loan Amount]
	  --,NULL
      ,convert(date,[Origination Date])
      --,[Investor Insurer Group]
	  ,convert(datetime,Getdate())
		FROM [zCust_PennyMac].[dbo].[INPUT_RAW_CUST]
		where isnull([LoanID],'') not like ''
		--From INPUT_RAW_20200923

		 
				
		Select * From [zCust_PennyMac].[dbo].[INPUT_IN]

		Select count(*) From [zCust_PennyMac].[dbo].[INPUT_IN]

		Select INPUTKEY, count(*) From [zCust_PennyMac].[dbo].[INPUT_IN]
		Group by INPUTKEY
		having count(*) > 1

		Select * From [zCust_PennyMac].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_PennyMac].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'

		Select * From [zCust_PennyMac].[dbo].[INPUT_IN]
		where INPUTAddress like '%  %'

		Select * From [zCust_PennyMac].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'
		

		UPDATE [zCust_PennyMac].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_PennyMac].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_PennyMac].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_PennyMac].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_PennyMac].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_PennyMac].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2

		

    EXEC [zCust_PennyMac].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 2 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_PennyMac].[dbo].[PennyMac_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_PennyMac].[dbo].[PennyMac_STD])
					END
			END


    EXEC [zCust_PennyMac].[dbo].[usp_100c_sp_ASP_Cust_STD]

	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_PennyMac'
	
	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_PennyMac'


	Select CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_PennyMac].[dbo].[a_PropMatch_WORK]
	group by CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END 

	Select CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_PennyMac].[dbo].[a_PropMatch_WORK_FLANK]
	group by CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END 

	--Insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.a_PropMatch_Work
	--Select * From a_PropMatch_Work

	--EXEC dbo.usp_201_CreateUniqueRefId
	--EXEC [dbo].[usp_225_Get_Legal]


	--EXEC dbo.usp_211_Create_TransHist_Rev5

	EXEC [zCust_PennyMac].[dbo].[usp_502_Pull_DTDB_DATA_V2]

	EXEC [zCust_PennyMac].[dbo].[usp_502_Pull_FLANK_DATA_V2]

		
	

END


