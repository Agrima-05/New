/* Source: AZUVNSQLDTDB003.datatree.local | HOA | OA.LinkOwnerAssociationContact | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */


CREATE PROCEDURE [HOA].[OA].[LinkOwnerAssociationContact]
AS

	Truncate Table OA.OwnerAssociationContact

	INSERT INTO [HOA].[OA].[OwnerAssociationContact]
	Select OaId, ContactId, ConfidenceScore, EarliestRecordingDate, LastRecordingDate from (
		SELECT oa.Id as OaId, c.Id as ContactId, MAX(soac.ConfidenceScore) as ConfidenceScore, MIN(soac.EarliestRecordingDate) as EarliestRecordingDate, MAX(soac.LastRecordingDate) as LastRecordingDate
		, DENSE_RANK() OVER (Partition By oa.Id Order by Case When c.InitialSourceId = 11 THEN 0 ELSE 1 END) as rownum
		FROM [HOA].[Staging].[OwnerAssociation] soa
		INNER JOIN [HOA].[Staging].[OwnerAssociationContact] soac ON soa.Id = soac.OwnerAssociationId
		INNER JOIN [HOA].[Staging].[Contact] sc ON soac.ContactId = sc.Id
		INNER JOIN [HOA].[OA].[OwnerAssociation] oa ON soa.MasterId = oa.Id
		INNER JOIN [HOA].[OA].[Contact] c ON sc.MasterId = c.Id
		WHERE soac.StatusId NOT IN (3, 6)
		Group by oa.Id, c.Id, c.InitialSourceId
	) g where rownum = 1
	--LEFT JOIN OA.OwnerAssociationContact b ON oa.Id = b.OwnerAssociationId AND c.Id = b.ContactId
	--WHERE b.OwnerAssociationId IS NULL
	
 Update [HOA].[OA].[c]
 Set ContactTypeId = 3
 FROM [HOA].[OA].[Contact] c
  inner join [HOA].[OA].[OwnerAssociationContact] oac on oac.ContactId = c.Id
  inner join [HOA].[OA].[OwnerAssociation] o on o.Id= oac.OwnerAssociationId
 where EXISTS (Select oac.ContactId from [HOA].[OA].[OwnerAssociationContact] oac 
 where oac.ContactId = c.Id
 Group by oac.ContactId
 having count(1) > 1
 )
 and Email like '%@%law%'
 and c.ContactTypeId <> 3

Update [HOA].[OA].[c]
 Set ContactTypeId = 3
 FROM [HOA].[OA].[Contact] c
  inner join [HOA].[OA].[OwnerAssociationContact] oac on oac.ContactId = c.Id
  inner join [HOA].[OA].[OwnerAssociation] o on o.Id= oac.OwnerAssociationId
WHERE o.OwnerAssociationTypeId = 6
 AND c.ContactTypeId <> 3

 Update [HOA].[OA].[c]
 Set ContactTypeId = 2 
 FROM [HOA].[OA].[Contact] c
  inner join [HOA].[OA].[OwnerAssociationContact] oac on oac.ContactId = c.Id
  inner join [HOA].[OA].[OwnerAssociation] o on o.Id= oac.OwnerAssociationId
 where EXISTS (Select oac.ContactId from [HOA].[OA].[OwnerAssociationContact] oac 
 where oac.ContactId = c.Id
 Group by oac.ContactId
 having count(1) > 1
 )
 and (c.ContactTypeId = 1 OR c.ContactTypeId IS NULL)

