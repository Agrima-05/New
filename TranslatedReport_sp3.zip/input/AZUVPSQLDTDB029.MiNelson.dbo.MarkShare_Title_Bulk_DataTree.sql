/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_Bulk_DataTree | type=P */





-- ===============================================================================================
-- Author:		My Phan
-- Create date: 1/14/2020
-- Description:	Create MarkShareTitle_DATATree
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_Bulk_DataTree]
                
AS 


SET NOCOUNT ON

BEGIN
 

 -------------------------Check lender clean---------------------------------------

 
--SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK]
--    where (lender like'L%N%DePO%' and [Lender Clean] not like 'LOANDEPOT.COM, LLC')
--	or (lender like 'Bank%America%' and [Lender Clean] not like 'BANK OF AMERICA, N.A.')
--	or (lender like 'Well%Fargo%' and [Lender Clean] not like 'WELLS FARGO BANK, NATIONAL ASSOCIATION')
--	or( lender like  'Qu%ken%Lo%n%' and [Lender Clean] not like 'QUICKEN LOANS INC')
--	or (lender like 'US Bank%' and [Lender Clean] not like 'U.S. BANK N.A.')
--		order by 1

--		SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK]
 -- where lender like 'bank%america%fork%'

------ Loan depot

--update a
--set a.[Lender Clean] = 'LOANDEPOT.COM, LLC'
----SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK] a
--    where (lender like 'L%N%DePO%' and [Lender Clean] not like 'LOANDEPOT.COM, LLC')

       ---Bank of America


--update a set a.[Lender Clean] = 'BANK OF AMERICA, N.A.'
----SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK] a
--    where lender like 'Bank%America%' and [Lender Clean] not like 'BANK OF AMERICA, N.A.'
--	and [Lender Clean] not like 'BANK OF AMERCAN FORK'
--	and lender  not in  ('BANK TRUST CO AMERICAS', 'BANK TRUST COMPANY AMERICAS', 'BANKCO POPULAR NORTH AMERICA', 'BANKING CONSULTANTS/AMERICA LL', 'BANK OF AMERICAN FORK')

---- Wells Fargo
--update a set a.[Lender Clean] ='WELLS FARGO BANK, NATIONAL ASSOCIATION'
----SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK] a
--    where lender like 'W%l%F%rgo%' and [Lender Clean] not like 'WELLS FARGO BANK, NATIONAL ASSOCIATION'

--- Quicken Loans
--update a
--set a.[Lender Clean] = 'QUICKEN LOANS INC.'
----SELECT *
--  FROM [MiNelson].[mktshr].[LenderClean_BK] a
--    where lender like 'Qu%ken%Lo%n%' and [Lender Clean] not like 'QUICKEN LOANS INC'



----- US BanK
--update a
--set a.[Lender Clean] = 'U.S. BANK N.A.'
------SELECT *
----  FROM [MiNelson].[mktshr].[LenderClean_BK] a
----    where (lender like 'US Bank%' or lender like 'US BANKK') and [Lender Clean] not like 'U.S. BANK N.A.'
	


-------------------------------------------------------------------------------------------------
 
  --------Incremental Process 12/10/2019
 -- ---652562, 863333
 -- select count (*) from [MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental]

 ----   select * into [MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental_save_20250605] 
	----from [MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental]

 ---- ---76,172,323
 ---- select count (*) from [MiNelson].[mktshr].[TitleMarketShare_Bulk]
 ---- where date > '2020-01-01'

 -- --32,252,967
 --   select count (*) from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]


  ----- Update title and lender clean tables
  --  select convert (varchar(10),GETDATE(), 126)

-----------------------------------------------------------
-----------[mktshr].[DT_TitleCompanyHierarchy_BK]
-----------------------------------------------------------





truncate table  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental]

insert into  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental]
  ([Marketshare]
      ,[TitleCompany]
	  ,[TitleCompany Display]
      ,[Source]
      ,[Updated]
      ,[Orig Source]
      ,[DB_Count]
      ,[Perm_Count])
	  (
 SELECT  case when [Marketshare] = 'FAF' then 'FIRST AMERICAN TITLE'
		when [Marketshare] = 'FNF' then 'FIDELITY NATIONAL TITLE'
		when [Marketshare] = 'ORI' then 'OLD REPUBLIC TITLE'
		when [Marketshare] = 'STC' then 'STEWART TITLE'
		else Marketshare end as Marketshare
      ,left([TitleCompany],60)
	  ,[TitleCompany Display]
      ,[Source]
      ,[Updated]
      ,[Orig Source]
      ,[DB_Count]
      ,[Perm_Count]
	  FROM [MiNelson].[mktshr].[TitleCompanyHierarchy_BK]
	 -- where  --right (source, 8 ) = '20200109' or right(source, 10) = '2020-01-09'
  --right (source, 8 )  =  convert (varchar(10),GETDATE(), 112)
  --or right(source, 10) = convert (varchar(10),GETDATE(), 126)
  )
 

   update [MiNelson].[dbo].[a]
   set  a.[TitleCompany] = replace([TitleCompany] , ',', '')
  -- select *
   from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental] a
   where TitleCompany like '%,%'

    update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')
   --select *
	 from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental] a
   where [TitleCompany Display] like '%,%'


 --- deleteing updated records 
  --Delete from  [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK]
  --where titlecompany in 
  --(select titlecompany from Minelson.[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental])

---Insert to main table

truncate table [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK]

insert into [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK]
([Marketshare]
      ,[TitleCompany]
	  ,[TitleCompany Display]
      ,[Source]
      ,[Updated]
      ,[Orig Source]
      ,[DB_Count]
      ,[Perm_Count])
	  (
SELECT  case when [Marketshare] = 'FAF' then 'FIRST AMERICAN TITLE'
		when [Marketshare] = 'FNF' then 'FIDELITY NATIONAL TITLE'
		when [Marketshare] = 'ORI' then 'OLD REPUBLIC TITLE'
		when [Marketshare] = 'STC' then 'STEWART TITLE'
		else Marketshare end as Marketshare
      ,left([TitleCompany],60)-- ,[TitleCompany]
	  ,[TitleCompany Display]
      ,[Source]
      ,[Updated]
      ,[Orig Source]
      ,[DB_Count]
      ,[Perm_Count]
	  FROM [MiNelson].[mktshr].[TitleCompanyHierarchy_BK])

     update [MiNelson].[dbo].[a]
   set  a.[TitleCompany] = replace([TitleCompany] , ',', '')
  -- select *
   from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK] a
   where TitleCompany like '%,%'


   update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')
   --select *
	 from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK] a
   where [TitleCompany Display] like '%,%'


--insert into [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK]
--([Marketshare]
--      ,[TitleCompany]
--	  ,[TitleCompany Display]
--      ,[Source]
--      ,[Updated]
--      ,[Orig Source]
--      ,[DB_Count]
--      ,[Perm_Count])
--	  (
--SELECT  [Marketshare]
--      ,[TitleCompany]
--	  ,[TitleCompany Display]
--      ,[Source]
--      ,[Updated]
--      ,[Orig Source]
--      ,[DB_Count]
--      ,[Perm_Count]
--  FROM Minelson.[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental])

SELECT  [TitleCompany]
     ,count(*)
  FROM [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK]
  group by [TitleCompany]
	having count (*) > 1



-----------------------------------------------------------
-----------[MiNelson].[mktshr].[DT_TitleCompanyTable_BK]
------------------------------------------------------------

  --select * from [MiNelson].[mktshr].[TitleCompanyTable_BK]
  --where --updated = '2020-02-06' 
  --updated = convert (varchar(10),GETDATE(), 126)

  truncate table [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental]

  insert into [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental]
  ( [Title Company]
      ,[Title Company Clean]
      ,[Source]
      ,[Notes]
      ,[Count]
      ,[Table_Count]
      ,[DB_Count]
      ,[Updated])
(
  SELECT left([Title Company], 60) as [Title Company]
      ,left([Title Company Clean],60) as [Title Company Clean]
      ,[Source]
      ,[Notes]
      ,null as[Count]
      ,null as [Table_Count]
      ,[DB_Count]
      ,null as[Updated]
  
  from [MiNelson].[mktshr].[TitleCompanyTable_BK]
  --where --updated = '2020-01-09' 
  --updated = convert (varchar(10),GETDATE(), 126) 
  )

    update [MiNelson].[dbo].[a]
	set a.[Title Company Clean] = replace([Title Company Clean] , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental] a
   where [Title Company Clean] like '%,%'



 
  
  --- delete updating records

--delete from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK]  
-- where [title company] in ( select [title company] 
-- from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental] )
 
  --- add to main table

  truncate table [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] 

  insert into [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] 
  ([Title Company]
      ,[Title Company Clean]
      ,[Source]
      ,[Notes]
      ,[Count]
      ,[Table_Count]
      ,[DB_Count]
      ,[Updated])
	  (
 SELECT  left([Title Company], 60) as [Title Company]
      ,left([Title Company Clean],60) as [Title Company Clean]
      ,[Source]
      ,[Notes]
      ,null as[Count]
      ,null as [Table_Count]
      ,[DB_Count]
      ,Null as [Updated]
  
  from [MiNelson].[mktshr].[TitleCompanyTable_BK]
  )


     update [MiNelson].[dbo].[a]
	set a.[Title Company Clean] = replace([Title Company Clean] , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] a
   where [Title Company Clean] like '%,%'

  --insert into [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] 
  --([Title Company]
  --    ,[Title Company Clean]
  --    ,[Source]
  --    ,[Notes]
  --    ,[Count]
  --    ,[Table_Count]
  --    ,[DB_Count]
  --    ,[Updated])
	 -- (
  --SELECT  [Title Company]
  --    ,[Title Company Clean]
  --    ,[Source]
  --    ,[Notes]
  --    ,[Count]
  --    ,[Table_Count]
  --    ,[DB_Count]
  --    ,[Updated]
  --FROM [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental]
  --)

 -- select * from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental]

----------------------------------------------------------
----------[MiNelson].[mktshr].[LenderClean_BK]
----------------------------------------------------------


  --select * from 
  --[MiNelson].[mktshr].[LenderClean_BK] b
  --where --updated =  '2020-01-09'
  -- updated = convert (varchar(10),GETDATE(), 126)

   truncate table [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental]

   insert into [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental]
   ([Lender]
      ,[Lender Clean]
      ,[Lender Code]
      ,[NMLSID]
      ,[Count]
      ,[Source]
      ,[Updated]
      ,[Right_NMLSID]
      ,[NMLSID2])
	  (
   SELECT   [Lender]
      ,[Lender Clean]
      ,null as [Lender Code]
      ,[NMLSID]
      ,[Count]
      ,null as [Source]
      ,[Updated]
      ,null as [Right_NMLSID]
      , null as [NMLSID2]
from   [MiNelson].[mktshr].[LenderClean_BK] 
  --where --updated =  '2020-01-09'
  -- updated = convert (varchar(10),GETDATE(), 126)
  )

     update [MiNelson].[dbo].[a]
  set a.[lender clean] = replace([lender clean] , ',', '') 
  --select *
  from  [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental] a
   where [lender clean] like '%,%'

  ----- deleting updated records
  --Delete from [MiNelson].[mktshr].[DT_LenderClean_BK]
  --where lender in 
  --(select lender from [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental])

  --- add to main table
  truncate table  [MiNelson].[mktshr].[DT_LenderClean_BK]

    insert into [MiNelson].[mktshr].[DT_LenderClean_BK]
  ([Lender]
      ,[Lender Clean]
      ,[Lender Code]
      ,[NMLSID]
      ,[Count]
      ,[Source]
      ,[Updated]
      ,[Right_NMLSID]
      ,[NMLSID2])
	  (
  SELECT  [Lender]
      ,[Lender Clean]
      ,[Lender Code]
      ,[NMLSID]
      ,[Count]
      ,[Source]
      ,[Updated]
      ,[Right_NMLSID]
      ,[NMLSID2]
  FROM [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental])

     update [MiNelson].[dbo].[a]
  set a.[lender clean] = replace([lender clean] , ',', '') 
 -- select*
  from  [MiNelson].[mktshr].[DT_LenderClean_BK] a
   where [lender clean] like '%,%'

  --insert into [MiNelson].[mktshr].[DT_LenderClean_BK]
  --([Lender]
  --    ,[Lender Clean]
  --    ,[Lender Code]
  --    ,[NMLSID]
  --    ,[Count]
  --    ,[Source]
  --    ,[Updated]
  --    ,[Right_NMLSID]
  --    ,[NMLSID2])
	 -- (
  --SELECT  [Lender]
  --    ,[Lender Clean]
  --    ,[Lender Code]
  --    ,[NMLSID]
  --    ,[Count]
  --    ,[Source]
  --    ,[Updated]
  --    ,[Right_NMLSID]
  --    ,[NMLSID2]
  --FROM [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental])


 -- select * from  [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental]

-----------------------------------------------------------
-----------[MiNelson].[mktshr].[LenderHierarchy] 
-----------------------------------------------------------

 
 --select * from  [MiNelson].[mktshr].[LenderHierarchy] 
 -- where --updated =  '2020-01-09'
 --  updated = convert (varchar(10),GETDATE(), 126)

truncate table [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental]

insert into [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental]
([UltimateParentLender]
      ,[ParentLender]
      ,[Lender]
      ,[Updated])
	  (
SELECT  [UltimateParentLender]
      ,[ParentLender]
      ,[Lender]
      ,null as [Updated]
 from  [MiNelson].[mktshr].[LenderHierarchy] 
  --where --updated =  '2020-01-09'
  --   updated = convert (varchar(10),GETDATE(), 126)
	 )

	 
        
	update [MiNelson].[dbo].[a]
	set a.lender = replace(lender , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental] a
   where [lender] like '%,%'
   

   update [MiNelson].[dbo].[a]
   set  a.ParentLender = replace(ParentLender , ',', '')
   --select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental] a
   where [ParentLender] like '%,%'


------	 deleting update records
--delete from [MiNelson].[mktshr].[DT_LenderHierarchy]
--where lender in (select lender from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental])

---- insert to main table

truncate table [MiNelson].[mktshr].[DT_LenderHierarchy]

insert into [MiNelson].[mktshr].[DT_LenderHierarchy]
([UltimateParentLender]
      ,[ParentLender]
      ,[Lender]
      ,[Updated])
	  (
SELECT  [UltimateParentLender]
      ,[ParentLender]
      ,[Lender]
      ,[Updated]
  FROM [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental])

       
	update [MiNelson].[dbo].[a]
	set a.lender = replace(lender , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy] a
   where [lender] like '%,%'
   

   update [MiNelson].[dbo].[a]
   set  a.ParentLender = replace(ParentLender , ',', '')
   --select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy] a
   where [ParentLender] like '%,%'


--insert into [MiNelson].[mktshr].[DT_LenderHierarchy]
--([UltimateParentLender]
--      ,[ParentLender]
--      ,[Lender]
--      ,[Updated])
--	  (
--SELECT  [UltimateParentLender]
--      ,[ParentLender]
--      ,[Lender]
--      ,[Updated]
--  FROM [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental])

  select count (*) from [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental]
  select count (*) from [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK]
  select count (*) from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental]
  select count (*) from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK]
  select count (*) from  [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental]
  select count (*) from  [MiNelson].[mktshr].[DT_LenderClean_BK]
  select count (*) from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental]
  select count (*) from [MiNelson].[mktshr].[DT_LenderHierarchy]

--------------------------------------------------------------



/*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]


select  a.*,(case when [zip code] = '' then null else cast ([zip code] as int) end) as ZipInt,
cast (replace(Fips, right (Fips,3),'') as tinyint)  As StateFips,
cast ((case when Residential = 'Yes' then 1 else 0 end) as tinyint) as IsResidential ,
cast ((case when corporate = 'Yes' then 1 else 0 end) as tinyint) as CorporateOwned,
b.Transaction_Type_Code, b.IsSales,c.[Loan_Type_Code], d.Property_Type_Code,
case when [Sales Price]< 300000 then 1
when [Sales Price]>= 300000 and [Sales Price] <= 399999 then 2
when [Sales Price]>= 400000 and [Sales Price] <= 499999 then 3
when [Sales Price]>= 500000 and [Sales Price] <= 599999 then 4
when [Sales Price]>= 600000 and [Sales Price] <= 699999 then 5
when [Sales Price]>= 700000 and [Sales Price] <= 799999 then 6
when [Sales Price]>= 800000 and [Sales Price] <= 899999 then 7
when [Sales Price]>= 900000 and [Sales Price] <= 999999 then 8
when [Sales Price]>= 1000000  then 9 end as SalePriceRange_code,
case when [Loan Amount]< 100000 then 1
when [Loan Amount]>= 100000 and [Loan Amount] <= 299999 then 2
when [Loan Amount]>= 300000 and [Loan Amount] <= 499999 then 3
when [Loan Amount]>= 500000 and [Loan Amount] <= 699999 then 4
when [Loan Amount]>= 700000 and [Loan Amount] <= 899999 then 5
when [Loan Amount]>= 900000  then 6 end as LoanAmountRange_code,
a.[Title Company] as Title_Company_Raw,
a.Lender as Lender_Raw

into   [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
from 
[MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental] a
left join [MiNelson].[mktshr].[DT_TransactionType_lookUp] b
on a.[Transaction Type] = b.[Transaction Type]
left join  [MiNelson].[mktshr].[DT_LoanType_lookUp] c
on a.[loan type] = c.[Loan Type]
left join [MiNelson].[mktshr].[DT_PropertyType_lookUp] d
on a.[Property Type] = d.[Property Type]




--------------------- check might want to use _DT table 





 ----------Adding Marketshare , lender parent and clean names-----------------


--- update clean title company name

  --SELECT a.[Title Company], b.[Title Company Clean]
  --FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  --inner join  [MiNelson].[mktshr].[TitleCompanyTable_BK] b
  -- on a.[title company] = b.[Title Company]

   --- update only len less than 60
   update [MiNelson].[dbo].[a]
   set  a.[Title Company] = b.[Title Company Clean]
    FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  inner join  [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] b
   on a.[title company] = b.[Title Company]
 --  where len([Title Company Clean]) <= 60

--   SELECT a.[Title Company],  c.TitleCompany, c.Marketshare
--  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
--inner join  Minelson.[mktshr].[DT_TitleCompanyHierarchy_BK] c
--   on a.[title company] = c.[TitleCompany]

--  update a
--  set a.[marketshare] = c.Marketshare
--  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
--inner join  Minelson.[mktshr].[DT_TitleCompanyHierarchy_BK] c
--   on a.[title company] = c.[TitleCompany]

select count (*) ---- 610803  ----652562
--select *
FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]


/*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]


   select a.*, c.[Marketshare] as Marketshare, c.[TitleCompany Display]
   into  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]
     FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
left join  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK] c
   on a.[title company] = c.[TitleCompany]



 /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
 select * 
 into [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
 from 
 [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]

 /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_new]

  --- step 2A


 ---- update missing Marketshare

   --select *-- [Title Company], marketshare
   -- from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
   --where [Title Company] is not null and marketshare is null

   update [MiNelson].[dbo].[a] set  marketshare = 'REGIONAL'
    from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
   where [Title Company] is not null and marketshare is null

   -- select *-- [Title Company], marketshare
   -- from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
   --where [Title Company] is not null and [TitleCompany Display] is null

   update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = left([Title Company],25)
   --select left([Title Company],25),*
    from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
   where [Title Company] is not null and [TitleCompany Display] is null

   -- select *-- [Title Company], marketshare
   -- from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
   --where [TitleCompany Display] is null or 
   --len([TitleCompany Display])> 25

   --select * from    [MiNelson].[mktshr].[TitleCompanyTable_BK] a
   --left join  [MiNelson].mktshr.[DT_TitleCompanyHierarchy_BK] b
   --on a.[Title Company Clean] = b.TitleCompany
   --where b.TitleCompany is null


    alter table [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
  add [ParentLender] [varchar](60) NULL


  --------- Step 2B


update [MiNelson].[dbo].[a]
set 
 a.lender= b.[Lender Clean]
       
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  inner join    [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender = b.lender
    where len (b.[Lender Clean]) <=30

	update [MiNelson].[dbo].[a]
set 
 a.lender= left (b.[Lender Clean],30)
       
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  inner join    [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender = b.lender
    where len (b.[Lender Clean]) > 30

  update [MiNelson].[dbo].[a]
  set a.[ParentLender] = c.[parentlender]
 -- select *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  inner join [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender_Raw = b.Lender
  inner join   [MiNelson].[mktshr].[DT_LenderHierarchy]  c
on  b.[Lender Clean] = c.[Lender]



update [MiNelson].[dbo].[a]
set a.parentlender = lender
--select *
 FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
 where lender <> 'unknown' and parentlender is null

 ------------------------------------------------------------------
 ----------Updating for Jerry' s request 01/14/2020
 ------------------------------------------------------------------

 --- cashsale lender from unknown to "NO LENDER"

Update [MiNelson].[dbo].[a]
set a.lender = 'NO LENDER'
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  where [Transaction Type] in  ('Newhome - Cash Sale', 'REO - Cash Sale', 
  'Resale - Cash Sale', 'Subdivision - Cash Sale', 'Timeshare - Cash Sale')
    and Lender  = 'unknown'

	update [MiNelson].[dbo].[a]
	set a.lender = 'UNKNOWN'
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
	where lender = ''

	Update [MiNelson].[dbo].[a]
set a.Parentlender = 'NO LENDER'
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
  where [Transaction Type] in  ('Newhome - Cash Sale', 'REO - Cash Sale', 
  'Resale - Cash Sale', 'Subdivision - Cash Sale', 'Timeshare - Cash Sale')
    and Parentlender = 'unknown'

	update [MiNelson].[dbo].[a]
	set a.Parentlender = 'UNKNOWN'
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
	where Parentlender = ''

	update [MiNelson].[dbo].[a]
	set a.Builder = null
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
	where builder = 'unknown'

	Update [MiNelson].[dbo].[a]
	set a.[Loan to Value] = null
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
	where [Loan to Value] = 'No Data'

	update [MiNelson].[dbo].[a]
	set a.[Title Company] = 'UNKNOWN'
	--select *
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process] a
	where [Title Company] = ''
 -------------------------------------------------------------------

truncate table [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]


insert into  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]
([DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	 ,[TitleCompany Display] 
	 ,[IsSales])
( SELECT  [DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      , case when  [Adjustable Rate] = 'Yes' then 1 else 0 end as [Adjustable Rate]
      ,[Loan Type]
      ,case when [Reverse Mortgage] = 'yes' then 1 else 0 end as [Reverse Mortgage]
      ,case when [Conforming] = 'yes' then 1 else 0 end as  [Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,case when [MTG1_PRIVATE_PARTY_LENDER] = 'y' then 1 else 0 end as [MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	  ,[TitleCompany Display]
	  ,[IsSales]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
 )



 ----- insert into main table


 --Delete update records
  


  -------------------------------------------------------------need to truncate main table for the first time





  Delete 
 -- select *
  from  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] 
where DeedID in (
SELECT deedid
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]
)

--- delete older than 5 years

--select left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 

Delete
--- select *
from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]
where left(date,7) <left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 

Delete
-- select *
from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] 
where left(date,7) <left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 


insert into  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]
([DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	  ,[TitleCompany Display]
	  ,[IsSales])
(SELECT  [DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	  ,[TitleCompany Display]
	  ,[IsSales]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental])

  -----Delete not in Deed
  /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_Delete_temp_bulk_DT') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]

Select m.DeedID,m.DeedSequence 
into [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]
from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] m where not exists
(Select * from [MiNelson].[mktshr].[TitleMarketShare_Bulk] mm 
where mm.DeedID=m.DeedID and mm.DeedSequence=m.DeedSequence)

Delete m from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] m 
inner join [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT] t 
on t.DeedID=m.DeedID and t.DeedSequence=m.DeedSequence

/*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_Delete_temp_bulk_DT') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]

  ---------------------take out comma for lender and title tables------------------------

   update [MiNelson].[dbo].[a]
  set a.[lender clean] = replace([lender clean] , ',', '') 
 -- select*
  from  [MiNelson].[mktshr].[DT_LenderClean_BK] a
   where [lender clean] like '%,%'
        
	update [MiNelson].[dbo].[a]
	set a.lender = replace(lender , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy] a
   where [lender] like '%,%'
   

   update [MiNelson].[dbo].[a]
   set  a.ParentLender = replace(ParentLender , ',', '')
 --  select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy] a
   where [ParentLender] like '%,%'


    update [MiNelson].[dbo].[a]
	set a.[Title Company Clean] = replace([Title Company Clean] , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] a
   where [Title Company Clean] like '%,%'



   update [MiNelson].[dbo].[a]
   set  a.[TitleCompany] = replace([TitleCompany] , ',', '')
  -- select *
   from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK] a
   where TitleCompany like '%,%'


   update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')
  -- select *
	 from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK] a
   where [TitleCompany Display] like '%,%'



  --------------Clean Title company

  --  SELECT  [Title Company], count (*) as count
  --FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]
  --where [Title Company] like '%365%' --and state = 'CA'
  --group by  [Title Company]
  --order by 2 desc


  ---- 
   update [MiNelson].[dbo].[a]
   set  a.[Title Company] = b.[Title Company Clean]
  -- select b.[Title Company Clean] ,*
    FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  inner join  [MiNelson].[mktshr].[DT_TitleCompanyTable_BK] b
   on a.[Title_Company_Raw] = b.[Title Company]
   where a.[Title Company] <> [Title Company Clean] 

  update [MiNelson].[dbo].[a]
  set a.[marketshare] = c.Marketshare
 -- select a.Marketshare , c.Marketshare, *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
inner join  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK] c
   on a.[title company] = c.[TitleCompany]
   where a.Marketshare <> c.Marketshare

   update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = c.[TitleCompany Display]
     -- select a.*, c.[Marketshare] as Marketshare, c.[TitleCompany Display]
       FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
left join  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK] c
   on a.[title company] = c.[TitleCompany]
   where a.[TitleCompany Display] <> c.[TitleCompany Display]


    --------------------------take to check 02/07/2024 ----------------------------------
					
					--update a
					--   set a.[TitleCompany Display] = left([Title Company],25)
					--   --select left([Title Company],25),*
					--	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
					--   where [Title Company] is not null and [TitleCompany Display] is null

					   ------------------------------------------------------------------------------
   -- select *-- [Title Company], marketshare
   -- from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]
   --where [TitleCompany Display] is null or 
   --len([TitleCompany Display])> 25

------ clean lender

--stop Here 



update [MiNelson].[dbo].[a]
set 
 a.lender= b.[Lender Clean]
       
	--   select  a.lender, a.Lender_Raw, b.[Lender Clean]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  inner join    [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender_raw = b.lender
    where len( [Lender Clean]) <= 30
	and lender_raw <> 'unknown'
	and a.lender <> b.[Lender Clean]




	update [MiNelson].[dbo].[a]
set 
 a.lender= left(b.[Lender Clean],30)
       
	--   select  a.lender, a.Lender_Raw, b.[Lender Clean]
	-- select count(*)
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  inner join    [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender_raw = b.lender
    where len( [Lender Clean]) > 30
	and lender_raw <> 'unknown'
	and a.lender <> left(b.[Lender Clean],30)


select distinct lender, ParentLender 
FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]
where lender like 'bank of america%'



 update [MiNelson].[dbo].[a]
  set a.[ParentLender] = left(c.[parentlender],60)
 -- select  a.lender, a.[ParentLender] ,b.[lender clean],left(c.[parentlender],60),  c.[parentlender]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  inner join [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender_raw = b.lender
  inner join   [MiNelson].[mktshr].[DT_LenderHierarchy]  c
on  a.[Lender] = c.[Lender]
where a.[ParentLender] <> left(c.[parentlender],60)
--order by 1


  update [MiNelson].[dbo].[a]
  set a.[ParentLender] = c.[parentlender]
 -- select  a.lender, a.[ParentLender] , c.[parentlender]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  inner join   [MiNelson].[mktshr].[DT_LenderHierarchy]  c
on  a.[Lender] = c.[Lender]
where a.[ParentLender] <> c.[parentlender]

----------------------update historical records when no parent lender in hierarchy table
---------------------parentlender should be equal to lender clean 7/17/2024

 update [MiNelson].[dbo].[a]
 set a.ParentLender = left( b.[Lender Clean],60)
   FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
 left join [MiNelson].[mktshr].[DT_LenderClean_BK] b
  on a.Lender_raw = b.lender
  left join   [MiNelson].[mktshr].[DT_LenderHierarchy]  c
on  b.[Lender Clean] = c.[Lender]
 where a.lender <> 'NO LENDER' and c.ParentLender is null and a.ParentLender is not null 
 --and  deedid in (349462979,430082628,519224953)
 and  a.ParentLender <> b.[Lender Clean]


Update [MiNelson].[dbo].[a]
set a.lender = 'NO LENDER'
--select *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]a
  where [Transaction Type] in  ('Newhome - Cash Sale', 'REO - Cash Sale', 
  'Resale - Cash Sale', 'Subdivision - Cash Sale', 'Timeshare - Cash Sale')
    and Lender  like '%unknown%'

	update [MiNelson].[dbo].[a]
	set a.lender = 'UNKNOWN'
	--select *
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
	where lender = ''

	Update [MiNelson].[dbo].[a]
set a.Parentlender = 'NO LENDER'
--select *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where [Transaction Type] in  ('Newhome - Cash Sale', 'REO - Cash Sale', 
  'Resale - Cash Sale', 'Subdivision - Cash Sale', 'Timeshare - Cash Sale')
    and Parentlender like 'unknown%' 

	update [MiNelson].[dbo].[a]
	set a.Parentlender = 'NO LENDER'
	--select *
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
	where (Parentlender = '' or parentlender is null)
	and lender = 'No lender'


	update [MiNelson].[dbo].[a]
	set a.Parentlender = lender 
	--select *
	from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
	where Parentlender = '' or parentlender is null
	and lender = 'unknown'


 /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_incremental_save]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_incremental_save]

 select * into [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_incremental_save]
  from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_incremental]

   ----- check Take out comma

   
 update [MiNelson].[dbo].[a]
  set a.[Title Company] = replace([title company] , ',', '') 
 -- select * 
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where [Title Company] like '%,%'

    update [MiNelson].[dbo].[a]
  set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')  
   -- select * 
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where [TitleCompany Display]like '%,%'


  update [MiNelson].[dbo].[a]
  set a.lender = replace(lender , ',', '') 
   -- select * 
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where [lender] like '%,%'


   update [MiNelson].[dbo].[a]
  set a.[ParentLender] =  replace([ParentLender] , ',', '')
  -- select * 
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where [ParentLender] like '%,%'

----- Attorney update

--UPDATE b
--SET b.Attorney = SR_LAWYER_NAME
--,b.UpdateDate=convert(VARCHAR(8), getdate(), 112)
--select *
--FROM MiNelson.mktshr.DT_TitleMarketShare_Bulk b WITH (NOLOCK)
--INNER JOIN MiNelson.mktshr.TitleMarketShare_Bulk_Attorney a WITH (NOLOCK) ON a.Deed_DeedID = b.DeedID 
--WHERE b.Attorney = 'UNKNOWN'

UPDATE [MiNelson].[dbo].[b]
SET b.Attorney = a.Attorney
,b.UpdateDate=a.UpdateDate
--select *
FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] b WITH (NOLOCK)
INNER JOIN [MiNelson].[mktshr].[TitleMarketShare_Bulk] a WITH (NOLOCK) ON a.DeedID = b.DeedID and a.DeedSequence = b.DeedSequence
WHERE b.Attorney = 'UNKNOWN' and a.Attorney <> 'UNKNOWN'

------------------------------------------------
    update [MiNelson].[dbo].[a]
	set a.Lender = 'LOANDEPOT.COM LLC'
	,ParentLender ='LOANDEPOT.COM LLC'
	--select *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where
(( lender like  '%Loan%Depot%'  ) 	 and ([Lender] not like 'LOANDEPOT.COM LLC' or 	 [ParentLender] not  like 'LOANDEPOT.COM LLC') ) 

 update [MiNelson].[dbo].[a]
	set a.Lender = 'QUICKEN LOANS INC'
	,ParentLender ='QUICKEN LOANS INC'
	--select *
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
  where
( (lender like   'Quicken%Loan%'   ) 	 and ([Lender] not like 'QUICKEN LOANS INC' or 	 [ParentLender] not  like 'QUICKEN LOANS INC') ) or
(ParentLender like 'Quicken%Loan%' and lender  not like 'QUICKEN LOANS INC')


   ---- stop here

  truncate table [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]


insert into  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]
([DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	 ,[TitleCompany Display]
	 ,[IsSales])
(SELECT  [DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[Rundate]
      ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[UpdateDate]
      ,[ZipInt]
      ,[StateFips]
      ,[IsResidential]
      ,[CorporateOwned]
      ,[Transaction_Type_Code]
      ,[Loan_Type_Code]
      ,[Property_Type_Code]
      ,[SalePriceRange_code]
      ,[LoanAmountRange_code]
      ,[Title_Company_Raw]
      ,[Lender_Raw]
      ,[Marketshare]
      ,[ParentLender]
	  ,[TitleCompany Display]
	  ,[IsSales]
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk])

   /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count]


   select a.[Title Company], count(*) as count
   into [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count]
    FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] a
	   group by a.[Title Company]

update [MiNelson].[dbo].[a]
set a.DB_Count = c.count
from [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental] a
left join [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count] c
 on a.[titlecompany] = c.[Title Company]
 where c.count is not null 


 update [MiNelson].[dbo].[a]
set a.DB_Count = c.count
from  [Minelson].[mktshr].[DT_TitleCompanyHierarchy_BK] a
left join [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count] c
 on a.[titlecompany] = c.[Title Company]
 where c.count is not null 
 
   /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_count]


   ----- Take out comma

   
 update [MiNelson].[dbo].[a]
  set a.[Title Company] = replace([title company] , ',', '') 
 -- select * 
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
  where [Title Company] like '%,%'

    update [MiNelson].[dbo].[a]
  set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')  
  --select *
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
  where [TitleCompany Display]like '%,%'

  update [MiNelson].[dbo].[a]
  set a.[Title Company] = replace([Title Company],'-','')
 -- select * 
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
where [Title Company] like '-%'

    update [MiNelson].[dbo].[a]
  set  a.[TitleCompany Display] = replace([TitleCompany Display],'-','')
  --select *
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
where [TitleCompany Display] like '-%'


  update [MiNelson].[dbo].[a]
  set a.lender = replace(lender , ',', '') 
--  select *
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
  where [lender] like '%,%'


   update [MiNelson].[dbo].[a]
  set a.[ParentLender] =  replace([ParentLender] , ',', '')
  --select *
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental] a
  where [ParentLender] like '%,%'


    update [MiNelson].[dbo].[a]
  set a.[lender clean] = replace([lender clean] , ',', '') 
 -- select *
  from  [MiNelson].[mktshr].[DT_LenderClean_BK_Incremental] a
   where [lender clean] like '%,%'
        
	update [MiNelson].[dbo].[a]
	set a.lender = replace(lender , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental] a
   where [lender] like '%,%'
   

   update [MiNelson].[dbo].[a]
   set  a.ParentLender = replace(ParentLender , ',', '')
 --  select *
    from [MiNelson].[mktshr].[DT_LenderHierarchy_Incremental] a
   where [ParentLender] like '%,%'


    update [MiNelson].[dbo].[a]
	set a.[Title Company Clean] = replace([Title Company Clean] , ',', '')
	--select *
    from [MiNelson].[mktshr].[DT_TitleCompanyTable_BK_Incremental] a
   where [Title Company Clean] like '%,%'



   update [MiNelson].[dbo].[a]
   set  a.[TitleCompany] = replace([TitleCompany] , ',', '')
  -- select *
   from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental] a
   where TitleCompany like '%,%'


   update [MiNelson].[dbo].[a]
   set a.[TitleCompany Display] = replace([TitleCompany Display] , ',', '')
  -- select *
	 from [MiNelson].[mktshr].[DT_TitleCompanyHierarchy_BK_Incremental] a
   where [TitleCompany Display] like '%,%'

   
   -----------------checking---------------------------

  -- 	 SELECT *
  --FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]
  --where ParentLender like '%UNKNOWN Lender%' or lender like '%UNKNOWN Lender%'


   -----------------------------------------------------------------

--   			SELECT *
--  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Bulk]

--    where 
--	( lender like 'American%Pacific%Mortgage%' and ([Lender] not like 'American Pacific Mortgage%'  or [ParentLender] not like 'American Pacific Mortgage%')) or
--	(lender like 'Bank%America%' and ([Lender] not like 'BANK OF AMERICA N.A.' or [ParentLender] not like 'BANK OF AMERICA N.A.')) or
--	lender like 'Bank of the West%' and parentlender not like 'Bank of the West' or
--	 ( lender like 'Broker%Solutions%'  and ([Lender] not like 'BROKER SOLUTIONS INC.%' 	 or [ParentLender] not like 'BROKER SOLUTIONS INC.%')) or
--	 ( lender like 'CALIBER%HOME%LOANS%'   and ([Lender] not like 'CALIBER HOME LOANS INC.%' 	 or [ParentLender] not like 'CALIBER HOME LOANS INC.%')) or
--	(lender like 'Citibank%' 	 and ([Lender] not like 'CITIBANK NA' or 	 [ParentLender] not  like 'CITIGROUP INC.')) or
--	 (lender like 'EQUITY%SMART%' 	 and ([Lender] not like 'EQUITY SMART HOME LOANS INC' or 	 [ParentLender] not  like 'EQUITY SMART HOME LOANS INC')) or
--	 (lender like 'fairway ind%'	 and ([Lender] not like 'FAIRWAY INDEPENDENT MORTGAGE C' or 	 [ParentLender] not  like 'FAIRWAY INDEPENDENT MORTGAGE CORPORATION')) or
--	(lender like 'flag%star%bank%'	 and ([Lender] not like 'FLAGSTAR BANK FSB' or 	 [ParentLender] not  like 'FLAGSTAR BANK FSB')) or
--	(lender like 'Freedom Mortgage%co%'  	 and ([Lender] not like 'FREEDOM MORTGAGE CORPORATION' or 	 [ParentLender] not  like 'FREEDOM MORTGAGE CORPORATION')) or
--	(lender like 'Finance%Of%America%Mort%' 	 and ([Lender] not like 'FINANCE OF AMERICA MORTGAGE LL' or 	 [ParentLender] not  like 'FINANCE OF AMERICA MORTGAGE LLC') )or
--	(lender like  'Finance%Of%America%Re%' 	 and ([Lender] not like  'FINANCE OF AMERICA REVERSE LLC'  or 	 [ParentLender] not  like 'FINANCE OF AMERICA MORTGAGE LLC') )or
--(( lender like 'First%Republic%b%'  ) 	 and ([Lender] not like 'FIRST REPUBLIC BANK' or 	 [ParentLender] not  like 'FIRST REPUBLIC BANK')) or
--(( lender like 'First%Republic%m%g%'  ) 	 and ([Lender] not like 'FIRST REPUBLIC MORTGAGE%' or 	 [ParentLender] not  like 'FIRST REPUBLIC BANK') )or
--(( lender like  'Guild%Mortgage%Company%'  ) 	 and ([Lender] not like 'GUILD MORTGAGE COMPANY' or 	 [ParentLender] not  like 'GUILD MORTGAGE COMPANY')) or
-- (( lender like  'Homebridge%Financial%Services%'   ) 	 and ([Lender] not like 'HOMEBRIDGE FINANCIAL SERVICES' or 	 [ParentLender] not  like 'HOMEBRIDGE FINANCIAL SERVICES INC.')) or
--(( lender like  'Impac%Mortgage%'   ) 	 and ([Lender] not like 'IMPAC MORTGAGE CORP.' or 	 [ParentLender] not  like 'IMPAC MORTGAGE CORP.')) or
--(( lender like  'JPMorgan%Chase%'   ) 	 and ([Lender] not like 'JPMORGAN CHASE BANK NATIONAL%' or 	 [ParentLender] not  like 'JPMORGAN CHASE BANK N.A.') ) or
--(( lender like  '%Loan%Depot%'  ) 	 and ([Lender] not like 'LOANDEPOT.COM LLC' or 	 [ParentLender] not  like 'LOANDEPOT.COM LLC') ) or
--(( lender like   'MUFG%Union%Bank%'  ) 	 and ([Lender] not like 'MUFG UNION BANK N.A.' or 	 [ParentLender] not  like 'MUFG UNION BANK N.A.') ) or
--( (lender like   'Nationstar%Mortgage%'  ) 	 and ([Lender] not like 'NATIONSTAR MORTGAGE LLC' or 	 [ParentLender] not  like 'NATIONSTAR MORTGAGE LLC')) or
-- ( [ParentLender]  like    'Nationstar%M%' and [ParentLender] not  like 'NATIONSTAR MORTGAGE LLC') or
--( (lender like   'Quicken%Loan%'   ) 	 and ([Lender] not like 'QUICKEN LOANS INC' or 	 [ParentLender] not  like 'QUICKEN LOANS INC') ) or
--(ParentLender like 'Quicken%Loan%' and lender  not like 'QUICKEN LOANS INC') or
-- ( (lender like   '%School%First%'   ) 	 and ([Lender] not like 'SCHOOLSFIRST FEDERAL CREDIT UN' or 	 [ParentLender] not  like 'SCHOOLSFIRST FEDERAL CREDIT UNION')) or
-- ( (lender like   '%Well%Fargo%'   ) 	 and ([Lender] not like 'WELLS FARGO BANK NATIONAL ASSO' or 	 [ParentLender] not  like 'WELLS FARGO BANK N.A.') ) or
--((lender like   'united%whole%'   ) 	 and ([Lender] not like 'UNITED WHOLESALE MORTGAGE' or 	 [ParentLender] not  like 'UNITED SHORE FINANCIAL SVCS')) or
--((lender like   'united%shore%'   ) 	 and ([Lender] not like 'UNITED SHORE FINANCIAL SVCS' or 	 [ParentLender] not  like 'UNITED SHORE FINANCIAL SVCS')) or
--( Lender like    'stearns%le%' and parentLender not like    'STEARNS LENDING LLC%' ) or
--( Lender like    'stearns%ba%' and parentLender not like    'STEARNS LENDING LLC%' )
--order by lender



--select count(*) from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_incremental_save]
--select count(*) from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
--select count (*) from [MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental]

 /*IF OBJECT_ID('[MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_process]
 

 ---- Adding Delete records 02/03/2022
-- truncate table [MiNelson].[mktshr].[TitleMarketShare_bulk_Deleted]

 
--insert into  [MiNelson].[mktshr].[TitleMarketShare_bulk_Deleted]
--  (DeedID, DeedSequence)
--	  (
--		SELECT DeedID, DeedSequence
--		FROM [MiNelson].[mktshr].[TitleMarketShare_Delete]
--		 where rundate = convert (varchar(10),GETDATE(), 112)
--  )
 
 --SELECT *
 -- FROM [MiNelson].[mktshr].[TitleMarketShare_Delete]
 -- where rundate = convert (varchar(10),GETDATE(), 112)
  
  --SELECT *
  --FROM [MiNelson].[mktshr].[TitleMarketShare_bulk_Deleted]

END  


