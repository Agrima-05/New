SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_300_Start_Output_OS_National_S20]


AS
BEGIN
	
	SET NOCOUNT ON;

	----20231129 -  We’re not using their Start Date for this solution.  
	----We’re returning the Current Owner on the property for each extract & setting the 
	----Transaction Status field to Event Found when the current owner name doesn’t match the owner name we sent 
	----on that property on the last extract.

		DROP TABLE [dbo].[x_Custom_OUTPUT_S20]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S20](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[INPUT Key][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			[INPUT_Customer ID][varchar](250)NULL,
			[INPUT_UniqueID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[INPUT_CURRENTOWNER][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
			[Current Owner][varchar](250)NULL,
			[Recording Date][varchar](250)NULL,
			[Document Type][varchar](250)NULL,
			[Document #][varchar](250)NULL,

			-------INTERNAL-----
			[TRACKED_OWNERNAME][varchar](250)NULL
			
			
		) ON [PRIMARY]

		


		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] (
		[INPUT Key]
		,[INPUT_Customer ID],
			[INPUT_UniqueID],
			[INPUT_ADDRESS],
			[INPUT_CITY],
			[INPUT_STATE],
			[INPUT_ZIPCODE],
			[TRACKED_OWNERNAME],
			[FIPS],
			[PROPERTYID],
			[INPUT_CURRENTOWNER]
	   )
	
		Select 	INPUTKEY
		,CUSTOMERID
		,UNIQUEID
         ,[Address]
      ,[City]
      ,[State]
      ,[ZipCODE]
	  ,[TRACKED_OWNERNAME]
	  ,FIPS
	  ,[PROPERTYID]
	  ,[INPUT_OWNER]
   
       --Select * 
	   
	   FROM [zCust_OS_National].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null


		------********ONLY RUN FULL PORTFOLIO on 5th of month or next bus day****-------
		DECLARE @TODAY date = convert(date,getdate())
		DECLARE @5th date = (Select top 1  [CalendarDate] FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc) 

		
		IF @TODAY <> @5th
		BEGIN
		
		Delete from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		--Select * 
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as A join [zCust_OS_National].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT KEY] = B.INPUTKEY
		where B.DATE_RECEIVED < convert(Date,getdate())


		END

	  
	  
	  Select top 100 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S20 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S20 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUT Key] = c.RAW_ID

		

		Update [zCust_OS_National].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[RUN Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


		
		Update [zCust_OS_National].[dbo].[a]
		set 
		A.[Coverage Status] = B.TaxrollActive
		--,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE

	
		------------------------------------------------------------------------

		Update [zCust_OS_National].[dbo].[A]
		Set 
		A.[Current Owner] = B.OwnerStdNAME1FULL
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as A join [data].[dbo].[Property] as B with(NOLOCK)
		on A.FIPS = B.FIPS 
		and A.PROPERTYID = B.PropertyID


		-------Ownership Deed---
		   Update [zCust_OS_National].[dbo].[w_TransHist_FLANK] 
		   SET toUse = NULL
		   where toUse is not null

		 

			UPDATE [zCust_OS_National].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[INPUTKey], B.[INPUT Start Date], A.PropertyID,A.Doc_Id,DocumentTypeDesc--, C.*
			FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK] a JOIN [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as B on 
			A.RAW_ID = B.[INPUT Key]  
			where Doc_Src_Ind like 'D'
		


			

		

	Truncate table [dbo].w_TransHist_FLANK_II

	INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate,[PROPERTYID],REO,REOSALE )
SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate ,[PROPERTYID],REO,REOSALE
FROM     [zCust_OS_National].[dbo].[w_TransHist_FLANK]
WHERE  (ToUse = 'Y')


			UPDATE [zCust_OS_National].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC, Documentnbr desc) AS RowNum
				FROM 
			[zCust_OS_National].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		where PROPERTYID like '38080973'
		Order by RAW_ID, RecordingDate
		

		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_OS_National].[dbo].[A]
		Set 
		A.[Recording Date] = B.RecordingDate
		,A.[Document Type] = B.DocumentType
		,A.[Document #] = case when ISNULL(B.FA_YearDocNbrFmt,'') like '' then B.FA_BookPageFmt else B.FA_YearDocNbrFmt end
		--Select B.DocumentType 
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as A join [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] as B with(NOLOCK)
		on A.[INPUT Key] = B.RAW_ID
		WHERE B.RecordNumber = 1


		--Update A
		--Set 
		--A.[Recording Date] = B.CurrSaleRecordingDate
		--,A.[Document Type] = B.CurrSaleDocumentType
		--,A.[Document #] = case when ISNULL(B.CurrSaleFormatDocNbr,'') like '' then B.CurrSaleFormatBook + '.' + B.CurrSaleFormatPage
		--else B.CurrSaleFormatDocNbr end

		--From x_Custom_OUTPUT_S20 as A join data.dbo.Property as B with(NOLOCK)
		--on A.FIPS = B.FIPS 
		--and A.PROPERTYID = B.PropertyID
		--WHERE ISNULL(B.CurrentSaleTransactionID,'') not like ''

		



	
		--Update A
		--Set 
		--A.[Recording Date] = C.RecordingDt
		--,A.[Document Type] = C.DocumentTypeCode
		--,A.[Document #] = case when ISNULL(C.YearDocNbrFrmt,'') like '' then C.BkPgFrmt
		--else C.YearDocNbrFrmt end

		--From x_Custom_OUTPUT_S20 as A join data.dbo.Property as B with(NOLOCK)
		--on A.FIPS = B.FIPS 
		--and A.PROPERTYID = B.PropertyID
		--join data.dbo.Deed as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
		--AND B.FAOwnerTransactionId = C.TransactionID
		--AND ISNULL(B.FAOwnerTransactionId,'') not like ''
		--AND (C.RecordingDt > A.[Recording Date] or isnull(A.[Recording Date],'') like '')

	
		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		set [Recording Date] = convert(date,[Recording Date])
		where [Recording Date] is not null and [Recording Date] not like ''

		--Select [Recording Date] from x_Custom_OUTPUT_S20

		Update [zCust_OS_National].[dbo].[A]
		Set A.[Document Type] = B.CodeDesc
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] as A
		join [global].[dbo].[lkup_Doc_Type] as B on 
		A.[Document Type] = B.DocTypeID

		Select [Document Type], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Document Type]
		ORder by [Document Type]

		----------------------

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_OS_National].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_OS_National].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20] a join [zCust_OS_National].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		Update  [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Set [Transaction Status] = 
		case when ISNULL([Current Owner],'') <> ISNULL(TRACKED_OWNERNAME,'') then 'Event Found'
		else 'Event Not Found' end




		Select [Property Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Address Standardization]

		Select [Transaction Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Transaction Status]

		Select [Coverage Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Coverage Status]

		Select * from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S20]
		where [Property Status] like 'Property Not Found'


END





