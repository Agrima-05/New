/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_insert_hoa_famls | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
CREATE PROCEDURE [Listings].[Listings_dbo].[usp_insert_hoa_famls]
	-- Add the parameters for the stored procedure here  
	@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from  
	-- interfering with SELECT statements.  
	SET NOCOUNT ON;

	-- truncate table listings.dbo.HOA_FAMLS  
	-- Insert statements for procedure here  
	--SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>  
	BEGIN TRY
		DECLARE @update_flag_date VARCHAR(10) = try_cast((
					SELECT TOP 1 update_flag_date
					FROM [LISTINGS].[Listings_dbo].[FA_MLS]
					ORDER BY update_flag_date DESC
					) AS DATE)

		UPDATE [Listings].[Listings_dbo].[a]
		SET [Fee_Type] = 'Home Owner Assessments Fee'
			,[Fee_Amount] = CASE 
				WHEN s.association_fees LIKE '9999%'
					OR s.association_fees LIKE '0.%'
					OR s.association_fees IN (
						'0'
						,'1'
						)
					THEN NULL
				ELSE s.association_fees
				END
			,[Fee_Frequency] = CASE 
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Annual'
						,'Annually'
						,'One Time'
						,'Year'
						,'Yearly'
						,'Yr '
						,'Yr.'
						,'Yr'
						,'Annua'
						,'ANNUAL'
						,'Annually'
						,'ANNUALLY'
						,'Annually'
						)
					THEN 'ANNUALLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Mo'
						,'Mo.'
						,'Month'
						,'Monthly'
						,'Monthly, due Annually'
						,'Monthly, due Quarterly'
						,'Monthly, due Semi-Annually'
						,'Monthly, due Monthly'
						,'Bi-Annual'
						,'bi-Monthly'
						,'Monthl'
						,'Monthly'
						,'MONTHL'
						,'Monthly'
						)
					THEN 'MONTH'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Qt'
						,'Quarterly'
						,'Qr.'
						,'Quart'
						,'Quarte'
						,'Quarterly'
						,'QUARTE'
						,'Quarterly'
						)
					THEN 'QUARTERLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Semi Annual'
						,'Semi Annually'
						,' Semi-Annua'
						,'Semi-Annually'
						,'SemiAnnual'
						,'Semiannually'
						,'SEMANN'
						,'Semi Annual'
						,'Semi Annually'
						,'Semi-'
						,'Semi-Annua'
						,'Semi-Annual'
						,'Semi-Annually'
						,'Semi-Annualy'
						)
					THEN 'SEMI-ANNUALLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'M'
						,'Mandatory'
						,'N/A'
						,'None'
						,'Not Applicable'
						,'Other'
						,'Other/Remarks'
						,'Sa'
						,'See Agent'
						,'Unknown'
						,'Unknown (N)'
						,'Voluntary'
						,'Voluntary HOA '
						,'Daily'
						,'Seasonal'
						,'Week'
						,'Not Applicable'
						,'Other'
						,'Other/Remarks'
						,'Sa'
						,'See Agent'
						)
					OR ISNUMERIC(s.association_fees_frequency) = 1
					OR s.association_fees_frequency IS NULL
					THEN ''
				END
			,[Release_Date] = s.date_last_advertised
			,[UPDATE_FLAG] = 'I'
			,update_flag_date = @update_flag_date
		FROM [LISTINGS].[dbo].[HOA_FAMLS] a
		OUTER APPLY (
			SELECT *
			FROM [listings].[listings_dbo].[FMA_Snapshot_Sean] AS s WITH (INDEX (idx_id_created))
			WHERE (s.id + 1000000000) = a.fee_id
				AND s.created = (
					SELECT MAX(created)
					FROM [LISTINGS].[Listings_dbo].[FMA_Snapshot_Sean]
					)
			) s
		WHERE s.id IS NOT NULL

		--
		-- truncate table LISTINGS.dbo.HOA_FAMLS
		--
		INSERT INTO [listings].[dbo].[HOA_FAMLS] (
			[FEE_ID]
			,[Property_ID]
			,[Fee_Type]
			,[Fee_Amount]
			,[Fee_Frequency]
			,[Release_Date]
			,[UPDATE_FLAG]
			,[UPDATE_FLAG_DATE]
			)
		SELECT --top(50)   
			(s.id) + 1000000000 AS fee_id
			,(s.id) + 1000000000 AS property_id
			,'Home Owner Assessments Fee' AS Fee_Type
			,CASE 
				WHEN s.association_fees LIKE '9999%'
					OR s.association_fees LIKE '0.%'
					OR s.association_fees IN (
						'0'
						,'1'
						)
					THEN NULL
				ELSE s.association_fees
				END AS Fee_Amount
			,CASE 
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Annual'
						,'Annually'
						,'One Time'
						,'Year'
						,'Yearly'
						,'Yr '
						,'Yr.'
						,'Yr'
						,'Annua'
						,'ANNUAL'
						,'Annually'
						,'ANNUALLY'
						,'Annually'
						)
					THEN 'ANNUALLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Mo'
						,'Mo.'
						,'Month'
						,'Monthly'
						,'Monthly, due Annually'
						,'Monthly, due Quarterly'
						,'Monthly, due Semi-Annually'
						,'Monthly, due Monthly'
						,'Bi-Annual'
						,'bi-Monthly'
						,'Monthl'
						,'Monthly'
						,'MONTHL'
						,'Monthly'
						)
					THEN 'MONTH'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Qt'
						,'Quarterly'
						,'Qr.'
						,'Quart'
						,'Quarte'
						,'Quarterly'
						,'QUARTE'
						,'Quarterly'
						)
					THEN 'QUARTERLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'Semi Annual'
						,'Semi Annually'
						,' Semi-Annua'
						,'Semi-Annually'
						,'SemiAnnual'
						,'Semiannually'
						,'SEMANN'
						,'Semi Annual'
						,'Semi Annually'
						,'Semi-'
						,'Semi-Annua'
						,'Semi-Annual'
						,'Semi-Annually'
						,'Semi-Annualy'
						)
					THEN 'SEMI-ANNUALLY'
				WHEN ltrim(rtrim(s.association_fees_frequency)) IN (
						'M'
						,'Mandatory'
						,'N/A'
						,'None'
						,'Not Applicable'
						,'Other'
						,'Other/Remarks'
						,'Sa'
						,'See Agent'
						,'Unknown'
						,'Unknown (N)'
						,'Voluntary'
						,'Voluntary HOA '
						,'Daily'
						,'Seasonal'
						,'Week'
						,'Not Applicable'
						,'Other'
						,'Other/Remarks'
						,'Sa'
						,'See Agent'
						)
					OR ISNUMERIC(s.association_fees_frequency) = 1
					OR s.association_fees_frequency IS NULL
					THEN ''
				END AS Fee_Frequency
			,s.date_last_advertised AS Release_Date
			,'I' AS UPDATE_FLAG
			,@update_flag_date AS UPDATE_FLAG_DATE
	
		FROM [listings].[Listings_dbo].[FMA_Snapshot_Sean] AS s WITH (
				NOLOCK
				,INDEX (idx_id_created)
				)
		WHERE s.created = (
				SELECT max(created)
				FROM [listings].[listings_dbo].[FMA_Snapshot_Sean]
				)
			AND s.association_fees IS NOT NULL
			AND s.association_fees <> '0'
			AND ((s.id) + 1000000000) NOT IN (
				SELECT fee_id
				FROM [LISTINGS].[dbo].[HOA_FAMLS] WITH (
						NOLOCK
						,INDEX (PK_HOA_FAMLS)
						)
				)
			--  
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END
	--select Release_Date , count(1) as cnt from listings.dbo.HOA_FAMLS
	--group by Release_Date
	--order by Release_Date desc
	--select UPDATE_FLAG_DATE  , count(1) as cnt from listings.dbo.HOA_FAMLS
	--group by UPDATE_FLAG_DATE
	--order by UPDATE_FLAG_DATE
	--select top 100 * from listings.dbo.HOA_FAMLS


