SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON







-- =============================================
-- Create date: 20151215
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_SecureTitleLock].[dbo].[usp_502_Pull_DTDB_DATA_V2_WO6] 
	
AS
BEGIN


	SET NOCOUNT ON;

    EXEC [zCust_SecureTitleLock].[dbo].[usp_201_CreateUniqueRefId]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_202_Get_PropertyReference]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_203_Get_DIM_NOVA_DOCUMENT_A_V2]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_204_Get_DOC_XREF]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_205_Get_DIM_NOVA_DOCUMENT_B_V2]

	--EXEC dbo.[usp_205a_Get_DIM_NOVA_DOCUMENT_C_V2]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_206_Get_FCT_DOC_NAME]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_207_Get_DIM_CLNAME]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_208_Get_PreForeclosure]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_209_Get_RAS]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_210_Get_ASSR]

	EXEC [zCust_SecureTitleLock].[dbo].[usp_210b_Get_DEEDHIST]

	EXEC [zCust_SecureTitleLock].[dbo].[usp_213_Get_DEED]

	EXEC [zCust_SecureTitleLock].[dbo].[usp_215_Get_DM_Data_Status]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_216_Get_LastSaleData]

    EXEC [zCust_SecureTitleLock].[dbo].[usp_220_Get_AVM]

    --EXEC dbo.usp_220_Get_ListingData

	--EXEC [dbo].[usp_221_Get_SoftClose]

	EXEC [zCust_SecureTitleLock].[dbo].[usp_211_Create_TransHist_Rev5_WO6]

	

	--EXEC dbo.usp_212_Create_ImagesToPull



END




