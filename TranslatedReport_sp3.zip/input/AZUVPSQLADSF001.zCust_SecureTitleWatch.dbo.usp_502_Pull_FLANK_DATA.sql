SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





-- =============================================
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_SecureTitleWatch].[dbo].[usp_502_Pull_FLANK_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK
		UPDATE [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK]
		SET FIPS = '0' + FIPS
		WHERE LEN(FIPS)=4

		

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_SecureTitleWatch].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') like '' and  ISNULL(A.BkPgFrmt,'') like '' then  DocNbrSrce 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'')  like ''  and  ISNULL(A.BkPgFrmt,'') not like '' then  BkPgFrmt 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') not like '' then A.YearDocNbrFrmt
		else A.CMTIDInstNbr end as DocNbrSrce
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower1
		, CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END as BuyerBorrower2
		
		,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,CASE WHEN Seller2FullName is NULL THEN Seller2CompanyName ELSE Seller2FullName END SellerLender2
		,SaleDate,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,a.Loan1LenderName as NewLenderAssignee
		,A.Buyer1FirstName,A.Buyer1FirstNameMiddleInitial,A.Buyer1LastName, A.Buyer1LastNameOrCorpName
		,case when A.REO = 1 then 'R' else NULL End as REO
		,A.TitleCompanyName
		INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_DEEDS]
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.DeedTransactionType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES

		IF  EXISTS (SELECT * FROM [zCust_SecureTitleWatch].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') like '' and  ISNULL(A.BkPgFrmt,'') like '' then  DocNbrSrce 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'')  like ''  and  ISNULL(A.BkPgFrmt,'') not like '' then  BkPgFrmt 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') not like '' then A.YearDocNbrFrmt
		else A.CMTIDInstNbr end as DocNbrSrce
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower1
		, case when Borrower2FullName is null then Borrower2CompanyName else Borrower2FullName end as BuyerBorrower2
		,LenderName AS SellerLender
		,NULL as  SellerLender2
		,LoanAmount,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.LenderName as NewLenderAssignee,ContractDate
		,A.Borrower1FirstName,A.Borrower1FirstNameMiddleInitial,A.Borrower1LastName,A.Borrower1LastNameMiddleInitial
		,A.LoanType
		,'N' as Purchase
		,LoanInterestRate as LoanInterestRate
		,TypeFinance as TypeFinance
		,LoanTermMonths as LoanTerm
		,A.TitleCompanyName
		INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_MTG]
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d  with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.LoanTransType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		ALTER TABLE [w_FLANK_MTG] ALTER COLUMN [SellerLender2][varchar](250)NULL


		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,case when Loan1TransactionID is null then TransactionId else Loan1TransactionID end,FAPropertyID,Loan1RecordingDt
		--,Loan1Document
		--,case when ISNULL(A.Loan1CMTIDInstNbr,'') like '' then  Loan1Document else A.Loan1CMTIDInstNbr end as Loan1Document
		,case when ISNULL(A.Loan1CMTIDInstNbr,'') like '' and ISNULL(A.Loan1YearDocNbrFmt,'') like '' then  Loan1Document 
		when ISNULL(A.Loan1CMTIDInstNbr,'') like '' and ISNULL(A.Loan1YearDocNbrFmt,'') not like '' then A.Loan1YearDocNbrFmt
		else A.Loan1CMTIDInstNbr end as Loan1Document

		,Loan1Book,Loan1Page,NULL,NULL
		, left(case when Buyer1FullName is null then Buyer1CompanyName else Buyer1FullName end,70) as BuyerBorrower1
		, left(case when Buyer2FullName is null then Buyer2CompanyName else Buyer2FullName end,70) as BuyerBorrower2
		,left(Loan1LenderName,40) AS SellerLender
		,left(Loan2LenderName,40) AS SellerLender2
		,Loan1Amount,Loan1DocumentTypeCode,d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,left(a.Loan1LenderName,40) as NewLenderAssignee,NULL
		,left(A.Buyer1FirstName,40),left(A.Buyer1FirstNameMiddleInitial,40),left(A.Buyer1LastName,60), left(A.Buyer1LastNameOrCorpName,40)
		,A.Loan1Type 
		,'Y' as Purchase
		,Loan1InterestRate
		,Loan1TypeFinance
		,Loan1TermMonths as LoanTerm
		,TitleCompanyName
		--Select * 
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		AND a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt 

		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,case when Loan2TransactionID is null then TransactionId else Loan2TransactionID end,FAPropertyID,Loan2RecordingDt
		--,Loan2Document
		--,case when ISNULL(A.Loan2CMTIDInstNbr,'') like '' then  Loan2Document else A.Loan2CMTIDInstNbr end 
		
		,case when ISNULL(A.Loan2CMTIDInstNbr,'') like '' and ISNULL(A.Loan2YearDocNbrFmt,'') like '' then  Loan2Document 
		when ISNULL(A.Loan2CMTIDInstNbr,'') like '' and ISNULL(A.Loan2YearDocNbrFmt,'') not like '' then A.Loan2YearDocNbrFmt
		else A.Loan2CMTIDInstNbr end as Loan1Document


		,Loan2Book,Loan2Page,NULL,NULL
		, left(case when Buyer1FullName is null then Buyer1CompanyName else Buyer1FullName end,70) as BuyerBorrower1
		, left(case when Buyer2FullName is null then Buyer2CompanyName else Buyer2FullName end,70) as BuyerBorrower2
		
		,left(Loan2LenderName,40) AS SellerLender
		,NULL as SellerLender2
		,Loan2Amount,Loan2DocumentTypeCode,d.CodeDesc as DocType
		,Loan2TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,left(a.Loan2LenderName,40) as NewLenderAssignee,NULL
		,left(A.Buyer1FirstName,40),left(A.Buyer1FirstNameMiddleInitial,40),left(A.Buyer1LastName,60), left(A.Buyer1LastNameOrCorpName,40)
		,A.Loan2Type
		,'Y' as Purchase
		,Loan2InterestRate
		,Loan2TypeFinance
		,Loan2TermMonths as LoanTerm
		,TitleCompanyName
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan2TransactionType Like t.TransType
		WHERE Loan2RecordingDt is not null
		AND a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt 


			

		----ASSIGN/REL

		

		IF  EXISTS (SELECT * FROM [zCust_SecureTitleWatch].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		--,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end as DocNbrSrce
		,case when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') like '' then  DocNbrSrce 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') not like '' then A.YearDocNbrFrmt
		else A.CMTIDInstNbr end as DocNbrSrce

		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullNameStd is null and Borrower1CompanyName is null then BorrowerFullName
			when Borrower1FullNameStd is null and Borrower1CompanyName is not null then Borrower1CompanyName else Borrower1FullNameStd end as BuyerBorrower1
		, case when Borrower2FullNameStd is null then Borrower2CompanyName else Borrower2FullNameStd end as BuyerBorrower2
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt
		,case when ISNULL(A.OrigLoanCMTIDInstNbr,'') like '' then   OrigDeedDocNbr else A.OrigLoanCMTIDInstNbr end as OrigDeedDocNbr
		,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'A' as DocSrcInd,[ChronoKey],Assignee,AssignorName as Assignor,REF_ID
		,a.Assignee1CompanyName as NewLenderAssignee,AssignorName as OldLenderAssignor
		,A.Loan_FA_YearDocNbrFmt
		,A.FASAMId
		,A.FADeedId
		INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		


		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		--,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end
		,case when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') like '' then  DocNbrSrce 
		when ISNULL(A.CMTIDInstNbr,'') like '' and ISNULL(A.YearDocNbrFrmt,'') not like '' then A.YearDocNbrFrmt
		else A.CMTIDInstNbr end as DocNbrSrce

		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullNameStd is null then Borrower1CompanyName else Borrower1FullNameStd end as BuyerBorrower1
		, case when Borrower2FullNameStd is null then Borrower2CompanyName else Borrower2FullNameStd end as BuyerBorrower2
		
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt
		,case when ISNULL(A.OrigLoanCMTIDInstNbr,'') like '' then   OrigDeedDocNbr else A.OrigLoanCMTIDInstNbr end
		,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'R' as DocSrcInd,[ChronoKey],NULL,NULL,REF_ID
		,a.OrigLenderBen as NewLenderAssignee, NULL
		,A.Loan_FA_YearDocNbrFmt
		,A.FASAMId
		,A.FADeedId
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		UPDATE [zCust_SecureTitleWatch].[dbo].[w_Flank_ASR]
		SET OrigDeedRecordingDt = NULL
		where isDATE(OrigDeedRecordingDt)=0

		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_SecureTitleWatch].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType,REF_ID
		INTO [zCust_SecureTitleWatch].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_SecureTitleWatch].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentType = d.DocTypeID
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt




		---- CREATE TransHist 

		SET CONCAT_NULL_YIELDS_NULL OFF

		TRUNCATE TABLE w_TransHist_FLANK

		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  --,[BookSrce]
			  --,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  --,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate]
			  --,[BuyerBorrowerFirstNameMI]
			  --,[BuyerBorrowerLastNameMI]
			  ,	[BuyerBorrower1] 
			  ,	[BuyerBorrower2]
			  ,[SellerLender1]
			  ,[SellerLender2]
			  --,PURCHASE
			  ,[TITLECONAME]
			  )
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,BuyerBorrower1
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  --,NewLenderAssignee
			  ,NULL
			  ,Saledate
			  --,Buyer1FirstNameMiddleInitial
			  --,Buyer1LastNameOrCorpName 
			  ,	[BuyerBorrower1] 
			  ,	[BuyerBorrower2] 
			  ,[SellerLender]
			  ,[SellerLender2]
			  --,REO
			  ,TitleCompanyName
		--Select * 
		FROM [zCust_SecureTitleWatch].[dbo].[w_FLANK_DEEDS]


		

		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate] 
			  --,[BuyerBorrowerFirstNameMI]
			  --,[BuyerBorrowerLastNameMI]
			  --,LoanType 
			    ,[BuyerBorrower1] 
			  ,	[BuyerBorrower2] 
			  ,[SellerLender1]
			  ,[SellerLender2]
			  --,Purchase 
			  --,Rate
			  --,RateType
			  ,[TITLECONAME])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,[BuyerBorrower1]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,ContractDate
			  --,Borrower1FirstNameMiddleInitial
			  --,Borrower1LastNameMiddleInitial
			  --,LoanType 
			  ,	[BuyerBorrower1] 
			  ,	[BuyerBorrower2] 
			  ,[SellerLender]
			  ,[SellerLender2]
			  --,Purchase 
			--,LoanInterestRate
			--,TypeFinance
			,TitleCompanyName
		FROM [zCust_SecureTitleWatch].[dbo].[w_FLANK_MTG]

		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  --,[OrigLoanFAYearFmtDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount]
			  --,	[BuyerBorrower1] 
			  --,	[BuyerBorrower2]
			  --,[OrigTransBookPage] 
			  )
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,left([BuyerBorrower1],250)
			  ,NULL
			  ,NULL
			  --,OrigDeedRecordingDt
			  ,case When OrigDeedDocNbr is null then OrigDeedBook + '.' + OrigDeedPage ELSE  OrigDeedDocNbr END
			  ,Loan_FA_YearDocNbrFmt
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,'R'
			  ,case when FASAMId is null then FADeedId else FASAMId end
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,left(Assignee,250)
			  ,left(Assignor,250)
			  ,[OrigLoanAmt]
			  --,left(	[BuyerBorrower1] ,250)
			  --,left(	[BuyerBorrower2] ,250)
			  --,OrigDeedBook + '.' + OrigDeedPage
		FROM [zCust_SecureTitleWatch].[dbo].[w_FLANK_ASR]

		INSERT INTO [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount]
			  --,[OrigTransBookPage]
			  )
		SELECT Distinct FIPS
			  ,FAPropertyID
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  -- ,[BookSrce]
			  --,[PageSrce]
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigNODDocumentNbr
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,OrigBeneficiaryLender
			  ,NULL
			  ,OrigLoanAmt
			  --,LoanBook + '.' + LoanPage
		
		FROM [zCust_SecureTitleWatch].[dbo].[w_FLANK_NOD]

		UPDATE [zCust_SecureTitleWatch].[dbo].[a]
		SET FA_DocNbrFmt = c.FA_DocNbrFmt
		,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		,FA_BookPageFmt = c.FA_BookPageFmt
		,FA_YearBookPageFmt = c.FA_YearBookPageFmt
        ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
        ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
        ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
        ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
        ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		FROM [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK] a 
		JOIN [global].[dbo].[Transaction_Master] c with(NOLOCK)
		on a.FIPS = c.FIPS
		and a.Doc_Id = c.TransactionID
		Where C.FIPS in(Select Distinct FIPS from [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK])

		--UPDATE a 
		--set a.REF_ID = b.REF_ID
		--FROM w_transHist_Flank a JOIN a_PropMatch_Work_FLANK b
		--on convert(int,a.Fips) = convert(int,b.Fips)
		--and a.ref_id = b.propertyID

		  UPDATE [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]
		  SET CmtID = case when FA_CMTID_YearDocNum is not null then FA_CMTID_YearDocNum
			WHEN FA_CMTID_BookPage is not null then FA_CMTID_BookPage
			WHEN FA_CMTID_YearDAteDocNum is not null then FA_CMTID_YearDAteDocNum
			WHEN FA_CMTID_DocNum is not null then FA_CMTID_DocNum
			WHEN FA_CMTID_YearBookPage is not null then FA_CMTID_YearBookPage
			END

		  UPDATE [zCust_SecureTitleWatch].[dbo].[w_TransHist_FLANK]
		  SET CmtID = 1091
		  WHERE FIPS = 17031


END





