/* Source: AZUVPSQLDRGN004.datatree.local | NameParser | dbo.usp_name_parser_unified | type=P */



-- =============================================
-- Create date: 20181022
-- =============================================
CREATE PROCEDURE [NameParser].[dbo].[usp_name_parser_unified] @tableName varchar(255), @RowCounts varchar(1) = 'Y', @MailingLabel varchar(1) = 'N', @ErrorCapture varchar(1) = 'N'

AS
	EXEC [NameParser].[dbo].[usp_name_parser_unifiedV10_4_2] @tableName, @RowCounts, @MailingLabel

