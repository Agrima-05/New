SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- ============================================
-- Description:	Process OUTPUT
-- =============================================
CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_300_Start_Output_SITUS_AMC_OpenLien_FLANK]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT_OPEN_LIEN]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_OPEN_LIEN](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID][varchar](250)NULL,
			[INPUT DealID][varchar](250)NULL,
			[INPUT Solution ID][varchar](250)NULL,
			[INPUT Unique RecordID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Mortgage Start Date][varchar](250)NULL,
			[Mortgage Thru Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Borrower Name 1][varchar](250)NULL,
			[Borrower Name 2][varchar](250)NULL,
			[1st Lender][varchar](250)NULL,
			[1st Recording Date][varchar](250)NULL,
			[1st Mortgage Amount][varchar](250)NULL,
			[1st Doc Number][varchar](250)NULL,
			[1st Loan Type][varchar](250)NULL,
			[1st Interest Rate][varchar](250)NULL,
			[1st Rate Type][varchar](250)NULL,
			[1st Mortgage Term][varchar](250)NULL,
			[2nd Lender][varchar](250)NULL,
			[2nd Recording Date][varchar](250)NULL,
			[2nd Mortgage Amount][varchar](250)NULL,
			[2nd Doc Number][varchar](250)NULL,
			[2nd Loan Type][varchar](250)NULL,
			[2nd Interest Rate][varchar](250)NULL,
			[2nd Rate Type][varchar](250)NULL,
			[2nd Mortgage Term][varchar](250)NULL,
			[3rd Lender][varchar](250)NULL,
			[3rd Recording Date][varchar](250)NULL,
			[3rd Mortgage Amount][varchar](250)NULL,
			[3rd Doc Number][varchar](250)NULL,
			[3rd Loan Type][varchar](250)NULL,
			[3rd Interest Rate][varchar](250)NULL,
			[3rd Rate Type][varchar](250)NULL,
			[3rd Mortgage Term][varchar](250)NULL,
			[4th Lender][varchar](250)NULL,
			[4th Recording Date][varchar](250)NULL,
			[4th Mortgage Amount][varchar](250)NULL,
			[4th Doc Number][varchar](250)NULL,
			[4th Loan Type][varchar](250)NULL,
			[4th Interest Rate][varchar](250)NULL,
			[4th Rate Type][varchar](250)NULL,
			[4th Mortgage Term][varchar](250)NULL,
			-----Internal - REMOVE---
			[Mtg1TransactionID][varchar](250)NULL,
			[Mtg2TransactionID][varchar](250)NULL,
			[Mtg3TransactionID][varchar](250)NULL,
			[Mtg4TransactionID][varchar](250)NULL
		) ON [PRIMARY]


	---- POPULATE OUTPUT with Customer Provided Data
		INSERT INTO [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] ([INPUT DealID],[INPUT Solution ID],[INPUT Unique RecordID],[INPUT Address],[INPUT City],[INPUT State]
		,[INPUT Zip])
		Select 
		[Deal ID]
      ,[Solution ID]
      --,convert(bigint,[Unique RecordID])
	  ,[Unique RecordID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
     FROM 
	 --[dbo].INPUT_RAW_351184VND
	  --[dbo].INPUT_RAW_351325VND
	  INPUT_RAW_CUST
	  where ISNULL([Unique RecordID],'0') not like '0'
	and [Unique RecordID] not like ''
	and [Unique RecordID] is not null
	
		
		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]


		UPDATE [zCust_SITUS_AMC].[dbo].[a] 
		SET a.PROPERTYID = c.PROPERTYID
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a JOIN 
		[zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Unique RecordID] = c.RAW_ID



		
		Update [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = Convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique RecordID] = c.RAW_ID

		Update [zCust_SITUS_AMC].[dbo].[a]
		set 
		[Mortgage Start Date] = case when ISNULL(SAMMINRECORDDATE,'') like '' then NULL else convert(date,SamMinRecordDate) end
		,[Mortgage Thru Date] = case when ISNULL(SamMaxRecordDate,'') like '' then NULL else convert(date,SamMaxRecordDate) end 
		,[Mortgage Coverage Status] = SAMActive
		
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE
		
		
		Update [zCust_SITUS_AMC].[dbo].[A]
		Set
		A.[Borrower Name 1] = case when B.TotalOpenLienNbr > 0 then  B.[OwnerStdNAME1FULL] else null end
		,A.[Borrower Name 2] = case when B.TotalOpenLienNbr > 0 then  B.[OwnerStdNAME2FULL] else null end
		,A.[1st Lender] = B.[Mtg1Lender]
		,A.[1st Recording Date] = B.[Mtg1RecordingDt]
		,A.[1st Mortgage Amount] = B.[Mtg1LoanAmt]
		,A.[1st Doc Number] = case when B.[Mtg1InputDocNbr] is null then B.[Mtg1InputBook] + '.' + B.[Mtg1InputPage] else B.[Mtg1InputDocNbr] end
		,A.[1st Loan Type] = B.[Mtg1LoanType]
		,A.[1st Interest Rate] = B.[Mtg1InterestRate]
		,A.[1st Rate Type] = B.[Mtg1Typefinancing]
		,A.[1st Mortgage Term] = B.[Mtg1Term]
		,A.[2nd Lender] = B.[Mtg2Lender]
		,A.[2nd Recording Date] = B.[Mtg2RecordingDt]
		,A.[2nd Mortgage Amount] = B.[Mtg2LoanAmt]
		,A.[2nd Doc Number] = case when B.[Mtg2InputDocNbr] is null then B.[Mtg2InputBook] + '.' + B.[Mtg2InputPage] else B.[Mtg2InputDocNbr] end
		,A.[2nd Loan Type] = B.[Mtg2LoanType]
		,A.[2nd Interest Rate] = B.[Mtg2InterestRate]
		,A.[2nd Rate Type] = B.[Mtg2Typefinancing]
		,A.[2nd Mortgage Term] = B.[Mtg2Term]
		,A.[3rd Lender] = B.[Mtg3Lender]
		,A.[3rd Recording Date] = B.[Mtg3RecordingDt]
		,A.[3rd Mortgage Amount] = B.[Mtg3LoanAmt]
		,A.[3rd Doc Number] = case when B.[Mtg3InputDocNbr] is null then B.[Mtg3InputBook] + '.' + B.[Mtg3InputPage] else B.[Mtg3InputDocNbr] end
		,A.[3rd Loan Type] = B.[Mtg3LoanType]
		,A.[3rd Interest Rate] = B.[Mtg3InterestRate]
		,A.[3rd Rate Type] = B.[Mtg3Typefinancing]
		,A.[3rd Mortgage Term] = B.[Mtg3Term]
		,A.[4th Lender] = B.[Mtg4Lender]
		,A.[4th Recording Date] = B.[Mtg4RecordingDt]
		,A.[4th Mortgage Amount] = B.[Mtg4LoanAmt]
		,A.[4th Doc Number] = case when B.[Mtg4InputDocNbr] is null then B.[Mtg4InputBook] + '.' + B.[Mtg4InputPage] else B.[Mtg4InputDocNbr] end
		,A.[4th Loan Type] = B.[Mtg4LoanType]
		,A.[4th Interest Rate] = B.[Mtg4InterestRate]
		,A.[4th Rate Type] = B.[Mtg4Typefinancing]
		,A.[4th Mortgage Term] = B.[Mtg4Term]
		,A.[Mtg1TransactionID] = B.[Mtg1TransactionID]
		,A.[Mtg2TransactionID] = B.[Mtg2TransactionID]
		,A.[Mtg3TransactionID] = B.[Mtg3TransactionID]
		,A.[Mtg4TransactionID] = B.[Mtg4TransactionID]
		--Select B.Mtg1FormatDocNbr, Mtg1FormatBook, Mtg1FormatPage
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID
		where A.PropertyID is not null

		-----------------------------FOrmat Doc Number--------------
		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[1st Doc Number] = B.Loan1CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg1TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[1st Mortgage Amount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[1st Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[2nd Doc Number] = B.Loan1CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg2TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[2nd Mortgage Amount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[2nd Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[3rd Doc Number] = B.Loan1CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg3TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[3rd Mortgage Amount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[3rd Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER


		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[4th Doc Number] = B.Loan1CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg4TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[4th Mortgage Amount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[4th Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER


		--------Loan 2--------
		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[1st Doc Number] = B.Loan2CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg1TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[1st Mortgage Amount] = B.SECONDMORTGAGEAMOUNT
		And A.[1st Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[2nd Doc Number] = B.Loan2CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg2TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[2nd Mortgage Amount] = B.SECONDMORTGAGEAMOUNT
		And A.[2nd Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[3rd Doc Number] = B.Loan2CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg3TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[3rd Mortgage Amount] = B.SECONDMORTGAGEAMOUNT
		And A.[3rd Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER


		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[4th Doc Number] = B.Loan2CMTIDInstNbr
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg4TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[4th Mortgage Amount] = B.SECONDMORTGAGEAMOUNT
		And A.[4th Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER


		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[1st Loan Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[1st Loan Type] = B.[LoanTypeID]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[2nd Loan Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[2nd Loan Type] = B.[LoanTypeID]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[3rd Loan Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[3rd Loan Type] = B.[LoanTypeID]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[4th Loan Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[4th Loan Type] = B.[LoanTypeID]



		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[1st Rate Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[1st Rate Type] = B.[TypeFinId]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[2nd Rate Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[2nd Rate Type] = B.[TypeFinId]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[3rd Rate Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[3rd Rate Type] = B.[TypeFinId]

		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[4th Rate Type] = B.CodeDesc
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[4th Rate Type] = B.[TypeFinId]


		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a JOIN [zCust_SITUS_AMC].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique RecordID] = b.Raw_ID

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END
		
		UPDATE [zCust_SITUS_AMC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] a join [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique RecordID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		SET [Event Status] = CASE WHEN [1st Recording Date] is not null THEN 'Event Found' ELSE 'Event Not Found' END

		Select [Mortgage Coverage Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		Group by [Mortgage Coverage Status]

		Select [Property Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		Group by [Address Standardization]

		Select [Event Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		Group by [Event Status]

		Select FIPS, PROPERTYID, [INPUT Unique RecordID], [INPUT Address], [Mortgage Coverage Status], [Mortgage Start Date], [Mortgage Thru Date]
		From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN] where [Mortgage Coverage Status] like 'Not%'

		Select [Mortgage Coverage Status], FIPS, count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_LIEN]
		Group by [Mortgage Coverage Status], FIPS
		Order by [Mortgage Coverage Status], FIPS

		--Select * From global.dbo.county where FIPSCODE = '17071'


		--Select * From [x_Custom_OUTPUT_OPEN_LIEN]


END



