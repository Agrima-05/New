SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [US_Addresses].[dbo].[asp_group3]
AS
BEGIN

	set nocount on
	IF OBJECT_ID('US_Addresses.dbo.tempGroup3', 'U') IS NOT NULL--drop temp table if exists
	  DROP TABLE [US_Addresses].[dbo].[tempGroup3]; 

	create table [US_Addresses].[dbo].[tempGroup3] (id int,fullAddress varchar(100), zipcode varchar(10), city varchar(500), state varchar(10))
	declare @timesWithNothing int = 0
	While @timesWithNothing < 15--keep going until all addresses parsed
	Begin
       
			  --Prep temp to be SD
			  truncate table [US_Addresses].[dbo].[tempGroup3]
		   insert into [US_Addresses].[dbo].[tempGroup3] (id, fullAddress, zipcode,city, state) select top 10000 id, fullAddress, zipcode, city, state from [us_addresses].[dbo].[allAddresses_parsed_group3] order by id--grab 10,000 to parse
       
			  --Drop existing table
			  IF OBJECT_ID('US_Addresses.dbo.tempGroup3STD', 'U') IS NOT NULL--drop temp table if exists
						 DROP TABLE [US_Addresses].[dbo].[tempGroup3STD]; 
          
			  select s.*,p.id  
			  into [US_Addresses].[dbo].[tempGroup3STD]
		   from [US_Addresses].[dbo].[tempGroup3]  p with(nolock)
				  cross apply [addr].[dbo].[StandardizeAddress](0,1,fullAddress, city, state, zipcode)  s
		   option(maxdop 30) 


			  insert into [us_addresses].[dbo].[asp_group3_STD] (
			  [AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      ,[CountyFips]
      ,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
      ,[id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
			  )
		   select 
		   [AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      ,[CountyFips]
      ,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
      ,[id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
		    from  [US_Addresses].[dbo].[tempGroup3STD] where verified = 1

	insert into [us_addresses].[dbo].[asp_group3_STD_All] (
			  [AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      ,[CountyFips]
      ,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
      ,[id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
			  )
		   select 
		   [AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      ,[CountyFips]
      ,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
      ,[id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
		    from  [US_Addresses].[dbo].[tempGroup3STD]

		   insert into [us_addresses].[dbo].[allAddresses_parsed_group3_asp_complete] (
		   [zipcode]
      ,[StreetPreDirectionalAbbreviation]
      ,[StreetPostDirectionalAbbreviation]
      ,[streetName]
      ,[houseNumber]
      ,[apartment]
      ,[ID]
      ,[parsed]
      ,[fips]
      ,[parsedDate]
      ,[StreetSuffixAbbreviation]
      ,[fullAddress]) select 
	  [zipcode]
      ,[StreetPreDirectionalAbbreviation]
      ,[StreetPostDirectionalAbbreviation]
      ,[streetName]
      ,[houseNumber]
      ,[apartment]
      ,[ID]
      ,[parsed]
      ,[fips]
      ,[parsedDate]
      ,[StreetSuffixAbbreviation]
      ,[fullAddress] from [us_addresses].[dbo].[allAddresses_parsed_group3] 
			  where id in (select id from [US_Addresses].[dbo].[tempGroup3])--copy the 10,000 parsed to different table
		   delete from [us_addresses].[dbo].[allAddresses_parsed_group3] where id in (select id from [US_Addresses].[dbo].[tempGroup3])--remove parsed rows
		   if(@@rowcount = 0)
		   Begin
				  set @timesWithNothing = @timesWithNothing + 1
				  WAITFOR DELAY '00:01'; 
		   End
		   else
		   Begin
				  set @timesWithNothing = 0
		   End

	END

END



