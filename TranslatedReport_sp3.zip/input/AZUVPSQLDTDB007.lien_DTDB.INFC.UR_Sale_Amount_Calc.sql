/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Sale_Amount_Calc | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Sale_Amount_Calc] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc'
		,N'Started'

	 
	/*========================================
  11001 - Whasington DC
=========================================*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Estimated_Sale_Price]
		SELECT d1.ur_doc_id
			,d1.fips
			,CASE 
				WHEN d1.Recording_date >= '2023-10-01'
					THEN CASE 
							WHEN d1.DOC_TRANSFER_TAX <= 5800
								THEN (d1.DOC_TRANSFER_TAX * 100 / 1.10)
							WHEN d1.DOC_TRANSFER_TAX > 5800
								THEN (d1.DOC_TRANSFER_TAX * 100 / 1.45)
							END
				WHEN d1.Recording_date < '2023-10-01'
					THEN CASE 
							WHEN d1.DOC_TRANSFER_TAX <= 5800
								THEN (d1.DOC_TRANSFER_TAX * 100 / 1.10) ----consideration less than 400,000
							WHEN d1.DOC_TRANSFER_TAX BETWEEN 5800
									AND 29725
								THEN (d1.DOC_TRANSFER_TAX * 100 / 1.45) ----consdideration 400,000 to 2,000,000
							WHEN d1.DOC_TRANSFER_TAX > 29725
								AND ISNULL(r._commercial, 0) = 1
								AND ISNULL(r._Residential, 0) = 0
								THEN (d1.DOC_TRANSFER_TAX * 100 / 2.5)
							ELSE (d1.DOC_TRANSFER_TAX * 100 / 1.45) --- consideration over 2,000,000 only if property is commercial/vacant land? If it is residential it would be 1.45 rate. 
							END
				END AS Estimated_Sale_Price
		INTO [lien_dtdb].[tmp].[Estimated_Sale_Price]
		--If the property is NOT residential property:
		--•    If the loan amount is less than $2,000,000: 1.45%
		--•    If the loan amount tis $2,000,000 or more: 2.5%
		--FROM lien.dbo.DTDB_DocIdExtract_PreProcess d WITH (NOLOCK)
		--FROM lien.tmp.reprocess_records_to_be_processed d WITH (NOLOCK)
		FROM [Lien_dtdb].[infc].[deed_work] d1 WITH (
				NOLOCK
				,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
				)
		OUTER APPLY (
			SELECT max(CASE 
						WHEN PROPERTY_INDICATOR NOT IN (
								'10' -- single
								,'11' -- Condo 
								,'21' -- Duplex
								,'22' -- Apartment
								)
							THEN 1
						ELSE 0
						END) AS _commercial
				,max(CASE 
						WHEN PROPERTY_INDICATOR IN (
								'10' -- single
								,'11' -- Condo 
								,'21' -- Duplex
								,'22' -- Apartment
								)
							THEN 1
						ELSE 0
						END) AS _Residential
			FROM [Lien].[UR].[Merge_ref_ids] r WITH (
					NOLOCK
					,INDEX (id_doc_id)
					)
			OUTER APPLY (
				SELECT PROPERTY_INDICATOR
				FROM [assr].[dbo].[assr] a WITH (
						NOLOCK
						,INDEX (IDX_Assr_Ref_ID)
						)
				WHERE a.ref_id = r.ref_id
				) a
			WHERE r.doc_id = d1.ur_doc_id
			) r
		WHERE d1.fips = 11001
			AND d1.SALE_AMOUNT IS NULL
			AND d1.DOC_TRANSFER_TAX IS NOT NULL

	--AND isnull(d1a.multi_apn, '') = ''
	CREATE INDEX idx_doc_id ON [lien_dtdb].[tmp].[Estimated_Sale_Price] (ur_doc_ID)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.SALE_AMOUNT = ROUND(t.Estimated_Sale_Price, 0)
	----	,a.sale_code = NULL -- 'C'
	FROM [Lien_dtdb].[infc].[deed_work]  a with(nolock,index(idx_ur_doc_id))
	INNER JOIN [lien_dtdb].[tmp].[Estimated_Sale_Price] t ON t.UR_Doc_Id = a.UR_Doc_Id
	WHERE isnull(a.SALE_AMOUNT, 0) <> ROUND(t.Estimated_Sale_Price, 0)
		AND t.Estimated_Sale_Price > 0.00
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*================================================================================================
  Create table for all WA counties from Lien_dtdb.infc.Deed_work in order to supplement missing
  Situs_city values where possible
  ===============================================================================================*/
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price]
		SELECT w.deedid
			,w.fips
			,w.ur_doc_id
			,w.recording_date
			,w.ref_id
			,Coalesce(w.situs_city, ar.situs_city) AS Situs_city
			,w.source_type
			,w.sale_amount
			,nullif(w.doc_transfer_tax, 0) AS doc_transfer_tax
			,w.sale_code
		INTO [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price]
		FROM [Lien_dtdb].[infc].[deed_work] w
		OUTER APPLY (
			SELECT situs_city
			FROM [assr].[dbo].[assr] ar
			WHERE ar.ref_id = w.ref_id
			) ar
		WHERE (
				w.fips BETWEEN 53000
					AND 54000
				OR w.fips = 6075
				)
			AND ISNULL(w.doc_transfer_tax, 0) > 10
			AND ISNULL(w.Sale_Amount, 0) = 0
		ORDER BY w.fips

	CREATE INDEX idx_Fips_city ON [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] (
		fips
		,Situs_city
		)

	CREATE INDEX idx_deedid ON [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] (deedid)

	--SELECT * FROM Lien_dtdb.tmp.Deed_work_WA_Sales_Price

	/*================================================
  Calculate sales price - Table Driven

  City Logic
  - 53007
  - 53017
  ================================================*/
	--SELECT a.*
	--	,'calc' AS _calc
	--	,calc.*
	--	,g.*
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount = calc._new_sale_amount
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[INFC].[TaxRate_Washington] b WITH (
				NOLOCK
				,INDEX (idx_fips_rec_dt_from_to_city)
				)
		WHERE b.fips = a.fips
			AND A.RECORDING_DATE BETWEEN B.RECORDING_DATE_From
				AND B.RECORDING_DATE_tO
			AND (a.DOC_TRANSFER_TAX - B.DOC_TRANSFER_TAX_city_fee) BETWEEN B.tax_range_low
				AND B.tax_range_high
			AND B.SITUS_CITY IS NOT NULL
			AND b.situs_city = a.SITUS_CITY
		) G
	OUTER APPLY (
		SELECT try_cast(Round((((a.doc_Transfer_Tax - g.tax_Rate_adjustment) * 100) / g.tax_Rate) + g.DOC_TRANSFER_TAX_add_on, - 2) AS DECIMAL(13, 2)) AS _new_sale_amount
		) calc
	WHERE a.DOC_TRANSFER_TAX IS NOT NULL
		AND g.SITUS_CITY IS NOT NULL
		AND a.situs_city IS NOT NULL
		AND a.fips IN (
			53007
			,53017
			)
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*================================================
   State Logic
     - 53007
	 - 53017
  ================================================*/
	--SELECT a.*
	--	,'calc' AS _calc
	--	,calc.*
	--	,g.*
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount = calc._new_sale_amount
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[INFC].[TaxRate_Washington] b WITH (
				NOLOCK
				,INDEX (idx_fips_rec_dt_from_to_city)
				)
		WHERE b.fips = a.fips
			AND A.RECORDING_DATE BETWEEN B.RECORDING_DATE_From
				AND B.Recording_date_To
			AND (a.DOC_TRANSFER_TAX - B.DOC_TRANSFER_TAX_city_fee) BETWEEN B.tax_range_low
				AND B.tax_range_high
					--AND B.SITUS_CITY IS NULL
		) G
	OUTER APPLY (
		SELECT try_cast(Round((((a.doc_Transfer_Tax - g.tax_Rate_adjustment) * 100) / g.tax_Rate) + g.DOC_TRANSFER_TAX_add_on, - 2) AS DECIMAL(13, 2)) AS _new_sale_amount
		) calc
	WHERE a.DOC_TRANSFER_TAX IS NOT NULL
		AND isnull(a.sale_Amount, 0) = 0
		AND a.fips IN (
			53007
			,53017
			)
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for 
	- 53035
	- 53057
	- 53073
	- 53029
	- 53031
	
	- 53005	a.situs_city NOT IN ('Benton City')
	- 53009 a.situs_city NOT IN ('Forks')
	- 53011 a.situs_city NOT IN ('Yacolt')
	- 53025 a.situs_city NOT IN ('Coulee City','Grand Coulee','Hartline')
	- 53033 a.situs_city NOT IN ('Skykomish')
	- 53041 a.situs_city NOT IN ('Pe Ell','Toledo','Winlock')
	- 53061 a.situs_city NOT IN ('Darrington') 
	- 53063 a.situs_city NOT IN ('Medical Lake','Rockford','Spangle','Fairfield')
	- 53077 a.situs_city NOT IN ('Harrah','Moxee City','Naches','Selah','Tieton','Toppenish','Unicorp')
	
	- 53071 a.situs_city IN ('College Place','Waitsburg')
	- 53047 a.situs_city IN ('COULEE DAM','TONASKET')
	- 53037 a.situs_city IN ('Cle Elum','Roslyn')
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN (a.Doc_Transfer_Tax - 5.00) <= 8000
					THEN (a.Doc_Transfer_Tax - 5.00) * 100 / 1.6
				WHEN (a.Doc_Transfer_Tax - 5.00) BETWEEN 8000
						AND 25800
					THEN (a.Doc_Transfer_Tax - 8005) * 100 / 1.78 + 500000
				WHEN (a.Doc_Transfer_Tax - 5.00) BETWEEN 25800
						AND 74550
					THEN (a.Doc_Transfer_Tax - 25805) * 100 / 3.25 + 1500000
				WHEN (a.Doc_Transfer_Tax - 5.00) > 74550
					THEN (a.Doc_Transfer_Tax - 74555) * 100 / 3.5 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			a.fips IN (
				--  53011
				53035
				--, 53041
				,53057
				--, 53061
				--, 53063
				,53073
				--, 53077
				,53029
				--, 53033
				--, 53005
				--, 53009
				--, 53025
				,53031
				)
			OR (
				a.fips = 53005
				AND a.situs_city NOT IN ('Benton City')
				)
			OR (
				a.fips = 53009
				AND a.situs_city NOT IN ('Forks')
				)
			OR (
				a.fips = 53011
				AND a.situs_city NOT IN ('Yacolt')
				)
			OR (
				a.fips = 53025
				AND a.situs_city NOT IN (
					'Coulee City'
					,'Grand Coulee'
					,'Hartline'
					)
				)
			OR (
				a.fips = 53033
				AND a.situs_city NOT IN ('Skykomish')
				)
			OR (
				a.fips = 53041
				AND a.situs_city NOT IN (
					'Pe Ell'
					,'Toledo'
					,'Winlock'
					)
				)
			OR (
				a.fips = 53061
				AND a.situs_city NOT IN ('Darrington')
				)
			OR (
				a.fips = 53063
				AND a.situs_city NOT IN (
					'Medical Lake'
					,'Rockford'
					,'Spangle'
					,'Fairfield'
					)
				)
			OR (
				a.fips = 53077
				AND a.situs_city NOT IN (
					'Harrah'
					,'Moxee City'
					,'Naches'
					,'Selah'
					,'Tieton'
					,'Toppenish'
					,'Unicorp'
					)
				)
			OR (
				a.fips = 53071
				AND a.situs_city IN (
					'College Place'
					,'Waitsburg'
					)
				)
			OR (
				a.fips = 53047
				AND a.situs_city IN (
					'COULEE DAM'
					,'TONASKET'
					)
				)
			OR (
				a.fips = 53037
				AND a.situs_city IN (
					'Cle Elum'
					,'Roslyn'
					)
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53069 
	- 53027 
	- 53001 
 
	- 53037 
	- 53047 
	- 53065 
	- 53071 
	- 53059 
  
	- 53041 situs_city IN ('Pe Ell','Toledo','Winlock')
	- 53063 situs_city IN ('Medical Lake','Rockford','Spangle','Fairfield')
	- 53061 situs_city IN ('Darrington')
	- 53077 situs_city IN ('Harrah','Moxee City','Naches','Selah','Tieton','Toppenish','Unicorp')
	- 53033 situs_city IN ('Skykomish')
	- 53025 situs_city IN ('Coulee City','Grand Coulee','Hartline')
	- 53005 situs_city IN ('Benton City')
	- 53009 situs_city IN ('Forks')
	- 53011 situs_city IN ('Yacolt')
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round((
				CASE 
					WHEN (a.Doc_Transfer_Tax - 5.00) <= 6750
						THEN (a.Doc_Transfer_Tax - 5.00) * 100 / 1.35
					WHEN (a.Doc_Transfer_Tax - 5.00) BETWEEN 6750
							AND 22050
						THEN (a.Doc_Transfer_Tax - 6755) * 100 / 1.53 + 500000
					WHEN (a.Doc_Transfer_Tax - 5.00) BETWEEN 22050
							AND 67050
						THEN (a.Doc_Transfer_Tax - 22055) * 100 / 3.00 + 1500000
					WHEN (a.Doc_Transfer_Tax - 5) > 67050
						THEN (a.Doc_Transfer_Tax - 67055) * 100 / 3.25 + 3000000
					ELSE NULL
					END
				), - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53041
				AND a.situs_city IN (
					'Pe Ell'
					,'Toledo'
					,'Winlock'
					)
				)
			OR (
				a.fips = 53063
				AND a.situs_city IN (
					'Medical Lake'
					,'Rockford'
					,'Spangle'
					,'Fairfield'
					)
				)
			OR (
				a.fips = 53061
				AND a.situs_city = 'Darrington'
				)
			OR (
				a.fips = 53077
				AND a.situs_city IN (
					'Harrah'
					,'Moxee City'
					,'Naches'
					,'Selah'
					,'Tieton'
					,'Toppenish'
					,'Unicorp'
					)
				)
			OR (
				a.fips = 53033
				AND a.situs_city = 'Skykomish'
				)
			OR (
				a.fips = 53025
				AND a.situs_city IN (
					'Coulee City'
					,'Grand Coulee'
					,'Hartline'
					)
				)
			OR (
				a.fips = 53005
				AND a.situs_city = 'Benton City'
				)
			OR (
				a.fips = 53009
				AND a.situs_city = 'Forks'
				)
			OR (
				a.fips = 53011
				AND a.situs_city = 'Yacolt'
				)
			--OR (
			--	a.fips IN (
			--		 53069 
			--		,53027 
			--		,53001 
			--		,53037 
			--		,53047 
			--		,53065 
			--		,53071 
			--		,53059 
			--		)
			--	)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53015 situs_city IN ('Woodland')
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN (a.Doc_Transfer_Tax) <= 8000
					THEN (a.Doc_Transfer_Tax * 100 / 1.6)
				WHEN (a.Doc_Transfer_Tax) BETWEEN 8000
						AND 25800
					THEN (a.Doc_Transfer_Tax - 8000) * 100 / 1.78 + 500000
				WHEN (a.Doc_Transfer_Tax) BETWEEN 25800
						AND 74550
					THEN (a.Doc_Transfer_Tax - 25800) * 100 / 3.25 + 1500000
				WHEN (a.Doc_Transfer_Tax) > 74550
					THEN (a.Doc_Transfer_Tax - 74550) * 100 / 3.5 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips = 53015
		AND situs_city = 'Woodland'
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53045
	- 53053

	- 53021 situs_city NOT IN ('Kahlotus','Mesa')
	- 53067 situs_city NOT IN ('Rainier')
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN (a.Doc_Transfer_Tax) <= 8000
					THEN (a.Doc_Transfer_Tax * 100 / 1.6)
				WHEN (a.Doc_Transfer_Tax) BETWEEN 8000
						AND 25800
					THEN (a.Doc_Transfer_Tax - 8000) * 100 / 1.78 + 500000
				WHEN (a.Doc_Transfer_Tax) BETWEEN 25800
						AND 74550
					THEN (a.Doc_Transfer_Tax - 25800) * 100 / 3.25 + 1500000
				WHEN (a.Doc_Transfer_Tax) > 74550
					THEN (a.Doc_Transfer_Tax - 74550) * 100 / 3.5 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (
			53045
			--,53021
			,53053
			--,53067
			)
		OR (
			a.fips = 53021
			AND a.situs_city NOT IN (
				'Kahlotus'
				,'Mesa'
				)
			)
		OR (
			a.fips = 53067
			AND a.situs_city NOT IN ('Rainier')
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53003
	- 53013
	- 53023
	- 53049

	- 53021 situs_city IN ('Kahlotus','Mesa')
	- 53053 situs_city IN ('Eatonville','Wilkeson')
	- 53067 situs_city IN ('Rainier')
	- 53015 situs_city NOT IN ('Woodland')
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN (a.Doc_Transfer_Tax) <= 6750
					THEN a.Doc_Transfer_Tax * 100 / 1.35
				WHEN (a.Doc_Transfer_Tax) BETWEEN 6750
						AND 22050
					THEN (a.Doc_Transfer_Tax - 6750) * 100 / 1.53 + 500000
				WHEN (a.Doc_Transfer_Tax) BETWEEN 22050
						AND 67050
					THEN (a.Doc_Transfer_Tax - 22050) * 100 / 3 + 1500000
				WHEN (a.Doc_Transfer_Tax) > 67050
					THEN (a.Doc_Transfer_Tax - 67050) * 100 / 3.25 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53021
				AND a.situs_city IN (
					'Kahlotus'
					,'Mesa'
					)
				)
			OR (
				a.fips = 53053
				AND a.situs_city IN (
					'Eatonville'
					,'Wilkeson'
					)
				)
			OR (
				a.fips = 53067
				AND a.situs_city = 'Rainier'
				)
			OR (
				a.fips = 53015
				AND a.situs_city <> 'Woodland'
				)
			OR (
				a.fips IN (
					53003
					,53013
					,53023
					,53049
					)
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 6075
		 
 =========================================================*/
	UPDATE [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price]
	SET sale_amount = a1.sale_amount
	--,Sale_code = a2.sale_code
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	OUTER APPLY (
		SELECT round(CASE 
					WHEN doc_transfer_tax <= 1250
						THEN (doc_transfer_tax * 500 / 2.50)
					WHEN doc_transfer_tax BETWEEN 7499
							AND 1250
						THEN (doc_transfer_tax * 500 / 3.40)
					WHEN doc_transfer_tax BETWEEN 7500
							AND 112500
						THEN (doc_transfer_tax * 500 / 3.75)
					WHEN doc_transfer_tax BETWEEN 112500
							AND 275000
						THEN (doc_transfer_tax * 500 / 11.25)
					WHEN doc_transfer_tax BETWEEN 275000
							AND 1500000
						THEN (doc_transfer_tax * 500 / 27.50)
					WHEN doc_transfer_tax > 1500000
						THEN (doc_transfer_tax * 500 / 30.00)
					ELSE NULL
					END, - 2) AS sale_amount
		) a1
	WHERE fips IN (6075)
		AND Source_Type = 'e'
		AND RECORDING_DATE >= '2021-08-01'
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53015
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN a.DOC_TRANSFER_TAX <= 6750
					THEN (a.DOC_TRANSFER_TAX * 100 / 1.35)
				WHEN a.DOC_TRANSFER_TAX BETWEEN 6750
						AND 22050
					THEN (a.DOC_TRANSFER_TAX - 6750) * 100 / 1.53 + 500000
				WHEN a.DOC_TRANSFER_TAX BETWEEN 22050
						AND 67050
					THEN (a.DOC_TRANSFER_TAX - 22050) * 100 / 3 + 1500000
				WHEN a.DOC_TRANSFER_TAX > 67050
					THEN (a.DOC_TRANSFER_TAX - 67050) * 100 / 3.25 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (53015)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.recording_date > '2022-01-01'
		AND a.Source_type = 'E'
		AND ISNULL(a.sale_amount, 0) = 0
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date > 2022-01-01 and < 2023-01-01

  Special logic for:
	- 53071 situs_city IN ('college place','waitsburg')
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN (a.DOC_TRANSFER_TAX - 5.00) <= 8000
					THEN (a.DOC_TRANSFER_TAX - 5.00) * 100 / 1.6
				WHEN (a.DOC_TRANSFER_TAX - 5.00) BETWEEN 8000
						AND 25800
					THEN (a.DOC_TRANSFER_TAX - 8005) * 100 / 1.78 + 500000
				WHEN (a.DOC_TRANSFER_TAX - 5.00) BETWEEN 25800
						AND 74550
					THEN (a.DOC_TRANSFER_TAX - 25805) * 100 / 3.25 + 1500000
				WHEN (a.DOC_TRANSFER_TAX - 5.00) > 74550
					THEN (a.DOC_TRANSFER_TAX - 74555) * 100 / 3.5 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (53071)
		AND a.situs_city IN (
			'college place'
			,'waitsburg'
			)
		AND a.recording_date > '2022-01-01'
		AND a.Recording_Date < '2023-01-01'
		AND a.Source_type = 'E'
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date < 2023-01-01

  Special logic for:
	- 53055
		 
 =========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = round(CASE 
				WHEN a.Doc_Transfer_Tax <= 15500
					THEN a.Doc_Transfer_Tax * 100 / 3.10
				WHEN a.Doc_Transfer_Tax BETWEEN 15500
						AND 48300
					THEN (a.Doc_Transfer_Tax - 15500) * 100 / 3.28 + 500000
				WHEN a.Doc_Transfer_Tax BETWEEN 48300
						AND 119500
					THEN (a.Doc_Transfer_Tax - 48300) * 100 / 4.75 + 1500000
				WHEN a.Doc_Transfer_Tax > 119500
					THEN (a.Doc_Transfer_Tax - 119500) * 100 / 5.00 + 3000000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (53055)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND a.Source_type = 'E'
		AND a.Recording_Date < '2023-01-01'
		AND isnull(a.sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*========================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53021 situs_city IN ('Kahlotus','Mesa')
	- 53053 situs_city IN ('Eatonville')	AND a.Recording_Date < '2026-03-01' -- B32251 Added 2026/03/13
	- 53053 situs_city IN ('Wilkeson')		AND a.Recording_Date < '2026-03-01' -- BUG787762 Added 2024/12/11
	- 53067 situs_city IN ('Rainier')
 
	=========================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 7087.50
					THEN a.doc_Transfer_Tax * 100 / 1.35
				WHEN a.doc_Transfer_Tax BETWEEN 7087.50
						AND 22387.50
					THEN (a.doc_Transfer_Tax - 7087.50) * 100 / 1.53 + 525000
				WHEN a.doc_Transfer_Tax BETWEEN 22387.50
						AND 67397.5
					THEN (a.doc_Transfer_Tax - 22387.50) * 100 / 3 + 1525000
				WHEN a.doc_Transfer_Tax > 67387.5
					THEN (a.doc_Transfer_Tax - 67387.5) * 100 / 3.25 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53021
				AND a.situs_city IN (
					'Kahlotus'
					,'Mesa'
					)
				)
			OR (
				a.fips = 53053
				AND a.situs_city IN ('Eatonville')
				AND a.Recording_Date < '2026-03-01' -- B32251 Added 2026/03/13
				)
			OR (
				a.fips = 53053
				AND a.situs_city IN ('Wilkeson')
				AND a.Recording_Date < '2026-03-01' -- BUG787762 Added 2024/12/11
				)
			OR (
				a.fips = '53067'
				AND a.situs_city = 'Rainier'
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53041 situs_city IN ('Pe Ell','Winlock')
	- 53041 situs_city IN ('Toledo') AND a.recording_date < '2023-01-15'
	- 53063 situs_city IN ('Medical Lake','Rockford','Spangle','Fairfield')
	- 53061 situs_city IN ('Darrington')	 AND a.recording_date < '2026-05-01' -- B33097 added 2026/05/04
	- 53077 situs_city IN ('Harrah','Moxee City','Naches','Selah','Tieton','Unicorp')
	- 53077 situs_city IN ('Toppenish') AND a.recording_date < '2024-07-01'
	- 53033 situs_city IN ('Skykomish')
			 
	- 53025 situs_city IN ('Coulee City','Grand Coulee','Hartline')
	- 53005 situs_city IN ('Benton City') AND a.Recording_Date < '2024/11/01'
	- 53009 situs_city IN ('Forks')
	- 53011 situs_city IN ('Yacolt')
	- 53037 situs_city IN ('South Cle Elum','Kittitas') -----added since most counties are now 0.50%
			 
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN (a.doc_Transfer_Tax - 5.00) <= 7087.50
					THEN (a.doc_Transfer_Tax - 5.00) * 100 / 1.35
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 7087.50
						AND 22387.50
					THEN (a.doc_Transfer_Tax - 7092.5) * 100 / 1.53 + 525000
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 22387.50
						AND 67387.5
					THEN (a.doc_Transfer_Tax - 22392.5) * 100 / 3.00 + 1525000
				WHEN (a.doc_Transfer_Tax - 5) > 67387.5
					THEN (a.doc_Transfer_Tax - 67392.5) * 100 / 3.25 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53041
				AND a.situs_city IN (
					'Pe Ell'
					,'Winlock'
					)
				)
			OR (
				a.fips = 53041
				AND a.situs_city IN ('Toledo')
				AND a.recording_date < '2023-01-15'
				)
			OR (
				a.fips = 53063
				AND a.situs_city IN (
					'Medical Lake'
					,'Rockford'
					,'Spangle'
					,'Fairfield'
					)
				)
			OR (
				a.fips = 53061
				AND a.situs_city = 'Darrington'
				AND a.recording_date < '2026-05-01' -- B33097 added 2026/05/04
				)
			OR (
				a.fips = 53077
				AND a.situs_city IN (
					'Harrah'
					,'Moxee City'
					,'Naches'
					,'Selah'
					,'Tieton'
					,'Unicorp'
					)
				)
			OR (
				a.fips = 53077
				AND a.situs_city IN ('Toppenish')
				AND a.recording_date < '2024-07-01'
				)
			OR (
				a.fips = 53033
				AND a.situs_city = 'Skykomish'
				)
			OR (
				a.fips = 53025
				AND a.situs_city IN (
					'Coulee City'
					,'Grand Coulee'
					,'Hartline'
					)
				)
			OR (
				a.fips = 53005
				AND a.situs_city = 'Benton City'
				AND a.Recording_Date < '2024/11/01'
				) -- bug 787762 - MP 20241209
			OR (
				a.fips = 53009
				AND a.situs_city = 'Forks'
				)
			OR (
				a.fips = 53011
				AND a.situs_city = 'Yacolt'
				)
			OR (
				a.fips = 53037
				AND a.situs_city IN (
					'South Cle Elum'
					,'Kittitas'
					) -----added since most counties are now 0.50%
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53071 situs_city IN ('College Place','Waitsburg')
 
	- 53047 situs_city IN ('COULEE DAM','TONASKET')

 NEW THRESHOLDS  @.50  TECH FEES included
 
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*, 
		round(CASE 
				WHEN (a.doc_Transfer_Tax - 5.00) <= 8400
					THEN (a.doc_Transfer_Tax - 5.00) * 100 / 1.6
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 8400
						AND 26200
					THEN (a.doc_Transfer_Tax - 8405) * 100 / 1.78 + 525000
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 26200
						AND 74950
					THEN (a.doc_Transfer_Tax - 26205) * 100 / 3.25 + 1525000
				WHEN (a.doc_Transfer_Tax - 5) > 74950
					THEN (a.doc_Transfer_Tax - 74955) * 100 / 3.5 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53071
				AND a.situs_city IN (
					'College Place'
					,'Waitsburg'
					)
				)
			OR (
				a.fips = 53047
				AND UPPER(situs_city) IN (
					'COULEE DAM'
					,'TONASKET'
					)
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND isnull(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53015 situs_city IN ('Woodland')
	- 53051 situs_city IN ('Newport')
 
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 8400
					THEN (a.doc_Transfer_Tax * 100 / 1.6)
				WHEN a.doc_Transfer_Tax BETWEEN 8400
						AND 26200
					THEN (a.doc_Transfer_Tax - 8400) * 100 / 1.78 + 525000
				WHEN a.doc_Transfer_Tax BETWEEN 26200
						AND 74950
					THEN (a.doc_Transfer_Tax - 26200) * 100 / 3.25 + 1525000
				WHEN a.doc_Transfer_Tax > 74950
					THEN (a.doc_Transfer_Tax - 74950) * 100 / 3.5 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips = 53015
				AND a.situs_city = 'Woodland'
				)
			OR (
				a.fips = 53051
				AND a.situs_city = 'Newport'
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.SAle_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53015
	- 53051
 
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 7087.50
					THEN (a.doc_Transfer_Tax * 100 / 1.35)
				WHEN a.doc_Transfer_Tax BETWEEN 7087.50
						AND 22387.50
					THEN (a.doc_Transfer_Tax - 7087.50) * 100 / 1.53 + 525000
				WHEN a.doc_Transfer_Tax BETWEEN 22387.50
						AND 67397.5
					THEN (a.doc_Transfer_Tax - 22387.50) * 100 / 3 + 1525000
				WHEN a.doc_Transfer_Tax > 67387.5
					THEN (a.doc_Transfer_Tax - 67387.5) * 100 / 3.25 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (
			53015
			,53051
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53003
	- 53013
	- 53023
	- 53049
	- 53043 
 
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 7087.50
					THEN (a.doc_Transfer_Tax * 100 / 1.35)
				WHEN a.doc_Transfer_Tax BETWEEN 7087.50
						AND 22387.50
					THEN (a.doc_Transfer_Tax - 7087.50) * 100 / 1.53 + 525000
				WHEN a.doc_Transfer_Tax BETWEEN 22387.50
						AND 67397.5
					THEN (a.doc_Transfer_Tax - 22387.50) * 100 / 3 + 1525000
				WHEN a.doc_Transfer_Tax > 67387.5
					THEN (a.doc_Transfer_Tax - 67387.5) * 100 / 3.25 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE (
			(
				a.fips IN (
					53003
					,53013
					,53023
					,53049
					,53043 --Lincoln BUG787762 - Added 2024/12/09
					)
				)
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53069
	- 53027
	- 53001
 	- 53047
	- 53065
	- 53071
	- 53059
 
 NEW Tresholds @.25 TECH FEES
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round((
				CASE 
					WHEN (a.doc_Transfer_Tax - 5.00) <= 7087.50
						THEN (a.doc_Transfer_Tax - 5.00) * 100 / 1.35
					WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 7087.50
							AND 22387.50
						THEN (a.doc_Transfer_Tax - 7092.5) * 100 / 1.53 + 525000
					WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 22387.50
							AND 67387.5
						THEN (a.doc_Transfer_Tax - 22392.5) * 100 / 3.00 + 1525000
					WHEN (a.doc_Transfer_Tax - 5) > 67387.5
						THEN (a.doc_Transfer_Tax - 67392.5) * 100 / 3.25 + 3025000
					ELSE NULL
					END
				), - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (
			53069
			,53027
			,53001
			,53047
			,53065
			,53071
			,53059
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.SAle_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53011
	- 53035
	- 53037
	- 53041
	- 53057
	- 53061
	- 53063
	- 53073
	- 53077
	- 53029
	- 53033
	- 53005
	- 53009
	- 53025
	- 53031
 
  
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN (a.doc_Transfer_Tax - 5.00) <= 8400
					THEN (a.doc_Transfer_Tax - 5.00) * 100 / 1.6
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 8400
						AND 26200
					THEN (a.Doc_Transfer_Tax - 8405) * 100 / 1.78 + 525000
				WHEN (a.Doc_Transfer_Tax - 5.00) BETWEEN 26200
						AND 74950
					THEN (a.Doc_Transfer_Tax - 26205) * 100 / 3.25 + 1525000
				WHEN (a.doc_Transfer_Tax - 5.00) > 74950
					THEN (a.doc_Transfer_Tax - 74955) * 100 / 3.5 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (
			53011
			,53035
			,53037
			,53041
			,53057
			,53061
			,53063
			,53073
			,53077
			,53029
			,53033
			,53005
			,53009
			,53025
			,53031
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	--AND isnull(a.multi_apn, '') = ''
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53045
	- 53021
	- 53067
  
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 8400
					THEN (a.doc_Transfer_Tax * 100 / 1.6)
				WHEN a.doc_Transfer_Tax BETWEEN 8400
						AND 26200
					THEN (a.doc_Transfer_Tax - 8400) * 100 / 1.78 + 525000
				WHEN a.doc_Transfer_Tax BETWEEN 26200
						AND 74950
					THEN (a.doc_Transfer_Tax - 26200) * 100 / 3.25 + 1525000
				WHEN a.doc_Transfer_Tax > 74950
					THEN (a.doc_Transfer_Tax - 74950) * 100 / 3.5 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips IN (
			53045
			,53021
			,53067
			)
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53055
	 
  
 ==============================================================================================================*/
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE             
				WHEN (a.doc_Transfer_Tax - 5.00) <= 16275
					THEN (a.doc_Transfer_Tax * 100 / 3.10)
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 16275
						AND 49075
					THEN (a.doc_Transfer_Tax - 16275) * 100 / 3.28 + 525000
				WHEN (a.doc_Transfer_Tax - 5.00) BETWEEN 49075
						AND 120325
					THEN (a.doc_Transfer_Tax - 49075) * 100 / 4.75 + 1525000
				WHEN (a.doc_Transfer_Tax - 5.00) > 120325
					THEN (a.doc_Transfer_Tax - 120325) * 100 / 5.0 + 3025000
				ELSE NULL            
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips = 53055
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	/*=============================================================================================================
  Recording_date >= 2023-01-01

  Special logic for:
	- 53053
	 
  
 ==============================================================================================================*/
	--
	-- B32251 - Pierce Wa  
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Sale_Amount =
		-- SELECT b.*,
		round(CASE 
				WHEN a.doc_Transfer_Tax <= 8400.00
					THEN a.doc_Transfer_Tax / 0.0160
				WHEN a.doc_Transfer_Tax <= 26200.00
					THEN (a.doc_Transfer_Tax - 8400.00) / 0.0178 + 525000
				WHEN a.doc_Transfer_Tax <= 74950.00
					THEN (a.doc_Transfer_Tax - 26200.00) / 0.0325 + 1525000
				WHEN a.doc_Transfer_Tax > 74950.00
					THEN (a.doc_Transfer_Tax - 74950.00) / 0.0350 + 3025000
				ELSE NULL
				END, - 2)
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] a WITH (
			NOLOCK
			,INDEX (idx_Fips_city)
			)
	WHERE a.fips = 53053
		AND a.Recording_Date >= '2026-03-01'
		AND isnull(a.Doc_Transfer_Tax, 0) > 10
		AND ISNULL(a.Sale_Amount, 0) = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	------------------------------------------------------------------------
	-- Update Sale_amount and Sale_Code
	------------------------------------------------------------------------
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sale_amount = w.sale_amount
		,sale_code = 'E'
	FROM [Lien_dtdb].[tmp].[Deed_work_WA_Sales_Price] w WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			) ON a.ur_doc_id = w.ur_doc_id
	WHERE isnull(w.sale_amount, 0) > 0

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


