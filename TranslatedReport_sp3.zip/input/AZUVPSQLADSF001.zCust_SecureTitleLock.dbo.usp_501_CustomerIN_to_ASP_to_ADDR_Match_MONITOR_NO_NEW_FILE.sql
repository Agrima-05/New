SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF






CREATE PROCEDURE [zCust_SecureTitleLock].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match_MONITOR_NO_NEW_FILE] 
	
AS
BEGIN

	SET NOCOUNT ON;
		
		

			
		------Backup INPUT_IN_MONITOR in case need to roll back---
		DECLARE @DATE varchar(30)
		Set @DATE =    FORMAT(Getdate(),'yyyyMMddHHmmssffff')
		--DECLARE @DATE varchar(10)
		--Set @DATE =     FORMAT(Getdate(),'yyyyMMdd')
		EXEC('Select * into dbo.[INPUT_MONITOR_' + @DATE + '] From [INPUT_MONITOR]')


	--Select A.INPUTKey
	--, A.MAX_DEEDDATE, B.MAX_DEEDDATE 
	--, A.MAX_HOALIENDATE, B.MAX_HOALIENDATE 
	--, A.MAX_INVLDATE, B.MAX_INVLDATE 
	--, A.MAX_LISTDATE, B.MAX_DEEDDATE 
	--, A.MAX_LISTPRICE, B.MAX_LISTPRICE 
	--, A.MAX_MTGDATE, B.MAX_MTGDATE 
	--, A.MAX_PFCDATE, B.MAX_PFCDATE 
	--From INPUT_MONITOR as A 
	--join INPUT_MONITOR_20211210 as B on A.INPUTKey = B.INPUTKey

		

	

			   	

	--EXEC dbo.[usp_502_Pull_DTDB_DATA_V2_WO6]
	EXEC [zCust_SecureTitleLock].[dbo].[usp_502_Pull_FLANK_DATA_WO6]

	

END



