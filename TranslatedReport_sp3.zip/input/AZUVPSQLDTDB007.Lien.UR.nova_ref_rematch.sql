/* Source: DWS-ETL01.DATATREE.LOCAL | lien | UR.nova_ref_rematch | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Sunwoo Park>
-- Create date: <2026-02-23> 
-- Description:	<Nova ref rematch> 
-- =============================================
CREATE PROCEDURE [Lien].[UR].[nova_ref_rematch] (@fips INT)
AS


BEGIN TRY

	-- declare @fips INT = 12109
	DECLARE @ERROR VARCHAR(500)
	,@Txt VARCHAR(50)
	SET @Txt = CONCAT (
			'Nova ref rematch - '
			,@fips
			)

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Started'

	--declare @fips INT = 	45075
	DECLARE @fips_code CHAR(5) = right('00' + try_cast(@fips AS VARCHAR(5)), 5)

	-- #Note: filter ref_match by fips county
	DROP TABLE

	IF EXISTS [lien].[tmp].[nova_ref_rematch_tbl1]
		SELECT d.doc_id AS D_doc_id
			,d.fips_code
			,rm.*
		INTO [lien].[tmp].[nova_ref_rematch_tbl1]
		FROM [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (idx_fips_inst_rcdt_cmt_dt_seq)
				)
		OUTER APPLY (
			SELECT rm.doc_id
				,rm.REFERENCE_id
				,rm.fips
				,rm.nova_doc_id
				,rm.Nova_REF_ID
			FROM [lien].[ur].[Reference_match] rm WITH (
					NOLOCK
					,INDEX (id_doc_id)
					)
			WHERE rm.doc_id = d.doc_id
			) rm
		WHERE d.fips_code = @fips_code
			AND rm.REFERENCE_id IS NOT NULL

	--
	-- ref_id
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[nova_ref_rematch_ref_id]
		SELECT DISTINCT nova_ref_id
			,0 AS _valid
		INTO [lien].[tmp].[nova_ref_rematch_ref_id]
		FROM [lien].[tmp].[nova_ref_rematch_tbl1]
		WHERE nova_ref_id > 0

	CREATE INDEX idx_nova_ref_id ON [lien].[tmp].[nova_ref_rematch_ref_id] (nova_ref_id)

	UPDATE [Lien].[UR].[a]
	SET a._valid = 1
	FROM [lien].[tmp].[nova_ref_rematch_ref_id] a WITH (
			NOLOCK
			,INDEX (idx_nova_ref_id)
			)
	INNER JOIN [ASSR].[dbo].[Assr] ar WITH (
			NOLOCK
			,INDEX (IDX_Assr_Ref_ID)
			) ON ar.REF_ID = a.Nova_REF_ID

	--
	-- nova check
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[nova_ref_rematch_nova]
		SELECT DISTINCT nova_doc_id
			,0 AS _valid
		INTO [lien].[tmp].[nova_ref_rematch_nova]
		FROM [lien].[tmp].[nova_ref_rematch_tbl1]
		WHERE nova_doc_id > 0

	CREATE INDEX idx_nova_doc_id ON [lien].[tmp].[nova_ref_rematch_nova] (nova_doc_id)

	UPDATE [Lien].[UR].[a]
	SET a._valid = 1
	FROM [lien].[tmp].[nova_ref_rematch_nova] a WITH (
			NOLOCK
			,INDEX (idx_nova_doc_id)
			)
	INNER JOIN [novadimdoc].[dbo].[dim_nova_document] n WITH (
			NOLOCK
			,INDEX (IDX_DOCID_FIPS_DOCNUMBER)
			) ON n.doc_id = a.nova_doc_id

	--
	-- create doc_id list to rematch
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[nova_ref_rematch_tbl2]
		SELECT DISTINCT doc_id
		INTO [lien].[tmp].[nova_ref_rematch_tbl2]
		FROM [lien].[tmp].[nova_ref_rematch_tbl1] a
		LEFT JOIN [lien].[tmp].[nova_ref_rematch_ref_id] b WITH (
				NOLOCK
				,INDEX (idx_nova_ref_id)
				) ON b.nova_ref_id = a.nova_ref_id
		LEFT JOIN [lien].[tmp].[nova_ref_rematch_nova] c WITH (
				NOLOCK
				,INDEX (idx_nova_doc_id)
				) ON c.nova_doc_id = a.nova_doc_id
		WHERE (
				a.Nova_REF_ID > 0
				AND b._valid = 0
				) -- #obj.3: Find a ref_id (=>doc_id) that does not exist in assr
			OR (
				a.nova_doc_id > 0
				AND c._valid = 0
				) -- #obj.2: Find a new ref_id (=>doc_id) for a reference where the previous ref_id is no longer valid
			OR isnull(a.Nova_REF_ID, 0) = 0 -- #obj.1: Find a ref_id (=>doc_id) for a reference that currently has no "Nova" ref_id
			OR isnull(a.nova_doc_id, 0) = 0

	-- Insert fix doc_ids
	-- truncate table lien.[UR].[Fix_Request]
	TRUNCATE TABLE [lien].[tmp].[usp_UpdateReferenceMatch_fips_rematch_input]

	INSERT INTO [lien].[tmp].[usp_UpdateReferenceMatch_fips_rematch_input] (doc_id)
	SELECT doc_id
	--into lien.tmp.usp_UpdateReferenceMatch_fips_rematch_input
	FROM [lien].[tmp].[nova_ref_rematch_tbl2]

	-- select * from lien.tmp.usp_UpdateReferenceMatch_fips_rematch_input

	-- invoke new rematch_logic_sp using permenant table as output
	EXEC [lien].[UR].[usp_UpdateReferenceMatch_fips] @fips = @fips
		,@annual = 1
		,@ERROR = @ERROR

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	--
	INSERT INTO [lien].[UR].[Fix_Request] (
		[doc_id]
		,[m_status_id]
		,[del_PROPERTY_APN_MATCH]
		,[del_PROPERTY_Std_Address]
		,[del_PROPERTYHeader]
		,[del_REFERENCE_Match]
		,[del_NAME_STD_ADDRESS]
		,[update_status]
		,[process_date]
		,[set_m_status_id_to]
		,[reprocess_flag]
		,[reprocess_reason]
		)
	SELECT d.[doc_id]
		,d.[m_status_id]
		,0 AS [del_PROPERTY_APN_MATCH]
		,0 AS [del_PROPERTY_Std_Address]
		,0 AS [del_PROPERTYHeader]
		,0 AS [del_REFERENCE_Match]
		,0 AS [del_NAME_STD_ADDRESS]
		,NULL AS [update_status]
		,getdate() AS [process_date]
		,d.[m_status_id] AS [set_m_status_id_to]
		,0 AS [reprocess_flag]
		,CONCAT (
			'nova ref rematch - fips '
			,@fips_code
			) AS [reprocess_reason]
	FROM [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			)
	WHERE doc_id IN (
			SELECT DISTINCT doc_id
			FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp]
			)

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END
END CATCH


