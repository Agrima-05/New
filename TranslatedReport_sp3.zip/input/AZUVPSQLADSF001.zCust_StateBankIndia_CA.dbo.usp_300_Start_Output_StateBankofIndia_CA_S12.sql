SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- ============================================
-- Description:	Process OUTPUT
-- =============================================
CREATE PROCEDURE [zCust_StateBankIndia_CA].[dbo].[usp_300_Start_Output_StateBankofIndia_CA_S12]

AS
BEGIN
	
	SET NOCOUNT ON;

------1.	Per call 20250903
------2.	Open Lien – NO TRACKING!!!  Just giving them all current open liens as of the date of the extract
------3.	Event Found = Any open mortgages!


	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT_S12]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S12](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
		
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Thru Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			--[INPUT Borrower Name 1][varchar](250)NULL,
			--[INPUT Borrower Name 2][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Current Owner Doc Type][varchar](250)NULL,
			--[Current Owner Ownership Rights][varchar](250)NULL,
			--[Owner1CorpInd][varchar](250)NULL,
			--[Owner2CorpInd][varchar](250)NULL,
			[TotalOpenLienNbr][varchar](250)NULL,
			[TotalOpenLienAmt][varchar](250)NULL,
			[Mortgage1Lender][varchar](250)NULL,
			[Mortgage1RecordingDate][varchar](250)NULL,
			[Mortgage1LoanAmount][varchar](250)NULL,
			--[Mortgage1Estimated Loan Balance][varchar](250)NULL,
			[Mortgage1Doc Number][varchar](250)NULL,
			[Mortgage1Loan Type][varchar](250)NULL,
			[Mortgage1Interest Rate][varchar](250)NULL,
			[Mortgage1RateType][varchar](250)NULL,
			[Mortgage1EstIntRateInd][varchar](250)NULL,
			[Mortgage1Term][varchar](250)NULL,
			[Mortgage2Lender][varchar](250)NULL,
			[Mortgage2RecordingDate][varchar](250)NULL,
			[Mortgage2LoanAmount][varchar](250)NULL,
			[Mortgage2Doc Number][varchar](250)NULL,
			[Mortgage2Loan Type][varchar](250)NULL,
			--[Mortgage2Estimated Loan Balance][varchar](250)NULL,
			[Mortgage2Interest Rate][varchar](250)NULL,
			[Mortgage2RateType][varchar](250)NULL,
			[Mortgage2EstIntRateInd][varchar](250)NULL,
			[Mortgage2Term][varchar](250)NULL,
			[Mortgage3Lender][varchar](250)NULL,
			[Mortgage3RecordingDate][varchar](250)NULL,
			[Mortgage3LoanAmount][varchar](250)NULL,
			--[Mortgage3Estimated Loan Balance][varchar](250)NULL,
			[Mortgage3Doc Number][varchar](250)NULL,
			[Mortgage3Loan Type][varchar](250)NULL,
			[Mortgage3Interest Rate][varchar](250)NULL,
			[Mortgage3RateType][varchar](250)NULL,
			[Mortgage3EstIntRateInd][varchar](250)NULL,
			[Mortgage3Term][varchar](250)NULL,
			[Mortgage4Lender][varchar](250)NULL,
			[Mortgage4RecordingDate][varchar](250)NULL,
			[Mortgage4LoanAmount][varchar](250)NULL,
			--[Mortgage4Estimated Loan Balance][varchar](250)NULL,
			[Mortgage4Doc Number][varchar](250)NULL,
			[Mortgage4Loan Type][varchar](250)NULL,
			[Mortgage4Interest Rate][varchar](250)NULL,
			[Mortgage4RateType][varchar](250)NULL,
			[Mortgage4EstIntRateInd][varchar](250)NULL,
			[Mortgage4Term][varchar](250)NULL,




			---------------Internal---REMOVE--------
			[Mtg1TransactionID] [varchar](250) NULL,
			[Mtg2TransactionID] [varchar](250) NULL,
			[Mtg3TransactionID] [varchar](250) NULL,
			[Mtg4TransactionID] [varchar](250) NULL

			
		
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] (
		[INPUT Unique ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		FIPS,
		PROPERTYID
		)
		Select 
		INPUTKEY,
		ADDRESS,
		CITY,
		STATE,
		ZIPCODE,
		FIPS,
		PROPERTYID
		From [zCust_StateBankIndia_CA].[dbo].[INPUT_MONITOR]


		
		
	
		Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]

		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		set [Report Date] = Convert(date,GetDate())


	

		UPDATE [zCust_StateBankIndia_CA].[dbo].[a] 
		SET a.PROPERTYID = c.PROPERTYID
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Unique ID] = c.RAW_ID



		
		Update [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = Convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--Select A.[INPUT Unique ID]
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique ID] = c.RAW_ID


		
		Select top 1000 * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]


		Update [zCust_StateBankIndia_CA].[dbo].[a]
		set 
		--[MortgageStartDate] = case when ISNULL(SAMMINRECORDDATE,'') like '' then NULL else convert(date,SamMinRecordDate) end
		--,
		[Mortgage Thru Date] = case when ISNULL(SamMaxRecordDate,'') like '' then NULL else convert(date,SamMaxRecordDate) end 
		,[Mortgage Coverage Status] = SAMActive
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE

			
		

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set
		A.TotalOpenLienAmt = B.TotalOpenLienAmt
		,A.TotalOpenLienNbr = B.TotalOpenLienNbr
		,A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		--,A.Owner1CorpInd = B.OwnerStd1CorpInd
		--,A.Owner2CorpInd = B.OwnerStd2CorpInd
		--,A.[Current Owner Ownership Rights] = B.OwnerStd1OwnershipRights
		,A.[Mortgage1Lender] = B.[Mtg1Lender]
		,A.[Mortgage1RecordingDate] = case when B.[Mtg1RecordingDt] is not null then convert(Date,B.[Mtg1RecordingDt]) else NULL END
		,A.[Mortgage1LoanAmount] = B.[Mtg1LoanAmt]
		,A.[Mortgage1Doc Number] = case when B.[Mtg1FormatDocNbr] is null then B.[Mtg1FormatBook] + '.' + B.[Mtg1FormatPage] else B.[Mtg1FormatDocNbr] end
		,A.[Mortgage1Loan Type] = B.[Mtg1LoanType]
		,A.[Mortgage1Interest Rate] = B.[Mtg1InterestRate]
		,A.[Mortgage1RateType] = B.[Mtg1Typefinancing]
		,A.[Mortgage1Term] = B.[Mtg1Term]
		,A.[Mortgage2Lender] = B.[Mtg2Lender]
		,A.[Mortgage2RecordingDate] =  case when B.[Mtg2RecordingDt] is not null then convert(Date,B.[Mtg2RecordingDt]) else NULL END
		,A.[Mortgage2LoanAmount] = B.[Mtg2LoanAmt]
		,A.[Mortgage2Doc Number] = case when B.[Mtg2FormatDocNbr] is null then B.[Mtg2FormatBook] + '.' + B.[Mtg2FormatPage] else B.[Mtg2FormatDocNbr] end
		,A.[Mortgage2Loan Type] = B.[Mtg2LoanType]
		,A.[Mortgage2Interest Rate] = B.[Mtg2InterestRate]
		,A.[Mortgage2RateType] = B.[Mtg2Typefinancing]
		,A.[Mortgage2Term] = B.[Mtg2Term]
		,A.[Mortgage3Lender] = B.[Mtg3Lender]
		,A.[Mortgage3RecordingDate] =  case when B.[Mtg3RecordingDt] is not null then convert(Date,B.[Mtg3RecordingDt]) else NULL END
		,A.[Mortgage3LoanAmount] = B.[Mtg3LoanAmt]
		,A.[Mortgage3Doc Number] = case when B.[Mtg3FormatDocNbr] is null then B.[Mtg3FormatBook] + '.' + B.[Mtg3FormatPage] else B.[Mtg3FormatDocNbr] end
		,A.[Mortgage3Loan Type] = B.[Mtg3LoanType]
		,A.[Mortgage3Interest Rate] = B.[Mtg3InterestRate]
		,A.[Mortgage3RateType] = B.[Mtg3Typefinancing]
		,A.[Mortgage3Term] = B.[Mtg3Term]
		,A.[Mortgage4Lender] = B.[Mtg4Lender]
		,A.[Mortgage4RecordingDate] =  case when B.[Mtg4RecordingDt] is not null then convert(Date,B.[Mtg4RecordingDt]) else NULL END
		,A.[Mortgage4LoanAmount] = B.[Mtg4LoanAmt]
		,A.[Mortgage4Doc Number] = case when B.[Mtg4FormatDocNbr] is null then B.[Mtg4FormatBook] + '.' + B.[Mtg4FormatPage] else B.[Mtg4FormatDocNbr] end
		,A.[Mortgage4Loan Type] = B.[Mtg4LoanType]
		,A.[Mortgage4Interest Rate] = B.[Mtg4InterestRate]
		,A.[Mortgage4RateType] = B.[Mtg4Typefinancing]
		,A.[Mortgage4Term] = B.[Mtg4Term]
		,A.[Mtg1TransactionID] = B.[Mtg1TransactionID]
		,A.[Mtg2TransactionID] = B.[Mtg2TransactionID]
		,A.[Mtg3TransactionID] = B.[Mtg3TransactionID]
		,A.[Mtg4TransactionID] = B.[Mtg4TransactionID]

		--,A.[Mortgage1Estimated Loan Balance] = B.Mtg1EstLoanBalance
		--,A.[Mortgage2Estimated Loan Balance] = B.Mtg2EstLoanBalance
		--,A.[Mortgage3Estimated Loan Balance] = B.Mtg3EstLoanBalance
		--,A.[Mortgage4Estimated Loan Balance] = B.Mtg4EstLoanBalance

		,A.[Mortgage1EstIntRateInd] = case when b.MTG1InterestRateSrce like 'E' and B.Mtg1TransactionId is not null then 'Y' else NULL end
		,A.[Mortgage2EstIntRateInd] = case when b.MTG2InterestRateSrce like 'E' and B.Mtg2TransactionId is not null then 'Y' else NULL end
		,A.[Mortgage3EstIntRateInd] = case when b.MTG3InterestRateSrce like 'E' and B.Mtg3TransactionId is not null then 'Y' else NULL end
		,A.[Mortgage4EstIntRateInd] = case when b.MTG4InterestRateSrce like 'E' and B.Mtg4TransactionId is not null then 'Y' else NULL end

		--Select top 100 B.Mtg1FormatDocNbr, B.Mtg1FormatBook
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID

		-----------------------------FOrmat Doc Number--------------
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage1Doc Number] = case when B.Loan1CMTIDInstNbr is null then A.[Mortgage1Doc Number] else B.Loan1CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg1TransactionID = B.FirstAmericanUniqueTransactionID
		and A.Mortgage1LoanAmount = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[Mortgage1Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage2Doc Number] = case when B.Loan1CMTIDInstNbr is null then A.[Mortgage2Doc Number] else B.Loan1CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg2TransactionID = B.FirstAmericanUniqueTransactionID
		and A.Mortgage2LoanAmount = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[Mortgage2Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage3Doc Number] = case when B.Loan1CMTIDInstNbr is null then A.[Mortgage3Doc Number] else B.Loan1CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg3TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage3LoanAmount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[Mortgage3Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER


		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage4Doc Number] = case when B.Loan1CMTIDInstNbr is null then A.[Mortgage4Doc Number] else B.Loan1CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg4TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage4LoanAmount] = B.FIRSTMORTGAGEMORTGAGEAMOUNT
		And A.[Mortgage4Doc Number] = B.FIRSTMORTGAGEDOCUMENTNUMBER


		--------Loan 2--------
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage1Doc Number] = case when B.Loan2CMTIDInstNbr is null then A.[Mortgage1Doc Number] else B.Loan2CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg1TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage1LoanAmount] = B.SECONDMORTGAGEAMOUNT
		And A.[Mortgage1Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage2Doc Number] = case when B.Loan2CMTIDInstNbr is null then A.[Mortgage2Doc Number] else B.Loan2CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg2TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage2LoanAmount] = B.SECONDMORTGAGEAMOUNT
		And A.[Mortgage2Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage3Doc Number] = case when B.Loan2CMTIDInstNbr is null then A.[Mortgage3Doc Number] else B.Loan2CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg3TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage3LoanAmount] = B.SECONDMORTGAGEAMOUNT
		And A.[Mortgage3Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER


		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage4Doc Number] = case when B.Loan2CMTIDInstNbr is null then A.[Mortgage4Doc Number] else B.Loan2CMTIDInstNbr end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		and A.Mtg4TransactionID = B.FirstAmericanUniqueTransactionID
		and A.[Mortgage4LoanAmount] = B.SECONDMORTGAGEAMOUNT
		And A.[Mortgage4Doc Number] = B.SECONDMORTGAGEDOCUMENTNUMBER


		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage1Loan Type] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[Mortgage1Loan Type] = B.[LoanTypeID]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage2Loan Type] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[Mortgage2Loan Type] = B.[LoanTypeID]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage3Loan Type] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[Mortgage3Loan Type] = B.[LoanTypeID]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage4Loan Type] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Loan_Type] as B with(NOLOCK) 
		on A.[Mortgage4Loan Type] = B.[LoanTypeID]



		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage1RateType] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[Mortgage1RateType] = B.[TypeFinId]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage2RateType] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[Mortgage2RateType] = B.[TypeFinId]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage3RateType] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[Mortgage3RateType] = B.[TypeFinId]

		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Mortgage4RateType] = B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Type_Fin] as B with(NOLOCK) 
		on A.[Mortgage4RateType] = B.[TypeFinId]



			
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

		--Update A
		--Set A.[Current Owner Ownership Rights] = B.CodeDesc
		----Select A.[Current Owner Ownership Rights] , B.CodeDesc
		--FROM x_custom_OUTPUT_S12 a 
		--JOIN [Global].[dbo].[lkup_Assessee_Vesting]  as B with(NOLOCK) 
		--on A.[Current Owner Ownership Rights] = B.[BKFSCode]




		Select top 100 * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END
		
		
		Update  [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		--Select a.[INPUT Unique ID], B.RAW_ID, B.CarrierCode
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID
		
		

		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END
		
		UPDATE [zCust_StateBankIndia_CA].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12] a join [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		------20240726 - Assume if open mtg found then Event Found
		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		SET [Event Status] = CASE WHEN 
		ISNULL(Mtg1TransactionID,'') not like '' 
		THEN 'Event Found' ELSE 'Event Not Found' END


		Select [Mortgage Coverage Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		Group by [Mortgage Coverage Status]

		Select [Property Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		Group by [Address Standardization]

		Select [Event Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		Group by [Event Status]

	


		Select [INPUT Unique ID], PROPERTYID
		, Mtg1TransactionID	,[Mortgage1EstIntRateInd]
		, Mtg2TransactionID	,[Mortgage2EstIntRateInd]
		, Mtg3TransactionID	,[Mortgage3EstIntRateInd]
		, Mtg4TransactionID	,[Mortgage4EstIntRateInd]
		From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]
		where 
		([Mortgage1EstIntRateInd] like 'Y'	and Mtg1TransactionID is null) OR
		([Mortgage2EstIntRateInd] like 'Y'	and Mtg2TransactionID is null) OR
		([Mortgage3EstIntRateInd] like 'Y'	and Mtg3TransactionID is null) OR
		([Mortgage4EstIntRateInd] like 'Y'	and Mtg4TransactionID is null) 

		Select top 10000 * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S12]


END



