SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [Data].[dbo].[Prop_Assr_Refresh_STEP2]
as
BEGIN


EXEC('
		Use DATA

				EXEC sp_rename ''Property'', ''Property_OLD''
				EXEC sp_rename ''Property_BATCH'', ''Property''
				





CREATE CLUSTERED INDEX [clx-PropertyId] ON [dbo].[Property] (
	[PropertyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE )




CREATE NONCLUSTERED INDEX [Fips_SumBuildingSqFt] ON [dbo].[Property]
(
	[FIPS] ASC,
	[SumBuildingSqFt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

')


EXEC('
		Use ASSR
		

				EXEC sp_rename ''Assr'', ''Assr_OLD''
				EXEC sp_rename ''Assr_BATCH'', ''Assr''
				
')


END
