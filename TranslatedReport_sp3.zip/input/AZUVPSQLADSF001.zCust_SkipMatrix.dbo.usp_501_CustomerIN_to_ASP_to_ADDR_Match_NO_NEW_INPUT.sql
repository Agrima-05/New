SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF




CREATE PROCEDURE [zCust_SkipMatrix].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match_NO_NEW_INPUT]
		
	
AS
BEGIN

	SET NOCOUNT ON;


		--------BACKUP monitor table----
		DECLARE @DATE varchar(10)
		Set @DATE =  convert(varchar(10),Getdate(),112)
		EXEC('Select * into dbo.[INPUT_Monitor_' + @DATE + '] From INPUT_Monitor')
		


 -- -------------------Used for matching------------
	Truncate table INPUT_IN

	INSERT INTO [zCust_SkipMatrix].[dbo].[INPUT_IN](INPUTKey      ,[INPUTAddress]      ,[INPUTCity]      ,[INPUTState]      ,[INPUTZip]
        ,INPUTAPN     )

		SELECT     
		[Unique ID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
      ,[APN]
      From [zCust_SkipMatrix].[dbo].[INPUT_Monitor]
	  where [Record Indicator] not like 'D'
					
	 
	 Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
	

	

		Select top 100 * From [zCust_SkipMatrix].[dbo].[INPUT_IN]

		Select count(*) From [zCust_SkipMatrix].[dbo].[INPUT_IN]

		Select INPUTKey,count(*) From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		Group by INPUTKey
		Having count(*) >1

		Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		where INPUTKey like '%e%'

		Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		where len(INPUTZip) > 10

		Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		where InputAddress like '%  %'

		Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'


		UPDATE [zCust_SkipMatrix].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_SkipMatrix].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_SkipMatrix].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_SkipMatrix].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_SkipMatrix].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2

	
	
	---- INSERT DATA INTO ASP IN TABLE AND SET TRIGGER FOR PROCESS

	  EXEC [zCust_SkipMatrix].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]


---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 2 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_SkipMatrix].[dbo].[SkipMatrix_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_SkipMatrix].[dbo].[SkipMatrix_STD])
					END
			END


    EXEC [zCust_SkipMatrix].[dbo].[usp_100c_sp_ASP_Cust_STD]

	

		-----------------------------------------------------

		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_SkipMatrix'
		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_SkipMatrix'

			
		
		
			Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
			 from [zCust_SkipMatrix].[dbo].[a_PropMatch_WORK]
			group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END

			Select CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
			 from [zCust_SkipMatrix].[dbo].[a_PropMatch_WORK_FLANK]
			group by CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END

		


			--EXEC dbo.[usp_502_Pull_DTDB_DATA_V2]

			--EXEC dbo.usp_502_Pull_FLANK_DATA

			

		
	--------Drop & recreate table on SQL 11 & run DTDB data pull there b/c of number of records---
	--Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.a_PropMatch_Work
	--Select * From a_PropMatch_Work

	--EXEC dbo.usp_211_Create_TransHist_Rev5


		
END



