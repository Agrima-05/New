/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.USP_Extract_Names | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[USP_Extract_Names] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change
MArie		7/30/2024	Use Lien_dtdb Code tables
*****************************************************************************************************************
*/
/*
USE Lien_dtdb
GO

DECLARE	@return_value int,
		@ERROR varchar(500)

EXEC	lien_dtdb.INFC.[USP_Extract_Names]
		@ERROR = @ERROR OUTPUT

SELECT	@ERROR as N'@ERROR'

SELECT	'Return Value' = @return_value

GO
*/
--declare @ERROR VARCHAR(500) 
BEGIN TRY
	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'USP_Extract_Names'
		,N'Started'

	/*
USE lien_dtdb
GO

DECLARE	@return_value int,
		@ERROR varchar(500)

EXEC	@return_value = INFC.USP_Extract_Names
		@ERROR = @ERROR OUTPUT

SELECT	@ERROR as N'@ERROR'

SELECT	'Return Value' = @return_value

GO

GO
*/
	--
	-- call the procedure to create name tables for the testing - ons in production it would be done as part of hte daily rotuine
	--
	/*	
DECLARE	@return_value int,
		@ERROR varchar(500)
	EXEC lien_DTDB.UR.usp_DailyExtractNames @ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END
	

	delete from lien_dtdb.infc.deed_buyer_names where doc_id not in (110150188,208648164,117734583, 69982004, 176732665, 178064909)

	select * from lien_dtdb.infc.deed_buyer_names_pivot where doc_id in (110150188,208648164,117734583, 69982004, 176732665, 178064909)
	select * from lien_dtdb.infc.deed_buyer_names_pivot where doc_id in (110150188)
	*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[USP_Extract_Names_dedupe_LFR_LFE_LE]
		SELECT ROW_NUMBER() OVER (
				PARTITION BY Doc_id
				,last_company_name
				,first_name
				,middle_name
				,suffix ORDER BY CASE 
						WHEN role_type IN ('Party Receiving Life Estate')
							THEN 0
						WHEN party_type_code IN (
								'LFR'
								,'LFE'
								)
							THEN 1
						WHEN vesting_code IN ('LE')
							THEN 2
						ELSE 9
						END
				) AS dupl_role_type_vesting
			,*
		INTO [lien_dtdb].[tmp].[USP_Extract_Names_dedupe_LFR_LFE_LE]
		FROM [lien_dtdb].[infc].[deed_buyer_names]

	--WHERE doc_id IN (353686652)
	TRUNCATE TABLE [lien_dtdb].[infc].[deed_buyer_names]

	INSERT INTO [lien_dtdb].[infc].[deed_buyer_names] (
		Doc_id
		,Name_id
		,_Name_type
		,doc_unique_id
		,sequence_number
		,name_identifier
		,last_company_name
		,first_name
		,middle_name
		,suffix
		,party_type_code
		,role_type
		,relationship_code
		,vesting_code
		,percent_transferred
		,address_same_as_property_address_flag
		,address
		,orig_Mtg_Lender_Name
		,RN
		,address_city_name
		,address_state_name
		,address_zip_code
		,dba_aka_sort_seq
		,RoleType_single_sort_seq
		,AddressMatchResults
		,dedupe_delete
		,ROW4
		,Combine_NAME
		,aditional_name_id
		,_Parse_seq
		,ROW_aka
		)
	SELECT Doc_id
		,Name_id
		,_Name_type
		,doc_unique_id
		,sequence_number
		,name_identifier
		,last_company_name
		,first_name
		,middle_name
		,suffix
		,party_type_code
		,role_type
		,relationship_code
		,vesting_code
		,percent_transferred
		,address_same_as_property_address_flag
		,address
		,orig_Mtg_Lender_Name
		,RN
		,address_city_name
		,address_state_name
		,address_zip_code
		,dba_aka_sort_seq
		,RoleType_single_sort_seq
		,AddressMatchResults
		,dedupe_delete
		,ROW4
		,Combine_NAME
		,aditional_name_id
		,_Parse_seq
		,ROW_aka
	FROM [lien_dtdb].[tmp].[USP_Extract_Names_dedupe_LFR_LFE_LE]
	WHERE dupl_role_type_vesting = 1

	--
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[infc].[deed_buyer_names_wrk]
		SELECT *
			,ROW4 AS ROW4_2
		INTO [lien_dtdb].[infc].[deed_buyer_names_wrk]
		FROM [lien_dtdb].[infc].[deed_buyer_names] a

	CREATE INDEX idx_doc_id_address ON [lien_dtdb].[infc].[deed_buyer_names_wrk] (
		doc_id
		,last_company_name
		,first_name
		,middle_name
		,suffix
		) include (name_id)

	-- select * from lien_dtdb.infc.deed_buyer_names_wrk
	/****** Object:  Index idx_doc_id    Script Date: 9/25/2023 2:02:57 PM ******/
	CREATE NONCLUSTERED INDEX idx_doc_id ON [lien_dtdb].[infc].[deed_buyer_names_wrk] (Doc_id ASC)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				) ON [PRIMARY]

	/****** Object:  Index idx_row    Script Date: 9/25/2023 2:02:58 PM ******/
	CREATE NONCLUSTERED INDEX idx_row ON [lien_dtdb].[infc].[deed_buyer_names_wrk] (
		Doc_id ASC
		,ROW4 ASC
		)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				) ON [PRIMARY]

	CREATE INDEX idx_doc_id_name_id ON [lien_dtdb].[infc].[deed_buyer_names_wrk] (
		doc_id
		,name_id
		)

	--  
	--
	-- Combine Related names
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate]
		CREATE TABLE [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate] (
			doc_id INT NOT NULL
			,Name_id INT NOT NULL
			,new_last_company_name VARCHAR(200) NULL
			,master_row BIGINT NULL
			,child_row BIGINT NULL
			,nx_Name_id INT NULL
			,name_identifier VARCHAR(1) NULL
			,vesting_code VARCHAR(10) NULL
			)

	CREATE INDEX idx ON [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate] (doc_id)

	--begin transaction
	DECLARE @row4 INT = 1

	WHILE @row4 < 9
	BEGIN
		--select 'before insert' as _a, * from lien_dtdb.infc.deed_buyer_names
		INSERT INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate] (
			doc_id
			,Name_id
			,new_last_company_name
			,master_row
			,child_row
			,nx_Name_id
			,name_identifier
			,vesting_code
			)
		SELECT n.doc_id
			,n.Name_id
			,CASE 
				WHEN nn.new_last_company_name_id = 1
					THEN n.last_company_name
				WHEN nn.new_last_company_name_id = 2
					THEN substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name + ' ' + '&' + ' ' + nx.first_name + ' ' + nx.middle_name + ' ' + nx.suffix, '  ', ' ')), 1, 200)
				WHEN nn.new_last_company_name_id = 3
					THEN substring(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, 1, 200)
				WHEN nn.new_last_company_name_id = 4
					THEN substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, '  ', ' ')), 1, 200)
						--if name_identifer is equal to 'I', party_type is = to 'SPS' or  relationship_code = 'HW' or 'DP', or 'HH' or 'MC' or 'WH' or 'WM' or 'LC' and sequence number 0001 last_company_name is equal to sequence number 0002 last_company_name, map sequence_number '0001' last_company_name + suffix + first_name + middle_name + ' & ' + <then from sequence_number = '0002'> first_name + middle_name + suffix
				ELSE substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, '  ', ' ')), 1, 200) --n.last_company_name  --- Marie
				END AS new_last_company_name
			,n.ROW4 AS master_row
			,nx.ROW4 AS child_row
			,CASE 
				WHEN nn.new_last_company_name_id = 2
					THEN nx.name_id
				ELSE 0
				END AS nx_Name_id
			,n.name_identifier
			,n.vesting_code
		--			select * 
		FROM [lien_dtdb].[infc].[deed_buyer_names] n
		OUTER APPLY (
			SELECT *
			FROM [lien_dtdb].[infc].[deed_buyer_names] nx
			WHERE nx.doc_id = n.doc_id
				AND nx.ROW4 = @row4 + 1
			) nx
		OUTER APPLY (
			SELECT CASE 
					WHEN n.name_identifier IN (
							'C'
							,'T'
							)
						AND n.party_type_code <> 'CO'
						THEN 1 --n.last_company_name
					WHEN n.name_identifier IN ('I')
						AND nx.row4 IS NOT NULL
						AND (n.party_type_code IN ('SPS'))
						AND nx.last_company_name = n.last_company_name
						--AND n.Vesting_code <> 'LE' --marie 20251216
						--AND nx.Vesting_code <> 'LE' --marie 20251216
						THEN 2
					WHEN n.name_identifier IN ('I')
						AND (
							n.party_type_code NOT IN ('SPS')
							OR n.relationship_code NOT IN (
								'HW'
								,'DP'
								,'HH'
								,'MC'
								,'WH'
								,'WM'
								,'LC'
								)
							)
						--AND n.Vesting_code <> 'LE' --marie 20251216
						--AND nx.Vesting_code <> 'LE' --marie 20251216
						THEN 3
					WHEN n.name_identifier IN ('I')
						AND nx.row4 IS NOT NULL
						AND (
							n.party_type_code IN ('SPS')
							OR n.relationship_code NOT IN (
								'HW'
								,'DP'
								,'HH'
								,'MC'
								,'WH'
								,'WM'
								,'LC'
								)
							)
						--AND n.Vesting_code <> 'LE' --marie 20251216
						--AND nx.Vesting_code <> 'LE' --marie 20251216
						AND nx.last_company_name <> n.last_company_name
						THEN 4
					ELSE 5
					END AS new_last_company_name_id
			) nn
		WHERE /*n.doc_id = 218752883
		AND*/ n.row4 = @row4
		--AND n.Vesting_code <> 'LE' --marie 20251216
		--AND nx.Vesting_code <> 'LE' --marie 20251216
		ORDER BY n.sequence_number

		--		SELECT 'lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashUpdate' as _aa ,* FROM lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashUpdate
		DELETE a
		--SELECT a.*
		FROM [lien_dtdb].[infc].[deed_buyer_names] a
		INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate] b ON b.doc_id = a.Doc_id
		WHERE a.row4 = @row4 + 1
			AND b.child_row = @row4 + 1
			AND new_last_company_name LIKE '%&%'
			AND b.name_identifier = 'I'

		SET @row4 = @row4 + 1
			--			select 'after delete' as _a, * from lien_dtdb.infc.deed_buyer_names
	END

	/*
	SELECT *
	FROM lien_dtdb.infc.deed_buyer_names a

	select * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashUpdate
	*/
	--------------------------------------------------
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Combine_NAME = substring(replace(b.new_last_company_name, '  ', ' '), 1, 60)
		,a.aditional_name_id = b.nx_name_id
	FROM [lien_dtdb].[infc].[deed_buyer_names] a
	INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate] b ON b.Name_id = a.Name_id
		AND b.master_row = a.row4

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Combine_NAME = substring(rtrim(replace(a.last_company_name + ' ' + a.suffix + ' ' + a.first_name + ' ' + a.middle_name, '  ', ' ')), 1, 60)
	FROM [lien_dtdb].[infc].[deed_buyer_names] a
	WHERE isnull(a.Combine_NAME, '') = ''

	-- tot hierso
	--  	select * from lien_dtdb.infc.deed_buyer_names where doc_id = 175866803
	--rollback
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashupd1]
		SELECT *
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id ORDER BY RoleType_single_sort_seq
					--CASE 
					--		WHEN a.vesting_code IN ('LE')
					--			THEN 1
					--		ELSE 0
					--		END DESC
					--	,row4
				) AS ROW5
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashupd1]
		FROM [lien_dtdb].[infc].[deed_buyer_names] a

	--WHERE doc_id = 218752883
	--select right('0000' + cast(b.row5 as varchar),4) as new_sequence_number , a.* 
	/*
	select row4,RoleType_single_sort_seq ,* from lien_dtdb.infc.deed_buyer_names where doc_id = 175866803
	select ROW5,row4, * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashupd1 where doc_id = 175866803
*/
	--UPDATE a
	--SET a.sequence_number = right('0000' + cast(b.row5 AS VARCHAR), 4)
	--FROM lien_dtdb.infc.deed_buyer_names a
	--INNER JOIN lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashupd1 b ON b.nahme_id = a.name_id
	--	AND b.row4 = a.row4
	UPDATE [lien_DTDB].[INFC].[a]
	--SET a.sequence_number = right('0000' + cast(a.RoleType_single_sort_seq AS VARCHAR), 4)
	SET a.sequence_number = right('0000' + cast(a._Parse_seq AS VARCHAR), 4) --?????????????????????????????????????????????????????????????????????????????????????????????
	FROM [lien_dtdb].[infc].[deed_buyer_names] a

	--INNER JOIN lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashupd1 b ON b.name_id = a.name_id
	--	AND b.row4 = a.row4
	/*
 select * from  lien_dtdb.infc.deed_buyer_names a
 select * from lien_dtdb.infc.deed_buyer_names_wrk
 */
	--Seller names
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_seller_names_wrk]
		SELECT *
			,ROW4 AS ROW4_2
		INTO [Lien_dtdb].[infc].[deed_seller_names_wrk]
		FROM [Lien_dtdb].[infc].[deed_seller_names] a

	--where  ((a.party_type_code in ('aka','dba') and a.dba_aka_sort_seq =1 ) or a.party_type_code not in ('aka','dba'))
	--select * from Lien_dtdb.infc.deed_seller_names_wrk
	/****** Object:  Index idx_doc_id    Script Date: 9/25/2023 2:02:57 PM ******/
	CREATE NONCLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[infc].[deed_seller_names_wrk] (Doc_id ASC)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				) ON [PRIMARY]

	/****** Object:  Index idx_row    Script Date: 9/25/2023 2:02:58 PM ******/
	CREATE NONCLUSTERED INDEX idx_row ON [Lien_dtdb].[infc].[deed_seller_names_wrk] (
		Doc_id ASC
		,ROW4 ASC
		)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				) ON [PRIMARY]

	CREATE INDEX idx_doc_id_name_id ON [Lien_dtdb].[infc].[deed_seller_names_wrk] (
		doc_id
		,name_id
		)

	-- select * from Lien_dtdb.infc.deed_seller_names_pivot
	--
	-- Combine Related names
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_Seller]
		CREATE TABLE [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_Seller] (
			doc_id INT NOT NULL
			,Name_id INT NOT NULL
			,new_last_company_name VARCHAR(200) NULL
			,master_row BIGINT NULL
			,child_row BIGINT NULL
			)

	CREATE INDEX idx ON [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_Seller] (doc_id)

	SET @row4 = 1

	WHILE @row4 < 9
	BEGIN
		INSERT INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_Seller] (
			doc_id
			,Name_id
			,new_last_company_name
			,master_row
			,child_row
			)
		SELECT n.doc_id
			,n.Name_id
			,CASE 
				WHEN n.name_identifier IN (
						'C'
						,'T'
						)
					AND n.party_type_code <> 'CO'
					THEN n.last_company_name
				WHEN n.name_identifier IN ('I')
					AND nx.row4 IS NOT NULL
					AND (
						n.party_type_code IN ('SPS')
						--OR n.relationship_code NOT IN (
						--	'HW'
						--	,'DP'
						--	,'HH'
						--	,'MC'
						--	,'WH'
						--	,'WM'
						--	,'LC'
						--	)
						)
					AND nx.last_company_name = n.last_company_name
					THEN substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name + ' ' + '&' + ' ' + nx.first_name + ' ' + nx.middle_name + ' ' + nx.suffix, '  ', ' ')), 1, 200)
				WHEN n.name_identifier IN ('I')
					AND (
						n.party_type_code NOT IN ('SPS')
						OR n.relationship_code NOT IN (
							'HW'
							,'DP'
							,'HH'
							,'MC'
							,'WH'
							,'WM'
							,'LC'
							)
						)
					THEN substring(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, 1, 200)
				WHEN n.name_identifier IN ('I')
					AND nx.row4 IS NOT NULL
					AND (
						n.party_type_code IN ('SPS')
						OR n.relationship_code NOT IN (
							'HW'
							,'DP'
							,'HH'
							,'MC'
							,'WH'
							,'WM'
							,'LC'
							)
						)
					AND nx.last_company_name <> n.last_company_name
					THEN substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, '  ', ' ')), 1, 200)
						--if name_identifer is equal to 'I', party_type is = to 'SPS' or  relationship_code = 'HW' or 'DP', or 'HH' or 'MC' or 'WH' or 'WM' or 'LC' and sequence number 0001 last_company_name is equal to sequence number 0002 last_company_name, map sequence_number '0001' last_company_name + suffix + first_name + middle_name + ' & ' + <then from sequence_number = '0002'> first_name + middle_name + suffix
				ELSE substring(rtrim(replace(n.last_company_name + ' ' + n.suffix + ' ' + n.first_name + ' ' + n.middle_name, '  ', ' ')), 1, 200) --n.last_company_name  --- Marie
				END AS new_last_company_name
			,n.ROW4 AS master_row
			,nx.ROW4 AS child_row
		FROM [Lien_dtdb].[infc].[deed_seller_names] n
		OUTER APPLY (
			SELECT *
			FROM [Lien_dtdb].[infc].[deed_seller_names] nx
			WHERE nx.doc_id = n.doc_id
				AND nx.ROW4 = @row4 + 1
			) nx
		WHERE /*n.doc_id = 218752883
		AND*/ n.row4 = @row4
			AND (
				(
					n.party_type_code IN (
						'aka'
						,'dba'
						)
					AND n.dba_aka_sort_seq = 1
					)
				OR n.party_type_code NOT IN (
					'aka'
					,'dba'
					)
				)
		ORDER BY n.sequence_number

		--SELECT * FROM lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_hashUpdate
		DELETE a
		--declare @row4 int = 1
		--SELECT a.*
		FROM [Lien_dtdb].[infc].[deed_seller_names] a
		INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_seller] b ON b.doc_id = a.Doc_id
		WHERE a.row4 = @row4 + 1
			AND b.child_row = @row4 + 1
			AND new_last_company_name LIKE '%&%'

		SET @row4 = @row4 + 1
	END

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Combine_NAME = substring(replace(b.new_last_company_name, '  ', ' '), 1, 60)
	FROM [Lien_dtdb].[infc].[deed_seller_names] a
	INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashUpdate_Seller] b ON b.Name_id = a.Name_id
		AND b.master_row = a.row4

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Combine_NAME = substring(rtrim(replace(a.last_company_name + ' ' + a.suffix + ' ' + a.first_name + ' ' + a.middle_name, '  ', ' ')), 1, 60)
	FROM [Lien_dtdb].[infc].[deed_seller_names] a
	WHERE isnull(a.Combine_NAME, '') = ''

	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashupd1_Seller]
		SELECT *
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id ORDER BY row4
				) AS ROW5
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashupd1_Seller]
		FROM [Lien_dtdb].[infc].[deed_seller_names] a

	--WHERE doc_id = 218752883
	--select right('0000' + cast(b.row5 as varchar),4) as new_sequence_number , a.* 
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sequence_number = right('0000' + cast(b.row5 AS VARCHAR), 4)
	FROM [Lien_dtdb].[infc].[deed_seller_names] a
	INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hashupd1_Seller] b ON b.name_id = a.name_id
		AND b.row4 = a.row4

	-- end mtg_names
	/*
select * from lien_dtdb.infc.deed_buyer_names
select * from lien_dtdrb.dbo.deed_buyer_names_wrk
select * from lien_dtdb.infc.deed_buyer_names_pivot
*/
	--
	--end Combine
	--
	--	select * from lien_dtdb.infc.deed_buyer_names where doc_id = 175866803
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names]
		SELECT k.*
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names]
		FROM (
			SELECT a.Doc_id
				,a.Combine_NAME
				,ROW_NUMBER() OVER (
					PARTITION BY a.doc_id
					,b.last_company_name
					,b.first_name
					,b.middle_name
					,b.suffix ORDER BY b.name_id
					) AS delete_duplicates
				--,a.sequence_number
				--,a.Name_id
				--,a.sequence_number
				--,a.last_company_name
				--,a.first_name
				--,a.middle_name
				--,a.party_type_code
				--,a.aditional_name_id
				,'b' AS _b
				,b.*
			FROM [lien_dtdb].[infc].[deed_buyer_names] a
			OUTER APPLY (
				SELECT b.name_id
					--,try_cast(b.sequence_number AS INT) AS sequence_number -- ?????????????????????????????????????????????????????????????????
					,try_cast(b._Parse_seq AS INT) AS sequence_number
					,b.last_company_name
					,b.first_name
					,b.middle_name
					,b.suffix
					,b.party_type_code
					,b.relationship_code
					,b.vesting_code
					,b.percent_transferred
					--
					,b._Name_type
					,b.doc_unique_id
					,b.name_identifier
					,b.role_type
					,b.address_same_as_property_address_flag
					,b.address
					,b.orig_Mtg_Lender_Name
					,b.RN
					,b.address_city_name
					,b.address_state_name
					,b.address_zip_code
					,b.dba_aka_sort_seq
					,b.RoleType_single_sort_seq
					,b.AddressMatchResults
					,b.aditional_name_id
					,b._Parse_seq
					,b.ROW_aka
					,ns.Fips
					,ns.Ref_id
					,ns.Match_code
					,ns.Apn
					,ns.HouseNumber
					,ns.Street_Number
					,ns.Direction
					,ns.Street_Name
					,ns.Street_Type
					,ns.Post_Direction
					,ns.Unit_Type
					,ns.Unit
					,ns.City
					,ns.STATE
					,ns.Zip
					,ns.Plus4
					,ns.CRRT
					,ns.CountyName
					,ns.PMB
					,ns.PMSA
					,ns.MSA
					,ns.ZipType
					,ns.Urbanization
					,ns.CongressionalDistrict
					,ns.CountryCode
					,ns.CityAbbreviation
					,ns.AddressTypeCode
					,ns.AddressTypeString
					,ns.DPV_Count
					,ns.DPV_Footnotes
					,ns.CMRA
					,ns.ELOT_Number
					,ns.ELOT_Order
					,ns.LACS
					,ns.LACS_LinkIndicator
					,ns.EWS_Flag
					,ns.RBDI
					,ns.SuiteLinkReturnCode
					,ns.DeliveryPointCheckDigit
					,ns.DeliveryPointCode
					,ns.CensusBlock
					,ns.CensusTract
					,ns.PlaceCode
					,ns.PlaceName
					,ns.CBSACode
					,ns.CBSALevel
					,ns.CBSATitle
					,ns.CBSADivisionCode
					,ns.CBSADivisionLevel
					,ns.CBSADivisionTitle
					,ns.Latitude
					,ns.Longitude
					,ns.Verified
					,ns.Geocoded
					,ns.GeoErrorCode
					,ns.GeoStatusCode
					,ns.AddressType
				FROM [lien_dtdb].[infc].[deed_buyer_names_wrk] b
				OUTER APPLY (
					SELECT *
					FROM [lien].[ur].[NAME_STD_ADDRESS] ns WITH (
							NOLOCK
							,INDEX (PK_Name_Std_Address)
							)
					WHERE ns.Name_id = b.Name_id
					) ns
				WHERE b.name_id = a.name_id
				
				UNION ALL
				
				SELECT c.name_id
					--,try_cast(c.sequence_number AS INT) AS sequence_number -- ?????????????????????????????????????????????????????????????????
					,try_cast(c._Parse_seq AS INT) AS sequence_number
					,c.last_company_name
					,c.first_name
					,c.middle_name
					,c.suffix
					,c.party_type_code
					,c.relationship_code
					,c.vesting_code
					,c.percent_transferred
					--
					,c._Name_type
					,c.doc_unique_id
					,c.name_identifier
					,c.role_type
					,c.address_same_as_property_address_flag
					,c.address
					,c.orig_Mtg_Lender_Name
					,c.RN
					,c.address_city_name
					,c.address_state_name
					,c.address_zip_code
					,c.dba_aka_sort_seq
					,c.RoleType_single_sort_seq
					,c.AddressMatchResults
					,c.aditional_name_id
					,c._Parse_seq
					,c.ROW_aka
					,ns.Fips
					,ns.Ref_id
					,ns.Match_code
					,ns.Apn
					,ns.HouseNumber
					,ns.Street_Number
					,ns.Direction
					,ns.Street_Name
					,ns.Street_Type
					,ns.Post_Direction
					,ns.Unit_Type
					,ns.Unit
					,ns.City
					,ns.STATE
					,ns.Zip
					,ns.Plus4
					,ns.CRRT
					,ns.CountyName
					,ns.PMB
					,ns.PMSA
					,ns.MSA
					,ns.ZipType
					,ns.Urbanization
					,ns.CongressionalDistrict
					,ns.CountryCode
					,ns.CityAbbreviation
					,ns.AddressTypeCode
					,ns.AddressTypeString
					,ns.DPV_Count
					,ns.DPV_Footnotes
					,ns.CMRA
					,ns.ELOT_Number
					,ns.ELOT_Order
					,ns.LACS
					,ns.LACS_LinkIndicator
					,ns.EWS_Flag
					,ns.RBDI
					,ns.SuiteLinkReturnCode
					,ns.DeliveryPointCheckDigit
					,ns.DeliveryPointCode
					,ns.CensusBlock
					,ns.CensusTract
					,ns.PlaceCode
					,ns.PlaceName
					,ns.CBSACode
					,ns.CBSALevel
					,ns.CBSATitle
					,ns.CBSADivisionCode
					,ns.CBSADivisionLevel
					,ns.CBSADivisionTitle
					,ns.Latitude
					,ns.Longitude
					,ns.Verified
					,ns.Geocoded
					,ns.GeoErrorCode
					,ns.GeoStatusCode
					,ns.AddressType
				FROM [lien_dtdb].[infc].[deed_buyer_names_wrk] c
				OUTER APPLY (
					SELECT *
					FROM [lien].[ur].[NAME_STD_ADDRESS] ns WITH (
							NOLOCK
							,INDEX (PK_Name_Std_Address)
							)
					WHERE ns.Name_id = c.Name_id
					) ns
				WHERE c.name_id = a.aditional_name_id
				) b
			) k
		WHERE /*k.doc_id = 147162128 --175866803 --147388713 -- 
		AND*/ k.delete_duplicates = 1

	CREATE INDEX idx_doc_id_name_id ON [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] (
		doc_id
		,name_id
		)

	CREATE INDEX idx_doc_id_comb_name_dupl ON [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] (
		doc_id
		,Combine_NAME
		,delete_duplicates
		)

	/*
 select  format(count(*), '##,##0') as cnt from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names where doc_id = 147162128
 select * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names where doc_id = 147162128

*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hasseq_update]
		SELECT Doc_id
			,name_id
			,sequence_number
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id ORDER BY sequence_number
				) AS New_seq
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hasseq_update]
		FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names]

	--select t.* , a.* 
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.sequence_number = t.New_seq
	FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] a
	INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_hasseq_update] t ON t.doc_id = a.doc_id
		AND t.name_id = a.name_id

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[USP_Extract_Names_NAME_STD_ADDRESS]
		SELECT *
		INTO [lien_dtdb].[tmp].[USP_Extract_Names_NAME_STD_ADDRESS]
		FROM [lien].[ur].[NAME_STD_ADDRESS] ns WITH (
				NOLOCK
				,INDEX (PK_Name_Std_Address)
				)
		WHERE ns.Name_id IN (
				SELECT name_id
				FROM [lien_dtdb].[infc].[deed_buyer_names_wrk]
				)

	CREATE CLUSTERED INDEX idx_name_id ON [lien_dtdb].[tmp].[USP_Extract_Names_NAME_STD_ADDRESS] (name_id)

	-- get the address from the record that was not selected
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Fips = ns.fips
		,a.Ref_id = ns.Ref_id
		,a.Match_code = ns.Match_code
		,a.Apn = ns.Apn
		,a.HouseNumber = ns.HouseNumber
		,a.Street_Number = ns.Street_Number
		,a.Direction = ns.Direction
		,a.Street_Name = ns.Street_Name
		,a.Street_Type = ns.Street_Type
		,a.Post_Direction = ns.Post_Direction
		,a.Unit_Type = ns.Unit_Type
		,a.Unit = ns.Unit
		,a.City = ns.City
		,a.STATE = ns.STATE
		,a.Zip = ns.Zip
		,a.Plus4 = ns.Plus4
		,a.CRRT = ns.CRRT
		,a.CountyName = ns.CountyName
		,a.PMB = ns.PMB
		,a.PMSA = ns.PMSA
		,a.MSA = ns.MSA
		,a.ZipType = ns.ZipType
		,a.Urbanization = ns.Urbanization
		,a.CongressionalDistrict = ns.CongressionalDistrict
		,a.CountryCode = ns.CountryCode
		,a.CityAbbreviation = ns.CityAbbreviation
		,a.AddressTypeCode = ns.AddressTypeCode
		,a.AddressTypeString = ns.AddressTypeString
		,a.DPV_Count = ns.DPV_Count
		,a.DPV_Footnotes = ns.DPV_Footnotes
		,a.CMRA = ns.CMRA
		,a.ELOT_Number = ns.ELOT_Number
		,a.ELOT_Order = ns.ELOT_Order
		,a.LACS = ns.LACS
		,a.LACS_LinkIndicator = ns.LACS_LinkIndicator
		,a.EWS_Flag = ns.EWS_Flag
		,a.RBDI = ns.RBDI
		,a.SuiteLinkReturnCode = ns.SuiteLinkReturnCode
		,a.DeliveryPointCheckDigit = ns.DeliveryPointCheckDigit
		,a.DeliveryPointCode = ns.DeliveryPointCode
		,a.CensusBlock = ns.CensusBlock
		,a.CensusTract = ns.CensusTract
		,a.PlaceCode = ns.PlaceCode
		,a.PlaceName = ns.PlaceName
		,a.CBSACode = ns.CBSACode
		,a.CBSALevel = ns.CBSALevel
		,a.CBSATitle = ns.CBSATitle
		,a.CBSADivisionCode = ns.CBSADivisionCode
		,a.CBSADivisionLevel = ns.CBSADivisionLevel
		,a.CBSADivisionTitle = ns.CBSADivisionTitle
		,a.Latitude = ns.Latitude
		,a.Longitude = ns.Longitude
		,a.Verified = ns.Verified
		,a.Geocoded = ns.Geocoded
		,a.AddressMatchResults = ns.AddressMatchResults
		,a.GeoErrorCode = ns.GeoErrorCode
		,a.GeoStatusCode = ns.GeoStatusCode
		,a.AddressType = ns.AddressType
	FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] a -- with(nolock,index(idx_HouseNumber))
	OUTER APPLY (
		SELECT TOP 1 w.doc_id
			,w.Name_id
			,w.last_company_name
			,w.first_name
			,w.middle_name
			,w.suffix
			,w.address
		FROM [lien_dtdb].[infc].[deed_buyer_names_wrk] w WITH (
				NOLOCK
				,INDEX (idx_doc_id_address)
				)
		WHERE w.doc_id = a.doc_id
			AND w.last_company_name = a.last_company_name
			AND w.first_name = a.first_name
			AND w.middle_name = a.middle_name
			AND w.suffix = a.suffix
		ORDER BY w.address DESC
		) b
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[tmp].[USP_Extract_Names_NAME_STD_ADDRESS] ns WITH (
				NOLOCK
				,INDEX (idx_name_id)
				)
		WHERE ns.Name_id = b.Name_id
		) ns
	WHERE ns.name_id <> a.name_id
		AND a.HouseNumber IS NULL
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--create index idx_HouseNumber on lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names (HouseNumber)
	/*
 select * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names where doc_id = 147162128

*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_distinct_buyer_names]
		SELECT DISTINCT doc_id
			,Combine_NAME
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_distinct_buyer_names]
		FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names]

	/*
	select 'USP_Extract_Names_distinct_buyer_name', * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_distinct_buyer_names where doc_id = 147162128
	select 'USP_Extract_Names_buyer_own_names', * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_own_names  where doc_id = 147162128
	select 'USP_Extract_Names_buyer_Parsed_names' ,* from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names where doc_id = 147162128

*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_own_names]
		SELECT ROW_NUMBER() OVER (
				PARTITION BY b.doc_id ORDER BY b.sequence_number
				) AS ROW4_deed_seq
			,b.*
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_own_names]
		FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_distinct_buyer_names] a
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] b WITH (
					NOLOCK
					,INDEX (idx_doc_id_comb_name_dupl)
					)
			WHERE b.doc_id = a.doc_id
				AND b.Combine_NAME = a.Combine_NAME
				AND b.delete_duplicates = 1
			ORDER BY b.sequence_number
			) b

	--OUTER APPLY (
	--	SELECT *
	--	FROM lien.ur.NAME_STD_ADDRESS ns WITH (
	--			NOLOCK
	--			,INDEX (PK_Name_Std_Address)
	--			)
	--	WHERE ns.Name_id = b.Name_id
	--	) ns
	/*
   select * from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_own_names
*/
	----DROP TABLE
	----IF EXISTS lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_baaaaaaaaaaaaaaaauyer_Parsed_names
	----	SELECT a.*
	----	--,ROW_NUMBER( ) OVER ( PARTITION BY 0  ORDER BY ( SELECT 0 ) ) AS ROW4
	----	INTO lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_baaaaaaaaaaaaaaaauyer_Parsed_names
	----	FROM (
	----		SELECT *
	----		FROM lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names
	----		) a
	--SELECT 'buyer_own_names' AS _buyer_own_names
	--	,*
	--FROM lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_own_names
	--SELECT 'buyer_Parsed_names' AS _buyer_Parsed_names
	--	,*
	--FROM lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_Parsed_names
	--
	--pivot
	--
	--select  * from  lien_dtdb.infc.[deed_buyer_names_pivot] where doc_id = 353101766
	--	select  format(count(*), '##,##0') as cnt from lien_dtdb.lien_dtdb_tmp.USP_Extract_Names_buyer_own_names where doc_id = 147162128
	-- [Execute SQL Task] Error: Executing the query "DECLARE @ERROR varchar(500)
	--,@Error_Msg varchar(50..." failed with the following error: "Index 'idx_doc_id' on table 'lien_dtdb.infc.deed_buyer_names_pivot' (specified in the FROM clause) does not exist.". Possible failure reasons: Problems with the query, "ResultSet" property not set correctly, parameters not set correctly, or connection not established correctly.
	DROP TABLE

	IF EXISTS [lien_dtdb].[infc].[deed_buyer_names_pivot]
		CREATE TABLE [lien_dtdb].[infc].[deed_buyer_names_pivot] (
			[Doc_id] [int] NOT NULL
			,[role_type_1] [varchar](200) NULL
			,[role_type_2] [varchar](200) NULL
			,[role_type_3] [varchar](200) NULL
			,[role_type_4] [varchar](200) NULL
			,[role_type_5] [varchar](200) NULL
			,[role_type_6] [varchar](200) NULL
			,[role_type_7] [varchar](200) NULL
			,[role_type_8] [varchar](200) NULL
			,[Name_id_1] [int] NULL
			,[Name_id_2] [int] NULL
			,[Name_id_3] [int] NULL
			,[Name_id_4] [int] NULL
			,[Name_id_5] [int] NULL
			,[Name_id_6] [int] NULL
			,[Name_id_7] [int] NULL
			,[Name_id_8] [int] NULL
			,[name_identifier_1] [varchar](1) NULL
			,[name_identifier_2] [varchar](1) NULL
			,[name_identifier_3] [varchar](1) NULL
			,[name_identifier_4] [varchar](1) NULL
			,[name_identifier_5] [varchar](1) NULL
			,[name_identifier_6] [varchar](1) NULL
			,[name_identifier_7] [varchar](1) NULL
			,[name_identifier_8] [varchar](1) NULL
			,[BYR1_CORP_IND] [varchar](1) NULL
			,[BYR2_CORP_IND] [varchar](1) NULL
			,[BYR3_CORP_IND] [varchar](1) NULL
			,[BYR4_CORP_IND] [varchar](1) NULL
			,[BYR5_CORP_IND] [varchar](1) NULL
			,[BYR6_CORP_IND] [varchar](1) NULL
			,[BYR7_CORP_IND] [varchar](1) NULL
			,[BYR8_CORP_IND] [varchar](1) NULL
			,[BYR1_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR2_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR3_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR4_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR5_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR6_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR7_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR8_OWN_ETAL_IND] [varchar](1) NULL
			,[BYR1_CO_NAME] [varchar](1) NULL
			,[BYR2_CO_NAME] [varchar](1) NULL
			,[BYR3_CO_NAME] [varchar](1) NULL
			,[BYR4_CO_NAME] [varchar](1) NULL
			,[BYR5_CO_NAME] [varchar](1) NULL
			,[BYR6_CO_NAME] [varchar](1) NULL
			,[BYR7_CO_NAME] [varchar](1) NULL
			,[BYR8_CO_NAME] [varchar](1) NULL
			,[BYR1_OWNERSHIP] [varchar](3) NULL
			,[BYR2_OWNERSHIP] [varchar](3) NULL
			,[BYR3_OWNERSHIP] [varchar](3) NULL
			,[BYR4_OWNERSHIP] [varchar](3) NULL
			,[BYR5_OWNERSHIP] [varchar](3) NULL
			,[BYR6_OWNERSHIP] [varchar](3) NULL
			,[BYR7_OWNERSHIP] [varchar](3) NULL
			,[BYR8_OWNERSHIP] [varchar](3) NULL
			,[BYR1_OWN_NAME] [varchar](60) NULL
			,[BYR2_OWN_NAME] [varchar](60) NULL
			,[BYR3_OWN_NAME] [varchar](60) NULL
			,[BYR4_OWN_NAME] [varchar](60) NULL
			,[BYR5_OWN_NAME] [varchar](60) NULL
			,[BYR6_OWN_NAME] [varchar](60) NULL
			,[BYR7_OWN_NAME] [varchar](60) NULL
			,[BYR8_OWN_NAME] [varchar](60) NULL
			,[BYR1_LAST_NAME] [varchar](200) NULL
			,[BYR2_LAST_NAME] [varchar](200) NULL
			,[BYR3_LAST_NAME] [varchar](200) NULL
			,[BYR4_LAST_NAME] [varchar](200) NULL
			,[BYR5_LAST_NAME] [varchar](200) NULL
			,[BYR6_LAST_NAME] [varchar](200) NULL
			,[BYR7_LAST_NAME] [varchar](200) NULL
			,[BYR8_LAST_NAME] [varchar](200) NULL
			,[BYR1_FIRST_NAME] [varchar](200) NULL
			,[BYR2_FIRST_NAME] [varchar](200) NULL
			,[BYR3_FIRST_NAME] [varchar](200) NULL
			,[BYR4_FIRST_NAME] [varchar](200) NULL
			,[BYR5_FIRST_NAME] [varchar](200) NULL
			,[BYR6_FIRST_NAME] [varchar](200) NULL
			,[BYR7_FIRST_NAME] [varchar](200) NULL
			,[BYR8_FIRST_NAME] [varchar](200) NULL
			,[BYR1_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR2_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR3_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR4_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR5_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR6_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR7_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR8_MIDDLE_INITIAL] [varchar](200) NULL
			,[BYR1_SUFFIX] [varchar](200) NULL
			,[BYR2_SUFFIX] [varchar](200) NULL
			,[BYR3_SUFFIX] [varchar](200) NULL
			,[BYR4_SUFFIX] [varchar](200) NULL
			,[BYR5_SUFFIX] [varchar](200) NULL
			,[BYR6_SUFFIX] [varchar](200) NULL
			,[BYR7_SUFFIX] [varchar](200) NULL
			,[BYR8_SUFFIX] [varchar](200) NULL
			,[party_type_code_1] [varchar](200) NULL
			,[party_type_code_2] [varchar](200) NULL
			,[party_type_code_3] [varchar](200) NULL
			,[party_type_code_4] [varchar](200) NULL
			,[party_type_code_5] [varchar](200) NULL
			,[party_type_code_6] [varchar](200) NULL
			,[party_type_code_7] [varchar](200) NULL
			,[party_type_code_8] [varchar](200) NULL
			,[BYR1_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR2_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR3_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR4_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR5_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR6_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR7_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR8_OWN_RELATIONSHIP_TYPE] [varchar](10) NULL
			,[BYR1_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR2_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR3_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR4_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR5_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR6_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR7_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[BYR8_OWNERSHIP_RIGHTS_CODE] [varchar](10) NULL
			,[percent_transferred_1] [varchar](200) NULL
			,[percent_transferred_2] [varchar](200) NULL
			,[percent_transferred_3] [varchar](200) NULL
			,[percent_transferred_4] [varchar](200) NULL
			,[percent_transferred_5] [varchar](200) NULL
			,[percent_transferred_6] [varchar](200) NULL
			,[percent_transferred_7] [varchar](200) NULL
			,[percent_transferred_8] [varchar](200) NULL
			,[address_same_as_property_address_flag_1] [varchar](200) NULL
			,[address_same_as_property_address_flag_2] [varchar](200) NULL
			,[address_same_as_property_address_flag_3] [varchar](200) NULL
			,[address_same_as_property_address_flag_4] [varchar](200) NULL
			,[address_same_as_property_address_flag_5] [varchar](200) NULL
			,[address_same_as_property_address_flag_6] [varchar](200) NULL
			,[address_same_as_property_address_flag_7] [varchar](200) NULL
			,[address_same_as_property_address_flag_8] [varchar](200) NULL
			,[MA_HOUSE_NBR_PREFIX_1] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_2] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_3] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_4] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_5] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_6] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_7] [varchar](1) NULL
			,[MA_HOUSE_NBR_PREFIX_8] [varchar](1) NULL
			,[MA_HOUSE_NBR_1] [varchar](30) NULL
			,[MA_HOUSE_NBR_2] [varchar](30) NULL
			,[MA_HOUSE_NBR_3] [varchar](30) NULL
			,[MA_HOUSE_NBR_4] [varchar](30) NULL
			,[MA_HOUSE_NBR_5] [varchar](30) NULL
			,[MA_HOUSE_NBR_6] [varchar](30) NULL
			,[MA_HOUSE_NBR_7] [varchar](30) NULL
			,[MA_HOUSE_NBR_8] [varchar](30) NULL
			,[MA_HOUSE_NBR_SUFFIX_1] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_2] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_3] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_4] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_5] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_6] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_7] [varchar](1) NULL
			,[MA_HOUSE_NBR_SUFFIX_8] [varchar](1) NULL
			,[MA_STREET_DIRECTION_1] [varchar](2) NULL
			,[MA_STREET_DIRECTION_2] [varchar](2) NULL
			,[MA_STREET_DIRECTION_3] [varchar](2) NULL
			,[MA_STREET_DIRECTION_4] [varchar](2) NULL
			,[MA_STREET_DIRECTION_5] [varchar](2) NULL
			,[MA_STREET_DIRECTION_6] [varchar](2) NULL
			,[MA_STREET_DIRECTION_7] [varchar](2) NULL
			,[MA_STREET_DIRECTION_8] [varchar](2) NULL
			,[MA_STREET_NAME_1] [varchar](60) NULL
			,[MA_STREET_NAME_2] [varchar](60) NULL
			,[MA_STREET_NAME_3] [varchar](60) NULL
			,[MA_STREET_NAME_4] [varchar](60) NULL
			,[MA_STREET_NAME_5] [varchar](60) NULL
			,[MA_STREET_NAME_6] [varchar](60) NULL
			,[MA_STREET_NAME_7] [varchar](60) NULL
			,[MA_STREET_NAME_8] [varchar](60) NULL
			,[MA_MODE_1] [varchar](4) NULL
			,[MA_MODE_2] [varchar](4) NULL
			,[MA_MODE_3] [varchar](4) NULL
			,[MA_MODE_4] [varchar](4) NULL
			,[MA_MODE_5] [varchar](4) NULL
			,[MA_MODE_6] [varchar](4) NULL
			,[MA_MODE_7] [varchar](4) NULL
			,[MA_MODE_8] [varchar](4) NULL
			,[MA_QUADRANT_1] [varchar](2) NULL
			,[MA_QUADRANT_2] [varchar](2) NULL
			,[MA_QUADRANT_3] [varchar](2) NULL
			,[MA_QUADRANT_4] [varchar](2) NULL
			,[MA_QUADRANT_5] [varchar](2) NULL
			,[MA_QUADRANT_6] [varchar](2) NULL
			,[MA_QUADRANT_7] [varchar](2) NULL
			,[MA_QUADRANT_8] [varchar](2) NULL
			,[MA_APARTMENT_UNIT_1] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_2] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_3] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_4] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_5] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_6] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_7] [varchar](50) NULL
			,[MA_APARTMENT_UNIT_8] [varchar](50) NULL
			,[MA_CITY_1] [varchar](55) NULL
			,[MA_CITY_2] [varchar](55) NULL
			,[MA_CITY_3] [varchar](55) NULL
			,[MA_CITY_4] [varchar](55) NULL
			,[MA_CITY_5] [varchar](55) NULL
			,[MA_CITY_6] [varchar](55) NULL
			,[MA_CITY_7] [varchar](55) NULL
			,[MA_CITY_8] [varchar](55) NULL
			,[MA_STATE_1] [varchar](2) NULL
			,[MA_STATE_2] [varchar](2) NULL
			,[MA_STATE_3] [varchar](2) NULL
			,[MA_STATE_4] [varchar](2) NULL
			,[MA_STATE_5] [varchar](2) NULL
			,[MA_STATE_6] [varchar](2) NULL
			,[MA_STATE_7] [varchar](2) NULL
			,[MA_STATE_8] [varchar](2) NULL
			,[MA_ZIP_CODE_1] [varchar](54) NULL
			,[MA_ZIP_CODE_2] [varchar](54) NULL
			,[MA_ZIP_CODE_3] [varchar](54) NULL
			,[MA_ZIP_CODE_4] [varchar](54) NULL
			,[MA_ZIP_CODE_5] [varchar](54) NULL
			,[MA_ZIP_CODE_6] [varchar](54) NULL
			,[MA_ZIP_CODE_7] [varchar](54) NULL
			,[MA_ZIP_CODE_8] [varchar](54) NULL
			,[MA_CARRIER_CODE_1] [varchar](4) NULL
			,[MA_CARRIER_CODE_2] [varchar](4) NULL
			,[MA_CARRIER_CODE_3] [varchar](4) NULL
			,[MA_CARRIER_CODE_4] [varchar](4) NULL
			,[MA_CARRIER_CODE_5] [varchar](4) NULL
			,[MA_CARRIER_CODE_6] [varchar](4) NULL
			,[MA_CARRIER_CODE_7] [varchar](4) NULL
			,[MA_CARRIER_CODE_8] [varchar](4) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_1] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_2] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_3] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_4] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_5] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_6] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_7] [varchar](200) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS_8] [varchar](200) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_1] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_2] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_3] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_4] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_5] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_6] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_7] [varchar](1) NULL
			,[MA_DO_NOT_PUBLISH_FLAG_8] [varchar](1) NULL
			,[orig_Mtg_Lender_Name_1] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_2] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_3] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_4] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_5] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_6] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_7] [varchar](200) NULL
			,[orig_Mtg_Lender_Name_8] [varchar](200) NULL
			,[address_1] [varchar](200) NULL
			,[address_2] [varchar](200) NULL
			,[address_3] [varchar](200) NULL
			,[address_4] [varchar](200) NULL
			,[address_5] [varchar](200) NULL
			,[address_6] [varchar](200) NULL
			,[address_7] [varchar](200) NULL
			,[address_8] [varchar](200) NULL
			,[address_city_name_1] [varchar](200) NULL
			,[address_city_name_2] [varchar](200) NULL
			,[address_city_name_3] [varchar](200) NULL
			,[address_city_name_4] [varchar](200) NULL
			,[address_city_name_5] [varchar](200) NULL
			,[address_city_name_6] [varchar](200) NULL
			,[address_city_name_7] [varchar](200) NULL
			,[address_city_name_8] [varchar](200) NULL
			,[address_state_name_1] [varchar](200) NULL
			,[address_state_name_2] [varchar](200) NULL
			,[address_state_name_3] [varchar](200) NULL
			,[address_state_name_4] [varchar](200) NULL
			,[address_state_name_5] [varchar](200) NULL
			,[address_state_name_6] [varchar](200) NULL
			,[address_state_name_7] [varchar](200) NULL
			,[address_state_name_8] [varchar](200) NULL
			,[address_zip_code_1] [varchar](200) NULL
			,[address_zip_code_2] [varchar](200) NULL
			,[address_zip_code_3] [varchar](200) NULL
			,[address_zip_code_4] [varchar](200) NULL
			,[address_zip_code_5] [varchar](200) NULL
			,[address_zip_code_6] [varchar](200) NULL
			,[address_zip_code_7] [varchar](200) NULL
			,[address_zip_code_8] [varchar](200) NULL
			) ON [PRIMARY]

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[infc].[deed_buyer_names_pivot] (doc_id)

	-- nessie
	INSERT INTO [lien_dtdb].[infc].[deed_buyer_names_pivot] (
		Doc_id
		,role_type_1
		,role_type_2
		,role_type_3
		,role_type_4
		,role_type_5
		,role_type_6
		,role_type_7
		,role_type_8
		,Name_id_1
		,Name_id_2
		,Name_id_3
		,Name_id_4
		,Name_id_5
		,Name_id_6
		,Name_id_7
		,Name_id_8
		,name_identifier_1
		,name_identifier_2
		,name_identifier_3
		,name_identifier_4
		,name_identifier_5
		,name_identifier_6
		,name_identifier_7
		,name_identifier_8
		,BYR1_CORP_IND
		,BYR2_CORP_IND
		,BYR3_CORP_IND
		,BYR4_CORP_IND
		,BYR5_CORP_IND
		,BYR6_CORP_IND
		,BYR7_CORP_IND
		,BYR8_CORP_IND
		,BYR1_OWN_NAME
		,BYR2_OWN_NAME
		,BYR3_OWN_NAME
		,BYR4_OWN_NAME
		,BYR5_OWN_NAME
		,BYR6_OWN_NAME
		,BYR7_OWN_NAME
		,BYR8_OWN_NAME
		)
	SELECT Doc_id
		,role_type_1
		,role_type_2
		,role_type_3
		,role_type_4
		,role_type_5
		,role_type_6
		,role_type_7
		,role_type_8
		,Name_id_1
		,Name_id_2
		,Name_id_3
		,Name_id_4
		,Name_id_5
		,Name_id_6
		,Name_id_7
		,Name_id_8
		,name_identifier_1
		,name_identifier_2
		,name_identifier_3
		,name_identifier_4
		,name_identifier_5
		,name_identifier_6
		,name_identifier_7
		,name_identifier_8
		,BYR1_CORP_IND
		,BYR2_CORP_IND
		,BYR3_CORP_IND
		,BYR4_CORP_IND
		,BYR5_CORP_IND
		,BYR6_CORP_IND
		,BYR7_CORP_IND
		,BYR8_CORP_IND
		,BYR1_OWN_NAME
		,BYR2_OWN_NAME
		,BYR3_OWN_NAME
		,BYR4_OWN_NAME
		,BYR5_OWN_NAME
		,BYR6_OWN_NAME
		,BYR7_OWN_NAME
		,BYR8_OWN_NAME
	FROM (
		SELECT doc_id
			,max(CASE 
					WHEN ROW4_deed_seq = 1
						THEN role_type
					ELSE ''
					END) AS role_type_1
			,max(CASE 
					WHEN ROW4_deed_seq = 2
						THEN role_type
					ELSE ''
					END) AS role_type_2
			,max(CASE 
					WHEN ROW4_deed_seq = 3
						THEN role_type
					ELSE ''
					END) AS role_type_3
			,max(CASE 
					WHEN ROW4_deed_seq = 4
						THEN role_type
					ELSE ''
					END) AS role_type_4
			,max(CASE 
					WHEN ROW4_deed_seq = 5
						THEN role_type
					ELSE ''
					END) AS role_type_5
			,max(CASE 
					WHEN ROW4_deed_seq = 6
						THEN role_type
					ELSE ''
					END) AS role_type_6
			,max(CASE 
					WHEN ROW4_deed_seq = 7
						THEN role_type
					ELSE ''
					END) AS role_type_7
			,max(CASE 
					WHEN ROW4_deed_seq = 8
						THEN role_type
					ELSE ''
					END) AS role_type_8
			,max(CASE 
					WHEN ROW4_deed_seq = 1
						THEN Name_id
					ELSE ''
					END) AS Name_id_1
			,max(CASE 
					WHEN ROW4_deed_seq = 2
						THEN Name_id
					ELSE ''
					END) AS Name_id_2
			,max(CASE 
					WHEN ROW4_deed_seq = 3
						THEN Name_id
					ELSE ''
					END) AS Name_id_3
			,max(CASE 
					WHEN ROW4_deed_seq = 4
						THEN Name_id
					ELSE ''
					END) AS Name_id_4
			,max(CASE 
					WHEN ROW4_deed_seq = 5
						THEN Name_id
					ELSE ''
					END) AS Name_id_5
			,max(CASE 
					WHEN ROW4_deed_seq = 6
						THEN Name_id
					ELSE ''
					END) AS Name_id_6
			,max(CASE 
					WHEN ROW4_deed_seq = 7
						THEN Name_id
					ELSE ''
					END) AS Name_id_7
			,max(CASE 
					WHEN ROW4_deed_seq = 8
						THEN Name_id
					ELSE ''
					END) AS Name_id_8
			,max(CASE 
					WHEN ROW4_deed_seq = 1
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_1
			,max(CASE 
					WHEN ROW4_deed_seq = 2
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_2
			,max(CASE 
					WHEN ROW4_deed_seq = 3
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_3
			,max(CASE 
					WHEN ROW4_deed_seq = 4
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_4
			,max(CASE 
					WHEN ROW4_deed_seq = 5
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_5
			,max(CASE 
					WHEN ROW4_deed_seq = 6
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_6
			,max(CASE 
					WHEN ROW4_deed_seq = 7
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_7
			,max(CASE 
					WHEN ROW4_deed_seq = 8
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_8
			,max(CASE 
					WHEN ROW4_deed_seq = 1
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR1_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 2
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR2_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 3
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR3_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 4
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR4_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 5
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR5_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 6
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR6_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 7
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR7_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 8
						AND name_identifier IN (
							'C'
							--,'T'
							)
						AND Combine_NAME NOT IN ('NAME NOT AVAILABLE')
						THEN 'Y'
					ELSE ''
					END) AS BYR8_CORP_IND
			,max(CASE 
					WHEN ROW4_deed_seq = 1
						THEN Combine_NAME
					ELSE ''
					END) AS BYR1_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 2
						THEN Combine_NAME
					ELSE ''
					END) AS BYR2_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 3
						THEN Combine_NAME
					ELSE ''
					END) AS BYR3_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 4
						THEN Combine_NAME
					ELSE ''
					END) AS BYR4_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 5
						THEN Combine_NAME
					ELSE ''
					END) AS BYR5_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 6
						THEN Combine_NAME
					ELSE ''
					END) AS BYR6_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 7
						THEN Combine_NAME
					ELSE ''
					END) AS BYR7_OWN_NAME
			,max(CASE 
					WHEN ROW4_deed_seq = 8
						THEN Combine_NAME
					ELSE ''
					END) AS BYR8_OWN_NAME
		FROM (
			SELECT a.Doc_id
				,role_type
				,ROW4_deed_seq
				,a.Name_id
				,a.doc_unique_id
				,a.sequence_number
				,ltrim(rtrim(isnull(a.name_identifier, ''))) AS name_identifier
				--,ltrim(rtrim(isnull(a.Combine_NAME, ''))) AS Combine_NAME
				,CASE 
					WHEN PATINDEX('%TRUST%', a.Combine_NAME) > 0
						AND substring(a.Combine_NAME, 1, 9) <> 'REVOCABLE'
						AND substring(a.Combine_NAME, 1, 5) <> 'TRUST'
						THEN substring(a.Combine_NAME, 1, PATINDEX('%TRUST%', a.Combine_NAME) + 5)
					ELSE a.Combine_NAME
					END AS Combine_NAME
			FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_own_names] a
			) b
		GROUP BY b.doc_id
		) c

	/*
select * from lien_dtdb.infc.[deed_buyer_names_pivot]

*/
	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_parse_names_pivot]
		SELECT doc_id
			,max(CASE 
					WHEN sequence_number = 1
						THEN last_company_name
					ELSE ''
					END) AS BYR1_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 2
						THEN last_company_name
					ELSE ''
					END) AS BYR2_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 3
						THEN last_company_name
					ELSE ''
					END) AS BYR3_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 4
						THEN last_company_name
					ELSE ''
					END) AS BYR4_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 5
						THEN last_company_name
					ELSE ''
					END) AS BYR5_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 6
						THEN last_company_name
					ELSE ''
					END) AS BYR6_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 7
						THEN last_company_name
					ELSE ''
					END) AS BYR7_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 8
						THEN last_company_name
					ELSE ''
					END) AS BYR8_LAST_NAME
			,max(CASE 
					WHEN sequence_number = 1
						THEN first_name
					ELSE ''
					END) AS BYR1_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 2
						THEN first_name
					ELSE ''
					END) AS BYR2_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 3
						THEN first_name
					ELSE ''
					END) AS BYR3_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 4
						THEN first_name
					ELSE ''
					END) AS BYR4_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 5
						THEN first_name
					ELSE ''
					END) AS BYR5_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 6
						THEN first_name
					ELSE ''
					END) AS BYR6_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 7
						THEN first_name
					ELSE ''
					END) AS BYR7_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 8
						THEN first_name
					ELSE ''
					END) AS BYR8_FIRST_NAME
			,max(CASE 
					WHEN sequence_number = 1
						THEN middle_name
					ELSE ''
					END) AS BYR1_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 2
						THEN middle_name
					ELSE ''
					END) AS BYR2_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 3
						THEN middle_name
					ELSE ''
					END) AS BYR3_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 4
						THEN middle_name
					ELSE ''
					END) AS BYR4_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 5
						THEN middle_name
					ELSE ''
					END) AS BYR5_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 6
						THEN middle_name
					ELSE ''
					END) AS BYR6_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 7
						THEN middle_name
					ELSE ''
					END) AS BYR7_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 8
						THEN middle_name
					ELSE ''
					END) AS BYR8_MIDDLE_INITIAL
			,max(CASE 
					WHEN sequence_number = 1
						THEN suffix
					ELSE ''
					END) AS BYR1_SUFFIX
			,max(CASE 
					WHEN sequence_number = 2
						THEN suffix
					ELSE ''
					END) AS BYR2_SUFFIX
			,max(CASE 
					WHEN sequence_number = 3
						THEN suffix
					ELSE ''
					END) AS BYR3_SUFFIX
			,max(CASE 
					WHEN sequence_number = 4
						THEN suffix
					ELSE ''
					END) AS BYR4_SUFFIX
			,max(CASE 
					WHEN sequence_number = 5
						THEN suffix
					ELSE ''
					END) AS BYR5_SUFFIX
			,max(CASE 
					WHEN sequence_number = 6
						THEN suffix
					ELSE ''
					END) AS BYR6_SUFFIX
			,max(CASE 
					WHEN sequence_number = 7
						THEN suffix
					ELSE ''
					END) AS BYR7_SUFFIX
			,max(CASE 
					WHEN sequence_number = 8
						THEN suffix
					ELSE ''
					END) AS BYR8_SUFFIX
			,max(CASE 
					WHEN sequence_number = 1
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN relationship_code
					ELSE ''
					END) AS BYR1_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 2
						THEN relationship_code
					ELSE ''
					END) AS BYR2_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 3
						THEN relationship_code
					ELSE ''
					END) AS BYR3_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 4
						THEN relationship_code
					ELSE ''
					END) AS BYR4_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 5
						THEN relationship_code
					ELSE ''
					END) AS BYR5_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 6
						THEN relationship_code
					ELSE ''
					END) AS BYR6_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 7
						THEN relationship_code
					ELSE ''
					END) AS BYR7_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 8
						THEN relationship_code
					ELSE ''
					END) AS BYR8_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN sequence_number = 1
						THEN vesting_code
					ELSE ''
					END) AS BYR1_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 2
						THEN vesting_code
					ELSE ''
					END) AS BYR2_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 3
						THEN vesting_code
					ELSE ''
					END) AS BYR3_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 4
						THEN vesting_code
					ELSE ''
					END) AS BYR4_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 5
						THEN vesting_code
					ELSE ''
					END) AS BYR5_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 6
						THEN vesting_code
					ELSE ''
					END) AS BYR6_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 7
						THEN vesting_code
					ELSE ''
					END) AS BYR7_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 8
						THEN vesting_code
					ELSE ''
					END) AS BYR8_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN sequence_number = 1
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_8
			,max(CASE 
					WHEN sequence_number = 1
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_1
			,max(CASE 
					WHEN sequence_number = 2
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_2
			,max(CASE 
					WHEN sequence_number = 3
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_3
			,max(CASE 
					WHEN sequence_number = 4
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_4
			,max(CASE 
					WHEN sequence_number = 5
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_5
			,max(CASE 
					WHEN sequence_number = 6
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_6
			,max(CASE 
					WHEN sequence_number = 7
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_7
			,max(CASE 
					WHEN sequence_number = 8
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_8
		-- select top 10 * 
		INTO [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_parse_names_pivot]
		FROM (
			SELECT a.doc_id
				,a.sequence_number
				,ltrim(rtrim(isnull(a.last_company_name, ''))) AS last_company_name
				,ltrim(rtrim(isnull(a.first_name, ''))) AS first_name
				,ltrim(rtrim(isnull(a.middle_name, ''))) AS middle_name
				,ltrim(rtrim(isnull(a.suffix, ''))) AS suffix
				,ltrim(rtrim(isnull(a.party_type_code, ''))) AS party_type_code
				,ltrim(rtrim(isnull(a.relationship_code, ''))) AS relationship_code
				,ltrim(rtrim(isnull(a.vesting_code, ''))) AS vesting_code
				,ltrim(rtrim(isnull(a.percent_transferred, ''))) AS percent_transferred
				,ltrim(rtrim(isnull(a.address_same_as_property_address_flag, ''))) AS address_same_as_property_address_flag
				,'' AS MA_HOUSE_NBR_PREFIX
				,upper(ltrim(rtrim(isnull(a.HouseNumber, '')))) AS MA_HOUSE_NBR
				,'' AS MA_HOUSE_NBR_SUFFIX
				,upper(ltrim(rtrim(isnull(a.Direction, '')))) AS MA_STREET_DIRECTION
				,upper(ltrim(rtrim(isnull(a.Street_Name, '')))) AS MA_STREET_NAME
				,upper(ltrim(rtrim(isnull(a.Street_Type, '')))) AS MA_MODE
				,upper(ltrim(rtrim(isnull(a.Post_Direction, '')))) AS MA_QUADRANT
				,upper(ltrim(rtrim(isnull(a.Unit, '')))) AS MA_APARTMENT_UNIT
				,upper(ltrim(rtrim(isnull(a.City, '')))) AS MA_CITY
				,upper(ltrim(rtrim(isnull(a.STATE, '')))) AS MA_STATE
				,upper(ltrim(rtrim(isnull(a.Zip, '')))) + UPPER(ltrim(rtrim(isnull(a.Plus4, '')))) AS MA_ZIP_CODE
				,upper(ltrim(rtrim(isnull(a.CRRT, '')))) AS MA_CARRIER_CODE
				--,upper(ltrim(rtrim(isnull(a.address, '')))) AS MA_ORIGINAL_MAILING_ADDRESS
				,upper(ltrim(rtrim(CASE 
								WHEN CHARINDEX('|', a.address) > 0
									THEN LEFT(a.address, CHARINDEX('|', a.address) - 1)
								ELSE ISNULL(a.address, '')
								END))) AS MA_ORIGINAL_MAILING_ADDRESS
				,'' AS MA_DO_NOT_PUBLISH_FLAG
				,upper(ltrim(rtrim(isnull(a.orig_Mtg_Lender_Name, '')))) AS orig_Mtg_Lender_Name
				,upper(ltrim(rtrim(isnull(a.address, '')))) AS address
				,upper(ltrim(rtrim(isnull(a.address_city_name, '')))) AS address_city_name
				,upper(ltrim(rtrim(isnull(a.address_state_name, '')))) AS address_state_name
				,upper(ltrim(rtrim(isnull(a.address_zip_code, '')))) AS address_zip_code
			FROM [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_Parsed_names] a
			) a
		GROUP BY doc_id

	CREATE INDEX idx_doc_id ON [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_parse_names_pivot] (doc_id)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.BYR1_LAST_NAME = b.BYR1_LAST_NAME
		,a.BYR2_LAST_NAME = b.BYR2_LAST_NAME
		,a.BYR3_LAST_NAME = b.BYR3_LAST_NAME
		,a.BYR4_LAST_NAME = b.BYR4_LAST_NAME
		,a.BYR5_LAST_NAME = b.BYR5_LAST_NAME
		,a.BYR6_LAST_NAME = b.BYR6_LAST_NAME
		,a.BYR7_LAST_NAME = b.BYR7_LAST_NAME
		,a.BYR8_LAST_NAME = b.BYR8_LAST_NAME
		,a.BYR1_FIRST_NAME = b.BYR1_FIRST_NAME
		,a.BYR2_FIRST_NAME = b.BYR2_FIRST_NAME
		,a.BYR3_FIRST_NAME = b.BYR3_FIRST_NAME
		,a.BYR4_FIRST_NAME = b.BYR4_FIRST_NAME
		,a.BYR5_FIRST_NAME = b.BYR5_FIRST_NAME
		,a.BYR6_FIRST_NAME = b.BYR6_FIRST_NAME
		,a.BYR7_FIRST_NAME = b.BYR7_FIRST_NAME
		,a.BYR8_FIRST_NAME = b.BYR8_FIRST_NAME
		,a.BYR1_MIDDLE_INITIAL = b.BYR1_MIDDLE_INITIAL
		,a.BYR2_MIDDLE_INITIAL = b.BYR2_MIDDLE_INITIAL
		,a.BYR3_MIDDLE_INITIAL = b.BYR3_MIDDLE_INITIAL
		,a.BYR4_MIDDLE_INITIAL = b.BYR4_MIDDLE_INITIAL
		,a.BYR5_MIDDLE_INITIAL = b.BYR5_MIDDLE_INITIAL
		,a.BYR6_MIDDLE_INITIAL = b.BYR6_MIDDLE_INITIAL
		,a.BYR7_MIDDLE_INITIAL = b.BYR7_MIDDLE_INITIAL
		,a.BYR8_MIDDLE_INITIAL = b.BYR8_MIDDLE_INITIAL
		,a.BYR1_SUFFIX = b.BYR1_SUFFIX
		,a.BYR2_SUFFIX = b.BYR2_SUFFIX
		,a.BYR3_SUFFIX = b.BYR3_SUFFIX
		,a.BYR4_SUFFIX = b.BYR4_SUFFIX
		,a.BYR5_SUFFIX = b.BYR5_SUFFIX
		,a.BYR6_SUFFIX = b.BYR6_SUFFIX
		,a.BYR7_SUFFIX = b.BYR7_SUFFIX
		,a.BYR8_SUFFIX = b.BYR8_SUFFIX
		,a.party_type_code_1 = b.party_type_code_1
		,a.party_type_code_2 = b.party_type_code_2
		,a.party_type_code_3 = b.party_type_code_3
		,a.party_type_code_4 = b.party_type_code_4
		,a.party_type_code_5 = b.party_type_code_5
		,a.party_type_code_6 = b.party_type_code_6
		,a.party_type_code_7 = b.party_type_code_7
		,a.party_type_code_8 = b.party_type_code_8
		,a.BYR1_OWN_RELATIONSHIP_TYPE = b.BYR1_OWN_RELATIONSHIP_TYPE
		,a.BYR2_OWN_RELATIONSHIP_TYPE = b.BYR2_OWN_RELATIONSHIP_TYPE
		,a.BYR3_OWN_RELATIONSHIP_TYPE = b.BYR3_OWN_RELATIONSHIP_TYPE
		,a.BYR4_OWN_RELATIONSHIP_TYPE = b.BYR4_OWN_RELATIONSHIP_TYPE
		,a.BYR5_OWN_RELATIONSHIP_TYPE = b.BYR5_OWN_RELATIONSHIP_TYPE
		,a.BYR6_OWN_RELATIONSHIP_TYPE = b.BYR6_OWN_RELATIONSHIP_TYPE
		,a.BYR7_OWN_RELATIONSHIP_TYPE = b.BYR7_OWN_RELATIONSHIP_TYPE
		,a.BYR8_OWN_RELATIONSHIP_TYPE = b.BYR8_OWN_RELATIONSHIP_TYPE
		,a.BYR1_OWNERSHIP_RIGHTS_CODE = b.BYR1_OWNERSHIP_RIGHTS_CODE
		,a.BYR2_OWNERSHIP_RIGHTS_CODE = b.BYR2_OWNERSHIP_RIGHTS_CODE
		,a.BYR3_OWNERSHIP_RIGHTS_CODE = b.BYR3_OWNERSHIP_RIGHTS_CODE
		,a.BYR4_OWNERSHIP_RIGHTS_CODE = b.BYR4_OWNERSHIP_RIGHTS_CODE
		,a.BYR5_OWNERSHIP_RIGHTS_CODE = b.BYR5_OWNERSHIP_RIGHTS_CODE
		,a.BYR6_OWNERSHIP_RIGHTS_CODE = b.BYR6_OWNERSHIP_RIGHTS_CODE
		,a.BYR7_OWNERSHIP_RIGHTS_CODE = b.BYR7_OWNERSHIP_RIGHTS_CODE
		,a.BYR8_OWNERSHIP_RIGHTS_CODE = b.BYR8_OWNERSHIP_RIGHTS_CODE
		,a.BYR1_OWNERSHIP = b.percent_transferred_1
		,a.BYR2_OWNERSHIP = b.percent_transferred_2
		,a.BYR3_OWNERSHIP = b.percent_transferred_3
		,a.BYR4_OWNERSHIP = b.percent_transferred_4
		,a.BYR5_OWNERSHIP = b.percent_transferred_5
		,a.BYR6_OWNERSHIP = b.percent_transferred_6
		,a.BYR7_OWNERSHIP = b.percent_transferred_7
		,a.BYR8_OWNERSHIP = b.percent_transferred_8
		,a.percent_transferred_1 = b.percent_transferred_1
		,a.percent_transferred_2 = b.percent_transferred_2
		,a.percent_transferred_3 = b.percent_transferred_3
		,a.percent_transferred_4 = b.percent_transferred_4
		,a.percent_transferred_5 = b.percent_transferred_5
		,a.percent_transferred_6 = b.percent_transferred_6
		,a.percent_transferred_7 = b.percent_transferred_7
		,a.percent_transferred_8 = b.percent_transferred_8
		,a.address_same_as_property_address_flag_1 = b.address_same_as_property_address_flag_1
		,a.address_same_as_property_address_flag_2 = b.address_same_as_property_address_flag_2
		,a.address_same_as_property_address_flag_3 = b.address_same_as_property_address_flag_3
		,a.address_same_as_property_address_flag_4 = b.address_same_as_property_address_flag_4
		,a.address_same_as_property_address_flag_5 = b.address_same_as_property_address_flag_5
		,a.address_same_as_property_address_flag_6 = b.address_same_as_property_address_flag_6
		,a.address_same_as_property_address_flag_7 = b.address_same_as_property_address_flag_7
		,a.address_same_as_property_address_flag_8 = b.address_same_as_property_address_flag_8
		,a.MA_HOUSE_NBR_PREFIX_1 = b.MA_HOUSE_NBR_PREFIX_1
		,a.MA_HOUSE_NBR_PREFIX_2 = b.MA_HOUSE_NBR_PREFIX_2
		,a.MA_HOUSE_NBR_PREFIX_3 = b.MA_HOUSE_NBR_PREFIX_3
		,a.MA_HOUSE_NBR_PREFIX_4 = b.MA_HOUSE_NBR_PREFIX_4
		,a.MA_HOUSE_NBR_PREFIX_5 = b.MA_HOUSE_NBR_PREFIX_5
		,a.MA_HOUSE_NBR_PREFIX_6 = b.MA_HOUSE_NBR_PREFIX_6
		,a.MA_HOUSE_NBR_PREFIX_7 = b.MA_HOUSE_NBR_PREFIX_7
		,a.MA_HOUSE_NBR_PREFIX_8 = b.MA_HOUSE_NBR_PREFIX_8
		,a.MA_HOUSE_NBR_1 = b.MA_HOUSE_NBR_1
		,a.MA_HOUSE_NBR_2 = b.MA_HOUSE_NBR_2
		,a.MA_HOUSE_NBR_3 = b.MA_HOUSE_NBR_3
		,a.MA_HOUSE_NBR_4 = b.MA_HOUSE_NBR_4
		,a.MA_HOUSE_NBR_5 = b.MA_HOUSE_NBR_5
		,a.MA_HOUSE_NBR_6 = b.MA_HOUSE_NBR_6
		,a.MA_HOUSE_NBR_7 = b.MA_HOUSE_NBR_7
		,a.MA_HOUSE_NBR_8 = b.MA_HOUSE_NBR_8
		,a.MA_HOUSE_NBR_SUFFIX_1 = b.MA_HOUSE_NBR_SUFFIX_1
		,a.MA_HOUSE_NBR_SUFFIX_2 = b.MA_HOUSE_NBR_SUFFIX_2
		,a.MA_HOUSE_NBR_SUFFIX_3 = b.MA_HOUSE_NBR_SUFFIX_3
		,a.MA_HOUSE_NBR_SUFFIX_4 = b.MA_HOUSE_NBR_SUFFIX_4
		,a.MA_HOUSE_NBR_SUFFIX_5 = b.MA_HOUSE_NBR_SUFFIX_5
		,a.MA_HOUSE_NBR_SUFFIX_6 = b.MA_HOUSE_NBR_SUFFIX_6
		,a.MA_HOUSE_NBR_SUFFIX_7 = b.MA_HOUSE_NBR_SUFFIX_7
		,a.MA_HOUSE_NBR_SUFFIX_8 = b.MA_HOUSE_NBR_SUFFIX_8
		,a.MA_STREET_DIRECTION_1 = b.MA_STREET_DIRECTION_1
		,a.MA_STREET_DIRECTION_2 = b.MA_STREET_DIRECTION_2
		,a.MA_STREET_DIRECTION_3 = b.MA_STREET_DIRECTION_3
		,a.MA_STREET_DIRECTION_4 = b.MA_STREET_DIRECTION_4
		,a.MA_STREET_DIRECTION_5 = b.MA_STREET_DIRECTION_5
		,a.MA_STREET_DIRECTION_6 = b.MA_STREET_DIRECTION_6
		,a.MA_STREET_DIRECTION_7 = b.MA_STREET_DIRECTION_7
		,a.MA_STREET_DIRECTION_8 = b.MA_STREET_DIRECTION_8
		,a.MA_STREET_NAME_1 = b.MA_STREET_NAME_1
		,a.MA_STREET_NAME_2 = b.MA_STREET_NAME_2
		,a.MA_STREET_NAME_3 = b.MA_STREET_NAME_3
		,a.MA_STREET_NAME_4 = b.MA_STREET_NAME_4
		,a.MA_STREET_NAME_5 = b.MA_STREET_NAME_5
		,a.MA_STREET_NAME_6 = b.MA_STREET_NAME_6
		,a.MA_STREET_NAME_7 = b.MA_STREET_NAME_7
		,a.MA_STREET_NAME_8 = b.MA_STREET_NAME_8
		,a.MA_MODE_1 = b.MA_MODE_1
		,a.MA_MODE_2 = b.MA_MODE_2
		,a.MA_MODE_3 = b.MA_MODE_3
		,a.MA_MODE_4 = b.MA_MODE_4
		,a.MA_MODE_5 = b.MA_MODE_5
		,a.MA_MODE_6 = b.MA_MODE_6
		,a.MA_MODE_7 = b.MA_MODE_7
		,a.MA_MODE_8 = b.MA_MODE_8
		,a.MA_QUADRANT_1 = b.MA_QUADRANT_1
		,a.MA_QUADRANT_2 = b.MA_QUADRANT_2
		,a.MA_QUADRANT_3 = b.MA_QUADRANT_3
		,a.MA_QUADRANT_4 = b.MA_QUADRANT_4
		,a.MA_QUADRANT_5 = b.MA_QUADRANT_5
		,a.MA_QUADRANT_6 = b.MA_QUADRANT_6
		,a.MA_QUADRANT_7 = b.MA_QUADRANT_7
		,a.MA_QUADRANT_8 = b.MA_QUADRANT_8
		,a.MA_APARTMENT_UNIT_1 = b.MA_APARTMENT_UNIT_1
		,a.MA_APARTMENT_UNIT_2 = b.MA_APARTMENT_UNIT_2
		,a.MA_APARTMENT_UNIT_3 = b.MA_APARTMENT_UNIT_3
		,a.MA_APARTMENT_UNIT_4 = b.MA_APARTMENT_UNIT_4
		,a.MA_APARTMENT_UNIT_5 = b.MA_APARTMENT_UNIT_5
		,a.MA_APARTMENT_UNIT_6 = b.MA_APARTMENT_UNIT_6
		,a.MA_APARTMENT_UNIT_7 = b.MA_APARTMENT_UNIT_7
		,a.MA_APARTMENT_UNIT_8 = b.MA_APARTMENT_UNIT_8
		,a.MA_CITY_1 = b.MA_CITY_1
		,a.MA_CITY_2 = b.MA_CITY_2
		,a.MA_CITY_3 = b.MA_CITY_3
		,a.MA_CITY_4 = b.MA_CITY_4
		,a.MA_CITY_5 = b.MA_CITY_5
		,a.MA_CITY_6 = b.MA_CITY_6
		,a.MA_CITY_7 = b.MA_CITY_7
		,a.MA_CITY_8 = b.MA_CITY_8
		,a.MA_STATE_1 = b.MA_STATE_1
		,a.MA_STATE_2 = b.MA_STATE_2
		,a.MA_STATE_3 = b.MA_STATE_3
		,a.MA_STATE_4 = b.MA_STATE_4
		,a.MA_STATE_5 = b.MA_STATE_5
		,a.MA_STATE_6 = b.MA_STATE_6
		,a.MA_STATE_7 = b.MA_STATE_7
		,a.MA_STATE_8 = b.MA_STATE_8
		,a.MA_ZIP_CODE_1 = b.MA_ZIP_CODE_1
		,a.MA_ZIP_CODE_2 = b.MA_ZIP_CODE_2
		,a.MA_ZIP_CODE_3 = b.MA_ZIP_CODE_3
		,a.MA_ZIP_CODE_4 = b.MA_ZIP_CODE_4
		,a.MA_ZIP_CODE_5 = b.MA_ZIP_CODE_5
		,a.MA_ZIP_CODE_6 = b.MA_ZIP_CODE_6
		,a.MA_ZIP_CODE_7 = b.MA_ZIP_CODE_7
		,a.MA_ZIP_CODE_8 = b.MA_ZIP_CODE_8
		,a.MA_CARRIER_CODE_1 = b.MA_CARRIER_CODE_1
		,a.MA_CARRIER_CODE_2 = b.MA_CARRIER_CODE_2
		,a.MA_CARRIER_CODE_3 = b.MA_CARRIER_CODE_3
		,a.MA_CARRIER_CODE_4 = b.MA_CARRIER_CODE_4
		,a.MA_CARRIER_CODE_5 = b.MA_CARRIER_CODE_5
		,a.MA_CARRIER_CODE_6 = b.MA_CARRIER_CODE_6
		,a.MA_CARRIER_CODE_7 = b.MA_CARRIER_CODE_7
		,a.MA_CARRIER_CODE_8 = b.MA_CARRIER_CODE_8
		,a.MA_ORIGINAL_MAILING_ADDRESS_1 = b.MA_ORIGINAL_MAILING_ADDRESS_1
		,a.MA_ORIGINAL_MAILING_ADDRESS_2 = b.MA_ORIGINAL_MAILING_ADDRESS_2
		,a.MA_ORIGINAL_MAILING_ADDRESS_3 = b.MA_ORIGINAL_MAILING_ADDRESS_3
		,a.MA_ORIGINAL_MAILING_ADDRESS_4 = b.MA_ORIGINAL_MAILING_ADDRESS_4
		,a.MA_ORIGINAL_MAILING_ADDRESS_5 = b.MA_ORIGINAL_MAILING_ADDRESS_5
		,a.MA_ORIGINAL_MAILING_ADDRESS_6 = b.MA_ORIGINAL_MAILING_ADDRESS_6
		,a.MA_ORIGINAL_MAILING_ADDRESS_7 = b.MA_ORIGINAL_MAILING_ADDRESS_7
		,a.MA_ORIGINAL_MAILING_ADDRESS_8 = b.MA_ORIGINAL_MAILING_ADDRESS_8
		,a.MA_DO_NOT_PUBLISH_FLAG_1 = b.MA_DO_NOT_PUBLISH_FLAG_1
		,a.MA_DO_NOT_PUBLISH_FLAG_2 = b.MA_DO_NOT_PUBLISH_FLAG_2
		,a.MA_DO_NOT_PUBLISH_FLAG_3 = b.MA_DO_NOT_PUBLISH_FLAG_3
		,a.MA_DO_NOT_PUBLISH_FLAG_4 = b.MA_DO_NOT_PUBLISH_FLAG_4
		,a.MA_DO_NOT_PUBLISH_FLAG_5 = b.MA_DO_NOT_PUBLISH_FLAG_5
		,a.MA_DO_NOT_PUBLISH_FLAG_6 = b.MA_DO_NOT_PUBLISH_FLAG_6
		,a.MA_DO_NOT_PUBLISH_FLAG_7 = b.MA_DO_NOT_PUBLISH_FLAG_7
		,a.MA_DO_NOT_PUBLISH_FLAG_8 = b.MA_DO_NOT_PUBLISH_FLAG_8
		,a.orig_Mtg_Lender_Name_1 = b.orig_Mtg_Lender_Name_1
		,a.orig_Mtg_Lender_Name_2 = b.orig_Mtg_Lender_Name_2
		,a.orig_Mtg_Lender_Name_3 = b.orig_Mtg_Lender_Name_3
		,a.orig_Mtg_Lender_Name_4 = b.orig_Mtg_Lender_Name_4
		,a.orig_Mtg_Lender_Name_5 = b.orig_Mtg_Lender_Name_5
		,a.orig_Mtg_Lender_Name_6 = b.orig_Mtg_Lender_Name_6
		,a.orig_Mtg_Lender_Name_7 = b.orig_Mtg_Lender_Name_7
		,a.orig_Mtg_Lender_Name_8 = b.orig_Mtg_Lender_Name_8
	FROM [lien_dtdb].[infc].[deed_buyer_names_pivot] a WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			)
	INNER JOIN [lien_dtdb].[lien_dtdb_tmp].[USP_Extract_Names_buyer_parse_names_pivot] b WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			) ON b.doc_id = a.doc_id

	-- seller Name
	/*
- the code extract up to 8 seller names for a document 0 that is 8 nameids that adhere to criteria below

*/
	----------------------------------------------------------------------------------------------------------------------
	-- spanner
	-- select top 100 * from Lien_dtdb.infc.deed_seller_names_pivot
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_seller_names_pivot]
		SELECT m.*
			,m1.*
			,m2.*
		INTO [Lien_dtdb].[infc].[deed_seller_names_pivot]
		FROM (
			SELECT Doc_id
				,max(CASE 
						WHEN ROW4 = 1
							THEN role_type
						ELSE ''
						END) AS role_type_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN role_type
						ELSE ''
						END) AS role_type_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN role_type
						ELSE ''
						END) AS role_type_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN role_type
						ELSE ''
						END) AS role_type_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN role_type
						ELSE ''
						END) AS role_type_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN role_type
						ELSE ''
						END) AS role_type_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN role_type
						ELSE ''
						END) AS role_type_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN role_type
						ELSE ''
						END) AS role_type_8
				--,role_type
				,max(CASE 
						WHEN ROW4 = 1
							THEN Name_id
						ELSE ''
						END) AS Name_id_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN Name_id
						ELSE ''
						END) AS Name_id_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN Name_id
						ELSE ''
						END) AS Name_id_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN Name_id
						ELSE ''
						END) AS Name_id_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN Name_id
						ELSE ''
						END) AS Name_id_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN Name_id
						ELSE ''
						END) AS Name_id_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN Name_id
						ELSE ''
						END) AS Name_id_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN Name_id
						ELSE ''
						END) AS Name_id_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN name_identifier
						ELSE ''
						END) AS name_identifier_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR1_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 2
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR2_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 3
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR3_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 4
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR4_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 5
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR5_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 6
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR6_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 7
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR7_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 8
							THEN CASE 
									WHEN first_name IS NULL
										THEN last_company_name
									ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
									END
						ELSE ''
						END) AS BYR8_OWN_NAME
				,max(CASE 
						WHEN ROW4 = 1
							THEN last_company_name
						ELSE ''
						END) AS BYR1_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 2
							THEN last_company_name
						ELSE ''
						END) AS BYR2_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 3
							THEN last_company_name
						ELSE ''
						END) AS BYR3_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 4
							THEN last_company_name
						ELSE ''
						END) AS BYR4_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 5
							THEN last_company_name
						ELSE ''
						END) AS BYR5_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 6
							THEN last_company_name
						ELSE ''
						END) AS BYR6_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 7
							THEN last_company_name
						ELSE ''
						END) AS BYR7_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 8
							THEN last_company_name
						ELSE ''
						END) AS BYR8_LAST_NAME
				,max(CASE 
						WHEN ROW4 = 1
							THEN first_name
						ELSE ''
						END) AS BYR1_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 2
							THEN first_name
						ELSE ''
						END) AS BYR2_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 3
							THEN first_name
						ELSE ''
						END) AS BYR3_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 4
							THEN first_name
						ELSE ''
						END) AS BYR4_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 5
							THEN first_name
						ELSE ''
						END) AS BYR5_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 6
							THEN first_name
						ELSE ''
						END) AS BYR6_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 7
							THEN first_name
						ELSE ''
						END) AS BYR7_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 8
							THEN first_name
						ELSE ''
						END) AS BYR8_FIRST_NAME
				,max(CASE 
						WHEN ROW4 = 1
							THEN middle_name
						ELSE ''
						END) AS BYR1_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 2
							THEN middle_name
						ELSE ''
						END) AS BYR2_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 3
							THEN middle_name
						ELSE ''
						END) AS BYR3_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 4
							THEN middle_name
						ELSE ''
						END) AS BYR4_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 5
							THEN middle_name
						ELSE ''
						END) AS BYR5_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 6
							THEN middle_name
						ELSE ''
						END) AS BYR6_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 7
							THEN middle_name
						ELSE ''
						END) AS BYR7_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 8
							THEN middle_name
						ELSE ''
						END) AS BYR8_MIDDLE_INITIAL
				,max(CASE 
						WHEN ROW4 = 1
							THEN suffix
						ELSE ''
						END) AS BYR1_SUFFIX
				,max(CASE 
						WHEN ROW4 = 2
							THEN suffix
						ELSE ''
						END) AS BYR2_SUFFIX
				,max(CASE 
						WHEN ROW4 = 3
							THEN suffix
						ELSE ''
						END) AS BYR3_SUFFIX
				,max(CASE 
						WHEN ROW4 = 4
							THEN suffix
						ELSE ''
						END) AS BYR4_SUFFIX
				,max(CASE 
						WHEN ROW4 = 5
							THEN suffix
						ELSE ''
						END) AS BYR5_SUFFIX
				,max(CASE 
						WHEN ROW4 = 6
							THEN suffix
						ELSE ''
						END) AS BYR6_SUFFIX
				,max(CASE 
						WHEN ROW4 = 7
							THEN suffix
						ELSE ''
						END) AS BYR7_SUFFIX
				,max(CASE 
						WHEN ROW4 = 8
							THEN suffix
						ELSE ''
						END) AS BYR8_SUFFIX
				,max(CASE 
						WHEN ROW4 = 1
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN party_type_code
						ELSE ''
						END) AS party_type_code_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN relationship_code
						ELSE ''
						END) AS BYR1_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 2
							THEN relationship_code
						ELSE ''
						END) AS BYR2_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 3
							THEN relationship_code
						ELSE ''
						END) AS BYR3_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 4
							THEN relationship_code
						ELSE ''
						END) AS BYR4_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 5
							THEN relationship_code
						ELSE ''
						END) AS BYR5_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 6
							THEN relationship_code
						ELSE ''
						END) AS BYR6_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 7
							THEN relationship_code
						ELSE ''
						END) AS BYR7_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 8
							THEN relationship_code
						ELSE ''
						END) AS BYR8_OWN_RELATIONSHIP_TYPE
				,max(CASE 
						WHEN ROW4 = 1
							THEN vesting_code
						ELSE ''
						END) AS BYR1_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 2
							THEN vesting_code
						ELSE ''
						END) AS BYR2_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 3
							THEN vesting_code
						ELSE ''
						END) AS BYR3_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 4
							THEN vesting_code
						ELSE ''
						END) AS BYR4_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 5
							THEN vesting_code
						ELSE ''
						END) AS BYR5_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 6
							THEN vesting_code
						ELSE ''
						END) AS BYR6_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 7
							THEN vesting_code
						ELSE ''
						END) AS BYR7_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 8
							THEN vesting_code
						ELSE ''
						END) AS BYR8_OWNERSHIP_RIGHTS_CODE
				,max(CASE 
						WHEN ROW4 = 1
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN percent_transferred
						ELSE ''
						END) AS percent_transferred_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN address_same_as_property_address_flag
						ELSE ''
						END) AS address_same_as_property_address_flag_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_HOUSE_NBR_PREFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_PREFIX_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_HOUSE_NBR
						ELSE ''
						END) AS MA_HOUSE_NBR_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_HOUSE_NBR_SUFFIX
						ELSE ''
						END) AS MA_HOUSE_NBR_SUFFIX_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_STREET_DIRECTION
						ELSE ''
						END) AS MA_STREET_DIRECTION_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_STREET_NAME
						ELSE ''
						END) AS MA_STREET_NAME_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_MODE
						ELSE ''
						END) AS MA_MODE_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_QUADRANT
						ELSE ''
						END) AS MA_QUADRANT_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_APARTMENT_UNIT
						ELSE ''
						END) AS MA_APARTMENT_UNIT_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_CITY
						ELSE ''
						END) AS MA_CITY_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_STATE
						ELSE ''
						END) AS MA_STATE_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_ZIP_CODE
						ELSE ''
						END) AS MA_ZIP_CODE_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_CARRIER_CODE
						ELSE ''
						END) AS MA_CARRIER_CODE_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_ORIGINAL_MAILING_ADDRESS
						ELSE ''
						END) AS MA_ORIGINAL_MAILING_ADDRESS_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN MA_DO_NOT_PUBLISH_FLAG
						ELSE ''
						END) AS MA_DO_NOT_PUBLISH_FLAG_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN orig_Mtg_Lender_Name
						ELSE ''
						END) AS orig_Mtg_Lender_Name_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN address
						ELSE ''
						END) AS address_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN address
						ELSE ''
						END) AS address_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN address
						ELSE ''
						END) AS address_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN address
						ELSE ''
						END) AS address_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN address
						ELSE ''
						END) AS address_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN address
						ELSE ''
						END) AS address_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN address
						ELSE ''
						END) AS address_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN address
						ELSE ''
						END) AS address_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN address_city_name
						ELSE ''
						END) AS address_city_name_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN address_state_name
						ELSE ''
						END) AS address_state_name_8
				,max(CASE 
						WHEN ROW4 = 1
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_1
				,max(CASE 
						WHEN ROW4 = 2
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_2
				,max(CASE 
						WHEN ROW4 = 3
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_3
				,max(CASE 
						WHEN ROW4 = 4
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_4
				,max(CASE 
						WHEN ROW4 = 5
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_5
				,max(CASE 
						WHEN ROW4 = 6
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_6
				,max(CASE 
						WHEN ROW4 = 7
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_7
				,max(CASE 
						WHEN ROW4 = 8
							THEN address_zip_code
						ELSE ''
						END) AS address_zip_code_8
			FROM (
				SELECT a.Doc_id
					,role_type
					--,ROW_NUMBER() OVER (
					--	PARTITION BY a.doc_id ORDER BY a._Parse_seq
					--		--a.name_identifier
					--		--,cast(sequence_number AS INT)
					--	) AS ROW4
					,ROW_NUMBER() OVER (
						PARTITION BY doc_id ORDER BY CASE 
								WHEN party_type_code = 'AKA'
									AND a.name_identifier = 'c'
									THEN 1
								ELSE _Parse_seq + 100
								END
						) AS ROW4
					,a.Name_id
					,a.doc_unique_id
					,a.sequence_number
					,ltrim(rtrim(isnull(a.name_identifier, ''))) AS name_identifier
					,ltrim(rtrim(isnull(a.last_company_name, ''))) AS last_company_name
					,ltrim(rtrim(isnull(a.first_name, ''))) AS first_name
					,ltrim(rtrim(isnull(a.middle_name, ''))) AS middle_name
					,ltrim(rtrim(isnull(a.suffix, ''))) AS suffix
					,ltrim(rtrim(isnull(a.party_type_code, ''))) AS party_type_code
					,ltrim(rtrim(isnull(a.relationship_code, ''))) AS relationship_code
					,ltrim(rtrim(isnull(a.vesting_code, ''))) AS vesting_code
					,ltrim(rtrim(isnull(a.percent_transferred, ''))) AS percent_transferred
					,ltrim(rtrim(isnull(a.address_same_as_property_address_flag, ''))) AS address_same_as_property_address_flag
					,ltrim(rtrim(isnull(na.Direction, ''))) AS MA_HOUSE_NBR_PREFIX
					,ltrim(rtrim(isnull(na.HouseNumber, ''))) AS MA_HOUSE_NBR
					,ltrim(rtrim(isnull(na.Post_Direction, ''))) AS MA_HOUSE_NBR_SUFFIX
					,ltrim(rtrim(isnull(na.Post_Direction, ''))) AS MA_STREET_DIRECTION
					,ltrim(rtrim(isnull(na.Street_Name, ''))) AS MA_STREET_NAME
					,ltrim(rtrim(isnull(na.Street_Type, ''))) AS MA_MODE
					,'' AS MA_QUADRANT
					,ltrim(rtrim(isnull(na.Unit, ''))) AS MA_APARTMENT_UNIT
					,ltrim(rtrim(isnull(na.City, ''))) AS MA_CITY
					,ltrim(rtrim(isnull(na.STATE, ''))) AS MA_STATE
					,ltrim(rtrim(isnull(na.Zip, ''))) + ltrim(rtrim(isnull(na.Plus4, ''))) AS MA_ZIP_CODE
					,ltrim(rtrim(isnull(na.CRRT, ''))) AS MA_CARRIER_CODE
					--,REplace(a.address + ltrim(rtrim(isnull(a.address_city_name, '') + ', ' + ltrim(rtrim(isnull(address_state_name, '') + ', ' + ltrim(rtrim(isnull(address_zip_code, ''), ' ', '') AS MA_ORIGINAL_MAILING_ADDRESS
					--,ltrim(rtrim(isnull(a.address, ''))) AS MA_ORIGINAL_MAILING_ADDRESS
					,ltrim(rtrim(CASE 
								WHEN CHARINDEX('|', a.address) > 0
									THEN LEFT(a.address, CHARINDEX('|', a.address) - 1)
								ELSE ISNULL(a.address, '')
								END)) AS MA_ORIGINAL_MAILING_ADDRESS
					,'' AS MA_DO_NOT_PUBLISH_FLAG
					,ltrim(rtrim(isnull(a.orig_Mtg_Lender_Name, ''))) AS orig_Mtg_Lender_Name
					,ltrim(rtrim(isnull(a.address, ''))) AS address
					,ltrim(rtrim(isnull(a.address_city_name, ''))) AS address_city_name
					,ltrim(rtrim(isnull(a.address_state_name, ''))) AS address_state_name
					,ltrim(rtrim(isnull(a.address_zip_code, ''))) AS address_zip_code
				FROM [Lien_dtdb].[infc].[deed_seller_names] a
				OUTER APPLY (
					SELECT *
					FROM [lien].[ur].[NAME_STD_ADDRESS] na
					WHERE na.Name_id = a.Name_id
					) na
				--WHERE doc_id in (164025098, 163873593, 114683143, 163924302, 164025303, 164025311, 163900605, 164025417, 102846629)
				WHERE (
						isnull(a.party_type_code, '') <> 'AKA'
						OR (
							isnull(a.party_type_code, '') = 'AKA'
							AND a.dba_aka_sort_seq = 1
							)
						)
				) a
			GROUP BY a.doc_id
			) m
		OUTER APPLY (
			SELECT replace(CASE 
						WHEN (
								role_type_1 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_1 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_1 = 'I'
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_2 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_2 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_2 = 'I'
							THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_3 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_3 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_3 = 'I'
							THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_4 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_4 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_4 = 'I'
							THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_5 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_5 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_5 = 'I'
							THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_6 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_6 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_6 = 'I'
							THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_7 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_7 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_7 = 'I'
							THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_8 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_8 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_8 = 'I'
							THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL + ' LE'
						WHEN (
								role_type_1 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_1 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_1 IN (
								'C'
								,'T'
								)
							THEN m.BYR1_LAST_NAME + ' LE'
						WHEN (
								role_type_2 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_2 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_2 IN (
								'C'
								,'T'
								)
							THEN m.BYR2_LAST_NAME + ' LE'
						WHEN (
								role_type_3 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_3 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_3 IN (
								'C'
								,'T'
								)
							THEN m.BYR3_LAST_NAME + ' LE'
						WHEN (
								role_type_4 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_4 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_4 IN (
								'C'
								,'T'
								)
							THEN m.BYR4_LAST_NAME + ' LE'
						WHEN (
								role_type_5 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_5 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_5 IN (
								'C'
								,'T'
								)
							THEN m.BYR5_LAST_NAME + ' LE'
						WHEN (
								role_type_6 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_6 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_6 IN (
								'C'
								,'T'
								)
							THEN m.BYR6_LAST_NAME + ' LE'
						WHEN (
								role_type_7 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_7 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_7 IN (
								'C'
								,'T'
								)
							THEN m.BYR7_LAST_NAME + ' LE'
						WHEN (
								role_type_8 = 'PARTY RECEIVING LIFE ESTATE'
								OR party_type_code_8 IN (
									'LFE'
									,'LFR'
									)
								)
							AND name_identifier_8 IN (
								'C'
								,'T'
								)
							THEN m.BYR8_LAST_NAME + ' LE'
						WHEN name_identifier_1 = 'T'
							THEN m.BYR1_LAST_NAME
						WHEN name_identifier_2 = 'T'
							THEN m.BYR2_LAST_NAME
						WHEN name_identifier_3 = 'T'
							THEN m.BYR3_LAST_NAME
						WHEN name_identifier_4 = 'T'
							THEN m.BYR4_LAST_NAME
						WHEN name_identifier_5 = 'T'
							THEN m.BYR5_LAST_NAME
						WHEN name_identifier_6 = 'T'
							THEN m.BYR6_LAST_NAME
						WHEN name_identifier_7 = 'T'
							THEN m.BYR7_LAST_NAME
						WHEN name_identifier_8 = 'T'
							THEN m.BYR8_LAST_NAME
						WHEN name_identifier_1 = 'I'
							AND party_type_code_1 IN ('TRS')
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL
						WHEN name_identifier_2 = 'I'
							AND party_type_code_2 IN ('TRS')
							THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL
						WHEN name_identifier_3 = 'I'
							AND party_type_code_3 IN ('TRS')
							THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL
						WHEN name_identifier_4 = 'I'
							AND party_type_code_4 IN ('TRS')
							THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL
						WHEN name_identifier_5 = 'I'
							AND party_type_code_5 IN ('TRS')
							THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
						WHEN name_identifier_6 = 'I'
							AND party_type_code_6 IN ('TRS')
							THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
						WHEN name_identifier_7 = 'I'
							AND party_type_code_7 IN ('TRS')
							THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
						WHEN name_identifier_8 = 'I'
							AND party_type_code_8 IN ('TRS')
							THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
						WHEN name_identifier_1 = 'I'
							AND party_type_code_1 IN ('EST')
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_2 = 'I'
							AND party_type_code_2 IN ('EST')
							THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_3 = 'I'
							AND party_type_code_3 IN ('EST')
							THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_4 = 'I'
							AND party_type_code_4 IN ('EST')
							THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_5 = 'I'
							AND party_type_code_5 IN ('EST')
							THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_6 = 'I'
							AND party_type_code_6 IN ('EST')
							THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_7 = 'I'
							AND party_type_code_7 IN ('EST')
							THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_8 = 'I'
							AND party_type_code_8 IN ('EST')
							THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL + ' EST'
						WHEN name_identifier_1 IN (
								'C'
								,'T'
								)
							AND party_type_code_1 IN ('EST')
							THEN m.BYR1_LAST_NAME + ' EST'
						WHEN name_identifier_2 IN (
								'C'
								,'T'
								)
							AND party_type_code_2 IN ('EST')
							THEN m.BYR2_LAST_NAME + ' EST'
						WHEN name_identifier_3 IN (
								'C'
								,'T'
								)
							AND party_type_code_3 IN ('EST')
							THEN m.BYR3_LAST_NAME + ' EST'
						WHEN name_identifier_4 IN (
								'C'
								,'T'
								)
							AND party_type_code_4 IN ('EST')
							THEN m.BYR4_LAST_NAME + ' EST'
						WHEN name_identifier_5 IN (
								'C'
								,'T'
								)
							AND party_type_code_5 IN ('EST')
							THEN m.BYR5_LAST_NAME + ' EST'
						WHEN name_identifier_6 IN (
								'C'
								,'T'
								)
							AND party_type_code_6 IN ('EST')
							THEN m.BYR6_LAST_NAME + ' EST'
						WHEN name_identifier_7 IN (
								'C'
								,'T'
								)
							AND party_type_code_7 IN ('EST')
							THEN m.BYR7_LAST_NAME + ' EST'
						WHEN name_identifier_8 IN (
								'C'
								,'T'
								)
							AND party_type_code_8 IN ('EST')
							THEN m.BYR8_LAST_NAME + ' EST'
						WHEN name_identifier_1 = 'C'
							AND (
								party_type_code_1 != 'CO'
								OR party_type_code_1 = ''
								)
							AND name_identifier_2 = 'C'
							AND party_type_code_2 = 'AKA'
							THEN m.BYR2_LAST_NAME
						WHEN name_identifier_1 = 'C'
							AND (
								party_type_code_1 != 'CO'
								OR party_type_code_1 = ''
								)
							THEN m.BYR1_LAST_NAME
						WHEN m.name_identifier_1 = 'I'
							AND (
								party_type_code_1 = 'SPS'
								OR party_type_code_2 = 'SPS'
								)
							AND (
								m.BYR2_LAST_NAME <> ''
								OR LEN(LTRIM(RTRIM(m.BYR2_LAST_NAME))) > 0
								)
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL + ' & ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL + ' ' + m.BYR2_SUFFIX
						WHEN m.name_identifier_1 = 'I'
							AND (
								party_type_code_1 = 'SPS'
								OR party_type_code_2 = 'SPS'
								)
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL
						WHEN m.name_identifier_1 = 'I'
							AND (
								party_type_code_1 <> 'SPS'
								OR party_type_code_1 = ''
								)
							THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL
						ELSE 'UNKNOWN'
						END, '  ', ' ') AS SELLER_NAME_PLAINTIFF_1
				,CASE 
					WHEN (
							role_type_1 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_1 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_1 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_2 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_2 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_2 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_3 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_3 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_3 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_4 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_4 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_4 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_5 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_5 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_5 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_6 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_6 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_6 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_7 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_7 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_7 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN (
							role_type_8 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_8 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_8 IN (
							'C'
							,'T'
							)
						THEN 'Y'
							--WHEN name_identifier_1 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_2 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_3 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_4 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_5 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_6 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_7 IN ('T')
							--	THEN 'Y'
							--WHEN name_identifier_8 IN ('T')
							--	THEN 'Y'
					WHEN party_type_code_1 = 'EST'
						AND name_identifier_1 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_2 = 'EST'
						AND name_identifier_2 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_3 = 'EST'
						AND name_identifier_3 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_4 = 'EST'
						AND name_identifier_4 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_5 = 'EST'
						AND name_identifier_5 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_6 = 'EST'
						AND name_identifier_6 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_7 = 'EST'
						AND name_identifier_7 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
					WHEN party_type_code_8 = 'EST'
						AND name_identifier_8 IN (
							'C'
							--,'T'
							)
						THEN 'Y'
							-- this is not needed becasue of next line when name_identifier_1 in ('C') and  (party_type_code_1 != 'CO' OR ISNULL(party_type_code_1,'') ='') and name_identifier_1 in ('C') and party_type_code_2 = 'AKA' then 'Y'
					WHEN name_identifier_1 IN ('C')
						AND (
							party_type_code_1 != 'CO'
							OR party_type_code_1 = ''
							)
						THEN 'Y'
					WHEN name_identifier_1 IN (
							'C'
							--,'T'
							)
						AND party_type_code_1 = 'FBO'
						THEN 'Y'
					ELSE NULL
					END AS SELLER_NAME_PLAINTIFF1_CORP_IND
				,CASE 
					WHEN (
							role_type_1 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_1 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_1 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '1ILFE'
					WHEN (
							role_type_2 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_2 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_2 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '2ILFE'
					WHEN (
							role_type_3 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_3 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_3 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '3ILFE'
					WHEN (
							role_type_4 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_4 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_4 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '4ILFE'
					WHEN (
							role_type_5 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_5 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_5 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '5ILFE'
					WHEN (
							role_type_6 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_6 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_6 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '6ILFE'
					WHEN (
							role_type_7 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_7 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_7 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '7ILFE'
					WHEN (
							role_type_8 = 'PARTY RECEIVING LIFE ESTATE'
							OR party_type_code_8 IN (
								'LFE'
								,'LFR'
								)
							)
						AND name_identifier_8 IN (
							'I'
							,'C'
							,'T'
							)
						THEN '8ILFE'
					WHEN name_identifier_1 IN ('T')
						THEN '1PT'
					WHEN name_identifier_2 IN ('T')
						THEN '2PT'
					WHEN name_identifier_3 IN ('T')
						THEN '3PT'
					WHEN name_identifier_4 IN ('T')
						THEN '4PT'
					WHEN name_identifier_5 IN ('T')
						THEN '5PT'
					WHEN name_identifier_6 IN ('T')
						THEN '6PT'
					WHEN name_identifier_7 IN ('T')
						THEN '7PT'
					WHEN name_identifier_8 IN ('T')
						THEN '8PT'
					WHEN name_identifier_1 IN ('I')
						AND party_type_code_1 = 'TRS'
						THEN '1TRS'
					WHEN name_identifier_2 IN ('I')
						AND party_type_code_2 = 'TRS'
						THEN '2TRS'
					WHEN name_identifier_3 IN ('I')
						AND party_type_code_3 = 'TRS'
						THEN '3TRS'
					WHEN name_identifier_4 IN ('I')
						AND party_type_code_4 = 'TRS'
						THEN '4TRS'
					WHEN name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN '5TRS'
					WHEN name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN '6TRS'
					WHEN name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN '7TRS'
					WHEN name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN '8TRS'
					WHEN name_identifier_1 IN ('I')
						AND party_type_code_1 = 'EST'
						THEN '1IEST'
					WHEN name_identifier_2 IN ('I')
						AND party_type_code_2 = 'EST'
						THEN '2IEST'
					WHEN name_identifier_3 IN ('I')
						AND party_type_code_3 = 'EST'
						THEN '3IEST'
					WHEN name_identifier_4 IN ('I')
						AND party_type_code_4 = 'EST'
						THEN '4IEST'
					WHEN name_identifier_5 IN ('I')
						AND party_type_code_5 = 'EST'
						THEN '5IEST'
					WHEN name_identifier_6 IN ('I')
						AND party_type_code_6 = 'EST'
						THEN '6IEST'
					WHEN name_identifier_7 IN ('I')
						AND party_type_code_7 = 'EST'
						THEN '7IEST'
					WHEN name_identifier_8 IN ('I')
						AND party_type_code_8 = 'EST'
						THEN '8IEST'
					WHEN name_identifier_1 IN ('C')
						AND party_type_code_1 = 'EST'
						THEN '1CEST'
					WHEN name_identifier_2 IN ('C')
						AND party_type_code_2 = 'EST'
						THEN '2CEST'
					WHEN name_identifier_3 IN ('C')
						AND party_type_code_3 = 'EST'
						THEN '3CEST'
					WHEN name_identifier_4 IN ('C')
						AND party_type_code_4 = 'EST'
						THEN '4CEST'
					WHEN name_identifier_5 IN ('C')
						AND party_type_code_5 = 'EST'
						THEN '5CEST'
					WHEN name_identifier_6 IN ('C')
						AND party_type_code_6 = 'EST'
						THEN '6CEST'
					WHEN name_identifier_7 IN ('C')
						AND party_type_code_7 = 'EST'
						THEN '7CEST'
					WHEN name_identifier_8 IN ('C')
						AND party_type_code_8 = 'EST'
						THEN '8CEST'
					WHEN name_identifier_1 IN ('T')
						AND party_type_code_1 = 'EST'
						THEN '1TEST'
					WHEN name_identifier_2 IN ('T')
						AND party_type_code_2 = 'EST'
						THEN '2TEST'
					WHEN name_identifier_3 IN ('T')
						AND party_type_code_3 = 'EST'
						THEN '3TEST'
					WHEN name_identifier_4 IN ('T')
						AND party_type_code_4 = 'EST'
						THEN '4TEST'
					WHEN name_identifier_5 IN ('T')
						AND party_type_code_5 = 'EST'
						THEN '5TEST'
					WHEN name_identifier_6 IN ('T')
						AND party_type_code_6 = 'EST'
						THEN '6TEST'
					WHEN name_identifier_7 IN ('T')
						AND party_type_code_7 = 'EST'
						THEN '7TEST'
					WHEN name_identifier_8 IN ('T')
						AND party_type_code_8 = 'EST'
						THEN '8TEST'
					WHEN name_identifier_1 = 'C'
						AND (
							party_type_code_1 != 'CO'
							OR party_type_code_1 = ''
							)
						AND name_identifier_2 = 'C'
						AND party_type_code_2 = 'AKA'
						THEN '2AKA'
					WHEN name_identifier_1 = 'C'
						AND (
							party_type_code_1 != 'CO'
							OR party_type_code_1 = ''
							)
						THEN '1C'
					WHEN m.name_identifier_1 = 'I'
						AND (
							party_type_code_1 = 'SPS'
							OR party_type_code_2 = 'SPS'
							)
						AND (
							m.BYR2_LAST_NAME <> ''
							OR LEN(m.BYR2_LAST_NAME) > 0
							)
						THEN '12I'
					WHEN m.name_identifier_1 = 'I'
						AND (
							party_type_code_1 = 'SPS'
							OR party_type_code_2 = 'SPS'
							)
						THEN '1I'
					WHEN m.name_identifier_1 = 'I'
						AND (
							party_type_code_1 <> 'SPS'
							OR party_type_code_1 = ''
							)
						THEN '1I'
					ELSE ''
					END AS v_SELLER_NAME_PLAINTIFF_1_Flag
				-- informatica isnull example
				--this  ISNULL(last_company_name_S2_I_Seller)=0 OR LENGTH(LTRIM(RTRIM(last_company_name_S2_I_Seller))
				--become this isnull(last_company_name_S2_I_Seller,'') <> '' or len(last_company_name_S2_I_Seller) > 0)
			) m1
		OUTER APPLY (
			SELECT CASE 
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR2_LAST_NAME) > 0)
						THEN m.BYR2_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR3_LAST_NAME) > 0)
						THEN m.BYR3_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR4_LAST_NAME) > 0)
						THEN m.BYR4_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR5_LAST_NAME) > 0)
						THEN m.BYR5_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR6_LAST_NAME) > 0)
						THEN m.BYR6_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR3_LAST_NAME) > 0)
						THEN m.BYR3_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR4_LAST_NAME) > 0)
						THEN m.BYR4_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR5_LAST_NAME) > 0)
						THEN m.BYR5_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR6_LAST_NAME) > 0)
						THEN m.BYR6_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND (LEN(m.BYR4_LAST_NAME) > 0)
						THEN m.BYR4_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND (LEN(m.BYR5_LAST_NAME) > 0)
						THEN m.BYR5_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND (LEN(m.BYR6_LAST_NAME) > 0)
						THEN m.BYR6_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND (LEN(m.BYR5_LAST_NAME) > 0)
						THEN m.BYR5_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND (LEN(m.BYR6_LAST_NAME) > 0)
						THEN m.BYR6_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND (LEN(m.BYR6_LAST_NAME) > 0)
						THEN m.BYR6_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '6PT'
						AND (LEN(m.BYR7_LAST_NAME) > 0)
						THEN m.BYR7_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '6PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '7PT'
						AND (LEN(m.BYR8_LAST_NAME) > 0)
						THEN m.BYR8_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_1 IN ('I')
						AND party_type_code_1 = 'TRS'
						THEN m.BYR1_LAST_NAME + ' ' + m.BYR1_SUFFIX + ' ' + m.BYR1_FIRST_NAME + ' ' + m.BYR1_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_2 IN ('I')
						AND party_type_code_2 = 'TRS'
						THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_3 IN ('I')
						AND party_type_code_3 = 'TRS'
						THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_4 IN ('I')
						AND party_type_code_4 = 'TRS'
						THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							)
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_2 IN ('I')
						AND party_type_code_2 = 'TRS'
						THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_3 IN ('I')
						AND party_type_code_3 = 'TRS'
						THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_4 IN ('I')
						AND party_type_code_4 = 'TRS'
						THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('1TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_3 IN ('I')
						AND party_type_code_3 = 'TRS'
						THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_4 IN ('I')
						AND party_type_code_4 = 'TRS'
						THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('2TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('3TRS')
						AND name_identifier_4 IN ('I')
						AND party_type_code_4 = 'TRS'
						THEN m.BYR4_LAST_NAME + ' ' + m.BYR4_SUFFIX + ' ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('3TRS')
						AND name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('3TRS')
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('3TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('3TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('4TRS')
						AND name_identifier_5 IN ('I')
						AND party_type_code_5 = 'TRS'
						THEN m.BYR5_LAST_NAME + ' ' + m.BYR5_SUFFIX + ' ' + m.BYR5_FIRST_NAME + ' ' + m.BYR5_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('4TRS')
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('4TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('4TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('5TRS')
						AND name_identifier_6 IN ('I')
						AND party_type_code_6 = 'TRS'
						THEN m.BYR6_LAST_NAME + ' ' + m.BYR6_SUFFIX + ' ' + m.BYR6_FIRST_NAME + ' ' + m.BYR6_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('5TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('5TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('6TRS')
						AND name_identifier_7 IN ('I')
						AND party_type_code_7 = 'TRS'
						THEN m.BYR7_LAST_NAME + ' ' + m.BYR7_SUFFIX + ' ' + m.BYR7_FIRST_NAME + ' ' + m.BYR7_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('6TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN ('7TRS')
						AND name_identifier_8 IN ('I')
						AND party_type_code_8 = 'TRS'
						THEN m.BYR8_LAST_NAME + ' ' + m.BYR8_SUFFIX + ' ' + m.BYR8_FIRST_NAME + ' ' + m.BYR8_MIDDLE_INITIAL
					WHEN name_identifier_1 = 'C'
						AND (
							party_type_code_1 != 'CO'
							OR party_type_code_1 = ''
							)
						AND name_identifier_2 = 'C'
						AND party_type_code_2 = 'AKA'
						THEN '2AKA'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1C'
							,'1T'
							,'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							,'1TRS'
							,'2TRS'
							,'3TRS'
							,'4TRS'
							,'5TRS'
							,'6TRS'
							,'7TRS'
							,'8TRS'
							,'1ILFE'
							,'2ILFE'
							,'3ILFE'
							,'4ILFE'
							,'5ILFE'
							,'6ILFE'
							,'7ILFE'
							,'8ILFE'
							,'1CLFE'
							,'2CLFE'
							,'3CLFE'
							,'4CLFE'
							,'5CLFE'
							,'6CLFE'
							,'7CLFE'
							,'8CLFE'
							,'1TLFE'
							,'2TLFE'
							,'3TLFE'
							,'4TLFE'
							,'5TLFE'
							,'6TLFE'
							,'7TLFE'
							,'8TLFE'
							,'1IEST'
							,'2IEST'
							,'3IEST'
							,'4IEST'
							,'5IEST'
							,'6IEST'
							,'7IEST'
							,'8IEST'
							,'1CEST'
							,'2CEST'
							,'3CEST'
							,'4CEST'
							,'5CEST'
							,'6CEST'
							,'7CEST'
							,'8CEST'
							,'1TEST'
							,'2TEST'
							,'3TEST'
							,'4TEST'
							,'5TEST'
							,'6TEST'
							,'7TEST'
							,'8TEST'
							)
						AND name_identifier_2 IN ('C')
						AND (
							party_type_code_2 != 'CO'
							OR party_type_code_2 = ''
							)
						THEN m.BYR2_LAST_NAME
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'12I'
							,'2AKA'
							,'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							,'1TRS'
							,'2TRS'
							,'3TRS'
							,'4TRS'
							,'5TRS'
							,'6TRS'
							,'7TRS'
							,'8TRS'
							,'1ILFE'
							,'2ILFE'
							,'3ILFE'
							,'4ILFE'
							,'5ILFE'
							,'6ILFE'
							,'7ILFE'
							,'8ILFE'
							,'1CLFE'
							,'2CLFE'
							,'3CLFE'
							,'4CLFE'
							,'5CLFE'
							,'6CLFE'
							,'7CLFE'
							,'8CLFE'
							,'1TLFE'
							,'2TLFE'
							,'3TLFE'
							,'4TLFE'
							,'5TLFE'
							,'6TLFE'
							,'7TLFE'
							,'8TLFE'
							,'1IEST'
							,'2IEST'
							,'3IEST'
							,'4IEST'
							,'5IEST'
							,'6IEST'
							,'7IEST'
							,'8IEST'
							,'1CEST'
							,'2CEST'
							,'3CEST'
							,'4CEST'
							,'5CEST'
							,'6CEST'
							,'7CEST'
							,'8CEST'
							,'1TEST'
							,'2TEST'
							,'3TEST'
							,'4TEST'
							,'5TEST'
							,'6TEST'
							,'7TEST'
							,'8TEST'
							)
						AND name_identifier_1 IN ('I')
						AND (
							party_type_code_1 = 'SPS'
							OR party_type_code_2 = 'SPS'
							)
						AND name_identifier_3 IN ('I')
						AND (
							party_type_code_3 = 'SPS'
							OR party_type_code_4 = 'SPS'
							)
						AND (m.BYR4_LAST_NAME > '')
						THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL + ' & ' + m.BYR4_FIRST_NAME + ' ' + m.BYR4_MIDDLE_INITIAL + ' ' + m.BYR4_SUFFIX
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'12I'
							,'2AKA'
							,'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							,'1TRS'
							,'2TRS'
							,'3TRS'
							,'4TRS'
							,'5TRS'
							,'6TRS'
							,'7TRS'
							,'8TRS'
							,'1ILFE'
							,'2ILFE'
							,'3ILFE'
							,'4ILFE'
							,'5ILFE'
							,'6ILFE'
							,'7ILFE'
							,'8ILFE'
							,'1CLFE'
							,'2CLFE'
							,'3CLFE'
							,'4CLFE'
							,'5CLFE'
							,'6CLFE'
							,'7CLFE'
							,'8CLFE'
							,'1TLFE'
							,'2TLFE'
							,'3TLFE'
							,'4TLFE'
							,'5TLFE'
							,'6TLFE'
							,'7TLFE'
							,'8TLFE'
							,'1IEST'
							,'2IEST'
							,'3IEST'
							,'4IEST'
							,'5IEST'
							,'6IEST'
							,'7IEST'
							,'8IEST'
							,'1CEST'
							,'2CEST'
							,'3CEST'
							,'4CEST'
							,'5CEST'
							,'6CEST'
							,'7CEST'
							,'8CEST'
							,'1TEST'
							,'2TEST'
							,'3TEST'
							,'4TEST'
							,'5TEST'
							,'6TEST'
							,'7TEST'
							,'8TEST'
							)
						AND name_identifier_1 IN ('I')
						AND (
							party_type_code_1 = 'SPS'
							OR party_type_code_2 = 'SPS'
							)
						AND name_identifier_3 IN ('I')
						AND (
							party_type_code_3 = 'SPS'
							OR party_type_code_4 = 'SPS'
							)
						AND (m.BYR3_LAST_NAME > '')
						THEN m.BYR3_LAST_NAME + ' ' + m.BYR3_SUFFIX + ' ' + m.BYR3_FIRST_NAME + ' ' + m.BYR3_MIDDLE_INITIAL
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1I'
							,'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							,'1TRS'
							,'2TRS'
							,'3TRS'
							,'4TRS'
							,'5TRS'
							,'6TRS'
							,'7TRS'
							,'8TRS'
							,'1ILFE'
							,'2ILFE'
							,'3ILFE'
							,'4ILFE'
							,'5ILFE'
							,'6ILFE'
							,'7ILFE'
							,'8ILFE'
							,'1CLFE'
							,'2CLFE'
							,'3CLFE'
							,'4CLFE'
							,'5CLFE'
							,'6CLFE'
							,'7CLFE'
							,'8CLFE'
							,'1TLFE'
							,'2TLFE'
							,'3TLFE'
							,'4TLFE'
							,'5TLFE'
							,'6TLFE'
							,'7TLFE'
							,'8TLFE'
							,'1IEST'
							,'2IEST'
							,'3IEST'
							,'4IEST'
							,'5IEST'
							,'6IEST'
							,'7IEST'
							,'8IEST'
							,'1CEST'
							,'2CEST'
							,'3CEST'
							,'4CEST'
							,'5CEST'
							,'6CEST'
							,'7CEST'
							,'8CEST'
							,'1TEST'
							,'2TEST'
							,'3TEST'
							,'4TEST'
							,'5TEST'
							,'6TEST'
							,'7TEST'
							,'8TEST'
							)
						AND name_identifier_1 IN ('I')
						AND (
							party_type_code_1 <> 'SPS'
							OR party_type_code_1 = ''
							)
						AND name_identifier_2 IN ('I')
						AND (
							party_type_code_2 <> 'SPS'
							OR party_type_code_2 = ''
							)
						THEN m.BYR2_LAST_NAME + ' ' + m.BYR2_SUFFIX + ' ' + m.BYR2_FIRST_NAME + ' ' + m.BYR2_MIDDLE_INITIAL
					ELSE ''
					END AS SELLER_NAME_PLAINTIFF_2
				,CASE 
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR2_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR3_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR4_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR5_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR6_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '1PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR3_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR4_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR5_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR6_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '2PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR4_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR5_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR6_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '3PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR5_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR6_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '4PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR6_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '5PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '6PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR7_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '6PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag = '7PT'
						AND name_identifier_2 IN ('T')
						AND m.BYR8_LAST_NAME = ''
						THEN 'Y'
					WHEN m1.v_SELLER_NAME_PLAINTIFF_1_Flag IN (
							'1C'
							,'1T'
							,'1PT'
							,'2PT'
							,'3PT'
							,'4PT'
							,'5PT'
							,'6PT'
							,'7PT'
							,'8PT'
							,'1TRS'
							,'2TRS'
							,'3TRS'
							,'4TRS'
							,'5TRS'
							,'6TRS'
							,'7TRS'
							,'8TRS'
							,'1ILFE'
							,'2ILFE'
							,'3ILFE'
							,'4ILFE'
							,'5ILFE'
							,'6ILFE'
							,'7ILFE'
							,'8ILFE'
							,'1CLFE'
							,'2CLFE'
							,'3CLFE'
							,'4CLFE'
							,'5CLFE'
							,'6CLFE'
							,'7CLFE'
							,'8CLFE'
							,'1TLFE'
							,'2TLFE'
							,'3TLFE'
							,'4TLFE'
							,'5TLFE'
							,'6TLFE'
							,'7TLFE'
							,'8TLFE'
							,'1IEST'
							,'2IEST'
							,'3IEST'
							,'4IEST'
							,'5IEST'
							,'6IEST'
							,'7IEST'
							,'8IEST'
							,'1CEST'
							,'2CEST'
							,'3CEST'
							,'4CEST'
							,'5CEST'
							,'6CEST'
							,'7CEST'
							,'8CEST'
							,'1TEST'
							,'2TEST'
							,'3TEST'
							,'4TEST'
							,'5TEST'
							,'6TEST'
							,'7TEST'
							,'8TEST'
							)
						AND name_identifier_2 IN ('C')
						AND (
							party_type_code_2 <> 'CO'
							OR party_type_code_2 = ''
							)
						THEN 'Y'
					ELSE ''
					END AS SELLER_NAME_PLAINTIFF_2_CORP_IND
			) m2

	--last_company_name_FBO +  ' ' +  suffix_FBO +  ' ' +  first_name_FBO +  ' ' +  middle_name_FBO
	--------------------------------------------------------------------------------------------------
	-- Lender Names
	/*
- the code extract up to 8 Lender names for a document 0 that is 8 nameids that adhere to criteria below - we only carry one lender per Mtg

*/
	DROP TABLE

	IF EXISTS [Lien_dtdb].[INFC].[deed_Lender_names_pivot]
		SELECT Doc_id
			,max(CASE 
					WHEN ROW4 = 1
						THEN role_type
					ELSE ''
					END) AS role_type_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN role_type
					ELSE ''
					END) AS role_type_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN role_type
					ELSE ''
					END) AS role_type_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN role_type
					ELSE ''
					END) AS role_type_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN role_type
					ELSE ''
					END) AS role_type_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN role_type
					ELSE ''
					END) AS role_type_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN role_type
					ELSE ''
					END) AS role_type_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN role_type
					ELSE ''
					END) AS role_type_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN Name_id
					ELSE ''
					END) AS Name_id_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN Name_id
					ELSE ''
					END) AS Name_id_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN Name_id
					ELSE ''
					END) AS Name_id_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN Name_id
					ELSE ''
					END) AS Name_id_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN Name_id
					ELSE ''
					END) AS Name_id_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN Name_id
					ELSE ''
					END) AS Name_id_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN Name_id
					ELSE ''
					END) AS Name_id_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN Name_id
					ELSE ''
					END) AS Name_id_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN name_identifier
					ELSE ''
					END) AS name_identifier_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR1_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 2
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR2_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 3
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR3_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 4
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR4_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 5
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR5_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 6
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR6_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 7
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR7_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 8
						THEN CASE 
								WHEN first_name IS NULL
									THEN last_company_name
								ELSE last_company_name + ' ' + isnull(first_name, '') + ' ' + isnull(middle_name, '')
								END
					ELSE ''
					END) AS BYR8_OWN_NAME
			,max(CASE 
					WHEN ROW4 = 1
						THEN last_company_name
					ELSE ''
					END) AS BYR1_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 2
						THEN last_company_name
					ELSE ''
					END) AS BYR2_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 3
						THEN last_company_name
					ELSE ''
					END) AS BYR3_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 4
						THEN last_company_name
					ELSE ''
					END) AS BYR4_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 5
						THEN last_company_name
					ELSE ''
					END) AS BYR5_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 6
						THEN last_company_name
					ELSE ''
					END) AS BYR6_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 7
						THEN last_company_name
					ELSE ''
					END) AS BYR7_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 8
						THEN last_company_name
					ELSE ''
					END) AS BYR8_LAST_NAME
			,max(CASE 
					WHEN ROW4 = 1
						THEN first_name
					ELSE ''
					END) AS BYR1_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 2
						THEN first_name
					ELSE ''
					END) AS BYR2_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 3
						THEN first_name
					ELSE ''
					END) AS BYR3_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 4
						THEN first_name
					ELSE ''
					END) AS BYR4_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 5
						THEN first_name
					ELSE ''
					END) AS BYR5_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 6
						THEN first_name
					ELSE ''
					END) AS BYR6_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 7
						THEN first_name
					ELSE ''
					END) AS BYR7_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 8
						THEN first_name
					ELSE ''
					END) AS BYR8_FIRST_NAME
			,max(CASE 
					WHEN ROW4 = 1
						THEN middle_name
					ELSE ''
					END) AS BYR1_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 2
						THEN middle_name
					ELSE ''
					END) AS BYR2_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 3
						THEN middle_name
					ELSE ''
					END) AS BYR3_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 4
						THEN middle_name
					ELSE ''
					END) AS BYR4_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 5
						THEN middle_name
					ELSE ''
					END) AS BYR5_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 6
						THEN middle_name
					ELSE ''
					END) AS BYR6_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 7
						THEN middle_name
					ELSE ''
					END) AS BYR7_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 8
						THEN middle_name
					ELSE ''
					END) AS BYR8_MIDDLE_INITIAL
			,max(CASE 
					WHEN ROW4 = 1
						THEN suffix
					ELSE ''
					END) AS BYR1_SUFFIX
			,max(CASE 
					WHEN ROW4 = 2
						THEN suffix
					ELSE ''
					END) AS BYR2_SUFFIX
			,max(CASE 
					WHEN ROW4 = 3
						THEN suffix
					ELSE ''
					END) AS BYR3_SUFFIX
			,max(CASE 
					WHEN ROW4 = 4
						THEN suffix
					ELSE ''
					END) AS BYR4_SUFFIX
			,max(CASE 
					WHEN ROW4 = 5
						THEN suffix
					ELSE ''
					END) AS BYR5_SUFFIX
			,max(CASE 
					WHEN ROW4 = 6
						THEN suffix
					ELSE ''
					END) AS BYR6_SUFFIX
			,max(CASE 
					WHEN ROW4 = 7
						THEN suffix
					ELSE ''
					END) AS BYR7_SUFFIX
			,max(CASE 
					WHEN ROW4 = 8
						THEN suffix
					ELSE ''
					END) AS BYR8_SUFFIX
			,max(CASE 
					WHEN ROW4 = 1
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN party_type_code
					ELSE ''
					END) AS party_type_code_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN relationship_code
					ELSE ''
					END) AS BYR1_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 2
						THEN relationship_code
					ELSE ''
					END) AS BYR2_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 3
						THEN relationship_code
					ELSE ''
					END) AS BYR3_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 4
						THEN relationship_code
					ELSE ''
					END) AS BYR4_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 5
						THEN relationship_code
					ELSE ''
					END) AS BYR5_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 6
						THEN relationship_code
					ELSE ''
					END) AS BYR6_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 7
						THEN relationship_code
					ELSE ''
					END) AS BYR7_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 8
						THEN relationship_code
					ELSE ''
					END) AS BYR8_OWN_RELATIONSHIP_TYPE
			,max(CASE 
					WHEN ROW4 = 1
						THEN vesting_code
					ELSE ''
					END) AS BYR1_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 2
						THEN vesting_code
					ELSE ''
					END) AS BYR2_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 3
						THEN vesting_code
					ELSE ''
					END) AS BYR3_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 4
						THEN vesting_code
					ELSE ''
					END) AS BYR4_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 5
						THEN vesting_code
					ELSE ''
					END) AS BYR5_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 6
						THEN vesting_code
					ELSE ''
					END) AS BYR6_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 7
						THEN vesting_code
					ELSE ''
					END) AS BYR7_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 8
						THEN vesting_code
					ELSE ''
					END) AS BYR8_OWNERSHIP_RIGHTS_CODE
			,max(CASE 
					WHEN ROW4 = 1
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN percent_transferred
					ELSE ''
					END) AS percent_transferred_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN address_same_as_property_address_flag
					ELSE ''
					END) AS address_same_as_property_address_flag_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_HOUSE_NBR_PREFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_PREFIX_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_HOUSE_NBR
					ELSE ''
					END) AS MA_HOUSE_NBR_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_HOUSE_NBR_SUFFIX
					ELSE ''
					END) AS MA_HOUSE_NBR_SUFFIX_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_STREET_DIRECTION
					ELSE ''
					END) AS MA_STREET_DIRECTION_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_STREET_NAME
					ELSE ''
					END) AS MA_STREET_NAME_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_MODE
					ELSE ''
					END) AS MA_MODE_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_QUADRANT
					ELSE ''
					END) AS MA_QUADRANT_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_APARTMENT_UNIT
					ELSE ''
					END) AS MA_APARTMENT_UNIT_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_CITY
					ELSE ''
					END) AS MA_CITY_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_STATE
					ELSE ''
					END) AS MA_STATE_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_ZIP_CODE
					ELSE ''
					END) AS MA_ZIP_CODE_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_CARRIER_CODE
					ELSE ''
					END) AS MA_CARRIER_CODE_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_ORIGINAL_MAILING_ADDRESS
					ELSE ''
					END) AS MA_ORIGINAL_MAILING_ADDRESS_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN MA_DO_NOT_PUBLISH_FLAG
					ELSE ''
					END) AS MA_DO_NOT_PUBLISH_FLAG_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN orig_Mtg_Lender_Name
					ELSE ''
					END) AS orig_Mtg_Lender_Name_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN address
					ELSE ''
					END) AS address_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN address
					ELSE ''
					END) AS address_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN address
					ELSE ''
					END) AS address_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN address
					ELSE ''
					END) AS address_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN address
					ELSE ''
					END) AS address_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN address
					ELSE ''
					END) AS address_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN address
					ELSE ''
					END) AS address_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN address
					ELSE ''
					END) AS address_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN address_city_name
					ELSE ''
					END) AS address_city_name_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN address_state_name
					ELSE ''
					END) AS address_state_name_8
			,max(CASE 
					WHEN ROW4 = 1
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_1
			,max(CASE 
					WHEN ROW4 = 2
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_2
			,max(CASE 
					WHEN ROW4 = 3
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_3
			,max(CASE 
					WHEN ROW4 = 4
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_4
			,max(CASE 
					WHEN ROW4 = 5
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_5
			,max(CASE 
					WHEN ROW4 = 6
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_6
			,max(CASE 
					WHEN ROW4 = 7
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_7
			,max(CASE 
					WHEN ROW4 = 8
						THEN address_zip_code
					ELSE ''
					END) AS address_zip_code_8
		INTO [Lien_dtdb].[INFC].[deed_Lender_names_pivot]
		FROM (
			SELECT a.Doc_id
				,role_type
				,ROW_NUMBER() OVER (
					PARTITION BY a.doc_id ORDER BY CASE 
							WHEN a.name_identifier = 'c'
								THEN 1
							WHEN a.name_identifier = 't'
								THEN 2
							ELSE 3
							END
						,sequence_number
						--(SELECT 0	)
					) AS ROW4
				,a.Name_id
				,a.doc_unique_id
				,a.sequence_number
				,ltrim(rtrim(isnull(a.name_identifier, ''))) AS name_identifier
				,ltrim(rtrim(isnull(a.last_company_name, ''))) AS last_company_name
				,ltrim(rtrim(isnull(a.first_name, ''))) AS first_name
				,ltrim(rtrim(isnull(a.middle_name, ''))) AS middle_name
				,ltrim(rtrim(isnull(a.suffix, ''))) AS suffix
				,ltrim(rtrim(isnull(a.party_type_code, ''))) AS party_type_code
				,ltrim(rtrim(isnull(a.relationship_code, ''))) AS relationship_code
				,ltrim(rtrim(isnull(a.vesting_code, ''))) AS vesting_code
				,ltrim(rtrim(isnull(a.percent_transferred, ''))) AS percent_transferred
				,ltrim(rtrim(isnull(a.address_same_as_property_address_flag, ''))) AS address_same_as_property_address_flag
				,ltrim(rtrim(isnull(na.Direction, ''))) AS MA_HOUSE_NBR_PREFIX
				,ltrim(rtrim(isnull(na.HouseNumber, ''))) AS MA_HOUSE_NBR
				,ltrim(rtrim(isnull(na.Post_Direction, ''))) AS MA_HOUSE_NBR_SUFFIX
				,ltrim(rtrim(isnull(na.Post_Direction, ''))) AS MA_STREET_DIRECTION
				,ltrim(rtrim(isnull(na.Street_Name, ''))) AS MA_STREET_NAME
				,ltrim(rtrim(isnull(na.Street_Type, ''))) AS MA_MODE
				,'' AS MA_QUADRANT
				,ltrim(rtrim(isnull(na.Unit, ''))) AS MA_APARTMENT_UNIT
				,ltrim(rtrim(isnull(na.City, ''))) AS MA_CITY
				,ltrim(rtrim(isnull(na.STATE, ''))) AS MA_STATE
				,ltrim(rtrim(isnull(na.Zip, ''))) + ltrim(rtrim(isnull(na.Plus4, ''))) AS MA_ZIP_CODE
				,ltrim(rtrim(isnull(na.CRRT, ''))) AS MA_CARRIER_CODE
				----,REplace(a.address + ltrim(rtrim(isnull(a.address_city_name, '') + ', ' + ltrim(rtrim(isnull(address_state_name, '') + ', ' + ltrim(rtrim(isnull(address_zip_code, ''), ' ', '') AS MA_ORIGINAL_MAILING_ADDRESS
				--,ltrim(rtrim(isnull(a.address, ''))) AS MA_ORIGINAL_MAILING_ADDRESS
				,ltrim(rtrim(CASE 
							WHEN CHARINDEX('|', a.address) > 0
								THEN LEFT(a.address, CHARINDEX('|', a.address) - 1)
							ELSE ISNULL(a.address, '')
							END)) AS MA_ORIGINAL_MAILING_ADDRESS
				,'' AS MA_DO_NOT_PUBLISH_FLAG
				,ltrim(rtrim(isnull(a.orig_Mtg_Lender_Name, ''))) AS orig_Mtg_Lender_Name
				,ltrim(rtrim(isnull(a.address, ''))) AS address
				,ltrim(rtrim(isnull(a.address_city_name, ''))) AS address_city_name
				,ltrim(rtrim(isnull(a.address_state_name, ''))) AS address_state_name
				,replace(ltrim(rtrim(isnull(a.address_zip_code, ''))), '-', '') AS address_zip_code
			FROM [Lien_dtdb].[INFC].[deed_Lender_names] a
			--where doc_id in (51203156, 195040161) 
			OUTER APPLY (
				SELECT *
				FROM [lien].[ur].[NAME_STD_ADDRESS] na
				WHERE na.Name_id = a.Name_id
				) na
				--WHERE doc_id in (164025098, 163873593, 114683143, 163924302, 164025303, 164025311, 163900605, 164025417, 102846629)
			) a
		GROUP BY a.doc_id

	CREATE INDEX idx_doc_id ON [lien_DTDB].[Infc].[deed_Lender_names_pivot] (doc_id)

	--
	--  CREATE Name tables for RAS
	-- 
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[Ras_Names]
		SELECT a.*
			,ROW_NUMBER() OVER (
				PARTITION BY a.doc_id
				,A.Name_type ORDER BY CASE 
						WHEN A.party_type_code IN (
								'DBA'
								,'AKA'
								)
							THEN 1
						ELSE 0
						END
				) AS dba_aka_sort_seq
		INTO [Lien_dtdb].[infc].[Ras_Names]
		FROM (
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,N.first_name AS first_name
				,N.middle_name AS middle_name
				,N.suffix AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'RAS_Assignor' AS Name_Type
				,party_type_code
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT UR_DOC_TYPE
					FROM [Lien_DTDB].[dbo].[UR_RAS_Doc_Types] DT
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(N.role_type))) IN (
					SELECT CodeValue
					FROM [Lien].[dbo].[codetable]
					WHERE TableShortName = 'RAS_Assignor_Role_TP'
					)
			--AND isnull(n.party_type_code, '') NOT IN (
			--	'DBA'
			--	,'AKA'
			--	)
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,N.first_name AS first_name
				,N.middle_name AS middle_name
				,N.suffix AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'Ras_Assignee' AS Name_Type
				,party_type_code
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT UR_DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_RAS_Doc_Types] DT
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(N.role_type))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'RAS_Assignee_Role_TP'
					)
				AND isnull(n.party_type_code, '') NOT IN (
					'DBA'
					,'AKA'
					)
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,N.first_name AS first_name
				,N.middle_name AS middle_name
				,N.suffix AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'RAS_Lender' AS Name_Type
				,party_type_code
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT UR_DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_RAS_Doc_Types] DT
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(N.role_type))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'RAS_Lndr_Role_TP'
					)
			--AND isnull(n.party_type_code, '') NOT IN (
			--	'DBA'
			--	,'AKA'
			--	)
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,N.first_name AS first_name
				,N.middle_name AS middle_name
				,N.suffix AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'RAS_Borrower' AS Name_Type
				,party_type_code
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT UR_DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_RAS_Doc_Types] DT
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(N.role_type))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'RAS_Borr_Role_TP'
					)
				--AND isnull(n.party_type_code, '') NOT IN (
				--	'DBA'
				--	,'AKA'
				--	)
			) a

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[infc].[Ras_Names] (doc_id)

	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[Ras_Names_Pivot]
		SELECT doc_id
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS ras_Assignor_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS RAS_Assignor_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS RAS_Assignor_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS RAS_Assignor_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS RAS_Assignor_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS RAS_Assignor_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Assignor'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS RAS_Assignor_role_type_1
			--
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS ras_Assignee_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS Ras_Assignee_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS Ras_Assignee_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS Ras_Assignee_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS Ras_Assignee_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS Ras_Assignee_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'Ras_Assignee'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS Ras_Assignee_role_type_1
			--
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS ras_Lender_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS ras_Lender_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS ras_Lender_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS ras_Lender_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS ras_Lender_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS ras_Lender_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Lender'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS ras_Lender_role_type_1
			--
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS ras_Borrower_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS ras_Borrower_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS ras_Borrower_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS ras_Borrower_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS ras_Borrower_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS ras_Borrower_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'RAS_Borrower'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS ras_Borrower_role_type_1
		INTO [Lien_dtdb].[infc].[Ras_Names_pivot]
		FROM [Lien_dtdb].[infc].[Ras_Names]
		GROUP BY doc_id

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[infc].[Ras_Names_pivot] (doc_id)

	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[PFC_Names]
		SELECT a.sequence_number
			,name_identifier
			,isnull(last_company_name, '') AS last_company_name
			,isnull(first_name, '') AS first_name
			,isnull(middle_name, '') AS middle_name
			,isnull(suffix, '') AS suffix
			,isnull(role_type, '') AS role_type
			,doc_id
			,Name_Type
			,party_type_code
			,name_sequence_id
			,ROW_NUMBER() OVER (
				PARTITION BY a.doc_id
				,Name_type ORDER BY CASE 
						WHEN party_type_code IN (
								'DBA'
								,'AKA'
								)
							THEN 1
						ELSE 0
						END
				) AS dba_aka_sort_seq
		INTO [Lien_dtdb].[infc].[PFC_Names]
		FROM (
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,isnull(try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)), '') AS last_company_name
				,isnull(N.first_name, '') AS first_name
				,isnull(N.middle_name, '') AS middle_name
				,isnull(N.suffix, '') AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'PFC_Borrower_sq1' AS Name_Type
				,isnull(n.party_type_code, '') AS party_type_code
				,name_sequence_id
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_PFC_Doc_Types] dt
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'PFC_BorrSq1_Role_TP'
					)
				AND REPLACE(N.sequence_number, '0', '') = '1'
			--AND isnull(n.party_type_code, '') NOT IN ('DBA') --,'AKA')
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,isnull(N.first_name, '') AS first_name
				,isnull(N.middle_name, '') AS middle_name
				,isnull(N.suffix, '') AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'PFC_Borrower_sq2' AS Name_Type
				,isnull(n.party_type_code, '') AS party_type_code
				,name_sequence_id
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_PFC_Doc_Types] dt
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'PFC_BorrSq2_Role_TP'
					)
				AND REPLACE(N.sequence_number, '0', '') = '2'
			--AND isnull(n.party_type_code, '') NOT IN ('DBA') --,'AKA')
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,isnull(N.first_name, '') AS first_name
				,isnull(N.middle_name, '') AS middle_name
				,isnull(N.suffix, '') AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'PFC_Trustee_sq1' AS Name_Type
				,isnull(n.party_type_code, '') AS party_type_code
				,name_sequence_id
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_PFC_Doc_Types] dt
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'PFC_TrstSq1_Role_TP'
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) <> 'BENEFICIARY'
				AND REPLACE(N.sequence_number, '0', '') = '1'
			--AND isnull(n.party_type_code, '') NOT IN ('DBA') --,'AKA')
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,isnull(N.first_name, '') AS first_name
				,isnull(N.middle_name, '') AS middle_name
				,isnull(N.suffix, '') AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'PFC_Trustee_sq2' AS Name_Type
				,isnull(n.party_type_code, '') AS party_type_code
				,name_sequence_id
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_PFC_Doc_Types] dt
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'PFC_TrstSq2_Role_TP'
					)
				AND REPLACE(N.sequence_number, '0', '') = '2'
			--AND isnull(n.party_type_code, '') NOT IN ('DBA') --,'AKA')
			
			UNION ALL
			
			SELECT try_cast([SPDB].[dbo].[RegexExtract](sequence_number, '(^0+.*)', '1', 0) AS INT) sequence_number
				,N.name_identifier AS name_identifier
				,try_cast(substring(N.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,isnull(N.first_name, '') AS first_name
				,isnull(N.middle_name, '') AS middle_name
				,isnull(N.suffix, '') AS suffix
				,try_cast(substring(N.role_type, 1, 200) AS VARCHAR(200)) AS role_type
				,N.doc_id AS doc_id
				,'PFC_Lender' AS Name_Type
				,isnull(n.party_type_code, '') AS party_type_code
				,name_sequence_id
			FROM [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d
			INNER JOIN [lien].[UR].[NAME] N WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = d.doc_id
			WHERE d.doc_type IN (
					SELECT DOC_TYPE
					FROM [LIEN_DTDB].[dbo].[UR_PFC_Doc_Types] dt
					WHERE (
							dt.Delete_date IS NULL
							OR dt.Delete_date > d.Recording_Date_D
							)
					)
				AND UPPER(LTRIM(RTRIM(substring(N.role_type, 1, 200)))) IN (
					SELECT CodeValue
					FROM [lien].[dbo].[codetable]
					WHERE TableShortName = 'PFC_Lndr_Role_TP'
					)
				--AND isnull(n.party_type_code, '') NOT IN ('DBA') --,'AKA')
			) a

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[infc].[PFC_Names] (doc_id)

	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[PFC_Names_pivot]
		SELECT doc_id
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS pfc_bor_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS pfc_bor_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS pfc_bor_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS pfc_bor_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS pfc_bor_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS pfc_bor_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq1'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS pfc_bor_role_type_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN sequence_number
						ELSE NULL
						END, '')) AS pfc_bor_sequence_number_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN name_identifier
						ELSE NULL
						END, '')) AS pfc_bor_name_identifier_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN last_company_name
						ELSE NULL
						END, '')) AS pfc_bor_last_company_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN first_name
						ELSE NULL
						END, '')) AS pfc_bor_first_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN middle_name
						ELSE NULL
						END, '')) AS pfc_bor_middle_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN suffix
						ELSE NULL
						END, '')) AS pfc_bor_suffix_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Borrower_sq2'
							AND sequence_number = 2
							THEN role_type
						ELSE NULL
						END, '')) AS pfc_bor_role_type_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS pfc_trust_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS pfc_trust_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS pfc_trust_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS pfc_trust_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS pfc_trust_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS pfc_trust_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq1'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS pfc_trust_role_type_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN sequence_number
						ELSE NULL
						END, '')) AS pfc_trust_sequence_number_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN name_identifier
						ELSE NULL
						END, '')) AS pfc_trust_name_identifier_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN last_company_name
						ELSE NULL
						END, '')) AS pfc_trust_last_company_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN first_name
						ELSE NULL
						END, '')) AS pfc_trust_first_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN middle_name
						ELSE NULL
						END, '')) AS pfc_trust_middle_name_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN suffix
						ELSE NULL
						END, '')) AS pfc_trust_suffix_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Trustee_sq2'
							AND sequence_number = 2
							THEN role_type
						ELSE NULL
						END, '')) AS pfc_trust_role_type_2
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN sequence_number
						ELSE NULL
						END, '')) AS pfc_lndr_sequence_number_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN name_identifier
						ELSE NULL
						END, '')) AS pfc_lndr_name_identifier_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN last_company_name
						ELSE NULL
						END, '')) AS pfc_lndr_last_company_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN first_name
						ELSE NULL
						END, '')) AS pfc_lndr_first_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN middle_name
						ELSE NULL
						END, '')) AS pfc_lndr_middle_name_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN suffix
						ELSE NULL
						END, '')) AS pfc_lndr_suffix_1
			,max(isnull(CASE 
						WHEN Name_Type = 'PFC_Lender1'
							AND sequence_number = 1
							THEN role_type
						ELSE NULL
						END, '')) AS pfc_lndr_role_type_1
		INTO [Lien_dtdb].[infc].[PFC_Names_pivot]
		FROM [Lien_dtdb].[infc].[PFC_Names]
		GROUP BY doc_id

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien_dtdb].[infc].[PFC_Names_pivot] (doc_id)

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'USP_Extract_Names'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


