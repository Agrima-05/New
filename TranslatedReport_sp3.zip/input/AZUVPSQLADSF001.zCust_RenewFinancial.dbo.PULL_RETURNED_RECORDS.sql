SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [zCust_RenewFinancial].[dbo].[PULL_RETURNED_RECORDS]
as
BEGIN


  INSERT INTO [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT]
	   SELECT --top 20
		 REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') as Errors
		,REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')

		-----Added 20210907 per NH---
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_Message], CHAR(13), ''), CHAR(10), ''),'|','')

  
  ----20210907 - Per Giang
  ----I have created a new view OutputLayout5  using OutputLayout4 and expose 3 additional fields: OtherTaxDetails1_Message, OtherTaxDetails2_Message and OtherTaxDetails3_Message


		--Select 	A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
		----FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--Select A.BatchID, A.ExternalKey,PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
		FROM [TaxSourceAPI].[dbo].[OutputLayout5] as A with(NOLOCK)
		join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
		and ReportStatus like 'Ready'
		--and A.ExternalKey = 'FL-00064948'
		--Order by A.ExternalKey


	


	  UPdate [zCust_RenewFinancial].[dbo].[A]
	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
	  From  [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT] as B on 
	  A.UniqueID = B.[ExternalKey]


	INSERT INTO [zCust_RenewFinancial].[dbo].[INPUT_MONITOR_COMPLETED](UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID)
SELECT UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID
FROM     [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
WHERE  (DATE_COMPLETED IS NOT NULL)
	  --Select * From [INPUT_MONITOR_COMPLETED]


	  Delete from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
	  --Select * 
	  From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR_COMPLETED] as B on 
	  A.UniqueID = B.UniqueID
	  and A.BatchID = B.BatchID
	  where B.DATE_COMPLETED is not null

	 


	  Select count(*) From [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT]

	  --Select count(*) From TaxSourceAPI.dbo.Property as A with(NOLOCK)
	  --join INPUT_MONITOR as B on A.ExternalKey = B.UNIQUEID
	  --and A.BatchId = B.BATCHID


	  			DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @body5 NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Renew Taxsource Returned Record Count - ' + @Date 
				--SET @body3 = '<html><body><H3>RECORDS REMAINING</H3>
				--<table border = 1> 
				--<tr><th> RECORDS REMAINING  </th></tr>' 
				--SET @xml2 = 
				--CAST(( 
				
				--	Select count(*) as 'td','' From INPUT_MONITOR as A with(NOLOCK)
				--	where DATE_COMPLETED is null
	
				--FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

				--SET @body1 = '<html><body><H3>BATCH COUNT</H3>
				--<table border = 1> 
				--<tr><th> DATE_COMPLETED  </th> <th> BATCHID  </th> <th> TOTAL </th></tr>'  

		--		SET @xml = 
		--		CAST(( 
				
		--Select convert(date,left(B.DATE_COMPLETED,8)) as 'td','',A.Batchid as 'td','',  count(*) as 'td',''  
		--From [x_Custom_OUTPUT] as A with(NOLOCK)
		--join INPUT_MONITOR_COMPLETED as B with(NOLOCK) on A.ExternalKey = B.UNIQUEID
		--and A.Batchid = B.Batchid
		--Group by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid 
		--ORder by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid 
	
		--		FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

			SET @xml = 
				N'<H1>BATCH COUNT:</H1>' +
				N'<table border="1">' +
				N'<tr><th> DATE_COMPLETED  </th> <th> BATCHID  </th> <th> TOTAL </th></tr>' +
				CAST ( ( Select convert(date,left(B.DATE_COMPLETED,8)) as 'td','',A.Batchid as 'td','',  count(*) as 'td',''  
		From [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT] as A with(NOLOCK)
		join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR_COMPLETED] as B with(NOLOCK) on A.ExternalKey = B.UNIQUEID
		and A.Batchid = B.Batchid
		Group by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid 
		ORder by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid    
						  FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
				N'</table>' ;

				SET @xml2 = 
				N'<H1>RECORDS REMAINING:</H1>' +
				N'<table border="1">' +
				N'<tr><th> RECORDS REMAINING  </th></tr>' +
				CAST ( ( 	Select count(*) as 'td','' From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A with(NOLOCK)
					where DATE_COMPLETED is null 
						  FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
				N'</table>' ;

				--Set @body2 = '<html><body><H1>BATCH COUNT</H1>
				--<table border = 1> 
				--<tr><th> DATE_COMPLETED  </th> <th> BATCHID  </th> <th> TOTAL </th></tr>'  + @XML
				 
				--Set @body4 = '<html><body><H3>RECORDS REMAINING</H3>
				--<table border = 1> 
				--<tr><th> RECORDS REMAINING  </th></tr>'  + @XML2
				 
				Set @body5 = @xml + ' <br/> ' + @XML2  
				
				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body5,
				@body_format ='HTML',
				--@recipients = 'klowe@firstam.com;MicSmith@firstam.com',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = high
						;

	

			--Select Batchid, count(*) as TOTAL From [x_Custom_OUTPUT]
			--Group by Batchid
			--Order by Batchid
		

		--Select convert(date,left(B.DATE_COMPLETED,8)) as 'td','',A.Batchid as 'td','',  count(*) as 'td',''  
		--From [x_Custom_OUTPUT] as A with(NOLOCK)
		--join INPUT_MONITOR_COMPLETED as B with(NOLOCK) on A.ExternalKey = B.UNIQUEID
		--and A.Batchid = B.Batchid
		--Group by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid 
		--ORder by convert(date,left(B.DATE_COMPLETED,8)),A.Batchid 
				

			






		END
