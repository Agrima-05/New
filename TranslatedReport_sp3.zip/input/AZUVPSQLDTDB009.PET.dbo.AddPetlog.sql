/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.AddPetlog | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE    PROCEDURE [PET].[dbo].[AddPetlog]
	 @Fips INT
	,@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [PET].[dbo].[PETLog] (
	 [Fips]
	,[LogTimestamp]
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	 @Fips
	,getdate()
	,@Level
	,@Logger
	,@Message
	)

