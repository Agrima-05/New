SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [Data].[dbo].[Prop_Assr_Refresh_STEP1]
as
BEGIN



/*IF  EXISTS (SELECT * FROM [Data].[sys].[objects] WHERE object_id = OBJECT_ID(N'[Data].[dbo].[Property_BATCH]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [Data].[dbo].[Property_BATCH]

/*IF  EXISTS (SELECT * FROM [Data].[sys].[objects] WHERE object_id = OBJECT_ID(N'[Data].[dbo].[Property_OLD]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [Data].[dbo].[Property_OLD]



	CREATE TABLE [dbo].[Property_BATCH](
	[FIPS] [char](5) NOT NULL,
	[PropertyID] [bigint] NOT NULL,
	[FormattedAPN] [varchar](45) NULL,
	[APNSeqNbr] [char](2) NULL,
	[UnformattedAPN] [varchar](45) NULL,
	[OldAPN] [varchar](31) NULL,
	[OLDAPNSeqNbr] [varchar](31) NULL,
	[TaxAccountNumber] [varchar](30) NULL,
	[RecordType] [varchar](2) NULL,
	[VendorPID] [bigint] NULL,
	[SitusStdFullStreetAddress] [varchar](116) NULL,
	[SitusStdHouseNbr] [varchar](30) NULL,
	[SitusStdHouseNbr2] [varchar](10) NULL,
	[SitusStdHouseNbrSuffix] [varchar](10) NULL,
	[SitusStdDirectionLeft] [varchar](2) NULL,
	[SitusStdStreet] [varchar](60) NULL,
	[SitusStdMode] [varchar](10) NULL,
	[SitusStdDirectionRight] [varchar](2) NULL,
	[SitusStdUnitNbr] [varchar](15) NULL,
	[SitusStdCity] [varchar](55) NULL,
	[SitusStdState] [varchar](2) NULL,
	[SitusStdZIP5] [varchar](9) NULL,
	[SitusStdZIP4] [varchar](4) NULL,
	[SitusLatitude] [float] NULL,
	[SitusLongitude] [float] NULL,
	[SitusStdCarrierCode] [varchar](4) NULL,
	[SitusCensusTract] [varchar](6) NULL,
	[SitusCensusTractBlock] [varchar](20) NULL,
	[SitusStdUnitType] [varchar](20) NULL,
	[SitusStdMatchCode] [varchar](30) NULL,
	[LotSizeSqFt] [int] NULL,
	[LotSizeAcres] [varchar](10) NULL,
	[LotSizeFrontageFeet] [varchar](10) NULL,
	[LotSizeDepthFeet] [varchar](10) NULL,
	[LotIrregularInd] [bit] NULL,
	[LotUsableSize] [varchar](10) NULL,
	[PropertyClassID] [varchar](2) NULL,
	[StdLandUseCode] [char](5) NULL,
	[StateLandUseCode] [char](10) NULL,
	[CountyLandUseCode] [char](10) NULL,
	[CountyLandUseDescription] [varchar](45) NULL,
	[TimeshareCode] [char](1) NULL,
	[Zoning] [varchar](25) NULL,
	[SiteInfluenceCode] [varchar](10) NULL,
	[NeighborhoodCode] [varchar](10) NULL,
	[TopographyCode] [varchar](10) NULL,
	[MobileHomeInd] [bit] NULL,
	[LotCode] [char](2) NULL,
	[LotNumber] [char](7) NULL,
	[LandLot] [char](10) NULL,
	[Block] [char](7) NULL,
	[Section] [char](7) NULL,
	[District] [varchar](12) NULL,
	[LegalUnit] [char](6) NULL,
	[Municipality] [varchar](30) NULL,
	[LegalSection] [varchar](30) NULL,
	[LegalTownship] [varchar](30) NULL,
	[LegalRange] [varchar](30) NULL,
	[Meridian] [varchar](30) NULL,
	[LegalQuarter] [varchar](30) NULL,
	[LegalQuarterQuarter] [varchar](30) NULL,
	[LegalDescription] [varchar](2000) NULL,
	[AssessorsMapRef1] [varchar](15) NULL,
	[AssessorsMapRef2] [varchar](15) NULL,
	[SubdivisionName] [varchar](40) NULL,
	[SubdivisionPhaseNbr] [char](7) NULL,
	[SubdivisionTractNbr] [char](10) NULL,
	[SubdivisionPlatBook] [char](10) NULL,
	[SubdivisionPlatPage] [char](10) NULL,
	[NewRecordType] [char](2) NULL,
	[SwiSCodeNY] [varchar](10) NULL,
	[MailingCareOfName] [varchar](80) NULL,
	[MailingStdFullStreetAddress] [varchar](116) NULL,
	[MailingStdHouseNbr] [varchar](30) NULL,
	[MailingStdHouseNbr2] [varchar](10) NULL,
	[MailingStdHouseNbrSuffix] [varchar](10) NULL,
	[MailingStdDirectionLeft] [varchar](2) NULL,
	[MailingStdStreet] [varchar](60) NULL,
	[MailingStdMode] [varchar](10) NULL,
	[MailingStdDirectionRight] [varchar](2) NULL,
	[MailingStdUnitNbr] [varchar](15) NULL,
	[MailingStdCity] [varchar](55) NULL,
	[MailingStdState] [varchar](2) NULL,
	[MailingStdZIP5] [varchar](9) NULL,
	[MailingStdZIP4] [varchar](9) NULL,
	[MailingStdCarrierCode] [varchar](4) NULL,
	[MailingStdUnitType] [varchar](20) NULL,
	[MailingStdMatchCode] [varchar](30) NULL,
	[MailingOptOut] [bit] NULL,
	[MailingOptOutDate] [varchar](8) NULL,
	[OwnerOccupied] [char](1) NULL,
	[AbsenteeOwner] [char](1) NULL,
	[OwnerStdNAME1FULL] [varchar](80) NULL,
	[OwnerStdNAME2FULL] [varchar](80) NULL,
	[OwnerStdNAME3FULL] [varchar](80) NULL,
	[OwnerStdNAME4FULL] [varchar](80) NULL,
	[OwnerEtALIndicator] [varchar](5) NULL,
	[OwnerStd1CorpInd] [bit] NULL,
	[OwnerStd1LastName] [varchar](30) NULL,
	[OwnerStd1FirstName] [varchar](30) NULL,
	[OwnerStd1MiddleName] [varchar](20) NULL,
	[OwnerStd1Suffix] [varchar](5) NULL,
	[OwnerStd1CorpName] [varchar](45) NULL,
	[OwnerStd1OwnershipRights] [varchar](5) NULL,
	[OwnerStd1RelationshipType] [varchar](5) NULL,
	[Owner1DoNotParse] [bit] NULL,
	[OwnerStd2CorpInd] [bit] NULL,
	[OwnerStd2LastName] [varchar](30) NULL,
	[OwnerStd2FirstName] [varchar](30) NULL,
	[OwnerStd2MiddleName] [varchar](20) NULL,
	[OwnerStd2Suffix] [varchar](5) NULL,
	[OwnerStd2CorpName] [varchar](45) NULL,
	[OwnerStd2OwnershipRights] [varchar](5) NULL,
	[OwnerStd2RelationshipType] [varchar](5) NULL,
	[Owner2DoNotParse] [bit] NULL,
	[OwnerStd3CorpInd] [bit] NULL,
	[OwnerStd3LastName] [varchar](30) NULL,
	[OwnerStd3FirstName] [varchar](30) NULL,
	[OwnerStd3MiddleName] [varchar](20) NULL,
	[OwnerStd3Suffix] [varchar](5) NULL,
	[OwnerStd3CorpName] [varchar](45) NULL,
	[OwnerStd3OwnershipRights] [varchar](5) NULL,
	[OwnerStd3RelationshipType] [varchar](5) NULL,
	[Owner3DoNotParse] [bit] NULL,
	[OwnerStd4CorpInd] [bit] NULL,
	[OwnerStd4LastName] [varchar](30) NULL,
	[OwnerStd4FirstName] [varchar](30) NULL,
	[OwnerStd4MiddleName] [varchar](20) NULL,
	[OwnerStd4Suffix] [varchar](5) NULL,
	[OwnerStd4CorpName] [varchar](45) NULL,
	[OwnerStd4OwnershipRights] [varchar](5) NULL,
	[OwnerStd4RelationshipType] [varchar](5) NULL,
	[Owner4DoNotParse] [bit] NULL,
	[AssesseeStd1Name] [varchar](80) NULL,
	[AssesseeStd2Name] [varchar](80) NULL,
	[AssesseeNameIndicator] [varchar](1) NULL,
	[AssesseeNameIndicator2] [varchar](1) NULL,
	[Amenities] [varchar](10) NULL,
	[DrivewayCode] [varchar](10) NULL,
	[EasementInd] [bit] NULL,
	[QualityCode] [varchar](10) NULL,
	[ViewInd] [bit] NULL,
	[ViewCode] [varchar](10) NULL,
	[ViewQualityCode] [varchar](10) NULL,
	[WaterAccessableInd] [bit] NULL,
	[WaterFeatureInd] [bit] NULL,
	[WaterfrontCode] [varchar](10) NULL,
	[WaterfrontFeet] [int] NULL,
	[WaterfrontQualityCode] [varchar](10) NULL,
	[BuildingArea] [int] NULL,
	[BuildingAreaInd] [varchar](2) NULL,
	[TotalRooms] [int] NULL,
	[Bedrooms] [int] NULL,
	[BathTotalCalc] [numeric](5, 2) NULL,
	[BathFull] [int] NULL,
	[BathsParcialNbr] [int] NULL,
	[BathHalf] [int] NULL,
	[Bath1QTR] [int] NULL,
	[Bath3QTR] [int] NULL,
	[BathFixturesNbr] [int] NULL,
	[OtherRooms] [varchar](5) NULL,
	[AirConditioningCode] [int] NULL,
	[AirConditioningTypeCode] [int] NULL,
	[BasementCode] [int] NULL,
	[BasementFinishedCode] [int] NULL,
	[BuildingClassCode] [int] NULL,
	[BuildingConditionCode] [int] NULL,
	[BuildingQualityCode] [int] NULL,
	[ConstructionTypeCode] [int] NULL,
	[DeckCode] [int] NULL,
	[ElectricityCode] [int] NULL,
	[ExteriorWallsCode] [int] NULL,
	[FireplaceCode] [int] NULL,
	[FloorCoverCode] [int] NULL,
	[FloorTypeCode] [int] NULL,
	[FoundationInd] [int] NULL,
	[FrameCode] [int] NULL,
	[Garage] [int] NULL,
	[GarageParkingNbr] [int] NULL,
	[HeatCode] [int] NULL,
	[HeatingFuelTypeCode] [int] NULL,
	[InteriorWallsCode] [int] NULL,
	[PavingCode] [int] NULL,
	[PatioCode] [int] NULL,
	[PoolCode] [int] NULL,
	[PorchCode] [int] NULL,
	[RoofCoverCode] [int] NULL,
	[RoofTypeCode] [int] NULL,
	[SewerCode] [int] NULL,
	[ShapeCode] [int] NULL,
	[StoriesCode_OLD] [int] NULL,
	[StoriesNbrCode_OLD] [int] NULL,
	[StyleCode] [int] NULL,
	[WallExteriorCode] [int] NULL,
	[WallheightCode] [int] NULL,
	[WaterCode] [int] NULL,
	[YearBuilt] [varchar](4) NULL,
	[EffectiveYearBuilt] [varchar](4) NULL,
	[SumBuildingsNbr] [int] NULL,
	[SumAboveGradeLivingSqFt] [int] NULL,
	[SumAdjAreaSqFt] [int] NULL,
	[SumBasementSqFt] [int] NULL,
	[SumBuildingSqFt] [int] NULL,
	[SumGarageSqFt] [int] NULL,
	[SumGrossAreaSqFt] [int] NULL,
	[SumGroundFloorSqFt] [int] NULL,
	[SumLivingAreaSqFt] [int] NULL,
	[SumResidentialUnits] [int] NULL,
	[AssdLandValue] [int] NULL,
	[AssdImprovementValue] [int] NULL,
	[AssdTotalValue] [int] NULL,
	[AssdYear] [char](4) NULL,
	[MarketValueLand] [int] NULL,
	[MarketValueImprovement] [int] NULL,
	[MarketTotalValue] [int] NULL,
	[MarketValueYear] [char](4) NULL,
	[ApprLandValue] [int] NULL,
	[ApprImprovementValue] [int] NULL,
	[ApprTotalValue] [int] NULL,
	[ApprYear] [char](4) NULL,
	[TaxValueLand] [int] NULL,
	[TaxValueImprovement] [int] NULL,
	[TaxTotalValue] [int] NULL,
	[TaxableYear] [char](4) NULL,
	[UNVLandValue] [int] NULL,
	[UNVImprovementValue] [int] NULL,
	[UNVTotalValue] [int] NULL,
	[UNVValueYear] [char](4) NULL,
	[TaxRateCodeArea] [varchar](20) NULL,
	[TaxYear] [char](4) NULL,
	[TaxAmount] [bigint] NULL,
	[TaxDeliquentYear1] [char](4) NULL,
	[TaxDeliquentValue1] [int] NULL,
	[TaxExemptionCode] [varchar](10) NULL,
	[TaxexemptInd] [bit] NULL,
	[CalifHomeownerInd] [bit] NULL,
	[CemeteryInd] [bit] NULL,
	[DisabledInd] [bit] NULL,
	[HomesteadInd] [bit] NULL,
	[HospitalInd] [bit] NULL,
	[LibraryInd] [bit] NULL,
	[PublicUtilityInd] [bit] NULL,
	[ReligiousInd] [bit] NULL,
	[SchoolCollegeInd] [bit] NULL,
	[SeniorInd] [bit] NULL,
	[VeteranInd] [bit] NULL,
	[WelfareInd] [bit] NULL,
	[WidowInd] [bit] NULL,
	[SchoolTaxDistrict1Code] [varchar](15) NULL,
	[SchoolTaxDistrict1Ind] [char](1) NULL,
	[SchoolTaxDistrict2Code] [varchar](15) NULL,
	[SchoolTaxDistrict2Ind] [char](1) NULL,
	[SchoolTaxDistrict3Code] [varchar](15) NULL,
	[SchoolTaxDistrict3Ind] [char](1) NULL,
	[FADeleteFlag] [bit] NULL,
	[FADeleteFlagDate] [datetime] NULL,
	[CurrentSaleTransactionId] [bigint] NULL,
	[CurrentSaleChronoKey] [varchar](31) NULL,
	[CurrSaleInputDocNbr] [varchar](20) NULL,
	[CurrSaleInputBook] [varchar](10) NULL,
	[CurrSaleInputPage] [varchar](10) NULL,
	[CurrSaleFormatDocNbr] [varchar](20) NULL,
	[CurrSaleFormatBook] [varchar](10) NULL,
	[CurrSaleFormatPage] [varchar](10) NULL,
	[CurrSaleRecordingDate] [varchar](8) NULL,
	[CurrSaleDocumentType] [varchar](30) NULL,
	[CurrSalesPrice] [int] NULL,
	[CurrSalesPriceCode] [varchar](5) NULL,
	[CurrSaleContractDate] [varchar](8) NULL,
	[CurrSaleBuyer1FullName] [varchar](60) NULL,
	[CurrSaleBuyer2FullName] [varchar](60) NULL,
	[CurrSaleBuyer3FullName] [varchar](60) NULL,
	[CurrSaleBuyer4FullName] [varchar](60) NULL,
	[CurrSaleSeller1FullName] [varchar](60) NULL,
	[CurrSaleSeller2FullName] [varchar](60) NULL,
	[ConCurrMtg1InputDocNbr] [varchar](20) NULL,
	[ConCurrMtg1InputBook] [varchar](10) NULL,
	[ConCurrMtg1InputPage] [varchar](10) NULL,
	[ConCurrMtg1FormatDocNbr] [varchar](20) NULL,
	[ConCurrMtg1FormatBook] [varchar](10) NULL,
	[ConCurrMtg1FormatPage] [varchar](10) NULL,
	[ConCurrMtg1RecordingDt] [varchar](10) NULL,
	[ConCurrMtg1LoanAmt] [int] NULL,
	[ConCurrMtg1Lender] [varchar](30) NULL,
	[ConCurrMtg1LenderCode] [varchar](10) NULL,
	[ConCurrMtg1LenderType] [varchar](5) NULL,
	[ConCurrMtg1PrivateLender] [bit] NULL,
	[ConCurrMtg1Term] [varchar](3) NULL,
	[ConCurrMtg1LoanDueDt] [varchar](10) NULL,
	[ConCurrMtg1AdjOrFix] [varchar](1) NULL,
	[ConCurrMtg1LoanType] [varchar](10) NULL,
	[ConCurrMtg1Typefinancing] [varchar](10) NULL,
	[ConCurrMtg1LienPosition] [int] NULL,
	[ConCurrMtg2InputDocNbr] [varchar](20) NULL,
	[ConCurrMtg2InputBook] [varchar](10) NULL,
	[ConCurrMtg2InputPage] [varchar](10) NULL,
	[ConCurrMtg2FormatDocNbr] [varchar](20) NULL,
	[ConCurrMtg2FormatBook] [varchar](10) NULL,
	[ConCurrMtg2FormatPage] [varchar](10) NULL,
	[ConCurrMtg2RecordingDt] [varchar](10) NULL,
	[ConCurrMtg2LoanAmt] [int] NULL,
	[ConCurrMtg2Lender] [varchar](30) NULL,
	[ConCurrMtg2LenderCode] [varchar](10) NULL,
	[ConCurrMtg2LenderType] [varchar](5) NULL,
	[ConCurrMtg2PrivateLender] [bit] NULL,
	[ConCurrMtg2LoanDueDt] [varchar](10) NULL,
	[ConCurrMtg2AdjOrFix] [varchar](1) NULL,
	[ConCurrMtg2LoanType] [varchar](10) NULL,
	[ConCurrMtg2Typefinancing] [varchar](10) NULL,
	[ConCurrMtg2LienPosition] [int] NULL,
	[Mtg1TransactionId] [bigint] NULL,
	[Mtg1ChronoKey] [varchar](31) NULL,
	[Mtg1LoanAmt] [int] NULL,
	[Mtg1Lender] [varchar](30) NULL,
	[Mtg1LenderCode] [varchar](10) NULL,
	[Mtg1LenderType] [varchar](10) NULL,
	[Mtg1PrivateLender] [bit] NULL,
	[Mtg1LoanDueDt] [varchar](10) NULL,
	[Mtg1AdjRider] [varchar](1) NULL,
	[Mtg1LoanType] [varchar](10) NULL,
	[Mtg1Typefinancing] [varchar](10) NULL,
	[Mtg1LienPosition] [int] NULL,
	[Mtg2TransactionId] [bigint] NULL,
	[Mtg2ChronoKey] [varchar](31) NULL,
	[Mtg2InputDocNbr] [varchar](20) NULL,
	[Mtg2InputBook] [varchar](10) NULL,
	[Mtg2InputPage] [varchar](10) NULL,
	[Mtg2FormatDocNbr] [varchar](20) NULL,
	[Mtg2FormatBook] [varchar](10) NULL,
	[Mtg2FormatPage] [varchar](10) NULL,
	[Mtg2RecordingDt] [varchar](10) NULL,
	[Mtg2LoanAmt] [int] NULL,
	[Mtg2Lender] [varchar](30) NULL,
	[Mtg2LenderCode] [varchar](10) NULL,
	[Mtg2LenderType] [varchar](10) NULL,
	[Mtg2PrivateLender] [bit] NULL,
	[Mtg2LoanDueDt] [varchar](10) NULL,
	[Mtg2AdjRider] [varchar](1) NULL,
	[Mtg2LoanType] [varchar](10) NULL,
	[Mtg2Typefinancing] [varchar](10) NULL,
	[Mtg2LienPosition] [int] NULL,
	[Mtg3TransactionId] [bigint] NULL,
	[Mtg3ChronoKey] [varchar](31) NULL,
	[Mtg3InputDocNbr] [varchar](20) NULL,
	[Mtg3InputBook] [varchar](10) NULL,
	[Mtg3InputPage] [varchar](10) NULL,
	[Mtg3FormatDocNbr] [varchar](20) NULL,
	[Mtg3FormatBook] [varchar](10) NULL,
	[Mtg3FormatPage] [varchar](10) NULL,
	[Mtg3RecordingDt] [varchar](10) NULL,
	[Mtg3LoanAmt] [int] NULL,
	[Mtg3Lender] [varchar](30) NULL,
	[Mtg3LenderCode] [varchar](10) NULL,
	[Mtg3LenderType] [varchar](10) NULL,
	[Mtg3PrivateLender] [bit] NULL,
	[Mtg3LoanDueDt] [varchar](10) NULL,
	[Mtg3AdjRider] [varchar](1) NULL,
	[Mtg3LoanType] [varchar](10) NULL,
	[Mtg3Typefinancing] [varchar](10) NULL,
	[Mtg3LienPosition] [int] NULL,
	[Mtg4TransactionId] [bigint] NULL,
	[Mtg4ChronoKey] [varchar](31) NULL,
	[Mtg4InputDocNbr] [varchar](20) NULL,
	[Mtg4InputBook] [varchar](10) NULL,
	[Mtg4InputPage] [varchar](10) NULL,
	[Mtg4FormatDocNbr] [varchar](20) NULL,
	[Mtg4FormatBook] [varchar](10) NULL,
	[Mtg4FormatPage] [varchar](10) NULL,
	[Mtg4RecordingDt] [varchar](10) NULL,
	[Mtg4LoanAmt] [int] NULL,
	[Mtg4Lender] [varchar](30) NULL,
	[Mtg4LenderCode] [varchar](10) NULL,
	[Mtg4LenderType] [varchar](10) NULL,
	[Mtg4PrivateLender] [bit] NULL,
	[Mtg4LoanDueDt] [varchar](10) NULL,
	[Mtg4AdjRider] [varchar](1) NULL,
	[Mtg4LoanType] [varchar](10) NULL,
	[Mtg4Typefinancing] [varchar](10) NULL,
	[Mtg4LienPosition] [int] NULL,
	[PrevSaleTransactionId] [bigint] NULL,
	[PrevSaleChronoKey] [varchar](31) NULL,
	[PrevSaleInputDocNbr] [varchar](20) NULL,
	[PrevSaleInputBook] [varchar](10) NULL,
	[PrevSaleInputPage] [varchar](10) NULL,
	[PrevSaleFormatDocNbr] [varchar](20) NULL,
	[PrevSaleFormatBook] [varchar](10) NULL,
	[PrevSaleFormatPage] [varchar](10) NULL,
	[PrevSaleRecordingDate] [varchar](8) NULL,
	[PrevSalesPrice] [int] NULL,
	[PrevSalesPriceCode] [varchar](5) NULL,
	[PrevSaleContractDate] [varchar](8) NULL,
	[PrevSaleBuyer1FullName] [varchar](60) NULL,
	[PrevSaleBuyer2FullName] [varchar](60) NULL,
	[PrevSaleBuyer3FullName] [varchar](60) NULL,
	[PrevSaleBuyer4FullName] [varchar](60) NULL,
	[PrevSaleSeller1FullName] [varchar](60) NULL,
	[PrevSaleSeller2FullName] [varchar](60) NULL,
	[PrevMtg1InputDocNbr] [varchar](20) NULL,
	[PrevMtg1InputBook] [varchar](10) NULL,
	[PrevMtg1InputPage] [varchar](10) NULL,
	[PrevMtg1FormatDocNbr] [varchar](20) NULL,
	[PrevMtg1FormatBook] [varchar](10) NULL,
	[PrevMtg1FormatPage] [varchar](10) NULL,
	[PrevMtg1RecordingDt] [varchar](10) NULL,
	[PrevMtg1LoanAmt] [int] NULL,
	[PrevMtg1Lender] [varchar](30) NULL,
	[PrevMtg1LenderCode] [varchar](10) NULL,
	[PrevMtg1LenderType] [varchar](5) NULL,
	[PrevMtg1PrivateLender] [bit] NULL,
	[PrevMtg1LoanDueDt] [varchar](10) NULL,
	[PrevMtg1AdjRider] [varchar](1) NULL,
	[PrevMtg1LoanType] [varchar](10) NULL,
	[PrevMtg1Typefinancing] [varchar](10) NULL,
	[EditionNumber] [char](2) NULL,
	[VersionId] [numeric](9, 0) NULL,
	[VendorLoadDate] [varchar](8) NULL,
	[FASourceInd] [varchar](2) NULL,
	[FATimestamp] [datetime2](7) NULL,
	[FAUserId] [varchar](50) NULL,
	[FACreateDt] [datetime2](7) NULL,
	[FADeriveProcessDt] [datetime2](7) NULL,
	[FAEnhanceprocessDt] [datetime2](7) NULL,
	[FAOwnershipUpdateDt] [datetime2](7) NULL,
	[FAActiveDt] [datetime2](7) NULL,
	[SitusDPVCount] [char](5) NULL,
	[SitusDPVFootnote] [char](4) NULL,
	[SitusLACS] [char](1) NULL,
	[SitusLACSLinkInd] [char](1) NULL,
	[SitusDPCheckDigit] [char](1) NULL,
	[SitusDPCheckCode] [char](2) NULL,
	[SitusCensusBlock] [char](4) NULL,
	[SitusGeoErrorCode] [char](1) NULL,
	[SitusGeoStatusCode] [char](1) NULL,
	[MailingDPVCount] [char](5) NULL,
	[MailingDPVFootnote] [char](4) NULL,
	[MailingLACS] [char](1) NULL,
	[MailingLACSLinkInd] [char](1) NULL,
	[MailingDPCheckDigit] [char](1) NULL,
	[MailingDPCheckCode] [char](2) NULL,
	[MailingCensusBlock] [char](4) NULL,
	[MailingCensusTract] [char](6) NULL,
	[MailingGeoErrorCode] [char](1) NULL,
	[MailingGeoStatusCode] [char](1) NULL,
	[CheckOwnership] [varchar](1) NULL,
	[Mtg1InputDocNbr] [varchar](20) NULL,
	[Mtg1InputBook] [varchar](10) NULL,
	[Mtg1FormatDocNbr] [varchar](20) NULL,
	[Mtg1FormatBook] [varchar](10) NULL,
	[Mtg1FormatPage] [varchar](10) NULL,
	[Mtg1RecordingDt] [varchar](10) NULL,
	[Mtg1InputPage] [varchar](10) NULL,
	[FAUCIDFlag] [char](1) NULL,
	[FADateReceived] [varchar](8) NULL,
	[FAAddressParsedSitus] [datetime] NULL,
	[FAAddressParsedMailing] [datetime] NULL,
	[FACLTV] [decimal](10, 2) NULL,
	[FAOLTV] [decimal](10, 2) NULL,
	[FALatitude] [float] NULL,
	[FALongitude] [float] NULL,
	[FAEstLotSqFt] [bigint] NULL,
	[FAOwnerTransactionId] [bigint] NULL,
	[MailForeignAddrInd] [varchar](1) NULL,
	[FAIsListedFlag] [char](1) NULL,
	[FAIsListedFlagDt] [varchar](8) NULL,
	[FAIsListedPriceRange] [varchar](25) NULL,
	[TPLatitude] [float] NULL,
	[TPLongitude] [float] NULL,
	[TPGeoStatusCode] [varchar](20) NULL,
	[FAGeoStatusCode] [varchar](20) NULL,
	[SumCommercialUnits] [int] NULL,
	[SitusGeoCodeResults] [varchar](30) NULL,
	[MailingGeoCodeResults] [varchar](30) NULL,
	[LienPosUpdateFlag] [varchar](1) NULL,
	[LienPosUpdateDate] [datetime] NULL,
	[TotalOpenLienAmt] [int] NULL,
	[TotalOpenLienNbr] [int] NULL,
	[VacantFlag] [varchar](1) NULL,
	[VacantFlagDate] [datetime] NULL,
	[AssessorLkupToken0] [varchar](50) NULL,
	[AssessorLkupToken1] [varchar](50) NULL,
	[SchoolDistrictName] [varchar](80) NULL,
	[AssessorLkupToken2] [varchar](50) NULL,
	[FADataArchiveDate] [datetime] NULL,
	[ConCurrMtg2Term] [varchar](3) NULL,
	[Mtg1Term] [varchar](3) NULL,
	[Mtg2Term] [varchar](3) NULL,
	[Mtg3Term] [varchar](3) NULL,
	[Mtg4Term] [varchar](3) NULL,
	[PrevMtg1Term] [varchar](3) NULL,
	[BankOwned] [varchar](1) NULL,
	[StoriesCode] [varchar](10) NULL,
	[StoriesNbrCode] [varchar](10) NULL,
	[BasementFinishSqFt] [varchar](11) NULL,
	[BasementUnfinSqFt] [varchar](11) NULL,
	[GarageFinishSqFt] [varchar](11) NULL,
	[GarageUnFinSqFt] [varchar](11) NULL,
	[AtticSqFt] [varchar](11) NULL,
	[AtticFinishSqFt] [varchar](11) NULL,
	[AtticUnfinSqFt] [varchar](11) NULL,
	[Mtg1EstPaymentAmt] [varchar](15) NULL,
	[Mtg1InterestRate] [varchar](6) NULL,
	[Mtg2EstPaymentAmt] [varchar](15) NULL,
	[Mtg2InterestRate] [varchar](6) NULL,
	[Mtg3EstPaymentAmt] [varchar](15) NULL,
	[Mtg3InterestRate] [varchar](6) NULL,
	[Mtg4EstPaymentAmt] [varchar](15) NULL,
	[Mtg4InterestRate] [varchar](6) NULL,
	[ConCurrMtg1InterestRate] [varchar](6) NULL,
	[ConCurrMtg2InterestRate] [varchar](6) NULL,
	[PrevMtg1InterestRate] [varchar](6) NULL,
	[MailingFIPS] [varchar](5) NULL,
	[DBSTaxAmount] [bigint] NULL,
	[DBSTaxYear] [varchar](4) NULL,
	[Mtg1EstLoanBalance] [int] NULL,
	[Mtg2EstLoanBalance] [int] NULL,
	[Mtg3EstLoanBalance] [int] NULL,
	[Mtg4EstLoanBalance] [int] NULL,
	[OldApnIndicator] [varchar](1) NULL,
	[PrevSaleDocumentType] [varchar](2) NULL,
	[SecondPrevSaleTransactionId] [bigint] NULL,
	[SecondPrevSaleRecordingDate] [varchar](8) NULL,
	[SecondPrevSalesPrice] [int] NULL,
	[ThirdPrevSaleTransactionId] [bigint] NULL,
	[ThirdPrevSaleRecordingDate] [varchar](8) NULL,
	[ThirdPrevSalesPrice] [int] NULL,
	[HouseFacingDirection] [varchar](2) NULL,
	[FARooftopLatitude] [float] NULL,
	[FARooftopLongitude] [float] NULL,
	[BuildingEstFootprintSqFt] [int] NULL,
	[BathTotalCalcEst] [numeric](5, 2) NULL,
	[DQOZ_TractType] [varchar](50) NULL,
	[DQOZ_ACSDataSource] [varchar](10) NULL,
	[VacantScore] [varchar](3) NULL,
	[CurrSalesPriceEst] [int] NULL,
	[DTDB_Ref_ID] [bigint] NULL
) ON [PRIMARY]


EXEC('USE ASSR

/*IF  EXISTS (SELECT * FROM [ASSR].sys.objects WHERE object_id = OBJECT_ID(N''[ASSR].[dbo].[Assr_BATCH]'') AND type in (N''U''))*/
DROP TABLE IF EXISTS [ASSR].[dbo].[Assr_BATCH]

		
/*IF  EXISTS (SELECT * FROM [ASSR].sys.objects WHERE object_id = OBJECT_ID(N''[ASSR].[dbo].[Assr_OLD]'') AND type in (N''U''))*/
DROP TABLE IF EXISTS [ASSR].[dbo].[Assr_OLD]


CREATE TABLE [ASSR].[dbo].[Assr_BATCH](
	[AssrID] [numeric](12, 0) NOT NULL,
	[FIPS] [int] NOT NULL,
	[REF_ID] [numeric](12, 0) NOT NULL,
	[UNFORMATTED_APN] [varchar](45) NULL,
	[APN_SEQUENCE_NBR] [char](3) NULL,
	[FORMATTED_APN] [varchar](60) NULL,
	[ORIGINAL_APN] [varchar](45) NULL,
	[PREVIOUS_PARCEL_NBR] [varchar](45) NULL,
	[P_ID_IRIS_FRMTD] [varchar](60) NULL,
	[ALTERNATE_APN] [varchar](60) NULL,
	[ACCOUNT_NBR] [varchar](15) NULL,
	[SITUS_HOUSE_NBR] [varchar](10) NULL,
	[SITUS_HOUSE_NBR_#2] [varchar](10) NULL,
	[SITUS_HOUSE_NBR_SUFFIX] [varchar](10) NULL,
	[SITUS_DIRECTION] [char](2) NULL,
	[SITUS_STREET_NAME] [varchar](30) NULL,
	[SITUS_MODE] [char](5) NULL,
	[SITUS_QUADRANT] [char](2) NULL,
	[SITUS_UNIT_NBR] [char](6) NULL,
	[SITUS_CITY] [varchar](40) NULL,
	[SITUS_STATE] [char](2) NULL,
	[SITUS_ZIP_CODE] [char](9) NULL,
	[SITUS_CARRIER_CODE] [char](4) NULL,
	[OWN1_LAST_NAME] [varchar](60) NULL,
	[OWN1_FIRST_NAME_M_I] [varchar](32) NULL,
	[OWN1_SUFFIX] [char](5) NULL,
	[Situs_Street_Num_Fmt] [varchar](20) NULL,
	[Situs_Zip_5] [varchar](5) NULL,
	[Lic_PropertyID] [bigint] NULL,
	[Lic_StreetNum] [varchar](20) NULL,
	[Lic_StreetName] [varchar](50) NULL,
	[Lic_APN] [varchar](50) NULL,
	[Lic_OwnerLastName] [varchar](80) NULL,
	[Lic_Zip5] [varchar](5) NULL,
	[Match_StreetNumber] [varchar](1) NULL,
	[Match_StreetName] [varchar](1) NULL,
	[Match_Zip5] [varchar](1) NULL,
	[Match_APN] [varchar](1) NULL,
	[Match_Owner] [varchar](1) NULL,
	[Match_Score] [varchar](10) NULL,
	[Lic_AccountNbr] [varchar](50) NULL,
	[Match_AccountNbr] [varchar](1) NULL,
	[Lic_Fips] [nchar](5) NULL,
	[Lic_DTDB_Match_Flag] [nchar](1) NULL,
	[PtnFmtToLicApn] [varchar](500) NULL,
	[PtnUnFmtToLicApn] [varchar](500) NULL,
	[Archived_REF_ID] [varchar](1) NULL
) ON [PRIMARY]

')

END
