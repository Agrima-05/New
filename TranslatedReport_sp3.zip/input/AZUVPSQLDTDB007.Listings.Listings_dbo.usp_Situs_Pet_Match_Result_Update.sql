/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Situs_Pet_Match_Result_Update | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Situs_Pet_Match_Result_Update] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation


Notes 
1. the where clause need to limit the data to the daily input

DECLARE @Error_Msg varchar(500),
		@ERROR varchar(500)

EXEC	Listings.Listings_dbo.usp_Combine_Daily_Adds_and_Snapshot
		@ERROR = @ERROR OUTPUT

 SET  @Error_Msg = @ERROR

--SELECT ? = @Error_Msg 


******************************************************************************************************************/
--declare @fileid INT = 1 ,@ERROR VARCHAR(500) --OUTPUT
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Situs_Pet_Match_Result_Update: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'

	UPDATE [Listings].[Listings_dbo].[a]
	SET a.Match_fips = b.Match_fips
		,a.Ref_id = b.Ref_id
		,a.Match_code = b.Match_code
	FROM [LISTINGS].[Listings_tmp].[Listings_Raw_Std_Address_wrk] a WITH (
			NOLOCK
			,INDEX (PK_IDX_Listings_Rowid_address)
			)
	INNER JOIN [LISTINGS].[listings_tmp].[Situs_Std_Address_Result] b WITH (
			NOLOCK
			,INDEX (idx_file_id_id)
			) ON b.fileid = @fileid
		AND b.id = a.row_id
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


