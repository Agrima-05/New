/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.ProcessARB | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
CREATE PROCEDURE [PET].[dbo].[ProcessARB] @fips VARCHAR(5) = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Henk	4/14/2022	Initial version
paul	7/31/22		add begin transaction logic
******************************************************************************************************************/
BEGIN
	BEGIN TRY
		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'ProcessARB'
			,N'Started'

		BEGIN TRANSACTION

		SET NOCOUNT ON;

		DECLARE @sqlcmd VARCHAR(max)

		SET @sqlcmd = 
			'
		begin transaction
		UPDATE p
		SET LEGAL_DESC_APN_ARB = a.legal_desc_apn_arb
		FROM [PET].[dbo].[PET_NEO_LEGALS] p
		OUTER APPLY (
			SELECT label1
				,value1
				,label2
				,value2
				,label3
				,value3
				,label4
				,value4
				,label5
				,value5
				,label6
				,value6
				,label7
				,value7
				,label8
				,value8
				,label9
				,value9
				,label10
				,Value10
				,label11
				,value11
				,label12
				,value12
				,label13
				,value13
				,label14
				,value14
				,label15
				,value15
				,label16
				,value16
				,label17
				,value17
				,label18
				,value18
				,label19
				,value19
				,label20
				,value20
				,label21
				,value21
				,label22
				,value22
				,label23
				,value23
		) n
		OUTER APPLY (
			SELECT NEO_APN AS legal_desc_apn
		) n2
		outer apply (
			SELECT [NEO_LAND_TYPE] AS dl_land_type
		) b
		OUTER APPLY (
			SELECT iif(dl_land_type = ''SB'' AND isnull(n.Label1, '''') = ''Book'' AND substring(isnull(n.value1, ''''),1,1) = ''A'',substring(isnull(n.value1, ''''),2,10),n.value1) as _arb_book
		) arb
		outer apply (
			SELECT ' 
			+ [PET].[dbo].[fn_parseArb](@fips) + '
	  ) a
		WHERE FIPS=
	  ' + @fips + '
	  commit'

		--SELECT @sqlcmd
		EXEC (@sqlcmd)

		COMMIT

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'ProcessARB'
			,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		--ROLLBACK
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


