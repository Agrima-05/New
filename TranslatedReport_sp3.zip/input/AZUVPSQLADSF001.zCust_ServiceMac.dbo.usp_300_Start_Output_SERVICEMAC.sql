SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_300_Start_Output_SERVICEMAC]

AS
BEGIN
	
	SET NOCOUNT ON;

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUTCustomerID1][varchar](250)NULL,
			[INPUTCustomerID2][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip5][varchar](250)NULL,
			[Zip4][varchar](250)NULL,
			[FIPS State Code][varchar](250)NULL,
			[FIPS County Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[AVM Coverage][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[FinalValue][varchar](250)NULL,
			[HighValue][varchar](250)NULL,
			[LowValue][varchar](250)NULL,
			[ConfidenceScore][varchar](250)NULL,
			[StandardDeviation][varchar](250)NULL,
			[ValuationDate][varchar](250)NULL,

			-----Internal - REMOVE---
			[FinalValue_OLD][varchar](250)NULL


		) ON [PRIMARY]


		INSERT INTO [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],
		[INPUTCustomerID1],
		[INPUTCustomerID2],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		,[FinalValue_OLD]
		,[WORK_REF_ID]
		,[PROPERTYID])
		

		------Need to build this part out based on customer input file not yet received
		Select 
		[UniqueId]
		,[CustomerID1]
		,[CustomerID2]
		,[Address]
		,[City]
		,[State]
		,[Zip]
		,[FinalValue]
		,REF_ID
		,PROPERTYID
		
		--convert(bigint,[LoanNumber] )     
		--,REPLACE(LTRIM(RTRIM(REPLACE([PropertyStreetAddress],'’','') )) ,'  ',' ')
		--,LTRIM(RTRIM([CityName] ))     ,[PropertyAlphaStateCode]      ,[PropertyZipCode]
		--FROM [dbo].[INPUT_RAW_ServiceMac_20201219]
		--Select * 
		FROM [zCust_ServiceMac].[dbo].[INPUT_MONITOR]
		where REcordIndicator not like 'D'
		and UniqueID is not null
		


		Select top 10 * From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]

		
		UPDATE [zCust_ServiceMac].[dbo].[a] 
		SET 
		--a.WORK_REF_ID = c.REF_ID
		--,A.PropertYID = C.PropertYID
		--,
		A.FIPS = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		,A.[FIPS State Code] = left(CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END,2)
		,A.[FIPS County Code] = right(CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END,3)
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ServiceMac].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT KEY] = c.RAW_ID

		
		Update [zCust_ServiceMac].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip5] = c.Zip 
		, a.[Zip4] = c.Zip4
		, a.[Report Date] = Convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT KEY] = c.RAW_ID
	
		Select count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		Select count(*) From [zCust_ServiceMac].[dbo].[a_ASP_IN_STD]
		
		--Select top 1000 A.FIPS, A.PROPERTYID, A.[INPUT Address],A.[Property Address], B.SitusStdFullStreetAddress From x_Custom_OUTPUT as A 
		--join data.dbo.Property as B With(NOLOCK) on A.PROPERTYID = B.PropertyID
		--where  [Property Address] not like '%' + left(B.SitusStdFullStreetAddress,4) + '%'


		Update [zCust_ServiceMac].[dbo].[a]
		set [AVM Coverage] = AVMActive
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [global].[dbo].[county] b  with(NOLOCK) ON a.FIPS = b.FIPSCODE

		

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] 
		SET [AVM Coverage] = CASE WHEN [AVM Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_ServiceMac].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT KEY] = b.Raw_ID

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN PROPERTYID is not null and PROPERTYID not like '0'
		and PROPERTYID not like ''
		THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_ServiceMac].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		--Select count(*)
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a join [zCust_ServiceMac].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT KEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'



		-----20210107 - Per EC - If value changed then Event Found - else populate OLD info & Event Not Found
		UPDATE [zCust_ServiceMac].[dbo].[A]
		SET A.[FinalValue] = convert(int,convert(Money,B.final_value))
		,A.ConfidenceScore = B.score
		,A.[LowValue] = convert(int,convert(Money,B.low))
		,A.[HighValue] = convert(int,convert(Money,B.high))
		,A.[StandardDeviation] = B.STDEV
		,A.[ValuationDate] = Convert(date,B.Valuation_date)
		,[Event Status] = 'Event Found'
		--Select A.[INPUT KEY], A.FinalValue_OLD, convert(int,convert(Money,B.final_value)), B.Valuation_DAte
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[AVM] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and a.PROPERTYID = b.PROPERTYID
		join [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as C on A.[INPUT KEY] = C.UniqueId
		where (convert(int,convert(Money,A.[FinalValue_OLD]))  <> convert(int,convert(Money,B.final_value))
		or A.[FinalValue_OLD] is null or A.[FinalValue_OLD] like '')
		and a.PROPERTYID is not null
		and B.final_value > 0

		Select top 100 * From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]

		--Select top 100 * From data.dbo.AVM as B with(NOLOCK) 


		UPDATE [zCust_ServiceMac].[dbo].[A]
		SET A.[FinalValue] = convert(int,convert(Money,B.final_value))
		,A.ConfidenceScore = B.score
		,A.[LowValue] = convert(int,convert(Money,B.low))
		,A.[HighValue] = convert(int,convert(Money,B.high))
		,A.[StandardDeviation] = B.STDEV
		,A.[ValuationDate] = Convert(date,B.Valuation_date)
		,[Event Status] = 'Event Found'
		--Select A.[INPUT KEY], A.FinalValue_OLD, convert(int,convert(Money,B.final_value))
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[AVM] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and a.WORK_REF_ID = b.REF_ID
		join [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as C on A.[INPUT KEY] = C.UniqueId
		where (convert(int,convert(Money,A.[FinalValue_OLD]))  <> convert(int,convert(Money,B.final_value))
		or A.[FinalValue_OLD] is null or A.[FinalValue_OLD] like '')
		and a.WORK_REF_ID is not null
		AND A.FinalValue is null



		
		--Select top 100 * From data.dbo.AVM as B with(NOLOCK) 

		--Update x_Custom_OUTPUT
		--SET [Event Status] = CASE WHEN [FinalValue] is not null and [FinalValue] not like ''
		--and [FinalValue] not like '0'
		--THEN 'Event Found' ELSE 'Event Not Found' END

		UPDATE [zCust_ServiceMac].[dbo].[A]
		SET A.[FinalValue] = B.FinalValue
		,A.ConfidenceScore = B.ConfidenceScore
		,A.[LowValue] = B.[LowValue]
		,A.[HighValue] = B.[HighValue]
		,A.[StandardDeviation] = B.[StandardDeviation]
		,A.[ValuationDate] = B.[ValuationDate]
		,[Event Status] = 'Event Not Found'
		--Select * 
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as B with(NOLOCK) 
		on A.[INPUT KEY] = B.UniqueId
		where A.[FinalValue] is null or A.[FinalValue] like ''

		--Select PropertyID, PropertyClassID From data.dbo.Property with(NOLOCK)
		--where PropertyID = '119736347'

		Select [AVM Coverage], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		Group by [AVM Coverage]

		Select AddressStandardization, count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		Group by AddressStandardization

		Select [Property Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		Group by [Event Status]


		Select * From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT]
		where [Property Status] like '%not%' 

		--Select B.StdLandUseCode, B.PropertyClassID,C.CodeDesc,B.YearBuilt, A.* From x_Custom_OUTPUT as A 
		--join data.dbo.Property as B with(NOLOCK) on 
		--A.PROPERTYID = B.PropertyID
		--join global.dbo.lkup_STD_LUSE as C
		--on B.StdLandUseCode = C.BKFSCODE
		--where A.FinalValue is null
		--Order by B.PropertyClassID

		--Select A.FIPS, A.PropertyID, A.FinalValue From data.dbo.vAVM_STD as A with(NOLOCK)
		--left outer join data.dbo.AVM as B with(NOLOCK) on A.FIPS = B.FIPS
		--and A.PropertyID = B.PropertyID
		--where B.PropertyID is null
		--and A.PropertyID is not null

		Select A.[INPUT KEY], A.FinalValue, A.FinalValue_OLD, B.DATE_RECEIVED
		--,B.FinalValue
		 From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] as A
		 join [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as B with(NOLOCK) on A.[INPUT KEY] = B.UniqueId
		  --join zzz_SERVICEMAC_20210113_OUTPUT as B on 		A.[INPUT KEY] = B.[INPUT KEY]
		where A.[Event Status] like 'Event Found'
		Order by B.DATE_RECEIVED desc


		Select A.[INPUT KEY], A.FinalValue, A.FinalValue_OLD, B.DATE_RECEIVED
		--,B.FinalValue
		 From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT] as A
		 join [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as B with(NOLOCK) on A.[INPUT KEY] = B.UniqueId
		  --join zzz_SERVICEMAC_20210113_OUTPUT as B on 		A.[INPUT KEY] = B.[INPUT KEY]
		where A.[Event Status] like 'Event Not Found'
		Order by B.DATE_RECEIVED desc


	

END





