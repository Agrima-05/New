SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [zCust_Sharonview].[dbo].[usp_300_Start_Output_SharonView]

AS
BEGIN
	
	SET NOCOUNT ON;


----Solution Note:
----AddRecordEventStatus: When a new portfolio add record is included, this will be set to Y and tracked for billing purposes
----CurrentOwnerEventStatus: This will be used to define when an Ownership Change has occurred/not occurred
----LienPositionEventStatus: This will be used to define when a change to the FA Lien position has occurred/not occurred
----Monitoring Update: Return data fields only when there is an Owner Change or Lien Position Change??????????????????????????????????????????????????????
----Initial extract of newly added records:
	-----How to set Event Status fields other than the new record enevt status field??
----Mortgage Match Criteria: Date +/- 120 days; Amount +/- 5%; If Multiples found, return closest in date/amount, return 1 matched mortgage only

	
----	My Notes:
----1)	If their input mtg is no longer open this is still considered a lien position change
----2)	$1K is in addition to others
----3)	We are monitoring for their input mortgage to change lien position as well as owner change
----a.	Pricing review - $0.75 for portfolio add PLUS $1K monthly monitor fee PLUS $1 per event found (owner change, lien position change or both)
----b.	Initial billing will be Count of records 0.75 ONLY
----c.	Ongoing – Event Found will be $1.00 per Event PLUS $1000 monitor fee PLUS $0.75 for any NEWLY Added records 


		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID]  [varchar](250) NULL,
		
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Start Date][varchar](250)NULL,
			[Deed Thru Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Start Date][varchar](250)NULL,
			[Mortgage Thru Date][varchar](250)NULL,
			[AddRecordEventStatus][varchar](250)NULL,
			[CurrentOwnerEvent Status][varchar](250)NULL,
			[LienPositionEvent Status][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Current Owner Change Date][varchar](250)NULL,
			[Current Owner Change Doc Type][varchar](250)NULL,
			[Input Origination Date][varchar](250)NULL,
			[Input Origination Amount][varchar](250)NULL,
			[Recording Date][varchar](250)NULL,
			[Document #][varchar](250)NULL,
			[Amount ][varchar](250)NULL,
			[Lender][varchar](250)NULL,
			[INPUT Mortgage Lien Position][varchar](250)NULL,
			[FA Lien Position][varchar](250)NULL,
			
			--------Internal
			[MTGTransactionID_DOCID][varchar](250)NULL,
			[FLANK_OR_DTDB][varchar](250)NULL

		) ON [PRIMARY]

	
		

	
	SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] (
		[INPUT Unique ID],
		[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		[Input Origination Date],
		[Input Origination Amount],
		[INPUT Mortgage Lien Position]
		,[Recording Date]
		,[Document #]
		,[Amount ]
		,[Lender]
		,[FA Lien Position]
		,[MTGTransactionID_DOCID]
		,[FLANK_OR_DTDB]
		)

		

		Select 
		[UNique_ID]
		,LOANID
		,ADDRESS
		,CITY
		,[State]	
		,[Zip]
		,convert(date,[Origination_Date])
		,convert(money,Origination_Amount)
		,[Lien_Position]
		--Select *
		--from (Select A.*  From INPUT_RAW_20241024_2 as A join 
		-- (Select  [UNique_ID], count(*) T From INPUT_RAW_20241024_2
		--Group by [UNique_ID]
		--having count(*) = 1)B on A.[UNique_ID] = B.[UNique_ID])A
		,[FA_Recording Date]
		,[FA_Document #]
		,[FA_Amount ]
		,[FA_Lender]
		,FA_LIENPOS
		,[FA_MTGTransactionID_DOCID]
		,[FA_FLANK_OR_DTDB]
	   FROM 	[zCust_Sharonview].[dbo].[INPUT_MONITOR]
		Where ISNULL([UNique_ID],'') not like ''

		



	   Select  * From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
	  

	   

		UPDATE [zCust_Sharonview].[dbo].[a] 
		SET 
		A.PropertyID = C.PropertyID
			,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Sharonview].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT Unique ID] = c.RAW_ID
	



		
		Update [zCust_Sharonview].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Sharonview].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Unique ID] = c.RAW_ID


		
		Update [zCust_Sharonview].[dbo].[A]
		Set 
		a.[Property Address] = B.SitusSTDFUllStreetAddress
		, a.City = B.SitusSTDCity
		, a.[State] = B.SitusSTDState
		, a.[Zip Code] = B.SitusSTDZip5 + B.SitusSTDZip4
		, a.Fips = CASE WHEN LEN(B.FIPS) = 4 THEN '0' + B.FIPS ELSE B.FIPS END
		 ,A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		  ,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		 ,A.[Current Owner Change Date] = case when B.faownershipupdatedt is null then convert(date,B.CurrSaleRecordingDate)   
										else convert(date,B.faownershipupdatedt) end
		 ,A.[Current Owner Change Doc Type] = case when B.faownershipupdatedt is null then B.CurrentSaleTransactionId else B.faownertransactionid end
		--Select B.*
		From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as A join [data].[dbo].[Property] as B 
		with(NOLOCK) on A.FIPS = B.FIPS
		and A.PROPERTYID = B.PROPERTYID



		Update [zCust_Sharonview].[dbo].[A]
		Set
		A.AddRecordEventStatus = 'Y'
		From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as A join [zCust_Sharonview].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT Unique ID] = B.Unique_ID
		where convert(date,B.DATE_ADDED) = convert(date,Getdate())


		----on initial extract for newly added records = how should each of these be set:

		----1.	[CurrentOwnerEvent Status] = If we return an Owner Name on an initial extract then this is Event Found?
		----2.	[LienPositionEvent Status] = If we return a lien position on an initial extract then this is Event Found?


		Update [zCust_Sharonview].[dbo].[A]
		Set
		A.[CurrentOwnerEvent Status] = case when 
			(ISNULL(A.[Current Owner 1],'') <> ISNULL(B.FA_OWNERNAME,'') OR	ISNULL(A.[Current Owner 2],'') <> ISNULL(B.[FA_OWNERNAME_2],'')) 
			AND AddRecordEventStatus is null	then 'Event Found' 
		when 
			(ISNULL(A.[Current Owner 1],'') not like '' 	OR	ISNULL(A.[Current Owner 2],'') not like '') 
			AND AddRecordEventStatus like 'Y' then 'Event Found' 
		else 'Event Not Found' end
		--Select A.[Current Owner 1],A.[Current Owner 2],B.FA_OWNERNAME,B.[FA_OWNERNAME_2]
		From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as A join [zCust_Sharonview].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT Unique ID] = B.Unique_ID






		Update [zCust_Sharonview].[dbo].[a]
		set 
		A.[Deed Coverage Status] = B.DeedActive
		,A.[Deed Start Date] = case when B.DeedMinRecordDate like '' then NULL else convert(date,B.DeedMinRecordDate) end
		,A.[Deed Thru Date] = case when B.DeedMAXRECORDDATE like '' then NULL else convert(date,B.DeedMAXRECORDDATE) end
		
		,A.[Mortgage Coverage Status] = B.SamActive
		,A.[Mortgage Start Date] = case when B.SAMMinRecordDate like '' then NULL else convert(date,B.SAMMinRecordDate) end
		,A.[Mortgage Thru Date] = case when B.SAMMAXRECORDDATE like '' then NULL else convert(date,B.SAMMAXRECORDDATE) end

		
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a 
			JOIN [global].[dbo].[county] b  with(NOLOCK)
			ON convert(int,a.FIPs) = b.FIPsCode


		
		Select * from [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]

			---------------------------20240614 - Changed to use FLANK first to correspond with FLANK open lien also being populated-------------


				------***********--------START WITH --DTDB----***********---------------------------------------------------------------------
		
		
		Update [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')
	

		
	UPdate [zCust_Sharonview].[dbo].[w_transhist_FLANK]
	Set Touse = null 
	where Touse is not null

	

	
	--------------------------------------------------------------------------------------------------------------------






	

		--------Added 20200401 because input name may be OBRIEN but our recorded name is O BRIEN so using last 4 of name---
		--UPDATE w_transhist_FLANK
		--SET ToUse = 'Y' 
		----Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date],O.[INPUTBorrowerLastName], P.RecordingDate, P.Value, P.BuyerBorrower, P.DocumentNbr 
		--FROM x_Custom_OUTPUT o Join w_transhist_FLANK p
		--	ON O.[INPUT Unique ID] = P.RAW_ID
		--	WHERE ISNULL(O.[Recording Date],'') like '' AND 
		--	ISNULL(O.[INPUT Origination Date],'') like '' AND 
		--	O.[INPUT Unique ID] not in (Select distinct RAW_ID from w_transhist_FLANK where ToUse = 'Y') and P.ToUse is null and p.Doc_Src_Ind = 'M'
		--		and INPUTBorrowerLastName is not null
		--			and Convert(MONEY,o.[INPUT Origination Amount]) = Convert(MONEY,p.Value)
		--					and buyerborrower LIKE '%' + right(INPUTBorrowerLastName,4) + '%'
		--						AND p.DocumentType not like 'MO'


		----+/- 120 days & +/- 5% ----
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'Y' 
		--Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date],O.[INPUTBorrowerLastName], P.RecordingDate, P.Value, P.BuyerBorrower, P.DocumentNbr 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			WHERE ISNULL(O.[Recording Date],'') like ''  AND 
			O.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where ToUse = 'Y') and  
			p.Doc_Src_Ind = 'M'
				and Convert(MONEY,o.[INPUT Origination Amount]) 
				between convert(money,p.Value) 	- (convert(money,p.Value) * .05  ) and convert(money,p.Value) 
				+ (convert(money,p.Value) * .05 )
					and (convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,P.RecordingDate)-120 
					and convert(DATETIME,P.RecordingDate)+ 120
					   or convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,DocDate)-120  
					  and convert(DATETIME,DocDate)+ 120
					  )
						AND p.DocumentType not like 'MO'
						



	
			Select O.[INPUT Unique ID],O.PROPERTYID, O.[INPUT Origination Amount], O.[INPUT Origination Date]--,O.[INPUTBorrowerLastName]
			, P.RecordingDate, P.DocDate,P.Value, P.BuyerBorrower, P.DocumentNbr,P.DocumentType
			,ToUse
			,P.DOC_ID
			FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			join 
				(Select RAW_ID, count(*) as TOTAL From  [zCust_Sharonview].[dbo].[w_transhist_FLANK]
				where ToUse = 'Y' 
				Group by RAW_ID
				having count(*) > 1) B on 
				P.RAW_ID = B.RAW_ID
				where P.ToUse = 'Y'
				and P.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where  ToUse = 'X' )
			Order by P.RAW_ID



	
		
			Select RAW_ID,ToUse,count(*) From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			where ToUse like 'Y'
			Group by RAW_ID,ToUse
			having count(*) > 1

			Select RAW_ID,ToUse,count(*) From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			where ToUse like 'Y'
			Group by RAW_ID,ToUse


		----------------START HERE--------------

		-----Added 20200330 to dedup where Lien Pos is populated----
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,P.Doc_ID, P.Lien_Pos from [zCust_Sharonview].[dbo].[w_transhist_FLANK] P 
				join 
					(Select  P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
					WHERE ToUse = 'Y'
					Group by P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID and D.DocumentNbr = P.DocumentNbr
					and D.RecordingDate = P.RecordingDate and P.Value = D.Value
					
					where ToUse = 'Y'
					and P.Lien_Pos >0)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.Doc_ID
			WHERE ToUse = 'Y' and T.Lien_Pos > 0


		-----Added 20200330 to dedup dupped doc numbers----
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] P 
				join 
					(Select  P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
					WHERE ToUse = 'Y'
					Group by P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID and D.DocumentNbr = P.DocumentNbr
					and D.RecordingDate = P.RecordingDate and P.Value = D.Value
					where ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'


		------Dedup where no doc number-----
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] P 
				join 
					(Select  P.RAW_ID, P.RecordingDate, P.Value
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
					WHERE ToUse = 'Y' AND ISNULL(P.DocumentNbr,'') like ''
					Group by P.RAW_ID, P.RecordingDate, P.Value
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID 
					and D.RecordingDate = P.RecordingDate and P.Value = D.Value
					where  ISNULL(P.DocumentNbr,'') like ''
					and ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where  ToUse = 'X' )

	 -----Dedup Max Doc ID
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] P 
				join 
					(Select  P.RAW_ID, P.DocDate, P.Value
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
					WHERE ToUse = 'Y' 
					Group by P.RAW_ID, P.DocDate, P.Value
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID 
					and D.DocDate = P.DocDate and P.Value = D.Value
					where  ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where  ToUse = 'X' )


	


		Select O.FIPS,O.[INPUT Unique ID], T.REF_ID,O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate,T.DocDate, T.DocumentNbr,T.Value , T.Doc_Src_Ind, T.Doc_Id
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_transhist_FLANK] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_transhist_FLANK] 
		where ToUSe = 'Y'
		Group by RAW_ID
		having count(*) > 1)A)
		and touse = 'Y'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]

		

		
		-------------------------------------------
		--------RETURN RECORD WITH MAX RECORDING DATE--------
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.* 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
			(Select A.RAW_ID as RAWID,MAX(ABS(DATEDIFF(day,coalesce(A.DocDate,A.REcordingDate)
			,convert(date,B.[INPUT Origination Date])))) as MINDATE From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
			where ToUse = 'Y'
			and B.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where ToUse like 'X')
			Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and ABS(DATEDIFF(day,coalesce(T.DocDate,T.REcordingDate),O.[INPUT Origination Date])) = P.MINDATE
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where  ToUse = 'X' )
			--Order by O.[INPUT Unique ID]


			
			--------RETURN RECORD WITH MAX DOCID DATE--------
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'Y' 
		--Select O.[INPUT Unique ID], O.[INPUT Amount], O.[INPUT Origination Date], T.* 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select A.RAW_ID as RAWID,MIN(DOC_ID) as MINID From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
				as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
				where ToUse = 'X'
				and B.[INPUT Unique ID]  in 
				(Select RAW_ID from 
				(Select RAW_ID, count(*) as TOTAL from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where ToUse like 'X'
				Group by RAW_ID
				having count(*) > 1)A)
				Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and T.DOC_ID = P.MINID
			WHERE ToUse = 'X'


			
		Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate, T.DocDate,T.DocumentNbr,T.Value , T.Doc_Src_Ind
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_transhist_FLANK] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_transhist_FLANK] 
		where ToUSe = 'X'
		Group by RAW_ID
		having count(*) > 1)A)
		and touse = 'X'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]


		Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate, T.DocumentNbr,T.Value , T.Doc_Src_Ind
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_transhist_FLANK] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_transhist_FLANK] 
		where ToUSe = 'X'
		Group by RAW_ID
		having count(*) = 1)A)
		and touse = 'X'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]


		
		UPDATE [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		SET ToUse = 'X' 
		--Select O.[INPUT Origination Date], T.REcordingDate, DATEDIFF(day,T.REcordingDate,O.[INPUT Origination Date]) 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_transhist_FLANK] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
			(Select A.RAW_ID as RAWID,MIN(ABS(DATEDIFF(day,A.REcordingDate,convert(date,B.[INPUT Origination Date])))) as MINDATE From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
			where ToUse = 'Y'
			and B.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where ToUse like 'X')
			Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and ABS(DATEDIFF(day,T.REcordingDate,O.[INPUT Origination Date])) = P.MINDATE
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where  ToUse = 'X' )
			and O.[INPUT Unique ID]  in 
			(Select RAW_ID from 
			(Select RAW_ID, DocDate, count(*) as TOTAL from [zCust_Sharonview].[dbo].[w_transhist_FLANK] where ToUse like 'Y'
			Group by RAW_ID, DocDate
			having count(*) > 1)A)

			--Select ABS(DATEDIFF(day,T.REcordingDate,'2016-04-12')) ,* From w_transhist_FLANK T where RAW_ID = '6374804'
			--and ToUse is not null

			--UPdate w_transhist_FLANK
			--Set ToUse = 'Y'
			--where RAW_ID = '6374804'
			--and ToUse is not null

	

	
			
		
			UPDATE [zCust_Sharonview].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_Sharonview].[dbo].[w_transhist_FLANK] t WHERE ToUse = 'X' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID


		Select RAW_ID,count(*) From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		WHERE ToUse = 'X'
		Group by RAW_ID
		having count(*) > 1


		Select A.* From [zCust_Sharonview].[dbo].[w_transhist_FLANK] as A 
		join (Select RAW_ID,count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		WHERE ToUse = 'X'
		Group by RAW_ID
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'X'
	

		---------------------------------------------------START HERE-------------------------------------------------------------

			Select O.[INPUT Unique ID],O.WORK_REF_ID,O.PROPERTYID, O.[INPUT Origination Amount], O.[INPUT Origination Date]
			--,O.[INPUTBorrowerLastName]
			, P.RecordingDate, P.Value, P.BuyerBorrower, P.DocumentNbr
			,ToUse
			,P.DOC_ID
			FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_transhist_FLANK] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			join 
				(Select RAW_ID, count(*) as TOTAL From  [zCust_Sharonview].[dbo].[w_transhist_FLANK]
				where ToUse = 'X' 
				Group by RAW_ID
				having count(*) > 1) B on 
				P.RAW_ID = B.RAW_ID
				where P.ToUse = 'X'
			Order by P.RAW_ID
				
			
	
			Select ToUse,count(*) From [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			Group by ToUse

			-----View unselected records
			Select RAW_ID, RecordingDate, DocDate,DocumentNbr, Value, Doc_Src_Ind ,TOUSE
			From [zCust_Sharonview].[dbo].[w_transhist_FLANK] where RAW_ID in (
			Select RAW_ID from  [zCust_Sharonview].[dbo].[w_transhist_FLANK]
			where ToUse = 'Y')
			and TOUSE is not null
			Order by RAW_ID

			

		Truncate table w_transhist_FLANK_II

		INSERT INTO [zCust_Sharonview].[dbo].[w_transhist_FLANK_II]
		SELECT *
		FROM     [zCust_Sharonview].[dbo].[w_transhist_FLANK]
		WHERE  (ToUse = 'X')


			UPDATE [zCust_Sharonview].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_Sharonview].[dbo].[w_transhist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate ASC) AS RowNum
				FROM 
			[zCust_Sharonview].[dbo].[w_transhist_FLANK_II] t WHERE ToUse = 'X' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID

		Select * FRom [zCust_Sharonview].[dbo].[w_transhist_FLANK_II]
		where RecordNumber is null

		
		Select RAW_ID,  count(*) FRom [zCust_Sharonview].[dbo].[w_transhist_FLANK_II]
		Group by RAW_ID
		having count(*) > 1



		Select RAW_ID, RecordNumber, count(*) FRom [zCust_Sharonview].[dbo].[w_transhist_FLANK_II]
		Group by RAW_ID, RecordNumber
		having count(*) > 1
			
			

			UPDATE [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] 
			SET 
			[Recording Date] = a.RecordingDate
			,[Amount ] = Value
			,[Document #] = DocumentNbr
			,[Lender] = SellerLender
			,[FA Lien Position]  = A.Lien_Pos
			,[MTGTransactionID_DOCID] = A.Doc_Id
			,[FLANK_OR_DTDB] = 'F'
			--Select A.RAW_ID, A.Doc_ID,A.Lien_Pos
			From [zCust_Sharonview].[dbo].[w_transhist_FLANK_II] a with(NOLOCK) JOIN [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] b with(NOLOCK)
			on A.RAW_ID = B.[INPUT Unique ID]
			JOIN [zCust_Sharonview].[dbo].[INPUT_IN] c with(NOLOCK)
			ON b.[INPUT Unique ID] = c.[INPUTKey]
			WHERE b.[Recording Date] is NULL and  a.Doc_Src_Ind = 'M' 
			and A.RecordNumber = 1


			--------------------Update Lien Position for previously matched Mortgage---------
			UPDATE [zCust_Sharonview].[dbo].[B] 
			SET 
			B.[FA Lien Position]  = A.Lien_Pos
			,[MTGTransactionID_DOCID] = A.Doc_Id
			,[FLANK_OR_DTDB] = 'F'
			--Select A.RAW_ID, A.Doc_ID,A.Lien_Pos,B.[FA Lien Position] 
			From [zCust_Sharonview].[dbo].[w_transhist_FLANK] a with(NOLOCK) JOIN [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] b with(NOLOCK)
			on A.RAW_ID = B.[INPUT Unique ID]
			And A.DOC_ID = B.[MTGTransactionID_DOCID]
			WHERE  a.Doc_Src_Ind = 'M' 
			and B.FLANK_OR_DTDB like 'F'
			AND ISNULL(B.[FA Lien Position] ,'') <> ISNULL(A.Lien_Pos ,'')
			

		----------------------------------Find Input Mortgage-----------------------


			------***********--------BACKFILL ONLY WITH DTDB where Mtg was not matched in FLANK----***********---------------------------------------------------------------------
		
		Update [zCust_Sharonview].[dbo].[w_TransHist] SET toUse = NULL
		Update [zCust_Sharonview].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')


		--Select * From [w_TransHist_DEDUP]

		Truncate table [w_TransHist_DEDUP]

		Insert into [zCust_Sharonview].[dbo].[w_TransHist_DEDUP]([Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,DocumentNbr
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      ,[BuyerBorrowerLastName]
      ,[BuyerBorrowerFirstName]
      ,[SellerLenderLastName]
      ,[SellerLenderFirstName]
      --,[TitleCompanyName]
      ,[Updated_Date]
      ,[MTG_Term]
      ,[MTG_TermType]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Rate_Type]
      ,[RAW_ID]
      ,[DocDate]
	  --,Assignor	
	  --,Assignee
	  )
		Select [Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,REPLACE(REPLACE(REPLACE(REPLACE(DocumentNbr,'-','.'),'..','.'),' ',''),'/','.')
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      ,[BuyerBorrowerLastName]
      ,[BuyerBorrowerFirstName]
      ,[SellerLenderLastName]
      ,[SellerLenderFirstName]
      --,[TitleCompanyName]
      ,[Updated_Date]
      ,[MTG_Term]
      ,[MTG_TermType]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Rate_Type]
      ,[RAW_ID]
      ,[DocDate]
      --,[Assignor]
      --,[Assignee] 
	  --,BORROWER1FULLNAME
	  --,BORROWER2FULLNAME
	  --Select * 
	  From [zCust_Sharonview].[dbo].[w_TransHist]


	  Truncate table [w_TransHist]

	  Insert into [zCust_Sharonview].[dbo].[w_TransHist]([Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,DocumentNbr
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      ,[BuyerBorrowerLastName]
      ,[BuyerBorrowerFirstName]
      ,[SellerLenderLastName]
      ,[SellerLenderFirstName]
      --,[TitleCompanyName]
      ,[Updated_Date]
      ,[MTG_Term]
      ,[MTG_TermType]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Rate_Type]
      ,[RAW_ID]
      ,[DocDate])
	  Select [Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,[DocumentType]
      ,DocumentNbr
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,[DocumentTypeDesc]
      ,[ToUse]
      ,[BuyerBorrowerLastName]
      ,[BuyerBorrowerFirstName]
      ,[SellerLenderLastName]
      ,[SellerLenderFirstName]
      --,[TitleCompanyName]
      ,[Updated_Date]
      ,[MTG_Term]
      ,[MTG_TermType]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Rate_Type]
      ,[RAW_ID]
      ,[DocDate] From [zCust_Sharonview].[dbo].[w_TransHist_DEDUP]
		

		Update [zCust_Sharonview].[dbo].[w_TransHist] SET toUse = NULL
		Update [zCust_Sharonview].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_Sharonview].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')

	 --Update w_TransHist SET DocumentNbr = REPLACE(REPLACE(REPLACE(REPLACE(DocumentNbr,'-','.'),'..','.'),' ',''),'/','.')
		
	UPdate [zCust_Sharonview].[dbo].[w_TransHist]
	Set Touse = null 
	where Touse is not null

	

	
		----+/- 120 days & +/- 5% ----
		UPDATE [zCust_Sharonview].[dbo].[w_transhist]
		SET ToUse = 'Y' 
		--Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], P.RecordingDate, P.Value, P.BuyerBorrower, P.DocumentNbr 
		--,convert(money,p.Value) 	- (convert(money,p.Value) * .05 ) 
		--,convert(money,p.Value) 	+ (convert(money,p.Value) * .05 )
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_transhist] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			WHERE ISNULL(O.[Recording Date],'') like ''  AND 
			O.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_transhist] where ToUse = 'Y') and  
			p.Doc_Src_Ind = 'M'
				and Convert(MONEY,o.[INPUT Origination Amount]) 
				between convert(money,p.Value) 	- (convert(money,p.Value) * .05  ) and convert(money,p.Value) 
				+ (convert(money,p.Value) * .05 )
					and (convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,P.RecordingDate)-120 
					and convert(DATETIME,P.RecordingDate)+ 120
					   or convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,DocDate)-120  
					  and convert(DATETIME,DocDate)+ 120
					  )
						AND p.DocumentType not like 'MO'
						





	
	--------------------------------------------------------------------------------------------------------------------


			Select O.[INPUT Unique ID],O.WORK_REF_ID,O.PROPERTYID, O.[INPUT Origination Amount], O.[INPUT Origination Date]--,O.[INPUTBorrowerLastName]
			, P.RecordingDate, P.DocDate,P.Value, P.BuyerBorrower, P.DocumentNbr,P.DocumentType
			,ToUse
			,P.DOC_ID
			FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_TransHist] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			join 
				(Select RAW_ID, count(*) as TOTAL From  [zCust_Sharonview].[dbo].[w_TransHist]
				where ToUse = 'Y' 
				Group by RAW_ID
				having count(*) > 1) B on 
				P.RAW_ID = B.RAW_ID
				where P.ToUse = 'Y'
				and P.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where  ToUse = 'X' )
			Order by P.RAW_ID




	

		
			Select RAW_ID,ToUse,count(*) From [zCust_Sharonview].[dbo].[w_TransHist]
			where ToUse like 'Y'
			Group by RAW_ID,ToUse
			having count(*) > 1

			

		----------------START HERE--------------

		-----Added 20200330 to dedup dupped doc numbers----
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_TransHist] P 
				join 
					(Select  P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_TransHist] p
					WHERE ToUse = 'Y'
					Group by P.RAW_ID, P.RecordingDate, P.Value,  P.DocumentNbr
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID and D.DocumentNbr = P.DocumentNbr
					and D.RecordingDate = P.RecordingDate and P.Value = D.Value
					where ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'


		------Dedup where no doc number-----
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_TransHist] P 
				join 
					(Select  P.RAW_ID, P.RecordingDate, P.Value
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_TransHist] p
					WHERE ToUse = 'Y' AND ISNULL(P.DocumentNbr,'') like ''
					Group by P.RAW_ID, P.RecordingDate, P.Value
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID 
					and D.RecordingDate = P.RecordingDate and P.Value = D.Value
					where  ISNULL(P.DocumentNbr,'') like ''
					and ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where  ToUse = 'X' )

	 -----Dedup Max Doc ID
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'X' 
		--Select * 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select P.RAW_ID,max(P.Doc_ID) as MAXID from [zCust_Sharonview].[dbo].[w_TransHist] P 
				join 
					(Select  P.RAW_ID, P.DocDate, P.Value
					,count(*) as TOTAL
					FROM [zCust_Sharonview].[dbo].[w_TransHist] p
					WHERE ToUse = 'Y' 
					Group by P.RAW_ID, P.DocDate, P.Value
					having count(*) > 1) as D on 
					D.RAW_ID = P.RAW_ID 
					and D.DocDate = P.DocDate and P.Value = D.Value
					where  ToUse = 'Y'
					Group by P.RAW_ID)P
			
			on T.RAW_ID = P.RAW_ID and T.Doc_ID = P.MAXID
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where  ToUse = 'X' )


	
		


		Select O.FIPS,O.[INPUT Unique ID], T.REF_ID,O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate,T.DocDate, T.DocumentNbr,T.Value , T.Doc_Src_Ind, T.Doc_Id
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_TransHist] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_TransHist] 
		where ToUSe = 'Y'
		Group by RAW_ID
		having count(*) > 1)A)
		and touse = 'Y'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]

		

		
		-------------------------------------------
		--------RETURN RECORD WITH MAX RECORDING DATE--------
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'X' 
		--Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.* 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
			(Select A.RAW_ID as RAWID,MAX(ABS(DATEDIFF(day,coalesce(A.DocDate,A.REcordingDate)
			,convert(date,B.[INPUT Origination Date])))) as MINDATE From [zCust_Sharonview].[dbo].[w_TransHist]
			as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
			where ToUse = 'Y'
			and B.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where ToUse like 'X')
			Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and ABS(DATEDIFF(day,coalesce(T.DocDate,T.REcordingDate),O.[INPUT Origination Date])) = P.MINDATE
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where  ToUse = 'X' )
			--Order by O.[INPUT Unique ID]


			
			--------RETURN RECORD WITH MAX DOCID DATE--------
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'Y' 
		--Select O.[INPUT Unique ID], O.[INPUT Amount], O.[INPUT Origination Date], T.* 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
				(Select A.RAW_ID as RAWID,MIN(DOC_ID) as MINID From [zCust_Sharonview].[dbo].[w_TransHist]
				as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
				where ToUse = 'X'
				and B.[INPUT Unique ID]  in 
				(Select RAW_ID from 
				(Select RAW_ID, count(*) as TOTAL from [zCust_Sharonview].[dbo].[w_TransHist] where ToUse like 'X'
				Group by RAW_ID
				having count(*) > 1)A)
				Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and T.DOC_ID = P.MINID
			WHERE ToUse = 'X'


		
			
		Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate, T.DocDate,T.DocumentNbr,T.Value , T.Doc_Src_Ind
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_TransHist] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_TransHist] 
		where ToUSe = 'X'
		Group by RAW_ID
		having count(*) > 1)A)
		and touse = 'X'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]


		Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date], T.ToUse, T.RecordingDate, T.DocumentNbr,T.Value , T.Doc_Src_Ind
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  
		(Select * From [zCust_Sharonview].[dbo].[w_TransHist] where RAW_ID in 
		(Select RAW_ID from 
		(Select RAW_ID, count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_TransHist] 
		where ToUSe = 'X'
		Group by RAW_ID
		having count(*) = 1)A)
		and touse = 'X'		
		)as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
		Order by O.[INPUT Unique ID]


		
		UPDATE [zCust_Sharonview].[dbo].[w_TransHist]
		SET ToUse = 'X' 
		--Select O.[INPUT Origination Date], T.REcordingDate, DATEDIFF(day,T.REcordingDate,O.[INPUT Origination Date]) 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join  [zCust_Sharonview].[dbo].[w_TransHist] as T 
		ON O.[INPUT Unique ID] = T.RAW_ID
			join 
			(Select A.RAW_ID as RAWID,MIN(ABS(DATEDIFF(day,A.REcordingDate,convert(date,B.[INPUT Origination Date])))) as MINDATE From [zCust_Sharonview].[dbo].[w_TransHist]
			as A join [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as B on A.RAW_ID = B.[INPUT Unique ID]
			where ToUse = 'Y'
			and B.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where ToUse like 'X')
			Group by A.RAW_ID) as P on 
			T.RAW_ID = P.RAWID
			and ABS(DATEDIFF(day,T.REcordingDate,O.[INPUT Origination Date])) = P.MINDATE
			WHERE ToUse = 'Y'
			and T.RAW_ID not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where  ToUse = 'X' )
			and O.[INPUT Unique ID]  in 
			(Select RAW_ID from 
			(Select RAW_ID, DocDate, count(*) as TOTAL from [zCust_Sharonview].[dbo].[w_TransHist] where ToUse like 'Y'
			Group by RAW_ID, DocDate
			having count(*) > 1)A)

			--Select ABS(DATEDIFF(day,T.REcordingDate,'2016-04-12')) ,* From w_TransHist T where RAW_ID = '6374804'
			--and ToUse is not null

			--UPdate w_TransHist
			--Set ToUse = 'Y'
			--where RAW_ID = '6374804'
			--and ToUse is not null

	

	
			
		
			UPDATE [zCust_Sharonview].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_Sharonview].[dbo].[w_TransHist] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_Sharonview].[dbo].[w_TransHist] t WHERE ToUse = 'X' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID


		Select RAW_ID,count(*) From [zCust_Sharonview].[dbo].[w_TransHist]
		WHERE ToUse = 'X'
		Group by RAW_ID
		having count(*) > 1


		Select A.* From [zCust_Sharonview].[dbo].[w_TransHist] as A 
		join (Select RAW_ID,count(*) as TOTAL From [zCust_Sharonview].[dbo].[w_TransHist]
		WHERE ToUse = 'X'
		Group by RAW_ID
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'X'

		

		---------------------------------------------------START HERE-------------------------------------------------------------

			Select O.[INPUT Unique ID],O.WORK_REF_ID,O.PROPERTYID, O.[INPUT Origination Amount], O.[INPUT Origination Date]
			--,O.[INPUTBorrowerLastName]
			, P.RecordingDate, P.Value, P.BuyerBorrower, P.DocumentNbr
			,ToUse
			,P.DOC_ID
			FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_TransHist] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			join 
				(Select RAW_ID, count(*) as TOTAL From  [zCust_Sharonview].[dbo].[w_TransHist]
				where ToUse = 'X' 
				Group by RAW_ID
				having count(*) > 1) B on 
				P.RAW_ID = B.RAW_ID
				where P.ToUse = 'X'
			Order by P.RAW_ID
				
			
	
			Select ToUse,count(*) From [zCust_Sharonview].[dbo].[w_TransHist]
			Group by ToUse

			-----View unselected records
			Select RAW_ID, RecordingDate, DocDate,DocumentNbr, Value, Doc_Src_Ind ,TOUSE
			From [zCust_Sharonview].[dbo].[w_TransHist] where RAW_ID in (
			Select RAW_ID from  [zCust_Sharonview].[dbo].[w_TransHist]
			where ToUse = 'Y')
			and TOUSE is not null
			Order by RAW_ID

			

			--Select * From  w_TransHist where DocumentTypeDesc like '%sub%'


			--Select Documenttype, DocumentTypeDesc, count(*) From w_TransHist where DocumentTypeDesc like '%sub%'
			--Group by Documenttype, DocumentTypeDesc
			--Order by Documenttype, DocumentTypeDesc

		Truncate table w_TransHist_II

		INSERT INTO [zCust_Sharonview].[dbo].[w_TransHist_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					--, OrigTransValue
					)
		SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					--, OrigTransValue
		FROM     [zCust_Sharonview].[dbo].[w_TransHist]
		WHERE  (ToUse = 'X')


			UPDATE [zCust_Sharonview].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_Sharonview].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate ASC) AS RowNum
				FROM 
			[zCust_Sharonview].[dbo].[w_TransHist_II] t WHERE ToUse = 'X' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID

		Select * FRom [zCust_Sharonview].[dbo].[w_TransHist_II]
		where RecordNumber is null

		
		Select RAW_ID,  count(*) FRom [zCust_Sharonview].[dbo].[w_TransHist_II]
		Group by RAW_ID
		having count(*) > 1



		Select RAW_ID, RecordNumber, count(*) FRom [zCust_Sharonview].[dbo].[w_TransHist_II]
		Group by RAW_ID, RecordNumber
		having count(*) > 1
			
			

			UPDATE [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] 
			SET 
			[Recording Date] = a.RecordingDate
			,[Amount ] = Value
			,[Document #] = DocumentNbr
			,[Lender] = SellerLender
			--,[OrigBorrower] = A.BuyerBorrower
			,[FA Lien Position]  = A.Lien_Pos
			,[MTGTransactionID_DOCID] = A.Doc_Id
			,[FLANK_OR_DTDB] = 'D'
			--,[OrigBorrower1] = case when A.BuyerBorrower like '%&%' and A.BuyerBorrower like '%,%' AND right(A.BuyerBorrower,1) not like '&' then 
			--left(BuyerBorrower,charindex('&',BuyerBorrower)-1)
			--else BuyerBorrower end
			--,[OrigBorrower2] = case when A.BuyerBorrower like '%&%' and A.BuyerBorrower like '%,%' AND right(A.BuyerBorrower,1) not like '&' then 
			--right(BuyerBorrower,charindex('&',REVERSE(BuyerBorrower))-2)
			--+ ',' + left(BuyerBorrower,charindex(',',BuyerBorrower)-1)
			--else BuyerBorrower end
			
			--Select BuyerBorrower,charindex('&',REVERSE(BuyerBorrower))
			--,case when A.BuyerBorrower like '%&%' and A.BuyerBorrower like '%,%' AND right(A.BuyerBorrower,1) not like '&' then 
			--right(BuyerBorrower,charindex('&',REVERSE(BuyerBorrower))-2)
			--+ ',' + 
			--left(BuyerBorrower,charindex(',',BuyerBorrower)-1)
			--else BuyerBorrower end
			--Select A.*
			From [zCust_Sharonview].[dbo].[w_TransHist_II] a with(NOLOCK) JOIN [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] b with(NOLOCK)
			on A.RAW_ID = B.[INPUT Unique ID]
			JOIN [zCust_Sharonview].[dbo].[INPUT_IN] c with(NOLOCK)
			ON b.[INPUT Unique ID] = c.[INPUTKey]
			WHERE b.[Recording Date] is NULL and  a.Doc_Src_Ind = 'M' 
			and A.RecordNumber = 1
			--Order by charindex('&',REVERSE(BuyerBorrower))




					--------------------Update Lien Position for previously matched Mortgage---------
			UPDATE [zCust_Sharonview].[dbo].[B] 
			SET 
			B.[FA Lien Position]  = A.Lien_Pos
			,[MTGTransactionID_DOCID] = A.Doc_Id
			,[FLANK_OR_DTDB] = 'F'
			--Select A.RAW_ID, A.Doc_ID,A.Lien_Pos,B.[FA Lien Position], B.PropertyID, A.* 
			From [zCust_Sharonview].[dbo].[w_transhist] a with(NOLOCK) JOIN [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] b with(NOLOCK)
			on A.RAW_ID = B.[INPUT Unique ID]
			And A.DOC_ID = B.[MTGTransactionID_DOCID]
			WHERE  a.Doc_Src_Ind = 'M' 
			and B.FLANK_OR_DTDB like 'D'
			AND ISNULL(B.[FA Lien Position] ,'') <> ISNULL(A.Lien_Pos ,'')
	


			-----------------Backfilling Lien position from FLANK where DTDB doesn't show as open but FLANK does----
			UPDATE [zCust_Sharonview].[dbo].[A] 
			SET 
			A.[FA Lien Position]  = '1'			
			--Select A.[INPUT Unique ID] ,A.[INPUT Origination Amount], A.[INPUT Origination Date]
			--,A.[Document #],A.[Amount ],A.[Recording Date],A.[FA Lien Position],A.MTGTransactionID_DOCID, A.FLANK_OR_DTDB
			--,B.Mtg1FormatDocNbr, B.Mtg1LoanAmt,B.Mtg1REcordingDt, B.Mtg1InputDocNbr,B.Mtg1TransactionId
			From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a with(NOLOCK) JOIN 
			[data].[dbo].[Property] as B with(NOLOCK) on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID
			where 
			ISNULL(A.[FA Lien Position],'') like ''
			and ISNULL(A.[Recording Date],'') not like ''
			AND (A.[Document #] = B.Mtg1FormatDocNbr OR A.[Document #] = B.Mtg1InputDocNbr)
			and A.[Amount ] = B.Mtg1LoanAmt
			and A.[Recording Date] = convert(date,B.Mtg1REcordingDt)


			UPDATE [zCust_Sharonview].[dbo].[A] 
			SET 
			A.[FA Lien Position]  = '2'			
			--Select A.[INPUT Unique ID] ,A.PROPERTYID,A.[INPUT Origination Amount], A.[INPUT Origination Date]
			--,A.[Document #],A.[Amount ],A.[Recording Date],A.[FA Lien Position],A.MTGTransactionID_DOCID, A.FLANK_OR_DTDB
			--,B.Mtg2FormatDocNbr, B.Mtg2LoanAmt,B.Mtg2REcordingDt, B.Mtg2InputDocNbr
			From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a with(NOLOCK) JOIN 
			[data].[dbo].[Property] as B with(NOLOCK) on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID
			where 
			ISNULL(A.[FA Lien Position],'') like ''
			and ISNULL(A.[Recording Date],'') not like ''
			AND (A.[Document #] = B.Mtg2FormatDocNbr OR A.[Document #] = B.Mtg2InputDocNbr)
			and A.[Amount ] = B.Mtg2LoanAmt
			and A.[Recording Date] = convert(date,B.Mtg2REcordingDt)


			UPDATE [zCust_Sharonview].[dbo].[A] 
			SET 
			A.[FA Lien Position]  = '3'			
			--Select A.[INPUT Unique ID],A.PROPERTYID ,A.[INPUT Origination Amount], A.[INPUT Origination Date]
			--,A.[Document #],A.[Amount ],A.[Recording Date]
			--,B.Mtg3FormatDocNbr, B.Mtg3LoanAmt,B.Mtg3REcordingDt, B.Mtg3InputDocNbr,A.MTGTransactionID_DOCID, A.FLANK_OR_DTDB
			From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a with(NOLOCK) JOIN 
			[data].[dbo].[Property] as B with(NOLOCK) on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID
			where 
			ISNULL(A.[FA Lien Position],'') like ''
			and ISNULL(A.[Recording Date],'') not like ''
			AND (A.[Document #] = B.Mtg3FormatDocNbr OR A.[Document #] = B.Mtg3InputDocNbr)
			and A.[Amount ] = B.Mtg3LoanAmt
			and A.[Recording Date] = convert(date,B.Mtg3REcordingDt)
			
			

			UPDATE [zCust_Sharonview].[dbo].[A] 
			SET 
			A.[FA Lien Position]  = '4'			
			--Select A.[INPUT Unique ID] ,A.[INPUT Origination Amount], A.[INPUT Origination Date]
			--,A.[Document #],A.[Amount ],A.[Recording Date]
			--,B.Mtg4FormatDocNbr, B.Mtg4LoanAmt,B.Mtg4REcordingDt, B.Mtg4InputDocNbr
			From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a with(NOLOCK) JOIN 
			[data].[dbo].[Property] as B with(NOLOCK) on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID
			where 
			ISNULL(A.[FA Lien Position],'') like ''
			and ISNULL(A.[Recording Date],'') not like ''
			AND (A.[Document #] = B.Mtg4FormatDocNbr OR A.[Document #] = B.Mtg4InputDocNbr)
			and A.[Amount ] = B.Mtg4LoanAmt
			and A.[Recording Date] = convert(date,B.Mtg4REcordingDt)
					
					
		
	Select 
	A.[INPUT Unique ID], A.PropertyID
	--,C.State ,C.[County Name], D.FormattedAPN,  B.DocumentNbr,B.Value
	
	,A.[INPUT Origination Amount], A.[INPUT Origination Date]
	,A.FIPS,B.RecordingDate, B.Value,REF_ID, DocumentNbr, B.Doc_Id, C.SrcDeed, C.SrcDeedStartDate
	--,A.INPUTBorrowerLastName
	, B.BuyerBorrower
	,A.[INPUT Origination Amount]-convert(money,B.Value)
	, convert(money,B.Value) 	- (convert(money,B.Value) * .05  ) , convert(money,B.Value) 
				+ (convert(money,B.Value) * .05 )
	From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as A 
	--join w_TransHist as B on A.[INPUT Unique ID] = B.RAW_ID
	join [zCust_Sharonview].[dbo].[w_TransHist_FLANK] as B on A.[INPUT Unique ID] = B.RAW_ID
	join [global].[dbo].[county] as C on A.FIPS = C.FIPSCODE
	join [data].[dbo].[Property] as D with(NOLOCK) on A.PROPERTYID = D.PropertyID
	where [Recording Date] is null
	and  convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,B.RecordingDate)-120 
					and convert(DATETIME,B.RecordingDate)+120
	and B.Doc_Src_Ind like 'M'
	--and left([INPUT Origination Amount],4) = left(value,4)
	--ORder by C.State ,C.[County Name]
	And B.RecordingDate >= C.SrcDeedStartDate
	--and B.Value is not null
	order by A.[INPUT Origination Amount]-convert(money,B.Value)



	Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date]--, O.INPUTBorrowerLastName
	,P.RecordingDate,P.DocDate, P.Value, P.BuyerBorrower, P.Doc_Src_Ind
	FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] o Join [zCust_Sharonview].[dbo].[w_TransHist] p
			ON O.[INPUT Unique ID] = P.RAW_ID
			WHERE ISNULL(O.[Recording Date],'') like ''  AND 
			O.[INPUT Unique ID] not in (Select distinct RAW_ID from [zCust_Sharonview].[dbo].[w_TransHist] where ToUse = 'Y') and  
			p.Doc_Src_Ind = 'M'
				and Convert(MONEY,o.[INPUT Origination Amount]) 
				between convert(money,p.Value) 	- (convert(money,p.Value) * .05  ) and convert(money,p.Value) 
				+ (convert(money,p.Value) * .05 )
					and (convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,P.RecordingDate)-150 
					and convert(DATETIME,P.RecordingDate)+ 150
					   or convert(DATETIME,[INPUT Origination Date]) BETWEEN convert(DATETIME,DocDate)-150  
					  and convert(DATETIME,DocDate)+ 150
					  )
						--and buyerborrower LIKE '%' + LTRIM(RTRIM(INPUTBorrowerLastName)) + '%'
							AND p.DocumentType not like 'MO'


	-----TEsting---
	Select O.[INPUT Unique ID], O.[INPUT Origination Amount], O.[INPUT Origination Date],[Recording Date] ,[Amount ]
	,ABS(convert(money,[INPUT Origination Amount])-convert(money,[Amount ]))
	,ABS(convert(money,[INPUT Origination Amount])-convert(money,[Amount ]))/convert(money,[INPUT Origination Amount])
	FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] O
	where [Amount ] > 0
	Order by ABS(convert(money,[INPUT Origination Amount])-convert(money,[Amount ]))/convert(money,[INPUT Origination Amount]) desc



	

	-----------------------------------START HERE---------------------
	------------------LienPositionEventStatus: This will be used to define when a change to the FA Lien position has occurred/not occurred-----------------------
	-------------Need to know how to populate this when Input Lien Pos = 0
	-------------Need to know how to populate this when this is a NEW input record
				------20241029 Per EC - If we return a lien position, we’d call that Event Found, for the initial baseline run of an input record
	-------------Need to add matched mortgage rec date, doc number, Amount, TransID & FLANK or DTDB indicator to INPUT_MONITOR to check for changes
	-----20241029 - Per EC - Janine explained that not all the loans they lend, have a required lien position, so at the time of funding/origination, they don’t know what position their lien is in.
	


	Select [INPUT Unique ID],[INPUT Mortgage Lien Position],[FA Lien Position]
	,[INPUT Origination Date],[INPUT Origination Amount]
	,[Recording Date] ,[Amount ]
	,convert(money,[INPUT Origination Amount]) - convert(money,[Amount ]) as DIFF
	From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
	where [FA Lien Position] is not null 
	Order by convert(money,[INPUT Origination Amount]) - convert(money,[Amount ]) 


	Select * From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]


		----on initial extract for newly added records = how should each of these be set:

		----1.	[CurrentOwnerEvent Status] = If we return an Owner Name on an initial extract then this is Event Found?
		----2.	[LienPositionEvent Status] = If we return a lien position on an initial extract then this is Event Found?


		Update [zCust_Sharonview].[dbo].[A]
		Set A.[LienPositionEvent Status] = case 
		when A.AddRecordEventStatus like 'Y' and A.[FA Lien Position] > 0 then 'Event Found' 
		when A.AddRecordEventStatus IS NULL  and ISNULL(A.[FA Lien Position],'') <> ISNULL(B.FA_LIENPOS,'') then 'Event Found' 
		else 'Event Not Found' end
		--Select A.[FA Lien Position], B.FA_LIENPOS, A.[LienPositionEvent Status]
		From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] as A 
		join [zCust_Sharonview].[dbo].[INPUT_MONITOR] as B on A.[INPUT Unique ID] = B.Unique_ID





		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_Sharonview].[dbo].[A]
		Set 
		A.[Current Owner Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Change Doc Type] = C.DocumentTypeCode
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_Sharonview].[dbo].[A]
		Set 
		A.[Current Owner Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Change Doc Type] = C.DocumentTypeCode
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null

		
		Update [zCust_Sharonview].[dbo].[A]
		Set A.[Current Owner Change Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type], B.CodeDesc
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Change Doc Type] = B.[DocTypeID]
	

		Select [Current Owner Change Doc Type], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [Current Owner Change Doc Type]
		ORder by [Current Owner Change Doc Type]
		

		Select * From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]

		Update [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] 
		SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1'
		OR ISNULL([Recording Date],'') not like ''
		THEN 'In Coverage' ELSE 'Not In Coverage' END


		--------------Mortgage Coverage----------
	Select O.[INPUT Unique ID], [Recording Date] ,[Amount ], [Mortgage Coverage Status], [Mortgage Start Date], [Mortgage Thru Date]
	FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] O
	where ISNULL([Recording Date],'') not like ''
	and [Mortgage Coverage Status] like 'Not In Coverage'


		Update  [zCust_Sharonview].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Sharonview].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID

		Update [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN PROPERTYID is not null and PROPERTYID not like '0' THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_Sharonview].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_Sharonview].[dbo].[x_Custom_OUTPUT] a join [zCust_Sharonview].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		

		Select [Property Status], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]
		
		Select [LienPositionEvent Status], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [LienPositionEvent Status]

		Select [Deed Coverage Status], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [Deed Coverage Status]

		Select [Mortgage Coverage Status], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [Mortgage Coverage Status]
		
		Select [Address Standardization], count(*) From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]
		Group by [Address Standardization]

		Select * From [zCust_Sharonview].[dbo].[x_Custom_OUTPUT]

		
	

END



