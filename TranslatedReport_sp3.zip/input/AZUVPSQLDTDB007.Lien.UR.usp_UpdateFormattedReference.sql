/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_UpdateFormattedReference | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- DROP TABLE lien.tmp.usp_UpdateFormattedReference_tracker
/*
--SELECT Fips
--	,DateStarted
--	,DateEnded
-- --	begin transaction update a set a.DateStarted = null 
--FROM lien.tmp.usp_UpdateFormattedReference_tracker a
--where DateEnded is null
--and DateStarted is not null
-- commit
--ORDER BY fips
*/

-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_UpdateFormattedReference]
AS
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_UpdateFormattedREference'
	,N'Started'

--determine which documents need to formatting
TRUNCATE TABLE [lien].[tmp].[Documents_to_be_formatted]

--select top 100 * select  format(count(*), '##,##0') as cnt from lien.tmp.Documents_to_be_formatted
------------------------------------------lien.dbo.DTDB_DocIdExtract_Process
-- select  format(count(*), '##,##0') as cnt from lien.tmp.reprocess_PFC
--
--determine the last time the tracker ran
--
DECLARE @date DATETIME2 = (
		SELECT max(m_update_date)
		FROM [lien].[UR].[document_transaction_log_tracker]
		WHERE INFC_Extract_date IS NOT NULL
		)

--SELECT @date
--
--find all the doc_id that had a change since the last update ran
--
INSERT INTO [lien].[tmp].[Documents_to_be_formatted] (
	[doc_id]
	,[m_update_date]
	,[fips_code]
	,[Fips]
	,[Instrument_nbr]
	,[recording_date_d]
	,[m_status_id]
	,[reprocess_flag]
	,[ur_matrix]
	,[previous_doc_unique_id]
	,[update_type]
	,[doc_title]
	,[doc_type]
	)
SELECT d.doc_id
	,b.m_update_date AS m_update_date
	,d.fips_code
	,try_cast(d.Fips_code AS INT) AS Fips
	,d.Instrument_nbr
	,d.recording_date_d
	,d.m_status_id
	,isnull(d.reprocess_flag, '') AS reprocess_flag
	,d.[ur_matrix]
	,d.[previous_doc_unique_id]
	,d.[update_type]
	,d.[doc_title]
	,d.[doc_type]
FROM (
	SELECT a.doc_id
		,a.m_update_date
		,ROW_NUMBER() OVER (
			PARTITION BY a.doc_id ORDER BY a.m_update_date DESC
			) AS ROW4
	FROM (
		SELECT l.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		--where l.doc_id in (147093623,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[NAME] n WITH (INDEX (PK_NAME)) ON n.name_id = l.name_id
		--where l.doc_id in (147093623,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Name_id IS NOT NULL
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[Property] n WITH (INDEX (PK_PROPERTY)) ON n.Property_id = l.Property_id
		--where l.doc_id in (131803293,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Property_id IS NOT NULL
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[Reference] n WITH (INDEX (PK_REFERENCE)) ON n.Reference_id = l.Reference_id
		--where l.doc_id in (131803293,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Reference_id IS NOT NULL
		) a
	WHERE doc_id IS NOT NULL
	) b
INNER JOIN [lien].[ur].[DOCUMENT] d WITH (
		NOLOCK
		,INDEX (pk_document)
		) ON d.doc_id = b.Doc_id
WHERE row4 = 1


OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);



	


DROP TABLE if exists [lien].[tmp].[usp_UpdateFormattedReference_tracker]
BEGIN
	CREATE TABLE [lien].[tmp].[usp_UpdateFormattedReference_tracker] (
		[Fips] [int] NOT NULL
		,
		--[Rows] [int] NOT NULL,
		--[SPID] [int] NOT NULL,
		[DateStarted] [datetime] NULL
		,[DateEnded] [datetime] NULL
		)

	INSERT INTO [lien].[tmp].[usp_UpdateFormattedReference_tracker] (
		[Fips]
		,[DateStarted]
		,[DateEnded]
		)
	SELECT fips
		,NULL AS DateStarted
		,NULL AS DateEnded
	FROM (
		SELECT DISTINCT try_cast(fips_code AS INT) AS Fips
		FROM [lien].[tmp].[Documents_to_be_formatted]
		) n
	
END


DECLARE @fips INT = NULL
	,@fips_a CHAR(5) = NULL



--select the starting fips
--
SELECT @fips = min(fips)
FROM [lien].[tmp].[usp_UpdateFormattedReference_tracker]
WHERE DateStarted IS NULL

SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)

--
--begin the loop for the Fips
DECLARE @return_value INT = 0
DECLARE @rowcount INT = 0
DECLARE @year VARCHAR(4) = datepart(year, getdate())
DECLARE @year_2 VARCHAR(2) = substring(@year, 3, 2)

--
WHILE @fips IS NOT NULL
	AND @fips > 0
BEGIN
	--
	--Udpate the control trable to say you are workig on the fips
	--
	BEGIN
		UPDATE [lien].[tmp].[usp_UpdateFormattedReference_tracker]
		SET DateStarted = getdate()
		WHERE fips = @fips
	END

	RAISERROR (
			'%s Busy with Fips %s'
			,0
			,1
			,@fips_a
			,@fips_a
			)
	WITH NOWAIT

	--
	-- here the logic start that you  wnat to run by fips
	--

	UPDATE [Lien].[UR].[r]
	SET r.[Fmt_Reference_Doc_Number] = fm.Fmt_Doc_Nbr
		,r.[Fmt_BookPAge] = fm.FMT_Book_Page
		,r.[FMT_CMT_ID] = CASE 
			WHEN isnull(fm.cmtid, '') = 'N/A'
				OR isnull(fm.cmtid, '') = 'NULL'
				OR isnull(fm.cmtid, '') = ''
				OR fm.Fmt_Doc_Nbr IS NULL
				THEN 0
			ELSE fm.cmtid
			END
		,r.FMT_CMT_ID_Book_Page = CASE 
			WHEN isnull(fm.cmtid_bkpg, '') = 'N/A'
				OR isnull(fm.cmtid_bkpg, '') = 'NULL'
				OR isnull(fm.cmtid_bkpg, '') = ''
				OR FM.FMT_Book_Page IS NULL
				THEN 0
			ELSE fm.cmtid_bkpg
			END
		,r.Updated = getdate()
	OUTPUT NULL AS Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,inserted.REFERENCE_id AS reference_id
		,inserted.Updated
		,'usp_UpdateFormattedReference_1' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[tmp].[Documents_to_be_formatted] a WITH (
			NOLOCK
			,INDEX (idxa_del)
			)
	INNER JOIN [Lien].[UR].[Document] D WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = a.doc_id
	INNER JOIN [Lien].[UR].[REFERENCE] r WITH (
			NOLOCK
			,INDEX (ix_doc_id)
			) ON d.doc_id = r.doc_id
	-- the below outer apply is used for Hawaii
	OUTER APPLY (
		SELECT CASE 
				WHEN d.Fips_code BETWEEN '15000'
						AND '16000'
					THEN '15003'
				ELSE d.fips_code
				END AS Fips
		) d1
	OUTER APPLY (
		SELECT rc.Reference_CategoryName AS categoryname
			,cast(d1.Fips AS INT) AS Fips
			--------------------------------------------------------------------------------'-',''
			,REplace(r.reference_doc_number, ' ', '') AS reference_doc_number
			,try_cast((
					SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](r.[reference_recording_date])
					) AS VARCHAR) AS reference_recording_date
		FROM [Lien].[dbo].[calico_dtdb_cmtid_Ref_Category] rc
		WHERE rc.doc_type = d.doc_type
		) dt
	OUTER APPLY (
		SELECT CASE 
				WHEN isdate(dt.reference_recording_date) = 1
					THEN dt.[reference_recording_date]
				WHEN dt.[reference_recording_date] IS NULL
					AND isdate(r.reference_recording_year) = 1
					AND isnull(r.reference_recording_year, '') > ''
					THEN r.reference_recording_year + '0101'
				WHEN isdate(substring(dt.reference_doc_number, 1, 4)) = 1
					AND substring(dt.reference_doc_number, 1, 4) BETWEEN '1970'
						AND @year
					THEN substring(dt.reference_doc_number, 1, 4) + '0101'
				WHEN len(dt.reference_doc_number) >= 7
					AND r.reference_recording_year IS NULL
					AND r.reference_recording_date IS NULL
					AND isnumeric(substring(dt.reference_doc_number, 1, 2)) = 1
					AND substring(dt.reference_doc_number, 1, 2) BETWEEN '00'
						AND @year_2
							--and substring(dt.reference_doc_number,3,1) = 0
					THEN '20' + substring(dt.reference_doc_number, 1, 2) + '0101'
				ELSE dt.[reference_recording_date]
				END AS reference_recording_date
		) r2
	OUTER APPLY (
		SELECT *
		FROM [spdb].[dbo].[fn_FmtDocBookPAge_tbl_DTDB](dt.fips, REPLACE(REPLACE(r2.[reference_recording_date], CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(substring(r.[reference_book], 1, 8), CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(substring(r.[reference_page], 1, 8), CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(dt.[reference_doc_number], CHAR(13), ''), CHAR(10), ''), dt.categoryname)
		) fm
	WHERE a.fips_code = @fips_a
		AND (len(isnull(r.reference_doc_number, '')) < 20)
		AND (
			r.reference_doc_number IS NOT NULL
			OR r.reference_book IS NOT NULL
			)
		AND r.[Fmt_Reference_Doc_Number] IS NULL
		AND r.[Fmt_BookPAge] IS NULL
		AND (
			isnull(r.[Fmt_Reference_Doc_Number], '') <> isnull(fm.Fmt_Doc_Nbr, '')
			OR isnull(r.[Fmt_BookPAge], '') <> isnull(fm.FMT_Book_Page, '')
			OR isnull(r.[FMT_CMT_ID], 0) <> isnull(fm.cmtid, 0)
			OR isnull(r.FMT_CMT_ID_Book_Page, 0) <> isnull(fm.cmtid_bkpg, 0)
			)

	--
	--
	--
	UPDATE [Lien].[UR].[D]
	SET D.Fmt_Doc_Number = fm.Fmt_Doc_Nbr
		,d.FMT_Book_Page = fm.FMT_Book_Page
		,d.[FMT_CMT_ID] = CASE 
			WHEN isnull(fm.cmtid, '') = 'N/A'
				OR isnull(fm.cmtid, '') = 'NULL'
				OR isnull(fm.cmtid, '') = ''
				OR fm.Fmt_Doc_Nbr IS NULL
				THEN 0
			ELSE fm.cmtid
			END
		,d.FMT_CMT_ID_Book_Page = CASE 
			WHEN isnull(fm.cmtid_bkpg, '') = 'N/A'
				OR isnull(fm.cmtid_bkpg, '') = 'NULL'
				OR isnull(fm.cmtid_bkpg, '') = ''
				OR Fm.FMT_Book_Page IS NULL
				THEN 0
			ELSE fm.cmtid_bkpg
			END
		,d.m_update_date = getdate()
	OUTPUT inserted.doc_id AS Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'usp_UpdateFormattedReference_2' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[tmp].[Documents_to_be_formatted] a WITH (
			NOLOCK
			,INDEX (idxa_del)
			)
	INNER JOIN [Lien].[UR].[Document] D WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = a.doc_id
	OUTER APPLY (
		SELECT REplace(replace([SPDB].[dbo].[fn_RemoveLeadingZeros](d.recording_doc_number), '-', ''), ' ', '') AS recording_doc_number
			,[spdb].[eprvdb].[fn_DTOCR_RecordingDate](d.[recording_date]) AS recording_date
		) dd
	OUTER APPLY (
		SELECT CASE 
				WHEN d.Fips_code BETWEEN '15000'
						AND '16000'
					THEN '15003'
				ELSE d.fips_code
				END AS Fips
		) d1
	OUTER APPLY (
		SELECT a.categoryname
		FROM [Lien].[dbo].[calico_DocType_Catecory_DTDB] a
		WHERE documentcode = d.doc_type
		) dt
	OUTER APPLY (
		SELECT *
		FROM [spdb].[dbo].[fn_FmtDocBookPAge_tbl_DTDB](d1.fips, REPLACE(REPLACE(dd.[recording_date], CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(substring(d.recording_book, 1, 8), CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(substring(d.recording_page, 1, 8), CHAR(13), ''), CHAR(10), ''), REPLACE(REPLACE(dd.recording_doc_number, CHAR(13), ''), CHAR(10), ''), dt.categoryname)
		) fm
	WHERE a.fips_code = @fips_a
		AND (len(isnull(d.[recording_doc_number], '')) < 20)
		AND (
			d.[recording_doc_number] IS NOT NULL
			OR d.recording_book IS NOT NULL
			)
		AND d.Fmt_Doc_Number IS NULL
		AND d.FMT_Book_Page IS NULL
		AND (
			isnull(d.Fmt_Doc_Number, '') <> isnull(fm.Fmt_Doc_Nbr, '')
			OR isnull(d.FMT_Book_Page, '') <> isnull(fm.FMT_Book_Page, '')
			OR isnull(d.[FMT_CMT_ID], 0) <> isnull(fm.cmtid, 0)
			OR isnull(d.FMT_CMT_ID_Book_Page, 0) <> isnull(fm.cmtid_bkpg, 0)
			)

	SET @rowcount = @@rowcount

	RAISERROR (
			'%s updated  %d'
			,0
			,1
			,@fips_a
			,@rowcount
			)


	--
	--Update the control table to indicate you are done
	--
	BEGIN
		UPDATE [lien].[tmp].[usp_UpdateFormattedReference_tracker]
		SET DateEnded = getdate()
		WHERE fips = @fips
	END

	--
	--Select the new fips to process - if non found then @fips would be null
	--
	SELECT @fips = min(fips)
	FROM [lien].[tmp].[usp_UpdateFormattedReference_tracker]
	WHERE DateStarted IS NULL

	SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
END



EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_UpdateFormattedREference'
	,N'Ended'


