SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Create Devworx Table for Snowflake extract
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_850_CreateDevworx_V2]

AS
BEGIN

	SET NOCOUNT ON;
		declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

	IF(SELECT CAST(getdate() AS time)) between '00:30:00' and '08:30:00'

	BEGIN

		UPDATE [AZUVPSQLADSF001].Jobs.[dbo].[SystemProperty] 
		SET [Value] = 'Y'
		,[UpdateDate] = GetDate()
		WHERE [Name] = 'IsDevworxRunning'

		DROP INDEX IF EXISTS [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_I_Batch]

		 TRUNCATE TABLE [Devworx].[dbo].[Devworx_ALL_I_Batch]

		CREATE UNIQUE NONCLUSTERED INDEX [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_I_Batch]
		([MLSID] ASC,[ListingId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

			INSERT INTO [Devworx].[dbo].[Devworx_ALL_I_Batch]([MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription])
		Select Distinct LEFT(a.[mls_id],15)
			,CASE WHEN LEN(a.[FIPS]) = 4 then '0' + a.[FIPS] ELSE a.[FIPS] END
			,a.[PropertyID]
			,a.[REF_ID]
			,LEFT([parcel_number],50)
			,CASE WHEN LEFT(b.[FULLStreetAddress],116) is NULL THEN LEFT(a.[address],116) ELSE LEFT(b.FullStreetAddress,116) END
			,LEFT([HouseNbr],30)
			,LEFT([LeftDirection],2)
			,LEFT([Street],55)
			,LEFT([Mode],10)
			,LEFT([RightDirection],2)
			,LEFT([UnitType],20)
			,LEFT([UnitNumber],15)
			,LEFT(b.[City],55)
			,LEFT(b.[State],2)
			,LEFT(b.[Zip],10)
			,LEFT([ZIP4],10)
			,LEFT([CarrierCode],4)
			,[mls_lat]
			,[mls_lng]
			,LEFT([GeoStatusCode],1)
			,LEFT(a.[mls_listing_id],225)
			,LEFT([mls_status],50)
			,LEFT([status],50)
			,[Platlabs_Listdate]
			,LEFT([price],15)
			,LEFT([original_listing_price],15)
			,NULL 
			,[sold_date]
			,LEFT([sold_price],15)
			,LEFT([mls_property_type],50)
			,LEFT([mls_property_sub_type],50)
			,[on_market_date] 
			,[off_market_date]
			,[pending_date]
			,a.[LoadDate]
			,LEFT([days_on_market],15)
			,LEFT([photo_count],15)
			,LEFT([Appliances],1024)
			,LEFT([bedrooms],15)
			,LEFT([bathrooms_full],15)
			,LEFT([bathrooms_half],15)
			,LEFT([bathrooms],5)
			,LEFT([square_feet],15) 
			,NULL
			,LEFT([construction_materials],1024)
			,LEFT([air_conditioning],1024)
			,LEFT([exterior_features],1024)
			,LEFT([fence_description],1024)
			,NULL
			,LEFT([flooring_information],1024)
			,NULL --LEFT([FoundationDetails],1024)
			,LEFT([garage_spaces],15)
			,LEFT([heat_type],1024)
			,LEFT([interior_features],1024)
			,LEFT([above_grade_finished_area],15)
			,LEFT([lot_description],1024)
			,CASE WHEN [lot_size_units] like 'acres' then LEFT([lot_size_area],5) ELSE NULL END 
			,LEFT([lot_size_square_feet],15)
			,NULL
			,LEFT([parking_description],1024)
			,LEFT([parking_spaces],15)
			,LEFT([patio_and_porch_features],1024)
			,LEFT([pool_description],1024)
			,LEFT([roofing],1024)
			,LEFT([security_features],1024)
			,LEFT([sewer],1024)
			,LEFT([stories_total],5)
			,LEFT([utilities],1024)
			,LEFT([property_view_description],1024)
			,LEFT([water],1024)
			,LEFT([waterfront_description],1024)
			,NULL
			,LEFT([windows_description],1024)
			,LEFT([year_built],5)
			,LEFT([description],4000)
			,LEFT([confidential_description],4000)
			,NULL
			,NULL
			,LEFT([hoa_fee],10)
			,LEFT([hoa_frequency],25)
			,LEFT([hoa_fee_includes],1024)
			,LEFT([hoa_name],50)
			,LEFT([hoa_phone],16)
			,LEFT([elementary_school],50)
			,LEFT([junior_high_school],50)
			,LEFT([high_school],50)
			,LEFT([school_district],50)
			,LEFT([subdivision],50)
			,LEFT([tax_legal_description],6000)
			,LEFT([green_features],1024)
			,CASE WHEN isNULL([is_new_construction],'') = 'true' Then 'Y' Else NULL END
			,NULL
			,LEFT([total_units],5)
			,NULL
			,LEFT([lot_size_area],15)
			,LEFT([above_grade_finished_area],15)
			,LEFT([below_grade_finished_area],15)
			,NULL
			,LEFT([fireplaces],15)
			,NULL  --LEFT([YearBuiltEffective],5)
			,NULL  --[Levels]
			,LEFT([tax_year],5)
			,[financial_information]
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL  --LEFT([CoveredSpaces],15)
			,NULL
			,NULL  --LEFT([SpaYN],1024)
			,LEFT([lot_size_units],25)
			,'SQFT'
			,LEFT([rooms],15)
			,LEFT([zoning],255)
			--select count(*) 
			FROM [src_PlatLabs].[listing].[ListingsRaw] a with(NOLOCK) LEFT OUTER JOIN [src_PlatLabs].[addr].[StandardizedAddress] b with(NOLOCK)
			on a.[mls_id] = b.[mls_id]
								and a.[mls_listing_id] = b.[mls_listing_id]
			WHERE coalesce([mls_list_date],[list_date]) <= CAST(GETDATE() as DATE)
			and a.REF_ID is not null
			and isNULL(price,'') not like '%e%'
			and isNULL(original_listing_price,'') not like '%e%'
			and LoadDate > (Select MAX(FATimestamp) from [DevWorx].[dbo].[Devworx_ALL_I] with(NOLOCK))

		ALTER INDEX [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_I_Batch] REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		DROP INDEX IF EXISTS [ix_Zip] ON [Devworx].[dbo].[Devworx_ALL_I]
		DROP INDEX IF EXISTS [ix_StandardStatus] ON [Devworx].[dbo].[Devworx_ALL_I]
		DROP INDEX IF EXISTS [ix_mlsid] ON [Devworx].[dbo].[Devworx_ALL_I]
		DROP INDEX IF EXISTS [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL_I]
		DROP INDEX IF EXISTS [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL_I]
		DROP INDEX IF EXISTS [ix_FATimestamp] ON [Devworx].[dbo].[Devworx_ALL_I]

		DROP INDEX IF EXISTS [ix_Zip] ON [Devworx].[dbo].[Devworx_ALL_Land]
		DROP INDEX IF EXISTS [ix_StandardStatus] ON [Devworx].[dbo].[Devworx_ALL_Land]
		DROP INDEX IF EXISTS [ix_mlsid] ON [Devworx].[dbo].[Devworx_ALL_Land]
		DROP INDEX IF EXISTS [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL_Land]
		DROP INDEX IF EXISTS [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL_Land]
		DROP INDEX IF EXISTS [ix_FATimestamp] ON [Devworx].[dbo].[Devworx_ALL_Land]

		Delete from [src_PlatLabs].[dbo].[a]
			From [Devworx].[dbo].[Devworx_ALL_I] a JOIN [Devworx].[dbo].[Devworx_ALL_I_Batch] b
			ON a.MLSID = b.MLSID
			and a.ListingId = b.ListingId

			INSERT INTO [Devworx].[dbo].[Devworx_ALL_I]([MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription])
		SELECT [MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription]
			FROM [Devworx].[dbo].[Devworx_ALL_I_Batch]


		CREATE NONCLUSTERED INDEX [ix_FATimestamp] ON [Devworx].[dbo].[Devworx_ALL_I]
		([FATimestamp] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL_I]
		([FIPSCode] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL_I]
		([FIPSCode] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_mlsid] ON [Devworx].[dbo].[Devworx_ALL_I]
		([MLSID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_StandardStatus] ON [Devworx].[dbo].[Devworx_ALL_I]
		([StandardStatus] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_Zip] ON [Devworx].[dbo].[Devworx_ALL_I]
		([Zip] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]


	----- ADDED LAND NON MATCHED 20260428

			DROP INDEX IF EXISTS [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_Land_Batch]

		 TRUNCATE TABLE [Devworx].[dbo].[Devworx_ALL_Land_Batch]

		CREATE UNIQUE NONCLUSTERED INDEX [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_Land_Batch]
		([MLSID] ASC,[ListingId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

			INSERT INTO [Devworx].[dbo].[Devworx_ALL_Land_Batch]([MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription])
		Select Distinct LEFT(a.[mls_id],15)
			,CASE WHEN LEN(a.[FIPS]) = 4 then '0' + a.[FIPS] ELSE a.[FIPS] END
			,a.[PropertyID]
			,a.[REF_ID]
			,LEFT([parcel_number],50)
			,CASE WHEN LEFT(b.[FULLStreetAddress],116) is NULL THEN LEFT(a.[address],116) ELSE LEFT(b.FullStreetAddress,116) END
			,LEFT([HouseNbr],30)
			,LEFT([LeftDirection],2)
			,LEFT([Street],55)
			,LEFT([Mode],10)
			,LEFT([RightDirection],2)
			,LEFT([UnitType],20)
			,LEFT([UnitNumber],15)
			,LEFT(b.[City],55)
			,LEFT(b.[State],2)
			,LEFT(b.[Zip],10)
			,LEFT([ZIP4],10)
			,LEFT([CarrierCode],4)
			,[mls_lat]
			,[mls_lng]
			,LEFT([GeoStatusCode],1)
			,LEFT(a.[mls_listing_id],225)
			,LEFT([mls_status],50)
			,LEFT([status],50)
			,[Platlabs_Listdate]
			,LEFT([price],15)
			,LEFT([original_listing_price],15)
			,NULL 
			,[sold_date]
			,LEFT([sold_price],15)
			,LEFT([mls_property_type],50)
			,LEFT([mls_property_sub_type],50)
			,[on_market_date] 
			,[off_market_date]
			,[pending_date]
			,a.[LoadDate]
			,LEFT([days_on_market],15)
			,LEFT([photo_count],15)
			,LEFT([Appliances],1024)
			,LEFT([bedrooms],15)
			,LEFT([bathrooms_full],15)
			,LEFT([bathrooms_half],15)
			,LEFT([bathrooms],5)
			,LEFT([square_feet],15) 
			,NULL
			,LEFT([construction_materials],1024)
			,LEFT([air_conditioning],1024)
			,LEFT([exterior_features],1024)
			,LEFT([fence_description],1024)
			,NULL
			,LEFT([flooring_information],1024)
			,NULL --LEFT([FoundationDetails],1024)
			,LEFT([garage_spaces],15)
			,LEFT([heat_type],1024)
			,LEFT([interior_features],1024)
			,LEFT([above_grade_finished_area],15)
			,LEFT([lot_description],1024)
			,CASE WHEN [lot_size_units] like 'acres' then LEFT([lot_size_area],5) ELSE NULL END 
			,LEFT([lot_size_square_feet],15)
			,NULL
			,LEFT([parking_description],1024)
			,LEFT([parking_spaces],15)
			,LEFT([patio_and_porch_features],1024)
			,LEFT([pool_description],1024)
			,LEFT([roofing],1024)
			,LEFT([security_features],1024)
			,LEFT([sewer],1024)
			,LEFT([stories_total],5)
			,LEFT([utilities],1024)
			,LEFT([property_view_description],1024)
			,LEFT([water],1024)
			,LEFT([waterfront_description],1024)
			,NULL
			,LEFT([windows_description],1024)
			,LEFT([year_built],5)
			,LEFT([description],4000)
			,LEFT([confidential_description],4000)
			,NULL
			,NULL
			,LEFT([hoa_fee],10)
			,LEFT([hoa_frequency],25)
			,LEFT([hoa_fee_includes],1024)
			,LEFT([hoa_name],50)
			,LEFT([hoa_phone],16)
			,LEFT([elementary_school],50)
			,LEFT([junior_high_school],50)
			,LEFT([high_school],50)
			,LEFT([school_district],50)
			,LEFT([subdivision],50)
			,LEFT([tax_legal_description],6000)
			,LEFT([green_features],1024)
			,CASE WHEN isNULL([is_new_construction],'') = 'true' Then 'Y' Else NULL END
			,NULL
			,LEFT([total_units],5)
			,NULL
			,LEFT([lot_size_area],15)
			,LEFT([above_grade_finished_area],15)
			,LEFT([below_grade_finished_area],15)
			,NULL
			,LEFT([fireplaces],15)
			,NULL  --LEFT([YearBuiltEffective],5)
			,NULL  --[Levels]
			,LEFT([tax_year],5)
			,[financial_information]
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL  --LEFT([CoveredSpaces],15)
			,NULL
			,NULL  --LEFT([SpaYN],1024)
			,LEFT([lot_size_units],25)
			,'SQFT'
			,LEFT([rooms],15)
			,LEFT([zoning],255)
			--select count(*) 
			FROM [src_PlatLabs].[listing].[ListingsRaw] a with(NOLOCK) LEFT OUTER JOIN [src_PlatLabs].[addr].[StandardizedAddress] b with(NOLOCK)
			on a.[mls_id] = b.[mls_id]
								and a.[mls_listing_id] = b.[mls_listing_id]
			WHERE coalesce(list_date,Platlabs_listDate) <= CAST(GETDATE() as DATE)
			and property_type in('land')
			and a.REF_ID is NULL
			and isNULL(price,'') not like '%e%'
			and isNULL(original_listing_price,'') not like '%e%'
			and LoadDate > (Select MAX(FATimestamp) from [DevWorx].[dbo].[Devworx_ALL_Land] with(NOLOCK))

		ALTER INDEX [ix_MLSID_LISTINGID] ON [Devworx].[dbo].[Devworx_ALL_Land_Batch] REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		Delete from [src_PlatLabs].[dbo].[a]
			From [Devworx].[dbo].[Devworx_ALL_Land] a JOIN [Devworx].[dbo].[Devworx_ALL_Land_Batch] b
			ON a.MLSID = b.MLSID
			and a.ListingId = b.ListingId

			INSERT INTO [Devworx].[dbo].[Devworx_ALL_Land]([MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription])
		SELECT [MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription]
			FROM [Devworx].[dbo].[Devworx_ALL_Land_Batch]


		CREATE NONCLUSTERED INDEX [ix_FATimestamp] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([FATimestamp] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([FIPSCode] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([FIPSCode] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_mlsid] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([MLSID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_StandardStatus] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([StandardStatus] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_Zip] ON [Devworx].[dbo].[Devworx_ALL_Land]
		([Zip] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]





		UPDATE [AZUVPSQLADSF001].Jobs.[dbo].[SystemProperty] 
		SET [Value] = 'N'
		,[UpdateDate] = GetDate()
		WHERE [Name] = 'IsDevworxRunning'


	DECLARE @To2 varchar(255) = 'jeschmeyer@firstam.com;mikes@platlabs.com;adamf@platlabs.com', 
	--DECLARE @To2 varchar(255) = 'micsmith@firstam.com', 
	@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
	@t_subject2 varchar(50) = 'DAAS PLATLABS',
	@t_body2 varchar(2000) = 'The DAAS Platlabs Devworx data is ready to extract'


	SET NOCOUNT ON;
	DECLARE @t_getdate2 datetime = GETDATE()
	SET @t_body2 = @t_body2 + '**** ' + cast(@t_getdate2 as varchar(20)) + ' PT ****'

	EXEC msdb.dbo.sp_send_dbmail
		@recipients = @To2,
		@profile_name = @t_profile_name2,
		@subject = @t_subject2,
		@body = @t_body2


	END

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

 
END




