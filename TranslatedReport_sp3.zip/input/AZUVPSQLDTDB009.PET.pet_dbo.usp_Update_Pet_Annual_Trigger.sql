/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Update_Pet_Annual_Trigger | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

--CREATE
--	OR

CREATE PROCEDURE [PET].[pet_dbo].[usp_Update_Pet_Annual_Trigger] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
-- declare @ERROR VARCHAR(500)  , @fips INT = 5143 , @Refresh BIT = 0
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555, N'info'
		,N'usp_Update_Pet_Annual_Trigger'
		,N'Started'

	DECLARE @SQL VARCHAR(MAX)
		,@LinkSvr VARCHAR(100) = ''

	--IF @@SERVERNAME <> 'AZUVNSQLDTDB003'
	SET @LinkSvr = CASE 
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB009'
				THEN '[DWS-ETL01].'
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB029'
				THEN '[DWS-ETL01.DATATREE.LOCAL].'
			ELSE ''
			END;
	SET @SQL = '


		UPDATE a
		SET a.Process_Flag = 1
		FROM pet.dbo.PET_Enhanced_Process_List a
		--where a.fips 
		WHERE a.fips IN (
				SELECT fips
				FROM ' + @LinkSvr + 'assr.[pet_tmp].[pet_daily_tracker] 
				where refresh = 1
				)
			'

	--Print @SQL
	EXEC (@SQL)

	EXEC [PET].[dbo].[AddPetlog] 55555, N'info'
		,N'usp_Update_Pet_Annual_Trigger'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


