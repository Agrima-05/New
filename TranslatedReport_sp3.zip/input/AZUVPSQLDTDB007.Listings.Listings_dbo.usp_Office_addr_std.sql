/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Office_addr_std | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Office_addr_std] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Office_addr_std'

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'

	INSERT INTO [LISTINGS].[Listings_dbo].[Listings_Agent_Office_Std_Addr] (
		[Addr_type]
		,[Property_ID]
		,[FIPS]
		,[REF_ID]
		,[HouseNumber]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STD_State]
		,[Zip]
		,[Plus4]
		,[CRRT]
		,[CountyName]
		,[PMB]
		,[PMSA]
		,[MSA]
		,[ZipType]
		,[Urbanization]
		,[CongressionalDistrict]
		,[CountryCode]
		,[CityAbbreviation]
		,[AddressTypeCode]
		,[AddressTypeString]
		,[DPV_Count]
		,[DPV_Footnotes]
		,[CMRA]
		,[ELOT_Number]
		,[ELOT_Order]
		,[LACS]
		,[LACS_LinkIndicator]
		,[EWS_Flag]
		,[RBDI]
		,[SuiteLinkReturnCode]
		,[DeliveryPointCheckDigit]
		,[DeliveryPointCode]
		,[CensusBlock]
		,[CensusTract]
		,[PlaceCode]
		,[PlaceName]
		,[CBSACode]
		,[CBSALevel]
		,[CBSATitle]
		,[CBSADivisionCode]
		,[CBSADivisionLevel]
		,[CBSADivisionTitle]
		,[Latitude]
		,[Longitude]
		,[Verified]
		,[Geocoded]
		,[AddressMatchResults]
		,[GeoErrorCode]
		,[GeoStatusCode]
		,[Created]
		,[Raw_Address]
		)
	SELECT 'O' AS [Addr_type]
		,0 AS [Property_ID]
		,aa.CountyFips AS [FIPS]
		,NULL AS [REF_ID]
		,substring(aa.StreetNumber, 1, 30) AS HouseNumber
		,substring(aa.StreetNumber, 1, 25) AS Street_Number
		,substring(aa.PreDir, 1, 2) AS Direction
		,substring(aa.StreetName, 1, 50) AS Street_Name
		,substring(aa.StreetType, 1, 4) AS street_Type
		,substring(aa.PostDir, 1, 2) AS Post_Direction
		,substring(aa.SuiteType, 1, 10) AS Unit_Type
		,substring(aa.Suite, 1, 6) AS Unit
		,substring(aa.City, 1, 55) AS City
		,substring(aa.STATE, 1, 2) AS STD_State
		,substring(aa.Zip, 1, 5) AS Zip
		,substring(aa.Plus4, 1, 4) AS Plus4
		,substring(aa.CarrierRoute, 1, 4) AS CRRT
		,substring(aa.CountyName, 1, 35) AS CountyName
		,substring(aa.PrivateMailbox, 1, 30) AS PMB
		,substring(aa.Pmsa, 1, 2) AS PMSA
		,substring(aa.Msa, 1, 70) AS MSA
		,substring(aa.ZipType, 1, 2) AS ZipType
		,substring(aa.Urbanization, 1, 6) AS Urbanization
		,substring(aa.CongressionalDistrict, 1, 2) AS CongressionalDistrict
		,substring(aa.CountryCode, 1, 10) AS CountryCode
		,substring(aa.CityAbbreviation, 1, 13) AS CityAbbreviation
		,substring(aa.AddressTypeCode, 1, 1) AS AddressTypeCode
		,substring(aa.AddressTypeString, 1, 60) AS AddressTypeString
		,substring('', 1, 5) AS DPV_Count
		,substring(aa.DPVFootNotes, 1, 4) AS DPV_Footnotes
		,substring(aa.CMRA, 1, 1) AS CMRA
		,substring(aa.ELotNumber, 1, 5) AS ELOT_Number
		,substring(aa.ELotOrder, 1, 2) AS ELOT_Order
		,substring(aa.Lacs, 1, 1) AS LACS
		,substring(aa.LACSLinkIndicator, 1, 1) AS LACS_LinkIndicator
		,substring(aa.EWSFlag, 1, 1) AS EWS_Flag
		,substring(aa.RBDI, 1, 1) AS RBDI
		,substring(aa.SuiteLinkReturnCode, 1, 1) AS SuiteLinkReturnCode
		,substring(aa.DeliveryPointCheckDigit, 1, 1) AS DeliveryPointCheckDigit
		,substring(aa.DeliveryPointCode, 1, 2) AS DeliveryPointCode
		,substring(aa.CensusBlock, 1, 4) AS CensusBlock
		,substring(aa.CensusTract, 1, 6) AS CensusTract
		,substring(aa.PlaceCode, 1, 7) AS PlaceCode
		,substring(aa.PlaceName, 1, 60) AS PlaceName
		,substring(aa.CBSACode, 1, 5) AS CBSACode
		,substring(aa.CBSALevel, 1, 30) AS CBSALevel
		,substring(aa.CBSATitle, 1, 50) AS CBSATitle
		,substring(aa.CBSADivisionCode, 1, 5) AS CBSADivisionCode
		,substring(aa.CBSADivisionLevel, 1, 30) AS CBSADivisionLevel
		,substring(aa.CBSADivisionTitle, 1, 50) AS CBSADivisionTitle
		,aa.Latitude AS Latitude
		,aa.Longitude AS Longitude
		,aa.Verified AS Verified
		,aa.Geocoded AS Geocoded
		,substring(aa.AddressMatchResults, 1, 30) AS AddressMatchResults
		,substring(aa.GeoErrorCode, 1, 1) AS GeoErrorCode
		,substring(aa.GeoStatusCode, 1, 1) AS GeoStatusCode
		,getdate() AS Created
		,substring(a1.MLS_OFFICE_ADDRESS, 1, 200) AS Raw_Address
	-- select top 100 a.MLS_OFFICE_ADDRESS , aa.* 
	FROM (
		SELECT DISTINCT a.MLS_OFFICE_ADDRESS
		FROM [listings].[Listings_dbo].[FA_MLS_Wrk] a
		LEFT JOIN [LISTINGS].[Listings_dbo].[Listings_Agent_Office_Std_Addr] bb WITH (
				NOLOCK
				,INDEX (Listings_Agent_Office_Std_Addr_Raw_Address)
				) ON bb.Raw_Address = a.MLS_OFFICE_ADDRESS
		WHERE a.MLS_OFFICE_ADDRESS > ''
			AND bb.Raw_Address IS NULL
		) a1
	OUTER APPLY (
		SELECT *
		FROM [Addr].[dbo].[StandardizeAddressFreeForm](0, 1, a1.MLS_OFFICE_ADDRESS)
		) aa
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


