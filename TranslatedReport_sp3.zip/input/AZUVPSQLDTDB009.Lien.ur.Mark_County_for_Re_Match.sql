/* Source: AZUVNSQLDTDB003.datatree.local | Lien | ur.Mark_County_for_Re_Match | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Sunwoo Park>
-- Create date: <2026-02-23> 
-- Description:	<Nova ref rematch> 
-- =============================================
CREATE PROCEDURE [Lien].[ur].[Mark_County_for_Re_Match] (@fips INT)
AS
DECLARE @ERROR VARCHAR(500)
	,@Txt VARCHAR(50)

BEGIN TRY
	SET @Txt = CONCAT (
			'Mark_County_for_Re_Match - '
			,@fips
			)

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Started'

	--
	--


UPDATE [Lien].[ur].[r]
SET r.[Status] = 'To_be_Run'
	,r.[Modified_Date] = GETDATE()
	,r.[Promote] = 'Production'
	,r.Ref_Status = NULL
	,r.Ref_Modified_Date = NULL
	,r.cnt_ref_rematch_before = 0
	,r.cnt_nova_doc_found_before = 0
	,r.cnt_nova_ref_found_before = 0
	,r.cnt_ref_rematch_after = 0
	,r.cnt_nova_doc_found_after = 0
	,r.cnt_nova_ref_found_after = 0
FROM [Lien].[dbo].[Lien_Rematch] r
WHERE Fips = @fips



	--
	--
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END
END CATCH


