/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_detect_neo_updates_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_detect_neo_updates_Incr]
	-- @Fips INT          
	--,@Neo_Counties VARCHAR(5)          
	--,@Land_Id_Ind VARCHAR(6)          
	--,@Neo_server VARCHAR(100)          
	--,@LLL_update_date datetime      
	--,@update_count int output      
	@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************          
CHANGE LOG:          
==========          
who  date  change          
           
	Determine if a county needs to run incremental, Full annual or not at all
******************************************************************************************************************/
BEGIN TRY
	SET NOCOUNT ON

	 



	-- SELECT * FROM pet.Pet_tmp.Pet_Incremental_Counties          
	--DECLARE @Fips INT = 2020          
	-- ,@Neo_Counties VARCHAR(5) = 'AK03'          
	-- ,@Land_Id_Ind VARCHAR(6) = 'FLNS'          
	-- ,@Neo_server VARCHAR(100) = '[AZUVNSQLDTLM008.DATATRACE.LOCAL]'          
	--    select count(1) FROM [AZUVNSQLDTLM009.DATATRACE.LOCAL].[Neo].[FL55].[LVL_land_links]  where LLL_update_date >  '20230223 00:29:10.000' order by LLL_update_date desc      
	-- there must be a while to updatge hte pet_counties table if no update found on LVL_land_links      
	DECLARE @fips INT = 99999

		EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_detect_neo_updates_Incr'
		,N'Started'

	SET @fips = (
			SELECT TOP 1 c.fips
			FROM [pet].[dbo].[pet_counties] c
			LEFT JOIN [pet].[dbo].[pet_enhanced_process_list] p WITH (
					NOLOCK
					,INDEX (idxc_fips)
					) ON p.fips = c.fips
			WHERE c.Stage_SSIS_connection IS NOT NULL
				AND c.Incremental_Process_Date IS NULL --not null?    
				AND p.process_flag = 0
			ORDER BY c.fips
			)

	WHILE @fips IS NOT NULL
	BEGIN
		DECLARE @Neo_Counties VARCHAR(6)
			,@Land_Id_Ind VARCHAR(6)
			,@Neo_server VARCHAR(100)
			,@Neo_Date DATETIME
			,@Neo_DB VARCHAR(6)
			,@SQL VARCHAR(max)

		SELECT @Neo_Counties = neo_counties
			,@Land_Id_Ind = Land_Id_Ind
			,@Neo_Server = CASE 
				WHEN @@SERVERNAME = 'AZUVNSQLDTDB003'
					THEN ltrim(rtrim(Stage_SSIS_Connection))
				ELSE ltrim(rtrim(Prod_SSIS_Connection))
				END
			,@Neo_Date = CASE 
				WHEN @@SERVERNAME = 'AZUVNSQLDTDB003'
					THEN Stage_Max_Neo_Update_Date
				ELSE Prod_Max_Neo_Update_Date
				END
		FROM [pet].[dbo].[pet_counties]
		WHERE fips = @Fips


		SET @Neo_DB = CASE 
				WHEN @Neo_Counties IN (
						'NV02'
						,'TR00'
						,'US00'
						,'WA06'
						,'WA08'
						,'WA11'
						,'WA14'
						,'WA15'
						,'WA17'
						,'WA18'
						,'WA21'
						,'WA23'
						,'WA27'
						,'WA29'
						,'WA31'
						,'WA32'
						,'WA34'
						,'WA37'
						,'WA39'
						,'WA19'
						)
						and @@SERVERNAME = 'AZUVNSQLDTDB003' 
					THEN 'Neo_WA'
				ELSE 'Neo'
				END

		--SELECT @Neo_Counties      
		--,@Land_Id_Ind      
		--,@Neo_server     
		--,@Neo_Date     
		--print('here before if else block ' + cast(@fips as varchar) + ' ' + cast(@neo_date as varchar))    
		--Delete county at fips from pet_incremental_counties when the neo_date is null so it is not ran through the package    
		IF (@Neo_Date IS NULL)
		BEGIN
			DELETE [pet].[pet_tmp].[Pet_Incremental_Counties]
			WHERE Fips = @fips

			UPDATE [pet].[dbo].[pet_counties]
			SET incremental_process_date = GETDATE()
			WHERE fips = @fips
		END
		ELSE
		BEGIN
			SET @SQL = (
					'update c    
			  set c.incremental_process_date = GETDATE()    
			  from pet.dbo.pet_counties c    
			  where     
			   c.Fips = ' + CAST(@Fips AS VARCHAR) + ' and    
			   (    
				select count(1) FROM [' + @Neo_Server + '].[' + @Neo_DB + '].[' + @Neo_Counties + '].[LVL_land_links]  where LLL_link_type = ''XR'' and LLL_update_date >  ''' + CONVERT(VARCHAR, @Neo_Date, 13) + '''    
			   ) = 0;'
					)

			--CAST(@Neo_date as VARCHAR)    
			--CONVERT(varchar,@Neo_Date,13)    
			--select @fips    
			--need server name, county code,     
			--select count(1) FROM [AZUVNSQLDTLM009.DATATRACE.LOCAL].[Neo].[FL55].[LVL_land_links]  where LLL_update_date >  '20230223 00:29:10.000' order by LLL_update_date desc      
			--print for testing    
			--PRINT(@SQL)    
			EXEC (@SQL)
		END

		DELETE tmpCounties
		FROM [pet].[Pet_tmp].[Pet_Incremental_Counties] AS tmpCounties
		INNER JOIN [PET].[dbo].[pet_counties] AS petCounties ON petCounties.Fips = tmpCounties.fips
		WHERE tmpCounties.fips = @Fips
			AND tmpCounties.Incremental_Process_Date IS NULL
			AND petCounties.Incremental_Process_Date IS NOT NULL

		IF (
				@Neo_Date IS NOT NULL
				AND @fips IN (
					SELECT Fips
					FROM [pet].[pet_tmp].[Pet_Incremental_Counties]
					)
				)
		BEGIN
			SELECT (@Neo_Counties)

			SET @SQL = (
					'drop table if exists #testPerc    
   select SUM(1) as totalCount, sum(case when lll_update_Date > ''' + CONVERT(VARCHAR, @Neo_Date, 13) + ''' then 1 else 0 end) as numChanged   
   , max(lll_update_Date) as MAX_NEO_Update_date
      into #testPerc    
      from [' + @Neo_Server + '].[' + @Neo_DB + '].[' + @Neo_Counties + '].[LVL_land_links]    
      where lll_update_Date is not null and LLL_link_type = ''XR''    
  
      if((select CAST(numChanged as decimal) / CAST(totalCount AS decimal) as div from #testPerc) > .02)  
		 begin   
		
		  update County     
		  set County.Incremental_Process_Date = GETDATE()    
		  from pet.dbo.PET_Counties as County    
		  where County.Fips = ' + CAST(@fips AS VARCHAR) + ';    
  
		  update EnhancedList    
		  set EnhancedList.Process_Flag = 1    
		  from pet.dbo.pet_enhanced_process_list as EnhancedList with(nolock, index(idxc_fips))    
		  where EnhancedList.FIPS = ' + CAST(@fips AS VARCHAR) + 
					';    
  
		  delete tmpCounty    
		  from pet.pet_tmp.Pet_Incremental_Counties as tmpCounty    
		  inner join PET.dbo.pet_counties as petCounties with(nolock, index(idxc_fips)) on petCounties.Fips = tmpCounty.fips     
		  where tmpCounty.fips = ' + CAST(@fips AS VARCHAR) + ' and tmpCounty.Incremental_Process_Date is null and petCounties.Incremental_Process_Date is not null  
		 end
		 
		 update a set a.MAX_NEO_Update_date = isnull(b.MAX_NEO_Update_date,getdate())  from pet.pet_tmp.Pet_Incremental_Counties a
		 outer apply (select MAX_NEO_Update_date from #testPerc ) b
		 where a.fips = ' + CAST(@fips AS VARCHAR)
					)

			--PRINT(@SQL)    
			EXEC (@SQL)
		END

		SET @fips = (
				SELECT TOP 1 c.fips
				FROM [pet].[dbo].[pet_counties] c
				LEFT JOIN [pet].[dbo].[pet_enhanced_process_list] p WITH (
						NOLOCK
						,INDEX (idxc_fips)
						) ON p.fips = c.fips
				WHERE c.Stage_SSIS_connection IS NOT NULL
					AND c.Incremental_Process_Date IS NULL
					AND p.process_flag = 0
					AND c.fips > @fips
				ORDER BY c.fips
				)
	END

	--testing purposes  
	--so that if after testing you want to re run the counties that just previously ran through the package, reset the stage_max_neo_date  
	--to the corresponding fips date  
	--of course also reset incremental process date column to null  
	--drop table if exists pet.pet_tmp.pet_incremental_counties_temp_dates  
	--select incr.Fips, incr.NEO_Counties, counties.Stage_Max_NEO_Update_date  
	--into pet.pet_tmp.pet_incremental_counties_temp_dates  
	--from pet.pet_tmp.Pet_Incremental_Counties as incr  
	--inner join pet.dbo.pet_counties as counties on incr.Fips = counties.Fips;  

	SET @fips = 99999

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_detect_neo_updates_Incr'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


