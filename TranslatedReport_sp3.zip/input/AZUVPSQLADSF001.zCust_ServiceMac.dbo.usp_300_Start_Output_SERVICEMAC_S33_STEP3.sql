SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_300_Start_Output_SERVICEMAC_S33_STEP3]

AS
BEGIN
	
	

		/****** Object:  Index [NonClusteredIndex-20180712-100727]    Script Date: 8/31/2018 6:54:05 PM ******/
		CREATE UNIQUE NONCLUSTERED INDEX [NonClusteredIndex-NOD] ON [dbo].[x_Custom_OUTPUT_S33]
		(
			[NOD_NOS_RecordedDocumentNumber] ASC,
			[NOD_NOS_RecordingDate] ASC,
			[INPUTKey] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	

		Truncate table NOD_NOS_RELEASE_COMBINED

		
		Insert into [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED]([INPUTKEY],[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr]
	   --,[SUP]
	   )
	   Select A.[INPUTKey],NULL,convert(date,B.REcordingDate) as NOD_NOS_RecordingDate,B.DocumentID as NOD_NOS_RecordedDocumentNumber
		,B.Document_Title_Text as NOD_NOS_DocType
		, B.LienAmount as NOD_NOS_DefaultAmount
		, B.LawName as HOA_TrusteeAttorneyName
		,B.LawPhone as HOA_TrusteeAttorneyPhoneNumber
		,B.Auction_Date as HOA_AuctionDate
		,B.OrigRecDate as NOD_NOS_OrigRecDate
		,B.OrigDocNbr as NOD_NOS_OrigDocNbr
		--,B.[SUP]
		--,A.Work_REF_ID
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] A JOIN [zCust_ServiceMac].[dbo].[HOA_NOD] as B 
		on A.[INPUTKey] = B.[INPUTKEY]


	

		
		UPdate [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Set [NbrofRecordings_NOD_NOS] = NULL
		
		UPDATE [zCust_ServiceMac].[dbo].[a]
		SET a.[NbrofRecordings_NOD_NOS] = b.[NbrofRecordings_NOD_NOS]
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] a JOIN (SELECT [INPUTKEY],count(*)  as [NbrofRecordings_NOD_NOS] FROM [zCust_ServiceMac].[dbo].[HOA_NOD] 
		GROUP BY [INPUTKEY]) b
		on A.[INPUTKey] = B.[INPUTKEY]


		

			Update [zCust_ServiceMac].[dbo].[HOA_NOD_NOS_RELEASE]
			Set REcordNumber = 0

		
			UPDATE [zCust_ServiceMac].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_ServiceMac].[dbo].[HOA_NOD_NOS_RELEASE] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY],REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_ServiceMac].[dbo].[HOA_NOD_NOS_RELEASE] t ) r ON t.REF_ID = r.REF_ID AND (t.NOD_NOS_Recorded_Document_Number = r.NOD_NOS_Recorded_Document_Number 
			OR t.DocumentId = R.DocumentId)
			and t.[INPUTKEY] = r.[INPUTKEY]



		------------------------COMBINED NOD_NOS_RELEASE-----------
		Insert into [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED]([INPUTKEY],[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr]
	   --,[SUP]
	   )

	   Select 	distinct A.[INPUTKey],NULL,
	   convert(date,convert(varchar(10),B.REcordingDate,126))
		, B.NOD_NOS_Recorded_Document_Number
		,D.Full_Name
		, B.LienAmount
		, B.LawName
		, B.LawPhone
		,NULL
		,NULL
		,NULL
		--Select B.* 	
		--,[SUP]						
		FROM  [zCust_ServiceMac].[dbo].[HOA_NOD_NOS_RELEASE] as B 
		join [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] A 
		on A.[INPUTKey] = B.[INPUTKEY]
		join [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705] as D
		on B.DocType = D.[HOA_Doc_Type]
		



			Update [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED]
			Set REcordNumber = 0

		
			UPDATE [zCust_ServiceMac].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY] ORDER BY [NOD_NOS_RecordingDate] DESC) AS RowNum
				FROM 
			[zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] t ) r ON t.[INPUTKEY] = r.[INPUTKEY] AND (t.[NOD_NOS_RecordedDocumentNumber] = r.[NOD_NOS_RecordedDocumentNumber])
			and t.[INPUTKEY] = r.[INPUTKEY]


			Update [zCust_ServiceMac].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.[INPUTKey],A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_ServiceMac].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			(A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Inst_Nbr OR 
			A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Book_Page 
			)
			where 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null


			
			Update [zCust_ServiceMac].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.[INPUTKey],A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_ServiceMac].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			A.NOD_NOS_RecordedDocumentNumber =
			left(Fmt_Inst_Nbr,len(Fmt_Inst_Nbr)-charindex('.',REVERSE(Fmt_Inst_Nbr))) + '.' 
			+ SUBSTRING(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1), PATINDEX('%[^0]%', Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)+'.'), LEN(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)))
			where A.NOD_NOS_RecordedDocumentNumber like '%.%.%'
			AND Fmt_Inst_Nbr like '%.%.%'
			AND 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null





		----------------20181004 - KL - Per NH - populate NOD/NOS fields first - then build down with what is left-------


		---********************Uncomment & RUN!!!!!!!!*********************************
		Update [zCust_ServiceMac].[dbo].[A]
		Set 
		A.NOD_NOS_RecordNbr = B.REcordNumber
		,A.NOD_NOS_RecordingDate = B.NOD_NOS_RecordingDate
		,A.NOD_NOS_RecordedDocumentNumber = B.NOD_NOS_RecordedDocumentNumber
		,A.NOD_NOS_DocType = B.NOD_NOS_DocType
		,A.NOD_NOS_DefaultAmount = B.NOD_NOS_DefaultAmount
		,A.HOA_TrusteeAttorneyName = B.HOA_TrusteeAttorneyName
		,A.HOA_TrusteeAttorneyPhoneNumber = B.HOA_TrusteeAttorneyPhoneNumber
		,A.HOA_AuctionDate = B.HOA_AuctionDate
		--,A.NOD_NOS_OrigRecDate = B.NOD_NOS_OrigRecDate
		--,A.NOD_NOS_OrigDocNbr =  B.NOD_NOS_OrigDocNbr
		------------Added 20190329 to track SUP records----
		--,A.NOD_NOS_SUP = B.SUP
		--Select * 																	
		FROM  [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] as B 
		join [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] A 
		on A.[INPUTKey] = B.[INPUTKEY]
		WHERE B.REcordNumber = 1
		And A.NOD_NOS_RecordNbr is null
		

	


		UPdate [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Set [NbrofRecordings] = 0
		
		UPDATE [zCust_ServiceMac].[dbo].[a]
		SET a.[NbrofRecordings] = b.NbrOfRecordings
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] a JOIN (SELECT [INPUTKEY],count(*)  as NbrOfRecordings FROM [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED] 
		GROUP BY [INPUTKEY]) b
		on A.[INPUTKey] = B.[INPUTKEY]


		--Select MAX(convert(int,[NbrofRecordings_RELEASED])) FROM x_Custom_OUTPUT_S33
		--Select MAX(convert(int,NOD_NOS_RELEASE_COMBINED)) FROM x_Custom_OUTPUT_S33
		Select MAX(convert(int,[NbrofRecordings])) FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Select MAX(convert(int,[Number of HOA Liens])) FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]

		--Select FIPS,[INPUTKey], NbrofRecordings, NbrofRecordings_NOD_NOS, NOD_NOS_RecordNbr From x_Custom_OUTPUT_S33
		--order by convert(int,[NbrofRecordings]) desc


		----------------------------------------BUILD DOWN    COMBINED-----NOD_NOS_RELEASES PER NH 20181004------------------------------------
		IF (Select max(convert(int,RecordNumber)) from [zCust_ServiceMac].[dbo].[NOD_NOS_RELEASE_COMBINED]) > 1
		BEGIN
		
		Truncate table dbo.RELEASE_BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ServiceMac].[dbo].[RELEASE_BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ServiceMac].[sys].[tables] as A join [zCust_ServiceMac].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S33'
			and B.Name not in ('NOD_NOS_RecordNbr','NOD_NOS_RecordingDate ','NOD_NOS_RecordedDocumentNumber','NOD_NOS_DocType','NOD_NOS_DefaultAmount'
			,'HOA_TrusteeAttorneyName','HOA_TrusteeAttorneyPhoneNumber','HOA_AuctionDate'
			--,'NOD_NOS_OrigRecDate','NOD_NOS_OrigDocNbr'
			,'NOD_NOS_SUP')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.RELEASE_BUILD_DOWN_COLUMNS


		--If (Select MAX(convert(int,NbrofRecordings_RELEASED)) FROM x_Custom_OUTPUT_S33) > 0
		--BEGIN

		

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ServiceMac].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ServiceMac].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[NbrofRecordings])) FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S33(
												' +  @FIELDLIST3 + '

												  ,[NOD_NOS_RecordNbr]
												  ,[NOD_NOS_RecordingDate]
												  ,[NOD_NOS_RecordedDocumentNumber]
												  ,[NOD_NOS_DocType]
												  ,[NOD_NOS_DefaultAmount]
												  ,[HOA_TrusteeAttorneyName]
												  ,[HOA_TrusteeAttorneyPhoneNumber]
												  ,[HOA_AuctionDate]
												  --,[NOD_NOS_OrigRecDate]
												  --,[NOD_NOS_OrigDocNbr]
												  --,[NOD_NOS_SUP]
												  )
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												 ,B.REcordNumber
												  ,B.[NOD_NOS_RecordingDate]
												  ,B.[NOD_NOS_RecordedDocumentNumber]
												  ,B.[NOD_NOS_DocType]
												  ,B.[NOD_NOS_DefaultAmount]
												  ,B.[HOA_TrusteeAttorneyName]
												  ,B.[HOA_TrusteeAttorneyPhoneNumber]
												  ,B.[HOA_AuctionDate]
												  --,B.[NOD_NOS_OrigRecDate]
												  --,B.[NOD_NOS_OrigDocNbr]
												  --,B.[SUP]
										--Select B.* 	
										
										FROM  NOD_NOS_RELEASE_COMBINED as B 
										join x_Custom_OUTPUT_S33 A 
										on A.[INPUTKey] = B.[INPUTKEY]
										WHERE 
										B.REcordNumber = ''' + @BeginNbrOfTrans6 + '''
										')
										

												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			
		--Select * From x_Custom_OUTPUT_S33
		--where NbrofRecordings > 0
		--Order by NOD_NOS_RecordNbr desc,INPUT Unique RecordID


		--Select count(*) FRom a_ASP_IN_STD

		

		Update  [zCust_ServiceMac].[dbo].[a]
		SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] a JOIN [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKey] = b.Raw_ID


		
	

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		SET [Property Status] = CASE WHEN WORK_REF_ID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_ServiceMac].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		--Select * 
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] a join [zCust_ServiceMac].[dbo].[a_PropMatch_WORK] b
		on a.[INPUTKey] = b.RAW_ID
		WHERE b.MultiMatch = 'M' and a.Work_REF_ID is null

			

		UPDATE [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] 
		Set  [Event Status] = NULL

		


		--------------------Changed to ONLY return Event Found when HOA Lien, NOD/NOS, REscission/Release found per NH 20190125----
		UPDATE [zCust_ServiceMac].[dbo].[A] 
		Set  A.[Event Status] = case when [Number of HOA Liens] > 0 OR NbrOfRecordings > 0
		or NbrofRecordings_RELEASED > 0
		then 'Event Found' ELSE 'Event Not Found' END
		--Select A.[INPUTKey] ,A.[HAS_HOA_RECORD],B.[HOA_FOUND]
		From   [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		as A 


		-------DELETING RECORDS WITH NO EVENTS AND NOT NEWLY ADDED----
		Delete from [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		where [Event Status] like 'Event Not Found'
		and DATE_ADDED < Getdate()-5

		
		
						


		-----------------------UNCOMMENT & RUN to FIND MAX RECORD DATE-----------------
		IF  EXISTS (SELECT * FROM [zCust_ServiceMac].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[FIND_MAX_RECORD]') AND type in (N'U'))
		DROP TABLE [dbo].[FIND_MAX_RECORD]

		IF(Select count(*) From  [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		where [Number of HOA Liens] > 0) > 0 
		BEGIN

		EXEC('Select A.* into [dbo].[FIND_MAX_RECORD]
		From 
		(
		Select [INPUTKey], WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT_S33
		where [Number of HOA Liens] > 0
		
		UNION ALL
		
		Select [INPUTKey], WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT_S33
		where NbrOfRecordings > 0
		)A

		join 
		(Select [INPUTKey],WORK_REF_ID,max(RECORD_DATE) as MAXDATE FROM (
		Select [INPUTKey], WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT_S33
		where [Number of HOA Liens] > 0
		
		UNION ALL
		
		Select [INPUTKey], WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT_S33
		where NbrOfRecordings > 0
		)A
		Group by [INPUTKey],WORK_REF_ID) B  
		on A.[INPUTKey] = B.[INPUTKey]
		and A.RECORD_DATE = B.MAXDATE

		


		Select DoCType, count(*) From [FIND_MAX_RECORD]
		Group by DocType

		')


		END

	
		
		--DECLARE @FIELDNAME varchar(200)
		--DECLARE CLEAN_cursor CURSOR FOR  
		--Select '[' + NAME + ']' From sys.columns
		--where Object_ID = 
		--(Select OBJECT_ID FROM sys.tables
		--where NAME = 'x_Custom_OUTPUT_S33')
		--and 
		--(NAME like '%DocType%' )
		--order by NAME

		--	OPEN CLEAN_cursor   
		--	FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME

		--	WHILE @@FETCH_STATUS = 0   
		--		BEGIN   
		--				EXEC('
		--				Select ' + @FIELDNAME + ', count(*) as TOTAL from  [x_Custom_OUTPUT_S33]
		--				Group by ' + @FIELDNAME + ' 
		--				')
			

		--			FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME   
		--		END   

		--CLOSE CLEAN_cursor   
		--DEALLOCATE CLEAN_cursor
		  



		UPDATE [zCust_ServiceMac].[dbo].[A]
		Set A.HAS_HOA_RECORD = 'Y'
		From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]  as A 
		join [zCust_ServiceMac].[dbo].[LIEN_TRACKING_HIST] as B on 
		A.[INPUTKey] = B.[INPUTKEY]
		where A.HAS_HOA_RECORD is null or A.HAS_HOA_RECORD like ''


		
		Select [AddressStandardization], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [AddressStandardization]
	

		Select [Event Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [Event Status]

		Select [Property Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [Property Status]

		Select * From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		where [Event Status] like 'Event Found' and [Property Status] in ('Property Not Found','Multiple Properties Found')




		Select [Event Status], count(*) from (
		Select [INPUTKey],[Event Status], count(*) as TOTAL From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [INPUTKey],[Event Status])A
		Group  by [Event Status]

		--Select [CoverageStatus_PREFC], count(*) From x_Custom_OUTPUT_S33
		--Group by [CoverageStatus_PREFC]

		Select [CoverageStatus_HOA_LIEN], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [CoverageStatus_HOA_LIEN]

		Select count(*) From  [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		where [CoverageStatus_HOA_LIEN] = 'Y'
		and [HAS_HOA_RECORD] = 'Y'
		
		--Select [AddressMatch], count(*) From x_Custom_OUTPUT_S33
		--Group by [AddressMatch]

		Select [HAS_HOA_RECORD], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33]
		Group by [HAS_HOA_RECORD]

		--Select [Prioritization], count(*) From x_Custom_OUTPUT_S33
		--Group by [Prioritization]




		------------------HOA Liens------------------
		--Select  A.FIPS, WORK_REF_ID, HAS_HOA_RECORD,[PROPERTYID],A.[INPUTKey]
		----,DATE_ADDED
		--,A.[INput Address], [Event Status],[Super Lien State]
		----,[FREEBIE]
		----,[LastDocTypeRecorded]
		--,Number of HOA Liens
		--,HOA_LienRecordingDate_001 ,HOA_LienRecordedDocumentNumber_001      ,HOA_LienAmount_001       ,HOA_LienName_001, HOA_LienDocType_001--,[HOA_SUP_001]
		--,HOA_LienRecordingDate_002 ,HOA_LienRecordedDocumentNumber_002      ,HOA_LienAmount_002       ,HOA_LienName_002, HOA_LienDocType_002--,[HOA_SUP_002]
		--,HOA_LienRecordingDate_003 ,HOA_LienRecordedDocumentNumber_003      ,HOA_LienAmount_003       ,HOA_LienName_003, HOA_LienDocType_003--,[HOA_SUP_003]
		----,HOA_LienRecordingDate_004 ,HOA_LienRecordedDocumentNumber_004      ,HOA_LienAmount_004       ,HOA_LienName_004, HOA_LienDocType_004
		----,HOA_LienRecordingDate_005 ,HOA_LienRecordedDocumentNumber_005      ,HOA_LienAmount_005       ,HOA_LienName_005, HOA_LienDocType_005
		----,HOA_LienRecordingDate_006 ,HOA_LienRecordedDocumentNumber_006      ,HOA_LienAmount_006       ,HOA_LienName_006, HOA_LienDocType_006
		----,HOA_LienRecordingDate_007 ,HOA_LienRecordedDocumentNumber_007      ,HOA_LienAmount_007       ,HOA_LienName_007, HOA_LienDocType_007
		----,HOA_LienRecordingDate_008 ,HOA_LienRecordedDocumentNumber_008      ,HOA_LienAmount_008       ,HOA_LienName_008, HOA_LienDocType_008
		--,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount
		--,A.MAX_LIENDATE
		--,B.State, B.[County Name]
		--From dbo.x_Custom_OUTPUT_S33 as A join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		----join INPUT_MONITOR as C on A.[INPUTKey] = C.INPUT Unique RecordID
		--where Number of HOA Liens > 0
		--Order by [Event Status],Number of HOA Liens desc

		
		


		--Select  A.FIPS, WORK_REF_ID, A.[INPUTKey],[Event Status],A.INPUTStreetAddress,[Number of HOA Liens],NbrofRecordings,[NbrofRecordings_NOD_NOS]
		--,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount
		--,B.State, B.[County Name]
		--From dbo.x_Custom_OUTPUT_S33 as A join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		----join INPUT_MONITOR as C on A.[INPUTKey] = C.INPUT Unique RecordID
		--where [Number of HOA Liens] > 0
		----and EventStatus like 'Event Found'
		--Order by [INPUTKey],NbrofRecordings desc,  NOD_NOS_RecordNbr


	 
	 Select top 10000 INPUTKEY, WORK_REF_ID, PropertyID, [Number of HOA Liens], NbrofRecordings, [Event Status]
	 ,NbrofRecordings_NOD_NOS, *
	 From  [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S33] A
	 Order by A.[Number of HOA Liens] desc, A.[NbrofRecordings] desc, A.INPUTKEY

	


END



