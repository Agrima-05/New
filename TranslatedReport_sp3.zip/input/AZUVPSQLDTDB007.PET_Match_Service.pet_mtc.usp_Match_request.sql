/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.usp_Match_request | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

 create   PROCEDURE [PET_Match_Service].[pet_mtc].[usp_Match_request] @Request_type VARCHAR(1) = NULL
	,@Request_description VARCHAR(200) = NULL
	,@in_fileid INT = NULL
	,@req_status VARCHAR(1) = NULL
	,@Input_file VARCHAR(200) = NULL
	,@Output_File VARCHAR(200) = NULL
	,@ServerName VARCHAR(200) = NULL
	,@DbName VARCHAR(200) = NULL
	,@SchemaName VARCHAR(100) = NULL
	,@out_fileid INT OUTPUT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	20025-04-30	Create
******************************************************************************************************************/
/*
USE [PET]
GO


DECLARE @Request_type varchar(1) = 'S'
DECLARE @Request_description varchar(200) = 'Lien Daily Capture'
DECLARE @Input_file varchar(200) = 'Situs_Std_Address'
DECLARE @Output_File varchar(200) = 'Situs_Std_Address_Result'
DECLARE @ServerName varchar(200) = @@servername
DECLARE @DbName varchar(200) = 'Lien'
DECLARE @SchemaName varchar(10) = 'Lien_dbo'
DECLARE @out_fileid int
declare @in_fileid int =1
declare @req_status varchar(1) = 'P'
-- TODO: Set parameter values here.



EXEC	pet_match_service.[pet_mtc].[usp_Match_request]
		@Request_type 
		, @Request_description 
		, @in_fileid 
		, @req_status 
		, @Input_file 
		, @Output_File 
		, @ServerName 
		, @DbName 
		, @SchemaName
		, @out_fileid OUTPUT

		select top 100 * from [PET_Match_service].[pet_mtc].[Match_Request]
	

*/
BEGIN TRY
	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,N'usp_Match_request'
		,N'Started'

	IF (
			@Request_type IS NULL
			OR @Request_description IS NULL
			)
		AND isnull(@req_status, '') NOT IN (
			'P'
			,'C'
			,'R'
			)
	BEGIN
		SELECT 'Please provide Request Type and Request_description'

		RETURN
	END

	IF isnull(@req_status, '') = ''
		AND isnull(@in_fileid, 0) = 0
	BEGIN
		INSERT INTO [PET_Match_Service].[pet_mtc].[Match_Request] (
			[Request_type]
			,[Request_description]
			,[req_status]
			,[Input_file]
			,[Output_File]
			,[ServerName]
			,[DbName]
			,[SchemaName]
			,[Created]
			,[Updated]
			)
		SELECT @Request_type AS Reques_type
			,@Request_description AS Request_description
			,'N' AS req_status
			,@Input_file
			,@Output_File
			,@ServerName
			,@DbName
			,@SchemaName
			,getdate() AS Created
			,NULL AS Updated

		SET @out_fileid = (
				SELECT TOP 1 fileid
				FROM [PET_Match_Service].[pet_mtc].[Match_Request]
				ORDER BY fileid DESC
				)
	END

	IF isnull(@in_fileid, 0) > 0
	BEGIN
		IF isnull(@req_status, '') = 'R'
		BEGIN
			UPDATE [PET_Match_Service].[pet_mtc].[r]
			SET r.req_status = 'R'
			FROM [PET_Match_Service].[pet_mtc].[Match_Request] r
			WHERE fileid = @in_fileid
		END

		IF isnull(@req_status, '') = 'C'
		BEGIN
			UPDATE [PET_Match_Service].[pet_mtc].[r]
			SET r.req_status = 'C'
			FROM [PET_Match_Service].[pet_mtc].[Match_Request] r
			WHERE fileid = @in_fileid
		END

		IF isnull(@req_status, '') = 'P'
		BEGIN
			UPDATE [PET_Match_Service].[pet_mtc].[r]
			SET r.req_status = 'P'
			FROM [PET_Match_Service].[pet_mtc].[Match_Request] r
			WHERE fileid = @in_fileid
		END
	END

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,N'usp_Match_request'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

