/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.USP_Extract_Reference | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[USP_Extract_Reference] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	SET NOCOUNT ON

	EXEC [lien_DTDB].[INFC].[AddinfcLog] N'info'
		,N'USP_Extract_Reference'
		,N'Started'

	/*

USE lien_dtdb
GO

DECLARE	@return_value int

EXEC	@return_value = INFC.USP_Extract_Reference

SELECT	'Return Value' = @return_value

GO

select format(count(*), '##,##0') as cnt from lien_DTDB.infc.Reference_extract

select top 100 * from lien_DTDB.infc.Reference_extract


*/
	--
	--
	DROP TABLE

	IF EXISTS [lien_DTDB].[infc].[Reference_extract]
		SELECT r.doc_id
			,r.REFERENCE_id
			,rm.reference_id_sequence_number
			,r.doc_unique_id
			,ltrim(rtrim(isnull(r.reference_type_code, ''))) AS reference_type_code
			,ltrim(rtrim(isnull(rm.new_reference_book, ''))) AS reference_book
			,ltrim(rtrim(isnull(rm.new_reference_page, ''))) AS reference_page
			,ltrim(rtrim(isnull(r.reference_recording_year, ''))) AS reference_recording_year
			,ltrim(rtrim(isnull(rm.new_reference_doc_number, ''))) AS reference_doc_number
			,ltrim(rtrim(isnull([spdb].[eprvdb].[fn_DTOCR_RecordingDate](CASE 
								WHEN r.reference_recording_date IS NOT NULL
									THEN r.reference_recording_date
								WHEN isdate(r.reference_recording_year) = 1
									AND isnull(r.reference_recording_year, '') > ''
									THEN r.reference_recording_year
								ELSE NULL
								END), ''))) AS reference_recording_date
			,ltrim(rtrim(isnull(r.reference_questionable_indicator, ''))) AS reference_questionable_indicator
			,ltrim(rtrim(isnull(r.batch, ''))) AS batch
			,ltrim(rtrim(isnull(r.bucket, ''))) AS bucket
			,ltrim(rtrim(isnull(r.reference_book_type, ''))) AS reference_book_type
			,ltrim(rtrim(isnull(r.Fmt_Reference_Doc_Number, ''))) AS Fmt_Reference_Doc_Number
			,ltrim(rtrim(isnull(r.Fmt_BookPAge, ''))) AS Fmt_BookPAge
			,ltrim(rtrim(isnull(r.Updated, ''))) AS Updated
			,ltrim(rtrim(isnull(r.FMT_CMT_ID, 0))) AS FMT_CMT_ID
			,ltrim(rtrim(isnull(r.FMT_CMT_ID_Book_Page, 0))) AS FMT_CMT_ID_Book_Page
			,ltrim(rtrim(isnull(r.m_create_date, ''))) AS m_create_date
			,ltrim(rtrim(isnull(r.reference_sequence_id, 0))) AS reference_sequence_id
			,ltrim(rtrim(isnull(r.reference_reason, ''))) AS reference_reason
			,ltrim(rtrim(isnull(rm.pr_fips, ''))) AS fips
			,ltrim(rtrim(isnull(rm._bookPage, ''))) AS _bookPage
			,isnull(try_cast(rm.nova_doc_id AS DECIMAL(12, 0)), 0) AS nova_doc_id
			,ltrim(rtrim(isnull(rm.Nova_Doc_Number, ''))) AS Nova_Doc_Number
			,isnull(try_cast(rm.Nova_REF_ID AS DECIMAL(12, 0)), 0) AS Nova_REF_ID
			,ltrim(rtrim(isnull(rm.Nova_Property_Id, 0))) AS Nova_Property_Id
			,ltrim(rtrim(isnull(rm.Nova_Cmt_Id, 0))) AS Nova_Cmt_Id
			,ltrim(rtrim(isnull(rm.Sr_Unique_Id, 0))) AS Sr_Unique_Id
			,ltrim(rtrim(isnull(rm.multi_apn, ''))) AS multi_apn
			,ltrim(rtrim(isnull(rm.Doc_Src_Ind, ''))) AS Doc_Src_Ind
		INTO [lien_DTDB].[infc].[Reference_extract]
		FROM [lien].[UR].[REFERENCE] r WITH (
				NOLOCK
				,INDEX (ix_doc_id)
				)
		INNER JOIN [lien_DTDB].[tmp].[reprocess_records_to_be_processed] pc WITH (
				NOLOCK
				,INDEX (idx)
				) ON pc.doc_id = r.doc_id
		OUTER APPLY (
			SELECT CASE 
					WHEN pc.fips BETWEEN '15000'
							AND '16000'
						AND pc.Recording_Date_D > '2024-08-01'
						THEN CASE 
								WHEN substring(r.reference_doc_number, 1, 2) = 'A-'
									THEN 'h1'
								WHEN substring(r.reference_doc_number, 1, 1) = 'A'
									THEN 'h2'
								WHEN substring(r.reference_doc_number, 1, 1) = 'T'
									THEN 'h3'
								ELSE 'N'
								END
					ELSE 'N'
					END AS _Hawaii_cond
			) d2
		OUTER APPLY (
			SELECT CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN substring(r.reference_doc_number, 3, 4)
					WHEN d2._Hawaii_cond = 'h2'
						THEN substring(r.reference_doc_number, 2, 4)
					ELSE reference_book
					END AS reference_book
				,CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN substring(r.reference_doc_number, 7, 6)
					WHEN d2._Hawaii_cond = 'h2'
						THEN substring(r.reference_doc_number, 6, 6)
					ELSE reference_page
					END AS reference_page
				,CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN NULL
					WHEN d2._Hawaii_cond = 'h2'
						THEN NULL
					ELSE r.reference_doc_number
					END AS reference_doc_number
			) d3
		OUTER APPLY (
			SELECT rm2.doc_id
				,rm2.REFERENCE_id
				,rm2.pr_fips
				,rm2.doc_unique_id
				,rm2.reference_id_sequence_number
				,rm2.reference_type_code
				,rm2.reference_book
				,rm2.reference_page
				,rm2._bookPage
				,rm2.reference_recording_year
				,rm2.reference_doc_number
				,rm2.reference_recording_date
				,rm2._reference_recording_date
				,rm2.reference_questionable_indicator
				,rm2.batch
				,rm2.bucket
				,rm2.nova_doc_id
				,rm2.Nova_Doc_Number
				,rm2.Nova_REF_ID
				,rm2.Nova_Property_Id
				,rm2.Nova_Cmt_Id
				,rm2.Sr_Unique_Id
				,rm2.Updated
				,rm2.Created
				,rm2.Multi_APN
				,rm2.Doc_Src_Ind
				,CASE 
					WHEN r.Fmt_Reference_Doc_Number LIKE '%.%'
						--AND isnull(d2.Fmt_Doc_Number, '') > ''
						THEN right(try_cast('000000000000' AS VARCHAR) + reverse(substring(reverse(r.Fmt_Reference_Doc_Number), 1, PATINDEX('%.%', reverse(r.Fmt_Reference_Doc_Number)) - 1)), 12)
					WHEN isnull(r.Fmt_Reference_Doc_Number, '') > ''
						THEN right(try_cast('000000000000' AS VARCHAR) + r.Fmt_Reference_Doc_Number, 12)
					WHEN d3.reference_doc_number > ''
						THEN right(try_cast('000000000000' AS VARCHAR) + d3.reference_doc_number, 12)
					ELSE NULL
					END AS new_reference_doc_number
				,CASE 
					WHEN d3.reference_book > ''
						--THEN right('00000' + substring(r.reference_book,1,6), 6)
						THEN right('00000' + SUBSTRING(ISNULL([SPDB].[dbo].[RegexExtract](d3.reference_book, '([^0]+.*)', '1', 0), ''), 1, 6), 6)
					ELSE NULL
					END AS new_reference_book
				,CASE 
					WHEN d3.reference_page > ''
						--THEN right('00000' + substring(r.reference_page,1,6), 6)
						THEN right('00000' + SUBSTRING(ISNULL([SPDB].[dbo].[RegexExtract](substring(d3.reference_page, 1, 6), '([^0]+.*)', '1', 0), ''), 1, 6), 6)
					ELSE NULL
					END AS new_reference_page
			FROM (
				SELECT rm.*
					,coalesce(pr.fips, pc.Fips) AS pr_fips
					,pr.ref_id AS ar_ref_id
				--,ROW_NUMBER() OVER (
				--	PARTITION BY REFERENCE_id
				--	,isnull(Nova_REF_ID, 0) ORDER BY reference_id_sequence_number
				--	) AS ROW4
				FROM [lien].[UR].[REFERENCE_Match] rm WITH (
						NOLOCK
						,INDEX (ix_ref)
						)
				OUTER APPLY (
					SELECT fips
						,ref_id
					--FROM ASSR.dbo.PropertyReference WITH (NOLOCK,INDEX (PK_PropertyReference))
					FROM [assr].[dbo].[assr] ar with(nolock,index(IDX_Assr_Ref_ID))
					WHERE ar.ref_id = rm.Nova_REF_ID
					and rm.nova_ref_id > 0
					) pr
				WHERE rm.reference_id = r.reference_id
					--and (select count(1) as cnt from Novadimdoc.dbo.vDimDocument nd with(nolock,index(IDX_DOCID_FIPS_DOCNUMBER)) where nd.doc_id = rm.nova_doc_id) > 0
				) rm2
				--WHERE rm2.row4 = 1
			) rm
		OUTER APPLY (
			SELECT doc_id
				,Orig_Src
				,fips
			FROM [novadimdoc].[dbo].[dim_nova_document] nov WITH (
					NOLOCK
					,INDEX (IDX_DOCID_FIPS_DOCNUMBER)
					)
			WHERE nov.doc_id = rm.nova_doc_id
			) nov
		--LEFT JOIN lien.ur.document d ON d.doc_id = r.doc_id
		WHERE (
				isnull(d3.reference_book, '') > ''
				OR isnull(d3.reference_page, '') > ''
				OR isnull(d3.reference_doc_number, '') > ''
				)
			AND isnull(nov.Orig_Src, '') NOT IN ('TIT')
		--and rm.Nova_REF_ID > 0
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--AND (
	--	rm.nova_doc_id IS NULL  --- we did not finc a match - the orphan should go to ras
	--	OR (					--- we found a nova record and it fell in the time period for the fips
	--		nov.doc_id IS NOT NULL
	--		AND rm.nova_doc_id IS NOT NULL
	--		)
	--	)
	--AND r.doc_id = 234088717
	CREATE INDEX idx_doc_id_ref_id_seq ON [lien_DTDB].[infc].[Reference_extract] (
		doc_id
		,REFERENCE_id
		,reference_id_sequence_number
		)

	CREATE INDEX idx_doc_ref ON [lien_DTDB].[infc].[Reference_extract] (
		doc_id
		,REFERENCE_id
		,Nova_REF_ID
		)

	CREATE INDEX idx_reference_Ref_id ON [lien_DTDB].[infc].[Reference_extract] (
		REFERENCE_id
		,Nova_REF_ID
		)

	EXEC [lien_DTDB].[INFC].[AddinfcLog] N'info'
		,N'USP_Extract_Reference'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH
	/*

	select top 100  ur_doc_id , created from ras.dbo.ras
	where source_type = 'e'
	order by ras_id desc
	select * from lien_DTDB.tmp.reprocess_records_to_be_processed
	--select m_status_id , doc_id  from lien_DTDB.ur.document
	where doc_id in (210315728, 210332407, 210350055, 210370854, 210374967, 210397004, 210402643, 210410327, 210423091, 210439877, 210435084, 210426139, 210425258, 210416675)
*/


