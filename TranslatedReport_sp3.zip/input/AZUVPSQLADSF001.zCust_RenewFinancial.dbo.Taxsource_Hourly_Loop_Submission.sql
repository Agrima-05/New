SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [zCust_RenewFinancial].[dbo].[Taxsource_Hourly_Loop_Submission]
as
BEGIN


		--Select A.BatchID, A.ExternalKey, ReportStatus,* 	
		--FROM TaxSourceAPI.[dbo].[OutputLayout5] as A with(NOLOCK)
		--join zCust_RenewFinancial.dbo.INPUT_MONITOR as B 
		--on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and ReportStatus like 'Error' or 



	
		
------Submit 20 random records per 30 min starting at 8PM ET until all are submitted------------

						DECLARE @DATE VARCHAR(100)
						Set @Date =  (Select format(getdate(),'yyyyMMddHHmm'))
						DECLARE @query NVARCHAR(MAX)
						DECLARE @body NVARCHAR(MAX)
						DECLARE @RECNUM NVARCHAR(MAX)
						DECLARE @xml NVARCHAR(MAX)
						DECLARE @Subject NVARCHAR(MAX)
						--DECLARE @DATE VARCHAR(10)
						DECLARE @tab char(1) = CHAR(9)
						DECLARE @IMP VARCHAR(40)
						DECLARE @query_attachment_filename NVARCHAR(MAX)
			
			

			IF(Select count(*) 	From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] 
			where 
			--BATCHID = 
			--(Select MAX(convert(bigint,BATCHID)) From zCust_RenewFinancial.dbo.[INPUT_MONITOR] with(NOLOCK)
			--where DATE_COMPLETED is null)
			DATE_COMPLETED is null
			AND DATE_SUBMITTED is null) > 0

			--Select *   from [TaxSourceAPI].[dbo].[Property] with(NOLOCK)
			--where BatchID >= '20'


		
			BEGIN

				


						Update [TaxSourceAPI].[dbo].[Property]
						Set SubmissionStatus = NULL
						--Select * 
						From [TaxSourceAPI].[dbo].[Property] as A 
						join 
							(Select top 20  A.* from [TaxSourceAPI].[dbo].[OutputLayout5] as A with(NOLOCK)
							join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as C on A.BatchId = C.BATCHID and A.ExternalKey = C.UniqueID
							where  A.Batchid = 28 and C.DATE_COMPLETED is null  and C.DATE_SUBMITTED is null
							and A.SubmissionStatus like 'Submitted'
							and ReportStatus is null or (ReportStatus like 'Error%' 
							AND (Errors like '%the operation was cancelled%'  
							OR  Errors is null OR  Errors 

NOT in ('{"Type":"Error","Code":"property-tax-search-validation","Message":"''Amount'' must not be empty."},{"Type":"Error","Code":"property-tax-search-validation","Message":"InstallmentAmount must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DelinquentDate must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"property-tax-search-validation","Message":"InstallmentAmount must not be empty or null"}',
'{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for ALACHUA COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for BROWARD COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for CHARLOTTE COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for HILLSBOROUGH COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for MIAMI-DADE COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for OSCEOLA COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for PASCO COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"MULTIPLE MATCHES FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for SARASOTA COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"NO RECORD FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for BROWARD COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"NO RECORD FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for MIAMI-DADE COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"NO RECORD FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for PALM BEACH COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}',
'{"Type":"Error","Code":"webscrape-error","Message":"NO RECORD FOUND"},{"Type":"Error","Code":"internal-agency-error","Message":"Internal exception encountered for SARASOTA COUNTY TAX COLLECTOR"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Tax Bill Year less than Current Tax Year"},{"Type":"Error","Code":"property-tax-search-validation","Message":"TaxYear must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"AmountDue must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"Status must not be empty or null"},{"Type":"Error","Code":"property-tax-search-validation","Message":"DueDate must not be empty or null"}'

)))
)B on 
						A.BatchId = B.BatchId
						and A.ExternalKey = B.ExternalKey


						--Select * From [TaxSourceAPI].[dbo].[Property] with(NOLOCK)
						--where BatchID = 28
						--and SubmissionStatus is null
						--Order by ExternalKey

						--Select SubmissionStatus, count(*) From [TaxSourceAPI].[dbo].[Property] as A  with(NOLOCK)
						--join [INPUT_MONITOR] as B  with(NOLOCK) on A.BatchID = B.BatchID
						--and A.ExternalKey = B.UniqueID
						--where A.BatchID = 28
						--Group by SubmissionStatus


						--Select A.BatchId, A.ExternalKey, A.ReportStatus, A.Errors from [TaxSourceAPI].[dbo].[OutputLayout5] as A with(NOLOCK)
						--join [INPUT_MONITOR] as C with(NOLOCK) on A.BatchId = C.BATCHID and A.ExternalKey = C.UniqueID
						--where  A.Batchid = 28 and C.DATE_COMPLETED is null  and C.DATE_SUBMITTED is NOT null
						--Order by A.ReportStatus


					

					--DECLARE @DATE VARCHAR(100)
					--Set @Date =  (Select format(getdate(),'yyyyMMddHHmm'))
					Update [zCust_RenewFinancial].[dbo].[A]
					Set A.DATE_SUBMITTED = @Date
					--Select * 
					From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
					join [TaxSourceAPI].[dbo].[Property] as B with(NOLOCK) on 
					A.UniqueID = B.ExternalKey
					and A.BATCHID = B.BatchId
					where B.BATCHID = 28
					AND A.DATE_SUBMITTED is null
					AND A.DATE_COMPLETED is null
					AND B.SubmissionStatus is null


				

						--DECLARE @DATE VARCHAR(100)
						--Set @Date =  (Select format(getdate(),'yyyyMMddHHmm'))
	
						--DECLARE @query NVARCHAR(MAX)
						--DECLARE @body NVARCHAR(MAX)
						--DECLARE @RECNUM NVARCHAR(MAX)
						--DECLARE @xml NVARCHAR(MAX)
						--DECLARE @Subject NVARCHAR(MAX)
						----DECLARE @DATE VARCHAR(10)
						--DECLARE @tab char(1) = CHAR(9)
						--DECLARE @IMP VARCHAR(40)
						--DECLARE @query_attachment_filename NVARCHAR(MAX)
						Set @RECNUM = (Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
							where DATE_COMPLETED is null AND DATE_SUBMITTED is null)
						--Set @Date = Convert(varchar(10),Getdate(),112)
						Set @Subject = 'RenewFinancial_Taxsource_Process_Starting - ' + @Date + ' - ' + @RECNUM + ' To go!'
						SET @body = NULL
		
		

						-----------sp_send_dbmail example-------------
						EXEC msdb.dbo.sp_send_dbmail
						@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
						@query =  NULL,
						@body = @body,
						@body_format ='HTML',
						@recipients = 'klowe@firstam.com',
						@subject = @subject,
						@attach_query_result_as_file = 0,
						@query_attachment_filename = @query_attachment_filename,
						@query_result_separator=@tab,
						@query_result_no_padding=1
								;
			

			END


			ELSE

			BEGIN

				--DECLARE @DATE VARCHAR(100)
				--Set @Date =  (Select format(getdate(),'yyyyMMddHHmm'))
	
				--DECLARE @query NVARCHAR(MAX)
				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @RECNUM NVARCHAR(MAX)
				--DECLARE @xml NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				----DECLARE @DATE VARCHAR(10)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @IMP VARCHAR(40)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				--Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'RenewFinancial_Taxsource_ No More Records to Submit - ' + @Date 
				SET @body = NULL
		
				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1
						;

				END


END
