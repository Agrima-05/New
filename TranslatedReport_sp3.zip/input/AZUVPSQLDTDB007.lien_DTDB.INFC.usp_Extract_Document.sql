/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_Extract_Document | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[usp_Extract_Document] @ERROR_PARENT VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change
paul		7/30/21     do not populate legal_desc_map_lot_high when legal_desc_map_lot is populated from legal parse
Marie		5/30/2024	Sale_price calculation Add isnull when testing if transfer_sale_purchase_price > '0.00'	or = '0.00'
Marie		8/21/2024	Add Doc_signed_date to lien_DTDB.infc.Document_DTDB_Transform_columns - To use in Deed_work Extract
Marie		1/10/2025   BUG769831 - Hawaii Land Court / Certificate missing Doc Numbers
Paul	    7/8/2025	bug B29758 to add more attorney name exlsusions and add new column return_to_email
Marie		8/20/2025	B30861 - New Sales Code Exempt status mapping update UR to Deed
Marie		8/17/2026	B33522 - Remove Sale Price to Tax conversion when transfer tax is $0 (sale_code = 'X')
Marie		10/02/2026	B34622 - Populate Attorney_last_name and Attorney_first_name from requested_prepared_by_attorney_contact_name
epretorius	11/4/2026	B34622 - Exclude email/website from attorney name fields; route contact email to attorney_email
epretorius	11/4/2026	B34622 - Route phone numbers from last/first company name fields to attorney phone (formatted)
epretorius	11/4/2026	B34622 - Phone routing uses UR last company and first name fields (no First_Company_Name column)
epretorius	11/4/2026	B34622 - Route phone from requested_prepared_by_attorney_contact_name
Marie		10/20/2026	B34761 - Change Sale Proce Calculation for Paulding OH (29125) to tax_rule = 9
******************************************************************************************************************/
/*
USE Lien
GO

DECLARE              @return_value int,
                                @ERROR varchar(100)

EXEC      @return_value = [INFC].usp_Extract_Deed_Work
                                @ERROR = @ERROR OUTPUT

SELECT  @ERROR as N'@ERROR'

SELECT  'Return Value' = @return_value

select * from lien_DTDB.INFC.Deed_work 
select * from lien_DTDB.infc.mortgage_work
select * from deed.dbo.deed where ur_doc_id in (select doc_id from lien_DTDB.dbo.DTDB_DocIdExtract_Process)




truncate table lien_DTDB.INFC.Deed_work
truncate table lien_DTDB.infc.mortgage_work




select * from lien_DTDB.dbo.deed_buyer_names_pivot where doc_id = 200725659


--where doc_id in (102101547,163924747)

select top 100 doc_type, * from lien.ur.document where doc_id in (163925268,163923598)

SELECT TOP 100 a.ur_doc_id ,DEED_TYPE
                ,*
FROM lien_DTDB.INFC.Deed_work a


where a.ur_doc_id in (191575342,191745551)
ORDER BY a.ur_doc_id

SELECT TOP 100 a.ur_doc_id,DEED_TYPE
                ,*
FROM lien_DTDB.dbo.UR_DeedWrk_example a
--where SELLER_NAME_PLAINTIFF_2 is not null
--where MTG1_RECORDING_DATE is not null
WHERE a.ur_doc_id in (191575342)
ORDER BY a.ur_doc_id


SELECT TOP 100 *
FROM lien_DTDB.ur.NAME
WHERE doc_id in (163925268,163923598)

SELECT TOP 100 *
FROM lien_DTDB.dbo.deed_buyer_names_pivot
WHERE doc_id IN (163925268,163923598)


                                '35178   ', '2000'
select * from lien_DTDB.ur.NAME_STD_ADDRESS
where name_id in (215309931, 215311984, 215311985, 215312024, 293015984, 293015985, 293015986)

docid's with party receiving life estate


GO

*/
--declare  @ERROR_PARENT VARCHAR(500)
DECLARE @ERROR VARCHAR(500)

BEGIN TRY
	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_Extract_Document'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien_DTDB].[tmp].[Document_Isnull]
		SELECT ltrim(rtrim(isnull(d.doc_id, 0))) AS doc_id
			,ROW_NUMBER() OVER (
				PARTITION BY 0 ORDER BY (
						SELECT 0
						)
				) AS ROW4
			,UPPER(ltrim(rtrim(isnull(d.doc_unique_id, '')))) AS doc_unique_id
			,UPPER(ltrim(rtrim(isnull(d.source_PK, 0)))) AS source_PK
			,UPPER(ltrim(rtrim(isnull(d.fips_code, '')))) AS fips_code
			,try_cast(d.fips_code AS INT) AS Fips
			,UPPER(ltrim(rtrim(isnull(d.apn_research_flag, '')))) AS apn_research_flag
			,UPPER(ltrim(rtrim(isnull(d.vendor_code, '')))) AS vendor_code
			,UPPER(ltrim(rtrim(isnull(d.cmt_docnumber, '')))) AS cmt_docnumber
			,UPPER(ltrim(rtrim(isnull(d.cmt_id, 0)))) AS cmt_id
			,UPPER(ltrim(rtrim(isnull(d.source, '')))) AS source
			,UPPER(ltrim(rtrim(isnull(d.county, '')))) AS county
			,UPPER(ltrim(rtrim(isnull(d.STATE, '')))) AS STATE
			,UPPER(ltrim(rtrim(isnull(d.recording_date, '')))) AS recording_date
			,UPPER(ltrim(rtrim(isnull(d.recording_time, '')))) AS recording_time
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN isnull(d3.recording_book, '') = '0'
									THEN NULL
								WHEN d3.recording_book = d.recording_date
									THEN NULL
								ELSE d3.recording_book
								END, '')))) AS recording_book
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN isnull(d3.recording_page, '') = '0'
									THEN NULL
								WHEN d3.recording_book = d.recording_date
									THEN NULL
								ELSE d3.recording_page
								END, '')))) AS recording_page
			,UPPER(ltrim(rtrim(isnull(d.recording_doc_page_count, 0)))) AS recording_doc_page_count
			,UPPER(ltrim(rtrim(isnull(d.recording_year, '')))) AS recording_year
			,UPPER(ltrim(rtrim(isnull(d3.recording_doc_number, '')))) AS recording_doc_number
			,UPPER(ltrim(rtrim(isnull(d.recording_doc_number_alternate, '')))) AS recording_doc_number_alternate
			,UPPER(ltrim(rtrim(isnull(d.recording_doc_sequence_number, 0)))) AS recording_doc_sequence_number
			,UPPER(ltrim(rtrim(isnull(d.accomodation_recording, '')))) AS accomodation_recording
			,UPPER(ltrim(rtrim(isnull(d.electronic_recording, '')))) AS electronic_recording
			,UPPER(ltrim(rtrim(isnull(d.re_recording, '')))) AS re_recording
			,UPPER(ltrim(rtrim(isnull(d.doc_title, '')))) AS doc_title
			,UPPER(ltrim(rtrim(isnull(d.doc_type, '')))) AS doc_type
			,UPPER(ltrim(rtrim(isnull(d.doc_date, '')))) AS doc_date
			,UPPER(ltrim(rtrim(isnull(d.doc_filing_date, '')))) AS doc_filing_date
			,UPPER(ltrim(rtrim(isnull(d.doc_signed_date, '')))) AS doc_signed_date
			,UPPER(ltrim(rtrim(isnull(d.corrected_recording, '')))) AS corrected_recording
			,UPPER(ltrim(rtrim(isnull(d.retake_recording, '')))) AS retake_recording
			,UPPER(ltrim(rtrim(isnull(d.doc_questionable_indicator, '')))) AS doc_questionable_indicator
			,UPPER(ltrim(rtrim(isnull(d.bankruptcy_case_number, '')))) AS bankruptcy_case_number
			,UPPER(ltrim(rtrim(isnull(d.bankruptcy_chapter, '')))) AS bankruptcy_chapter
			,UPPER(ltrim(rtrim(isnull(d.bankruptcy_type, '')))) AS bankruptcy_type
			,UPPER(ltrim(rtrim(isnull(d.bankruptcy_location, '')))) AS bankruptcy_location
			,UPPER(ltrim(rtrim(isnull(d.case_book, '')))) AS case_book
			,UPPER(ltrim(rtrim(isnull(d.case_page, '')))) AS case_page
			,UPPER(ltrim(rtrim(isnull(d.case_number, '')))) AS case_number
			,UPPER(ltrim(rtrim(isnull(d.case_filed_in_county, '')))) AS case_filed_in_county
			,UPPER(ltrim(rtrim(isnull(d.case_court_type, '')))) AS case_court_type
			,UPPER(ltrim(rtrim(isnull(d.case_original_number, '')))) AS case_original_number
			,UPPER(ltrim(rtrim(isnull(d.case_original_court_type, '')))) AS case_original_court_type
			,UPPER(ltrim(rtrim(isnull(d.case_status, '')))) AS case_status
			,UPPER(ltrim(rtrim(isnull(d.death_certificate_number, '')))) AS death_certificate_number
			,UPPER(ltrim(rtrim(isnull(d.county_of_death, '')))) AS county_of_death
			,UPPER(ltrim(rtrim(isnull(d.city_village_town_of_death, '')))) AS city_village_town_of_death
			,UPPER(ltrim(rtrim(isnull(d.loan_number, '')))) AS loan_number
			,UPPER(ltrim(rtrim(isnull(d.loan_numberoriginal_senior_loan, '')))) AS loan_numberoriginal_senior_loan
			,UPPER(ltrim(rtrim(isnull(d.loan_type, '')))) AS loan_type
			,UPPER(ltrim(rtrim(isnull(d.loan_min_number, '')))) AS loan_min_number
			,UPPER(ltrim(rtrim(isnull(d.mers_flag, '')))) AS mers_flag
			,UPPER(ltrim(rtrim(isnull(d.title_escrow_number, '')))) AS title_escrow_number
			,UPPER(ltrim(rtrim(isnull(d.title_gf_number, '')))) AS title_gf_number
			,UPPER(ltrim(rtrim(isnull(d.title_misc_number, '')))) AS title_misc_number
			,UPPER(ltrim(rtrim(isnull(d.title_order_number, '')))) AS title_order_number
			,UPPER(ltrim(rtrim(isnull(d.title_officer, '')))) AS title_officer
			--,UPPER(ltrim(rtrim(isnull(CASE 
			--					WHEN TITLE_COMPANY_NAME = 'NEW TITLE COMPANY NAME'
			--						AND new_title_company_name > ''
			--						THEN new_title_company_name
			--					ELSE TITLE_COMPANY_NAME
			--					END, '')))) AS title_company_name
			,(
				SELECT [Lien].[dbo].[fn_parse_title_comp_name](UPPER(ltrim(rtrim(isnull(CASE 
											WHEN D.TITLE_COMPANY_NAME = 'NEW TITLE COMPANY NAME'
												AND D.new_title_company_name > ''
												THEN D.new_title_company_name
											ELSE D.TITLE_COMPANY_NAME
											END, '')))))
				) AS title_company_name
			,UPPER(ltrim(rtrim(isnull(d.title_company_code, '')))) AS title_company_code
			,UPPER(ltrim(rtrim(isnull(d.account_number, '')))) AS account_number
			,UPPER(ltrim(rtrim(isnull(d.amendment_number, '')))) AS amendment_number
			,UPPER(ltrim(rtrim(isnull(d.attorney_bar_number, '')))) AS attorney_bar_number
			,UPPER(ltrim(rtrim(isnull(d.bond_number, '')))) AS bond_number
			,UPPER(ltrim(rtrim(isnull(d.lot_line_adjustment_number, '')))) AS lot_line_adjustment_number
			,UPPER(ltrim(rtrim(isnull(d.certificate_number, '')))) AS certificate_number
			,UPPER(ltrim(rtrim(isnull(d.claim_number, '')))) AS claim_number
			,UPPER(ltrim(rtrim(isnull(d.contract_number, '')))) AS contract_number
			,UPPER(ltrim(rtrim(isnull(d.corporation_number, '')))) AS corporation_number
			,UPPER(ltrim(rtrim(isnull(d.estoppel_affidavit_county, '')))) AS estoppel_affidavit_county
			,UPPER(ltrim(rtrim(isnull(d.estoppel_affidavit_state, '')))) AS estoppel_affidavit_state
			,UPPER(ltrim(rtrim(isnull(d.excise_tax_number, '')))) AS excise_tax_number
			,UPPER(ltrim(rtrim(isnull(d.federal_tax_lien_area, '')))) AS federal_tax_lien_area
			,UPPER(ltrim(rtrim(isnull(d.federal_tax_lien_area_phone, '')))) AS federal_tax_lien_area_phone
			,UPPER(ltrim(rtrim(isnull(d.grantee_is_foreclosing_beneficiary, '')))) AS grantee_is_foreclosing_beneficiary
			,UPPER(ltrim(rtrim(isnull(d.installment_judgment, '')))) AS installment_judgment
			,UPPER(ltrim(rtrim(CASE 
							WHEN isnull(d.interfamily_flag, '') = 'X'
								THEN 'Y'
							ELSE isnull(d.interfamily_flag, '')
							END))) AS interfamily_flag
			,UPPER(ltrim(rtrim(isnull(d.license_number, '')))) AS license_number
			,UPPER(ltrim(rtrim(isnull(d.lien_number, '')))) AS lien_number
			,UPPER(ltrim(rtrim(isnull(d.map_plat_id, '')))) AS map_plat_id
			,UPPER(ltrim(rtrim(isnull(d.mechanics_lien_number, '')))) AS mechanics_lien_number
			,UPPER(ltrim(rtrim(isnull(d.ordinance_number, '')))) AS ordinance_number
			,UPPER(ltrim(rtrim(isnull(d.patent_number, '')))) AS patent_number
			,UPPER(ltrim(rtrim(isnull(d.permit_number, '')))) AS permit_number
			,UPPER(ltrim(rtrim(isnull(d.resolution_number, '')))) AS resolution_number
			,UPPER(ltrim(rtrim(isnull(d.tax_account_serial_warrant_number, '')))) AS tax_account_serial_warrant_number
			,UPPER(ltrim(rtrim(isnull(d.tax_type, '')))) AS tax_type
			,UPPER(ltrim(rtrim(isnull(d.trustees_sale_number, '')))) AS trustees_sale_number
			,UPPER(ltrim(rtrim(isnull(d.ucc_number, '')))) AS ucc_number
			,UPPER(ltrim(rtrim(isnull(d.undersigned_same_as_borrower, '')))) AS undersigned_same_as_borrower
			,UPPER(ltrim(rtrim(isnull(d.water_rights_number, '')))) AS water_rights_number
			,try_cast(ltrim(rtrim(isnull(d.judgment_amount, 0))) AS DECIMAL(13, 2)) AS judgment_amount
			,try_cast(ltrim(rtrim(isnull(d.judgment_grand_total, 0))) AS DECIMAL(13, 2)) AS judgment_grand_total
			,try_cast(ltrim(rtrim(isnull(d.judgment_court_fees, 0))) AS DECIMAL(13, 2)) judgment_court_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_attorney_fees, 0))) AS DECIMAL(13, 2)) judgment_attorney_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_principal_fees, 0))) AS DECIMAL(13, 2)) judgment_principal_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_interest_fees, 0))) AS DECIMAL(13, 2)) judgment_interest_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_filing_fees, 0))) AS DECIMAL(13, 2)) judgment_filing_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_per_diem_fees, 0))) AS DECIMAL(13, 2)) judgment_per_diem_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_late_fees, 0))) AS DECIMAL(13, 2)) judgment_late_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_tax_fees, 0))) AS DECIMAL(13, 2)) judgment_tax_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_insurance_fees, 0))) AS DECIMAL(13, 2)) judgment_insurance_fees
			,try_cast(ltrim(rtrim(isnull(d.judgment_other_fees, 0))) AS DECIMAL(13, 2)) judgment_other_fees
			,try_cast(ltrim(rtrim(isnull(d.loan_balloon_payment_amount, 0))) AS DECIMAL(13, 2)) loan_balloon_payment_amount
			--,try_cast(ltrim(rtrim(isnull(CASE 	WHEN len(d.loan_financed_amount) > 12 THEN NULL	ELSE d.loan_financed_amount END, 0))) AS DECIMAL(15, 2)) loan_financed_amount
			,try_cast(ltrim(rtrim(isnull(floor(d.loan_financed_amount), 0))) AS DECIMAL(13, 2)) loan_financed_amount -------------------------------------------------------------drop the cents???????
			,try_cast(ltrim(rtrim(isnull(d.loan_interest_rate, 0))) AS DECIMAL(13, 2)) AS loan_interest_rate
			,try_cast(ltrim(rtrim(isnull(d.loan_advance_additional_new_amount, 0))) AS DECIMAL(13, 2)) AS loan_advance_additional_new_amount
			--,try_cast(ltrim(rtrim(isnull(CASE WHEN len(d.loan_maximum_amount_credit_limit) >= 12 THEN NULL ELSE d.loan_maximum_amount_credit_limit END, 0))) AS DECIMAL(15, 2)) loan_maximum_amount_credit_limit
			,try_cast(ltrim(rtrim(isnull(d.loan_maximum_amount_credit_limit, 0))) AS DECIMAL(13, 2)) loan_maximum_amount_credit_limit
			,try_cast(ltrim(rtrim(isnull(d.loan_modification_change_amount, 0))) AS DECIMAL(13, 2)) loan_modification_change_amount
			,try_cast(ltrim(rtrim(isnull(d.loan_original_amount, 0))) AS DECIMAL(13, 2)) loan_original_amount
			,try_cast(ltrim(rtrim(isnull(d.loan_amount_of_in_favor_of_party, 0))) AS DECIMAL(13, 2)) loan_amount_of_in_favor_of_party
			,try_cast(ltrim(rtrim(isnull(d.loan_amount_of_subordinating_party, 0))) AS DECIMAL(13, 2)) loan_amount_of_subordinating_party
			,try_cast(ltrim(rtrim(isnull(d.loan_amount_subordinated_limit, 0))) AS DECIMAL(13, 2)) loan_amount_subordinated_limit
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_1, 0))) AS DECIMAL(13, 2)) AS recording_fee_1
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_2, 0))) AS DECIMAL(13, 2)) AS recording_fee_2
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_3, 0))) AS DECIMAL(13, 2)) AS recording_fee_3
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_4, 0))) AS DECIMAL(13, 2)) AS recording_fee_4
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_5, 0))) AS DECIMAL(13, 2)) AS recording_fee_5
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_6, 0))) AS DECIMAL(13, 2)) AS recording_fee_6
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_7, 0))) AS DECIMAL(13, 2)) AS recording_fee_7
			,try_cast(ltrim(rtrim(isnull(d.recording_fee_total, 0))) AS DECIMAL(13, 2)) AS recording_fee_total
			,try_cast(ltrim(rtrim(isnull(d.transfer_sale_purchase_price, 0))) AS DECIMAL(13, 2)) AS transfer_sale_purchase_price
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax, 0))) AS DECIMAL(13, 2)) AS transfer_tax
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax_city, 0))) AS DECIMAL(13, 2)) AS transfer_tax_city
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax_county, 0))) AS DECIMAL(13, 2)) AS transfer_tax_county
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax_misc, 0))) AS DECIMAL(13, 2)) AS transfer_tax_misc
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax_state, 0))) AS DECIMAL(13, 2)) AS transfer_tax_state
			,try_cast(ltrim(rtrim(isnull(d.transfer_tax_town, 0))) AS DECIMAL(13, 2)) AS transfer_tax_town
			,UPPER(ltrim(rtrim(isnull(d.transfer_tax_value_f_p, '')))) AS transfer_tax_value_f_p
			,UPPER(ltrim(rtrim(isnull(d.transfer_tax_number_non_disclosure_flag, '')))) AS transfer_tax_number_non_disclosure_flag
			,UPPER(ltrim(rtrim(isnull(d.amount_due, 0)))) AS amount_due
			,UPPER(ltrim(rtrim(isnull(d.amount_of_default, 0)))) AS amount_of_default
			,UPPER(ltrim(rtrim(isnull(d.bond_amount, 0)))) AS bond_amount
			,UPPER(ltrim(rtrim(isnull(d.cash_down_amount, 0)))) AS cash_down_amount
			,UPPER(ltrim(rtrim(isnull(d.contract_amount, 0)))) AS contract_amount
			,UPPER(ltrim(rtrim(isnull(d.collection_costs, 0)))) AS collection_costs
			,UPPER(ltrim(rtrim(isnull(d.foreclosure_filing_fee, 0)))) AS foreclosure_filing_fee
			,UPPER(ltrim(rtrim(isnull(d.ground_rent_amount, 0)))) AS ground_rent_amount
			,UPPER(ltrim(rtrim(isnull(d.ground_rent_frequency, '')))) AS ground_rent_frequency
			,UPPER(ltrim(rtrim(isnull(d.late_charges, 0)))) AS late_charges
			,UPPER(ltrim(rtrim(isnull(d.minimum_bid_amount, 0)))) AS minimum_bid_amount
			,UPPER(ltrim(rtrim(isnull(d.support_arrears_amount, 0)))) AS support_arrears_amount
			,UPPER(ltrim(rtrim(isnull(d.support_payment_amount, 0)))) AS support_payment_amount
			,UPPER(ltrim(rtrim(isnull(d.support_total_amount, 0)))) AS support_total_amount
			,UPPER(ltrim(rtrim(isnull(d.tax_amount, 0)))) AS tax_amount
			,UPPER(ltrim(rtrim(isnull(d.tax_interest_amount, 0)))) AS tax_interest_amount
			,UPPER(ltrim(rtrim(isnull(d.tax_penalty_amount, 0)))) AS tax_penalty_amount
			,UPPER(ltrim(rtrim(isnull(d.unpaid_balance, 0)))) AS unpaid_balance
			,UPPER(ltrim(rtrim(isnull(d.unpaid_balance_as_of_modification_date, '')))) AS unpaid_balance_as_of_modification_date
			,UPPER(ltrim(rtrim(isnull(d.unpaid_prinicipal_amount_due, 0)))) AS unpaid_prinicipal_amount_due
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_closed, '')))) AS date_bankruptcy_closed
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_case_filed, '')))) AS date_bankruptcy_case_filed
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_conversion, '')))) AS date_bankruptcy_conversion
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_discharged, '')))) AS date_bankruptcy_discharged
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_dismissed, '')))) AS date_bankruptcy_dismissed
			,UPPER(ltrim(rtrim(isnull(d.date_bankruptcy_341_meeting, '')))) AS date_bankruptcy_341_meeting
			,UPPER(ltrim(rtrim(isnull(d.bankruptcy_341_meeting_time, '')))) AS bankruptcy_341_meeting_time
			,UPPER(ltrim(rtrim(isnull(d.date_of_birth_of_deceased, '')))) AS date_of_birth_of_deceased
			,UPPER(ltrim(rtrim(isnull(d.date_of_death, '')))) AS date_of_death
			,UPPER(ltrim(rtrim(isnull(d.date_death_certificate_filed, '')))) AS date_death_certificate_filed
			,UPPER(ltrim(rtrim(isnull(d.date_physician_signed_death_certifate, '')))) AS date_physician_signed_death_certifate
			,UPPER(ltrim(rtrim(isnull(d.date_of_divorce, '')))) AS date_of_divorce
			,UPPER(ltrim(rtrim(isnull(d.date_of_marriage, '')))) AS date_of_marriage
			,UPPER(ltrim(rtrim(isnull(d.date_of_separation, '')))) AS date_of_separation
			,UPPER(ltrim(rtrim(isnull(d.date_of_reconcilation, '')))) AS date_of_reconcilation
			,UPPER(ltrim(rtrim(isnull(d.date_amount_due, '')))) AS date_amount_due
			,UPPER(ltrim(rtrim(isnull(d.date_of_assessment, '')))) AS date_of_assessment
			,UPPER(ltrim(rtrim(isnull(d.date_of_auction, '')))) AS date_of_auction
			,UPPER(ltrim(rtrim(isnull(d.date_balloon_payment_due, '')))) AS date_balloon_payment_due
			,UPPER(ltrim(rtrim(isnull(d.date_of_birth_of_minor_child, '')))) AS date_of_birth_of_minor_child
			,UPPER(ltrim(rtrim(isnull(d.date_of_cessation, '')))) AS date_of_cessation
			,UPPER(ltrim(rtrim(isnull(d.date_of_commencement, '')))) AS date_of_commencement
			,UPPER(ltrim(rtrim(isnull(d.date_of_completion, '')))) AS date_of_completion
			,UPPER(ltrim(rtrim(isnull(d.date_of_default, '')))) AS date_of_default
			,UPPER(ltrim(rtrim(isnull(d.date_of_estoppel_affidavit, '')))) AS date_of_estoppel_affidavit
			,UPPER(ltrim(rtrim(isnull(d.date_first_missed_payment, '')))) AS date_first_missed_payment
			,UPPER(ltrim(rtrim(isnull(d.date_interest_accrued_to, '')))) AS date_interest_accrued_to
			,UPPER(ltrim(rtrim(isnull(d.date_interest_calculated_through, '')))) AS date_interest_calculated_through
			,UPPER(ltrim(rtrim(isnull(d.date_interest_started, '')))) AS date_interest_started
			,UPPER(ltrim(rtrim(isnull(d.date_of_judgment, '')))) AS date_of_judgment
			,UPPER(ltrim(rtrim(isnull(d.date_of_lien_total_amount, '')))) AS date_of_lien_total_amount
			,UPPER(ltrim(rtrim(isnull(d.date_of_loan_maturity, '')))) AS date_of_loan_maturity
			,UPPER(ltrim(rtrim(isnull(d.date_materials_first_delivered, '')))) AS date_materials_first_delivered
			,UPPER(ltrim(rtrim(isnull(d.date_materials_last_delivered, '')))) AS date_materials_last_delivered
			,UPPER(ltrim(rtrim(isnull(d.date_of_in_favor_of_loan, '')))) AS date_of_in_favor_of_loan
			,UPPER(ltrim(rtrim(isnull(d.date_of_subordinated_loan, '')))) AS date_of_subordinated_loan
			,UPPER(ltrim(rtrim(isnull(d.date_stay_ordered, '')))) AS date_stay_ordered
			,UPPER(ltrim(rtrim(isnull(d.date_surrendered_mobile_home, '')))) AS date_surrendered_mobile_home
			,UPPER(ltrim(rtrim(isnull(d.tax_last_day_for_refiling, '')))) AS tax_last_day_for_refiling
			,UPPER(ltrim(rtrim(isnull(d.tax_period_begin_date, '')))) AS tax_period_begin_date
			,UPPER(ltrim(rtrim(isnull(d.tax_period_end_date, '')))) AS tax_period_end_date
			,UPPER(ltrim(rtrim(isnull(d.date_of_unpaid_balance, '')))) AS date_of_unpaid_balance
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_flag, '')))) AS adjustable_int_flag
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_negative_amortization_flag, '')))) AS adjustable_int_negative_amortization_flag
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_only_flag, '')))) AS adjustable_int_only_flag
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_change_date, '')))) AS adjustable_int_change_date
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_change_frequency, '')))) AS adjustable_int_change_frequency
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_change_interval, 0)))) AS adjustable_int_change_interval
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_calculation_change, 0)))) AS adjustable_int_calculation_change
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_maximum_perc, 0)))) AS adjustable_int_maximum_perc
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_index_type_code, '')))) AS adjustable_int_index_type_code
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_change_perc_limit, 0)))) AS adjustable_int_change_perc_limit
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_first_int_rate_change_cap, 0)))) AS adjustable_int_first_int_rate_change_cap
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_look_back_period, 0)))) AS adjustable_int_look_back_period
			,UPPER(ltrim(rtrim(isnull(d.adjustable_int_rate_pay_option, '')))) AS adjustable_int_rate_pay_option
			,UPPER(ltrim(rtrim(isnull(d.rider_1_4_family_flag, '')))) AS rider_1_4_family_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_assumability_flag, '')))) AS rider_assumability_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_balloon_payment_flag, '')))) AS rider_balloon_payment_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_biweekly_payment_flag, '')))) AS rider_biweekly_payment_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_condominium_flag, '')))) AS rider_condominium_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_conversion_flag, '')))) AS rider_conversion_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_construction_loan_flag, '')))) AS rider_construction_loan_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_demand_or_broker_call_loan_flag, '')))) AS rider_demand_or_broker_call_loan_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_equity_loan_flag, '')))) AS rider_equity_loan_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_graduated_payment_flag, '')))) AS rider_graduated_payment_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_growing_equity_loan_flag, '')))) AS rider_growing_equity_loan_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_home_improvement_flag, '')))) AS rider_home_improvement_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_homestead_flag, '')))) AS rider_homestead_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_interest_only_loan_flag, '')))) AS rider_interest_only_loan_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_planned_unit_development_flag, '')))) AS rider_planned_unit_development_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_pre_payment_flag, '')))) AS rider_pre_payment_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_prime_equity_line_flag, '')))) AS rider_prime_equity_line_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_rate_improvement_flag, '')))) AS rider_rate_improvement_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_request_for_notice_flag, '')))) AS rider_request_for_notice_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_second_home_flag, '')))) AS rider_second_home_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_shared_appreciation_flag, '')))) AS rider_shared_appreciation_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_trust_revocable_trust_flag, '')))) AS rider_trust_revocable_trust_flag
			,UPPER(ltrim(rtrim(isnull(d.rider_va_flag, '')))) AS rider_va_flag
			,UPPER(ltrim(rtrim(isnull(d.auction_address, '')))) AS auction_address
			,UPPER(ltrim(rtrim(isnull(d.auction_city, '')))) AS auction_city
			,UPPER(ltrim(rtrim(isnull(d.auction_state, '')))) AS auction_state
			,UPPER(ltrim(rtrim(isnull(d.auction_zip, '')))) AS auction_zip
			,UPPER(ltrim(rtrim(isnull(d.auction_time, '')))) AS auction_time
			,UPPER(ltrim(rtrim(isnull(d.judges_last_name, '')))) AS judges_last_name
			,UPPER(ltrim(rtrim(isnull(d.judges_first_name, '')))) AS judges_first_name
			,UPPER(ltrim(rtrim(isnull(d.judges_middle_initial, '')))) AS judges_middle_initial
			,UPPER(ltrim(rtrim(isnull(d.judges_suffix, '')))) AS judges_suffix
			,UPPER(ltrim(rtrim(isnull(d.judges_phone, '')))) AS judges_phone
			,UPPER(ltrim(rtrim(isnull(d.judges_name_blob, '')))) AS judges_name_blob
			,UPPER(ltrim(rtrim(isnull(d.nmls_company1, '')))) AS nmls_company1
			,UPPER(ltrim(rtrim(isnull(d.nmls_company1_id, '')))) AS nmls_company1_id
			,UPPER(ltrim(rtrim(isnull(d.nmls_company2, '')))) AS nmls_company2
			,UPPER(ltrim(rtrim(isnull(d.nmls_company2_id, '')))) AS nmls_company2_id
			,UPPER(ltrim(rtrim(isnull(d.nmls_officer, '')))) AS nmls_officer
			,UPPER(ltrim(rtrim(isnull(d.nmls_officer_id, '')))) AS nmls_officer_id
			,UPPER(ltrim(rtrim(isnull(d.notary_place_of_execution, '')))) AS notary_place_of_execution
			,UPPER(ltrim(rtrim(isnull(d.notary_date_of_execution, '')))) AS notary_date_of_execution
			,UPPER(ltrim(rtrim(isnull(d.notary_last_name, '')))) AS notary_last_name
			,UPPER(ltrim(rtrim(isnull(d.notary_first_name, '')))) AS notary_first_name
			,UPPER(ltrim(rtrim(isnull(d.notary_middle_name, '')))) AS notary_middle_name
			,UPPER(ltrim(rtrim(isnull(d.notary_suffix, '')))) AS notary_suffix
			,UPPER(ltrim(rtrim(isnull(d.notary_commission_license_number, '')))) AS notary_commission_license_number
			,UPPER(ltrim(rtrim(isnull(d.notary_commission_expiration_date, '')))) AS notary_commission_expiration_date
			,UPPER(ltrim(rtrim(isnull(d.notary_vendor_number, '')))) AS notary_vendor_number
			,UPPER(ltrim(rtrim(isnull(d.notary_phone, '')))) AS notary_phone
			,UPPER(ltrim(rtrim(isnull(d.notary_county_where_bond_is_filed, '')))) AS notary_county_where_bond_is_filed
			,UPPER(ltrim(rtrim(isnull(d.notary_state_where_bond_is_filed, '')))) AS notary_state_where_bond_is_filed
			,UPPER(ltrim(rtrim(isnull(d.notary_company_where_bond_is_insured, '')))) AS notary_company_where_bond_is_insured
			,UPPER(ltrim(rtrim(isnull(d.payment_address, '')))) AS payment_address
			,UPPER(ltrim(rtrim(isnull(d.payment_address_city, '')))) AS payment_address_city
			,UPPER(ltrim(rtrim(isnull(d.payment_address_state, '')))) AS payment_address_state
			,UPPER(ltrim(rtrim(isnull(d.payment_address_zip, '')))) AS payment_address_zip
			,UPPER(ltrim(rtrim(isnull(d.payment_address_phone, '')))) AS payment_address_phone
			,UPPER(ltrim(rtrim(isnull(d.place_of_filing_address, '')))) AS place_of_filing_address
			,UPPER(ltrim(rtrim(isnull(d.place_of_filing_address_city, '')))) AS place_of_filing_address_city
			,UPPER(ltrim(rtrim(isnull(d.place_of_filing_address_state, '')))) AS place_of_filing_address_state
			,UPPER(ltrim(rtrim(isnull(d.place_of_filing_address_zip, '')))) AS place_of_filing_address_zip
			,UPPER(ltrim(rtrim(isnull(d.place_of_filing_phone, '')))) AS place_of_filing_phone
			--
			,UPPER(ltrim(rtrim(isnull(d1700.requested_prepared_by_attorney_name_identifier, '')))) AS requested_prepared_by_attorney_name_identifier
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](att_nm.attorney_last_coalesce) = 1
									OR [Lien_DTDB].[INFC].[fn_Is_Phone_Number](att_nm.attorney_last_coalesce) = 1
									OR (
										[Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_attorney_contact_name) = 1
										AND UPPER(LTRIM(RTRIM(att_nm.attorney_last_coalesce))) = UPPER(LTRIM(RTRIM(d.requested_prepared_by_attorney_contact_name)))
										)
									THEN ''
								ELSE att_nm.attorney_last_coalesce
								END, '')))) AS requested_prepared_by_Attorney_Last_Company_Name
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](att_nm.attorney_first_coalesce) = 1
									OR [Lien_DTDB].[INFC].[fn_Is_Phone_Number](att_nm.attorney_first_coalesce) = 1
									OR (
										[Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_attorney_contact_name) = 1
										AND UPPER(LTRIM(RTRIM(att_nm.attorney_first_coalesce))) = UPPER(LTRIM(RTRIM(d.requested_prepared_by_attorney_contact_name)))
										)
									THEN ''
								ELSE att_nm.attorney_first_coalesce
								END, '')))) AS requested_prepared_by_attorney_first_name
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](att_nm.attorney_middle_coalesce) = 1
									THEN ''
								ELSE att_nm.attorney_middle_coalesce
								END, '')))) AS requested_prepared_by_attorney_middle_initial
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](att_nm.attorney_suffix_coalesce) = 1
									THEN ''
								ELSE att_nm.attorney_suffix_coalesce
								END, '')))) AS requested_prepared_by_attorney_suffix
			,UPPER(ltrim(rtrim(isnull(d1700.requested_prepared_by_attorney_address, '')))) AS requested_prepared_by_attorney_address
			,UPPER(ltrim(rtrim(isnull(d1700.requested_prepared_by_attorney_address_city, '')))) AS requested_prepared_by_attorney_address_city
			,UPPER(ltrim(rtrim(isnull(d1700.requested_prepared_by_attorney_address_state, '')))) AS requested_prepared_by_attorney_address_state
			,UPPER(ltrim(rtrim(isnull(d1700.requested_prepared_by_attorney_address_zip, '')))) AS requested_prepared_by_attorney_address_zip
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN [Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_attorney_contact_name) = 1
									THEN [Lien_DTDB].[INFC].[fn_Format_Phone_Number](d.requested_prepared_by_attorney_contact_name)
								WHEN NULLIF(LTRIM(RTRIM(d1700.requested_prepared_by_attorney_phone)), '') IS NOT NULL
									THEN COALESCE([Lien_DTDB].[INFC].[fn_Format_Phone_Number](d1700.requested_prepared_by_attorney_phone), UPPER(LTRIM(RTRIM(d1700.requested_prepared_by_attorney_phone))))
								WHEN [Lien_DTDB].[INFC].[fn_Is_Phone_Number](att_nm.attorney_last_coalesce) = 1
									THEN [Lien_DTDB].[INFC].[fn_Format_Phone_Number](att_nm.attorney_last_coalesce)
								WHEN [Lien_DTDB].[INFC].[fn_Is_Phone_Number](att_nm.attorney_first_coalesce) = 1
									THEN [Lien_DTDB].[INFC].[fn_Format_Phone_Number](att_nm.attorney_first_coalesce)
								WHEN [Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_Attorney_Last_Company_Name) = 1
									THEN INFC.fn_Format_Phone_Number(d.requested_prepared_by_Attorney_Last_Company_Name)
								ELSE [Lien_DTDB].[INFC].[fn_Format_Phone_Number](d1700.requested_prepared_by_attorney_phone)
								END, '')))) AS requested_prepared_by_attorney_phone
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN NULLIF(LTRIM(RTRIM(d1700.requested_prepared_by_attorney_email)), '') IS NOT NULL
									THEN d1700.requested_prepared_by_attorney_email
								WHEN [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](d.requested_prepared_by_attorney_contact_name) = 1
									AND [Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_attorney_contact_name) = 0
									THEN UPPER(LTRIM(RTRIM(d.requested_prepared_by_attorney_contact_name)))
								ELSE d1700.requested_prepared_by_attorney_email
								END, '')))) AS requested_prepared_by_attorney_email
			,UPPER(ltrim(rtrim(isnull(d1700.Attorney_Firm_Name, '')))) AS Attorney_Firm_Name
			--
			,UPPER(ltrim(rtrim(isnull(d.return_to_name_identifier, '')))) AS return_to_name_identifier
			,UPPER(ltrim(rtrim(isnull(d.return_to_last_company_name, '')))) AS return_to_last_company_name
			,UPPER(ltrim(rtrim(isnull(d.return_to_first_name, '')))) AS return_to_first_name
			,UPPER(ltrim(rtrim(isnull(d.return_to_middle_name, '')))) AS return_to_middle_name
			,UPPER(ltrim(rtrim(isnull(d.return_to_suffix, '')))) AS return_to_suffix
			,UPPER(ltrim(rtrim(isnull(d.return_to_address, '')))) AS return_to_address
			,UPPER(ltrim(rtrim(isnull(d.return_to_city, '')))) AS return_to_city
			,UPPER(ltrim(rtrim(isnull(d.return_to_state, '')))) AS return_to_state
			,UPPER(ltrim(rtrim(isnull(d.return_to_zip, '')))) AS return_to_zip
			,UPPER(ltrim(rtrim(isnull(d.return_to_phone, '')))) AS return_to_phone
			--
			,UPPER(ltrim(rtrim(isnull(d.legal_desc_multi_property_flag, '')))) AS legal_desc_multi_property_flag
			,UPPER(ltrim(rtrim(isnull(d.legal_desc_blob, '')))) AS legal_desc_blob
			,UPPER(ltrim(rtrim(isnull(d.legal_desc_multi_apn_flag, '')))) AS legal_desc_multi_apn_flag
			,UPPER(ltrim(rtrim(isnull(d.remarks, '')))) AS remarks
			,UPPER(ltrim(rtrim(isnull(d.lineage_file, '')))) AS lineage_file
			,UPPER(ltrim(rtrim(isnull(d.md5, '')))) AS md5
			,UPPER(ltrim(rtrim(isnull(d.run_id, 0)))) AS run_id
			,UPPER(ltrim(rtrim(isnull(d.universal_document_identifier, '')))) AS universal_document_identifier
			,UPPER(ltrim(rtrim(isnull(d.pre_payment_interest, 0)))) AS pre_payment_interest
			,UPPER(ltrim(rtrim(isnull(d.pre_payment_increments, 0)))) AS pre_payment_increments
			,UPPER(ltrim(rtrim(isnull(d.concurrent_deed_flag, '')))) AS concurrent_deed_flag
			,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_contact_name, '')))) AS requested_prepared_by_attorney_contact_name
			,UPPER(ltrim(rtrim(isnull(d.ur_matrix, '')))) AS ur_matrix
			,UPPER(ltrim(rtrim(isnull(d.batch, '')))) AS batch
			,UPPER(ltrim(rtrim(isnull(d.bucket, '')))) AS bucket
			,UPPER(ltrim(rtrim(isnull(d.recording_thru_page_number, '')))) AS recording_thru_page_number
			,UPPER(ltrim(rtrim(isnull(d.alt_cmt_docnumber, '')))) AS alt_cmt_docnumber
			,UPPER(ltrim(rtrim(isnull(d.alt_cmt_id, 0)))) AS alt_cmt_id
			,UPPER(ltrim(rtrim(isnull(d.ur_json_version, '')))) AS ur_json_version
			,UPPER(ltrim(rtrim(isnull(d.m_status_id, 0)))) AS m_status_id
			,UPPER(ltrim(rtrim(isnull(d.m_create_date, '')))) AS m_create_date
			,UPPER(ltrim(rtrim(isnull(d.m_update_date, '')))) AS m_update_date
			,UPPER(ltrim(rtrim(isnull(d.Fmt_Doc_Number, '')))) AS Fmt_Doc_Number
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN d.FMT_Book_Page IN (
										'000.000'
										,'00'
										,'000'
										)
									THEN NULL
								ELSE d.FMT_Book_Page
								END, '')))) AS FMT_Book_Page
			,UPPER(ltrim(rtrim(isnull(d.FMT_CMT_ID, 0)))) AS FMT_CMT_ID
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN d.FMT_Book_Page IN (
										'000.000'
										,'00'
										,'000'
										)
									THEN NULL
								ELSE d.FMT_CMT_ID_Book_Page
								END, 0)))) AS FMT_CMT_ID_Book_Page
			,UPPER(ltrim(rtrim(isnull(d.property_override_type, '')))) AS property_override_type
			,UPPER(ltrim(rtrim(isnull(d.pace_restriction_flag, '')))) AS pace_restriction_flag
			,UPPER(ltrim(rtrim(isnull(d.timeshare_flag, '')))) AS timeshare_flag
			,UPPER(ltrim(rtrim(isnull(d.reprocess_flag, '')))) AS reprocess_flag
			,UPPER(ltrim(rtrim(isnull(d.mail_tax_bill_address, '')))) AS mail_tax_bill_address
			,UPPER(ltrim(rtrim(isnull(d.mail_tax_bill_city, '')))) AS mail_tax_bill_city
			,UPPER(ltrim(rtrim(isnull(d.mail_tax_bill_state, '')))) AS mail_tax_bill_state
			,UPPER(ltrim(rtrim(isnull(d.mail_tax_bill_zip, '')))) AS mail_tax_bill_zip
			,UPPER(ltrim(rtrim(isnull(d.deed_type, '')))) AS deed_type
			,UPPER(ltrim(rtrim(isnull(d.owelty_flag, '')))) AS owelty_flag
			,UPPER(ltrim(rtrim(isnull(d.discriminatory_language_flag, '')))) AS discriminatory_language_flag
			,UPPER(ltrim(rtrim(isnull(d.loan_repayment_term, '')))) AS loan_repayment_term
			,UPPER(ltrim(rtrim(isnull(d.rider_renewal_extension_flag, '')))) AS rider_renewal_extension_flag
			,UPPER(ltrim(rtrim(isnull(d.entity_type, '')))) AS entity_type
			,UPPER(ltrim(rtrim(isnull(d.previous_doc_unique_id, '')))) AS previous_doc_unique_id
			,UPPER(ltrim(rtrim(isnull(d.update_type, '')))) AS update_type
			,UPPER(ltrim(rtrim(isnull(d.new_title_company_name, '')))) AS new_title_company_name
			,UPPER(ltrim(rtrim(isnull(d.recording_date_d, '')))) AS recording_date_d
			,try_cast('' AS CHAR(1)) AS Sale_code
			,UPPER(ltrim(rtrim(isnull(d3.HAWAII_LAND_COURT_DOC_NBR, '')))) AS HAWAII_LAND_COURT_DOC_NBR
			,UPPER(ltrim(rtrim(isnull(d3.HAWAII_TCT_CERTIFICATE_NBR, '')))) AS HAWAII_TCT_CERTIFICATE_NBR
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN d.requested_prepared_by_attorney_name_identifier = 'C'
									THEN d.requested_prepared_by_Attorney_Last_Company_Name
								ELSE NULL
								END, '')))) AS Attorney_name1
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN d.requested_prepared_by_other_party_name_identifier = 'C'
									THEN d.requested_prepared_by_other_party_last_company_name
								ELSE NULL
								END, '')))) AS Attorney_name2
			,UPPER(ltrim(rtrim(isnull(CASE 
								WHEN d.return_to_name_identifier = 'C'
									THEN d.return_to_last_company_name
								ELSE NULL
								END, '')))) AS Attorney_name3
		INTO [lien_DTDB].[tmp].[Document_Isnull]
		FROM [lien].[ur].[document] d WITH (NOLOCK)
		INNER JOIN [lien_DTDB].[tmp].[reprocess_records_to_be_processed] d1 WITH (
				NOLOCK
				,INDEX (idx)
				) ON d1.doc_id = d.doc_id
		OUTER APPLY (
			SELECT CASE 
					WHEN /* d.Fips_code BETWEEN '17000'
							AND '18000'
						AND*/ d.requested_prepared_by_Attorney_Last_Company_Name IS NOT NULL
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%title%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '% bank'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '% bank %'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE 'bank %'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%bank %'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%financ%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%funding%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%credit%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%loan%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%lend%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%fcu%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%ABST%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%MORTG%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%SETTLEMENT%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%HOUSING%'
						AND d.requested_prepared_by_Attorney_Last_Company_Name NOT LIKE '%AGENCY%'
						--	)
						THEN 1
					WHEN d.requested_prepared_by_other_party_last_company_name IS NOT NULL
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%title%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '% bank'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '% bank %'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE 'bank %'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%bank %'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%financ%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%funding%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%credit%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%loan%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%lend%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%fcu%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%ABST%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%MORTG%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%SETTLEMENT%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%HOUSING%'
						AND d.requested_prepared_by_other_party_last_company_name NOT LIKE '%AGENCY%'
						THEN 2
					WHEN d.return_to_last_company_name IS NOT NULL
						AND d.return_to_last_company_name NOT LIKE '%title%'
						AND d.return_to_last_company_name NOT LIKE '% bank'
						AND d.return_to_last_company_name NOT LIKE '% bank %'
						AND d.return_to_last_company_name NOT LIKE 'bank %'
						AND d.return_to_last_company_name NOT LIKE '%bank %'
						AND d.return_to_last_company_name NOT LIKE '%financ%'
						AND d.return_to_last_company_name NOT LIKE '%funding%'
						AND d.return_to_last_company_name NOT LIKE '%credit%'
						AND d.return_to_last_company_name NOT LIKE '%loan%'
						AND d.return_to_last_company_name NOT LIKE '%lend%'
						AND d.return_to_last_company_name NOT LIKE '%fcu%'
						AND d.return_to_last_company_name NOT LIKE '%ABST%'
						AND d.return_to_last_company_name NOT LIKE '%MORTG%'
						AND d.return_to_last_company_name NOT LIKE '%SETTLEMENT%'
						AND d.return_to_last_company_name NOT LIKE '%HOUSING%'
						AND d.return_to_last_company_name NOT LIKE '%AGENCY%'
						THEN 3
					ELSE 0
					END AS _attorney_other
			) d_other
		OUTER APPLY (
			SELECT UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_name_identifier, '')))) AS requested_prepared_by_attorney_name_identifier
				,CASE 
					WHEN d.requested_prepared_by_attorney_name_identifier = 'I'
						THEN UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_Attorney_Last_Company_Name, ''))))
					ELSE NULL
					END AS requested_prepared_by_Attorney_Last_Company_Name
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_first_name, '')))) AS requested_prepared_by_attorney_first_name
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_middle_initial, '')))) AS requested_prepared_by_attorney_middle_initial
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_suffix, '')))) AS requested_prepared_by_attorney_suffix
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_address, '')))) AS requested_prepared_by_attorney_address
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_address_city, '')))) AS requested_prepared_by_attorney_address_city
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_address_state, '')))) AS requested_prepared_by_attorney_address_state
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_attorney_address_zip, '')))) AS requested_prepared_by_attorney_address_zip
				,UPPER(ltrim(rtrim(isnull(coalesce(d.requested_prepared_by_attorney_phone, d.return_to_phone), '')))) AS requested_prepared_by_attorney_phone
				,UPPER(ltrim(rtrim(isnull(coalesce(d.requested_prepared_by_attorney_email, d.return_to_email), '')))) AS requested_prepared_by_attorney_email
				,CASE 
					WHEN d.requested_prepared_by_attorney_name_identifier = 'C'
						THEN UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_Attorney_Last_Company_Name, ''))))
					ELSE NULL
					END AS Attorney_Firm_Name
			WHERE d_other._attorney_other = 1
			
			UNION ALL
			
			SELECT UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_name_identifier, '')))) AS requested_prepared_by_attorney_name_identifier
				,CASE 
					WHEN d.requested_prepared_by_other_party_name_identifier = 'I'
						THEN UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_last_company_name, ''))))
					ELSE NULL
					END AS requested_prepared_by_Attorney_Last_Company_Name
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_first_name, '')))) AS requested_prepared_by_attorney_first_name
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_middle_initial, '')))) AS requested_prepared_by_attorney_middle_initial
				,UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_suffix, '')))) AS requested_prepared_by_attorney_suffix
				,NULL AS requested_prepared_by_attorney_address
				,NULL AS requested_prepared_by_attorney_address_city
				,NULL AS requested_prepared_by_attorney_address_state
				,NULL AS requested_prepared_by_attorney_address_zip
				,UPPER(ltrim(rtrim(isnull(coalesce(d.requested_prepared_by_attorney_phone, d.return_to_phone), '')))) AS requested_prepared_by_attorney_phone
				,UPPER(ltrim(rtrim(isnull(coalesce(d.requested_prepared_by_attorney_email, d.return_to_email), '')))) AS requested_prepared_by_attorney_email
				,CASE 
					WHEN d.requested_prepared_by_other_party_name_identifier = 'C'
						THEN UPPER(ltrim(rtrim(isnull(d.requested_prepared_by_other_party_last_company_name, ''))))
					ELSE NULL
					END AS Attorney_Firm_Name
			WHERE d_other._attorney_other = 2
			
			UNION ALL
			
			SELECT UPPER(ltrim(rtrim(isnull(d.return_to_name_identifier, '')))) AS requested_prepared_by_attorney_name_identifier
				,CASE 
					WHEN d.return_to_name_identifier = 'I'
						THEN UPPER(ltrim(rtrim(isnull(d.return_to_last_company_name, ''))))
					ELSE NULL
					END AS requested_prepared_by_Attorney_Last_Company_Name
				,UPPER(ltrim(rtrim(isnull(d.return_to_first_name, '')))) AS requested_prepared_by_attorney_first_name
				,UPPER(ltrim(rtrim(isnull(d.return_to_middle_name, '')))) AS requested_prepared_by_attorney_middle_initial
				,UPPER(ltrim(rtrim(isnull(d.return_to_suffix, '')))) AS requested_prepared_by_attorney_suffix
				,UPPER(ltrim(rtrim(isnull(d.return_to_address, '')))) AS requested_prepared_by_attorney_address
				,UPPER(ltrim(rtrim(isnull(d.return_to_city, '')))) AS requested_prepared_by_attorney_address_city
				,UPPER(ltrim(rtrim(isnull(d.return_to_state, '')))) AS requested_prepared_by_attorney_address_state
				,UPPER(ltrim(rtrim(isnull(d.return_to_zip, '')))) AS requested_prepared_by_attorney_address_zip
				,UPPER(ltrim(rtrim(isnull(coalesce(d.return_to_phone, d.requested_prepared_by_attorney_phone), '')))) AS requested_prepared_by_attorney_phone
				,UPPER(ltrim(rtrim(isnull(coalesce(d.requested_prepared_by_attorney_email, d.return_to_email), '')))) AS requested_prepared_by_attorney_email
				,CASE 
					WHEN d.return_to_name_identifier = 'C'
						THEN UPPER(ltrim(rtrim(isnull(d.return_to_last_company_name, ''))))
					ELSE NULL
					END AS Attorney_Firm_Name
			WHERE d_other._attorney_other = 3
			) d1700
		-- B34622 - Populate First, Middle and Last from contact name or last company name
		OUTER APPLY (
			SELECT p.Last_Name
				,p.Middle_Name
				,p.First_Name
				,p.Suffix
			FROM [Lien_DTDB].[INFC].[fn_Parse_Person_Name](d.requested_prepared_by_attorney_contact_name) p
			WHERE d1700.Attorney_Firm_Name IS NOT NULL
				AND d.requested_prepared_by_attorney_contact_name IS NOT NULL
				AND [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](d.requested_prepared_by_attorney_contact_name) = 0
				AND [Lien_DTDB].[INFC].[fn_Is_Phone_Number](d.requested_prepared_by_attorney_contact_name) = 0
				AND NULLIF(LTRIM(RTRIM(d1700.requested_prepared_by_Attorney_Last_Company_Name)), '') IS NULL
			) nn_contact
		OUTER APPLY (
			SELECT p.Last_Name
				,p.Middle_Name
				,p.First_Name
				,p.Suffix
			FROM [Lien_DTDB].[INFC].[fn_Parse_Person_Name](d1700.requested_prepared_by_Attorney_Last_Company_Name) p
			WHERE d1700.Attorney_Firm_Name IS NOT NULL
				AND d.requested_prepared_by_attorney_contact_name IS NOT NULL
				AND [Lien_DTDB].[INFC].[fn_Is_Email_Or_Website](d1700.requested_prepared_by_Attorney_Last_Company_Name) = 0
				AND [Lien_DTDB].[INFC].[fn_Is_Phone_Number](d1700.requested_prepared_by_Attorney_Last_Company_Name) = 0
				AND d.return_to_name_identifier = 'I'
				AND NULLIF(LTRIM(RTRIM(d1700.requested_prepared_by_Attorney_Last_Company_Name)), '') IS NOT NULL
				AND NULLIF(LTRIM(RTRIM(d1700.requested_prepared_by_attorney_first_name)), '') IS NULL
			) nn_last
		OUTER APPLY (
			SELECT Coalesce(nn_contact.Last_name, nn_last.Last_name, d1700.requested_prepared_by_Attorney_Last_Company_Name) AS attorney_last_coalesce
				,Coalesce(nn_contact.First_Name, nn_last.First_Name, d1700.requested_prepared_by_attorney_first_name) AS attorney_first_coalesce
				,Coalesce(nn_contact.Middle_Name, nn_last.Middle_Name, d1700.requested_prepared_by_attorney_middle_initial) AS attorney_middle_coalesce
				,Coalesce(nn_contact.Suffix, nn_last.Suffix, d1700.requested_prepared_by_attorney_suffix) AS attorney_suffix_coalesce
			) att_nm
		-------------------------
		OUTER APPLY (
			SELECT CASE 
					WHEN d.fips_code BETWEEN '15000'
							AND '16000'
						AND d.Recording_Date_D > '2024-08-01'
						THEN CASE 
								WHEN substring(d.recording_doc_number, 1, 2) = 'A-'
									THEN 'h1'
								WHEN substring(d.recording_doc_number, 1, 1) = 'A'
									THEN 'h2'
								WHEN substring(d.recording_doc_number, 1, 1) = 'T'
									THEN 'h3'
								ELSE 'N'
								END
					ELSE 'N'
					END AS _Hawaii_cond
			) d2
		OUTER APPLY (
			SELECT CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN substring(d.recording_doc_number, 3, 4)
					WHEN d2._Hawaii_cond = 'h2'
						THEN substring(d.recording_doc_number, 2, 4)
					ELSE RECORDING_BOOK
					END AS RECORDING_BOOK
				,CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN substring(d.recording_doc_number, 7, 6)
					WHEN d2._Hawaii_cond = 'h2'
						THEN substring(d.recording_doc_number, 6, 6)
					ELSE RECORDING_PAGE
					END AS RECORDING_PAGE
				,CASE 
					WHEN d2._Hawaii_cond = 'h1'
						THEN NULL
					WHEN d2._Hawaii_cond = 'h2'
						THEN NULL
					ELSE d.recording_doc_number
					END AS recording_doc_number
				--,CASE 
				--	WHEN d2._Hawaii_cond IN ('h1','h2') THEN d.recording_doc_number
				--	ELSE NULL
				--	END AS HAWAII_LAND_COURT_DOC_NBR
				--,CASE 
				--	WHEN d2._Hawaii_cond IN ('h3')
				--		THEN d.recording_doc_number_Alternate
				--	ELSE NULL
				--	END AS HAWAII_TCT_CERTIFICATE_NBR
				,CASE 
					WHEN d.fips_code BETWEEN '15000'
							AND '16000'
						AND d.recording_doc_number LIKE '%T%'
						THEN d.recording_doc_number
					ELSE NULL
					END AS HAWAII_LAND_COURT_DOC_NBR
				,CASE 
					WHEN d.fips_code BETWEEN '15000'
							AND '16000'
						AND ISNULL(d.recording_doc_number_Alternate, '') > ''
						THEN d.recording_doc_number_Alternate
					ELSE NULL
					END AS HAWAII_TCT_CERTIFICATE_NBR
			) d3
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	/*	 

SELECT 'Document_Isnull' AS _Document_Isnull
,doc_id
,Attorney_Firm_Name
	--,Last_Name
	--,Middle_Name
	--,First_Name
	--,Suffix
	,requested_prepared_by_attorney_name_identifier
	,requested_prepared_by_Attorney_Last_Company_Name
	,requested_prepared_by_attorney_first_name
	,requested_prepared_by_attorney_middle_initial
	,requested_prepared_by_attorney_suffix
	--,requested_prepared_by_attorney_address
	--,requested_prepared_by_attorney_address_city
	--,requested_prepared_by_attorney_address_state
	--,requested_prepared_by_attorney_address_zip
	--,requested_prepared_by_attorney_phone
	--,requested_prepared_by_attorney_email
	
	,return_to_name_identifier
	,return_to_last_company_name
	,return_to_first_name
	,return_to_middle_name
	,return_to_suffix
	,return_to_address
	,return_to_city
	,return_to_state
	,return_to_zip
	,return_to_phone
	,*
FROM lien_DTDB.tmp.Document_Isnull
WHERE doc_id = 318087482



	*/
	CREATE UNIQUE CLUSTERED INDEX idxc_doc_id ON [lien_DTDB].[tmp].[Document_Isnull] (Doc_id)

	CREATE INDEX idx_Fips ON [lien_DTDB].[tmp].[Document_Isnull] (Fips)

	--
	-- Move attorney_firm_Name to title company names where 'title' is in the name - B33123
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.title_company_name = (
			SELECT [Lien].[dbo].[fn_parse_title_comp_name](CASE 
						WHEN (
								a.Attorney_name1 LIKE '%TITLE%'
								OR a.Attorney_name1 LIKE '%ABSTRACT%'
								)
							AND a.Attorney_name1 NOT LIKE '%ENTITLED%'
							THEN a.Attorney_name1
						WHEN (
								a.Attorney_name2 LIKE '%TITLE%'
								OR a.Attorney_name2 LIKE '%ABSTRACT%'
								)
							AND a.Attorney_name2 NOT LIKE '%ENTITLED%'
							THEN a.Attorney_name2
						WHEN (
								a.Attorney_name3 LIKE '%TITLE%'
								OR a.Attorney_name3 LIKE '%ABSTRACT%'
								)
							AND a.Attorney_name3 NOT LIKE '%ENTITLED%'
							THEN a.Attorney_name3
						END)
			)
	--AS New_Title_company_name
	--		select *  
	FROM [lien_DTDB].[tmp].[Document_Isnull] a
	WHERE (
			a.title_company_name IN (
				'NONE LISTED ON DOCUMENT'
				,'NEW TITLE COMPANY NAME'
				)
			OR isnull(title_company_name, '') = ''
			)
		AND (
			coalesce(nullif(a.attorney_name1, ' '), nullif(a.attorney_name2, ' '), nullif(a.attorney_name3, ' ')) LIKE '%TITLE%'
			OR coalesce(nullif(a.attorney_name1, ' '), nullif(a.attorney_name2, ' '), nullif(a.attorney_name3, ' ')) LIKE '%ABSTRACT%'
			)

	--(
	--		a.Attorney_Firm_Name LIKE '%title agency%'
	--		OR a.Attorney_Firm_Name LIKE '%title insurance agency%'
	--		OR a.Attorney_Firm_Name LIKE '%title%'
	--		OR a.Attorney_Firm_Name LIKE '%ABSTRACT%'
	--		)
	--	AND a.Attorney_Firm_Name NOT LIKE '%ENTITLED%'
	--	AND (
	--		title_company_name IN (
	--			'NONE LISTED ON DOCUMENT'
	--			,'NEW TITLE COMPANY NAME'
	--			)
	--		OR isnull(title_company_name, '') = ''
	--		)
	------
	------determine recording_doc_number and book and Page from cmt_docnumber and alt_cmt_docnumber if present
	------
	------
	------ Special sale_amount calculation for 11001 and Washington state that is being called from the ProperytHeader routine but we have to call 
	------     it from here for our testing purposes
	------
	----EXEC lien_DTDB.[INFC].[USP_Sales_Price_Calculation] @ERROR = @ERROR OUTPUT
	----IF @ERROR IS NOT NULL
	----BEGIN
	----	SET @ERROR_PARENT = @ERROR
	----	RETURN
	----		--RAISERROR (
	----		--		@ERROR
	----		--		,16
	----		--		,1
	----		--		)
	----END
	--DROP TABLE if exists MiNelson.dbo.paul_test
	--select * into Minelson.dbo.paul_test
	--from lien_DTDB.tmp.Document_Isnull
	--
	-- pre processing columns to avoid that in main capture
	--
	-- select top 100 * from lien_DTDB.infc.Document_DTDB_Transform_columns  where doc_id = 236442363
	DROP TABLE

	IF EXISTS [lien_DTDB].[infc].[Document_DTDB_Transform_columns] --lien_DTDB.dbo.DTDB_DocIdExtract_PreProcess
		SELECT d.doc_id
			,d3.recording_date
			,d3.doc_date
			,d3.Doc_signed_date
			,Fips
			,CASE 
				WHEN d.cmt_docnumber > ''
					AND d.cmt_id > 0
					AND d.cmt_id = cmt.cmt_id -- cmt.cmt_id  indicate cmt_docnumber is a document and not a bookpage
					THEN d.cmt_docnumber
				WHEN d.alt_cmt_docnumber > ''
					AND d.alt_cmt_id > 0
					AND d.alt_cmt_id = cmt.cmt_id
					THEN d.alt_cmt_docnumber
				ELSE d.Fmt_Doc_Number
				END AS FMT_DOC_NBR
			,nullif(CASE 
					WHEN d.cmt_docnumber > ''
						AND d.cmt_id > 0
						AND d.cmt_id = cmt.cmt_id
						THEN d.cmt_id
					WHEN d.alt_cmt_docnumber > ''
						AND d.alt_cmt_id > 0
						AND d.alt_cmt_id = cmt.cmt_id
						THEN d.alt_cmt_id
					ELSE d.FMT_CMT_ID
					END, 0) AS CMT_ID_DOC_NBR
			,CASE 
				WHEN d.cmt_docnumber > ''
					AND d.cmt_id > 0
					AND d.cmt_id = cmt.b_cmt_id
					THEN d.cmt_docnumber
				WHEN d.alt_cmt_docnumber > ''
					AND d.alt_cmt_id > 0
					AND d.alt_cmt_id = cmt.b_cmt_id -- cmt.b_cmt_id  indicate cmt_docnumber is a bookpage and not a document
					THEN d.alt_cmt_docnumber
				ELSE d.FMT_Book_Page
				END AS FMT_Book_Page
			,nullif(CASE 
					WHEN d.cmt_docnumber > ''
						AND d.cmt_id > 0
						AND d.cmt_id = cmt.b_cmt_id
						THEN d.cmt_id
					WHEN d.alt_cmt_docnumber > ''
						AND d.alt_cmt_id > 0
						AND d.alt_cmt_id = cmt.b_cmt_id
						THEN d.alt_cmt_id
					ELSE d.FMT_CMT_ID_Book_Page
					END, 0) AS CMT_ID_Book_Page
			,a1.*
			,a2.*
			,a3.*
			,a4.DOC_TRANSFER_TAX
			,a4_1.SALE_AMOUNT
			,a5.*
			,dpf.Deployed_fips
			,try_cast(NULL AS VARCHAR(12)) AS _Recording_doc_number
			,try_cast(NULL AS VARCHAR(6)) AS _Recording_book
			,try_cast(NULL AS VARCHAR(6)) AS _Recording_Page
		INTO [lien_DTDB].[infc].[Document_DTDB_Transform_columns]
		FROM [lien_DTDB].[tmp].[Document_Isnull] d WITH (NOLOCK)
		LEFT JOIN [Deed].[dbo].[UR_Loan_Types] lt WITH (NOLOCK) ON lt.UR_Values = d.loan_type
		LEFT JOIN [Lien_DTDB].[dbo].[UR_Document_Types] dt WITH (
				NOLOCK
				,INDEX (idx_doc_type)
				) ON dt.UR_VALUE = d.doc_type
			AND (
				dt.Delete_date IS NULL
				OR dt.Delete_date > d.Recording_Date_D
				)
			AND isnull(dt.deed_type, '') <> 'Z'
		LEFT JOIN [lien_DTDB].[Infc].[deed_Lender_names_pivot] lndr WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				) ON lndr.doc_id = d.doc_id
		OUTER APPLY (
			SELECT 1 AS Deployed_fips
			FROM [Deed].[dbo].[UR_Deployed_Fips] g WITH (
					NOLOCK
					,INDEX (IDX_fips_ci)
					)
			WHERE g.fips = d.fips
			) dpf
		OUTER APPLY (
			SELECT d_doc
				,cmt_id
				,b_cmt_id
			FROM [SPDB].[dbo].[fn_Get_Parms_for_CMTID](d.cmt_id, d.alt_cmt_id)
			) cmt
		OUTER APPLY (
			SELECT CASE 
					WHEN d.fips_code BETWEEN 15000
							AND 16000
						THEN replace(replace(replace(d.Fmt_Doc_Number, 'A', ''), 'T', ''), '-', '')
					ELSE d.Fmt_Doc_Number
					END AS Fmt_Doc_Number
			) d2 ----------------------------------------------make sure this is used
		OUTER APPLY (
			SELECT (
					SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](d.recording_date)
					) AS recording_date
				,(
					SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](d.doc_date)
					) AS doc_date
				,(
					SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](d.doc_Signed_date)
					) AS doc_Signed_date
				,(
					SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](date_of_loan_maturity)
					) AS date_of_loan_maturity
				,CASE 
					WHEN try_cast(datepart(year, d.recording_date_d) AS VARCHAR(4)) = substring(d.recording_doc_number, 1, 4)
						AND substring(d.recording_doc_number, 5, 1) = '-'
						THEN substring(d.recording_doc_number, 6, 20)
					ELSE d.recording_doc_number
					END AS recording_doc_number
			) d3
		OUTER APPLY (
			SELECT
				--CASE 
				--	WHEN d.recording_doc_number LIKE '%.%'
				--		THEN Right('000000000000' + reverse(substring(Reverse(d3.recording_doc_number), 1, PATINDEX('%.%', reverse(d.recording_doc_number)) - 1)), 12)
				--	WHEN isnull(d3.recording_doc_number, '') > ''
				--		AND isnull(d3.recording_doc_number, '') NOT IN ('0')
				--		THEN Right('000000000000' + d3.recording_doc_number, 12)
				--	ELSE NULL
				--	END AS doc_nbr
				--try_cast(null as varchar(12)) as doc_nbr
				CASE 
					WHEN d2.Fmt_Doc_Number LIKE '%.%'
						--AND isnull(d2.Fmt_Doc_Number, '') > ''
						THEN right(try_cast('000000000000' AS VARCHAR) + reverse(substring(reverse(d2.Fmt_Doc_Number), 1, PATINDEX('%[.]%', reverse(d2.Fmt_Doc_Number)) - 1)), 12)
					WHEN isnull(d2.Fmt_Doc_Number, '') > ''
						THEN right(try_cast('000000000000' AS VARCHAR) + d2.Fmt_Doc_Number, 12)
					WHEN d.cmt_DocNumber LIKE '%.%'
						--AND isnull(d.cmt_DocNumber, '') > ''
						AND d.cmt_id = cmt.cmt_id
						THEN right(try_cast('000000000000' AS VARCHAR) + reverse(substring(reverse(d.cmt_DocNumber), 1, PATINDEX('%[.]%', reverse(d.cmt_DocNumber)) - 1)), 12)
					WHEN d.alt_cmt_DocNumber LIKE '%.%'
						--AND isnull(d.cmt_DocNumber, '') > ''
						AND d.alt_cmt_id = cmt.cmt_id
						THEN right(try_cast('000000000000' AS VARCHAR) + reverse(substring(reverse(d.alt_cmt_DocNumber), 1, PATINDEX('%[.]%', reverse(d.alt_cmt_DocNumber)) - 1)), 12)
					WHEN d.cmt_DocNumber > ''
						AND isnull(cmt.d_doc, 1) = isnull(d.cmt_id, 2)
						THEN right(try_cast('000000000000' AS VARCHAR) + d.cmt_DocNumber, 12)
					WHEN d3.recording_doc_number LIKE '%.%'
						THEN Right('000000000000' + reverse(substring(Reverse(d3.recording_doc_number), 1, PATINDEX('%.%', reverse(d.recording_doc_number)) - 1)), 12)
					WHEN isnull(d3.recording_doc_number, '') > ''
						AND isnull(d3.recording_doc_number, '') NOT IN ('0')
						THEN Right('000000000000' + d3.recording_doc_number, 12)
					ELSE NULL
					END AS doc_nbr
				-- select * from lien_DTDB.infc.Document_DTDB_Transform_columns where doc_id in (199376562)
				,CASE 
					WHEN d.RECORDING_BOOK > ''
						THEN right('00000' + substring(d.RECORDING_BOOK, 1, 6), 6)
					ELSE NULL
					END AS RECORDING_BOOK
				,CASE 
					WHEN d.RECORDING_page > ''
						THEN right('00000' + d.RECORDING_page, 6)
					ELSE NULL
					END AS RECORDING_page
				--,(
				--	SELECT T.Rules AS Tax_Rules
				--	FROM Deed.dbo.UR_TaxRates T
				--	WHERE t.fips = d.fips
				--	) AS Tax_Rules
				,CASE 
					WHEN d3.date_of_loan_maturity < d3.recording_date
						THEN NULL
					ELSE d3.date_of_loan_maturity
					END AS date_of_loan_maturity
				,CASE 
					WHEN d.doc_type IN (
							'DOTSBA'
							,'MTGSBA'
							)
						AND lndr.BYR1_LAST_NAME LIKE '%SMALL BUS%'
						THEN 'SBA'
					WHEN -----------d.loan_type IN ('S','FS')
						d.loan_type LIKE '%S%'
						OR ISNULL(d.doc_title, '') LIKE '%Home Equity Conversion%'
						-- B32429 - Missing Reverse Mortgages
						OR isnull(lndr.BYR1_OWN_NAME, '') LIKE '%HECM%'
						OR isnull(lndr.BYR1_OWN_NAME, '') LIKE '%Home Equity Conversion%'
						OR isnull(lndr.BYR1_OWN_NAME, '') LIKE '%Reverse%'
						OR isnull(lndr.BYR2_OWN_NAME, '') LIKE '%HECM%'
						OR isnull(lndr.BYR2_OWN_NAME, '') LIKE '%Home Equity Conversion%'
						OR isnull(lndr.BYR2_OWN_NAME, '') LIKE '%Reverse%'
						OR isnull(lndr.BYR3_OWN_NAME, '') LIKE '%HECM%'
						OR isnull(lndr.BYR3_OWN_NAME, '') LIKE '%Home Equity Conversion%'
						OR isnull(lndr.BYR3_OWN_NAME, '') LIKE '%Reverse%'
						OR isnull(lndr.BYR4_OWN_NAME, '') LIKE '%HECM%'
						OR isnull(lndr.BYR4_OWN_NAME, '') LIKE '%Home Equity Conversion%'
						OR isnull(lndr.BYR4_OWN_NAME, '') LIKE '%Reverse%'
						THEN 'REV'
					WHEN lndr.BYR1_LAST_NAME LIKE '%SMALL%'
						THEN 'SBA'
					WHEN lndr.BYR1_First_NAME > ''
						OR LNDR.name_identifier_1 = 't'
						THEN 'PP'
					WHEN d.doc_type IN (
							'DOTWRP'
							,'MTGWRP'
							)
						THEN 'WRP'
					ELSE lt.Loan_Type_Code
					END AS _loan_type
				,try_cast(CASE 
						WHEN d.re_recording = 'Y'
							THEN 'RD'
						WHEN d.corrected_recording = 'Y'
							THEN 'CD'
						WHEN --d.loan_type IN ('S','FS')
							d.loan_type LIKE '%S%'
							THEN 'VR'
						WHEN d.loan_type IN (
								'R'
								,'FR'
								,'HR'
								,'VR'
								)
							AND dt.DETAILED_DOCUMENT_TYPE = 'CL'
							THEN 'CL'
						WHEN d.loan_type IN (
								'R'
								,'FR'
								,'HR'
								,'VR'
								)
							THEN 'EQ'
						ELSE dt.DETAILED_DOCUMENT_TYPE
						END AS CHAR(2)) AS DETAILED_DOC_TYPE
				,CASE 
					WHEN vendor_code = 'IIMI'
						THEN 'I'
					WHEN vendor_code = 'DSI'
						THEN 'D'
					WHEN vendor_code = 'COMPETENT'
						THEN 'S'
					WHEN vendor_code = 'FAI'
						THEN 'A'
					WHEN vendor_code = 'FVL'
						THEN 'V'
					WHEN source = 'EPR'
						THEN 'E'
					WHEN source = 'REDX'
						THEN 'M'
					ELSE 'X'
					END AS data_src_ind
			) a1
		OUTER APPLY (
			SELECT CASE 
					WHEN a1.DETAILED_DOC_TYPE = 'CL'
						OR d.rider_construction_loan_flag = 'Y'
						OR datediff(month, d.recording_date_d, a1.date_of_loan_maturity) < 19
						THEN 'Y'
					ELSE NULL
					END AS MTG1_CONSTRUCTION_LOAN
				,CASE 
					WHEN a1.date_of_loan_maturity IS NOT NULL
						AND d.recording_date_d IS NOT NULL
						THEN RIGHT('000' + TRY_CAST((datepart(year, a1.date_of_loan_maturity) - datepart(year, d.recording_date_d)) AS VARCHAR), 4)
					ELSE NULL
					END AS MTG1_MTG_TERM_
			) a2
		OUTER APPLY (
			SELECT try_cast(CASE 
						WHEN a1._loan_type IS NULL
							AND a1.DETAILED_DOC_TYPE NOT IN (
								'EQ'
								,'CD'
								,'RD'
								,'CL'
								,'VR'
								)
							AND a2.MTG1_CONSTRUCTION_LOAN IS NULL
							AND a2.MTG1_MTG_TERM_ BETWEEN '0010'
								AND '0041'
							THEN 'CNV'
						ELSE a1._loan_type
						END AS CHAR(3)) AS loan_type
			) a3
		OUTER APPLY (
			SELECT TOP 1 AR.SITUS_CITY
			FROM [lien].[ur].[PROPERTYHeader] ph WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					)
			OUTER APPLY (
				SELECT coalesce(pa_ref_id, ps_ref_id, pl_ref_id) AS _ref_id
				) ph1
			OUTER APPLY (
				SELECT SITUS_CITY
				FROM [ASSR].[dbo].[assr] WITH (
						NOLOCK
						,INDEX (IDX_Assr_Ref_ID)
						)
				WHERE ref_id = ph1._ref_id
				) AR
			WHERE ph.doc_id = d.doc_id
				AND AR.SITUS_CITY IS NOT NULL
			) ph
		--OUTER APPLY (
		--	SELECT /*d.transfer_sale_purchase_price AS transfer_price
		--				,*/ round(sum(a3.Transfer_tax), 0) AS Transfer_tax
		--		,max(b.has_rule_9) AS has_rule_9
		--	FROM lien_dtdb.infc.TaxRate_SalesPriceTiers a
		--	OUTER APPLY (
		--		SELECT 1 AS has_rule_9
		--		FROM [lien_dtdb].[infc].[TaxRate_County]
		--		WHERE fips = 53055
		--			AND RuleNbr = 9
		--		) b
		--	OUTER APPLY (
		--		SELECT TaxAmtTo - d.transfer_sale_purchase_price AS _aaa
		--		) a2
		--	OUTER APPLY (
		--		SELECT CASE 
		--				WHEN TaxAmtfrom > d.transfer_sale_purchase_price
		--					THEN 0
		--				WHEN d.transfer_sale_purchase_price < TaxAmtTo
		--					THEN ((d.transfer_sale_purchase_price - TaxAmtfrom) * taxrate) / 100.00
		--				WHEN d.transfer_sale_purchase_price > TaxAmtTo
		--					THEN ((TaxAmtTo - TaxAmtfrom) * TaxRate) / 100.00
		--				ELSE 0.00
		--				END AS Transfer_tax
		--		) a3
		--	) tax_tier
		OUTER APPLY (
			SELECT CASE 
					--when tax_tier.has_rule_9 = 1 
					--	then tax_tier.Transfer_tax
					WHEN d.fips BETWEEN 17000
							AND 18000
						THEN CASE 
								WHEN d.transfer_tax <> 0
									THEN d.transfer_tax
								WHEN d.transfer_tax_state <> 0
									THEN (d.transfer_tax_state / 2) * 3
								WHEN d.transfer_tax_county <> 0
									THEN (d.transfer_tax_county * 2) / 3
								ELSE 0
								END
							-- B34761 Paulding OH
					WHEN d.fips = 39125
						THEN CASE 
								WHEN d.transfer_tax <> 0 				THEN d.transfer_tax
								WHEN d.transfer_tax_County <> 0  		THEN d.transfer_tax_County
								WHEN d.transfer_tax_State <> 0			THEN d.transfer_tax_State
								ELSE 0
								END
					ELSE d.transfer_tax
					END AS transfer_tax
				,CASE 
					WHEN d.fips = 39125
						THEN CASE 
								WHEN d.transfer_tax <> 0 				THEN 'State'
								WHEN d.transfer_tax_County <> 0         THEN 'County'
								WHEN d.transfer_tax_State <> 0			THEN 'State'
								ELSE ''
								END
					ELSE ''
					END AS State_County
			) d4
		OUTER APPLY (
			SELECT TOP 1 t1.RuleNbr AS RuleNbr
				,coalesce(NJ_Taxrate.NJ_Taxrate, city_rnge.taxRate, city.taxRate, cnty_Rnge.taxRate, t1.TaxRate) AS TaxRate
				,tr.Sales_Price_calculation
				,tr.Doc_Transfer_Tax_calculation
			FROM [lien_dtdb].[infc].[TaxRate_County] t1 WITH (
					NOLOCK
					,INDEX (idx_fips_date)
					)
			----- NJ Taxrate
			OUTER APPLY (
				SELECT TOP 1 Taxrate AS NJ_Taxrate
					,RuleNbr
				FROM [lien_dtdb].[infc].[TaxRate_County_Ranges] ct_rnge WITH (
						NOLOCK
						,INDEX (idx_fips_date)
						)
				WHERE ct_rnge.fips = CAST(d.fips_code AS INT)
					AND d.recording_date_d >= ct_rnge.Date_from
					AND (
						(
							d.transfer_sale_purchase_price > ct_rnge.TaxAmtFrom
							AND d.transfer_sale_purchase_price <= ct_rnge.TaxAmtTo
							)
						OR (ct_rnge.TaxAmtFrom = 0.00)
						)
				ORDER BY ct_rnge.Date_from DESC
				) Nj_taxrate
			---- city range taxrate  
			OUTER APPLY (
				SELECT TOP 1 *
				FROM [Lien_DTDB].[INFC].[TaxRate_City_Ranges] city_rnge WITH (
						NOLOCK
						,INDEX (idx_fips_City_date)
						)
				WHERE city_rnge.fips = Cast(d.fips_code AS INT)
					AND city_rnge.city = ph.SITUS_CITY
					AND d.recording_date_d > = city_rnge.Date_from
					AND (
						(
							d4.transfer_tax > city_rnge.TaxAmtFrom
							AND d4.transfer_tax <= city_rnge.TaxAmtTo
							)
						OR (city_rnge.TaxAmtFrom = 0.00)
						)
					AND city_rnge.Taxrate > 0
				ORDER BY city_rnge.Date_from DESC
				) city_rnge
			------ city taxrate  
			OUTER APPLY (
				SELECT *
				FROM [lien_dtdb].[infc].[TaxRate_City] city WITH (
						NOLOCK
						,INDEX (idx_fips_City_date)
						)
				WHERE city.fips = Cast(d.fips_code AS INT)
					AND city.city = ph.SITUS_CITY
					AND d.recording_date_d >= city.Date_from
				) city
			------ County_Ranges Taxrate
			OUTER APPLY (
				SELECT TOP 1 *
				FROM [lien_dtdb].[infc].[TaxRate_County_Ranges] cnty_Rnge WITH (
						NOLOCK
						,INDEX (idx_fips_date)
						)
				WHERE cnty_Rnge.fips = d.fips
					AND d.recording_date_d >= cnty_Rnge.Date_from
					AND (
						(
							d4.transfer_tax > cnty_Rnge.TaxAmtFrom
							AND d4.transfer_tax <= cnty_Rnge.TaxAmtTo
							)
						OR (cnty_Rnge.TaxAmtFrom = 0.00)
						)
				ORDER BY cnty_Rnge.Date_from DESC
				) cnty_Rnge
			INNER JOIN [lien_dtdb].[infc].[TaxRate_Rules] tr WITH (
					NOLOCK
					,INDEX (idx_RuleNbr)
					) ON tr.RuleNbr = coalesce(Nj_taxrate.RuleNbr, city_rnge.RuleNbr, city.RuleNbr, cnty_Rnge.RuleNbr, t1.RuleNbr)
			--coalesce(city_rnge.RuleNbr, ct.RuleNbr, ct_Rnge.RuleNbr, t1.RuleNbr)  
			--coalesce(ct_Rnge.RuleNbr, ct.RuleNbr, t1.RuleNbr)
			WHERE t1.fips = d.fips
				AND t1.date_from <= d.recording_date_d
			ORDER BY t1.date_from DESC
			) t1
		OUTER APPLY (
			SELECT CASE 
					WHEN ISNULL(d.transfer_sale_purchase_price, 0.00) > '0.00'
						THEN d.transfer_sale_purchase_price
							--WHEN fips_code = '39049'
							--	AND recording_date >= '2021-09-10'
							--	THEN d4.transfer_tax * 1000.00 / 1.00
							--		--when fips_code = '06065'and SITUS_CITY = 'RIVERSIDE'then v_Rule17_SA
					WHEN ISNULL(d.transfer_sale_purchase_price, 0.00) = '0.00'
						AND (
							d4.transfer_tax > '0.00'
							OR d.transfer_tax_state > '0.00'
							)
						THEN CASE 
								WHEN t1.RuleNbr = 1
									THEN d4.transfer_tax * 1000 / t1.TaxRate
								WHEN t1.RuleNbr = 2
									--then (d.Transfer_tax_State + (d.Transfer_tax_State/2))*1000/t1.TaxRate
									THEN /*CASE 
											WHEN d4.transfer_tax > '0.00'
												THEN d4.transfer_tax * 1000.00 / t1.TaxRate
											ELSE*/ (d.transfer_tax_state + (d.transfer_tax_state / 2)) * 1000.00 / t1.TaxRate
										/*END*/
								WHEN t1.RuleNbr IN (
										3
										,7
										)
									THEN (d.Transfer_tax_State + d.Transfer_tax_County) * 1000 / t1.TaxRate
								WHEN t1.RuleNbr = 4
									THEN (d4.Transfer_tax * 2) * 1000 / t1.TaxRate
								WHEN t1.RuleNbr = 5
									THEN d.Transfer_Tax_State * 1000 / t1.TaxRate
								WHEN t1.RuleNbr = 6
									THEN d4.transfer_tax * 100 / t1.TaxRate
								WHEN t1.RuleNbr = 8
									THEN coalesce(d4.transfer_tax, d.transfer_tax_state) * 1000 / t1.TaxRate
										-- B34761 - New Taxrule for Paulding OH
								WHEN t1.RuleNbr = 9 AND d4.State_County = 'State'
									THEN d4.transfer_tax * 1000
								WHEN t1.RuleNbr = 9 AND d4.State_County = 'County'
									THEN d4.transfer_tax * 1000 / t1.Taxrate
								ELSE 0.00
								END
					ELSE 0.00
					END AS SALE_AMOUNT
				,CASE 
					WHEN STATE IN (
							'ID'
							,'AK'
							,'KS'
							,'MO'
							,'MS'
							,'MT'
							,'ND'
							,'NM'
							,'TX'
							,'WY'
							,'UT'
							)
						OR d.transfer_tax_value_f_p = 'X' -- B33522 
						THEN '0.00'
					WHEN d4.Transfer_tax > 0
						THEN d4.Transfer_tax
					WHEN FIPS <> 26103
						AND d.transfer_tax_county > '0.00'
						THEN d.transfer_tax_county
							--
							--WHEN FIPS = 17031
							--	AND d.Recording_date_d <= '2022-09-01'
							--	THEN d.transfer_tax_county
					WHEN FIPS = 17031
						AND RuleNbr = 5
						AND d.transfer_tax_State > '0.00'
						THEN d.transfer_tax_State
					WHEN d.transfer_tax_county = 0.00
						AND d4.transfer_tax > 0.00
						THEN d4.transfer_tax
							--WHEN FIPS = 6065
							--	AND ph.SITUS_CITY = 'RIVERSIDE'
							--	THEN d.transfer_sale_purchase_price * 2.20 / 1000
							--
							--WHEN FIPS = 39049
							--	AND d.Recording_date_d >= '2021-09-10'
							--	THEN d.transfer_sale_purchase_price * 1.00 / 1000.00
					WHEN d4.transfer_tax = '0.00'
						AND (
							d.transfer_sale_purchase_price > '0.00'
							OR d.transfer_tax_state > '0.00'
							)
						THEN CASE 
								WHEN t1.rulenbr IN (
										1
										,5
										,7
										,8
									
										)
									THEN d.transfer_sale_purchase_price * t1.TaxRate / 1000
								WHEN t1.rulenbr = 2
									THEN d.Transfer_tax_State + (d.Transfer_tax_State / 2)
								WHEN t1.rulenbr IN (
										3
										,4
										)
									THEN d.Transfer_tax_State + d.Transfer_tax_County
								WHEN t1.rulenbr = 5
									THEN d.transfer_sale_purchase_price * t1.TaxRate / 100
								WHEN t1.rulenbr = 6
									THEN d.transfer_sale_purchase_price * t1.TaxRate / 100
								WHEN t1.rulenbr = 9
									THEN d.transfer_sale_purchase_price / 1000
								ELSE 0.00
								END
					ELSE 0.00
					END AS DOC_TRANSFER_TAX
			) a4
		OUTER APPLY (
			SELECT CASE 
					WHEN d.[state] = 'IA'
						AND a4.SALE_AMOUNT > 0
						THEN a4.SALE_AMOUNT + 500
					ELSE a4.SALE_AMOUNT
					END AS SALE_AMOUNT
			) a4_1
		OUTER APPLY (
			SELECT CASE 
					WHEN d.transfer_tax_value_f_p = 'X'
						THEN d.transfer_tax_value_f_p
					WHEN d.STATE = 'HI'
						AND d.transfer_sale_purchase_price = 0
						AND isnull(a4.SALE_AMOUNT, 0) > 0
						THEN 'E'
					WHEN d.STATE = 'CA'
						AND a4_1.sale_amount > 0
						THEN d.transfer_tax_value_f_p
					WHEN d.STATE NOT IN (
							'CA'
							,'ID'
							,'AK'
							,'KS'
							,'MO'
							,'MS'
							,'MT'
							,'ND'
							,'NM'
							,'TX'
							,'WY'
							,'UT'
							)
						AND a4_1.sale_amount > '0.00'
						AND d.transfer_tax_number_non_disclosure_flag = 'y'
						THEN 'N'
							--when d.legal_desc_unincorporated_property_flag = 'Y' then 'U'---------------------------------------------------------
					WHEN d4.transfer_tax = '0.00'
						AND d.transfer_sale_purchase_price > '0.00'
						AND a4.DOC_TRANSFER_TAX > '0.00'
						THEN 'C'
					WHEN d4.transfer_tax = '0.00'
						AND d.transfer_tax_state > '0.00'
						AND a4.DOC_TRANSFER_TAX > '0.00'
						THEN 'C'
					ELSE ''
					END AS SALE_CODE
			) a5
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--		case when [state] = 'CA' and transfer_sale_purchase_price = 0.00 and transfer_tax_value_f_p > ''
	--  then transfer_tax_value_f_p
	--  when [state] not in ('CA','ID','AK','KS','MO','MS','MT','ND','NM','TX','WY','UT') 
	--  and transfer_sale_purchase_price = 0.00
	--  and transfer_tax_number_non_disclosure_flag = 'Y'
	--  then 'N'
	--  when legal_desc_unincorporated_property_flag = 'Y'
	--  then 'U'
	--  when transfer_tax > 0.00  AND transfer_sale_purchase_price > 0.00 
	--then 'C'
	--when transfer_tax = 0.00 and transfer_tax_state > 0.00 
	--then 'C'
	--  else '' end 
	--where d.doc_id = 102101547
	CREATE CLUSTERED INDEX ixa ON [lien_DTDB].[infc].[Document_DTDB_Transform_columns] (doc_id)

	--		UPDATE d
	--SET d._Recording_doc_number = SPDB.dbo.RegexExtract(CASE 
	--			WHEN d3_doc._Recording_doc_number IS NOT NULL
	--				THEN right('00000000000' + d3_doc._Recording_doc_number, 12)
	--			ELSE right('00000000000' + d.doc_nbr, 12)
	--			END, '([^0]+.*)', '1', 0)
	--	,d._Recording_book = SPDB.dbo.RegexExtract(CASE 
	--			WHEN d3_bkpg._Recording_book IS NOT NULL
	--				THEN right('00000' + d3_bkpg._Recording_book, 6)
	--			ELSE right('00000' + d.Recording_book, 6)
	--			END, '([^0]+.*)', '1', 0)
	--	,d._Recording_Page = SPDB.dbo.RegexExtract(CASE 
	--			WHEN d3_bkpg._Recording_Page IS NOT NULL
	--				THEN right('00000' + d3_bkpg._Recording_Page, 6)
	--			ELSE right('000000' + d.Recording_Page, 6)
	--			END, '([^0]+.*)', '1', 0)
	UPDATE [lien_DTDB].[INFC].[d]
	SET d._Recording_doc_number = CASE 
			WHEN fips_code = '06067'
				THEN NULL
			WHEN d3_doc._Recording_doc_number IS NOT NULL
				THEN right('00000000000' + d3_doc._Recording_doc_number, 12)
			ELSE right('00000000000' + d.doc_nbr, 12)
			END
		,d._Recording_book = CASE 
			WHEN len(d3_bkpg._Recording_book) > 6
				THEN right(d3_bkpg._Recording_book, 6)
			WHEN d3_bkpg._Recording_book IS NOT NULL
				THEN right('00000' + d3_bkpg._Recording_book, 6)
			ELSE right('00000' + d.Recording_book, 6)
			END
		,d._Recording_Page = CASE 
			WHEN len(d3_bkpg._Recording_Page) > 6
				THEN right(d3_bkpg._Recording_Page, 6)
			WHEN d3_bkpg._Recording_Page IS NOT NULL
				THEN right('00000' + d3_bkpg._Recording_Page, 6)
			ELSE right('000000' + d.Recording_Page, 6)
			END
	FROM [lien_DTDB].[infc].[Document_DTDB_Transform_columns] d WITH (
			NOLOCK
			,INDEX (ixa)
			)
	--where doc_id = 236574904
	INNER JOIN [lien_DTDB].[tmp].[Document_Isnull] a WITH (
			NOLOCK
			,INDEX (idxc_doc_id)
			) ON a.doc_id = d.doc_id
	OUTER APPLY (
		SELECT d_doc
			,cmt_id
			,b_cmt_id
		FROM [SPDB].[dbo].[fn_Get_Parms_for_CMTID](a.cmt_id, a.alt_cmt_id)
		) cmt
	OUTER APPLY (
		SELECT CASE 
				WHEN A.fips_code = '06067'
					THEN NULL
				WHEN isnull(cmt.cmt_id, 0) = isnull(a.cmt_id, 0)
					AND isnull(a.cmt_id, 0) > 0 -- the cmt id is an doc_cmt_id and should be use
					THEN a.cmt_docnumber
				WHEN isnull(a.alt_cmt_docnumber, '') > '' --- to get here the cmtid was not a doc_cmt and if we have a value in in alt_cmt_doc_number then use it
					THEN a.alt_cmt_docnumber
						--WHEN isnull(d.fmt_doc_nbr, '') > ''
						--	THEN d.fmt_doc_nbr
				ELSE d.fmt_doc_nbr -- else default to our fmt_doc_nr
				END AS _doc_nbr
			,CASE 
				WHEN isnull(cmt.b_cmt_id, 0) = isnull(a.cmt_id, 0)
					AND isnull(a.cmt_id, 0) > 0
					THEN a.cmt_docnumber
				WHEN isnull(a.alt_cmt_docnumber, '') > ''
					THEN a.alt_cmt_docnumber
						--WHEN isnull(d.FMT_Book_Page, '') > ''
						--	THEN d.FMT_Book_Page
				ELSE d.FMT_Book_Page
				END AS _book_page
		) d2
	OUTER APPLY (
		SELECT TOP 1 item AS _Recording_doc_number
		FROM (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY 0 ORDER BY (
							SELECT 0
							)
					) AS ItemNumber
				,value AS Item
			FROM [lien_DTDB].[INFC].[STRING_SPLIT](d2._doc_nbr, '.')
			WHERE RTRIM(value) <> ''
			) ff
		ORDER BY itemnumber DESC
		) d3_doc
	OUTER APPLY (
		SELECT a.*
			,CASE 
				WHEN _item3 IS NOT NULL
					THEN _item1 + _item2
				ELSE _item1
				END AS _Recording_book
			,CASE 
				WHEN _item3 IS NOT NULL
					THEN _item3
				ELSE _item2
				END AS _Recording_Page
		FROM (
			SELECT max(CASE 
						WHEN itemnumber = 1
							THEN item
						ELSE NULL
						END) AS _item1
				,max(CASE 
						WHEN itemnumber = 2
							THEN item
						ELSE NULL
						END) AS _item2
				,max(CASE 
						WHEN itemnumber = 3
							THEN item
						ELSE NULL
						END) AS _item3
			FROM (
				SELECT ROW_NUMBER() OVER (
						PARTITION BY 0 ORDER BY (
								SELECT 0
								)
						) AS ItemNumber
					,value AS Item
				FROM [lien_DTDB].[INFC].[STRING_SPLIT](d2._book_page, '.')
				WHERE RTRIM(value) <> ''
				) ff
			) a
		) d3_bkpg
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_Extract_Document'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH 


