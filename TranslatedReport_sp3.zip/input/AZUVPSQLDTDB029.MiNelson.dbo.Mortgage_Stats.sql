/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.Mortgage_Stats | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 3/24/2021
-- Description:	Create Mortage Stats
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[Mortgage_Stats]
                
AS 


SET NOCOUNT ON

BEGIN
 
 --- Remember to use Minelson DB. ALready making the change for using BK only for RT replacement counties

--- step 1

 ---- Link BK Mtg
 
-- /*IF OBJECT_ID('Minelson.[dbo].[Deed_BK]') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.[dbo].[Deed_BK]

--  --   IF OBJECT_ID('[dbo].[Deed_BK_link_Final]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_Final]


--SELECT t.Fips,
-- t.US_State,
-- t.US_County,
-- t.Situs_City,
-- t.Situs_Zip_Code,
-- t.Sale_Date,t.Recording_Date,
-- t.Deed_Type,
-- t.Sale_Amount,
-- t.Mtg1_Mtg_Amount,
--t.Mtg2_Mtg_Amount,
--t.Mtg3_Mtg_Amount,

--t.Mtg4_Mtg_Amount ,
--  t.Mtg1_Mtg_Company_Code,
-- t.Mtg1_Mtg_Loan_Type_Code,
-- t.Title_Company_Name,
-- t.Pri_Cat_Code,
-- t.Resale_New_Construction ,
--  t.Reo_sale  ,
  
-- t.Arms_Length_Id ,
-- t.Inter_Family , 
--t.REF_ID , 
--t.DeedID, 
--  t.MULTI_APN , 
--    t.Source_Type,
--  t.SRC_TBL,
--  t.CLGX_UNIQUE_ID ,
-- t.DOC_NBR  , t.recording_book ,t.Recording_Page ,
-- t.MTG1_DOC_NBR ,
-- t.MTG2_DOC_NBR ,
--t.TRANSACTION_TYPE ,t.DETAILED_DOC_TYPE,
--t.BYR1_OWN_NAME, 
-- SALE_CODE , MTG1_LENDER_LAST_NAME, [SELLER_NAME_PLAINTIFF_1]
 
--into Minelson.[dbo].[Deed_BK]
--FROM [Deed].[dbo].[vDeed] t
--where isnull(Sale_Date,Recording_Date) >= '2000-01-01' 
--and source_type = 'B'

----union 

------- using Deed for county replace by RT on control table. we are continue using BK
----(SELECT t.Fips,
---- t.US_State,
---- t.US_County,
---- t.Situs_City,
---- t.Situs_Zip_Code,
---- t.Sale_Date,t.Recording_Date,
---- t.Deed_Type,
---- t.Sale_Amount,
---- t.Mtg1_Mtg_Amount,
----t.Mtg2_Mtg_Amount,
----t.Mtg3_Mtg_Amount,

----t.Mtg4_Mtg_Amount ,
----  t.Mtg1_Mtg_Company_Code,
---- t.Mtg1_Mtg_Loan_Type_Code,
---- t.Title_Company_Name,
---- t.Pri_Cat_Code,
---- t.Resale_New_Construction ,
----  t.Reo_sale  ,
  
---- t.Arms_Length_Id ,
---- t.Inter_Family , 
----t.REF_ID , 
----t.DeedID, 
----  t.MULTI_APN , 
----    t.Source_Type,
----  t.SRC_TBL,
----  t.CLGX_UNIQUE_ID ,
---- t.DOC_NBR  , t.recording_book ,t.Recording_Page ,
---- t.MTG1_DOC_NBR ,
---- t.MTG2_DOC_NBR ,
----t.TRANSACTION_TYPE ,t.DETAILED_DOC_TYPE,
----t.BYR1_OWN_NAME, 
---- SALE_CODE , MTG1_LENDER_LAST_NAME, [SELLER_NAME_PLAINTIFF_1]
 
----FROM [Deed].[dbo].[Deed] t
------where fips in (SELECT distinct fips
------  FROM [Deed].[dbo].[Transaction_Date_Control]
------  where source = 'D' and   startDate > '2012-05-31'   and doc_src_ind = 'D'
------) and isnull(Sale_Date,Recording_Date) >= '20180101' ----134,609
------and  t.source_type = 'B'

----inner join [Deed].[dbo].[Transaction_Date_Control] c
----on t.fips = c.fips and c.doc_src_ind = 'D' and c.d_StartDate >'2012-05-31'
----where   isnull(Sale_Date,Recording_Date) >= c.d_StartDate
----and t.source_type = 'B'
---- and t.fips in (Select fips from History..RT_Deployed_fips)

----)


------------------------------------------------------

--/*IF OBJECT_ID('[MiNelson].[dbo].[Deed_BK_link]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Deed_BK_link]

--SELECT * into [dbo].[Deed_BK_link]
--frOM [dbo].[Deed_BK]


--alter table  [dbo].[Deed_BK_link]
--add Link  varchar(2)

--alter table  [dbo].[Deed_BK_link] add  MTG1_MTG_AMOUNT_new numeric (13,2)
-- alter table  [dbo].[Deed_BK_link]  add MTG1_DOC_NBR_new varchar (12)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link] add [MTG1_RECORDING_DATE_new] date
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]     add [MTG1_DOC_DATE_new] date
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_RECORDING_BOOK_new] varchar (6)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_RECORDING_PAGE_new] varchar (6)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_DETAILED_DOC_TYPE_new] varchar (2)
--    alter table  [dbo].[Deed_BK_link]   add [MTG1_LENDER_LAST_NAME_new] varchar (30)
--  --   alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_LENDER_FIRST_NAME_new] varchar (30)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_LENDER_ADDRESS_new]varchar (60)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_LENDER_CITY_new] varchar (30)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]    add [MTG1_LENDER_STATE_new] varchar (2)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_LENDER_ZIP_new] varchar (9)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_MTG_COMPANY_CODE_new] varchar (6)
--  alter table  [dbo].[Deed_BK_link]    add [MTG1_MTG_LOAN_TYPE_CODE_new] varchar (3)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]    add [MTG1_MTG_TERM_CODE_new] varchar (1)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_MTG_TERM_new] varchar (4)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_MTG_DUE_DATE_new] date
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_MTG_INTEREST_RATE_TYPE_new] varchar (3)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_MTG_INTEREST_RATE_new] varchar (7)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG1_SELLER_CARRY_BACK_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_PRIVATE_PARTY_LENDER_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_CONSTRUCTION_LOAN_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_REFI_FLAG_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_EQUITY_FLAG_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG1_OTHER_SUBORDINATE_LOANS_new] varchar (1)


--alter table  [dbo].[Deed_BK_link] add  MTG2_MTG_AMOUNT_new numeric (13,2)
-- alter table  [dbo].[Deed_BK_link]  add MTG2_DOC_NBR_new varchar (12)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link] add [MTG2_RECORDING_DATE_new] date
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]     add [MTG2_DOC_DATE_new] date
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_RECORDING_BOOK_new] varchar (6)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_RECORDING_PAGE_new] varchar (6)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_DETAILED_DOC_TYPE_new] varchar (2)
--    alter table  [dbo].[Deed_BK_link]   add [MTG2_LENDER_LAST_NAME_new] varchar (30)
--  --   alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_LENDER_FIRST_NAME_new] varchar (30)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_LENDER_ADDRESS_new]varchar (60)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_LENDER_CITY_new] varchar (30)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]    add [MTG2_LENDER_STATE_new] varchar (2)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_LENDER_ZIP_new] varchar (9)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_MTG_COMPANY_CODE_new] varchar (6)
--  alter table  [dbo].[Deed_BK_link]    add [MTG2_MTG_LOAN_TYPE_CODE_new] varchar (3)
--  --alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]    add [MTG2_MTG_TERM_CODE_new] varchar (1)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_MTG_TERM_new] varchar (4)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_MTG_DUE_DATE_new] date
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_MTG_INTEREST_RATE_TYPE_new] varchar (3)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_MTG_INTEREST_RATE_new] varchar (7)
--  -- alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]   add [MTG2_SELLER_CARRY_BACK_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_PRIVATE_PARTY_LENDER_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_CONSTRUCTION_LOAN_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_REFI_FLAG_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_EQUITY_FLAG_new] varchar (1)
--  --  alter table  [Property_Eval_Test].[dbo].[Deed_BK_link]  add [MTG2_OTHER_SUBORDINATE_LOANS_new] varchar (1)



 
-- ----- step 2

--------------------- Link Process---------------------------

---------------------------------------update already link mtg


--update d
--set d.link = 'Y'

--FROM [dbo].[Deed_BK_link] d
--WHERE
--  Source_Type = 'B'
-- AND (MTG1_MTG_AMOUNT is not null  and MTG1_MTG_AMOUNT <> 0)
-- AND NULLIF(DOC_NBR, '') IS NOT NULL
-- AND NULLIF(MTG1_DOC_NBR, '') IS NOT NULL
-- AND MTG1_DOC_NBR != DOC_NBR
 
-------------------------set M1 for already link mtg1------------------------------

--  IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1]

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
---- x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
---- x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s, x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
---- x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
----,y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
----      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
----        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
----      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
----      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--   ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
--      --,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
--      --,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
--      --,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
--      --,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
--      --,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
--      --,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--      ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
--      --,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
--      --,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
--      --,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
--      --,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
--      --,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
--      --,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
--      --,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
--      --,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
--      --,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
--      --,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
--      --,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into [dbo].[Deed_BK_link_mtg1]

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM [dbo].[Deed_BK_link]
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD'  --  and sale_amount is not null 
--and link = 'Y'
             
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM [dbo].[Deed_BK_link]
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--and DETAILED_DOC_TYPE not in ('CD','RD','MO')
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and (y.RECORDING_DATE between x.RECORDING_DATE and Dateadd( day,45,x.RECORDING_DATE))
--and left(x.BYR1_OWN_NAME, 4) = left(y.BYR1_OWN_NAME,4)

--order by x.REF_ID


--   update a
--   set a.link = 'M1'
--   from [dbo].[Deed_BK_link] a
--    inner join  [dbo].Deed_BK_link_mtg1 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
-- where 
--(case when  mtg1_doc_nbr_D is null then null else right(mtg1_Doc_nbr_D, 4)end)=
--(case when right(Mtg1_doc_nbr_S, 2) = '-0' then left(right(Mtg1_doc_nbr_S, 6),4) else right(Mtg1_doc_nbr_S, 4) end)



---------------------------------------second mtg for already link---------------------------

--      IF OBJECT_ID('[dbo].[Deed_BK_link_mtg2]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg2]

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn], 
--            row_number() over(partition by x.FIPS,x.Ref_ID order by x.sale_amount desc) as [rn_ref],
 
--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
---- x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
---- x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s, x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
---- x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
----,y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
----      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
----        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
----      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
----      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--   ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
--      --,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
--      --,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
--      --,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
--      --,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
--      --,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
--      --,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--      ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
--      --,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
--      --,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
--      --,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
--      --,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
--      --,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
--      --,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
--      --,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
--      --,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
--      --,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
--      --,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
--      --,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into [dbo].[Deed_BK_link_mtg2]

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM [dbo].[Deed_BK_link]
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD' and Mtg2_Mtg_Amount is null --  and sale_amount is not null 
--and link = 'Y'
             
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM [dbo].[Deed_BK_link]
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--and DETAILED_DOC_TYPE not in ('CD','RD','MO') 
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and (y.RECORDING_DATE between x.RECORDING_DATE and Dateadd( day,45,x.RECORDING_DATE))
--and left(x.BYR1_OWN_NAME, 4) = left(y.BYR1_OWN_NAME,4)
--order by x.REF_ID


-- update a
--   set a.link = 'B2'
--    ,a.Mtg2_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg2_Doc_NBR_New = Mtg1_Doc_Nbr_S
-- --  ,a.[MTG2_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
-- --,a.[MTG2_DOC_DATE_new] = b.MTG1_DOC_DATE_S
-- -- ,a.[MTG2_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
-- --  ,a.[MTG2_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
-- --  ,a.[MTG2_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG2_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
-- --   ,a.[MTG2_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
-- --  ,a.[MTG2_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
-- --   ,a.[MTG2_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- --,a.[MTG2_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
-- --  ,a.[MTG2_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
-- --  ,a.[MTG2_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
-- ,a.[MTG2_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
-- -- ,a.[MTG2_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
-- --  ,a.[MTG2_MTG_TERM_new] = b.MTG1_MTG_TERM_S
-- -- ,a.[MTG2_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
-- --  ,a.[MTG2_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
-- --  ,a.[MTG2_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
-- --  ,a.[MTG2_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
-- --   ,a.[MTG2_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
-- --  ,a.[MTG2_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
-- --   ,a.[MTG2_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
-- --   ,a.[MTG2_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
-- --   ,a.[MTG2_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S

--      from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg2] b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
-- where b.rn = 1 and b.rn_ref = 1
  

--  ---------------------set mtg1 record--------------
--      update a
--   set a.link = 'M2'
  
--    from [dbo].[Deed_BK_link] a
--    inner join  [dbo].Deed_BK_link_mtg2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
-- where b.rn = 1 and b.rn_ref = 1



---- -----------------------------concurr recording-----------------
 
 
--      IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1_concur]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur]

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--         row_number() over(partition by x.FIPS,x.Ref_ID order by x.sale_amount desc) as [rn_ref],

--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
---- x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
---- x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s, x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
---- x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
----,y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
----      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
----        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
----      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
----      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--         ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
----      ,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
----      ,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
----      ,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
----      ,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
----      ,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
----      ,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--     ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
----      ,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
----      ,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
----      ,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
----      ,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
----      ,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
----      ,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
----      ,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
----      ,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
----      ,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
----      ,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
----      ,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into [dbo].[Deed_BK_link_mtg1_concur]

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM [dbo].[Deed_BK_link]
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD' -- and sale_amount is not null 
--AND NULLIF(MTG1_DOC_NBR, '') IS NULL and mtg1_mtg_amount is  null
--and link is null
             
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM [dbo].[Deed_BK_link]
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--and DETAILED_DOC_TYPE not in ('CD','RD','MO') 

--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and (y.RECORDING_DATE between x.RECORDING_DATE and Dateadd( day,45,x.RECORDING_DATE))
--and left(x.BYR1_OWN_NAME, 4) = left(y.BYR1_OWN_NAME,4)

--order by x.REF_ID



--------------first concur

--      IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1_concur_1]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur_1]


--select * into [dbo].[Deed_BK_link_mtg1_concur_1]
--from[dbo].[Deed_BK_link_mtg1_concur]
--where rn = 1 and rn_ref = 1

--      IF OBJECT_ID('[Deed_BK_link_mtg1_concur_1_final]') IS NOT NULL DROP TABLE [Deed_BK_link_mtg1_concur_1_final]
--      IF OBJECT_ID('[Deed_BK_link_mtg1_concur_1_temp]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur_1_temp]


--select    row_number() over(partition by FIPS, ref_id_D order by isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) desc) as [rn_1],
--isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) as doc_page ,* 
--into [dbo].[Deed_BK_link_mtg1_concur_1_temp]
--from  [dbo].[Deed_BK_link_mtg1_concur_1]

--select * 
--into [dbo].[Deed_BK_link_mtg1_concur_1_final]
--from [dbo].[Deed_BK_link_mtg1_concur_1_temp]
--where rn_1 = 1



----select    row_number() over(partition by FIPS, ref_id_D order by isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) desc) as [rn_1],
----isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) as doc_page ,* 
----from  [MiNelson].[dbo].[Deed_BK_link_mtg1_concur_1]
----where ref_id_D in 
----(select ref_id_D
----from (
----select ref_id_D, ref_id_s, mtg1_doc_nbr_s, count(*) as count
----from [MiNelson].[dbo].[Deed_BK_link_mtg1_concur_1]
----  group by  ref_id_D, ref_id_s,mtg1_doc_nbr_s
----  having count(*) > 1)x)
----  order by ref_id_d



-- update a
--   set a.link = 'Y1'
--    ,a.Mtg1_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg1_Doc_NBR_New = b.Mtg1_Doc_Nbr_S
-- --  ,a.[MTG1_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
-- --,a.[MTG1_DOC_DATE_new] = b.MTG1_DOC_DATE_S
-- -- ,a.[MTG1_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
-- --  ,a.[MTG1_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
-- --  ,a.[MTG1_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG1_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
-- --   ,a.[MTG1_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
-- --  ,a.[MTG1_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
-- --   ,a.[MTG1_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- --,a.[MTG1_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
-- --  ,a.[MTG1_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
-- --  ,a.[MTG1_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
-- ,a.[MTG1_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
-- -- ,a.[MTG1_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
-- --  ,a.[MTG1_MTG_TERM_new] = b.MTG1_MTG_TERM_S
-- -- ,a.[MTG1_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
-- --  ,a.[MTG1_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
-- --  ,a.[MTG1_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
-- --  ,a.[MTG1_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
-- --   ,a.[MTG1_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
-- --  ,a.[MTG1_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
-- --   ,a.[MTG1_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
-- --   ,a.[MTG1_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
-- --   ,a.[MTG1_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S

--    from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg1_concur_1_final] b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
   
  
  
--      update a
--   set a.link = 'M1'
--     from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg1_concur_1_final] b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
 


---------------- second concur mtg

--    IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1_concur_2]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur_2]


--select * into [dbo].[Deed_BK_link_mtg1_concur_2]
--from [dbo].[Deed_BK_link_mtg1_concur]
--where rn = 2



--   update a
--   set a.link = 'Y2'
--    ,a.Mtg2_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg2_Doc_NBR_New = Mtg1_Doc_Nbr_S
-- --  ,a.[MTG2_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
-- --,a.[MTG2_DOC_DATE_new] = b.MTG1_DOC_DATE_S
-- -- ,a.[MTG2_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
-- --  ,a.[MTG2_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
-- --  ,a.[MTG2_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG2_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
-- --   ,a.[MTG2_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
-- --  ,a.[MTG2_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
-- --   ,a.[MTG2_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- --,a.[MTG2_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
-- --  ,a.[MTG2_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
-- --  ,a.[MTG2_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
--  ,a.[MTG2_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
-- -- ,a.[MTG2_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
-- --  ,a.[MTG2_MTG_TERM_new] = b.MTG1_MTG_TERM_S
-- -- ,a.[MTG2_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
-- --  ,a.[MTG2_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
-- --  ,a.[MTG2_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
-- --  ,a.[MTG2_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
-- --   ,a.[MTG2_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
-- --  ,a.[MTG2_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
-- --   ,a.[MTG2_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
-- --   ,a.[MTG2_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
-- --   ,a.[MTG2_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S

--      from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg1_concur_2] b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
  
 
--  ---------------------set mtg1 record--------------
--      update a
--   set a.link = 'M2'
  
--    from [dbo].[Deed_BK_link] a
--    inner join   [dbo].Deed_BK_link_mtg1_concur_2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
 
 
 
-- ----------------------------Matching wrong link mtg for interspousal transfer Deed---------------------------------


 
--      IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1_concur]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur]

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--         row_number() over(partition by x.FIPS,x.Ref_ID order by x.sale_amount desc) as [rn_ref],

--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
--         ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S

--     ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S

--into [dbo].[Deed_BK_link_mtg1_concur]

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM Minelson.[dbo].[Deed_BK_link]
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD'  and sale_amount is not null 
--AND NULLIF(MTG1_DOC_NBR, '') IS NULL and mtg1_mtg_amount is  null
--and link is null
             
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM Minelson.[dbo].[Deed_BK_link]
--where
--Source_Type = 'B' and SRC_TBL = 'BKD'and  link = 'Y' and (Sale_Amount is null or Sale_Amount = 0)
--and DETAILED_DOC_TYPE not in ('CD','RD','MO') 
--and mtg1_mtg_amount is not null
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and (y.RECORDING_DATE between x.RECORDING_DATE and Dateadd( day,45,x.RECORDING_DATE))
--and left(x.BYR1_OWN_NAME, 4) = left(y.BYR1_OWN_NAME,4)

--order by x.REF_ID


 
--      IF OBJECT_ID('[dbo].[Deed_BK_link_mtg1_concur_1]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur_1]


--select * into [dbo].[Deed_BK_link_mtg1_concur_1]
--from[dbo].[Deed_BK_link_mtg1_concur]
--where rn = 1 and rn_ref = 1

--      IF OBJECT_ID('[Deed_BK_link_mtg1_concur_1_final]') IS NOT NULL DROP TABLE [Deed_BK_link_mtg1_concur_1_final]
--      IF OBJECT_ID('[Deed_BK_link_mtg1_concur_1_temp]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_mtg1_concur_1_temp]


--select    row_number() over(partition by FIPS, ref_id_D order by isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) desc) as [rn_1],
--isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) as doc_page ,* 
--into [dbo].[Deed_BK_link_mtg1_concur_1_temp]
--from  [dbo].[Deed_BK_link_mtg1_concur_1]

--select * 
--into [dbo].[Deed_BK_link_mtg1_concur_1_final]
--from [dbo].[Deed_BK_link_mtg1_concur_1_temp]
--where rn_1 = 1




-- update a
--   set a.link = 'Y1'
--    ,a.Mtg1_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg1_Doc_NBR_New = b.Mtg1_Doc_Nbr_S
--    ,a.[MTG1_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
-- ,a.[MTG1_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
--     from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg1_concur_1_final] b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
   
  
  
--      update a
--   set a.link = 'AZ'
--     from [dbo].[Deed_BK_link] a
--    inner join   [dbo].[Deed_BK_link_mtg1_concur_1_final] b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
 
 
-- -------------------------update original fields_---------------
 
--     IF OBJECT_ID('[dbo].[Deed_BK_link_Final]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_Final]


 
-- select * into  [dbo].[Deed_BK_link_Final]
-- from [dbo].[Deed_BK_link]



------------update original fields for fist mtg link

--update a
--set 
-- Mtg1_mtg_amount = Mtg1_mtg_amount_new
--   ,Mtg1_Doc_NBR = Mtg1_Doc_Nbr_new
-- --   ,[MTG1_MTG_COMPANY_CODE] = MTG1_MTG_COMPANY_CODE_new
-- --  ,[MTG1_RECORDING_DATE] = MTG1_RECORDING_DATE_new
-- --,[MTG1_DOC_DATE] = MTG1_DOC_DATE_new
-- -- ,[MTG1_RECORDING_BOOK] = MTG1_RECORDING_BOOK_new
-- --  ,[MTG1_RECORDING_PAGE] = MTG1_RECORDING_PAGE_new
-- --  ,[MTG1_DETAILED_DOC_TYPE] = MTG1_DETAILED_DOC_TYPE_new
--  ,a.[MTG1_LENDER_LAST_NAME] = MTG1_LENDER_LAST_NAME_new
-- --   ,a.[MTG1_LENDER_FIRST_NAME] = MTG1_LENDER_FIRST_NAME_new
-- --  ,a.[MTG1_LENDER_ADDRESS]= MTG1_LENDER_ADDRESS_new
-- --   ,a.[MTG1_LENDER_CITY] = MTG1_LENDER_CITY_new
-- --,a.[MTG1_LENDER_STATE] = MTG1_LENDER_STATE_new
-- --  ,a.[MTG1_LENDER_ZIp] = MTG1_LENDER_ZIP_new
  
--  ,a.[MTG1_MTG_LOAN_TYPE_CODE] = MTG1_MTG_LOAN_TYPE_CODE_new
-- -- ,a.[MTG1_MTG_TERM_CODE] = MTG1_MTG_TERM_CODE_new
-- --  ,a.[MTG1_MTG_TERM_] = MTG1_MTG_TERM_new
-- -- ,a.[MTG1_MTG_DUE_DATE] = MTG1_MTG_DUE_DATE_new
-- --  ,a.[MTG1_MTG_INTEREST_RATE_TYPE] = MTG1_MTG_INTEREST_RATE_TYPE_new
-- --  ,a.[MTG1_MTG_INTEREST_RATE] = MTG1_MTG_INTEREST_RATE_new
-- --  ,a.[MTG1_SELLER_CARRY_BACK] = MTG1_SELLER_CARRY_BACK_new
-- --   ,a.[MTG1_PRIVATE_PARTY_LENDER] = MTG1_PRIVATE_PARTY_LENDER_new
-- --  ,a.[MTG1_CONSTRUCTION_LOAN] = MTG1_CONSTRUCTION_LOAN_new
-- --   ,a.[MTG1_REFI_FLAG] = MTG1_REFI_FLAG_new
-- --   ,a.[MTG1_EQUITY_FLAG] = MTG1_EQUITY_FLAG_new
-- --   ,a.[MTG1_OTHER_SUBORDINATE_LOANS] = MTG1_OTHER_SUBORDINATE_LOANS_new

--from [dbo].[Deed_BK_link_Final] a
--where link = 'Y1'


-------------------------update original fields for first and second mtg link

--update a
--set 
-- Mtg1_mtg_amount = Mtg1_mtg_amount_new
--   ,Mtg1_Doc_NBR = Mtg1_Doc_Nbr_new
--  --  ,[MTG1_MTG_LOAN_TYPE_CODE] = MTG1_MTG_LOAN_TYPE_CODE_new
-- --  ,[MTG1_RECORDING_DATE] = MTG1_RECORDING_DATE_new
-- --,[MTG1_DOC_DATE] = MTG1_DOC_DATE_new
-- -- ,[MTG1_RECORDING_BOOK] = MTG1_RECORDING_BOOK_new
-- --  ,[MTG1_RECORDING_PAGE] = MTG1_RECORDING_PAGE_new
-- --  ,[MTG1_DETAILED_DOC_TYPE] = MTG1_DETAILED_DOC_TYPE_new
--  ,a.[MTG1_LENDER_LAST_NAME] = MTG1_LENDER_LAST_NAME_new
-- --   ,a.[MTG1_LENDER_FIRST_NAME] = MTG1_LENDER_FIRST_NAME_new
-- --  ,a.[MTG1_LENDER_ADDRESS]= MTG1_LENDER_ADDRESS_new
-- --   ,a.[MTG1_LENDER_CITY] = MTG1_LENDER_CITY_new
-- --,a.[MTG1_LENDER_STATE] = MTG1_LENDER_STATE_new
-- --  ,a.[MTG1_LENDER_ZIp] = MTG1_LENDER_ZIP_new
-- --  ,a.[MTG1_MTG_COMPANY_CODE] = MTG1_MTG_COMPANY_CODE_new
--,a.[MTG1_MTG_LOAN_TYPE_CODE] = MTG1_MTG_LOAN_TYPE_CODE_new
-- -- ,a.[MTG1_MTG_TERM_CODE] = MTG1_MTG_TERM_CODE_new
-- --  ,a.[MTG1_MTG_TERM_] = MTG1_MTG_TERM_new
-- -- ,a.[MTG1_MTG_DUE_DATE] = MTG1_MTG_DUE_DATE_new
-- --  ,a.[MTG1_MTG_INTEREST_RATE_TYPE] = MTG1_MTG_INTEREST_RATE_TYPE_new
-- --  ,a.[MTG1_MTG_INTEREST_RATE] = MTG1_MTG_INTEREST_RATE_new
-- --  ,a.[MTG1_SELLER_CARRY_BACK] = MTG1_SELLER_CARRY_BACK_new
-- --   ,a.[MTG1_PRIVATE_PARTY_LENDER] = MTG1_PRIVATE_PARTY_LENDER_new
-- --  ,a.[MTG1_CONSTRUCTION_LOAN] = MTG1_CONSTRUCTION_LOAN_new
-- --   ,a.[MTG1_REFI_FLAG] = MTG1_REFI_FLAG_new
-- --   ,a.[MTG1_EQUITY_FLAG] = MTG1_EQUITY_FLAG_new
-- --   ,a.[MTG1_OTHER_SUBORDINATE_LOANS] = MTG1_OTHER_SUBORDINATE_LOANS_new

-- ,Mtg2_mtg_amount = Mtg2_mtg_amount_new
--   ,Mtg2_Doc_NBR = Mtg2_Doc_Nbr_new
--  -- ,[MTG2_MTG_LOAN_TYPE_CODE] = MTG2_MTG_LOAN_TYPE_CODE_new
-- --  ,[MTG2_RECORDING_DATE] = MTG2_RECORDING_DATE_new
-- --,[MTG2_DOC_DATE] = MTG2_DOC_DATE_new
-- -- ,[MTG2_RECORDING_BOOK] = MTG2_RECORDING_BOOK_new
-- --  ,[MTG2_RECORDING_PAGE] = MTG2_RECORDING_PAGE_new
-- --  ,[MTG2_DETAILED_DOC_TYPE] = MTG2_DETAILED_DOC_TYPE_new
-- -- ,[MTG2_LENDER_LAST_NAME] = MTG2_LENDER_LAST_NAME_new
-- --   ,a.[MTG2_LENDER_FIRST_NAME] = MTG2_LENDER_FIRST_NAME_new
-- --  ,a.[MTG2_LENDER_ADDRESS]= MTG2_LENDER_ADDRESS_new
-- --   ,a.[MTG2_LENDER_CITY] = MTG2_LENDER_CITY_new
-- --,a.[MTG2_LENDER_STATE] = MTG2_LENDER_STATE_new
-- --  ,a.[MTG2_LENDER_ZIp] = MTG2_LENDER_ZIP_new
-- --  ,a.[MTG2_MTG_COMPANY_CODE] = MTG2_MTG_COMPANY_CODE_new
----,[MTG2_MTG_LOAN_TYPE_CODE] = MTG2_MTG_LOAN_TYPE_CODE_new
-- -- ,a.[MTG2_MTG_TERM_CODE] = MTG2_MTG_TERM_CODE_new
-- --  ,a.[MTG2_MTG_TERM] = MTG2_MTG_TERM_new
-- -- ,a.[MTG2_MTG_DUE_DATE] = MTG2_MTG_DUE_DATE_new
-- --  ,a.[MTG2_MTG_INTEREST_RATE_TYPE] = MTG2_MTG_INTEREST_RATE_TYPE_new
-- --  ,a.[MTG2_MTG_INTEREST_RATE] = MTG2_MTG_INTEREST_RATE_new
-- --  ,a.[MTG2_SELLER_CARRY_BACK] = MTG2_SELLER_CARRY_BACK_new
-- --   ,a.[MTG2_PRIVATE_PARTY_LENDER] = MTG2_PRIVATE_PARTY_LENDER_new
-- --  ,a.[MTG2_CONSTRUCTION_LOAN] = MTG2_CONSTRUCTION_LOAN_new
-- --   ,a.[MTG2_REFI_FLAG] = MTG2_REFI_FLAG_new
-- --   ,a.[MTG2_EQUITY_FLAG] = MTG2_EQUITY_FLAG_new
-- --   ,a.[MTG2_OTHER_SUBORDINATE_LOANS] = MTG2_OTHER_SUBORDINATE_LOANS_new

--from [dbo].[Deed_BK_link_Final] a
--where link = 'Y2'

----
--------------------------------
--------------update original fields for second mtg link where Bk already link the first

--update a
--set 
--Mtg2_mtg_amount = Mtg2_mtg_amount_new
--   ,Mtg2_Doc_NBR = Mtg2_Doc_Nbr_new
--    -- ,[MTG2_MTG_COMPANY_CODE] = MTG2_MTG_COMPANY_CODE_new
-- --  ,[MTG2_RECORDING_DATE] = MTG2_RECORDING_DATE_new
-- --,[MTG2_DOC_DATE] = MTG2_DOC_DATE_new
-- -- ,[MTG2_RECORDING_BOOK] = MTG2_RECORDING_BOOK_new
-- --  ,[MTG2_RECORDING_PAGE] = MTG2_RECORDING_PAGE_new
-- --  ,[MTG2_DETAILED_DOC_TYPE] = MTG2_DETAILED_DOC_TYPE_new
-- -- ,a.[MTG2_LENDER_LAST_NAME] = MTG2_LENDER_LAST_NAME_new
-- --   ,a.[MTG2_LENDER_FIRST_NAME] = MTG2_LENDER_FIRST_NAME_new
-- --  ,a.[MTG2_LENDER_ADDRESS]= MTG2_LENDER_ADDRESS_new
-- --   ,a.[MTG2_LENDER_CITY] = MTG2_LENDER_CITY_new
-- --,a.[MTG2_LENDER_STATE] = MTG2_LENDER_STATE_new
-- --  ,a.[MTG2_LENDER_ZIp] = MTG2_LENDER_ZIP_new

-- -- ,a.[MTG2_MTG_LOAN_TYPE_CODE] = MTG2_MTG_LOAN_TYPE_CODE_new
-- -- ,a.[MTG2_MTG_TERM_CODE] = MTG2_MTG_TERM_CODE_new
-- --  ,a.[MTG2_MTG_TERM] = MTG2_MTG_TERM_new
-- -- ,a.[MTG2_MTG_DUE_DATE] = MTG2_MTG_DUE_DATE_new
-- --  ,a.[MTG2_MTG_INTEREST_RATE_TYPE] = MTG2_MTG_INTEREST_RATE_TYPE_new
-- --  ,a.[MTG2_MTG_INTEREST_RATE] = MTG2_MTG_INTEREST_RATE_new
-- --  ,a.[MTG2_SELLER_CARRY_BACK] = MTG2_SELLER_CARRY_BACK_new
-- --   ,a.[MTG2_PRIVATE_PARTY_LENDER] = MTG2_PRIVATE_PARTY_LENDER_new
-- --  ,a.[MTG2_CONSTRUCTION_LOAN] = MTG2_CONSTRUCTION_LOAN_new
-- --   ,a.[MTG2_REFI_FLAG] = MTG2_REFI_FLAG_new
-- --   ,a.[MTG2_EQUITY_FLAG] = MTG2_EQUITY_FLAG_new
-- --   ,a.[MTG2_OTHER_SUBORDINATE_LOANS] = MTG2_OTHER_SUBORDINATE_LOANS_new
 
--from [dbo].[Deed_BK_link_Final] a
--where link = 'B2'


--------------------------------



--------------------------------

--    IF OBJECT_ID('[dbo].[Deed_BK_link_HomeSale]') IS NOT NULL DROP TABLE [dbo].[Deed_BK_link_HomeSale]

--select * 
--into [dbo].[Deed_BK_link_HomeSale]
--from [dbo].[Deed_BK_link_Final]
--where  (link is null or link not in ('M1','M2', 'AZ'))



--- step 3
  

  ------------------------------create BK raw data table


--  -----------------------------------------------------------------------------------

--  if object_id('MiNelson.dbo.Mortgage_RawData_BK') is not null
--       drop table MiNelson.dbo.Mortgage_RawData_BK;
       
       
--select
-- t.Fips,
-- t.US_State,
-- t.US_County,
-- --t.Situs_Unit_Nbr,
-- t.Situs_City,
-- left(t.Situs_Zip_Code,5) as [SitusZip],
-- left(isnull(Recording_Date,Sale_Date),7) as [SaleMonth],
-- --CONVERT(VARCHAR(10), isnull(Recording_Date,Sale_Date), 112)  as [RecDt],
-- --Doc_Nbr,
-- t.Deed_Type,
-- t.Sale_Amount,
-- t.Mtg1_Mtg_Amount,
-- case when t.Mtg1_Mtg_Amount is Null then Null
--  else isnull(t.Mtg1_Mtg_Amount,0) + isnull(t.Mtg2_Mtg_Amount,0) + isnull(t.Mtg3_Mtg_Amount,0) + isnull(t.Mtg4_Mtg_Amount,0) 
-- end as [Sum_Mtg_Amount],
-- t.Mtg1_Mtg_Company_Code,
-- t.Mtg1_Mtg_Loan_Type_Code,
-- t.Title_Company_Name,
-- t.Pri_Cat_Code,
-- --------- LoanType -------------------------
-- case 
--  when (t.[MTG1_LENDER_LAST_NAME] like 'USDA%' 
--	or t.[MTG1_LENDER_LAST_NAME] like '%DEP%AGRIC%'
--	or [MTG1_LENDER_LAST_NAME] like 'FARM SE%'  
--	or [MTG1_LENDER_LAST_NAME] like 'FARM SV%'  
--	or [MTG1_LENDER_LAST_NAME] like '% FSA%'  
--	or [MTG1_LENDER_LAST_NAME] like 'RURAL H%' 
--	or [MTG1_LENDER_LAST_NAME] like 'USA%RHS%'
	
--  ) then 'USDA'
--  when t.[MTG1_LENDER_LAST_NAME] = t.[SELLER_NAME_PLAINTIFF_1] Then 'SC'
--  when t.[MTG1_MTG_LOAN_TYPE_CODE] in ( 'CNV', 'CON') then 'CNV' 
--  when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'FHA' then 'FHA'
--  when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'VA' then 'VA'
--   when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'PP' then 'PP'
--    when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'SBA' then 'Other'
--  else 'Other'
-- end as [LoanType],
-- 'All' as [LoanTypeAll],
-- -------------------------------------------------
-- case when t.Arms_Length_Id = 1 then 'Arms-length' -------> Change 7/21 
--  when t.Inter_Family = 'Y' then 'Interfamily'
--  else t.Pri_Cat_Code --Null
-- end as [ArmsLength],
-- p.Property_Indicator,
-- p.Land_Use,
-- --------- PropertyType -------------------------
-- case when p.Property_Indicator in ('10','11','21') then
--   case when p.Property_Indicator = '10' then 'SFR'
--    when p.Property_Indicator = '11' then 'Condo'
--    else 'Other'
--   end
--  when p.Property_Indicator between '20' and '29'
--   then 'Commercial'
--  when p.Property_Indicator between '30' and '39'
--   then 'Industrial'
-- end as [PropertyType],
-- case when p.Property_Indicator in ('10','11','21') then 'All Res' 
--  else 'Non-Res'
-- end as [PropertyTypeAll],
 
-- --------------Owner Occupied-----------------------------------
--case when  p.Absentee_Own_Status = 'A' then 'A'
-- when p.Absentee_Own_Status IN ( 'O', 'M')  then 'O'
--else 'Unknown' end AS Owner_Occupied,

-- p.Total_Value_Calculated,
-- p.Land_Square_Footage,
-- p.Universal_Building_Square_Feet,
-- p.Sum_Of_Building_Square_Feet,
-- isnull(p.Year_Built,p.Effective_Year_Built) as [YearBuilt],
-- p.Sum_Of_Bedrooms,
-- p.Total_Baths_Calculated,
-- Case when Universal_Building_Square_Feet = null then Null
-- when cast(Universal_Building_Square_Feet as float) = 0 then Null
-- when t.Sale_Amount = null then Null
-- When t.SALE_AMOUNT = 0 then Null
-- Else cast (t.Sale_Amount/ CAST(P.Universal_Building_Square_Feet AS float) as decimal (10,2)) 
-- end
--as [Price/Sqft],
 
--t.REF_ID as [Ref_Id/Hist_Property_ID] ---- adding ref_id to reseach 9/29/15
----,MTG1_REFI_FLAG
--,p.SITUS_HOUSE_NBR
--,p.SITUS_STREET_NAME
--,p.MAIL_HOUSE_NBR
--,p.MAIL_STREET_NAME
--, p.SITUS_UNIT_NBR
--,p.MAIL_UNIT_NBR

--into MiNelson.dbo.Mortgage_RawData_BK

--from
-- Deed.dbo.vDeed t with (Nolock) left outer join Assr.dbo.assr p with (Nolock) on
--  t.Fips = p.Fips and
--  t.REF_ID = p.REF_ID 
--where
--isnull(Recording_Date,Sale_Date) >= '2000-01-01' and
-- (MULTI_APN not in ('D', 'M') or MULTI_APN is Null) and  ------Change 9/24/15 exclude M
-- t.Pri_Cat_Code in ('A','B') and    -- Added 3/02/15
-- t.Arms_Length_Id = 1 --or Deed_Type = 'U') --- Change to increase Foreclosure 7/14/15 --- not included non armslength 8/27/15
--and  p.Property_Indicator in ('10','11','21')
-- --and t.Source_Type != 'B'  -----------Add filter out Flank Data 9/24/15
-- and t.Deed_Type != 'X'   -------------Remove Deed_type = 'X' 9/24/15



-- ---------------Create CL Raw data table--------------------

  -----------------------------------------------------------------------------------

  /*if object_id('MiNelson.dbo.Mortgage_RawData_BK_CL_UR') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData_BK_CL_UR];
       
       
select
 t.Fips,
 t.US_State,
 t.US_County,
 --t.Situs_Unit_Nbr,
 t.Situs_City,
 left(t.Situs_Zip_Code,5) as [SitusZip],
 left(isnull(Recording_Date,Sale_Date),7) as [SaleMonth],
 --CONVERT(VARCHAR(10), isnull(Recording_Date,Sale_Date), 112)  as [RecDt],
 --Doc_Nbr,
 t.Deed_Type,
 t.Sale_Amount,
 t.Mtg1_Mtg_Amount,
  t.MTG2_MTG_AMOUNT,
 case when t.Mtg1_Mtg_Amount is Null then Null
  else isnull(t.Mtg1_Mtg_Amount,0) + isnull(t.Mtg2_Mtg_Amount,0) + isnull(t.Mtg3_Mtg_Amount,0) + isnull(t.Mtg4_Mtg_Amount,0) 
 end as [Sum_Mtg_Amount],
 t.Mtg1_Mtg_Company_Code,
 t.Mtg1_Mtg_Loan_Type_Code,
 t.Title_Company_Name,
 t.Pri_Cat_Code,
 --------- LoanType -------------------------
 case 
  when (t.[MTG1_LENDER_LAST_NAME] like 'USDA%' 
	or t.[MTG1_LENDER_LAST_NAME] like '%DEP%AGRIC%'
	or [MTG1_LENDER_LAST_NAME] like 'FARM SE%'  
	or [MTG1_LENDER_LAST_NAME] like 'FARM SV%'  
	or [MTG1_LENDER_LAST_NAME] like '% FSA%'  
	or [MTG1_LENDER_LAST_NAME] like 'RURAL H%' 
	or [MTG1_LENDER_LAST_NAME] like 'USA%RHS%'
	
  ) then 'USDA'
  when t.[MTG1_LENDER_LAST_NAME] = t.[SELLER_NAME_PLAINTIFF_1] Then 'SC'
  when t.[MTG1_MTG_LOAN_TYPE_CODE] in ( 'CNV', 'CON') then 'CNV' 
  when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'FHA' then 'FHA'
  when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'VA' then 'VA'
   when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'PP' then 'PP'
    when t.[MTG1_MTG_LOAN_TYPE_CODE] = 'SBA' then 'Other'
  else 'Other'
 end as [LoanType],
 'All' as [LoanTypeAll],
 -------------------------------------------------
 case when t.Arms_Length_Id = 1 then 'Arms-length' -------> Change 7/21 
  when t.Inter_Family = 'Y' then 'Interfamily'
  else t.Pri_Cat_Code --Null
 end as [ArmsLength],
 p.Property_Indicator,
 p.Land_Use,
 --------- PropertyType -------------------------
 case when p.Property_Indicator in ('10','11','21') then
   case when p.Property_Indicator = '10' then 'SFR'
    when p.Property_Indicator = '11' then 'Condo'
    else 'Other'
   end
  when p.Property_Indicator between '20' and '29'
   then 'Commercial'
  when p.Property_Indicator between '30' and '39'
   then 'Industrial'
 end as [PropertyType],
 case when p.Property_Indicator in ('10','11','21') then 'All Res' 
  else 'Non-Res'
 end as [PropertyTypeAll],
 
 --------------Owner Occupied-----------------------------------
case when  p.Absentee_Own_Status = 'A' then 'A'
 when p.Absentee_Own_Status IN ( 'O', 'M')  then 'O'
else 'Unknown' end AS Owner_Occupied,

 p.Total_Value_Calculated,
 p.Land_Square_Footage,
 p.Universal_Building_Square_Feet,
 p.Sum_Of_Building_Square_Feet,
 isnull(p.Year_Built,p.Effective_Year_Built) as [YearBuilt],
 p.Sum_Of_Bedrooms,
 p.Total_Baths_Calculated,
 --Case when Universal_Building_Square_Feet = null then Null
 --when cast(Universal_Building_Square_Feet as float) = 0 then Null
 --when t.Sale_Amount = null then Null
 --When t.SALE_AMOUNT = 0 then Null
 --Else cast (t.Sale_Amount/ CAST(P.Universal_Building_Square_Feet AS float) as decimal (10,2)) 
 --end
null as [Price/Sqft],
 
t.REF_ID as [Ref_Id/Hist_Property_ID] ---- adding ref_id to reseach 9/29/15
--,MTG1_REFI_FLAG
,p.SITUS_HOUSE_NBR
,p.SITUS_STREET_NAME
,p.MAIL_HOUSE_NBR
,p.MAIL_STREET_NAME
, p.SITUS_UNIT_NBR
,p.MAIL_UNIT_NBR

into [MiNelson].[dbo].[Mortgage_RawData_BK_CL_UR]

from
 [Deed].[dbo].[vDeed] t with (Nolock) left outer join [Assr].[dbo].[assr] p with (Nolock) on
  t.Fips = p.Fips and
  t.REF_ID = p.REF_ID 
where
isnull(Recording_Date,Sale_Date) >= '2000-01-01' and
 (MULTI_APN not in ('D', 'M') or MULTI_APN is Null) and  ------Change 9/24/15 exclude M
 t.Pri_Cat_Code in ('A','B') and    -- Added 3/02/15
 t.Arms_Length_Id = 1 --or Deed_Type = 'U') --- Change to increase Foreclosure 7/14/15 --- not included non armslength 8/27/15
and  p.Property_Indicator in ('10','11','21')
 --and (t.Source_Type != 'B'  or t.Source_Type is null) -----------Add filter out Flank Data 9/24/15
 and t.Deed_Type != 'X'   -------------Remove Deed_type = 'X' 9/24/15

 ------------------------------------------------------------------------------------------

 
 ---------------Create raw from HistDeed-------------------

  -----------------------------------------------------------------------------------

  /*if object_id('MiNelson.dbo.Mortgage_RawData_HistDeed') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData_HistDeed];
       
       
select 
 t.Fips,
  t.HIST_MM_STATE_CODE as [US_State] ,  
 t.HIST_MM_FIPS_COUNTY_NAME as [US_County],
 p.Situs_City,  
 left(p.Situs_Zip_Code,5) as [SitusZip],  
 left(isnull(nullif(t.SR_DATE_FILING, ' '),nullif(t.HIST_SR_DATE_TRANSFER, ' ')),4)+'-'+substring(isnull(nullif(t.SR_DATE_FILING, ' '),nullif(t.HIST_SR_DATE_TRANSFER, ' ')),5,2) as [SaleMonth],   
 t.HIST_SR_DEED_TYPE as [Deed_Type],   
 --cast(case when t.HIST_SR_VAL_TRANSFER = '0' then Null else t.Hist_SR_Val_Transfer end as float) as [Sale_Amount],  -- Added 3/05/15 
 --cast(case when t.HIST_SR_LOAN_VAL_1 = '0' then Null else t.HIST_SR_LOAN_VAL_1 end as float) as [Mtg1_Mtg_Amount],   
 --case when t.HIST_SR_LOAN_VAL_1 = '0' then Null   
 -- else cast(case when t.HIST_SR_LOAN_VAL_1 = '0' then 0 else t.HIST_SR_LOAN_VAL_1 end as float) + 
 --  cast(case when t.HIST_SR_LOAN_VAL_2 = '0' then 0 else t.HIST_SR_LOAN_VAL_2 end as float) + 
 --  cast(case when t.HIST_SR_LOAN_VAL_3 = '0' then 0 else t.HIST_SR_LOAN_VAL_3 end as float)  
 --end as [Sum_Mtg_Amount],   

 cast(case when (REPLACE(t.HIST_SR_VAL_TRANSFER, CASE WHEN CHARINDEX('.',t.HIST_SR_VAL_TRANSFER, 0)>0 THEN RIGHT(t.HIST_SR_VAL_TRANSFER,3) ELSE '' END ,'')) = '0' then Null else t.Hist_SR_Val_Transfer end as float) as [Sale_Amount],  -- Added 3/05/15 
 cast(case when (REPLACE(t.HIST_SR_LOAN_VAL_1, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_1, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_1,3) ELSE '' END ,'')) = '0' then Null else t.HIST_SR_LOAN_VAL_1 end as float) as [Mtg1_Mtg_Amount],   
  cast(case when (REPLACE(t.HIST_SR_LOAN_VAL_1, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_2, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_2,3) ELSE '' END ,'')) = '0' then Null else t.HIST_SR_LOAN_VAL_2 end as float) as [Mtg2_Mtg_Amount],  
  
 case when (REPLACE(t.HIST_SR_LOAN_VAL_1, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_1, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_1,3) ELSE '' END ,''))  = '0' then Null   
  else cast(case when (REPLACE(t.HIST_SR_LOAN_VAL_1, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_1, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_1,3) ELSE '' END ,''))  = '0' then 0 else (REPLACE(t.HIST_SR_LOAN_VAL_1, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_1, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_1,3) ELSE '' END ,''))  end as float) + 
   cast(case when (REPLACE(t.HIST_SR_LOAN_VAL_2, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_2, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_2,3) ELSE '' END ,'')) = '0' then 0 else (REPLACE(t.HIST_SR_LOAN_VAL_2, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_2, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_2,3) ELSE '' END ,''))  end as float) + 
   cast(case when (REPLACE(t.HIST_SR_LOAN_VAL_3, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_3, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_3,3) ELSE '' END ,'')) = '0' then 0 else (REPLACE(t.HIST_SR_LOAN_VAL_3, CASE WHEN CHARINDEX('.', t.HIST_SR_LOAN_VAL_3, 0)>0 THEN RIGHT(t.HIST_SR_LOAN_VAL_3,3) ELSE '' END ,'')) end as float)  
 end as [Sum_Mtg_Amount],   

  t.HIST_SR_LNDR_CODE_1 as [Mtg1_Mtg_Company_Code],   
 t.HIST_SR_LOAN_TYPE_1 as [Mtg1_Mtg_Loan_Type_Code],   
 t.HIST_SR_TITLE_CO_NAME as [Title_Company_Name],   
 Null as [Pri_Cat_Code],   


 --------- LoanType -------------------------
 case 
  when (t.[HIST_SR_LNDR_LAST_NAME_1] like 'USDA%' 
	or t.[HIST_SR_LNDR_LAST_NAME_1] like '%DEP%AGRIC%'
	or t.[HIST_SR_LNDR_LAST_NAME_1] like 'FARM SE%'  
	or t.[HIST_SR_LNDR_LAST_NAME_1] like 'FARM SV%'  
	or t.[HIST_SR_LNDR_LAST_NAME_1] like '% FSA%'  
	or t.[HIST_SR_LNDR_LAST_NAME_1] like 'RURAL H%' 
	or t.[HIST_SR_LNDR_LAST_NAME_1] like 'USA%RHS%'
	or  t.[HIST_SR_LNDR_first_NAME_1] like 'USDA%' 
	or t.[HIST_SR_LNDR_first_NAME_1] like '%DEP%AGRIC%'
	or t.[HIST_SR_LNDR_first_NAME_1] like 'FARM SE%'  
	or t.[HIST_SR_LNDR_first_NAME_1] like 'FARM SV%'  
	or t.[HIST_SR_LNDR_first_NAME_1] like '% FSA%'  
	or t.[HIST_SR_LNDR_first_NAME_1] like 'RURAL H%' 
	or t.[HIST_SR_LNDR_first_NAME_1] like 'USA%RHS%'
	
  ) then 'USDA'
  when t.[HIST_SR_LNDR_LAST_NAME_1] = t.Hist_sr_seller Then 'SC'
  when  t.HIST_SR_LOAN_TYPE_1 in ( 'CNV', 'CON', 'C') then 'CNV' 
  when  t.HIST_SR_LOAN_TYPE_1 in ('F',  'FHA') then 'FHA'
  when  t.HIST_SR_LOAN_TYPE_1 in ('V', 'VA') then 'VA'
  -- when  t.HIST_SR_LOAN_TYPE_1 = 'PP' then 'PP'
    when  t.HIST_SR_LOAN_TYPE_1 = 'SBA' then 'Other'
  else 'Other'
 end as [LoanType],
 'All' as [LoanTypeAll],
 -------------------------------------------------

  case when t.Arms_Length_Id = 1  then 'Arms-length'   
  when t.SR_INTER_RELATED = 'Y' then 'Interfamily'  
  else Null  
 end as [ArmsLength],   
 p.Property_Indicator,   
 p.Land_Use,   

 --------- PropertyType -------------------------
 case when p.Property_Indicator in ('10','11','21') then
   case when p.Property_Indicator = '10' then 'SFR'
    when p.Property_Indicator = '11' then 'Condo'
    else 'Other'
   end
  when p.Property_Indicator between '20' and '29'
   then 'Commercial'
  when p.Property_Indicator between '30' and '39'
   then 'Industrial'
 end as [PropertyType],
 case when p.Property_Indicator in ('10','11','21') then 'All Res' 
  else 'Non-Res'
 end as [PropertyTypeAll],
 
 --------------Owner Occupied-----------------------------------
case when  p.Absentee_Own_Status = 'A' then 'A'
 when p.Absentee_Own_Status IN ( 'O', 'M')  then 'O'
else 'Unknown' end AS Owner_Occupied,

 
 p.Total_Value_Calculated,
 p.Land_Square_Footage,
 p.Universal_Building_Square_Feet,
 p.Sum_Of_Building_Square_Feet,
 isnull(p.Year_Built,p.Effective_Year_Built) as [YearBuilt],
 p.Sum_Of_Bedrooms,
 p.Total_Baths_Calculated,

 
 Case when Universal_Building_Square_Feet = null then Null
 when cast(Universal_Building_Square_Feet as float) = 0 then Null
 when t.HIST_SR_VAL_TRANSFER = null then Null
 when t.HIST_SR_VAL_TRANSFER = '0' then Null
 Else cast (t.HIST_SR_VAL_TRANSFER/ CAST(P.Universal_Building_Square_Feet AS float) as decimal (10,2)) 
 end
as [Price/Sqft],
p.Ref_Id 
 ,p.SITUS_HOUSE_NBR
,p.SITUS_STREET_NAME
,p.MAIL_HOUSE_NBR
,p.MAIL_STREET_NAME
, p.SITUS_UNIT_NBR
,p.MAIL_UNIT_NBR

into [MiNelson].[dbo].[Mortgage_RawData_HistDeed]

from    
 [History].[dbo].[vHist_Deed] t with (nolock)  inner join [assr].[dbo].[PropertyReference] xref with (nolock) on   
  t.HIST_HIST_SR_PROPERTY_ID = xref.SA_PROPERTY_ID and  
  t.Fips = xref.Fips  
 left outer join [Assr].[dbo].[assr] p with (nolock) on   
  xref.Ref_Id = p.Ref_Id and
  xref.Fips = p.Fips  
 
--   left join Addr.[dbo].[CL_Address_Base] b with (nolock) on p.fips = b.fips and p.ref_id = b.ref_id and b.Address_Type = 'S'
--left join Minelson.stats.CBSA_Codes c with (nolock)
--on t.Fips = c.Fips

where 
--t.fips = 06059 and
 (t.HIST_SR_TRAN_TYPE != 'T' or t.HIST_SR_TRAN_TYPE is null) and ------ remove timshare records 6/2/2016
 
isnull(nullif(t.SR_DATE_FILING, ' '),nullif(t.HIST_SR_DATE_TRANSFER, ' '))  >= '20000101' and --'20120531' and 
--- between '19870101' and '20120531' and 

-- isnull(t.HIST_SR_DATE_TRANSFER,t.SR_DATE_FILING) between ? and ? and  --Added 6/11/15 
 --(t.HIST_SR_VAL_TRANSFER <= 5000000 or p.Property_Indicator in ('10','11','21')) and -- Added 3/05/15
HIST_SR_MULT_APN_FLAG_KEYED in ( '', null) and -------- take out 'Y'records 12/18/15 
 t.Arms_Length_Id = 1 --or t.HIST_SR_DOC_TYPE = 'u') --- change 7/14/15 get more foreclosure-- change not include foreclosure
and  p.Property_Indicator in ('10','11','21') 
  

    alter table [MiNelson].[dbo].[Mortgage_RawData_HistDeed]
   Alter Column Pri_Cat_Code char(1)
  
  --alter table MiNelson.dbo.Mortgage_RawData_HistDeed
  -- Alter Column Deed_type char(2)


 -- select * from MiNelson.dbo.Mortgage_RawData

 ----------union -----------------------

   /*if object_id('MiNelson.dbo.Mortgage_RawData') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData];

	   select * 
	   into [MiNelson].[dbo].[Mortgage_RawData]
	   from     [MiNelson].[dbo].[Mortgage_RawData_BK_CL_UR]
	   union all (select * from [MiNelson].[dbo].[Mortgage_RawData_HistDeed])

-------------------------------------------------------------------
----------Owner occupied logic--------------------------------------


---- update to O----------------

--update r
--set r.Owner_Occupied = 'O'
--from  MiNelson.dbo.Mortgage_RawData r
--where Owner_Occupied = 'unknown'
--and SITUS_HOUSE_NBR = MAIL_HOUSE_NBR
--and SITUS_STREET_NAME = MAIL_STREET_NAME
--and (SITUS_UNIT_NBR is null or SITUS_UNIT_NBR = MAIL_UNIT_NBR)

update [MiNelson].[dbo].[r]
set r.Owner_Occupied = 'O'
from [MiNelson].[dbo].[Mortgage_RawData] r
where Owner_Occupied = 'unknown'
	and replace(ltrim(replace(Ltrim(Rtrim(SITUS_HOUSE_NBR)),'0',' ')),' ','0') = replace(ltrim(replace(Ltrim(Rtrim(MAIL_HOUSE_NBR)),'0',' ')),' ','0')
and replace(ltrim(replace(Ltrim(Rtrim(SITUS_STREET_NAME)),'0',' ')),' ','0') = replace(ltrim(replace(Ltrim(Rtrim(MAIL_STREET_NAME)),'0',' ')),' ','0') 
and (SITUS_UNIT_NBR is null or replace(ltrim(replace(Ltrim(Rtrim(SITUS_UNIT_NBR)),'0',' ')),' ','0') = replace(ltrim(replace(ltrim(Rtrim(MAIL_UNIT_NBR)),'0',' ')),' ','0'))


----update to A------------------

update [MiNelson].[dbo].[r]
set r.Owner_Occupied = 'A'
from  [MiNelson].[dbo].[Mortgage_RawData] r
where Owner_Occupied = 'unknown'
and SITUS_STREET_NAME is not null
and MAIL_STREET_NAME is not null
and MAIL_STREET_NAME not like '%po box%'
and (SITUS_HOUSE_NBR <> MAIL_HOUSE_NBR
	or SITUS_STREET_NAME <> MAIL_STREET_NAME)




-----------------Lets make the mortgage amount filters for AEI be: 
------------- calculate the trends using mortgages with a mortgage amount greater than 3,000 and less than 25 million. ---------------------

Delete 
--select * 
from [MiNelson].[dbo].[Mortgage_RawData]
where Mtg1_Mtg_Amount < 3000 or Mtg1_Mtg_Amount > 25000000


Delete from [MiNelson].[dbo].[Mortgage_RawData]
where mtg1_mtg_amount is null and sum_mtg_amount is null


 ------------Filter Month00 and future date

  Delete
  FROM [MiNelson].[dbo].[Mortgage_RawData]
  where right(SaleMonth,2) = '00'


Delete
  FROM [MiNelson].[dbo].[Mortgage_RawData]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))
  

-----------------9/9/2016---------------------------
---The only change for the AEI rerun is to assume FHA,VA and USDA loans are all owner occupied.  

update [MiNelson].[dbo].[r]
set r.Owner_Occupied = 'O'
from [MiNelson].[dbo].[Mortgage_RawData] r 
where LoanType in ('USDA', 'FHA', 'VA')
and Owner_Occupied <> 'O'




----- step 4

----------------------County Level ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_County]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_County];
       
select
	Fips,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
	sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_County]
	
from (
	select
		Fips,
		SaleMonth,
		PropertyType,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
	
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,
		

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	Fips,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	Fips,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
	sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ),
	--Count (LTV_Range) as LTV_Count,


	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		Fips,
		SaleMonth,
		PropertyTypeAll,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
		
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	Fips,
	SaleMonth,
	PropertyTypeAll,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_County_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_County_level]


select
	s.Fips,
	c.State,
	c.County,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
--	LTV_Range as LTV,
	

	sum(case when LoanType = 'USDA' then Mgt1Count else 0 end) as [USDA_MtgCount],
--	sum(case when LoanType = 'USDA' then LTV_Count else 0 end) as [USDA_LTVCount],
	
	sum(case when LoanType = 'USDA' then MedMtg1Amt else 0 end) as [USDA_MedFirstMtg],
	sum(case when LoanType = 'USDA' then MedMtgSumAmt else 0 end) as [USDA_MedTotalMtg],
	sum(case when LoanType = 'USDA' then AvgFirstMortgage else 0 end) as [USDA_AvgFirstMtg],
	sum(case when LoanType = 'USDA' then AvgTotalMortgage else 0 end) as [USDA_AvgTotalMtg],
	
	sum(case when LoanType = 'SC' then Mgt1Count else 0 end) as [SC_MtgCount],
	--sum(case when LoanType = 'SC' then LTV_Count else 0 end) as [SC_LTVCount],

	sum(case when LoanType = 'SC' then MedMtg1Amt else 0 end) as [SC_MedFirstMtg],
	sum(case when LoanType = 'SC' then MedMtgSumAmt else 0 end) as [SC_MedTotalMtg],
	sum(case when LoanType = 'SC' then AvgFirstMortgage else 0 end) as [SC_AvgFirstMtg],
	sum(case when LoanType = 'SC' then AvgTotalMortgage else 0 end) as [SC_AvgTotalMtg],

	sum(case when LoanType = 'CNV' then Mgt1Count else 0 end) as [CNV_MtgCount],
	--sum(case when LoanType = 'CNV' then LTV_Count else 0 end) as [CNV_LTVCount],
	
	sum(case when LoanType = 'CNV' then MedMtg1Amt else 0 end) as [CNV_MedFirstMtg],
	sum(case when LoanType = 'CNV' then MedMtgSumAmt else 0 end) as [CNV_MedTotalMtg],
	sum(case when LoanType = 'CNV' then AvgFirstMortgage else 0 end) as [CNV_AvgFirstMtg],
	sum(case when LoanType = 'CNV' then AvgTotalMortgage else 0 end) as [CNV_AvgTotalMtg],

sum(case when LoanType = 'FHA' then Mgt1Count else 0 end) as [FHA_MtgCount],
--sum(case when LoanType = 'FHA' then LTV_Count else 0 end) as [FHA_LTVCount],

	sum(case when LoanType = 'FHA' then MedMtg1Amt else 0 end) as [FHA_MedFirstMtg],
	sum(case when LoanType = 'FHA' then MedMtgSumAmt else 0 end) as [FHA_MedTotalMtg],
	sum(case when LoanType = 'FHA' then AvgFirstMortgage else 0 end) as [FHA_AvgFirstMtg],
	sum(case when LoanType = 'FHA' then AvgTotalMortgage else 0 end) as [FHA_AvgTotalMtg],

sum(case when LoanType = 'VA' then Mgt1Count else 0 end) as [VA_MtgCount],
--sum(case when LoanType = 'VA' then LTV_Count else 0 end) as [VA_LTVCount],

	sum(case when LoanType = 'VA' then MedMtg1Amt else 0 end) as [VA_MedFirstMtg],
	sum(case when LoanType = 'VA' then MedMtgSumAmt else 0 end) as [VA_MedTotalMtg],
	sum(case when LoanType = 'VA' then AvgFirstMortgage else 0 end) as [VA_AvgFirstMtg],
	sum(case when LoanType = 'VA' then AvgTotalMortgage else 0 end) as [VA_AvgTotalMtg],

sum(case when LoanType = 'PP' then Mgt1Count else 0 end) as [PP_MtgCount],
--sum(case when LoanType = 'PP' then LTV_Count else 0 end) as [PP_LTVCount],

	sum(case when LoanType = 'PP' then MedMtg1Amt else 0 end) as [PP_MedFirstMtg],
	sum(case when LoanType = 'PP' then MedMtgSumAmt else 0 end) as [PP_MedTotalMtg],
	sum(case when LoanType = 'PP' then AvgFirstMortgage else 0 end) as [PP_AvgFirstMtg],
	sum(case when LoanType = 'PP' then AvgTotalMortgage else 0 end) as [PP_AvgTotalMtg],
	
sum(case when LoanType = 'Other' then Mgt1Count else 0 end) as [Other_MtgCount],
--sum(case when LoanType = 'Other' then LTV_Count else 0 end) as [Other_LTVCount],

	sum(case when LoanType = 'Other' then MedMtg1Amt else 0 end) as [Other_MedFirstMtg],
	sum(case when LoanType = 'Other' then MedMtgSumAmt else 0 end) as [Other_MedTotalMtg],
	sum(case when LoanType = 'Other' then AvgFirstMortgage else 0 end) as [Other_AvgFirstMtg],
	sum(case when LoanType = 'Other' then AvgTotalMortgage else 0 end) as [Other_AvgTotalMtg]


 into 
[MiNelson].[dbo].[Mortgage_County_Level]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_County] s inner join [Assr].[dbo].[CountyCodes] c on
		s.Fips = c.Fips
group by
	s.Fips,
	c.State,
	c.County,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range

--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



----------------------County Level total ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_County_total]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_County_total];
       
select
	Fips,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
	sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_County_total]
	
from (
	select
		Fips,
		SaleMonth,
		PropertyType,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
	
		Mtg1_Mtg_Amount,
			MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,
		

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	Fips,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	Fips,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
	sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--Count (LTV_Range) as LTV_Count,


	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		Fips,
		SaleMonth,
		PropertyTypeAll,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
		
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by Fips,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	Fips,
	SaleMonth,
	PropertyTypeAll,
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------


select * from [MiNelson].[dbo].[Mortgage_Aggregates_County_total]
	


------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_County_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_County_level_total]


select
	s.Fips,
	c.State,
	c.County,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
--	LTV_Range as LTV,
	

	sum( Mgt1Count) as [All_Mtg1Count],
	sum( Mtg2Count) as [All_Mtg2Count],

	sum(MedMtg1Amt) as [All_MedFirstMtg],
	sum(MedMtgSumAmt) as [All_MedTotalMtg],
	sum(AvgFirstMortgage) as [ALL_AvgFirstMtg],
	sum(AvgTotalMortgage) as [ALL_AvgTotalMtg]
	


 into 
[MiNelson].[dbo].[Mortgage_County_Level_total]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_County_total] s inner join [Assr].[dbo].[CountyCodes] c on
		s.Fips = c.Fips
group by
	s.Fips,
	c.State,
	c.County,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range

--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



--------------------------------



/*IF OBJECT_ID('[MiNelson].[stats].Mortgage_Stats_County') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[stats].[Mortgage_Stats_County]


  SELECT C.*, 
       T.All_Mtg1Count,
	    T.All_Mtg2Count,
	(T.All_Mtg1Count + T.All_Mtg2Count) as [All_Mtg_Count],
	   T.[All_MedFirstMtg]
      ,T.[All_MedTotalMtg]
      ,T.[ALL_AvgFirstMtg]
      ,T.[ALL_AvgTotalMtg]
     
	  into [MiNelson].[stats].[Mortgage_Stats_County]
  FROM [MiNelson].[dbo].[Mortgage_County_Level] C
  left join [MiNelson].[dbo].[Mortgage_County_Level_total] T
  on C.fips = T.fips and
  C.State = T.State and
  C.county = T.county and
  C.SaleMonth = T.SaleMonth and
  C.PropertyType = T.PropertyType and 
  C.Owner_Occupied = T.Owner_Occupied
  order by salemonth
 

 --select * from [MiNelson].[stats].Mortgage_Stats_County
 --where fips = 06059
 --order by 1,4,6,5
  ---------------------------------------------
  
  --- step 5
----------------------State Level ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_State]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_State];
       
select
	State,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_State]
	
from (
	select
		us_state as State,
		SaleMonth,
		PropertyType,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	State,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
--	LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	State,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		us_state as State,
		SaleMonth,
		PropertyTypeAll,
		LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	State,
	SaleMonth,
	PropertyTypeAll,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_State_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_State_level]


select
	State,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	sum(case when LoanType = 'USDA' then Mgt1Count else 0 end) as [USDA_MtgCount],
	--sum(case when LoanType = 'USDA' then LTV_Count else 0 end) as [USDA_LTVCount],
	sum(case when LoanType = 'USDA' then MedMtg1Amt else 0 end) as [USDA_MedFirstMtg],
	sum(case when LoanType = 'USDA' then MedMtgSumAmt else 0 end) as [USDA_MedTotalMtg],
	sum(case when LoanType = 'USDA' then AvgFirstMortgage else 0 end) as [USDA_AvgFirstMtg],
	sum(case when LoanType = 'USDA' then AvgTotalMortgage else 0 end) as [USDA_AvgTotalMtg],
	
	sum(case when LoanType = 'SC' then Mgt1Count else 0 end) as [SC_MtgCount],
--	sum(case when LoanType = 'SC' then LTV_Count else 0 end) as [SC_LTVCount],
	sum(case when LoanType = 'SC' then MedMtg1Amt else 0 end) as [SC_MedFirstMtg],
	sum(case when LoanType = 'SC' then MedMtgSumAmt else 0 end) as [SC_MedTotalMtg],
	sum(case when LoanType = 'SC' then AvgFirstMortgage else 0 end) as [SC_AvgFirstMtg],
	sum(case when LoanType = 'SC' then AvgTotalMortgage else 0 end) as [SC_AvgTotalMtg],

	sum(case when LoanType = 'CNV' then Mgt1Count else 0 end) as [CNV_MtgCount],
--	sum(case when LoanType = 'CNV' then LTV_Count else 0 end) as [CNV_LTVCount],
	sum(case when LoanType = 'CNV' then MedMtg1Amt else 0 end) as [CNV_MedFirstMtg],
	sum(case when LoanType = 'CNV' then MedMtgSumAmt else 0 end) as [CNV_MedTotalMtg],
	sum(case when LoanType = 'CNV' then AvgFirstMortgage else 0 end) as [CNV_AvgFirstMtg],
	sum(case when LoanType = 'CNV' then AvgTotalMortgage else 0 end) as [CNV_AvgTotalMtg],

sum(case when LoanType = 'FHA' then Mgt1Count else 0 end) as [FHA_MtgCount],
--sum(case when LoanType = 'FHA' then LTV_Count else 0 end) as [FHA_LTVCount],
	sum(case when LoanType = 'FHA' then MedMtg1Amt else 0 end) as [FHA_MedFirstMtg],
	sum(case when LoanType = 'FHA' then MedMtgSumAmt else 0 end) as [FHA_MedTotalMtg],
	sum(case when LoanType = 'FHA' then AvgFirstMortgage else 0 end) as [FHA_AvgFirstMtg],
	sum(case when LoanType = 'FHA' then AvgTotalMortgage else 0 end) as [FHA_AvgTotalMtg],

sum(case when LoanType = 'VA' then Mgt1Count else 0 end) as [VA_MtgCount],
--sum(case when LoanType = 'VA' then LTV_Count else 0 end) as [VA_LTVCount],
	sum(case when LoanType = 'VA' then MedMtg1Amt else 0 end) as [VA_MedFirstMtg],
	sum(case when LoanType = 'VA' then MedMtgSumAmt else 0 end) as [VA_MedTotalMtg],
	sum(case when LoanType = 'VA' then AvgFirstMortgage else 0 end) as [VA_AvgFirstMtg],
	sum(case when LoanType = 'VA' then AvgTotalMortgage else 0 end) as [VA_AvgTotalMtg],

sum(case when LoanType = 'PP' then Mgt1Count else 0 end) as [PP_MtgCount],
--sum(case when LoanType = 'PP' then LTV_Count else 0 end) as [PP_LTVCount],
	sum(case when LoanType = 'PP' then MedMtg1Amt else 0 end) as [PP_MedFirstMtg],
	sum(case when LoanType = 'PP' then MedMtgSumAmt else 0 end) as [PP_MedTotalMtg],
	sum(case when LoanType = 'PP' then AvgFirstMortgage else 0 end) as [PP_AvgFirstMtg],
	sum(case when LoanType = 'PP' then AvgTotalMortgage else 0 end) as [PP_AvgTotalMtg],
	
sum(case when LoanType = 'Other' then Mgt1Count else 0 end) as [Other_MtgCount],
--sum(case when LoanType = 'Other' then LTV_Count else 0 end) as [Other_LTVCount],
	sum(case when LoanType = 'Other' then MedMtg1Amt else 0 end) as [Other_MedFirstMtg],
	sum(case when LoanType = 'Other' then MedMtgSumAmt else 0 end) as [Other_MedTotalMtg],
	sum(case when LoanType = 'Other' then AvgFirstMortgage else 0 end) as [Other_AvgFirstMtg],
	sum(case when LoanType = 'Other' then AvgTotalMortgage else 0 end) as [Other_AvgTotalMtg]


 into 
[MiNelson].[dbo].[Mortgage_State_Level]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_State]  
group by
	
	State,
	SaleMonth,
	PropertyType,
	Owner_Occupied
--	LTV_Range 
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



-----------Total State level---------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_State_total]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_State_total];
       
select
	State,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_State_Total]
	
from (
	select
		us_state as State,
		SaleMonth,
		PropertyType,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	State,
	SaleMonth,
	PropertyType,
--	LoanType,
	Owner_Occupied,
--	LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	State,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
	sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		us_state as State,
		SaleMonth,
		PropertyTypeAll,
	--	LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by us_state,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	State,
	SaleMonth,
	PropertyTypeAll,
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_State_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_State_level_total]


select
	State,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	
	
	sum( Mgt1Count) as [All_Mtg1Count],
	sum( Mtg2Count) as [All_Mtg2Count],
	sum(MedMtg1Amt) as [All_MedFirstMtg],
	sum(MedMtgSumAmt) as [All_MedTotalMtg],
	sum(AvgFirstMortgage) as [ALL_AvgFirstMtg],
	sum(AvgTotalMortgage) as [ALL_AvgTotalMtg]
	

 into 
[MiNelson].[dbo].[Mortgage_State_Level_total]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_State_total]  
group by
	
	State,
	SaleMonth,
	PropertyType,
	Owner_Occupied
--	LTV_Range 
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



/*IF OBJECT_ID('[MiNelson].[stats].Mortgage_Stats_State') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[stats].[Mortgage_Stats_State]



    SELECT C.*, 
       T.All_Mtg1Count,
	    T.All_Mtg2Count,
	(T.All_Mtg1Count + T.All_Mtg2Count) as [All_Mtg_Count],
	   T.[All_MedFirstMtg]
      ,T.[All_MedTotalMtg]
      ,T.[ALL_AvgFirstMtg]
      ,T.[ALL_AvgTotalMtg]
     
	  into [MiNelson].[Stats].[Mortgage_Stats_State]
 FROM [MiNelson].[dbo].[Mortgage_state_Level] C
  left join [MiNelson].[dbo].[Mortgage_state_Level_total] T
  on 
  C.State = T.State and
   C.SaleMonth = T.SaleMonth and
  C.PropertyType = T.PropertyType and 
  C.Owner_Occupied = T.Owner_Occupied
  order by salemonth
 
 --select  * from [MiNelson].[Stats].Mortgage_Stats_State
 --where state = 'ca'
 --order by 2,4,3


  -----------------------------------------------------------
  --- step 6
  
----------------------CBSA Level ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_CBSA]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_CBSA];
       
select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_CBSA]
	
from (
	select
		C.CBSA_Code as CBSACode,
		C.CBSA_Name as CBSAName,
		SaleMonth,
		PropertyType,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x  left join [MiNelson].[stats].[CBSA_Codes] as C 
		on x.fips = C.fips
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--TV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		C.CBSA_Code as CBSACode,
		C.CBSA_Name as CBSAName,
		SaleMonth,
		PropertyTypeAll,
		LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x  left join [MiNelson].[stats].[CBSA_Codes] as C 
		on x.fips = C.fips
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyTypeAll,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_CBSA_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_CBSA_level]


select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	sum(case when LoanType = 'USDA' then Mgt1Count else 0 end) as [USDA_MtgCount],
	--sum(case when LoanType = 'USDA' then LTV_Count else 0 end) as [USDA_LTVCount],
	sum(case when LoanType = 'USDA' then MedMtg1Amt else 0 end) as [USDA_MedFirstMtg],
	sum(case when LoanType = 'USDA' then MedMtgSumAmt else 0 end) as [USDA_MedTotalMtg],
	sum(case when LoanType = 'USDA' then AvgFirstMortgage else 0 end) as [USDA_AvgFirstMtg],
	sum(case when LoanType = 'USDA' then AvgTotalMortgage else 0 end) as [USDA_AvgTotalMtg],
	
	sum(case when LoanType = 'SC' then Mgt1Count else 0 end) as [SC_MtgCount],
	--sum(case when LoanType = 'SC' then LTV_Count else 0 end) as [SC_LTVCount],
	sum(case when LoanType = 'SC' then MedMtg1Amt else 0 end) as [SC_MedFirstMtg],
	sum(case when LoanType = 'SC' then MedMtgSumAmt else 0 end) as [SC_MedTotalMtg],
	sum(case when LoanType = 'SC' then AvgFirstMortgage else 0 end) as [SC_AvgFirstMtg],
	sum(case when LoanType = 'SC' then AvgTotalMortgage else 0 end) as [SC_AvgTotalMtg],

	sum(case when LoanType = 'CNV' then Mgt1Count else 0 end) as [CNV_MtgCount],
--	sum(case when LoanType = 'CNV' then LTV_Count else 0 end) as [CNV_LTVCount],
	sum(case when LoanType = 'CNV' then MedMtg1Amt else 0 end) as [CNV_MedFirstMtg],
	sum(case when LoanType = 'CNV' then MedMtgSumAmt else 0 end) as [CNV_MedTotalMtg],
	sum(case when LoanType = 'CNV' then AvgFirstMortgage else 0 end) as [CNV_AvgFirstMtg],
	sum(case when LoanType = 'CNV' then AvgTotalMortgage else 0 end) as [CNV_AvgTotalMtg],

sum(case when LoanType = 'FHA' then Mgt1Count else 0 end) as [FHA_MtgCount],
--sum(case when LoanType = 'FHA' then LTV_Count else 0 end) as [FHA_LTVCount],
	sum(case when LoanType = 'FHA' then MedMtg1Amt else 0 end) as [FHA_MedFirstMtg],
	sum(case when LoanType = 'FHA' then MedMtgSumAmt else 0 end) as [FHA_MedTotalMtg],
	sum(case when LoanType = 'FHA' then AvgFirstMortgage else 0 end) as [FHA_AvgFirstMtg],
	sum(case when LoanType = 'FHA' then AvgTotalMortgage else 0 end) as [FHA_AvgTotalMtg],

sum(case when LoanType = 'VA' then Mgt1Count else 0 end) as [VA_MtgCount],
--sum(case when LoanType = 'VA' then LTV_Count else 0 end) as [VA_LTVCount],
	sum(case when LoanType = 'VA' then MedMtg1Amt else 0 end) as [VA_MedFirstMtg],
	sum(case when LoanType = 'VA' then MedMtgSumAmt else 0 end) as [VA_MedTotalMtg],
	sum(case when LoanType = 'VA' then AvgFirstMortgage else 0 end) as [VA_AvgFirstMtg],
	sum(case when LoanType = 'VA' then AvgTotalMortgage else 0 end) as [VA_AvgTotalMtg],

sum(case when LoanType = 'PP' then Mgt1Count else 0 end) as [PP_MtgCount],
--sum(case when LoanType = 'PP' then LTV_Count else 0 end) as [PP_LTVCount],
	sum(case when LoanType = 'PP' then MedMtg1Amt else 0 end) as [PP_MedFirstMtg],
	sum(case when LoanType = 'PP' then MedMtgSumAmt else 0 end) as [PP_MedTotalMtg],
	sum(case when LoanType = 'PP' then AvgFirstMortgage else 0 end) as [PP_AvgFirstMtg],
	sum(case when LoanType = 'PP' then AvgTotalMortgage else 0 end) as [PP_AvgTotalMtg],
	
sum(case when LoanType = 'Other' then Mgt1Count else 0 end) as [Other_MtgCount],
--sum(case when LoanType = 'Other' then LTV_Count else 0 end) as [Other_LTVCount],
	sum(case when LoanType = 'Other' then MedMtg1Amt else 0 end) as [Other_MedFirstMtg],
	sum(case when LoanType = 'Other' then MedMtgSumAmt else 0 end) as [Other_MedTotalMtg],
	sum(case when LoanType = 'Other' then AvgFirstMortgage else 0 end) as [Other_AvgFirstMtg],
	sum(case when LoanType = 'Other' then AvgTotalMortgage else 0 end) as [Other_AvgTotalMtg]


 into 
[MiNelson].[dbo].[Mortgage_CBSA_Level]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_CBSA]  
group by
	
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



--------------------CBSA Total Level------------



  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total];
       
select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total]
	
from (
	select
		C.CBSA_Code as CBSACode,
		C.CBSA_Name as CBSAName,
		SaleMonth,
		PropertyType,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x  left join [MiNelson].[stats].[CBSA_Codes] as C 
		on x.fips = C.fips
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--TV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		C.CBSA_Code as CBSACode,
		C.CBSA_Name as CBSAName,
		SaleMonth,
		PropertyTypeAll,
	--	LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by C.CBSA_Code,C.CBSA_Name,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x  left join [MiNelson].[stats].[CBSA_Codes] as C 
		on x.fips = C.fips
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyTypeAll,
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_CBSA_Level_Total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_CBSA_level_Total]


select
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	
	sum( Mgt1Count) as [All_Mtg1Count],
	sum( Mtg2Count) as [All_Mtg2Count],
	sum(MedMtg1Amt) as [All_MedFirstMtg],
	sum(MedMtgSumAmt) as [All_MedTotalMtg],
	sum(AvgFirstMortgage) as [ALL_AvgFirstMtg],
	sum(AvgTotalMortgage) as [ALL_AvgTotalMtg]

 into 
[MiNelson].[dbo].[Mortgage_CBSA_Level_Total]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total]  
group by
	
	CBSACode,
	CBSAName,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType




/*IF OBJECT_ID('[MiNelson].[stats].Mortgage_Stats_CBSA') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[stats].[Mortgage_Stats_CBSA]



    SELECT C.*, 
        T.All_Mtg1Count,
	    T.All_Mtg2Count,
	(T.All_Mtg1Count + T.All_Mtg2Count) as [All_Mtg_Count],
	   T.[All_MedFirstMtg]
      ,T.[All_MedTotalMtg]
      ,T.[ALL_AvgFirstMtg]
      ,T.[ALL_AvgTotalMtg]
     
	  into [MiNelson].[stats].[Mortgage_Stats_CBSA]
 FROM [MiNelson].[dbo].[Mortgage_CBSA_level]  C
  left join [MiNelson].[dbo].[Mortgage_CBSA_Level_Total] T
  on c.CBSACode = t.cbsacode and
	c.CBSAName = t.cbsaName and
    C.SaleMonth = T.SaleMonth and
  C.PropertyType = T.PropertyType and 
  C.Owner_Occupied = T.Owner_Occupied
  order by salemonth
 
 --select  * from[MiNelson].[stats].Mortgage_Stats_CBSA
 --where cbsacode =28300
 --order by 3,5,4

  ---- step 7



----------------------Nation Level ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Nation]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Nation];
       
select
	
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_Nation]
	
from (
	select
		
		SaleMonth,
		PropertyType,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
--	LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		
		SaleMonth,
		PropertyTypeAll,
		LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	
	SaleMonth,
	PropertyTypeAll,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Nation_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Nation_level]


select
	
	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	sum(case when LoanType = 'USDA' then Mgt1Count else 0 end) as [USDA_MtgCount],
	--sum(case when LoanType = 'USDA' then LTV_Count else 0 end) as [USDA_LTVCount],
	sum(case when LoanType = 'USDA' then MedMtg1Amt else 0 end) as [USDA_MedFirstMtg],
	sum(case when LoanType = 'USDA' then MedMtgSumAmt else 0 end) as [USDA_MedTotalMtg],
	sum(case when LoanType = 'USDA' then AvgFirstMortgage else 0 end) as [USDA_AvgFirstMtg],
	sum(case when LoanType = 'USDA' then AvgTotalMortgage else 0 end) as [USDA_AvgTotalMtg],
	
	sum(case when LoanType = 'SC' then Mgt1Count else 0 end) as [SC_MtgCount],
--	sum(case when LoanType = 'SC' then LTV_Count else 0 end) as [SC_LTVCount],
	sum(case when LoanType = 'SC' then MedMtg1Amt else 0 end) as [SC_MedFirstMtg],
	sum(case when LoanType = 'SC' then MedMtgSumAmt else 0 end) as [SC_MedTotalMtg],
	sum(case when LoanType = 'SC' then AvgFirstMortgage else 0 end) as [SC_AvgFirstMtg],
	sum(case when LoanType = 'SC' then AvgTotalMortgage else 0 end) as [SC_AvgTotalMtg],

	sum(case when LoanType = 'CNV' then Mgt1Count else 0 end) as [CNV_MtgCount],
--	sum(case when LoanType = 'CNV' then LTV_Count else 0 end) as [CNV_LTVCount],
	sum(case when LoanType = 'CNV' then MedMtg1Amt else 0 end) as [CNV_MedFirstMtg],
	sum(case when LoanType = 'CNV' then MedMtgSumAmt else 0 end) as [CNV_MedTotalMtg],
	sum(case when LoanType = 'CNV' then AvgFirstMortgage else 0 end) as [CNV_AvgFirstMtg],
	sum(case when LoanType = 'CNV' then AvgTotalMortgage else 0 end) as [CNV_AvgTotalMtg],

sum(case when LoanType = 'FHA' then Mgt1Count else 0 end) as [FHA_MtgCount],
--sum(case when LoanType = 'FHA' then LTV_Count else 0 end) as [FHA_LTVCount],
	sum(case when LoanType = 'FHA' then MedMtg1Amt else 0 end) as [FHA_MedFirstMtg],
	sum(case when LoanType = 'FHA' then MedMtgSumAmt else 0 end) as [FHA_MedTotalMtg],
	sum(case when LoanType = 'FHA' then AvgFirstMortgage else 0 end) as [FHA_AvgFirstMtg],
	sum(case when LoanType = 'FHA' then AvgTotalMortgage else 0 end) as [FHA_AvgTotalMtg],

sum(case when LoanType = 'VA' then Mgt1Count else 0 end) as [VA_MtgCount],
--sum(case when LoanType = 'VA' then LTV_Count else 0 end) as [VA_LTVCount],
	sum(case when LoanType = 'VA' then MedMtg1Amt else 0 end) as [VA_MedFirstMtg],
	sum(case when LoanType = 'VA' then MedMtgSumAmt else 0 end) as [VA_MedTotalMtg],
	sum(case when LoanType = 'VA' then AvgFirstMortgage else 0 end) as [VA_AvgFirstMtg],
	sum(case when LoanType = 'VA' then AvgTotalMortgage else 0 end) as [VA_AvgTotalMtg],

sum(case when LoanType = 'PP' then Mgt1Count else 0 end) as [PP_MtgCount],
--sum(case when LoanType = 'PP' then LTV_Count else 0 end) as [PP_LTVCount],
	sum(case when LoanType = 'PP' then MedMtg1Amt else 0 end) as [PP_MedFirstMtg],
	sum(case when LoanType = 'PP' then MedMtgSumAmt else 0 end) as [PP_MedTotalMtg],
	sum(case when LoanType = 'PP' then AvgFirstMortgage else 0 end) as [PP_AvgFirstMtg],
	sum(case when LoanType = 'PP' then AvgTotalMortgage else 0 end) as [PP_AvgTotalMtg],
	
sum(case when LoanType = 'Other' then Mgt1Count else 0 end) as [Other_MtgCount],
--sum(case when LoanType = 'Other' then LTV_Count else 0 end) as [Other_LTVCount],
	sum(case when LoanType = 'Other' then MedMtg1Amt else 0 end) as [Other_MedFirstMtg],
	sum(case when LoanType = 'Other' then MedMtgSumAmt else 0 end) as [Other_MedTotalMtg],
	sum(case when LoanType = 'Other' then AvgFirstMortgage else 0 end) as [Other_AvgFirstMtg],
	sum(case when LoanType = 'Other' then AvgTotalMortgage else 0 end) as [Other_AvgTotalMtg]


 into 
[MiNelson].[dbo].[Mortgage_Nation_Level]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_Nation]  
group by
	
	SaleMonth,
	PropertyType,
	Owner_Occupied
--	LTV_Range 
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



-----------Total Nation level---------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Nation_total]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Nation_total];
       
select
	
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_Nation_Total]
	
from (
	select
		
		SaleMonth,
		PropertyType,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by SaleMonth,PropertyType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by SaleMonth,PropertyType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	
	SaleMonth,
	PropertyType,
--	LoanType,
	Owner_Occupied,
--	LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		
		SaleMonth,
		PropertyTypeAll,
	--	LoanType,
		Owner_Occupied,
		--LTV_Range,
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	
	SaleMonth,
	PropertyTypeAll,
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Nation_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Nation_level_total]


select

	SaleMonth,
	PropertyType,
	Owner_Occupied,
	--LTV_Range as LTV,
	
	
	sum( Mgt1Count) as [All_Mtg1Count],
	sum( Mtg2Count) as [All_Mtg2Count],
	sum(MedMtg1Amt) as [All_MedFirstMtg],
	sum(MedMtgSumAmt) as [All_MedTotalMtg],
	sum(AvgFirstMortgage) as [ALL_AvgFirstMtg],
	sum(AvgTotalMortgage) as [ALL_AvgTotalMtg]
	

 into 
[MiNelson].[dbo].[Mortgage_Nation_Level_total]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_Nation_total]  
group by
	
	SaleMonth,
	PropertyType,
	Owner_Occupied
--	LTV_Range 
--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



/*IF OBJECT_ID('[MiNelson].[stats].Mortgage_Stats_Nation') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[stats].[Mortgage_Stats_Nation]



    SELECT C.*, 
       T.All_Mtg1Count,
	    T.All_Mtg2Count,
	(T.All_Mtg1Count + T.All_Mtg2Count) as [All_Mtg_Count],
	   T.[All_MedFirstMtg]
      ,T.[All_MedTotalMtg]
      ,T.[ALL_AvgFirstMtg]
      ,T.[ALL_AvgTotalMtg]
     
	  into [MiNelson].[Stats].[Mortgage_Stats_Nation]
 FROM [MiNelson].[dbo].[Mortgage_Nation_Level] C
  left join [MiNelson].[dbo].[Mortgage_Nation_Level_total] T
  on 
 
   C.SaleMonth = T.SaleMonth and
  C.PropertyType = T.PropertyType and 
  C.Owner_Occupied = T.Owner_Occupied
  order by salemonth
 


--select  * from [MiNelson].[Stats].Mortgage_Stats_Nation




 ------------------Step 8----------------------------------- 
 
 ---------------------Zip Lelvel---------------------------


 

  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Zip]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Zip];
       
select
	 SitusZip,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_Zip]
	
from (
	select
		 SitusZip,
		SaleMonth,
		PropertyType,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
	
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,
		

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,LoanType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	 SitusZip,
	SaleMonth,
	PropertyType,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	 SitusZip,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--Count (LTV_Range) as LTV_Count,


	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		 SitusZip,
		SaleMonth,
		PropertyTypeAll,
		LoanType,
		Owner_Occupied,
	--	LTV_Range,
		
		Mtg1_Mtg_Amount,MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,LoanType,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	 SitusZip,
	SaleMonth,
	PropertyTypeAll,
	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Zip_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Zip_level]


select
	s.SitusZip,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
--	LTV_Range as LTV,
	

	sum(case when LoanType = 'USDA' then Mgt1Count else 0 end) as [USDA_MtgCount],
--	sum(case when LoanType = 'USDA' then LTV_Count else 0 end) as [USDA_LTVCount],
	
	sum(case when LoanType = 'USDA' then MedMtg1Amt else 0 end) as [USDA_MedFirstMtg],
	sum(case when LoanType = 'USDA' then MedMtgSumAmt else 0 end) as [USDA_MedTotalMtg],
	sum(case when LoanType = 'USDA' then AvgFirstMortgage else 0 end) as [USDA_AvgFirstMtg],
	sum(case when LoanType = 'USDA' then AvgTotalMortgage else 0 end) as [USDA_AvgTotalMtg],
	
	sum(case when LoanType = 'SC' then Mgt1Count else 0 end) as [SC_MtgCount],
	--sum(case when LoanType = 'SC' then LTV_Count else 0 end) as [SC_LTVCount],

	sum(case when LoanType = 'SC' then MedMtg1Amt else 0 end) as [SC_MedFirstMtg],
	sum(case when LoanType = 'SC' then MedMtgSumAmt else 0 end) as [SC_MedTotalMtg],
	sum(case when LoanType = 'SC' then AvgFirstMortgage else 0 end) as [SC_AvgFirstMtg],
	sum(case when LoanType = 'SC' then AvgTotalMortgage else 0 end) as [SC_AvgTotalMtg],

	sum(case when LoanType = 'CNV' then Mgt1Count else 0 end) as [CNV_MtgCount],
	--sum(case when LoanType = 'CNV' then LTV_Count else 0 end) as [CNV_LTVCount],
	
	sum(case when LoanType = 'CNV' then MedMtg1Amt else 0 end) as [CNV_MedFirstMtg],
	sum(case when LoanType = 'CNV' then MedMtgSumAmt else 0 end) as [CNV_MedTotalMtg],
	sum(case when LoanType = 'CNV' then AvgFirstMortgage else 0 end) as [CNV_AvgFirstMtg],
	sum(case when LoanType = 'CNV' then AvgTotalMortgage else 0 end) as [CNV_AvgTotalMtg],

sum(case when LoanType = 'FHA' then Mgt1Count else 0 end) as [FHA_MtgCount],
--sum(case when LoanType = 'FHA' then LTV_Count else 0 end) as [FHA_LTVCount],

	sum(case when LoanType = 'FHA' then MedMtg1Amt else 0 end) as [FHA_MedFirstMtg],
	sum(case when LoanType = 'FHA' then MedMtgSumAmt else 0 end) as [FHA_MedTotalMtg],
	sum(case when LoanType = 'FHA' then AvgFirstMortgage else 0 end) as [FHA_AvgFirstMtg],
	sum(case when LoanType = 'FHA' then AvgTotalMortgage else 0 end) as [FHA_AvgTotalMtg],

sum(case when LoanType = 'VA' then Mgt1Count else 0 end) as [VA_MtgCount],
--sum(case when LoanType = 'VA' then LTV_Count else 0 end) as [VA_LTVCount],

	sum(case when LoanType = 'VA' then MedMtg1Amt else 0 end) as [VA_MedFirstMtg],
	sum(case when LoanType = 'VA' then MedMtgSumAmt else 0 end) as [VA_MedTotalMtg],
	sum(case when LoanType = 'VA' then AvgFirstMortgage else 0 end) as [VA_AvgFirstMtg],
	sum(case when LoanType = 'VA' then AvgTotalMortgage else 0 end) as [VA_AvgTotalMtg],

sum(case when LoanType = 'PP' then Mgt1Count else 0 end) as [PP_MtgCount],
--sum(case when LoanType = 'PP' then LTV_Count else 0 end) as [PP_LTVCount],

	sum(case when LoanType = 'PP' then MedMtg1Amt else 0 end) as [PP_MedFirstMtg],
	sum(case when LoanType = 'PP' then MedMtgSumAmt else 0 end) as [PP_MedTotalMtg],
	sum(case when LoanType = 'PP' then AvgFirstMortgage else 0 end) as [PP_AvgFirstMtg],
	sum(case when LoanType = 'PP' then AvgTotalMortgage else 0 end) as [PP_AvgTotalMtg],
	
sum(case when LoanType = 'Other' then Mgt1Count else 0 end) as [Other_MtgCount],
--sum(case when LoanType = 'Other' then LTV_Count else 0 end) as [Other_LTVCount],

	sum(case when LoanType = 'Other' then MedMtg1Amt else 0 end) as [Other_MedFirstMtg],
	sum(case when LoanType = 'Other' then MedMtgSumAmt else 0 end) as [Other_MedTotalMtg],
	sum(case when LoanType = 'Other' then AvgFirstMortgage else 0 end) as [Other_AvgFirstMtg],
	sum(case when LoanType = 'Other' then AvgTotalMortgage else 0 end) as [Other_AvgTotalMtg]


 into 
[MiNelson].[dbo].[Mortgage_Zip_Level]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_Zip] s 
group by
	s.SitusZip,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range

--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



----------------------Zip Level total ---------------------------------------------


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-----  Calculate aggregates granular/granular  ----------------------------------
---------------------------------------------------------------------------------


  /*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Zip_total]') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Zip_total];
       
select
	 SitusZip,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,

	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--count(LTV_Range) as LTV_Count,
	

	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

 into 
	[MiNelson].[dbo].[Mortgage_Aggregates_Zip_total]
	
from (
	select
		 SitusZip,
		SaleMonth,
		PropertyType,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
	
		Mtg1_Mtg_Amount,
		MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,
		

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyType,Owner_Occupied) as [RowCntMtgSum]
	
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' ---or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	 SitusZip,
	SaleMonth,
	PropertyType,
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage

---------------------------------

UNION

---------------------------------------------------------------------------------
-----  Calculate aggregates all/granular  ---------------------------------------
---------------------------------------------------------------------------------
select
	 SitusZip,
	SaleMonth,
	PropertyTypeAll as [PropertyType],
	--LoanType,
	Owner_Occupied,
	--LTV_Range,
	
	AvgFirstMortgage,
	AvgTotalMortgage,
	COUNT (Mtg1_Mtg_Amount) as Mgt1Count,
		sum (case when Mtg2_Mtg_Amount is not null and MTG2_MTG_AMOUNT <> 0 then 1 else 0 end ) as Mtg2Count,
	--Count (LTV_Range) as LTV_Count,


	convert(int,avg(case when RowNumMtg1 in ((RowCntMtg1 + 1)/2,(RowCntMtg1 + 2)/2) then Mtg1_Mtg_Amount else Null end)) as [MedMtg1Amt],
	convert(int,avg(case when RowNumMtgSum in ((RowCntMtgSum + 1)/2,(RowCntMtgSum + 2)/2) then Sum_Mtg_Amount else Null end)) as [MedMtgSumAmt]

from (
	select
		 SitusZip,
		SaleMonth,
		PropertyTypeAll,
	--	LoanType,
		Owner_Occupied,
	--	LTV_Range,
		
		Mtg1_Mtg_Amount,MTG2_MTG_AMOUNT,
		Sum_Mtg_Amount,

	convert(int,avg(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgFirstMortgage],
	convert(int,avg(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied)) as [AvgTotalMortgage],

		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Mtg1_Mtg_Amount,999999999)) as [RowNumMtg1],
		Row_Number() over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied order by isnull(Sum_Mtg_Amount,999999999)) as [RowNumMtgSum],
		count(Mtg1_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtg1],
		count(Sum_Mtg_Amount) over(partition by  SitusZip,SaleMonth,PropertyTypeAll,Owner_Occupied) as [RowCntMtgSum]
	from 
		[MiNelson].[dbo].[Mortgage_RawData] as x
	where
		ArmsLength = 'Arms-length' -----or RefiType = 'Foreclosure') 
		and
		PropertyType in ('SFR','Condo','Other')
	)y
group by
	 SitusZip,
	SaleMonth,
	PropertyTypeAll,
--	LoanType,
	Owner_Occupied,
	--LTV_Range,
	AvgFirstMortgage,
	AvgTotalMortgage
	
---------------------------------------------------------------------------------

------------ PIVOT the results -------------------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Zip_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Zip_level_total]


select
	s.SitusZip,
	SaleMonth,
	PropertyType,
	Owner_Occupied,
--	LTV_Range as LTV,
	

	
	sum( Mgt1Count) as [All_Mtg1Count],
	sum( Mtg2Count) as [All_Mtg2Count],
	sum(MedMtg1Amt) as [All_MedFirstMtg],
	sum(MedMtgSumAmt) as [All_MedTotalMtg],
	sum(AvgFirstMortgage) as [ALL_AvgFirstMtg],
	sum(AvgTotalMortgage) as [ALL_AvgTotalMtg]
	


 into 
[MiNelson].[dbo].[Mortgage_Zip_Level_total]

from
	[MiNelson].[dbo].[Mortgage_Aggregates_Zip_total] s 
group by
	s.SitusZip,
	SaleMonth,
	PropertyType,
	Owner_Occupied
	--LTV_Range

--order by
--	s.Fips,
--	SaleMonth,
--	PropertyType



--------------------------------





/*IF OBJECT_ID('[MiNelson].[stats].Mortgage_Stats_Zip') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[stats].[Mortgage_Stats_Zip]


  SELECT C.*, 
     T.All_Mtg1Count,
	    T.All_Mtg2Count,
	(T.All_Mtg1Count + T.All_Mtg2Count) as [All_Mtg_Count],
	   T.[All_MedFirstMtg]
      ,T.[All_MedTotalMtg]
      ,T.[ALL_AvgFirstMtg]
      ,T.[ALL_AvgTotalMtg]
     
	  into [MiNelson].[stats].[Mortgage_Stats_Zip]
  FROM [MiNelson].[dbo].[Mortgage_Zip_Level] C
  left join [MiNelson].[dbo].[Mortgage_Zip_Level_total] T
  on c.situszip = t.situsZip and 
  C.SaleMonth = T.SaleMonth and
  C.PropertyType = T.PropertyType and 
  C.Owner_Occupied = T.Owner_Occupied
  order by salemonth
 

 --select * from [MiNelson].[stats].Mortgage_Stats_Zip
 --where situszip = '92708'
 --order by 2,4,3

  ---------------------------------------------
  






------------------Drop temp tables------------------

  /*if object_id('MiNelson.dbo.Mortgage_RawData_LTV') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData_LTV];
	    /*if object_id('MiNelson.dbo.Mortgage_RawData_BK') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData_BK];
	     /*if object_id('MiNelson.dbo.Mortgage_RawData_CL') is not null
       */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_RawData_CL];
       
       
/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_County]') is not null */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_County];
/*if object_id('Minelson.[dbo].[Mortgage_Aggregates_County_total]') is not null */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_County_total];
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_County_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_County_level]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_County_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_County_Level_total]

/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_State]') is not null        */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_State];
/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_State_Total]') is not null        */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_State_Total];
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_State_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_State_level]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_State_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_State_Level_total]

   
/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_CBSA]') is not null  */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_CBSA];      
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_CBSA_Total];
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_CBSA_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_CBSA_level]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_CBSA_Level_Total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_CBSA_Level_Total]


/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Nation]') is not null  */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Nation]  
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Aggregates_Nation_Total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Nation_Total];
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Nation_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Nation_Level]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Nation_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Nation_Level_total]

/*if object_id('[MiNelson].[dbo].[Mortgage_Aggregates_Zip]') is not null  */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Zip]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Aggregates_Zip_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Aggregates_Zip_total]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Zip_Level]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Zip_Level]
/*IF OBJECT_ID('[MiNelson].[dbo].[Mortgage_Zip_Level_total]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Mortgage_Zip_Level_total]


  --if object_id('MiNelson.dbo.Mortgage_RawData') is not null
  --     drop table MiNelson.dbo.Mortgage_RawData;
       
 
----Inset into Fulfillment-----------------------------

/*IF OBJECT_ID('Fulfillment.dbo.Mortgage_Stats_CBSA') IS NOT NULL */
DROP TABLE IF EXISTS [Fulfillment].[dbo].[Mortgage_Stats_CBSA]

/*IF OBJECT_ID('Fulfillment.dbo.Mortgage_Stats_State') IS NOT NULL */
DROP TABLE IF EXISTS [Fulfillment].[dbo].[Mortgage_Stats_State]

/*IF OBJECT_ID('Fulfillment.dbo.Mortgage_Stats_County') IS NOT NULL */
DROP TABLE IF EXISTS [Fulfillment].[dbo].[Mortgage_Stats_County]

/*IF OBJECT_ID('Fulfillment.dbo.Mortgage_Stats_Zip') IS NOT NULL */
DROP TABLE IF EXISTS [Fulfillment].[dbo].[Mortgage_Stats_Zip]

/*IF OBJECT_ID('Fulfillment.dbo.Mortgage_Stats_Nation') IS NOT NULL */
DROP TABLE IF EXISTS [Fulfillment].[dbo].[Mortgage_Stats_Nation]



 select *  
 into [Fulfillment].[dbo].[Mortgage_Stats_CBSA]
 From [Minelson].[stats].[Mortgage_Stats_CBSA]
 
  select * 
  into [Fulfillment].[dbo].[Mortgage_Stats_State]
  From [Minelson].[stats].[Mortgage_Stats_State]
 
 Select *
 into [Fulfillment].[dbo].[Mortgage_Stats_County]
 From [Minelson].[stats].[Mortgage_Stats_County]
 
 select * 
  into [Fulfillment].[dbo].[Mortgage_Stats_Nation]
  From [Minelson].[stats].[Mortgage_Stats_Nation]
 
 Select *
 into [Fulfillment].[dbo].[Mortgage_Stats_Zip]
 From [Minelson].[stats].[Mortgage_Stats_Zip]
 
 --- deliver files

  
  ------------Filter Month00 and future date

  Delete
 -- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_Nation]
  where right(SaleMonth,2) = '00'
  
  Delete
-- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_Nation]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))
  
   Delete
 -- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_CBSA]
  where right(SaleMonth,2) = '00'
  
Delete
-- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_CBSA]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))


   Delete
 -- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_State]
  where right(SaleMonth,2) = '00'


Delete
-- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_State]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))

   Delete
 -- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_County]
  where right(SaleMonth,2) = '00'


Delete
-- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_County]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))

   Delete
 -- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_Zip]
  where right(SaleMonth,2) = '00'


Delete
-- select *
  FROM [Fulfillment].[dbo].[Mortgage_Stats_Zip]
  where SaleMonth > (  select left (CONVERT(varchar(10), GETDATE(),126),7))


select *  
From [Fulfillment].[dbo].[Mortgage_Stats_CBSA]

select * 
From [Fulfillment].[dbo].[Mortgage_Stats_State]

Select *
From [Fulfillment].[dbo].[Mortgage_Stats_County]

select * 
from [Fulfillment].[dbo].[Mortgage_Stats_Zip]

select * 
from [Fulfillment].[dbo].[Mortgage_Stats_Nation]
order by SaleMonth


-------- Texas Sales file

--/*IF OBJECT_ID('Fulfillment.dbo.Texas_Sales') IS NOT NULL */
DROP TABLE IF EXISTS Fulfillment.dbo.Texas_Sales

--SELECT COUNT(*) as count,
--       a.fips as fips,
--       isnull(left(sale_date,7),left(Recording_Date,7)) as salemonth
-- into Fulfillment.dbo.Texas_Sales
     
--  FROM [Assr].[dbo].[Assr] as a
--  inner join [Deed].[dbo].[vDeed] as b
--  on a.ref_id = b.ref_id

-- where isnull(Sale_Date,RECORDING_DATE) >= '2012-06-01' and
--  (MULTI_APN not in ('D', 'M') or MULTI_APN is Null) and  ------Change 9/24/15 exclude M
--  b.Pri_Cat_Code in ('A','B') and    -- Added 3/02/15
--  b.Arms_Length_Id = 1 --or Deed_Type = 'U') --- Change to increase Foreclosure 7/14/15 --- not included non armslength 8/27/15
--and (a.Property_Indicator in ('10','11','21') 
--              OR (a.Property_Indicator = '80'    ---------- 8/31/16 adding New construction
--                     and a.land_use in ('465', '460')
--            and ( (a.situs_house_nbr = a.mail_house_nbr and a.situs_street_name = a.mail_street_name) or a.SITUS_UNIT_NBR is not null)) )
----and b.Source_Type != 'B'  -----------Add filter out Flank Data 9/24/15
--and b.Deed_Type != 'X'   -------------Remove Deed_type = 'X' 9/24/15

--and (a.SITUS_STATE in ( 'MT','ID','WY','ND','KS','NM','IN','AK','UT','TX','MS') or (a.situs_state = 'MO' and a.fips !=29189))
--and (b.SALE_AMOUNT is null or b.SALE_AMOUNT = 0 )

--group by  a.fips, isnull(left(sale_date,7),left(Recording_Date,7))
--order by a.fips, isnull(left(sale_date,7),left(Recording_Date,7)) 
 


-- --- deliver files

  
--select *  
--From Fulfillment.dbo.Mortgage_Stats_CBSA

--select * 
--From Fulfillment.dbo.Mortgage_Stats_State

--Select *
--From Fulfillment.dbo.Mortgage_Stats_County

--select * 
--From Fulfillment.dbo.Texas_Sales
--order by salemonth desc



------------------End -----------------------------------------




-- select * from Fulfillment.dbo.Mortgage_Stats_State
-- where Owner_Occupied <> 'O'




--  ---------------------------Percentitle-----------------------------------------------------

  
--  if object_id('MiNelson.dbo.Mortgage_RawData_Percentile') is not null
--       drop table MiNelson.dbo.Mortgage_RawData_Percentile;
       

--  select C.CBSA_Code as CBSACode,
--		C.CBSA_Name as CBSAName,
--		left (salemonth,4) + case when right(salemonth,2) in (1,2,3) then '-1'
--								when right(salemonth,2) in (4,5,6) then '-2'
--								when right(salemonth,2) in (7,8,9) then '-3'
--								else  '-4' end as [Quarter]

-- ,x.* 
-- into MiNelson.dbo.Mortgage_RawData_Percentile
--from MiNelson.dbo.Mortgage_RawData x
--left join [MiNelson].[stats].[CBSA_Codes] as C 
--		on x.fips = C.fips


  
--  if object_id('MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80') is not null
--       drop table MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80;



--WITH
--  percentiles AS
--(
--  select CBSACode, CBSAName, Quarter, Sale_amount,
--  (NTILE(100) OVER (PARTITION BY CBSACode, CBSAName, Quarter ORDER BY Sale_amount ASC  ))  as Percentile
--from MiNelson.dbo.Mortgage_RawData_Percentile
--where Mtg1_Mtg_loan_type_code  = 'FHA'

--)
--SELECT
--  *, row_number() over(partition by CBSACode, CBSAName, Quarter  order by Sale_amount desc) rn
--  into MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80

--FROM
--  percentiles
--WHERE
--  percentile = 80 and cbsacode is not null
--  order by 1, 3


 

--   if object_id('MiNelson.Stats.Mortgage_Stats_Saleprice_Percentile80') is not null
--       drop table MiNelson.Stats.Mortgage_Stats_Saleprice_Percentile80;

--select CBSACode, CBSAName, Quarter, Sale_amount as SalePrice, Percentile
--into MiNelson.Stats.Mortgage_Stats_Saleprice_Percentile80
-- from MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80
--  where rn = 1
--  order by 1,3

--select *
--into Fulfillment.dbo.Mortgage_Stats_Saleprice_Percentile80
-- from MiNelson.Stats.Mortgage_Stats_Saleprice_Percentile80


--  --- drop temp tables

    
--  if object_id('MiNelson.dbo.Mortgage_RawData_Percentile') is not null
--       drop table MiNelson.dbo.Mortgage_RawData_Percentile;
       
	     
--  if object_id('MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80') is not null
--       drop table MiNelson.dbo.Mortgage_Stats_Saleprice_Percentile80;


--	  select * from  MiNelson.Stats.Mortgage_Stats_Saleprice_Percentile80

END  




