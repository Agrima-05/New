/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.Usp_Create_after_Pet_Values | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
CREATE
	

 PROCEDURE [PET].[pet_dbo].[Usp_Create_after_Pet_Values] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'Usp_Create_after_Pet_Values'
		,N'Started'

	DROP TABLE

	IF EXISTS [Pet].[Pet_tmp].[Pet_ref_ids_Apns_after]
		SELECT DISTINCT pa.fips
			,pa.ref_id
			,pa.apn
		INTO [pet].[Pet_tmp].[Pet_ref_ids_Apns_after]
		FROM [pet].[dbo].[pet_apn] pa WITH (
				NOLOCK
				,INDEX (ixb_fips_ref_id)
				)
		INNER JOIN [Pet].[Pet_tmp].[Assr] pt WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON pt.fips = pa.fips
			AND pt.ref_id = pa.ref_id

	CREATE CLUSTERED INDEX idx_fips_apn ON [pet].[Pet_tmp].[Pet_ref_ids_Apns_After] (
		fips
		,apn
		)

	--DROP TABLE

	--IF EXISTS #Fips_apn
	--	SELECT DISTINCT fips
	--		,apn
	--	INTO #fips_apn
	--	FROM (
	--		SELECT fips
	--			,apn
	--		FROM pet.Pet_tmp.Pet_ref_ids_Apns_before
			
	--		UNION ALL
			
	--		SELECT fips
	--			,apn
	--		FROM assr.Pet_tmp.Pet_ref_ids_Apns_after
	--		) a

	--CREATE INDEX ixa_Fips_Apn ON #fips_apn (
	--	Fips
	--	,apn
	--	)

	--DROP TABLE

	--IF EXISTS #Dup_ind
	--	SELECT b.fips
	--		,apn
	--		,try_cast(CASE 
	--				WHEN cnt > 1
	--					THEN 1
	--				ELSE 0
	--				END AS BIT) AS dup_ind
	--	INTO #Dup_ind
	--	FROM (
	--		SELECT a.fips
	--			,a.apn
	--			,count(1) AS cnt
	--		FROM (
	--			SELECT DISTINCT p.Fips
	--				,p.ref_id
	--				,p.apn
	--			FROM PET.dbo.PET_APN p WITH (
	--					NOLOCK
	--					,INDEX (ixa_Fips_Apn)
	--					)
	--			INNER JOIN #fips_apn a WITH (
	--					NOLOCK
	--					,INDEX (ixa_Fips_Apn)
	--					) ON a.fips = p.fips
	--				AND a.apn = p.apn
	--			) a
	--		GROUP BY a.fips
	--			,a.apn
	--		) b
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		)

	--CREATE CLUSTERED INDEX ixa_Fips_Apn ON #Dup_ind (
	--	fips
	--	,apn
	--	)

	--UPDATE p
	--SET p.Dup_ind = d.Dup_ind
	----SELECT TOP 100 p.*
	----	,d.*
	--FROM PET.dbo.PET_APN p WITH (
	--		NOLOCK
	--		,INDEX (ixa_Fips_Apn)
	--		)
	--INNER JOIN #Dup_ind d WITH (
	--		NOLOCK
	--		,INDEX (ixa_Fips_Apn)
	--		) ON d.FIPS = p.fips
	--	AND d.apn = p.apn
	--WHERE d.Dup_ind <> p.Dup_ind

	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	--
	--  pet neo legals
	--
	-- get the after
	DROP TABLE

	IF EXISTS [pet].[Pet_tmp].[Pet_ref_ids_Legal_after]
		SELECT DISTINCT pl.fips
			,pl.ref_id
			,pl.NEO_TITLE_LEGAL
			,pl.neo_apn
		INTO [pet].[Pet_tmp].[Pet_ref_ids_legal_after]
		FROM [pet].[dbo].[pet_neo_legals] pl WITH (
				NOLOCK
				,INDEX (ix_fips_ref_id)
				)
		INNER JOIN [Pet].[Pet_tmp].[Assr] pt WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON pt.fips = pl.fips
			AND pt.ref_id = pl.ref_id

	CREATE CLUSTERED INDEX idx_fips_apn ON [pet].[Pet_tmp].[Pet_ref_ids_legal_after] (
		fips
		,NEO_TITLE_LEGAL
		)

	---- determine duplicates
	--DROP TABLE

	--IF EXISTS #Fips_NEO_TITLE_LEGAL
	--	SELECT DISTINCT a.fips
	--		,a.NEO_TITLE_LEGAL
	--	INTO #fips_NEO_TITLE_LEGAL
	--	FROM (
	--		SELECT fips
	--			,NEO_TITLE_LEGAL
	--		FROM pet.Pet_tmp.Pet_ref_ids_Legal_before
			
	--		UNION ALL
			
	--		SELECT fips
	--			,NEO_TITLE_LEGAL
	--		FROM pet.Pet_tmp.Pet_ref_ids_Legal_after
	--		) a

	--CREATE INDEX ixa_Fips_NEO_TITLE_LEGAL ON #fips_NEO_TITLE_LEGAL (
	--	Fips
	--	,NEO_TITLE_LEGAL
	--	)

	--DROP TABLE

	--IF EXISTS #Legal_dup_ind
	--	SELECT b.fips
	--		,NEO_TITLE_LEGAL
	--		,try_cast(CASE 
	--				WHEN cnt > 1
	--					THEN 1
	--				ELSE 0
	--				END AS BIT) AS legal_dup_ind
	--	INTO #Legal_dup_ind
	--	FROM (
	--		SELECT a.fips
	--			,a.NEO_TITLE_LEGAL
	--			,count(1) AS cnt
	--		FROM (
	--			SELECT DISTINCT p.Fips
	--				,p.ref_id
	--				,p.NEO_TITLE_LEGAL
	--			FROM PET.dbo.PET_NEO_LEGALs p WITH (
	--					NOLOCK
	--					,INDEX (a)
	--					)
	--			INNER JOIN #fips_NEO_TITLE_LEGAL a WITH (
	--					NOLOCK
	--					,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
	--					) ON a.fips = p.fips
	--				AND a.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL
	--			) a
	--		GROUP BY a.fips
	--			,a.NEO_TITLE_LEGAL
	--		) b
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		)


			

	--CREATE CLUSTERED INDEX ixa_Fips_NEO_TITLE_LEGAL ON #Legal_dup_ind (
	--	fips
	--	,NEO_TITLE_LEGAL
	--	)

	----
	---- Update pet_neo_legal 
	----
	--UPDATE p
	--SET p.legal_dup_ind = d.legal_dup_ind
	--FROM PET.dbo.PET_NEO_LEGALs p WITH (
	--		NOLOCK
	--		,INDEX (a)
	--		)
	--INNER JOIN #Legal_dup_ind d WITH (
	--		NOLOCK
	--		,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
	--		) ON d.FIPS = p.fips
	--	AND d.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL
	--WHERE d.legal_dup_ind <> p.legal_dup_ind

	----
	---- update pet.dbo.pet with Legal_Dup_Ind
	----
	--DROP TABLE
	--IF EXISTS #pet_legal_dup

	--select p.fips, p.ref_id, max(case when p.legal_dup_ind = 1 then 1 else 0 end ) as legal_dup_ind
	--into #pet_legal_dup
	--	FROM PET.dbo.PET_NEO_LEGALs p WITH (
	--		NOLOCK
	--		,INDEX (a)
	--		)
	--INNER JOIN #Legal_dup_ind d WITH (
	--		NOLOCK
	--		,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
	--		) ON d.FIPS = p.fips
	--		AND d.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL
 --  group by  p.fips, p.ref_id





	--CREATE INDEX idx_fips_ref_id ON #pet_legal_dup (
	--	Fips
	--	,ref_id
	--	)

	--UPDATE p
	--SET p.legal_dup_ind = a.legal_dup_ind
	--FROM pet.dbo.pet p
	--INNER JOIN #pet_legal_dup a WITH (
	--		NOLOCK
	--		,INDEX (idx_fips_ref_id)
	--		) ON a.fips = p.fips
	--	AND a.ref_id = p.ref_id

	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'Usp_Create_after_Pet_Values'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH



