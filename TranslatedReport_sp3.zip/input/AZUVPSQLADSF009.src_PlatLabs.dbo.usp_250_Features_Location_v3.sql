SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Location_v3]

AS
BEGIN


	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[LocationJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[LocationJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Location, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Location') AS j

			DROP TABLE IF EXISTS Table_S
			DROP TABLE IF EXISTS Table_T
			DROP TABLE IF EXISTS Table_U
			DROP TABLE IF EXISTS Table_V


			Select MLSID,MLS_LISTING_ID,[County] INTO [src_PlatLabs].[dbo].[Table_s]
					from [src_Platlabs].[features].[LocationJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Location]) WITH([County] varchar(1000)) as County_array
						WHERE [Location] like '%"County"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_s(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_s(MLSID)

			Select MLSID,MLS_LISTING_ID,[HOAAmenities] INTO [src_PlatLabs].[dbo].[Table_t]
					from [src_Platlabs].[features].[LocationJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(replace([Location],'HOA Amenities','HOAAmenities')) WITH([HOAAmenities] varchar(1000)) as HOAAmenities_array
						WHERE [Location] like '%"HOA Amenities"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_t(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_t(MLSID)

			Select MLSID,MLS_LISTING_ID,[OriginatingMLS] INTO [src_PlatLabs].[dbo].[Table_u]
					from [src_Platlabs].[features].[LocationJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(REPLACE([Location],'Originating MLS','OriginatingMLS')) WITH([OriginatingMLS] varchar(1000)) as OriginatingMLS_array
						WHERE [Location] like '%"Originating MLS"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_u(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_u(MLSID)

			Select MLSID,MLS_LISTING_ID,[RoadAccess] INTO [src_PlatLabs].[dbo].[Table_v]
					from [src_Platlabs].[features].[LocationJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(REPLACE([Location],'Road/Access','RoadAccess')) WITH([RoadAccess] varchar(1000)) as RoadAccess_array
						WHERE [Location] like '%"Road/Access"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_v(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_v(MLSID)


			EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END




