SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [src_PlatLabs].[dbo].[usp_800_Create_FULL_Listing_v4]
AS
BEGIN

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).
		
		IF(Select DATEPART(HOUR,GetDate())) = 19
		BEGIN
			WAITFOR DELAY '01:01:01';
		END
					
			BEGIN
				EXEC msdb.dbo.sp_start_job N'DirectDivListingUpdate';  
					WAITFOR DELAY '00:00:10'
				EXEC msdb.dbo.sp_start_job N'DirectDivAgentOfficeUpdate';  
					WAITFOR DELAY '00:00:10'
				EXEC msdb.dbo.sp_start_job N'DirectDivNewAgentLoad';  
					WAITFOR DELAY '00:00:10'
			END

				IF EXISTS(SELECT j.name AS job_name 
				FROM [msdb].[dbo].[sysjobactivity] ja 
				LEFT JOIN [msdb].[dbo].[sysjobhistory] jh ON ja.job_history_id = jh.instance_id
				JOIN [msdb].[dbo].[sysjobs] j ON ja.job_id = j.job_id
				WHERE ja.session_id = (SELECT TOP 1 session_id FROM [msdb].[dbo].[syssessions] ORDER BY session_id DESC)
				  AND start_execution_date is not null
				  AND stop_execution_date is null
				  AND j.name = 'DirectDivListingClosedUpdate')
				  
				  BEGIN

					WHILE(SELECT j.name AS job_name 
						FROM [msdb].[dbo].[sysjobactivity] ja 
						LEFT JOIN [msdb].[dbo].[sysjobhistory] jh ON ja.job_history_id = jh.instance_id
						JOIN [msdb].[dbo].[sysjobs] j ON ja.job_id = j.job_id
						WHERE ja.session_id = (SELECT TOP 1 session_id FROM [msdb].[dbo].[syssessions] ORDER BY session_id DESC)
						  AND start_execution_date is not null
						  AND stop_execution_date is null
						  AND j.name = 'DirectDivListingClosedUpdate') = 'DirectDivListingClosedUpdate'
						BEGIN
						  ---- SEND EMAIL
				  			DECLARE @To2 varchar(255) = 'mikes@platlabs.com;MauroTorres@firstam.com;SantiagoGarcia@firstam.com;adamf@platlabs.com', 
								@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
								@t_subject2 varchar(50) = 'DirectDivListingClosedUpdate',
								@t_body2 varchar(2000) = 'The DirectDivListingClosedUpdate Process is still running'

								SET NOCOUNT ON;
								DECLARE @t_getdate2 datetime = GETDATE()
								SET @t_body2 = @t_body2 + '**** ' + cast(@t_getdate2 as varchar(20)) + ' PT ****'

								EXEC msdb.dbo.sp_send_dbmail
									@recipients = @To2,
									@profile_name = @t_profile_name2,
									@subject = @t_subject2,
									@body = @t_body2
						  ---- WAIT 
							WAITFOR DELAY '00:10:00'
						END
					END

				EXEC msdb.dbo.sp_start_job N'DirectDivListingClosedUpdate';  


		TRUNCATE table [src_Platlabs].[listing].[listingFull_WORKING]
		DROP INDEX IF EXISTS [ix_MLSIDListingID] on [src_Platlabs].[listing].[listingFull_WORKING]

		DECLARE @MaxLoadDt datetime
		Select @MaxLoadDt = MAX(LoadDate) from [src_PlatLabs].[listing].[ListingFull] WITH(NOLOCK)

				--Purposefully capturing the start and end time of this module
				declare @note_start_time datetime = getdate()
				
		INSERT INTO [src_Platlabs].[listing].[listingFull_WORKING](school_district
		,elementary_school
		,junior_high_school
		,high_school
		,middle_school
		,videos_change_date
		,major_change_date
		,above_grade_finished_area
		,activation_date
		,active
		,additional_features
		,[address]
		,air_conditioning
		,allow_avm
		,allow_comments
		,annual_insurance
		,annual_maintenance
		,annual_management_fees
		,annual_tax
		,annual_utilities
		,appliances
		,approximate_age
		,area_name
		,area_name_minor
		,availability_date
		,basement_description
		,bathrooms
		,bathrooms_full
		,bathrooms_half
		,bathrooms_partial
		,bathrooms_quarter
		,bathrooms_three_quarter
		,bedrooms
		,below_grade_description
		,below_grade_finished_area
		,building_name
		,cancelled_date
		,ceiling_height
		,ceiling_height_str
		,city
		,close_date
		,commission_misc
		,community
		,condition
		,confidential_description
		,construction_materials
		,contingencies
		,contingent_date
		,contract_date
		,contract_status_change_date
		,country
		,country_code
		,county
		,created_date
		,cumulative_days_on_market
		,current_use
		,days_on_market
		,days_on_market_replication_date
		,den_description
		,[description]
		,design
		,dining_room_description
		,directions
		,disability_features
		,display_lat
		,display_lng
		,display_mls_number
		,documents_change_timestamp
		,door_features
		,down_payment_resource
		,driveway_description
		,exclusions
		,expiration_date
		,exterior_description
		,exterior_features
		,extras
		,family_room_description
		,fence_description
		,financial_information
		,fireplace_description
		,fireplaces
		,flooring_information
		,foreclosure_type
		,formatted_address
		,frontage_type
		,garage_description
		,garage_spaces
		,geocode_date
		,geocode_quality
		,green_features
		,has_basement
		,has_electricity
		,has_fireplace
		,has_garage
		,has_hoa
		,has_horse_property
		,has_mountain_view
		,has_open_house
		,has_pool
		,has_price_reduced
		,has_sewer
		,has_view
		,has_water
		,has_waterfront
		,has_waterview
		,heat_source
		,heat_type
		,hide_address
		,hoa_amenities
		,hoa_fee
		,hoa_fee_includes
		,hoa_frequency
		,hoa_name
		,hoa_phone
		,idx
		,improvements
		,interior_features
		,is_adult_community
		,is_boat_slip
		,is_business_with_real_estate
		,is_commercial
		,is_commercial_lease
		,is_condo
		,is_condo_townhouse
		,is_coop
		,is_cul_de_sac
		,is_duplex
		,is_farm_hobby
		,is_foreclosure
		,is_gated_community
		,is_golf_community
		,is_industrial
		,is_investment
		,is_loft
		,is_lot
		,is_mixed_use
		,is_mobile_home
		,is_model
		,is_multi_family
		,is_new_construction
		,is_on_golf_course
		,is_one_story
		,is_other
		,is_rental
		,is_residential_lease
		,is_shortsale
		,is_single_family
		,is_single_family_detached
		,is_three_plus_story
		,is_townhouse
		,is_two_story
		,kitchen
		,kitchen_description
		,kitchen_dimensions
		,kitchen_level
		,landscape
		,last_update_date
		,latitude
		,laundry_room_description
		,list_date
		,listing_agent_commission_rate
		,listing_agent_email
		,listing_agent_flat_fee
		,listing_agent_id
		,listing_agent_name
		,listing_agent_phone
		,listing_agent_uid
		,listing_agreement
		,listing_key
		,listing_office_id
		,listing_office_name
		,listing_office_phone
		,listing_office_uid
		,living_room_description
		,[location]
		,longitude
		,lot_description
		,lot_dimension
		,lot_size
		,lot_size_area
		,lot_size_display
		,lot_size_source
		,lot_size_square_feet
		,lot_size_units
		,market_name
		,master_bath_description
		,master_bedroom_description
		,master_bedroom_level
		,mls_create_date
		,mls_id
		,mls_lat
		,mls_list_date
		,mls_listing_id
		,mls_lng
		,mls_property_sub_type
		,mls_property_type
		,mls_status
		,mls_update_date
		,modified_date
		,monthly_hoa_fee
		,neighborhood
		,normalized_hoa_frequency
		,occupant_type
		,off_market_date
		,on_market_date
		,open_house
		,original_listing_price
		,originating_system_name
		,outbuildings_description
		,[ownership]
		,parcel_number
		,parcel_number_public_record
		,parking_description
		,parking_spaces
		,patio_and_porch_features
		,pending_date
		,pets_allowed
		,photo_count
		,photo_date
		,pool_description
		,price
		,price_change_date
		,price_change_timestamp
		,price_display
		,price_per_square_foot
		,property_type
		,property_view_description
		,restrictions
		,road_frontage_description
		,roofing
		,rooms
		,rooms_description
		,rupid
		,sale_type
		,security_features
		,seller_concessions
		,selling_agent_commission_rate
		,selling_agent_flat_fee
		,sewer
		,sold_date
		,sold_price
		,source_create_date
		,source_system_key
		,source_system_name
		,square_feet
		,square_feet_of_land
		,square_feet_range
		,square_foot_source
		,[state]
		,[status]
		,status_change_date
		,stories_description
		,stories_total
		,street_direction
		,street_name
		,street_number
		,street_pre_direction
		,street_type
		,structure_type
		,style
		,subdivision
		,substructure
		,tax_legal_description
		,tax_year
		,tenant_pays
		,topography
		,total_units
		,township
		,[uid]
		,unit_number
		,utilities
		,utilities_available
		,virtual_tour
		,virtual_tour_branded
		,walk_score
		,water
		,water_frontage
		,waterfront_description
		,windows_description
		,withdrawn_date
		,year_built
		,year_built_source
		,zip
		,zoning
		,LoadDate
		,PropertyID
		,REF_ID
		,FIPS
		,buyer_financing
		,energy_source
		,finished_area
		,furnished
		,has_irrigation_water_rights
		,is_land_lease
		,originating_system_id
		,possession
		,seller_concessions_comments
		,special_listing_conditions
		,tenant_total_expenses
		,unfinished_area
		,water_body_name
		,zoning_description
		,NormalizedAddress_CompleteAddress
		,NormalizedAddress_StreetNumber
		,NormalizedAddress_StreetPredirection
		,NormalizedAddress_StreetName
		,NormalizedAddress_StreetSuffix
		,NormalizedAddress_StreetPostdirection
		,NormalizedAddress_City
		,NormalizedAddress_State
		,NormalizedAddress_Zip
		,GeoData_City_Name
		,GeoData_Zip_Name
		,GeoData_Neighborhood_Name
		,GeoData_School_District_Name
		,co_listing_agent_Name
		,co_listing_agent_email
		,co_listing_agent_phone
		,co_listing_agent_FirstName
		,co_listing_agent_LastName
		,co_listing_agent_License_Number
		,co_Selling_agent_Name
		,co_Selling_agent_email
		,co_Selling_agent_phone
		,co_Selling_agent_FirstName
		,co_Selling_agent_LastName
		,co_Selling_agent_License_Number
		,Selling_Agent_Name
		,Selling_Agent_email
		,Selling_Agent_phone
		,Selling_Agent_FirstName
		,Selling_Agent_LastName
		,Selling_Agent_license_number
		,Sell_Agent_Office_ID
		,Sell_Agent_Office_Name
		,Sell_Agent_Office_Phone
		,List_Agent_Name
		,List_Agent_email
		,List_Agent_phone
		,List_Agent_FirstName
		,List_Agent_LastName
		,List_Agent_License_Number
		,List_Agent_Office_ID
		,List_Agent_Office_Name
		,List_Agent_Office_Phone
		,[attribution_contact]
		,[InitialLoadDate]
		,[Platlabs_listdate]
		,[Selling_Agent_ID]
		,[source_mls_url]
		)
		Select Distinct zz.[school_district]
		  ,zz.[elementary_school]
		  ,zz.[junior_high_school]
		  ,zz.[high_school]
		  ,zz.[middle_school]
		  ,zz.[videos_change_date]
		  ,zz.[major_change_date]
		  ,zz.[above_grade_finished_area]
		  ,zz.[activation_date]
		  ,zz.[active]
		  ,zz.[additional_features]
		  ,zz.[address]
		  ,zz.[air_conditioning]
		  ,zz.[allow_avm]
		  ,zz.[allow_comments]
		  ,zz.[annual_insurance]
		  ,zz.[annual_maintenance]
		  ,zz.[annual_management_fees]
		  ,zz.[annual_tax]
		  ,zz.[annual_utilities]
		  ,zz.[appliances]
		  ,zz.[approximate_age]
		  ,zz.[area_name]
		  ,zz.[area_name_minor]
		  ,zz.[availability_date]
		  ,zz.[basement_description]
		  ,zz.[bathrooms]
		  ,zz.[bathrooms_full]
		  ,zz.[bathrooms_half]
		  ,zz.[bathrooms_partial]
		  ,zz.[bathrooms_quarter]
		  ,zz.[bathrooms_three_quarter]
		  ,zz.[bedrooms]
		  ,zz.[below_grade_description]
		  ,zz.[below_grade_finished_area]
		  ,zz.[building_name]
		  ,zz.[cancelled_date]
		  ,zz.[ceiling_height]
		  ,zz.[ceiling_height_str]
		  ,zz.[city]
		  ,zz.[close_date]
		  ,zz.[commission_misc]
		  ,zz.[community]
		  ,zz.[condition]
		  ,zz.[confidential_description]
		  ,zz.[construction_materials]
		  ,zz.[contingencies]
		  ,zz.[contingent_date]
		  ,zz.[contract_date]
		  ,zz.[contract_status_change_date]
		  ,zz.[country]
		  ,zz.[country_code]
		  ,zz.[county]
		  ,zz.[created_date]
		  ,zz.[cumulative_days_on_market]
		  ,zz.[current_use]
		  ,zz.[days_on_market]
		  ,zz.[days_on_market_replication_date]
		  ,zz.[den_description]
		  ,zz.[description]
		  ,zz.[design]
		  ,zz.[dining_room_description]
		  ,zz.[directions]
		  ,zz.[disability_features]
		  ,zz.[display_lat]
		  ,zz.[display_lng]
		  ,zz.[display_mls_number]
		  ,zz.[documents_change_timestamp]
		  ,zz.[door_features]
		  ,zz.[down_payment_resource]
		  ,zz.[driveway_description]
		  ,zz.[exclusions]
		  ,zz.[expiration_date]
		  ,zz.[exterior_description]
		  ,zz.[exterior_features]
		  ,zz.[extras]
		  ,zz.[family_room_description]
		  ,zz.[fence_description]
		  ,zz.[financial_information]
		  ,zz.[fireplace_description]
		  ,zz.[fireplaces]
		  ,zz.[flooring_information]
		  ,zz.[foreclosure_type]
		  ,zz.[formatted_address]
		  ,zz.[frontage_type]
		  ,zz.[garage_description]
		  ,zz.[garage_spaces]
		  ,zz.[geocode_date]
		  ,zz.[geocode_quality]
		  ,zz.[green_features]
		  ,zz.[has_basement]
		  ,zz.[has_electricity]
		  ,zz.[has_fireplace]
		  ,zz.[has_garage]
		  ,zz.[has_hoa]
		  ,zz.[has_horse_property]
		  ,zz.[has_mountain_view]
		  ,zz.[has_open_house]
		  ,zz.[has_pool]
		  ,zz.[has_price_reduced]
		  ,zz.[has_sewer]
		  ,zz.[has_view]
		  ,zz.[has_water]
		  ,zz.[has_waterfront]
		  ,zz.[has_waterview]
		  ,zz.[heat_source]
		  ,zz.[heat_type]
		  ,zz.[hide_address]
		  ,zz.[hoa_amenities]
		  ,zz.[hoa_fee]
		  ,zz.[hoa_fee_includes]
		  ,zz.[hoa_frequency]
		  ,zz.[hoa_name]
		  ,zz.[hoa_phone]
		  ,zz.[idx]
		  ,zz.[improvements]
		  ,zz.[interior_features]
		  ,zz.[is_adult_community]
		  ,zz.[is_boat_slip]
		  ,zz.[is_business_with_real_estate]
		  ,zz.[is_commercial]
		  ,zz.[is_commercial_lease]
		  ,zz.[is_condo]
		  ,zz.[is_condo_townhouse]
		  ,zz.[is_coop]
		  ,zz.[is_cul_de_sac]
		  ,zz.[is_duplex]
		  ,zz.[is_farm_hobby]
		  ,zz.[is_foreclosure]
		  ,zz.[is_gated_community]
		  ,zz.[is_golf_community]
		  ,zz.[is_industrial]
		  ,zz.[is_investment]
		  ,zz.[is_loft]
		  ,zz.[is_lot]
		  ,zz.[is_mixed_use]
		  ,zz.[is_mobile_home]
		  ,zz.[is_model]
		  ,zz.[is_multi_family]
		  ,zz.[is_new_construction]
		  ,zz.[is_on_golf_course]
		  ,zz.[is_one_story]
		  ,zz.[is_other]
		  ,zz.[is_rental]
		  ,zz.[is_residential_lease]
		  ,zz.[is_shortsale]
		  ,zz.[is_single_family]
		  ,zz.[is_single_family_detached]
		  ,zz.[is_three_plus_story]
		  ,zz.[is_townhouse]
		  ,zz.[is_two_story]
		  ,zz.[kitchen]
		  ,zz.[kitchen_description]
		  ,zz.[kitchen_dimensions]
		  ,zz.[kitchen_level]
		  ,zz.[landscape]
		  ,zz.[last_update_date]
		  ,zz.[latitude]
		  ,zz.[laundry_room_description]
		  ,zz.[list_date]
		  ,zz.[listing_agent_commission_rate]
		  ,zz.[listing_agent_email]
		  ,zz.[listing_agent_flat_fee]
		  ,zz.[listing_agent_id]
		  ,zz.[listing_agent_name]
		  ,zz.[listing_agent_phone]
		  ,zz.[listing_agent_uid]
		  ,zz.[listing_agreement]
		  ,zz.[listing_key]
		  ,zz.[listing_office_id]
		  ,zz.[listing_office_name]
		  ,zz.[listing_office_phone]
		  ,zz.[listing_office_uid]
		  ,zz.[living_room_description]
		  ,zz.[location]
		  ,zz.[longitude]
		  ,zz.[lot_description]
		  ,zz.[lot_dimension]
		  ,zz.[lot_size]
		  ,zz.[lot_size_area]
		  ,zz.[lot_size_display]
		  ,zz.[lot_size_source]
		  ,zz.[lot_size_square_feet]
		  ,zz.[lot_size_units]
		  ,zz.[market_name]
		  ,zz.[master_bath_description]
		  ,zz.[master_bedroom_description]
		  ,zz.[master_bedroom_level]
		  ,zz.[mls_create_date]
		  ,zz.[mls_id]
		  ,zz.[mls_lat]
		  ,zz.[mls_list_date]
		  ,zz.[mls_listing_id]
		  ,zz.[mls_lng]
		  ,zz.[mls_property_sub_type]
		  ,zz.[mls_property_type]
		  ,zz.[mls_status]
		  ,zz.[mls_update_date]
		  ,zz.[modified_date]
		  ,zz.[monthly_hoa_fee]
		  ,zz.[neighborhood]
		  ,zz.[normalized_hoa_frequency]
		  ,zz.[occupant_type]
		  ,zz.[off_market_date]
		  ,zz.[on_market_date]
		  ,zz.[open_house]
		  ,zz.[original_listing_price]
		  ,zz.[originating_system_name]
		  ,zz.[outbuildings_description]
		  ,zz.[ownership]
		  ,zz.[parcel_number]
		  ,zz.[parcel_number_public_record]
		  ,zz.[parking_description]
		  ,zz.[parking_spaces]
		  ,zz.[patio_and_porch_features]
		  ,zz.[pending_date]
		  ,zz.[pets_allowed]
		  ,zz.[photo_count]
		  ,zz.[photo_date]
		  ,zz.[pool_description]
		  ,zz.[price]
		  ,zz.[price_change_date]
		  ,zz.[price_change_timestamp]
		  ,zz.[price_display]
		  ,zz.[price_per_square_foot]
		  ,zz.[property_type]
		  ,zz.[property_view_description]
		  ,zz.[restrictions]
		  ,zz.[road_frontage_description]
		  ,zz.[roofing]
		  ,zz.[rooms]
		  ,zz.[rooms_description]
		  ,zz.[rupid]
		  ,zz.[sale_type]
		  ,zz.[security_features]
		  ,zz.[seller_concessions]
		  ,zz.[selling_agent_commission_rate]
		  ,zz.[selling_agent_flat_fee]
		  ,zz.[sewer]
		  ,zz.[sold_date]
		  ,zz.[sold_price]
		  ,zz.[source_create_date]
		  ,zz.[source_system_key]
		  ,zz.[source_system_name]
		  ,zz.[square_feet]
		  ,zz.[square_feet_of_land]
		  ,zz.[square_feet_range]
		  ,zz.[square_foot_source]
		  ,zz.[state]
		  ,zz.[status]
		  ,zz.[status_change_date]
		  ,zz.[stories_description]
		  ,zz.[stories_total]
		  ,zz.[street_direction]
		  ,zz.[street_name]
		  ,zz.[street_number]
		  ,zz.[street_pre_direction]
		  ,zz.[street_type]
		  ,zz.[structure_type]
		  ,zz.[style]
		  ,zz.[subdivision]
		  ,zz.[substructure]
		  ,zz.[tax_legal_description]
		  ,zz.[tax_year]
		  ,zz.[tenant_pays]
		  ,zz.[topography]
		  ,zz.[total_units]
		  ,zz.[township]
		  ,zz.[uid]
		  ,zz.[unit_number]
		  ,zz.[utilities]
		  ,zz.[utilities_available]
		  ,zz.[virtual_tour]
		  ,zz.[virtual_tour_branded]
		  ,zz.[walk_score]
		  ,zz.[water]
		  ,zz.[water_frontage]
		  ,zz.[waterfront_description]
		  ,zz.[windows_description]
		  ,zz.[withdrawn_date]
		  ,zz.[year_built]
		  ,zz.[year_built_source]
		  ,zz.[zip]
		  ,zz.[zoning]
		  ,zz.[LoadDate]
		  ,zz.[PropertyID]
		  ,zz.[REF_ID]
		  ,zz.[FIPS]
		  ,zz.[buyer_financing]
		  ,zz.[energy_source]
		  ,zz.[finished_area]
		  ,zz.[furnished]
		  ,zz.[has_irrigation_water_rights]
		  ,zz.[is_land_lease]
		  ,zz.[originating_system_id]
		  ,zz.[possession]
		  ,zz.[seller_concessions_comments]
		  ,zz.[special_listing_conditions]
		  ,zz.[tenant_total_expenses]
		  ,zz.[unfinished_area]
		  ,zz.[water_body_name]
		  ,zz.[zoning_description]
		,NA.NormalizedAddress_CompleteAddress
		,NA.NormalizedAddress_StreetNumber
		,NA.NormalizedAddress_StreetPredirection
		,NA.NormalizedAddress_StreetName
		,NA.NormalizedAddress_StreetSuffix
		,NA.NormalizedAddress_StreetPostdirection
		,NA.NormalizedAddress_City
		,NA.NormalizedAddress_State
		,NA.NormalizedAddress_Zip
		,GD.[city_name] [GeoData_City_Name]
		,GD.[zip_name] [GeoData_Zip_Name]
		,GD.[neighborhood_name] [GeoData_Neighborhood_Name]
		,GD.[school_district_name] [GeoData_School_District_Name]
		,ClA.[CoAgentName] [co_listing_agent_Name]
		,ClA.AgentEmail [co_listing_agent_email]
		,ClA.[AgentPhone] [co_listing_agent_phone]
		,ClA.[FirstName] [co_listing_agent_FirstName]
		,ClA.[LastName] [co_listing_agent_LastName]
		,ClA.[LicenseNumber] [co_listing_agent_License_Number]
		,CsA.[SellingAgentFullName] [co_Selling_agent_Name]
		,CsA.[Email] [co_Selling_agent_email]
		,CsA.[CoSellAgentPhone] [co_Selling_agent_phone]
		,CsA.[FirstName] [co_Selling_agent_FirstName]
		,CsA.[LastName] [co_Selling_agent_LastName]
		,CsA.[LicenseNumber] [co_Selling_agent_License_Number]
		,SA.[agent_ListAgentFullName] [Selling_Agent_Name]
		,SA.[agent_Email] [Selling_Agent_email]
		,SA.[agent_Phone] [Selling_Agent_phone]
		,SA.[agent_FirstName] [Selling_Agent_FirstName]
		,SA.[agent_LastName] [Selling_Agent_LastName]
		,SA.[agent_LicenseNumber] [Selling_Agent_license_number]
		,SA.[office_id] [Sell_Agent_Office_ID]
		,SA.[office_name] [Sell_Agent_Office_Name]
		,SA.[office_phone] [Sell_Agent_Office_Phone]
		,LA.[agent_ListAgentFullName] [List_Agent_Name]
		,LA.[agent_Email] [List_Agent_email]
		,LA.[agent_Phone] [List_Agent_phone]
		,LA.[agent_FirstName] [List_Agent_FirstName]
		,LA.[agent_LastName] [List_Agent_LastName]
		,LA.[agent_LicenseNumber] [List_Agent_License_Number]
		,LA.[office_id] [List_Agent_Office_ID]
		,LA.[office_name] [List_Agent_Office_Name]
		,LA.[office_phone] [List_Agent_Office_Phone]
		,zz.[attribution_contact]
		,zz.[InitialLoadDate]
		,[Platlabs_listdate]
		,SA.[agent_id]
		,[source_mls_url]		
		FROM [src_Platlabs].[listing].[ListingsRaw_Batch]  zz with(NOLOCK)
		LEFT OUTER JOIN [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData] NA with(NOLOCK) on zz.mls_id = NA.mls_id and zz.mls_listing_id = NA.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[geodata].[RawGeoData] GD with(NOLOCK) on zz.mls_id = GD.mls_id and zz.mls_listing_id = GD.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[agent].[CoSellingAgents] CsA with(NOLOCK) on zz.mls_id = CsA.mls_id and zz.mls_listing_id = CsA.[mls_listing_id]
		LEFT OUTER JOIN [src_PlatLabs].[agent].[CoAgent_Batch] ClA with(NOLOCK) on zz.mls_id = ClA.mls_id and zz.mls_listing_id = ClA.[mls_listing_id]
		LEFT OUTER JOIN [src_PlatLabs].[agent].[SellingAgents] SA with(NOLOCK) ON zz.mls_id = SA.mls_id and zz.mls_listing_id = SA.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[agent].[ListAgents] LA with(NOLOCK) ON zz.mls_id = LA.mls_id and zz.mls_listing_id = LA.mls_listing_id


		CREATE NONCLUSTERED INDEX [ix_MLSIDListingID] ON [listing].[listingFull_WORKING]
		([mls_id] ASC,[mls_listing_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

		---- Load Feature Data
		BEGIN
			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureExteriorGeneral = a.General
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_a] a ON zz.mls_id = a.MLSID
			and zz.mls_listing_id = a.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureExteriorStyle = b.[Style]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_b] b ON zz.mls_id = b.MLSID
			and zz.mls_listing_id = b.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureExteriorPool = c.[Pool]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_c] c ON zz.mls_id = c.MLSID
			and zz.mls_listing_id = c.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureExteriorParking = d.[Parking]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_d] d ON zz.mls_id = d.MLSID
			and zz.mls_listing_id = d.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorAppliances = e.[AC]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_e] e ON zz.mls_id = e.MLSID
			and zz.mls_listing_id = e.MLS_LISTING_ID


			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorAppliances = f.[Appliances]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_f] f ON zz.mls_id = f.MLSID
			and zz.mls_listing_id = f.MLS_LISTING_ID


			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorBasement = g.[Basement]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_g] g ON zz.mls_id = g.MLSID
			and zz.mls_listing_id = g.MLS_LISTING_ID


			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorDisability = h.[DisabilityFeature]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_h] h ON zz.mls_id = h.MLSID
			and zz.mls_listing_id = h.MLS_LISTING_ID


			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorGreen = i.[EcoGreenFeature]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_i] i ON zz.mls_id = i.MLSID
			and zz.mls_listing_id = i.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorFireplace = j.[Fireplace]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_j] j ON zz.mls_id = j.MLSID
			and zz.mls_listing_id = j.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorFlooring = k.[Flooring]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_k] k ON zz.mls_id = k.MLSID
			and zz.mls_listing_id = k.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorGeneral = l.[General]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_l] l ON zz.mls_id = l.MLSID
			and zz.mls_listing_id = l.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorHeating = m.[Heating]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_m] m ON zz.mls_id = m.MLSID
			and zz.mls_listing_id = m.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorLaundry = n.[Laundry]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_n] n ON zz.mls_id = n.MLSID
			and zz.mls_listing_id = n.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FeatureInteriorRooms = o.[Rooms]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_o] o ON zz.mls_id = o.MLSID
			and zz.mls_listing_id = o.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.ConstructionGeneral = p.[General]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_p] p ON zz.mls_id = p.MLSID
			and zz.mls_listing_id = p.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.constructinoRoofing = q.[Roofing]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_q] q ON zz.mls_id = q.MLSID
			and zz.mls_listing_id = q.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.ConstructionWindows = r.[windows]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_r] r ON zz.mls_id = r.MLSID
			and zz.mls_listing_id = r.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LocationCounty = s.[County]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_s] s ON zz.mls_id = s.MLSID
			and zz.mls_listing_id = s.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LocationHOAAmenities = t.HOAAmenities
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_t] t ON zz.mls_id = t.MLSID
			and zz.mls_listing_id = t.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LocationOriginatingMLS = u.[OriginatingMLS]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_u] u ON zz.mls_id = u.MLSID
			and zz.mls_listing_id = u.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LocationRoadAccess = v.[RoadAccess]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_v] v ON zz.mls_id = v.MLSID
			and zz.mls_listing_id = v.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LotCurrentUse = w.CurrentUse
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_w] w ON zz.mls_id = w.MLSID
			and zz.mls_listing_id = w.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LotFencing = x.Fencing
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_x] x ON zz.mls_id = x.MLSID
			and zz.mls_listing_id = x.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LotView = y.[view]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_y] y ON zz.mls_id = y.MLSID
			and zz.mls_listing_id = y.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.LotZoning = z.zoning
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_z] z ON zz.mls_id = z.MLSID
			and zz.mls_listing_id = z.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.UtilitesSewer = aa.Sewer
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_aa] aa ON zz.mls_id = aa.MLSID
			and zz.mls_listing_id = aa.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.UtilitiesUtilities = ab.Utilities
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_ab] ab ON zz.mls_id = ab.MLSID
			and zz.mls_listing_id = ab.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.UtilitiesWater = ac.Water
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_ac] ac ON zz.mls_id = ac.MLSID
			and zz.mls_listing_id = ac.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FinancialBuyersAgentCompensation = ad.BuyersAgentCompensation
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_ad] ad ON zz.mls_id = ad.MLSID
			and zz.mls_listing_id = ad.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FinancialNACompensation = ae.NACompensation
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_ae] ae ON zz.mls_id = ae.MLSID
			and zz.mls_listing_id = ae.MLS_LISTING_ID

			UPDATE [src_PlatLabs].[dbo].[zz]
			SET zz.FinancialSource = af.[Source]
			FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
			JOIN [src_PlatLabs].[dbo].[Table_af] af ON zz.mls_id = af.MLSID
			and zz.mls_listing_id = af.MLS_LISTING_ID

					--Purposefully capturing the start and end time of this module
					--declare @note_end_time datetime = getdate()
					--declare @listingCount int
					--set @listingCount = (select count(*) from [src_PlatLabs].listing.listingFull_WORKING with(nolock))
					--insert into [xVJ].dbo.[temp_track_proc] values ('800_insert_mod', @note_start_time, @note_end_time, getdate(), @listingCount)

			update [src_PlatLabs].[listing].[listingFull_WORKING]
			SET has_Pool = 'true'
			where has_pool is null and pool_description is not null and pool_description not like 'None'

			update [src_PlatLabs].[listing].[listingFull_WORKING]
			SET has_basement = 'true'
			where has_basement is null and basement_description is not null and basement_description not like 'None'

			update [src_PlatLabs].[listing].[listingFull_WORKING]
			SET has_fireplace = 'true'
			where has_fireplace is null and fireplace_description is not null and fireplace_description not like 'None'

			update [src_PlatLabs].[listing].[listingFull_WORKING]
			SET has_garage = 'true'
			where has_garage is null and (parking_description like 'Garage %' or parking_description like '%, Garage%')
		END

		EXEC [src_PlatLabs].[dbo].[usp_001_Clean_Extra_Ascii_from_table_ListingFull]

		update [src_PlatLabs].[dbo].[a]
		SET a.[status] = b.[Status]
		,a.[modified_date] = CASE WHEN a.[modified_date] < CAST(GETDATE() as date) THEN GETDATE() ELSE a.[modified_date] END
		from [src_PlatLabs].[listing].[listingFull_WORKING] a with(NOLOCK) JOIN [Global].[dbo].[lkup_StdStatus] b with(NOLOCK)
		on a.MLS_Status = b.MLS_Status
		WHERE a.[Status] != b.[Status]

		  update [src_platlabs].[listing].[listingFull_WORKING] 
		  set has_price_reduced = 'true' 
		  where [price] < [original_listing_price]
		  and has_price_reduced is NULL
		  and status in('Active','Pending','Contengent','Backup')

		  update [src_platlabs].[listing].[listingFull_WORKING] 
		  set has_hoa = 'true' 
		  where status in('Active','Pending','Contengent','Backup')
		  and has_hoa is NULL
		  and (hoa_amenities is not null
			or isNULL(hoa_fee,0) > 0
				or hoa_frequency is not null)  
		
		DELETE FROM [src_PlatLabs].[dbo].[a]
		FROM [src_PlatLabs].[listing].[listingFull] a JOIN [src_PlatLabs].[listing].[listingFull_WORKING] b
		on a.mls_id = b.mls_id
		and a.mls_listing_id = b.mls_listing_id

	INSERT INTO [src_PlatLabs].[listing].[listingFull] ([school_district]
      ,[elementary_school]
      ,[junior_high_school]
      ,[high_school]
      ,[middle_school]
      ,[videos_change_date]
      ,[major_change_date]
      ,[above_grade_finished_area]
      ,[activation_date]
      ,[active]
      ,[additional_features]
      ,[address]
      ,[air_conditioning]
      ,[allow_avm]
      ,[allow_comments]
      ,[annual_insurance]
      ,[annual_maintenance]
      ,[annual_management_fees]
      ,[annual_tax]
      ,[annual_utilities]
      ,[appliances]
      ,[approximate_age]
      ,[area_name]
      ,[area_name_minor]
      ,[availability_date]
      ,[basement_description]
      ,[bathrooms]
      ,[bathrooms_full]
      ,[bathrooms_half]
      ,[bathrooms_partial]
      ,[bathrooms_quarter]
      ,[bathrooms_three_quarter]
      ,[bedrooms]
      ,[below_grade_description]
      ,[below_grade_finished_area]
      ,[building_name]
      ,[cancelled_date]
      ,[ceiling_height]
      ,[ceiling_height_str]
      ,[city]
      ,[close_date]
      ,[commission_misc]
      ,[community]
      ,[condition]
      ,[confidential_description]
      ,[construction_materials]
      ,[contingencies]
      ,[contingent_date]
      ,[contract_date]
      ,[contract_status_change_date]
      ,[country]
      ,[country_code]
      ,[county]
      ,[created_date]
      ,[cumulative_days_on_market]
      ,[current_use]
      ,[days_on_market]
      ,[days_on_market_replication_date]
      ,[den_description]
      ,[description]
      ,[design]
      ,[dining_room_description]
      ,[directions]
      ,[disability_features]
      ,[display_lat]
      ,[display_lng]
      ,[display_mls_number]
      ,[documents_change_timestamp]
      ,[door_features]
      ,[down_payment_resource]
      ,[driveway_description]
      ,[exclusions]
      ,[expiration_date]
      ,[exterior_description]
      ,[exterior_features]
      ,[extras]
      ,[family_room_description]
      ,[fence_description]
      ,[financial_information]
      ,[fireplace_description]
      ,[fireplaces]
      ,[flooring_information]
      ,[foreclosure_type]
      ,[formatted_address]
      ,[frontage_type]
      ,[garage_description]
      ,[garage_spaces]
      ,[geocode_date]
      ,[geocode_quality]
      ,[green_features]
      ,[has_basement]
      ,[has_electricity]
      ,[has_fireplace]
      ,[has_garage]
      ,[has_hoa]
      ,[has_horse_property]
      ,[has_mountain_view]
      ,[has_open_house]
      ,[has_pool]
      ,[has_price_reduced]
      ,[has_sewer]
      ,[has_view]
      ,[has_water]
      ,[has_waterfront]
      ,[has_waterview]
      ,[heat_source]
      ,[heat_type]
      ,[hide_address]
      ,[hoa_amenities]
      ,[hoa_fee]
      ,[hoa_fee_includes]
      ,[hoa_frequency]
      ,[hoa_name]
      ,[hoa_phone]
      ,[idx]
      ,[improvements]
      ,[interior_features]
      ,[is_adult_community]
      ,[is_boat_slip]
      ,[is_business_with_real_estate]
      ,[is_commercial]
      ,[is_commercial_lease]
      ,[is_condo]
      ,[is_condo_townhouse]
      ,[is_coop]
      ,[is_cul_de_sac]
      ,[is_duplex]
      ,[is_farm_hobby]
      ,[is_foreclosure]
      ,[is_gated_community]
      ,[is_golf_community]
      ,[is_industrial]
      ,[is_investment]
      ,[is_loft]
      ,[is_lot]
      ,[is_mixed_use]
      ,[is_mobile_home]
      ,[is_model]
      ,[is_multi_family]
      ,[is_new_construction]
      ,[is_on_golf_course]
      ,[is_one_story]
      ,[is_other]
      ,[is_rental]
      ,[is_residential_lease]
      ,[is_shortsale]
      ,[is_single_family]
      ,[is_single_family_detached]
      ,[is_three_plus_story]
      ,[is_townhouse]
      ,[is_two_story]
      ,[kitchen]
      ,[kitchen_description]
      ,[kitchen_dimensions]
      ,[kitchen_level]
      ,[landscape]
      ,[last_update_date]
      ,[latitude]
      ,[laundry_room_description]
      ,[list_date]
      ,[listing_agent_commission_rate]
      ,[listing_agent_email]
      ,[listing_agent_flat_fee]
      ,[listing_agent_id]
      ,[listing_agent_name]
      ,[listing_agent_phone]
      ,[listing_agent_uid]
      ,[listing_agreement]
      ,[listing_key]
      ,[listing_office_id]
      ,[listing_office_name]
      ,[listing_office_phone]
      ,[listing_office_uid]
      ,[living_room_description]
      ,[location]
      ,[longitude]
      ,[lot_description]
      ,[lot_dimension]
      ,[lot_size]
      ,[lot_size_area]
      ,[lot_size_display]
      ,[lot_size_source]
      ,[lot_size_square_feet]
      ,[lot_size_units]
      ,[market_name]
      ,[master_bath_description]
      ,[master_bedroom_description]
      ,[master_bedroom_level]
      ,[mls_create_date]
      ,[mls_id]
      ,[mls_lat]
      ,[mls_list_date]
      ,[mls_listing_id]
      ,[mls_lng]
      ,[mls_property_sub_type]
      ,[mls_property_type]
      ,[mls_status]
      ,[mls_update_date]
      ,[modified_date]
      ,[monthly_hoa_fee]
      ,[neighborhood]
      ,[normalized_hoa_frequency]
      ,[occupant_type]
      ,[off_market_date]
      ,[on_market_date]
      ,[open_house]
      ,[original_listing_price]
      ,[originating_system_name]
      ,[outbuildings_description]
      ,[ownership]
      ,[parcel_number]
      ,[parcel_number_public_record]
      ,[parking_description]
      ,[parking_spaces]
      ,[patio_and_porch_features]
      ,[pending_date]
      ,[pets_allowed]
      ,[photo_count]
      ,[photo_date]
      ,[pool_description]
      ,[price]
      ,[price_change_date]
      ,[price_change_timestamp]
      ,[price_display]
      ,[price_per_square_foot]
      ,[property_type]
      ,[property_view_description]
      ,[restrictions]
      ,[road_frontage_description]
      ,[roofing]
      ,[rooms]
      ,[rooms_description]
      ,[rupid]
      ,[sale_type]
      ,[security_features]
      ,[seller_concessions]
      ,[selling_agent_commission_rate]
      ,[selling_agent_flat_fee]
      ,[sewer]
      ,[sold_date]
      ,[sold_price]
      ,[source_create_date]
      ,[source_system_key]
      ,[source_system_name]
      ,[square_feet]
      ,[square_feet_of_land]
      ,[square_feet_range]
      ,[square_foot_source]
      ,[state]
      ,[status]
      ,[status_change_date]
      ,[stories_description]
      ,[stories_total]
      ,[street_direction]
      ,[street_name]
      ,[street_number]
      ,[street_pre_direction]
      ,[street_type]
      ,[structure_type]
      ,[style]
      ,[subdivision]
      ,[substructure]
      ,[tax_legal_description]
      ,[tax_year]
      ,[tenant_pays]
      ,[topography]
      ,[total_units]
      ,[township]
      ,[uid]
      ,[unit_number]
      ,[utilities]
      ,[utilities_available]
      ,[virtual_tour]
      ,[virtual_tour_branded]
      ,[walk_score]
      ,[water]
      ,[water_frontage]
      ,[waterfront_description]
      ,[windows_description]
      ,[withdrawn_date]
      ,[year_built]
      ,[year_built_source]
      ,[zip]
      ,[zoning]
      ,[LoadDate]
      ,[PropertyID]
      ,[REF_ID]
      ,[FIPS]
      ,[buyer_financing]
      ,[energy_source]
      ,[finished_area]
      ,[furnished]
      ,[has_irrigation_water_rights]
      ,[is_land_lease]
      ,[originating_system_id]
      ,[possession]
      ,[seller_concessions_comments]
      ,[special_listing_conditions]
      ,[tenant_total_expenses]
      ,[unfinished_area]
      ,[water_body_name]
      ,[zoning_description]
      ,[FeatureExteriorGeneral]
      ,[FeatureExteriorStyle]
      ,[FeatureExteriorPool]
      ,[FeatureExteriorParking]
      ,[FeatureInteriorAC]
      ,[FeatureInteriorAppliances]
      ,[FeatureInteriorBasement]
      ,[FeatureInteriorDisability]
      ,[FeatureInteriorGreen]
      ,[FeatureInteriorFireplace]
      ,[FeatureInteriorFlooring]
      ,[FeatureInteriorGeneral]
      ,[FeatureInteriorHeating]
      ,[FeatureInteriorLaundry]
      ,[FeatureInteriorRooms]
      ,[ConstructionGeneral]
      ,[constructinoRoofing]
      ,[ConstructionWindows]
      ,[LocationCounty]
      ,[LocationHOAAmenities]
      ,[LocationOriginatingMLS]
      ,[LocationRoadAccess]
      ,[LotCurrentUse]
      ,[LotFencing]
      ,[LotView]
      ,[LotZoning]
      ,[UtilitesSewer]
      ,[UtilitiesUtilities]
      ,[UtilitiesWater]
      ,[FinancialBuyersAgentCompensation]
      ,[FinancialNACompensation]
      ,[FinancialSource]
      ,[NormalizedAddress_CompleteAddress]
      ,[NormalizedAddress_StreetNumber]
      ,[NormalizedAddress_StreetPredirection]
      ,[NormalizedAddress_StreetName]
      ,[NormalizedAddress_StreetSuffix]
      ,[NormalizedAddress_StreetPostdirection]
      ,[NormalizedAddress_City]
      ,[NormalizedAddress_State]
      ,[NormalizedAddress_Zip]
      ,[GeoData_City_Name]
      ,[GeoData_Zip_Name]
      ,[GeoData_Neighborhood_Name]
      ,[GeoData_School_District_Name]
      ,[co_listing_agent_Name]
      ,[co_listing_agent_email]
      ,[co_listing_agent_phone]
      ,[co_listing_agent_FirstName]
      ,[co_listing_agent_LastName]
      ,[co_listing_agent_License_Number]
      ,[co_Selling_agent_Name]
      ,[co_Selling_agent_email]
      ,[co_Selling_agent_phone]
      ,[co_Selling_agent_FirstName]
      ,[co_Selling_agent_LastName]
      ,[co_Selling_agent_License_Number]
      ,[Selling_Agent_Name]
      ,[Selling_Agent_email]
      ,[Selling_Agent_phone]
      ,[Selling_Agent_FirstName]
      ,[Selling_Agent_LastName]
      ,[Selling_Agent_license_number]
      ,[Sell_Agent_Office_ID]
      ,[Sell_Agent_Office_Name]
      ,[Sell_Agent_Office_Phone]
      ,[List_Agent_Name]
      ,[List_Agent_email]
      ,[List_Agent_phone]
      ,[List_Agent_FirstName]
      ,[List_Agent_LastName]
      ,[List_Agent_License_Number]
      ,[List_Agent_Office_ID]
      ,[List_Agent_Office_Name]
      ,[List_Agent_Office_Phone]
      ,[attribution_contact]
		,[InitialLoadDate]
	  ,[Platlabs_listdate]
	  ,[Selling_Agent_ID]
	  ,[source_mls_url]
	  ,rowNum)
		SELECT [school_district]
      ,[elementary_school]
      ,[junior_high_school]
      ,[high_school]
      ,[middle_school]
      ,[videos_change_date]
      ,[major_change_date]
      ,[above_grade_finished_area]
      ,[activation_date]
      ,[active]
      ,[additional_features]
      ,[address]
      ,[air_conditioning]
      ,[allow_avm]
      ,[allow_comments]
      ,[annual_insurance]
      ,[annual_maintenance]
      ,[annual_management_fees]
      ,[annual_tax]
      ,[annual_utilities]
      ,[appliances]
      ,[approximate_age]
      ,[area_name]
      ,[area_name_minor]
      ,[availability_date]
      ,[basement_description]
      ,[bathrooms]
      ,[bathrooms_full]
      ,[bathrooms_half]
      ,[bathrooms_partial]
      ,[bathrooms_quarter]
      ,[bathrooms_three_quarter]
      ,[bedrooms]
      ,[below_grade_description]
      ,[below_grade_finished_area]
      ,[building_name]
      ,[cancelled_date]
      ,[ceiling_height]
      ,[ceiling_height_str]
      ,[city]
      ,[close_date]
      ,[commission_misc]
      ,[community]
      ,[condition]
      ,[confidential_description]
      ,[construction_materials]
      ,[contingencies]
      ,[contingent_date]
      ,[contract_date]
      ,[contract_status_change_date]
      ,[country]
      ,[country_code]
      ,[county]
      ,[created_date]
      ,[cumulative_days_on_market]
      ,[current_use]
      ,[days_on_market]
      ,[days_on_market_replication_date]
      ,[den_description]
      ,[description]
      ,[design]
      ,[dining_room_description]
      ,[directions]
      ,[disability_features]
      ,[display_lat]
      ,[display_lng]
      ,[display_mls_number]
      ,[documents_change_timestamp]
      ,[door_features]
      ,[down_payment_resource]
      ,[driveway_description]
      ,[exclusions]
      ,[expiration_date]
      ,[exterior_description]
      ,[exterior_features]
      ,[extras]
      ,[family_room_description]
      ,[fence_description]
      ,[financial_information]
      ,[fireplace_description]
      ,[fireplaces]
      ,[flooring_information]
      ,[foreclosure_type]
      ,[formatted_address]
      ,[frontage_type]
      ,[garage_description]
      ,[garage_spaces]
      ,[geocode_date]
      ,[geocode_quality]
      ,[green_features]
      ,[has_basement]
      ,[has_electricity]
      ,[has_fireplace]
      ,[has_garage]
      ,[has_hoa]
      ,[has_horse_property]
      ,[has_mountain_view]
      ,[has_open_house]
      ,[has_pool]
      ,[has_price_reduced]
      ,[has_sewer]
      ,[has_view]
      ,[has_water]
      ,[has_waterfront]
      ,[has_waterview]
      ,[heat_source]
      ,[heat_type]
      ,[hide_address]
      ,[hoa_amenities]
      ,[hoa_fee]
      ,[hoa_fee_includes]
      ,[hoa_frequency]
      ,[hoa_name]
      ,[hoa_phone]
      ,[idx]
      ,[improvements]
      ,[interior_features]
      ,[is_adult_community]
      ,[is_boat_slip]
      ,[is_business_with_real_estate]
      ,[is_commercial]
      ,[is_commercial_lease]
      ,[is_condo]
      ,[is_condo_townhouse]
      ,[is_coop]
      ,[is_cul_de_sac]
      ,[is_duplex]
      ,[is_farm_hobby]
      ,[is_foreclosure]
      ,[is_gated_community]
      ,[is_golf_community]
      ,[is_industrial]
      ,[is_investment]
      ,[is_loft]
      ,[is_lot]
      ,[is_mixed_use]
      ,[is_mobile_home]
      ,[is_model]
      ,[is_multi_family]
      ,[is_new_construction]
      ,[is_on_golf_course]
      ,[is_one_story]
      ,[is_other]
      ,[is_rental]
      ,[is_residential_lease]
      ,[is_shortsale]
      ,[is_single_family]
      ,[is_single_family_detached]
      ,[is_three_plus_story]
      ,[is_townhouse]
      ,[is_two_story]
      ,[kitchen]
      ,[kitchen_description]
      ,[kitchen_dimensions]
      ,[kitchen_level]
      ,[landscape]
      ,[last_update_date]
      ,[latitude]
      ,[laundry_room_description]
      ,[list_date]
      ,[listing_agent_commission_rate]
      ,[listing_agent_email]
      ,[listing_agent_flat_fee]
      ,[listing_agent_id]
      ,[listing_agent_name]
      ,[listing_agent_phone]
      ,[listing_agent_uid]
      ,[listing_agreement]
      ,[listing_key]
      ,[listing_office_id]
      ,[listing_office_name]
      ,[listing_office_phone]
      ,[listing_office_uid]
      ,[living_room_description]
      ,[location]
      ,[longitude]
      ,[lot_description]
      ,[lot_dimension]
      ,[lot_size]
      ,[lot_size_area]
      ,[lot_size_display]
      ,[lot_size_source]
      ,[lot_size_square_feet]
      ,[lot_size_units]
      ,[market_name]
      ,[master_bath_description]
      ,[master_bedroom_description]
      ,[master_bedroom_level]
      ,[mls_create_date]
      ,[mls_id]
      ,[mls_lat]
      ,[mls_list_date]
      ,[mls_listing_id]
      ,[mls_lng]
      ,[mls_property_sub_type]
      ,[mls_property_type]
      ,[mls_status]
      ,[mls_update_date]
      ,[modified_date]
      ,[monthly_hoa_fee]
      ,[neighborhood]
      ,[normalized_hoa_frequency]
      ,[occupant_type]
      ,[off_market_date]
      ,[on_market_date]
      ,[open_house]
      ,[original_listing_price]
      ,[originating_system_name]
      ,[outbuildings_description]
      ,[ownership]
      ,[parcel_number]
      ,[parcel_number_public_record]
      ,[parking_description]
      ,[parking_spaces]
      ,[patio_and_porch_features]
      ,[pending_date]
      ,[pets_allowed]
      ,[photo_count]
      ,[photo_date]
      ,[pool_description]
      ,[price]
      ,[price_change_date]
      ,[price_change_timestamp]
      ,[price_display]
      ,[price_per_square_foot]
      ,[property_type]
      ,[property_view_description]
      ,[restrictions]
      ,[road_frontage_description]
      ,[roofing]
      ,[rooms]
      ,[rooms_description]
      ,[rupid]
      ,[sale_type]
      ,[security_features]
      ,[seller_concessions]
      ,[selling_agent_commission_rate]
      ,[selling_agent_flat_fee]
      ,[sewer]
      ,[sold_date]
      ,[sold_price]
      ,[source_create_date]
      ,[source_system_key]
      ,[source_system_name]
      ,[square_feet]
      ,[square_feet_of_land]
      ,[square_feet_range]
      ,[square_foot_source]
      ,[state]
      ,[status]
      ,[status_change_date]
      ,[stories_description]
      ,[stories_total]
      ,[street_direction]
      ,[street_name]
      ,[street_number]
      ,[street_pre_direction]
      ,[street_type]
      ,[structure_type]
      ,[style]
      ,[subdivision]
      ,[substructure]
      ,[tax_legal_description]
      ,[tax_year]
      ,[tenant_pays]
      ,[topography]
      ,[total_units]
      ,[township]
      ,[uid]
      ,[unit_number]
      ,[utilities]
      ,[utilities_available]
      ,[virtual_tour]
      ,[virtual_tour_branded]
      ,[walk_score]
      ,[water]
      ,[water_frontage]
      ,[waterfront_description]
      ,[windows_description]
      ,[withdrawn_date]
      ,[year_built]
      ,[year_built_source]
      ,[zip]
      ,[zoning]
      ,[LoadDate]
      ,[PropertyID]
      ,[REF_ID]
      ,[FIPS]
      ,[buyer_financing]
      ,[energy_source]
      ,[finished_area]
      ,[furnished]
      ,[has_irrigation_water_rights]
      ,[is_land_lease]
      ,[originating_system_id]
      ,[possession]
      ,[seller_concessions_comments]
      ,[special_listing_conditions]
      ,[tenant_total_expenses]
      ,[unfinished_area]
      ,[water_body_name]
      ,[zoning_description]
      ,[FeatureExteriorGeneral]
      ,[FeatureExteriorStyle]
      ,[FeatureExteriorPool]
      ,[FeatureExteriorParking]
      ,[FeatureInteriorAC]
      ,[FeatureInteriorAppliances]
      ,[FeatureInteriorBasement]
      ,[FeatureInteriorDisability]
      ,[FeatureInteriorGreen]
      ,[FeatureInteriorFireplace]
      ,[FeatureInteriorFlooring]
      ,[FeatureInteriorGeneral]
      ,[FeatureInteriorHeating]
      ,[FeatureInteriorLaundry]
      ,[FeatureInteriorRooms]
      ,[ConstructionGeneral]
      ,[constructinoRoofing]
      ,[ConstructionWindows]
      ,[LocationCounty]
      ,[LocationHOAAmenities]
      ,[LocationOriginatingMLS]
      ,[LocationRoadAccess]
      ,[LotCurrentUse]
      ,[LotFencing]
      ,[LotView]
      ,[LotZoning]
      ,[UtilitesSewer]
      ,[UtilitiesUtilities]
      ,[UtilitiesWater]
      ,[FinancialBuyersAgentCompensation]
      ,[FinancialNACompensation]
      ,[FinancialSource]
      ,[NormalizedAddress_CompleteAddress]
      ,[NormalizedAddress_StreetNumber]
      ,[NormalizedAddress_StreetPredirection]
      ,[NormalizedAddress_StreetName]
      ,[NormalizedAddress_StreetSuffix]
      ,[NormalizedAddress_StreetPostdirection]
      ,[NormalizedAddress_City]
      ,[NormalizedAddress_State]
      ,[NormalizedAddress_Zip]
      ,[GeoData_City_Name]
      ,[GeoData_Zip_Name]
      ,[GeoData_Neighborhood_Name]
      ,[GeoData_School_District_Name]
      ,[co_listing_agent_Name]
      ,[co_listing_agent_email]
      ,[co_listing_agent_phone]
      ,[co_listing_agent_FirstName]
      ,[co_listing_agent_LastName]
      ,[co_listing_agent_License_Number]
      ,[co_Selling_agent_Name]
      ,[co_Selling_agent_email]
      ,[co_Selling_agent_phone]
      ,[co_Selling_agent_FirstName]
      ,[co_Selling_agent_LastName]
      ,[co_Selling_agent_License_Number]
      ,[Selling_Agent_Name]
      ,[Selling_Agent_email]
      ,[Selling_Agent_phone]
      ,[Selling_Agent_FirstName]
      ,[Selling_Agent_LastName]
      ,[Selling_Agent_license_number]
      ,[Sell_Agent_Office_ID]
      ,[Sell_Agent_Office_Name]
      ,[Sell_Agent_Office_Phone]
      ,[List_Agent_Name]
      ,[List_Agent_email]
      ,[List_Agent_phone]
      ,[List_Agent_FirstName]
      ,[List_Agent_LastName]
      ,[List_Agent_License_Number]
      ,[List_Agent_Office_ID]
      ,[List_Agent_Office_Name]
      ,[List_Agent_Office_Phone]
      ,[attribution_contact]
	  ,[InitialLoadDate]
	  ,[Platlabs_Listdate]
	  ,[Selling_Agent_ID]
	  ,[source_mls_url]
	  ,ROW_NUMBER() OVER(PARTITION BY mls_id,mls_listing_id ORDER BY LoadDate) as RowNum 
	  FROM [src_PlatLabs].[listing].[listingFull_WORKING] WITH(NOLOCK)

		-- INSERT NEW MLS's FOR EXTRACT
		INSERT INTO [src_PlatLabs].[dbo].[platlabs_extract_photoLinks_config]
		Select mls_id,null from [src_platlabs].[dbo].[platlabs_update_config] with(NOLOCK)
		where active = '1' and code like '%_39'

		INSERT INTO [src_PlatLabs].[dbo].[platlabs_extract_stdLayout_config]
		Select mls_id,null from [src_platlabs].[dbo].[platlabs_update_config] with(NOLOCK)
		where active = '1' and code like '%_39'


		----- TEMP adjustment 
				UPDATE [src_PlatLabs].[listing].[listingFull]
				SET FeatureExteriorGeneral = NULL
				,FeatureExteriorStyle = [style]
				,FeatureExteriorPool = [pool_description]
				,FeatureExteriorParking = [parking_description]
				,FeatureInteriorAC = air_conditioning
				,FeatureInteriorAppliances = appliances
				,FeatureInteriorBasement = [basement_description]
				,FeatureInteriorDisability = [disability_features]
				,FeatureInteriorGreen = green_features
				,FeatureInteriorFireplace = [fireplaces]
				,FeatureInteriorFlooring = [flooring_information]
				,FeatureInteriorGeneral = NULL
				,FeatureInteriorHeating = NULL
				,FeatureInteriorLaundry = [laundry_room_description]
				,FeatureInteriorRooms = rooms
				,ConstructionGeneral = NULL
				,constructinoRoofing = [roofing]
				,ConstructionWindows = [windows_description]
				,LocationCounty = [county]
				,LocationHOAAmenities = [hoa_amenities]
				,LocationOriginatingMLS = [originating_system_name]
				,LocationRoadAccess = NULL
				,LotCurrentUse = [current_use]
				,LotFencing = fence_description
				,LotView = NULL
				,LotZoning = [zoning]
				,UtilitesSewer = [sewer]
				,UtilitiesUtilities = [utilities]
				,UtilitiesWater = [water]
				,FinancialBuyersAgentCompensation = NULL
				,FinancialNACompensation = NULL
				,FinancialSource = NULL
				,GeoData_City_Name = [city]
				,GeoData_Zip_Name = [zip]
				,GeoData_Neighborhood_Name = [neighborhood]
				,GeoData_School_District_Name = [school_district]
				WHERE mls_id = 3020

		---- PREP WEBSITE EXTRACT

		DELETE FROM [src_PlatLabs].[dbo].[a]
		FROM [Extracts].[dbo].[vWebsite_V3] a JOIN [src_platlabs].[listing].[listingFull_WORKING] l with(NOLOCK)
		ON a.id = cast(l.mls_id as varchar) + '-' + l.mls_listing_id

			

				Insert into [Extracts].[dbo].[vWebsite_V3]
					SELECT cast(l.mls_id as varchar) + '-' + l.mls_listing_id as [id]
						,appliances as [appliances]
						,style as [architectural_style]
						,hoa_fee as [association_fee]
						,hoa_frequency as [association_fee_frequency]
						,NULL as [association_type]
						,Case when (parking_description like '%Attached Garage%' or parking_description like '%Garage attached%') Then 'Y' Else 'N' End as [attached_garage_yn]
						,Case when has_basement = 'true' Then 'Y' Else 'N' End as [basement_yn]
						,bathrooms_full as [bathrooms_full]
						,bathrooms_half as [bathrooms_half]
						,bathrooms as [bathrooms_total_integer]
						,l.bedrooms as [bedrooms_total]
						,FinancialBuyersAgentCompensation as [buyer_agency_compensation]
						,NULL as [buyer_agency_compensation_type]
						,l.city as [city]
						,hoa_amenities as [community_features]
						,construction_materials as [construction_materials]
						,air_conditioning as [cooling]
						,country as [country]
						,county as [county_or_parish]
						,NULL as [covered_spaces]
						,cumulative_days_on_market as [cumulative_days_on_market]
						,days_on_market as [days_on_market]
						,directions as [directions]
						,elementary_school as [elementary_school_name]
						,exclusions as [exclusions]
						,exterior_features as [exterior_features]
						,fence_description as [fencing]
						,fireplace_description as [fireplace_features]
						,fireplaces as [fireplaces_total]
						,flooring_information as [flooring]
						,NULL as [foundation_details]
						,garage_spaces as [garage_spaces]
						,CASE WHEN (garage_spaces is not null and garage_spaces not like '0') then 'Y' Else 'N' End as [garage_yn]
						,NULL as [hoamanagement_company]
						,hoa_phone as [hoamanagement_company_phone]
						,heat_type as [heating]
						,high_school as [high_school_name]
						,interior_features as [interior_features]
						,middle_school as [intermediate_school_name]
						,junior_high_school as [junior_high_school_name]
						,CASE WHEN z.FALatitude is null then l.latitude ELSE z.FALatitude END as [latitude]
						,laundry_room_description as [laundry_features]
						,NULL as [levels]
						,listing_agent_phone as [list_agent_direct_phone]
						,listing_agent_email as [list_agent_email]
						,listing_agent_name as [list_agent_full_name]
						,a.[mlskey] as [list_agent_key_numeric]
						,a.[primary_association] as [list_agent_mls_provider]
						,a.[mls_id] as [list_agent_mls_id]
						,NULL as [list_agent_texting_allowed_yn]
						,CASE WHEN l.[originating_system_name] is NULL THEN l.[market_name] ELSE l.[originating_system_name] END as [list_mls_provider]
						,NULL as [list_office_key_numeric]
						,NULL as [list_office_manager]
						,NULL as [list_office_manager_key_numeric]
						,NULL as [list_office_manager_license]
						,NULL as [list_office_manager_mls_id]
						,NULL as [list_office_manager_phone]
						,[listing_office_id] as [list_office_mls_id]
						,listing_office_name as [list_office_name]
						,listing_office_phone as [list_office_phone]
						,price as [list_price]
						,[Platlabs_listdate] as Listing_contract_date
						,l.mls_listing_id as [listing_id]
						,NULL as [listing_key_numeric]
						,square_feet as [living_area]
						,case when z.FAlongitude is null then l.longitude Else z.FALongitude END as [longitude]
						,lot_description as [lot_number]
						,CASE WHEN [lot_size] = [lot_size_square_feet] THEN cast([lot_size] as money)/43560 ELSE [lot_size] END as [lot_size_acres]
						,[lot_size] as [lot_size_area]
						,CASE WHEN [lot_size_square_feet] is NULL THEN CAST(ROUND(cast(Lot_size as money)*43560,0) as bigint) ELSE [lot_size_square_feet] END as [lot_size_square_feet]
						,CASE WHEN [lot_size_units] is NULL THEN CASE WHEN [lot_size] = [lot_size_square_feet] THEN 'SQFT' WHEN [lot_size] is NULL THEN NULL ELSE 'Acres' END ELSE [lot_size_units] END  as [lot_size_units]
						,middle_school as [middle_school_name]
						,l.[status] as [mls_status]
						,l.[mls_update_date] as [modification_timestamp]
						,dining_room_description as [number_of_dining_areas]
						,living_room_description as [number_of_living_areas]
						,original_listing_price as [original_list_price]
						,NULL as [owner_name]
						,CASE WHEN parcel_number is NULL THEN parcel_number_public_record ELSE parcel_number END as [parcel_number]
						,parking_description as [parking_features]
						,patio_and_porch_features as [patio_and_porch_features]
						,l.photo_date as [photos_change_timestamp]
						,CASE WHEN has_pool = 'true' THEN 'Y' ELSE 'N' END as [pool_yn]
						,case when s.[zip] is null then l.[zip] Else s.[Zip] end as [postal_code]
						,NULL as [postal_code_plus4]
						,NULL as [previous_list_price]
						,NULL as [previous_status]
						,price_change_timestamp as [price_change_timestamp]
						,elementary_school as [primary_school_name]
						,CASE WHEN [allow_comments] = 'N' THEN NULL ELSE [confidential_description] END as [private_remarks]
						,NULL as [property_key]
						,mls_property_sub_type as [property_sub_type]
						,mls_property_type as [property_type]
						,[description] as [public_remarks]
						,roofing as [roof]
						,school_district as [school_district]
						,high_school as [senior_high_school_name]
						,NULL as [showing_contact_phone]
						,NULL as [showing_instructions]
						,NULL as [showing_requirements]
						,mls_status as [standard_status]
						,l.[state] as [state_or_province]
						,status_change_date as [status_change_timestamp]
						,stories_description as [stories]
						,CASE WHEN stories_total is NULL THEN CASE WHEN stories_description = 'one' THEN '1' WHEN stories_description = 'two' THEN '1' WHEN stories_description = 'one and one half' THEN '1.5' WHEN stories_description = 'Three' THEN '3' ELSE NULL END ELSE stories_total END  as [stories_total]
						,s.LeftDirection as [street_dir_prefix]
						,s.RightDirection as [street_dir_suffix]
						,s.Street as [street_name]
						,s.HouseNbr as [street_number]
						,s.HouseNbr as [street_number_numeric]
						,s.Mode as [street_suffix]
						,structure_type as [structural_style]
						,NULL as [sub_agency_compensation]
						,NULL as [sub_agency_compensation_type]
						,subdivision as [subdivision_name]
						,NULL as [tax_block]
						,tax_legal_description as [tax_legal_description]
						,NULL as [us_property_mui]
						,NULL as [unexempt_taxes]
						,utilities as [utilities]
						,virtual_tour_branded as [virtual_toururlunbranded]
						,water_frontage as [waterfront_yn]
						,windows_description as [window_features]
						,year_built as [year_built]
						,year_built_source as [year_built_details]
						,NULL as [year_of_purchase]
						,NULL as [year_built_effective]
						,NULL as [special_listing_conditions]
						,o.[nrds_id] as [office_key_numeric]
						,o.[phone] as [office_phone]
						,o.[zip] as [office_postal_code]
						,o.[license_number] as [license_number]
						,NULL as [office_corporate_license]
						,o.[state] as [office_state_or_province]
						,o.[city] as [office_mail_city]
						,o.[address] as [office_mail_address]
						,[listing_agent_id] as [member_mls_id]
						,[listing_agent_phone] as [member_phone]
						,a.email as [member_email]
						,[listing_agent_name] as [member_full_name]
						,[parent_org_id] as [office_broker_mls_id]
						,CASE WHEN s.[FullStreetAddress] IS NULL THEN l.[address] ELSE s.[FullStreetAddress] END as [Fulladdress]
						,CASE WHEN s.[City] IS NULL THEN l.[City] ELSE s.[City] END as [FullCity]
						,CASE WHEN s.[State] IS NULL THEN l.[State] ELSE s.[State] END as [Region]
						,CASE WHEN s.[Zip] IS NULL THEN l.[Zip] ELSE s.[Zip] END as [FullPostal_code]
						,replace(market_name,'_39','') as MLSCode 
						,cast(p.PhotoLinks as varchar(8000)) as PhotoLinks
						,l.[price_display] as price_display
						,l.allow_avm as allow_avm
						,l.LoadDate 
						,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE v.DIRECT_FINAL_VALUE END as AVMValue
						,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE v.DIRECT_HIGH_VALUE END as HighValue
						,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE v.DIRECT_LOW_VALUE END as LowValue
						,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE v.DIRECT_CONFIDENCE_SCORE END as ConfidenceScore
						,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE v.DIRECT_FORECAST_STANDARD_DEVIATION END as ForecastStandardDeviation
						,l.[attribution_contact]
						,l.[hide_address]
						,[source_mls_url]
					  FROM [src_platlabs].[listing].[listingFull_WORKING] l with(NOLOCK) 
						
						Left outer join [src_PlatLabs].[agent].[Platlabs_agents] a with(NOLOCK)
							on l.mls_id = a.mls_id
								and l.[listing_agent_uid] = a.[uid]
						Left outer join [src_PlatLabs].[Office].[Platlabs_Offices] o with(NOLOCK)
							on l.mls_id = a.mls_id
								and l.[listing_office_uid] = o.[uid]
						left outer join [src_PlatLabs].[photos].[RawPhotoLinks_25] p with(NOLOCK) 
							on l.mls_id = p.mls_id
								and l.mls_listing_id = p.mls_listing_id
						left outer join [zCust_ADS__00_SharedProcs].[dbo].[Holocron] v with(NOLOCK) 
							on l.PropertyID = v.PropertyID
						left outer join [src_PlatLabs].[addr].[StandardizedAddress] s with(NOLOCK) 
							on l.mls_id = s.mls_id
								and l.mls_listing_id = s.mls_listing_id
						left outer join [zCust_ADS__00_SharedProcs].[dbo].[Property_LatLong] z with(NOLOCK) 
							on l.PropertyID = z.propertyid
						WHERE l.[status] in('Active','Backup','Contingent','Pending','Coming Soon')
						and l.mls_id > 2602


		---- MOVED TO 1st PART OF 900 --- MAS 20251021
		------Start the whole process over again
		----update Reports.dbo.[Platlabs_update_times] set download_ready_to_start = 1
		------------------------------------------------------------


		-- ADD NEW MLS's TO CI 
		insert into [Reports].[dbo].[SentToCI_Listings](mls_id,mls_name,code,DateSent,DateSentUpdates)
		Select mls_id,MLSFullName,PlatlabsCode,GETDATE()-1,GETDATE()-1
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] WITH(NOLOCK)
		where active = 1
		and mls_id not in(Select mls_id from [Reports].[dbo].[SentToCI] WITH(NOLOCK))


		-- ADD NEW MLS's TO WEB Listings
		insert into [Reports].[dbo].[SentToWEB_Listings](mls_id,mls_name,code,DateSent,DateSentUpdates)
		Select mls_id,MLSFullName,PlatlabsCode,GETDATE()-1,GETDATE()-1
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] WITH(NOLOCK)
		where active = 1
		and mls_id not in(Select mls_id from [Reports].[dbo].[SentToWEB] WITH(NOLOCK))

		-- ADD NEW MLS's TO WEB 
		insert into [Reports].[dbo].[SentToWEB](mls_id,mls_name,code,DateSent,DateSentUpdates)
		Select mls_id,MLSFullName,PlatlabsCode,GETDATE()-1,GETDATE()-1
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] WITH(NOLOCK)
		where active = 1
		and mls_id not in(Select mls_id from [Reports].[dbo].[SentToWEB] WITH(NOLOCK))

		-- ADD NEW MLS's TO CI Photo
		insert into [Reports].[dbo].[SentToCI_Photos](mls_id,mls_name,code,DateSent,DateSentUpdates)
		Select mls_id,MLSFullName,PlatlabsCode,GETDATE()-1,GETDATE()-1
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] WITH(NOLOCK)
		where active = 1
		and mls_id not in(Select mls_id from [Reports].[dbo].[SentToCI] WITH(NOLOCK))


		-- ADD NEW MLS's TO WEB Photo
		insert into [Reports].[dbo].[SentToWEB_Photos](mls_id,mls_name,code,DateSent,DateSentUpdates)
		Select mls_id,MLSFullName,PlatlabsCode,GETDATE()-1,GETDATE()-1
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] WITH(NOLOCK)
		where active = 1
		and mls_id not in(Select mls_id from [Reports].[dbo].[SentToWEB] WITH(NOLOCK))


		UPDATE [src_PlatLabs].[dbo].[a]
		SET a.sold_date	 = b.sold_date
		From [src_PlatLabs].[listing].[listingFull] a with(NOLOCK) JOIN [src_PlatLabs].[listing].[ListingsRaw] b with(NOLOCK)
			ON a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id
			WHERE a.LoadDate > GETDATE()-1
			and a.sold_date is null 
			and b.sold_date is not null
				
		UPDATE [src_PlatLabs].[dbo].[a]
		SET a.sold_price = b.sold_price 
		From [src_PlatLabs].[listing].[listingFull] a with(NOLOCK) JOIN [src_PlatLabs].[listing].[ListingsRaw] b with(NOLOCK)
			ON a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id
			WHERE a.LoadDate > GETDATE()-1
			and a.sold_price is null 
			and b.sold_price is not null
				


		WHILE(Select YesOrNo FROM [src_PlatLabs].[dbo].[MainListingComplete]) = 'N'
			BEGIN
				Waitfor Delay '00:02:10'	
			END

		--declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END


