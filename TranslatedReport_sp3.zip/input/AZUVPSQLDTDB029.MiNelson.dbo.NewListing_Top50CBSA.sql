/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.NewListing_Top50CBSA | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 4/14/2020
-- Description:	Create New Listing Trends for top 25 CBSA
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[NewListing_Top50CBSA]
                
AS 


SET NOCOUNT ON

BEGIN
 

 
  --- By Day

  
   /*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_temp_Day') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_temp_Day]


 select   h.fips, (select l.REF_ID from [FA_Listing].[dbo].[Listing] l where l.Listing_ID=h.Listing_Id) ref_id,
 --h.ref_id, 
 MLS_Listing_Number,      
             case  WHEN UpdateSeq = 1
                           THEN 'Yes'
                     ELSE NULL
                     END new
					 ,CASE 
                     WHEN MLS_STATUS_STD = 'Active' and UpdateSeq = 1
                           THEN MLS_List_Date_STD 
                     ELSE NULL
                     END AS Active_yearMonth_New
              ,CASE 
                     WHEN MLS_STATUS_STD = 'Active'
                           THEN  convert ( date,[UpdateTimestamp])--Original_UPDATE_FLAG_DATE_STD
                     ELSE NULL
                     END AS Active_yearMonth
            into [Minelson].[dbo].[ListingTrends_raw_temp_Day]


              FROM [FA_Listing].[dbo].[vListingHistory] h
              WHERE Listing_ID IN (SELECT distinct Listing_ID
                           FROM [FA_Listing].[dbo].[Listing]
                           where MLS_List_Date_STD >= '2019-01-01'     
						     and fips in (   select distinct fips from [MiNelson].[List].[Top_50_CBSAs]           )  )               
              and UpdateSeq = 1 and  MLS_STATUS_STD = 'Active'


  --- By Day

  
--   /*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_temp_Day') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.ListingTrends_raw_temp_Day

--Select c.*
--,coalesce(Active_yearMonth_New,Active_yearMonth, Pending_yearMonth, Sold_yearMonth, Fail_yearMonth) as sort_month
--into Minelson.dbo.ListingTrends_raw_temp_Day
--from(

--SELECT DISTINCT b.new,
--Active_yearMonth_New
--       ,Active_yearMonth
--       ,Pending_yearMonth
--       ,Sold_yearMonth
--          ,Fail_yearMonth
--       ,Listing_ID
--	   ,Fips
--	   , Ref_id
--FROM (
--       SELECT CASE 
--                     WHEN UpdateSeq = 1
--                           THEN 'Yes'
--                     ELSE NULL
--                     END new
--					   ,CASE 
--                     WHEN MLS_STATUS_STD = 'Active' and UpdateSeq = 1
--                           THEN MLS_List_Date_STD 
--                     ELSE NULL
--                     END AS Active_yearMonth_New
--              ,CASE 
--                     WHEN MLS_STATUS_STD = 'Active'
--                           THEN  convert ( date,[UpdateTimestamp])--Original_UPDATE_FLAG_DATE_STD
--                     ELSE NULL
--                     END AS Active_yearMonth
--              ,CASE 
--                     WHEN MLS_STATUS_STD = 'Pending'
--                           THEN convert ( date,[UpdateTimestamp])-- Original_UPDATE_FLAG_DATE_STD 
--						    ELSE NULL


--                     END AS Pending_yearMonth
--              ,CASE 
--                     WHEN MLS_STATUS_STD = 'Sold'
--                           THEN   SOLD_DATE_STD 
--                     ELSE NULL
--                     END AS Sold_yearMonth
--                                  ,CASE 
--                     WHEN MLS_STATUS_STD = 'Fail'
--                           THEN  convert ( date,[UpdateTimestamp])-- Original_UPDATE_FLAG_DATE_STD 
--                     ELSE NULL
--                     END AS Fail_yearMonth
--              ,a.*
--       FROM (
--              SELECT *
--              FROM [FA_Listing].[dbo].[vListingHistory] h
--              WHERE Listing_ID IN (SELECT distinct Listing_ID
--                           FROM [FA_Listing].[dbo].[Listing]
--                           where MLS_List_Date_STD >= '2019-01-01'     
--						     and fips in (   select distinct fips from [MiNelson].[List].[Top_50_CBSAs]                            
--                       )
--                   )
   
--              ) a
--       ) b
--) c
--order by Listing_id ,
--coalesce(Active_yearMonth_New, Active_yearMonth, Pending_yearMonth, Sold_yearMonth) 

select * from [Minelson].[dbo].[ListingTrends_raw_temp_Day]
where new = 'yes' and Active_yearMonth is   null

  /*IF OBJECT_ID('Minelson.List.NewListing_Top50CBSA_Day') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[List].[NewListing_Top50CBSA_Day]

select b.[CBSA_Code], b.[CBSA_Name],  Active_yearMonth_New as Day,   count (*) as Total_Count
, sum (case when Ref_id is not null then 1 else 0 end) as Count_With_Ref_ID
into [Minelson].[List].[NewListing_Top50CBSA_Day]
from [Minelson].[dbo].[ListingTrends_raw_temp_Day] a
left join [Minelson].[Stats].[CBSA_Codes] b
on a.fips = b.fips 
where new = 'yes' and Active_yearMonth_New is not null
group by b.[CBSA_Code], b.[CBSA_Name], Active_yearMonth_New
order by 1

--- clean up

Delete  
from [Minelson].[List].[NewListing_Top50CBSA_Day]
where  cbsa_code is null


Delete  
from [Minelson].[List].[NewListing_Top50CBSA_Day]
where Day is null or 
day < '2019-01-01' or 
day > getdate()

Delete  from [Minelson].[List].[NewListing_Top50CBSA_Day]
  where CBSA_Code not in  (select distinct CBSA_Code from [MiNelson].[List].[Top_50_CBSAs])        

select *  from [Minelson].[List].[NewListing_Top50CBSA_Day]
order by  1,3

   
--/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_temp_Annette') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.ListingTrends_raw_temp_Annette

--select *
--into Minelson.dbo.ListingTrends_raw_temp_Annette
--from Minelson.dbo.ListingTrends_raw_temp_Day

--select * from  Minelson.dbo.Calendar

  
/*IF OBJECT_ID('Minelson.List.NewListing_Top50CBSA_MLS_ListDate') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[List].[NewListing_Top50CBSA_MLS_ListDate]


select a.CBSA_CODE, a.[CBSA_Name], left (CONCAT(a.Day , '--', b.DayOfWeekName), 15) as Day, a.Total_Count, a.Count_With_Ref_ID
into [Minelson].[List].[NewListing_Top50CBSA_MLS_ListDate]
from [Minelson].[List].[NewListing_Top50CBSA_Day] a
left join [Minelson].[dbo].[Calendar] b
on a.Day = b.CalendarDate


/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_temp_Day') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_temp_Day]
/*IF OBJECT_ID('Minelson.List.NewListing_Top50CBSA_Day') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[List].[NewListing_Top50CBSA_Day]




select *  from [Minelson].[List].[NewListing_Top50CBSA_MLS_ListDate]
order by  1,3

 
END  




