SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_Pinnacle].[dbo].[usp_300_Start_Output_PINNACLE_ASSESSOR_BATCH]
	

AS
BEGIN
	
	SET NOCOUNT ON;


		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
		[INPUT UniqueID][varchar](250)NULL,
		[INPUT PropertyID][varchar](250)NULL,
		[INPUT Address][varchar](250)NULL,
		[INPUT City][varchar](250)NULL,
		[INPUT State][varchar](250)NULL,
		[INPUT Zip][varchar](250)NULL,
		[INPUT DTRefID][varchar](250)NULL,
		[INPUT APN][varchar](250)NULL,
		[INPUT FIPS][varchar](250)NULL,
		[PropertyFound][varchar](250)NULL,
		[FIPS][varchar](250)NULL,
		[PropertyID][varchar](250)NULL,
		[APN][varchar](250)NULL,
		[APNSeqNbr][varchar](250)NULL,
		[OldAPN][varchar](250)NULL,
		[OldApnIndicator][varchar](250)NULL,
		[TaxAccountNumber][varchar](250)NULL,
		[SitusFullStreetAddress][varchar](250)NULL,
		[SitusHouseNbr][varchar](250)NULL,
		[SitusHouseNbrSuffix][varchar](250)NULL,
		[SitusDirectionLeft][varchar](250)NULL,
		[SitusStreet][varchar](250)NULL,
		[SitusMode][varchar](250)NULL,
		[SitusDirectionRight][varchar](250)NULL,
		[SitusUnitType][varchar](250)NULL,
		[SitusUnitNbr][varchar](250)NULL,
		[SitusCity][varchar](250)NULL,
		[SitusState][varchar](250)NULL,
		[SitusZIP5][varchar](250)NULL,
		[SitusZIP4][varchar](250)NULL,
		[SitusCarrierCode][varchar](250)NULL,
		[SitusLatitude][varchar](250)NULL,
		[SitusLongitude][varchar](250)NULL,
		[SitusGeoStatusCode][varchar](250)NULL,
		[PropertyClassID][varchar](250)NULL,
		[LandUseCode][varchar](250)NULL,
		[StateLandUseCode][varchar](250)NULL,
		[CountyLandUseCode][varchar](250)NULL,
		[Zoning][varchar](250)NULL,
		[SitusCensusTract][varchar](250)NULL,
		[SitusCensusBlock][varchar](250)NULL,
		[MobileHomeInd][varchar](250)NULL,
		[TimeshareCode][varchar](250)NULL,
		[SchoolDistrictName][varchar](250)NULL,
		[LotSizeFrontageFeet][varchar](250)NULL,
		[LotSizeDepthFeet][varchar](250)NULL,
		[LotSizeAcres][varchar](250)NULL,
		[LotSizeSqFt][varchar](250)NULL,
		[Owner1CorpInd][varchar](250)NULL,
		[Owner1LastName][varchar](250)NULL,
		[Owner1FirstName][varchar](250)NULL,
		[Owner1MiddleName][varchar](250)NULL,
		[Owner1Suffix][varchar](250)NULL,
		[Owner2CorpInd][varchar](250)NULL,
		[Owner2LastName][varchar](250)NULL,
		[Owner2FirstName][varchar](250)NULL,
		[Owner2MiddleName][varchar](250)NULL,
		[Owner2Suffix][varchar](250)NULL,
		[OwnerNAME1FULL][varchar](250)NULL,
		[OwnerNAME2FULL][varchar](250)NULL,
		[OwnerOccupied][varchar](250)NULL,
		[Owner1OwnershipRights][varchar](250)NULL,
		[MailingFullStreetAddress][varchar](250)NULL,
		[MailingHouseNbr][varchar](250)NULL,
		[MailingHouseNbrSuffix][varchar](250)NULL,
		[MailingDirectionLeft][varchar](250)NULL,
		[MailingStreet][varchar](250)NULL,
		[MailingMode][varchar](250)NULL,
		[MailingDirectionRight][varchar](250)NULL,
		[MailingUnitType][varchar](250)NULL,
		[MailingUnitNbr][varchar](250)NULL,
		[MailingCity][varchar](250)NULL,
		[MailingState][varchar](250)NULL,
		[MailingZIP5][varchar](250)NULL,
		[MailingZIP4][varchar](250)NULL,
		[MailingCarrierCode][varchar](250)NULL,
		[MailingOptOut][varchar](250)NULL,
		[MailingCOName][varchar](250)NULL,
		[MailingForeignAddressInd][varchar](250)NULL,
		[AssdTotalValue][varchar](250)NULL,
		[AssdLandValue][varchar](250)NULL,
		[AssdImprovementValue][varchar](250)NULL,
		[MarketTotalValue][varchar](250)NULL,
		[MarketValueLand][varchar](250)NULL,
		[MarketValueImprovement][varchar](250)NULL,
		[TaxAmt][varchar](250)NULL,
		[TaxYear][varchar](250)NULL,
		[TaxDeliquentYear][varchar](250)NULL,
		[MarketYear][varchar](250)NULL,
		[AssdYear][varchar](250)NULL,
		[TaxRateCodeArea][varchar](250)NULL,
		[SchoolTaxDistrict1Code][varchar](250)NULL,
		[SchoolTaxDistrict2Code][varchar](250)NULL,
		[SchoolTaxDistrict3Code][varchar](250)NULL,
		[HomesteadInd][varchar](250)NULL,
		[VeteranInd][varchar](250)NULL,
		[DisabledInd][varchar](250)NULL,
		[WidowInd][varchar](250)NULL,
		[SeniorInd][varchar](250)NULL,
		[SchoolCollegeInd][varchar](250)NULL,
		[ReligiousInd][varchar](250)NULL,
		[WelfareInd][varchar](250)NULL,
		[PublicUtilityInd][varchar](250)NULL,
		[CemeteryInd][varchar](250)NULL,
		[HospitalInd][varchar](250)NULL,
		[LibraryInd][varchar](250)NULL,
		[BuildingArea][varchar](250)NULL,
		[BuildingAreaInd][varchar](250)NULL,
		[SumBuildingSqFt][varchar](250)NULL,
		[SumLivingAreaSqFt][varchar](250)NULL,
		[SumGroundFloorSqFt][varchar](250)NULL,
		[SumGrossAreaSqFt][varchar](250)NULL,
		[SumAdjAreaSqFt][varchar](250)NULL,
		[AtticSqFt][varchar](250)NULL,
		[AtticUnfinishedSqFt][varchar](250)NULL,
		[AtticFinishedSqFt][varchar](250)NULL,
		[SumBasementSqFt][varchar](250)NULL,
		[BasementUnfinishedSqFt][varchar](250)NULL,
		[BasementFinishedSqFt][varchar](250)NULL,
		[SumGarageSqFt][varchar](250)NULL,
		[GarageUnFinishedSqFt][varchar](250)NULL,
		[GarageFinishedSqFt][varchar](250)NULL,
		[YearBuilt][varchar](250)NULL,
		[EffectiveYearBuilt][varchar](250)NULL,
		[Bedrooms][varchar](250)NULL,
		[TotalRooms][varchar](250)NULL,
		[BathTotalCalc][varchar](250)NULL,
		[BathFull][varchar](250)NULL,
		[BathsPartialNbr][varchar](250)NULL,
		[BathFixturesNbr][varchar](250)NULL,
		[Amenities][varchar](250)NULL,
		[AirConditioningCode][varchar](250)NULL,
		[BasementCode][varchar](250)NULL,
		[BuildingClassCode][varchar](250)NULL,
		[BuildingConditionCode][varchar](250)NULL,
		[ConstructionTypeCode][varchar](250)NULL,
		[DeckInd][varchar](250)NULL,
		[ExteriorWallsCode][varchar](250)NULL,
		[InteriorWallsCode][varchar](250)NULL,
		[FireplaceCode][varchar](250)NULL,
		[FloorCoverCode][varchar](250)NULL,
		[Garage][varchar](250)NULL,
		[HeatCode][varchar](250)NULL,
		[HeatingFuelTypeCode][varchar](250)NULL,
		[SiteInfluenceCode][varchar](250)NULL,
		[GarageParkingNbr][varchar](250)NULL,
		[DrivewayCode][varchar](250)NULL,
		[OtherRooms][varchar](250)NULL,
		[PatioCode][varchar](250)NULL,
		[PoolCode][varchar](250)NULL,
		[PorchCode][varchar](250)NULL,
		[BuildingQualityCode][varchar](250)NULL,
		[RoofCoverCode][varchar](250)NULL,
		[RoofTypeCode][varchar](250)NULL,
		[SewerCode][varchar](250)NULL,
		[StoriesNbrCode][varchar](250)NULL,
		[StyleCode][varchar](250)NULL,
		[SumResidentialUnits][varchar](250)NULL,
		[SumBuildingsNbr][varchar](250)NULL,
		[SumCommercialUnits][varchar](250)NULL,
		[TopographyCode][varchar](250)NULL,
		[WaterCode][varchar](250)NULL,
		[LotCode][varchar](250)NULL,
		[LotNbr][varchar](250)NULL,
		[LandLot][varchar](250)NULL,
		[Block][varchar](250)NULL,
		[Section][varchar](250)NULL,
		[District][varchar](250)NULL,
		[LegalUnit][varchar](250)NULL,
		[Municipality][varchar](250)NULL,
		[SubdivisionName][varchar](250)NULL,
		[SubdivisionPhaseNbr][varchar](250)NULL,
		[SubdivisionTractNbr][varchar](250)NULL,
		[Meridian][varchar](250)NULL,
		[AssessorsMapRef][varchar](250)NULL,
		[LegalDescription][varchar](2500)NULL,
		[CurrentSaleTransactionId][varchar](250)NULL,
		[CurrentSaleDocNbr][varchar](250)NULL,
		[CurrentSaleBook][varchar](250)NULL,
		[CurrentSalePage][varchar](250)NULL,
		[CurrentSaleRecordingDate][varchar](250)NULL,
		[CurrentSaleContractDate][varchar](250)NULL,
		[CurrentSaleDocumentType][varchar](250)NULL,
		[CurrentSalesPrice][varchar](250)NULL,
		[CurrentSalesPriceCode][varchar](250)NULL,
		[CurrentSaleBuyer1FullName][varchar](250)NULL,
		[CurrentSaleBuyer2FullName][varchar](250)NULL,
		[CurrentSaleSeller1FullName][varchar](250)NULL,
		[CurrentSaleSeller2FullName][varchar](250)NULL,
		[ConcurrentMtg1DocNbr][varchar](250)NULL,
		[ConcurrentMtg1Book][varchar](250)NULL,
		[ConcurrentMtg1Page][varchar](250)NULL,
		[ConcurrentMtg1RecordingDate][varchar](250)NULL,
		[ConcurrentMtg1LoanAmt][varchar](250)NULL,
		[ConcurrentMtg1Lender][varchar](250)NULL,
		[ConcurrentMtg1Term][varchar](250)NULL,
		[ConcurrentMtg1InterestRate][varchar](250)NULL,
		[ConcurrentMtg1LoanDueDate][varchar](250)NULL,
		[ConcurrentMtg1LoanType][varchar](250)NULL,
		[ConcurrentMtg1TypeFinancing][varchar](250)NULL,
		[ConcurrentMtg2DocNbr][varchar](250)NULL,
		[ConcurrentMtg2Book][varchar](250)NULL,
		[ConcurrentMtg2Page][varchar](250)NULL,
		[ConcurrentMtg2RecordingDate][varchar](250)NULL,
		[ConcurrentMtg2LoanAmt][varchar](250)NULL,
		[ConcurrentMtg2Lender][varchar](250)NULL,
		[ConcurrentMtg2Term][varchar](250)NULL,
		[ConcurrentMtg2InterestRate][varchar](250)NULL,
		[ConcurrentMtg2LoanDueDate][varchar](250)NULL,
		[ConcurrentMtg2LoanType][varchar](250)NULL,
		[ConcurrentMtg2Typefinancing][varchar](250)NULL,
		[PrevSaleTransactionId][varchar](250)NULL,
		[PrevSaleDocNbr][varchar](250)NULL,
		[PrevSaleBook][varchar](250)NULL,
		[PrevSalePage][varchar](250)NULL,
		[PrevSaleRecordingDate][varchar](250)NULL,
		[PrevSaleContractDate][varchar](250)NULL,
		[PrevSaleDocumentType][varchar](250)NULL,
		[PrevSalesPrice][varchar](250)NULL,
		[PrevSalesPriceCode][varchar](250)NULL,
		[PrevSaleBuyer1FullName][varchar](250)NULL,
		[PrevSaleBuyer2FullName][varchar](250)NULL,
		[PrevSaleSeller1FullName][varchar](250)NULL,
		[PrevSaleSeller2FullName][varchar](250)NULL,
		[PrevMtg1DocNbr][varchar](250)NULL,
		[PrevMtg1Book][varchar](250)NULL,
		[PrevMtg1Page][varchar](250)NULL,
		[PrevMtg1RecordingDate][varchar](250)NULL,
		[PrevMtg1LoanAmt][varchar](250)NULL,
		[PrevMtg1Lender][varchar](250)NULL,
		[PrevMtg1Term][varchar](250)NULL,
		[PrevMtg1InterestRate][varchar](250)NULL,
		[PrevMtg1LoanDueDate][varchar](250)NULL,
		[PrevMtg1LoanType][varchar](250)NULL,
		[PrevMtg1TypeFinancing][varchar](250)NULL,
		[FATimeStamp][varchar](250)NULL,
		[FARecordType][varchar](250)NULL


		) ON [PRIMARY]

		
		

		SET CONCAT_NULL_YIELDS_NULL OFF  

		--Insert into x_Custom_OUTPUT ([INPUT UniqueID],
		--[INPUT Address],
		--[INPUT City],
		--[INPUT State],
		--[INPUT Zip],
		--[INPUT APN])
			
		--Select  
		--[UniqueID]
  --      ,[SITE_Address]
  --    ,[SITE_City]
  --    ,[SITE_State]
  --    ,NULL
  --    ,[APN]
		--FROM [zCust_ADS__S10_PropertyInfo].dbo.INPUT_RAW_PINNACLE_20240919


			Insert into [zCust_Pinnacle].[dbo].[x_Custom_OUTPUT] ([INPUT UniqueID],
		--[INPUT PropertyID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		--[INPUT Zip],
		[INPUT DTRefID],
		[INPUT APN],
		[INPUT FIPS]
		)
			
		Select  
		[UniqueID]
      --,[PropertyID]
      ,[Address]
      ,[City]
      ,[State]
      --,[ZIP]
      ,[DTRefID]
      ,[APN]
      ,[FIPS]
	  --Select * 
		FROM [zCust_Pinnacle].[dbo].[INPUT_RAW_CUST_SPEC_PROJ]
		
	

		Select * From [zCust_Pinnacle].[dbo].[x_Custom_OUTPUT]



		
		UPDATE [zCust_Pinnacle].[dbo].[a] 
		SET 
		A.PropertyID = C.PropertyID
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_Pinnacle].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT UniqueID] = c.RAW_ID





		Update [zCust_Pinnacle].[dbo].[A]
		Set
		--A.[FIPS] = B.[FIPS]
		--,A.[PropertyID] = B.[PropertyID]
		--,
		A.[APN] = B.[FormattedAPN]
		,A.[APNSeqNbr] = B.[APNSeqNbr]
		,A.[OldAPN] = B.[OldAPN]
		,A.[OldApnIndicator] = B.[OldApnIndicator]
		,A.[TaxAccountNumber] = B.[TaxAccountNumber]
		,A.[SitusFullStreetAddress] = B.[SitusStdFullStreetAddress]
		,A.[SitusHouseNbr] = B.[SitusStdHouseNbr]
		,A.[SitusHouseNbrSuffix] = B.[SitusStdHouseNbrSuffix]
		,A.[SitusDirectionLeft] = B.[SitusStdDirectionLeft]
		,A.[SitusStreet] = B.[SitusStdStreet]
		,A.[SitusMode] = B.[SitusStdMode]
		,A.[SitusDirectionRight] = B.[SitusStdDirectionRight]
		,A.[SitusUnitType] = B.[SitusStdUnitType]
		,A.[SitusUnitNbr] = B.[SitusStdUnitNbr]
		,A.[SitusCity] = B.[SitusStdCity]
		,A.[SitusState] = B.[SitusStdState]
		,A.[SitusZIP5] = B.[SitusStdZIP5]
		,A.[SitusZIP4] = B.[SitusStdZIP4]
		,A.[SitusCarrierCode] = B.[SitusStdCarrierCode]
		,A.[SitusLatitude] = B.[SitusLatitude]
		,A.[SitusLongitude] = B.[SitusLongitude]
		,A.[SitusGeoStatusCode] = B.[SitusGeoStatusCode]
		,A.[PropertyClassID] = B.[PropertyClassID]
		,A.[LandUseCode] = B.[StdLandUseCode]
		,A.[StateLandUseCode] = B.[StateLandUseCode]
		,A.[CountyLandUseCode] = B.[CountyLandUseCode]
		,A.[Zoning] = B.[Zoning]
		,A.[SitusCensusTract] = B.[SitusCensusTract]
		,A.[SitusCensusBlock] = B.[SitusCensusBlock]
		,A.[MobileHomeInd] = B.[MobileHomeInd]
		,A.[TimeshareCode] = B.[TimeshareCode]
		,A.[SchoolDistrictName] = B.[SchoolDistrictName]
		,A.[LotSizeFrontageFeet] = B.[LotSizeFrontageFeet]
		,A.[LotSizeDepthFeet] = B.[LotSizeDepthFeet]
		,A.[LotSizeAcres] = B.[LotSizeAcres]
		,A.[LotSizeSqFt] = B.[LotSizeSqFt]
		,A.[Owner1CorpInd] = B.[OwnerStd1CorpInd]
		,A.[Owner1LastName] = B.[OwnerStd1LastName]
		,A.[Owner1FirstName] = B.[OwnerStd1FirstName]
		,A.[Owner1MiddleName] = B.[OwnerStd1MiddleName]
		,A.[Owner1Suffix] = B.[OwnerStd1Suffix]
		,A.[Owner2CorpInd] = B.[OwnerStd2CorpInd]
		,A.[Owner2LastName] = B.[OwnerStd2LastName]
		,A.[Owner2FirstName] = B.[OwnerStd2FirstName]
		,A.[Owner2MiddleName] = B.[OwnerStd2MiddleName]
		,A.[Owner2Suffix] = B.[OwnerStd2Suffix]
		,A.[OwnerNAME1FULL] = B.[OwnerStdNAME1FULL]
		,A.[OwnerNAME2FULL] = B.[OwnerStdNAME2FULL]
		,A.[OwnerOccupied] = B.[OwnerOccupied]
		,A.[Owner1OwnershipRights] = B.[OwnerStd1OwnershipRights]
		,A.[MailingFullStreetAddress] = B.[MailingStdFullStreetAddress]
		,A.[MailingHouseNbr] = B.[MailingStdHouseNbr]
		,A.[MailingHouseNbrSuffix] = B.[MailingStdHouseNbrSuffix]
		,A.[MailingDirectionLeft] = B.[MailingStdDirectionLeft]
		,A.[MailingStreet] = B.[MailingStdStreet]
		,A.[MailingMode] = B.[MailingStdMode]
		,A.[MailingDirectionRight] = B.[MailingStdDirectionRight]
		,A.[MailingUnitType] = B.[MailingStdUnitType]
		,A.[MailingUnitNbr] = B.[MailingStdUnitNbr]
		,A.[MailingCity] = B.[MailingStdCity]
		,A.[MailingState] = B.[MailingStdState]
		,A.[MailingZIP5] = B.[MailingStdZIP5]
		,A.[MailingZIP4] = B.[MailingStdZIP4]
		,A.[MailingCarrierCode] = B.[MailingStdCarrierCode]
		,A.[MailingOptOut] = B.[MailingOptOut]
		,A.[MailingCOName] = B.[MailingCareOfName]
		,A.[MailingForeignAddressInd] = B.[MailForeignAddrInd]
		,A.[AssdTotalValue] = B.[AssdTotalValue]
		,A.[AssdLandValue] = B.[AssdLandValue]
		,A.[AssdImprovementValue] = B.[AssdImprovementValue]
		,A.[MarketTotalValue] = B.[MarketTotalValue]
		,A.[MarketValueLand] = B.[MarketValueLand]
		,A.[MarketValueImprovement] = B.[MarketValueImprovement]
		,A.[TaxAmt] = B.[TaxAmount]
		,A.[TaxYear] = B.[TaxYear]
		,A.[TaxDeliquentYear] = B.[TaxDeliquentYear1]
		,A.[MarketYear] = B.[MarketValueYear]
		,A.[AssdYear] = B.[AssdYear]
		,A.[TaxRateCodeArea] = B.[TaxRateCodeArea]
		,A.[SchoolTaxDistrict1Code] = B.[SchoolTaxDistrict1Code]
		,A.[SchoolTaxDistrict2Code] = B.[SchoolTaxDistrict2Code]
		,A.[SchoolTaxDistrict3Code] = B.[SchoolTaxDistrict3Code]
		,A.[HomesteadInd] = B.[HomesteadInd]
		,A.[VeteranInd] = B.[VeteranInd]
		,A.[DisabledInd] = B.[DisabledInd]
		,A.[WidowInd] = B.[WidowInd]
		,A.[SeniorInd] = B.[SeniorInd]
		,A.[SchoolCollegeInd] = B.[SchoolCollegeInd]
		,A.[ReligiousInd] = B.[ReligiousInd]
		,A.[WelfareInd] = B.[WelfareInd]
		,A.[PublicUtilityInd] = B.[PublicUtilityInd]
		,A.[CemeteryInd] = B.[CemeteryInd]
		,A.[HospitalInd] = B.[HospitalInd]
		,A.[LibraryInd] = B.[LibraryInd]
		,A.[BuildingArea] = B.[BuildingArea]
		,A.[BuildingAreaInd] = B.[BuildingAreaInd]
		,A.[SumBuildingSqFt] = B.[SumBuildingSqFt]
		,A.[SumLivingAreaSqFt] = B.[SumLivingAreaSqFt]
		,A.[SumGroundFloorSqFt] = B.[SumGroundFloorSqFt]
		,A.[SumGrossAreaSqFt] = B.[SumGrossAreaSqFt]
		,A.[SumAdjAreaSqFt] = B.[SumAdjAreaSqFt]
		,A.[AtticSqFt] = B.[AtticSqFt]
		,A.[AtticUnfinishedSqFt] = B.[AtticUnfinSqFt]
		,A.[AtticFinishedSqFt] = B.[AtticFinishSqFt]
		,A.[SumBasementSqFt] = B.[SumBasementSqFt]
		,A.[BasementUnfinishedSqFt] = B.[BasementUnfinSqFt]
		,A.[BasementFinishedSqFt] = B.[BasementFinishSqFt]
		,A.[SumGarageSqFt] = B.[SumGarageSqFt]
		,A.[GarageUnFinishedSqFt] = B.[GarageUnFinSqFt]
		,A.[GarageFinishedSqFt] = B.[GarageFinishSqFt]
		,A.[YearBuilt] = B.[YearBuilt]
		,A.[EffectiveYearBuilt] = B.[EffectiveYearBuilt]
		,A.[Bedrooms] = B.[Bedrooms]
		,A.[TotalRooms] = B.[TotalRooms]
		,A.[BathTotalCalc] = B.[BathTotalCalc]
		,A.[BathFull] = B.[BathFull]
		,A.[BathsPartialNbr] = B.[BathsParcialNbr]
		,A.[BathFixturesNbr] = B.[BathFixturesNbr]
		,A.[Amenities] = B.[Amenities]
		,A.[AirConditioningCode] = B.[AirConditioningCode]
		,A.[BasementCode] = B.[BasementCode]
		,A.[BuildingClassCode] = B.[BuildingClassCode]
		,A.[BuildingConditionCode] = B.[BuildingConditionCode]
		,A.[ConstructionTypeCode] = B.[ConstructionTypeCode]
		,A.[DeckInd] = B.[DeckCode]
		,A.[ExteriorWallsCode] = B.[ExteriorWallsCode]
		,A.[InteriorWallsCode] = B.[InteriorWallsCode]
		,A.[FireplaceCode] = B.[FireplaceCode]
		,A.[FloorCoverCode] = B.[FloorCoverCode]
		,A.[Garage] = B.[Garage]
		,A.[HeatCode] = B.[HeatCode]
		,A.[HeatingFuelTypeCode] = B.[HeatingFuelTypeCode]
		,A.[SiteInfluenceCode] = B.[SiteInfluenceCode]
		,A.[GarageParkingNbr] = B.[GarageParkingNbr]
		,A.[DrivewayCode] = B.[DrivewayCode]
		,A.[OtherRooms] = B.[OtherRooms]
		,A.[PatioCode] = B.[PatioCode]
		,A.[PoolCode] = B.[PoolCode]
		,A.[PorchCode] = B.[PorchCode]
		,A.[BuildingQualityCode] = B.[BuildingQualityCode]
		,A.[RoofCoverCode] = B.[RoofCoverCode]
		,A.[RoofTypeCode] = B.[RoofTypeCode]
		,A.[SewerCode] = B.[SewerCode]
		,A.[StoriesNbrCode] = B.[StoriesNbrCode]
		,A.[StyleCode] = B.[StyleCode]
		,A.[SumResidentialUnits] = B.[SumResidentialUnits]
		,A.[SumBuildingsNbr] = B.[SumBuildingsNbr]
		,A.[SumCommercialUnits] = B.[SumCommercialUnits]
		,A.[TopographyCode] = B.[TopographyCode]
		,A.[WaterCode] = B.[WaterCode]
		,A.[LotCode] = B.[LotCode]
		,A.[LotNbr] = B.[LotNumber]
		,A.[LandLot] = B.[LandLot]
		,A.[Block] = B.[Block]
		,A.[Section] = B.[Section]
		,A.[District] = B.[District]
		,A.[LegalUnit] = B.[LegalUnit]
		,A.[Municipality] = B.[Municipality]
		,A.[SubdivisionName] = B.[SubdivisionName]
		,A.[SubdivisionPhaseNbr] = B.[SubdivisionPhaseNbr]
		,A.[SubdivisionTractNbr] = B.[SubdivisionTractNbr]
		,A.[Meridian] = B.[Meridian]
		,A.[AssessorsMapRef] = B.[AssessorsMapRef1]
		,A.[LegalDescription] = B.[LegalDescription]
		,A.[CurrentSaleTransactionId] = B.[CurrentSaleTransactionId]
		,A.[CurrentSaleDocNbr] = B.[CurrSaleInputDocNbr]
		,A.[CurrentSaleBook] = B.[CurrSaleInputBook]
		,A.[CurrentSalePage] = B.[CurrSaleInputPage]
		,A.[CurrentSaleRecordingDate] = B.[CurrSaleRecordingDate]
		,A.[CurrentSaleContractDate] = B.[CurrSaleContractDate]
		,A.[CurrentSaleDocumentType] = B.[CurrSaleDocumentType]
		,A.[CurrentSalesPrice] = B.[CurrSalesPrice]
		,A.[CurrentSalesPriceCode] = B.[CurrSalesPriceCode]
		,A.[CurrentSaleBuyer1FullName] = B.[CurrSaleBuyer1FullName]
		,A.[CurrentSaleBuyer2FullName] = B.[CurrSaleBuyer2FullName]
		,A.[CurrentSaleSeller1FullName] = B.[CurrSaleSeller1FullName]
		,A.[CurrentSaleSeller2FullName] = B.[CurrSaleSeller2FullName]
		,A.[ConcurrentMtg1DocNbr] = B.[ConCurrMtg1InputDocNbr]
		,A.[ConcurrentMtg1Book] = B.[ConCurrMtg1InputBook]
		,A.[ConcurrentMtg1Page] = B.[ConCurrMtg1InputPage]
		,A.[ConcurrentMtg1RecordingDate] = B.[ConCurrMtg1RecordingDt]
		,A.[ConcurrentMtg1LoanAmt] = B.[ConCurrMtg1LoanAmt]
		,A.[ConcurrentMtg1Lender] = B.[ConCurrMtg1Lender]
		,A.[ConcurrentMtg1Term] = B.[ConCurrMtg1Term]
		,A.[ConcurrentMtg1InterestRate] = B.[ConCurrMtg1InterestRate]
		,A.[ConcurrentMtg1LoanDueDate] = B.[ConCurrMtg1LoanDueDt]
		,A.[ConcurrentMtg1LoanType] = B.[ConCurrMtg1LoanType]
		,A.[ConcurrentMtg1TypeFinancing] = B.[ConCurrMtg1Typefinancing]
		,A.[ConcurrentMtg2DocNbr] = B.[ConCurrMtg2InputDocNbr]
		,A.[ConcurrentMtg2Book] = B.[ConCurrMtg2InputBook]
		,A.[ConcurrentMtg2Page] = B.[ConCurrMtg2InputPage]
		,A.[ConcurrentMtg2RecordingDate] = B.[ConCurrMtg2RecordingDt]
		,A.[ConcurrentMtg2LoanAmt] = B.[ConCurrMtg2LoanAmt]
		,A.[ConcurrentMtg2Lender] = B.[ConCurrMtg2Lender]
		,A.[ConcurrentMtg2Term] = B.[ConCurrMtg2Term]
		,A.[ConcurrentMtg2InterestRate] = B.[ConCurrMtg2InterestRate]
		,A.[ConcurrentMtg2LoanDueDate] = B.[ConCurrMtg2LoanDueDt]
		,A.[ConcurrentMtg2LoanType] = B.[ConCurrMtg2LoanType]
		,A.[ConcurrentMtg2Typefinancing] = B.[ConCurrMtg2Typefinancing]
		,A.[PrevSaleTransactionId] = B.[PrevSaleTransactionId]
		,A.[PrevSaleDocNbr] = B.[PrevSaleInputDocNbr]
		,A.[PrevSaleBook] = B.[PrevSaleInputBook]
		,A.[PrevSalePage] = B.[PrevSaleInputPage]
		,A.[PrevSaleRecordingDate] = B.[PrevSaleRecordingDate]
		,A.[PrevSaleContractDate] = B.[PrevSaleContractDate]
		,A.[PrevSaleDocumentType] = B.[PrevSaleDocumentType]
		,A.[PrevSalesPrice] = B.[PrevSalesPrice]
		,A.[PrevSalesPriceCode] = B.[PrevSalesPriceCode]
		,A.[PrevSaleBuyer1FullName] = B.[PrevSaleBuyer1FullName]
		,A.[PrevSaleBuyer2FullName] = B.[PrevSaleBuyer2FullName]
		,A.[PrevSaleSeller1FullName] = B.[PrevSaleSeller1FullName]
		,A.[PrevSaleSeller2FullName] = B.[PrevSaleSeller2FullName]
		,A.[PrevMtg1DocNbr] = B.[PrevMtg1InputDocNbr]
		,A.[PrevMtg1Book] = B.[PrevMtg1InputBook]
		,A.[PrevMtg1Page] = B.[PrevMtg1InputPage]
		,A.[PrevMtg1RecordingDate] = B.[PrevMtg1RecordingDt]
		,A.[PrevMtg1LoanAmt] = B.[PrevMtg1LoanAmt]
		,A.[PrevMtg1Lender] = B.[PrevMtg1Lender]
		,A.[PrevMtg1Term] = B.[PrevMtg1Term]
		,A.[PrevMtg1InterestRate] = B.[PrevMtg1InterestRate]
		,A.[PrevMtg1LoanDueDate] = B.[PrevMtg1LoanDueDt]
		,A.[PrevMtg1LoanType] = B.[PrevMtg1LoanType]
		,A.[PrevMtg1TypeFinancing] = B.[PrevMtg1Typefinancing]
		,A.[FATimeStamp] = B.[FATimestamp]
		,A.[FARecordType] = B.[FAUCIDFlag]


		FROM [zCust_Pinnacle].[dbo].[x_Custom_OUTPUT] as A join 
		[data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) 
		on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID
		--where B.FAUCIDFlag not like 'D'
		
		
		Update [zCust_Pinnacle].[dbo].[x_custom_OUTPUT]
		SET PropertyFound = CASE WHEN PropertyID is not null and PropertyID not like '0' and PropertyID not like '' THEN 'Property Found' ELSE 'Property Not Found' END

		
		UPDATE [zCust_Pinnacle].[dbo].[a] SET PropertyFound = 'Multiple Properties Found' 
		FROM [zCust_Pinnacle].[dbo].[x_custom_OUTPUT] a join [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT UniqueID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

	
	
		Select PropertyFound,count(*) From [zCust_Pinnacle].[dbo].[x_custom_OUTPUT]
		Group by PropertyFound

		
		Select top 10000 A.[INPUT UniqueID],A.FIPS, [INPUT PropertyID], [INPUT Address], [INPUT APN], [INPUT FIPS] 
		,B.State, B.[County Name]
		From [zCust_Pinnacle].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		where PropertyFound  like 'Multiple Properties Found'
		Order by [INPUT UniqueID], PropertyID

		--Select RAW_ID, UNFORMATTED_APN, SITUS_HOUSE_NBR, SITUS_STREET_NAME From a_PropMatches_FLANK
		--where RAW_ID in (7495)
		--Order by RAW_ID, UNFORMATTED_APN


		--Select FIPS, FormattedAPN, SitusStdFullStreetAddress, SitusStdCity,SitusStdZIP5,FAUCIDFlag From data.dbo.Property with(NOLOCK)
		--where FIPS = '53063'
		--and FormattedAPN in ('P1056.1040','P1056.2320','P1056.3240','P1056.0148','P1056.0160','P1056.0110','P1056.0400','P1056.2240','P1056.0270','P1056.2840','P1056.0560'
		--,'P1056.2120','P1056.0210','P1056.1200','P1056.1480')



		Select [INPUT UniqueID],[INPUT PropertyID], [INPUT Address],[INPUT City],[INPUT Zip], [INPUT APN], [INPUT FIPS]
		,PropertyID, SitusFullStreetAddress, APN
		From [zCust_Pinnacle].[dbo].[x_custom_OUTPUT] where PropertyID in (
			Select PropertyID from (
			Select PropertyID,count(*) T From [zCust_Pinnacle].[dbo].[x_custom_OUTPUT]
			where PropertyID not like '0' and PropertyID is not null
			Group by PropertyID
			having count(*) > 1)A)
		Order by PropertyID



		Truncate table [Jobs_Lkup].[dbo].[Pinnacle_Shape_TO_PULL]
		Insert into [Jobs_Lkup].[dbo].[Pinnacle_Shape_TO_PULL]
		Select Distinct PROPERTYID 
		From [zCust_Pinnacle].[dbo].[x_custom_OUTPUT]
		where PROPERTYID is not null and PROPERTYID not like '' and PROPERTYID not like '0'

		Select count(*) From [Jobs_Lkup].[dbo].[Pinnacle_Shape_TO_PULL]

		


		Select top 100 [INPUT UniqueID],[INPUT APN] ,FIPS, PROPERTYID, APN
		
		From [zCust_Pinnacle].[dbo].[x_Custom_OUTPUT]
		where [INPUT APN] like '103-280-60-00-6%'
		
		Select * From [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
		where RAW_ID in ('9378','9379')

		

END





