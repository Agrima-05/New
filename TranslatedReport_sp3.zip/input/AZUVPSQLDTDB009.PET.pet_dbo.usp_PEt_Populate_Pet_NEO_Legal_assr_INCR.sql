/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_PEt_Populate_Pet_NEO_Legal_assr_INCR | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE
	

 PROCEDURE [PET].[pet_dbo].[usp_PEt_Populate_Pet_NEO_Legal_assr_INCR] @Fips INT = NULL
	,@Refresh BIT = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
-- declare  @Fips INT = NULL ,@Refresh BIT = 0 ,@ERROR VARCHAR(500) 
BEGIN
	BEGIN TRY
		EXEC [PET].[dbo].[AddPetlog] 55555
			,N'info'
			,N'usp_PEt_Populate_Pet_NEO_Legal_assr_INCR'
			,N'Started'

		--   declare  @Fips INT = 1 	,@Refresh BIT = 0 , @ERROR VARCHAR(500) 
		DECLARE @incremental_flag BIT = 1

		IF @Refresh = 0
		BEGIN
			-- select top 100 * from    PET.pet_tmp.Pet_assr_incr_tracker
			DROP TABLE

			IF EXISTS [PET].[pet_tmp].[Pet_assr_incr_tracker]
				CREATE TABLE [PET].[pet_tmp].[Pet_assr_incr_tracker] (
					[Fips] [int] NOT NULL
					,[DateStarted] [datetime] NULL
					,[DateEnded] [datetime] NULL
					)

			INSERT INTO [Pet].[pet_tmp].[Pet_assr_incr_tracker] (
				[Fips]
				,[DateStarted]
				,[DateEnded]
				)
			SELECT fips
				,NULL AS DateStarted
				,NULL AS DateEnded
			FROM (
				SELECT DISTINCT Fips
						
				FROM [pet].[pet_tmp].[pet_apn_wrk] a
				OUTER APPLY (
					SELECT Prod_SSIS_connection
						,Stage_SSIS_connection
					FROM [PET].[dbo].[pet_counties]
					WHERE fips = a.fips
					) c
				WHERE (
						c.Prod_SSIS_connection IS NOT NULL
						OR c.Stage_SSIS_connection IS NOT NULL
						)
				) n
				where n.fips not in (15003)

			--where n.fips >= 30000
			--DECLARE @fips_a CHAR(5) = NULL
			--SET @datefrom_a = Replace(cast(@datefrom AS NVARCHAR(24)), '-', '')
			--SET @dateto_a = Replace(cast(@dateto AS NVARCHAR(24)), '-', '')
			--
			SELECT @fips = min(fips)
			FROM [Pet].[pet_tmp].[Pet_assr_incr_tracker]
			WHERE DateStarted IS NULL

			--SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
			--
			--begin the loop for the Fips
			DECLARE @return_value INT = 0
			DECLARE @rowcount INT = 0

			--
			WHILE @fips IS NOT NULL
				AND @fips > 0
			BEGIN
				--
				--Udpate the control trable to say you are workig on the fips
				--
				BEGIN
					UPDATE [Pet].[pet_tmp].[Pet_assr_incr_tracker]
					SET DateStarted = getdate()
					WHERE fips = @fips
				END

				RAISERROR (
						'%s Busy with Fips %s'
						,0
						,1
						,' '
						,' '
						)
				WITH NOWAIT

				--
				-- here the logic start that you  wnat to run by fips
				--
				-- Declare @fips int = 26025
				DROP TABLE

				IF EXISTS [pet].[pet_tmp].[Incr_Dist_Apn]
					--SELECT a.fips
					--	,a.NEO_APN
					--	,cast(SPDB.dbo.RegexReplace(a.NEO_APN, '(\/| |-|\.)', '', 0) AS VARCHAR(100)) AS strippedAPN
					--	,cast(SPDB.dbo.RegexReplace(a.NEO_APN, '( )', '', 0) AS VARCHAR(100)) AS spaceAPN
					SELECT DISTINCT b.*
					INTO [pet].[pet_tmp].[Incr_Dist_Apn]
					FROM (
						SELECT fips
							,NEO_APN
							,count(1) AS cnt
						FROM [pet].[dbo].[pet_NEO_Xref_FULL] WITH (
								NOLOCK
								,INDEX (ixb)
								)
						WHERE fips = @fips
						GROUP BY fips
							,NEO_APN
						) a
					OUTER APPLY (
						SELECT a.fips
							,a.neo_apn
							,a.neo_apn AS apn_m
						
						UNION ALL
						
						SELECT a.fips
							,a.neo_apn
							,cast([SPDB].[dbo].[RegexReplace](a.NEO_APN, '(\/| |-|\.)', '', 0) AS VARCHAR(100)) AS apn_m
						
						UNION ALL
						
						SELECT a.fips
							,a.neo_apn
							,cast([SPDB].[dbo].[RegexReplace](a.NEO_APN, '( )', '', 0) AS VARCHAR(100)) AS apn_m
						) b
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);

				CREATE INDEX idx_fips_apn ON [pet].[pet_tmp].[Incr_Dist_Apn] (
					fips
					,apn_m
					) INCLUDE (neo_apn)

				DROP TABLE

				IF EXISTS [pet].[pet_tmp].[Incr_apn_wrk]
					SELECT DISTINCT a.REF_ID
						,a.FIPS
						,a.APN_Type
						,a.APN
					INTO [pet].[pet_tmp].[Incr_apn_wrk]
					FROM [pet].[pet_tmp].[pet_apn_wrk] a WITH (
							NOLOCK
							,INDEX (idx_fips_apn_type)
							)
					CROSS APPLY (
						SELECT *
						FROM [pet].[dbo].[pet_fips_apn_type] b WITH (
								NOLOCK
								,INDEX (fips_apn_type_NEO)
								)
						WHERE b.fips = a.fips
							AND b.APN_Type = a.APN_Type
							AND b.NEO_PET = 1
						) b
					WHERE a.fips = @fips
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);

				CREATE INDEX idx_fips_apn ON [pet].[pet_tmp].[Incr_apn_wrk] (
					fips
					,apn
					)

				DROP TABLE

				IF EXISTS [pet].[pet_tmp].[Incr_apn_match_1]
					SELECT DISTINCT k.*
					--,ROW_NUMBER() OVER (
					--	PARTITION BY ref_id
					--	,apn_type ORDER BY (
					--			SELECT 0
					--			)
					--	) AS ROW4
					INTO [pet].[pet_tmp].[Incr_apn_match_1]
					FROM (
						SELECT DISTINCT p.[REF_ID]
							,a.[FIPS]
							,'NEOF' AS apn_type
							,0 AS [APN_ID]
							,LTRIM(RTRIM(a.NEO_APN)) AS [APN]
							,getdate() AS [created]
							,NULL AS [updated]
						FROM [pet].[pet_tmp].[Incr_apn_wrk] p WITH (
								NOLOCK
								,INDEX (idx_fips_apn)
								)
						INNER JOIN [pet].[pet_tmp].[Incr_Dist_Apn] a WITH (
								NOLOCK
								,INDEX (idx_fips_apn)
								) ON a.Fips = p.Fips
							AND a.apn_m = p.APN
							--INNER JOIN Pet.tmp.Pet_Fips_Apn_type_Inserts f WITH (INDEX (fips_apn_type_NEO)) ON f.Fips = p.Fips
							--	AND f.Apn_type = p.Apn_type
							--	AND f.NEO_PET = 1
						) k
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);

				--CREATE INDEX ixa ON pet.pet_tmp.Incr_apn_match_1 (row4)
				CREATE INDEX idx_fips_apn ON [pet].[pet_tmp].[Incr_apn_match_1] (
					fips
					,APN
					)

				--
				-- Remove Pet_neo_legals for incremental ref_ids - they will be added back if still needed
				-- 
				DELETE pl
				FROM [pet].[dbo].[pet_neo_legals] pl
				INNER JOIN [PET].[pet_tmp].[PET_WRK] pw WITH (
						NOLOCK
						,INDEX (idx_fips_with_ref_id)
						) --with(nolock,index(IDX_FIPS_REF_ID))
					ON pw.fips = pl.fips
					AND pw.ref_id = pl.ref_id
				WHERE pl.fips = @fips
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);




				TRUNCATE TABLE [pet].[pet_tmp].[PET_NEO_LEGALS]

				INSERT INTO [pet].[pet_tmp].[PET_NEO_LEGALS] (
					[FIPS]
					,[REF_ID]
					,[NEO_LAND_TYPE]
					,[NEO_TITLE_LEGAL]
					,[NEO_APN]
					,[PORTION_IND]
					,[NEO_TITLE_LEGAL_18]
					)
				SELECT xr.[FIPS]
					,a.[REF_ID]
					,xr.[NEO_LAND_TYPE]
					,xr.[NEO_TITLE_LEGAL]
					,xr.[NEO_APN]
					,xr.[PORTION_IND]
					,substring(xr.[NEO_TITLE_LEGAL], 1, 18) AS NEO_TITLE_LEGAL_18
				FROM [pet].[pet_tmp].[Incr_apn_match_1] a WITH (
						NOLOCK
						,INDEX (idx_fips_apn)
						)
				INNER JOIN [pet].[dbo].[pet_neo_xref_full] xr WITH (
						NOLOCK
						,INDEX (ixb)
						) ON xr.fips = a.fips
					AND xr.neo_apn = a.apn
				CROSS APPLY (
					SELECT count(1) AS lgl_cnt
					FROM [pet].[dbo].[pet_neo_legals] pl WITH (
							NOLOCK
							,INDEX (Ixuc_fips_ref_id_neo_legal)
							)
					WHERE pl.fips = a.fips
						AND pl.ref_id = a.ref_id
						AND pl.neo_apn = a.apn
						AND isnull(pl.NEO_TITLE_LEGAL, '') = isnull(xr.NEO_TITLE_LEGAL, '')
					) pl
				WHERE pl.lgl_cnt = 0
					AND xr.NEO_TITLE_LEGAL > ''
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

				--
				-- add neo apn to pet_apn
				--
				--
				INSERT INTO [Pet].[dbo].[PET_APN] (
					[REF_ID]
					,[FIPS]
					,[APN_Type]
					,[APN_ID]
					,[APN]
					,[created]
					,[updated]
					)

					SELECT a.*
					FROM (
						SELECT [REF_ID]
							,[FIPS]
							,[APN_Type]
							,[APN_ID]
							,[APN]
							,getdate() AS created
							,[updated]
						FROM [pet].[pet_tmp].[Incr_apn_match_1]
	
						UNION
	
						SELECT [REF_ID]
							,[FIPS]
							,'NEO' AS [APN_Type]
							,[APN_ID]
							,[APN]
							,[created]
							,[updated]
						FROM [pet].[pet_tmp].[Incr_apn_match_1]
						) a
					OUTER APPLY (
						SELECT ref_id
						FROM [pet].[dbo].[pet_apn] pa WITH (
								NOLOCK
								,INDEX (fips_ref_id_apntype)
								)
						WHERE pa.fips = a.fips
							AND pa.ref_id = a.ref_id
							AND pa.APN_Type = a.apn_type
						) pa
					WHERE pa.ref_id IS NULL
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);



				INSERT INTO [pet].[dbo].[PET_NEO_LEGALS] (
					[FIPS]
					,[REF_ID]
					,[NEO_LAND_TYPE]
					,[NEO_TITLE_LEGAL]
					,[NEO_APN]
					,[PORTION_IND]
					,[NEO_TITLE_LEGAL_18]
					,[created]
					)
				SELECT [FIPS]
					,[REF_ID]
					,[NEO_LAND_TYPE]
					,[NEO_TITLE_LEGAL]
					,[NEO_APN]
					,[PORTION_IND]
					,[NEO_TITLE_LEGAL_18]
					,getdate() as created
				FROM [pet].[pet_tmp].[PET_NEO_LEGALS] a
				OUTER APPLY (
					SELECT count(1) AS cnt
					FROM [pet].[dbo].[pet_neo_legals] pl WITH (
							NOLOCK
							,INDEX (Ixuc_fips_ref_id_neo_legal)
							)
					WHERE pl.FIPS = a.FIPS
						AND pl.REF_ID = a.REF_ID
						AND pl.NEO_APN = a.NEO_APN
						AND isnull(pl.NEO_TITLE_LEGAL, '') = isnull(a.NEO_TITLE_LEGAL, '')
					) pl
				WHERE pl.cnt = 0
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

				--
				--
				--
				DROP TABLE

				IF EXISTS [pet].[pet_tmp].[usp_PEt_Populate_Pet_NEO_Legal_assr_INCR_pet_lg_cnt]
					SELECT a.[FIPS]
						,a.[REF_ID]
						,SUM(1) AS NEO_LEGAL_CNT
						,SUM(CASE 
								WHEN a.[NEO_LAND_TYPE] = 'AN'
									THEN 1
								ELSE 0
								END) AS NEO_LAND_TYPE_AN
						,SUM(CASE 
								WHEN a.[NEO_LAND_TYPE] = 'AT'
									THEN 1
								ELSE 0
								END) AS NEO_LAND_TYPE_AT
						,SUM(CASE 
								WHEN a.[NEO_LAND_TYPE] = 'MC'
									THEN 1
								ELSE 0
								END) AS NEO_LAND_TYPE_MC
						,SUM(CASE 
								WHEN a.[NEO_LAND_TYPE] = 'SB'
									THEN 1
								ELSE 0
								END) AS NEO_LAND_TYPE_SB
						,SUM(CASE 
								WHEN a.[NEO_LAND_TYPE] = 'SC'
									THEN 1
								ELSE 0
								END) AS NEO_LAND_TYPE_SC
					INTO [pet].[pet_tmp].[usp_PEt_Populate_Pet_NEO_Legal_assr_INCR_pet_lg_cnt]
					FROM [pet].[dbo].[PET_NEO_LEGALS] a
					CROSS APPLY (
						SELECT DISTINCT fips
							,ref_id
						FROM [pet].[pet_tmp].[Incr_apn_wrk] b
						WHERE b.fips = a.fips
							AND b.ref_id = a.ref_id
						) b
					--INNER JOIN pet.pet_tmp.Incr_apn_wrk b ON b.fips = a.fips
					--	AND b.ref_id = a.ref_id
					GROUP BY a.[FIPS]
						,a.[REF_ID]
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);

				CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_PEt_Populate_Pet_NEO_Legal_assr_INCR_pet_lg_cnt] (
					fips
					,ref_id
					)

				UPDATE [PET].[pet_dbo].[a]
				SET a.NEO_LEGAL_CNT = b.NEO_LEGAL_CNT
					,a.NEO_LAND_TYPE_AN = b.NEO_LAND_TYPE_AN
					,a.NEO_LAND_TYPE_AT = b.NEO_LAND_TYPE_AT
					,a.NEO_LAND_TYPE_MC = b.NEO_LAND_TYPE_MC
					,a.NEO_LAND_TYPE_SB = b.NEO_LAND_TYPE_SB
					,a.NEO_LAND_TYPE_SC = b.NEO_LAND_TYPE_SC
				FROM [pet].[dbo].[pet] a WITH (
						NOLOCK
						,INDEX (IDX_FIPS_REF_ID_X)
						)
				INNER JOIN [pet].[pet_tmp].[usp_PEt_Populate_Pet_NEO_Legal_assr_INCR_pet_lg_cnt] b WITH (
						NOLOCK
						,INDEX (idx_fips_ref_id)
						) ON b.fips = a.fips
					AND b.ref_id = a.ref_id
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

				TRUNCATE TABLE [pet].[pet_tmp].[Pet_Incremental_Add]

				INSERT INTO [pet].[pet_tmp].[Pet_Incremental_Add] (
					FIPS
					,NEO_APN
					,NEO_LAND_TYPE
					,NEO_TITLE_LEGAL
					,PORTION_IND
					)
				SELECT FIPS
					,NEO_APN
					,NEO_LAND_TYPE
					,NEO_TITLE_LEGAL
					,PORTION_IND
				FROM [pet].[pet_tmp].[PET_NEO_LEGALS]
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

				--
				--Parse Neo Legal
				-- 

				EXEC [Pet].[pet_dbo].[usp_ProcessPetCounty_3_Multi_Legals_Incr] @fips = @fips
					,@incremental_flag = 1
					,@ERROR = @ERROR

				--
				-- Calculate ARB 
				-- 
				--EXEC [PET].[pet_dbo].[ProcessARB_incr] @Fips = @fips ,@ERROR = @ERROR
				EXEC [PET].[pet_dbo].[ProcessARB_incr] @Fips = @fips ,@ERROR = @ERROR

				
								
				DROP TABLE

				IF EXISTS [pet].[pet_tmp].[Incr_pet_ref_ids]
					SELECT DISTINCT fips
						,ref_id
					INTO [pet].[pet_tmp].[Incr_pet_ref_ids]
					FROM [pet].[pet_tmp].[pet_apn_wrk] a WITH (
							NOLOCK
							,INDEX (fips_ref_id_apntype)
							)
					WHERE a.fips = @fips
					OPTION (
						RECOMPILE
						,MAXDOP 12
						,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
						);

				CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[Incr_pet_ref_ids] (
					fips
					,ref_id
					)

				TRUNCATE TABLE [PET].[pet_tmp].[Pet_Incremental_REF_ID]

				INSERT INTO [PET].[pet_tmp].[Pet_Incremental_REF_ID] (
					NEO_TITLE_LEGAL
					,REF_ID
					,PORTION_IND
					,fips
					,NEO_APN
					)
				--SELECT NEO_TITLE_LEGAL
				--	,REF_ID
				--	,PORTION_IND
				--	,fips
				--	,NEO_APN
				--FROM pet.pet_tmp.PET_NEO_LEGALS
				SELECT a.NEO_TITLE_LEGAL
					,a.REF_ID
					,a.PORTION_IND
					,a.fips
					,a.NEO_APN
				FROM [pet].[dbo].[PET_NEO_LEGALS] a WITH (
						NOLOCK
						,INDEX (ix_fips_ref_id)
						)
				INNER JOIN [pet].[pet_tmp].[Incr_pet_ref_ids] w WITH (
						NOLOCK
						,INDEX (idx_fips_ref_id)
						) ON w.fips = a.fips
					AND w.ref_id = a.ref_id
				ORDER BY a.fips
					,a.ref_id
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

				EXEC [Pet].[pet_dbo].[usp_Update_Pet_With_Legal_INCR] @fips = @fips
					,@ERROR = @ERROR

				SET @rowcount = @@rowcount

				RAISERROR (
						'%s updated  %d'
						,0
						,1
						,''
						,@rowcount
						)

				--
				--Update the control table to indicate you are done
				--
				BEGIN
					UPDATE [Pet].[pet_tmp].[Pet_assr_incr_tracker]
					SET DateEnded = getdate()
					WHERE fips = @fips
				END

				--
				--Select the new fips to process - if non found then @fips would be null
				--
				SELECT @fips = min(fips)
				FROM [Pet].[pet_tmp].[Pet_assr_incr_tracker]
				WHERE DateStarted IS NULL
					--SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
			END
		END

		EXEC [PET].[dbo].[AddPetlog] 55555
			,N'info'
			,N'usp_PEt_Populate_Pet_NEO_Legal_assr_INCR'
			,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


