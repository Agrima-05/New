/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Merge_RAS_From_RAS_work | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Merge_RAS_From_RAS_work] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG: 
==========
who		date		change
Marie	2023-10-03	Initial Creation - Merge Ras_work to Ras
 
******************************************************************************************************************/
BEGIN TRY
	EXEC [lien_DTDB].[infc].[AddinfcLog] N'info'
		,N'UR_Merge_RAS_From_RAS_work'
		,N'Started'

	/*
	Make sure all columns will have  a null value instead of a space
	*/
	DROP TABLE

	IF EXISTS #Temp
		SELECT nullif(w.FIPS, 0) AS FIPS
			,nullif(w.REF_ID, 0) AS REF_ID
			,nullif(w.US_State, '') AS US_State
			,nullif(w.US_County, '') AS US_County
			,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
			,nullif(w.Update_Timestamp, '') AS Update_Timestamp
			,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
			,nullif(w.Document_Type, '') AS Document_Type
			,nullif(w.Document_Date, '') AS Document_Date
			,nullif(w.Recording_Date, '') AS Recording_Date
			,nullif(w.Recording_Book, '') AS Recording_Book
			,nullif(w.Recording_Page, '') AS Recording_Page
			,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
			,nullif(w.Loan_Amount, 0) AS Loan_Amount
			,nullif(w.Borrower_First_Name, '') AS Borrower_First_Name
			,nullif(w.Borrower_Full_Name, '') AS Borrower_Full_Name
			,nullif(w.Assignor_Name_Subordinating_Lender_Old, '') AS Assignor_Name_Subordinating_Lender_Old
			,nullif(w.Assignee_Name_Subordinated_Lender_New, '') AS Assignee_Name_Subordinated_Lender_New
			,nullif(w.Original_Lender_Name_Releases, '') AS Original_Lender_Name_Releases
			,nullif(w.Original_Date, '') AS Original_Date
			,nullif(w.Original_Recording_Book, '') AS Original_Recording_Book
			,nullif(w.Original_Recording_Page, '') AS Original_Recording_Page
			,nullif(w.Original_Recording_Instrument_Nbr, '') AS Original_Recording_Instrument_Nbr
			,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
			,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
			,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
			,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
			,nullif(w.Pending_Transaction, '') AS Pending_Transaction
			,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
			,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
			,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
			,nullif(w.Situs_Direction, '') AS Situs_Direction
			,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
			,nullif(w.Situs_Mode, '') AS Situs_Mode
			,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
			,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
			,nullif(w.Situs_City, '') AS Situs_City
			,nullif(w.Situs_State, '') AS Situs_State
			,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
			,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
			,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
			,nullif(w.Created, '') AS Created
			,nullif(w.Updated, '') AS Updated
			,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
			,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
			,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
			,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
			,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
			,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
			,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
			,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
			,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
			,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
			,nullif(w.Source_Type, '') AS Source_Type
			,nullif(w.SRC_TBL, '') AS SRC_TBL
			,nullif(w.DEED_PID, 0) AS DEED_PID
			,nullif(w.SAM_PID, 0) AS SAM_PID
			,nullif(w.LEAP_ID, 0) AS LEAP_ID
			,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
			,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
			,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
			,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
			,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
			,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
			,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
			,nullif(w.MATURITY_DATE, '') AS MATURITY_DATE
			,nullif(w.TITLE_COMPANY, '') AS TITLE_COMPANY
			,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
			,nullif(w.UR_Remarks, '') AS UR_Remarks
		--		,nullif(w.ras_checksum, 0) AS ras_checksum
		INTO #temp
		FROM [lien_DTDB].[INFC].[Ras_work] w

	TRUNCATE TABLE [lien_DTDB].[INFC].[Ras_work]

	INSERT INTO [lien_DTDB].[INFC].[Ras_work] (
		FIPS
		,REF_ID
		,US_State
		,US_County
		,CLGX_Unique_ID
		,Update_Timestamp
		,Add_Change_Delete_Identifier
		,Document_Type
		,Document_Date
		,Recording_Date
		,Recording_Book
		,Recording_Page
		,Recording_Instrument_Nbr
		,Loan_Amount
		,Borrower_First_Name
		,Borrower_Full_Name
		,Assignor_Name_Subordinating_Lender_Old
		,Assignee_Name_Subordinated_Lender_New
		,Original_Lender_Name_Releases
		,Original_Date
		,Original_Recording_Book
		,Original_Recording_Page
		,Original_Recording_Instrument_Nbr
		,Original_Loan_Amount
		,Tax_Id_Nbr_APN_Unformatted
		,APN_Sequence_NBR
		,Tax_Id_Nbr_APN_Formatted
		,Pending_Transaction
		,Situs_House_Nbr
		,Situs_House_Nbr2
		,Situs_House_Nbr_Suffix
		,Situs_Direction
		,Situs_Street_Name
		,Situs_Mode
		,Situs_Post_Direction
		,Situ_Unit_Nbr
		,Situs_City
		,Situs_State
		,Situs_Zip_Code
		,Situs_Carrier_Code
		,Multi_Property_Indicator
		,Created
		,Updated
		,PREVIOUS_PARCEL_NBR
		,PREVIOUS_PARCEL_SEQUENCE_NBR
		,Fmt_Inst_Nbr
		,CMT_ID_Inst_nbr
		,Fmt_Ori_Inst_Nbr
		,CMT_ID_Ori_Inst_nbr
		,Fmt_Book_Page
		,CMT_ID_Book_Page
		,Fmt_Ori_Book_Page
		,CMT_ID_Ori_Book_Page
		,Source_Type
		,SRC_TBL
		,DEED_PID
		,SAM_PID
		,LEAP_ID
		,UR_Doc_Unique_Id
		,UR_Doc_Id
		,UR_Property_Id
		,UR_Name_Id
		,UR_Reference_Id
		,MTG_CLGX_UNIQUE_ID
		,MTG_Source_Type
		,MATURITY_DATE
		,TITLE_COMPANY
		,UR_Prop_Seq_Num
		,UR_Remarks
		)
	SELECT nullif(w.FIPS, 0) AS FIPS
		,nullif(w.REF_ID, 0) AS REF_ID
		,nullif(w.US_State, '') AS US_State
		,nullif(w.US_County, '') AS US_County
		,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
		,nullif(w.Update_Timestamp, '') AS Update_Timestamp
		,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
		,nullif(w.Document_Type, '') AS Document_Type
		,nullif(w.Document_Date, '') AS Document_Date
		,nullif(w.Recording_Date, '') AS Recording_Date
		,nullif(w.Recording_Book, '') AS Recording_Book
		,nullif(w.Recording_Page, '') AS Recording_Page
		,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
		,nullif(w.Loan_Amount, 0) AS Loan_Amount
		,nullif(w.Borrower_First_Name, '') AS Borrower_First_Name
		,nullif(w.Borrower_Full_Name, '') AS Borrower_Full_Name
		,nullif(w.Assignor_Name_Subordinating_Lender_Old, '') AS Assignor_Name_Subordinating_Lender_Old
		,nullif(w.Assignee_Name_Subordinated_Lender_New, '') AS Assignee_Name_Subordinated_Lender_New
		,nullif(w.Original_Lender_Name_Releases, '') AS Original_Lender_Name_Releases
		,nullif(w.Original_Date, '') AS Original_Date
		,nullif(w.Original_Recording_Book, '') AS Original_Recording_Book
		,nullif(w.Original_Recording_Page, '') AS Original_Recording_Page
		,nullif(w.Original_Recording_Instrument_Nbr, '') AS Original_Recording_Instrument_Nbr
		,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
		,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
		,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
		,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
		,nullif(w.Pending_Transaction, '') AS Pending_Transaction
		,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
		,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
		,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
		,nullif(w.Situs_Direction, '') AS Situs_Direction
		,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
		,nullif(w.Situs_Mode, '') AS Situs_Mode
		,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
		,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
		,nullif(w.Situs_City, '') AS Situs_City
		,nullif(w.Situs_State, '') AS Situs_State
		,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
		,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
		,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
		,nullif(w.Created, '') AS Created
		,nullif(w.Updated, '') AS Updated
		,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
		,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
		,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
		,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
		,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
		,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
		,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
		,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
		,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
		,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
		,nullif(w.Source_Type, '') AS Source_Type
		,nullif(w.SRC_TBL, '') AS SRC_TBL
		,nullif(w.DEED_PID, 0) AS DEED_PID
		,nullif(w.SAM_PID, 0) AS SAM_PID
		,nullif(w.LEAP_ID, 0) AS LEAP_ID
		,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
		,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
		,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
		,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
		,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
		,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
		,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
		,nullif(w.MATURITY_DATE, '') AS MATURITY_DATE
		,nullif(w.TITLE_COMPANY, '') AS TITLE_COMPANY
		,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
		,nullif(w.UR_Remarks, '') AS UR_Remarks
	--		,nullif(w.ras_checksum, 0) AS ras_checksum
	FROM #temp w

	BEGIN TRANSACTION

	UPDATE [lien_DTDB].[INFC].[r]
	SET --r.FIPS = nullif(w.FIPS,0)
		r.REF_ID = nullif(w.REF_ID, 0)
		,r.US_State = nullif(w.US_State, '')
		,r.US_County = nullif(w.US_County, '')
		--,r.CLGX_Unique_ID	= nullif(w.CLGX_Unique_ID,0)	
		,r.Update_Timestamp = nullif(w.Update_Timestamp, 0)
		,r.Add_Change_Delete_Identifier = nullif(w.Add_Change_Delete_Identifier, '')
		,r.Document_Type = nullif(w.Document_Type, '')
		,r.Document_Date = nullif(w.Document_Date, '')
		,r.Recording_Date = nullif(w.Recording_Date, '')
		,r.Recording_Book = nullif(w.Recording_Book, '')
		,r.Recording_Page = nullif(w.Recording_Page, '')
		,r.Recording_Instrument_Nbr = nullif(w.Recording_Instrument_Nbr, '')
		,r.Loan_Amount = nullif(w.Loan_Amount, 0)
		,r.Borrower_First_Name = nullif(w.Borrower_First_Name, '')
		,r.Borrower_Full_Name = nullif(w.Borrower_Full_Name, '')
		,r.Assignor_Name_Subordinating_Lender_Old = nullif(w.Assignor_Name_Subordinating_Lender_Old, '')
		,r.Assignee_Name_Subordinated_Lender_New = nullif(w.Assignee_Name_Subordinated_Lender_New, '')
		,r.Original_Lender_Name_Releases = nullif(w.Original_Lender_Name_Releases, '')
		,r.Original_Date = nullif(w.Original_Date, '')
		,r.Original_Recording_Book = nullif(w.Original_Recording_Book, '')
		,r.Original_Recording_Page = nullif(w.Original_Recording_Page, '')
		,r.Original_Recording_Instrument_Nbr = nullif(w.Original_Recording_Instrument_Nbr, '')
		,r.Original_Loan_Amount = nullif(w.Original_Loan_Amount, 0)
		,r.Tax_Id_Nbr_APN_Unformatted = nullif(w.Tax_Id_Nbr_APN_Unformatted, '')
		,r.APN_Sequence_NBR = nullif(w.APN_Sequence_NBR, 0)
		,r.Tax_Id_Nbr_APN_Formatted = nullif(w.Tax_Id_Nbr_APN_Formatted, '')
		,r.Pending_Transaction = nullif(w.Pending_Transaction, '')
		,r.Situs_House_Nbr = nullif(w.Situs_House_Nbr, '')
		,r.Situs_House_Nbr2 = nullif(w.Situs_House_Nbr2, '')
		,r.Situs_House_Nbr_Suffix = nullif(w.Situs_House_Nbr_Suffix, '')
		,r.Situs_Direction = nullif(w.Situs_Direction, '')
		,r.Situs_Street_Name = nullif(w.Situs_Street_Name, '')
		,r.Situs_Mode = nullif(w.Situs_Mode, '')
		,r.Situs_Post_Direction = nullif(w.Situs_Post_Direction, '')
		,r.Situ_Unit_Nbr = nullif(w.Situ_Unit_Nbr, '')
		,r.Situs_City = nullif(w.Situs_City, '')
		,r.Situs_State = nullif(w.Situs_State, '')
		,r.Situs_Zip_Code = nullif(w.Situs_Zip_Code, '')
		,r.Situs_Carrier_Code = nullif(w.Situs_Carrier_Code, '')
		,r.Multi_Property_Indicator = nullif(w.Multi_Property_Indicator, '')
		,r.Created = nullif(w.Created, '')
		,r.Updated = nullif(w.Updated, '')
		,r.PREVIOUS_PARCEL_NBR = nullif(w.PREVIOUS_PARCEL_NBR, '')
		,r.PREVIOUS_PARCEL_SEQUENCE_NBR = nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0)
		,r.Fmt_Inst_Nbr = nullif(w.Fmt_Inst_Nbr, '')
		,r.CMT_ID_Inst_nbr = nullif(w.CMT_ID_Inst_nbr, 0)
		,r.Fmt_Ori_Inst_Nbr = nullif(w.Fmt_Ori_Inst_Nbr, '')
		,r.CMT_ID_Ori_Inst_nbr = nullif(w.CMT_ID_Ori_Inst_nbr, 0)
		,r.Fmt_Book_Page = nullif(w.Fmt_Book_Page, '')
		,r.CMT_ID_Book_Page = nullif(w.CMT_ID_Book_Page, 0)
		,r.Fmt_Ori_Book_Page = nullif(w.Fmt_Ori_Book_Page, '')
		,r.CMT_ID_Ori_Book_Page = nullif(w.CMT_ID_Ori_Book_Page, 0)
		,r.Source_Type = nullif(w.Source_Type, '')
		--,r.SRC_TBL = nullif(w.SRC_TBL, '')	
		,r.DEED_PID = nullif(w.DEED_PID, 0)
		,r.SAM_PID = nullif(w.SAM_PID, 0)
		,r.LEAP_ID = nullif(w.LEAP_ID, 0)
		,r.UR_Doc_Unique_Id = nullif(w.UR_Doc_Unique_Id, '')
		,r.UR_Doc_Id = nullif(w.UR_Doc_Id, 0)
		,r.UR_Property_Id = nullif(w.UR_Property_Id, 0)
		,r.UR_Name_Id = nullif(w.UR_Name_Id, 0)
		--,r.UR_Reference_Id = nullif(w.UR_Reference_Id,0)
		,r.MTG_CLGX_UNIQUE_ID = nullif(w.MTG_CLGX_UNIQUE_ID, 0)
		,r.MTG_Source_Type = nullif(w.MTG_Source_Type, '')
		,r.MATURITY_DATE = nullif(w.MATURITY_DATE, '')
		,r.TITLE_COMPANY = nullif(w.TITLE_COMPANY, '')
		--,r.UR_Prop_Seq_Num = nullif(w.UR_Prop_Seq_Num, '')
		,r.UR_Remarks = nullif(w.UR_Remarks, '')
	-- select  format(count(*), '##,##0') as cnt
	FROM [ras].[dbo].[RAS] r
	INNER JOIN [lien_DTDB].[infc].[RAS_Work] w ON r.Fips = w.fips
		AND isnull(r.UR_Reference_id, 0) = isnull(w.UR_Reference_id, 0)
		--AND ISNULL(r.UR_Prop_Seq_Num, 0) = ISNULL(w.UR_Prop_Seq_Num, 0)
		AND r.CLGX_UNIQUE_ID = w.CLGX_UNIQUE_ID
		AND r.SRC_TBL = w.SRC_TBL
	WHERE r.ras_checksum <> w.ras_checksum

	INSERT INTO [ras].[dbo].[RAS] (
		FIPS
		,REF_ID
		,US_State
		,US_County
		,CLGX_Unique_ID
		,Update_Timestamp
		,Add_Change_Delete_Identifier
		,Document_Type
		,Document_Date
		,Recording_Date
		,Recording_Book
		,Recording_Page
		,Recording_Instrument_Nbr
		,Loan_Amount
		,Borrower_First_Name
		,Borrower_Full_Name
		,Assignor_Name_Subordinating_Lender_Old
		,Assignee_Name_Subordinated_Lender_New
		,Original_Lender_Name_Releases
		,Original_Date
		,Original_Recording_Book
		,Original_Recording_Page
		,Original_Recording_Instrument_Nbr
		,Original_Loan_Amount
		,Tax_Id_Nbr_APN_Unformatted
		,APN_Sequence_NBR
		,Tax_Id_Nbr_APN_Formatted
		,Pending_Transaction
		,Situs_House_Nbr
		,Situs_House_Nbr2
		,Situs_House_Nbr_Suffix
		,Situs_Direction
		,Situs_Street_Name
		,Situs_Mode
		,Situs_Post_Direction
		,Situ_Unit_Nbr
		,Situs_City
		,Situs_State
		,Situs_Zip_Code
		,Situs_Carrier_Code
		,Multi_Property_Indicator
		,Created
		,Updated
		,PREVIOUS_PARCEL_NBR
		,PREVIOUS_PARCEL_SEQUENCE_NBR
		,Fmt_Inst_Nbr
		,CMT_ID_Inst_nbr
		,Fmt_Ori_Inst_Nbr
		,CMT_ID_Ori_Inst_nbr
		,Fmt_Book_Page
		,CMT_ID_Book_Page
		,Fmt_Ori_Book_Page
		,CMT_ID_Ori_Book_Page
		,Source_Type
		,SRC_TBL
		,DEED_PID
		,SAM_PID
		,LEAP_ID
		,UR_Doc_Unique_Id
		,UR_Doc_Id
		,UR_Property_Id
		,UR_Name_Id
		,UR_Reference_Id
		,MTG_CLGX_UNIQUE_ID
		,MTG_Source_Type
		,MATURITY_DATE
		,TITLE_COMPANY
		,UR_Prop_Seq_Num
		,UR_Remarks
		)
	SELECT nullif(w.FIPS, 0) AS FIPS
		,nullif(w.REF_ID, 0) AS REF_ID
		,nullif(w.US_State, '') AS US_State
		,nullif(w.US_County, '') AS US_County
		,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
		,nullif(w.Update_Timestamp, '') AS Update_Timestamp
		,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
		,nullif(w.Document_Type, '') AS Document_Type
		,nullif(w.Document_Date, '') AS Document_Date
		,nullif(w.Recording_Date, '') AS Recording_Date
		,nullif(w.Recording_Book, '') AS Recording_Book
		,nullif(w.Recording_Page, '') AS Recording_Page
		,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
		,nullif(w.Loan_Amount, 0) AS Loan_Amount
		,nullif(w.Borrower_First_Name, '') AS Borrower_First_Name
		,nullif(w.Borrower_Full_Name, '') AS Borrower_Full_Name
		,nullif(w.Assignor_Name_Subordinating_Lender_Old, '') AS Assignor_Name_Subordinating_Lender_Old
		,nullif(w.Assignee_Name_Subordinated_Lender_New, '') AS Assignee_Name_Subordinated_Lender_New
		,nullif(w.Original_Lender_Name_Releases, '') AS Original_Lender_Name_Releases
		,nullif(w.Original_Date, '') AS Original_Date
		,nullif(w.Original_Recording_Book, '') AS Original_Recording_Book
		,nullif(w.Original_Recording_Page, '') AS Original_Recording_Page
		,nullif(w.Original_Recording_Instrument_Nbr, '') AS Original_Recording_Instrument_Nbr
		,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
		,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
		,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
		,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
		,nullif(w.Pending_Transaction, '') AS Pending_Transaction
		,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
		,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
		,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
		,nullif(w.Situs_Direction, '') AS Situs_Direction
		,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
		,nullif(w.Situs_Mode, '') AS Situs_Mode
		,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
		,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
		,nullif(w.Situs_City, '') AS Situs_City
		,nullif(w.Situs_State, '') AS Situs_State
		,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
		,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
		,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
		,nullif(w.Created, '') AS Created
		,nullif(w.Updated, '') AS Updated
		,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
		,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
		,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
		,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
		,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
		,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
		,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
		,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
		,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
		,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
		,nullif(w.Source_Type, '') AS Source_Type
		,nullif(w.SRC_TBL, '') AS SRC_TBL
		,nullif(w.DEED_PID, 0) AS DEED_PID
		,nullif(w.SAM_PID, 0) AS SAM_PID
		,nullif(w.LEAP_ID, 0) AS LEAP_ID
		,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
		,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
		,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
		,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
		,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
		,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
		,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
		,nullif(w.MATURITY_DATE, '') AS MATURITY_DATE
		,nullif(w.TITLE_COMPANY, '') AS TITLE_COMPANY
		,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
		--		,nullif(w.ras_checksum, 0) AS ras_checksum
		,nullif(w.UR_Remarks, '') AS UR_Remarks
	FROM [lien_DTDB].[INFC].[Ras_work] w
	LEFT JOIN [ras].[dbo].[RAS] r ON r.Fips = w.fips
		AND isnull(r.UR_Reference_id, 0) = isnull(w.UR_Reference_id, 0)
		--AND ISNULL(r.UR_Prop_Seq_Num, 0) = ISNULL(w.UR_Prop_Seq_Num, 0)
		AND r.CLGX_UNIQUE_ID = w.clgx_unique_id
		AND r.SRC_TBL = w.SRC_TBL
	WHERE r.fips IS NULL

	/*
	keep ras.dbo.UR_rasWrk in sync withy the updates to Ras table
	
	*/
	TRUNCATE TABLE [ras].[dbo].[ur_rasWrk]

	INSERT INTO [RAS].[dbo].[UR_RASWrk] (
		[FIPS]
		,[REF_ID]
		,[US_State]
		,[US_County]
		,[CLGX_Unique_ID]
		,[Update_Timestamp]
		,[Add_Change_Delete_Identifier]
		,[Document_Type]
		,[Document_Date]
		,[Recording_Date]
		,[Recording_Book]
		,[Recording_Page]
		,[Recording_Instrument_Nbr]
		,[Loan_Amount]
		,[Borrower_First_Name]
		,[Borrower_Full_Name]
		,[Assignor_Name_Subordinating_Lender_Old]
		,[Assignee_Name_Subordinated_Lender_New]
		,[Original_Lender_Name_Releases]
		,[Original_Date]
		,[Original_Recording_Book]
		,[Original_Recording_Page]
		,[Original_Recording_Instrument_Nbr]
		,[Original_Loan_Amount]
		,[Tax_Id_Nbr_APN_Unformatted]
		,[APN_Sequence_NBR]
		,[Tax_Id_Nbr_APN_Formatted]
		,[Pending_Transaction]
		,[Situs_House_Nbr]
		,[Situs_House_Nbr2]
		,[Situs_House_Nbr_Suffix]
		,[Situs_Direction]
		,[Situs_Street_Name]
		,[Situs_Mode]
		,[Situs_Post_Direction]
		,[Situ_Unit_Nbr]
		,[Situs_City]
		,[Situs_State]
		,[Situs_Zip_Code]
		,[Situs_Carrier_Code]
		,[Multi_Property_Indicator]
		,[Created]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[Fmt_Inst_Nbr]
		,[CMT_ID_Inst_nbr]
		,[Fmt_Ori_Inst_Nbr]
		,[CMT_ID_Ori_Inst_nbr]
		,[Fmt_Book_Page]
		,[CMT_ID_Book_Page]
		,[Fmt_Ori_Book_Page]
		,[CMT_ID_Ori_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[DEED_PID]
		,[SAM_PID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[MTG_CLGX_UNIQUE_ID]
		,[MTG_Source_Type]
		,[MATURITY_DATE]
		,[TITLE_COMPANY]
		,[Updated]
		,[UR_Prop_Seq_Num]
		,[UR_Remarks]
		)
	SELECT [FIPS]
		,[REF_ID]
		,[US_State]
		,[US_County]
		,[CLGX_Unique_ID]
		,[Update_Timestamp]
		,[Add_Change_Delete_Identifier]
		,[Document_Type]
		,[Document_Date]
		,[Recording_Date]
		,[Recording_Book]
		,[Recording_Page]
		,[Recording_Instrument_Nbr]
		,[Loan_Amount]
		,[Borrower_First_Name]
		,[Borrower_Full_Name]
		,[Assignor_Name_Subordinating_Lender_Old]
		,[Assignee_Name_Subordinated_Lender_New]
		,[Original_Lender_Name_Releases]
		,[Original_Date]
		,[Original_Recording_Book]
		,[Original_Recording_Page]
		,[Original_Recording_Instrument_Nbr]
		,[Original_Loan_Amount]
		,[Tax_Id_Nbr_APN_Unformatted]
		,[APN_Sequence_NBR]
		,[Tax_Id_Nbr_APN_Formatted]
		,[Pending_Transaction]
		,[Situs_House_Nbr]
		,[Situs_House_Nbr2]
		,[Situs_House_Nbr_Suffix]
		,[Situs_Direction]
		,[Situs_Street_Name]
		,[Situs_Mode]
		,[Situs_Post_Direction]
		,[Situ_Unit_Nbr]
		,[Situs_City]
		,[Situs_State]
		,[Situs_Zip_Code]
		,[Situs_Carrier_Code]
		,[Multi_Property_Indicator]
		,[Created]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[Fmt_Inst_Nbr]
		,[CMT_ID_Inst_nbr]
		,[Fmt_Ori_Inst_Nbr]
		,[CMT_ID_Ori_Inst_nbr]
		,[Fmt_Book_Page]
		,[CMT_ID_Book_Page]
		,[Fmt_Ori_Book_Page]
		,[CMT_ID_Ori_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[DEED_PID]
		,[SAM_PID]
		--,[LEAP_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[MTG_CLGX_UNIQUE_ID]
		,[MTG_Source_Type]
		,[MATURITY_DATE]
		,[TITLE_COMPANY]
		,[Updated]
		,[UR_Prop_Seq_Num]
		,[UR_Remarks]--select *
	FROM [LIEN_DTDB].[INFC].[Ras_work]

	--
	-- #multi 
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp0_ras]
		SELECT DISTINCT r.fips
			,r.[Fmt_Inst_Nbr]
			,r.FMT_Book_Page
			,r.recording_date
			,r.Fmt_Ori_Inst_Nbr
			,r.Fmt_Ori_Book_Page
		INTO [lien_dtdb].[tmp].[Multi_apn_temp0_ras]
		FROM [Lien_dtdb].[infc].[ras_work] r
		WHERE r.source_type = 'e'

	-- extract the delete records form logfile
	DECLARE @ext_date DATETIME = (
			SELECT TOP 1 dateadd(day, - 2, INFC_Extract_date)
			FROM [lien].[UR].[document_transaction_log_tracker] WITH (
					NOLOCK
					,INDEX (ixu_update_date)
					)
			WHERE INFC_Extract_date IS NOT NULL
			ORDER BY m_update_date DESC
			)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp0_ras_reset]
		SELECT DISTINCT dd.*
		INTO [lien_dtdb].[tmp].[Multi_apn_temp0_ras_reset]
		FROM [lien].[ur].[document_transaction_log] a WITH (
				NOLOCK
				,INDEX (ixc_update_date)
				)
		OUTER APPLY (
			SELECT try_cast(d.fips_code AS INT) AS Fips
				,d.Fmt_Doc_Number AS Fmt_Inst_Nbr
				,d.FMT_Book_Page AS FMT_Book_Page
				,d.Recording_Date_D AS Recording_Date
				,rr.Fmt_Ori_Inst_Nbr
				,rr.Fmt_Ori_Book_Page
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			CROSS APPLY (
				SELECT *
				FROM [trinitytest].[dbo].[hash_Paul_valid_doc_type] dt WITH (
						NOLOCK
						,INDEX (idx_doc_type)
						)
				WHERE dt.doc_type = d.doc_type
					AND dt._dest = 'RAS'
				) dt
			OUTER APPLY (
				SELECT REFERENCE_id
					,Fmt_Reference_Doc_Number AS Fmt_Ori_Inst_Nbr
					,Fmt_BookPAge AS Fmt_Ori_Book_Page
				FROM [lien].[ur].[reference] r WITH (
						NOLOCK
						,INDEX (ix_doc_id)
						)
				WHERE r.doc_id = d.doc_id
				) rr
			WHERE d.doc_id = a.doc_id
			) dd
		WHERE a.m_update_date >= @ext_date
			AND a.Process_name LIKE '%delete%'
			AND dd.fips IS NOT NULL

	-- combine the the 2 file
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp0_ras_comb]
		SELECT DISTINCT u.*
		INTO [lien_dtdb].[tmp].[Multi_apn_temp0_ras_comb]
		FROM (
			SELECT *
			FROM [lien_dtdb].[tmp].[Multi_apn_temp0_ras]
			
			UNION
			
			SELECT *
			FROM [lien_dtdb].[tmp].[Multi_apn_temp0_ras_reset]
			) u

	DROP INDEX

	IF EXISTS idx_fips_Fmt_Inst_bkpg_Recdt ON [lien_dtdb].[tmp].[Multi_apn_temp0_ras_comb]
		CREATE CLUSTERED INDEX idx_fips_Fmt_Inst_bkpg_Recdt ON [lien_dtdb].[tmp].[Multi_apn_temp0_ras_comb] (
			fips
			,[Fmt_Inst_Nbr]
			,FMT_Book_Page
			,recording_date
			,Fmt_Ori_Inst_Nbr
			,Fmt_Ori_Book_Page
			)
/*
	-- null multi ind the records on ras for the combined file
	-- remove this update
	UPDATE a
	SET a.Multi_Property_Indicator = NULL
	FROM lien_dtdb.tmp.Multi_apn_temp0_ras_comb c WITH (
			NOLOCK
			,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
			)
	INNER JOIN [RAS].[dbo].[RAS] a WITH (
			NOLOCK
			,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
			) ON a.fips = c.fips
		AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(c.[Fmt_Inst_Nbr], '')
		AND isnull(a.FMT_Book_Page, '') = isnull(c.FMT_Book_Page, '')
		AND isnull(a.recording_date, '') = isnull(c.recording_date, '')
		AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(c.Fmt_Ori_Inst_Nbr, '')
		AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(c.Fmt_Ori_Book_Page, '')
	WHERE a.source_type = 'e'

	DROP TABLE

	IF EXISTS lien_dtdb.tmp.Multi_apn_temp1_ras;
		SELECT a.ur_doc_id
			,d.fips_code
			,d.recording_date_d
			,d.doc_type
			,d.cmt_id
			,ROW_NUMBER() OVER (
				PARTITION BY d.fips_code
				,d.recording_date_d
				,d.doc_type
				,d.cmt_id
				,a.[Fmt_Inst_Nbr]
				,a.FMT_Book_Page
				,a.Fmt_Ori_Inst_Nbr
				,a.Fmt_Ori_Book_Page ORDER BY a.ur_doc_id
					,a.ref_id
					,a.[Tax_Id_Nbr_APN_Unformatted]
					--,a.ORIGINAL_SITE_ADDRESS
				) AS ROW4
			,'a' AS _a
			,a.[RAS_ID]
			,a.fips
			,a.ref_id
			,a.[Fmt_Inst_Nbr]
			,a.FMT_Book_Page
			,a.Fmt_Ori_Inst_Nbr
			,a.Fmt_Ori_Book_Page
			,a.recording_date
			,a.source_type
		INTO lien_dtdb.tmp.Multi_apn_temp1_ras
		FROM lien_dtdb.tmp.Multi_apn_temp0_ras_comb dw WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				)
		INNER JOIN [RAS].[dbo].[RAS] a WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				) ON a.fips = dw.fips
			AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(dw.[Fmt_Inst_Nbr], '')
			AND isnull(a.FMT_Book_Page, '') = isnull(dw.FMT_Book_Page, '')
			AND isnull(a.recording_date, '') = isnull(dw.recording_date, '')
			AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(dw.Fmt_Ori_Inst_Nbr, '')
			AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(dw.Fmt_Ori_Book_Page, '')
		LEFT JOIN lien.ur.document d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.doc_id = a.ur_doc_id
		WHERE a.source_type = 'e'
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON lien_dtdb.tmp.Multi_apn_temp1_ras (
		fips
		,[Fmt_Inst_Nbr]
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		,source_type
		)
*/
	DROP TABLE
	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras]
		SELECT a.ur_doc_id
			,d.fips_code
			,d.recording_date_d
			,d.doc_type
			,d.cmt_id
			,ROW_NUMBER() OVER (
				PARTITION BY --d.fips_code
				d.recording_date_d
				,d.doc_type
				,d.cmt_id
				,a.fips
				,ISNULL(a.[Fmt_Inst_Nbr],'')
				,ISNULL(a.FMT_Book_Page,'')
				,ISNULL(a.Fmt_Ori_Inst_Nbr,'')
				,ISNULL(a.Fmt_Ori_Book_Page ,'')
				ORDER BY a.ur_doc_id
					,a.ref_id
					,a.[Tax_Id_Nbr_APN_Unformatted]
					--,a.ORIGINAL_SITE_ADDRESS
				) AS ROW4
			,'a' AS _a
			,a.[RAS_ID]
			,a.fips
			,a.ref_id
			,a.[Fmt_Inst_Nbr]
			,a.FMT_Book_Page
			,a.Fmt_Ori_Inst_Nbr
			,a.Fmt_Ori_Book_Page
			,a.recording_date
			,a.source_type
			,a.src_tbl
			,a.Multi_Property_Indicator
		INTO [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp0_ras_comb] dw WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				)
		INNER JOIN [RAS].[dbo].[RAS] a WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				) ON a.fips = dw.fips
			AND a.recording_date = dw.recording_date
			AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(dw.[Fmt_Inst_Nbr], '')
			AND isnull(a.FMT_Book_Page, '') = isnull(dw.FMT_Book_Page, '')
			--AND isnull(a.recording_date, '') = isnull(dw.recording_date, '')
			AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(dw.Fmt_Ori_Inst_Nbr, '')
			AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(dw.Fmt_Ori_Book_Page, '')
		LEFT JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.doc_id = a.ur_doc_id
		WHERE a.source_type = 'e'
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras] (
		fips
		,[Fmt_Inst_Nbr]
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		,source_type
		)

	--
	--identify records that have multiple occurences on the ras work for the same document
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp2_ras]
		SELECT DISTINCT --d.fips_code
			d.fips
			,d.Fmt_Inst_Nbr
			,d.FMT_Book_Page
			,d.Fmt_Ori_Inst_Nbr
			,d.Fmt_Ori_Book_Page
			,d.recording_date
			--,d.recording_date_d
			,d.doc_type
			,d.cmt_id
		INTO [lien_dtdb].[tmp].[Multi_apn_temp2_ras]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras] d
		--FROM lien_dtdb.tmp.Multi_apn_temp1_ras d
		WHERE row4 > 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON [lien_dtdb].[tmp].[Multi_apn_temp2_ras] (
		--fips_code
		fips
		,Fmt_Inst_Nbr
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		--,recording_date_d
		,doc_type
		,cmt_id
		)

	--
	-- assign the M or D so that we can set the multi_apn flag
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp2_ras_apn]
		SELECT c.[RAS_ID]
			,CASE 
				WHEN c.row4 = 1
					THEN 'M'
				ELSE 'D'
				END AS Multi_apn
		INTO [lien_dtdb].[tmp].[Multi_apn_temp2_ras_apn]
		FROM (
			SELECT b.*
			FROM [lien_dtdb].[tmp].[Multi_apn_temp2_ras] a WITH (
					NOLOCK
					,INDEX (idx_multi)
					)
			INNER JOIN [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras] b WITH (
			--INNER JOIN lien_dtdb.tmp.Multi_apn_temp1_ras b WITH (
					NOLOCK
					,INDEX (idx_multi)
					) ON --b.fips_code = a.fips_code
					b.fips = a.fips
				AND isnull(b.[Fmt_Inst_Nbr], '') = isnull(a.[Fmt_Inst_Nbr], '')
				AND isnull(b.FMT_Book_Page, '') = isnull(a.FMT_Book_Page, '')
				AND isnull(b.Fmt_Ori_Inst_Nbr, '') = isnull(a.Fmt_Ori_Inst_Nbr, '')
				AND isnull(b.Fmt_Ori_Book_Page, '') = isnull(a.Fmt_Ori_Book_Page, '')
				AND b.recording_date = a.recording_date
				--AND b.recording_date_d = a.recording_date_d
				AND b.doc_type = a.doc_type
				AND isnull(b.cmt_id, 0) = isnull(a.cmt_id, 0)
			) c
		ORDER BY --c.fips_code
			c.fips
			,c.Fmt_Inst_Nbr
			,c.FMT_Book_Page
			,c.Fmt_Ori_Inst_Nbr
			,c.Fmt_Ori_Book_Page
			,c.recording_date
			--,c.recording_date_d
			,c.doc_type
			,c.cmt_id
			,c.ROW4
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_RAS_ID ON [lien_dtdb].[tmp].[Multi_apn_temp2_ras_apn] ([RAS_ID])


	--
	-- create the combine file of all the detail records plus the multi_apn results
	-- 	
	DROP TABLE
	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras_update]
		SELECT a.*
			,b.ras_id AS b_ras_id
			,b.Multi_apn as new_Multi_apn
			--,b.Multi_apn AS new_multi_apn
		INTO [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras_update]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras] a WITH (
				NOLOCK
				,INDEX (idx_multi)
				--,INDEX (idx_ras_id)
				)
		OUTER APPLY (
			SELECT *
			FROM [Lien_dtdb].[tmp].[Multi_apn_temp2_ras_apn] b WITH (
					NOLOCK
					,INDEX (idx_ras_id)
					)
			WHERE a.ras_ID = b.ras_ID
			) b

	CREATE CLUSTERED INDEX idx_ras_id ON [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras_update] (ras_id)
/*
	select * 
 
	from lien_dtdb.tmp.Multi_apn_temp_fips_ras_update a
	where ur_doc_id = 389758106

	WHERE isnull(a.[Multi_Property_Indicator], '') <> isnull(a.new_Multi_apn, '')
	and Multi_Property_Indicator is not null


	select top 100 Multi_Property_Indicator ,* from ras.dbo.ras where ur_doc_id = 389758106
	

*/
	-- do the update just like deed without the sale_amout  
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.[Multi_Property_Indicator] = a.new_Multi_apn
		,d.updated = getdate()
	FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_ras_update] a WITH (
	--FROM lien_dtdb.tmp.Multi_apn_temp2_ras_apn a WITH (
			NOLOCK
			,INDEX (idx_RAS_ID)
			)
	INNER JOIN [RAS].[dbo].[RAS] d WITH (
			NOLOCK
			,INDEX (RasID)
			) ON d.[RAS_ID] = a.[RAS_ID]
	WHERE isnull(a.[Multi_Property_Indicator], '') <> isnull(a.new_Multi_apn, '')
	OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

	EXEC [lien_DTDB].[infc].[AddinfcLog] N'info'
		,N'UR_Merge_RAS_From_RAS_work'
		,N'Ended'

	COMMIT
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

