/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Delete_Pet_Missing_assr_ref_id | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Delete_Pet_Missing_assr_ref_id] @ERROR VARCHAR(500) OUTPUT
AS
--
-- Delete pet records not on assr any more
--
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Delete_Pet_Missing_assr_ref_id'
		,N'Started'

	DECLARE @SQL VARCHAR(MAX)
		,@LinkSvr VARCHAR(100) = ''

	SET @LinkSvr = CASE 
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB009' -- DWS-ETL01.DATATREE.LOCAL,1433
				THEN '[DWS-ETL01].'
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB029' --AZUVPSQLDTDB029.datatree.local
				THEN ''
			ELSE '' -- AZUVNSQLDTDB003
			END
	SET @sql = N'
	DROP TABLE

	IF EXISTS Pet.pet_tmp.Missing_assr_ref_id
		SELECT *
		INTO Pet.pet_tmp.Missing_assr_ref_id
		FROM ' + @LinkSvr + 'Assr.pet_tmp.Missing_assr_ref_id

	CREATE INDEX idx_fips_ref_id ON Pet.pet_tmp.Missing_assr_ref_id (
		Fips
		,ref_id
		)
'

	--Select @sql as N'@sql'
	EXEC (@sql)

	DELETE p
	FROM [pet].[dbo].[pet] p
	INNER JOIN [Pet].[pet_tmp].[Missing_assr_ref_id] b WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON b.fips = p.fips
		AND b.ref_id = p.ref_id

	DELETE p
	FROM [pet].[dbo].[pet_apn] p
	INNER JOIN [Pet].[pet_tmp].[Missing_assr_ref_id] b WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON b.fips = p.fips
		AND b.ref_id = p.ref_id

	DELETE p
	FROM [pet].[dbo].[PET_NAME] p
	INNER JOIN [Pet].[pet_tmp].[Missing_assr_ref_id] b WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON b.fips = p.fips
		AND b.ref_id = p.ref_id

	DELETE p
	FROM [pet].[dbo].[pet_neo_legals] p
	INNER JOIN [Pet].[pet_tmp].[Missing_assr_ref_id] b WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON b.fips = p.fips
		AND b.ref_id = p.ref_id

	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Delete_Pet_Missing_assr_ref_id'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


