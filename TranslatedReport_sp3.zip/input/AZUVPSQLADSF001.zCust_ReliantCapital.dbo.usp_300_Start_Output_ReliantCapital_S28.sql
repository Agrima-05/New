SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_ReliantCapital].[dbo].[usp_300_Start_Output_ReliantCapital_S28]

AS
BEGIN
	
	SET NOCOUNT ON;

	----20240716 - Per EC - ONLY run the  "-" records through S85---

		DROP TABLE [dbo].[x_Custom_OUTPUT_S28]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S28](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
		[INPUT Unique ID][varchar](250)NULL,
		[INPUT Address][varchar](250)NULL,
		[INPUT City][varchar](250)NULL,
		[INPUT State][varchar](250)NULL,
		[INPUT Zip][varchar](250)NULL,
		[Property Address][varchar](250)NULL,
		[City][varchar](250)NULL,
		[State][varchar](250)NULL,
		[Zip Code][varchar](250)NULL,
		[Run Date][varchar](250)NULL,
		[Address Standardization][varchar](250)NULL,
		[INVL Converage Status][varchar](250)NULL,
		[INVL Thru Date][varchar](250)NULL,
		[Property Status][varchar](250)NULL,
		[Event Status ][varchar](250)NULL,
		[Current Owner 1][varchar](250)NULL,
		[Current Owner 2][varchar](250)NULL,
		[Ownership Change Date][varchar](250)NULL,
		[Current Owner Doc Type][varchar](250)NULL,
		[# of Recordings][varchar](250)NULL,


			-----INTERNAL----
			[START DATE][varchar](250)NULL,
			[MAX_INVL_RECDATE][varchar](250)NULL

		) ON [PRIMARY]



		  INSERT INTO [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] (  [INPUT Unique ID],
		  [INPUT Address],
			[INPUT City],
			[INPUT State],
			[INPUT Zip],
			FIPS,
			PROPERTYID,
			[MAX_INVL_RECDATE],
			[Start Date]  )
	
		Select 	
		[INPUTKEY]
		,[Address]
		,[City]
		,[State]
		,[ZipCODE]
		,FIPS
		,[PROPERTYID]
		,[MAX_INVL_RECDATE]
		,convert(Date,[Monitoring START DATE])
		--Select * 
	   
	   FROM [zCust_ReliantCapital].[dbo].[INPUT_MONITOR]
		where [Record Indicator] not like 'D'
		and [INPUTKEY] is not null
		and INPUTKEY not like '%-%'
		--and DATE_RECEIVED = convert(Date,getdate())

		Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]


		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--FROM x_Custom_OUTPUT_S28 a JOIN 
		--a_PropMatch_Work_FLANK c on a.[INPUT Unique ID] = c.RAW_ID



		
		Update [zCust_ReliantCapital].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = Convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a JOIN [zCust_ReliantCapital].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique ID] = c.RAW_ID







		Update [zCust_ReliantCapital].[dbo].[a]
		set 
		A.[INVL Thru Date] = B.maxdate
		,A.[INVL Converage Status] = case when B.FIPS is not null then 1 else 0 end
		--Select * 
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a 
			left outer JOIN (Select FIPS, Min(Recordingdt) as MinDate, Max(Recordingdt) as maxdate from [data].[dbo].[v_Invl] with(NOLOCK)
			where 
			farecordtype not like 'D' AND recordingdt is not null and 
			FIPS in (Select distinct FIPS from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] where FIPS is not null and FIPS not like '' and FIPS not like '0')
			Group by FIPS) B on 
			A.FIPS = B.FIPS

		

	UPDATE [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] 
	SET [INVL Thru Date] = ''
	WHERE [INVL Thru Date] = '1900-01-01'

	UPDATE [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] 
	SET [INVL Thru Date] = ''
	WHERE [INVL Thru Date] = '01/01/1900'

	UPDATE [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] 
	SET [INVL Thru Date] = CONVERT(varchar(10), convert(date,[INVL Thru Date],126), 101)
	WHERE [INVL Thru Date] not like ''


		
		Update [zCust_ReliantCapital].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
			FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID



				
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_ReliantCapital].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_ReliantCapital].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_ReliantCapital].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

	

	--------PULL INVL BULK---
	--Drop table dbo.INVL_BULK_PULL
	
	-----20240715 - 
	-----Per EC - 
	----1 - INVL Doc Categories to Monitor: ALN, BND, ELN, FLN, JDG, LEN, LID, MLN, NTE, SBT, SLN, TRU, UCC
	----2 - INVL Match will be from input address to all Main Property ID, Party 1 Name 1 & Name 2 Mail Address ID & Party 2 Name 1 Mailing Address IDs
	----3 - Pull ALL NON_INACTIVE INVL NOT USING THEIR INPUT DATE

	
	
		Truncate table dbo.INVL_BULK_PULL

		INSERT INTO [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]( [ROWNUM]
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,A.[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		FROM     [Data].[dbo].[v_INVL] AS A WITH (NOLOCK) INNER JOIN
			[zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] AS B WITH (NOLOCK) ON A.PropertyID = B.PROPERTYID 
						
		WHERE  (B.PROPERTYID IS NOT NULL) AND (B.PROPERTYID NOT LIKE '') AND (B.PROPERTYID NOT LIKE '0') 
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('ALN','BND','ELN','FLN','JDG','LEN','LID','MLN','NTE','SBT','SLN','TRU','UCC'
		------20260701 - Changed to add more doc categories per EC
		,'ABJ','AFF','AGR','CER','CTR','DCR','EAS','EXC','LEV','LSE','MAP','ORD','PRO','RED','REL','STR','SUP')


		INSERT INTO [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      
      ,A.[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] as B with(NOLOCK) on A.Party1_Name1_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('ALN','BND','ELN','FLN','JDG','LEN','LID','MLN','NTE','SBT','SLN','TRU','UCC'
		------20260701 - Changed to add more doc categories per EC
		,'ABJ','AFF','AGR','CER','CTR','DCR','EAS','EXC','LEV','LSE','MAP','ORD','PRO','RED','REL','STR','SUP')

       


		INSERT INTO [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,A.[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] as B with(NOLOCK) on A.Party1_Name2_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('ALN','BND','ELN','FLN','JDG','LEN','LID','MLN','NTE','SBT','SLN','TRU','UCC'
		------20260701 - Changed to add more doc categories per EC
		,'ABJ','AFF','AGR','CER','CTR','DCR','EAS','EXC','LEV','LSE','MAP','ORD','PRO','RED','REL','STR','SUP')


		INSERT INTO [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,A.[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] as B with(NOLOCK) on A.Party2_Name1_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('ALN','BND','ELN','FLN','JDG','LEN','LID','MLN','NTE','SBT','SLN','TRU','UCC'
		------20260701 - Changed to add more doc categories per EC
		,'ABJ','AFF','AGR','CER','CTR','DCR','EAS','EXC','LEV','LSE','MAP','ORD','PRO','RED','REL','STR','SUP')


		
		--Select * From INVL_BULK_PULL



		---------20240202 -----REMOVE ALL RECORDS IF ONLY RELEASES PRESENT per EC:
		--Delete from A
		----Select * 
		--From INVL_BULK_PULL as A 
		--join (
		--Select A.[INPUT KEY] , A.TOTAL_ALL ,B.TOTAL_REL ,A.TOTAL_ALL - B.TOTAL_REL as [DIFF] 
		--from 
		--(Select [INPUT KEY],  count(*) as TOTAL_ALL From INVL_BULK_PULL with(NOLOCK)
		--Group by [INPUT KEY])A

		--left outer join 
		--(Select [INPUT KEY],  count(*) as TOTAL_REL From INVL_BULK_PULL  with(NOLOCK)
		--where LTRIM(RTRIM(DocType)) in ('ABJPRL','ABJREL','AFFLENREL','AGRCHTPRL','AGRCHTREL','AGRCPRPRL','AGRCPRREL','AGRDEDPRL'
		--,'AGRDFRREL','AGRDVLPRL','AGRLENREL','AGRPRL','AGRREL','AGRRMBREL','AGRSECREL','AGRSETREL','AGRSLEPRL','AGRSLEREL','AGRZONREL','ALNENGREL'
		--,'ALNPRL','ALNREL','ANMREL','ASRPRL','ASRREL','BKYPRL','BKYREL','BNDPRL','BNDREL','BUSREL','CAVREL','CCRPRL','CCRREL','CERREL','COVAGRREL'
		--,'COVPRL','COVREL','CTRDEDREL','CTRPRL','CTRREL','DCLPRL','DCLREL','EASPRL','EASREL','ELNPRL','ELNREL','EXCPRL','EXCREL','FLNPRL','FLNREL'
		--,'INJPRL','INJREL','JDGLENREL','JDGPRL','JDGREL','LENCNTPRL','LENCNTREL','LENCTYPRL','LENCTYREL','LENDOJPRL','LENDOJREL','LENMEDPRL'
		--,'LENMEDREL','LENOGLREL','LENPRL','LENREL','LEVPRL','LEVREL','LISHLNPRL','LISHLNREL','LISMLNPRL','LISMLNREL','LISMTGPRL','LISMTGREL'
		--,'LISPRL','LISREL','LLCREL','LSEASNPRL','LSEASNREL','LSEBREREL','LSEPRL','LSEREL','LSESUBREL','MLNPRL','MLNREL','NOTCMCPRL','NOTCMCREL'
		--,'NOTISTPRL','NOTISTREL','NOTLFEREL','NOTLIBREL','NOTNNRREL','NOTPLDREL','NOTPRL','NOTREL','NOTSWRREL','NOTWTRREL','NTEPRL','NTEREL'
		--,'ODNREL','OGLPRL','OGLREL','OPTPRL','OPTREL','ORDPRL','ORDREL','ORDWRL','PERREL','PETREL','POAPRL','POAREL','POLPRL','POLREL','PRL'
		--,'PRODCRREL','PROJDGPRL','PROJDGREL','PROSLEREL','PTRPRL','REL','RELAFF','REQPRLDOT','REQPRLMTG','REQRELDOT','REQRELMTG','REQRELVAC','RESREL'
		--,'ROYPRL','SLNPRL','SLNREL','SUPJDGPRL','SUPLENPRL','SUPLENREL','SUPREL','TNMREL','UCCPRL','UCCREL','VLNPRL','VLNREL','WAIPRL','WAIREL'
		--,'WRTPRL','WRTREL')
		--Group by [INPUT KEY])B
		--on A.[INPUT KEY] = B.[INPUT KEY])B 
		--on A.[INPUT KEY] = B.[INPUT KEY]
		--where B.[DIFF] = 0


		Update [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]
		Set
		Recordingdt = CONVERT(varchar(10), convert(date,Recordingdt,126), 101)
		,DocumentDt = CONVERT(varchar(10), convert(date,DocumentDt,126), 101)
		,doc_filing_date = CONVERT(varchar(10), convert(date,doc_filing_date,126), 101)
		



		
		Update [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]
		Set ROWNUM = NULL

			UPDATE [zCust_ReliantCapital].[dbo].[t] 
			SET T.ROWNUM = R.RowNum2
			FROM [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUT KEY] ORDER BY REcordingDt DESC) AS RowNum2
				FROM 
			[zCust_ReliantCapital].[dbo].[INVL_BULK_PULL] t  ) r ON t.[INPUT KEY] = r.[INPUT KEY] AND t.TransactionID = r.TransactionID
			 
				
		
		
		Select max(convert(int,ROWNUM )) from [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]


		Select * From [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]
		where ROWNUM is null

		Select A.* From  [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL] as A 
		join (
		Select [INPUT KEY], ROWNUM, count(*) T From [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL]
		Group by [INPUT KEY], ROWNUM
		having count(*) > 1) B on A.[INPUT KEY] = B.[INPUT KEY]
		and A.ROWNUM = B.ROWNUM
		Order by A.[INPUT KEY]

		
		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Set [# of Recordings] = NULL
		where convert(int,[# of Recordings]) > 0


		UPDATE [zCust_ReliantCapital].[dbo].[a]
		SET a.[# of Recordings] = 
		--case when b.NbrOfRecordings > 30 then '30' else 
		b.NbrOfRecordings 
		--end
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a JOIN (SELECT [INPUT KEY],MAX(ROWNUM) NbrOfRecordings FROM [zCust_ReliantCapital].[dbo].[INVL_BULK_PULL] GROUP BY [INPUT KEY]) b
		on a.[INPUT Unique ID] = b.[INPUT KEY]

		Select max(convert(bigint,[# of Recordings])) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]

		

		IF (Select count(*) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		where [# of Recordings] > 0 ) > 0

		BEGIN

			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Record_Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Recordingdt] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [DocumentDt] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [doc_filing_date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [DocNbrSrce] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [BookSrce] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [PaceSrce] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Doc_Category] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [DocTypeID] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [DocType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [DocumentTitle] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [federal_tax_lien_area] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [federal_tax_lien_area_phone] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_last_day_for_refiling] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_period_begin_date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_period_end_date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_interest_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_penalty_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [judgment_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [lien_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [map_plat_id] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [mechanics_lien_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [ordinance_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [patent_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [permit_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [resolution_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_account_serial_warrant_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [tax_type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [trustees_sale_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [ucc_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [undersigned_same_as_borrower] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [amount_due] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [amount_of_default] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [bond_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [cash_down_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [contract_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [collection_costs] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [unpaid_balance] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [unpaid_balance_as_of_modification_date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [unpaid_prinicipal_amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_FullName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_last_Company_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_First_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Middle_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Role_Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_MailPropertyID] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_PreDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_StreetNumber] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_StreetName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_PostDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_StreetType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_SuiteType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Suite] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name1_ZipPlus4] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_FullName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_last_Company_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_First_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Middle_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Role_Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_MailPropertyID] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_PreDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_StreetNumber] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_StreetName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_PostDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_StreetType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_SuiteType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Suite] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party1_Name2_ZipPlus4] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_FullName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_last_Company_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_First_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Middle_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Role_Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_MailPropertyID] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_PreDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_StreetNumber] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_StreetName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_PostDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_StreetType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_SuiteType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Suite] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name1_ZipPlus4] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_FullName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_last_Company_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_First_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Middle_Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Role_Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_MailPropertyID] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_PreDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_StreetNumber] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_StreetName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_PostDir] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_StreetType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_SuiteType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Suite] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Party2_Name2_ZipPlus4] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Reference_recording_year] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [reference_recording_date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [reference_doc_number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [reference_book] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [reference_page] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Fmt_Reference_Doc_Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_S28 ADD [Fmt_Reference_BookPAge] [varchar](250) NULL')





			EXEC('UPDATE a
			SET 
				A. [Record_Number] = B.ROWNUM
				,A.[Recordingdt] =  B.Recordingdt
				,A.[DocumentDt] =  B.DocumentDt
				,A.[doc_filing_date] =  B.doc_filing_date
				,A.[DocNbrSrce] =  B.DocNbrSrce
				,A.[BookSrce] =  B.BookSrce
				,A.[PaceSrce] =  B.PaceSrce
				,A.[Doc_Category] =  B.Doc_Category
				,A.[DocTypeID] =  B.DocTypeID
				,A.[DocType] =  B.DocType
				,A.[DocumentTitle] =  B.DocumentTitle
				,A.[federal_tax_lien_area] =  B.Federal_Tax_Lien_Area
				,A.[federal_tax_lien_area_phone] =  B.Federal_Tax_Lien_Area_Phone
				,A.[tax_last_day_for_refiling] =  B.Tax_Last_Day_for_Refiling
				,A.[tax_period_begin_date] =  B.Tax_Period_Begin_Date
				,A.[tax_period_end_date] =  B.Tax_Period_End_Date
				,A.[tax_amount] =  B.Tax_Amount
				,A.[tax_interest_amount] =  B.Tax_Interest_Amount
				,A.[tax_penalty_amount] =  B.Tax_Penalty_Amount
				,A.[judgment_amount] =  B.Judgment_Amount
				,A.[lien_number] =  B.Lien_Number
				,A.[map_plat_id] =  B.Map_Plat_ID
				,A.[mechanics_lien_number] =  B.Mechanics_Lien_Number
				,A.[ordinance_number] =  B.Ordinance_Number
				,A.[patent_number] =  B.Patent_Number
				,A.[permit_number] =  B.Permit_Number
				,A.[resolution_number] =  B.Resolution_Number
				,A.[tax_account_serial_warrant_number] =  B.Tax_Account_Serial_Warrant_Number
				,A.[tax_type] =  B.Tax_Type
				,A.[trustees_sale_number] =  B.Trustees_Sale_Number
				,A.[ucc_number] =  B.UCC_Number
				,A.[undersigned_same_as_borrower] =  B.Undersigned_Same_as_Borrower
				,A.[amount_due] =  B.Amount_Due
				,A.[amount_of_default] =  B.Amount_of_Default
				,A.[bond_amount] =  B.Bond_Amount
				,A.[cash_down_amount] =  B.Cash_Down_Amount
				,A.[contract_amount] =  B.Contract_Amount
				,A.[collection_costs] =  B.Collection_Costs
				,A.[unpaid_balance] =  B.Unpaid_Balance
				,A.[unpaid_balance_as_of_modification_date] =  B.Unpaid_Balance_as_of_Modification_Date
				,A.[unpaid_prinicipal_amount] =  B.unpaid_prinicipal_amount
				,A.[Party1_Name1_FullName] =  B.[Party1_Name1_FullName]
				,A.[Party1_Name1_last_Company_Name] =  B.[Party1_Name1_last_Company_Name]
				,A.[Party1_Name1_First_Name] =  B.[Party1_Name1_First_Name]
				,A.[Party1_Name1_Middle_Name] =  B.[Party1_Name1_Middle_Name]
				,A.[Party1_Name1_Suffix] =  B.[Party1_Name1_Suffix]
				,A.[Party1_Name1_Role_Type] =  B.[Party1_Name1_Roll_Type]
				,A.[Party1_Name1_MailPropertyID] =  B.[Party1_Name1_MailPropertyID]
				,A.[Party1_Name1_Address] =  B.[Party1_Name1_Address]
				,A.[Party1_Name1_PreDir] =  B.[Party1_Name1_PreDir]
				,A.[Party1_Name1_StreetNumber] =  B.[Party1_Name1_StreetNumber]
				,A.[Party1_Name1_StreetName] =  B.[Party1_Name1_StreetName]
				,A.[Party1_Name1_PostDir] =  B.[Party1_Name1_PostDir]
				,A.[Party1_Name1_StreetType] =  B.[Party1_Name1_StreetType]
				,A.[Party1_Name1_SuiteType] =  B.[Party1_Name1_SuiteType]
				,A.[Party1_Name1_Suite] =  B.[Party1_Name1_Suite]
				,A.[Party1_Name1_City] =  B.[Party1_Name1_City]
				,A.[Party1_Name1_State] =  B.[Party1_Name1_State]
				,A.[Party1_Name1_Zip] =  B.[Party1_Name1_Zip]
				,A.[Party1_Name1_ZipPlus4] =  B.[Party1_Name1_ZipPlus4]
				,A.[Party1_Name2_FullName] =  B.[Party1_Name2_FullName]
				,A.[Party1_Name2_last_Company_Name] =  B.[Party1_Name2_last_Company_Name]
				,A.[Party1_Name2_First_Name] =  B.[Party1_Name2_First_Name]
				,A.[Party1_Name2_Middle_Name] =  B.[Party1_Name2_Middle_Name]
				,A.[Party1_Name2_Suffix] =  B.[Party1_Name2_Suffix]
				,A.[Party1_Name2_Role_Type] =  B.[Party1_Name2_Roll_Type]
				,A.[Party1_Name2_MailPropertyID] =  B.[Party1_Name2_MailPropertyID]
				,A.[Party1_Name2_Address] =  B.[Party1_Name2_Address]
				,A.[Party1_Name2_PreDir] =  B.[Party1_Name2_PreDir]
				,A.[Party1_Name2_StreetNumber] =  B.[Party1_Name2_StreetNumber]
				,A.[Party1_Name2_StreetName] =  B.[Party1_Name2_StreetName]
				,A.[Party1_Name2_PostDir] =  B.[Party1_Name2_PostDir]
				,A.[Party1_Name2_StreetType] =  B.[Party1_Name2_StreetType]
				,A.[Party1_Name2_SuiteType] =  B.[Party1_Name2_SuiteType]
				,A.[Party1_Name2_Suite] =  B.[Party1_Name2_Suite]
				,A.[Party1_Name2_City] =  B.[Party1_Name2_City]
				,A.[Party1_Name2_State] =  B.[Party1_Name2_State]
				,A.[Party1_Name2_Zip] =  B.[Party1_Name2_Zip]
				,A.[Party1_Name2_ZipPlus4] =  B.[Party1_Name2_ZipPlus4]
				,A.[Party2_Name1_FullName] =  B.[Party2_Name1_FullName]
				,A.[Party2_Name1_last_Company_Name] =  B.[Party2_Name1_last_Company_Name]
				,A.[Party2_Name1_First_Name] =  B.[Party2_Name1_First_Name]
				,A.[Party2_Name1_Middle_Name] =  B.[Party2_Name1_Middle_Name]
				,A.[Party2_Name1_Suffix] =  B.[Party2_Name1_Suffix]
				,A.[Party2_Name1_Role_Type] =  B.[Party2_Name1_Roll_Type]
				,A.[Party2_Name1_MailPropertyID] =  B.[Party2_Name1_MailPropertyID]
				,A.[Party2_Name1_Address] =  B.[Party2_Name1_Address]
				,A.[Party2_Name1_PreDir] =  B.[Party2_Name1_PreDir]
				,A.[Party2_Name1_StreetNumber] =  B.[Party2_Name1_StreetNumber]
				,A.[Party2_Name1_StreetName] =  B.[Party2_Name1_StreetName]
				,A.[Party2_Name1_PostDir] =  B.[Party2_Name1_PostDir]
				,A.[Party2_Name1_StreetType] =  B.[Party2_Name1_StreetType]
				,A.[Party2_Name1_SuiteType] =  B.[Party2_Name1_SuiteType]
				,A.[Party2_Name1_Suite] =  B.[Party2_Name1_Suite]
				,A.[Party2_Name1_City] =  B.[Party2_Name1_City]
				,A.[Party2_Name1_State] =  B.[Party2_Name1_State]
				,A.[Party2_Name1_Zip] =  B.[Party2_Name1_Zip]
				,A.[Party2_Name1_ZipPlus4] =  B.[Party2_Name1_ZipPlus4]
				,A.[Party2_Name2_FullName] =  B.[Party2_Name2_FullName]
				,A.[Party2_Name2_last_Company_Name] =  B.[Party2_Name2_last_Company_Name]
				,A.[Party2_Name2_First_Name] =  B.[Party2_Name2_First_Name]
				,A.[Party2_Name2_Middle_Name] =  B.[Party2_Name2_Middle_Name]
				,A.[Party2_Name2_Suffix] =  B.[Party2_Name2_Suffix]
				,A.[Party2_Name2_Role_Type] =  B.[Party2_Name2_Roll_Type]
				,A.[Party2_Name2_MailPropertyID] =  B.[Party2_Name2_MailPropertyID]
				,A.[Party2_Name2_Address] =  B.[Party2_Name2_Address]
				,A.[Party2_Name2_PreDir] =  B.[Party2_Name2_PreDir]
				,A.[Party2_Name2_StreetNumber] =  B.[Party2_Name2_StreetNumber]
				,A.[Party2_Name2_StreetName] =  B.[Party2_Name2_StreetName]
				,A.[Party2_Name2_PostDir] =  B.[Party2_Name2_PostDir]
				,A.[Party2_Name2_StreetType] =  B.[Party2_Name2_StreetType]
				,A.[Party2_Name2_SuiteType] =  B.[Party2_Name2_SuiteType]
				,A.[Party2_Name2_Suite] =  B.[Party2_Name2_Suite]
				,A.[Party2_Name2_City] =  B.[Party2_Name2_City]
				,A.[Party2_Name2_State] =  B.[Party2_Name2_State]
				,A.[Party2_Name2_Zip] =  B.[Party2_Name2_Zip]
				,A.[Party2_Name2_ZipPlus4] =  B.[Party2_Name2_ZipPlus4]
				,A.[Reference_recording_year] =  B.[Reference_recording_year]
				,A.[reference_recording_date] =  B.[reference_recording_date]
				,A.[reference_doc_number] =  B.[reference_doc_number]
				,A.[reference_book] =  B.[reference_book]
				,A.[reference_page] =  B.[reference_page]
				,A.[Fmt_Reference_Doc_Number] =  B.[Fmt_Reference_Doc_Number]
				,A.[Fmt_Reference_BookPAge] =  B.[Fmt_Reference_BookPAge]




			FROM x_Custom_OUTPUT_S28 a JOIN  INVL_BULK_PULL as B 
			on a.[INPUT Unique ID] = b.[INPUT KEY]
			WHERE B.ROWNUM = 1
			')

		END
		
		----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[# of Recordings])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ReliantCapital].[sys].[tables] as A join [zCust_ReliantCapital].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S28'
			and B.Name not in ('Record_Number'
			,'Recordingdt','DocumentDt','doc_filing_date','DocNbrSrce','BookSrce','PaceSrce','Doc_Category','DocTypeID','DocType','DocumentTitle','federal_tax_lien_area','federal_tax_lien_area_phone','tax_last_day_for_refiling',
'tax_period_begin_date','tax_period_end_date','tax_amount','tax_interest_amount','tax_penalty_amount','judgment_amount','lien_number','map_plat_id','mechanics_lien_number','ordinance_number','patent_number',
'permit_number','resolution_number','tax_account_serial_warrant_number','tax_type','trustees_sale_number','ucc_number','undersigned_same_as_borrower','amount_due','amount_of_default',
'bond_amount','cash_down_amount','contract_amount','collection_costs','unpaid_balance','unpaid_balance_as_of_modification_date','unpaid_prinicipal_amount','Party1_Name1_FullName',
'Party1_Name1_last_Company_Name','Party1_Name1_First_Name','Party1_Name1_Middle_Name','Party1_Name1_Suffix','Party1_Name1_Role_Type','Party1_Name1_MailPropertyID','Party1_Name1_Address','Party1_Name1_PreDir',
'Party1_Name1_StreetNumber','Party1_Name1_StreetName','Party1_Name1_PostDir','Party1_Name1_StreetType','Party1_Name1_SuiteType','Party1_Name1_Suite','Party1_Name1_City','Party1_Name1_State',
'Party1_Name1_Zip','Party1_Name1_ZipPlus4','Party1_Name2_FullName','Party1_Name2_last_Company_Name','Party1_Name2_First_Name','Party1_Name2_Middle_Name','Party1_Name2_Suffix','Party1_Name2_Role_Type',
'Party1_Name2_MailPropertyID','Party1_Name2_Address','Party1_Name2_PreDir','Party1_Name2_StreetNumber','Party1_Name2_StreetName','Party1_Name2_PostDir','Party1_Name2_StreetType','Party1_Name2_SuiteType',
'Party1_Name2_Suite','Party1_Name2_City','Party1_Name2_State','Party1_Name2_Zip','Party1_Name2_ZipPlus4','Party2_Name1_FullName','Party2_Name1_last_Company_Name','Party2_Name1_First_Name',
'Party2_Name1_Middle_Name','Party2_Name1_Suffix','Party2_Name1_Role_Type','Party2_Name1_MailPropertyID','Party2_Name1_Address','Party2_Name1_PreDir','Party2_Name1_StreetNumber','Party2_Name1_StreetName',
'Party2_Name1_PostDir','Party2_Name1_StreetType','Party2_Name1_SuiteType','Party2_Name1_Suite','Party2_Name1_City','Party2_Name1_State','Party2_Name1_Zip','Party2_Name1_ZipPlus4','Party2_Name2_FullName',
'Party2_Name2_last_Company_Name','Party2_Name2_First_Name','Party2_Name2_Middle_Name','Party2_Name2_Suffix','Party2_Name2_Role_Type','Party2_Name2_MailPropertyID','Party2_Name2_Address','Party2_Name2_PreDir',
'Party2_Name2_StreetNumber','Party2_Name2_StreetName','Party2_Name2_PostDir','Party2_Name2_StreetType','Party2_Name2_SuiteType','Party2_Name2_Suite','Party2_Name2_City','Party2_Name2_State','Party2_Name2_Zip',
'Party2_Name2_ZipPlus4','Reference_recording_year','reference_recording_date','reference_doc_number','reference_book','reference_page','Fmt_Reference_Doc_Number','Fmt_Reference_BookPAge')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.BUILD_DOWN_COLUMNS


				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[# of Recordings])) FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S28(
												' +  @FIELDLIST3 + '

												   ,[Record_Number]
												    ,[Recordingdt]
													,[DocumentDt]
													,[doc_filing_date]
													,[DocNbrSrce]
													,[BookSrce]
													,[PaceSrce]
													,[Doc_Category]
													,[DocTypeID]
													,[DocType]
													,[DocumentTitle]
													,[federal_tax_lien_area]
													,[federal_tax_lien_area_phone]
													,[tax_last_day_for_refiling]
													,[tax_period_begin_date]
													,[tax_period_end_date]
													,[tax_amount]
													,[tax_interest_amount]
													,[tax_penalty_amount]
													,[judgment_amount]
													,[lien_number]
													,[map_plat_id]
													,[mechanics_lien_number]
													,[ordinance_number]
													,[patent_number]
													,[permit_number]
													,[resolution_number]
													,[tax_account_serial_warrant_number]
													,[tax_type]
													,[trustees_sale_number]
													,[ucc_number]
													,[undersigned_same_as_borrower]
													,[amount_due]
													,[amount_of_default]
													,[bond_amount]
													,[cash_down_amount]
													,[contract_amount]
													,[collection_costs]
													,[unpaid_balance]
													,[unpaid_balance_as_of_modification_date]
													,[unpaid_prinicipal_amount]
													,[Party1_Name1_FullName]
													,[Party1_Name1_last_Company_Name]
													,[Party1_Name1_First_Name]
													,[Party1_Name1_Middle_Name]
													,[Party1_Name1_Suffix]
													,[Party1_Name1_Role_Type]
													,[Party1_Name1_MailPropertyID]
													,[Party1_Name1_Address]
													,[Party1_Name1_PreDir]
													,[Party1_Name1_StreetNumber]
													,[Party1_Name1_StreetName]
													,[Party1_Name1_PostDir]
													,[Party1_Name1_StreetType]
													,[Party1_Name1_SuiteType]
													,[Party1_Name1_Suite]
													,[Party1_Name1_City]
													,[Party1_Name1_State]
													,[Party1_Name1_Zip]
													,[Party1_Name1_ZipPlus4]
													,[Party1_Name2_FullName]
													,[Party1_Name2_last_Company_Name]
													,[Party1_Name2_First_Name]
													,[Party1_Name2_Middle_Name]
													,[Party1_Name2_Suffix]
													,[Party1_Name2_Role_Type]
													,[Party1_Name2_MailPropertyID]
													,[Party1_Name2_Address]
													,[Party1_Name2_PreDir]
													,[Party1_Name2_StreetNumber]
													,[Party1_Name2_StreetName]
													,[Party1_Name2_PostDir]
													,[Party1_Name2_StreetType]
													,[Party1_Name2_SuiteType]
													,[Party1_Name2_Suite]
													,[Party1_Name2_City]
													,[Party1_Name2_State]
													,[Party1_Name2_Zip]
													,[Party1_Name2_ZipPlus4]
													,[Party2_Name1_FullName]
													,[Party2_Name1_last_Company_Name]
													,[Party2_Name1_First_Name]
													,[Party2_Name1_Middle_Name]
													,[Party2_Name1_Suffix]
													,[Party2_Name1_Role_Type]
													,[Party2_Name1_MailPropertyID]
													,[Party2_Name1_Address]
													,[Party2_Name1_PreDir]
													,[Party2_Name1_StreetNumber]
													,[Party2_Name1_StreetName]
													,[Party2_Name1_PostDir]
													,[Party2_Name1_StreetType]
													,[Party2_Name1_SuiteType]
													,[Party2_Name1_Suite]
													,[Party2_Name1_City]
													,[Party2_Name1_State]
													,[Party2_Name1_Zip]
													,[Party2_Name1_ZipPlus4]
													,[Party2_Name2_FullName]
													,[Party2_Name2_last_Company_Name]
													,[Party2_Name2_First_Name]
													,[Party2_Name2_Middle_Name]
													,[Party2_Name2_Suffix]
													,[Party2_Name2_Role_Type]
													,[Party2_Name2_MailPropertyID]
													,[Party2_Name2_Address]
													,[Party2_Name2_PreDir]
													,[Party2_Name2_StreetNumber]
													,[Party2_Name2_StreetName]
													,[Party2_Name2_PostDir]
													,[Party2_Name2_StreetType]
													,[Party2_Name2_SuiteType]
													,[Party2_Name2_Suite]
													,[Party2_Name2_City]
													,[Party2_Name2_State]
													,[Party2_Name2_Zip]
													,[Party2_Name2_ZipPlus4]
													,[Reference_recording_year]
													,[reference_recording_date]
													,[reference_doc_number]
													,[reference_book]
													,[reference_page]
													,[Fmt_Reference_Doc_Number]
													,[Fmt_Reference_BookPAge]


													)
												  
											  Select 
											
											   ' +  @FIELDLIST4 + '

												,B.[ROWNUM]
												, B.Recordingdt
												, B.DocumentDt
												, B.doc_filing_date
												, B.DocNbrSrce
												, B.BookSrce
												, B.PaceSrce
												, B.Doc_Category
												, B.DocTypeID
												, B.DocType
												, B.DocumentTitle
												, B.Federal_Tax_Lien_Area
												, B.Federal_Tax_Lien_Area_Phone
												, B.Tax_Last_Day_for_Refiling
												, B.Tax_Period_Begin_Date
												, B.Tax_Period_End_Date
												, B.Tax_Amount
												, B.Tax_Interest_Amount
												, B.Tax_Penalty_Amount
												, B.Judgment_Amount
												, B.Lien_Number
												, B.Map_Plat_ID
												, B.Mechanics_Lien_Number
												, B.Ordinance_Number
												, B.Patent_Number
												, B.Permit_Number
												, B.Resolution_Number
												, B.Tax_Account_Serial_Warrant_Number
												, B.Tax_Type
												, B.Trustees_Sale_Number
												, B.UCC_Number
												, B.Undersigned_Same_as_Borrower
												, B.Amount_Due
												, B.Amount_of_Default
												, B.Bond_Amount
												, B.Cash_Down_Amount
												, B.Contract_Amount
												, B.Collection_Costs
												, B.Unpaid_Balance
												, B.Unpaid_Balance_as_of_Modification_Date
												, B.unpaid_prinicipal_amount
												, B.[Party1_Name1_FullName]
												, B.[Party1_Name1_last_Company_Name]
												, B.[Party1_Name1_First_Name]
												, B.[Party1_Name1_Middle_Name]
												, B.[Party1_Name1_Suffix]
												, B.[Party1_Name1_Roll_Type]
												, B.[Party1_Name1_MailPropertyID]
												, B.[Party1_Name1_Address]
												, B.[Party1_Name1_PreDir]
												, B.[Party1_Name1_StreetNumber]
												, B.[Party1_Name1_StreetName]
												, B.[Party1_Name1_PostDir]
												, B.[Party1_Name1_StreetType]
												, B.[Party1_Name1_SuiteType]
												, B.[Party1_Name1_Suite]
												, B.[Party1_Name1_City]
												, B.[Party1_Name1_State]
												, B.[Party1_Name1_Zip]
												, B.[Party1_Name1_ZipPlus4]
												, B.[Party1_Name2_FullName]
												, B.[Party1_Name2_last_Company_Name]
												, B.[Party1_Name2_First_Name]
												, B.[Party1_Name2_Middle_Name]
												, B.[Party1_Name2_Suffix]
												, B.[Party1_Name2_Roll_Type]
												, B.[Party1_Name2_MailPropertyID]
												, B.[Party1_Name2_Address]
												, B.[Party1_Name2_PreDir]
												, B.[Party1_Name2_StreetNumber]
												, B.[Party1_Name2_StreetName]
												, B.[Party1_Name2_PostDir]
												, B.[Party1_Name2_StreetType]
												, B.[Party1_Name2_SuiteType]
												, B.[Party1_Name2_Suite]
												, B.[Party1_Name2_City]
												, B.[Party1_Name2_State]
												, B.[Party1_Name2_Zip]
												, B.[Party1_Name2_ZipPlus4]
												, B.[Party2_Name1_FullName]
												, B.[Party2_Name1_last_Company_Name]
												, B.[Party2_Name1_First_Name]
												, B.[Party2_Name1_Middle_Name]
												, B.[Party2_Name1_Suffix]
												, B.[Party2_Name1_Roll_Type]
												, B.[Party2_Name1_MailPropertyID]
												, B.[Party2_Name1_Address]
												, B.[Party2_Name1_PreDir]
												, B.[Party2_Name1_StreetNumber]
												, B.[Party2_Name1_StreetName]
												, B.[Party2_Name1_PostDir]
												, B.[Party2_Name1_StreetType]
												, B.[Party2_Name1_SuiteType]
												, B.[Party2_Name1_Suite]
												, B.[Party2_Name1_City]
												, B.[Party2_Name1_State]
												, B.[Party2_Name1_Zip]
												, B.[Party2_Name1_ZipPlus4]
												, B.[Party2_Name2_FullName]
												, B.[Party2_Name2_last_Company_Name]
												, B.[Party2_Name2_First_Name]
												, B.[Party2_Name2_Middle_Name]
												, B.[Party2_Name2_Suffix]
												, B.[Party2_Name2_Roll_Type]
												, B.[Party2_Name2_MailPropertyID]
												, B.[Party2_Name2_Address]
												, B.[Party2_Name2_PreDir]
												, B.[Party2_Name2_StreetNumber]
												, B.[Party2_Name2_StreetName]
												, B.[Party2_Name2_PostDir]
												, B.[Party2_Name2_StreetType]
												, B.[Party2_Name2_SuiteType]
												, B.[Party2_Name2_Suite]
												, B.[Party2_Name2_City]
												, B.[Party2_Name2_State]
												, B.[Party2_Name2_Zip]
												, B.[Party2_Name2_ZipPlus4]
												, B.[Reference_recording_year]
												, B.[reference_recording_date]
												, B.[reference_doc_number]
												, B.[reference_book]
												, B.[reference_page]
												, B.[Fmt_Reference_Doc_Number]
												, B.[Fmt_Reference_BookPAge]


										--Select B.[unpaid_prinicipal_amount]
										
										FROM x_Custom_OUTPUT_S28 a JOIN  INVL_BULK_PULL as B 
										on a.[INPUT Unique ID] = b.[INPUT KEY]
										WHERE B.ROWNUM = ''' + @BeginNbrOfTrans6 + '''
										AND A.[Record_Number] = ''1''
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			--Select [INPUT Unique ID],[Number_of_Recordings],[Record_Number] From x_Custom_OUTPUT_S28
			--where [Number_of_Recordings] > 0
			--Order by [INPUT Unique ID],[Record_Number]

			--Select * From INVL_BULK_PULL

			
			IF (Select count(*) From  [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
			where [# of Recordings] > 0) > 0

			BEGIN

			EXEC('

			--------DECODE Doc Type Category -----
			Select DocType, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DocType
			Order by DocType

			UPdate x_Custom_OUTPUT_S28
			Set DocType = case 
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJ'' then ''ABSTRACT OF JUDGMENT''
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJAMD'' then ''ABSTRACT OF JUDGMENT AMENDMENT''
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJASN'' then ''ABSTRACT OF JUDGMENT ASSIGNMENT''
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJFED'' then ''FEDERAL ABSTRACT OF JUDGMENT''
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJPRL'' then ''ABSTRACT OF JUDGMENT PARTIAL RELEASE''
			when [Doc_Category] like ''ABJ'' and DocType like ''ABJREL'' then ''ABSTRACT OF JUDGMENT  RELEASE''
			when [Doc_Category] like ''ACK'' and DocType like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [Doc_Category] like ''ACP'' and DocType like ''ACP'' then ''ACCEPTANCE''
			when [Doc_Category] like ''AFD'' and DocType like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [Doc_Category] like ''AFD'' and DocType like ''AFDTEE'' then ''AFFIDAVIT OF DEATH OF TRUSTEE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFF'' then ''AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFADD'' then ''AFFIDAVIT OF ADDRESS''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFAFX'' then ''AFFIDAVIT OF AFFIXTURE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFAUC'' then ''AFFIDAVIT OF AUCTIONEER''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFBKY'' then ''BANKRUPTCY AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFBUS'' then ''AFFIDAVIT OF CORPORATION''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCMC'' then ''AFFIDAVIT OF COMMENCEMENT/NON-COMMENCEMENT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCMP'' then ''AFFIDAVIT OF COMPLIANCE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCOV'' then ''AFFIDAVIT OF COVENANT AND AGREEMENT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCPR'' then ''COMMUNITY PROPERTY AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCPT'' then ''AFFIDAVIT OF COMPLETION''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFCUS'' then ''AFFIDAVIT OF CUSTODY OF MINOR''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFDED'' then ''AFFIDAVIT CONCERNING A DEED''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFDIV'' then ''AFFIDAVIT AS TO DIVORCE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFDOT'' then ''AFFIDAVIT AS TO DEED OF TRUST''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFEAS'' then ''AFFIDAVIT CONFINING EASEMENT IN TRACT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFERR'' then ''AFFIDAVIT OF SCRIVENERS ERROR/ERRONEOUS RECORDATION''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFETP'' then ''AFFIDAVIT OF ESTOPPEL''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFFOR'' then ''AFFIDAVIT OF FORFEITURE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFHEI'' then ''AFFIDAVIT OF HEIRSHIP''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFIDT'' then ''AFFIDAVIT OF IDENTITY''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFINH'' then ''AFFIDAVIT THAT NO INHERITANCE TAX IS DUE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFIST'' then ''AFFIDAVIT OF INTEREST''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFJDG'' then ''AFFIDAVIT AS TO JUDGMENT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFJTNTRM'' then ''AFFIDAVIT OF TERMINATION OF JOINT TENANCY <NO DEATH INVOLVED>''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLEN'' then ''AFFIDAVIT OF LIEN''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLENAGR'' then ''LIEN AGREEMENT AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLENREL'' then ''AFFIDAVIT OF RELEASE OF LIENS''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLOS'' then ''AFFIDAVIT OF LOST DOCUMENT <NOT DOT, MTG, NTE>''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLOSDOT'' then ''AFFIDAVIT OF LOST DEED OF TRUST''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLOSDTM'' then ''AFFIDAVIT OF LOST DEED OF TRUST/MORTGAGE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLOSMTG'' then ''AFFIDAVIT OF LOST MORTGAGE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFLOSNTE'' then ''AFFIDAVIT OF LOST NOTE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMAL'' then ''AFFIDAVIT OF MAILING''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMAP'' then ''MAP AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMAR'' then ''AFFIDAVIT OF MARITAL STATUS''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMGE'' then ''MORTGAGEES AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMLN'' then ''AFFIDAVIT FOR MECHANICS LIEN''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFMTGREL'' then ''AFFIDAVIT DOCUMENTING SATISFACTION OF MORTGAGE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFNAM'' then ''AFFIDAVIT OF SAME NAME''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFNCM'' then ''AFFIDAVIT OF NON-COMPLIANCE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFNMC'' then ''AFFIDAVIT OF NAME CHANGE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFOGL'' then ''OIL AND GAS LEASE AFFIDAVIT''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFPAY'' then ''AFFIDAVIT OF PAYMENT OF TAXES''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFPBL'' then ''AFFIDAVIT OF PUBLICATION''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFPOS'' then ''AFFIDAVIT OF POSSESSION''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFPUR'' then ''AFFIDAVIT OF PURCHASE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFSRV'' then ''AFFIDAVIT OF SERVICE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFTEE'' then ''AFFIDAVIT OF SUCCESSOR TRUSTEE''
			when [Doc_Category] like ''AFF'' and DocType like ''AFFTOD'' then ''TRANSFER ON DEATH AFFIDAVIT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGR'' then ''AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRADV'' then ''ADDITIONAL ADVANCE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRAER'' then ''AVIATION AGREEMENT (AIRSPACE)''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRAFR'' then ''AFFORDABLE HOUSING AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRAMD'' then ''AMENDMENT OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRANX'' then ''ANNEXATION AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRASN'' then ''ASSIGNMENT OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRASP'' then ''ASSUMPTION AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRATR'' then ''ATTORNMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRBLD'' then ''BUILDING & LOAN AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCDO'' then ''CONDOMINIUM AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCHT'' then ''CHATTEL SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCHTPRL'' then ''PARTIAL RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCHTREL'' then ''RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCPR'' then ''COMMUNITY PROPERTY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCPRMOD'' then ''MODIFICATION OF COMMUNITY PROPERTY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCPRPRL'' then ''PARTIAL RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCPRREL'' then ''RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCRL'' then ''CROSS COLLATERALIZATION AND CROSS DEFAULT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRCSD'' then ''CONSOLIDATION AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDED'' then ''AGREEMENT FOR DEED''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDEDMOD'' then ''MODIFICATION OF AGREEMENT FOR DEED''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDEDPRL'' then ''PARTIAL RELEASE OF AGREEMENT FOR DEED''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDFR'' then ''DEFERRAL AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDFRREL'' then ''RELEASE OF DEFERRAL AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDIV'' then ''DIVORCE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDOT'' then ''DEED OF TRUST AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDVL'' then ''DEVELOPMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDVLASN'' then ''ASSIGNMENT OF DEVELOPMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDVLASP'' then ''ASSUMPTION OF DEVELOPMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRDVLPRL'' then ''PARTIAL RELEASE OF DEVELOPMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRENC'' then ''ENCROACHMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRENG'' then ''ENERGY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRENV'' then ''ENVIRONMENTAL INDEMNITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRESC'' then ''ESCROW AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRFAC'' then ''FACILITIES AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRFML'' then ''FARMLAND DEVELOPMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRFOR'' then ''AGREEMENT TO FORFEIT PROPERTY''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRIDM'' then ''INDEMNITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRJOI'' then ''JOINDER AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLEN'' then ''LIEN AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLENAMD'' then ''AMENDMENT TO LIEN AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLENREL'' then ''RELEASE OF LIEN AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLIC'' then ''LICENSE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLICREL'' then ''CANCELLATION OF LICENSE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLLA'' then ''AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLLAMOD'' then ''MODIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLLARAT'' then ''RATIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLON'' then ''LOAN AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRLONMOD'' then ''LOAN MODIFICATION AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRMAI'' then ''ROAD MAINTENANCE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRMAR'' then ''MARRIAGE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRMER'' then ''MERGER AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRMOD'' then ''MODIFICATION OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRMTG'' then ''MORTGAGE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRNDA'' then ''NON-DISTURBANCE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRNEN'' then ''AGREEMENT NOT TO ENCUMBER''
			when [Doc_Category] like ''AGR'' and DocType like ''AGROGL'' then ''OIL AND GAS AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPAY'' then ''AGREEMENT FOR PAYMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPLD'' then ''NEGATIVE PLEDGE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPRL'' then ''PARTIAL RELEASE OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPUR'' then ''PURCHASE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPURREL'' then ''TERMINATION OF PURCHASE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRPWL'' then ''PARTY WALL AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRRAT'' then ''RATIFICATION OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRREG'' then ''REGULATORY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRREI'' then ''REINSTATEMENT OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRREL'' then ''RELEASE OF AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRRMB'' then ''AGREEMENT TO REIMBURSE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRRMBREL'' then ''RELEASE OF AGREEMENT TO REIMBURSE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSEC'' then ''SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSECASN'' then ''ASSIGNMENT OF SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSECREL'' then ''RELEASE OF SECURITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSEP'' then ''SEPARATION AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSET'' then ''SETTLEMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSETREL'' then ''RELEASE OF SETTLEMENT AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSIT'' then ''SITE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSITAMD'' then ''AMENDED SITE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLE'' then ''AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEAMD'' then ''AMENDMENT OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEASN'' then ''ASSIGNMENT OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEEXT'' then ''EXTENSION OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEMOD'' then ''MODIFICATION OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEPRL'' then ''PARTIAL RELEASE OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSLEREL'' then ''RELEASE OF AGREEMENT OF SALE''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRSWR'' then ''SEWER AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRUSE'' then ''USE AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRUTL'' then ''UTILITY AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRVIO'' then ''AGREEMENT TO CORRECT CODE VIOLATION''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRWTR'' then ''WATER AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRZON'' then ''ZONING AGREEMENT''
			when [Doc_Category] like ''AGR'' and DocType like ''AGRZONREL'' then ''RELEASE OF ZONING AGREEMENT''
			when [Doc_Category] like ''ALN'' and DocType like ''ALN'' then ''ASSESSMENT LIEN''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNCFD'' then ''COMMUNITY FACILITIES DISTRICT LIEN''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [Doc_Category] like ''AMD'' and DocType like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [Doc_Category] like ''ANM'' and DocType like ''ANM'' then ''ASSUMED NAME''
			when [Doc_Category] like ''ANM'' and DocType like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [Doc_Category] like ''APL'' and DocType like ''APL'' then ''APPLICATION''
			when [Doc_Category] like ''APL'' and DocType like ''APLAMD'' then ''APPLICATION AMENDMENT''
			when [Doc_Category] like ''APL'' and DocType like ''APLASN'' then ''APPLICATION ASSIGNMENT''
			when [Doc_Category] like ''ASR'' and DocType like ''ASR'' then ''ASSIGNMENT OF RENTS''
			when [Doc_Category] like ''ASR'' and DocType like ''ASRAMD'' then ''ASSIGNMENT OF RENTS AMENDMENT''
			when [Doc_Category] like ''ASR'' and DocType like ''ASRASN'' then ''ASSIGNMENT OF RENTS ASSIGNMENT''
			when [Doc_Category] like ''ASR'' and DocType like ''ASRPRL'' then ''ASSIGNMENT OF RENTS PARTIAL RELEASE''
			when [Doc_Category] like ''ASR'' and DocType like ''ASRREL'' then ''ASSIGNMENT OF RENTS  RELEASE''
			when [Doc_Category] like ''BKY'' and DocType like ''BKY'' then ''BANKRUPTCY''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYAMD'' then ''BANKRUPTCY AMENDMENT''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYCNV'' then ''BANKRUPTCY CONVERSION''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYDIS'' then ''BANKRUPTCY DISCHARGE''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYDSM'' then ''BANKRUPTCY DISMISSAL''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYJDG'' then ''BANKRUPTCY JUDGMENT''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYORD'' then ''BANKRUPTCY ORDER''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYPRL'' then ''BANKRUPTCY PARTIAL RELEASE''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYREL'' then ''BANKRUPTCY RELEASE''
			when [Doc_Category] like ''BKY'' and DocType like ''BKYSPL'' then ''BANKRUPTCY SPLIT''
			when [Doc_Category] like ''BND'' and DocType like ''BND'' then ''BOND''
			when [Doc_Category] like ''BND'' and DocType like ''BNDASN'' then ''BOND ASSIGNMENT''
			when [Doc_Category] like ''BND'' and DocType like ''BNDMLN'' then ''MECHANICS LIEN BOND''
			when [Doc_Category] like ''BND'' and DocType like ''BNDNTY'' then ''NOTARY BOND''
			when [Doc_Category] like ''BND'' and DocType like ''BNDPRL'' then ''BOND PARTIAL RELEASE''
			when [Doc_Category] like ''BND'' and DocType like ''BNDREL'' then ''BOND RELEASE''
			when [Doc_Category] like ''BND'' and DocType like ''BNDSUR'' then ''SURETY BOND''
			when [Doc_Category] like ''BSL'' and DocType like ''BSL'' then ''BILL OF SALE''
			when [Doc_Category] like ''BSL'' and DocType like ''BSLASN'' then ''BILL OF SALE ASSIGNMENT''
			when [Doc_Category] like ''BSL'' and DocType like ''BSLMOD'' then ''BILL OF SALE MODIFICATION''
			when [Doc_Category] like ''BUS'' and DocType like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSAMD'' then ''AMENDED BUSINESS CERTIFICATE''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSAUT'' then ''BUSINESS SIGNING AUTHORIZATION''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSFIC'' then ''AFFIDAVIT OF DOING BUSINESS UNDER FICTITIOUS NAME''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSLIQ'' then ''NOTICE OF INTENDED TRANSFER OF RETAIL ALCOHOLIC BEVERAGE LICENSE''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSMER'' then ''BUSINESS MERGER''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSREL'' then ''RELEASE OF BUSINESS CERTIFICATE''
			when [Doc_Category] like ''BUS'' and DocType like ''BUSSLE'' then ''BUSINESS SALE''
			when [Doc_Category] like ''CAV'' and DocType like ''CAV'' then ''CAVEAT''
			when [Doc_Category] like ''CAV'' and DocType like ''CAVREL'' then ''CAVEAT RELEASE''
			when [Doc_Category] like ''CCR'' and DocType like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRACK'' then ''ACKNOWLEDGMENT OF DECLARATION OF RESTRICTIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRACP'' then ''ACCEPTANCE OF TERMS, COVENANT & CONDITIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRADP'' then ''ADOPTION & AFFIRMATION OF DECLARATION ESTABLISHING COVENANTS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRAMD'' then ''DECLARATION OF RESTRICTIONS AMENDMENT''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRANX'' then ''DECLARATION OF COVENANTS ANNEXATION''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRASN'' then ''ASSIGNMENT OF DECLARATION OF RESTRICTIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRBLD'' then ''DESIGNATION OF BUILDER UNDER DECLARATION OF RESTRICTIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRCNS'' then ''CONSENT TO DECLARATION OF RESTRICTIONS''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRMOD'' then ''DECLARATION OF RESTRICTIONS MODIFICATION''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRPET'' then ''PETITION FOR ANNEXATION & DECLARATION OF COVENANT''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRPRL'' then ''DECLARATION OF RESTRICTIONS PARTIAL RELEASE''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRRAT'' then ''COVENANTS & RESTRICTIONS RATIFICATION''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRREL'' then ''DECLARATION OF RESTRICTIONS RELEASE''
			when [Doc_Category] like ''CCR'' and DocType like ''CCRUSE'' then ''DECLARATION OF RESTRICTIONS ON USE''
			when [Doc_Category] like ''CER'' and DocType like ''CER'' then ''CERTIFICATE''
			when [Doc_Category] like ''CER'' and DocType like ''CERAMD'' then ''CERTIFICATE AMENDMENT''
			when [Doc_Category] like ''CER'' and DocType like ''CERASN'' then ''CERTIFICATE ASSIGNMENT''
			when [Doc_Category] like ''CER'' and DocType like ''CERCMP'' then ''CERTIFICATE OF COMPLIANCE''
			when [Doc_Category] like ''CER'' and DocType like ''CERCMPHOA'' then ''CERTIFICATE OF COMPLIANCE <HOA>''
			when [Doc_Category] like ''CER'' and DocType like ''CERCOR'' then ''CERTIFICATE OF CORRECTION''
			when [Doc_Category] like ''CER'' and DocType like ''CERCPT'' then ''CERTIFICATE OF COMPLETION''
			when [Doc_Category] like ''CER'' and DocType like ''CERDEA'' then ''DEATH CERTIFICATE''
			when [Doc_Category] like ''CER'' and DocType like ''CERDST'' then ''CERTIFICATE OF DISTRIBUTION''
			when [Doc_Category] like ''CER'' and DocType like ''CERERR'' then ''CERTIFICATE  OF SCRIVENERS ERROR''
			when [Doc_Category] like ''CER'' and DocType like ''CERLLA'' then ''CERTIFICATE OF LOT LINE ADJUSTMENTS''
			when [Doc_Category] like ''CER'' and DocType like ''CERMAR'' then ''CERTIFICATE OF MARRIAGE''
			when [Doc_Category] like ''CER'' and DocType like ''CERNCM'' then ''CERTIFICATE OF NON-COMPLIANCE''
			when [Doc_Category] like ''CER'' and DocType like ''CERNCMHOA'' then ''CERTIFICATE OF NON-COMPLIANCE <HOA>''
			when [Doc_Category] like ''CER'' and DocType like ''CERREL'' then ''CERTIFICATE OF CANCELLATION/RELEASE''
			when [Doc_Category] like ''CER'' and DocType like ''CERSLE'' then ''CERTIFICATE OF SALE <NOT TAX OR FORECLOSURE>''
			when [Doc_Category] like ''CER'' and DocType like ''CERTOR'' then ''TORRENS CERTIFICATE''
			when [Doc_Category] like ''CER'' and DocType like ''CERTTL'' then ''CERTIFICATE OF TITLE''
			when [Doc_Category] like ''CER'' and DocType like ''CERWTR'' then ''CERTIFICATE OF WATER RIGHTS''
			when [Doc_Category] like ''CHJ'' and DocType like ''CHJ'' then ''CHANGE OF JUDGE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNS'' then ''CONSENT''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSCDO'' then ''CONSENT TO CONDOMINIUM CONVERSION''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSCUS'' then ''CONSENT OF PARENT FOR TEMPORARY CUSTODY''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSDED'' then ''CONSENT TO DEED''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSDOT'' then ''CONSENT TO DEED OF TRUST''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSLSE'' then ''LANDORDS CONSENT TO  LEASE ASSIGNMENT/SUBLEASE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSMAP'' then ''CONSENT TO MAP''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSMTG'' then ''CONSENT TO MORTGAGE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSNTE'' then ''CONSENT TO NOTE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSOGL'' then ''CONSENT TO OIL AND GAS LEASE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSOPT'' then ''CONSENT OF OPTIONEE''
			when [Doc_Category] like ''CNS'' and DocType like ''CNSRES'' then ''CONSENT & APPROVAL OF RESTRICTIONS''
			when [Doc_Category] like ''COV'' and DocType like ''COV'' then ''COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVACK'' then ''ACKNOWLEGMENT OF COVENANTS''
			when [Doc_Category] like ''COV'' and DocType like ''COVAGR'' then ''COVENANT AGREEMENT''
			when [Doc_Category] like ''COV'' and DocType like ''COVAGRAMD'' then ''AMENDMENT OF COVENANT AGREEMENT''
			when [Doc_Category] like ''COV'' and DocType like ''COVAGRREL'' then ''RELEASE OF COVENANT AGREEMENT''
			when [Doc_Category] like ''COV'' and DocType like ''COVAMD'' then ''AMENDMENT OF COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVCNS'' then ''CONSENT TO COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVEAS'' then ''DECLARATION OF EASEMENTS COVENANTS''
			when [Doc_Category] like ''COV'' and DocType like ''COVENV'' then ''ENVIRONMENTAL COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVIMP'' then ''COVENANT OF IMPROVEMENTS''
			when [Doc_Category] like ''COV'' and DocType like ''COVLLA'' then ''DECLARATION OF BOUNDARY LINE ADJUSTMENT & COVENANTS''
			when [Doc_Category] like ''COV'' and DocType like ''COVMOD'' then ''COVENANT MODIFICATION''
			when [Doc_Category] like ''COV'' and DocType like ''COVOPT'' then ''AFFORDABILITY COVENANT AND OPTION TO PURCHASE''
			when [Doc_Category] like ''COV'' and DocType like ''COVPRK'' then ''COVENANT OF PARKING''
			when [Doc_Category] like ''COV'' and DocType like ''COVPRL'' then ''PARTIAL RELEASE OF COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVREL'' then ''RELEASE OF COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVSLM'' then ''SUPPLEMENTAL DECLARATION OF COVENANTS''
			when [Doc_Category] like ''COV'' and DocType like ''COVUSE'' then ''AGRICULTURAL STRUCTURE USE COVENANT''
			when [Doc_Category] like ''COV'' and DocType like ''COVVAR'' then ''VARIANCE/SETABCK COVENANT''
			when [Doc_Category] like ''CRP'' and DocType like ''CRP'' then ''CORPORATION''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPAMD'' then ''CORPORATION AMENDMENT''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPBYL'' then ''CORPORATE BYLAWS''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPBYLAMD'' then ''AMENDMENT TO CORPORATE BYLAWS''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPBYLREL'' then ''REVOCATION OF CORPORATE BYLAWS''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPNMC'' then ''CORPORATION NAME CHANGE''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPREI'' then ''CORPORATION REINSTATEMENT''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPREL'' then ''REVOCATION OF CORPORATION''
			when [Doc_Category] like ''CRP'' and DocType like ''CRPSPN'' then ''SUSPENSION OF CORPORATION''
			when [Doc_Category] like ''CTR'' and DocType like ''CTR'' then ''CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRAGL'' then ''WILLIAMSON ACT CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRAMD'' then ''CONTRACT AMENDMENT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRASN'' then ''CONTRACT ASSIGNMENT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRASP'' then ''CONTRACT ASSUMPTION''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRBRE'' then ''CONTRACT BREACH''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRCHT'' then ''PERSONAL PROPERTY CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRCHTASN'' then ''ASSIGNMENT OF PERSONAL PROPERTY CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRCST'' then ''CONSTRUCTION CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRDED'' then ''CONTRACT FOR DEED''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRDEDREL'' then ''CONTRACT FOR DEED RELEASE''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRENG'' then ''ENERGY CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRLON'' then ''LOAN CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRMAR'' then ''MARRIAGE CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRMOD'' then ''CONTRACT MODIFICATION''
			when [Doc_Category] like ''CTR'' and DocType like ''CTROGL'' then ''OIL & GAS CONTRACT''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRPRL'' then ''CONTRACT PARTIAL RELEASE''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRREI'' then ''CONTRACT REINSTATE''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRREL'' then ''CONTRACT RELEASE''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRSLE'' then ''CONTRACT OF SALE''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRUTL'' then ''CONTRACT FOR UTILITIES''
			when [Doc_Category] like ''CTR'' and DocType like ''CTRWTR'' then ''CONTRACT FOR WATER RIGHTS''
			when [Doc_Category] like ''DCL'' and DocType like ''DCL'' then ''DECLARATION''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLAGL'' then ''DECLARATION OF WILLIAMSON ACT RESTRICTED LAND''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLAMD'' then ''DECLARATION AMENDMENT''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLDEA'' then ''DECLARATION OF DEATH''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLMAR'' then ''DECLARATION REGARDING MARRIAGE''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLPRL'' then ''DECLARATION PARTIAL RELEASE''
			when [Doc_Category] like ''DCL'' and DocType like ''DCLREL'' then ''DECLARATION RELEASE''
			when [Doc_Category] like ''DCR'' and DocType like ''DCR'' then ''DECREE''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRDEA'' then ''DECREE ESTABLISHING FACT OF DEATH''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRDIV'' then ''DECREE OF DIVORCE''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRDST'' then ''DECREE OF DISTRIBUTION''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRLFE'' then ''DECREE TERMINATING LIFE ESTATE''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRMOD'' then ''DECREE MODIFICATION''
			when [Doc_Category] like ''DCR'' and DocType like ''DCRQUI'' then ''QUIET TITLE DECREE''
			when [Doc_Category] like ''DSC'' and DocType like ''DSC'' then ''DISCLAIMER''
			when [Doc_Category] like ''DSM'' and DocType like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [Doc_Category] like ''DTM'' and DocType like ''DTM'' then ''MORTGAGE, DEED OF TRUST''
			when [Doc_Category] like ''DTM'' and DocType like ''DTM2'' then ''SECOND MORTGAGE, DEED OF TRUST''
			when [Doc_Category] like ''EAS'' and DocType like ''EAS'' then ''EASEMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASAGR'' then ''EASEMENT AGREEMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASAMD'' then ''EASEMENT AMENDMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASASN'' then ''EASEMENT ASSIGNMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASCNS'' then ''CONSENT TO EASEMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASCNSDOT'' then ''BENEFICIARIES CONSENT TO EASEMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASCTR'' then ''EASEMENT CONTRACT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASDED'' then ''EASEMENT DEED''
			when [Doc_Category] like ''EAS'' and DocType like ''EASDEDAMD'' then ''DEED EASEMENT AMENDMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASPRL'' then ''EASEMENT PARTIAL RELEASE''
			when [Doc_Category] like ''EAS'' and DocType like ''EASRAT'' then ''RATIFICATION OF EASEMENT''
			when [Doc_Category] like ''EAS'' and DocType like ''EASREL'' then ''EASEMENT RELEASE''
			when [Doc_Category] like ''EAS'' and DocType like ''EASSUB'' then ''EASEMENT SUBORDINATION''
			when [Doc_Category] like ''ELN'' and DocType like ''ELN'' then ''ECONOMIC LIEN''
			when [Doc_Category] like ''ELN'' and DocType like ''ELNPRL'' then ''PARTIAL RELEASE OF ECONOMIC LIEN''
			when [Doc_Category] like ''ELN'' and DocType like ''ELNREL'' then ''RELEASE OF ECONOMIC LIEN''
			when [Doc_Category] like ''EXC'' and DocType like ''EXC'' then ''EXECUTION''
			when [Doc_Category] like ''EXC'' and DocType like ''EXCPRL'' then ''EXECUTION PARTIAL RELEASE''
			when [Doc_Category] like ''EXC'' and DocType like ''EXCREL'' then ''EXECUTION RELEASE''
			when [Doc_Category] like ''FLN'' and DocType like ''FLN'' then ''FEDERAL TAX LIEN''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNAMD'' then ''FEDERAL TAX LIEN AMENDMENT''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNEST'' then ''FEDERAL ESTATE TAX LIEN''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNEXT'' then ''FEDERAL TAX LIEN EXTENSION''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNFIL'' then ''FEDERAL TAX LIEN REFILING''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNINH'' then ''FEDERAL INHERITANCE TAX LIEN''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNMOD'' then ''FEDERAL TAX LIEN MODIFICATION''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNNON'' then ''FEDERAL TAX LIEN NON-ATTACHMENT''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNPRL'' then ''FEDERAL TAX LIEN PARTIAL RELEASE ''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNREL'' then ''FEDERAL TAX LIEN  RELEASE ''
			when [Doc_Category] like ''FLN'' and DocType like ''FLNSUB'' then ''FEDERAL LIEN SUBORDINATION''
			when [Doc_Category] like ''INJ'' and DocType like ''INJ'' then ''INJUCTION''
			when [Doc_Category] like ''INJ'' and DocType like ''INJAMD'' then ''INJUCTION AMENDMENT''
			when [Doc_Category] like ''INJ'' and DocType like ''INJPRL'' then ''INJUCTION PARTIAL RELEASE''
			when [Doc_Category] like ''INJ'' and DocType like ''INJREL'' then ''INJUCTION RELEASE''
			when [Doc_Category] like ''JDG'' and DocType like ''JDG'' then ''JUDGMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGAMD'' then ''JUDGMENT AMENDMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGASN'' then ''JUDGMENT ASSIGNMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGDEA'' then ''JUDGMENT DEATH''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGDIV'' then ''DIVORCE JUDGMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGDOM'' then ''JUDGMENT  <DOMESTIC MATTERS>''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGDOT'' then ''JUDGMENT REGARDING DEED OF TRUST''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGDST'' then ''JUDGMENT DISTRIBUTION''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGEVT'' then ''JUDGMENT OF POSSESSION & EVICTION''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGFED'' then ''FEDERAL JUDGMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGLEN'' then ''JUDGMENT LIEN''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGLENASN'' then ''ASSIGNMENT OF JUDGMENT LIEN''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGLENREL'' then ''JUDGMENT LIEN RELEASE''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGLISREL'' then ''JUDGMENT LIS PENDENS''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGMOD'' then ''JUDGMENT MODIFICATION''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGMTG'' then ''JUDGMENT AFFECTING MORTGAGE''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGPRL'' then ''JUDGMENT PARTIAL RELEASE''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGQUI'' then ''QUIET TITLE JUDGMENT''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGREL'' then ''JUDGMENT RELEASE''
			when [Doc_Category] like ''JDG'' and DocType like ''JDGSUB'' then ''JUDGMENT SUBORDINATION''
			when [Doc_Category] like ''JTV'' and DocType like ''JTV'' then ''JOINT VENTURE''
			when [Doc_Category] like ''JTV'' and DocType like ''JTVAMD'' then ''JOINT VENTURE AMENDMENT''
			when [Doc_Category] like ''JTV'' and DocType like ''JTVASN'' then ''JOINT VENTURE ASSIGNMENT''
			when [Doc_Category] like ''JTV'' and DocType like ''JTVREL'' then ''JOINT VENTURE DISSOLUTION''
			when [Doc_Category] like ''LEN'' and DocType like ''LEN'' then ''LEIN <GENERAL>''
			when [Doc_Category] like ''LEN'' and DocType like ''LENAMD'' then ''LIEN AMENDMENT''
			when [Doc_Category] like ''LEN'' and DocType like ''LENASN'' then ''LIEN ASSIGNMENT''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCNT'' then ''COUNTY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCNTPRL'' then ''PARTIAL RELASE OF COUNTY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCNTREL'' then ''RELEASE OF COUNTY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCTY'' then ''CITY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCTYPRL'' then ''PARTIAL RELEASE OF CITY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENCTYREL'' then ''RELEASE OF CITY LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENDOJ'' then ''DEPARTMENT OF JUSTICE LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENDOJPRL'' then ''PARTIAL RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENDOJREL'' then ''RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENENV'' then ''ENVIRONMENTAL LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENEXT'' then ''LIEN EXTENSION''
			when [Doc_Category] like ''LEN'' and DocType like ''LENGRB'' then ''GARBAGE LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENMED'' then ''MEDICAL LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENMEDPRL'' then ''PARTIAL RELEASE OF MEDICAL LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENMEDREL'' then ''RELEASE OF MEDICAL LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENMOD'' then ''LIEN MODIFICATION''
			when [Doc_Category] like ''LEN'' and DocType like ''LENOGL'' then ''OIL & GAS LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENOGLREL'' then ''RELEASE OF OIL & GAS LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENORS'' then ''ORS LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENPPT'' then ''POSTPONED PROPERTY TAX LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENPRL'' then ''LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''LEN'' and DocType like ''LENRAT'' then ''RATIFICATION OF LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENREL'' then ''LIEN RELEASE''
			when [Doc_Category] like ''LEN'' and DocType like ''LENSLE'' then ''NOTICE OF SALE <LIEN>''
			when [Doc_Category] like ''LEN'' and DocType like ''LENSUB'' then ''LIEN SUBORDINATION''
			when [Doc_Category] like ''LEN'' and DocType like ''LENSWR'' then ''SEWER LIEN''
			when [Doc_Category] like ''LEN'' and DocType like ''LENUTL'' then ''UTILITY LIEN''
			when [Doc_Category] like ''LEV'' and DocType like ''LEV'' then ''LEVY''
			when [Doc_Category] like ''LEV'' and DocType like ''LEVPRL'' then ''LEVY PARTIAL RELEASE''
			when [Doc_Category] like ''LEV'' and DocType like ''LEVREL'' then ''LEVY RELEASE''
			when [Doc_Category] like ''LEV'' and DocType like ''LEVSLE'' then ''LEVY SALE''
			when [Doc_Category] like ''LIC'' and DocType like ''LIC'' then ''LICENSE''
			when [Doc_Category] like ''LIC'' and DocType like ''LICAMD'' then ''LICENSE AMENDMENT''
			when [Doc_Category] like ''LIC'' and DocType like ''LICASN'' then ''LICENSE ASSIGNMENT''
			when [Doc_Category] like ''LIC'' and DocType like ''LICREL'' then ''EXPIRATION OF LICENSE''
			when [Doc_Category] like ''LID'' and DocType like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [Doc_Category] like ''LIS'' and DocType like ''LIS'' then ''LIS PENDENS''
			when [Doc_Category] like ''LIS'' and DocType like ''LISAMD'' then ''LIS PENDENS AMENDMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISASN'' then ''LIS PENDENS ASSIGNMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISHLN'' then ''LIS PENDENS <HOA>''
			when [Doc_Category] like ''LIS'' and DocType like ''LISHLNAMD'' then ''LIS PENDENS <HOA> AMENDMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISHLNASN'' then ''LIS PENDENS <HOA> ASSIGNMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISHLNPRL'' then ''LIS PENDENS <HOA> PARTIAL RELEASE''
			when [Doc_Category] like ''LIS'' and DocType like ''LISHLNREL'' then ''LIS PENDENS <HOA> RELEASE''
			when [Doc_Category] like ''LIS'' and DocType like ''LISMLN'' then ''LIS PENDENS - MECHANICS LIEN''
			when [Doc_Category] like ''LIS'' and DocType like ''LISMLNAMD'' then ''LIS PENDENS <MECHANICS LIEN> AMENDMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISMLNASN'' then ''LIS PENDENS <MECHANICS LIEN> ASSIGNMENT''
			when [Doc_Category] like ''LIS'' and DocType like ''LISMLNPRL'' then ''LIS PENDENS <MECHANICS LIEN> PARTIAL RELEASE''
			when [Doc_Category] like ''LIS'' and DocType like ''LISMLNREL'' then ''LIS PENDENS <MECHANICS LIEN> RELEASE''
			when [Doc_Category] like ''LIS'' and DocType like ''LISPRL'' then ''LIS PENDENS PARTIAL RELEASE''
			when [Doc_Category] like ''LIS'' and DocType like ''LISPRO'' then ''LIS PENDENS - PROBATE ACTION''
			when [Doc_Category] like ''LIS'' and DocType like ''LISQUI'' then ''QUIET TITLE NOTICE OF LIS PENDENS''
			when [Doc_Category] like ''LIS'' and DocType like ''LISREL'' then ''LIS PENDENS RELEASE''
			when [Doc_Category] like ''LLC'' and DocType like ''LLC'' then ''LLC''
			when [Doc_Category] like ''LLC'' and DocType like ''LLCAGR'' then ''LIMITED LIABILITY COMPANY OPERATING AGREEMENT''
			when [Doc_Category] like ''LLC'' and DocType like ''LLCAMD'' then ''LLC AMENDMENT''
			when [Doc_Category] like ''LLC'' and DocType like ''LLCASN'' then ''LLC ASSIGNMENT''
			when [Doc_Category] like ''LLC'' and DocType like ''LLCREL'' then ''LLC RELEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSE'' then ''LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEAMD'' then ''LEASE AMENDMENT''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEASN'' then ''ASSIGNMENT OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEASNPRL'' then ''PARTIAL RELEASE OF ASSIGNMENT OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEASNREL'' then ''RELEASE OF ASSIGNMENT OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEASP'' then ''ASSUMPTION OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEBRE'' then ''BREACH OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEBREREL'' then ''RELEASE OF BREACH OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSECHT'' then ''EQUIPMENT LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEDSC'' then ''LEASE DISCLAIMER''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEEXT'' then ''LEASE EXTENSION''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEMASASN'' then ''ASSIGNMENT OF MASTER LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEMOD'' then ''LEASE MODIFICATION''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEOPT'' then ''LEASE OPTION''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEPRL'' then ''LEASE PARTIAL RELEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEQCL'' then ''QUITCLAIM OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSERAT'' then ''LEASE RATIFICATION''
			when [Doc_Category] like ''LSE'' and DocType like ''LSEREL'' then ''LEASE RELEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSERIP'' then ''RIPARIAN LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSESBL'' then ''SUBLEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSESLM'' then ''LEASE SUPPLEMENT''
			when [Doc_Category] like ''LSE'' and DocType like ''LSESUB'' then ''SUBORDINATION OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSESUBASN'' then ''ASSIGNMENT OF SUBORDINATION OF LEASE''
			when [Doc_Category] like ''LSE'' and DocType like ''LSESUBREL'' then ''SUBORDINATION OF LEASE RELEASE''
			when [Doc_Category] like ''MAP'' and DocType like ''MAP'' then ''MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPAGL'' then ''AGRICULTURAL MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPAMD'' then ''MAP AMENDMENT''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPANX'' then ''ANNEXATION MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPAPL'' then ''MAP APPLICATION''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPAPV'' then ''MAP APPROVAL''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPASM'' then ''ASSESSMENT DISTRICT MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPCDO'' then ''CONDOMINIUM MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPCEM'' then ''CEMETARY MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPCFD'' then ''COMMUNITY FACILITY DISTRICT MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPDIV'' then ''DIVISION OF LAND MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPGUR'' then ''MAP GUARANTY''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPMCL'' then ''MINING CLAIM MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPMOD'' then ''MAP MODIFICATION''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPPCL'' then ''PARCEL MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPRAT'' then ''MAP RATIFICATION''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPRVN'' then ''REVERSION TO ACERAGE MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPSBD'' then ''SUBDIVISION MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPSHP'' then ''SHORT PLAT''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPSPV'' then ''SUPERVISORS PLAT''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPSVY'' then ''SURVEY MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPTRA'' then ''TRACT MAP''
			when [Doc_Category] like ''MAP'' and DocType like ''MAPVAC'' then ''MAP VACATION''
			when [Doc_Category] like ''MCL'' and DocType like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLJTV'' then ''AFFIDAVIT OF MINING VENTURE AGREEMENT''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLJTVREL'' then ''MINING VENTURE AGREEMENT TERMINATION''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLLOC'' then ''CERTIFICATE OF LOCATION/NOTICE OF MINING LOCATION''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLNIH'' then ''NOTICE OF INTENTION TO HOLD <MINING CLAIM>''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLPAY'' then ''AFFIDAVIT OF EVIDENCE OF PAYMENT''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLREL'' then ''NOTICE OF ABANDONMENT OF MINING CLAIM''
			when [Doc_Category] like ''MCL'' and DocType like ''MCLWRK'' then ''AFFIDAVIT OF LABOR/PROOF OF LABOR''
			when [Doc_Category] like ''MEM'' and DocType like ''MEM'' then ''MEMORANDUM''
			when [Doc_Category] like ''MEM'' and DocType like ''MEMLEN'' then ''MEMORANDUM OF LIEN AFFECTING REAL PROPERTY''
			when [Doc_Category] like ''MEM'' and DocType like ''MEMSLE'' then ''MEMORANDUM OF SALE''
			when [Doc_Category] like ''MIN'' and DocType like ''MIN'' then ''MINERAL INTEREST''
			when [Doc_Category] like ''MLN'' and DocType like ''MLN'' then ''MECHANICS LIEN''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNAMD'' then ''MECHANICS LIEN AMENDMENT''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNASN'' then ''MECHANICS LIEN ASSIGNMENT''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNEXT'' then ''MECHANICS LIEN EXTENSION''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNMOD'' then ''MECHANICS LIEN MODIFICATION''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNPRL'' then ''MECHANICS LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''MLN'' and DocType like ''MLNREL'' then ''MECHANICS LIEN RELEASE''
			when [Doc_Category] like ''MTY'' and DocType like ''MTY'' then ''MILITARY''
			when [Doc_Category] like ''NOI'' and DocType like ''NOI'' then ''NOTICE OF INTENT''
			when [Doc_Category] like ''NOI'' and DocType like ''NOIRED'' then ''NOTICE OF INTENT TO REDEEM''
			when [Doc_Category] like ''NOT'' and DocType like ''NOT'' then ''NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTAMD'' then ''AMENDED NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTAPE'' then ''NOTICE OF APPEAL''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTATT'' then ''NOTICE OF ATTACHMENT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTBLD'' then ''NOTICE OF SUBSTANDARD BUILDING''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTBRE'' then ''NOTICE OF BREACH''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTBREREL'' then ''CANCELLATION OF NOTICE OF BREACH''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCMC'' then ''NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCMCPRL'' then ''PARTIAL RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCMCREL'' then ''RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCMP'' then ''NOTICE OF COMPLIANCE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCPRREL'' then ''NOTICE OF TERMINATION OF INTEREST IN COMMUNITY PROPERTY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCPT'' then ''NOTICE OF COMPLETION''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTCSE'' then ''NOTICE OF CESSATION''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDEA'' then ''NOTICE OF DEATH''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDLQ'' then ''NOTICE OF DELINQUENCY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDML'' then ''NOTICE OF DEMOLITION''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDOT'' then ''NOTICE REGARDING DEED OF TRUST''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDSB'' then ''NOTICE OF DISBURSEMENT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTDSC'' then ''DISCLAIMER NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTERR'' then ''NOTICE OF SCRIVENERS ERROR''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTEVT'' then ''NOTICE OF EVICTION''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTIST'' then ''NOTICE OF INTEREST''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTISTPRL'' then ''PARTIAL RELEASE OF NOTICE OF INTEREST''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTISTREL'' then ''RELEASE OF NOTICE OF INTEREST''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLFE'' then ''NOTICE OF LIFE ESTATE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLFEREL'' then ''RELEASE OF NOTICE OF LIFE ESTATE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLIB'' then ''NOTICE OF NON-LIABILITY ''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLIBREL'' then ''RELEASE OF NOTICE OF NON-LIABILITY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLID'' then ''NOTICE OF LOCAL IMPROVEMENT DISTRICT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLLA'' then ''NOTICE OF LOT MERGER''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTLLAREL'' then ''NOTICE OF LOT MERGER REVERSAL''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTMH'' then ''NOTICE OF MANUFACTURED HOME''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTMIN'' then ''NOTICE TO PRESERVE MINERAL RIGHTS''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTMTG'' then ''NOTICE REGARDING MORTGAGE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTNNR'' then ''NOTICE OF NON RESPONSIBILITY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTNNRREL'' then ''RELEASE OF NOTICE OF NON RESPONSIBILITY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTPLD'' then ''NOTICE OF PLEDGE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTPLDREL'' then ''RELEASE OF NOTICE OF PLEDGE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTPRL'' then ''PARTIAL RELEASE OF NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTQNT'' then ''QUARANTINED PROPERTY  NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTREL'' then ''RELEASE OF NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSET'' then ''NOTICE OF SETTLEMENT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSTO'' then ''STOP NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSVY'' then ''SURVEY NOTICE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSWR'' then ''NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSWRREL'' then ''RELEASE OF NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTSZD'' then ''NOTICE OF SEIZURE''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTTAX'' then ''NOTICE OF TAX''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTTAXREL'' then ''RESCISSION OF NOTICE OF TAX DEFAULTED PROPERTY''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTTRN'' then ''NOTICE OF TRANSFER''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTTRU'' then ''NOTICE OF TRUST''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTVIO'' then ''NOTICE OF VIOLATION''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTWTH'' then ''NOTICE TO WITHHOLD''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTWTR'' then ''NOTICE OF WATER RIGHT''
			when [Doc_Category] like ''NOT'' and DocType like ''NOTWTRREL'' then ''RELEASE OF NOTICE OF WATER RIGHT''
			when [Doc_Category] like ''NTE'' and DocType like ''NTE'' then ''PROMISSORY NOTE''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEADV'' then ''NOTE FOR ADVANCES''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEAMD'' then ''NOTE AMENDMENT''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEASN'' then ''NOTE ASSIGNMENT''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEASP'' then ''LIEN NOTE ASSUMPTION''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEPRL'' then ''LIEN NOTE PARTIAL RELEASE''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEREI'' then ''REINSTATEMENT OF NOTE''
			when [Doc_Category] like ''NTE'' and DocType like ''NTEREL'' then ''NOTE RELEASE''
			when [Doc_Category] like ''OAT'' and DocType like ''OAT'' then ''OATH''
			when [Doc_Category] like ''ODN'' and DocType like ''ODN'' then ''ORDINANCE''
			when [Doc_Category] like ''ODN'' and DocType like ''ODNREL'' then ''ORDINANCE RELEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGL'' then ''OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLAMD'' then ''AMENDED OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLASN'' then ''ASSIGNMENT OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLDSC'' then ''DISCLAIMER OF OIL & GAS RIGHTS''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLINT'' then ''OIL & GAS INTEREST''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLMOD'' then ''MODIFICATION OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLOPT'' then ''OPTION FOR OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLOPTAMD'' then ''AMENDED OPTION FOR OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLPRA'' then ''PARTIAL ASSIGNMENT OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLPRL'' then ''PARTIAL RELEASE OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLQCL'' then ''QUITCLAIM OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLRAT'' then ''RATIFICATION OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLREL'' then ''RELEASE OF OIL & GAS LEASE''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLRTL'' then ''OIL & GAS LEASE RENTAL ORDER''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLSTP'' then ''STIPULATION OF OIL & GAS''
			when [Doc_Category] like ''OGL'' and DocType like ''OGLSUB'' then ''SUBORDINATION OF OIL & GAS LEASE''
			when [Doc_Category] like ''OPT'' and DocType like ''OPT'' then ''OPTION''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTAGR'' then ''RIGHT OF FIRST REFUSAL AGREEMENT''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTAMD'' then ''OPTION AMENDMENT''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTASN'' then ''OPTION ASSIGNMENT''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTEXT'' then ''OPTION EXTENSION''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTMOD'' then ''OPTION MODIFICATION''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTOGL'' then ''OPTION OIL & GAS''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTPRL'' then ''OPTION PARTIAL RELEASE''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTREL'' then ''OPTION RELEASE''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTSUB'' then ''OPTION SUBORDINATION''
			when [Doc_Category] like ''OPT'' and DocType like ''OPTXER'' then ''EXERCISE OF OPTION''
			when [Doc_Category] like ''ORD'' and DocType like ''ORD'' then ''ORDER''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDAMD'' then ''ORDER AMENDMENT''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDASN'' then ''ORDER ASSIGNMENT''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDED'' then ''ORDER AFFECTING DEED''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDIV'' then ''DIVORCE ORDER''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDOM'' then ''ORDER <DOMESTIC MATTERS>''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDOT'' then ''ORDER FOR DEED OF TRUST''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDSM'' then ''ORDER DISMISSAL''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDDST'' then ''ORDER OF DISTRIBUTION''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDEVT'' then ''ORDER OF POSSESSION & EVICTION''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDJDG'' then ''ORDER AND JUDGMENT''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDJDGAMD'' then ''AMENDED ORDER & FINAL JUDGMENT''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDLEN'' then ''ORDER OF LIEN''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDMTG'' then ''ORDER AFFECTING MORTGAGE''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDPRL'' then ''ORDER PARTIAL RELEASE''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDQUI'' then ''ORDER TO QUIET TITLE''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDREL'' then ''ORDER RELEASE''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDSLE'' then ''ORDER OF SALE''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDSLEAMD'' then ''ORDER OF SALE AMENDED''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDSUB'' then ''ORDER SUBORDINATION''
			when [Doc_Category] like ''ORD'' and DocType like ''ORDWRL'' then ''ORDER AND RELEASE OF LIEN''
			when [Doc_Category] like ''PER'' and DocType like ''PER'' then ''PERMIT''
			when [Doc_Category] like ''PER'' and DocType like ''PERAMD'' then ''PERMIT AMENDMENT''
			when [Doc_Category] like ''PER'' and DocType like ''PERAPL'' then ''PERMIT APPLICATION''
			when [Doc_Category] like ''PER'' and DocType like ''PERASN'' then ''PERMIT ASSIGNMENT''
			when [Doc_Category] like ''PER'' and DocType like ''PERREL'' then ''PERMIT RELEASE''
			when [Doc_Category] like ''PET'' and DocType like ''PET'' then ''PETITION''
			when [Doc_Category] like ''PET'' and DocType like ''PETDIV'' then ''DIVORCE PETITION''
			when [Doc_Category] like ''PET'' and DocType like ''PETREL'' then ''PETITION RELEASE''
			when [Doc_Category] like ''POA'' and DocType like ''POA'' then ''POWER OF ATTORNEY''
			when [Doc_Category] like ''POA'' and DocType like ''POAAFF'' then ''AFFIDAVIT AS TO POWER OF ATTORNEY''
			when [Doc_Category] like ''POA'' and DocType like ''POAAMD'' then ''POWER OF ATTORNEY AMENDMENT''
			when [Doc_Category] like ''POA'' and DocType like ''POALTD'' then ''LIMITED POWER OF ATTORNEY''
			when [Doc_Category] like ''POA'' and DocType like ''POAMOD'' then ''POWER OF ATTORNEY MODIFICATION''
			when [Doc_Category] like ''POA'' and DocType like ''POAPRL'' then ''POWER OF ATTORNEY PARTIAL RELEASE''
			when [Doc_Category] like ''POA'' and DocType like ''POAREL'' then ''POWER OF ATTORNEY RELEASE''
			when [Doc_Category] like ''POA'' and DocType like ''POASBT'' then ''SUBSTITUTION OF POWER OF ATTORNEY''
			when [Doc_Category] like ''POA'' and DocType like ''POASPC'' then ''SPECIAL POWER OF ATTORNEY''
			when [Doc_Category] like ''POL'' and DocType like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLAMD'' then ''AMENDED POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLASN'' then ''ASSIGNMENT OF POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLMOD'' then ''MODIFICATION OF POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLPRL'' then ''PARTIAL RELEASE OF POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLRAT'' then ''RATIFICATION OF POOLING AGREEMENT''
			when [Doc_Category] like ''POL'' and DocType like ''POLREL'' then ''RELEASE OF POOLING AGREEMENT''
			when [Doc_Category] like ''PRL'' and DocType like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [Doc_Category] like ''PRO'' and DocType like ''PRO'' then ''PROBATE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROAFF'' then ''PROBATE AFFIDAVIT''
			when [Doc_Category] like ''PRO'' and DocType like ''PROAMD'' then ''PROBATE AMENDMENT''
			when [Doc_Category] like ''PRO'' and DocType like ''PROCSV'' then ''PROBATE CONSERVATOR''
			when [Doc_Category] like ''PRO'' and DocType like ''PRODCR'' then ''PROBATE DECREE''
			when [Doc_Category] like ''PRO'' and DocType like ''PRODCRREL'' then ''PROBATE DECREE RELEASE''
			when [Doc_Category] like ''PRO'' and DocType like ''PRODST'' then ''PROBATE DISTRIBUTION''
			when [Doc_Category] like ''PRO'' and DocType like ''PROGDN'' then ''PROBATE GUARDIANSHIP''
			when [Doc_Category] like ''PRO'' and DocType like ''PROGDNREL'' then ''PROBATE REVOCATION OF GUARDIANSHIP''
			when [Doc_Category] like ''PRO'' and DocType like ''PROICP'' then ''PROBATE INCOMPENTENCY''
			when [Doc_Category] like ''PRO'' and DocType like ''PROJDG'' then ''PROBATE JUDGMENT''
			when [Doc_Category] like ''PRO'' and DocType like ''PROJDGAMD'' then ''PROBATE JUDGMENT AMENDMENT''
			when [Doc_Category] like ''PRO'' and DocType like ''PROJDGPRL'' then ''PROBATE JUDGMENT PARTIAL RELEASE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROJDGREL'' then ''PROBATE JUDGMENT RELEASE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROLET'' then ''PROBATE LETTERS''
			when [Doc_Category] like ''PRO'' and DocType like ''PROMOD'' then ''PROBATE MODIFICATION''
			when [Doc_Category] like ''PRO'' and DocType like ''PROORD'' then ''PROBATE ORDER''
			when [Doc_Category] like ''PRO'' and DocType like ''PROPET'' then ''PROBATE PETITION''
			when [Doc_Category] like ''PRO'' and DocType like ''PROREL'' then ''PROBATE DISCHARGE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROSLE'' then ''PROBATE SALE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROSLEREL'' then ''PROBATE SALE RELEASE''
			when [Doc_Category] like ''PRO'' and DocType like ''PROWAR'' then ''PROBATE WARD OF THE STATE''
			when [Doc_Category] like ''PTR'' and DocType like ''PTR'' then ''PARTNERSHIP''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRAFF'' then ''PARTNERSHIP AFFIDAVIT''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRAMD'' then ''PARTNERSHIP AMENDMENT''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRANM'' then ''PARTNERSHIP FICTITIOUS OR ASSUMED NAME''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRASN'' then ''PARTNERSHIP ASSIGNMENT''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRLLC'' then ''PARTNERSHIP LLC''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRNMC'' then ''PARTNERSHIP NAME CHANGE''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRPRL'' then ''PARTNERSHIP PARTIAL RELEASE''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRREL'' then ''PARTNERSHIP DISSOLUTION''
			when [Doc_Category] like ''PTR'' and DocType like ''PTRSLE'' then ''PARTNERSHIP SALE''
			when [Doc_Category] like ''RED'' and DocType like ''RED'' then ''NOTICE OF REDEMPTION''
			when [Doc_Category] like ''REL'' and DocType like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [Doc_Category] like ''REL'' and DocType like ''RELAFF'' then ''AFFIDAVIT TO  RELEASE''
			when [Doc_Category] like ''REQ'' and DocType like ''REQDSM'' then ''REQUEST FOR DISMISSAL''
			when [Doc_Category] like ''REQ'' and DocType like ''REQPRLDOT'' then ''REQUEST FOR PARTIAL RELEASE OF DEED OF TRUST''
			when [Doc_Category] like ''REQ'' and DocType like ''REQPRLMTG'' then ''REQUEST FOR PARTIAL RELEASE OF MORTGAGE''
			when [Doc_Category] like ''REQ'' and DocType like ''REQRELDOT'' then ''REQUEST FOR DEED OF RELEASE & FULL RECONVEYANCE''
			when [Doc_Category] like ''REQ'' and DocType like ''REQRELMTG'' then ''REQUEST FOR RELEASE OF MORTGAGE''
			when [Doc_Category] like ''REQ'' and DocType like ''REQRELVAC'' then ''VACATION OF REQUEST FOR RELEASE OF DEED OF TRUST/MORTGAGE''
			when [Doc_Category] like ''REQ'' and DocType like ''REQUCC'' then ''UCC SEARCH REQUEST''
			when [Doc_Category] like ''REQ'' and DocType like ''REQWAI'' then ''REQUEST FOR WAIVER''
			when [Doc_Category] like ''RES'' and DocType like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESACK'' then ''BUYERS ACKNOWLEGMENT OF AFFORDABLE DEED RESTRICTIONS  ''
			when [Doc_Category] like ''RES'' and DocType like ''RESAFF'' then ''AFFIDAVIT FOR PESTICIDE RESTRICTIVE COVENANTS''
			when [Doc_Category] like ''RES'' and DocType like ''RESAGR'' then ''AGREEMENT FOR RESTRICTIVE COVENANTS''
			when [Doc_Category] like ''RES'' and DocType like ''RESAMD'' then ''RESTRICTIONS AMENDMENT''
			when [Doc_Category] like ''RES'' and DocType like ''RESANX'' then ''RESTRICTIONS ANNEXATION''
			when [Doc_Category] like ''RES'' and DocType like ''RESAPP'' then ''DECLARATION OF APPOINTMENT OF ARCHITECTURAL COMM. <RESTRICTIONS>''
			when [Doc_Category] like ''RES'' and DocType like ''RESCNS'' then ''CONSENT TO RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESLLA'' then ''RESTRICTIVE COVENANT PERTAINING TO CONSOLIDATION OF LOTS''
			when [Doc_Category] like ''RES'' and DocType like ''RESPRK'' then ''DESIGNATION OF PARKING UNDER RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESREL'' then ''RESTRICTIONS RELEASE''
			when [Doc_Category] like ''RES'' and DocType like ''RESSLE'' then ''RESALE RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESSTP'' then ''STIPULATION OF RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESSTR'' then ''SUBSTITUTION OF TRUSTEE UNDER RESTRICTIONS''
			when [Doc_Category] like ''RES'' and DocType like ''RESTRN'' then ''RESTRICTIONS ON TRANSFER OF PROPERTY''
			when [Doc_Category] like ''RES'' and DocType like ''RESUSE'' then ''USE RESTRICTION''
			when [Doc_Category] like ''RES'' and DocType like ''RESVAR'' then ''VARIANCE/SETBACK UNDER RESTRICTIONS''
			when [Doc_Category] like ''ROY'' and DocType like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [Doc_Category] like ''ROY'' and DocType like ''ROYAMD'' then ''AMENDED ROYALTY AGREEMENT''
			when [Doc_Category] like ''ROY'' and DocType like ''ROYASN'' then ''ASSIGNMENT OF ROYALTY INTEREST''
			when [Doc_Category] like ''ROY'' and DocType like ''ROYPRL'' then ''PARTIAL RELEASE OF ROYALTY INTEREST''
			when [Doc_Category] like ''ROY'' and DocType like ''ROYQCL'' then ''QUITCLAIM OF ROYALTY INTEREST''
			when [Doc_Category] like ''RQN'' and DocType like ''RQN'' then ''REQUEST FOR NOTICE''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNAGR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF AGREEMENT ''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNCTR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF CONTRACT ''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNDOT'' then ''REQUEST FOR NOTICE OF DEFAULT OF DEED OF TRUST''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNHLN'' then ''REQUEST FOR NOTICE OF SALE -HOA LIEN''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNLEN'' then ''REQUEST FOR NOTICE OF SALE -LIEN''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNMLN'' then ''REQUEST FOR NOTICE OF SALE -MECHANICS LIEN''
			when [Doc_Category] like ''RQN'' and DocType like ''RQNMTG'' then ''REQUEST FOR NOTICE OF DEFAULT OF MORTGAGE''
			when [Doc_Category] like ''RSL'' and DocType like ''RSL'' then ''RESOLUTION''
			when [Doc_Category] like ''SBT'' and DocType like ''SBTAGR'' then ''SUBSTITUTION AGREEMENT <NOT DOT/MTG>''
			when [Doc_Category] like ''SBT'' and DocType like ''SBTSTR'' then ''SUBSTITUTION OF TRUSTEE <GENERAL>''
			when [Doc_Category] like ''SBT'' and DocType like ''SBTWAS'' then ''SUBSTITUTION AND ASSIGNMENT''
			when [Doc_Category] like ''SHF'' and DocType like ''SHFSLE'' then ''SHERIFFS SALE''
			when [Doc_Category] like ''SLE'' and DocType like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [Doc_Category] like ''SLE'' and DocType like ''SLEASN'' then ''ASSIGNMENT OF SALE''
			when [Doc_Category] like ''SLE'' and DocType like ''SLEMOD'' then ''MODIFICATION OF SALE''
			when [Doc_Category] like ''SLE'' and DocType like ''SLENOI'' then ''NOTICE OF INTENDED SALE/INTENT TO SELL''
			when [Doc_Category] like ''SLE'' and DocType like ''SLEREL'' then ''CANCELLATION OF SALE''
			when [Doc_Category] like ''SLN'' and DocType like ''SLN'' then ''STATE TAX LIEN''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNAMD'' then ''STATE TAX LIEN AMENDMENT''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNEST'' then ''STATE ESTATE TAX LIEN''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNEXT'' then ''STATE TAX LIEN EXTENTION''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNINH'' then ''STATE INHERITANCE TAX LIEN''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNMOD'' then ''STATE TAX LIEN MODIFICATION''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNPRL'' then ''STATE TAX LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNREL'' then ''STATE TAX LIEN RELEASE''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNSBE'' then ''STATE BOARD OF EQUILIZATION LIEN''
			when [Doc_Category] like ''SLN'' and DocType like ''SLNSUB'' then ''STATE LIEN SUBORDINATION''
			when [Doc_Category] like ''STM'' and DocType like ''STM'' then ''STATEMENT''
			when [Doc_Category] like ''STM'' and DocType like ''STMAUT'' then ''STATEMENT OF AUTHORITY''
			when [Doc_Category] like ''STM'' and DocType like ''STMBRE'' then ''STATEMENT OF BREACH''
			when [Doc_Category] like ''STM'' and DocType like ''STMCHA'' then ''STATEMENT OF CHANGE''
			when [Doc_Category] like ''STM'' and DocType like ''STMCLO'' then ''DISCLOSURE STATEMENT''
			when [Doc_Category] like ''STM'' and DocType like ''STMIDT'' then ''STATEMENT IDENTIFYING REAL PROPERTY''
			when [Doc_Category] like ''STM'' and DocType like ''STMIST'' then ''STATEMENT OF INTEREST''
			when [Doc_Category] like ''STM'' and DocType like ''STMLOC'' then ''STATEMENT OF LOCATION''
			when [Doc_Category] like ''STM'' and DocType like ''STMMAR'' then ''STATEMENT OF UNRECORDED MARRIAGE''
			when [Doc_Category] like ''STM'' and DocType like ''STMOWN'' then ''STATEMENT OF OWNERSHIP''
			when [Doc_Category] like ''STM'' and DocType like ''STMPBL'' then ''STATEMENT OF PUBLICATION''
			when [Doc_Category] like ''STM'' and DocType like ''STMREL'' then ''REVOCATION OF STATEMENT''
			when [Doc_Category] like ''STM'' and DocType like ''STMWTR'' then ''STATEMENT OF CLAIM OF RIGHT TO USE PUBLIC WATERS''
			when [Doc_Category] like ''STM'' and DocType like ''STMXPL'' then ''EXPLANATORY STATEMENT''
			when [Doc_Category] like ''STP'' and DocType like ''STP'' then ''STIPULATION''
			when [Doc_Category] like ''STR'' and DocType like ''STRREQREL'' then ''SUBSTITUTION OF TRUSTEE AND REQUEST FOR FULL RECONVEYANCE''
			when [Doc_Category] like ''SUI'' and DocType like ''SUI'' then ''SUIT''
			when [Doc_Category] like ''SUI'' and DocType like ''SUIAMD'' then ''SUIT AMENDMENT''
			when [Doc_Category] like ''SUI'' and DocType like ''SUIQUI'' then ''SUIT QUIET TITLE''
			when [Doc_Category] like ''SUI'' and DocType like ''SUIVAC'' then ''SUIT VACATE''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPJDG'' then ''SUPPORT JUDGMENT''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPJDGAMD'' then ''AMENDED SUPPORT JUDGMENT''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPJDGPRL'' then ''PARTIAL RELEASE OF SUPPORT JUDGMENT''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPLEN'' then ''SUPPORT LIEN''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPLENPRL'' then ''SUPPORT LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPLENREL'' then ''SUPPORT LIEN RELEASE''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPORD'' then ''SUPPORT ORDER''
			when [Doc_Category] like ''SUP'' and DocType like ''SUPREL'' then ''SUPPORT RELEASE''
			when [Doc_Category] like ''SWD'' and DocType like ''SWD'' then ''SPECIAL WARRANTY DEED''
			when [Doc_Category] like ''TNM'' and DocType like ''TNM'' then ''TRADE NAME''
			when [Doc_Category] like ''TNM'' and DocType like ''TNMAMD'' then ''TRADE NAME AMENDMENT''
			when [Doc_Category] like ''TNM'' and DocType like ''TNMAPL'' then ''TRADE NAME APPLICATION''
			when [Doc_Category] like ''TNM'' and DocType like ''TNMREL'' then ''TRADE NAME RELEASE''
			when [Doc_Category] like ''TRU'' and DocType like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [Doc_Category] like ''TRU'' and DocType like ''TRUSTR'' then ''SUBSTITUTION OF TRUSTEE OF A TRUST''
			when [Doc_Category] like ''UCC'' and DocType like ''UCC'' then ''FINANCING STATEMENT''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCAMD'' then ''FINANCING STATEMENT AMENDMENT''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCASN'' then ''FINANCING STATEMENT ASSIGNMENT''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCASP'' then ''FINANCING STATEMENT ASSUMPTION OF LIABILITY''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCCON'' then ''FINANCING STATEMENT CONTINUATION''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCDSP'' then ''DISPOSITION OF FINANCING STATEMENT''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCMOD'' then ''FINANCING STATEMENT MODIFICATION''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCOGL'' then ''FINANCING STATEMENT - OIL & GAS LEASE COLLATERAL''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCOOP'' then ''FINANCING STATEMENT - COOP''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCPRA'' then ''FINANCING STATEMENT PARTIAL ASSIGNMENT''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCPRL'' then ''FINANCING STATEMENT PARTIAL RELEASE''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCREL'' then ''FINANCING STATEMENT RELEASE''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCSUB'' then ''FINANCING STATEMENT SUBORDINATION''
			when [Doc_Category] like ''UCC'' and DocType like ''UCCTER'' then ''FINANCING STATEMENT TERMINATION''
			when [Doc_Category] like ''UNU'' and DocType like ''UNU'' then ''UNUSED BY COUNTY''
			when [Doc_Category] like ''VEC'' and DocType like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [Doc_Category] like ''VIT'' and DocType like ''VIT'' then ''VITAL''
			when [Doc_Category] like ''VLN'' and DocType like ''VLN'' then ''VENDORS LIEN''
			when [Doc_Category] like ''VLN'' and DocType like ''VLNPRL'' then ''VENDORS LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''VLN'' and DocType like ''VLNREL'' then ''VENDORS LIEN  RELEASE''
			when [Doc_Category] like ''VOI'' and DocType like ''VOID'' then ''VOID''
			when [Doc_Category] like ''WAI'' and DocType like ''WAI'' then ''WAIVER''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIAMD'' then ''AMENDMENT OF WAIVER''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIHOM'' then ''WAIVER OF HOMESTEAD''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIIST'' then ''WAIVER OF OWNERSHIP INTEREST''
			when [Doc_Category] like ''WAI'' and DocType like ''WAILEN'' then ''WAIVER OF LIEN''
			when [Doc_Category] like ''WAI'' and DocType like ''WAILIB'' then ''WAIVER OF PERSONAL LIABILITY''
			when [Doc_Category] like ''WAI'' and DocType like ''WAILRD'' then ''LANDLORDS WAIVER & CONSENT''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIMAP'' then ''WAIVER OF MAP''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIMGE'' then ''MORTGAGEES WAIVER & CONSENT''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIMLN'' then ''WAIVER OF MECHANICS LIEN''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIOPT'' then ''OPTION WAIVER''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIPRL'' then ''PARTIAL RELEASE OF WAIVER''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIREL'' then ''RELEASE OF WAIVER''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIRES'' then ''WAIVER OF RESTRICTIONS''
			when [Doc_Category] like ''WAI'' and DocType like ''WAIRHT'' then ''WAIVER OF DOWER RIGHTS''
			when [Doc_Category] like ''WAI'' and DocType like ''WAISLN'' then ''WAIVER OF STATE TAX LIEN''
			when [Doc_Category] like ''WAI'' and DocType like ''WAISUB'' then ''WAIVER OF SUBORDINATION RIGHTS''
			when [Doc_Category] like ''WAI'' and DocType like ''WAITAX'' then ''WAIVER OF TAX''
			when [Doc_Category] like ''WRT'' and DocType like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			when [Doc_Category] like ''WRT'' and DocType like ''WRTPRL'' then ''WRIT PARTIAL RELEASE <NOT AN EXECUTION>''
			when [Doc_Category] like ''WRT'' and DocType like ''WRTREL'' then ''WRIT RELEASE <NOT AN EXECUTION>''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNENG'' then ''ASSESSMENT ENERGY LIEN''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNENGAMD'' then ''ASSESSMENT ENERGY LIEN AMENDMENT''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNENGREL'' then ''ASSESSMENT ENERGY LIEN RELEASE''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [Doc_Category] like ''ALN'' and DocType like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [Doc_Category] like ''AMD'' and DocType like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [Doc_Category] like ''ANM'' and DocType like ''ANM'' then ''ASSUMED NAME''
			when [Doc_Category] like ''ANM'' and DocType like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [Doc_Category] like ''APL'' and DocType like ''APL'' then ''APPLICATION''
			when [Doc_Category] like ''LEN'' and DocType like ''LENENF'' then ''CODE ENFORCEMENT LIEN''


			else DocType end





			Select DocType, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DocType
			Order by DocType


			--------DECODE Doc Type Category -----

			Select Doc_Category, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by Doc_Category
			Order by Doc_Category


			
			Update  x_Custom_OUTPUT_S28
			Set Doc_Category = case 
			when [Doc_Category] like ''ABJ'' then ''ABSTRACT''
			when [Doc_Category] like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [Doc_Category] like ''ACP'' then ''ACCEPTANCE''
			when [Doc_Category] like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [Doc_Category] like ''AFF'' then ''AFFIDAVIT''
			when [Doc_Category] like ''AGR'' then ''AGREEMENT''
			when [Doc_Category] like ''ALN'' then ''ASSESSMENT LIEN''
			when [Doc_Category] like ''AMD'' then ''AMENDMENT''
			when [Doc_Category] like ''ANM'' then ''ASSUMED NAME''
			when [Doc_Category] like ''APL'' then ''APPLICATION''
			when [Doc_Category] like ''ASR'' then ''ASSIGNMENT or Rents''
			when [Doc_Category] like ''BKY'' then ''BANKRUPTCY''
			when [Doc_Category] like ''BND'' then ''BOND''
			when [Doc_Category] like ''BSL'' then ''BILL OF SALE''
			when [Doc_Category] like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [Doc_Category] like ''CAV'' then ''CAVEAT''
			when [Doc_Category] like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTION''
			when [Doc_Category] like ''CER'' then ''CERTIFICATE''
			when [Doc_Category] like ''CHJ'' then ''CHANGE OF JUDGE''
			when [Doc_Category] like ''CNS'' then ''CONSENT''
			when [Doc_Category] like ''COV'' then ''COVENANT''
			when [Doc_Category] like ''CRP'' then ''CORPORATION''
			when [Doc_Category] like ''CTR'' then ''CONTRACT''
			when [Doc_Category] like ''DCL'' then ''DECLARATION''
			when [Doc_Category] like ''DCR'' then ''DECREE''
			when [Doc_Category] like ''DSC'' then ''DISCLAIMER''
			when [Doc_Category] like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [Doc_Category] like ''EAS'' then ''EASEMENT''
			when [Doc_Category] like ''ELN'' then ''ECONOMIC LIEN''
			when [Doc_Category] like ''EXC'' then ''EXECUTION''
			when [Doc_Category] like ''FLN'' then ''FEDERAL TAX LIEN''
			when [Doc_Category] like ''HLN'' then ''HOA LIEN''
			when [Doc_Category] like ''HOM'' then ''DECLARATION OF HOMESTEAD''
			when [Doc_Category] like ''INJ'' then ''INJUCTION''
			when [Doc_Category] like ''JDG'' then ''JUDGMENT''
			when [Doc_Category] like ''JTV'' then ''JOINT VENTURE''
			when [Doc_Category] like ''LEN'' then ''LEIN <GENERAL>''
			when [Doc_Category] like ''LEV'' then ''LEVY''
			when [Doc_Category] like ''LIC'' then ''LICENSE''
			when [Doc_Category] like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [Doc_Category] like ''LIS'' then ''LIS PENDENS''
			when [Doc_Category] like ''LLC'' then ''LLC''
			when [Doc_Category] like ''LSE'' then ''LEASE''
			when [Doc_Category] like ''MAP'' then ''MAP''
			when [Doc_Category] like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [Doc_Category] like ''MEM'' then ''MEMORANDUM''
			when [Doc_Category] like ''MIN'' then ''MINERAL INTEREST''
			when [Doc_Category] like ''MLN'' then ''MECHANICS LIEN''
			when [Doc_Category] like ''MOD'' then ''MODIFICATION <UNSPECIFICED>''
			when [Doc_Category] like ''MTY'' then ''MILITARY''
			when [Doc_Category] like ''NOI'' then ''NOTICE OF INTENT''
			when [Doc_Category] like ''NOT'' then ''NOTICE''
			when [Doc_Category] like ''NTE'' then ''PROMISSORY NOTE''
			when [Doc_Category] like ''OAT'' then ''OATH''
			when [Doc_Category] like ''ODN'' then ''ORDINANCE''
			when [Doc_Category] like ''OGL'' then ''OIL & GAS LEASE''
			when [Doc_Category] like ''OPT'' then ''OPTION''
			when [Doc_Category] like ''ORD'' then ''ORDER''
			when [Doc_Category] like ''PER'' then ''PERMIT''
			when [Doc_Category] like ''PET'' then ''PETITION''
			when [Doc_Category] like ''POA'' then ''POWER OF ATTORNEY''
			when [Doc_Category] like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [Doc_Category] like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [Doc_Category] like ''PRO'' then ''PROBATE''
			when [Doc_Category] like ''PTR'' then ''PARTNERSHIP''
			when [Doc_Category] like ''RED'' then ''NOTICE OF REDEMPTION''
			when [Doc_Category] like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [Doc_Category] like ''REQ'' then ''REQUEST''
			when [Doc_Category] like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [Doc_Category] like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [Doc_Category] like ''RQN'' then ''REQUEST FOR NOTICE''
			when [Doc_Category] like ''RSL'' then ''RESOLUTION''
			when [Doc_Category] like ''SBT'' then ''SUBSTITUTION''
			when [Doc_Category] like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [Doc_Category] like ''SLN'' then ''STATE TAX LIEN''
			when [Doc_Category] like ''STM'' then ''STATEMENT''
			when [Doc_Category] like ''STP'' then ''STIPULATION''
			when [Doc_Category] like ''STR'' then ''SUBSTITUTION''
			when [Doc_Category] like ''SUI'' then ''SUIT''
			when [Doc_Category] like ''SUP'' then ''SUPPORT''
			when [Doc_Category] like ''TNM'' then ''TRADE NAME''
			when [Doc_Category] like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [Doc_Category] like ''UCC'' then ''FINANCING STATEMENT''
			when [Doc_Category] like ''UNU'' then ''UNUSED BY COUNTY''
			when [Doc_Category] like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [Doc_Category] like ''VIT'' then ''VITAL''
			when [Doc_Category] like ''VLN'' then ''VENDORS LIEN''
			when [Doc_Category] like ''VOI'' then ''VIOLATION''
			when [Doc_Category] like ''WAI'' then ''WAIVER''
			when [Doc_Category] like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			else [Doc_Category] end


			
			Select Doc_Category, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by Doc_Category
			Order by Doc_Category

			
			')

			END

			Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]


		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] 
		SET [INVL Converage Status] = CASE WHEN [INVL Converage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_ReliantCapital].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a JOIN [zCust_ReliantCapital].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID
		
	


		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ReliantCapital].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28] a join [zCust_ReliantCapital].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		and (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		


		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		SET [Event Status] = case when [# of Recordings] > 0	THEN 'Event Found' ELSE 'Event Not Found' END
		
		
		Select [Property Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Address Standardization]

		Select [INVL Converage Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Group by [INVL Converage Status]

		Select [Event Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Event Status]


		Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S28]
		Order by [INPUT Unique ID]

	



END



