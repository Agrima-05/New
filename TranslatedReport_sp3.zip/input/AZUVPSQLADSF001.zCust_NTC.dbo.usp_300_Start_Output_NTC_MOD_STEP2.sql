SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_NTC].[dbo].[usp_300_Start_Output_NTC_MOD_STEP2]

AS
BEGIN
	
	SET NOCOUNT ON;

	
	

----20250305 - Solution Notes
----Doc retrieval of the Loan Modification is REQUIRED, if no doc images, no return.
----If more than 1 matched mortgage found, look which one has mod, the one with the mod becomes "matched mortgage", if both do have a mod, consider the most recent the matched mortgage

-----Step 2 - NULL Mtg fields for MODs with no image & set FLAG.   
	


				
			UPDATE [zCust_NTC].[dbo].[A] 
			SET 
			--A.[OrigTrans RecDate] = NULL
			--,A.[OrigTrans DocNumber] = NULL
			--,A.[OrigTrans LoanAmount] = NULL
			--,A.[OrigTransBkPg] = NULL
			A.[MTGRecording Date]  =NULL
			,A.[MTGLoan Amount] = NULL
			,A.[MTGInstrument #] = NULL
			,A.[MTGBookPage] = NULL
			,A.[MTGDoc Type] = NULL
			,A.[MTGBorrower Name] = NULL
			,A.MODRecordingNoImage = 'Y'
			--Select A.*
			From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MOD] A with(NOLOCK)
			left outer join (Select INPUTKEY From [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') B
			on A.[Unique ID] = B.INPUTKEY
			where B.INPUTKEY is null
			and A.[MTGRecording Date] is not null

		
			


	
		-------Delete records with no images as Flag has already been set--------
		-----NOT deleting as need to report MODs with no image counts
		--Delete from z_Images_To_Pull
		--where ISNULL(XosStatus,'') not like 'Completed'



		Select XosStatus, count(*) from [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XosStatus

	




END






