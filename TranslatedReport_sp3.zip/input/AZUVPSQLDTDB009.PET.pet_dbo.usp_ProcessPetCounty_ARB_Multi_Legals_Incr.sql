/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_ARB_Multi_Legals_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================    
-- Author:        <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description:   <Description,,>    
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'    
-- =============================================    
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_ARB_Multi_Legals_Incr] @fips INT
	,@FeatureName AS VARCHAR(50)
	,@ServiceName AS VARCHAR(50)
	,@FormatId AS VARCHAR(10)
	,@Incremental_Flag BIT
AS
EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_ARB_Multi_Legals_Incr'
	,N'Started'

DECLARE @GetDynamicFormat tmpGetDynamicFormat

INSERT INTO @GetDynamicFormat (
	[FeatureName]
	,[ServiceName]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[OutputField]
	,[LongDesc]
	,[Label]
	,[MsgLabel]
	,[Partner]
	,[PartnerType]
	,[WildStart]
	,[DataType]
	,[Required]
	,[Enumeration]
	,[TabIndex]
	,[FromField]
	,[DataTreeIndexes]
	,[FormatChar]
	,[_overlay]
	,[ROW4]
	)
EXEC [pet].[dbo].[GetDynamicFormat] @FeatureName --'TITLE_SERVICES'    
	,@ServiceName --'SUBDIVIDED'    
	,@FormatId --@PPLNT_PLAT_ID_FRMT    

SELECT 'ARB parms' AS aaaa
	,*
FROM @GetDynamicFormat

DECLARE @Min_Subformatid INT = (
		SELECT min(Subformatid)
		FROM @GetDynamicFormat
		)
DECLARE @year_pos INT = (
		SELECT p.offset
		FROM @GetDynamicFormat p
		WHERE p.Field = 'Year'
		)
	,@Ref_id INT = NULL --13580129    

--IF object_id('Tempdb..pet.pet_tmp.Incr_ARB_Multi_Legals_Incr_temp3') IS NOT NULL
DROP TABLE

IF EXISTS [pet].[pet_tmp].[Incr_ARB_Multi_Legals_Incr_temp3];
	SELECT a.REF_ID
		,a.NEO_APN
		,a.NEO_LAND_TYPE
		,a.NEO_TITLE_LEGAL
		,a._field
		--,Replace(Replace(Replace(ltrim(a._value), 'T', ''), 'C', ''), 'M', '') AS _value    
		,a._value
		,a.fips
		,a.row4
		,'' AS bookType
	INTO [pet].[pet_tmp].[Incr_ARB_Multi_Legals_Incr_temp3]
	FROM (
		SELECT distinct 
			--top 100     
			t.REF_ID
			,t.NEO_APN
			,t.NEO_LAND_TYPE
			,t.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL
			,Field AS _field
			,p.ROW4
			,substring(t.NEO_TITLE_LEGAL, Offset, [Length]) AS _value
			,t.fips
		FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (NOLOCK,INDEX (idx_fips_neoAPN))
		cross APPLY (
			SELECT *
			FROM [pet].[dbo].[PET_neo_legals] t WITH (
					NOLOCK
					,INDEX (ix_fipsNEO)
					)
			WHERE t.fips = incr.fips
				AND t.neo_apn = incr.neo_apn
				and t.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
				AND t.NEO_LAND_TYPE IN ('AN')
			) t
		OUTER APPLY (
			SELECT *
			FROM @GetDynamicFormat
			--WHERE _overlay <> 0    
			WHERE SubFormatId = CASE 
					WHEN @FormatId = 'A2'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 3, 1) = ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'B0'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 19, 1) = ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'CH'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 1, 1) = ''
									THEN 2
								ELSE 1
								END
					WHEN @FormatId = 'DG'
						THEN CASE 
								WHEN len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 1, 8)))) = 0
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'DT'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 7, 1) = ''
									AND len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 21, 30)))) = 0
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'GN'
						THEN CASE 
								WHEN len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 2, 4)))) = 0
									THEN 2
								ELSE 1
								END
					WHEN @FormatId = 'HO'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 6, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'IN'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 1, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'JE'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 12, 1) = ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'JM'
						THEN CASE 
								WHEN len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 1, 2)))) > 0
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'K5'
						THEN CASE 
								WHEN isnumeric(SUBSTRING(t.NEO_TITLE_LEGAL, 15, 2)) = 0
									THEN 2
								ELSE 1
								END
					WHEN @FormatId = 'K8'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 3, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'KZ'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 1, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'LN'
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 6, 1) = ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId IN (
							'M1'
							,'M2'
							,'M3'
							,'MD'
							,'MN'
							)
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 1, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId IN ('S1')
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 11, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 's2'
						THEN CASE 
								WHEN len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 10, 2)))) > 0
									THEN 1
								ELSE 2
								END
					WHEN @FormatId IN ('SM')
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 4, 1) <> ''
									THEN 1
								ELSE 2
								END
					WHEN @FormatId = 'SP'
						THEN CASE 
								WHEN len(ltrim(rtrim(SUBSTRING(t.NEO_TITLE_LEGAL, 1, 7)))) > 0
									THEN 1
								ELSE 2
								END
					WHEN @FormatId IN ('UM')
						THEN CASE 
								WHEN SUBSTRING(t.NEO_TITLE_LEGAL, 4, 1) <> ''
									THEN 1
								ELSE 2
								END
					ELSE @Min_Subformatid
					END
			) p
		WHERE incr.fips = @fips
			and incr.NEO_LAND_TYPE = 'AN'
			
			--WHERE t.fips = @fips
			--	AND t.NEO_LAND_TYPE IN ('AN')
			--AND (  
			--@Incremental_flag = 0  
			--OR (  
			-- @Incremental_flag = 1  
			--AND incr.neo_apn IS NOT NULL  
			-- )  
			--)  
		) a
	WHERE isnull(a._value, '') > ''

--Select * from #temp    
CREATE UNIQUE INDEX ix_ref_id_field ON [pet].[pet_tmp].[Incr_ARB_Multi_Legals_Incr_temp3] (
	Fips
	,REF_ID
	,NEO_APN
	,NEO_TITLE_LEGAL
	,_field
	)

BEGIN TRANSACTION

INSERT INTO [PET].[dbo].[Pet_LabelColumns_Multi_Legals] (
	[REF_ID]
	,NEO_APN
	,[NEO_LAND_TYPE]
	,[NEO_TITLE_LEGAL]
	,[_field]
	,[_value]
	,fips
	,ROW4
	,bookType
	)
SELECT b.[REF_ID]
	,b.NEO_APN
	,b.[NEO_LAND_TYPE]
	,b.[NEO_TITLE_LEGAL]
	,b.[_field]
	,b.[_value]
	,b.fips
	,b.ROW4
	,b.bookType
FROM [pet].[pet_tmp].[Incr_ARB_Multi_Legals_Incr_temp3] b WITH (
		NOLOCK
		,INDEX (ix_ref_id_field)
		)
LEFT JOIN [PET].[dbo].[Pet_LabelColumns_Multi_Legals] c WITH (
		NOLOCK
		,INDEX ([ClusteredIndex-20170302-172737])
		) ON c.Fips = b.Fips
	AND c.REF_ID = b.REF_ID
	AND c.NEO_APN = b.NEO_APN
	AND c.NEO_TITLE_LEGAL = b.NEO_TITLE_LEGAL
	AND c._field = b._field
WHERE c.ref_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

COMMIT

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_ARB_Multi_Legals_Incr'
	,N'Ended'


