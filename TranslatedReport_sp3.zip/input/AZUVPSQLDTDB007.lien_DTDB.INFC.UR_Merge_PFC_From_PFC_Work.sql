/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Merge_PFC_From_PFC_Work | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Merge_PFC_From_PFC_Work] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG: 
==========
who		date		change
Marie	2023-10-03	Initial Creation - Merge PreForeclosureWrk to RasPreForeclosure
 
******************************************************************************************************************/
BEGIN TRY
	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'UR_Merge_PFC_From_PFC_Work'
		,N'Started'

	BEGIN TRANSACTION

	DROP TABLE

	IF EXISTS #Temp
		SELECT nullif(w.FIPS, 0) AS FIPS
			,nullif(w.REF_ID, 0) AS REF_ID
			,nullif(w.USState, '') AS USState
			,nullif(w.USCounty, '') AS USCounty
			,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
			,nullif(w.Update_Timestamp, '') AS Update_Timestamp
			,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
			,nullif(w.Document_Type, '') AS Document_Type
			,nullif(w.Lis_Pendens_Type, '') AS Lis_Pendens_Type
			,nullif(w.Document_Date, '') AS Document_Date
			,nullif(w.Recording_Date, '') AS Recording_Date
			,nullif(w.Recording_Book, '') AS Recording_Book
			,nullif(w.Recording_Page, '') AS Recording_Page
			,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
			,nullif(w.Borrower_Defendant_Name_Full1, '') AS Borrower_Defendant_Name_Full1
			,nullif(w.Borrower_Defendant_Name_Full2, '') AS Borrower_Defendant_Name_Full2
			,nullif(w.Trustee_Attorney_Plaintiff_Full1, '') AS Trustee_Attorney_Plaintiff_Full1
			,nullif(w.Trustee_Attorney_Plaintiff_Full2, '') AS Trustee_Attorney_Plaintiff_Full2
			,nullif(w.Original_Loan_Date, '') AS Original_Loan_Date
			,nullif(w.Original_Loan_Recording_Book, '') AS Original_Loan_Recording_Book
			,nullif(w.Original_Loan_Recording_Page, '') AS Original_Loan_Recording_Page
			,nullif(w.Original_Loan_Recording_Instrument_Nbr, '') AS Original_Loan_Recording_Instrument_Nbr
			,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
			,nullif(w.Lender_Beneficiary_Name, '') AS Lender_Beneficiary_Name
			,nullif(w.Default_Amount, 0) AS Default_Amount
			,nullif(w.Default_Date, '') AS Default_Date
			,nullif(w.Judgment_Amount, 0) AS Judgment_Amount
			,nullif(w.Original_Pre_Foreclosure_Date, '') AS Original_Pre_Foreclosure_Date
			,nullif(w.Original_Pre_Foreclosure_Recording_Book, '') AS Original_Pre_Foreclosure_Recording_Book
			,nullif(w.Original_Pre_Foreclosure_Recording_Page, '') AS Original_Pre_Foreclosure_Recording_Page
			,nullif(w.Original_Pre_Foreclosure_Instrument_Nbr, '') AS Original_Pre_Foreclosure_Instrument_Nbr
			,nullif(w.Auction_Date, '') AS Auction_Date
			,nullif(w.Auction_Location, '') AS Auction_Location
			,nullif(w.Auction_City, '') AS Auction_City
			,nullif(w.Auction_State, '') AS Auction_State
			,nullif(w.Opening_Bid, 0) AS Opening_Bid
			,nullif(w.Unpaid_Balance, 0) AS Unpaid_Balance
			,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
			,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
			,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
			,nullif(w.Pending_Transaction, '') AS Pending_Transaction
			,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
			,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
			,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
			,nullif(w.Situs_Direction, '') AS Situs_Direction
			,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
			,nullif(w.Situs_Mode, '') AS Situs_Mode
			,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
			,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
			,nullif(w.Situs_City, '') AS Situs_City
			,nullif(w.Situs_State, '') AS Situs_State
			,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
			,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
			,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
			,nullif(w.Created, '') AS Created
			,nullif(w.Updated, '') AS Updated
			,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
			,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
			,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
			,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
			,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
			,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
			,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
			,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
			,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
			,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
			,nullif(w.Fmt_Loan_Inst_Nbr, '') AS Fmt_Loan_Inst_Nbr
			,nullif(w.CMT_ID_Loan_Inst_nbr, 0) AS CMT_ID_Loan_Inst_nbr
			,nullif(w.Fmt_Loan_Book_Page, '') AS Fmt_Loan_Book_Page
			,nullif(w.CMT_ID_Loan_Book_Page, 0) AS CMT_ID_Loan_Book_Page
			,nullif(w.Source_Type, '') AS Source_Type
			,nullif(w.SRC_TBL, '') AS SRC_TBL
			,isnull(w.DEED_PID, 0) AS DEED_PID
			,isnull(w.SAM_PID, 0) AS SAM_PID
			,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
			,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
			,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
			,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
			,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
			,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
			,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
			,nullif(w.CASE_NBR, '') AS CASE_NBR
			,nullif(w.Mtg_Sr_Unique_Id, 0) AS Mtg_Sr_Unique_Id
			,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
			,nullif(w.Trustee_Sale_Number, '') AS Trustee_Sale_Number
			,nullif(w.Trustee_Telephone_Number, '') AS Trustee_Telephone_Number
			,nullif(w.Auction_Time, '') AS Auction_Time
			,nullif(w.Title_Company, '') AS Title_Company
			,nullif(w.UR_Remarks, '') AS UR_Remarks
			,nullif(w.Lender_Beneficiary_Name_extended, '') AS Lender_Beneficiary_Name_extended
		INTO #temp
		FROM [lien_DTDB].[INFC].[PFC_Work] w

	TRUNCATE TABLE [lien_DTDB].[INFC].[PFC_Work]

	INSERT INTO [lien_DTDB].[INFC].[PFC_Work] (
		FIPS
		,REF_ID
		,USState
		,USCounty
		,CLGX_Unique_ID
		,Update_Timestamp
		,Add_Change_Delete_Identifier
		,Document_Type
		,Lis_Pendens_Type
		,Document_Date
		,Recording_Date
		,Recording_Book
		,Recording_Page
		,Recording_Instrument_Nbr
		,Borrower_Defendant_Name_Full1
		,Borrower_Defendant_Name_Full2
		,Trustee_Attorney_Plaintiff_Full1
		,Trustee_Attorney_Plaintiff_Full2
		,Original_Loan_Date
		,Original_Loan_Recording_Book
		,Original_Loan_Recording_Page
		,Original_Loan_Recording_Instrument_Nbr
		,Original_Loan_Amount
		,Lender_Beneficiary_Name
		,Default_Amount
		,Default_Date
		,Judgment_Amount
		,Original_Pre_Foreclosure_Date
		,Original_Pre_Foreclosure_Recording_Book
		,Original_Pre_Foreclosure_Recording_Page
		,Original_Pre_Foreclosure_Instrument_Nbr
		,Auction_Date
		,Auction_Location
		,Auction_City
		,Auction_State
		,Opening_Bid
		,Unpaid_Balance
		,Tax_Id_Nbr_APN_Unformatted
		,APN_Sequence_NBR
		,Tax_Id_Nbr_APN_Formatted
		,Pending_Transaction
		,Situs_House_Nbr
		,Situs_House_Nbr2
		,Situs_House_Nbr_Suffix
		,Situs_Direction
		,Situs_Street_Name
		,Situs_Mode
		,Situs_Post_Direction
		,Situ_Unit_Nbr
		,Situs_City
		,Situs_State
		,Situs_Zip_Code
		,Situs_Carrier_Code
		,Multi_Property_Indicator
		,Created
		,Updated
		,PREVIOUS_PARCEL_NBR
		,PREVIOUS_PARCEL_SEQUENCE_NBR
		,Fmt_Inst_Nbr
		,CMT_ID_Inst_nbr
		,Fmt_Ori_Inst_Nbr
		,CMT_ID_Ori_Inst_nbr
		,Fmt_Book_Page
		,CMT_ID_Book_Page
		,Fmt_Ori_Book_Page
		,CMT_ID_Ori_Book_Page
		,Fmt_Loan_Inst_Nbr
		,CMT_ID_Loan_Inst_nbr
		,Fmt_Loan_Book_Page
		,CMT_ID_Loan_Book_Page
		,Source_Type
		,SRC_TBL
		,DEED_PID
		,SAM_PID
		,UR_Doc_Unique_Id
		,UR_Doc_Id
		,UR_Property_Id
		,UR_Name_Id
		,UR_Reference_Id
		,MTG_CLGX_UNIQUE_ID
		,MTG_Source_Type
		,CASE_NBR
		,Mtg_Sr_Unique_Id
		,UR_Prop_Seq_Num
		,Trustee_Sale_Number
		,Trustee_Telephone_Number
		,Auction_Time
		,Title_Company
		,UR_Remarks
		,Lender_Beneficiary_Name_extended
		)
	SELECT nullif(w.FIPS, 0) AS FIPS
		,nullif(w.REF_ID, 0) AS REF_ID
		,nullif(w.USState, '') AS USState
		,nullif(w.USCounty, '') AS USCounty
		,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
		,nullif(w.Update_Timestamp, '') AS Update_Timestamp
		,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
		,nullif(w.Document_Type, '') AS Document_Type
		,nullif(w.Lis_Pendens_Type, '') AS Lis_Pendens_Type
		,nullif(w.Document_Date, '') AS Document_Date
		,nullif(w.Recording_Date, '') AS Recording_Date
		,nullif(w.Recording_Book, '') AS Recording_Book
		,nullif(w.Recording_Page, '') AS Recording_Page
		,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
		,nullif(w.Borrower_Defendant_Name_Full1, '') AS Borrower_Defendant_Name_Full1
		,nullif(w.Borrower_Defendant_Name_Full2, '') AS Borrower_Defendant_Name_Full2
		,nullif(w.Trustee_Attorney_Plaintiff_Full1, '') AS Trustee_Attorney_Plaintiff_Full1
		,nullif(w.Trustee_Attorney_Plaintiff_Full2, '') AS Trustee_Attorney_Plaintiff_Full2
		,nullif(w.Original_Loan_Date, '') AS Original_Loan_Date
		,nullif(w.Original_Loan_Recording_Book, '') AS Original_Loan_Recording_Book
		,nullif(w.Original_Loan_Recording_Page, '') AS Original_Loan_Recording_Page
		,nullif(w.Original_Loan_Recording_Instrument_Nbr, '') AS Original_Loan_Recording_Instrument_Nbr
		,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
		,nullif(w.Lender_Beneficiary_Name, '') AS Lender_Beneficiary_Name
		,nullif(w.Default_Amount, 0) AS Default_Amount
		,nullif(w.Default_Date, '') AS Default_Date
		,nullif(w.Judgment_Amount, 0) AS Judgment_Amount
		,nullif(w.Original_Pre_Foreclosure_Date, '') AS Original_Pre_Foreclosure_Date
		,nullif(w.Original_Pre_Foreclosure_Recording_Book, '') AS Original_Pre_Foreclosure_Recording_Book
		,nullif(w.Original_Pre_Foreclosure_Recording_Page, '') AS Original_Pre_Foreclosure_Recording_Page
		,nullif(w.Original_Pre_Foreclosure_Instrument_Nbr, '') AS Original_Pre_Foreclosure_Instrument_Nbr
		,nullif(w.Auction_Date, '') AS Auction_Date
		,nullif(w.Auction_Location, '') AS Auction_Location
		,nullif(w.Auction_City, '') AS Auction_City
		,nullif(w.Auction_State, '') AS Auction_State
		,nullif(w.Opening_Bid, 0) AS Opening_Bid
		,nullif(w.Unpaid_Balance, 0) AS Unpaid_Balance
		,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
		,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
		,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
		,nullif(w.Pending_Transaction, '') AS Pending_Transaction
		,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
		,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
		,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
		,nullif(w.Situs_Direction, '') AS Situs_Direction
		,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
		,nullif(w.Situs_Mode, '') AS Situs_Mode
		,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
		,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
		,nullif(w.Situs_City, '') AS Situs_City
		,nullif(w.Situs_State, '') AS Situs_State
		,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
		,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
		,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
		,nullif(w.Created, '') AS Created
		,nullif(w.Updated, '') AS Updated
		,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
		,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
		,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
		,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
		,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
		,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
		,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
		,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
		,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
		,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
		,nullif(w.Fmt_Loan_Inst_Nbr, '') AS Fmt_Loan_Inst_Nbr
		,nullif(w.CMT_ID_Loan_Inst_nbr, 0) AS CMT_ID_Loan_Inst_nbr
		,nullif(w.Fmt_Loan_Book_Page, '') AS Fmt_Loan_Book_Page
		,nullif(w.CMT_ID_Loan_Book_Page, 0) AS CMT_ID_Loan_Book_Page
		,nullif(w.Source_Type, '') AS Source_Type
		,nullif(w.SRC_TBL, '') AS SRC_TBL
		,isnull(w.DEED_PID, 0) AS DEED_PID
		,isnull(w.SAM_PID, 0) AS SAM_PID
		,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
		,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
		,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
		,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
		,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
		,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
		,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
		,nullif(w.CASE_NBR, '') AS CASE_NBR
		,nullif(w.Mtg_Sr_Unique_Id, 0) AS Mtg_Sr_Unique_Id
		,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
		,nullif(w.Trustee_Sale_Number, '') AS Trustee_Sale_Number
		,nullif(w.Trustee_Telephone_Number, '') AS Trustee_Telephone_Number
		,nullif(w.Auction_Time, '') AS Auction_Time
		,nullif(w.Title_Company, '') AS Title_Company
		,nullif(w.UR_Remarks, '') AS UR_Remarks
		,nullif(w.Lender_Beneficiary_Name_extended, '') AS Lender_Beneficiary_Name_extended
	FROM #temp W

	UPDATE [lien_DTDB].[INFC].[p]
	SET p.FIPS = nullif(w.FIPS, 0)
		,p.REF_ID = nullif(w.REF_ID, 0)
		,p.USState = nullif(w.USState, '')
		,p.USCounty = nullif(w.USCounty, '')
		--   ,p.CLGX_Unique_ID							= nullif(w.CLGX_Unique_ID, 0)                                                       
		,p.Update_Timestamp = nullif(w.Update_Timestamp, '')
		,p.Add_Change_Delete_Identifier = nullif(w.Add_Change_Delete_Identifier, '')
		,p.Document_Type = nullif(w.Document_Type, '')
		,p.Lis_Pendens_Type = nullif(w.Lis_Pendens_Type, '')
		,p.Document_Date = nullif(w.Document_Date, '')
		,p.Recording_Date = nullif(w.Recording_Date, '')
		,p.Recording_Book = nullif(w.Recording_Book, '')
		,p.Recording_Page = nullif(w.Recording_Page, '')
		,p.Recording_Instrument_Nbr = nullif(w.Recording_Instrument_Nbr, '')
		,p.Borrower_Defendant_Name_Full1 = nullif(w.Borrower_Defendant_Name_Full1, '')
		,p.Borrower_Defendant_Name_Full2 = nullif(w.Borrower_Defendant_Name_Full2, '')
		,p.Trustee_Attorney_Plaintiff_Full1 = nullif(w.Trustee_Attorney_Plaintiff_Full1, '')
		,p.Trustee_Attorney_Plaintiff_Full2 = nullif(w.Trustee_Attorney_Plaintiff_Full2, '')
		,p.Original_Loan_Date = nullif(w.Original_Loan_Date, '')
		,p.Original_Loan_Recording_Book = nullif(w.Original_Loan_Recording_Book, '')
		,p.Original_Loan_Recording_Page = nullif(w.Original_Loan_Recording_Page, '')
		,p.Original_Loan_Recording_Instrument_Nbr = nullif(w.Original_Loan_Recording_Instrument_Nbr, '')
		,p.Original_Loan_Amount = nullif(w.Original_Loan_Amount, 0)
		,p.Lender_Beneficiary_Name = nullif(w.Lender_Beneficiary_Name, '')
		,p.Default_Amount = nullif(w.Default_Amount, 0)
		,p.Default_Date = nullif(w.Default_Date, '')
		,p.Judgment_Amount = nullif(w.Judgment_Amount, 0)
		,p.Original_Pre_Foreclosure_Date = nullif(w.Original_Pre_Foreclosure_Date, '')
		,p.Original_Pre_Foreclosure_Recording_Book = nullif(w.Original_Pre_Foreclosure_Recording_Book, '')
		,p.Original_Pre_Foreclosure_Recording_Page = nullif(w.Original_Pre_Foreclosure_Recording_Page, '')
		,p.Original_Pre_Foreclosure_Instrument_Nbr = nullif(w.Original_Pre_Foreclosure_Instrument_Nbr, '')
		,p.Auction_Date = nullif(w.Auction_Date, '')
		,p.Auction_Location = nullif(w.Auction_Location, '')
		,p.Auction_City = nullif(w.Auction_City, '')
		,p.Auction_State = nullif(w.Auction_State, '')
		,p.Opening_Bid = nullif(w.Opening_Bid, 0)
		,p.Unpaid_Balance = nullif(w.Unpaid_Balance, 0)
		,p.Tax_Id_Nbr_APN_Unformatted = nullif(w.Tax_Id_Nbr_APN_Unformatted, '')
		,p.APN_Sequence_NBR = nullif(w.APN_Sequence_NBR, 0)
		,p.Tax_Id_Nbr_APN_Formatted = nullif(w.Tax_Id_Nbr_APN_Formatted, '')
		,p.Pending_Transaction = nullif(w.Pending_Transaction, '')
		,p.Situs_House_Nbr = nullif(w.Situs_House_Nbr, '')
		,p.Situs_House_Nbr2 = nullif(w.Situs_House_Nbr2, '')
		,p.Situs_House_Nbr_Suffix = nullif(w.Situs_House_Nbr_Suffix, '')
		,p.Situs_Direction = nullif(w.Situs_Direction, '')
		,p.Situs_Street_Name = nullif(w.Situs_Street_Name, '')
		,p.Situs_Mode = nullif(w.Situs_Mode, '')
		,p.Situs_Post_Direction = nullif(w.Situs_Post_Direction, '')
		,p.Situ_Unit_Nbr = nullif(w.Situ_Unit_Nbr, '')
		,p.Situs_City = nullif(w.Situs_City, '')
		,p.Situs_State = nullif(w.Situs_State, '')
		,p.Situs_Zip_Code = nullif(w.Situs_Zip_Code, '')
		,p.Situs_Carrier_Code = nullif(w.Situs_Carrier_Code, '')
		,p.Multi_Property_Indicator = nullif(w.Multi_Property_Indicator, '')
		--,p.Created = nullif(w.Created, '')
		,p.Updated = getdate() --nullif(w.Updated, '')
		,p.PREVIOUS_PARCEL_NBR = nullif(w.PREVIOUS_PARCEL_NBR, '')
		,p.PREVIOUS_PARCEL_SEQUENCE_NBR = nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0)
		,p.Fmt_Inst_Nbr = nullif(w.Fmt_Inst_Nbr, '')
		,p.CMT_ID_Inst_nbr = nullif(w.CMT_ID_Inst_nbr, 0)
		,p.Fmt_Ori_Inst_Nbr = nullif(w.Fmt_Ori_Inst_Nbr, '')
		,p.CMT_ID_Ori_Inst_nbr = nullif(w.CMT_ID_Ori_Inst_nbr, 0)
		,p.Fmt_Book_Page = nullif(w.Fmt_Book_Page, '')
		,p.CMT_ID_Book_Page = nullif(w.CMT_ID_Book_Page, 0)
		,p.Fmt_Ori_Book_Page = nullif(w.Fmt_Ori_Book_Page, '')
		,p.CMT_ID_Ori_Book_Page = nullif(w.CMT_ID_Ori_Book_Page, 0)
		,p.Fmt_Loan_Inst_Nbr = nullif(w.Fmt_Loan_Inst_Nbr, '')
		,p.CMT_ID_Loan_Inst_nbr = nullif(w.CMT_ID_Loan_Inst_nbr, 0)
		,p.Fmt_Loan_Book_Page = nullif(w.Fmt_Loan_Book_Page, '')
		,p.CMT_ID_Loan_Book_Page = nullif(w.CMT_ID_Loan_Book_Page, 0)
		,p.Source_Type = nullif(w.Source_Type, '')
		--   ,p.SRC_TBL									= nullif(w.SRC_TBL, '')                                                                
		,p.DEED_PID = isnull(w.DEED_PID, 0)
		,p.SAM_PID = isnull(w.SAM_PID, 0)
		,p.UR_Doc_Unique_Id = nullif(w.UR_Doc_Unique_Id, '')
		,p.UR_Doc_Id = nullif(w.UR_Doc_Id, 0)
		,p.UR_Property_Id = nullif(w.UR_Property_Id, 0)
		,p.UR_Name_Id = nullif(w.UR_Name_Id, 0)
		,p.UR_Reference_Id = nullif(w.UR_Reference_Id, 0)
		,p.MTG_CLGX_UNIQUE_ID = nullif(w.MTG_CLGX_UNIQUE_ID, 0)
		,p.MTG_Source_Type = nullif(w.MTG_Source_Type, '')
		,p.CASE_NBR = nullif(w.CASE_NBR, '')
		,p.Mtg_Sr_Unique_Id = nullif(w.Mtg_Sr_Unique_Id, 0)
		,p.UR_Prop_Seq_Num = nullif(w.UR_Prop_Seq_Num, 0)
		,p.Trustee_Sale_Number = nullif(w.Trustee_Sale_Number, '')
		,p.Trustee_Telephone_Number = nullif(w.Trustee_Telephone_Number, '')
		,p.Auction_Time = nullif(w.Auction_Time, '')
		,p.Title_Company = nullif(w.Title_Company, '')
		,p.UR_Remarks = nullif(w.UR_Remarks, '')
		,p.Lender_Beneficiary_Name_extended = nullif(w.Lender_Beneficiary_Name_extended, '')
	--,p.PFC_checksum
	-- select  format(count(*), '##,##0') as cnt
	FROM [Pre_Foreclosure].[dbo].[PreForeclosure] p
	--FROM lien_DTDB.INFC.PreForeclosure p
	INNER JOIN [lien_DTDB].[INFC].[PFC_Work] w ON w.Fips = p.fips
		AND isnull(w.UR_Reference_id, 0) = isnull(p.UR_Reference_id, 0)
		AND isnull(w.UR_Prop_Seq_Num, 0) = isnull(p.UR_Prop_Seq_Num, 0)
		AND w.CLGX_UNIQUE_ID = p.CLGX_UNIQUE_ID
		AND w.SRC_TBL = p.SRC_TBL
	WHERE w.PFC_checksum <> p.PFC_checksum

	INSERT INTO [Pre_Foreclosure].[dbo].[PreForeclosure] (
		FIPS
		,REF_ID
		,USState
		,USCounty
		,CLGX_Unique_ID
		,Update_Timestamp
		,Add_Change_Delete_Identifier
		,Document_Type
		,Lis_Pendens_Type
		,Document_Date
		,Recording_Date
		,Recording_Book
		,Recording_Page
		,Recording_Instrument_Nbr
		,Borrower_Defendant_Name_Full1
		,Borrower_Defendant_Name_Full2
		,Trustee_Attorney_Plaintiff_Full1
		,Trustee_Attorney_Plaintiff_Full2
		,Original_Loan_Date
		,Original_Loan_Recording_Book
		,Original_Loan_Recording_Page
		,Original_Loan_Recording_Instrument_Nbr
		,Original_Loan_Amount
		,Lender_Beneficiary_Name
		,Default_Amount
		,Default_Date
		,Judgment_Amount
		,Original_Pre_Foreclosure_Date
		,Original_Pre_Foreclosure_Recording_Book
		,Original_Pre_Foreclosure_Recording_Page
		,Original_Pre_Foreclosure_Instrument_Nbr
		,Auction_Date
		,Auction_Location
		,Auction_City
		,Auction_State
		,Opening_Bid
		,Unpaid_Balance
		,Tax_Id_Nbr_APN_Unformatted
		,APN_Sequence_NBR
		,Tax_Id_Nbr_APN_Formatted
		,Pending_Transaction
		,Situs_House_Nbr
		,Situs_House_Nbr2
		,Situs_House_Nbr_Suffix
		,Situs_Direction
		,Situs_Street_Name
		,Situs_Mode
		,Situs_Post_Direction
		,Situ_Unit_Nbr
		,Situs_City
		,Situs_State
		,Situs_Zip_Code
		,Situs_Carrier_Code
		,Multi_Property_Indicator
		,Created
		--,Updated
		,PREVIOUS_PARCEL_NBR
		,PREVIOUS_PARCEL_SEQUENCE_NBR
		,Fmt_Inst_Nbr
		,CMT_ID_Inst_nbr
		,Fmt_Ori_Inst_Nbr
		,CMT_ID_Ori_Inst_nbr
		,Fmt_Book_Page
		,CMT_ID_Book_Page
		,Fmt_Ori_Book_Page
		,CMT_ID_Ori_Book_Page
		,Fmt_Loan_Inst_Nbr
		,CMT_ID_Loan_Inst_nbr
		,Fmt_Loan_Book_Page
		,CMT_ID_Loan_Book_Page
		,Source_Type
		,SRC_TBL
		,DEED_PID
		,SAM_PID
		,UR_Doc_Unique_Id
		,UR_Doc_Id
		,UR_Property_Id
		,UR_Name_Id
		,UR_Reference_Id
		,MTG_CLGX_UNIQUE_ID
		,MTG_Source_Type
		,CASE_NBR
		,Mtg_Sr_Unique_Id
		,UR_Prop_Seq_Num
		,Trustee_Sale_Number
		,Trustee_Telephone_Number
		,Auction_Time
		,Title_Company
		,UR_Remarks
		,Lender_Beneficiary_Name_extended
		)
	SELECT nullif(w.FIPS, 0) AS FIPS
		,nullif(w.REF_ID, 0) AS REF_ID
		,nullif(w.USState, '') AS USState
		,nullif(w.USCounty, '') AS USCounty
		,nullif(w.CLGX_Unique_ID, 0) AS CLGX_Unique_ID
		,nullif(w.Update_Timestamp, '') AS Update_Timestamp
		,nullif(w.Add_Change_Delete_Identifier, '') AS Add_Change_Delete_Identifier
		,nullif(w.Document_Type, '') AS Document_Type
		,nullif(w.Lis_Pendens_Type, '') AS Lis_Pendens_Type
		,nullif(w.Document_Date, '') AS Document_Date
		,nullif(w.Recording_Date, '') AS Recording_Date
		,nullif(w.Recording_Book, '') AS Recording_Book
		,nullif(w.Recording_Page, '') AS Recording_Page
		,nullif(w.Recording_Instrument_Nbr, '') AS Recording_Instrument_Nbr
		,nullif(w.Borrower_Defendant_Name_Full1, '') AS Borrower_Defendant_Name_Full1
		,nullif(w.Borrower_Defendant_Name_Full2, '') AS Borrower_Defendant_Name_Full2
		,nullif(w.Trustee_Attorney_Plaintiff_Full1, '') AS Trustee_Attorney_Plaintiff_Full1
		,nullif(w.Trustee_Attorney_Plaintiff_Full2, '') AS Trustee_Attorney_Plaintiff_Full2
		,nullif(w.Original_Loan_Date, '') AS Original_Loan_Date
		,nullif(w.Original_Loan_Recording_Book, '') AS Original_Loan_Recording_Book
		,nullif(w.Original_Loan_Recording_Page, '') AS Original_Loan_Recording_Page
		,nullif(w.Original_Loan_Recording_Instrument_Nbr, '') AS Original_Loan_Recording_Instrument_Nbr
		,nullif(w.Original_Loan_Amount, 0) AS Original_Loan_Amount
		,nullif(w.Lender_Beneficiary_Name, '') AS Lender_Beneficiary_Name
		,nullif(w.Default_Amount, 0) AS Default_Amount
		,nullif(w.Default_Date, '') AS Default_Date
		,nullif(w.Judgment_Amount, 0) AS Judgment_Amount
		,nullif(w.Original_Pre_Foreclosure_Date, '') AS Original_Pre_Foreclosure_Date
		,nullif(w.Original_Pre_Foreclosure_Recording_Book, '') AS Original_Pre_Foreclosure_Recording_Book
		,nullif(w.Original_Pre_Foreclosure_Recording_Page, '') AS Original_Pre_Foreclosure_Recording_Page
		,nullif(w.Original_Pre_Foreclosure_Instrument_Nbr, '') AS Original_Pre_Foreclosure_Instrument_Nbr
		,nullif(w.Auction_Date, '') AS Auction_Date
		,nullif(w.Auction_Location, '') AS Auction_Location
		,nullif(w.Auction_City, '') AS Auction_City
		,nullif(w.Auction_State, '') AS Auction_State
		,nullif(w.Opening_Bid, 0) AS Opening_Bid
		,nullif(w.Unpaid_Balance, 0) AS Unpaid_Balance
		,nullif(w.Tax_Id_Nbr_APN_Unformatted, '') AS Tax_Id_Nbr_APN_Unformatted
		,nullif(w.APN_Sequence_NBR, 0) AS APN_Sequence_NBR
		,nullif(w.Tax_Id_Nbr_APN_Formatted, '') AS Tax_Id_Nbr_APN_Formatted
		,nullif(w.Pending_Transaction, '') AS Pending_Transaction
		,nullif(w.Situs_House_Nbr, '') AS Situs_House_Nbr
		,nullif(w.Situs_House_Nbr2, '') AS Situs_House_Nbr2
		,nullif(w.Situs_House_Nbr_Suffix, '') AS Situs_House_Nbr_Suffix
		,nullif(w.Situs_Direction, '') AS Situs_Direction
		,nullif(w.Situs_Street_Name, '') AS Situs_Street_Name
		,nullif(w.Situs_Mode, '') AS Situs_Mode
		,nullif(w.Situs_Post_Direction, '') AS Situs_Post_Direction
		,nullif(w.Situ_Unit_Nbr, '') AS Situ_Unit_Nbr
		,nullif(w.Situs_City, '') AS Situs_City
		,nullif(w.Situs_State, '') AS Situs_State
		,nullif(w.Situs_Zip_Code, '') AS Situs_Zip_Code
		,nullif(w.Situs_Carrier_Code, '') AS Situs_Carrier_Code
		,nullif(w.Multi_Property_Indicator, '') AS Multi_Property_Indicator
		,nullif(w.Created, '') AS Created
		--,nullif(w.Updated, '') AS Updated
		,nullif(w.PREVIOUS_PARCEL_NBR, '') AS PREVIOUS_PARCEL_NBR
		,nullif(w.PREVIOUS_PARCEL_SEQUENCE_NBR, 0) AS PREVIOUS_PARCEL_SEQUENCE_NBR
		,nullif(w.Fmt_Inst_Nbr, '') AS Fmt_Inst_Nbr
		,nullif(w.CMT_ID_Inst_nbr, 0) AS CMT_ID_Inst_nbr
		,nullif(w.Fmt_Ori_Inst_Nbr, '') AS Fmt_Ori_Inst_Nbr
		,nullif(w.CMT_ID_Ori_Inst_nbr, 0) AS CMT_ID_Ori_Inst_nbr
		,nullif(w.Fmt_Book_Page, '') AS Fmt_Book_Page
		,nullif(w.CMT_ID_Book_Page, 0) AS CMT_ID_Book_Page
		,nullif(w.Fmt_Ori_Book_Page, '') AS Fmt_Ori_Book_Page
		,nullif(w.CMT_ID_Ori_Book_Page, 0) AS CMT_ID_Ori_Book_Page
		,nullif(w.Fmt_Loan_Inst_Nbr, '') AS Fmt_Loan_Inst_Nbr
		,nullif(w.CMT_ID_Loan_Inst_nbr, 0) AS CMT_ID_Loan_Inst_nbr
		,nullif(w.Fmt_Loan_Book_Page, '') AS Fmt_Loan_Book_Page
		,nullif(w.CMT_ID_Loan_Book_Page, 0) AS CMT_ID_Loan_Book_Page
		,nullif(w.Source_Type, '') AS Source_Type
		,nullif(w.SRC_TBL, '') AS SRC_TBL
		,isnull(w.DEED_PID, 0) AS DEED_PID
		,isnull(w.SAM_PID, 0) AS SAM_PID
		,nullif(w.UR_Doc_Unique_Id, '') AS UR_Doc_Unique_Id
		,nullif(w.UR_Doc_Id, 0) AS UR_Doc_Id
		,nullif(w.UR_Property_Id, 0) AS UR_Property_Id
		,nullif(w.UR_Name_Id, 0) AS UR_Name_Id
		,nullif(w.UR_Reference_Id, 0) AS UR_Reference_Id
		,nullif(w.MTG_CLGX_UNIQUE_ID, 0) AS MTG_CLGX_UNIQUE_ID
		,nullif(w.MTG_Source_Type, '') AS MTG_Source_Type
		,nullif(w.CASE_NBR, '') AS CASE_NBR
		,nullif(w.Mtg_Sr_Unique_Id, 0) AS Mtg_Sr_Unique_Id
		,nullif(w.UR_Prop_Seq_Num, 0) AS UR_Prop_Seq_Num
		,nullif(w.Trustee_Sale_Number, '') AS Trustee_Sale_Number
		,nullif(w.Trustee_Telephone_Number, '') AS Trustee_Telephone_Number
		,nullif(w.Auction_Time, '') AS Auction_Time
		,nullif(w.Title_Company, '') AS Title_Company
		,nullif(w.UR_Remarks, '') AS UR_Remarks
		,nullif(w.Lender_Beneficiary_Name_extended, '') AS Lender_Beneficiary_Name_extended--select *
	FROM [lien_DTDB].[INFC].[PFC_Work] w
	LEFT JOIN [Pre_Foreclosure].[dbo].[PreForeclosure] p ON p.Fips = w.fips
		AND isnull(w.UR_Reference_id, 0) = isnull(p.UR_Reference_id, 0)
		AND isnull(p.UR_Prop_Seq_Num, 0) = isnull(w.UR_Prop_Seq_Num, 0)
		AND p.CLGX_UNIQUE_ID = w.clgx_unique_id
		AND p.SRC_TBL = w.SRC_TBL
	WHERE p.fips IS NULL


--
-- #multi 
--

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp0_pfc]
		SELECT DISTINCT p.fips
			,p.[Fmt_Inst_Nbr]
			,p.FMT_Book_Page
			,p.recording_date
			,p.Fmt_Ori_Inst_Nbr
			,p.Fmt_Ori_Book_Page
		INTO [lien_dtdb].[tmp].[Multi_apn_temp0_pfc]
		FROM [Lien_dtdb].[infc].[pfc_work] p
		WHERE p.source_type = 'e' 

	-- extract the delete records form logfile
	declare @ext_date datetime = (
		select top 1 dateadd(day, -2, INFC_Extract_date) 
		from [lien].[UR].[document_transaction_log_tracker] with (nolock,index(ixu_update_date))
		where INFC_Extract_date is not null
		order by m_update_date desc 
		)

	DROP TABLE if exists [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_reset]

	SELECT DISTINCT dd.*
	into [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_reset]
	FROM [lien].[ur].[document_transaction_log] a with (nolock,index(ixc_update_date))
	OUTER APPLY (
		SELECT try_cast(d.fips_code AS INT) AS Fips
			,d.Fmt_Doc_Number AS Fmt_Inst_Nbr
			,d.FMT_Book_Page AS FMT_Book_Page
			,d.Recording_Date_D AS Recording_Date
			,rr.Fmt_Ori_Inst_Nbr
			,rr.Fmt_Ori_Book_Page
		FROM [lien].[ur].[document] d WITH (NOLOCK,INDEX (pk_document))
		CROSS APPLY (
			SELECT *
			FROM [trinitytest].[dbo].[hash_Paul_valid_doc_type] dt WITH (NOLOCK,INDEX (idx_doc_type))
			WHERE dt.doc_type = d.doc_type
				AND dt._dest = 'pfc'
			) dt
		OUTER APPLY (
			SELECT REFERENCE_id
				,Fmt_Reference_Doc_Number AS Fmt_Ori_Inst_Nbr
				,Fmt_BookPAge AS Fmt_Ori_Book_Page
			FROM [lien].[ur].[reference] r WITH (NOLOCK,INDEX (ix_doc_id))
			WHERE r.doc_id = d.doc_id
			) rr
		WHERE d.doc_id = a.doc_id
		) dd
	WHERE a.m_update_date >= @ext_date
		AND a.Process_name LIKE '%delete%'
		AND dd.fips IS NOT NULL

-- combine the the 2 file
	DROP TABLE if exists [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_comb]
	select DISTINCT u.*
	into [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_comb]
	from (
		select * from [lien_dtdb].[tmp].[Multi_apn_temp0_pfc]
		union  
		select * from [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_reset]
		) u
	
 


	CREATE clustered INDEX idx_fips_Fmt_Inst_bkpg_Recdt ON [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_comb] (
			fips
			,[Fmt_Inst_Nbr]
			,FMT_Book_Page
			,recording_date
			,Fmt_Ori_Inst_Nbr
			,Fmt_Ori_Book_Page
			)


	



/*
-- null multi ind the records on ras for the combined file
-- remove this update
	update a
	set a.Multi_Property_Indicator = null
	from lien_dtdb.tmp.Multi_apn_temp0_pfc_comb c WITH (NOLOCK,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt))
	inner join [Pre_ForeClosure].[dbo].[PreForeclosure] a WITH (NOLOCK,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)) 
	ON a.fips = c.fips
		AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(c.[Fmt_Inst_Nbr], '')
		AND isnull(a.FMT_Book_Page, '') = isnull(c.FMT_Book_Page, '')
		AND isnull(a.recording_date, '') = isnull(c.recording_date, '')
		AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(c.Fmt_Ori_Inst_Nbr, '')
		AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(c.Fmt_Ori_Book_Page, '')
	WHERE a.source_type = 'e'
	

	DROP TABLE

	IF EXISTS lien_dtdb.tmp.Multi_apn_temp1_pfc
		SELECT a.ur_doc_id
			,d.fips_code
			,d.recording_date_d
			,d.doc_type
			,d.cmt_id
			,ROW_NUMBER() OVER (
				PARTITION BY d.fips_code
				,d.recording_date_d
				,d.doc_type
				,d.cmt_id
				,a.[Fmt_Inst_Nbr]
				,a.FMT_Book_Page
				,a.Fmt_Ori_Inst_Nbr
				,a.Fmt_Ori_Book_Page ORDER BY a.ur_doc_id
					,a.ref_id
					,a.[Tax_Id_Nbr_APN_Unformatted]
					--,a.ORIGINAL_SITE_ADDRESS
				) AS ROW4
			,'a' AS _a
			,a.[PreForeclosureID]
			,a.fips
			,a.ref_id
			,a.[Fmt_Inst_Nbr]
			,a.FMT_Book_Page
			,a.Fmt_Ori_Inst_Nbr
			,a.Fmt_Ori_Book_Page
			,a.recording_date
			,a.source_type
		INTO lien_dtdb.tmp.Multi_apn_temp1_pfc
		FROM lien_dtdb.tmp.Multi_apn_temp0_pfc_comb dw WITH (NOLOCK,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt))
		INNER JOIN [Pre_ForeClosure].[dbo].[PreForeclosure] a WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				) ON a.fips = dw.fips
			AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(dw.[Fmt_Inst_Nbr], '')
			AND isnull(a.FMT_Book_Page, '') = isnull(dw.FMT_Book_Page, '')
			AND isnull(a.recording_date, '') = isnull(dw.recording_date, '')
			AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(dw.Fmt_Ori_Inst_Nbr, '')
			AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(dw.Fmt_Ori_Book_Page, '')
		LEFT JOIN lien.ur.document d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.doc_id = a.ur_doc_id
		WHERE a.source_type = 'e'
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON lien_dtdb.tmp.Multi_apn_temp1_pfc (
		fips
		,[Fmt_Inst_Nbr]
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		,source_type
		)
*/

 



	DROP TABLE
	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc]
		SELECT a.ur_doc_id
			,d.fips_code
			,d.recording_date_d
			,d.doc_type
			,d.cmt_id
			,ROW_NUMBER() OVER (
				PARTITION BY --d.fips_code
				d.recording_date_d
				,d.doc_type
				,d.cmt_id
				,a.fips
				,ISNULL(a.[Fmt_Inst_Nbr],'')
				,ISNULL(a.FMT_Book_Page,'')
				,ISNULL(a.Fmt_Ori_Inst_Nbr,'')
				,ISNULL(a.Fmt_Ori_Book_Page ,'')
				ORDER BY a.ur_doc_id
					,a.ref_id
					,a.[Tax_Id_Nbr_APN_Unformatted]
					--,a.ORIGINAL_SITE_ADDRESS
				) AS ROW4
			,'a' AS _a
			,a.[PreForeclosureID]
			,a.fips
			,a.ref_id
			,a.[Fmt_Inst_Nbr]
			,a.FMT_Book_Page
			,a.Fmt_Ori_Inst_Nbr
			,a.Fmt_Ori_Book_Page
			,a.recording_date
			,a.source_type
			,a.src_tbl
			,a.Multi_Property_Indicator
		INTO [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp0_pfc_comb] dw WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				)
		INNER JOIN [Pre_ForeClosure].[dbo].[PreForeclosure] a WITH (
				NOLOCK
				,INDEX (idx_fips_Fmt_Inst_bkpg_Recdt)
				) ON a.fips = dw.fips
			AND a.recording_date = dw.recording_date
			AND isnull(a.[Fmt_Inst_Nbr], '') = isnull(dw.[Fmt_Inst_Nbr], '')
			AND isnull(a.FMT_Book_Page, '') = isnull(dw.FMT_Book_Page, '')
			--AND isnull(a.recording_date, '') = isnull(dw.recording_date, '')
			AND isnull(a.Fmt_Ori_Inst_Nbr, '') = isnull(dw.Fmt_Ori_Inst_Nbr, '')
			AND isnull(a.Fmt_Ori_Book_Page, '') = isnull(dw.Fmt_Ori_Book_Page, '')
		LEFT JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.doc_id = a.ur_doc_id
		WHERE a.source_type = 'e'
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc] (
		fips
		,[Fmt_Inst_Nbr]
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		,source_type
		)

  --select top 100 * from lien_dtdb.tmp.Multi_apn_temp_fips_pfc



	--
	--identify records that have multiple occurences on the pfc work for the same document
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp2_pfc]
		SELECT DISTINCT --d.fips_code
			d.fips
			,d.Fmt_Inst_Nbr
			,d.FMT_Book_Page
			,d.Fmt_Ori_Inst_Nbr
			,d.Fmt_Ori_Book_Page
			,d.recording_date
			--,d.recording_date_d
			,d.doc_type
			,d.cmt_id
		INTO [lien_dtdb].[tmp].[Multi_apn_temp2_pfc]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc] d
		--FROM lien_dtdb.tmp.Multi_apn_temp1_pfc d
		WHERE row4 > 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_multi ON [lien_dtdb].[tmp].[Multi_apn_temp2_pfc] (
		--fips_code
		fips
		,Fmt_Inst_Nbr
		,FMT_Book_Page
		,Fmt_Ori_Inst_Nbr
		,Fmt_Ori_Book_Page
		,recording_date
		--,recording_date_d
		,doc_type
		,cmt_id
		)

	--
	-- assign the M or D so that we can set the multi_apn flag
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp2_pfc_apn]
		SELECT c.[PreForeclosureID]
			,CASE 
				WHEN c.row4 = 1
					THEN 'M'
				ELSE 'D'
				END AS Multi_apn
		INTO [lien_dtdb].[tmp].[Multi_apn_temp2_pfc_apn]
		FROM (
			SELECT b.*
			FROM [lien_dtdb].[tmp].[Multi_apn_temp2_pfc] a WITH (
					NOLOCK
					,INDEX (idx_multi)
					)
			INNER JOIN [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc] b WITH (
			--INNER JOIN lien_dtdb.tmp.Multi_apn_temp1_pfc b WITH (
					NOLOCK
					,INDEX (idx_multi)
					) ON --b.fips_code = a.fips_code
					b.fips = a.fips
				AND isnull(b.[Fmt_Inst_Nbr], '') = isnull(a.[Fmt_Inst_Nbr], '')
				AND isnull(b.FMT_Book_Page, '') = isnull(a.FMT_Book_Page, '')
				AND isnull(b.Fmt_Ori_Inst_Nbr, '') = isnull(a.Fmt_Ori_Inst_Nbr, '')
				AND isnull(b.Fmt_Ori_Book_Page, '') = isnull(a.Fmt_Ori_Book_Page, '')
				AND b.recording_date = a.recording_date
				--AND b.recording_date_d = a.recording_date_d
				AND b.doc_type = a.doc_type
				AND isnull(b.cmt_id, 0) = isnull(a.cmt_id, 0)
			) c
		ORDER BY --c.fips_code
			c.fips
			,c.Fmt_Inst_Nbr
			,c.FMT_Book_Page
			,c.Fmt_Ori_Inst_Nbr
			,c.Fmt_Ori_Book_Page
			,c.recording_date
			--,c.recording_date_d
			,c.doc_type
			,c.cmt_id
			,c.ROW4
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_PreForeclosureID ON [lien_dtdb].[tmp].[Multi_apn_temp2_pfc_apn] ([PreForeclosureID])

	--
	-- create the combine file of all the detail records plus the multi_apn results
	-- 	
	DROP TABLE
	IF EXISTS [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc_update]
		SELECT a.*
			,b.[PreForeclosureID] AS b_PreForeclosureID
			,b.Multi_apn as new_Multi_apn
			--,b.Multi_apn AS new_multi_apn
		INTO [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc_update]
		FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc] a WITH (
				NOLOCK
				,INDEX (idx_multi)
				--,INDEX (idx_pfc_id)
				)
		OUTER APPLY (
			SELECT *
			FROM [Lien_dtdb].[tmp].[Multi_apn_temp2_pfc_apn] b WITH (
					NOLOCK
					,INDEX (idx_PreForeclosureID)
					)
			WHERE a.[PreForeclosureID] = b.[PreForeclosureID]
			) b

	CREATE CLUSTERED INDEX idx_PreForeclosureID ON [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc_update] ([PreForeclosureID])
/*
	 
	 select * from lien_dtdb.tmp.Multi_apn_temp_fips_pfc_update  a
	 	WHERE isnull(a.[Multi_Property_Indicator], '') <> isnull(a.new_Multi_apn, '')

	
*/

	-- do the update just like deed without the sale_amout   
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.[Multi_Property_Indicator] = a.new_Multi_apn
		,d.updated = getdate()
	FROM [lien_dtdb].[tmp].[Multi_apn_temp_fips_pfc_update] a WITH (
	--FROM lien_dtdb.tmp.Multi_apn_temp2_pfc_apn a WITH (
			NOLOCK
			,INDEX (idx_PreForeclosureID)
			)
	INNER JOIN [Pre_ForeClosure].[dbo].[PreForeclosure] d WITH (
			NOLOCK
			,INDEX (PK_PreForeclosure)
			) ON d.[PreForeclosureID] = a.[PreForeclosureID]
	WHERE isnull(a.[Multi_Property_Indicator], '') <> isnull(a.new_Multi_apn, '')
	OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

	COMMIT

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'UR_Merge_PFC_From_PFC_Work'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


