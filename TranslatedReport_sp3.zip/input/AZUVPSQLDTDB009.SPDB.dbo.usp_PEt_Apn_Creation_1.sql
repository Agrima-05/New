/* Source: DWS-ETL02.DATATREE.LOCAL | SPDB | dbo.usp_PEt_Apn_Creation_1 | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- =============================================
CREATE PROCEDURE [SPDB].[dbo].[usp_PEt_Apn_Creation_1] @fips INT = NULL
	,@Apn_type VARCHAR(10) = NULL
	,@list_Sql INT = 0
	,@Refresh BIT = 1
AS
begin try
declare @ERROR VARCHAR(500)

	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'usp_PEt_Apn_Creation_1'
		,N'Started'

-- declare @fips INT = 5051 ,@Apn_type VARCHAR(5) = 'N_UNF' ,@list_Sql INT = 1 ,@Refresh BIT = 0

-- declare @fips int = 5051, @Apn_type VARCHAR(5) = 'N_Fmt'  ,@list_Sql INT = 1 ,@Refresh BIT = 1
		DECLARE @SQL VARCHAR(MAX)
			,@LinkSvr VARCHAR(100) = ''





		--IF @@SERVERNAME <> 'AZUVNSQLDTDB003'
			SET @LinkSvr = case when @@SERVERNAME = N'AZUVPSQLDTDB009' then  '[DWS-ETL01].'
						    when @@SERVERNAME = N'AZUVPSQLDTDB029' then '[DWS-ETL01.DATATREE.LOCAL].'
							else ''
							end 


DECLARE @sql_cmd VARCHAR(max)
DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
	,@Rule VARCHAR(max) = NULL 
	,@Status VARCHAR(20) = NULL --'To_Be_Processed'
	,@node_delimeter VARCHAR(10) = NULL --'-'
	-- select top 100 * from Lien.dbo.PET_APN_Additional_Formats a
DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type


SELECT @Source_Apn = a.Source_Apn
	,@Rule = a.[Rule]
	,@node_delimeter = a.node_delimeter
FROM [PEt].[dbo].[PET_APN_Additional_Formats] a
WHERE a.fips = @fips
	AND a.APN_Type = @apn_type

SET @node_delimeter = CASE 
		WHEN @node_delimeter IS NULL
			THEN ' '
		ELSE @node_delimeter
		END
-- and (@Refresh  = 1 or ( @refresh = 0 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk) ))
SET @sql_cmd = cast(N'
DROP TABLE if exists pet.pet_tmp.usp_PEt_Apn_Creation_1_source1

SELECT  A.[FIPS]
	,a.[REF_ID]
	,a.' + @Source_apn + ' as apn
	,a.Unformatted_apn
	,a.original_apn
	,a.Alternate_apn
	,a.MUNICIPALITY_CODE
	,a.MUNICIPALITY_NAME


into pet.pet_tmp.usp_PEt_Apn_Creation_1_source1
FROM ' + @LinkSvr + '[Assr].[dbo].[Assr] a with (nolock) 

WHERE fips = ' + try_cast(@fips AS VARCHAR) AS NVARCHAR(max))

IF @refresh = 0
BEGIN
	SET @sql_cmd = @sql_cmd + cast(N'
 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk)
' AS NVARCHAR(max))
END


SET @sql_cmd = @sql_cmd + cast(N'


DROP TABLE if exists pet.pet_tmp.usp_PEt_Apn_Creation_1_source


SELECT  a.*
	,ROW_NUMBER( ) OVER ( PARTITION BY a.apn  ORDER BY ( SELECT 0 ) ) AS ROW4
	,aa.*

into pet.pet_tmp.usp_PEt_Apn_Creation_1_source
FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_source1 a
outer apply (SELECT node1,node2,node3,node4,node5,node6,node7,node8,node9,node10  FROM  spdb.[dbo].[fn_get_apn_nodes] (a.apn,''' + @node_delimeter + 
		''')
) aa

create clustered index ixa on pet.pet_tmp.usp_PEt_Apn_Creation_1_source (REf_id)

Delete from pet.pet_tmp.usp_PEt_Apn_Creation_1_source where ref_id in (
Select distinct Ref_id from pet.pet_tmp.usp_PEt_Apn_Creation_1_source where row4 > 1
)

DROP TABLE if exists pet.dbo.Pet_apn_additions

CREATE TABLE [PET].[dbo].[Pet_apn_additions](
	[REF_ID] [numeric](12, 0) NOT NULL,
	[FIPS] [int] NOT NULL,
	[APN_Type] [varchar](10) NULL,
	[APN_ID] [numeric](12, 0) NULL,
	[APN] [varchar](60) NULL,
	[created] [datetime] NULL,
	[updated] [datetime] NULL
) ON [PRIMARY]


create index ixa on pet.dbo.Pet_apn_additions (APN)



INSERT INTO pet.dbo.Pet_apn_additions
           ([REF_ID]
           ,[FIPS]
           ,[APN_Type]
           ,[APN_ID]
           ,[APN]
           ,[created]
           ,[updated]
           )
SELECT a.[REF_ID]
      ,a.[FIPS]
      ,''' + @APN_Type + 
		''' as [APN_Type]
      ,0 as [APN_ID]
      ,b._new_apn as [APN]
      ,getdate() as [created]
      ,getdate() as [updated]
  FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_source a
  OUTER APPLY (
	SELECT CASE 
			' + @Rule + '
			ELSE NULL
			END AS _new_apn
	) b
  where b._new_apn is not null



' AS NVARCHAR(max))

IF @list_Sql = 1
BEGIN
	SELECT @sql_cmd
END

IF @list_Sql = 0
BEGIN
	EXEC (@sql_cmd)
END
		--EXEC ntp.Stage.[AddNtpLog] N'info'
		--	,N'usp_PEt_Apn_Creation_1 END'
		--	,@mess
	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'usp_PEt_Apn_Creation_1'
		,N'Started'

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

