/* Source: DWS-ETL02.DATATREE.LOCAL | spdb | EPRVDB.CreatePageCntFileForNEO | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

/* =================================================================================================
	Author:			Henk de Weerdt
	Create date:	01/02/2025
	Description:	This procedure will first create a table for NEO that will then be exported 
					as a CSV file by SSIS

	CHANGE LOG:    
	==========    
	who		date		change    
	Henk	01/02/2025	Initial version
	Henk	01/10/2025	Right trimmed state and convert null to zero for page count
	Henk	01/23/2025	Format update date to mm/dd/yyyy hh:mm:ss
						Replace cmt doc number with recording doc number
	Henk	01/31/2025	try_cast fips + add indexes
	Henk	02/26/2025	Change parcel to varchar(2000)
	Henk	04/07/2025	New rules for reference:
						1. Reference 2 to be null
						2. If Ref2 = Ref1 or Ref2 = 0 then blank
						3. If Ref2 <> Ref1, then duplicat record and insert Ref2 value as Ref1

						Only take records newer from previous year
	Henk	04/22/2025	Modify recording document number for CACO, CA28 & CA39
	Henk	04/30/2025  Modify recording document format for CABA & CASJ
	Henk	05/13/2025	Ensure 'YEAR' is integer and initialize @reccount to zero
	Henk	07/30/2025	Add FileId to input to ensure only related files are loaded
	Henk	08/11/2025	Move the property data in the Remarks column and NULL the Parcel column
	Henk	08/15/2025	Make sure remarks is not larger than 200 characters
	Henk	01/26/2026	Add alt cmt id and alt doc number to joins
================================================================================================= */
CREATE PROCEDURE [SPDB].[EPRVDB].[CreatePageCntFileForNEO] @fips_code INT
	,@fileId INT
	,@reccount INT OUTPUT
AS
BEGIN
	-- DECLARE @fips_code INT = 12081, @reccount INT
	SET NOCOUNT ON;
	SET @reccount = 0

	DECLARE @fips_a CHAR(5) = RIGHT('00000' + try_cast(@fips_code AS VARCHAR(5)), 5)
	DECLARE @mess VARCHAR(100) = 'Started for Fips = ' + @fips_a
	DECLARE @last_year INT = YEAR(GETDATE()) - 1

	EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info'
		,N'CreatePageCntFileForNEO'
		,@mess

	DECLARE @docFileId INT = @fileId
		,@nameFileId INT = 0
		,@propFileId INT = 0
		,@refFileId INT = 0
		,@countyFileBatch VARCHAR(200)

	SELECT @countyFileBatch = [FileName]
	FROM [EPR_VDB_Tortee].[dbo].[FilesLoaded]
	WHERE [FileId] = @docFileId

	DECLARE @batch VARCHAR(200) = (
			SELECT substring(@countyFileBatch, 1, charindex('_Grantor-Grantee ', @countyFileBatch))
			)

	SELECT @nameFileId = [FileId]
	FROM [EPR_VDB_Tortee].[dbo].[FilesLoaded]
	WHERE [FileName] LIKE @batch + '%Name%'

	SELECT @propFileId = [FileId]
	FROM [EPR_VDB_Tortee].[dbo].[FilesLoaded]
	WHERE [FileName] LIKE @batch + '%Property%'

	SELECT @refFileId = [FileId]
	FROM [EPR_VDB_Tortee].[dbo].[FilesLoaded]
	WHERE [FileName] LIKE @batch + '%Reference%'

	TRUNCATE TABLE [EPR_VDB_TORTEE].[dbo].[NEO_PageCountExport];

	INSERT INTO [EPR_VDB_TORTEE].[dbo].[NEO_PageCountExport]
	SELECT us.STATE AS STATE
		,substring(rtrim(c.county), 1, 200) AS COUNTY_NAME
		,format(getdate(), 'MM/dd/yyyy HH:mm:ss') AS UPDATE_DATE
		,d.fips_code AS FIPS
		,try_cast(d.recording_year AS INT) AS YEAR
		,rd.Recording_Doc_Number AS INST_NUM1
		,NULL AS INST_NUM2
		,substring(d.recording_book, 1, 200) AS BOOK
		,substring(d.recording_page, 1, 200) AS PAGE
		,try_cast(d.recording_page_count AS INT) AS PGCNT
		,try_cast(d.loan_financed_amount AS DECIMAL(19, 2)) AS AMOUNT1
		,NULL AS AMOUNT2
		,format([spdb].[eprvdb].[fn_DTOCR_RecordingDate](d.recording_date), 'yyyyMMdd') AS REC_DATE
		,substring(COUNTY_party_name, 1, 200) AS PARTY_NAME
		,CASE 
			WHEN role_type IN (
					'GRANTOR'
					,'PARTY1'
					)
				THEN 1
			WHEN role_type IN (
					'GRANTEE'
					,'PARTY2'
					)
				THEN 2
			ELSE NULL
			END AS PARTY_IND
		,substring(d.doc_type, 1, 200) AS DOCTYP
		,substring(d.Doc_Title, 1, 200) AS SECTYP
		,substring(a.ref1, 1, 200) AS REF1
		,substring(a.ref2, 1, 200) AS REF2
		,substring(CASE 
			WHEN LEN(LTRIM(RTRIM(ISNULL(d.remarks, '')))) = 0
				AND LEN(LTRIM(RTRIM(ISNULL(b.PARCEL, '')))) = 0
				THEN NULL
			WHEN LEN(LTRIM(RTRIM(ISNULL(d.remarks, '')))) = 0
				THEN LTRIM(RTRIM(b.PARCEL))
			WHEN LEN(LTRIM(RTRIM(ISNULL(b.PARCEL, '')))) = 0
				THEN LTRIM(RTRIM(d.remarks))
			ELSE LTRIM(RTRIM(d.remarks)) + ' ' + LTRIM(RTRIM(b.PARCEL))
			END, 1, 200) AS REMARKS
		,NULL AS PARCEL
		,NULL AS RETAKE
	FROM [EPR_VDB_TORTEE].[dbo].[Document_table] d WITH (
			NOLOCK
			,INDEX (idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc)
			)
	JOIN [EPR_VDB].[dbo].[CountyCodes] c WITH (NOLOCK) ON c.fips = d.fips_code -- cast(t.fips_code AS INT)
	JOIN [EPR_VDB_TORTEE].[dbo].[Name_Table] n WITH (
			NOLOCK
			,INDEX (idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc)
			) ON d.fips_code = n.fips_code
		AND ISNULL(d.cmt_docnumber,'') = ISNULL(n.cmt_docnumber,'')
		AND ISNULL(d.cmt_id,0) = ISNULL(n.cmt_id,0)
		AND ISNULL(d.alt_cmt_docnumber,'') = ISNULL(n.alt_cmt_docnumber,'')
		AND ISNULL(d.alt_cmt_id,0) = ISNULL(n.alt_cmt_id,0)
		AND ISNULL(d.Doc_Type,'') = ISNULL(n.Doc_Type,'')
		AND n.[FileId] = @nameFileId
	JOIN [EPR_VDB_TORTEE].[dbo].[US_STATES] us WITH (NOLOCK) ON c.STATE = us.ABR
	OUTER APPLY (
		SELECT TOP 1 Reference_Doc_Number AS ref1
			,lead(Reference_Doc_Number, 1, 0) OVER (
				ORDER BY FIPS_Code
					,cmt_docnumber
					,cmt_id
					,doc_type
					,m_create_date
				) AS ref2
		FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] r WITH (
				NOLOCK
				,INDEX (idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc)
				)
		WHERE d.fips_code = r.fips_code
			AND ISNULL(d.cmt_docnumber,'') = ISNULL(r.cmt_docnumber,'')
			AND ISNULL(d.cmt_id,0) = ISNULL(r.cmt_id,0)
			AND ISNULL(d.alt_cmt_docnumber,'') = ISNULL(r.alt_cmt_docnumber,'')
			AND ISNULL(d.alt_cmt_id,0) = ISNULL(r.alt_cmt_id,0)
			AND ISNULL(d.Doc_Type,'') = ISNULL(r.Doc_Type,'')
			AND r.[FileId] = @refFileId
		) a
	OUTER APPLY (
		SELECT TOP 1 CASE 
				WHEN ISNULL(Legal_Desc_Extended, '') <> ''
					THEN Legal_Desc_Extended
				ELSE CONCAT (
						IIF(legal_desc_abstract_portion = '', '', 'LDA_P: ' + legal_desc_abstract_portion + ' ; ')
						,IIF(legal_desc_abstract_acreage = '', '', 'LDA_Ac: ' + legal_desc_abstract_acreage + ' ; ')
						,IIF(legal_desc_abstract_name = '', '', 'LDA_Nm: ' + legal_desc_abstract_name + ' ; ')
						,IIF(legal_desc_abstract_number = '', '', 'LDA_Nu: ' + legal_desc_abstract_number + ' ; ')
						,IIF(legal_desc_address = '', '', 'LD_Ad: ' + legal_desc_address + ' ; ')
						,IIF(legal_desc_address_city = '', '', 'LD_AC: ' + legal_desc_address_city + ' ; ')
						,IIF(legal_desc_address_state = '', '', 'LD_AS: ' + legal_desc_address_state + ' ; ')
						,IIF(legal_desc_address_zip = '', '', 'LD_AZ: ' + legal_desc_address_zip + ' ; ')
						,IIF(legal_desc_apn = '', '', 'LD_APN: ' + legal_desc_apn + ' ; ')
						,IIF(legal_desc_map_portion = '', '', 'LD_MP: ' + legal_desc_map_portion + ' ; ')
						,IIF(legal_desc_map_lot_low = '', '', 'LD_MLL: ' + legal_desc_map_lot_low + ' ; ')
						,IIF(legal_desc_map_block = '', '', 'LD_MB: ' + legal_desc_map_block + ' ; ')
						,IIF(legal_desc_map_plat_name = '', '', 'LD_MPNm: ' + legal_desc_map_plat_name + ' ; ')
						,IIF(legal_desc_map_plat_number = '', '', 'LD_MPNu: ' + legal_desc_map_plat_number + ' ; ')
						,IIF(legal_desc_map_plat_type_indicator = '', '', 'LD_MPTI: ' + legal_desc_map_plat_type_indicator + ' ; ')
						,IIF(legal_desc_map_plat_book = '', '', 'LD_MPB: ' + legal_desc_map_plat_book + ' ; ')
						,IIF(legal_desc_map_plat_page = '', '', 'LD_MPP: ' + legal_desc_map_plat_page + ' ; ')
						,IIF(legal_desc_str_portion = '', '', 'LD_SP: ' + legal_desc_str_portion + ' ; ')
						,IIF(legal_desc_str_quarter = '', '', 'LD_SQ: ' + legal_desc_str_quarter + ' ; ')
						,IIF(legal_desc_str_section = '', '', 'LD_SS: ' + legal_desc_str_section + ' ; ')
						,IIF(legal_desc_str_township = '', '', 'LD_ST: ' + legal_desc_str_township + ' ; ')
						,IIF(legal_desc_str_range = '', '', 'LD_SR: ' + legal_desc_str_range + ' ; ')
						,IIF(Legal_Desc_Map_Lot_High = '', '', 'LD_MLH: ' + Legal_Desc_Map_Lot_High + ' ; ')
						,IIF(Legal_Desc_Map_Unit_low = '', '', 'LD_MUL: ' + Legal_Desc_Map_Unit_low + ' ; ')
						,IIF(Legal_Desc_STR_Government_Lot = '', '', 'LD_SGL: ' + Legal_Desc_STR_Government_Lot + ' ; ')
						)
				END AS PARCEL
		FROM [EPR_VDB_TORTEE].[dbo].[Property_table] p WITH (
				NOLOCK
				,INDEX (idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc)
				)
		WHERE d.fips_code = p.fips_code
			AND ISNULL(d.cmt_docnumber,'') = ISNULL(p.cmt_docnumber,'')
			AND ISNULL(d.cmt_id,0) = ISNULL(p.cmt_id,0)
			AND ISNULL(d.alt_cmt_docnumber,'') = ISNULL(p.alt_cmt_docnumber,'')
			AND ISNULL(d.alt_cmt_id,0) = ISNULL(p.alt_cmt_id,0)
			AND ISNULL(d.Doc_Type,'') = ISNULL(p.Doc_Type,'')
			AND p.[FileId] = @propFileId
		) b
	OUTER APPLY (
		SELECT CASE 
				WHEN d.fips_code = 6013
					THEN SUBSTRING(d.Recording_Doc_Number, 1, IIF(CHARINDEX('-', d.Recording_Doc_Number) > 0, CHARINDEX('-', d.Recording_Doc_Number) - 1, 200))
				WHEN d.fips_code IN (
						6055
						,6083
						,6077
						,6078
						)
					THEN REPLACE(d.Recording_Doc_Number, '-', '')
				ELSE substring(d.Recording_Doc_Number, 1, 200)
				END AS Recording_Doc_Number
		) rd
	WHERE d.fips_code = @fips_code
		AND d.recording_year >= @last_year
		AND d.[FileId] = @docFileId

	SET @reccount = @@ROWCOUNT
	SET @mess = 'Ended with records inserted = ' + try_cast(@reccount AS VARCHAR(20))

	--SELECT @mess
	EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info'
		,N'CreatePageCntFileForNEO'
		,@mess

	INSERT INTO [EPR_VDB_TORTEE].[dbo].[NEO_PageCountExport]
	SELECT STATE
		,COUNTY_NAME
		,UPDATE_DATE
		,FIPS
		,YEAR
		,INST_NUM1
		,INST_NUM2
		,BOOK
		,PAGE
		,PGCNT
		,AMOUNT1
		,AMOUNT2
		,REC_DATE
		,PARTY_NAME
		,PARTY_IND
		,DOCTYP
		,SECTYP
		,REF2 AS REF1
		,NULL AS REF2
		,REMARKS
		,PARCEL
		,RETAKE
	-- select *
	FROM [EPR_VDB_TORTEE].[dbo].[NEO_PageCountExport]
	WHERE fips = @fips_code
		AND [YEAR] >= @last_year
		AND REF1 <> REF2
		AND ISNULL(REF2, '0') <> '0'

	UPDATE [EPR_VDB_TORTEE].[dbo].[NEO_PageCountExport]
	SET ref2 = NULL
	WHERE fips = @fips_code
END


