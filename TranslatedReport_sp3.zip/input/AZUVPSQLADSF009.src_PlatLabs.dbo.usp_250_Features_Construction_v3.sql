SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Construction_v3]

AS
BEGIN

	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[ConstructionJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))		
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[ConstructionJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Construction, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Construction') AS j

				DROP TABLE IF EXISTS Table_P
				DROP TABLE IF EXISTS Table_Q
				DROP TABLE IF EXISTS Table_R

				SELECT MLSID,MLS_LISTING_ID,t.[value] as [General] INTO [src_PlatLabs].[dbo].[Table_p]
				FROM [src_Platlabs].[features].[ConstructionJSON] t1 with(NOLOCK)
				CROSS APPLY OPENJSON(t1.Construction) AS t
				WHERE t.[key] = 'General' AND t1.[uid] in(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
				
				/*
				Select MLSID,MLS_LISTING_ID,[General] INTO Table_p
						from [src_Platlabs].[features].[ConstructionJSON] with(NOLOCK)
								CROSS APPLY OPENJSON([Construction]) WITH([General] varchar(1000)) as ConstGeneral_array
							WHERE [Construction] like '%"General"%'
							and [uid] in(Select [uid] From listing.ListingsRaw_Batch)
							*/

				Create INDEX ix_MlsIDListingID on Table_p(MLSID,MLS_LISTING_ID)
				create INDEX ix_MLSID on Table_p(MLSID)

				SELECT MLSID,MLS_LISTING_ID,t.[value] as [Roofing] INTO [src_PlatLabs].[dbo].[Table_q]
				FROM [src_Platlabs].[features].[ConstructionJSON] t1 with(NOLOCK)
				CROSS APPLY OPENJSON(t1.Construction) AS t
				WHERE t.[key] = 'Roofing' AND t1.[uid] in(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

				/*
				Select MLSID,MLS_LISTING_ID,[Roofing] INTO Table_q
						from [src_Platlabs].[features].[ConstructionJSON] with(NOLOCK)
								CROSS APPLY OPENJSON([Construction]) WITH([Roofing] varchar(1000)) as Roofing_array
							WHERE [Construction] like '%"Roofing"%'
							and [uid] in(Select [uid] From listing.ListingsRaw_Batch)
							*/

				Create INDEX ix_MlsIDListingID on Table_q(MLSID,MLS_LISTING_ID)
				create INDEX ix_MLSID on Table_q(MLSID)

				SELECT MLSID,MLS_LISTING_ID,t.[value] as [Windows] INTO [src_PlatLabs].[dbo].[Table_r]
				FROM [src_Platlabs].[features].[ConstructionJSON] t1 with(NOLOCK)
				CROSS APPLY OPENJSON(t1.Construction) AS t
				WHERE t.[key] = 'Windows' AND t1.[uid] in(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

				/*
				Select MLSID,MLS_LISTING_ID,[Windows] INTO Table_r
						from [src_Platlabs].[features].[ConstructionJSON] with(NOLOCK)
								CROSS APPLY OPENJSON([Construction]) WITH([Windows] varchar(1000)) as Windows_array
							WHERE [Construction] like '%"Windows"%'
							and [uid] in(Select [uid] From listing.ListingsRaw_Batch)
							*/

				Create INDEX ix_MlsIDListingID on Table_r(MLSID,MLS_LISTING_ID)
				create INDEX ix_MLSID on Table_r(MLSID)


	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




