/* Source: DWS-ETL02.DATATREE.LOCAL | SPDB | dbo.usp_PEt_Apn_Creation_2 | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- ================================================================================================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- ================================================================================================================
/******************************************************************************************************************
CHANGE LOG:
==========
who                date                change
Marie   9/13/2022        Remove Tanslated Fips 
******************************************************************************************************************/
CREATE
	

 PROCEDURE [SPDB].[dbo].[usp_PEt_Apn_Creation_2] @fips INT = NULL
	,@Apn_type VARCHAR(10) = NULL
	,@list_Sql INT = 0
	,@Refresh BIT = 1
	
AS
BEGIN TRY
declare @ERROR VARCHAR(500) --OUTPUT

	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'usp_PEt_Apn_Creation_2'
		,N'Started'



	DECLARE @sql_cmd VARCHAR(max)
	DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
		,@Rule VARCHAR(max) = NULL --
		,@Status VARCHAR(20) = NULL --'To_Be_Processed'
		,@node_delimeter VARCHAR(10) = NULL --'-'
	DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type

	--IF @list_Sql = 0
	--BEGIN
	--EXEC ntp.Stage.[AddNtpLog] N'info'
	--        ,N'[usp_PEt_Apn_Creation_2] begin'
	--        ,@mess
	--END
	--SELECT @FIPS = a.FIPS
	--        ,@APN_Type = a.APN_Type
	--        ,
	SELECT @Source_Apn = a.Source_Apn
		,@Rule = a.[Rule]
		,@node_delimeter = '-'
	FROM [PET].[dbo].[PET_APN_Additional_Formats] a
	WHERE fips = @fips
		AND a.apn_type = @apn_type

	--DECLARE @translated_fips INT = CASE 
	--                WHEN @fips BETWEEN 15000
	--                                AND 16000
	--                        THEN 15999
	--                ELSE @fips
	--                END
	SET @sql_cmd = cast(N'

delete a from pet.dbo.pet_apn a
where a.fips = ' + try_cast(@fips AS VARCHAR) + '
and a.apn_type = ''' + @Apn_type + '''
' AS NVARCHAR(max))

	IF @refresh = 0
	BEGIN
		SET @sql_cmd = @sql_cmd + cast(N'
 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk)
' AS NVARCHAR(max))
	END

	SET @sql_cmd = @sql_cmd + cast(N'

INSERT INTO PET.[dbo].[PET_APN]
           ([REF_ID]
           ,[FIPS]
           ,[APN_Type]
           ,[APN_ID]
           ,[APN]
           ,[created]
           ,[updated]
           )
SELECT a.[REF_ID]
           ,a.[FIPS]
           ,a.[APN_Type]
           ,a.[APN_ID]
           ,a.[APN]
           ,a.[created]
           ,a.[updated]

  FROM pet.dbo.Pet_apn_additions a


DROP TABLE

IF EXISTS pet.pet_tmp.pet_addl_formatting_del_dup
	SELECT apn
		,count(1) AS cnt
	INTO pet.pet_tmp.pet_addl_formatting_del_dup
	FROM (
		SELECT DISTINCT REF_ID
			,APN
		FROM PET.dbo.Translate_fips f with(nolock,index(ixc_fips))
		INNER JOIN [PET].[dbo].[PET_APN] p WITH (
				NOLOCK
				,INDEX (ixb_fips_ref_id)
				) ON p.fips = f.TranslatedFips
		
	where f.Fips = ' + try_cast(@fips AS VARCHAR) + 
			'

) a
group by apn
having count(1) > 1


Delete p from [PET].[dbo].[PET_APN] p
inner join PET.dbo.Translate_fips f  with(nolock,index(ix_transFips))
                on f.translatedfips = p.fips
where f.Fips = ' + try_cast(@fips AS VARCHAR) + ' and  apn in (Select apn from pet.pet_tmp.pet_addl_formatting_del_dup)
and apn_type = ''' + @Apn_type + '''
' AS NVARCHAR(max))

	IF @list_Sql = 1
	BEGIN
		SELECT @sql_cmd
	END

	IF @list_Sql = 0
	BEGIN
		EXEC (@sql_cmd)
	END
			--IF @list_Sql = 0
			--BEGIN
			--        EXEC ntp.Stage.[AddNtpLog] N'info'
			--                ,N'[usp_PEt_Apn_Creation_2] end'
			--                ,@mess
			--END


	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'usp_PEt_Apn_Creation_2'
		,N'Ended'

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


