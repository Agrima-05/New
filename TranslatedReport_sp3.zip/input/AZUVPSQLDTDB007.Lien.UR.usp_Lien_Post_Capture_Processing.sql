/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Lien_Post_Capture_Processing | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================  
-- Author:  Marie Pretorius  
-- Create date: 2023-02-06  
-- Description: Update Standard Lender Names  
-- =============================================  
CREATE PROCEDURE [Lien].[UR].[usp_Lien_Post_Capture_Processing] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who    date			change  
we need to create a code table  
  
Marie 2023-09-19 Add Entries to Lien.dbo.LenderName_Cleanup_Research table (640608 - Update Lender Names)  
Marie 2024-07-02	Add call to Sp Lien.UR.usp_Match_Pending_Documents 
					- Legal Match to Obtain Ref_id's and improve Merge Deed to Mortgage Ration for BUG 737740
Marie 2024-08-28	Remove Land Use Code 127 from TimeShare Logic Bug 701042
Marie 2025/10/29	B31091 - Set M_status_id = 3 for Mineral Deeds
Marie 2026/05/11    B31427 - Set M_status_id = 3 where legal_desc_property_questionable_indicator = 'Y'
******************************************************************************************************************/
--declare @ERROR VARCHAR(500)   
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Lien_Post_Capture_Processing'
		,N'Started'

	-----select * from lien.[UR].[document_transaction_log_tracker]  
	--set @date = 2023-03-01 08:35:07.530  
	--condor updates
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Condor_Updates'
		,N'Started'

	--  
	--Find records part of todays lien Run  
	--  
	DROP TABLE

	IF EXISTS [lien].[tmp].[DocumentToChangeStatus]
		CREATE TABLE [lien].[tmp].[DocumentToChangeStatus] (
			[doc_id] [int] NOT NULL
			,[m_update_date] [datetime2](3) NULL
			,[fips_code] [varchar](200) NULL
			,[Fips] [int] NULL
			,[Instrument_nbr] [varchar](100) NULL
			,[recording_date_d] [date] NULL
			,[m_status_id] [tinyint] NOT NULL
			,[reprocess_flag] [char](1) NOT NULL
			,[ur_matrix] [varchar](200) NULL
			,[doc_type] [varchar](200) NULL
			)

	--  
	--find all the doc_id that had a change since the last update ran  
	--  
	INSERT INTO [lien].[tmp].[DocumentToChangeStatus] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,doc_type
		)
	SELECT d.doc_id
		,D.m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.doc_type
	FROM [lien].[tmp].[reprocess_records_to_be_processed] z WITH (INDEX (idx_update_type))
	INNER JOIN [Lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (NCIDX_DOCUMENT__doc_unique_id)
			) ON z.previous_doc_unique_id = d.doc_unique_id
	WHERE z.update_type IN ('U')
		AND isnull(d.m_status_id, 0) < 3
		AND isnull(z.m_status_id, 0) < 3
	OPTION (
		RECOMPILE
		,MAXDOP 8
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--select * from Lien.UR.Merge_ref_ids  
	--where fips_code = '48355'  
	--select m_status_id, format(count(*), '##,##0') as cnt from  lien.ur.Merge_ref_ids  
	--where fips_code = '48355'  
	--group by m_status_id  
	--select * from lien.tmp.DocumentToChangeStatus  
	CREATE INDEX idx ON [lien].[tmp].[DocumentToChangeStatus] (doc_id)

	CREATE INDEX id_matrix ON [lien].[tmp].[DocumentToChangeStatus] (ur_matrix) include (m_status_id)

	CREATE INDEX id_m_status ON [lien].[tmp].[DocumentToChangeStatus] (m_status_id) include (
		Instrument_nbr
		,reprocess_flag
		)

	CREATE INDEX idxa ON [lien].[tmp].[DocumentToChangeStatus] (
		fips_code
		,Instrument_nbr
		,recording_date_d
		) include (
		doc_id
		,reprocess_flag
		,m_status_id
		)

	--  
	-- declare @ERROR varchar(500)  
	EXEC [lien].[UR].[usp_Fix_processing] @m_status_id = 4
		,@ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	--  
	--  
	--  
	------set the original record comming in with the update_type = 'D' also to status = 3  
	----BEGIN TRANSACTION
	----UPDATE a
	----SET a.m_status_id = 3
	----	,a.m_update_date = getdate()
	----OUTPUT inserted.Doc_id
	----	,NULL AS Name_id
	----	,NULL AS property_id
	----	,NULL AS reference_id
	----	,inserted.m_update_date
	----	,'Orig CondorDelete Records - m_status_id = 3' AS Process_name
	----INTO lien.ur.document_transaction_log
	----FROM Lien.ur.document a WITH (
	----		NOLOCK
	----		,INDEX (PK_DOCUMENT)
	----		)
	----INNER JOIN lien.tmp.reprocess_records_to_be_processed d ON d.doc_id = a.doc_id
	----WHERE d.update_type IN ('U')
	------,'U'  
	----UPDATE a
	----SET a.m_status_id = 3
	----FROM lien.tmp.reprocess_records_to_be_processed a WITH (INDEX (idx_update_type))
	----WHERE a.update_type IN ('D')
	----OR a.doc_title LIKE '%mineral%'
	------,'U'  
	----COMMIT
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Condor_Updates'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Condor_deletes/Mineral Deeds'
		,N'Started'

	--  
	--Condor deletes  
	--  
	--  
	--Find records part of todays lien Run  
	--  
	-- declare @ERROR VARCHAR(500)
	DROP TABLE

	IF EXISTS [lien].[tmp].[DocumentToChangeStatus]
		CREATE TABLE [lien].[tmp].[DocumentToChangeStatus] (
			[doc_id] [int] NOT NULL
			,[m_update_date] [datetime2](3) NULL
			,[fips_code] [varchar](200) NULL
			,[Fips] [int] NULL
			,[Instrument_nbr] [varchar](100) NULL
			,[recording_date_d] [date] NULL
			,[m_status_id] [tinyint] NOT NULL
			,[reprocess_flag] [char](1) NOT NULL
			,[ur_matrix] [varchar](200) NULL
			,[doc_type] [varchar](200) NULL
			)

	--  
	--find all the doc_id that had a change since the last update ran  
	--  
	INSERT INTO [lien].[tmp].[DocumentToChangeStatus] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,doc_type
		)
	SELECT d.doc_id
		,D.m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.doc_type
	FROM [lien].[tmp].[reprocess_records_to_be_processed] z WITH (INDEX (idx_update_type))
	INNER JOIN [Lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (NCIDX_DOCUMENT__doc_unique_id)
			) ON z.previous_doc_unique_id = d.doc_unique_id
	WHERE z.update_type IN (
			'D'
			--,'U'  
			)
		OR d.doc_title LIKE '%mineral%'
		/*  
We need to decide if we want to limit the records to be deleted to smaller than 3  
Question - Should we allow when a record is marked as a duplicate, or 6, or 7,  that the use can delete that record  
*/
		AND isnull(d.m_status_id, 0) < 3
		AND isnull(z.m_status_id, 0) < 3
	OPTION (
		RECOMPILE
		,MAXDOP 8
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--select * from Lien.UR.Merge_ref_ids  
	--where fips_code = '48355'  
	--select m_status_id, format(count(*), '##,##0') as cnt from  lien.ur.Merge_ref_ids  
	--where fips_code = '48355'  
	--group by m_status_id  
	--select * from lien.tmp.DocumentToChangeStatus  
	CREATE INDEX idx ON [lien].[tmp].[DocumentToChangeStatus] (doc_id)

	CREATE INDEX id_matrix ON [lien].[tmp].[DocumentToChangeStatus] (ur_matrix) include (m_status_id)

	CREATE INDEX id_m_status ON [lien].[tmp].[DocumentToChangeStatus] (m_status_id) include (
		Instrument_nbr
		,reprocess_flag
		)

	CREATE INDEX idxa ON [lien].[tmp].[DocumentToChangeStatus] (
		fips_code
		,Instrument_nbr
		,recording_date_d
		) include (
		doc_id
		,reprocess_flag
		,m_status_id
		)

	--  
	-- declare @ERROR varchar(500)  
	EXEC [lien].[UR].[usp_Fix_processing] @m_status_id = 3
		,@ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	--  
	--  
	--  
	--set the original record comming in with the update_type = 'D' also to status = 3  
	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[a]
	SET a.m_status_id = 3
		,a.m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'Orig CondorDelete Records - m_status_id = 3' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[ur].[document] a WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] d ON d.doc_id = a.doc_id
	WHERE d.update_type IN ('D')
		OR d.doc_title LIKE '%mineral%'

	--,'U'  
	UPDATE [Lien].[UR].[a]
	SET a.m_status_id = 3
	FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (idx_update_type))
	WHERE a.update_type IN ('D')
		OR a.doc_title LIKE '%mineral%'

	--,'U'  
	COMMIT

	--  
	--end condor deletes  
	--  
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Condor_deletes/Mineral Deeds'
		,N'Ended'

	--end condor updates
	/*---------------------------------------------------
       legal_desc_property_questionable_indicator = 'Y'
     ----------------------------------------------------*/
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Questionable_Indicator'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien].[tmp].[DocumentToChangeStatus]
		CREATE TABLE [lien].[tmp].[DocumentToChangeStatus] (
			[doc_id] [int] NOT NULL
			,[m_update_date] [datetime2](3) NULL
			,[fips_code] [varchar](200) NULL
			,[Fips] [int] NULL
			,[Instrument_nbr] [varchar](100) NULL
			,[recording_date_d] [date] NULL
			,[m_status_id] [tinyint] NOT NULL
			,[reprocess_flag] [char](1) NOT NULL
			,[ur_matrix] [varchar](200) NULL
			,[doc_type] [varchar](200) NULL
			)

	--  
	--find all the doc_id that had a change since the last update ran  
	--  
	INSERT INTO [lien].[tmp].[DocumentToChangeStatus] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,doc_type
		)
	SELECT d.doc_id
		,D.m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.doc_type
	FROM [lien].[tmp].[reprocess_records_to_be_processed] z WITH (INDEX (idx))
	INNER JOIN [Lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			) ON z.doc_id = d.doc_id
	--INNER JOIN lien.UR.propertyheader p WITH (
	--		NOLOCK
	--		,INDEX (ix_doc_id)
	--		) ON p.doc_id = d.doc_id
	--WHERE p.legal_desc_property_questionable_indicator = 'Y'
	Where d.doc_questionable_indicator = 'Y'
		AND isnull(d.m_status_id, 0) < 3
		AND isnull(z.m_status_id, 0) < 3
		AND d.Recording_date_d >= '2025-11-01'
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	CREATE INDEX idx ON [lien].[tmp].[DocumentToChangeStatus] (doc_id)

	--  
	-- declare @ERROR varchar(500)  
	EXEC [lien].[UR].[usp_Fix_processing] @m_status_id = 3
		,@ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	--  
	-- set the original record comming in with the legal_desc_property_questionable_indicator = 'y' also to status = 3  
	--
	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[a]
	SET a.m_status_id = 3
		,a.m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'legal_desc_property_questionable_indicator - m_status_id = 3' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[ur].[document] a WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	INNER JOIN [lien].[UR].[propertyheader] p WITH (
			NOLOCK
			,INDEX (ix_doc_id)
			) ON p.doc_id = a.doc_id
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] d ON d.doc_id = a.doc_id
	WHERE p.legal_desc_property_questionable_indicator = 'Y'
		AND isnull(d.m_status_id, 0) < 3

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Questionable_Indicator'
		,N'Ended'

	/*-----------------------------------
   Lender Names
   ---------------------------------*/
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Lender_name_updates'
		,N'Started'

	--  
	--find all the doc_id that had a change since the last update ran  
	--  
	/*===============================  
   Lender Name Updates  
   ==============================*/
	BEGIN TRANSACTION

	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names]
		SELECT name_id
			,role_type
			,try_cast(substring(ltrim(isnull(Orig_mtg_lender_name, '')), 1, 200) AS VARCHAR(200)) AS Orig_mtg_lender_name
			,try_cast(substring(ltrim(isnull(Last_Company_name, '')), 1, 200) AS VARCHAR(200)) AS Last_Company_name
			,isnull(first_name, '') AS first_name
			,isnull(middle_name, '') AS middle_name
			,isnull(suffix, '') AS suffix
			,Name_Identifier
			,try_cast(NULL AS DATETIME2) AS m_update_date
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] d WITH (
				NOLOCK
				,INDEX (idx)
				)
		INNER JOIN [lien].[ur].[NAME] n WITH (INDEX (doc_id)) ON n.doc_id = d.doc_id
		WHERE n.role_type IN (
				SELECT CodeValue
				FROM [Lien].[dbo].[CodeTable]
				WHERE TableShortName = 'Lndr_Role_TP'
				)
			AND n.last_company_name <> 'NAME NOT AVAILABLE'
			AND isnull(n.last_company_name, '') > ''

	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Cleanup]
		SELECT ID
			,isnull(Name, '') AS [Name]
			,isnull(UniqueName, '') AS UniqueName
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Cleanup]
		FROM [Lien].[dbo].[Lender_cleanup] c
		WHERE c.TYPE NOT IN (
				'UNKNOWN'
				,'INDIVIDUAL'
				,'INVALID'
				,'OMVA;OD'
				)

	CREATE INDEX idx_name ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Cleanup] (Name) include (UniqueName)

	CREATE CLUSTERED INDEX idx_last_company_name ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names] (Last_Company_name)

	UPDATE [Lien].[UR].[n]
	SET n.Orig_mtg_lender_name = CASE 
			WHEN n.Orig_Mtg_Lender_Name = ''
				AND n.Last_Company_name > ''
				THEN REPLACE(n.Last_company_name + ' ' + n.first_name + ' ' + n.middle_name + ' ' + n.suffix, '  ', ' ')
			ELSE n.Orig_mtg_lender_name
			END
		,n.Last_Company_Name = CASE 
			WHEN n.Name_Identifier <> 'I'
				AND c.UniqueName > ''
				AND n.Last_company_name <> c.UniqueName
				THEN c.UniqueName
			ELSE n.Last_company_name
			END
		,M_Update_date = getdate()
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names] n WITH (
			NOLOCK
			,INDEX (idx_last_company_name)
			)
	LEFT JOIN [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Cleanup] c WITH (INDEX (idx_name)) ON c.NAME = n.last_company_name
	WHERE c.UniqueName > ''
		AND n.last_company_name <> c.UniqueName
	OPTION (
		RECOMPILE
		,MAXDOP 8
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	CREATE INDEX idx_name_id ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names] (name_id) include (
		m_update_date
		,role_type
		,Orig_mtg_lender_name
		,Last_Company_name
		,first_name
		,middle_name
		,suffix
		,Name_Identifier
		)

	UPDATE [Lien].[UR].[nm]
	SET nm.Orig_Mtg_Lender_Name = n.Orig_Mtg_Lender_Name
		,nm.Last_Company_name = n.Last_Company_name
	FROM [lien].[ur].[name] nm WITH (
			NOLOCK
			,INDEX (PK_NAME)
			)
	INNER JOIN [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lender_Names] n WITH (
			NOLOCK
			,INDEX (idx_name_id)
			) ON n.name_id = nm.name_id
	WHERE n.m_update_date IS NOT NULL

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Lender_name_updates'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'dedres_exclusions_status_7'
		,N'Started'

	--  
	-- Set M_status_id  = 7 -- DEDRES exclusions  
	--  
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_7]
		SELECT d.doc_id
			,d.doc_type
			,d.STATE
			,d.transfer_sale_purchase_price
			,d.transfer_tax
			,d.transfer_tax_state
			,d.transfer_tax_county
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_7]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (idx))
		INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
		WHERE NOT (
				d.doc_type <> 'DEDRES'
				OR (
					d.doc_type = 'DEDRES'
					AND d.STATE IN (
						'NJ'
						,'MI'
						)
					AND (
						d.transfer_sale_purchase_price IS NOT NULL
						OR d.transfer_tax IS NOT NULL
						OR d.transfer_tax_state IS NOT NULL
						OR d.transfer_tax_county IS NOT NULL
						)
					)
				)
			AND a.m_status_id NOT IN (
				7
				,3
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_7] (Doc_id)

	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 7
		,m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'Set DEDRES exclusions - 7' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_7] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id

	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 7
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_7] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] d WITH (
			NOLOCK
			,INDEX (idx)
			) ON d.doc_id = a.doc_id

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'dedres_exclusions_status_7'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Timeshares_status_6'
		,N'Started'

	--  
	-- Set M_status_id  = 6 -- Non dtdb UR_MAtrix  
	--  
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_6]
		SELECT d.doc_id
			,a.ur_matrix
			,a.m_status_id
			,p.timeshare_cnt
			,luse.luse_cnt
			,nm.resort_cnt
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_6]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (id_matrix))
		INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
		OUTER APPLY (
			SELECT count(1) AS luse_cnt
			FROM [lien].[ur].[Merge_ref_ids] k WITH (
					NOLOCK
					,INDEX (id_doc_id)
					)
			LEFT JOIN [assr].[dbo].[assr] ar WITH (
					NOLOCK
					,INDEX (IDX_Assr_Ref_ID)
					) ON ar.ref_id = k.ref_id
			WHERE k.doc_id = a.doc_id
				AND ar.Land_Use IN (
					167
					,199
					,130
					--,127  BUG701042 2024/08/28
					,725
					)
			) luse
		OUTER APPLY (
			SELECT count(1) AS resort_cnt
			FROM [lien].[ur].[name] n WITH (
					NOLOCK
					,INDEX (doc_id)
					)
			OUTER APPLY (
				SELECT try_cast(substring(n.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				) nn
			WHERE n.doc_id = a.doc_id
				AND nn.last_company_name LIKE '%resort %'
				--AND d.transfer_sale_purchase_price < '50000'
			) nm
		OUTER APPLY (
			SELECT count(1) AS timeshare_cnt
			FROM [lien].[ur].[property] p WITH (
					NOLOCK
					,INDEX (ix_Doc_idSeq)
					)
			WHERE p.doc_id = d.doc_id
				AND (
					legal_desc_timeshare_name IS NOT NULL
					OR legal_desc_timeshare_inventory_control_number IS NOT NULL
					OR legal_desc_timeshare_unit IS NOT NULL
					OR legal_desc_timeshare_week IS NOT NULL
					OR legal_desc_timeshare_season IS NOT NULL
					OR legal_desc_timeshare_type IS NOT NULL
					OR legal_desc_timeshare_map_plat_lot IS NOT NULL
					OR legal_desc_timeshare_map_plat_block IS NOT NULL
					OR legal_desc_timeshare_map_plat_id IS NOT NULL
					OR legal_desc_timeshare_map_plat_type_indicator IS NOT NULL
					OR legal_desc_timeshare_map_plat_book IS NOT NULL
					OR legal_desc_timeshare_map_plat_page IS NOT NULL
					OR legal_desc_timeshare_year_type IS NOT NULL
					OR legal_desc_timeshare_phase IS NOT NULL
					OR legal_desc_timeshare_map_plat_lot_high IS NOT NULL
					OR legal_desc_timeshare_unit_high IS NOT NULL
					OR legal_desc_timeshare_points IS NOT NULL
					)
			) p
		WHERE (
				NOT (
					a.ur_matrix IS NULL
					OR (
						--isnull(a.ur_matrix, '') = 'PR-FILL'  
						--OR isnull(a.ur_matrix, '') = 'PR-FULL'  
						--OR isnull(a.ur_matrix, '') = 'PRFULL'  
						--OR isnull(a.ur_matrix, '') = 'UR-FULL'  
						a.ur_matrix IN (
							SELECT codevalue
							FROM [lien].[dbo].[codetable] WITH (
									NOLOCK
									,INDEX (idx_Table_value)
									)
							WHERE TableShortName = 'UR_MATRIX'
							)
						)
					)
				OR timeshare_cnt > 0
				OR luse.luse_cnt > 0
				OR (
					nm.resort_cnt > 0
					AND d.transfer_sale_purchase_price < '50000'
					)
				)
			AND a.m_status_id NOT IN (
				6
				,3
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_6] (Doc_id)

	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 6
		,m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,aa.Process_name AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_6] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
	OUTER APPLY (
		SELECT 'Set Non dtdb UR_MAtrix 6 -  ' + CASE 
				WHEN a.ur_matrix NOT IN (
						SELECT codevalue
						FROM [lien].[dbo].[codetable]
						WHERE TableShortName = 'UR_MATRIX'
						)
					THEN 'ur_matrix'
				WHEN timeshare_cnt > 0
					THEN 'Set Non dtdb Timeshare 6'
				WHEN luse_cnt > 0
					THEN 'Timeshare land use'
				WHEN resort_cnt > 0
					THEN 'Resort '
				ELSE ''
				END AS Process_name
		) aa

	--WHERE timeshare_cnt = 0  
	--UPDATE d  
	--SET d.m_status_id = 6  
	-- ,m_update_date = getdate()  
	--OUTPUT inserted.Doc_id  
	-- ,NULL AS Name_id  
	-- ,NULL AS property_id  
	-- ,NULL AS reference_id  
	-- ,inserted.m_update_date  
	-- ,'Set Non dtdb Timeshare 6' AS Process_name  
	--INTO lien.ur.document_transaction_log  
	--FROM Lien.tmp.usp_Lien_Post_Capture_Processing_status_6 a WITH (INDEX (idx_doc_id))  
	--INNER JOIN lien.ur.document d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id  
	----WHERE timeshare_cnt > 0  
	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 6
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_status_6] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] d WITH (
			NOLOCK
			,INDEX (idx)
			) ON d.doc_id = a.doc_id

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Timeshares_status_6'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'R/W and BLA properties_status_6'
		,N'Started'

	--  
	-- Set M_status_id  = 6 -- R/W and BLA properties
	--  
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_RW_BLA]
		SELECT DISTINCT t.doc_id
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_RW_BLA]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] t WITH (
				NOLOCK
				,INDEX (idx)
				)
		CROSS APPLY (
			SELECT doc_id
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			WHERE d.doc_id = t.doc_id
				AND d.transfer_sale_purchase_price IS NULL
				AND d.transfer_tax IS NULL
				AND d.m_status_id = 1
			) d
		CROSS APPLY (
			SELECT doc_id
			FROM [lien].[ur].[name] n WITH (
					NOLOCK
					,INDEX (doc_id)
					)
			WHERE n.doc_id = d.doc_id
				AND n.role_type = 'Grantee'
				AND (
					n.last_company_name LIKE '%highway%'
					OR n.last_company_name LIKE '%transportation%'
					)
			) n
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_RW_BLA] (Doc_id)

	BEGIN TRANSACTION

	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 6
		,m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'R/W and BLA properties - 6' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_RW_BLA] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id

	UPDATE [Lien].[UR].[d]
	SET d.m_status_id = 6
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_RW_BLA] a WITH (INDEX (idx_doc_id))
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] d WITH (
			NOLOCK
			,INDEX (idx)
			) ON d.doc_id = a.doc_id

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'R/W and BLA properties_status_6'
		,N'Ended'

	-- NULL   6631111  
	--PR-FILL  335073 --  
	--PR-FULL  3190916 --  
	--PRFULL   780  
	--UR-EXTERNAL  222  
	--UR-FULL  52613782 --  
	--UR-LEGACY  2,381,051  
	--UR-LITE  13,962,343  
	--UR-SUPERLITE  76,910 @@  
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Redex_Assing_doc_seq_nbr'
		,N'Started'

	--  
	--identify the redx record moved for the day so that we can assign a recording_doc_sequence_number  
	--  
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_doc_seq_up]
		SELECT a.Doc_id
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_doc_seq_up]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (
				NOLOCK
				,INDEX (idx)
				)
		INNER JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.doc_id = a.doc_id
		WHERE d.source = 'redx'
			AND d.m_status_id < 3

	CREATE INDEX idx_doc_id ON [Lien].[tmp].[usp_Lien_Post_Capture_Processing_doc_seq_up] (doc_id)

	--  
	-- identify the multi records that need the recording_doc_sequence_number updates  
	--  
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_redx_multi_document_seq_nbr]
		CREATE TABLE [Lien].[tmp].[usp_Lien_Post_Capture_Processing_redx_multi_document_seq_nbr] (
			[fips_code] [varchar](200) NULL
			,[Instrument_nbr] [varchar](100) NULL
			,[Recording_Date_D] [date] NULL
			,[cmt_id] [int] NULL
			,[doc_type] [varchar](200) NULL
			,[m_create_date] [datetime2](3) NULL
			,[cnt] [int] NULL
			,[status_1_cnt] [int] NULL
			,[status_5_cnt] [int] NULL
			,[legal_desc_multi_apn_flag] [char](1) NULL
			,[legal_desc_multi_property_flag] [char](1) NULL
			)

	INSERT INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_redx_multi_document_seq_nbr] (
		[fips_code]
		,[Instrument_nbr]
		,[Recording_Date_D]
		,[cmt_id]
		,[doc_type]
		,[m_create_date]
		,[cnt]
		,[status_1_cnt]
		,[status_5_cnt]
		,[legal_desc_multi_apn_flag]
		,[legal_desc_multi_property_flag]
		)
	SELECT a.*
	FROM (
		SELECT fips_code
			,Instrument_nbr
			,isnull(Recording_Date_D, '1900-01-01') AS Recording_Date_D
			,isnull(cmt_id, 0) AS cmt_id
			,doc_type
			,m_create_date
			,sum(1) AS cnt
			,sum(CASE 
					WHEN m_status_id = 1
						THEN 1
					ELSE 0
					END) AS status_1_cnt
			,sum(CASE 
					WHEN m_status_id = 5
						THEN 1
					ELSE 0
					END) AS status_5_cnt
			,max(legal_desc_multi_apn_flag) AS legal_desc_multi_apn_flag
			,max(legal_desc_multi_property_flag) AS legal_desc_multi_property_flag
		-- , recording_doc_sequence_number  
		FROM [Lien].[Ur].[DOCUMENT] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				)
		INNER JOIN [Lien].[tmp].[usp_Lien_Post_Capture_Processing_doc_seq_up] b WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				) ON b.doc_id = d.doc_id
		OUTER APPLY (
			SELECT count(1) AS cnt
			FROM [lien].[ur].[property] p WITH (
					NOLOCK
					,INDEX (ix_Doc_idSeq)
					)
			WHERE p.doc_id = d.doc_id
			) p
		WHERE /*d.m_status_id < 3  
  and*/ p.cnt > 0
			AND Instrument_nbr <> 'none'
		GROUP BY fips_code
			,Instrument_nbr
			,isnull(Recording_Date_D, '1900-01-01')
			,isnull(cmt_id, 0)
			,doc_type
			,m_create_date
		) a
	WHERE a.cnt > 1
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--select  * from Lien.tmp.usp_Lien_Post_Capture_Processing_redx_multi_document_seq_nbr -- this file countaint the goruping that needs to be sequenced  
	--  
	--FIND THE DOC_IDS FOR THE MULTIS AND DETEREMINE THE recording_doc_sequence_number VALUE  
	--  
	DROP TABLE

	IF EXISTS [lien].[redx].[redx_multiseq_tracker]
		SELECT d.doc_id
			,d.recording_doc_sequence_number
			--,right('000' + try_cast(ROW4 AS VARCHAR), 4) AS _seq
			,ROW4 AS _seq
			,d.fips_code
			,d.instrument_nbr
			,d.m_create_date
		INTO [lien].[redx].[redx_multiseq_tracker]
		FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_redx_multi_document_seq_nbr] a
		OUTER APPLY (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY 0 ORDER BY (
							SELECT 0
							)
					) AS ROW4
				,d.doc_id
				,d.recording_doc_sequence_number
				,d.fips_code
				,d.instrument_nbr
				,d.m_create_date
			FROM [lien].[ur].[document] d
			WHERE d.fips_code = a.fips_code
				AND d.instrument_nbr = a.instrument_nbr
				AND d.m_create_date = a.m_create_date
				AND d.doc_type = a.doc_type
			) d

	CREATE CLUSTERED INDEX idx_doc_id ON [lien].[redx].[redx_multiseq_tracker] (doc_id)

	--select * from lien.redx.redx_multiseq_tracker order by fips_code, instrument_nbr  
	--  
	-- Update the lien.ur.document table with the recording_doc_sequence_number and the status =  1  
	--  
	UPDATE [Lien].[UR].[a]
	SET a.m_update_date = getdate()
		--,a.m_status_id = 1
		,a.recording_doc_sequence_number = b._seq
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'Set Recording Doc Sequence Number for REDX records ' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [Lien].[ur].[document] a WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	INNER JOIN [lien].[redx].[redx_multiseq_tracker] b WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			) ON b.doc_id = a.doc_id

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Redex_Assing_doc_seq_nbr'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Duplicate_status_5'
		,N'Started'

	--  
	-- Set M_status_id  = 5 -- duplicate document  
	--  
	TRUNCATE TABLE [lien].[tmp].[DocumentToChangeStatus]

	INSERT INTO [lien].[tmp].[DocumentToChangeStatus] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,doc_type
		)
	SELECT e.[doc_id]
		,e.[m_update_date]
		,e.[fips_code]
		,try_cast(e.Fips_code AS INT) AS Fips
		,e.[Instrument_nbr]
		,e.[recording_date_d]
		,e.[m_status_id]
		,e.[reprocess_flag]
		,e.[ur_matrix]
		,e.doc_type
	--INTO Lien.tmp.usp_Lien_Post_Capture_Processing_status_5
	FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (id_m_status))
	INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
	CROSS APPLY (
		SELECT *
		FROM [ASSR].[dbo].[Translate_Fips] t WITH (
				NOLOCK
				,INDEX (ixc_fips)
				)
		WHERE t.fips = a.fips
		) t
	OUTER APPLY (
		SELECT e.[doc_id]
		,e.[m_update_date]
	
		,e.Fips_code 
		,e.[Instrument_nbr]
		,e.[recording_date_d]
		,e.[m_status_id]
		,'' as [reprocess_flag]
		,e.[ur_matrix]
		,e.doc_type
		FROM [lien].[ur].[document] e WITH (INDEX (idx_fips_inst_rcdt_cmt_dt_seq))
		WHERE e.fips_code = t.TranslatedFips_a --d.fips_code
			AND e.Instrument_nbr = d.Instrument_nbr --in (d.cmt_docnumber,D.Fmt_Doc_Number,D.FMT_Book_Page)  
			--AND e.recording_date_d = d.recording_date_d
			AND isnull(e.cmt_id, '') = isnull(d.cmt_id, '')
			--AND e.doc_type = d.doc_type
			AND isnull(e.recording_doc_sequence_number, '') = isnull(d.recording_doc_sequence_number, '')
			AND e.doc_id < d.doc_id
			AND ISNULL(e.reprocess_flag, '') = ''
			AND e.m_status_id < 3
		) e
	WHERE e.doc_id IS NOT NULL
		AND a.m_status_id < 3
		AND a.Instrument_nbr <> 'none'
		AND ISNULL(a.reprocess_flag, '') = ''
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [lien].[UR].[usp_Fix_processing] @m_status_id = 5
		,@ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	------select * from  lien.tmp.reprocess_records_to_be_processed 
	------select * from Lien.tmp.usp_Lien_Post_Capture_Processing_status_5
	----CREATE INDEX idx_doc_id ON Lien.tmp.usp_Lien_Post_Capture_Processing_status_5 (Doc_id)

	----BEGIN TRANSACTION

	----UPDATE d
	----SET d.m_status_id = 5
	----	,m_update_date = getdate()
	----OUTPUT inserted.Doc_id
	----	,NULL AS Name_id
	----	,NULL AS property_id
	----	,NULL AS reference_id
	----	,inserted.m_update_date
	----	,'Set Duplicate Status 5' AS Process_name
	----INTO lien.ur.document_transaction_log
	----FROM Lien.tmp.usp_Lien_Post_Capture_Processing_status_5 a WITH (INDEX (idx_doc_id))
	----INNER JOIN lien.ur.document d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id

	----UPDATE d
	----SET d.m_status_id = 5
	----FROM Lien.tmp.usp_Lien_Post_Capture_Processing_status_5 a WITH (INDEX (idx_doc_id))
	----INNER JOIN lien.tmp.reprocess_records_to_be_processed d ON d.doc_id = a.doc_id

	--  
	-- rider_balloon_payment_flag setting  
	--  

	Begin Transaction
	UPDATE [Lien].[UR].[d]
	SET d.rider_balloon_payment_flag = 'Y'
		,d.m_update_date = getdate()
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'Set rider_balloon_payment_flag' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (id_matrix))
	INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
	WHERE d.doc_title LIKE '%balloon%'
		AND d.rider_balloon_payment_flag IS NULL
		AND d.doc_type IN (
			SELECT CodeValue
			FROM [Lien].[dbo].[CodeTable]
			WHERE TableShortName = 'BALLOONRIDER'
			)

	--AND a.ur_matrix = 'ur-full'  
	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Duplicate_status_5'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Lender_name_updates'
		,N'Started'

	/*============================================================  
   Lender Name Research Table 640608 - Update Lender Names  
   ===========================================================*/
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lndr]
		SELECT DISTINCT a.*
		INTO [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lndr]
		FROM (
			SELECT Substring(n.last_company_name, 1, 255) AS Name
				,m1.UniqueName
				,CAST(NULL AS INT) AS [Counter]
				,CAST(NULL AS VARCHAR(255)) AS [Type]
				--,CASE   
				-- WHEN n.name_identifier = 'C' THEN 'COMPANY'  
				-- WHEN n.name_identifier = 'I' THEN 'INDIVIDUAL'  
				-- WHEN n.name_identifier = 'T' THEN 'TRUST'  
				-- ELSE 'UNKNOWN'  
				-- END AS [Type]  
				,CAST(GETDATE() AS DATETIME2(2)) AS Update_Date
			FROM [lien].[tmp].[reprocess_records_to_be_processed] p WITH (
					NOLOCK
					,INDEX (idx)
					)
			INNER JOIN [lien].[ur].[name] n WITH (
					NOLOCK
					,INDEX (doc_id)
					) ON n.doc_id = p.doc_id
			OUTER APPLY (
				SELECT TOP 1 UniqueName
				FROM [Lien].[dbo].[Lender_Cleanup] WITH (
						NOLOCK
						,INDEX (idx_uniqueName)
						)
				WHERE UniqueName = n.last_company_name
				) m1
			LEFT JOIN [Lien].[dbo].[Lender_Cleanup] c WITH (
					NOLOCK
					,INDEX (idx_name)
					) ON c.name = n.last_company_name
			WHERE n.role_type IN (
					SELECT CodeValue
					FROM [Lien].[dbo].[CodeTable] WITH (
							NOLOCK
							,INDEX (idxu_codeTableValueFips)
							)
					WHERE TableShortName = 'LenderRoleTypes'
					)
				AND c.Name IS NULL
				AND ISNULL(n.last_company_name, '') <> ''
				AND NOT EXISTS (
					SELECT Name
					FROM [Lien].[dbo].[LenderName_Cleanup_Research] r WITH (
							NOLOCK
							,INDEX (idx_Name)
							)
					WHERE r.Name = n.last_company_name
					)
			) a
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--SELECT *  
	--FROM Lien.tmp.usp_Lien_Post_Capture_Processing_Lndr  
	--ORDER BY name  
	INSERT INTO [Lien].[dbo].[LenderName_Cleanup_Research] (
		[Name]
		,[UniqueName]
		,[Counter]
		,[Type]
		,[Update_Date]
		)
	SELECT [Name]
		,[UniqueName]
		,[Counter]
		,[Type]
		,[Update_Date]
	FROM [Lien].[tmp].[usp_Lien_Post_Capture_Processing_Lndr] l

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Lender_name_updates'
		,N'Ended'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Create_Merge_ref_idsrecords '
		,N'Started'

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Create_Merge_ref_idsrecords '
		,N'Ended'

	--  
	-- create Merge_ref_idsrecords  
	--  
	BEGIN TRANSACTION

	DELETE a
	FROM [lien].[ur].[Merge_ref_ids] a WITH (
			NOLOCK
			,INDEX (id_doc_id)
			)
	INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] b ON b.doc_id = a.doc_id

	INSERT INTO [lien].[ur].[Merge_ref_ids] (
		doc_id
		,ur_matrix
		,m_status_id
		,fips_code
		,recording_date_d
		,doc_type
		,ref_id
		,property_id_sequence_number
		,reprocess_flag
		,Instrument_nbr
		)
	SELECT l.doc_id
		,l.ur_matrix
		,l.m_status_id
		,l.fips_code
		,l.recording_date_d
		,l.doc_type
		,l.ref_id
		,l.property_id_sequence_number
		,l.reprocess_flag
		,l.Instrument_nbr
	FROM (
		SELECT k.*
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id
				,ref_id ORDER BY _from
				) AS ROW4
		FROM (
			SELECT d.doc_id
				,d.ur_matrix
				,d.m_status_id
				,d.fips_code
				,d.recording_date_d
				,d.doc_type
				,ph.ref_id AS ref_id
				,ph.property_id_sequence_number
				,d.reprocess_flag
				,d.Instrument_nbr
				,'ph' AS _from
			FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (idx))
			INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
			OUTER APPLY (
				SELECT r.ref_id
					,ph.property_id_sequence_number
				FROM [lien].[ur].[propertyheader] ph WITH (INDEX (ix_doc_id))
				OUTER APPLY (
					SELECT coalesce(ph.pa_ref_id, ph.ps_ref_id, ph.pl_ref_id) AS ref_id
					) r
				WHERE ph.doc_id = d.doc_id
				) ph
			--WHERE a.doc_id = 222242656 --222205506  
			
			UNION ALL
			
			SELECT d.doc_id
				,d.ur_matrix
				,d.m_status_id
				,d.fips_code
				,d.recording_date_d
				,d.doc_type
				,rm.nova_ref_id AS ref_id
				,0 AS property_id_sequence_number
				,d.reprocess_flag
				,d.Instrument_nbr
				,'rm' AS _from
			FROM [lien].[tmp].[reprocess_records_to_be_processed] a WITH (INDEX (id_m_status))
			INNER JOIN [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT)) ON d.doc_id = a.doc_id
			OUTER APPLY (
				SELECT nova_ref_id
				FROM [lien].[ur].[REFERENCE_Match] rm WITH (
						NOLOCK
						,INDEX (id_doc_id)
						)
				WHERE rm.doc_id = d.doc_id
				) rm
				--WHERE a.doc_id = 222242656 --222205506  
			) k
		) l
	WHERE row4 = 1
		AND NOT (
			ref_id IS NULL
			AND property_id_sequence_number = 0
			)
	ORDER BY property_id_sequence_number
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Create_Merge_ref_idsrecords '
		,N'Ended'

	--  
	--  
	--  
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Lien_Post_Capture_Processing'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
		--ROLLBACK
END CATCH


