/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | LEAP.usp_UR_NameParse | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name> 
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[LEAP].[usp_UR_NameParse] @Created_Date DATETIME = NULL --'2017-12-04 04:44:11.000'
AS
BEGIN
	--use Lien rollback '20180228 08:00:15.000', '20180308 22:22:09.000'
	--DECLARE @Created_Date DATETIME = '2017-12-04 04:44:11.000'
	/*
[‎6/‎22/‎2018 10:58 AM]  
Hi - Last question - if I know I concat last name first when I create the name1 column, what should I enter in the NameFormatType
 
[‎6/‎22/‎2018 10:59 AM]  Smith, Michael A.:  
2 for Last name, First Name
 
[‎6/‎22/‎2018 11:00 AM]  
thanks
 
[‎6/‎22/‎2018 11:00 AM]  Smith, Michael A.:  
just fyi, here is what its based on:
AssesseeNameId	CodeDesc
1	First Name Middle Initial Last Name, single source
2	Last Name, First Name Middle Initials single source
3	Last name, first name middle initial, multiple source
4	No pattern to names 
 
[‎6/‎22/‎2018 11:01 AM]  
so if I dont know which it is I should enter 4 ?
 
[‎6/‎22/‎2018 11:01 AM]  Smith, Michael A.:  
yes then it will try to determine the order by the name tokens
 
[‎6/‎22/‎2018 11:02 AM]  
thanks
 

*/
	/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	2022-0718	Make NAme Identifier C when name = 'NAME NOT AVAILABLE' and Name Identifier null for REDX counties
******************************************************************************************************************/
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'UR_NameParse for Leap'
		,N'Started'

	--DECLARE @date_from DATE = dateadd(day, - 2, getdate())
	--DECLARE @date_from DATE = getdate()

	--SELECT @date_from AS N'@date_from'

	DECLARE @m_create_date DATETIME2

	SET @m_create_date = dateadd(hour, - 1, (
				SELECT TOP 1 m_create_date
				FROM [lien].[ur].[document] d WITH (
						NOLOCK
						,INDEX (IX_CREATED_DATE)
						)
				ORDER BY m_create_date DESC
				))

	SELECT @m_create_date

	DROP TABLE

	IF EXISTS #doc_id
		SELECT doc_id
		INTO #doc_id
		FROM [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (IX_CREATED_DATE)
				)
		WHERE d.m_create_date > @m_create_date

	--declare @fips int = 6001
	TRUNCATE TABLE [Lien].[dbo].[NameWork_V5]

	INSERT INTO [Lien].[dbo].[NameWork_V5] (
		[ID]
		,[Fips]
		,NameFormatType
		,[Name2FormatType]
		,[NameIDCode]
		,[Name1]
		,[Name2]
		)
	SELECT n.Name_Id AS [ID]
		,d.fips_code AS [Fips]
		,'2' AS [NameFormatType]
		,NULL AS [Name2FormatType]
		,NULL AS [NameIDCode]
		,a._name AS [Name1]
		,NULL AS [Name2]
	FROM [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT))
	INNER JOIN [Lien].[UR].[NAME] n WITH (INDEX (doc_id)) ON d.doc_id = n.doc_id
	LEFT JOIN [Lien].[UR].[Name_Parsed] p WITH (INDEX (PK_Name_Parsed)) ON p.name_id = n.Name_id
	OUTER APPLY (
		SELECT substring(isnull(ltrim(rtrim(n.Last_company_name)), '') + ' ' + isnull(ltrim(rtrim(n.first_name)), '') + ' ' + isnull(ltrim(rtrim(n.middle_name)), ''), 1, 100) AS _name
		) a
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM #doc_id
			)
		--d.m_create_date > @date_from /*d.fips_code = '13059'
		AND a._name > ''
		AND p.name_id IS NULL
		AND n.last_company_name NOT IN (
			'UNKNOWN'
			,'Available Name Not'
			,'NAME NOT AVAILABLE'
			)
	OPTION (
		RECOMPILE
		,MAXDOP 16
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [Lien].[LEAP].[n]
	SET n.name_identifier = 'C'
		,n.m_update_date = getdate()
	OUTPUT NULL AS Doc_id
		,inserted.Name_id AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'usp_UR_NameParse_5' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[ur].[document] d WITH (INDEX (PK_DOCUMENT))
	INNER JOIN [Lien].[UR].[NAME] n ON d.doc_id = n.doc_id
	LEFT JOIN [Lien].[UR].[Name_Parsed] p ON p.name_id = n.Name_id
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM #doc_id
			)
		--d.doc_id = 173909729 and 
		--d.m_create_date > @date_from
		AND n.last_company_name IN (
			'UNKNOWN'
			,'Available Name Not'
			,'NAME NOT AVAILABLE'
			)
	OPTION (
		RECOMPILE
		,MAXDOP 10
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--and source <> 'EPR'
	--and d.fips_code = @fips
	--and d.doc_id = 31875456
	--select d.doc_id, count(1) as cnt
	--	FROM lien.ur.document d 
	--LEFT JOIN [Lien].[UR].[NAME] n
	--	ON d.doc_id = n.doc_id
	--left join Lien.UR.Name_Parsed p on p.name_id = n.Name_id
	--OUTER APPLY (
	--	SELECT ltrim(rtrim(substring(isnull(n.Last_company_name, '') + ' ' + isnull(n.first_name, '') + ' ' + isnull(n.middle_name, ''), 1, 100))) AS _name
	--	) a
	--WHERE a._name > '' and p.name_id is null
	--and d.fips_code = 06001
	--group  by d.doc_id
	--order by cnt desc
	/*
		select fips_code, count(1) as cnt from lien.ur.document 
		group by fips_code
		order by fips_code


				SELECT [TAX_ASS_REC_ID]
			,fips
			,[AssesseeNameIndicator]
			,AssesseeNameIndicator2
			,AssesseeVestingIDCode
			,[AssesseeName]
			,[AssesseeName2]
		FROM adb..MD_AssessmentWrk
		WHERE countyfips IN (
				SELECT FIPS
				FROM adb..fips_42
		)

*/
	DECLARE @return_value INT

	EXEC @return_value = [dbo].[usp_remove_Extra_Ascii_from_sl_table] @table = N'NameWork_V5'
		,@startColumn = N'Name1'

	IF @return_value <> 0
	BEGIN
		RAISERROR (
				'Error raised in [usp_remove_Extra_Ascii_from_sl_table]'
				,16
				,1
				);
	END

	--  DECLARE @return_value INT
	EXEC @return_value = [Lien].[dbo].[usp_name_parser_unifiedV5] @tableName = N'NameWork_V5'

	IF @return_value <> 0
	BEGIN
		RAISERROR (
				'Error raised in [usp_name_parser_unifiedV5]'
				,16
				,1
				);
	END

	DECLARE @sucess BIT = 0

	BEGIN TRANSACTION

	--TRUNCATE TABLE [Lien].[UR].[Name_Parsed]
	INSERT INTO [Lien].[UR].[Name_Parsed] (
		[Name_id]
		,[Fips]
		,[Raw_name]
		,[NameFormatType]
		,[Name2FormatType]
		,[NameIDCode]
		,[Name1]
		,[COName]
		,[Name1CorpInd]
		,[Name2CorpInd]
		,[Name1TrustInd]
		,[Name2TrustInd]
		,[Name1Work]
		,[Name1First]
		,[Name1Middle]
		,[Name1Last]
		,[Name1Generation]
		,[Name2Work]
		,[Name2First]
		,[Name2Middle]
		,[Name2Last]
		,[Name2Generation]
		,[Name1fmt]
		,[Name2fmt]
		,[AdditionalName]
		,[ParsedTokenName1]
		,[ParsedTokenName2]
		,[OwnerRelationship]
		,[OwnerRights]
		,[OwnerEtalInd]
		,[Name1Percent]
		,[Name2Percent]
		,[Name1TokenFirst]
		,[Name1TokenLast]
		,[Name1Token1SurnameInd]
		,[Name1Token1SurnameProbabilty]
		,[Name1Token2SurnameInd]
		,[Name1Token2SurnameProbabilty]
		,[Name2TokenFirst]
		,[Name2TokenLast]
		,[Name2Token1SurnameInd]
		,[Name2Token1SurnameProbabilty]
		,[Name2Token2SurnameInd]
		,[Name2Token2SurnameProbabilty]
		,[N1]
		,[N1_Prob]
		,[N2]
		,[N2_Prob]
		,[N3]
		,[N3_Prob]
		,[N4]
		,[N4_Prob]
		,[N5]
		,[N5_Prob]
		,[N6]
		,[N6_Prob]
		,[N7]
		,[N7_Prob]
		,[N8]
		,[N8_Prob]
		,[N9]
		,[N9_Prob]
		,[N10]
		,[N10_Prob]
		,[N11]
		,[N11_Prob]
		,[N12]
		,[N12_Prob]
		,[Name1FirstProb]
		,[Name1MiddleProb]
		,[Name1LastProb]
		,[Name2FirstProb]
		,[Name2MiddleProb]
		,[Name2LastProb]
		,[NameRealtionship]
		,[m_create_date]
		,[m_update_date]
		)
	OUTPUT NULL AS Doc_id
		,inserted.Name_id AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_create_date
		,'usp_UR_NameParse_1' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	SELECT [ID]
		,[Fips]
		,[Name1] AS Raw_Name
		,[NameFormatType]
		,[Name2FormatType]
		,[NameIDCode]
		,[Name1]
		--,[Name2]
		,[COName]
		,[Name1CorpInd]
		,[Name2CorpInd]
		,[Name1TrustInd]
		,[Name2TrustInd]
		,[Name1Work]
		,[Name1First]
		,[Name1Middle]
		,[Name1Last]
		,[Name1Generation]
		,[Name2Work]
		,[Name2First]
		,[Name2Middle]
		,[Name2Last]
		,[Name2Generation]
		,[Name1fmt]
		,[Name2fmt]
		,[AdditionalName]
		,[ParsedTokenName1]
		,[ParsedTokenName2]
		,[OwnerRelationship]
		,[OwnerRights]
		,[OwnerEtalInd]
		,[Name1Percent]
		,[Name2Percent]
		,[Name1TokenFirst]
		,[Name1TokenLast]
		,[Name1Token1SurnameInd]
		,[Name1Token1SurnameProbabilty]
		,[Name1Token2SurnameInd]
		,[Name1Token2SurnameProbabilty]
		,[Name2TokenFirst]
		,[Name2TokenLast]
		,[Name2Token1SurnameInd]
		,[Name2Token1SurnameProbabilty]
		,[Name2Token2SurnameInd]
		,[Name2Token2SurnameProbabilty]
		,[N1]
		,[N1_Prob]
		,[N2]
		,[N2_Prob]
		,[N3]
		,[N3_Prob]
		,[N4]
		,[N4_Prob]
		,[N5]
		,[N5_Prob]
		,[N6]
		,[N6_Prob]
		,[N7]
		,[N7_Prob]
		,[N8]
		,[N8_Prob]
		,[N9]
		,[N9_Prob]
		,[N10]
		,[N10_Prob]
		,[N11]
		,[N11_Prob]
		,[N12]
		,[N12_Prob]
		,[Name1FirstProb]
		,[Name1MiddleProb]
		,[Name1LastProb]
		,[Name2FirstProb]
		,[Name2MiddleProb]
		,[Name2LastProb]
		,[NameRealtionship]
		,Getdate() AS [m_create_date]
		,getdate() AS [m_update_date]
	FROM [Lien].[dbo].[NameWork_v5] n(NOLOCK)

	UPDATE [Lien].[LEAP].[n]
	SET n.name_identifier = ni.name_identifier
		,n.m_update_date = getdate()
	OUTPUT NULL AS Doc_id
		,inserted.Name_id AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'usp_UR_NameParse_2' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[ur].[NAME] n
	INNER JOIN [Lien].[dbo].[NameWork_v5] d ON d.id = n.name_id
	OUTER APPLY (
		SELECT CASE 
				WHEN Name1TrustInd IS NOT NULL
					THEN 'T'
				WHEN Name1CorpInd IS NOT NULL
					THEN 'C'
				ELSE 'I'
				END AS name_identifier
		) ni
	WHERE n.name_identifier IS NULL

	--select * from [Lien].ur.name where name_id = 268547506
	--select * from [Lien].[dbo].[NameWork_v5] where id = 268547506
	--where [Name1] is not null
	/*  select * from [Lien].[UR].[Name_Parsed]


  select * FROM [Lien].[dbo].[NameWork] (nolock)
  where Name1Last is not null*/
	COMMIT

	--spanner begin
	DROP TABLE

	IF EXISTS #Temp
		SELECT -- n.name_id , n.doc_id ,n.last_company_name
			d.fips_code
			,nn.*
		INTO #temp
		FROM [Lien].[dbo].[NameWork_v5] a(NOLOCK)
		LEFT JOIN [lien].[ur].[NAME] n ON n.Name_id = a.id
		LEFT JOIN [lien].[ur].[document] d ON d.doc_id = n.doc_id
		OUTER APPLY (
			SELECT 1 AS Name_seq
				,n.[Name_id]
				,n.[doc_id]
				,n.[doc_unique_id]
				,n.[sequence_number]
				,n.[name_identifier]
				,n.[name_code]
				,a.Name1Last AS last_company_name
				,a.Name1First AS first_name
				,a.Name1Middle AS middle_name
				,a.Name1Generation AS suffix
				,n.[relate_to_name_id]
				,n.[party_type_code]
				,n.[relationship_code]
				,n.[vesting_code]
				,n.[percent_transferred]
				,n.[taxpayer_id_ssn_fein]
				,n.[spousal_information_flag]
				,n.[address_same_as_property_address_flag]
				,n.[address]
				,n.[address_city_name]
				,n.[address_state_name]
				,n.[address_zip_code]
				,n.[phone_number]
				,n.[email_website]
				,n.[foreign_address]
				,n.[foreign_address_country]
				,n.[questionable_indicator]
				,n.[role_blob]
				,n.[role_type]
				,n.[batch]
				,n.[bucket]
				,n.[Leap_Foreign_Addr_Part3]
				,n.[Leap_Party1_Account_Nbr]
				,n.[Leap_Party1_SSN_Nbr]
				,n.[Leap_Party1_Driver_License_Nbr]
				,n.[Leap_Party1_Driver_License_State]
				,n.[Leap_Party1_Date_Of_Birth]
				,n.[contact_name]
				,n.[m_create_date]
				,n.[m_update_date]
				,n.[name_sequence_id]
				,n.[birth_year]
			
			UNION ALL
			
			SELECT 2 AS Name_seq
				,n.[Name_id]
				,n.[doc_id]
				,n.[doc_unique_id]
				,n.[sequence_number] + 1 AS [sequence_number]
				,n.[name_identifier]
				,n.[name_code]
				,a.Name2Last AS last_company_name
				,a.Name2First AS first_name
				,a.Name2Middle AS middle_name
				,a.Name2Generation AS suffix
				,n.[relate_to_name_id]
				,n.[party_type_code]
				,n.[relationship_code]
				,n.[vesting_code]
				,n.[percent_transferred]
				,n.[taxpayer_id_ssn_fein]
				,n.[spousal_information_flag]
				,n.[address_same_as_property_address_flag]
				,n.[address]
				,n.[address_city_name]
				,n.[address_state_name]
				,n.[address_zip_code]
				,n.[phone_number]
				,n.[email_website]
				,n.[foreign_address]
				,n.[foreign_address_country]
				,n.[questionable_indicator]
				,n.[role_blob]
				,n.[role_type]
				,n.[batch]
				,n.[bucket]
				,n.[Leap_Foreign_Addr_Part3]
				,n.[Leap_Party1_Account_Nbr]
				,n.[Leap_Party1_SSN_Nbr]
				,n.[Leap_Party1_Driver_License_Nbr]
				,n.[Leap_Party1_Driver_License_State]
				,n.[Leap_Party1_Date_Of_Birth]
				,n.[contact_name]
				,n.[m_create_date]
				,n.[m_update_date]
				,n.[name_sequence_id]
				,n.[birth_year]
			) nn
		WHERE d.source = 'REDX'
			AND (
				n.last_company_name LIKE ('%&%')
				OR n.last_company_name LIKE ('% and%')
				OR (
					n.name_identifier = 'I'
					AND n.last_company_name IS NOT NULL
					AND n.first_name IS NULL
					)
				)
			AND nn.last_company_name IS NOT NULL

	CREATE INDEX ixa ON #temp (name_id)

	CREATE INDEX ixb ON #temp (sequence_number)

	BEGIN TRANSACTION

	--select * from #temp where doc_id = 127713951
	UPDATE [Lien].[LEAP].[a]
	SET a.last_company_name = t.last_company_name
		,a.first_name = t.first_name
		,a.middle_name = t.middle_name
		,a.suffix = t.suffix
		,a.m_update_date = getdate()
	OUTPUT NULL AS Doc_id
		,inserted.Name_id AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_update_date
		,'usp_UR_NameParse_3' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[ur].[NAME] a
	INNER JOIN #temp t ON t.name_id = a.Name_id
	WHERE t.name_seq = 1
		AND t.sequence_number = a.sequence_number

	DROP TABLE

	IF EXISTS #name_seq
		SELECT a.doc_id
			,a.role_type
			,max(sequence_number) AS Max_sequence_number
		INTO #name_seq
		FROM (
			SELECT a.doc_id
				,a.name_id
				,a.sequence_number
				,try_cast(role_type AS VARCHAR(50)) AS role_type
			FROM [lien].[ur].[NAME] a
			WHERE doc_id IN (
					SELECT DISTINCT doc_id
					FROM [lien].[ur].[NAME] a
					WHERE a.NAme_id IN (
							SELECT id
							FROM [Lien].[dbo].[NameWork_v5]
							)
					)
			) a
		GROUP BY a.doc_id
			,role_type

	CREATE INDEX ixb ON #name_seq (
		doc_id
		,role_type
		)

	--select * from #name_seq where doc_id = 127713951
	--select n.* ,a.*  from [Lien].[dbo].[NameWork_v5] a
	--left join lien.ur.name n on n.name_id = a.id
	-- select  * from #name_seq where doc_id = 127713454
	--order by doc_id
	INSERT INTO [Lien].[UR].[NAME] (
		[doc_id]
		,[doc_unique_id]
		,[sequence_number]
		,[name_identifier]
		,[name_code]
		,[last_company_name]
		,[first_name]
		,[middle_name]
		,[suffix]
		,[relate_to_name_id]
		,[party_type_code]
		,[relationship_code]
		,[vesting_code]
		,[percent_transferred]
		,[taxpayer_id_ssn_fein]
		,[spousal_information_flag]
		,[address_same_as_property_address_flag]
		,[address]
		,[address_city_name]
		,[address_state_name]
		,[address_zip_code]
		,[phone_number]
		,[email_website]
		,[foreign_address]
		,[foreign_address_country]
		,[questionable_indicator]
		,[role_blob]
		,[role_type]
		,[batch]
		,[bucket]
		,[Leap_Foreign_Addr_Part3]
		,[Leap_Party1_Account_Nbr]
		,[Leap_Party1_SSN_Nbr]
		,[Leap_Party1_Driver_License_Nbr]
		,[Leap_Party1_Driver_License_State]
		,[Leap_Party1_Date_Of_Birth]
		,[contact_name]
		,[m_create_date]
		,[m_update_date]
		,[name_sequence_id]
		,[birth_year]
		)
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_create_date
		,'usp_UR_NameParse_4' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	SELECT t.[doc_id]
		,t.[doc_unique_id]
		,n.Max_sequence_number + 1 AS [sequence_number]
		,t.[name_identifier]
		,t.[name_code]
		,t.[last_company_name]
		,t.[first_name]
		,t.[middle_name]
		,t.[suffix]
		,t.[relate_to_name_id]
		,t.[party_type_code]
		,t.[relationship_code]
		,t.[vesting_code]
		,t.[percent_transferred]
		,t.[taxpayer_id_ssn_fein]
		,t.[spousal_information_flag]
		,t.[address_same_as_property_address_flag]
		,t.[address]
		,t.[address_city_name]
		,t.[address_state_name]
		,t.[address_zip_code]
		,t.[phone_number]
		,t.[email_website]
		,t.[foreign_address]
		,t.[foreign_address_country]
		,t.[questionable_indicator]
		,t.[role_blob]
		,t.[role_type]
		,t.[batch]
		,t.[bucket]
		,t.[Leap_Foreign_Addr_Part3]
		,t.[Leap_Party1_Account_Nbr]
		,t.[Leap_Party1_SSN_Nbr]
		,t.[Leap_Party1_Driver_License_Nbr]
		,t.[Leap_Party1_Driver_License_State]
		,t.[Leap_Party1_Date_Of_Birth]
		,t.[contact_name]
		,t.[m_create_date]
		,t.[m_update_date]
		,t.[name_sequence_id]
		,t.[birth_year]
	FROM #Temp t
	OUTER APPLY (
		SELECT *
		FROM #name_seq n
		WHERE n.doc_id = t.doc_id
			AND t.role_type = n.role_type
		) n
	WHERE t.Name_seq = 2

	COMMIT

	--spanner end
	SET @sucess = 1

	--END TRY
	--BEGIN CATCH
	--	IF @sucess = 0
	--	BEGIN
	--		ROLLBACK TRANSACTION
	--		GOTO END_ROUTINE
	--	END
	--END CATCH
	--END_ROUTINE:
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'UR_NameParse for Leap'
		,N'Ended'

	RETURN @sucess
END


