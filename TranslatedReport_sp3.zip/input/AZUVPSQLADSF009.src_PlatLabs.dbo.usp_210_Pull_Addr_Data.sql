SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Pull New DATA
-- =============================================
CREATE PROCEDURE [src_PlatLabs].[dbo].[usp_210_Pull_Addr_Data]
AS
BEGIN

	SET NOCOUNT ON;

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		TRUNCATE TABLE [addr].[RawAddress_Batch]

		INSERT INTO [src_PlatLabs].[addr].[RawAddress_Batch]([uid],[mls_id],[mls_listing_id],[modified_date],[RawStreetNbr],[RawPreDir],[RawStreet],[RawMode],[RawPostDir],[unit_number],[RawCity]
		,[RawState],[RawZip],[normalized_address],[LoadDate],[zip],[city],[complete_address],[street_number],[street_name],[street_suffix],[secondary_number])
		select [uid],[mls_id],[mls_listing_id],[modified_date],ltrim(rtrim([RawStreetNbr])),ltrim(rtrim([RawPreDir])),ltrim(rtrim([RawStreet])),ltrim(rtrim([RawMode])),ltrim(rtrim([RawPostDir])),ltrim(rtrim([unit_number])),[RawCity]
		,[RawState],[RawZip],[normalized_address],GetDate(),[zip],[city],[complete_address],[street_number],[street_name],[street_suffix],[secondary_number]
		from (Select [uid],[mls_id],[mls_listing_id],[modified_date],[street_number] RawStreetNbr,[street_pre_direction] RawPreDir,[street_name] RawStreet,[street_type] RawMode
		,[street_direction] RawPostDir, [unit_number],[city] RawCity,[state] RawState,[zip] RawZip,normalized_address
		from [src_PlatLabs].[listing].[ListingsRaw_Batch] with (nolock)) info
		CROSS APPLY OPENJSON(normalized_address) WITH(
			   zip varchar(10)
			 , city varchar(100)
			 , complete_address varchar(200)
			 , street_number varchar(60)
			 , street_name varchar(100)
			 , street_suffix varchar(60)
			 , secondary_number varchar(60)
			 ) as Address_array

		order by mls_id,mls_listing_id;

			EXEC [src_PlatLabs].[dbo].[usp_001_Clean_Extra_Ascii_from_inputTable] 'addr','RawAddress_Batch'

		Delete from [src_PlatLabs].[dbo].[a]
		FROM [src_PlatLabs].[addr].[RawAddress] a JOIN [src_PlatLabs].[addr].[RawAddress_Batch] b
		on a.mls_id = b.mls_id
		and a.mls_listing_id = b.mls_listing_id

		Insert into [src_PlatLabs].[addr].[RawAddress]
		Select * from [src_PlatLabs].[addr].[RawAddress_Batch]

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END

