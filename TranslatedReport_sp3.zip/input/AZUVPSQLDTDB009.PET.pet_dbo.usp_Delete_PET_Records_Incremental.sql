/* Source: AZUVNSQLDTDB003.datatree.local | Pet | pet_dbo.usp_Delete_PET_Records_Incremental | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
-- =============================================        
-- Author:  Sean Dang        
-- Create date: 02/13/2025        
-- Description: Delete rows from Pet_Neo_Xref, Pet_Neo, Pet_APN        
    
--update    
--3/24 removed comment that checks if neo_title_legals match    
-- this is because in pet_Neo_legals, there can be records that share the same fips, ref_id, and neo_apn, but we only need to     
-- delete a record with a specific neo_title_legal and/or portion_ind    
-- without checking (possible) over deletion (bad)    
-- =============================================        
--use PET        
CREATE PROCEDURE [PET].[pet_dbo].[usp_Delete_PET_Records_Incremental]      
 -- Add the parameters for the stored procedure here        
 --@FIPS INT,        
 @ERROR VARCHAR(500) OUTPUT      
AS      
BEGIN      
 -- SET NOCOUNT ON added to prevent extra result sets from        
 -- interfering with SELECT statements.        
 SET NOCOUNT ON;      
      
 BEGIN TRY      
  --CREATE index [index name] on [temp table/table name] ([column name], [column name 2],....);        
  --CREATE index idx_fips_neoAPN on [PET].[pet_tmp].[Pet_Incremental_Delete] ( FIPS, NEO_APN );        
  DROP TABLE      
      
  IF EXISTS #GetPetRefID      
   SELECT DeletePet.FIPS AS FIPS      
    ,DeletePet.NEO_APN AS NEO_APN      
    ,PetApn.REF_ID AS REF_ID      
    ,PetApn.APN_Type AS APN_Type      
    ,DeletePet.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL      
    ,DeletePet.PORTION_IND AS PORTION_IND      
   INTO #GetPetRefID      
   FROM [PET].[pet_tmp].[Pet_Incremental_Delete] AS DeletePet WITH (      
     NOLOCK      
     ,INDEX (idx_fips_neoAPN)      
     )      
   INNER JOIN [PET].[dbo].[PET_APN] AS PetApn WITH (      
     NOLOCK      
     ,INDEX (ixa_Fips_Apn)      
     ) ON PetApn.FIPS = DeletePet.FIPS      
    AND PetApn.APN = DeletePet.NEO_APN      
   WHERE (      
     PetApn.APN_Type LIKE 'N\_%' ESCAPE '\'      
     OR PetApn.APN_Type IN (      
      'NEO'      
      ,'NEOF'      
      )      
     )      
      
  CREATE INDEX idx_FIPS_APN_#GetRef ON #GetPetRefID (      
   FIPS      
   ,NEO_APN      
   ) 
   CREATE INDEX idx_FIPS_APN_#GetRef_ref ON #GetPetRefID (      
   FIPS      
   ,REF_ID      
   ) 
      
  --  SELECT * FROM #GetPetRefID      
      
  DELETE NeoXrefDelete
  FROM [PET].[dbo].[PET_NEO_Xref_Full] AS NeoXrefDelete WITH (      
    NOLOCK      
    ,INDEX (ixb)      
    )      
  INNER JOIN [PET].[pet_tmp].[Pet_Incremental_Delete] AS PetDelete WITH (      
    NOLOCK      
    ,INDEX (idx_fips_neoAPN)      
    ) ON NeoXrefDelete.NEO_APN = PetDelete.NEO_APN      
   AND NeoXrefDelete.FIPS = PetDelete.FIPS      
   and isnull(PetDelete.NEO_TITLE_LEGAL,'') = isnull(NeoXrefDelete.NEO_TITLE_LEGAL,'')      
   and isnull(PetDelete.PORTION_IND,'') = isnull(NeoXrefDelete.PORTION_IND,'')    
  OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));    
      
  --WHERE (      
  --  (PetDelete.NEO_TITLE_LEGAL = NeoXrefDelete.NEO_TITLE_LEGAL)      
  --  OR (      
  --   PetDelete.NEO_TITLE_LEGAL IS NULL      
  --   AND NeoXrefDelete.NEO_TITLE_LEGAL IS NULL      
  --   )      
  --  )      
  -- AND (      
  --  (PetDelete.PORTION_IND = NeoXrefDelete.PORTION_IND)      
  --  OR (      
  --   PetDelete.PORTION_IND IS NULL      
  --   AND NeoXrefDelete.PORTION_IND IS NULL      
  --   )      
  --  )      
      
  DELETE DeleteApn  
  FROM [PET].[dbo].[PET_APN] AS DeleteApn WITH (      
    NOLOCK      
    ,INDEX (ix_fips_APN_TYPE)      
    )      
  INNER JOIN #GetPetRefID AS GetPetRefID WITH (      
    NOLOCK      
    ,INDEX (idx_FIPS_APN_#GetRef_ref)      
    ) ON DeleteApn.REF_ID = GetPetRefID.REF_ID      
   AND DeleteApn.FIPS = GetPetRefID.FIPS      
  WHERE DeleteApn.APN_Type = GetPetRefID.APN_Type      
  OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));    
 
  --DELETE DeleteLegals        
  --FROM [PET].[dbo].[PET_NEO_LEGALS] as DeleteLegals        
  --INNER JOIN #GetPetRefID as GetPetRefID on DeleteLegals.REF_ID = GetPetRefID.REF_ID        
  --WHERE some sorta conditional?         
  --DELETE DeleteLegals        
  --FROM         
  -- (        
  --  select Distinct NeoLegals.*        
  --  from [PET].[dbo].[Pet_NEO_LEGALS] as NeoLegals        
  --  inner join #GetPetRefID as DeleteByRef on NeoLegals.REF_ID = DeleteByRef.REF_ID        
  --  where DeleteByRef.NEO_APN = NeoLegals.NEO_APN and DeleteByRef.NEO_TITLE_LEGAL = NeoLegals.NEO_TITLE_LEGAL        
  -- ) as DeleteLegals        
  --temp table thatll hold the neo_title_legal and ref_id of the rows that need deleted        
  --switched to physical table        
  DROP TABLE      
      
  IF EXISTS [PET].[pet_tmp].[Pet_Incremental_REF_ID] --#testTable        
   SELECT DISTINCT NeoLegals.NEO_TITLE_LEGAL      
    ,NeoLegals.REF_ID      
    ,NeoLegals.PORTION_IND      
    ,NeoLegals.fips      
    ,NeoLegals.NEO_APN      
   INTO [PET].[pet_tmp].[Pet_Incremental_REF_ID] --#testTable        
   FROM [PET].[dbo].[Pet_NEO_LEGALS] AS NeoLegals      
 INNER JOIN #GetPetRefID AS DeleteByRef ON NeoLegals.REF_ID = DeleteByRef.REF_ID      
    AND NeoLegals.FIPS = DeleteByRef.FIPS      
    and isnull(DeleteByRef.NEO_TITLE_LEGAL,'') = isnull(NeoLegals.NEO_TITLE_LEGAL,'')      
   --and isnull(DeleteByRef.PORTION_IND,'') = isnull(NeoLegals.PORTION_IND,'')       
   and DeleteByRef.NEO_APN = NeoLegals.NEO_APN      
  OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));    
    
  CREATE index idx_fips_refID on [PET].[pet_tmp].[Pet_Incremental_REF_ID] ( FIPS );        
    
  --select * from [PET].[pet_tmp].[Pet_Incremental_REF_ID]    
    
  DELETE DeleteLegals      
  --select DeleteLEgals.*    
  FROM [PET].[dbo].[PET_NEO_LEGALS] AS DeleteLegals      
  INNER JOIN [PET].[pet_tmp].[Pet_Incremental_REF_ID] AS TestLegals ON       
   TestLegals.REF_ID = DeleteLegals.REF_ID      
    AND TestLegals.FIPS = DeleteLegals.FIPS      
    and isnull(DeleteLegals.NEO_TITLE_LEGAL,'') = isnull(TestLegals.NEO_TITLE_LEGAL,'')      
    --and isnull(DeleteLegals.PORTION_IND,'') = isnull(TestLegals.PORTION_IND,'')       
    and DeleteLegals.NEO_APN = TestLegals.NEO_APN       
  OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));    
    
  --WHERE TestLegals.NEO_TITLE_LEGAL IN (      
  --  SELECT NeoLegals.NEO_TITLE_LEGAL      
  --  FROM [PET].[dbo].[Pet_NEO_LEGALS] AS NeoLegals      
  --  INNER JOIN [PET].[pet_tmp].[Pet_Incremental_REF_ID] AS TestLegals ON NeoLegals.REF_ID = TestLegals.REF_ID      
  --  )      
  -- AND (      
  --  (DeleteLegals.NEO_TITLE_LEGAL = TestLegals.NEO_TITLE_LEGAL)      
  --  OR (      
  --   DeleteLegals.NEO_TITLE_LEGAL IS NULL      
  --   AND TestLegals.NEO_TITLE_LEGAL IS NULL      
  --   )      
  --  )      
  -- AND (      
  --  (DeleteLegals.PORTION_IND = TestLegals.PORTION_IND)      
  --  OR (      
  --   DeleteLegals.PORTION_IND IS NULL      
  --   AND TestLegals.PORTION_IND IS NULL      
  --   )      
  --  )      
 END TRY      
      
 BEGIN CATCH 
  rollback

  SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())      
      
  RAISERROR (      
    @ERROR      
    ,16      
    ,1      
    )      
 END CATCH      
END 

