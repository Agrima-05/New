SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Business_v3]

AS
BEGIN


	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		DELETE FROM [src_PlatLabs].[features].[BusinessJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

		INSERT INTO [src_PlatLabs].[features].[BusinessJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Business, j.[type], GETDATE()
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Business') AS j
		ORDER BY j.[key]
		
		--Select * from features.BusinessJSON
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




