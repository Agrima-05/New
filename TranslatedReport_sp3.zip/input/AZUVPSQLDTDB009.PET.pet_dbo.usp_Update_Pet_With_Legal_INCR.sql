/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Update_Pet_With_Legal_INCR | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:		Sean Dang
-- Create date: 02/25/2025
-- Description:	update PET table with new Legal information
-- =============================================
CREATE PROCEDURE [PET].[pet_dbo].[usp_Update_Pet_With_Legal_INCR]
	-- Add the parameters for the stored procedure here
	@Fips INT
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_Update_Pet_With_Legal_INCR'
			,N'Started'

		/*=================================================
	  Populate Legal information when matched to Xref
	  ================================================*/
		UPDATE [PET].[pet_dbo].[p]
		SET p.NEO_LAND_TYPE = l.NEO_LAND_TYPE
			,p.NEO_TITLE_LEGAL = l.NEO_TITLE_LEGAL
			,p.NEO_APN = a.APN
			,p.Label1 = l.Label1
			,p.Value1 = l.Value1
			,p.Label2 = l.Label2
			,p.Value2 = l.Value2
			,p.Label3 = l.Label3
			,p.Value3 = l.Value3
			,p.Label4 = l.Label4
			,p.Value4 = l.Value4
			,p.Label5 = l.Label5
			,p.Value5 = l.Value5
			,p.Label6 = l.Label6
			,p.Value6 = l.Value6
			,p.Label7 = l.Label7
			,p.Value7 = l.Value7
			,p.Label8 = l.Label8
			,p.Value8 = l.Value8
			,p.Label9 = l.Label9
			,p.Value9 = l.Value9
			,p.Label10 = l.Label10
			,p.Value10 = l.Value10
			,p.Label11 = l.Label11
			,p.Value11 = l.Value11
			,p.Label12 = l.Label12
			,p.Value12 = l.Value12
			,p.Label13 = l.Label13
			,p.Value13 = l.Value13
			,p.Label14 = l.Label14
			,p.Value14 = l.Value14
			,p.Label15 = l.Label15
			,p.Value15 = l.Value15
			,p.Label16 = l.Label16
			,p.Value16 = l.Value16
			,p.Label17 = l.Label17
			,p.Value17 = l.Value17
			,p.Label18 = l.Label18
			,p.Value18 = l.Value18
			,p.Label19 = l.Label19
			,p.Value19 = l.Value19
			,p.Label20 = l.Label20
			,p.Value20 = l.Value20
			,p.Label21 = l.Label21
			,p.Value21 = l.Value21
			,p.Label22 = l.Label22
			,p.Value22 = l.Value22
			,p.Label23 = l.Label23
			,p.Value23 = l.Value23
			,p.BookType = l.BookType
			--,p.Legal_Dup_Ind = l.Legal_Dup_Ind
			,p.updated = GETDATE()


		FROM [pet].[dbo].[Pet] p WITH (INDEX (IDX_FIPS_REF_ID))
		CROSS APPLY (
			SELECT DISTINCT fips
				,ref_id
			FROM [PET].[pet_tmp].[Pet_Incremental_REF_ID] b WITH (
					NOLOCK
					,INDEX (idx_fips_refID)
					)
			WHERE b.fips = p.fips
				AND b.ref_id = p.ref_id
			) b
		CROSS APPLY (
			SELECT *
			FROM [Pet].[dbo].[pet_neo_legals] l WITH (INDEX (ix_fips_ref_id))
			WHERE l.fips = p.fips
				AND l.ref_id = p.ref_id
			) l
		CROSS APPLY (
			SELECT *
			FROM [Pet].[dbo].[Pet_Apn] a WITH (INDEX (fips_ref_id_apntype))
			WHERE a.Fips = p.Fips
				AND a.Ref_id = p.Ref_id
				AND a.Apn_Type = 'NEOF'
			) a
		WHERE p.fips = @Fips
			AND p.NEO_Legal_cnt = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_Update_Pet_With_Legal_INCR'
			,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


