/* Source: DWS-ETL02.DATATREE.LOCAL | SPDB | dbo.usp_PEt_Apn_Creation_2_incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- ================================================================================================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- ================================================================================================================
/******************************************************************************************************************
CHANGE LOG:
==========
who                date                change
Marie   9/13/2022        Remove Tanslated Fips 
******************************************************************************************************************/
--CREATE
--	OR
CREATE   PROCEDURE [SPDB].[dbo].[usp_PEt_Apn_Creation_2_incr] @fips INT = NULL
	,@Apn_type VARCHAR(10) = NULL
	,@list_Sql INT = 0
	,@Refresh BIT = 0
AS
BEGIN TRY
	DECLARE @ERROR VARCHAR(500) --OUTPUT

	EXEC [PET].[dbo].[AddPetlog] @fips
		,N'info'
		,N'usp_PEt_Apn_Creation_2_incr'
		,N'Started'

	DECLARE @sql_cmd VARCHAR(max)
	DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
		,@Rule VARCHAR(max) = NULL --
		,@Status VARCHAR(20) = NULL --'To_Be_Processed'
		,@node_delimeter VARCHAR(10) = NULL --'-'
	DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type

	--IF @list_Sql = 0
	--BEGIN
	--EXEC ntp.Stage.[AddNtpLog] N'info'
	--        ,N'[usp_PEt_Apn_Creation_2] begin'
	--        ,@mess
	--END
	--SELECT @FIPS = a.FIPS
	--        ,@APN_Type = a.APN_Type
	--        ,
	SELECT @Source_Apn = a.Source_Apn
		,@Rule = a.[Rule]
		,@node_delimeter = '-'
	FROM [PET].[dbo].[PET_APN_Additional_Formats] a
	WHERE fips = @fips
		AND a.apn_type = @apn_type

	--DECLARE @translated_fips INT = CASE 
	--                WHEN @fips BETWEEN 15000
	--                                AND 16000
	--                        THEN 15999
	--                ELSE @fips
	--                END
	SET @sql_cmd = cast(N'

			delete a from pet.dbo.pet_apn a
		where a.fips = ' + try_cast(@fips AS VARCHAR) + '
		and a.apn_type = ''' + @Apn_type + '''
		 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk)
	' AS NVARCHAR(max))
	SET @sql_cmd = @sql_cmd + cast(
			N'
INSERT INTO PET.[dbo].[PET_APN] (
	[REF_ID]
	,[FIPS]
	,[APN_Type]
	,[APN_ID]
	,[APN]
	,[created]
	,[updated]
	)
SELECT a.[REF_ID]
	,a.[FIPS]
	,a.[APN_Type]
	,a.[APN_ID]
	,a.[APN]
	,a.[created]
	,a.[updated]
FROM pet.dbo.Pet_apn_additions a
OUTER APPLY (
	SELECT ref_id
	FROM pet.dbo.pet_apn pa WITH (
			NOLOCK
			,INDEX (fips_ref_id_apntype)
			)
	WHERE pa.fips = a.fips
		AND pa.ref_id = a.ref_id
		AND pa.APN_Type = a.apn_type
	) pa
WHERE pa.ref_id IS NULL
OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));




DROP TABLE

IF EXISTS pet.pet_tmp.pet_addl_formatting_del_dup
	SELECT f.apn
		,count(1) AS cnt
	INTO pet.pet_tmp.pet_addl_formatting_del_dup
	FROM pet.dbo.Pet_apn_additions a
	OUTER APPLY (
		SELECT p.REF_ID
			,p.apn
		FROM PET.dbo.Translate_fips f WITH (
				NOLOCK
				,INDEX (ixc_fips)
				)
		OUTER APPLY (
			SELECT DISTINCT ref_id
				,apn
			FROM pet.dbo.pet_apn p WITH (
					NOLOCK
					,INDEX (ixa_Fips_Apn)
					)
			WHERE p.fips = f.TranslatedFips
				AND p.apn = a.apn
			) p
		WHERE f.Fips = a.fips
		) f
	GROUP BY f.APN
	HAVING count(1) > 1

	OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));


DELETE p
FROM [PET].[dbo].[PET_APN] p
INNER JOIN PET.dbo.Translate_fips f WITH (
		NOLOCK
		,INDEX (ix_transFips)
		) ON f.translatedfips = p.fips


where f.Fips = ' 
			+ try_cast(@fips AS VARCHAR) + ' and  p.apn in (Select apn from pet.pet_tmp.pet_addl_formatting_del_dup)
and p.apn_type = ''' + @Apn_type + '''

' AS NVARCHAR(max))

	IF @list_Sql = 1
	BEGIN
		SELECT @sql_cmd
	END

	IF @list_Sql = 0
	BEGIN
		EXEC (@sql_cmd)
	END

	--IF @list_Sql = 0
	--BEGIN
	--        EXEC ntp.Stage.[AddNtpLog] N'info'
	--                ,N'[usp_PEt_Apn_Creation_2] end'
	--                ,@mess
	--END
	EXEC [PET].[dbo].[AddPetlog] @fips
		,N'info'
		,N'usp_PEt_Apn_Creation_2_incr'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


