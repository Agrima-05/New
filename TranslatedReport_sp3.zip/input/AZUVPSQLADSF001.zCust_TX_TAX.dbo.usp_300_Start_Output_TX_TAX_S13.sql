SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_TX_TAX].[dbo].[usp_300_Start_Output_TX_TAX_S13]


AS
BEGIN
	
	SET NOCOUNT ON;



		DROP TABLE [dbo].[x_Custom_OUTPUT_S13]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S13](
		    [FIPS] [varchar](5) NULL,
			--[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT FIPS][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[INPUT APN][varchar](250)NULL,
			[INPUT Start Date][varchar](250)NULL,
			[STD_Property Address][varchar](250)NULL,
			[STD_City][varchar](250)NULL,
			[STD_State][varchar](250)NULL,
			[STD_Zip Code][varchar](250)NULL,

			[LIC_Property Address][varchar](250)NULL,
			[LIC_City][varchar](250)NULL,
			[LIC_State][varchar](250)NULL,
			[LIC_Zip Code][varchar](250)NULL,

			[Run Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Through Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Through Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[APN][varchar](250)NULL,
			[TAXACCOUNTNUMBER][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Listing SOLD Date][varchar](250)NULL,

			[Deed_Recording Date][varchar](250)NULL,
			[Deed_Document Number][varchar](250)NULL,
			[Deed_Amount][varchar](250)NULL,
			[Deed_Buyer][varchar](250)NULL,
			[Deed_Seller][varchar](250)NULL,
			[Deed_Title_Company][varchar](250)NULL,

			[Mortgage_Recording Date][varchar](250)NULL,
			[Mortgage_Document Number][varchar](250)NULL,
			[Mortgage_Amount][varchar](250)NULL,
			[Mortgage_Borrower][varchar](250)NULL,
			[Mortgage_Lender][varchar](250)NULL,
			[Mortgage_Title_Company][varchar](250)NULL,

			--[Nbr of Recordings][varchar](250)NULL,

			


			---------------Internal---------
			[INPUTSTARTDATE][varchar](250)NULL
		) ON [PRIMARY]

		
		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13](
		[INPUT Unique ID],
		[INPUT FIPS],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		[INPUT APN],
		[INPUT Start Date],
		[INPUTSTARTDATE]
		)
	  
		
		Select 
		INPUTKey
		,INPUTFIPS
		,INPUTAddress 
		,INPUTCity
		,INPUTState
		,INPUTZip
		,INPUTAPN
		,convert(DAte,INPUTStartDate )
		,convert(DAte,INPUTStartDate )
		--Select top 100 * 
		From  [zCust_TX_TAX].[dbo].[INPUT_IN] as A 
		--From INPUT_RAW_CUST
		where ISNULL(INPUTKey,'') not like ''

		
	

		

		Select top 100 * From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]



	
		UPDATE [zCust_TX_TAX].[dbo].[a] 
		SET 
		-- A.WORK_REF_ID = C.REF_ID
		 --,
		 A.PropertyID = case when A.PropertyID is null then C.PropertyID else A.PropertyID end  
		,a.Fips = CASE WHEN A.FIPS is null then case when LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END else A.FIPS end
		,a.[Run Date] = convert(date,GetDate())
		--Select * 
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as c with(NOLOCK) on a.[INPUT Unique ID] = c.RAW_ID


				
	
		Update [zCust_TX_TAX].[dbo].[a]
		SET a.[STD_Property Address] = c.FullStreetAddress
		, a.STD_City = c.City
		, a.[STD_State] = c.[State]
		, a.[STD_Zip Code] = c.Zip + c.Zip4
		--, a.[RunDate] = convert(varchar(10),GetDate(),120)
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--Select C.*  
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_TX_TAX].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Unique ID] = c.RAW_ID



		-----Overwriting Address with FLANK matched 
		Update [zCust_TX_TAX].[dbo].[A]
		SET a.[LIC_Property Address] = c.SitusSTDFullStreetAddress
		, a.LIC_City = c.SitusSTDCity
		, a.[LIC_State] = c.SitusSTDState
		, a.[LIC_Zip Code] = c.SitusSTDZip5
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] A JOIN [data].[dbo].[Property] as C with(NOLOCK)
		on A.FIPS = C.FIPS and A.PropertyID = C.PropertyID

	
		Update [zCust_TX_TAX].[dbo].[A]
		Set 
		A.[Deed Coverage Status] = B.DeedActive
		,A.[Deed Through Date] = convert(date,B.DeedMaxRecordDate)
		,A.[Mortgage Coverage Status] = B.SAMActive
		,A.[Mortgage Through Date] = convert(date,B.SAMMaxRecordDate)
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN 
		[Global].[dbo].[county] as B on A.FIPS = B.FIPSCODE


		Update [zCust_TX_TAX].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		,A.APN = B.FormattedAPN
		,A.TAXACCOUNTNUMBER = B.TaxAccountNumber
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID

		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_TX_TAX].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_TX_TAX].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		UPdate [zCust_TX_TAX].[dbo].[A]
		Set
		A.[Listing SOLD Date] = B.SOLD_DATE
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN

		(Select  [INPUT Unique ID], min(B.SOLD_DATE) as SOLD_DATE From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A with(NOLOCK)
		join [LIsting].[dbo].[_LIstings_ALL_CURRENT] as B with(NOLOCK) on A.FIPS = B.COUNTY_FIPS
		and A.PropertyID = B.PM_PROPERTYID
		where A.PropertyiD not like '' and A.Propertyid is not null and A.Propertyid not like '0'
		and B.Status like 'Sold'
		and B.[Add_Change_Delete_Indicator] not like 'D'
		and B.SOLD_DATE >= A.INPUTSTARTDATE
		Group by [INPUT Unique ID])B
		on A.[INPUT Unique ID] = B.[INPUT Unique ID]


		--Update A
		--Set A.[Current Owner Doc Type] = B.CodeDesc
		----Select A.[Current Owner Doc Type] , B.CodeDesc
		--FROM x_Custom_OUTPUT_S13 a 
		--JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		--on A.[Current Owner Doc Type] = B.DocTypeID



		
		
		Exec [zCust_TX_TAX].[dbo].[usp_502_Pull_FLANK_DATA]

		---------ONE ARMS LEN DEED recorded >= Input Start Date - CLOSEST TO INPUT START DATE (OLDEST that is >= input start date)


		Update [zCust_TX_TAX].[dbo].[w_TransHist_FLANK]
		Set ToUse = NULL
		where ToUse is not null
		
		Update [zCust_TX_TAX].[dbo].[B]
		Set B.ToUse = 'Y'
		--Select A.InputStartDate, B.* 
		From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A join [zCust_TX_TAX].[dbo].[w_TransHist_FLANK] as B on A.[INPUT Unique ID] = B.RAW_ID
		where B.Doc_Src_Ind in ('D')
		and convert(date,B.RecordingDate) >= A.INPUTSTARTDATE
		AND ARMS_LEN = 1
		
		

		Truncate table w_TransHist_FLANK_II

		Insert into [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		Select * From [zCust_TX_TAX].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Order by RAW_ID, RecordingDate ASC, Doc_Src_Ind, DocumentNbr ASC

		
		Update [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		set RecordNumber = NULL

			UPDATE [zCust_TX_TAX].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID, Doc_Src_Ind ORDER BY RAW_ID,RecordingDate ASC,  Doc_ID ASC, DocumentNbr ASC) AS RowNum
				FROM 
			[zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID
			and ISNULL(t.DocumentNbr,'') = ISNULL(R.DocumentNbr,'')
			and t.Doc_Src_Ind = r.Doc_Src_Ind
			and t.RecordingDate = r.RecordingDate


		Select RAW_ID, count(*) From [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber = 1
		Group by RAW_ID
		having count(*) > 1


		UPdate [zCust_TX_TAX].[dbo].[A]
		set
		A.[Deed_Recording Date] = B.recordingdate
		,A.[Deed_Document Number] = B.Documentnbr
		,A.[Deed_Amount] = B.Value
		,A.[Deed_Buyer] = B.BuyerBorrower
		,A.[Deed_Seller] = B.SellerLender
		,A.[Deed_Title_Company] = B.TITLECONAME
		--Select top 100 A.INPUTSTARTDATE,B.*
		From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A 
		join [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] as B on A.[INPUT Unique ID] = B.RAW_ID
		where B.Doc_Src_Ind like 'D'
		and B.recordnumber = 1
		


		---------------FIRST OLDEST MORTGAGE recorded >= Input Start Date
		
		Update [zCust_TX_TAX].[dbo].[w_TransHist_FLANK]
		Set ToUse = NULL
		where ToUse is not null
		
		Update [zCust_TX_TAX].[dbo].[B]
		Set B.ToUse = 'Y'
		--Select A.InputStartDate, B.* 
		From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A join [zCust_TX_TAX].[dbo].[w_TransHist_FLANK] as B on A.[INPUT Unique ID] = B.RAW_ID
		where B.Doc_Src_Ind in ('M')
		and convert(date,B.RecordingDate) >= A.INPUTSTARTDATE
		
		
		

		Truncate table w_TransHist_FLANK_II

		Insert into [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		Select * From [zCust_TX_TAX].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Order by RAW_ID, RecordingDate ASC, Doc_Src_Ind, DocumentNbr ASC

		
		Update [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		set RecordNumber = NULL

			UPDATE [zCust_TX_TAX].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID, Doc_Src_Ind ORDER BY RAW_ID,RecordingDate ASC,  Doc_ID ASC, DocumentNbr ASC) AS RowNum
				FROM 
			[zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID
			and ISNULL(t.DocumentNbr,'') = ISNULL(R.DocumentNbr,'')
			and t.Doc_Src_Ind = r.Doc_Src_Ind
			and t.RecordingDate = r.RecordingDate


		Select RAW_ID, count(*) From [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber = 1
		Group by RAW_ID
		having count(*) > 1


		UPdate [zCust_TX_TAX].[dbo].[A]
		set
		A.[Mortgage_Recording Date] = B.recordingdate
		,A.[Mortgage_Document Number] = B.Documentnbr
		,A.[Mortgage_Amount] = B.Value
		,A.[Mortgage_Borrower] = B.BuyerBorrower
		,A.[Mortgage_Lender] = B.SellerLender
		,A.[Mortgage_Title_Company] = B.TITLECONAME
		--Select top 100 A.INPUTSTARTDATE,B.*
		From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A 
		join [zCust_TX_TAX].[dbo].[w_TransHist_FLANK_II] as B on A.[INPUT Unique ID] = B.RAW_ID
		where B.Doc_Src_Ind like 'M'
		and B.recordnumber = 1

	
		Select top 1000 * From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		

		--Update x_Custom_OUTPUT_S13
		--Set [Nbr of Recordings] = NULL
		--where convert(int,[Nbr of Recordings]) > 0


		--UPDATE a
		--SET a.[Nbr of Recordings] =  b.NbrOfRecordings  
		--FROM x_Custom_OUTPUT_S13 a JOIN 
		----(SELECT INPUTKEY,MAX(ROWNUM) NbrOfRecordings FROM DEEDS_TO_USE GROUP BY INPUTKEY) 
		--(SELECT RAW_ID,MAX(convert(int,RecordNumber)) NbrOfRecordings FROM w_TransHist_FLANK_II GROUP BY RAW_ID) 
		--b
		--on a.[INPUT Unique ID] = b.RAW_ID

		--Select MAX(convert(int,[Nbr of Recordings])) from x_Custom_OUTPUT_S13

		-------------------------20250421 - Per WL - Changed from Build Horizontal to build vertical-------

		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Record Number] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Recording Date] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Document Number] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Amount] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Doc Type] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer/Borrower] [varchar](250) NULL')
		------			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller/Lender] [varchar](250) NULL')
			

		------				EXEC('UPDATE a
		------				SET 
		------				A.[Record Number] = B.[RecordNumber]
		------				,A.[Recording Date] = B.RecordingDate
		------				,A.[Document Number] = B.DocumentNbr
		------				,A.[Amount] = B.Value
		------				,A.[Doc Type] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
		------				,A.[Buyer/Borrower] = B.BuyerBorrower
		------				,A.[Seller/Lender] = B.SellerLender
		------				--,A.[Title Company] = B.TITLECONAME


		------				--Select B.* 
		------				FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
		------				on a.[INPUT Unique ID] = b.RAW_ID
		------				WHERE B.[RecordNumber] = 1
		------				')
			
		------	 Select top 100 * From x_Custom_OUTPUT_S13


		------	----------------------------------------BUILD DOWN    ------------------------------------
		------IF (Select max(convert(int,[Nbr of Recordings])) from x_Custom_OUTPUT_S13) > 1
		------BEGIN
		
		------Truncate table dbo.BUILD_DOWN_COLUMNS

		
		------Insert into  dbo.BUILD_DOWN_COLUMNS 
		------Select * From (
		------Select 
		------Stuff(
  ------      (
  ------      Select Distinct ', [' +   B.Name + ']'
		------ From sys.tables as A join sys.columns as B on 
		------	A.OBJECT_ID = b.object_id
		------	where A.Name like 'x_Custom_OUTPUT_S13'
		------	and B.Name not in ('Record Number'
		------				,'Recording Date'
		------				,'Document Number'
		------				,'Amount'
		------				,'Doc Type'
		------				,'Buyer/Borrower'
		------				,'Seller/Lender')
		------				 For Xml Path('')
  ------      ), 1, 2, '') As Columns)A

		------Select * From dbo.BUILD_DOWN_COLUMNS


		
		------						Declare @BeginNbrOfTrans6 int
		------						Declare @EndNbrOfTrans6 int
		------						DECLARE @FIELDLIST3 nvarchar(max)
		------						DECLARE @FIELDLIST4 nvarchar(max)
		------						DECLARE @SQL6 nvarchar(max)

								

		------						Set @FIELDLIST3 = (Select * From dbo.BUILD_DOWN_COLUMNS)
		------						Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From dbo.BUILD_DOWN_COLUMNS)

		------						SET @BeginNbrOfTrans6 = 2
		------						Select @EndNbrOfTrans6 =   MAX(convert(int,[Nbr of Recordings])) FROM x_Custom_OUTPUT_S13

		------							WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
		------								BEGIN

				 
		------									DECLARE @RecNbr6 as varchar(5)
		------									SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

		------										EXEC('
		------										Insert into x_Custom_OUTPUT_S13(
		------										' +  @FIELDLIST3 + '

		------										  ,[Record Number]
		------											,[Recording Date]
		------											,[Document Number]
		------											,[Amount]
		------											,[Doc Type]
		------											,[Buyer/Borrower]
		------											,[Seller/Lender])

		------											  Select 
		------									 ' +  @FIELDLIST4 + '

		------										,B.[RecordNumber]
		------										,B.RecordingDate
		------										,B.DocumentNbr
		------										,B.Value
		------										,case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
		------										,B.BuyerBorrower
		------										, B.SellerLender
												
		------										--Select B.* 
		------										FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
		------										on a.[INPUT Unique ID] = b.RAW_ID
		------										WHERE B.[RecordNumber] = ''' + @BeginNbrOfTrans6 + '''
		------										AND A.[Record Number] = ''1''

											
		------								')
										
										
												
		------								SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
		------								END

		------	END
										
		------				EXEC('UPDATE a
		------				SET 
		------				A.[Doc Type] = B.[CodeDesc]
		------				--Select B.*
		------				FROM x_Custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
		------				on A.[Doc Type] = b.DocTypeID
						
		------				')


		------	--Select [Doc Type], count(*) From x_Custom_OUTPUT_S13
		------	--where [Nbr of Recordings] > 0
		------	--Group by [Doc Type]
		------	--Order by [Doc Type]


		-------- Select top 100 [INPUT Unique ID], [Nbr of Recordings], [REcord Number]
		-------- ,[Recording Date], [Document Number], Amount, [Doc Type], [Buyer/Borrower], [Seller/Lender]
		-------- From x_Custom_OUTPUT_S13
		--------Order by convert(int,[Nbr of Recordings]) desc


		 
		-------- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		--Declare @BeginNbrOfTrans int
		--Declare @EndNbrOfTrans int

		--SET @BeginNbrOfTrans = 1
		--Select @EndNbrOfTrans = MAX(convert(int,[Nbr of Recordings])) FROM x_Custom_OUTPUT_S13

		--	WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
		--		BEGIN
				 
		--			DECLARE @RecNbr as varchar(5)
		--			SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Document Number_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Amount_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer1/Borrower1_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer2/Borrower2_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller1/Lender_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller2_' + @RecNbr + '] [varchar](250) NULL')
		--			--EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Title Company_' + @RecNbr + '] [varchar](250) NULL')



		--				EXEC('UPDATE a
		--				SET 
		--				A.[Record Number_' + @RecNbr + '] = ''' + @RecNbr + '''
		--				,A.[Recording Date_' + @RecNbr + '] = B.RecordingDate
		--				,A.[Document Number_' + @RecNbr + '] = B.DocumentNbr
		--				,A.[Amount_' + @RecNbr + '] = B.Value
		--				,A.[Doc Type_' + @RecNbr + '] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
		--				,A.[Buyer1/Borrower1_' + @RecNbr + '] = B.BuyerBorrower1
		--				,A.[Buyer2/Borrower2_' + @RecNbr + '] = B.BuyerBorrower2
		--				,A.[Seller1/Lender_' + @RecNbr + '] = B.SellerLender1
		--				,A.[Seller2_' + @RecNbr + '] = B.SellerLender2
		--				--,A.[Title Company_' + @RecNbr + '] = B.TITLECONAME


		--				--Select B.* 
		--				FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
		--				on a.[INPUT Unique ID] = b.RAW_ID
		--				WHERE B.[RecordNumber] = ' + @BeginNbrOfTrans + '
		--				')

		--				EXEC('UPDATE a
		--				SET 
		--				A.[Doc Type_' + @RecNbr + '] = B.[CodeDesc]
		--				--Select B.*
		--				FROM x_Custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
		--				on A.[Doc Type_' + @RecNbr + '] = b.DocTypeID
		--				WHERE A.[Record Number_' + @RecNbr + '] = ' + @BeginNbrOfTrans + '
		--				')

						
						


		--			SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
		--		END 


		--Select * From x_Custom_OUTPUT_S13
		--Order by convert(int,[Nbr of Recordings]) desc

		Select top 1000 [INPUT Unique ID], PROPERTYID, [INPUT Address],[Property Status], * From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		where [Property Status] like 'Property Found'


		
		Update [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_TX_TAX].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_TX_TAX].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID

		Select count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Select count(*) From [zCust_TX_TAX].[dbo].[a_ASP_IN_STD]

	

		Update [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN 
		(PropertyID is  not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_TX_TAX].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] a join [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		---------------20240917 - Per EC Event Status = Has recording
		Update [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Event Status] = CASE WHEN ISNULL([Deed_Recording Date],'') not like '' OR ISNULL([Mortgage_Recording Date],'') not like ''
		THEN 'Event Found' ELSE 'Event Not Found' END


		Select [Mortgage Coverage Status], count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Mortgage Coverage Status]

		Select [Deed Coverage Status], count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Deed Coverage Status]


		Select [Address Standardization], count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Address Standardization]

		Select [Property Status], count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Event Status]

	

	

		Select top 1000 * 
		From [zCust_TX_TAX].[dbo].[x_Custom_OUTPUT_S13] as A 
		

	

			

END






