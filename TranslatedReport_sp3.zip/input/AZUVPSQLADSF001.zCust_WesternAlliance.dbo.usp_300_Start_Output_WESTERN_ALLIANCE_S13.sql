SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_WesternAlliance].[dbo].[usp_300_Start_Output_WESTERN_ALLIANCE_S13]


AS
BEGIN
	
	SET NOCOUNT ON;



		DROP TABLE [dbo].[x_Custom_OUTPUT_S13]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S13](
		    [FIPS] [varchar](5) NULL,
			--[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT Property ID][varchar](250)NULL,
			[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Through Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Through Date][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Current Owner Doc Type][varchar](250)NULL,
			[Nbr of Recordings][varchar](250)NULL,


			---------------Internal---------
			[INPUTSTARTDATE][varchar](250)NULL
		) ON [PRIMARY]

		

		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13](
		[INPUT Property ID],
		[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],

		[INPUTSTARTDATE])
	  
		
		Select 
		[PropertyID]
		,[LoanID] 
		,left([PropertyStreet] ,250)
		,[PropertyCity] 
		,[PropertyState]
		,[PropertyZIPCode] 
		,convert(DAte,[IssuanceDate] )
		
		From [zCust_WesternAlliance].[dbo].[INPUT_RAW_CUST]

		--SET CONCAT_NULL_YIELDS_NULL OFF
		--INSERT INTO x_Custom_OUTPUT_S13 (
		--[INPUT Property ID]
		--,[INPUTSTARTDATE])
		--Select 
		--[PROPERTY_ID], convert(date,START_DATE)
		--From [dbo].[INPUT_RAW_BUILDER_20260422] as A 
	
	

		

		Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]



	
		UPDATE [zCust_WesternAlliance].[dbo].[a] 
		SET 
		-- A.WORK_REF_ID = C.REF_ID
		 --,
		 A.PropertyID = case when A.PropertyID is null then C.PropertyID else A.PropertyID end  
		,a.Fips = CASE WHEN A.FIPS is null then case when LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END else A.FIPS end
		,a.[Report Date] = convert(date,GetDate())
		--Select * 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK_FLANK] as c with(NOLOCK) on a.[INPUT Property ID] = c.RAW_ID


				
	
		Update [zCust_WesternAlliance].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		--, a.[RunDate] = convert(varchar(10),GetDate(),120)
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--Select C.*  
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Property ID] = c.RAW_ID


	
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.[Deed Coverage Status] = B.DeedActive
		,A.[Deed Through Date] = convert(date,B.DeedMaxRecordDate)
		,A.[Mortgage Coverage Status] = B.SAMActive
		,A.[Mortgage Through Date] = convert(date,B.SAMMaxRecordDate)
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN 
		[Global].[dbo].[county] as B on A.FIPS = B.FIPSCODE


		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID

		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_WesternAlliance].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID


		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_WesternAlliance].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Property ID] = b.Raw_ID



		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN 
		(PropertyID is  not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_WesternAlliance].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a join [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Property ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		
		
		--Exec dbo.[usp_502_Pull_FLANK_DATA]

		Update [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK]
		Set ToUse = NULL
		where ToUse is not null
		
		Update [zCust_WesternAlliance].[dbo].[B]
		Set B.ToUse = 'Y'
		--Select A.InputStartDate, B.* 
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] as A join [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK] as B on A.[INPUT Property ID] = B.RAW_ID
		where B.Doc_Src_Ind in ('D','M')
		and convert(date,B.RecordingDate) > A.INPUTSTARTDATE
		--Order by A.InputStartDate
		


		--Update B
		--Set B.ToUse = 'Y'
		----Select A.InputStartDate, B.* 
		--From x_Custom_OUTPUT_S13 as A join w_TransHist_FLANK as B on A.[INPUT Property ID] = B.RAW_ID
		--where B.Doc_Src_Ind in ('D','M')
		--and RecordingDate >= A.INPUTSTARTDATE
		----ORder by A.InputStartDate
		

		

--/****** Object:  Index [NonClst_RefId_RecDt_DocNum]    Script Date: 9/11/2022 9:35:31 AM ******/
--CREATE UNIQUE NONCLUSTERED INDEX [IDX_TH_FLANK] ON w_TransHist_FLANK_II
--(
--	RAW_ID ASC,
--	RecordingDate ASC,
--	Doc_Src_Ind ASC,
--	DocumentNbr asc
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		Select RAW_ID, REF_ID,RecordingDate, Doc_Src_Ind, DocumentNbr, count(*) From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Group by RAW_ID, REF_ID,RecordingDate, Doc_Src_Ind, DocumentNbr
		having count(*) > 1



		Truncate table w_TransHist_FLANK_II

		Insert into [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		Select * From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Order by RAW_ID, RecordingDate desc, Doc_Src_Ind, DocumentNbr


		Select RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr, count(*) From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		where ToUse like 'Y'
		Group by RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr
		having count(*) > 1

		
		--Select RAW_ID, RecordingDate, DocumentNbr, Doc_Src_Ind, BuyerBorrower, SellerLender, Value From w_TransHist_FLANK_II
		--where RAW_ID in ('1545710','1548490','1650509','1691608','1695944','1705247')
		--and ToUse like 'Y'
		--Order by RAW_ID,DocumentNbr


		Update [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		set RecordNumber = NULL

			UPDATE [zCust_WesternAlliance].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC,  Doc_ID desc, DocumentNbr DESC) AS RowNum
				FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID
			and ISNULL(t.DocumentNbr,'') = ISNULL(R.DocumentNbr,'')


			Select * From  [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
			where Documentnbr is null


		Select RAW_ID,RecordNumber,count(*) From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		WHERE ToUse = 'Y'
		Group by RAW_ID,RecordNumber
		having count(*) > 1



		Select RAW_ID, Max(RecordNumber) as MAXNUM From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID
		Order by Max(RecordNumber) desc

		Select * From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]


		Select * From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber = 1
		Order by DocumentNbr


		Select A.* From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II]
		WHERE ToUse = 'Y'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'Y'

	
		-----20251202 - Per EC - Cap record count at most recent 20----

		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Set [Nbr of Recordings] = NULL
		where convert(int,[Nbr of Recordings]) > 0


		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET a.[Nbr of Recordings] = case when b.NbrOfRecordings > 20 then 20 else b.NbrOfRecordings  end
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a JOIN 
		--(SELECT INPUTKEY,MAX(ROWNUM) NbrOfRecordings FROM DEEDS_TO_USE GROUP BY INPUTKEY) 
		(SELECT RAW_ID,MAX(convert(int,RecordNumber)) NbrOfRecordings FROM [zCust_WesternAlliance].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) 
		b
		on a.[INPUT Property ID] = b.RAW_ID

		Select MAX(convert(int,[Nbr of Recordings])) from [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]

		-----------------------20250421 - Per WL - Changed from Build Horizontal to build vertical-------

		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Record Number] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Recording Date] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Document Number] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Amount] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Doc Type] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer/Borrower] [varchar](250) NULL')
		----			EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller/Lender] [varchar](250) NULL')
			

		----				EXEC('UPDATE a
		----				SET 
		----				A.[Record Number] = B.[RecordNumber]
		----				,A.[Recording Date] = B.RecordingDate
		----				,A.[Document Number] = B.DocumentNbr
		----				,A.[Amount] = B.Value
		----				,A.[Doc Type] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
		----				,A.[Buyer/Borrower] = B.BuyerBorrower
		----				,A.[Seller/Lender] = B.SellerLender
		----				--,A.[Title Company] = B.TITLECONAME


		----				--Select B.* 
		----				FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
		----				on a.[INPUT Property ID] = b.RAW_ID
		----				WHERE B.[RecordNumber] = 1
		----				')
			
		----	 Select top 100 * From x_Custom_OUTPUT_S13


		----	----------------------------------------BUILD DOWN    ------------------------------------
		----IF (Select max(convert(int,[Nbr of Recordings])) from x_Custom_OUTPUT_S13) > 1
		----BEGIN
		
		----Truncate table dbo.BUILD_DOWN_COLUMNS

		
		----Insert into  dbo.BUILD_DOWN_COLUMNS 
		----Select * From (
		----Select 
		----Stuff(
  ----      (
  ----      Select Distinct ', [' +   B.Name + ']'
		---- From sys.tables as A join sys.columns as B on 
		----	A.OBJECT_ID = b.object_id
		----	where A.Name like 'x_Custom_OUTPUT_S13'
		----	and B.Name not in ('Record Number'
		----				,'Recording Date'
		----				,'Document Number'
		----				,'Amount'
		----				,'Doc Type'
		----				,'Buyer/Borrower'
		----				,'Seller/Lender')
		----				 For Xml Path('')
  ----      ), 1, 2, '') As Columns)A

		----Select * From dbo.BUILD_DOWN_COLUMNS


		
		----						Declare @BeginNbrOfTrans6 int
		----						Declare @EndNbrOfTrans6 int
		----						DECLARE @FIELDLIST3 nvarchar(max)
		----						DECLARE @FIELDLIST4 nvarchar(max)
		----						DECLARE @SQL6 nvarchar(max)

								

		----						Set @FIELDLIST3 = (Select * From dbo.BUILD_DOWN_COLUMNS)
		----						Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From dbo.BUILD_DOWN_COLUMNS)

		----						SET @BeginNbrOfTrans6 = 2
		----						Select @EndNbrOfTrans6 =   MAX(convert(int,[Nbr of Recordings])) FROM x_Custom_OUTPUT_S13

		----							WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
		----								BEGIN

				 
		----									DECLARE @RecNbr6 as varchar(5)
		----									SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

		----										EXEC('
		----										Insert into x_Custom_OUTPUT_S13(
		----										' +  @FIELDLIST3 + '

		----										  ,[Record Number]
		----											,[Recording Date]
		----											,[Document Number]
		----											,[Amount]
		----											,[Doc Type]
		----											,[Buyer/Borrower]
		----											,[Seller/Lender])

		----											  Select 
		----									 ' +  @FIELDLIST4 + '

		----										,B.[RecordNumber]
		----										,B.RecordingDate
		----										,B.DocumentNbr
		----										,B.Value
		----										,case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
		----										,B.BuyerBorrower
		----										, B.SellerLender
												
		----										--Select B.* 
		----										FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
		----										on a.[INPUT Property ID] = b.RAW_ID
		----										WHERE B.[RecordNumber] = ''' + @BeginNbrOfTrans6 + '''
		----										AND A.[Record Number] = ''1''

											
		----								')
										
										
												
		----								SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
		----								END

		----	END
										
		----				EXEC('UPDATE a
		----				SET 
		----				A.[Doc Type] = B.[CodeDesc]
		----				--Select B.*
		----				FROM x_Custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
		----				on A.[Doc Type] = b.DocTypeID
						
		----				')


		----	--Select [Doc Type], count(*) From x_Custom_OUTPUT_S13
		----	--where [Nbr of Recordings] > 0
		----	--Group by [Doc Type]
		----	--Order by [Doc Type]


		------ Select top 100 [INPUT Property ID], [Nbr of Recordings], [REcord Number]
		------ ,[Recording Date], [Document Number], Amount, [Doc Type], [Buyer/Borrower], [Seller/Lender]
		------ From x_Custom_OUTPUT_S13
		------Order by convert(int,[Nbr of Recordings]) desc


		 
		------ ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = MAX(convert(int,[Nbr of Recordings])) FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Document Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer1/Borrower1_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer2/Borrower2_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller1/Lender_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller2_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Title Company_' + @RecNbr + '] [varchar](250) NULL')



						EXEC('UPDATE a
						SET 
						A.[Record Number_' + @RecNbr + '] = ''' + @RecNbr + '''
						,A.[Recording Date_' + @RecNbr + '] = B.RecordingDate
						,A.[Document Number_' + @RecNbr + '] = B.DocumentNbr
						,A.[Amount_' + @RecNbr + '] = B.Value
						,A.[Doc Type_' + @RecNbr + '] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
						,A.[Buyer1/Borrower1_' + @RecNbr + '] = B.BuyerBorrower1
						,A.[Buyer2/Borrower2_' + @RecNbr + '] = B.BuyerBorrower2
						,A.[Seller1/Lender_' + @RecNbr + '] = B.SellerLender1
						,A.[Seller2_' + @RecNbr + '] = B.SellerLender2
						--,A.[Title Company_' + @RecNbr + '] = B.TITLECONAME


						--Select B.* 
						FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
						on a.[INPUT Property ID] = b.RAW_ID
						WHERE B.[RecordNumber] = ' + @BeginNbrOfTrans + '
						')

						EXEC('UPDATE a
						SET 
						A.[Doc Type_' + @RecNbr + '] = B.[CodeDesc]
						--Select B.*
						FROM x_Custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
						on A.[Doc Type_' + @RecNbr + '] = b.DocTypeID
						WHERE A.[Record Number_' + @RecNbr + '] = ' + @BeginNbrOfTrans + '
						')

						
						


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 


		Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Order by convert(int,[Nbr of Recordings]) desc

		Select [INPUT Property ID], PROPERTYID, [INPUT Address],[Property Status] From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		where [Nbr of Recordings] is null
		and [Property Status] like 'Property Found'


		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		
		UPDATE [zCust_WesternAlliance].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] a join [zCust_WesternAlliance].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Property ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		---------------20240917 - Per EC Event Status = Has recording
		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Event Status] = CASE WHEN [Nbr of Recordings] > 0 
		THEN 'Event Found' ELSE 'Event Not Found' END


		Select [Mortgage Coverage Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Mortgage Coverage Status]

		Select [Deed Coverage Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Deed Coverage Status]


		Select [Address Standardization], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Address Standardization]

		Select [Property Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Event Status]

	

	  Select A.[INPUT Property ID], A.PROPERTYID, A.[Nbr of Recordings]
	  ,*
	  From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] as A 
	  where [Nbr of Recordings] > 0 
	  --and ISNULL([Document Number_001],'') like ''
	    Order by convert(int,[Nbr of Recordings]) desc


		Select *
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S13] as A 
		Order by convert(int,[Nbr of Recordings]) desc

	

			

END






