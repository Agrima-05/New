SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_501_STEP2] 
		
	
AS
BEGIN

	SET NOCOUNT ON;

					


				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @body5 NVARCHAR(MAX)
				DECLARE @body6 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @xml3 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 
				
				CASE WHEN (Select 
				case when 
				   (Select count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] with(NOLOCK)) < 450000 
				OR (Select count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] with(NOLOCK) where REF_ID is null) > 6000 
				OR (Select  count(*) FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] with(NOLOCK)	where DATE_ADDED = convert(Date,getdate())) = 0
				then 1 else 0 end as TOTAL) > 0 
							 
				
				then  'PROCTOR FINANCIAL - PROBLEM WITH PORTFOLIO!!! - ' + @Date 

				ELSE 'PROCTOR FINANCIAL - Portfolio Update counts - Starting DTDB Data pull - ' + @Date  END
				
				SET @body1 = '<html><body><H3>PROCTOR FINANCIAL - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> TOTAL  </th> <th> [MATCHED] </th> <th> NOT_MATCHED  </th></tr>' 
				
			

				SET @xml = 
				CAST(( 
					Select TOTAL as 'td','', [MATCHED] as 'td','', NOT_MATCHED  as 'td',''
					from (
					Select Count(*) as TOTAL
					,sum(case when REF_ID is not null then 1 else 0 end) as [MATCHED]
					,sum(case when REF_ID is null then 1 else 0 end) as NOT_MATCHED
					From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] with(NOLOCK)
					)A
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body2 = @body1 + @XML +'</table></body></html> <BR/><BR/>
				'

				
				SET @body3 = '<html><body><H3>PROCTOR FINANCIAL DELETES - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> DATE_DELETED  </th> <th> [TOTAL]   </th></tr>' 
				
			

				SET @xml2 = 
				CAST(( 
					Select DATE_DELETED as 'td','', TOTAL   as 'td',''
					from (
					Select top 5 DATE_DELETED, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR_DELETED] with(NOLOCK)
					Group by DATE_DELETED
					Order by DATE_DELETED desc 
					)A
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


					
				SET @body4 = '<html><body><H3>PROCTOR FINANCIAL ADDS - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> DATE_ADDED  </th> <th> [TOTAL]   </th></tr>' 
				
			

				SET @xml3 = 
				CAST(( 
					Select DATE_ADDED as 'td','', TOTAL   as 'td',''
					from (
					Select top 5 DATE_ADDED, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] with(NOLOCK)
					Group by DATE_ADDED
					Order by DATE_ADDED desc 
					)A
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body5 = 
				@body2 + '</table></body></html> <BR/><BR/>
				' + @body4 + @XML3 + '</table></body></html> <BR/><BR/>
				' + @body3 + @XML2 +'</table></body></html> <BR/><BR/>
								
				'



				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body5 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

		
				--Select 
				--case when (Select count(*) as TOTAL From [INPUT_MONITOR] with(NOLOCK)) < 450000 
				--OR (Select count(*) as TOTAL From [INPUT_MONITOR] with(NOLOCK) where REF_ID is null) > 3000 
				--OR (Select  count(*) FROM [INPUT_MONITOR] with(NOLOCK)	where DATE_ADDED = convert(Date,getdate())) = 0
				 
				--then 1 else 0 end as ASP_COUNT

			
END



