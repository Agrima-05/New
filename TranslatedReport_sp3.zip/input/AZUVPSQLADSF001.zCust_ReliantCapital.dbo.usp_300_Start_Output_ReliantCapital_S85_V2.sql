SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_ReliantCapital].[dbo].[usp_300_Start_Output_ReliantCapital_S85_V2]


AS
BEGIN
	
	SET NOCOUNT ON;

	

	----20240716 - Per EC - ONLY run the  "-" records through S85---


		DROP TABLE [dbo].[x_Custom_OUTPUT_S85_V2]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S85_V2](
			[FIPS][varchar](5)NULL,
			[PROPERTYID][varchar](250)NULL,
			
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT Last Name][varchar](250)NULL,
			[INPUT First Name][varchar](250)NULL,
			[INPUT Middle Name][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT Property State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Bankruptcy Record Count][varchar](250)NULL,
			
			--------Build Vertically - 20260302
			[Match Code][varchar](250)NULL,
			[Court ID][varchar](250)NULL,
			[Case Number][varchar](250)NULL,
			[Case Type][varchar](250)NULL,
			[Unique Case ID][varchar](250)NULL,
			[Other Case Number][varchar](250)NULL,
			[Judges Initials][varchar](250)NULL,
			[Filing Types][varchar](250)NULL,
			[Action Type ID][varchar](250)NULL,
			[Current Chapter][varchar](250)NULL,
			[Previous Chapter][varchar](250)NULL,
			[Original Chapter][varchar](250)NULL,
			[Filing Date][varchar](250)NULL,
			[Release Date][varchar](250)NULL,
			[Assets][varchar](250)NULL,
			[Assets Available for Distribution][varchar](250)NULL,
			[Sch 341 Date][varchar](250)NULL,
			[Sch 341 Time][varchar](250)NULL,
			[POC Date][varchar](250)NULL,
			[Alias Type][varchar](250)NULL,
			[Association Code][varchar](250)NULL,
			[Defendant Type][varchar](250)NULL,
			[Defendant Name][varchar](250)NULL,
			[Defendant Name Generation Code][varchar](250)NULL,
			[Defendant Street Address][varchar](250)NULL,
			[Defendant City][varchar](250)NULL,
			[Defendant State][varchar](250)NULL,
			[Defendant Zip Code][varchar](250)NULL,
			[Law Firm / Attorney Name, Trustee Name][varchar](250)NULL,
			[Attorney Name][varchar](250)NULL,
			[Attorney Phone][varchar](250)NULL,
			[Attorney Address][varchar](250)NULL,
			[Attorney City][varchar](250)NULL,
			[Attorney State][varchar](250)NULL,
			[Attorney Zip][varchar](250)NULL,

			

			----------INTERNAL---------
			[Start Date][varchar](250)Null,
			[MAX_BKY_RECDATE]	[varchar](250)NULL,
			[Record #]	[varchar](250)NULL
			

					
			
		) ON [PRIMARY]

		

	
		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2] (
			[INPUT Unique ID],
			[INPUT Last Name],
			[INPUT First Name],
			[INPUT Middle Name],
			[INPUT Address],
			[INPUT City],
			[INPUT Property State],
			[INPUT Zip],

			FIPS,
			PROPERTYID,
			[MAX_BKY_RECDATE],
			[Start Date]  )
	
		Select 	
		[INPUTKEY]
		,[Borrower Last Name]
		,[Borrower First Name]
		,[Borrower Middle Initial]
		,[Address]
		,[City]
		,[State]
		,[ZipCODE]
		,FIPS
		,[PROPERTYID]
		,MAX_BKY_RECDATE
		,convert(Date,[Monitoring START DATE])
		--Select * 
	   
	   FROM [zCust_ReliantCapital].[dbo].[INPUT_MONITOR]
		where [Record Indicator] not like 'D'
		and [INPUTKEY] is not null
		and INPUTKEY like '%-%'
		--and DATE_RECEIVED = convert(Date,getdate())

		  
	  
	  Select top 100 * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S85_V2 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S85_V2 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[Input Unique ID] = c.RAW_ID

		

		--Update a
		--SET a.[Property Address] = c.FullStreetAddress
		--, a.[City] = c.City
		--, a.[State] = c.[State]
		--, a.[Zip Code] = c.Zip + c.Zip4
		--, a.[Report Date] = convert(date,GetDate())
		----, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S85_V2 a JOIN [dbo].a_ASP_IN_STD c
		--			ON a.[Input Unique ID] = c.RAW_ID

		UPdate [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		Set [Run Date] = convert(date,GetDate())


		
		EXEC [zCust_ReliantCapital].[dbo].[usp_100_GET_BankruptcyDATA]

		--Select * From MatchWork_I


	 	Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		Set [Bankruptcy Record Count] = NULL
		

	

		--Select * From x_Custom_OUTPUT_S85_V2


		UPDATE [zCust_ReliantCapital].[dbo].[a]
		SET a.[Bankruptcy Record Count] = 	b.NbrOfRecordings
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2] a JOIN 
			(SELECT INPUTKEY,MAX(convert(int,RowNbr)) NbrOfRecordings 
			FROM [zCust_ReliantCapital].[dbo].[MatchWork_I] GROUP BY INPUTKEY) b
		on a.[Input Unique ID] = b.INPUTKEY


		Select max(convert(int,[Bankruptcy Record Count])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]


		--Select B.Name From sys.tables as A join sys.columns as B on A.object_id = B.object_id
		--where A.Name like 'MatchWork_I'
		--Order by B.Name





		UPDATE [zCust_ReliantCapital].[dbo].[A]
		Set

		A.[Record #] = b.RowNbr
		,A.[Match Code] = b.MATCHTYPE
		,A.[Court ID] = b.[BKY_COURT_ID]
		,A.[Case Number] = b.[BKY_CASE_NBR]
		,A.[Case Type] = b.[BKY_CASE_TYPE]
		,A.[Unique Case ID] = b.[BKY_UNQ_CASE_ID]
		,A.[Other Case Number] = b.[BKY_OTHER_CASE_NBR]
		,A.[Judges Initials] = b.[BKY_JUDGE_INIT]
		,A.[Filing Types] = b.[BKY_FILING_TYPE]
		,A.[Action Type ID] = b.[BKY_ACTION_TYPE]
		,A.[Current Chapter] = b.[BKY_CURR_CHAP]
		,A.[Previous Chapter] = b.[BKY_PREV_CHAP]
		,A.[Original Chapter] = b.[BKY_ORIG_CHAP]
		,A.[Filing Date] = Case WHEN ltrim(rtrim([BKY_FILING_DATE])) LIKE '00000000' THEN NULL ELSE ltrim(rtrim([BKY_FILING_DATE])) END
		,A.[Release Date] = Case WHEN ltrim(rtrim([BKY_RLSE_DATE])) LIKE '00000000' THEN NULL ELSE ltrim(rtrim([BKY_RLSE_DATE])) END
		,A.[Assets] = b.[BKY_ASSETS]
		,A.[Assets Available for Distribution] = b.[BKY_ASSETS_IND]
		,A.[Sch 341 Date] = b.[BKY_SCH341_DATE]
		,A.[Sch 341 Time] = b.[BKY_SCH341_TIME]
		,A.[POC Date] = b.[BKY_POC_DATE]
		,A.[Alias Type] = b.[BKY_ALIAS_TYPE]
		,A.[Association Code] = b.[BKY_ASOC_CODE]
		,A.[Defendant Type] = b.[BKY_DEF_TYPE]
		,A.[Defendant Name] = b.[BKY_DEF_NAME]
		,A.[Defendant Name Generation Code] = b.[BKY_DEF_NAME_GENCD]
		,A.[Defendant Street Address] = b.[BKY_DEF_ST_ADD]
		,A.[Defendant City] = b.[BKY_DEF_CITY]
		,A.[Defendant State] = b.[BKY_DEF_STATE]
		,A.[Defendant Zip Code] = b.[BKY_DEF_ZIP]
		,A.[Law Firm / Attorney Name, Trustee Name] = b.[BKY_TRSTE_NAME]
		,A.[Attorney Name] = b.[BKY_ATRNY_NAME]
		,A.[Attorney Phone] = b.[BKY_ATRNY_PHONE]
		,A.[Attorney Address] = b.[BKY_ATRNY_ADD]
		,A.[Attorney City] = b.[BKY_ATRNY_CITY]
		,A.[Attorney State] = b.[BKY_ATRNY_STATE]
		,A.[Attorney Zip] = b.[BKY_ATRNY_ZIP]


		--Select B.* 
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2] a JOIN 
		[zCust_ReliantCapital].[dbo].[MatchWork_I] as B on 
		a.[Input Unique ID] = b.INPUTKEY
		where B.RowNbr = 1



		Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		where [Bankruptcy Record Count] > 0
		order by [Input Unique ID],[Record #]



		
		----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[Bankruptcy Record Count])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ReliantCapital].[sys].[tables] as A join [zCust_ReliantCapital].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S85_V2'
			and B.Name not in ('Record #','Match Code','Court ID','Case Number','Case Type','Unique Case ID','Other Case Number','Judges Initials',
'Filing Types','Action Type ID','Current Chapter','Previous Chapter','Original Chapter','Filing Date','Release Date','Assets','Assets Available for Distribution',
'Sch 341 Date','Sch 341 Time','POC Date','Alias Type','Association Code','Defendant Type','Defendant Name','Defendant Name Generation Code','Defendant Street Address','Defendant City',
'Defendant State','Defendant Zip Code','Law Firm / Attorney Name, Trustee Name','Attorney Name','Attorney Phone','Attorney Address','Attorney City','Attorney State',
'Attorney Zip')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.BUILD_DOWN_COLUMNS


				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])

								


								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[Bankruptcy Record Count])) FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S85_V2(
												' +  @FIELDLIST3 + '

												 ,[Record #]
												,[Match Code] 
												,[Court ID] 
												,[Case Number] 
												,[Case Type] 
												,[Unique Case ID] 
												,[Other Case Number] 
												,[Judges Initials] 
												,[Filing Types] 
												,[Action Type ID] 
												,[Current Chapter] 
												,[Previous Chapter] 
												,[Original Chapter] 
												,[Filing Date] 
												,[Release Date] 
												,[Assets] 
												,[Assets Available for Distribution] 
												,[Sch 341 Date] 
												,[Sch 341 Time] 
												,[POC Date] 
												,[Alias Type] 
												,[Association Code] 
												,[Defendant Type] 
												,[Defendant Name] 
												,[Defendant Name Generation Code] 
												,[Defendant Street Address] 
												,[Defendant City] 
												,[Defendant State] 
												,[Defendant Zip Code] 
												,[Law Firm / Attorney Name, Trustee Name] 
												,[Attorney Name] 
												,[Attorney Phone] 
												,[Attorney Address] 
												,[Attorney City] 
												,[Attorney State] 
												,[Attorney Zip] 



												 )
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												, B.Rownbr
												, b.MATCHTYPE
												, b.[BKY_COURT_ID]
												, b.[BKY_CASE_NBR]
												, b.[BKY_CASE_TYPE]
												, b.[BKY_UNQ_CASE_ID]
												, b.[BKY_OTHER_CASE_NBR]
												, b.[BKY_JUDGE_INIT]
												, b.[BKY_FILING_TYPE]
												, b.[BKY_ACTION_TYPE]
												, b.[BKY_CURR_CHAP]
												, b.[BKY_PREV_CHAP]
												, b.[BKY_ORIG_CHAP]
												, Case WHEN ltrim(rtrim([BKY_FILING_DATE])) LIKE ''00000000'' THEN NULL ELSE ltrim(rtrim([BKY_FILING_DATE])) END
												, Case WHEN ltrim(rtrim([BKY_RLSE_DATE])) LIKE ''00000000'' THEN NULL ELSE ltrim(rtrim([BKY_RLSE_DATE])) END
												, b.[BKY_ASSETS]
												, b.[BKY_ASSETS_IND]
												, b.[BKY_SCH341_DATE]
												, b.[BKY_SCH341_TIME]
												, b.[BKY_POC_DATE]
												, b.[BKY_ALIAS_TYPE]
												, b.[BKY_ASOC_CODE]
												, b.[BKY_DEF_TYPE]
												, b.[BKY_DEF_NAME]
												, b.[BKY_DEF_NAME_GENCD]
												, b.[BKY_DEF_ST_ADD]
												, b.[BKY_DEF_CITY]
												, b.[BKY_DEF_STATE]
												, b.[BKY_DEF_ZIP]
												, b.[BKY_TRSTE_NAME]
												, b.[BKY_ATRNY_NAME]
												, b.[BKY_ATRNY_PHONE]
												, b.[BKY_ATRNY_ADD]
												, b.[BKY_ATRNY_CITY]
												, b.[BKY_ATRNY_STATE]
												, b.[BKY_ATRNY_ZIP]



												
										    --Select B.Rownbr 	
											FROM x_Custom_OUTPUT_S85_V2 a JOIN 
											MatchWork_I as B on 
											a.[Input Unique ID] = b.INPUTKEY
											WHERE B.Rownbr = ''' + @BeginNbrOfTrans6 + '''
											AND A.[Record #] = ''1''
										
										
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

		

			
		--Declare @BeginNbrOfTrans int
		--Declare @EndNbrOfTrans int

		--SET @BeginNbrOfTrans = 1
		--Select @EndNbrOfTrans = case when max(convert(int,[Bankruptcy Record Count])) is null then 1 else  
		--max(convert(int,[Bankruptcy Record Count])) end FROM x_Custom_OUTPUT_S85_V2
		

		--	WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
		--		BEGIN
				 
		--			DECLARE @RecNbr as varchar(5)
		--			SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Record #_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Match Code_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Court ID_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Case Number_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Case Type_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Unique Case ID_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Other Case Number_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Judges Initials_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Filing Types_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Action Type ID_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Current Chapter_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Previous Chapter_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Original Chapter_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Filing Date_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Release Date_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Assets_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Assets Available for Distribution_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Sch 341 Date_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Sch 341 Time_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [POC Date_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Alias Type_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Association Code_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant Type_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant Name_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant Name Generation Code_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant Street Address_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant City_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant State_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Defendant Zip Code_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Law Firm / Attorney Name, Trustee Name_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney Name_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney Phone_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney Address_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney City_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney State_' + @RecNbr + '] [varchar](250) NULL')
		--			EXEC('ALTER Table x_Custom_OUTPUT_S85_V2 ADD [Attorney Zip_' + @RecNbr + '] [varchar](250) NULL')

				
		--			EXEC('UPDATE a
		--			SET 
		--			A.[Record #_' + @RecNbr + '] = b.RowNbr
		--			,A.[Match Code_' + @RecNbr + '] = b.MATCHTYPE
		--			,A.[Court ID_' + @RecNbr + '] = b.[BKY_COURT_ID]
		--			,A.[Case Number_' + @RecNbr + '] = b.[BKY_CASE_NBR]
		--			,A.[Case Type_' + @RecNbr + '] = b.[BKY_CASE_TYPE]
		--			,A.[Unique Case ID_' + @RecNbr + '] = b.[BKY_UNQ_CASE_ID]
		--			,A.[Other Case Number_' + @RecNbr + '] = b.[BKY_OTHER_CASE_NBR]
		--			,A.[Judges Initials_' + @RecNbr + '] = b.[BKY_JUDGE_INIT]
		--			,A.[Filing Types_' + @RecNbr + '] = b.[BKY_FILING_TYPE]
		--			,A.[Action Type ID_' + @RecNbr + '] = b.[BKY_ACTION_TYPE]
		--			,A.[Current Chapter_' + @RecNbr + '] = b.[BKY_CURR_CHAP]
		--			,A.[Previous Chapter_' + @RecNbr + '] = b.[BKY_PREV_CHAP]
		--			,A.[Original Chapter_' + @RecNbr + '] = b.[BKY_ORIG_CHAP]
		--			,A.[Filing Date_' + @RecNbr + '] = Case WHEN ltrim(rtrim([BKY_FILING_DATE])) LIKE ''00000000'' THEN NULL ELSE ltrim(rtrim([BKY_FILING_DATE])) END
		--			,A.[Release Date_' + @RecNbr + '] = Case WHEN ltrim(rtrim([BKY_RLSE_DATE])) LIKE ''00000000'' THEN NULL ELSE ltrim(rtrim([BKY_RLSE_DATE])) END
		--			,A.[Assets_' + @RecNbr + '] = b.[BKY_ASSETS]
		--			,A.[Assets Available for Distribution_' + @RecNbr + '] = b.[BKY_ASSETS_IND]
		--			,A.[Sch 341 Date_' + @RecNbr + '] = b.[BKY_SCH341_DATE]
		--			,A.[Sch 341 Time_' + @RecNbr + '] = b.[BKY_SCH341_TIME]
		--			,A.[POC Date_' + @RecNbr + '] = b.[BKY_POC_DATE]
		--			,A.[Alias Type_' + @RecNbr + '] = b.[BKY_ALIAS_TYPE]
		--			,A.[Association Code_' + @RecNbr + '] = b.[BKY_ASOC_CODE]
		--			,A.[Defendant Type_' + @RecNbr + '] = b.[BKY_DEF_TYPE]
		--			,A.[Defendant Name_' + @RecNbr + '] = b.[BKY_DEF_NAME]
		--			,A.[Defendant Name Generation Code_' + @RecNbr + '] = b.[BKY_DEF_NAME_GENCD]
		--			,A.[Defendant Street Address_' + @RecNbr + '] = b.[BKY_DEF_ST_ADD]
		--			,A.[Defendant City_' + @RecNbr + '] = b.[BKY_DEF_CITY]
		--			,A.[Defendant State_' + @RecNbr + '] = b.[BKY_DEF_STATE]
		--			,A.[Defendant Zip Code_' + @RecNbr + '] = b.[BKY_DEF_ZIP]
		--			,A.[Law Firm / Attorney Name, Trustee Name_' + @RecNbr + '] = b.[BKY_TRSTE_NAME]
		--			,A.[Attorney Name_' + @RecNbr + '] = b.[BKY_ATRNY_NAME]
		--			,A.[Attorney Phone_' + @RecNbr + '] = b.[BKY_ATRNY_PHONE]
		--			,A.[Attorney Address_' + @RecNbr + '] = b.[BKY_ATRNY_ADD]
		--			,A.[Attorney City_' + @RecNbr + '] = b.[BKY_ATRNY_CITY]
		--			,A.[Attorney State_' + @RecNbr + '] = b.[BKY_ATRNY_STATE]
		--			,A.[Attorney Zip_' + @RecNbr + '] = b.[BKY_ATRNY_ZIP]


		--			--Select B.* 
		--			FROM x_Custom_OUTPUT_S85_V2 a JOIN 
		--			MatchWork_I as B on 
		--			a.[Input Unique ID] = b.INPUTKEY
		--			where B.RowNbr = ' + @BeginNbrOfTrans + '') 

					

		--			SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
		--		END


		


		Update  [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		Set [Event Status] = case when [Bankruptcy Record Count] > 0 then  'Event Found' else 'Event Not Found'
		end
		


		Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		where [Bankruptcy Record Count] > 0 
		

		Select [Event Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S85_V2]
		Group by [Event Status]

	

END





