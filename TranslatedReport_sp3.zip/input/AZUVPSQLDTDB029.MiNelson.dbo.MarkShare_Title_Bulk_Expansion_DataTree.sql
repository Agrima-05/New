/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_Bulk_Expansion_DataTree | type=P */








-- ===============================================================================================
-- Author:		My Phan
-- Create date: 1/14/2020
-- Description:	Create MarkShareTitle_Expansion_DATATree
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_Bulk_Expansion_DataTree]
                
AS 


SET NOCOUNT ON

BEGIN
 
 

/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] ;
     

select [DeedID], [DeedSequence],[FIPS], [Date],[MTG1_PRIVATE_PARTY_LENDER], Rundate,
[FMT_MTG1_DOC_NBR] ,
[FMT_MTG2_DOC_NBR] ,
FMT_MTG1_Book_Page ,
FMT_MTG2_Book_Page ,
 Ref_ID
into    [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
from  [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental_save]
--where rundate =  convert (varchar(10),GETDATE(), 112)


ALTER TABLE [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
ADD
    Officer_NMLS_ID nvarchar(64) NULL,
    Officer_Name nvarchar(254) NULL,
    Lender_NMLS_ID nvarchar(64) NULL,
    Lender_Name nvarchar(254) NULL,
    Lender_Street nvarchar(254) NULL,
    Lender_Street2 nvarchar(254) NULL,
    Lender_City nvarchar(254) NULL,
    Lender_State nvarchar(254) NULL,
    Lender_PostalCode nvarchar(254) NULL,
    Lender_Country nvarchar(254) NULL,
    Broker_NMLS_ID nvarchar(64) NULL,
    Broker_Name nvarchar(254) NULL,
    Broker_Street nvarchar(254) NULL,
    Broker_Street2 nvarchar(254) NULL,
    Broker_City nvarchar(254) NULL,
    Broker_State nvarchar(254) NULL,
    Broker_PostalCode nvarchar(254) NULL,
    Broker_Country nvarchar(254) NULL,
    CBSA_Code nvarchar(255) NULL,
    Owner_Occupied varchar(1) NULL,
    Latitude numeric(10,6) NULL,
    Longitude numeric(10,6) NULL,
    [Loan Type] varchar(12) NULL,
    Match_Flag varchar(1) NULL,
    Update_Flag varchar(1) NULL;

-------adding new fields
--alter table  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
--add Mtg_DeedID int
--alter table Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
--add UpdateDate varchar(8)


----Bk Data

--- adding index fips and deedid next time

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](fips,deedid)


--- step 2


-----------------------------rematch-----------------------------------------

alter table  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
add RoleID int


------ step 3



drop index ix_a on [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
create index ix_a on   [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](deedid, deedsequence)
--create index ix_a on  [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch] (deedid, deedsequence)


update [MiNelson].[dbo].[a]
set a.RoleID = b.RoleID
from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] a
inner join [MiNelson].[dbo].[NMLS_Rematch] b
on a.deedid = b.deedid and a.deedsequence = b._seq

select count(*) from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
where roleid is not null

 

--- updating nmls infor



--------------------------------------------------------------------------------------


----------------------------Adding NMLS data from Deed table ------------------

 update [MiNelson].[dbo].[b]
  set b.Officer_NMLS_ID = a.[NMLSAgentId_1],
b.Officer_Name = a.[NMLSAgentName_1],
b.Lender_NMLS_ID =a.[NMLSLenderId_1],
b.Lender_Name =a.[NMLSLenderName_1],
b.Broker_NMLS_ID = a.[NMLSBrokerId_1],
b.Broker_Name = a.[NMLSBrokerName_1],
b.Match_Flag = 'D'
from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
 inner join [Deed].[dbo].[deed] a
 on a.deedid = b.deedid 
where (a.[NMLSAgentId_1] is not null 
	or a.[NMLSAgentName_1] is not null
	or a.[NMLSLenderId_1] is not null
	or a.[NMLSLenderName_1] is not null
	or a.[NMLSBrokerId_1] is not null
	or a.[NMLSBrokerName_1] is not null)
 and b.DeedSequence = 1


    update [MiNelson].[dbo].[b]
	set  b.Officer_NMLS_ID = a.[NMLSAgentId_2],
b.Officer_Name = a.[NMLSAgentName_2],
b.Lender_NMLS_ID =a.[NMLSLenderId_2],
b.Lender_Name =a.[NMLSLenderName_2],
b.Broker_NMLS_ID = a.[NMLSBrokerId_2],
b.Broker_Name = a.[NMLSBrokerName_2],
b.Match_Flag = 'D'

  FROM [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
  inner join [deed].[dbo].[deed] a
  on a.deedid = b.deedid
 where (a.[NMLSAgentId_2] is not null 
	or a.[NMLSAgentName_2] is not null
	or a.[NMLSLenderId_2] is not null
	or a.[NMLSLenderName_2] is not null
	or a.[NMLSBrokerId_2] is not null
	or a.[NMLSBrokerName_2] is not null)
 and b.DeedSequence = 2


  update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = 'P'

FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
on a.RoleID = B.RoleID
where (a_NMLSID is not null
	or  a.a_Name is not null
	or a.l_NMLSID is not null
	or  a.l_name is not null
	or a.b_NMLSID is not null
	or a.b_Name is not null
	) and b.Match_Flag is null

--- matching firts mtg doc

update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '1'
--b.rundate = '20181130'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.documentnumber = b.FMT_MTG1_DOC_NBR
where b.FMT_MTG1_DOC_NBR <> '' and match_flag is null


--- match 2nd mtg


update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '2'
--b.rundate = '20181130'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.documentnumber = b.FMT_MTG2_DOC_NBR
where b.Match_flag is null and b.FMT_MTG2_DOC_NBR <> ''


---- Book ana Page 1

update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '3'
--b.rundate = '20181130'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.documentnumber = b.FMT_MTG1_Book_Page and a.deedid = b.deedid
where  b.Match_flag is null and b.FMT_MTG1_Book_Page <> ''
 



---- Book and Page 2

update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '4'
--b.rundate = '20181130'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.documentnumber = b.FMT_MTG2_Book_Page and a.deedid = b.deedid
where b.Match_flag is null and b.FMT_MTG2_Book_Page <> ''


-------using altdocumentnumber

update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '5'--,
--b.rundate = '20190213'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
on a.fips = b.fips and a.altdocumentnumber =  b.FMT_MTG1_DOC_NBR and a.deedid = b.deedid
where b.Match_flag is null and b.FMT_MTG1_DOC_NBR <> ''


update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '6'--,
--b.rundate = '20190213'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.altdocumentnumber  = b.FMT_MTG2_DOC_NBR
where b.Match_flag is null and b.FMT_MTG2_DOC_NBR <> ''



update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '7'--,
--b.rundate = '20190213'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
on a.fips = b.fips and a.altdocumentnumber = b.FMT_MTG1_Book_Page and a.deedid = b.deedid
where b.Match_flag is null and b.FMT_MTG1_Book_Page <> ''



---- Book and Page 2

update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = '8'--,
--b.rundate = '20190213'
--select count(*)
FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]  b
on a.fips = b.fips and a.altdocumentnumber = b.FMT_MTG2_Book_Page and a.deedid = b.deedid
where b.Match_flag is null and b.FMT_MTG2_Book_Page <> '' 


------ Adding Lender and broker addresses

			--drop index ix_a on   Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

			--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](Lender_NMLS_ID)

			--update a
			-- set a.Lender_Street = b.[Street]
			--	  ,a.Lender_Street2 = b.[Street2]
			--	  ,a.Lender_City = b.[City]
			--	  ,a.Lender_State = b.[State]
			--	  ,a.Lender_PostalCode = b.[PostalCode]
			--	  ,a.Lender_Country =b.[Country]
			--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
			--inner join [MiNelson].[nmls].[NMLS_Src_Company] b
			--on a.Lender_NMLS_ID = b.[NMLSID]


			--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

			--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](Broker_NMLS_ID)

			--update a
			-- set   a.Broker_Street = b.[Street]
			--	  ,a.Broker_Street2 = b.[Street2]
			--	  ,a.Broker_City = b.[City]
			--	  ,a.Broker_State = b.[State]
			--	  ,a.Broker_PostalCode = b.[PostalCode]
			--	  ,a.Broker_Country =b.[Country]
			--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
			--inner join [MiNelson].[nmls].[NMLS_Src_Company] b
			--on a.Broker_NMLS_ID = b.[NMLSID]





 ---- update lender_name 

 
 select Lender_NMLS_ID, count (*)
  from 
  (select distinct  Lender_NMLS_ID, Lender_Name
   from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
   )x
   group by     Lender_NMLS_ID
	having count (*) > 1

	--select * from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] b
 --where Lender_NMLS_ID in (	1474949,1045356)


 Update [MiNelson].[dbo].[a]
 set a.Lender_Name = b.Name
 from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
 on a.Lender_NMLS_ID = b.[NMLSID]
 where (a.Lender_Name <> b.Name) or (a.Lender_Name is null and b.Name is not null)

 --- update broker_name

 	 select [Broker_NMLS_ID], count (*)
  from 
  (select distinct  [Broker_NMLS_ID], [Broker_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
   )x
   group by     [Broker_NMLS_ID]
	having count (*) > 1


update [MiNelson].[dbo].[a]
set a.[Broker_Name] = b.Name

from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
 on a.[Broker_NMLS_ID] = b.[NMLSID]
 where (a.[Broker_Name] <> b.Name) or (a.[Broker_Name] is null and b.Name is not null)


 ----- update officer name
 

	 select [Officer_NMLS_ID], count (*)
  from 
  (select distinct  [Officer_NMLS_ID], [Officer_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
 --  where  [Officer_NMLS_ID] =1018455
   )x
   group by     [Officer_NMLS_ID]
	having count (*) > 1


	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp] ;

		 select [Officer_NMLS_ID], count (*) as count
		 into  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp]
  from 
  (select distinct  [Officer_NMLS_ID], [Officer_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
 --  where  [Officer_NMLS_ID] =1018455
   )x
   group by     [Officer_NMLS_ID]
	having count (*) > 1


	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp1]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] ;

			  
select  [Officer_NMLS_ID],  [Officer_Name], count (*) as cnt 
into  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1]
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
where  [Officer_NMLS_ID] in

(select [Officer_NMLS_ID] from  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp]
where [Officer_NMLS_ID] is not null
)
group by [Officer_NMLS_ID],  [Officer_Name]
order by 1

/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp2]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] ;

select [Officer_NMLS_ID],  [Officer_Name], cnt,
 row_number() over(partition by [Officer_NMLS_ID]  order by cnt desc) as [rn]
into [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] 
 from [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] 

 select  a.[Officer_NMLS_ID],  b.[Officer_NMLS_ID], a.[Officer_Name] , b.[Officer_Name] ,b.*  from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
 inner join [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2]  b
 on a.[Officer_NMLS_ID] = b.[Officer_NMLS_ID] and b.rn = 1
 and a.[Officer_Name] <> b.[Officer_Name]

 
 update [MiNelson].[dbo].[a]
 set  a.[Officer_Name] = b.[Officer_Name]   
 from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
 inner join [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] b
 on a.[Officer_NMLS_ID] = b.[Officer_NMLS_ID] and b.rn = 1
 and a.[Officer_Name] <> b.[Officer_Name]

 	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp] ;
		/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp1]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] ;
	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp2]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] ;


 -----

drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](fips)

---stop here

update [MiNelson].[dbo].[t]
set t.CBSA_code =  c.CBSA_Code
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] t
left join [Minelson].[Stats].[CBSA_Codes] c on t.FIPS = c.fips



drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk](fips,REF_ID )

update [MiNelson].[dbo].[t]
set t.Owner_occupied = p.Absentee_Own_Status 
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] t
left join [Assr].[dbo].[assr] p with (Nolock) on
t.Fips = p.Fips and   t.REF_ID = p.REF_ID 
 

 

update [MiNelson].[dbo].[t]
set t.Latitude = b.Latitude, 
t.Longitude = b.Longitude
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] t
inner join  [Addr].[dbo].[CL_Address_Base] b with (nolock) on t.fips = b.fips and t.ref_id = b.ref_id and b.Address_Type = 'S'




---- Adding USDA loan type  -----> 26,125

update [MiNelson].[dbo].[a]
set a.[Loan type] = 'USDA'
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a
inner join [Minelson].[mktshr].[TitleMarketShare] b
on a.deedid = b.Deedid and a.DeedSequence = b.DeedSequence
where  (b.lender like 'USDA%' 
    or b.lender like '%DEP%AGRIC%'
    or b.lender like 'FARM SE%'  
    or b.lender like 'FARM SV%'  
    or b.lender like '% FSA%'  
    or b.lender like 'RURAL H%' 
    or b.lender like 'USA%RHS%')
	and b.[loan type] not in ( 'VA', 'FHA')


------ Adding Listing Incremental FMA


--alter table Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]
--add Listing_ID int


------- step 4

--select count(*) from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

----select * from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]

--update a
--set a.Listing_ID = l.listing_ID
--from  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] a
--inner join FA_Listing.dbo.Listing l  on a.ref_id = l.Ref_id and a.date = l.sold_date_std and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
--where l.MLS_STATUS_STD = 'sold'

--update a
--set a.Listing_ID = l.listing_ID
--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] a
--inner join FA_Listing.dbo.Listing l on a.ref_id = l.Ref_id and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
--inner join ART.dbo.RT_Recorder r on RECORDER_ID+1000000000=a.DeedID and r.FIPS=a.FIPS and isdate(SR_DATE_FILING)=1
--where l.MLS_STATUS_STD = 'sold'
--and a.Date=cast(SR_DATE_FILING as Date)
--and a.DeedID>1000000000
--and a.Listing_Id is null

--update a
--set a.Listing_ID = l.listing_ID
--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] a
--inner join FA_Listing.dbo.Listing l on a.ref_id = l.Ref_id and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
--inner join Deed.dbo.Deed d on d.DeedID=a.DeedID and d.FIPS=a.FIPS and SALE_DATE is not null
--where l.MLS_STATUS_STD = 'sold'
--and a.Date=SALE_DATE
--and a.DeedID<1000000000
--and a.Listing_Id is null

----- adding match by saledate 11/16/2022

--update a
--set a.Listing_ID = l.listing_ID
--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk] a
--inner join FA_Listing.dbo.Listing l on a.ref_id = l.Ref_id 
--and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
--inner join Deed.dbo.Deed d on d.DeedID=a.DeedID and d.FIPS=a.FIPS and SALE_DATE is not null
--where l.MLS_STATUS_STD = 'sold'
--and d.SALE_DATE =l.sold_date_std
--and a.DeedID<1000000000
--and a.Listing_Id is null
--and d.TRANSACTION_TYPE in  ('1', '3')

----create index ix_a on  Minelson.[dbo].[TitleMarketShare_Listing_temp]  (Deedid, Deedsequence,listing_id)


--if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]') is not null
--    drop table  Minelson.[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk] ;


--SELECT 
--a.*,
--RTRIM(ISNULL(LTRIM(Substring(addr.HouseNumber, 1, LEN(addr.HouseNumber)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Direction, 1, LEN(addr.Direction)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Name, 1, LEN(addr.Street_Name)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Type, 1, LEN(addr.Street_Type)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Post_Direction, 1, LEN(addr.Post_Direction)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Unit, 1, LEN(addr.Unit)) + ' '), '')) AS [Property Address]
--       ,RTRIM(ISNULL(addr.City, '')) AS [Property City]
--       ,RTRIM(ISNULL(addr.STD_State, '')) AS [Property State]
--       ,RTRIM(ISNULL(addr.Zip, '')) AS [Property Zip]
--       ,RTRIM(ISNULL(addr.Plus4, '')) AS [Property Zip + 4] 
--,MLS_STATUS_STD
--,MLS_LIST_DATE_STD
--,MLS_Listing_Number
--,agentstd.MLS_LISTING_AGENT_NAME
--,agentstd.MLS_LISTING_AGENT_EMAIL
--,agentstd.AGENT_PHONE
--,officestd.MLS_OFFICE_NAME
--,officestd.MLS_OFFICE_EMAIL
--,officestd.MLS_OFFICE_ADDRESS
--,officestd.MLS_OFFICE_PHONE
--,Concurrent_Listed_Ind
--,SOLD_DATE_STD
--,Rental_Ind
--,MLS_LIST_PRICE_STD
--,SOLD_PRICE_STD
--,(Select [SUM_OF_GROSS_SQUARE_FEET] from Assr.dbo.Assr a where a.Fips=lh.Fips and a.REF_ID=lh.REF_ID) as [Gross Living Area (GLA)]
--,HOME_SIZE_STD
--,LOT_SIZE_STD
--,PRICE_PER_SQFT_STD
--,YEAR_BUILT_STD
--,SHORT_SALE_IND
--,HOUSE_NBR
--,MLS_DAYS_ON_MARKET_STD
--into Minelson.[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
--FROM  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a  
--left join FA_Listing.dbo.Listing lh with(NOLOCK) ON a.listing_id = lh.listing_id
--LEFT JOIN FA_Listing.dbo.FA_MLS_Raw_Std_Address addr with(NOLOCK) ON addr.Row_Id = lh.AddrId AND addr.Addr_type = 'S'
--LEFT JOIN FA_Listing.dbo.MLS_Listing_Agent agent with(NOLOCK) ON agent.MLS_Listing_Agent_CODE = lh.MLS_Listing_Agent_CODE
--LEFT JOIN FA_Listing.dbo.MLS_Listing_Agent_Std agentstd with(NOLOCK) ON agentstd.MLS_Listing_Agent_CODE_STD = agent.MLS_Listing_Agent_CODE_STD
--LEFT JOIN FA_Listing.dbo.MLS_Office office with(NOLOCK) ON office.MLS_OFFICE_CODE = lh.MLS_OFFICE_CODE
--LEFT JOIN FA_Listing.dbo.MLS_Office_Std officestd with(NOLOCK) ON officestd.MLS_OFFICE_CODE_STD = office.MLS_OFFICE_CODE_STD

-----------------------Check updatd records--------------------------------


  --SELECT count(*)
  --FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion]
  --SELECT count(*)
  --FROM [MiNelson].[mktshr].[TitleMarketShare]


  --------------------Adding listing Platlabs

  
/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk] ;


SELECT 
*
into [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
FROM  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]a  

ALTER TABLE [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
ADD
    [Listing_ID] varchar(25) NULL,
    [Property Address] varchar(100) NULL,
    [Property City] varchar(55) NULL,
    [Property State] varchar(2) NULL,
    [Property Zip] varchar(5) NULL,
    [Property Zip + 4] varchar(4) NULL,
    [MLS_STATUS_STD] varchar(50) NULL,
    [MLS_LIST_DATE_STD] date NULL,
    [MLS_Listing_Number] varchar(50) NULL,
    [MLS_LISTING_AGENT_NAME] varchar(500) NULL,
    [MLS_LISTING_AGENT_EMAIL] varchar(100) NULL,
    [AGENT_PHONE] varchar(30) NULL,
    [MLS_OFFICE_NAME] varchar(500) NULL,
    [MLS_OFFICE_EMAIL] varchar(100) NULL,
    [MLS_OFFICE_ADDRESS] varchar(1000) NULL,
    [MLS_OFFICE_PHONE] varchar(100) NULL,
    [Concurrent_Listed_Ind] bit NULL,
    [SOLD_DATE_STD] date NULL,
    [Rental_Ind] bit NULL,
    [MLS_LIST_PRICE_STD] decimal(15,2) NULL,
    [SOLD_PRICE_STD] decimal(15,2) NULL,
    [Gross Living Area (GLA)] varchar(7) NULL,
    [HOME_SIZE_STD] decimal(15,2) NULL,
    [LOT_SIZE_STD] decimal(18,2) NULL,
    [PRICE_PER_SQFT_STD] decimal(15,2) NULL,
    [YEAR_BUILT_STD] int NULL,
    [SHORT_SALE_IND] bit NULL,
    [HOUSE_NBR] varchar(50) NULL,
    [MLS_DAYS_ON_MARKET_STD] int NULL,
    [Listing Agent First Name] varchar(50) NULL,
    [Listing Agent Last Name] varchar(50) NULL,
    [LISTING AGENT LICENSE NUMBER] varchar(50) NULL,
    [LISTING OFFICE LICENSE NUMBER] varchar(250) NULL,
    [LISTING OFFICE WEBSITE] varchar(250) NULL,
    [BUYER AGENT NAME] varchar(100) NULL,
    [BUYER AGENT PHONE] varchar(25) NULL,
    [BUYER AGENT LICENSE NUMBER] varchar(50) NULL,
    [BUYER AGENT EMAIL] varchar(200) NULL,
    [BUYER OFFICE NAME] varchar(100) NULL,
    [BUYER OFFICE ADDRESS] varchar(520) NULL,
    [BUYER OFFICE PHONE] varchar(25) NULL,
    [BUYER OFFICE EMAIL] varchar(250) NULL,
    [BUYER OFFICE WEBSITE] varchar(250) NULL,
    [BUYER OFFICE LICENSE NUMBER] varchar(250) NULL,
    [Buyer Agent First Name] varchar(50) NULL,
    [Buyer Agent Last Name] varchar(50) NULL,
    [mls_id] int NULL,
    [BuyAgentID] varchar(100) NULL,
    [Agent_ID] varchar(250) NULL,
    [BUYER AGENT ADDRESS] varchar(520) NULL,
    [LIST AGENT ADDRESS] varchar(520) NULL;



update  [MiNelson].[dbo].[a]
set
a.[Listing_ID] = b.[Listing_ID],
a.[Property Address] = left(b.[Property Address],100),
a.[Property City] = left(b.[Property City],55) ,
a.[Property State] = b.[Property State] ,
a.[Property Zip] = left(b.[Property Zip],5) ,
a.[Property Zip + 4] = b.[Property Zip + 4],
a.[MLS_STATUS_STD] = b.[MLS_STATUS_STD] ,
a.[MLS_LIST_DATE_STD] = b.[MLS_LIST_DATE_STD] ,
a.[MLS_Listing_Number] = b.[MLS_Listing_Number] ,
a.[MLS_LISTING_AGENT_NAME] = b.[MLS_LISTING_AGENT_NAME],
a.[MLS_LISTING_AGENT_EMAIL] = b.[MLS_LISTING_AGENT_EMAIL] ,
a.[AGENT_PHONE] = left(b.[AGENT_PHONE],30) ,
a.[MLS_OFFICE_NAME] = b.[MLS_OFFICE_NAME] ,
a.[MLS_OFFICE_EMAIL] = left(b.[MLS_OFFICE_EMAIL], 250) ,
a.[MLS_OFFICE_ADDRESS] = b.[MLS_OFFICE_ADDRESS],
a.[MLS_OFFICE_PHONE] = left(b.[MLS_OFFICE_PHONE],100) ,
a.[Concurrent_Listed_Ind] = b.[Concurrent_Listed_Ind]  ,
a.[SOLD_DATE_STD] = b.[SOLD_DATE_STD] ,
a.[Rental_Ind] = (case when b.[Rental_Ind] = 'Y' then 1 else 0 end), 
a.[MLS_LIST_PRICE_STD] = b.[MLS_LIST_PRICE_STD] ,
a.[SOLD_PRICE_STD] = b.[SOLD_PRICE_STD] ,
a.[Gross Living Area (GLA)] = left(b.[Gross Living Area (GLA)],7) ,
a.[HOME_SIZE_STD] = b.[HOME_SIZE_STD] ,
a.[LOT_SIZE_STD] = b.[LOT_SIZE_STD] ,
a.[PRICE_PER_SQFT_STD] = b.[PRICE_PER_SQFT_STD] ,
a.[YEAR_BUILT_STD] = b.[YEAR_BUILT_STD] ,
a.[SHORT_SALE_IND] = (case when b.[SHORT_SALE_IND] = 'Y'  or b.[SHORT_SALE_IND] = 'true' then 1 else 0 end) ,
a.[HOUSE_NBR] = left( b.[HOUSE_NBR],50) ,
a.[MLS_DAYS_ON_MARKET_STD] = b.[MLS_DAYS_ON_MARKET_STD] 
 ,a.[Listing Agent First Name] = b.[Listing Agent First Name]
      ,a.[Listing Agent Last Name] = b.[Listing Agent Last Name]
      ,a.[LISTING AGENT LICENSE NUMBER] = b.[LISTING AGENT LICENSE NUMBER]
      ,a.[LISTING OFFICE LICENSE NUMBER] = b.[LISTING OFFICE LICENSE NUMBER]
      ,a.[LISTING OFFICE WEBSITE] = b.[LISTING OFFICE WEBSITE]
      ,a.[BUYER AGENT NAME] = b.[BUYER AGENT NAME]
      ,a.[BUYER AGENT PHONE] = b.[BUYER AGENT PHONE]
      ,a.[BUYER AGENT LICENSE NUMBER] = b.[BUYER AGENT LICENSE NUMBER]
      ,a.[BUYER AGENT EMAIL] = b.[BUYER AGENT EMAIL]
      ,a.[BUYER OFFICE NAME] = b.[BUYER OFFICE NAME]
      ,a.[BUYER OFFICE ADDRESS] = b.[BUYER OFFICE ADDRESS]
      ,a.[BUYER OFFICE PHONE] = b.[BUYER OFFICE PHONE]
      ,a.[BUYER OFFICE EMAIL] = b.[BUYER OFFICE EMAIL]
      ,a.[BUYER OFFICE WEBSITE] = b.[BUYER OFFICE WEBSITE]
      ,a.[BUYER OFFICE LICENSE NUMBER] = b.[BUYER OFFICE LICENSE NUMBER]
      ,a.[Buyer Agent First Name] = b.[Buyer Agent First Name]
      ,a.[Buyer Agent Last Name] = b.[Buyer Agent Last Name]
      ,a.[mls_id] = b.[mls_id]
	  ,a.[BuyAgentID] = b.buyAgentId
	  ,a.agent_id = b.agent_id
	  ,a.[BUYER AGENT ADDRESS] = b.[BUYER AGENT ADDRESS]
	  ,a.[LIST AGENT ADDRESS] = b.[LIST AGENT ADDRESS]
from [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk] a
inner join [MiNelson].[mktshr].[Marketshare_Platlabs] b
on a.DeedID = b.deedid and a.DeedSequence = 1



  -------------------------- Change Data Type for NMLS ID----------------------------------------------------------------------------------------

 -- select * from [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]

-- select  replace([Officer_NMLS_ID] ,',', ''),
--  * from  [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
--where   [Officer_NMLS_ID]  like '%,%' or  [Officer_NMLS_ID] like '%.%'


update [MiNelson].[dbo].[a]
set a.[Officer_NMLS_ID] = replace([Officer_NMLS_ID] ,',', '')
 from  [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk] a
where   [Officer_NMLS_ID]  like '%,%'


update [MiNelson].[dbo].[a]
set a.[Officer_NMLS_ID] = replace([Officer_NMLS_ID] ,'.', '')
 from  [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk] a
where   [Officer_NMLS_ID] like '%.%'

    Alter table [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
Alter Column  [Officer_NMLS_ID] bigint
 

Alter table [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
Alter Column  [Lender_NMLS_ID] bigint
 

Alter table [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
Alter Column  [Broker_NMLS_ID] bigint
 


--  Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion]
--Alter Column  [Officer_NMLS_ID] bigint
 

--Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion]
--Alter Column  [Lender_NMLS_ID] bigint
 

--Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion]
--Alter Column  [Broker_NMLS_ID] bigint
 

-- Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
--Alter Column  [Officer_NMLS_ID] bigint
 

--Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
--Alter Column  [Lender_NMLS_ID] bigint
 

--Alter table Minelson.[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
--Alter Column  [Broker_NMLS_ID] bigint
 
 --select Deedid,Deedsequence, count (*) from Minelson.[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
 --group by Deedid,Deedsequence
 --having count (*) > 1

-------------Adding incremental to production----------------

truncate table [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]

insert into  [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
(   [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
	  ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]

	  )
 
(SELECT  [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
	  ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]
	  from [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk])

------ Check count with production Marketshare table

Delete
--- select *
from [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
where left(date,7) <left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 

  Delete 
 -- select *
  from  [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]
where DeedID in (
SELECT deedid
  FROM [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
)

insert into  [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]
(    [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
      ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]

	  )
 
(SELECT [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
      ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]
	  from [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental])


	  
truncate table [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]

insert into  [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
(   [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
      ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]
	  )
 
(SELECT  [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
      ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]
	  from [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion])

	  
 SELECT count(*)
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]

 SELECT count(*)
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]

    SELECT count(*)
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]
  SELECT count(*)
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk_Incremental]


  
 Update [MiNelson].[dbo].[a]
 set a.Lender_Name = b.Name
 --select *
 from  [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]a
inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
 on a.Lender_NMLS_ID = b.[NMLSID]
 where (a.Lender_Name <> b.Name) or (a.Lender_Name is null and b.Name is not null)


--  Update a
-- set a.Lender_Name = b.Name
-- --select *
-- from  [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]a
--inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
-- on a.Lender_NMLS_ID = b.[NMLSID]
-- where (a.Lender_Name <> b.Name) or (a.Lender_Name is null and b.Name is not null)

 Delete
--- select *
from [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]
where left(date,7) <left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 

 Delete
--- select *
from [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
where left(date,7) <left (convert(varchar,DATEADD(month, -60,GETDATE()),120),7) 



---- DAtaTree delete duplicates


/*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_Delete_temp_bulk_DT') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]

Select m.DeedID,m.DeedSequence 
into [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]
from [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion] m where not exists
(Select * from [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk] mm 
where mm.DeedID=m.DeedID and mm.DeedSequence=m.DeedSequence)

Delete m from [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion] m 
inner join [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT] t 
on t.DeedID=m.DeedID and t.DeedSequence=m.DeedSequence

 Delete 
 -- select *
  from  [Minelson].[mktshr].[DT_TitleMarketShare_Expansion_Incremental]
where DeedID not in(
SELECT deedid
  FROM  [MiNelson].[mktshr].[DT_TitleMarketShare_Expansion]
)


/*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_Delete_temp_bulk_DT') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_Delete_temp_bulk_DT]

---- Clean up

/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_Bulk]') is not null     */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_Bulk];

------ Adding Listing for Full Bulk


 ---- delete records already delete from Deed table

 delete from  [Minelson].[mktshr].[TitleMarketShare_NMLS_Listing_Bulk]
 where deedid not in (select deedid from 
 [Minelson].[mktshr].[TitleMarketShare_Bulk])

 --- delete updated records
   Delete 
 -- select *
  from  [Minelson].[mktshr].[TitleMarketShare_NMLS_Listing_Bulk]
where DeedID in (
SELECT deedid
  FROM  [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk]
)

-------------Adding incremental to production----------------


insert into   [Minelson].[mktshr].[TitleMarketShare_NMLS_Listing_Bulk]
(  [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
      ,[Listing Agent First Name]
      ,[Listing Agent Last Name]
      ,[LISTING AGENT LICENSE NUMBER]
      ,[LISTING OFFICE LICENSE NUMBER]
      ,[LISTING OFFICE WEBSITE]
      ,[BUYER AGENT NAME]
      ,[BUYER AGENT PHONE]
      ,[BUYER AGENT LICENSE NUMBER]
      ,[BUYER AGENT EMAIL]
      ,[BUYER OFFICE NAME]
      ,[BUYER OFFICE ADDRESS]
      ,[BUYER OFFICE PHONE]
      ,[BUYER OFFICE EMAIL]
      ,[BUYER OFFICE WEBSITE]
      ,[BUYER OFFICE LICENSE NUMBER]
      ,[Buyer Agent First Name]
      ,[Buyer Agent Last Name]
      ,[mls_id]
      ,[BuyAgentID]
      ,[Agent_ID]
      ,[BUYER AGENT ADDRESS]
      ,[LIST AGENT ADDRESS]

	  )
 
(SELECT [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Rundate]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RoleID]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
	  ,null as [Listing Agent First Name]
      ,null as [Listing Agent Last Name]
      ,null as [LISTING AGENT LICENSE NUMBER]
      ,null as [LISTING OFFICE LICENSE NUMBER]
      ,null as [LISTING OFFICE WEBSITE]
      ,null as [BUYER AGENT NAME]
      ,null as [BUYER AGENT PHONE]
      ,null as [BUYER AGENT LICENSE NUMBER]
      ,null as [BUYER AGENT EMAIL]
      ,null as [BUYER OFFICE NAME]
      ,null as [BUYER OFFICE ADDRESS]
      ,null as [BUYER OFFICE PHONE]
      ,null as [BUYER OFFICE EMAIL]
      ,null as [BUYER OFFICE WEBSITE]
      ,null as [BUYER OFFICE LICENSE NUMBER]
      ,null as [Buyer Agent First Name]
      ,null as [Buyer Agent Last Name]
      ,null as [mls_id]
      ,null as [BuyAgentID]
      ,null as [Agent_ID]
      ,null as [BUYER AGENT ADDRESS]
      ,null as [LIST AGENT ADDRESS]

	  from [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental_Bulk])





;WITH CTE AS(
   SELECT deedid, deedsequence,
       RN = ROW_NUMBER()OVER(PARTITION BY deedid,  deedsequence ORDER BY deedid)
   FROM [Minelson].[mktshr].[TitleMarketShare_NMLS_Listing_Bulk]
)

DELETE FROM CTE WHERE RN > 1



END  




