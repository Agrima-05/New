SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_300_Start_Output_SITUS_AMC_PACE_FLANK]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT_OPEN_PACE]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_OPEN_PACE](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT DealID][varchar](250)NULL,
			[INPUT Solution ID][varchar](250)NULL,
			[INPUT Unique RecordID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[PACE Lien Coverage][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Total # of PACE records][varchar](250)NULL
		) ON [PRIMARY]


	---- POPULATE OUTPUT with Customer Provided Data
		INSERT INTO [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] ([INPUT DealID],[INPUT Solution ID],[INPUT Unique RecordID],[INPUT Address],[INPUT City],[INPUT State]
		,[INPUT Zip]
		--,[Start Date]
		)
		Select 
		[Deal ID]
      ,[Solution ID]
      --,convert(bigint,[Unique RecordID])
	  ,[Unique RecordID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
	  --,convert(date,[Start Date])
     FROM 
	 --Select * from 
	  INPUT_RAW_CUST
	  where ISNULL([Unique RecordID],'0') not like '0'
	and [Unique RecordID] not like ''
	and [Unique RecordID] is not null
	and [Solution ID] like 'S86'
	
		
		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]


		UPDATE [zCust_SITUS_AMC].[dbo].[a] 
		SET a.PROPERTYID = c.PROPERTYID
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a JOIN 
		[zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Unique RecordID] = c.RAW_ID



		
		Update [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = Convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique RecordID] = c.RAW_ID

		Update [zCust_SITUS_AMC].[dbo].[a]
		set 
		A.[PACE Lien Coverage] = case when B.FIPS is not null then 1 else 0 end
		--Select * 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a 
			left outer JOIN (Select FIPS, Min([Recording Date]) as MinDate, Max([Recording Date]) as maxdate from [data].[dbo].[vPACE_LIEN] with(NOLOCK)
			where FIPS in (Select distinct FIPS from [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] where FIPS is not null and FIPS not like '' and FIPS not like '0')
			Group by FIPS) B on 
			A.FIPS = B.FIPS


			

	--------PULL INVL BULK---
	--Drop table dbo.PACE_BULK_PULL
	
	Truncate table dbo.PACE_BULK_PULL

	Insert into [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]
	Select 
		NULL as ROWNUM
		,B.[INPUT Unique RecordID] as [INPUT KEY]
		,A.*

		--Select A.*
		--into dbo.PACE_BULK_PULL
		From [data].[dbo].[vPACE_LIEN] as A with(NOLOCK)
		join [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] as B with(NOLOCK) on A.PropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		--and convert(date,A.recordingDt) > convert(date,B.INPUT_FUNDED_DATE)
		and A.[Open Lien Indicator] like 'Y'
		and A.[FAUCID Flag] not like 'D'


		

		Select [Pace ID], count(*) From [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]
		Group by [Pace ID]
		having count(*) > 1

		
		Update [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]
		Set ROWNUM = NULL

			UPDATE [zCust_SITUS_AMC].[dbo].[t] 
			SET T.ROWNUM = R.RowNum2
			FROM [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUT KEY] ORDER BY [Recording Date] DESC) AS RowNum2
				FROM 
			[zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL] t  ) r ON t.[INPUT KEY] = r.[INPUT KEY] AND t.[Pace ID] = r.[Pace ID]
			 
				
		
		
		Select max(convert(int,ROWNUM )) from [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]


		Select * From [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]
		where ROWNUM is null

		Select [INPUT KEY], ROWNUM, count(*) From [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]
		Group by [INPUT KEY], ROWNUM
		having count(*) > 1

		Select * From [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL]

		
		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		Set [Total # of PACE records] = NULL
		where convert(int,[Total # of PACE records]) > 0


		UPDATE [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Total # of PACE records] = 
		--case when b.NbrOfRecordings > 30 then '30' else 
		b.NbrOfRecordings 
		--end
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a JOIN (SELECT [INPUT KEY],MAX(ROWNUM) NbrOfRecordings FROM [zCust_SITUS_AMC].[dbo].[PACE_BULK_PULL] GROUP BY [INPUT KEY]) b
		on a.[INPUT Unique RecordID] = b.[INPUT KEY]

		Select max(convert(bigint,[Total # of PACE records])) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]

		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]

		--Select * From PACE_BULK_PULL

		IF (Select count(*) from [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		where [Total # of PACE records] > 0 ) > 0

		BEGIN
			
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Record Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner1LastName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner1FirstName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner1MiddleName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner1Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner2LastName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner2FirstName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner2MiddleName] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Owner2Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Open Lien Indicator] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [TransactionType] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Doc Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Loan Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Recording Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Document Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Identifier] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [DocumentNumber] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Book] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Page] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Book and Page Formatted] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Financed Amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Interest Rate] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Lien Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Adjustable Percent] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Loan Amount] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Loan Amount Credit Limit] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Assessment Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Loan Maturity Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Tax Begin Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Tax End Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [PrePayment] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [PrePayment Interest] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [PrePayment Increments] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Program Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority Phone Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Authority Email Website] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator Last Name Co Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator First Name] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator Middle Initial] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator Suffix] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator Address] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator City] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator State] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Administrator Zip] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Recording Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Document Number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Document Number Formatted] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Book number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Page number] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_OPEN_PACE ADD [Original Book and Page Formatted] [varchar](250) NULL')

			

			EXEC('UPDATE a
			SET 
				A. [Record Number] = B.ROWNUM
				,A.[Owner1LastName] = B.[Owner1LastName]
				,A.[Owner1FirstName] = B.[Owner1FirstName]
				,A.[Owner1MiddleName] = B.[Owner1MiddleName]
				,A.[Owner1Suffix] = B.[Owner1Suffix]
				,A.[Owner2LastName] = B.[Owner2LastName]
				,A.[Owner2FirstName] = B.[Owner2FirstName]
				,A.[Owner2MiddleName] = B.[Owner2MiddleName]
				,A.[Owner2Suffix] = B.[Owner2Suffix]
				,A.[Open Lien Indicator] = B.[Open Lien Indicator]
				,A.[TransactionType] = B.[TransactionType]
				,A.[Doc Type] = B.[Doc Type]
				,A.[Loan Type] = B.[Loan Type]
				,A.[Recording Date] = B.[Recording Date]
				,A.[Document Date] = B.[Document Date]
				,A.[Identifier] = B.[Identifier]
				,A.[DocumentNumber] = B.[DocumentNumber]
				,A.[Book] = B.[Book]
				,A.[Page] = B.[Page]
				,A.[Book and Page Formatted] = B.[Book and Page Formatted]
				,A.[Financed Amount] = B.[Financed Amount]
				,A.[Interest Rate] = B.[Interest Rate]
				,A.[Lien Number] = B.[Lien Number]
				,A.[Adjustable Percent] = B.[Adjustable Percent]
				,A.[Loan Amount] = B.[Loan Amount]
				,A.[Loan Amount Credit Limit] = B.[Loan Amount Credit Limit]
				,A.[Assessment Date] = B.[Assessment Date]
				,A.[Loan Maturity Date] = B.[Loan Maturity Date]
				,A.[Tax Begin Date] = B.[Tax Begin Date]
				,A.[Tax End Date] = B.[Tax End Date]
				,A.[PrePayment] = B.[PrePayment]
				,A.[PrePayment Interest] = B.[PrePayment Interest]
				,A.[PrePayment Increments] = B.[PrePayment Increments]
				,A.[Program Name] = B.[Program Name]
				,A.[Authority Name] = B.[Authority Name]
				,A.[Authority Address] = B.[Authority Address]
				,A.[Authority City] = B.[Authority City]
				,A.[Authority State] = B.[Authority State]
				,A.[Authority Zip] = B.[Authority Zip]
				,A.[Authority Phone Number] = B.[Authority Phone Number]
				,A.[Authority Email Website] = B.[Authority Email Website]
				,A.[Administrator Last Name Co Name] = B.[Administrator Last Name Co Name]
				,A.[Administrator First Name] = B.[Administrator First Name]
				,A.[Administrator Middle Initial] = B.[Administrator Middle Initial]
				,A.[Administrator Suffix] = B.[Administrator Suffix]
				,A.[Administrator Address] = B.[Administrator Address]
				,A.[Administrator City] = B.[Administrator City]
				,A.[Administrator State] = B.[Administrator State]
				,A.[Administrator Zip] = B.[Administrator Zip]
				,A.[Original Recording Date] = B.[Original Recording Date]
				,A.[Original Document Number] = B.[Original Document Number]
				,A.[Original Document Number Formatted] = B.[Original Document Number Formatted]
				,A.[Original Book number] = B.[Original Book number]
				,A.[Original Page number] = B.[Original Page number]
				,A.[Original Book and Page Formatted] = B.[Original Book and Page Formatted]



			FROM x_Custom_OUTPUT_OPEN_PACE a JOIN  PACE_BULK_PULL as B 
			on a.[INPUT Unique RecordID] = b.[Input key] 
			WHERE B.ROWNUM = 1')

		END
		
		----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[Total # of PACE records])) from [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_SITUS_AMC].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_SITUS_AMC].[sys].[tables] as A join [zCust_SITUS_AMC].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_OPEN_PACE'
			and B.Name not in ('Record Number','Owner1LastName','Owner1FirstName','Owner1MiddleName','Owner1Suffix','Owner2LastName','Owner2FirstName','Owner2MiddleName','Owner2Suffix',
'Open Lien Indicator','TransactionType','Doc Type','Loan Type','Recording Date','Document Date','Identifier','DocumentNumber','Book','Page','Book and Page Formatted','Financed Amount','Interest Rate',
'Lien Number','Adjustable Percent','Loan Amount','Loan Amount Credit Limit','Assessment Date','Loan Maturity Date','Tax Begin Date','Tax End Date','PrePayment','PrePayment Interest','PrePayment Increments',
'Program Name','Authority Name','Authority Address','Authority City','Authority State','Authority Zip','Authority Phone Number','Authority Email Website','Administrator Last Name Co Name','Administrator First Name','Administrator Middle Initial',
'Administrator Suffix','Administrator Address','Administrator City','Administrator State','Administrator Zip','Original Recording Date','Original Document Number','Original Document Number Formatted','Original Book number',
'Original Page number','Original Book and Page Formatted')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.BUILD_DOWN_COLUMNS


				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_SITUS_AMC].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_SITUS_AMC].[dbo].[BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[Total # of PACE records])) FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_OPEN_PACE(
												' +  @FIELDLIST3 + '

												  ,[Record Number]
													,[Owner1LastName]
													,[Owner1FirstName]
													,[Owner1MiddleName]
													,[Owner1Suffix]
													,[Owner2LastName]
													,[Owner2FirstName]
													,[Owner2MiddleName]
													,[Owner2Suffix]
													,[Open Lien Indicator]
													,[TransactionType]
													,[Doc Type]
													,[Loan Type]
													,[Recording Date]
													,[Document Date]
													,[Identifier]
													,[DocumentNumber]
													,[Book]
													,[Page]
													,[Book and Page Formatted]
													,[Financed Amount]
													,[Interest Rate]
													,[Lien Number]
													,[Adjustable Percent]
													,[Loan Amount]
													,[Loan Amount Credit Limit]
													,[Assessment Date]
													,[Loan Maturity Date]
													,[Tax Begin Date]
													,[Tax End Date]
													,[PrePayment]
													,[PrePayment Interest]
													,[PrePayment Increments]
													,[Program Name]
													,[Authority Name]
													,[Authority Address]
													,[Authority City]
													,[Authority State]
													,[Authority Zip]
													,[Authority Phone Number]
													,[Authority Email Website]
													,[Administrator Last Name Co Name]
													,[Administrator First Name]
													,[Administrator Middle Initial]
													,[Administrator Suffix]
													,[Administrator Address]
													,[Administrator City]
													,[Administrator State]
													,[Administrator Zip]
													,[Original Recording Date]
													,[Original Document Number]
													,[Original Document Number Formatted]
													,[Original Book number]
													,[Original Page number]
													,[Original Book and Page Formatted])
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												,B.ROWNUM
												,B.[Owner1LastName]
												,B.[Owner1FirstName]
												,B.[Owner1MiddleName]
												,B.[Owner1Suffix]
												,B.[Owner2LastName]
												,B.[Owner2FirstName]
												,B.[Owner2MiddleName]
												,B.[Owner2Suffix]
												,B.[Open Lien Indicator]
												,B.[TransactionType]
												,B.[Doc Type]
												,B.[Loan Type]
												,B.[Recording Date]
												,B.[Document Date]
												,B.[Identifier]
												,B.[DocumentNumber]
												,B.[Book]
												,B.[Page]
												,B.[Book and Page Formatted]
												,B.[Financed Amount]
												,B.[Interest Rate]
												,B.[Lien Number]
												,B.[Adjustable Percent]
												,B.[Loan Amount]
												,B.[Loan Amount Credit Limit]
												,B.[Assessment Date]
												,B.[Loan Maturity Date]
												,B.[Tax Begin Date]
												,B.[Tax End Date]
												,B.[PrePayment]
												,B.[PrePayment Interest]
												,B.[PrePayment Increments]
												,B.[Program Name]
												,B.[Authority Name]
												,B.[Authority Address]
												,B.[Authority City]
												,B.[Authority State]
												,B.[Authority Zip]
												,B.[Authority Phone Number]
												,B.[Authority Email Website]
												,B.[Administrator Last Name Co Name]
												,B.[Administrator First Name]
												,B.[Administrator Middle Initial]
												,B.[Administrator Suffix]
												,B.[Administrator Address]
												,B.[Administrator City]
												,B.[Administrator State]
												,B.[Administrator Zip]
												,B.[Original Recording Date]
												,B.[Original Document Number]
												,B.[Original Document Number Formatted]
												,B.[Original Book number]
												,B.[Original Page number]
												,B.[Original Book and Page Formatted]


										--Select B.* 	
										
										FROM x_Custom_OUTPUT_OPEN_PACE a JOIN  PACE_BULK_PULL as B 
										on a.[INPUT Unique RecordID] = b.[INPUT KEY]
										WHERE B.ROWNUM = ''' + @BeginNbrOfTrans6 + '''
										AND A.[Record Number] = ''1''
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			--Select [INPUT Unique RecordID],[Total # of PACE records],[Record Number] From x_Custom_OUTPUT_OPEN_PACE
			--where [Total # of PACE records] > 0
			--Order by [INPUT Unique RecordID],[Record Number]


			IF(	Select count(*) From   [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
			where [Total # of PACE records] > 0) > 0 

			BEGIN

			EXEC('
			--------DECODE Doc Type  -----

			Select [Doc Type], count(*) From x_Custom_OUTPUT_OPEN_PACE
			where [Total # of PACE records] > 0
			Group by [Doc Type]
			Order by [Doc Type]


			
			Update  x_Custom_OUTPUT_OPEN_PACE
			Set [Doc Type] = case 
			when [Doc Type] like ''AGRENG'' then ''Agreement to Obtain PACE Loan ''
			when [Doc Type] like ''AGRENGAMD'' then ''Amendment to Agreement to Obtain PACE Loan''
			when [Doc Type] like ''AGRENGREL'' then ''Release of Agreement to Obtain PACE Loan ''
			when [Doc Type] like ''ALNENG'' then ''Notice of Assessment Tax Lien - Energy Lien''
			when [Doc Type] like ''ALNENGAMD'' then ''Amendment to Notice of Assessment Tax Lien  - Energy Lien''
			when [Doc Type] like ''ALNENGREL'' then ''Release of Notice of Assessment Tax Lien  - Energy Lien''
			when [Doc Type] like ''CTRASM'' then ''Contractual Assessment - Energy Lien''
			when [Doc Type] like ''CTRASMAMD'' then ''Amendment to Contractual Assessment - Energy Lien''
			when [Doc Type] like ''CTRASMREL'' then ''Release of Contractual Assessment - Energy Lien''

			else [Doc Type] end


			
			Select [Doc Type], count(*) From x_Custom_OUTPUT_OPEN_PACE
			where [Total # of PACE records] > 0
			Group by [Doc Type]
			Order by [Doc Type]


			--------DECODE Loan Type  -----

			Select [Loan Type], count(*) From x_Custom_OUTPUT_OPEN_PACE
			where [Total # of PACE records] > 0
			Group by [Loan Type]
			Order by [Loan Type]


			
			Update  x_Custom_OUTPUT_OPEN_PACE
			Set [Loan Type] = case 
			when [Loan Type] like ''PD'' then ''DOORS/WINDOWS/SKYLIGHTS''
			when [Loan Type] like ''PE'' then ''ELECTRIC VEHICLE CHARGING SYSTEM''
			when [Loan Type] like ''PF'' then ''FIXTURES/APPLIANCES''
			when [Loan Type] like ''PH'' then ''HVAC (HEATING, AIR CONDITIONING/COOLING or both)''
			when [Loan Type] like ''PI'' then ''IRRIGATION''
			when [Loan Type] like ''PL'' then ''LANDSCAPING/TURF''
			when [Loan Type] like ''PM'' then ''MULTIPLE''
			when [Loan Type] like ''PN'' then ''INSULATION/AIR SEALING''
			when [Loan Type] like ''PR'' then ''ROOF/ROOFING''
			when [Loan Type] like ''PS'' then ''SOLAR''
			when [Loan Type] like ''PU'' then ''UNDEFINED''
			when [Loan Type] like ''PV'' then ''DUCTS/VENTILATION/FANS''


			else [Loan Type] end


			
			Select [Loan Type], count(*) From x_Custom_OUTPUT_OPEN_PACE
			where [Total # of PACE records] > 0
			Group by [Loan Type]
			Order by [Loan Type]

			')

			END
			
			Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]


		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] 
		SET [PACE Lien Coverage] = CASE WHEN [PACE Lien Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a JOIN [zCust_SITUS_AMC].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique RecordID] = b.Raw_ID
		
		


		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_SITUS_AMC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE] a join [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique RecordID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		and (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 


		

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		SET [Event Status] = case when [Total # of PACE records] > 0	THEN 'Event Found' ELSE 'Event Not Found' END
		
		
		Select [Property Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		Group by [Address Standardization]

		Select [PACE Lien Coverage], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		Group by [PACE Lien Coverage]

		Select [Event Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]
		Group by [Event Status]


		--Select FIPS, PROPERTYID, [INPUT Unique RecordID], [INPUT Solution ID],[Total # of PACE records], [REcord Number], [Recording Date]  From  x_Custom_OUTPUT_OPEN_PACE
		--Order by [Total # of PACE records] desc,[INPUT Unique RecordID],[REcord Number]

		Select * From  [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_OPEN_PACE]


END



