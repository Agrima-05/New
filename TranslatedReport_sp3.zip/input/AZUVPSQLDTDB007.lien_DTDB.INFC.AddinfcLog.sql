/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.AddinfcLog | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
create PROCEDURE [lien_DTDB].[INFC].[AddinfcLog]
	@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [Lien_dtdb].[INFC].[InfcLog] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

