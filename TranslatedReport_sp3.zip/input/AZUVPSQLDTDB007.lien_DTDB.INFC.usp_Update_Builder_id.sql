/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_Update_Builder_id | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

 

CREATE PROCEDURE [lien_DTDB].[INFC].[usp_Update_Builder_id] @ERROR VARCHAR(500) OUTPUT

AS

SET NOCOUNT ON

 

/******************************************************************************************************************

CHANGE LOG:

==========

who                                       date        change

Marie                    1/10/2025          BUG769831 - Hawaii Land Court / Certificate missing Doc Numbers

******************************************************************************************************************/

BEGIN TRY

                EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'

                                ,N'usp_Update_Builder_id'

                                ,N'Started'

 

 

                UPDATE [lien_DTDB].[INFC].[D]

                SET D.Std_Builder_id = lb.Std_Builder_id

                                ,D.StandardizedBuilderName = lb.BuilderClean

                FROM [Lien_dtdb].[infc].[Deed_work] D

               

                OUTER APPLY (

                                SELECT lc.Std_Builder_id

                                                ,lb.builderclean

                                FROM [lien].[dbo].[Builder_Standard] lb WITH (

                                                                NOLOCK

                                                                ,INDEX (idx_Builder)

                                                                )

                                OUTER APPLY (

                                                SELECT Std_Builder_id

                                                FROM [lien].[dbo].[Builder_Standard_Cleaned] lc WITH (

                                                                                NOLOCK

                                                                                ,INDEX (idx_BuilderClean)

                                                                                )

                                                WHERE lc.builderclean = lb.builderclean

                                                and lc.Deleted IS NULL

                                                ) lc

                                WHERE lb.Builder = d.SELLER_NAME_PLAINTIFF_1

                                ) lb

                WHERE --d.fips = 12109 AND D.SOURCE_TYPE = 'e' and

               

                                lb.Std_Builder_id IS NOT NULL

                                --AND d.StandardizedBuilderName IS NULL

                                AND d.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'

                                --AND d.BYR1_FIRST_NAME != ''

                                AND d.PRI_CAT_CODE = 'A'

                                AND (

                                                (

                                                                d.RESALE_NEW_CONSTRUCTION = 'N'

                                                                OR d.TRANSACTION_TYPE IN ('3')

                                                                )

                                                OR (

                                                                d.RESALE_NEW_CONSTRUCTION = 'N'

                                                                AND d.TRANSACTION_TYPE IN ('2')

                                                                )

                                                OR (

                                                                d.RESALE_NEW_CONSTRUCTION = 'M'

                                                                AND d.TRANSACTION_TYPE IN ('1')

                                                                )

                                                )

                OPTION (

                                RECOMPILE

                                ,MAXDOP 12

                                ,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')

                                );

 

                EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'

                                ,N'usp_Update_Builder_id'

                                ,N'Ended'

END TRY

 

BEGIN CATCH

                --SET @ERROR = ERROR_MESSAGE() + CHAR(10) + 'in Paul_2 - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

                SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

 

                --SELECT @ERROR AS N'@ERROR'

                --ROLLBACK

                RAISERROR (

                                                @ERROR

                                                ,16

                                                ,1

                                                )

END CATCH

