SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	parse CoAgent data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_310_ListAgent]

AS
BEGIN


	SET NOCOUNT ON;

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		TRUNCATE TABLE agent.[ListAgents_Batch]

		INSERT INTO [src_platlabs].[agent].[ListAgents_Batch]
		Select [agentid]
		,[agentuid]
		,[mls_id]
		,[mls_listing_id]
		,agentName [name]
		,agentFirstName
		,agentLastName
		,agentEmail
		,agentPhone
		,agentLicenseNumber
		,office
		,officeID
		,officeName
		,officePhone
		,officeUID
		,GetDate() as LoadDate
		,[state]
		 from (Select mls_id,mls_listing_id,[state],[agents_listing_agent],a.id agentid,a.[uid] agentUID,a.[name] agentName,first_name agentFirstName
		 ,last_name agentLastName,email agentEmail,a.phone agentPhone,license_number agentLicenseNumber,office office,office_array.id officeID,office_array.name officeName,office_array.phone officePhone,office_array.uid officeUID
		FROM (Select mls_id,mls_listing_id,CASE WHEN LEN([state])>2 THEN NULL ELSE [state] End [state],[agents_listing_agent],id,Agent_Array.[uid],[name],first_name,last_name,email,phone,license_number,office
		from [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK)
				CROSS APPLY OPENJSON([agents_listing_agent]) WITH(
					id varchar(100)
					  ,uid varchar(100)
					  ,name varchar(100)
					  ,first_name varchar(50)
					  ,last_name varchar(50)
					  ,email varchar(200)
					  ,phone varchar(25)
					  ,license_number varchar(50)
					  ,office nvarchar(max) AS JSON
					 ) as Agent_Array) a
						CROSS APPLY OPENJSON([office]) WITH(
						[id] varchar(100)
						,[name] varchar(100)
						,[phone] varchar(25)
						,[uid] varchar(100)
						) as office_array) agentdata


		DELETE FROM [src_PlatLabs].[agent].[ListAgents_Batch] where [agent_uid] is NULL

		DELETE FROM [src_PlatLabs].[dbo].[a]
		FROM [src_PlatLabs].[agent].[ListAgents] a JOIN [src_PlatLabs].[agent].[ListAgents_Batch] b
		ON a.mls_id = b.mls_id
			AND a.mls_listing_id = b.mls_listing_id

		INSERT INTO [src_PlatLabs].[agent].[ListAgents]
		SELECT * FROM [src_PlatLabs].[agent].[ListAgents_Batch] WITH(NOLOCK)


			Select distinct mls_id,agent_id,agent_Email,agent_Phone into #p from [src_PlatLabs].[agent].[ListAgents] with(NOLOCK)

			create index ix on #p(mls_id,agent_id)

			UPDATE [src_PlatLabs].[dbo].[a]
			SET a.preferred_phone_number = b.agent_Phone
			,a.standardized_preferred_phone_number = b.agent_Phone
			,a.LoadDate = GETDATE()
			from [src_PlatLabs].[agent].[Platlabs_agents] a JOIN #p b 
			on a.mls_id = b.mls_id
			and a.dp_member_id = b.agent_id
			where a.preferred_phone_number is NULL 
			and b.agent_Phone is not null

			UPDATE [src_PlatLabs].[dbo].[a]
			SET a.email = b.agent_Email
			,a.LoadDate = GETDATE()
			from [src_PlatLabs].[agent].[Platlabs_agents] a JOIN #p b 
			on a.mls_id = b.mls_id
			and a.dp_member_id = b.agent_id
			where a.email is NULL 
			and b.agent_Email is not null

			DROP TABLE IF exists #p
 
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




