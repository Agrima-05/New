SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Financial_v3]

AS
BEGIN


	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[FinancialJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[FinancialJSON]
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Financial, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Financial') AS j

			DROP TABLE IF EXISTS Table_ad
			DROP TABLE IF EXISTS Table_ae
			DROP TABLE IF EXISTS Table_af


			Select MLSID,MLS_LISTING_ID,[BuyersAgentCompensation] INTO [src_PlatLabs].[dbo].[Table_ad]
					from [src_Platlabs].[features].[FinancialJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(REPLACE([Financial],'Buyers Agent Compensation','BuyersAgentCompensation')) WITH([BuyersAgentCompensation] varchar(1000)) as BuyersAgentCompensation_array
						WHERE [Financial] like '%"Buyers Agent Compensation"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_ad(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_ad(MLSID)

			Select MLSID,MLS_LISTING_ID,[NACompensation] INTO [src_PlatLabs].[dbo].[Table_ae]
					from [src_Platlabs].[features].[FinancialJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(REPLACE([Financial],'NA Compensation','NACompensation')) WITH([NACompensation] varchar(1000)) as NACompensation_array
						WHERE [Financial] like '%"NA Compensation"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_ae(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_ae(MLSID)

			SELECT MLSID, MLS_LISTING_ID, t.[value] as [Source] INTO [src_PlatLabs].[dbo].[Table_af]
			FROM [src_Platlabs].[features].[FinancialJSON] t1 with(NOLOCK)
			CROSS APPLY OPENJSON(t1.Financial) AS t
			WHERE t.[key] = 'Source' AND t1.[uid] IN(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			/*
			Select MLSID,MLS_LISTING_ID,[Source] INTO Table_af
					from [src_Platlabs].[features].[FinancialJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Financial]) WITH([Source] varchar(1000)) as Source_array
						WHERE [Financial] like '%"Source"%'
						and [uid] in(Select [uid] From listing.ListingsRaw_Batch)
						*/

			Create INDEX ix_MlsIDListingID on Table_af(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_af(MLSID)

			
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END




