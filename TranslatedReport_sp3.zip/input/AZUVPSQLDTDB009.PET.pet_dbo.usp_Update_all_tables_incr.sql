/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Update_all_tables_incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:		Sean Dang
-- Create date: 02/19/2025
-- Description:	Add rows to appropriate PET tables for PET_Incremental SSIS package
-- =============================================
CREATE PROCEDURE [PET].[pet_dbo].[usp_Update_all_tables_incr]
	-- Add the parameters for the stored procedure here
	@fips INT 
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	BEGIN TRY
		-- declare @fips int = 39007
		SET NOCOUNT ON;

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_Update_all_tables_incr'
			,N'Started'

		BEGIN TRANSACTION

		--add to NEO_Xref_Full
		INSERT INTO [PET].[dbo].[PET_NEO_Xref_Full] (
			Fips
			,NEO_APN
			,NEO_LAND_TYPE
			,NEO_TITLE_LEGAL
			,PORTION_IND
			)
		SELECT a.FIPS
			,a.NEO_APN
			,a.NEO_LAND_TYPE
			,a.NEO_TITLE_LEGAL
			,a.PORTION_IND
		FROM [PET].[pet_tmp].[Pet_Incremental_Add] AS a

		--add into pet apn is its own stored procedure?
		INSERT INTO [PET].[dbo].[PET_APN] (
			[REF_ID]
			,[FIPS]
			,[APN_Type]
			,[APN_ID]
			,[APN]
			,[created]
			,[updated]
			,[Dup_ind]
			)
		SELECT a.[REF_ID]
			,a.[FIPS]
			,a.[APN_Type]
			,a.[APN_ID]
			,a.[APN]
			,a.[created]
			,a.[updated]
			,a.Dup_ind
		FROM [PET].[peT_Tmp].[PET_APN_Inserts_Incremental] a
		LEFT JOIN [PET].[dbo].[PET_APN] t ON t.fips = a.fips
			AND t.ref_id = a.ref_id
			AND t.Apn_Type = a.Apn_Type
		WHERE t.Fips IS NULL
			AND a.Apn IS NOT NULL -- Add 4/25/2022 to prevent Null Apns to be stored from BK and DQ  
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		INSERT INTO [pet].[dbo].[PET_NEO_Legals] (
			FIPS
			,REF_ID
			,NEO_LAND_TYPE
			,NEO_TITLE_LEGAL
			,NEO_APN
			,Legal_Dup_Ind
			,created
			,PORTION_IND
			,Neo_title_legal_18
			)
		SELECT l.FIPS
			,l.REF_ID
			,l.NEO_LAND_TYPE
			,nullif(l.NEO_TITLE_LEGAL, '') AS NEO_TITLE_LEGAL
			,l.NEO_APN
			,l.Legal_Dup_Ind
			,l.created
			,l.PORTION_IND
			,SUBSTRING(l.Neo_title_legal,1,18) as Neo_title_legal_18
		FROM [pet].[tmp].[PET_NEO_LEGALS] l WITH (
				NOLOCK
				,INDEX (idx_fips)
				)
		CROSS APPLY (
			SELECT count(*) AS legal_cnt
			FROM [pet].[dbo].[pet_neo_legals] c WITH (
					NOLOCK
					,INDEX (Ixuc_fips_ref_id_neo_legal)
					)
			WHERE c.fips = l.fips
				AND c.ref_id = l.ref_id
				AND c.neo_apn = l.neo_apn
				AND c.NEO_TITLE_LEGAL = l.NEO_TITLE_LEGAL -- AND c.PORTION_IND = l.PORTION_IND--AND c.created = l.created    
			) c
		WHERE (c.legal_cnt = 0)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);


		/*=====================================      
 Populate NEO_Legal_Cnt on pet table      
 =====================================*/
		DROP TABLE

		IF EXISTS #Neo_Legal_Cnt
			CREATE TABLE #Neo_Legal_Cnt (
				Fips INT
				,REF_ID INT
				,Neo_Legal_Cnt INT
				,AN_cnt INT
				,AT_cnt INT
				,MC_cnt INT
				,SB_cnt INT
				,SC_cnt INT
				)

		CREATE INDEX idx_fips_ref_id ON #Neo_Legal_Cnt (
			fips
			,ref_id
			)

		INSERT INTO #Neo_Legal_Cnt
		SELECT l.Fips
			,l.REF_ID
			,count(*) AS Neo_Legal_Cnt
			,sum(CASE 
					WHEN l.NEO_LAND_TYPE = 'AN'
						THEN 1
					ELSE 0
					END) AS AN_cnt
			,sum(CASE 
					WHEN l.NEO_LAND_TYPE = 'AT'
						THEN 1
					ELSE 0
					END) AS AT_cnt
			,sum(CASE 
					WHEN l.NEO_LAND_TYPE = 'MC'
						THEN 1
					ELSE 0
					END) AS MC_cnt
			,sum(CASE 
					WHEN l.NEO_LAND_TYPE = 'SB'
						THEN 1
					ELSE 0
					END) AS SB_cnt
			,sum(CASE 
					WHEN l.NEO_LAND_TYPE = 'SC'
						THEN 1
					ELSE 0
					END) AS SC_cnt
		FROM [pet].[dbo].[PET_NEO_LEGALS] l --previous problem  
		CROSS APPLY (
			SELECT DISTINCT fips
				,ref_id
			FROM [pet].[tmp].[PET_NEO_LEGALS] neo WITH (
					NOLOCK
					,INDEX (idx_fips_ref_id)
					)
			WHERE neo.FIPS = l.FIPS
				AND neo.REF_ID = l.REF_ID
			) neo
		--INNER JOIN pet.tmp.PET_NEO_LEGALS AS neo ON neo.FIPS = l.FIPS
		--	AND neo.REF_ID = l.REF_ID
		--	AND neo.NEO_APN = l.NEO_APN
		GROUP BY l.Fips
			,l.ref_id

		UPDATE [PET].[pet_dbo].[p]
		SET p.NEO_APN = NULL
			,p.NEO_LAND_TYPE = NULL
			,p.NEO_TITLE_LEGAL = NULL
			,p.Label1 = NULL
			,p.Value1 = NULL
			,p.Label2 = NULL
			,p.Value2 = NULL
			,p.Label3 = NULL
			,p.Value3 = NULL
			,p.Label4 = NULL
			,p.Value4 = NULL
			,p.Label5 = NULL
			,p.Value5 = NULL
			,p.Label6 = NULL
			,p.Value6 = NULL
			,p.Label7 = NULL
			,p.Value7 = NULL
			,p.Label8 = NULL
			,p.Value8 = NULL
			,p.Label9 = NULL
			,p.Value9 = NULL
			,p.Label10 = NULL
			,p.Value10 = NULL
			,p.Label11 = NULL
			,p.Value11 = NULL
			,p.Label12 = NULL
			,p.Value12 = NULL
			,p.Label13 = NULL
			,p.Value13 = NULL
			,p.Label14 = NULL
			,p.Value14 = NULL
			,p.Label15 = NULL
			,p.Value15 = NULL
			,p.Label16 = NULL
			,p.Value16 = NULL
			,p.Label17 = NULL
			,p.Value17 = NULL
			,p.Label18 = NULL
			,p.Value18 = NULL
			,p.Label19 = NULL
			,p.Value19 = NULL
			,p.Label20 = NULL
			,p.Value20 = NULL
			,p.Label21 = NULL
			,p.Value21 = NULL
			,p.Label22 = NULL
			,p.Value22 = NULL
			,p.Label23 = NULL
			,p.Value23 = NULL
			,p.BookType = NULL
			,p.updated = GETDATE()
			,p.NEO_Legal_cnt = cnt.Neo_Legal_Cnt
			,p.NEO_LAND_TYPE_AN = cnt.AN_cnt
			,p.NEO_LAND_TYPE_AT = cnt.AT_cnt
			,p.NEO_LAND_TYPE_MC = cnt.MC_cnt
			,p.NEO_LAND_TYPE_SB = cnt.SB_cnt
			,p.NEO_LAND_TYPE_SC = cnt.SC_cnt
		FROM [pet].[dbo].[Pet] p WITH (INDEX (IDX_FIPS_REF_ID))
		INNER JOIN #Neo_Legal_Cnt AS cnt WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON cnt.FIPS = p.FIPS
			AND cnt.REF_ID = p.REF_ID
		WHERE p.fips = @Fips
		--AND cnt.NEO_Legal_cnt > 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		DROP TABLE

		IF EXISTS #leg_dup
			SELECT l.fips
				,l.NEO_TITLE_LEGAL
				,count(1) AS cnt
			INTO #leg_dup
			FROM [pet].[dbo].[PET_NEO_LEGALS] l WITH (
					NOLOCK
					,INDEX (a)
					)
			INNER JOIN [pet].[tmp].[PET_NEO_LEGALS] t WITH (
					NOLOCK
					,INDEX (a)
					) ON t.FIPS = l.FIPS
				AND t.NEO_TITLE_LEGAL = l.NEO_TITLE_LEGAL
			GROUP BY l.fips
				,l.NEO_TITLE_LEGAL
			HAVING count(1) > 1

		CREATE INDEX ixa ON #leg_dup (
			FIPS
			,NEO_TITLE_LEGAL
			)

		UPDATE [PET].[pet_dbo].[a]
		SET a.Legal_Dup_Ind = 1
		FROM [pet].[dbo].[PET_NEO_LEGALS] a WITH (
				NOLOCK
				,INDEX (a)
				)
		INNER JOIN #leg_dup d WITH (
				NOLOCK
				,INDEX (ixa)
				) ON d.fips = a.fips
			AND d.NEO_TITLE_LEGAL = a.NEO_TITLE_LEGAL

		COMMIT

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_Update_all_tables_incr'
			,N'Ended'
	END TRY

	BEGIN CATCH
		ROLLBACK

		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


