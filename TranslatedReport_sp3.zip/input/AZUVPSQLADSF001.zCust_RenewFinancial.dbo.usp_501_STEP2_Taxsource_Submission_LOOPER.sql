SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF





CREATE PROCEDURE [zCust_RenewFinancial].[dbo].[usp_501_STEP2_Taxsource_Submission_LOOPER] 
		
	
AS
BEGIN

	SET NOCOUNT ON;


		
		


			----DTAPI Production credentials for the Renew Account:

			----Account Number:
			----	2016111
			----Username:
			----	DTAPI_Renew-ADS_Prod
			----Password:
			----	RenewDTAPI1@Prod
			----Products Enabled:
			----	TaxSourceAutomated                                   

			------------------Tax Source-----------
			DECLARE @CUSTOMER varchar(100)
			Set @CUSTOMER = 'RenewFinancial'
			DECLARE @DATE varchar(30)
			--Set @DATE = (Select format(getdate(),'yyyyMMddHHmm'))
			Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			DECLARE @BATCH varchar(50)
			--SET @BATCH = (Select max(convert(int,ID)) + 1 from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK))
			--Set @DATE = '202104071524'
			
			Print @DATE

			--Select * From [TaxSourceAPI].[dbo].[Batch]
			--Order by ID desc

			
			INsert into [TaxSourceAPI].[dbo].[Batch]([Name])
			Select @CUSTOMER + '_' + @DATE

			SET @BATCH = (Select ID from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			)

			Print @BATCH

			Update [TaxSourceAPI].[dbo].[Batch]
			Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Renew_Financial\TaxSource\IMAGES\'+@DATE+'_'+@BATCH+'\Images'
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			and ID = @BATCH

			

			Select MAX(ID) From [TaxSourceAPI].[dbo].[Batch]
			where Name like 'RenewFinancial%'
			


		
			
			Update [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
			Set BatchID = (Select MAX(ID) From [TaxSourceAPI].[dbo].[Batch]
			where Name like 'RenewFinancial%')
			where DATE_COMPLETED is null
	
		


				Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId
				-----Changed 20220406 to populate FULL address rather than parsed so the executable submits the SearchType of FULLADDRESS rather than ADDRESS
				-----per GT & MC
				--, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
				,AddressLine
				, City, State, Zip, RefId, APN, Fips
				, REFERENCEID)
				
				Select 
				A.RAW_ID
				,B.[BATCHID]
				--,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
				,FullStreetAddress
				, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
				----Added 20210326 so customer can pass through their secondary reference id
				--,ROW_NUMBER() OVER (order by RAW_ID)
				,B.[Reference ID]
				From [zCust_RenewFinancial].[dbo].[a_Propmatch_WORk] as A 
				join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
				where B.BATCHID = 
				(Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
				where DATE_COMPLETED is null)
				
					


			Select count(*)  as ASP_COUNT From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]

			
			
			Select count(*) as ASP_COUNT  From [TaxSourceAPI].[dbo].[Property] as A 
			join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
			and A.ExternalKey = B.UniqueID
		

		
			Update [TaxSourceAPI].[dbo].[Property]
			Set ExternalKey = LTRIM(RTRIM(ExternalKey))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ExternalKey like '% %'

		

			Update [TaxSourceAPI].[dbo].[Property]
			Set ReferenceId = LTRIM(RTRIM(ReferenceId))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ReferenceId like '% %'


			Select ReferenceId , ExternalKey From [TaxSourceAPI].[dbo].[Property]
			where  BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and (ReferenceId like '% %'
			OR ExternalKey like '% %')



		
		Select BatchID, count(*) T From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
		Group by BATCHID

		--Select count(*) as ASP_COUNT 
		--FROM TaxSourceAPI.[dbo].[OutputLayout5] as A with(NOLOCK)
		--join zCust_RenewFinancial.dbo.INPUT_MONITOR as B  with(NOLOCK)
		--on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and ReportStatus like 'Ready'

	

		
END



