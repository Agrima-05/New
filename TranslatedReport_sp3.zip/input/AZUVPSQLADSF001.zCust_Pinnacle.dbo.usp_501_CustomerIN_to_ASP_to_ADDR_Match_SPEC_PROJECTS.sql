SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_Pinnacle].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match_SPEC_PROJECTS] 
	
AS
BEGIN

	SET NOCOUNT ON;

	

	--------------------------

		
		SET CONCAT_NULL_YIELDS_NULL OFF

		


		--Truncate table INPUT_IN

		--INSERT INTO INPUT_IN(INPUTKEY,INPUTADDRESS,INPUTCITY, INPUTSTATE, INPUTZIP)
		--Select  
		--[UniqueID]
     
  --    ,[Address]
  --    ,[City]
  --    ,[State]
    
  --    ,[APN]
  --    ,[FIPS]
	 -- ,[DTRefID]
		----FROM [zCust_Pinnacle].[dbo].[INPUT_RAW_20240701]
		----Select * 
		--FROM [zCust_Pinnacle].[dbo].[INPUT_RAW_CUST_SPEC_PROJ]

	 --  Select ROW_NUMBER() OVER (ORder by STREET,CITY,STATE,ZIPCODE) 
	 --  ,STREET,CITY,STATE,ZIPCODE
		--from [dbo].[INPUT_RAW_MAILADDR_20260924_2]

		Select * From [zCust_Pinnacle].[dbo].[INPUT_IN]

		-----------------20240925 - Per EC - Their contract allows 5K input records per month!!!------------

		  IF( Select (Select ISNULL(sum(totalrecords),'0') From [zCust_Pinnacle].[dbo].[ADS_COUNTS]	  where BillingDate is null
		  ----Added 20241001 as Pinnacle is going by calendar month 
			  and DATEPART(MM,CreateDate) = DATEPART(MM,getdate())
			  ) + (Select count(*)  FROM [zCust_Pinnacle].[dbo].[INPUT_IN])
		  ) > 4500

		
		--Select * From ADS_COUNTS	  where BillingDate is null
	

		BEGIN


	  
	
				DECLARE @query NVARCHAR(MAX)
				DECLARE @count varchar(50)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @count =  case when  ((Select sum(totalrecords) From [zCust_Pinnacle].[dbo].[ADS_COUNTS]	  where BillingDate is null) + (Select count(*)  FROM [zCust_Pinnacle].[dbo].[INPUT_IN])) 
				is null then 0 else ((Select sum(totalrecords) From [zCust_Pinnacle].[dbo].[ADS_COUNTS]	  where BillingDate is null) + (Select count(*)  FROM [zCust_Pinnacle].[dbo].[INPUT_IN]))  end
				--Print @count
				Set @Subject = 'Pinnacle - Approaching 5K records this month!! = ' + @count + ' -Date ' + @Date 
				
				

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = NULL,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;
		

		END



	
		Select top 10000 * From [zCust_Pinnacle].[dbo].[INPUT_IN]
	  
		Select * From [zCust_Pinnacle].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'
	 
		Select count(*) From [zCust_Pinnacle].[dbo].[INPUT_IN]

		Select * From [zCust_Pinnacle].[dbo].[INPUT_IN]
		where INPUTKEY in (
		Select INPUTKEY from (
		Select INPUTKEY, count(*) as TOTAL From [zCust_Pinnacle].[dbo].[INPUT_IN]
		Group by INPUTKEY
		having count(*) > 1)A)
		Order by INPUTKEY



		

		Select *From [zCust_Pinnacle].[dbo].[INPUT_IN]
		where len(INPUTZip) > 10

		Update [zCust_Pinnacle].[dbo].[INPUT_IN]
		Set INPUTAddress = REPLACE(INPUTAddress,'  ',' ')
		where INPUTAddress like '%  %'

		Select * From [zCust_Pinnacle].[dbo].[INPUT_IN]
		where INPUTAddress like '%  %'

		Update [zCust_Pinnacle].[dbo].[INPUT_IN]
		Set INPUTCity = REPLACE(INPUTCity,'  ',' ')
		where INPUTCity like '%  %'

		Select * From [zCust_Pinnacle].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'

		UPDATE [zCust_Pinnacle].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_Pinnacle].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

		UPDATE [zCust_Pinnacle].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2
      


    EXEC [zCust_Pinnacle].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_Pinnacle].[dbo].[Pinnacle_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_Pinnacle].[dbo].[Pinnacle_STD])
					END
			END

	---- APPENDS ASP DATA BACK TO DATABASE 

    EXEC [zCust_Pinnacle].[dbo].[usp_100c_sp_ASP_Cust_STD]

	Select count(*) From [zCust_Pinnacle].[dbo].[INPUT_IN]
	Select count(*) From [zCust_Pinnacle].[dbo].[a_ASP_IN_STD]
	
	Update [zCust_Pinnacle].[dbo].[a_ASP_IN_STD]
	Set FIPS = RIGHT('0' + convert(varchar(5),FIPS),5)
	where FIPS not like '0'

	Select FIPS, count(*) from [zCust_Pinnacle].[dbo].[a_ASP_IN_STD]
	Group by FIPS
	ORDER BY FIPS


	--------------------20241010 - Per Customer (Jennifer) - USE THEIR INPUT FIPS--------------------

	Update [zCust_Pinnacle].[dbo].[A]
	Set A.FIPS = RIGHT('0' + convert(varchar(5),B.INPUT_FIPS),5)
	--Select A.FIPS,  B.INPUT_FIPS, B.INPUT_PROPID
	From [zCust_Pinnacle].[dbo].[a_ASP_IN_STD] as A 
	join [zCust_Pinnacle].[dbo].[INPUT_IN] as B on A.RAW_ID = B.INPUTKey
	where A.FIPS <> B.INPUT_FIPS
	and RIGHT('0' + convert(varchar(5),A.FIPS),5) <> RIGHT('0' + convert(varchar(5),B.INPUT_FIPS),5)
	

	Select FIPS, count(*)  From [zCust_Pinnacle].[dbo].[a_ASP_IN_STD]
	Group by FIPS
	Order by FIPS
	

	----------------------------------------- COMMENTING OUT PRE-MATCH to Force Match on APN FIRST PER CUSTOMER!!!!!-----------------------
	---------------20241010 - Per customer (Jennifer) - change match heirarchy to tbe below:

----2.	The match hierarchy she wants us to use is:
		----a.	DTREFID (if populated and if still an active REF_ID/hasn’t changed)
		----b.	INPUT FIPS + APN (This requires the correct the correct Input FIPS to be provided)
		----c.	Address



		 ------New Process 20210203 to Prematch FLANK-----
			  
			 
			  IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_PreMatch]') AND type in (N'U'))
			  DROP TABLE [dbo].[w_PreMatch]

			  
              SELECT Right('0' + A.FIPS,5) as FIPS, A.FullStreetAddress, A.City, A.State, A.Zip, A.ZIP4, convert(bigint,0) as PropertyID,'' as MulitMatch
			  ,RAW_ID
			  ,B.INPUTBorrowerLastName
              INTO [zCust_Pinnacle].[dbo].[w_PreMatch]
			  FROM [zCust_Pinnacle].[dbo].[a_ASP_IN_STD] as A 
			  join [zCust_Pinnacle].[dbo].[INPUT_IN] as B on A.RAW_ID = B.INPUTKey

			  

              Create index [ix_Addr] on [dbo].w_PreMatch(FIPS,FullStreetAddress,Zip,Zip4)

          --    DECLARE @FipsCode varchar(5)

          --    DECLARE Prematch CURSOR FOR  
          --           SELECT Distinct [FIPS] 
          --           FROM [dbo].w_PreMatch
          --           WHERE LEN(FIPS)=5
          --           ORDER BY [FIPS]


          --    OPEN Prematch   
          --    FETCH NEXT FROM Prematch INTO @FipsCode

          --    WHILE @@FETCH_STATUS = 0   
          --    BEGIN   
  
          --           PRINT @FipsCode

					

          --           EXEC('UPDATE a
          --                        SET a.PropertyID = b.Propertyid
          --                        FROM [dbo].[w_PreMatch] a JOIN zCust_ADS__00_SharedProcs.dbo.Property b with(NOLOCK)
          --                        on a.FIPS = b.FIPS
          --                        and a.FullStreetAddress = b.SitusStdFullStreetAddress
          --                        and a.Zip = b.SitusStdZIP5
          --                        and a.ZIP4 = b.SitusStdZIP4
          --                        WHERE a.FIPS = ''' + @FipsCode + '''
          --                        and b.FIPS = ''' + @Fipscode + '''
								  --AND ISNULL(a.FullStreetAddress,'''') not like ''''
								  --AND ISNULL(a.Zip,'''') not like ''''
          --                 ')

                
						   	--EXEC('UPDATE a
          --                        SET a.PropertyID = NULL
          --                        FROM [dbo].[w_PreMatch] a 
								  --JOIN zCust_ADS__00_SharedProcs.dbo.Property_DUPS b with(NOLOCK)
          --                        on a.FIPS = b.FIPS
          --                        and a.FullStreetAddress = b.SitusStdFullStreetAddress
          --                        and a.Zip = b.SitusStdZIP5
          --                        and a.ZIP4 = b.SitusStdZIP4
          --                        WHERE a.FIPS = ''' + @FipsCode + '''
          --                        and b.FIPS = ''' + @Fipscode + '''
          --                 ')
                     
          --           FETCH NEXT FROM Prematch INTO @FipsCode   
          --    END   

          --    CLOSE Prematch   
          --    DEALLOCATE Prematch 


		  ------------Added 20241010 to force match on REF_ID
				UPDATE [zCust_Pinnacle].[dbo].[a]
                SET a.PropertyID = C.PropertyID
                --Select A.RAW_ID, B.FIPS, B.State, C.FIPS, C.SitusStdState
				FROM [zCust_Pinnacle].[dbo].[w_PreMatch] a 
				join [zCust_Pinnacle].[dbo].[INPUT_RAW_CUST_SPEC_PROJ] as B on A.RAW_ID = B.UniqueID
				join [data].[dbo].[Property] as C with(NOLOCK) on B.DTRefID = C.DTDB_Ref_ID
				where ISNULL(B.DTRefID,'') not like ''
				and C.FAUCIDFlag not like 'D'


				UPDATE [zCust_Pinnacle].[dbo].[a]
                SET a.PropertyID = C.PropertyID
                --Select A.RAW_ID, B.FIPS, B.State, C.FIPS, C.SitusStdState
				FROM [zCust_Pinnacle].[dbo].[w_PreMatch] a 
				join [zCust_Pinnacle].[dbo].[INPUT_RAW_CUST_SPEC_PROJ] as B on A.RAW_ID = B.UniqueID
				join [data].[dbo].[Property] as C with(NOLOCK) on B.DTRefID = C.DTDB_Ref_ID
				where ISNULL(B.DTRefID,'') not like ''
				--and C.FAUCIDFlag not like 'D'
				and A.PropertyID like '0'



			--	Select * From data.dbo.Property with(NOLOCK)
			--	where FIPS = '36051'
			--	and formattedapn like '243889 189.-1-54%'


			
			--Select top 10 * FROM [dbo].[w_PreMatch] a 
			--join INPUT_RAW_CUST_SPEC_PROJ as B on A.RAW_ID = B.UniqueID
			--where propertyid = 0


              Select count(*) from [zCust_Pinnacle].[dbo].[w_PreMatch]
              Select count(*) from [zCust_Pinnacle].[dbo].[w_PreMatch] where propertyid = 0


			   IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[INPUT_IN_PREMATCH]') AND type in (N'U'))
			  DROP TABLE [dbo].[INPUT_IN_PREMATCH]


			 Select * into [zCust_Pinnacle].[dbo].[INPUT_IN_PREMATCH]
			 From [zCust_Pinnacle].[dbo].[INPUT_IN]

			 Truncate table INPUT_IN

			 Insert into [zCust_Pinnacle].[dbo].[INPUT_IN]
			 Select A.* From [zCust_Pinnacle].[dbo].[INPUT_IN_PREMATCH] as A 
			 join [zCust_Pinnacle].[dbo].[w_PreMatch] as B on A.INPUTKey = B.RAW_ID
			 join [zCust_Pinnacle].[dbo].[a_ASP_IN_STD] as C on A.InputKey = C.RAW_ID
			 where (PropertyID like '0' or PropertyID is null or PropertyID like '')
			 and A.InputAddress not like 'P%'
			 and C.FIPS not like '0'


			Select count(*) From [zCust_Pinnacle].[dbo].[INPUT_IN]
			Select count(*) From [zCust_Pinnacle].[dbo].[INPUT_IN_PREMATCH]


	
	--EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_Pinnacle'
	
	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_Pinnacle'


		---Append Prematch records---
	INSERT INTO [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]([ASP_ID]
				  ,[FullStreetAddress]
				  ,[HouseNbr]
				  ,[LeftDirection]
				  ,[Street]
				  ,[Mode]
				  ,[RightDirection]
				  ,[UnitNumber]
				  ,[City]
				  ,[State]
				  ,[Zip]
				  ,[Zip4]
				  ,[Zip9]
				  ,[FIPS]
				  ,[CountyName]
 				  ,[BorrowerLastName]
				 ,[RAW_ID]
				 ,[INPUTAPN]
				 ,PropertyID)
				Select distinct A.[ASP_ID]
				  ,A.[FullStreetAddress]
				  ,A.[HouseNbr]
				  ,A.[LeftDirection]
				  ,A.[Street]
				  ,A.[Mode]
				  ,A.[RightDirection]
				  ,A.[UnitNumber]
				  ,a.[City]
				  ,a.[State]
				  ,a.[Zip]
				  ,a.[Zip4]
				  --,a.[zip]+isNULL(a.[zip4],'''') as [Zip9]
				  ,RIGHT(('0' + a.[zip]),5) + isNULL(a.[zip4],'') as [Zip9]
				  ,A.[FIPS]
				  ,A.[CountyName]
				  ,C.[INPUTBorrowerLastName]
				  ,A.[RAW_ID]
				  ,LEFT([InputAPN],50)
				  ,C.PropertyID
				   from [zCust_Pinnacle].[dbo].[a_ASP_IN_STD] a 
				   left outer join [zCust_Pinnacle].[dbo].[w_PreMatch] as C on A.RAW_ID = C.RAW_ID
				  LEFT OUTER JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] as B  
				  on a.[RAW_ID] = b.[RAW_ID]
				  where B.[RAW_ID] is null



				 Select count(*) From [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
				 Select count(*) From [zCust_Pinnacle].[dbo].[a_ASP_IN_STD]



		-- Post append clean up

		UPDATE [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
		SET Street = left([xMSmith].[dbo].[BeforeLastSpace](substring(street,1,LEN(Street)-(LEN(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%'
		, REVERSE(street)) - 1)))))),55)
		,UnitNumber = left(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%', REVERSE(street)) - 1)),15)
		WHERE REF_ID is null 
		AND Street like '% %[a-z][0-9]%[0-9]' or street like '% %[a-z][0-9]'
		

		UPDATE [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
		SET HouseNbr = left(REPLACE(HouseNbr,LeftDirection,''),30)
		WHERE isNULL(LeftDirection,'') not like '' AND HouseNbr like '%' + LeftDirection
		

		UPDATE [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
		SET INPUTAPN = NULL
		WHERE INPUTAPN = '0' or INPUTAPN = ''
	

	
		Update [zCust_Pinnacle].[dbo].[A]
		Set 
		A.REF_ID = B.DTDB_Ref_ID
		--Select A.RAW_ID, A.REF_ID, B.DTDB_Ref_ID, A.FullStreetAddress, B.SitusStdFullStreetAddress
		From [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] as A 
		join [data].[dbo].[Property] as B with(NOLOCK) on 
		A.PropertyID = B.PropertyID
		where A.PropertyID is not null
		and (A.REF_ID is null or A.REF_ID <> B.DTDB_Ref_ID)
		and B.DTDB_Ref_ID is not null
		--and RAW_ID = '0580380017 7274510'


		Select count(*) FRom [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] where REF_ID is null

	
	Truncate table a_PropMatch_WORK
	Insert into [zCust_Pinnacle].[dbo].[a_PropMatch_WORK]
	Select * From [zCust_Pinnacle].[dbo].[a_PropMatch_WORK_FLANK]



	Truncate table INPUT_IN

	Insert into [zCust_Pinnacle].[dbo].[INPUT_IN]
	Select * From [zCust_Pinnacle].[dbo].[INPUT_IN_PREMATCH]

	Select count(*) FRom [zCust_Pinnacle].[dbo].[INPUT_IN]
	Select count(*) FRom [zCust_Pinnacle].[dbo].[INPUT_IN_PREMATCH]





		Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
		WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
		ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
		from [zCust_Pinnacle].[dbo].[a_PropMatch_WORK]
		group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
		WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
		ELSE 'Matched' END

		Select CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
		WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
		ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
		from [zCust_Pinnacle].[dbo].[a_PropMatch_WORK_FLANK]
		group by CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
		WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
		ELSE 'Matched' END


			Select A.RAW_ID, A.INPUTAPN, A.PropertyID, A.MatchQuery, A.FIPS, B.FIPS
			,B.APN, C.FormattedAPN, C.TaxAccountNumber, B.DTRefID
			From [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] as A 
			join [zCust_Pinnacle].[dbo].[INPUT_RAW_CUST_SPEC_PROJ] as B on A.RAW_ID = B.UniqueID
			left outer join [data].[dbo].[Property] as C with(NOLOCK) on A.PropertyID = C.PropertyID
			where A.Propertyid like '' or A.Propertyid like '0' or A.Propertyid is null

			--Update a_PropMatch_Work_FLANK
			--set 
			--PropertyID = '48673816'
			--where RAW_ID = '9962'

			--Select FIPS, PropertyID, formattedapn, faucidflag, DTDB_REF_ID, SitusSTDFullStreetAddress, fatimestamp, fadatereceived
			--From data.dbo.Property with(NOLOCK)
			--where FIPS = '17197'
			--and formattedapn like '15-08-16-300-034%'

			--Select FIPS, DTDB_REF_ID, FAUCIDFLAG From data.dbo.Property with(NOLOCK)
			--where DTDB_REF_ID in (233961461,49736934)



END


