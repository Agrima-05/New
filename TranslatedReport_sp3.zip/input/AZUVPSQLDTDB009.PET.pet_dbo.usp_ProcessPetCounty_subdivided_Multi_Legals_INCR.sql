/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_subdivided_Multi_Legals_INCR | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================    
-- Author:        <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description:   <Description,,>    
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'     
-- =============================================    
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR] @fips INT
	,@FeatureName AS VARCHAR(50)
	,@ServiceName AS VARCHAR(50)
	,@FormatId AS VARCHAR(10)
	,@Incremental_Flag BIT
AS
--Set @FormatId = Case when @fips in (6059,6065) then 'TT' else @FormatId end    
EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_subdivided_Multi_Legals_INCR'
	,N'Started'

DECLARE @GetDynamicFormat tmpGetDynamicFormat

SET @Incremental_Flag = isnull(@Incremental_Flag, 0)

INSERT INTO @GetDynamicFormat (
	[FeatureName]
	,[ServiceName]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[OutputField]
	,[LongDesc]
	,[Label]
	,[MsgLabel]
	,[Partner]
	,[PartnerType]
	,[WildStart]
	,[DataType]
	,[Required]
	,[Enumeration]
	,[TabIndex]
	,[FromField]
	,[DataTreeIndexes]
	,[FormatChar]
	,[_overlay]
	,[ROW4]
	)
EXEC [pet].[dbo].[GetDynamicFormat] @FeatureName --'TITLE_SERVICES'    
	,@ServiceName --'SUBDIVIDED'    
	,@FormatId --@PPLNT_PLAT_ID_FRMT    

--UPDATE t1    
--SET t1._overlay = (    
--  SELECT count(1)    
--  FROM @GetDynamicFormat t2    
--  WHERE t2.ROW4 < t1.ROW4    
--   AND t1.Offset BETWEEN t2.Offset    
--    AND (t2.Offset + t2.[Length])    
--  )    
--FROM @GetDynamicFormat t1    
--SELECT 'Subdivided parms' AS aaaa    
-- ,*    
--FROM @GetDynamicFormat    
--DECLARE @year_pos INT = (    
--  SELECT p.offset    
--  FROM @GetDynamicFormat p    
--  WHERE p.Field = 'Year'    
--  )    
-- ,@Ref_id INT = NULL --13580129    
DROP TABLE

IF EXISTS [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR_temp]
	SELECT DISTINCT a.REF_ID
		,a.NEO_APN
		,a.NEO_LAND_TYPE
		,a.NEO_TITLE_LEGAL
		,CASE 
			WHEN ltrim(Rtrim(a._field)) = 'TorTeeNAme'
				THEN CASE 
						WHEN substring(a._field, len(a._field), 1) = '1'
							THEN 'GrantorName'
						WHEN substring(a._field, len(a._field), 1) = '2'
							THEN 'GranteeName'
						ELSE a._field
						END
			ELSE a._field
			END AS _field
		,a._value
		,NULL AS BookType
		,a.fips
		,a.ROW4
	INTO [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR_temp]
	FROM (
		SELECT -- top 100     
			t.REF_ID
			,t.NEO_APN
			,t.NEO_LAND_TYPE
			,t.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL
			,t.Fips
			,field AS _field
			,fld_value AS _value
			,0 AS row4
		FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (
				NOLOCK
				,INDEX (idx_fips_neoAPN)
				)

		cross APPLY (
			SELECT *
			FROM [pet].[dbo].[PET_neo_legals] t WITH (
					NOLOCK
					,INDEX (ix_fipsNEO)
					)
			WHERE t.fips = incr.fips
				AND t.neo_apn = incr.neo_apn
				and t.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
				AND t.NEO_LAND_TYPE IN ('SB')
			) t


		OUTER APPLY (
			SELECT *
			FROM [pet].[dbo].[fn_filter_overlap_on_dynamic_format](t.NEO_TITLE_LEGAL, @GetDynamicFormat)
			) p
		WHERE incr.fips = @fips
			AND incr.NEO_LAND_TYPE IN ('SB')
			-- AND (  
			-- @incremental_flag = 0  
			-- OR (  
			--  @incremental_flag = 1  
			--  AND incr.neo_apn IS NOT NULL  
			--  )  
			-- )  
		) a
	WHERE isnull(a._value, '') > ''

CREATE UNIQUE INDEX ix_ref_id_field ON [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR_temp] (
	Fips
	,REF_ID
	,NEO_APN
	,NEO_TITLE_LEGAL
	,_field
	)

INSERT INTO [PET].[dbo].[Pet_LabelColumns_Multi_Legals] (
	[REF_ID]
	,NEO_APN
	,[NEO_LAND_TYPE]
	,[NEO_TITLE_LEGAL]
	,[_field]
	,[_value]
	,[fips]
	,ROW4
	,BookType
	)
SELECT b.[REF_ID]
	,b.NEO_APN
	,b.[NEO_LAND_TYPE]
	,b.[NEO_TITLE_LEGAL]
	,b.[_field]
	,b.[_value]
	,b.fips
	,b.ROW4
	,b.BookType
FROM [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR_temp] b
LEFT JOIN [PET].[dbo].[Pet_LabelColumns_Multi_Legals] c ON c.Fips = b.Fips
	AND c.REF_ID = b.REF_ID
	AND c.NEO_APN = b.NEO_APN
	AND c.NEO_TITLE_LEGAL = b.NEO_TITLE_LEGAL
	AND c._field = b._field
WHERE c.ref_id IS NULL

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_subdivided_Multi_Legals_INCR'
	,N'Ended'


