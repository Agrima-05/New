/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | LEAP.usp_LeapDailyLoad | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[LEAP].[usp_LeapDailyLoad] @Created_Date DATETIME = NULL --'2017-12-04 04:44:11.000'
AS
BEGIN
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_LeapDailyLoad'
		,N'Started'

	--use Lien rollback '20180228 08:00:15.000', '20180308 22:22:09.000'
	--DECLARE @Created_Date DATETIME = '20240102 17:00:47.000'
	--BEGIN TRY
	--
	--Deteremine which LEAP_NEW records need to be copied to UR_DOCUMENT
	--
	/*IF object_id('Tempdb..#InputRecords') IS NOT NULL
		*/
DROP TABLE IF EXISTS #InputRecords;

	SELECT CASE 
			WHEN a.Recording_Doc_Nbr IS NULL
				THEN a.Recording_Book_Nbr + '-' + a.Recording_Page_Nbr
			ELSE a.Recording_Doc_Nbr
			END AS InstrumentNumber
		,CASE 
			WHEN Reference_Energy_Doc_Number IS NULL
				THEN a.Reference_Energy_Doc_Book + '-' + a.Reference_Energy_Doc_Page
			ELSE a.Reference_Energy_Doc_Number
			END AS ref_instrumentNumber
		,Reference_Energy_Recording_Date AS Ref_Recording_Date
		,isnull(APN, '') AS _APN
		,isnull(Court_Case_Number, '') AS _Court_Case_Number
		,isnull(Multiple_Record_Indicator1, '') AS _Multiple_Record_Indicator1
		,isnull(Multiple_Record_Indicator2, '') AS _Multiple_Record_Indicator2
		--,CASE 
		--	WHEN isnull(a.Document_Code, '') IN (
		--			'DOTSPR'
		--			,'DOTSRC'
		--			,'DOTSTRWAS'
		--			)
		--		OR (
		--			d.DocumentCode IS NOT NULL
		--			AND d.[DOC CODE] IS NULL
		--			)
		--		THEN 1
		--	ELSE 0
		--	END AS SkipInd
		,0 AS Skipind
		,CASE 
			WHEN a.Document_Type IS NULL
				THEN 1
			ELSE 0
			END AS NUll_Document_Type
		,CASE 
			WHEN a.Document_Code IS NULL
				THEN 1
			ELSE 0
			END AS NUll_Document_Code
		,CASE 
			WHEN a.Document_Code IS NOT NULL
				AND dt.DocumentCode IS NOT NULL
				THEN 1
			ELSE 0
			END AS erp_Document_Code
		,CASE 
			WHEN a.Document_Code IS NOT NULL
				AND dc.[DOC CODE] IS NOT NULL
				THEN 1
			ELSE 0
			END AS Leap_document_code
		,checksum(a.[State], a.[County], a.[Fips], a.[Vendor_Code], a.[Recording_Doc_Nbr], a.[Recording_Book_Nbr], a.[Recording_Page_Nbr], a.[Recording_Date], a.[Document_Type], a.[Document_Code], a.[Correction_Indicator], a.[Lien_Issuing_Agency], a.[Federal_Tax_Lien_Area], a.[Tax_Lien_Serial_Nbr] /*, a.[Party1_FirstName], a.[Party1_MiddleName], a.[Party1_LastName], a.[Party1_NameSuffix], a.[Party1_Alias_Name_Type]*/, a.[Party1_Mail_Street_Addr], a.[Party1_Mail_City], a.[Party1_Mail_State], a.[Party1_Mail_Zip_Code], a.[Party1_Mail_Zip_Plus4], a.[Foreign_Addr_Part1], a.[Foreign_Addr_Part2], a.[Foreign_Addr_Part3], a.[Party1_Account_Nbr], a.[Filler1], a.[Party1_SSN_Nbr], a.[Filler2], a.[Party1_Driver_License_Nbr], a.[Party1_Driver_License_State], a.[Filler3], a.[Additional_Judgement_Debtors], a.[Kind_Of_Tax], a.[Tax_Period_Minimum], a.[Tax_Period_Maximum], a.[Last_Day_For_Refiling], a.[Total_Lien_Estimated_Amount], a.[Federal_Tax_Lien_Prepared_Signed_City_Name], a.[Federal_Tax_Lien_Prepared_Signed_State_Code], a.
			[Federal_Tax_Lien_Energy_Doc_Date], a.[Reference_Energy_Doc_Number], a.[Reference_Energy_Doc_Book], a.[Reference_Energy_Doc_Page], a.[Reference_Energy_Recording_Date], a.[Court_Case_Number], a.[Party2_First_Name], a.[Party2_Middle_Name], a.[Party2_Last_Name], a.[Party2_Name_Suffix], a.[Party2_Mailing_Street], a.[Party2_Mailing_City], a.[Party2_Mailing_State], a.[Party2_Mailing_Zip], a.[Party2_Mailing_ZipPlus4], a.[Filler4], a.[Party2_SSN_Number], a.[Party3_First_Name], a.[Party3_Middle_Name], a.[Party3_Last_Name], a.[Party3_Name_Suffix], a.[Divorce_Decree_Filing_Date], a.[Property_Address], a.[Property_City], a.[Property_State], a.[Property_Zip_Code], a.[Property_Zip_Plus4], a.[Filler5], a.[Respondent_SSN_Number], a.[Attorney_Name], a.[Attorney_Phone_Number], a.[Attorney_Flag], a.[Judgment_Creditor], a.[Assignee_Of_Record], a.[Abstract_Issued_Date], a.[Creditor_Name], a.[Producer_Email_Address], a.[Solar_Energy_TermExpire_Date], a.[Solar_Energy_Type_Of_Agreement], a.[Installment_Judgment], a.[Stay_Ordered], a.
			[Stay_Ordered_Date], a.[Interest_Rate], a.[Back_Support_Amount], a.[Filler6], a.[Filler7], a.[Filler8], a.[Filler9], a.[Filler10], a.[Apn], a.[Apn_Portion_Indicator], a.[Multiple_Record_Indicator1], a.[Multiple_Record_Indicator2], a.[Apn_Research_Indicator], a.[Lot], a.[Block], a.[Tract_Name], a.[Parcel], a.[Parcel_Map_Book], a.[Parcel_Map_Page], a.[Section], a.[Township], a.[Range], a.[Unit_Number], a.[Municipality_Code], a.[District_Number], a.[District_Suffix_Number], a.[Land_Lot], a.[Party_1A_First_Name], a.[Party_1A_Middle_Name_or_Initial], a.[Party_1A_Last_Name], a.[Party_1A_Name_Suffix], a.[Party_1B_First_Name], a.[Party_1B_Middle_Name_or_Initial], a.[Party_1B_Last_Name], a.[Party_1B_Name_Suffix], a.[Party_1C_First_Name], a.[Party_1C_Middle_Name_or_Initial], a.[Party_1C_Last_Name], a.[Party_1C_Name_Suffix], a.[Party1_ETAL_Indicator], a.[Created_Date], a.[Party1_Company_Name], a.[Party2_Company_Name], a.[Party3_Company_Name], a.[Party1A_Company_Name], a.[Party1B_Company_Name], a.[Party1C_Company_Name], a.
			[Filler11], a.[Filler12], a.[Party1A_Alias_Name_Type], a.[Party1B_Alias_Name_Type], a.[Party1C_Alias_Name_Type]) AS _checksum
		,a.*
	INTO #InputRecords
	FROM [lien].[leap].[leap] a
	OUTER APPLY (
		SELECT d.DocumentCode
			,b.[DOC CODE]
		FROM [Lien].[LEAP].[DocumentType] d
		LEFT JOIN [lien].[LEAP].[LeapDocumentCode] b ON d.DocumentCode = b.[DOC CODE]
		WHERE d.DocumentCode = a.Document_Code
		) d
	LEFT JOIN [Lien].[LEAP].[DocumentType] dt ON dt.DocumentCode = a.Document_Code
	LEFT JOIN [Lien].[LEAP].[LeapDocumentCode] dc ON dc.[DOC CODE] = a.Document_Code
	WHERE a.created_date = @Created_Date

	--and a.id in (3577244, 3577384, 3577243, 3577242, 3577349, 3577241, 3577239, 3577385, 3577240, 3577386)
	--a.Created_Date = '20180514 09:01:17.000' and a.id in (3514789, 3514792)
	--WHERE a.id in (3577243, 3577241, 3577242, 3577240, 3577239, 3577385, 3577386, 3577349, 3577244, 3577384) --created_date = @Created_Date
	--and Recording_Doc_Nbr in ('2017336802') -- ('2017169895','2017172419', '2017172420', '2017172214', '2017171474')
	--select * from lien.leap.leap a  WHERE a.id in (3577243, 3577241, 3577242, 3577240, 3577239, 3577385, 3577386, 3577349, 3577244, 3577384) --created_date = @Created_Date
	--select top 100 * from lien.leap.leap  order by created_date desc
	-- select * from #InputRecords where id = 282769 
	CREATE INDEX ix_key ON #InputRecords (
		FIps
		,InstrumentNumber
		,Recording_Date
		,_APN
		,_Court_Case_Number
		)

	CREATE NONCLUSTERED INDEX IX_Skip ON #InputRecords (
		[erp_Document_Code]
		,[Leap_document_code]
		) INCLUDE ([ID])

	UPDATE [Lien].[LEAP].[a]
	SET a.skipind = 1
	FROM #inputRecords a
	WHERE a.erp_Document_Code = 1
		AND a.Leap_document_code = 0 -- skip records

	TRUNCATE TABLE [Lien].[tmp].[LEAP_KEY_IDS]

	INSERT INTO [Lien].[tmp].[LEAP_KEY_IDS] (
		[ID]
		,[Fips]
		,[InstrumentNumber]
		,[Recording_Date]
		,[Apn]
		,[Court_Case_Number]
		,[Created_Date]
		,[Leap_id]
		,[SkipInd]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Multi_Row]
		,[_checksum]
		)
	SELECT g.ID
		,Fips
		,InstrumentNumber
		,Recording_Date
		,Apn
		,Court_Case_Number
		,Created_Date
		,Leap_id
		,SkipInd
		,Multiple_Record_Indicator1
		,Multiple_Record_Indicator2
		--,case when Multiple_Record_Indicator1 = ''  and  Multiple_Record_Indicator2 = '' then ' ' else Multi_Row end as Multi_Row
		,CASE 
			WHEN Multiple_Record_Indicator1 = 'M'
				OR Multiple_Record_Indicator2 = 'M'
				THEN '1'
			ELSE Multi_Row
			END AS Multi_Row
		,_checksum
	FROM (
		SELECT ID
			,[Fips]
			,a.InstrumentNumber
			,a.Recording_Date
			,[Apn]
			,Court_Case_Number
			,[Created_Date]
			,0 AS Leap_id
			,a.SkipInd
			,b.Multiple_Record_Indicator1
			,b.Multiple_Record_Indicator2
			,ROW_NUMBER() OVER (
				PARTITION BY a.fips
				,a.InstrumentNumber
				,a.Recording_Date
				,isnull(a.Apn, '')
				,isnull(a.Court_Case_Number, '')
				,a.created_date
				,b._multiSort ORDER BY b._multiSort
				) AS Multi_Row
			,_checksum
		FROM #InputRecords a
		OUTER APPLY (
			SELECT count(1) AS ref_instrumentNumber_cnt
			FROM (
				SELECT DISTINCT ref_instrumentNumber
				FROM #InputRecords t
				WHERE t.fips = a.Fips
					AND t.InstrumentNumber = a.InstrumentNumber
					AND t.Recording_Date = a.Recording_Date
					AND t._APN = a._APN
					AND t._Court_Case_Number = _Court_Case_Number
				) j
			) AS r
		OUTER APPLY (
			SELECT /*case when r.ref_instrumentNumber_cnt > 1 then _Multiple_Record_Indicator1 else '' end AS Multiple_Record_Indicator1
			,case when ref_instrumentNumber_cnt > 1 then _Multiple_Record_Indicator2 else '' end AS Multiple_Record_Indicator2*/
				_Multiple_Record_Indicator1 AS Multiple_Record_Indicator1
				,_Multiple_Record_Indicator2 AS Multiple_Record_Indicator2
				--,case when _Multiple_Record_Indicator1 = 'M' or _Multiple_Record_Indicator2 = 'M' then 1 else 0 end _multiSort
				,CASE 
					WHEN Multiple_Record_Indicator1 = 'M'
						OR Multiple_Record_Indicator2 = 'M'
						THEN a.ID
					ELSE 0
					END AS _multiSort
				,CASE 
					WHEN a.Recording_Doc_Nbr IS NULL
						THEN a.Recording_Book_Nbr + '-' + a.Recording_Page_Nbr
					ELSE a.Recording_Doc_Nbr
					END AS InstrumentNumber
				,CASE 
					WHEN Reference_Energy_Doc_Number IS NULL
						THEN a.Reference_Energy_Doc_Book + '-' + a.Reference_Energy_Doc_Page
					ELSE a.Reference_Energy_Doc_Number
					END AS ref_instrumentNumber
				,Reference_Energy_Recording_Date AS Ref_Recording_Date
			) b
		) g

	--   select * from [Lien].[tmp].[LEAP_KEY_IDS]
	--select * from lien.leap.leap where id in (757800, 757801, 757802, 757803, 757804, 757805, 757806, 757807, 757808, 757809, 757810)
	TRUNCATE TABLE [Lien].[tmp].[LEAP_KEYS]

	INSERT INTO [Lien].[tmp].[LEAP_KEYS] (
		[Fips]
		,[InstrumentNumber]
		,[Recording_Date]
		,[Apn]
		,[Court_Case_Number]
		,[Created_Date]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[recording_doc_sequence_number]
		,[SkipInd]
		,[ID]
		)
	SELECT a.Fips
		,a.InstrumentNumber
		,a.Recording_Date
		,a.Apn
		,a.Court_Case_Number
		,a.Created_Date
		,a.Multiple_Record_Indicator1
		,a.Multiple_Record_Indicator2
		--,ROW_NUMBER() OVER (
		--	PARTITION BY a.fips
		--	,a.InstrumentNumber
		--	,a.Recording_Date
		--	,isnull(a.Apn, '')
		--	,isnull(a.Court_Case_Number, '')
		--	,a.created_date
		--	,a.Multi_Row
		--	--,c.ref_instrumentNumber
		--	ORDER BY a.Multiple_Record_Indicator1
		--		,a.Multiple_Record_Indicator2
		--	) 
		,a.Multi_Row AS recording_doc_sequence_number
		,0 AS SkipInd
		,a.ID
	FROM (
		SELECT DISTINCT Fips
			,InstrumentNumber
			,Recording_Date
			,Apn
			,Court_Case_Number
			,Created_Date
			,Multiple_Record_Indicator1
			,Multiple_Record_Indicator2
			,CASE 
				WHEN Multi_Row = '0'
					THEN '1'
				ELSE Multi_Row
				END AS Multi_Row
			,CASE 
				WHEN Multiple_Record_Indicator1 = 'M'
					OR Multiple_Record_Indicator2 = 'M'
					THEN t.ID
				ELSE 0
				END AS ID
		FROM [Lien].[tmp].[LEAP_KEY_IDS] t
		) a

	--Select * from  Lien.tmp.LEAP_KEY_IDS where  InstrumentNumber =  '2017167423'
	--select * from [Lien].[tmp].[LEAP_KEYS]  where  InstrumentNumber =  '2017167423'
	--
	-- First try to combine the records that were keyed the initail way
	--
	--  DECLARE @Created_Date DATETIME = '2018-05-17 09:01:14.000'
	CREATE INDEX ix_leap_fields ON #inputRecords (
		Fips
		,Recording_Doc_Nbr
		,Recording_Book_Nbr
		,Recording_Page_Nbr
		,Recording_Date
		,Apn
		,Court_Case_Number
		)

	/*IF object_id('Tempdb..#checksum1') IS NOT NULL
		*/
DROP TABLE IF EXISTS #checksum1;

	SELECT t1.id AS t1_id
		,t2.id AS t2_id
		,t1.Fips
		,CASE 
			WHEN t1.Recording_Doc_Nbr IS NULL
				THEN t1.Recording_Book_Nbr + '-' + t1.Recording_Page_Nbr
			ELSE t1.Recording_Doc_Nbr
			END AS InstrumentNumber
		--   ,t1.Recording_Doc_Nbr
		--,t1.Recording_Book_Nbr
		--,t1.Recording_Page_Nbr
		,t1.Recording_Date
		,t1.Apn
		,t1.Court_Case_Number
		--,checksum(t1.[State], t1.[County], t1.[Fips], t1.[Vendor_Code], t1.[Recording_Doc_Nbr], t1.[Recording_Book_Nbr], t1.[Recording_Page_Nbr], t1.[Recording_Date], t1.[Document_Type], t1.[Document_Code], t1.[Correction_Indicator], t1.[Lien_Issuing_Agency], t1.[Federal_Tax_Lien_Area], t1.[Tax_Lien_Serial_Nbr]/*, t1.[Party1_FirstName], t1.[Party1_MiddleName], t1.[Party1_LastName], t1.[Party1_NameSuffix], t1.[Party1_Alias_Name_Type]*/, t1.[Party1_Mail_Street_Addr], t1.[Party1_Mail_City], t1.[Party1_Mail_State], t1.[Party1_Mail_Zip_Code], t1.[Party1_Mail_Zip_Plus4], t1.[Foreign_Addr_Part1], t1.[Foreign_Addr_Part2], t1.[Foreign_Addr_Part3], t1.[Party1_Account_Nbr], t1.[Filler1], t1.[Party1_SSN_Nbr], t1.[Filler2], t1.[Party1_Driver_License_Nbr], t1.[Party1_Driver_License_State], t1.[Filler3], t1.[Additional_Judgement_Debtors], t1.[Kind_Of_Tax], t1.[Tax_Period_Minimum], t1.[Tax_Period_Maximum], t1.[Last_Day_For_Refiling], t1.[Total_Lien_Estimated_Amount], t1.[Federal_Tax_Lien_Prepared_Signed_City_Name], t1.
		--	[Federal_Tax_Lien_Prepared_Signed_State_Code], t1.[Federal_Tax_Lien_Energy_Doc_Date], t1.[Reference_Energy_Doc_Number], t1.[Reference_Energy_Doc_Book], t1.[Reference_Energy_Doc_Page], t1.[Reference_Energy_Recording_Date], t1.[Court_Case_Number], t1.[Party2_First_Name], t1.[Party2_Middle_Name], t1.[Party2_Last_Name], t1.[Party2_Name_Suffix], t1.[Party2_Mailing_Street], t1.[Party2_Mailing_City], t1.[Party2_Mailing_State], t1.[Party2_Mailing_Zip], t1.[Party2_Mailing_ZipPlus4], t1.[Filler4], t1.[Party2_SSN_Number], t1.[Party3_First_Name], t1.[Party3_Middle_Name], t1.[Party3_Last_Name], t1.[Party3_Name_Suffix], t1.[Divorce_Decree_Filing_Date], t1.[Property_Address], t1.[Property_City], t1.[Property_State], t1.[Property_Zip_Code], t1.[Property_Zip_Plus4], t1.[Filler5], t1.[Respondent_SSN_Number], t1.[Attorney_Name], t1.[Attorney_Phone_Number], t1.[Attorney_Flag], t1.[Judgment_Creditor], t1.[Assignee_Of_Record], t1.[Abstract_Issued_Date], t1.[Creditor_Name], t1.[Producer_Email_Address], t1.[Solar_Energy_TermExpire_Date], t1.
		--	[Solar_Energy_Type_Of_Agreement], t1.[Installment_Judgment], t1.[Stay_Ordered], t1.[Stay_Ordered_Date], t1.[Interest_Rate], t1.[Back_Support_Amount], t1.[Filler6], t1.[Filler7], t1.[Filler8], t1.[Filler9], t1.[Filler10], t1.[Apn], t1.[Apn_Portion_Indicator], t1.[Multiple_Record_Indicator1], t1.[Multiple_Record_Indicator2], t1.[Apn_Research_Indicator], t1.[Lot], t1.[Block], t1.[Tract_Name], t1.[Parcel], t1.[Parcel_Map_Book], t1.[Parcel_Map_Page], t1.[Section], t1.[Township], t1.[Range], t1.[Unit_Number], t1.[Municipality_Code], t1.[District_Number], t1.[District_Suffix_Number], t1.[Land_Lot], t1.[Party_1A_First_Name], t1.[Party_1A_Middle_Name_or_Initial], t1.[Party_1A_Last_Name], t1.[Party_1A_Name_Suffix], t1.[Party_1B_First_Name], t1.[Party_1B_Middle_Name_or_Initial], t1.[Party_1B_Last_Name], t1.[Party_1B_Name_Suffix], t1.[Party_1C_First_Name], t1.[Party_1C_Middle_Name_or_Initial], t1.[Party_1C_Last_Name], t1.[Party_1C_Name_Suffix], t1.[Party1_ETAL_Indicator], t1.[Created_Date], t1.[Party1_Company_Name], t1.
		--	[Party2_Company_Name], t1.[Party3_Company_Name], t1.[Party1A_Company_Name], t1.[Party1B_Company_Name], t1.[Party1C_Company_Name], t1.[Filler11], t1.[Filler12], t1.[Party1A_Alias_Name_Type], t1.[Party1B_Alias_Name_Type], t1.[Party1C_Alias_Name_Type]) 
		,t1._checksum AS t1_check
		--,checksum(t2.[State], t2.[County], t2.[Fips], t2.[Vendor_Code], t2.[Recording_Doc_Nbr], t2.[Recording_Book_Nbr], t2.[Recording_Page_Nbr], t2.[Recording_Date], t2.[Document_Type], t2.[Document_Code], t2.[Correction_Indicator], t2.[Lien_Issuing_Agency], t2.[Federal_Tax_Lien_Area], t2.[Tax_Lien_Serial_Nbr]/*, t2.[Party1_FirstName], t2.[Party1_MiddleName], t2.[Party1_LastName], t2.[Party1_NameSuffix], t2.[Party1_Alias_Name_Type]*/, t2.[Party1_Mail_Street_Addr], t2.[Party1_Mail_City], t2.[Party1_Mail_State], t2.[Party1_Mail_Zip_Code], t2.[Party1_Mail_Zip_Plus4], t2.[Foreign_Addr_Part1], t2.[Foreign_Addr_Part2], t2.[Foreign_Addr_Part3], t2.[Party1_Account_Nbr], t2.[Filler1], t2.[Party1_SSN_Nbr], t2.[Filler2], t2.[Party1_Driver_License_Nbr], t2.[Party1_Driver_License_State], t2.[Filler3], t2.[Additional_Judgement_Debtors], t2.[Kind_Of_Tax], t2.[Tax_Period_Minimum], t2.[Tax_Period_Maximum], t2.[Last_Day_For_Refiling], t2.[Total_Lien_Estimated_Amount], t2.[Federal_Tax_Lien_Prepared_Signed_City_Name], t2.
		--	[Federal_Tax_Lien_Prepared_Signed_State_Code], t2.[Federal_Tax_Lien_Energy_Doc_Date], t2.[Reference_Energy_Doc_Number], t2.[Reference_Energy_Doc_Book], t2.[Reference_Energy_Doc_Page], t2.[Reference_Energy_Recording_Date], t2.[Court_Case_Number], t2.[Party2_First_Name], t2.[Party2_Middle_Name], t2.[Party2_Last_Name], t2.[Party2_Name_Suffix], t2.[Party2_Mailing_Street], t2.[Party2_Mailing_City], t2.[Party2_Mailing_State], t2.[Party2_Mailing_Zip], t2.[Party2_Mailing_ZipPlus4], t2.[Filler4], t2.[Party2_SSN_Number], t2.[Party3_First_Name], t2.[Party3_Middle_Name], t2.[Party3_Last_Name], t2.[Party3_Name_Suffix], t2.[Divorce_Decree_Filing_Date], t2.[Property_Address], t2.[Property_City], t2.[Property_State], t2.[Property_Zip_Code], t2.[Property_Zip_Plus4], t2.[Filler5], t2.[Respondent_SSN_Number], t2.[Attorney_Name], t2.[Attorney_Phone_Number], t2.[Attorney_Flag], t2.[Judgment_Creditor], t2.[Assignee_Of_Record], t2.[Abstract_Issued_Date], t2.[Creditor_Name], t2.[Producer_Email_Address], t2.[Solar_Energy_TermExpire_Date], t2.
		--	[Solar_Energy_Type_Of_Agreement], t2.[Installment_Judgment], t2.[Stay_Ordered], t2.[Stay_Ordered_Date], t2.[Interest_Rate], t2.[Back_Support_Amount], t2.[Filler6], t2.[Filler7], t2.[Filler8], t2.[Filler9], t2.[Filler10], t2.[Apn], t2.[Apn_Portion_Indicator], t2.[Multiple_Record_Indicator1], t2.[Multiple_Record_Indicator2], t2.[Apn_Research_Indicator], t2.[Lot], t2.[Block], t2.[Tract_Name], t2.[Parcel], t2.[Parcel_Map_Book], t2.[Parcel_Map_Page], t2.[Section], t2.[Township], t2.[Range], t2.[Unit_Number], t2.[Municipality_Code], t2.[District_Number], t2.[District_Suffix_Number], t2.[Land_Lot], t2.[Party_1A_First_Name], t2.[Party_1A_Middle_Name_or_Initial], t2.[Party_1A_Last_Name], t2.[Party_1A_Name_Suffix], t2.[Party_1B_First_Name], t2.[Party_1B_Middle_Name_or_Initial], t2.[Party_1B_Last_Name], t2.[Party_1B_Name_Suffix], t2.[Party_1C_First_Name], t2.[Party_1C_Middle_Name_or_Initial], t2.[Party_1C_Last_Name], t2.[Party_1C_Name_Suffix], t2.[Party1_ETAL_Indicator], t2.[Created_Date], t2.[Party1_Company_Name], t2.
		--	[Party2_Company_Name], t2.[Party3_Company_Name], t2.[Party1A_Company_Name], t2.[Party1B_Company_Name], t2.[Party1C_Company_Name], t2.[Filler11], t2.[Filler12], t2.[Party1A_Alias_Name_Type], t2.[Party1B_Alias_Name_Type], t2.[Party1C_Alias_Name_Type]) 
		,t2._checksum AS t2_check
	INTO #checksum1
	FROM #inputRecords t1
	LEFT JOIN #inputRecords t2 ON t1.Fips = t2.Fips
		AND isnull(t1.Recording_Doc_Nbr, '') = isnull(t2.Recording_Doc_Nbr, '')
		AND isnull(t1.[Recording_Book_Nbr], '') = isnull(t2.[Recording_Book_Nbr], '')
		AND isnull(t1.[Recording_Page_Nbr], '') = isnull(t2.[Recording_Page_Nbr], '')
		AND t1.Recording_Date = t2.Recording_Date
		AND isnull(t1.Apn, '') = isnull(t2.Apn, '')
		AND isnull(t1.Court_Case_Number, '') = isnull(t2.Court_Case_Number, '')
	--AND t1.Created_Date = t2.Created_Date
	WHERE /*t1.Created_Date = @created_date --'20171212 22:17:27.000'
	AND*/ t2.id IS NOT NULL
		AND t1.id <> t2.id
		AND NOT (
			isnull(t1.Multiple_Record_Indicator1, '') = 'M'
			OR isnull(t1.Multiple_Record_Indicator2, '') = 'M'
			)
	--and t1.id in (222506,222507,222508)
	ORDER BY t1.id

	-- select * from #checksum1 where InstrumentNumber = '2018-036241' and t1_check = t2_check
	/*IF object_id('Tempdb..#checksum2') IS NOT NULL
		*/
DROP TABLE IF EXISTS #checksum2;

	SELECT ROW_NUMBER() OVER (
			PARTITION BY t1.fips
			,t1.InstrumentNumber
			,t1.Recording_Date
			,isnull(t1.Apn, '')
			,isnull(t1.Court_Case_Number, '')
			,t1_check
			--,t1.created_date
			ORDER BY t1_id
			) AS Multi_Row
		,t1_id
		,t2_id
		,Fips
		,InstrumentNumber
		,Recording_Date
		,Apn
		,Court_Case_Number
		,t1_check
		,t2_check
	INTO #checksum2
	FROM #checksum1 t1
	WHERE t1_check = t2_check

	--select * from #checksum2
	--SELECT t1.*
	--	,t.t1_id
	-- 
	/*IF object_id('Tempdb..#checksumupdate') IS NOT NULL
		*/
DROP TABLE IF EXISTS #checksumupdate;

	SELECT DISTINCT t1.t1_id AS get_id
		,t.t1_id AS leap_id
	INTO #checksumupdate
	FROM #checksum2 t1
	OUTER APPLY (
		SELECT *
		FROM #checksum2 t
		WHERE t.Fips = t1.Fips
			AND isnull(t.InstrumentNumber, '') = isnull(t1.InstrumentNumber, '')
			AND t.Recording_Date = t1.Recording_Date
			AND isnull(t.Apn, '') = isnull(t1.Apn, '')
			AND isnull(t.Court_Case_Number, '') = isnull(t1.Court_Case_Number, '')
			--AND t.Created_Date = t1.Created_Date
			AND t.Multi_Row = 1
		) t
	WHERE t1.t1_check = t1.t2_check

	CREATE INDEX ix_get_id ON #checksumupdate (get_id)

	--Select * from #checksumupdate
	UPDATE [Lien].[LEAP].[li]
	SET li.Leap_id = lk.leap_id
	FROM [Lien].[tmp].[LEAP_KEY_IDS] li
	INNER JOIN [Lien].[tmp].[LEAP_KEYS] lk ON lk.Fips = li.Fips
		AND lk.InstrumentNumber = li.InstrumentNumber
		AND lk.Recording_Date = li.Recording_Date
		AND isnull(lk.Apn, '') = isnull(li.Apn, '')
		AND isnull(lk.Court_Case_Number, '') = isnull(li.Court_Case_Number, '')
		AND lk.Created_Date = li.Created_Date
		AND lk.Multiple_Record_Indicator1 = li.Multiple_Record_Indicator1
		AND lk.Multiple_Record_Indicator2 = li.Multiple_Record_Indicator2
		AND li.Multi_Row = lk.recording_doc_sequence_number
		AND lk.id = li.Id
	--and (li.ID = 0 or lk.ID = li.ID)
	WHERE lk.id > 0
		AND li.leap_id = 0

	UPDATE [Lien].[LEAP].[li]
	SET li.Leap_id = lk.leap_id
	FROM [Lien].[tmp].[LEAP_KEY_IDS] li
	INNER JOIN [Lien].[tmp].[LEAP_KEYS] lk ON lk.Fips = li.Fips
		AND lk.InstrumentNumber = li.InstrumentNumber
		AND lk.Recording_Date = li.Recording_Date
		AND isnull(lk.Apn, '') = isnull(li.Apn, '')
		AND isnull(lk.Court_Case_Number, '') = isnull(li.Court_Case_Number, '')
		AND lk.Created_Date = li.Created_Date
		AND lk.Multiple_Record_Indicator1 = li.Multiple_Record_Indicator1
		AND lk.Multiple_Record_Indicator2 = li.Multiple_Record_Indicator2
		AND li.Multi_Row = lk.recording_doc_sequence_number
		AND lk.id = 0
	WHERE li.leap_id = 0

	--select * from #checksumupdate where get_id in (222525, 222526, 222527, 222528)
	--select * from Lien.tmp.LEAP_KEY_ids where InstrumentNumber = '2018-036241'
	--select Leap_id, count(1) as cnt from Lien.tmp.LEAP_KEY_ids where InstrumentNumber = '2018-036241' group by leap_id 
	UPDATE [Lien].[LEAP].[li]
	SET li.leap_id = s.leap_id
	--select li.*, lk.*
	FROM [Lien].[tmp].[LEAP_KEY_ids] li
	INNER JOIN #checksumupdate lk ON lk.get_id = li.id
	INNER JOIN [lien].[tmp].[leap_key_ids] s ON s.id = lk.leap_id
		--
		--set the recording_doc_seq correctly
		--
		;

	WITH rec_seq
	AS (
		SELECT k.*
			,ROW_NUMBER() OVER (
				PARTITION BY k.fips
				,k.InstrumentNumber
				,k.Recording_Date
				,isnull(k.Apn, '')
				,isnull(k.Court_Case_Number, '')
				,k.created_date ORDER BY (
						SELECT 0
						)
				) AS Multi_Row
		FROM [lien].[tmp].[leap_keys] k
		)
	UPDATE [Lien].[LEAP].[a]
	SET a.recording_doc_sequence_number = r.Multi_Row
	FROM [lien].[tmp].[leap_keys] a
	INNER JOIN rec_seq r ON r.leap_id = a.leap_id
	WHERE a.recording_doc_sequence_number <> r.Multi_Row

	--
	--Set Skip ind on all the detail for a leap_id
	--
	UPDATE [Lien].[LEAP].[a]
	SET SkipInd = CASE 
			WHEN (
					SELECT count(1)
					FROM [Lien].[tmp].[LEAP_KEY_IDS] k
					WHERE k.leap_id = a.leap_id
						AND SkipInd = 1
					) > 0
				THEN 1
			ELSE 0
			END
	FROM [Lien].[tmp].[LEAP_KEYS] a

	/*
	select * from [tmp].[LEAP_KEY_IDS] 
	--where Leap_id = 0
	where InstrumentNumber = '2018-0026001-00'
	select * from [tmp].[LEAP_KEYS]
		--where InstrumentNumber = '2018-0026001-00'
		where recording_doc_sequence_number > 1
*/
	/*IF object_id('Tempdb..#leap') IS NOT NULL
		*/
DROP TABLE IF EXISTS #leap;

	SELECT tk.leap_id
		,t.SkipInd
		,CASE 
			WHEN a.Recording_Doc_Nbr IS NULL
				THEN a.Recording_Book_Nbr + '-' + a.Recording_Page_Nbr
			ELSE a.Recording_Doc_Nbr
			END AS InstrumentNumber
		,a.ID
		,rc.[STATE] AS [STATE]
		,rc.county_code AS County
		,a.Fips
		,a.Vendor_Code
		,a.Recording_Doc_Nbr
		,a.Recording_Book_Nbr
		,a.Recording_Page_Nbr
		,a.Recording_Date
		,a.Document_Type
		,a.Document_Code
		,a.Correction_Indicator
		,a.Lien_Issuing_Agency
		,a.Federal_Tax_Lien_Area
		,a.Tax_Lien_Serial_Nbr
		,a.Party1_FirstName
		,a.Party1_MiddleName
		,a.Party1_LastName
		,a.Party1_NameSuffix
		,a.Party1_Alias_Name_Type
		,a.Party1_Mail_Street_Addr
		,a.Party1_Mail_City
		,a.Party1_Mail_State
		,a.Party1_Mail_Zip_Code
		,a.Party1_Mail_Zip_Plus4
		,a.Foreign_Addr_Part1
		,a.Foreign_Addr_Part2
		,a.Foreign_Addr_Part3
		,a.Party1_Account_Nbr
		,a.Party1_SSN_Nbr
		,a.Party1_Driver_License_Nbr
		,a.Party1_Driver_License_State
		--,a.Party1_Date_Of_Birth
		,a.Additional_Judgement_Debtors
		,a.Kind_Of_Tax
		,a.Tax_Period_Minimum
		,a.Tax_Period_Maximum
		,a.Last_Day_For_Refiling
		,a.Total_Lien_Estimated_Amount
		,a.Federal_Tax_Lien_Prepared_Signed_City_Name
		,a.Federal_Tax_Lien_Prepared_Signed_State_Code
		,a.Federal_Tax_Lien_Energy_Doc_Date
		,a.Reference_Energy_Doc_Number
		,a.Reference_Energy_Doc_Book
		,a.Reference_Energy_Doc_Page
		,a.Reference_Energy_Recording_Date
		,a.Court_Case_Number
		,a.Party2_First_Name
		,a.Party2_Middle_Name
		,a.Party2_Last_Name
		,a.Party2_Name_Suffix
		,a.Party2_Mailing_Street
		,a.Party2_Mailing_City
		,a.Party2_Mailing_State
		,a.Party2_Mailing_Zip
		,a.Party2_Mailing_ZipPlus4
		,a.Party2_SSN_Number
		,a.Party3_First_Name
		,a.Party3_Middle_Name
		,a.Party3_Last_Name
		,a.Party3_Name_Suffix
		,a.Divorce_Decree_Filing_Date
		,a.Property_Address
		,a.Property_City
		,a.Property_State
		,a.Property_Zip_Code
		,a.Property_Zip_Plus4
		,a.Respondent_SSN_Number
		,a.Attorney_Name
		,a.Attorney_Phone_Number
		,a.Attorney_Flag
		,a.Judgment_Creditor
		,a.Assignee_Of_Record
		,a.Abstract_Issued_Date
		,a.Creditor_Name
		,a.Producer_Email_Address
		,a.Solar_Energy_TermExpire_Date
		,a.Solar_Energy_Type_Of_Agreement
		,a.Installment_Judgment
		,a.Stay_Ordered
		,a.Stay_Ordered_Date
		,a.Interest_Rate
		,a.Back_Support_Amount
		--,a.Debtors_Name
		--,a.Address_Type
		--,a.County_Name
		--,a.Debtors_Phone_Number
		--,a.County_Tax_Lien_Flag
		,a.Apn
		,a.Apn_Portion_Indicator
		,a.Multiple_Record_Indicator1
		,a.Multiple_Record_Indicator2
		,a.Apn_Research_Indicator
		,a.Lot
		,a.Block
		,a.Tract_Name
		,a.Parcel
		,a.Parcel_Map_Book
		,a.Parcel_Map_Page
		,a.Section
		,a.Township
		,a.Range
		,a.Unit_Number
		,a.Municipality_Code
		,a.District_Number
		,a.District_Suffix_Number
		,a.Land_Lot
		,a.Party_1A_First_Name
		,a.Party_1A_Middle_Name_or_Initial
		,a.Party_1A_Last_Name
		,a.Party_1A_Name_Suffix
		,a.Party_1B_First_Name
		,a.Party_1B_Middle_Name_or_Initial
		,a.Party_1B_Last_Name
		,a.Party_1B_Name_Suffix
		,a.Party_1C_First_Name
		,a.Party_1C_Middle_Name_or_Initial
		,a.Party_1C_Last_Name
		,a.Party_1C_Name_Suffix
		,a.Party1_ETAL_Indicator
		,a.Created_Date
		,a.Party1_Company_Name
		,a.Party2_Company_Name
		,a.Party3_Company_Name
		,a.Party1A_Company_Name
		,a.Party1B_Company_Name
		,a.Party1C_Company_Name
		--,a.Party2_Alias_Name_Type
		--,a.Party3_Alias_Name_Type
		,a.Party1A_Alias_Name_Type
		,a.Party1B_Alias_Name_Type
		,a.Party1C_Alias_Name_Type
	INTO #leap
	FROM [Lien].[LEAP].[LEAP] a
	INNER JOIN [Lien].[tmp].[LEAP_KEY_IDS] tk ON tk.ID = a.ID
	INNER JOIN [Lien].[tmp].[LEAP_KEYS] t ON t.leap_id = tk.leap_id
	LEFT JOIN [NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] rc ON rc.fips = a.fips

	CREATE UNIQUE CLUSTERED INDEX [IX_ID] ON #leap ([ID] ASC)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,IGNORE_DUP_KEY = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				,FILLFACTOR = 80
				) ON [PRIMARY]

	CREATE INDEX [IX_Leap_id] ON #leap ([LEap_id] ASC)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,IGNORE_DUP_KEY = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				,FILLFACTOR = 80
				) ON [PRIMARY]

	CREATE NONCLUSTERED INDEX [ix_fips] ON #leap ([Fips] ASC)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				,FILLFACTOR = 80
				) ON [PRIMARY]

	CREATE NONCLUSTERED INDEX [ix_doc_code] ON #leap ([Document_Code] ASC) INCLUDE (
		[ID]
		,[Document_Type]
		,[InstrumentNumber]
		,[Recording_date]
		,[Fips]
		,[Apn]
		,[Created_Date]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Recording_Date]
		,Court_Case_Number
		)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				,FILLFACTOR = 80
				) ON [PRIMARY]

	CREATE NONCLUSTERED INDEX ix_Total_Lien_Estimated_Amount ON #leap ([Total_Lien_Estimated_Amount]) INCLUDE (
		[Fips]
		,[InstrumentNumber]
		,[Recording_date]
		,[Apn]
		,Court_Case_Number
		,[Created_Date]
		)

	CREATE NONCLUSTERED INDEX ix_Divorce_Decree_Filing_Date ON #leap ([Divorce_Decree_Filing_Date]) INCLUDE (
		[Fips]
		,[InstrumentNumber]
		,[Recording_date]
		,[Apn]
		,Court_Case_Number
		,[Created_Date]
		)

	CREATE NONCLUSTERED INDEX ix_Abstract_Issued_Date ON #leap ([Abstract_Issued_Date]) INCLUDE (
		[Fips]
		,[InstrumentNumber]
		,[Recording_date]
		,[Apn]
		,Court_Case_Number
		,[Created_Date]
		)

	CREATE NONCLUSTERED INDEX ix_Document_Type ON #leap (Document_Type) INCLUDE (
		[Fips]
		,[InstrumentNumber]
		,[Recording_date]
		,[Apn]
		,Court_Case_Number
		,[Created_Date]
		)

	CREATE NONCLUSTERED INDEX ix_instrument ON #leap (
		[InstrumentNumber]
		,[Fips]
		,[Created_Date]
		) INCLUDE (
		[ID]
		,[Apn]
		)

	CREATE NONCLUSTERED INDEX ix_instrument_2 ON #leap (
		[Fips]
		,[InstrumentNumber]
		,[Recording_date]
		,[Apn]
		,Court_Case_Number
		,[Created_Date]
		) INCLUDE ([ID])

	CREATE NONCLUSTERED INDEX ix_Attorney_Phone_Number ON [dbo].[#leap] ([Attorney_Phone_Number]) INCLUDE ([ID])

	--
	--Create tmp Reject table
	--
	TRUNCATE TABLE [Lien].[tmp].[LEAP_REJECTS]

	--
	-- Skip records
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Skip Records' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM #leap l
	WHERE l.skipInd = 1

	--
	-- Invalid or no Document Type
	--
	--	;
	--WITH #case
	--AS (
	--	SELECT DISTINCT lb.ID
	--	FROM #leap lb
	--	OUTER APPLY (
	--		SELECT TOP 1 *
	--		FROM Lien.LEAP.DocumentCategory c
	--		WHERE c.CategoryCode = isnull(lb.Document_Type, '')
	--		) c
	--	WHERE c.CategoryCode IS NULL
	--		AND (
	--			NOT (
	--				--document_Type IS NOT NULL
	--				--AND
	--				lb.Document_Code IS NULL
	--				)
	--			AND lb.skipInd = 0
	--			--AND NOT (
	--			--	isnull(lb.Document_Code, '') IN (
	--			--		'DOTSPR'
	--			--		,'DOTSRC'
	--			--		,'DOTSTRWAS'
	--			--		)
	--			--	)
	--			)
	--	)
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	--SELECT c.id
	--	--,c.Fips
	--	,'Invalid or no Document Type' AS Reject_Reason
	--FROM #case c
	SELECT l.id
		,'Invalid or no Document Type' AS Reject_Reason
	FROM #leap l
	LEFT JOIN #inputREcords k ON k.id = l.id
	LEFT JOIN [Lien].[LEAP].[DocumentCategory] c ON c.[CategoryCode] = l.Document_Type
	WHERE NUll_Document_Type = 1
		OR c.[CategoryCode] IS NULL

	--
	-- Document_Code
	--
	--	;
	--WITH #case
	--AS (
	--	SELECT DISTINCT lb.ID
	--	FROM #leap lb
	--	OUTER APPLY (
	--		SELECT TOP 1 [DocumentTypeID]
	--			,[DocCategoryID]
	--			,[DocumentCode]
	--			,[RepresentativeDocumentType]
	--		FROM Lien.LEAP.[DocumentType] dt
	--		WHERE dt.[DocCategoryID] IN (
	--				SELECT DocCategoryID
	--				FROM Lien.LEAP.DocumentCategory dc
	--				WHERE dc.CategoryCode = isnull(lb.Document_Type, '')
	--				)
	--			AND dt.[DocumentCode] = lb.Document_Code
	--		) dc
	--	WHERE dc.[DocumentTypeID] IS NULL
	--		AND (
	--			NOT (
	--				--document_Type IS NOT NULL
	--				--AND
	--				lb.Document_Code IS NULL
	--				)
	--			AND lb.skipInd = 0
	--			--AND NOT (
	--			--	isnull(lb.Document_Code, '') IN (
	--			--		'DOTSPR'
	--			--		,'DOTSRC'
	--			--		,'DOTSTRWAS'
	--			--		)
	--			--	)
	--			)
	--	)
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	--SELECT c.id
	--	--,c.Fips
	--	,'Invalid or no Document Code' AS Reject_Reason
	--FROM #case c
	SELECT l.id
		--,c.Fips
		,'Invalid or no Document Code' AS Reject_Reason
	FROM #leap l
	LEFT JOIN #inputREcords k ON k.id = l.id
	WHERE NUll_Document_Code = 1
		OR erp_Document_Code = 0

	--
	-- Duplicate Total_Lien_Estimated_Amount 
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Duplicate Total_Lien_Estimated_Amount' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM (
		SELECT a.Leap_id
			,count(1) AS cnt
		FROM (
			SELECT DISTINCT l.Leap_id
				,isnull(Total_Lien_Estimated_Amount, 0) AS Total_Lien_Estimated_Amount
			FROM #Leap l
			WHERE l.skipInd = 0
			) a
		GROUP BY a.leap_id
		HAVING count(1) > 1
		) b
	LEFT JOIN #leap l ON l.leap_id = b.leap_id

	--
	-- Duplicate Divorce_Decree_Filing_Date 
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Duplicate Divorce_Decree_Filing_Date' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM (
		SELECT a.Leap_id
			,count(1) AS cnt
		FROM (
			SELECT DISTINCT l.Leap_id
				--,isnull(Divorce_Decree_Filing_Date, 0) AS Divorce_Decree_Filing_Date
				,Divorce_Decree_Filing_Date
			FROM #Leap l
			WHERE Divorce_Decree_Filing_Date IS NOT NULL
				AND l.skipInd = 0
			) a
		GROUP BY a.leap_id
		HAVING count(1) > 1
		) b
	LEFT JOIN #leap l ON l.leap_id = b.leap_id

	--
	-- Duplicate Abstract_Issued_Date 
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Duplicate Abstract_Issued_Date' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM (
		SELECT a.Leap_id
			,count(1) AS cnt
		FROM (
			SELECT DISTINCT l.Leap_id
				,isnull(Abstract_Issued_Date, 0) AS Abstract_Issued_Date
			FROM #Leap l
			WHERE l.skipInd = 0
				AND l.Abstract_Issued_Date IS NOT NULL
			) a
		GROUP BY a.leap_id
		HAVING count(1) > 1
		) b
	LEFT JOIN #leap l ON l.leap_id = b.leap_id

	--
	-- Invalid Document_Type 
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Multiple Document_Type' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM (
		SELECT a.Leap_id
			,count(1) AS cnt
		FROM (
			SELECT DISTINCT l.Leap_id
				,isnull(Document_Type, '') AS Document_Type
			FROM #Leap l
			WHERE /*l.id = 282769 and */ l.skipInd = 0
			) a
		GROUP BY a.leap_id
		HAVING count(1) > 1
		) b
	LEFT JOIN #leap l ON l.leap_id = b.leap_id

	--select * from #leap where leap_id = 1538
	--
	-- Duplicate Document_Code
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT l.id
		,'Multiple Document_Code' AS Reject_Reason
	--,l.Total_Lien_Estimated_Amount
	--,b.Leap_id
	FROM (
		SELECT a.Leap_id
			,count(1) AS cnt
		FROM (
			SELECT DISTINCT l.Leap_id
				,isnull(Document_Code, '') AS Document_Code
			FROM #Leap l
			WHERE l.skipInd = 0
			) a
		GROUP BY a.leap_id
		HAVING count(1) > 1
		) b
	LEFT JOIN #leap l ON l.leap_id = b.leap_id

	--
	-- Duplicate Documents
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT a.ID
		,'Duplicate Document' AS Reject_Reason
	FROM [Lien].[tmp].[LEAP_KEY_IDS] a
	WHERE /*a.id = 3136230 and*/ (
			SELECT Count(1) AS cnt
			FROM [Lien].[LEAP].[LEAP_KEYS] lk
			LEFT JOIN [Lien].[LEAP].[LEAP_RejectRecords] r ON r.leap_id = lk.Leap_id
			WHERE lk.Fips = a.Fips
				AND lk.InstrumentNumber = a.InstrumentNumber
				AND lk.Recording_Date = a.Recording_Date
				AND isnull(lk.Apn, '') = isnull(a.Apn, '')
				AND isnull(lk.Court_Case_Number, '') = isnull(a.Court_Case_Number, '')
				--AND lk.Created_Date = li.Created_Date
				AND r.leap_id IS NULL
			) > 0
		AND a.skipInd = 0

	--
	--Invalid Attorney_Phone_Number
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Attorney_Phone_Number' AS Reject_Reason
	FROM #leap
	WHERE Attorney_Phone_Number IS NOT NULL
		AND len(Attorney_Phone_Number) <> 10
		AND skipInd = 0

	----
	----Invalid Party1_Date_Of_Birth
	----
	--INSERT INTO Lien.tmp.LEAP_REJECTS (
	--	[id]
	--	,[Reject_Reason]
	--	)
	--SELECT ID
	--	,'Invalid Party1_Date_Of_Birth' AS Reject_Reason
	--FROM #leap
	--WHERE Party1_Date_Of_Birth IS NOT NULL
	--	AND isdate((SUBSTRING(Party1_Date_Of_Birth, 5, 4) + SUBSTRING(Party1_Date_Of_Birth, 1, 2) + SUBSTRING(Party1_Date_Of_Birth, 3, 2))) = 0
	--
	--Invalid Last_Day_For_Refiling
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Last_Day_For_Refiling' AS Reject_Reason
	FROM #leap
	WHERE Last_Day_For_Refiling IS NOT NULL
		AND isdate((SUBSTRING(Last_Day_For_Refiling, 5, 4) + SUBSTRING(Last_Day_For_Refiling, 1, 2) + SUBSTRING(Last_Day_For_Refiling, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Tax_Period_Maximum
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Tax_Period_Maximum' AS Reject_Reason
	FROM #leap
	WHERE Tax_Period_Maximum IS NOT NULL
		AND isdate((SUBSTRING(Tax_Period_Maximum, 5, 4) + SUBSTRING(Tax_Period_Maximum, 1, 2) + SUBSTRING(Tax_Period_Maximum, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Tax_Period_Minimum
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Tax_Period_Minimum' AS Reject_Reason
	FROM #leap
	WHERE Tax_Period_Minimum IS NOT NULL
		AND isdate((SUBSTRING(Tax_Period_Minimum, 5, 4) + SUBSTRING(Tax_Period_Minimum, 1, 2) + SUBSTRING(Tax_Period_Minimum, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Recording_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Recording_Date' AS Reject_Reason
	FROM #leap
	WHERE Recording_Date IS NOT NULL
		AND isdate((SUBSTRING(Recording_Date, 5, 4) + SUBSTRING(Recording_Date, 1, 2) + SUBSTRING(Recording_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Federal_Tax_Lien_Energy_Doc_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Federal_Tax_Lien_Energy_Doc_Date' AS Reject_Reason
	FROM #leap
	WHERE Federal_Tax_Lien_Energy_Doc_Date IS NOT NULL
		AND isdate((SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 5, 4) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 1, 2) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Reference_Energy_Recording_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Reference_Energy_Recording_Date' AS Reject_Reason
	FROM #leap
	WHERE Reference_Energy_Recording_Date IS NOT NULL
		AND isdate((SUBSTRING(Reference_Energy_Recording_Date, 5, 4) + SUBSTRING(Reference_Energy_Recording_Date, 1, 2) + SUBSTRING(Reference_Energy_Recording_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Divorce_Decree_Filing_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Divorce_Decree_Filing_Date' AS Reject_Reason
	FROM #leap
	WHERE Divorce_Decree_Filing_Date IS NOT NULL
		AND isdate((SUBSTRING(Divorce_Decree_Filing_Date, 5, 4) + SUBSTRING(Divorce_Decree_Filing_Date, 1, 2) + SUBSTRING(Divorce_Decree_Filing_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Abstract_Issued_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Abstract_Issued_Date' AS Reject_Reason
	FROM #leap
	WHERE Abstract_Issued_Date IS NOT NULL
		AND isdate((SUBSTRING(Abstract_Issued_Date, 5, 4) + SUBSTRING(Abstract_Issued_Date, 1, 2) + SUBSTRING(Abstract_Issued_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Stay_Ordered_Date
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Stay_Ordered_Date' AS Reject_Reason
	FROM #leap
	WHERE Stay_Ordered_Date IS NOT NULL
		AND isdate((SUBSTRING(Stay_Ordered_Date, 5, 4) + SUBSTRING(Stay_Ordered_Date, 1, 2) + SUBSTRING(Stay_Ordered_Date, 3, 2))) = 0
		AND skipInd = 0

	--
	--Invalid Interest_Rate
	--
	INSERT INTO [Lien].[tmp].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT ID
		,'Invalid Interest_Rate' AS Reject_Reason
	FROM #leap
	WHERE Interest_Rate IS NOT NULL
		AND (
			isnumeric(Interest_Rate) = 0
			OR Interest_Rate > 50.00
			)
		AND skipInd = 0

	/*
	Select * from  Lien.tmp.LEAP_REJECTS where id in (2630927, 2736764)
     Select * from Lien.tmp.LEAP_KEY_ids where id in (2630927, 2736764)
	 Select * from Lien.LEAP.LEAP_KEY_ids where id in (2630927, 2736764)

	 Select * from Lien.tmp.[LEAP_KEY_IDS]  where fips = 6001 and InstrumentNumber = '2017010955'
	 Select * from Lien.tmp.LEAP_KEYS  where fips = 6001 and InstrumentNumber = '2017010955'
	 Select * from Lien.LEAP.LEAP_KEYS  where fips = 6001 and InstrumentNumber = '2017010955'

	 --delete from Lien.LEAP.LEAP_KEY_ids where id = 3136230
*/
	--
	--Identfify the daily documents with rejects
	--
	/*IF object_id('Tempdb..#reject_docs') IS NOT NULL
		*/
DROP TABLE IF EXISTS #reject_docs;

	SELECT DISTINCT l.Leap_id
	INTO #reject_docs
	FROM [Lien].[tmp].[LEAP_REJECTS] r
	INNER JOIN #leap l ON l.id = r.id

	CREATE UNIQUE INDEX ix_key ON #reject_docs (Leap_id)

	TRUNCATE TABLE [Lien].[tmp].[LEAP_RejectRecords]

	INSERT INTO [Lien].[tmp].[LEAP_RejectRecords] (
		[Leap_id]
		,[InstrumentNumber]
		,[ID]
		,[State]
		,[County]
		,[Fips]
		,[Vendor_Code]
		,[Recording_Doc_Nbr]
		,[Recording_Book_Nbr]
		,[Recording_Page_Nbr]
		,[Recording_Date]
		,[Document_Type]
		,[Document_Code]
		,[Correction_Indicator]
		,[Lien_Issuing_Agency]
		,[Federal_Tax_Lien_Area]
		,[Tax_Lien_Serial_Nbr]
		,[Party1_FirstName]
		,[Party1_MiddleName]
		,[Party1_LastName]
		,[Party1_NameSuffix]
		,[Party1_Alias_Name_Type]
		,[Party1_Mail_Street_Addr]
		,[Party1_Mail_City]
		,[Party1_Mail_State]
		,[Party1_Mail_Zip_Code]
		,[Party1_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party1_Account_Nbr]
		,[Party1_SSN_Nbr]
		,[Party1_Driver_License_Nbr]
		,[Party1_Driver_License_State]
		,[Additional_Judgement_Debtors]
		,[Kind_Of_Tax]
		,[Tax_Period_Minimum]
		,[Tax_Period_Maximum]
		,[Last_Day_For_Refiling]
		,[Total_Lien_Estimated_Amount]
		,[Federal_Tax_Lien_Prepared_Signed_City_Name]
		,[Federal_Tax_Lien_Prepared_Signed_State_Code]
		,[Federal_Tax_Lien_Energy_Doc_Date]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Doc_Page]
		,[Reference_Energy_Recording_Date]
		,[Court_Case_Number]
		,[Party2_First_Name]
		,[Party2_Middle_Name]
		,[Party2_Last_Name]
		,[Party2_Name_Suffix]
		,[Party2_Mailing_Street]
		,[Party2_Mailing_City]
		,[Party2_Mailing_State]
		,[Party2_Mailing_Zip]
		,[Party2_Mailing_ZipPlus4]
		,[Party2_SSN_Number]
		,[Party3_First_Name]
		,[Party3_Middle_Name]
		,[Party3_Last_Name]
		,[Party3_Name_Suffix]
		,[Divorce_Decree_Filing_Date]
		,[Property_Address]
		,[Property_City]
		,[Property_State]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[Respondent_SSN_Number]
		,[Attorney_Name]
		,[Attorney_Phone_Number]
		,[Attorney_Flag]
		,[Judgment_Creditor]
		,[Assignee_Of_Record]
		,[Abstract_Issued_Date]
		,[Creditor_Name]
		,[Producer_Email_Address]
		,[Solar_Energy_TermExpire_Date]
		,[Solar_Energy_Type_Of_Agreement]
		,[Installment_Judgment]
		,[Stay_Ordered]
		,[Stay_Ordered_Date]
		,[Interest_Rate]
		,[Back_Support_Amount]
		--,[Debtors_Name]
		--,[Address_Type]
		--,[County_Name]
		--,[Debtors_Phone_Number]
		--,[County_Tax_Lien_Flag]
		,[Apn]
		,[Apn_Portion_Indicator]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Apn_Research_Indicator]
		,[Lot]
		,[Block]
		,[Tract_Name]
		,[Parcel]
		,[Parcel_Map_Book]
		,[Parcel_Map_Page]
		,[Section]
		,[Township]
		,[Range]
		,[Unit_Number]
		,[Municipality_Code]
		,[District_Number]
		,[District_Suffix_Number]
		,[Land_Lot]
		,[Party_1A_First_Name]
		,[Party_1A_Middle_Name_or_Initial]
		,[Party_1A_Last_Name]
		,[Party_1A_Name_Suffix]
		,[Party_1B_First_Name]
		,[Party_1B_Middle_Name_or_Initial]
		,[Party_1B_Last_Name]
		,[Party_1B_Name_Suffix]
		,[Party_1C_First_Name]
		,[Party_1C_Middle_Name_or_Initial]
		,[Party_1C_Last_Name]
		,[Party_1C_Name_Suffix]
		,[Party1_ETAL_Indicator]
		,[Created_Date]
		,[Party1_Company_Name]
		,[Party2_Company_Name]
		,[Party3_Company_Name]
		,[Party1A_Company_Name]
		,[Party1B_Company_Name]
		,[Party1C_Company_Name]
		--,[Party2_Alias_Name_Type]
		--,[Party3_Alias_Name_Type]
		,[Party1A_Alias_Name_Type]
		,[Party1B_Alias_Name_Type]
		,[Party1C_Alias_Name_Type]
		)
	SELECT l.Leap_id
		,l.InstrumentNumber
		,l.ID
		,l.STATE
		,l.County
		,l.Fips
		,l.Vendor_Code
		,l.Recording_Doc_Nbr
		,l.Recording_Book_Nbr
		,l.Recording_Page_Nbr
		,l.Recording_Date
		,l.Document_Type
		,l.Document_Code
		,l.Correction_Indicator
		,l.Lien_Issuing_Agency
		,l.Federal_Tax_Lien_Area
		,l.Tax_Lien_Serial_Nbr
		,l.Party1_FirstName
		,l.Party1_MiddleName
		,l.Party1_LastName
		,l.Party1_NameSuffix
		,l.Party1_Alias_Name_Type
		,l.Party1_Mail_Street_Addr
		,l.Party1_Mail_City
		,l.Party1_Mail_State
		,l.Party1_Mail_Zip_Code
		,l.Party1_Mail_Zip_Plus4
		,l.Foreign_Addr_Part1
		,l.Foreign_Addr_Part2
		,l.Foreign_Addr_Part3
		,l.Party1_Account_Nbr
		,l.Party1_SSN_Nbr
		,l.Party1_Driver_License_Nbr
		,l.Party1_Driver_License_State
		--,l.Party1_Date_Of_Birth
		,l.Additional_Judgement_Debtors
		,l.Kind_Of_Tax
		,l.Tax_Period_Minimum
		,l.Tax_Period_Maximum
		,l.Last_Day_For_Refiling
		,l.Total_Lien_Estimated_Amount
		,l.Federal_Tax_Lien_Prepared_Signed_City_Name
		,l.Federal_Tax_Lien_Prepared_Signed_State_Code
		,l.Federal_Tax_Lien_Energy_Doc_Date
		,l.Reference_Energy_Doc_Number
		,l.Reference_Energy_Doc_Book
		,l.Reference_Energy_Doc_Page
		,l.Reference_Energy_Recording_Date
		,l.Court_Case_Number
		,l.Party2_First_Name
		,l.Party2_Middle_Name
		,l.Party2_Last_Name
		,l.Party2_Name_Suffix
		,l.Party2_Mailing_Street
		,l.Party2_Mailing_City
		,l.Party2_Mailing_State
		,l.Party2_Mailing_Zip
		,l.Party2_Mailing_ZipPlus4
		,l.Party2_SSN_Number
		,l.Party3_First_Name
		,l.Party3_Middle_Name
		,l.Party3_Last_Name
		,l.Party3_Name_Suffix
		,l.Divorce_Decree_Filing_Date
		,l.Property_Address
		,l.Property_City
		,l.Property_State
		,l.Property_Zip_Code
		,l.Property_Zip_Plus4
		,l.Respondent_SSN_Number
		,l.Attorney_Name
		,l.Attorney_Phone_Number
		,l.Attorney_Flag
		,l.Judgment_Creditor
		,l.Assignee_Of_Record
		,l.Abstract_Issued_Date
		,l.Creditor_Name
		,l.Producer_Email_Address
		,l.Solar_Energy_TermExpire_Date
		,l.Solar_Energy_Type_Of_Agreement
		,l.Installment_Judgment
		,l.Stay_Ordered
		,l.Stay_Ordered_Date
		,l.Interest_Rate
		,l.Back_Support_Amount
		--,l.Debtors_Name
		--,l.Address_Type
		--,l.County_Name
		--,l.Debtors_Phone_Number
		--,l.County_Tax_Lien_Flag
		,l.Apn
		,l.Apn_Portion_Indicator
		,l.Multiple_Record_Indicator1
		,l.Multiple_Record_Indicator2
		,l.Apn_Research_Indicator
		,l.Lot
		,l.Block
		,l.Tract_Name
		,l.Parcel
		,l.Parcel_Map_Book
		,l.Parcel_Map_Page
		,l.Section
		,l.Township
		,l.Range
		,l.Unit_Number
		,l.Municipality_Code
		,l.District_Number
		,l.District_Suffix_Number
		,l.Land_Lot
		,l.Party_1A_First_Name
		,l.Party_1A_Middle_Name_or_Initial
		,l.Party_1A_Last_Name
		,l.Party_1A_Name_Suffix
		,l.Party_1B_First_Name
		,l.Party_1B_Middle_Name_or_Initial
		,l.Party_1B_Last_Name
		,l.Party_1B_Name_Suffix
		,l.Party_1C_First_Name
		,l.Party_1C_Middle_Name_or_Initial
		,l.Party_1C_Last_Name
		,l.Party_1C_Name_Suffix
		,l.Party1_ETAL_Indicator
		,l.Created_Date
		,[Party1_Company_Name]
		,[Party2_Company_Name]
		,[Party3_Company_Name]
		,[Party1A_Company_Name]
		,[Party1B_Company_Name]
		,[Party1C_Company_Name]
		--,[Party2_Alias_Name_Type]
		--,[Party3_Alias_Name_Type]
		,[Party1A_Alias_Name_Type]
		,[Party1B_Alias_Name_Type]
		,[Party1C_Alias_Name_Type]
	FROM #leap l
	INNER JOIN #reject_docs r --------------------- are we going to reject a part of the document if it consist of 2 or more leap_ids
		ON r.leap_id = l.leap_id

	--
	-- Read Raw Detail and exclude skip records and exclude certain Document Codes
	--
	/*IF object_id('Tempdb..#leap2') IS NOT NULL
		*/
DROP TABLE IF EXISTS #leap2;

	SELECT a.Leap_id
		,a.InstrumentNumber
		,a.ID
		,rc.[STATE] AS [STATE]
		,rc.county_code AS County
		,a.Fips
		,a.Vendor_Code
		,a.Recording_Doc_Nbr
		,a.Recording_Book_Nbr
		,a.Recording_Page_Nbr
		,a.Recording_Date
		,a.Document_Type
		,a.Document_Code
		,a.Correction_Indicator
		,a.Lien_Issuing_Agency
		,a.Federal_Tax_Lien_Area
		,a.Tax_Lien_Serial_Nbr
		,a.Party1_FirstName
		,a.Party1_MiddleName
		,a.Party1_LastName
		,a.Party1_NameSuffix
		,a.Party1_Alias_Name_Type
		,a.Party1_Mail_Street_Addr
		,a.Party1_Mail_City
		,a.Party1_Mail_State
		,a.Party1_Mail_Zip_Code
		,a.Party1_Mail_Zip_Plus4
		,a.Foreign_Addr_Part1
		,a.Foreign_Addr_Part2
		,a.Foreign_Addr_Part3
		,a.Party1_Account_Nbr
		,a.Party1_SSN_Nbr
		,a.Party1_Driver_License_Nbr
		,a.Party1_Driver_License_State
		--,a.Party1_Date_Of_Birth
		,a.Additional_Judgement_Debtors
		,a.Kind_Of_Tax
		,a.Tax_Period_Minimum
		,a.Tax_Period_Maximum
		,a.Last_Day_For_Refiling
		,a.Total_Lien_Estimated_Amount
		,a.Federal_Tax_Lien_Prepared_Signed_City_Name
		,a.Federal_Tax_Lien_Prepared_Signed_State_Code
		,a.Federal_Tax_Lien_Energy_Doc_Date
		,a.Reference_Energy_Doc_Number
		,a.Reference_Energy_Doc_Book
		,a.Reference_Energy_Doc_Page
		,a.Reference_Energy_Recording_Date
		,a.Court_Case_Number
		,a.Party2_First_Name
		,a.Party2_Middle_Name
		,a.Party2_Last_Name
		,a.Party2_Name_Suffix
		,a.Party2_Mailing_Street
		,a.Party2_Mailing_City
		,a.Party2_Mailing_State
		,a.Party2_Mailing_Zip
		,a.Party2_Mailing_ZipPlus4
		,a.Party2_SSN_Number
		,a.Party3_First_Name
		,a.Party3_Middle_Name
		,a.Party3_Last_Name
		,a.Party3_Name_Suffix
		,a.Divorce_Decree_Filing_Date
		,a.Property_Address
		,a.Property_City
		,a.Property_State
		,a.Property_Zip_Code
		,a.Property_Zip_Plus4
		,a.Respondent_SSN_Number
		,a.Attorney_Name
		,a.Attorney_Phone_Number
		,a.Attorney_Flag
		,a.Judgment_Creditor
		,a.Assignee_Of_Record
		,a.Abstract_Issued_Date
		,a.Creditor_Name
		,a.Producer_Email_Address
		,a.Solar_Energy_TermExpire_Date
		,a.Solar_Energy_Type_Of_Agreement
		,a.Installment_Judgment
		,a.Stay_Ordered
		,a.Stay_Ordered_Date
		,a.Interest_Rate
		,a.Back_Support_Amount
		--,a.Debtors_Name
		--,a.Address_Type
		--,a.County_Name
		--,a.Debtors_Phone_Number
		--,a.County_Tax_Lien_Flag
		,a.Apn
		,a.Apn_Portion_Indicator
		,a.Multiple_Record_Indicator1
		,a.Multiple_Record_Indicator2
		,a.Apn_Research_Indicator
		,a.Lot
		,a.Block
		,a.Tract_Name
		,a.Parcel
		,a.Parcel_Map_Book
		,a.Parcel_Map_Page
		,a.Section
		,a.Township
		,a.Range
		,a.Unit_Number
		,a.Municipality_Code
		,a.District_Number
		,a.District_Suffix_Number
		,a.Land_Lot
		,a.Party_1A_First_Name
		,a.Party_1A_Middle_Name_or_Initial
		,a.Party_1A_Last_Name
		,a.Party_1A_Name_Suffix
		,a.Party_1B_First_Name
		,a.Party_1B_Middle_Name_or_Initial
		,a.Party_1B_Last_Name
		,a.Party_1B_Name_Suffix
		,a.Party_1C_First_Name
		,a.Party_1C_Middle_Name_or_Initial
		,a.Party_1C_Last_Name
		,a.Party_1C_Name_Suffix
		,a.Party1_ETAL_Indicator
		,a.Created_Date
		,a.Party1_Company_Name
		,a.Party2_Company_Name
		,a.Party3_Company_Name
		,a.Party1A_Company_Name
		,a.Party1B_Company_Name
		,a.Party1C_Company_Name
		--,a.Party2_Alias_Name_Type
		--,a.Party3_Alias_Name_Type
		,a.Party1A_Alias_Name_Type
		,a.Party1B_Alias_Name_Type
		,a.Party1C_Alias_Name_Type
	INTO #leap2
	FROM #leap a
	LEFT JOIN [NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] rc ON rc.fips = a.fips
	LEFT JOIN [Lien].[tmp].[LEAP_RejectRecords] lr ON lr.ID = a.ID
	WHERE NOT (
			--document_Type IS NOT NULL
			--AND
			a.Document_Code IS NULL
			)
		AND a.skipInd = 0
		--AND NOT (
		--	isnull(a.Document_Code, '') IN (
		--		'DOTSPR'
		--		,'DOTSRC'
		--		,'DOTSTRWAS'
		--		)
		--	)
		AND lr.id IS NULL --not in (Select ID from Lien.LEAP.LEAP_RejectRecords)

	--
	--get the different Party Names for a document number - add a rownumber to the table
	--
	/*IF object_id('Tempdb..#Leap4') IS NOT NULL
		*/
DROP TABLE IF EXISTS #Leap4;

	SELECT ROW_NUMBER() OVER (
			PARTITION BY b.leap_id ORDER BY (
					SELECT 0
					)
			) AS Part_seq
		,b.*
	INTO #leap4
	FROM (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY l.leap_id
				,isnull(l.Party1_FirstName, '')
				,isnull(l.Party1_MiddleName, '')
				,isnull(l.Party1_LastName, '')
				,isnull(l.Party1_NameSuffix, '')
				,isnull(l.Party1_Company_Name, '')
				,isnull(l.Party1_Alias_Name_Type, '') ORDER BY (
						SELECT 0
						)
				) AS ROW4
			,l.*
		FROM #Leap2 l
			--where Recording_Doc_Nbr = '2017169529'
			--where l.InstrumentNumber = '2017167582'
		) b

	--
	--Load Reference
	--
	/*IF object_id('Lien.tmp.Leap_New_Reference') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Lien].[tmp].[Leap_New_Reference];

	SELECT q.Leap_id
		,ROW_NUMBER() OVER (
			PARTITION BY q.leap_id ORDER BY (
					SELECT 0
					)
				--isnull(q.Reference_Energy_Doc_Number, '')
				--,isnull(q.Reference_Energy_Doc_Book, '')
				--,isnull(q.Reference_Energy_Doc_Page, '')
				--,isnull(q.Reference_Energy_Recording_Date, '')
			) AS Ref_Seq
		,q.Reference_Energy_Doc_Number
		,q.Reference_Energy_Doc_Book
		,q.Reference_Energy_Doc_Page
		,q.Reference_Energy_Recording_Date
	INTO [Lien].[tmp].[Leap_New_Reference]
	FROM (
		SELECT DISTINCT l.leap_id
			,l.[Reference_Energy_Doc_Number]
			,l.[Reference_Energy_Doc_Book]
			,l.[Reference_Energy_Doc_Page]
			--,l.[Reference_Energy_Recording_Date]
			,CASE 
				WHEN isdate(SUBSTRING(Reference_Energy_Recording_Date, 5, 4) + SUBSTRING(Reference_Energy_Recording_Date, 1, 2) + SUBSTRING(Reference_Energy_Recording_Date, 3, 2)) = 1
					THEN cast(SUBSTRING(Reference_Energy_Recording_Date, 5, 4) + SUBSTRING(Reference_Energy_Recording_Date, 1, 2) + SUBSTRING(Reference_Energy_Recording_Date, 3, 2) AS DATE)
				ELSE NULL
				END AS Reference_Energy_Recording_Date
		FROM #Leap4 l
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Reference_Energy_Doc_Number IS NOT NULL
				OR l.Reference_Energy_Doc_Book IS NOT NULL
				OR l.Reference_Energy_Doc_Page IS NOT NULL
				OR l.Reference_Energy_Recording_Date IS NOT NULL
				)
		) q

	--select leap_id, ref_seq, count(1) from Lien.tmp.Leap_New_Reference group by leap_id, ref_seq having count(1) > 1
	--Select top 100 *  from #Reference where  InstrumentNumber = '2017-0140225' --Ref_Seq > 1
	--order by Fips, InstrumentNumber
	--
	--Insert the Party 1 - borrower
	----
	--IF object_id('Lien.tmp.Leap_New_Parties') IS NOT NULL
	--	DROP TABLE Lien.tmp.Leap_New_Parties;
	TRUNCATE TABLE [Lien].[tmp].[Leap_New_Parties]

	--	select distinct _Column from Lien.LEAP.PartyRoles
	--select * from Lien.LEAP.PartyRoles
	--Select * from Lien.tmp.LEAP_Matrix where [Field Name] = 'Party 3 Last Name'
	--Select * from  Lien.tmp.Leap_New_Parties where RoleType = 'Unknown'
	--select * from  Lien.LEAP.PartyRoles where DocumentCode = 'ASRASN'
	--Select * from #leap4 where leap_id = 7256
	INSERT INTO [Lien].[tmp].[Leap_New_Parties] (
		[Leap_id]
		,[RoleType]
		,[Party_Seq]
		,[Party_FirstName]
		,[Party_MiddleName]
		,[Party_LastName]
		,[Party_NameSuffix]
		,[Party_Alias_Name_Type]
		,[Party_Company_Name]
		,[Party_Mail_Street_Addr]
		,[Party_Mail_City]
		,[Party_Mail_State]
		,[Party_Mail_Zip_Code]
		,[Party_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party_Account_Nbr]
		,[Party_SSN_Nbr]
		,[Party_Driver_License_Nbr]
		,[Party_Driver_License_State]
		--,[Party_Date_Of_Birth]
		,[PhoneNumber]
		)
	SELECT q.Leap_id
		,isnull(RoleType, 'Unknown') AS RoleType
		,ROW_NUMBER() OVER (
			PARTITION BY q.Leap_id
			,RoleType ORDER BY isnull(q.Party1_FirstName, '')
				,isnull(q.Party1_MiddleName, '')
				,isnull(q.Party1_LastName, '')
				,isnull(q.Party1_NameSuffix, '')
				,isnull(q.Party1_Alias_Name_Type, '')
				,isnull(q.Party1_Company_Name, '')
			) AS Party_Seq
		--,q.Party1_FirstName AS Party_FirstName
		,qq.Party1_FirstName AS Party_FirstName
		--,case when q.Party1_FirstName is not null and q.Party1_LastName is null then null else q.Party1_FirstName end as Party_FirstName
		,q.Party1_MiddleName AS Party_MiddleName
		--,q.Party1_LastName AS Party_LastName
		,qq.Party1_LastName AS Party_LastName
		--,case when q.Party1_FirstName is not null and q.Party1_LastName is null then q.Party1_FirstName else q.Party1_LastName end as Party_LastName
		,q.Party1_NameSuffix AS Party_NameSuffix
		,q.Party1_Alias_Name_Type AS Party_Alias_Name_Type
		--,q.Party1_Company_Name AS Party_Company_Name
		,qq.Party1_Company_Name AS Party_Company_Name
		,q.Party1_Mail_Street_Addr AS Party_Mail_Street_Addr
		,q.Party1_Mail_City AS Party_Mail_City
		,q.Party1_Mail_State AS Party_Mail_State
		,q.Party1_Mail_Zip_Code AS Party_Mail_Zip_Code
		,q.Party1_Mail_Zip_Plus4 AS Party_Mail_Zip_Plus4
		,q.Foreign_Addr_Part1 AS Foreign_Addr_Part1
		,q.Foreign_Addr_Part2 AS Foreign_Addr_Part2
		,q.Foreign_Addr_Part3 AS Foreign_Addr_Part3
		,q.Party1_Account_Nbr AS Party_Account_Nbr
		,q.Party1_SSN_Nbr AS Party_SSN_Nbr
		,q.Party1_Driver_License_Nbr AS Party_Driver_License_Nbr
		,q.Party1_Driver_License_State AS Party_Driver_License_State
		--,q.Party1_Date_Of_Birth AS Party_Date_Of_Birth
		,q.PhoneNumber
	--into #paul_test
	FROM (
		SELECT DISTINCT l.Leap_id
			,r._Role AS RoleType
			,l.Party1_FirstName
			,l.Party1_MiddleName
			,l.Party1_LastName
			,l.Party1_NameSuffix
			,l.Party1_Alias_Name_Type
			,l.Party1_Company_Name
			,l.Party1_Mail_Street_Addr
			,l.Party1_Mail_City
			,l.Party1_Mail_State
			,l.Party1_Mail_Zip_Code
			,l.Party1_Mail_Zip_Plus4
			,l.Foreign_Addr_Part1
			,l.Foreign_Addr_Part2
			,l.Foreign_Addr_Part3
			,l.Party1_Account_Nbr
			,l.Party1_SSN_Nbr
			,l.Party1_Driver_License_Nbr
			,l.Party1_Driver_License_State
			--,l.Party1_Date_Of_Birth
			--,CASE 
			--	WHEN isdate(SUBSTRING(Party1_Date_Of_Birth, 5, 4) + SUBSTRING(Party1_Date_Of_Birth, 1, 2) + SUBSTRING(Party1_Date_Of_Birth, 3, 2)) = 1
			--		THEN cast(SUBSTRING(Party1_Date_Of_Birth, 5, 4) + SUBSTRING(Party1_Date_Of_Birth, 1, 2) + SUBSTRING(Party1_Date_Of_Birth, 3, 2) AS DATE)
			--	ELSE NULL
			--	END AS Party1_Date_Of_Birth
			,cast(' ' AS VARCHAR(50)) AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 1 Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party1_FirstName IS NOT NULL
				OR l.Party1_MiddleName IS NOT NULL
				OR l.Party1_LastName IS NOT NULL
				OR l.Party1_NameSuffix IS NOT NULL
				OR l.Party1_Alias_Name_Type IS NOT NULL
				OR l.Party1_Company_Name IS NOT NULL
				)
		--AND Leap_id = 292393
		
		UNION ALL
		
		SELECT DISTINCT l.Leap_id
			,r._Role AS RoleType
			,l.Party_1A_First_Name AS Party_FirstName
			,l.Party_1A_Middle_Name_or_Initial AS Party_MiddleName
			,l.Party_1A_Last_Name AS Party_LastName
			,l.Party_1A_Name_Suffix AS Party_NameSuffix
			,l.Party1A_Alias_Name_Type AS Party_Alias_Name_Type
			,l.Party1A_Company_Name AS Party_Company_Name
			,NULL AS Party_Mail_Street_Addr
			,NULL AS Party_Mail_City
			,NULL AS Party_Mail_State
			,NULL AS Party_Mail_Zip_Code
			,NULL AS Party_Mail_Zip_Plus4
			,NULL AS Foreign_Addr_Part1
			,NULL AS Foreign_Addr_Part2
			,NULL AS Foreign_Addr_Part3
			,NULL AS Party_Account_Nbr
			,NULL AS Party_SSN_Nbr
			,NULL AS Party_Driver_License_Nbr
			,NULL AS Party_Driver_License_State
			--,NULL AS Party_Date_Of_Birth
			,NULL AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 1A Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party_1A_First_Name IS NOT NULL
				OR l.Party_1A_Middle_Name_or_Initial IS NOT NULL
				OR l.Party_1A_Last_Name IS NOT NULL
				OR l.Party_1A_Name_Suffix IS NOT NULL
				OR l.Party1A_Company_Name IS NOT NULL
				OR l.Party1A_Alias_Name_Type IS NOT NULL
				)
		
		UNION ALL
		
		SELECT DISTINCT l.leap_id
			,r._Role AS RoleType
			,l.Party_1B_First_Name AS Party_FirstName
			,l.Party_1B_Middle_Name_or_Initial AS Party_MiddleName
			,l.Party_1B_Last_Name AS Party_LastName
			,l.Party_1B_Name_Suffix AS Party_NameSuffix
			,l.Party1B_Alias_Name_Type AS Party_Alias_Name_Type
			,l.Party1B_Company_Name AS Party_Company_Name
			,NULL AS Party_Mail_Street_Addr
			,NULL AS Party_Mail_City
			,NULL AS Party_Mail_State
			,NULL AS Party_Mail_Zip_Code
			,NULL AS Party_Mail_Zip_Plus4
			,NULL AS Foreign_Addr_Part1
			,NULL AS Foreign_Addr_Part2
			,NULL AS Foreign_Addr_Part3
			,NULL AS Party_Account_Nbr
			,NULL AS Party_SSN_Nbr
			,NULL AS Party_Driver_License_Nbr
			,NULL AS Party_Driver_License_State
			--,NULL AS Party_Date_Of_Birth
			,NULL AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 1b Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party_1B_First_Name IS NOT NULL
				OR l.Party_1B_Middle_Name_or_Initial IS NOT NULL
				OR l.Party_1B_Last_Name IS NOT NULL
				OR l.Party_1B_Name_Suffix IS NOT NULL
				OR l.Party1B_Company_Name IS NOT NULL
				OR l.Party1B_Alias_Name_Type IS NOT NULL
				)
		
		UNION ALL
		
		SELECT DISTINCT l.Leap_id
			,r._Role AS RoleType
			,l.Party_1C_First_Name AS Party_FirstName
			,l.Party_1C_Middle_Name_or_Initial AS Party_MiddleName
			,l.Party_1C_Last_Name AS Party_LastName
			,l.Party_1C_Name_Suffix AS Party_NameSuffix
			,l.Party1C_Alias_Name_Type AS Party_Alias_Name_Type
			,l.Party1C_Company_Name AS Party_Company_Name
			,NULL AS Party_Mail_Street_Addr
			,NULL AS Party_Mail_City
			,NULL AS Party_Mail_State
			,NULL AS Party_Mail_Zip_Code
			,NULL AS Party_Mail_Zip_Plus4
			,NULL AS Foreign_Addr_Part1
			,NULL AS Foreign_Addr_Part2
			,NULL AS Foreign_Addr_Part3
			,NULL AS Party_Account_Nbr
			,NULL AS Party_SSN_Nbr
			,NULL AS Party_Driver_License_Nbr
			,NULL AS Party_Driver_License_State
			--,NULL AS Party_Date_Of_Birth
			,NULL AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 1c Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party_1C_First_Name IS NOT NULL
				OR l.Party_1C_Middle_Name_or_Initial IS NOT NULL
				OR l.Party_1C_Last_Name IS NOT NULL
				OR l.Party_1C_Name_Suffix IS NOT NULL
				OR l.Party1C_Company_Name IS NOT NULL
				OR l.Party1C_Alias_Name_Type IS NOT NULL
				)
		
		UNION ALL
		
		SELECT DISTINCT l.Leap_id
			,r._Role AS RoleType
			,l.Party2_First_Name AS Party_FirstName
			,l.Party2_Middle_Name AS Party_MiddleName
			,l.Party2_Last_Name AS Party_LastName
			,l.Party2_Name_Suffix AS Party_NameSuffix
			,NULL AS Party_Alias_Name_Type
			,l.Party2_Company_Name AS Party_Company_Name
			,l.Party2_Mailing_Street AS Party_Mail_Street_Addr
			,l.Party2_Mailing_City AS Party_Mail_City
			,l.Party2_Mailing_State AS Party_Mail_State
			,l.Party2_Mailing_Zip AS Party_Mail_Zip_Code
			,l.Party2_Mailing_ZipPlus4 AS Party_Mail_Zip_Plus4
			,NULL AS Foreign_Addr_Part1
			,NULL AS Foreign_Addr_Part2
			,NULL AS Foreign_Addr_Part3
			,NULL AS Party_Account_Nbr
			,l.Party2_SSN_Number AS Party_SSN_Nbr
			,NULL AS Party_Driver_License_Nbr
			,NULL AS Party_Driver_License_State
			--,NULL AS Party_Date_Of_Birth
			,NULL AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 2 Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party2_First_Name IS NOT NULL
				OR l.Party2_Middle_Name IS NOT NULL
				OR l.Party2_Last_Name IS NOT NULL
				OR l.Party2_Name_Suffix IS NOT NULL
				--OR l.Party2_Alias_Name_Type IS NOT NULL
				OR l.Party2_Company_Name IS NOT NULL
				)
		
		UNION ALL
		
		SELECT DISTINCT l.Leap_id
			,r._Role AS RoleType
			,l.Party3_First_Name AS Party_FirstName
			,l.Party3_Middle_Name AS Party_MiddleName
			,l.Party3_Last_Name AS Party_LastName
			,l.Party3_Name_Suffix AS Party_NameSuffix
			,NULL AS Party_Alias_Name_Type
			,l.Party3_Company_Name AS Party_Company_Name
			,NULL AS Party_Mail_Street_Addr
			,NULL AS Party_Mail_City
			,NULL AS Party_Mail_State
			,NULL AS Party_Mail_Zip_Code
			,NULL AS Party_Mail_Zip_Plus4
			,NULL AS Foreign_Addr_Part1
			,NULL AS Foreign_Addr_Part2
			,NULL AS Foreign_Addr_Part3
			,NULL AS Party_Account_Nbr
			,NULL AS Party_SSN_Nbr
			,NULL AS Party_Driver_License_Nbr
			,NULL AS Party_Driver_License_State
			--,NULL AS Party_Date_Of_Birth
			,NULL AS PhoneNumber
		FROM #Leap4 l
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Lien].[LEAP].[PartyRoles] r
			WHERE r._Column = 'Party 3 Last Name'
				AND r.DocumentCode = l.Document_Code
			) r
		WHERE /*l.InstrumentNumber = '2017432830'
				AND --l.InstrumentNumber = '2017167423'  and*/
			(
				l.Party3_First_Name IS NOT NULL
				OR l.Party3_Middle_Name IS NOT NULL
				OR l.Party3_Last_Name IS NOT NULL
				OR l.Party3_Name_Suffix IS NOT NULL
				OR l.Party3_Company_Name IS NOT NULL
				--OR l.Party3_Alias_Name_Type IS NOT NULL
				)
		) q
	OUTER APPLY (
		SELECT CASE 
				WHEN Party1_FirstName IS NOT NULL
					AND Party1_LastName IS NULL
					AND Party1_Company_Name IS NULL
					THEN 'F_C'
				ELSE 'F'
				END AS FirstName_Rule
			,CASE 
				WHEN Party1_FirstName IS NULL
					AND Party1_LastName IS NOT NULL
					AND Party1_Company_Name IS NULL
					AND Party1_MiddleName IS NULL
					THEN 'L_C'
				ELSE 'L'
				END LastName_Rule
		) ss
	OUTER APPLY (
		SELECT CASE 
				WHEN FirstName_Rule = 'F_C'
					THEN Party1_FirstName
				WHEN LastName_Rule = 'L_C'
					THEN Party1_LastName
				ELSE Party1_Company_Name
				END AS Party1_Company_Name
			,CASE 
				WHEN FirstName_Rule = 'F'
					THEN Party1_FirstName
				ELSE NULL
				END AS Party1_FirstName
			,CASE 
				WHEN LastName_Rule = 'L'
					THEN Party1_LastName
				ELSE NULL
				END AS Party1_LastName
		) qq

	--
	-- Load Lean_New_Poperty
	--
	--IF object_id('Lien.tmp.Leap_New_Property') IS NOT NULL
	--	DROP TABLE Lien.tmp.Leap_New_Property;
	TRUNCATE TABLE [Lien].[tmp].[Leap_New_Property]

	INSERT INTO [Lien].[tmp].[Leap_New_Property] (
		[Leap_id]
		,[property_id_sequence_number]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[legal_desc_address_zip]
		,[legal_desc_apn_portion]
		,[legal_desc_apn]
		,[legal_desc_map_lot_low]
		,[legal_desc_map_block]
		,[Legal_Desc_MAP_Plat_Name] ----
		,[Legal_Desc_MAP_Plat_Number] ----
		,[legal_desc_map_plat_book]
		,[legal_desc_map_plat_page]
		,[legal_desc_str_government_lot]
		,[legal_desc_map_unit_low]
		,[legal_desc_str_section]
		,[legal_desc_str_township]
		,[legal_desc_str_range]
		,[legal_desc_district]
		,[legal_desc_municipality]
		)
	--,[Legal_Desc_Multi_Property_Flag] --
	--,[Legal_Desc_Multi_APN_Flag] --
	SELECT a.Leap_id
		,ROW_NUMBER() OVER (
			PARTITION BY a.Leap_id ORDER BY (
					SELECT 0
					)
			) AS [property_id_sequence_number]
		,a.legal_desc_address
		,a.legal_desc_address_city
		,a.legal_desc_address_state
		,a.Property_Zip_Code
		,a.Property_Zip_Plus4
		,a.legal_desc_address_zip
		,a.legal_desc_apn_portion
		,a.legal_desc_apn
		,a.legal_desc_map_lot_low
		,a.legal_desc_map_block
		,a.Legal_Desc_MAP_Plat_Name
		,a.Legal_Desc_MAP_Plat_Number
		,a.legal_desc_map_plat_book
		,a.legal_desc_map_plat_page
		,a.legal_desc_str_government_lot
		,a.legal_desc_map_unit_low
		,a.legal_desc_str_section
		,a.legal_desc_str_township
		,a.legal_desc_str_range
		,a.legal_desc_district
		,a.legal_desc_municipality
	--,a.Legal_Desc_Multi_Property_Flag --
	--,a.Legal_Desc_Multi_APN_Flag --
	FROM (
		SELECT DISTINCT lb.Leap_id
			,lb.[Property_Address] AS [legal_desc_address]
			,lb.[Property_City] AS [legal_desc_address_city]
			,lb.[Property_State] AS [legal_desc_address_state]
			,lb.[Property_Zip_Code]
			,lb.[Property_Zip_Plus4]
			,ltrim(rtrim(isnull(lb.[Property_Zip_Code], '') + isnull(lb.[Property_Zip_Plus4], ''))) AS [legal_desc_address_zip]
			,lb.[Apn_Portion_Indicator] AS [legal_desc_apn_portion]
			--,lb.[Parcel] AS [legal_desc_apn]
			,lb.[APN] AS [legal_desc_apn]
			,lb.[Lot] AS legal_desc_map_lot_low
			,lb.[Block] AS [legal_desc_map_block]
			,lb.Tract_Name AS [Legal_Desc_MAP_Plat_Name] ----
			,lb.Parcel AS [Legal_Desc_MAP_Plat_Number] ----
			,lb.[Parcel_Map_Book] AS [legal_desc_map_plat_book]
			,lb.[Parcel_Map_Page] AS [legal_desc_map_plat_page]
			,lb.[Land_Lot] AS [legal_desc_str_government_lot]
			,lb.Unit_Number AS legal_desc_map_unit_low
			,lb.[Section] AS [legal_desc_str_section]
			,lb.[Township] AS [legal_desc_str_township]
			,lb.[Range] AS [legal_desc_str_range]
			,lb.[District_Number] AS [legal_desc_district]
			,lb.[Municipality_Code] AS [legal_desc_municipality]
		--,lb.Multiple_Record_Indicator1 as Legal_Desc_Multi_Property_Flag --
		--,lb.Multiple_Record_Indicator2 as Legal_Desc_Multi_APN_Flag --
		FROM #Leap4 lb
		WHERE --ROW4 = 1
			--AND
			/*lb.Part_seq = 1
and */ (
				lb.[Property_Address] IS NOT NULL
				OR lb.[Property_City] IS NOT NULL
				OR lb.[Property_State] IS NOT NULL
				OR lb.[Property_Zip_Code] IS NOT NULL
				OR lb.[Property_Zip_Plus4] IS NOT NULL
				--OR lb.[Apn_Portion_Indicator] IS NOT NULL
				OR lb.[Parcel] IS NOT NULL
				OR lb.[APN] IS NOT NULL
				OR lb.[Lot] IS NOT NULL
				OR lb.[Block] IS NOT NULL
				OR lb.[Parcel_Map_Book] IS NOT NULL
				OR lb.[Parcel_Map_Page] IS NOT NULL
				OR lb.[Land_Lot] IS NOT NULL
				OR lb.[Section] IS NOT NULL
				OR lb.[Township] IS NOT NULL
				OR lb.[Range] IS NOT NULL
				OR lb.[District_Number] IS NOT NULL
				OR lb.[Municipality_Code] IS NOT NULL
				OR lb.Tract_Name IS NOT NULL
				OR lb.Parcel IS NOT NULL
				--or lb.Multiple_Record_Indicator1 is not null
				--or lb.Multiple_Record_Indicator2 is not null
				)
		) a

	--Select * from Lien.tmp.Leap_New_Property  where leap_id = 14148
	--CREATE /*unique*/ INDEX ix_fips_InstrumentNumber_Apn_Part_seq ON Lien.tmp.Leap_New_Property (
	--	Leap_id
	--	,property_id_sequence_number
	--	) 
	--Select * from Lien.LEAP.Leap_New_Property where [property_id_sequence_number] > 1
	/*
select * from Lien.LEAP.Leap_New_Parties
*/
	--CREATE /*unique*/ INDEX ix_fips_InstrumentNumber_Apn_Part_seq ON Lien.tmp.Leap_New_Parties (
	--	Leap_id
	--	,Party_seq 
	--	)
	/*IF object_id('Lien.tmp.Leap_New') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Lien].[tmp].[Leap_New];

	SELECT l.ID
		,l.Part_seq
		,l.ROW4
		,l.leap_id
		,l.InstrumentNumber
		,l.Apn
		--,l.Apn_Portion_Indicator
		,l.Multiple_Record_Indicator1
		,l.Multiple_Record_Indicator2
		,l.Apn_Research_Indicator
		,l.STATE
		,l.County
		,l.Fips
		,l.Vendor_Code
		,l.Recording_Doc_Nbr
		,l.Recording_Book_Nbr
		,l.Recording_Page_Nbr
		--,l.Recording_Date
		,cast(SUBSTRING(Recording_Date, 5, 4) + SUBSTRING(Recording_Date, 1, 2) + SUBSTRING(Recording_Date, 3, 2) AS DATE) AS Recording_Date
		,l.Document_Type
		,l.Document_Code
		,l.Correction_Indicator
		,l.Lien_Issuing_Agency
		,l.Federal_Tax_Lien_Area
		,l.Tax_Lien_Serial_Nbr
		--name Columns
		--,l.Party1_FirstName
		--,l.Party1_MiddleName
		--,l.Party1_LastName
		--,l.Party1_NameSuffix
		--,l.Party1_Alias_Name_Type
		--,l.Party1_Mail_Street_Addr
		--,l.Party1_Mail_City
		--,l.Party1_Mail_State
		--,l.Party1_Mail_Zip_Code
		--,l.Party1_Mail_Zip_Plus4
		--,l.Foreign_Addr_Part1
		--,l.Foreign_Addr_Part2
		--,l.Foreign_Addr_Part3
		--,l.Party1_Account_Nbr
		--,l.Party1_SSN_Nbr
		--,l.Party1_Driver_License_Nbr
		--,l.Party1_Driver_License_State
		--,l.Party1_Date_Of_Birth
		-- end Name Columns
		,l.Additional_Judgement_Debtors
		,l.Kind_Of_Tax
		,l.Tax_Period_Minimum
		,l.Tax_Period_Maximum
		,l.Last_Day_For_Refiling
		,l.Total_Lien_Estimated_Amount
		,l.Federal_Tax_Lien_Prepared_Signed_City_Name
		,l.Federal_Tax_Lien_Prepared_Signed_State_Code
		--,l.Federal_Tax_Lien_Energy_Doc_Date
		,CASE 
			WHEN isdate(SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 5, 4) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 1, 2) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 3, 2)) = 1
				THEN cast(SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 5, 4) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 1, 2) + SUBSTRING(Federal_Tax_Lien_Energy_Doc_Date, 3, 2) AS DATE)
			ELSE NULL
			END AS Federal_Tax_Lien_Energy_Doc_Date
		-- Begin REferences
		--,l.Reference_Energy_Doc_Number
		--,l.Reference_Energy_Doc_Book
		--,l.Reference_Energy_Doc_Page
		--,l.Reference_Energy_Recording_Date
		,l.Court_Case_Number
		-- End References
		--Additional PArties
		--,l.Party2_First_Name
		--,l.Party2_Middle_Name
		--,l.Party2_Last_Name
		--,l.Party2_Name_Suffix
		--,l.Party2_Mailing_Street
		--,l.Party2_Mailing_City
		--,l.Party2_Mailing_State
		--,l.Party2_Mailing_Zip
		--,l.Party2_Mailing_ZipPlus4
		--,l.Party2_SSN_Number
		--,l.Party3_First_Name
		--,l.Party3_Middle_Name
		--,l.Party3_Last_Name
		--,l.Party3_Name_Suffix
		--end Additional Parties
		--,l.Divorce_Decree_Filing_Date
		,CASE 
			WHEN isdate(SUBSTRING(a.Divorce_Decree_Filing_Date, 5, 4) + SUBSTRING(a.Divorce_Decree_Filing_Date, 1, 2) + SUBSTRING(a.Divorce_Decree_Filing_Date, 3, 2)) = 1
				THEN cast(SUBSTRING(a.Divorce_Decree_Filing_Date, 5, 4) + SUBSTRING(a.Divorce_Decree_Filing_Date, 1, 2) + SUBSTRING(a.Divorce_Decree_Filing_Date, 3, 2) AS DATE)
			ELSE NULL
			END AS Divorce_Decree_Filing_Date
		--Property
		--,l.Property_Address
		--,l.Property_City
		--,l.Property_State
		--,l.Property_Zip_Code
		--,l.Property_Zip_Plus4
		--End Property
		,l.Respondent_SSN_Number ----------------------------this need to go to name
		,l.Attorney_Name ----------------------------this need to go to name
		,l.Attorney_Phone_Number ----------------------------this need to go to name
		,l.Attorney_Flag
		,l.Judgment_Creditor
		,l.Assignee_Of_Record
		--,l.Abstract_Issued_Date
		,CASE 
			WHEN isdate(SUBSTRING(a.Abstract_Issued_Date, 5, 4) + SUBSTRING(a.Abstract_Issued_Date, 1, 2) + SUBSTRING(a.Abstract_Issued_Date, 3, 2)) = 1
				THEN cast(SUBSTRING(a.Abstract_Issued_Date, 5, 4) + SUBSTRING(a.Abstract_Issued_Date, 1, 2) + SUBSTRING(a.Abstract_Issued_Date, 3, 2) AS DATE)
			ELSE NULL
			END AS Abstract_Issued_Date
		,l.Creditor_Name
		,l.Producer_Email_Address
		--,l.Solar_Energy_TermExpire_Date
		,CASE 
			WHEN isdate(SUBSTRING(Solar_Energy_TermExpire_Date, 5, 4) + SUBSTRING(Solar_Energy_TermExpire_Date, 1, 2) + SUBSTRING(Solar_Energy_TermExpire_Date, 3, 2)) = 1
				THEN cast(SUBSTRING(Solar_Energy_TermExpire_Date, 5, 4) + SUBSTRING(Solar_Energy_TermExpire_Date, 1, 2) + SUBSTRING(Solar_Energy_TermExpire_Date, 3, 2) AS DATE)
			ELSE NULL
			END AS Solar_Energy_TermExpire_Date
		,l.Solar_Energy_Type_Of_Agreement
		,l.Installment_Judgment
		,l.Stay_Ordered
		--,l.Stay_Ordered_Date
		,CASE 
			WHEN isdate(SUBSTRING(Stay_Ordered_Date, 5, 4) + SUBSTRING(Stay_Ordered_Date, 1, 2) + SUBSTRING(Stay_Ordered_Date, 3, 2)) = 1
				THEN cast(SUBSTRING(Stay_Ordered_Date, 5, 4) + SUBSTRING(Stay_Ordered_Date, 1, 2) + SUBSTRING(Stay_Ordered_Date, 3, 2) AS DATE)
			ELSE NULL
			END AS Stay_Ordered_Date
		,l.Interest_Rate
		,l.Back_Support_Amount
		--,l.Debtors_Name
		--,l.Address_Type 
		--,l.County_Name
		--,l.Debtors_Phone_Number
		--,l.County_Tax_Lien_Flag
		--,l.Lot
		--,l.Block
		--,l.Tract_Name  move to Legal_Desc_MAP_Plat_Name
		--,l.Parcel move to Legal_Desc_MAP_Plat_Number
		--,l.Parcel_Map_Book
		--,l.Parcel_Map_Page
		--,l.Section
		--,l.Township
		--,l.Range
		--, 
		--,l.Municipality_Code
		--,l.District_Number
		,l.[Tract_Name]
		,l.[Parcel]
		,l.District_Suffix_Number
		--,l.Land_Lot
		--Additional Name columns
		--,l.Party_1A_First_Name
		--,l.Party_1A_Middle_Name_or_Initial
		--,l.Party_1A_Last_Name
		--,l.Party_1A_Name_Suffix
		--,l.Party_1B_First_Name
		--,l.Party_1B_Middle_Name_or_Initial
		--,l.Party_1B_Last_Name
		--,l.Party_1B_Name_Suffix
		--,l.Party_1C_First_Name
		--,l.Party_1C_Middle_Name_or_Initial
		--,l.Party_1C_Last_Name
		--,l.Party_1C_Name_Suffix
		--end Additional Name Columns
		,l.Party1_ETAL_Indicator
		,l.Created_Date
	INTO [Lien].[tmp].[Leap_New]
	FROM #leap4 l
	OUTER APPLY (
		SELECT max(Divorce_Decree_Filing_Date) AS Divorce_Decree_Filing_Date
			,max(Abstract_Issued_Date) AS Abstract_Issued_Date
		FROM #leap4 a
		WHERE a.leap_id = l.Leap_id
		) a
	WHERE --ROW4 = 1
		--AND
		Part_seq = 1

	--select * from  Lien.LEAP.Leap_New
	CREATE UNIQUE INDEX ix_fips_InstrumentNumber_Apn ON [Lien].[tmp].[Leap_New] (Leap_id)

	CREATE UNIQUE INDEX ix_id ON [Lien].[tmp].[Leap_New] (Id)

	--Select * from Lien.LEAP.Leap_New
	--
	-- Set etal if we have more names than what we can fit on the table
	--
	--Select a.cnt, ln.Party1_ETAL_Indicator
	DECLARE @sucess BIT = 0

	BEGIN TRANSACTION

	UPDATE [Lien].[LEAP].[ln]
	SET ln.Party1_ETAL_Indicator = 'Y'
	FROM [Lien].[tmp].[Leap_New] ln
	OUTER APPLY (
		SELECT count(1) AS cnt
		FROM [Lien].[tmp].[Leap_New_Parties] lp4
		WHERE lp4.Leap_id = ln.Leap_id
		) a
	WHERE a.cnt > 4
		AND isnull(ln.Party1_ETAL_Indicator, '') <> 'Y'

	--select * from Lien.LEAP.LEAP_KEYS
	INSERT INTO [Lien].[LEAP].[LEAP_KEYS] (
		[Fips]
		,[InstrumentNumber]
		,[Recording_Date]
		,[Apn]
		,[Court_Case_Number]
		,[Created_Date]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[recording_doc_sequence_number]
		,[SkipInd]
		,[ID]
		)
	SELECT Fips
		,InstrumentNumber
		,Recording_Date
		,Apn
		,Court_Case_Number
		,Created_Date
		,Multiple_Record_Indicator1
		,Multiple_Record_Indicator2
		,recording_doc_sequence_number
		,SkipInd
		,ID
	FROM [Lien].[tmp].[LEAP_KEYs] t

	--select * from Lien.tmp.LEAP_KEYs
	/*IF object_id('Tempdb..#Leap_id_old_new') IS NOT NULL
		*/
DROP TABLE IF EXISTS #Leap_id_old_new;

	SELECT t.Leap_id AS old_leap_id
		,l.leap_id AS new_leap_id
	INTO #Leap_id_old_new
	FROM [Lien].[tmp].[LEAP_KEYs] t
	INNER JOIN [Lien].[LEAP].[LEAP_KEYS] l ON l.Fips = t.Fips
		AND l.InstrumentNumber = t.InstrumentNumber
		AND l.Recording_Date = t.Recording_Date
		AND isnull(l.Apn, '') = isnull(t.Apn, '')
		AND isnull(l.Court_Case_Number, '') = isnull(t.Court_Case_Number, '')
		AND l.Created_Date = t.Created_Date
		AND l.recording_doc_sequence_number = t.recording_doc_sequence_number
		AND l.ID = t.ID

	--Select leap_id ,count(1) as cnt from #Leap_id_old_new group by leap_id having count(1) > 1
	CREATE UNIQUE INDEX ix_old_leap_id ON #Leap_id_old_new (old_leap_id) --,recording_doc_sequence_number)

	CREATE UNIQUE INDEX ix_new_leap_id ON #Leap_id_old_new (new_leap_id) --,recording_doc_sequence_number)

	--Select * from #Leap_id_old_new
	-- SELECT TOP 100 * FROM Lien.tmp.LEAP_KEY_IDS
	--Select top 100 * 
	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[LEAP_KEY_IDS] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[LEAP_RejectRecords] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[Leap_New_Reference] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[Leap_New_Parties] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[Leap_New_Property] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	UPDATE [Lien].[LEAP].[a]
	SET a.Leap_id = b.new_leap_id
	FROM [Lien].[tmp].[Leap_New] a
	INNER JOIN #Leap_id_old_new b ON b.old_leap_id = a.Leap_id

	----------------------------------------------------------------------------------------------------------------------
	INSERT INTO [LIEN].[LEAP].[LEAP_KEY_IDS] (
		[ID]
		,[Fips]
		,[InstrumentNumber]
		,[Recording_Date]
		,[Apn]
		,[Court_Case_Number]
		,[Created_Date]
		,[Leap_id]
		,[SkipInd]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[_checksum]
		)
	SELECT ID
		,Fips
		,InstrumentNumber
		,Recording_Date
		,Apn
		,Court_Case_Number
		,Created_Date
		,Leap_id
		,SkipInd
		,Multiple_Record_Indicator1
		,Multiple_Record_Indicator2
		,_checksum
	FROM [Lien].[tmp].[LEAP_KEY_IDS]

	INSERT INTO [Lien].[LEAP].[LEAP_REJECTS] (
		[id]
		,[Reject_Reason]
		)
	SELECT *
	FROM [Lien].[tmp].[LEAP_REJECTS]

	INSERT INTO [Lien].[LEAP].[LEAP_RejectRecords] (
		[Leap_id]
		,[InstrumentNumber]
		,[ID]
		,[State]
		,[County]
		,[Fips]
		,[Vendor_Code]
		,[Recording_Doc_Nbr]
		,[Recording_Book_Nbr]
		,[Recording_Page_Nbr]
		,[Recording_Date]
		,[Document_Type]
		,[Document_Code]
		,[Correction_Indicator]
		,[Lien_Issuing_Agency]
		,[Federal_Tax_Lien_Area]
		,[Tax_Lien_Serial_Nbr]
		,[Party1_FirstName]
		,[Party1_MiddleName]
		,[Party1_LastName]
		,[Party1_NameSuffix]
		,[Party1_Alias_Name_Type]
		,[Party1_Mail_Street_Addr]
		,[Party1_Mail_City]
		,[Party1_Mail_State]
		,[Party1_Mail_Zip_Code]
		,[Party1_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party1_Account_Nbr]
		,[Party1_SSN_Nbr]
		,[Party1_Driver_License_Nbr]
		,[Party1_Driver_License_State]
		--,[Party1_Date_Of_Birth]
		,[Additional_Judgement_Debtors]
		,[Kind_Of_Tax]
		,[Tax_Period_Minimum]
		,[Tax_Period_Maximum]
		,[Last_Day_For_Refiling]
		,[Total_Lien_Estimated_Amount]
		,[Federal_Tax_Lien_Prepared_Signed_City_Name]
		,[Federal_Tax_Lien_Prepared_Signed_State_Code]
		,[Federal_Tax_Lien_Energy_Doc_Date]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Doc_Page]
		,[Reference_Energy_Recording_Date]
		,[Court_Case_Number]
		,[Party2_First_Name]
		,[Party2_Middle_Name]
		,[Party2_Last_Name]
		,[Party2_Name_Suffix]
		,[Party2_Mailing_Street]
		,[Party2_Mailing_City]
		,[Party2_Mailing_State]
		,[Party2_Mailing_Zip]
		,[Party2_Mailing_ZipPlus4]
		,[Party2_SSN_Number]
		,[Party3_First_Name]
		,[Party3_Middle_Name]
		,[Party3_Last_Name]
		,[Party3_Name_Suffix]
		,[Divorce_Decree_Filing_Date]
		,[Property_Address]
		,[Property_City]
		,[Property_State]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[Respondent_SSN_Number]
		,[Attorney_Name]
		,[Attorney_Phone_Number]
		,[Attorney_Flag]
		,[Judgment_Creditor]
		,[Assignee_Of_Record]
		,[Abstract_Issued_Date]
		,[Creditor_Name]
		,[Producer_Email_Address]
		,[Solar_Energy_TermExpire_Date]
		,[Solar_Energy_Type_Of_Agreement]
		,[Installment_Judgment]
		,[Stay_Ordered]
		,[Stay_Ordered_Date]
		,[Interest_Rate]
		,[Back_Support_Amount]
		--,[Debtors_Name]
		--,[Address_Type]
		--,[County_Name]
		--,[Debtors_Phone_Number]
		--,[County_Tax_Lien_Flag]
		,[Apn]
		,[Apn_Portion_Indicator]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Apn_Research_Indicator]
		,[Lot]
		,[Block]
		,[Tract_Name]
		,[Parcel]
		,[Parcel_Map_Book]
		,[Parcel_Map_Page]
		,[Section]
		,[Township]
		,[Range]
		,[Unit_Number]
		,[Municipality_Code]
		,[District_Number]
		,[District_Suffix_Number]
		,[Land_Lot]
		,[Party_1A_First_Name]
		,[Party_1A_Middle_Name_or_Initial]
		,[Party_1A_Last_Name]
		,[Party_1A_Name_Suffix]
		,[Party_1B_First_Name]
		,[Party_1B_Middle_Name_or_Initial]
		,[Party_1B_Last_Name]
		,[Party_1B_Name_Suffix]
		,[Party_1C_First_Name]
		,[Party_1C_Middle_Name_or_Initial]
		,[Party_1C_Last_Name]
		,[Party_1C_Name_Suffix]
		,[Party1_ETAL_Indicator]
		,[Created_Date]
		,[Party1_Company_Name]
		,[Party2_Company_Name]
		,[Party3_Company_Name]
		,[Party1A_Company_Name]
		,[Party1B_Company_Name]
		,[Party1C_Company_Name]
		--,[Party2_Alias_Name_Type]
		--,[Party3_Alias_Name_Type]
		,[Party1A_Alias_Name_Type]
		,[Party1B_Alias_Name_Type]
		,[Party1C_Alias_Name_Type]
		)
	SELECT *
	FROM [Lien].[tmp].[LEAP_RejectRecords]

	INSERT INTO [Lien].[LEAP].[Leap_New_Reference] (
		[Leap_id]
		,[Ref_Seq]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Doc_Page]
		,[Reference_Energy_Recording_Date]
		)
	SELECT *
	FROM [Lien].[tmp].[Leap_New_Reference]

	INSERT INTO [Lien].[LEAP].[Leap_New_Parties] (
		[Leap_id]
		,[RoleType]
		,[Party_Seq]
		,[Party_FirstName]
		,[Party_MiddleName]
		,[Party_LastName]
		,[Party_NameSuffix]
		,[Party_Alias_Name_Type]
		,[Party_Company_Name]
		,[Party_Mail_Street_Addr]
		,[Party_Mail_City]
		,[Party_Mail_State]
		,[Party_Mail_Zip_Code]
		,[Party_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party_Account_Nbr]
		,[Party_SSN_Nbr]
		,[Party_Driver_License_Nbr]
		,[Party_Driver_License_State]
		--,[Party_Date_Of_Birth]
		,[PhoneNumber]
		)
	SELECT *
	FROM [Lien].[tmp].[Leap_New_Parties]

	INSERT INTO [Lien].[LEAP].[Leap_New_Property] (
		[Leap_id]
		,[property_id_sequence_number]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[legal_desc_address_zip]
		,[legal_desc_apn_portion]
		,[legal_desc_apn]
		,[legal_desc_map_lot_low]
		,[legal_desc_map_block]
		,[Legal_Desc_MAP_Plat_Name] ----
		,[Legal_Desc_MAP_Plat_Number] ----
		,[legal_desc_map_plat_book]
		,[legal_desc_map_plat_page]
		,[legal_desc_str_government_lot]
		,[legal_desc_map_unit_low]
		,[legal_desc_str_section]
		,[legal_desc_str_township]
		,[legal_desc_str_range]
		,[legal_desc_district]
		,[legal_desc_municipality]
		)
	--,[Legal_Desc_Multi_Property_Flag] --
	--,[Legal_Desc_Multi_APN_Flag] --
	SELECT *
	FROM [Lien].[tmp].[Leap_New_Property]

	INSERT INTO [Lien].[LEAP].[Leap_New] (
		[ID]
		,[Part_seq]
		,[ROW4]
		,[leap_id]
		,[InstrumentNumber]
		,[Apn]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Apn_Research_Indicator]
		,[STATE]
		,[County]
		,[Fips]
		,[Vendor_Code]
		,[Recording_Doc_Nbr]
		,[Recording_Book_Nbr]
		,[Recording_Page_Nbr]
		,[Recording_Date]
		,[Document_Type]
		,[Document_Code]
		,[Correction_Indicator]
		,[Lien_Issuing_Agency]
		,[Federal_Tax_Lien_Area]
		,[Tax_Lien_Serial_Nbr]
		,[Additional_Judgement_Debtors]
		,[Kind_Of_Tax]
		,[Tax_Period_Minimum]
		,[Tax_Period_Maximum]
		,[Last_Day_For_Refiling]
		,[Total_Lien_Estimated_Amount]
		,[Federal_Tax_Lien_Prepared_Signed_City_Name]
		,[Federal_Tax_Lien_Prepared_Signed_State_Code]
		,[Federal_Tax_Lien_Energy_Doc_Date]
		,[Court_Case_Number]
		,[Divorce_Decree_Filing_Date]
		,[Respondent_SSN_Number]
		,[Attorney_Name]
		,[Attorney_Phone_Number]
		,[Attorney_Flag]
		,[Judgment_Creditor]
		,[Assignee_Of_Record]
		,[Abstract_Issued_Date]
		,[Creditor_Name]
		,[Producer_Email_Address]
		,[Solar_Energy_TermExpire_Date]
		,[Solar_Energy_Type_Of_Agreement]
		,[Installment_Judgment]
		,[Stay_Ordered]
		,[Stay_Ordered_Date]
		,[Interest_Rate]
		,[Back_Support_Amount]
		--,[Debtors_Name]
		--,[Address_Type]
		--,[County_Name]
		--,[Debtors_Phone_Number]
		--,[County_Tax_Lien_Flag]
		,[Tract_Name]
		,[Parcel]
		,[District_Suffix_Number]
		,[Party1_ETAL_Indicator]
		,[Created_Date]
		)
	SELECT *
	FROM [Lien].[tmp].[Leap_New]

	INSERT INTO [Lien].[LEAP].[LeapImportDate] (
		[Created_Date]
		,[REcord_count]
		,[Imported]
		)
	SELECT a.created_date
		,a.REcord_count
		,getdate() AS Imported
	FROM (
		SELECT created_date
			,count(1) AS REcord_count
		FROM [Lien].[LEAP].[LEAP] a
		WHERE a.created_date = @created_date
		GROUP BY created_date
		) a

	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	--Declare @Created_Date DateTime = '2017-12-04 04:44:11.000'
	--truncate table lien.[UR].[DOCUMENT]
	--truncate table Lien.UR.PROPERTY 
	--truncate table Lien.UR.REFERENCE
	--truncate table Lien.UR.NAME
	/*IF object_id('Tempdb..#Temp') IS NOT NULL
		*/
DROP TABLE IF EXISTS #Temp;

	SELECT n.Leap_id
	INTO #temp
	FROM [Lien].[LEAP].[LEAP_NEW] n
	WHERE n.Created_Date = @Created_Date

	--n.id  not in (select [source_PK ]   from Lien.UR.DOCUMENT )
	--AND N.ID = 292393
	CREATE UNIQUE INDEX ix_Leap_ID ON #temp (Leap_id)

	-- select top 100 * from Lien.UR.DOCUMENT
	INSERT INTO [Lien].[UR].[DOCUMENT] (
		[doc_unique_id] --- you might want to use this as input: Select newid()
		,[source_PK]
		,[fips_code]
		,[apn_research_flag]
		,[vendor_code]
		,[cmt_docnumber]
		,[cmt_id]
		,[source]
		,[county]
		,[state]
		,[recording_date]
		,[recording_time]
		,[recording_book]
		,[recording_page]
		,[recording_doc_page_count]
		,[recording_year]
		,[recording_doc_number]
		,[recording_doc_number_alternate]
		,[recording_doc_sequence_number]
		,[accomodation_recording]
		,[electronic_recording]
		,[re_recording]
		,[doc_title]
		,[doc_type]
		,[doc_date]
		,[doc_filing_date]
		,[doc_signed_date]
		,[corrected_recording]
		,[retake_recording]
		,[doc_questionable_indicator]
		,[bankruptcy_case_number]
		,[bankruptcy_chapter]
		,[bankruptcy_type]
		,[bankruptcy_location]
		,[case_book]
		,[case_page]
		,[case_number]
		,[case_filed_in_county]
		,[case_court_type]
		,[case_original_number]
		,[case_original_court_type]
		,[case_status]
		,[death_certificate_number]
		,[county_of_death]
		,[city_village_town_of_death]
		,[loan_number]
		,[loan_numberoriginal_senior_loan]
		,[loan_type]
		,[loan_min_number]
		,[mers_flag]
		,[title_escrow_number]
		,[title_gf_number]
		,[title_misc_number]
		,[title_order_number]
		,[title_officer]
		,[title_company_name]
		,[title_company_code]
		,[account_number]
		,[amendment_number]
		,[attorney_bar_number]
		,[bond_number]
		,[lot_line_adjustment_number]
		,[certificate_number]
		,[claim_number]
		,[contract_number]
		,[corporation_number]
		,[estoppel_affidavit_county]
		,[estoppel_affidavit_state]
		,[excise_tax_number]
		,[federal_tax_lien_area]
		,[federal_tax_lien_area_phone]
		,[grantee_is_foreclosing_beneficiary]
		,[installment_judgment]
		,[interfamily_flag]
		,[license_number]
		,[lien_number]
		,[map_plat_id]
		,[mechanics_lien_number]
		,[ordinance_number]
		,[patent_number]
		,[permit_number]
		,[resolution_number]
		,[tax_account_serial_warrant_number]
		,[tax_type]
		,[trustees_sale_number]
		,[ucc_number]
		,[undersigned_same_as_borrower]
		,[water_rights_number]
		,[judgment_amount]
		,[judgment_grand_total]
		,[judgment_court_fees]
		,[judgment_attorney_fees]
		,[judgment_principal_fees]
		,[judgment_interest_fees]
		,[judgment_filing_fees]
		,[judgment_per_diem_fees]
		,[judgment_late_fees]
		,[judgment_tax_fees]
		,[judgment_insurance_fees]
		,[judgment_other_fees]
		,[loan_balloon_payment_amount]
		,[loan_financed_amount]
		,[loan_interest_rate]
		,[loan_advance_additional_new_amount]
		,[loan_maximum_amount_credit_limit]
		,[loan_modification_change_amount]
		,[loan_original_amount]
		,[loan_amount_of_in_favor_of_party]
		,[loan_amount_of_subordinating_party]
		,[loan_amount_subordinated_limit]
		,[recording_fee_1]
		,[recording_fee_2]
		,[recording_fee_3]
		,[recording_fee_4]
		,[recording_fee_5]
		,[recording_fee_6]
		,[recording_fee_7]
		,[recording_fee_total]
		,[transfer_sale_purchase_price]
		,[transfer_tax]
		,[transfer_tax_city]
		,[transfer_tax_county]
		,[transfer_tax_misc]
		,[transfer_tax_state]
		,[transfer_tax_town]
		,[transfer_tax_value_f_p]
		,[transfer_tax_number_non_disclosure_flag]
		,[amount_due]
		,[amount_of_default]
		,[bond_amount]
		,[cash_down_amount]
		,[contract_amount]
		,[collection_costs]
		,[foreclosure_filing_fee]
		,[ground_rent_amount]
		,[ground_rent_frequency]
		,[late_charges]
		,[minimum_bid_amount]
		,[support_arrears_amount]
		,[support_payment_amount]
		,[support_total_amount]
		,[tax_amount]
		,[tax_interest_amount]
		,[tax_penalty_amount]
		,[unpaid_balance]
		,[unpaid_balance_as_of_modification_date]
		,[unpaid_prinicipal_amount_due]
		,[date_bankruptcy_closed]
		,[date_bankruptcy_case_filed]
		,[date_bankruptcy_conversion]
		,[date_bankruptcy_discharged]
		,[date_bankruptcy_dismissed]
		,[date_bankruptcy_341_meeting]
		,[bankruptcy_341_meeting_time]
		,[date_of_birth_of_deceased]
		,[date_of_death]
		,[date_death_certificate_filed]
		,[date_physician_signed_death_certifate]
		,[date_of_divorce]
		,[date_of_marriage]
		,[date_of_separation]
		,[date_of_reconcilation]
		,[date_amount_due]
		,[date_of_assessment]
		,[date_of_auction]
		,[date_balloon_payment_due]
		,[date_of_birth_of_minor_child]
		,[date_of_cessation]
		,[date_of_commencement]
		,[date_of_completion]
		,[date_of_default]
		,[date_of_estoppel_affidavit]
		,[date_first_missed_payment]
		,[date_interest_accrued_to]
		,[date_interest_calculated_through]
		,[date_interest_started]
		,[date_of_judgment]
		,[date_of_lien_total_amount]
		,[date_of_loan_maturity]
		,[date_materials_first_delivered]
		,[date_materials_last_delivered]
		,[date_of_in_favor_of_loan]
		,[date_of_subordinated_loan]
		,[date_stay_ordered]
		,[date_surrendered_mobile_home]
		,[tax_last_day_for_refiling]
		,[tax_period_begin_date]
		,[tax_period_end_date]
		,[date_of_unpaid_balance]
		,[adjustable_int_flag]
		,[adjustable_int_negative_amortization_flag]
		,[adjustable_int_only_flag]
		,[adjustable_int_change_date]
		,[adjustable_int_change_frequency]
		,[adjustable_int_change_interval]
		,[adjustable_int_calculation_change]
		,[adjustable_int_maximum_perc]
		,[adjustable_int_index_type_code]
		,[adjustable_int_change_perc_limit]
		,[adjustable_int_first_int_rate_change_cap]
		,[adjustable_int_look_back_period]
		,[adjustable_int_rate_pay_option]
		,[rider_1_4_family_flag]
		,[rider_assumability_flag]
		,[rider_balloon_payment_flag]
		,[rider_biweekly_payment_flag]
		,[rider_condominium_flag]
		,[rider_conversion_flag]
		,[rider_construction_loan_flag]
		,[rider_demand_or_broker_call_loan_flag]
		,[rider_equity_loan_flag]
		,[rider_graduated_payment_flag]
		,[rider_growing_equity_loan_flag]
		,[rider_home_improvement_flag]
		,[rider_homestead_flag]
		,[rider_interest_only_loan_flag]
		,[rider_planned_unit_development_flag]
		,[rider_pre_payment_flag]
		,[rider_prime_equity_line_flag]
		,[rider_rate_improvement_flag]
		,[rider_request_for_notice_flag]
		,[rider_second_home_flag]
		,[rider_shared_appreciation_flag]
		,[rider_trust_revocable_trust_flag]
		,[rider_va_flag]
		,[auction_address]
		,[auction_city]
		,[auction_state]
		,[auction_zip]
		,[auction_time]
		,[judges_last_name]
		,[judges_first_name]
		,[judges_middle_initial]
		,[judges_suffix]
		,[judges_phone]
		,[judges_name_blob]
		,[nmls_company1]
		,[nmls_company1_id]
		,[nmls_company2]
		,[nmls_company2_id]
		,[nmls_officer]
		,[nmls_officer_id]
		,[notary_place_of_execution]
		,[notary_date_of_execution]
		,[notary_last_name]
		,[notary_first_name]
		,[notary_middle_name]
		,[notary_suffix]
		,[notary_commission_license_number]
		,[notary_commission_expiration_date]
		,[notary_vendor_number]
		,[notary_phone]
		,[notary_county_where_bond_is_filed]
		,[notary_state_where_bond_is_filed]
		,[notary_company_where_bond_is_insured]
		,[payment_address]
		,[payment_address_city]
		,[payment_address_state]
		,[payment_address_zip]
		,[payment_address_phone]
		,[place_of_filing_address]
		,[place_of_filing_address_city]
		,[place_of_filing_address_state]
		,[place_of_filing_address_zip]
		,[place_of_filing_phone]
		,[requested_prepared_by_attorney_name_identifier]
		,[requested_prepared_by_attorney_last_company_name]
		,[requested_prepared_by_attorney_first_name]
		,[requested_prepared_by_attorney_middle_initial]
		,[requested_prepared_by_attorney_suffix]
		,[requested_prepared_by_attorney_address]
		,[requested_prepared_by_attorney_address_city]
		,[requested_prepared_by_attorney_address_state]
		,[requested_prepared_by_attorney_address_zip]
		,[requested_prepared_by_attorney_phone]
		,[return_to_name_identifier]
		,[return_to_last_company_name]
		,[return_to_first_name]
		,[return_to_middle_name]
		,[return_to_suffix]
		,[return_to_address]
		,[return_to_city]
		,[return_to_state]
		,[return_to_zip]
		,[return_to_phone]
		,[legal_desc_multi_property_flag]
		,[legal_desc_blob]
		,[legal_desc_multi_apn_flag]
		,[remarks]
		,[lineage_file]
		,[batch]
		,[bucket]
		,[m_create_date]
		,[m_update_date]
		,[Orig_Fips_Code]
		)
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.m_create_date
		,'import_Leap_transaction' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	SELECT (
			SELECT newid()
			) AS doc_unique_id
		,lb.Leap_id AS [source_PK ]
		,try_cast(right('00' + try_cast(lb.Fips as varchar),5) as char(5)) as [fips_code]
		,lb.Apn_Research_Indicator AS apn_research_flag
		,lb.Vendor_Code AS vendor_code
		,lb.Recording_Doc_Nbr AS cmt_docnumber
		,NULL AS cmt_id
		,'LEAP' AS source
		,lb.County AS county
		,lb.STATE AS STATE
		,lb.Recording_Date AS recording_date
		,NULL AS Recording_Time
		,lb.Recording_Book_Nbr AS recording_book
		,lb.Recording_Page_Nbr AS recording_page
		,NULL AS Recording_Doc_Page_Count
		,substring(cast(lb.Recording_Date AS VARCHAR), 1, 4) AS Recording_Year --- our column is Lb.Recording_date
		,lb.Recording_Doc_Nbr AS recording_doc_number
		,NULL AS recording_doc_number_alternate
		--,right('000' + k.recording_doc_sequence_number, 4) AS Recording_Doc_Sequence_Number
		,try_cast(k.recording_doc_sequence_number as int)  AS Recording_Doc_Sequence_Number
		,NULL AS Accomodation_Recording
		,NULL AS Electronic_Recording
		,lb.Correction_Indicator AS Re_Recording
		,NULL AS Doc_Title
		,lb.Document_Code AS doc_type
		,lb.Federal_Tax_Lien_Energy_Doc_Date AS Doc_Date ------------------
		,NULL AS Doc_Filing_Date
		,lb.Abstract_Issued_Date AS Doc_Signed_Date ---------------this date also go to date_of_completion
		,NULL AS Corrected_Recording
		,lb.Correction_Indicator AS Retake_Recording
		,NULL AS Doc_Questionable_Indicator
		,NULL AS Bankruptcy_Case_Number
		,NULL AS Bankruptcy_Chapter
		,NULL AS Bankruptcy_Type
		,NULL AS Bankruptcy_Location
		,NULL AS Case_Book
		,NULL AS Case_Page
		,lb.Court_Case_Number AS [case_number]
		,NULL AS Case_Filed_in_County
		,NULL AS Case_Court_Type
		,NULL AS Case_Original_Number
		,NULL AS Case_Original_Court_Type
		,NULL AS Case_Status
		,NULL AS Death_Certificate_Number
		,NULL AS County_of_Death
		,NULL AS City_Village_Town_of_Death
		,NULL AS Loan_Number
		,NULL AS Loan_NumberOriginal_Senior_Loan -- this one was not in the original
		,NULL AS Loan_Type -- this one was notin the original
		,NULL AS Loan_MIN_Number -- this one was notin the original
		,NULL AS MERS_Flag
		,NULL AS Title_Escrow_Number
		,NULL AS Title_GF_Number
		,NULL AS Title_Misc_Number
		,NULL AS Title_Order_Number
		,NULL AS Title_Officer
		,NULL AS Title_Company_Name
		,NULL AS Title_Company_Code
		,NULL AS Account_Number
		,NULL AS Amendment_Number
		,NULL AS Attorney_Bar_Number
		,NULL AS Bond_Number
		,NULL AS Lot_Line_Adjustment_Number
		,NULL AS Certificate_Number
		,NULL AS Claim_Number
		,NULL AS Contract_Number
		,NULL AS Corporation_Number
		,NULL AS Estoppel_Affidavit_County
		,NULL AS Estoppel_Affidavit_State
		,NULL AS Excise_Tax_Number
		,NULL AS Federal_Tax_Lien_Area
		,NULL AS Federal_Tax_Lien_Area_Phone
		,NULL AS Grantee_is_Foreclosing_Beneficiary
		,NULL AS Installment_Judgment
		,NULL AS Interfamily_Flag
		,NULL AS License_Number
		,NULL AS Lien_Number
		,NULL AS [map_plat_id]
		,NULL AS [mechanics_lien_number]
		,NULL AS [ordinance_number]
		,NULL AS [patent_number]
		,NULL AS [permit_number]
		,NULL AS [resolution_number]
		,lb.Tax_Lien_Serial_Nbr AS [tax_account_serial_warrant_number]
		,NULL AS [tax_type]
		,NULL AS [trustees_sale_number]
		,NULL AS [ucc_number]
		,NULL AS [undersigned_same_as_borrower]
		,NULL AS [water_rights_number]
		,lb.Total_Lien_Estimated_Amount AS [judgment_amount]
		,NULL AS [judgment_grand_total]
		,NULL AS [judgment_court_fees]
		,NULL AS [judgment_attorney_fees]
		,NULL AS [judgment_principal_fees]
		,NULL AS [judgment_interest_fees]
		,NULL AS [judgment_filing_fees]
		,NULL AS [judgment_per_diem_fees]
		,NULL AS [judgment_late_fees]
		,NULL AS [judgment_tax_fees]
		,NULL AS [judgment_insurance_fees]
		,NULL AS [judgment_other_fees]
		,NULL AS [loan_balloon_payment_amount]
		,NULL AS [loan_financed_amount]
		,lb.Interest_Rate AS [loan_interest_rate]
		,NULL AS [loan_advance_additional_new_amount]
		,NULL AS [loan_maximum_amount_credit_limit]
		,NULL AS [loan_modification_change_amount]
		,NULL AS [loan_original_amount]
		,NULL AS [loan_amount_of_in_favor_of_party]
		,NULL AS [loan_amount_of_subordinating_party]
		,NULL AS [loan_amount_subordinated_limit]
		,NULL AS [recording_fee_1]
		,NULL AS [recording_fee_2]
		,NULL AS [recording_fee_3]
		,NULL AS [recording_fee_4]
		,NULL AS [recording_fee_5]
		,NULL AS [recording_fee_6]
		,NULL AS [recording_fee_7]
		,NULL AS [recording_fee_total]
		,NULL AS [transfer_sale_purchase_price]
		,NULL AS [transfer_tax]
		,NULL AS [transfer_tax_city]
		,NULL AS [transfer_tax_county]
		,NULL AS [transfer_tax_misc]
		,NULL AS [transfer_tax_state]
		,NULL AS [transfer_tax_town]
		,NULL AS [transfer_tax_value_f_p]
		,NULL AS [transfer_tax_number_non_disclosure_flag]
		,NULL AS [amount_due]
		,NULL AS [amount_of_default]
		,NULL AS [bond_amount]
		,NULL AS [cash_down_amount]
		,NULL AS [contract_amount]
		,NULL AS [collection_costs]
		,NULL AS [foreclosure_filing_fee]
		,NULL AS [ground_rent_amount]
		,NULL AS [ground_rent_frequency]
		,NULL AS [late_charges]
		,NULL AS [minimum_bid_amount]
		,lb.Back_Support_Amount AS [support_arrears_amount] -------------------------- also go to unpaid_balance
		,NULL AS [support_payment_amount]
		,NULL AS [support_total_amount]
		,NULL AS [tax_amount]
		,NULL AS [tax_interest_amount]
		,NULL AS [tax_penalty_amount]
		,lb.Back_Support_Amount AS [unpaid_balance] -----------------------also go to support Support Arrears Amount
		,NULL AS [unpaid_balance_as_of_modification_date]
		,NULL AS [unpaid_prinicipal_amount_due]
		,NULL AS [date_bankruptcy_closed]
		,NULL AS [date_bankruptcy_case_filed]
		,NULL AS [date_bankruptcy_conversion]
		,NULL AS [date_bankruptcy_discharged]
		,NULL AS [date_bankruptcy_dismissed]
		,NULL AS [date_bankruptcy_341_meeting]
		,NULL AS [bankruptcy_341_meeting_time]
		,NULL AS [date_of_birth_of_deceased]
		,NULL AS [date_of_death]
		,NULL AS [date_death_certificate_filed]
		,NULL AS [date_physician_signed_death_certifate]
		--,lb.Divorce_Decree_Filing_Date AS [date_of_divorce]
		,CASE 
			WHEN lb.Document_Code IN (
					'DCRDIV'
					,'JDGDIV'
					,'ORDDIV'
					,'PETDIV'
					)
				THEN lb.Divorce_Decree_Filing_Date
			ELSE NULL
			END AS [date_of_divorce]
		,NULL AS [date_of_marriage]
		,NULL AS [date_of_separation]
		,NULL AS [date_of_reconcilation]
		,NULL AS [date_amount_due]
		,NULL AS [date_of_assessment]
		,NULL AS [date_of_auction]
		,NULL AS [date_balloon_payment_due]
		,NULL AS [date_of_birth_of_minor_child]
		,NULL AS [date_of_cessation]
		,NULL AS [date_of_commencement]
		,lb.Abstract_Issued_Date AS [date_of_completion] -------------------this date also go to  Doc_Signed_Date
		,NULL AS [date_of_default]
		,NULL AS [date_of_estoppel_affidavit]
		,NULL AS [date_first_missed_payment]
		,NULL AS [date_interest_accrued_to]
		,NULL AS [date_interest_calculated_through]
		,NULL AS [date_interest_started]
		,CASE 
			WHEN lb.Document_Code NOT IN (
					'DCRDIV'
					,'JDGDIV'
					,'ORDDIV'
					,'PETDIV'
					)
				THEN lb.Divorce_Decree_Filing_Date
			ELSE NULL
			END AS [date_of_judgment]
		--,lb.Divorce_Decree_Filing_Date AS [date_of_judgment]
		,NULL AS [date_of_lien_total_amount]
		,NULL AS [date_of_loan_maturity]
		,NULL AS [date_materials_first_delivered]
		,NULL AS [date_materials_last_delivered]
		,NULL AS [date_of_in_favor_of_loan]
		,NULL AS [date_of_subordinated_loan]
		,NULL AS [date_stay_ordered]
		,NULL AS [date_surrendered_mobile_home]
		,lb.Last_Day_For_Refiling AS [tax_last_day_for_refiling]
		,lb.Tax_Period_Minimum AS [tax_period_begin_date]
		,lb.Tax_Period_Maximum AS [tax_period_end_date]
		,NULL AS [date_of_unpaid_balance]
		,NULL AS [adjustable_int_flag]
		,NULL AS [adjustable_int_negative_amortization_flag]
		,NULL AS [adjustable_int_only_flag]
		,NULL AS [adjustable_int_change_date]
		,NULL AS [adjustable_int_change_frequency]
		,NULL AS [adjustable_int_change_interval]
		,NULL AS [adjustable_int_calculation_change]
		,NULL AS [adjustable_int_maximum_perc]
		,NULL AS [adjustable_int_index_type_code]
		,NULL AS [adjustable_int_change_perc_limit]
		,NULL AS [adjustable_int_first_int_rate_change_cap]
		,NULL AS [adjustable_int_look_back_period]
		,NULL AS [adjustable_int_rate_pay_option]
		,NULL AS [rider_1_4_family_flag]
		,NULL AS [rider_assumability_flag]
		,NULL AS [rider_balloon_payment_flag]
		,NULL AS [rider_biweekly_payment_flag]
		,NULL AS [rider_condominium_flag]
		,NULL AS [rider_conversion_flag]
		,NULL AS [rider_construction_loan_flag]
		,NULL AS [rider_demand_or_broker_call_loan_flag]
		,NULL AS [rider_equity_loan_flag]
		,NULL AS [rider_graduated_payment_flag]
		,NULL AS [rider_growing_equity_loan_flag]
		,NULL AS [rider_home_improvement_flag]
		,NULL AS [rider_homestead_flag]
		,NULL AS [rider_interest_only_loan_flag]
		,NULL AS [rider_planned_unit_development_flag]
		,NULL AS [rider_pre_payment_flag]
		,NULL AS [rider_prime_equity_line_flag]
		,NULL AS [rider_rate_improvement_flag]
		,NULL AS [rider_request_for_notice_flag]
		,NULL AS [rider_second_home_flag]
		,NULL AS [rider_shared_appreciation_flag]
		,NULL AS [rider_trust_revocable_trust_flag]
		,NULL AS [rider_va_flag]
		,NULL AS [auction_address]
		,NULL AS [auction_city]
		,NULL AS [auction_state]
		,NULL AS [auction_zip]
		,NULL AS [auction_time]
		,NULL AS [judges_last_name]
		,NULL AS [judges_first_name]
		,NULL AS [judges_middle_initial]
		,NULL AS [judges_suffix]
		,NULL AS [judges_phone]
		,NULL AS [judges_name_blob]
		,NULL AS [nmls_company1]
		,NULL AS [nmls_company1_id]
		,NULL AS [nmls_company2]
		,NULL AS [nmls_company2_id]
		,NULL AS [nmls_officer]
		,NULL AS [nmls_officer_id]
		,NULL AS [notary_place_of_execution]
		,NULL AS [notary_date_of_execution]
		,NULL AS [notary_last_name]
		,NULL AS [notary_first_name]
		,NULL AS [notary_middle_name]
		,NULL AS [notary_suffix]
		,NULL AS [notary_commission_license_number]
		,NULL AS [notary_commission_expiration_date]
		,NULL AS [notary_vendor_number]
		,NULL AS [notary_phone]
		,NULL AS [notary_county_where_bond_is_filed]
		,NULL AS [notary_state_where_bond_is_filed]
		,NULL AS [notary_company_where_bond_is_insured]
		,NULL AS [payment_address]
		,NULL AS [payment_address_city]
		,NULL AS [payment_address_state]
		,NULL AS [payment_address_zip]
		,NULL AS [payment_address_phone]
		,NULL AS [place_of_filing_address]
		,lb.Federal_Tax_Lien_Prepared_Signed_City_Name AS [place_of_filing_address_city]
		,lb.Federal_Tax_Lien_Prepared_Signed_State_Code AS [place_of_filing_address_state]
		,NULL AS [place_of_filing_address_zip]
		,NULL AS [place_of_filing_phone]
		,NULL AS [requested_prepared_by_attorney_name_identifier]
		,lb.Attorney_Name AS [requested_prepared_by_attorney_last_company_name]
		,NULL AS [requested_prepared_by_attorney_first_name]
		,NULL AS [requested_prepared_by_attorney_middle_initial]
		,NULL AS [requested_prepared_by_attorney_suffix]
		,NULL AS [requested_prepared_by_attorney_address]
		,NULL AS [requested_prepared_by_attorney_address_city]
		,NULL AS [requested_prepared_by_attorney_address_state]
		,NULL AS [requested_prepared_by_attorney_address_zip]
		,lb.Attorney_Phone_Number AS [requested_prepared_by_attorney_phone]
		,NULL AS [return_to_name_identifier]
		,NULL AS [return_to_last_company_name]
		,NULL AS [return_to_first_name]
		,NULL AS [return_to_middle_name]
		,NULL AS [return_to_suffix]
		,NULL AS [return_to_address]
		,NULL AS [return_to_city]
		,NULL AS [return_to_state]
		,NULL AS [return_to_zip]
		,NULL AS [return_to_phone]
		,lb.Multiple_Record_Indicator1 AS [legal_desc_multi_property_flag]
		,NULL AS [legal_desc_blob]
		,lb.Multiple_Record_Indicator2 AS [legal_desc_multi_apn_flag]
		,NULL AS [remarks]
		,NULL AS [lineage_file]
		,NULL AS [batch]
		,NULL AS [bucket]
		,getdate() AS [m_create_date]
		,getdate() AS [m_update_date]
		,try_cast(right('00' + try_cast(lb.Fips as varchar),5) as char(5)) as Orig_Fips_Code
		
	FROM [Lien].[LEAP].[LEAP_NEW] lb
	INNER JOIN #temp t ON t.Leap_id = lb.Leap_ID
	INNER JOIN [lien].[leap].[leap_keys] k ON k.leap_id = lb.leap_id
	OUTER APPLY (
		SELECT doc_id
		FROM [lien].[ur].[document] d
		WHERE t.leap_id = d.source_pk
			AND d.source = 'LEAP'
		) d
	WHERE d.doc_id IS NULL

	/*IF object_id('Tempdb..#Temp_doc_id') IS NOT NULL
		*/
DROP TABLE IF EXISTS #Temp_doc_id;

	SELECT DISTINCT t.leap_id
		,lb.doc_id
		,lb.doc_unique_id
	INTO #Temp_doc_id
	FROM [Lien].[UR].[DOCUMENT] lb
	INNER JOIN #temp t ON t.leap_id = lb.source_pk
		AND lb.source = 'LEAP'

	CREATE UNIQUE INDEX ix_id ON #temp_doc_id (LEap_id)

	--Select count(1) from Lien.UR.DOCUMENT 
	--select count(1) from Lien.LEAP.LEAP_NEW
	--FROM [Lien].LEAP.[LEAP_DOCUMENT]
	-- select count(1) from [Lien].LEAP.[LEAP_PROPERTY]
	INSERT INTO [Lien].[UR].[PROPERTY] (
		[doc_id]
		,[doc_unique_id]
		,[property_id_sequence_number]
		,[legal_desc_abstract_portion]
		,[legal_desc_abstract_acreage]
		,[legal_desc_abstract_name]
		,[legal_desc_abstract_number]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[legal_desc_address_zip]
		,[legal_desc_apn_portion]
		,[legal_desc_apn]
		,[legal_desc_apn_split]
		,[legal_desc_apn_arb]
		,[legal_desc_apn_alternate]
		,[legal_desc_map_portion]
		,[legal_desc_map_unit_low]
		,[legal_desc_map_unit_high]
		,[legal_desc_map_lot_type]
		,[legal_desc_map_lot_type_low]
		,[legal_desc_map_lot_type_high]
		,[legal_desc_map_lot_low]
		,[legal_desc_map_lot_high]
		,[legal_desc_map_block]
		,[legal_desc_map_building]
		,[legal_desc_map_sublot]
		,[legal_desc_map_plat_subcode]
		,[legal_desc_map_plat_name]
		,[legal_desc_map_plat_number]
		,[legal_desc_map_plat_condo_id]
		,[legal_desc_map_plat_type_indicator]
		,[legal_desc_map_plat_book]
		,[legal_desc_map_plat_page]
		,[legal_desc_mine_mining_claim_lode]
		,[legal_desc_mine_mining_district]
		,[legal_desc_mine_mining_survey]
		,[legal_desc_rancho_portion]
		,[legal_desc_rancho_name_number]
		,[legal_desc_str_portion]
		,[legal_desc_str_government_lot]
		,[legal_desc_str_quarter]
		,[legal_desc_str_section]
		,[legal_desc_str_township]
		,[legal_desc_str_range]
		,[legal_desc_tct]
		,[legal_desc_timeshare_name]
		,[legal_desc_timeshare_inventory_control_number]
		,[legal_desc_timeshare_unit]
		,[legal_desc_timeshare_week]
		,[legal_desc_timeshare_season]
		,[legal_desc_timeshare_type]
		,[legal_desc_timeshare_map_plat_lot]
		,[legal_desc_timeshare_map_plat_block]
		,[legal_desc_timeshare_map_plat_id]
		,[legal_desc_timeshare_map_plat_type_indicator]
		,[legal_desc_timeshare_map_plat_book]
		,[legal_desc_timeshare_map_plat_page]
		,[legal_desc_district]
		,[legal_desc_municipality]
		,[legal_desc_swiss_code]
		,[legal_desc_project_name]
		,[legal_desc_easement_flag]
		,[legal_desc_easement_type]
		,[legal_desc_unincorporated_property_flag]
		,[legal_desc_property_questionable_indicator]
		,[batch]
		,[bucket]
		,[m_create_date]
		,[m_update_date]
		)
	SELECT d.doc_id AS doc_id -- lb.doc_unique_id AS [doc_unique_id]
		,d.doc_unique_id AS [doc_unique_id]
		,lb.property_id_sequence_number
		,NULL AS [legal_desc_abstract_portion]
		,NULL AS [legal_desc_abstract_acreage]
		,NULL AS [legal_desc_abstract_name]
		,NULL AS [legal_desc_abstract_number]
		,lb.legal_desc_address AS [legal_desc_address]
		,lb.[legal_desc_address_city] AS [legal_desc_address_city]
		,lb.[legal_desc_address_state] AS [legal_desc_address_state]
		,lb.[Property_Zip_Code] + lb.[Property_Zip_Plus4] AS [legal_desc_address_zip]
		----[Tract_Name] [varchar](30) NULL,
		,lb.[legal_desc_apn_portion] AS [legal_desc_apn_portion] -----------
		,lb.[legal_desc_apn] AS [legal_desc_apn]
		,NULL AS [legal_desc_apn_split]
		,NULL AS [legal_desc_apn_arb]
		,NULL AS [legal_desc_apn_alternate]
		,NULL AS [legal_desc_map_portion]
		,lb.[legal_desc_map_unit_low] AS [legal_desc_map_unit_low]
		,NULL AS [legal_desc_map_unit_high]
		,NULL AS [legal_desc_map_lot_type]
		,NULL AS [legal_desc_map_lot_type_low]
		,NULL AS [legal_desc_map_lot_type_high]
		--,lb.[legal_desc_map_lot_low] AS [legal_desc_map_lot_low]
		,a.Lot_Low AS [legal_desc_map_lot_low]
		--,NULL AS [legal_desc_map_lot_high]
		,a.Lot_High AS [legal_desc_map_lot_high]
		,lb.[legal_desc_map_block] AS [legal_desc_map_block]
		,NULL AS [legal_desc_map_building]
		,NULL AS [legal_desc_map_sublot]
		,NULL AS [legal_desc_map_plat_subcode]
		,lb.legal_desc_map_plat_name AS legal_desc_map_plat_name
		,lb.legal_desc_map_plat_number AS legal_desc_map_plat_number
		,NULL AS [legal_desc_map_plat_condo_id]
		,NULL AS [legal_desc_map_plat_type_indicator]
		,lb.[legal_desc_map_plat_book] AS [legal_desc_map_plat_book]
		,lb.[legal_desc_map_plat_page] AS [legal_desc_map_plat_page]
		,NULL AS [legal_desc_mine_mining_claim_lode]
		,NULL AS [legal_desc_mine_mining_district]
		,NULL AS [legal_desc_mine_mining_survey]
		,NULL AS [legal_desc_rancho_portion]
		,NULL AS [legal_desc_rancho_name_number]
		,NULL AS [legal_desc_str_portion]
		,lb.[legal_desc_str_government_lot] AS [legal_desc_str_government_lot]
		,NULL AS [legal_desc_str_quarter]
		,lb.[legal_desc_str_section] AS [legal_desc_str_section]
		,lb.[legal_desc_str_township] AS [legal_desc_str_township]
		,lb.[legal_desc_str_range] AS [legal_desc_str_range]
		,NULL AS [legal_desc_tct]
		,NULL AS [legal_desc_timeshare_name]
		,NULL AS [legal_desc_timeshare_inventory_control_number]
		,NULL AS [legal_desc_timeshare_unit]
		,NULL AS [legal_desc_timeshare_week]
		,NULL AS [legal_desc_timeshare_season]
		,NULL AS [legal_desc_timeshare_type]
		,NULL AS [legal_desc_timeshare_map_plat_lot]
		,NULL AS [legal_desc_timeshare_map_plat_block]
		,NULL AS [legal_desc_timeshare_map_plat_id]
		,NULL AS [legal_desc_timeshare_map_plat_type_indicator]
		,NULL AS [legal_desc_timeshare_map_plat_book]
		,NULL AS [legal_desc_timeshare_map_plat_page]
		,lb.[legal_desc_district] AS [legal_desc_district]
		,lb.[legal_desc_municipality] AS [legal_desc_municipality]
		,NULL AS [legal_desc_swiss_code]
		,NULL AS [legal_desc_project_name]
		,NULL AS [legal_desc_easement_flag]
		,NULL AS [legal_desc_easement_type]
		,NULL AS [legal_desc_unincorporated_property_flag]
		,NULL AS [legal_desc_property_questionable_indicator]
		,NULL AS [batch]
		,NULL AS [bucket]
		,Getdate() AS [m_create_date]
		,getdate() AS [m_update_date]
	FROM [Lien].[LEAP].[LEAP_new_Property] lb
	INNER JOIN #temp t ON t.Leap_id = lb.LEap_id -- which records we capture now
	INNER JOIN #temp_doc_id d ON d.Leap_id = lb.LEap_id -- what their unique doc_id is on DOCUMENT
	OUTER APPLY (
		SELECT b.Lot_Low
			,CASE 
				WHEN (
						legal_desc_map_lot_low LIKE '%,%'
						OR legal_desc_map_lot_low LIKE '%-%'
						)
					THEN Lot_high
				ELSE NULL
				END AS Lot_high
		FROM (
			SELECT min(Item) AS Lot_Low
				,max(item) AS Lot_high
			FROM [SPDB].[dbo].[DelimitedSplit8K](REplace(lb.legal_desc_map_lot_low, '-', ','), ',')
			) b
		) a

	--
	-- [Lien].LEAP.[LEAP_NAME]
	--
	INSERT INTO [Lien].[UR].[NAME] (
		[doc_id]
		,[doc_unique_id]
		,[sequence_number]
		,[name_identifier]
		,[name_code]
		,[last_company_name]
		,[first_name]
		,[middle_name]
		,[suffix]
		,[relate_to_name_id]
		,[party_type_code]
		,[relationship_code]
		,[vesting_code]
		,[percent_transferred]
		,[taxpayer_id_ssn_fein]
		,[spousal_information_flag]
		,[address_same_as_property_address_flag]
		,[address]
		,[address_city_name]
		,[address_state_name]
		,[address_zip_code]
		,[phone_number]
		,[email_website]
		,[foreign_address]
		,[foreign_address_country]
		,[questionable_indicator]
		,[role_blob]
		,[role_type]
		,[batch]
		,[bucket]
		,[Leap_Foreign_Addr_Part3]
		,[Leap_Party1_Account_Nbr]
		,[Leap_Party1_SSN_Nbr]
		,[Leap_Party1_Driver_License_Nbr]
		,[Leap_Party1_Driver_License_State]
		,[Leap_Party1_Date_Of_Birth]
		,[contact_name]
		,[m_create_date]
		,[m_update_date]
		)
	--,[Leap_Party1_Date_Of_Birth]
	SELECT d.doc_id AS doc_id
		,d.doc_unique_id AS [doc_unique_id]
		,lb.[Party_Seq] AS [sequence_number]
		,CASE 
			WHEN isnull(lb.[Party_FirstName], '') LIKE '%trust%'
				OR isnull(lb.[Party_FirstName], '') LIKE '%trst%'
				OR isnull(a.last_company_name, '') LIKE '%trust%'
				OR isnull(a.last_company_name, '') LIKE '%trst%'
				THEN 'T'
			WHEN isnull(lb.[Party_FirstName], '') = ''
				AND isnull(a.last_company_name, '') <> ''
				THEN 'C'
			ELSE 'I'
			END AS [name_identifier] -- hive has the values C and I - what does that mean
		,NULL AS [name_code] -- name code is null 
		--,CASE 
		--	WHEN lb.[Party_Company_Name] IS NOT NULL
		--		THEN lb.[Party_Company_Name]
		--	ELSE lb.[Party_LastName]
		--	END AS [last_company_name]
		,a.last_company_name
		,lb.[Party_FirstName] AS [first_name]
		,lb.[Party_MiddleName] AS [middle_name]
		,lb.[Party_NameSuffix] AS [suffix]
		,NULL AS [relate_to_name_id]
		,lb.[Party_Alias_Name_Type] AS [party_type_code]
		,NULL AS [relationship_code]
		,NULL AS [vesting_code]
		,NULL AS [percent_transferred]
		,lb.[Party_SSN_Nbr] AS [taxpayer_id_ssn_fein]
		,NULL AS [spousal_information_flag]
		,NULL AS [address_same_as_property_address_flag]
		,lb.[Party_Mail_Street_Addr] AS [address]
		,lb.[Party_Mail_City] AS [address_city_name]
		,lb.[Party_Mail_State] AS [address_state_name]
		,lb.[Party_Mail_Zip_Code] + lb.[Party_Mail_Zip_Plus4] AS [address_zip_code]
		,lb.PhoneNumber AS [phone_number]
		,NULL AS [email_website]
		,lb.[Foreign_Addr_Part1] AS [foreign_address]
		,lb.[Foreign_Addr_Part2] AS [foreign_address_country]
		,NULL AS [questionable_indicator]
		,NULL AS [role_blob]
		,lb.[RoleType] AS [role_type] -- Borrower -- see table Lien.LEAP.DocumentRole --select top 100 * from Lien.LEAP.DocumentRole
		,NULL AS [batch]
		,NULL AS [bucket]
		,lb.[Foreign_Addr_Part3] AS [Leap_Foreign_Addr_Part3]
		,lb.[Party_Account_Nbr] AS [Leap_Party1_Account_Nbr]
		,NULL AS [Leap_Party1_SSN_Nbr] ---- delete this column
		,lb.[Party_Driver_License_Nbr] AS [Leap_Party1_Driver_License_Nbr]
		,lb.[Party_Driver_License_State] AS [Leap_Party1_Driver_License_State]
		--,lb.[Party_Date_Of_Birth] AS [Leap_Party1_Date_Of_Birth] -----------------------------------------------------Rachel mapped this to Date_of_Birth_of_Minor_Child on UR_DOCUMENT
		,NULL AS [Leap_Party1_Date_Of_Birth]
		,NULL AS [contact_name]
		,Getdate() AS [m_create_date]
		,getdate() AS [m_update_date]
	FROM [Lien].[LEAP].[LEAP_NEW_PARTIES] lb
	INNER JOIN #temp t ON t.leap_id = lb.[Leap_id]
	INNER JOIN #temp_doc_id d ON d.leap_id = lb.[Leap_id]
	OUTER APPLY (
		SELECT CASE 
				WHEN lb.[Party_Company_Name] IS NOT NULL
					THEN lb.[Party_Company_Name]
				ELSE lb.[Party_LastName]
				END AS [last_company_name]
		) a

	--
	-- LEAP_Reference
	--
	INSERT INTO [Lien].[UR].[REFERENCE] (
		[doc_id]
		,[doc_unique_id]
		,[reference_id_sequence_number]
		,[reference_type_code]
		,[reference_book]
		,[reference_page]
		,[reference_recording_year]
		,[reference_doc_number]
		,[reference_recording_date]
		,[reference_questionable_indicator]
		,[batch]
		,[bucket]
		,[Updated]
		,[m_create_date]
		)
	SELECT d.doc_id
		,d.doc_unique_id AS [doc_unique_id]
		,lb.[Ref_Seq] AS [reference_id_sequence_number]
		,' ' AS [reference_type_code] -- we need to get this from EPR
		,lb.[Reference_Energy_Doc_Book] AS [reference_book]
		,lb.[Reference_Energy_Doc_Page] AS [reference_page]
		,datepart(Year, lb.[Reference_Energy_Recording_Date]) AS [reference_recording_year]
		,lb.[Reference_Energy_Doc_Number] AS [reference_doc_number]
		,lb.[Reference_Energy_Recording_Date] AS [reference_recording_date]
		,NULL AS [reference_questionable_indicator]
		,NULL AS [batch]
		,NULL AS [bucket]
		,getdate() AS [Updated]
		,getdate() AS [m_create_date]
	FROM [Lien].[LEAP].[Leap_New_Reference] lb
	INNER JOIN #temp t ON t.leap_id = lb.[Leap_id]
	INNER JOIN #temp_doc_id d ON d.leap_id = lb.[Leap_id]
	ORDER BY doc_id
		,lb.[Ref_Seq]

	--select 1 / 0
	UPDATE [Lien].[LEAP].[a]
	SET a.Fips_code = cast('0' AS VARCHAR) + Fips_code
	FROM [Lien].[ur].[document] a
	WHERE len(a.fips_code) = 4

	COMMIT

	--	SET @sucess = 1
	--END TRY
	--BEGIN CATCH
	--	IF @sucess = 0
	--	BEGIN
	--		ROLLBACK TRANSACTION
	--		GOTO END_ROUTINE
	--	END
	--END CATCH
	--END_ROUTINE:
	--RETURN @sucess
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_LeapDailyLoad'
		,N'Ended'
END


