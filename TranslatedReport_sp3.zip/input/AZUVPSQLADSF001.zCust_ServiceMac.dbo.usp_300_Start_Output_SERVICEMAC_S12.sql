SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_300_Start_Output_SERVICEMAC_S12]

AS
BEGIN
	
	SET NOCOUNT ON;
		DROP TABLE [dbo].[X_CUSTOM_OUTPUT_S12]

		CREATE TABLE [dbo].[X_CUSTOM_OUTPUT_S12](
			[FIPS][varchar](5)NULL,
			[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			--[Mortgage Start Date][varchar](250)NULL,
			[Mortgage Thru Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,

			-----Added 20230509 per NH----
			[Number of Open Liens][varchar](250)NULL,
			
			
			[1st Lender][varchar](250)NULL,
			[1st Recording Date][varchar](250)NULL,
			[1st Mortgage Amount][varchar](250)NULL,
			[1st Doc Number][varchar](250)NULL,
			[1st Loan Type][varchar](250)NULL,
			--[1st Estimated Interest Rate Ind][varchar](250)NULL,
			[1st Interest Rate][varchar](250)NULL,
			[1st Rate Type][varchar](250)NULL,
			[1st Mortgage Term][varchar](250)NULL,
			--[1st Mortgage Est. Payment Amt][varchar](250)NULL,
			--[1st Mortgage Est Loan Balance][varchar](250)NULL,
			[2nd Lender][varchar](250)NULL,
			[2nd Recording Date][varchar](250)NULL,
			[2nd Mortgage Amount][varchar](250)NULL,
			[2nd Doc Number][varchar](250)NULL,
			[2nd Loan Type][varchar](250)NULL,
			--[2nd Estimated Interest Rate Ind][varchar](250)NULL,
			[2nd Interest Rate][varchar](250)NULL,
			[2nd Rate Type][varchar](250)NULL,
			[2nd Mortgage Term][varchar](250)NULL,
			--[2nd Mortgage Est. Payment Amount][varchar](250)NULL,
			--[2nd Mortgage Est Loan Balance][varchar](250)NULL,
			[3rd Lender][varchar](250)NULL,
			[3rd Recording Date][varchar](250)NULL,
			[3rd Mortgage Amount][varchar](250)NULL,
			[3rd Doc Number][varchar](250)NULL,
			[3rd Loan Type][varchar](250)NULL,
			--[3rd Estimated Interest Rate Ind][varchar](250)NULL,
			[3rd Interest Rate][varchar](250)NULL,
			[3rd Rate Type][varchar](250)NULL,
			[3rd Mortgage Term][varchar](250)NULL,
			--[3rd Mortgage Est. Payment Amount][varchar](250)NULL,
			--[3rd Mortgage Est Loan Balance][varchar](250)NULL,
			[4th Lender][varchar](250)NULL,
			[4th Recording Date][varchar](250)NULL,
			[4th Mortgage Amount][varchar](250)NULL,
			[4th Doc Number][varchar](250)NULL,
			[4th Loan Type][varchar](250)NULL,
			--[4th Estimated Interest Rate Ind][varchar](250)NULL,
			[4th Interest Rate][varchar](250)NULL,
			[4th Rate Type][varchar](250)NULL,
			[4th Mortgage Term][varchar](250)NULL,
			--,
			--[4th Mortgage Est. Payment Amount][varchar](250)NULL,
			--[4th Mortgage Est Loan Balance][varchar](250)NULL,


			---------Internal - Remove
			[Mtg1TransactionID][varchar](250)NULL,
			[Mtg2TransactionID][varchar](250)NULL,
			[Mtg3TransactionID][varchar](250)NULL,
			[Mtg4TransactionID][varchar](250)NULL
		
		-----INTERNAL----
		
		,[DATE_ADDED]	[varchar](250)NULL
		) ON [PRIMARY]

		



		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] (
		[INPUT Unique ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		,FIPS
		,WORK_REF_ID
		,PROPERTYID
		,[DATE_ADDED])

		Select 	
		[UniqueId]
		,[Address]
		,[City]
		,[State]
		,[Zip]
		,FIPS
		,[REF_ID]
		,[PROPERTYID]
		,[DATE_RECEIVED]
		--Select * 
	   
		FROM [zCust_ServiceMac].[dbo].[INPUT_MONITOR]
		where REcordIndicator not like 'D'
		and UniqueID is not null

		
		Select count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]

	
		Select top 100 * From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]

		Select FIPS, count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by FIPS
		Order by FIPS



		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM X_CUSTOM_OUTPUT_S12 a JOIN 
		--[dbo].a_PropMatch_Work_FLANK c on a.[INPUT Unique ID] = c.RAW_ID


		Update [zCust_ServiceMac].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN 
		[zCust_ServiceMac].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Unique ID] = c.RAW_ID

			-----

		Update [zCust_ServiceMac].[dbo].[a]
		set [Mortgage Coverage Status] = B.SAMActive
		--,A.[Mortgage Start Date] = case when ISNULL(B.SamMinRecordDate,'') like '' then NULL else convert(date,B.SamMinRecordDate) end
		,A.[Mortgage Thru Date] = case when ISNULL(B.SamMaxRecordDate,'') like '' then NULL else convert(date,B.SamMaxRecordDate) end 
		--Select D_Flag 
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE



		 Update [zCust_ServiceMac].[dbo].[A]
		 Set
		 A.[Number of Open Liens] = B.TotalOpenLienNbr
		 ,A.[Current Owner 1] =   B.OwnerStdNAME1FULL
		,A.[Current Owner 2] =   B.OwnerStdNAME2FULL 
		
		--,
		,A.[1st Lender] = B.Mtg1Lender
		,A.[1st Recording Date] = B.Mtg1RecordingDt
		,A.[1st Mortgage Amount] = B.Mtg1LoanAmt
		,A.[1st Doc Number] = B.Mtg1FormatDocNbr
		,A.[1st Loan Type] = B.Mtg1LoanType
		,A.[1st Interest Rate] = B.Mtg1InterestRate
		,A.[1st Rate Type] = B.Mtg1Typefinancing
		,A.[1st Mortgage Term] = B.Mtg1Term
				
		,A.[2nd Lender] = B.Mtg2Lender
		,A.[2nd Recording Date] = B.Mtg2RecordingDt
		,A.[2nd Mortgage Amount] = B.Mtg2LoanAmt
		,A.[2nd Doc Number] = B.Mtg2FormatDocNbr
		,A.[2nd Loan Type] = B.Mtg2LoanType
		,A.[2nd Interest Rate] = B.Mtg2InterestRate
		,A.[2nd Rate Type] = B.Mtg2Typefinancing
		,A.[2nd Mortgage Term] = B.Mtg2Term

		,A.[3rd Lender] = B.Mtg3Lender
		,A.[3rd Recording Date] = B.Mtg3RecordingDt
		,A.[3rd Mortgage Amount] = B.Mtg3LoanAmt
		,A.[3rd Doc Number] = B.Mtg3FormatDocNbr
		,A.[3rd Loan Type] = B.Mtg3LoanType
		,A.[3rd Interest Rate] = B.Mtg3InterestRate
		,A.[3rd Rate Type] = B.Mtg3Typefinancing
		,A.[3rd Mortgage Term] = B.Mtg3Term

		,A.[4th Lender] = B.Mtg4Lender
		,A.[4th Recording Date] = B.Mtg4RecordingDt
		,A.[4th Mortgage Amount] = B.Mtg4LoanAmt
		,A.[4th Doc Number] = B.Mtg4FormatDocNbr
		,A.[4th Loan Type] = B.Mtg4LoanType
		,A.[4th Interest Rate] = B.Mtg4InterestRate
		,A.[4th Rate Type] = B.Mtg4Typefinancing
		,A.[4th Mortgage Term] = B.Mtg4Term

		,A.[Mtg1TransactionID] = B.[Mtg1TransactionID]
		,A.[Mtg2TransactionID] = B.[Mtg2TransactionID]
		,A.[Mtg3TransactionID] = B.[Mtg3TransactionID]
		,A.[Mtg4TransactionID] = B.[Mtg4TransactionID]
		--Select top 10 B.*
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A join [data].[dbo].[Property] as B with(NOLOCK) on A.FIPS = B.FIPS
		and A.PROPERTYID = B.PropertyID
		where A.PROPERTYID is not null


		--Update A
		--Set
		--A.[1st Mortgage Est Loan Balance] = B.[Mtg1EstLoanBalance]
		--,A.[2nd Mortgage Est Loan Balance] = B.[Mtg2EstLoanBalance]
		--,A.[3rd Mortgage Est Loan Balance] = B.[Mtg3EstLoanBalance]
		--,A.[4th Mortgage Est Loan Balance] = B.[Mtg4EstLoanBalance]
		----Select top 10 B.*
		--From X_CUSTOM_OUTPUT_S12 as A join data.dbo.vAssessor_PREMIUM_NEW as B with(NOLOCK) on A.FIPS = B.FIPS
		--and A.PROPERTYID = B.PropertyID
		--where A.PROPERTYID is not null


		
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_ServiceMac].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Ownership Change Doc Type] = C.DocumentTypeCode
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_ServiceMac].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Ownership Change Doc Type] = C.DocumentTypeCode
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null

		

			----------------DECODE----------
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[1st Loan Type] = B.[CodeDesc]
		--Select A.[1_LoanType], B.*
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Loan_Type] as B on 
		A.[1st Loan Type] = B.LoanTypeID
		
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[2nd Loan Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Loan_Type] as B on 
		A.[2nd Loan Type] = B.LoanTypeID
		
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[3rd Loan Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Loan_Type] as B on 
		A.[3rd Loan Type] = B.LoanTypeID

		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[4th Loan Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Loan_Type] as B on 
		A.[4th Loan Type] = B.LoanTypeID

		---------
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[1st Rate Type]  = B.[CodeDesc]
		--Select A.[1_LoanType], B.*
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Type_Fin] as B on 
		A.[1st Rate Type] = B.[TypeFinId]
		
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[2nd Rate Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Type_Fin] as B on 
		A.[2nd Rate Type] = B.[TypeFinId]
		
		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[3rd Rate Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Type_Fin] as B on 
		A.[3rd Rate Type] = B.[TypeFinId]

		Update [zCust_ServiceMac].[dbo].[A]
		Set A.[4th Rate Type] = B.[CodeDesc]
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A
		join [Global].[dbo].[lkup_Type_Fin] as B on 
		A.[4th Rate Type] = B.[TypeFinId]


		--Update A
		--Set A.[Ownership Change Doc Type] = B.[CodeDesc]
		--From X_CUSTOM_OUTPUT_S12 as A
		--join [Global].[dbo].lkup_Doc_Type as B on 
		--A.[Ownership Change Doc Type] = B.DocTypeID
		
		
			

		----------------------

		Update [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_ServiceMac].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN 
		[zCust_ServiceMac].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID

		Update [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ServiceMac].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] a join [zCust_ServiceMac].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 



		--------------------------------------------------
	
		----MONITORING FOR OPEN LIEN CHANGES
		Update  [zCust_ServiceMac].[dbo].[A]
		SET A.[Event Status] = CASE WHEN 
		ISNULL(A.Mtg1TransactionID,'') <> ISNULL(B.Mtg1TransactionID,'') OR
		ISNULL(A.Mtg2TransactionID,'') <> ISNULL(B.Mtg2TransactionID,'') OR
		ISNULL(A.Mtg3TransactionID,'') <> ISNULL(B.Mtg3TransactionID,'') OR
		ISNULL(A.Mtg4TransactionID,'') <> ISNULL(B.Mtg4TransactionID,'') 
		then 'Event Found' else 'Event Not Found' end
		--Select A.[INPUT Unique ID] 
		--,ISNULL(A.Mtg1TransactionID,'') , ISNULL(B.Mtg1TransactionID,'') ,
		--ISNULL(A.Mtg2TransactionID,'') , ISNULL(B.Mtg2TransactionID,'') ,
		--ISNULL(A.Mtg3TransactionID,'') , ISNULL(B.Mtg3TransactionID,'') ,
		--ISNULL(A.Mtg4TransactionID,'') , ISNULL(B.Mtg4TransactionID,'') 
		From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A join [zCust_ServiceMac].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT Unique ID] = B.UniqueId



		-------DELETING RECORDS WITH NO EVENTS AND NOT NEWLY ADDED----
		Delete from [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		where [Event Status] like 'Event Not Found'
		and DATE_ADDED < Getdate()-5

		

		Select [Property Status], count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Address Standardization]
		
		Select [Event Status], count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Event Status]

		Select [Mortgage Coverage Status], count(*) From [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Mortgage Coverage Status]

		Select * From  [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A 
		where [Property Status] like 'Property Not Found'

		Select * From  [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12] as A 
		Order by [Number of Open Liens] desc


		

END


