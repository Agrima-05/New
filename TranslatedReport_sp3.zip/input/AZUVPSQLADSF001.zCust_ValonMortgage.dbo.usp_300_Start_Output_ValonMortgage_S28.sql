SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_ValonMortgage].[dbo].[usp_300_Start_Output_ValonMortgage_S28]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

	------20250116---Per Workorder
	----S13 - Deed; S28 - INVL; S34 - HOA Lien
	----Valon_Test_Data 20250108
	----S13 - Deed & S28 - INVL, return all recordings after their input start date; S34 - HOA Lien, return ALL Open HOA Liens, regardless of input start date
	----Please alert SE when ready for QC


		DROP TABLE [dbo].[x_Custom_OUTPUT_S28]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S28](
			
			
			
		   [FIPS] [varchar](5) NULL,
			--[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT UniqueID][varchar](250)NULL,
			--[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[INVL Coverage Status][varchar](250)NULL,
			[INVL Thru Date][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status ][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Current Owner Doc Type][varchar](250)NULL,
			[# of Recordings][varchar](250)NULL,
			[Recordingdt][varchar](250)NULL,
			[DocumentDt][varchar](250)NULL,
			[doc_filing_date][varchar](250)NULL,
			[DocNbrSrce][varchar](250)NULL,
			[BookSrce][varchar](250)NULL,
			[PaceSrce][varchar](250)NULL,
			[Doc_Category][varchar](250)NULL,
			[DocTypeID][varchar](250)NULL,
			[DocType][varchar](250)NULL,
			[DocumentTitle][varchar](250)NULL,
			[federal_tax_lien_area][varchar](250)NULL,
			[federal_tax_lien_area_phone][varchar](250)NULL,
			[tax_last_day_for_refiling][varchar](250)NULL,
			[tax_period_begin_date][varchar](250)NULL,
			[tax_period_end_date][varchar](250)NULL,
			[tax_amount][varchar](250)NULL,
			[tax_interest_amount][varchar](250)NULL,
			[tax_penalty_amount][varchar](250)NULL,
			[judgment_amount][varchar](250)NULL,
			[lien_number][varchar](250)NULL,
			[map_plat_id][varchar](250)NULL,
			[mechanics_lien_number][varchar](250)NULL,
			[ordinance_number][varchar](250)NULL,
			[patent_number][varchar](250)NULL,
			[permit_number][varchar](250)NULL,
			[resolution_number][varchar](250)NULL,
			[tax_account_serial_warrant_number][varchar](250)NULL,
			[tax_type][varchar](250)NULL,
			[trustees_sale_number][varchar](250)NULL,
			[ucc_number][varchar](250)NULL,
			[undersigned_same_as_borrower][varchar](250)NULL,
			[amount_due][varchar](250)NULL,
			[amount_of_default][varchar](250)NULL,
			[bond_amount][varchar](250)NULL,
			[cash_down_amount][varchar](250)NULL,
			[contract_amount][varchar](250)NULL,
			[collection_costs][varchar](250)NULL,
			[unpaid_balance][varchar](250)NULL,
			[unpaid_balance_as_of_modification_date][varchar](250)NULL,
			[unpaid_prinicipal_amount][varchar](250)NULL,
			[Party1_Name1_FullName][varchar](250)NULL,
			[Party1_Name1_last_Company_Name][varchar](250)NULL,
			[Party1_Name1_First_Name][varchar](250)NULL,
			[Party1_Name1_Middle_Name][varchar](250)NULL,
			[Party1_Name1_Suffix][varchar](250)NULL,
			[Party1_Name1_Role_Type][varchar](250)NULL,
			[Party1_Name1_MailPropertyID][varchar](250)NULL,
			[Party1_Name1_Address][varchar](250)NULL,
			[Party1_Name1_PreDir][varchar](250)NULL,
			[Party1_Name1_StreetNumber][varchar](250)NULL,
			[Party1_Name1_StreetName][varchar](250)NULL,
			[Party1_Name1_PostDir][varchar](250)NULL,
			[Party1_Name1_StreetType][varchar](250)NULL,
			[Party1_Name1_SuiteType][varchar](250)NULL,
			[Party1_Name1_Suite][varchar](250)NULL,
			[Party1_Name1_City][varchar](250)NULL,
			[Party1_Name1_State][varchar](250)NULL,
			[Party1_Name1_Zip][varchar](250)NULL,
			[Party1_Name1_ZipPlus4][varchar](250)NULL,
			[Party1_Name2_FullName][varchar](250)NULL,
			[Party1_Name2_last_Company_Name][varchar](250)NULL,
			[Party1_Name2_First_Name][varchar](250)NULL,
			[Party1_Name2_Middle_Name][varchar](250)NULL,
			[Party1_Name2_Suffix][varchar](250)NULL,
			[Party1_Name2_Role_Type][varchar](250)NULL,
			[Party1_Name2_MailPropertyID][varchar](250)NULL,
			[Party1_Name2_Address][varchar](250)NULL,
			[Party1_Name2_PreDir][varchar](250)NULL,
			[Party1_Name2_StreetNumber][varchar](250)NULL,
			[Party1_Name2_StreetName][varchar](250)NULL,
			[Party1_Name2_PostDir][varchar](250)NULL,
			[Party1_Name2_StreetType][varchar](250)NULL,
			[Party1_Name2_SuiteType][varchar](250)NULL,
			[Party1_Name2_Suite][varchar](250)NULL,
			[Party1_Name2_City][varchar](250)NULL,
			[Party1_Name2_State][varchar](250)NULL,
			[Party1_Name2_Zip][varchar](250)NULL,
			[Party1_Name2_ZipPlus4][varchar](250)NULL,
			[Party2_Name1_FullName][varchar](250)NULL,
			[Party2_Name1_last_Company_Name][varchar](250)NULL,
			[Party2_Name1_First_Name][varchar](250)NULL,
			[Party2_Name1_Middle_Name][varchar](250)NULL,
			[Party2_Name1_Suffix][varchar](250)NULL,
			[Party2_Name1_Role_Type][varchar](250)NULL,
			[Party2_Name1_MailPropertyID][varchar](250)NULL,
			[Party2_Name1_Address][varchar](250)NULL,
			[Party2_Name1_PreDir][varchar](250)NULL,
			[Party2_Name1_StreetNumber][varchar](250)NULL,
			[Party2_Name1_StreetName][varchar](250)NULL,
			[Party2_Name1_PostDir][varchar](250)NULL,
			[Party2_Name1_StreetType][varchar](250)NULL,
			[Party2_Name1_SuiteType][varchar](250)NULL,
			[Party2_Name1_Suite][varchar](250)NULL,
			[Party2_Name1_City][varchar](250)NULL,
			[Party2_Name1_State][varchar](250)NULL,
			[Party2_Name1_Zip][varchar](250)NULL,
			[Party2_Name1_ZipPlus4][varchar](250)NULL,
			[Party2_Name2_FullName][varchar](250)NULL,
			[Party2_Name2_last_Company_Name][varchar](250)NULL,
			[Party2_Name2_First_Name][varchar](250)NULL,
			[Party2_Name2_Middle_Name][varchar](250)NULL,
			[Party2_Name2_Suffix][varchar](250)NULL,
			[Party2_Name2_Role_Type][varchar](250)NULL,
			[Party2_Name2_MailPropertyID][varchar](250)NULL,
			[Party2_Name2_Address][varchar](250)NULL,
			[Party2_Name2_PreDir][varchar](250)NULL,
			[Party2_Name2_StreetNumber][varchar](250)NULL,
			[Party2_Name2_StreetName][varchar](250)NULL,
			[Party2_Name2_PostDir][varchar](250)NULL,
			[Party2_Name2_StreetType][varchar](250)NULL,
			[Party2_Name2_SuiteType][varchar](250)NULL,
			[Party2_Name2_Suite][varchar](250)NULL,
			[Party2_Name2_City][varchar](250)NULL,
			[Party2_Name2_State][varchar](250)NULL,
			[Party2_Name2_Zip][varchar](250)NULL,
			[Party2_Name2_ZipPlus4][varchar](250)NULL,
			[InactiveFlag][varchar](250)NULL,
			[Reference_recording_year][varchar](250)NULL,
			[reference_recording_date][varchar](250)NULL,
			[reference_doc_number][varchar](250)NULL,
			[reference_book][varchar](250)NULL,
			[reference_page][varchar](250)NULL,
			[Fmt_Reference_Doc_Number][varchar](250)NULL,
			[Fmt_Reference_BookPAge][varchar](250)NULL,

			----------INTERNAL-------------
			[Record #][varchar](250)NULL,
			[INPUTSTARTDATE][varchar](250)NULL,
			[MAX_INVL_RECDATE][varchar](250)NULL
		) ON [PRIMARY]

		

		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28](
		[INPUT UniqueID],
		--[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		,[FIPS]
		,[PROPERTYID]
		,[INPUTSTARTDATE]
		,[MAX_INVL_RECDATE])
	  
		SELECT 
		INPUTKEY
		--,Loan_ID
		,ADDRESS
		,[City]
		,[State]
		,[ZipCODE]
		,[FIPS]
		,[PROPERTYID]
		,convert(date,[Start Date])
		,[MAX_INVL_RECDATE]
		--Select * 
		FROM [zCust_ValonMortgage].[dbo].[INPUT_MONITOR]
		
		

		
	

		

		Select * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]



		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--,A.FIPS = C.FIPS
		--FROM x_Custom_OUTPUT_S28 a JOIN 
		--dbo.a_PropMatch_Work_FLANK c on a.[Input UniqueID] = c.RAW_ID


		
		
		Update [zCust_ValonMortgage].[dbo].[a]
		SET 
		a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = Convert(date,GetDate())
		,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN [zCust_ValonMortgage].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[Input UniqueID] = c.RAW_ID


			

		Update [zCust_ValonMortgage].[dbo].[a]
		set 
		A.[INVL Coverage Status] = case when B.FIPS is not null then 1 else 0 end
		,A.[INVL Thru Date] = B.MAX_DATE
		--Select * 
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a 
			left outer JOIN (Select FIPS, MAX(recordingdt) as MAX_DATE from [data].[dbo].[v_Invl] with(NOLOCK)
			where FIPS in (Select distinct FIPS from [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] where FIPS is not null and FIPS not like '' and FIPS not like '0')
			Group by FIPS) B on 
			A.FIPS = B.FIPS

			
		Update [zCust_ValonMortgage].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID

		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_ValonMortgage].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_ValonMortgage].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_ValonMortgage].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

	

	--------PULL INVL BULK---
	--Drop table dbo.INVL_BULK_PULL
	
		Truncate table dbo.INVL_BULK_PULL

	INSERT INTO [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
	SELECT NULL AS ROWNUM, B.[Input UniqueID] AS [INPUT KEY], A.[TransactionID]
		  ,A.[Fips]
		  ,A.[State]
		  ,A.[County]
		  ,A.[DocumentYear]
		  ,A.[Recordingdt]
		  ,A.[DocumentDt]
		  ,A.[doc_filing_date]
		  ,A.[DocNbrSrce]
		  ,A.[BookSrce]
		  ,A.[PaceSrce]
		  ,A.[Doc_Category]
		  ,A.[DocTypeID]
		  ,A.[DocType]
		  ,A.[DocumentTitle]
		  ,A.[case_number]
		  ,A.[case_book]
		  ,A.[case_page]
		  ,A.[date_of_death]
		  ,A.[account_number]
		  ,A.[amendment_number]
		  ,A.[attorney_bar_number]
		  ,A.[bond_number]
		  ,A.[lot_line_adjustment_number]
		  ,A.[certificate_number]
		  ,A.[claim_number]
		  ,A.[contract_number]
		  ,A.[corporation_number]
		  ,A.[excise_tax_number]
		  ,A.[federal_tax_lien_area]
		  ,A.[federal_tax_lien_area_phone]
		  ,A.[tax_last_day_for_refiling]
		  ,A.[tax_period_begin_date]
		  ,A.[tax_period_end_date]
		  ,A.[tax_amount]
		  ,A.[tax_interest_amount]
		  ,A.[tax_penalty_amount]
		  ,A.[judgment_amount]
		  ,A.[judgment_grand_total]
		  ,A.[judgment_court_fees]
		  ,A.[judgment_attorney_fees]
		  ,A.[judgment_principal_fees]
		  ,A.[judgment_interest_fees]
		  ,A.[judgment_filing_fees]
		  ,A.[judgment_per_diem_fees]
		  ,A.[judgment_late_fees]
		  ,A.[judgment_tax_fees]
		  ,A.[judgment_insurance_fees]
		  ,A.[judgment_other_fees]
		  ,A.[installment_judgment]
		  ,A.[license_number]
		  ,A.[lien_number]
		  ,A.[map_plat_id]
		  ,A.[mechanics_lien_number]
		  ,A.[ordinance_number]
		  ,A.[patent_number]
		  ,A.[permit_number]
		  ,A.[resolution_number]
		  ,A.[tax_account_serial_warrant_number]
		  ,A.[tax_type]
		  ,A.[trustees_sale_number]
		  ,A.[ucc_number]
		  ,A.[undersigned_same_as_borrower]
		  ,A.[amount_due]
		  ,A.[amount_of_default]
		  ,A.[bond_amount]
		  ,A.[cash_down_amount]
		  ,A.[contract_amount]
		  ,A.[collection_costs]
		  ,A.[unpaid_balance]
		  ,A.[unpaid_balance_as_of_modification_date]
		  ,A.[unpaid_prinicipal_amount]
		  ,A.[date_of_divorce]
		  ,A.[support_arrears_amount]
		  ,A.[support_payment_amount]
		  ,A.[support_total_amount]
		  ,A.[date_amount_due]
		  ,A.[date_stay_ordered]
		  ,A.[bankruptcy_case_number]
		  ,A.[bankruptcy_chapter]
		  ,A.[bankruptcy_type]
		  ,A.[bankruptcy_location]
		  ,A.[case_filed_in_county]
		  ,A.[case_court_type]
		  ,A.[case_original_number]
		  ,A.[case_original_court_type]
		  ,A.[case_status]
		  ,A.[date_bankruptcy_closed]
		  ,A.[date_bankruptcy_case_filed]
		  ,A.[date_bankruptcy_conversion]
		  ,A.[date_bankruptcy_discharged]
		  ,A.[date_bankruptcy_dismissed]
		  ,A.[date_bankruptcy_341_meeting]
		  ,A.[bankruptcy_341_meeting_time]
		  ,A.[requested_prepared_by_attorney_name_identifier]
		  ,A.[requested_prepared_by_attorney_last_company_name]
		  ,A.[requested_prepared_by_attorney_first_name]
		  ,A.[requested_prepared_by_attorney_middle_initial]
		  ,A.[requested_prepared_by_attorney_suffix]
		  ,A.[requested_prepared_by_attorney_address]
		  ,A.[requested_prepared_by_attorney_address_city]
		  ,A.[requested_prepared_by_attorney_address_state]
		  ,A.[requested_prepared_by_attorney_address_zip]
		  ,A.[requested_prepared_by_attorney_phone]
		  ,A.[Party1_Name1_FullName]
		  ,A.[Party1_Name1_last_Company_Name]
		  ,A.[Party1_Name1_First_Name]
		  ,A.[Party1_Name1_Middle_Name]
		  ,A.[Party1_Name1_Suffix]
		  ,A.[Party1_Name1_Roll_Type]
		  ,A.[Party1_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name1_Account_Nbr]
		  ,A.[Party1_Name1_SSN_Nbr]
		  ,A.[Party1_Name1_MailPropertyID]
		  ,A.[Party1_Name1_Address]
		  ,A.[Party1_Name1_PreDir]
		  ,A.[Party1_Name1_StreetNumber]
		  ,A.[Party1_Name1_StreetName]
		  ,A.[Party1_Name1_PostDir]
		  ,A.[Party1_Name1_StreetType]
		  ,A.[Party1_Name1_SuiteType]
		  ,A.[Party1_Name1_Suite]
		  ,A.[Party1_Name1_City]
		  ,A.[Party1_Name1_State]
		  ,A.[Party1_Name1_Zip]
		  ,A.[Party1_Name1_ZipPlus4]
		  ,A.[Party1_Name2_FullName]
		  ,A.[Party1_Name2_last_Company_Name]
		  ,A.[Party1_Name2_First_Name]
		  ,A.[Party1_Name2_Middle_Name]
		  ,A.[Party1_Name2_Suffix]
		  ,A.[Party1_Name2_Roll_Type]
		  ,A.[Party1_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name2_Account_Nbr]
		  ,A.[Party1_Name2_SSN_Nbr]
		  ,A.[Party1_Name2_MailPropertyID]
		  ,A.[Party1_Name2_Address]
		  ,A.[Party1_Name2_PreDir]
		  ,A.[Party1_Name2_StreetNumber]
		  ,A.[Party1_Name2_StreetName]
		  ,A.[Party1_Name2_PostDir]
		  ,A.[Party1_Name2_StreetType]
		  ,A.[Party1_Name2_SuiteType]
		  ,A.[Party1_Name2_Suite]
		  ,A.[Party1_Name2_City]
		  ,A.[Party1_Name2_State]
		  ,A.[Party1_Name2_Zip]
		  ,A.[Party1_Name2_ZipPlus4]
		  ,A.[Party1_Name3_FullName]
		  ,A.[Party1_Name3_last_Company_Name]
		  ,A.[Party1_Name3_First_Name]
		  ,A.[Party1_Name3_Middle_Name]
		  ,A.[Party1_Name3_Suffix]
		  ,A.[Party1_Name3_Roll_Type]
		  ,A.[Party1_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name3_Account_Nbr]
		  ,A.[Party1_Name3_SSN_Nbr]
		  ,A.[Party1_Name3_MailPropertyID]
		  ,A.[Party1_Name3_Address]
		  ,A.[Party1_Name3_PreDir]
		  ,A.[Party1_Name3_StreetNumber]
		  ,A.[Party1_Name3_StreetName]
		  ,A.[Party1_Name3_PostDir]
		  ,A.[Party1_Name3_StreetType]
		  ,A.[Party1_Name3_SuiteType]
		  ,A.[Party1_Name3_Suite]
		  ,A.[Party1_Name3_City]
		  ,A.[Party1_Name3_State]
		  ,A.[Party1_Name3_Zip]
		  ,A.[Party1_Name3_ZipPlus4]
		  ,A.[Party1_Name4_FullName]
		  ,A.[Party1_Name4_last_Company_Name]
		  ,A.[Party1_Name4_First_Name]
		  ,A.[Party1_Name4_Middle_Name]
		  ,A.[Party1_Name4_Suffix]
		  ,A.[Party1_Name4_Roll_Type]
		  ,A.[Party1_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name4_Account_Nbr]
		  ,A.[Party1_Name4_SSN_Nbr]
		  ,A.[Party1_Name4_MailPropertyID]
		  ,A.[Party1_Name4_Address]
		  ,A.[Party1_Name4_PreDir]
		  ,A.[Party1_Name4_StreetNumber]
		  ,A.[Party1_Name4_StreetName]
		  ,A.[Party1_Name4_PostDir]
		  ,A.[Party1_Name4_StreetType]
		  ,A.[Party1_Name4_SuiteType]
		  ,A.[Party1_Name4_Suite]
		  ,A.[Party1_Name4_City]
		  ,A.[Party1_Name4_State]
		  ,A.[Party1_Name4_Zip]
		  ,A.[Party1_Name4_ZipPlus4]
		  ,A.[Party2_Name1_FullName]
		  ,A.[Party2_Name1_last_Company_Name]
		  ,A.[Party2_Name1_First_Name]
		  ,A.[Party2_Name1_Middle_Name]
		  ,A.[Party2_Name1_Suffix]
		  ,A.[Party2_Name1_Roll_Type]
		  ,A.[Party2_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name1_Account_Nbr]
		  ,A.[Party2_Name1_SSN_Nbr]
		  ,A.[Party2_Name1_MailPropertyID]
		  ,A.[Party2_Name1_Address]
		  ,A.[Party2_Name1_PreDir]
		  ,A.[Party2_Name1_StreetNumber]
		  ,A.[Party2_Name1_StreetName]
		  ,A.[Party2_Name1_PostDir]
		  ,A.[Party2_Name1_StreetType]
		  ,A.[Party2_Name1_SuiteType]
		  ,A.[Party2_Name1_Suite]
		  ,A.[Party2_Name1_City]
		  ,A.[Party2_Name1_State]
		  ,A.[Party2_Name1_Zip]
		  ,A.[Party2_Name1_ZipPlus4]
		  ,A.[Party2_Name2_FullName]
		  ,A.[Party2_Name2_last_Company_Name]
		  ,A.[Party2_Name2_First_Name]
		  ,A.[Party2_Name2_Middle_Name]
		  ,A.[Party2_Name2_Suffix]
		  ,A.[Party2_Name2_Roll_Type]
		  ,A.[Party2_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name2_Account_Nbr]
		  ,A.[Party2_Name2_SSN_Nbr]
		  ,A.[Party2_Name2_MailPropertyID]
		  ,A.[Party2_Name2_Address]
		  ,A.[Party2_Name2_PreDir]
		  ,A.[Party2_Name2_StreetNumber]
		  ,A.[Party2_Name2_StreetName]
		  ,A.[Party2_Name2_PostDir]
		  ,A.[Party2_Name2_StreetType]
		  ,A.[Party2_Name2_SuiteType]
		  ,A.[Party2_Name2_Suite]
		  ,A.[Party2_Name2_City]
		  ,A.[Party2_Name2_State]
		  ,A.[Party2_Name2_Zip]
		  ,A.[Party2_Name2_ZipPlus4]
		  ,A.[Party2_Name3_FullName]
		  ,A.[Party2_Name3_last_Company_Name]
		  ,A.[Party2_Name3_First_Name]
		  ,A.[Party2_Name3_Middle_Name]
		  ,A.[Party2_Name3_Suffix]
		  ,A.[Party2_Name3_Roll_Type]
		  ,A.[Party2_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name3_Account_Nbr]
		  ,A.[Party2_Name3_SSN_Nbr]
		  ,A.[Party2_Name3_MailPropertyID]
		  ,A.[Party2_Name3_Address]
		  ,A.[Party2_Name3_PreDir]
		  ,A.[Party2_Name3_StreetNumber]
		  ,A.[Party2_Name3_StreetName]
		  ,A.[Party2_Name3_PostDir]
		  ,A.[Party2_Name3_StreetType]
		  ,A.[Party2_Name3_SuiteType]
		  ,A.[Party2_Name3_Suite]
		  ,A.[Party2_Name3_City]
		  ,A.[Party2_Name3_State]
		  ,A.[Party2_Name3_Zip]
		  ,A.[Party2_Name3_ZipPlus4]
		  ,A.[Party2_Name4_FullName]
		  ,A.[Party2_Name4_last_Company_Name]
		  ,A.[Party2_Name4_First_Name]
		  ,A.[Party2_Name4_Middle_Name]
		  ,A.[Party2_Name4_Suffix]
		  ,A.[Party2_Name4_Roll_Type]
		  ,A.[Party2_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name4_Account_Nbr]
		  ,A.[Party2_Name4_SSN_Nbr]
		  ,A.[Party2_Name4_MailPropertyID]
		  ,A.[Party2_Name4_Address]
		  ,A.[Party2_Name4_PreDir]
		  ,A.[Party2_Name4_StreetNumber]
		  ,A.[Party2_Name4_StreetName]
		  ,A.[Party2_Name4_PostDir]
		  ,A.[Party2_Name4_StreetType]
		  ,A.[Party2_Name4_SuiteType]
		  ,A.[Party2_Name4_Suite]
		  ,A.[Party2_Name4_City]
		  ,A.[Party2_Name4_State]
		  ,A.[Party2_Name4_Zip]
		  ,A.[Party2_Name4_ZipPlus4]
		  ,A.[Party3_Name1_FullName]
		  ,A.[Party3_Name1_last_Company_Name]
		  ,A.[Party3_Name1_First_Name]
		  ,A.[Party3_Name1_Middle_Name]
		  ,A.[Party3_Name1_Suffix]
		  ,A.[Party3_Name1_Roll_Type]
		  ,A.[Party3_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name1_Account_Nbr]
		  ,A.[Party3_Name1_SSN_Nbr]
		  ,A.[Party3_Name1_MailPropertyID]
		  ,A.[Party3_Name1_Address]
		  ,A.[Party3_Name1_PreDir]
		  ,A.[Party3_Name1_StreetNumber]
		  ,A.[Party3_Name1_StreetName]
		  ,A.[Party3_Name1_PostDir]
		  ,A.[Party3_Name1_StreetType]
		  ,A.[Party3_Name1_SuiteType]
		  ,A.[Party3_Name1_Suite]
		  ,A.[Party3_Name1_City]
		  ,A.[Party3_Name1_State]
		  ,A.[Party3_Name1_Zip]
		  ,A.[Party3_Name1_ZipPlus4]
		  ,A.[Party3_Name2_FullName]
		  ,A.[Party3_Name2_last_Company_Name]
		  ,A.[Party3_Name2_First_Name]
		  ,A.[Party3_Name2_Middle_Name]
		  ,A.[Party3_Name2_Suffix]
		  ,A.[Party3_Name2_Roll_Type]
		  ,A.[Party3_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name2_Account_Nbr]
		  ,A.[Party3_Name2_SSN_Nbr]
		  ,A.[Party3_Name2_MailPropertyID]
		  ,A.[Party3_Name2_Address]
		  ,A.[Party3_Name2_PreDir]
		  ,A.[Party3_Name2_StreetNumber]
		  ,A.[Party3_Name2_StreetName]
		  ,A.[Party3_Name2_PostDir]
		  ,A.[Party3_Name2_StreetType]
		  ,A.[Party3_Name2_SuiteType]
		  ,A.[Party3_Name2_Suite]
		  ,A.[Party3_Name2_City]
		  ,A.[Party3_Name2_State]
		  ,A.[Party3_Name2_Zip]
		  ,A.[Party3_Name2_ZipPlus4]
		  ,A.[Party3_Name3_FullName]
		  ,A.[Party3_Name3_last_Company_Name]
		  ,A.[Party3_Name3_First_Name]
		  ,A.[Party3_Name3_Middle_Name]
		  ,A.[Party3_Name3_Suffix]
		  ,A.[Party3_Name3_Roll_Type]
		  ,A.[Party3_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name3_Account_Nbr]
		  ,A.[Party3_Name3_SSN_Nbr]
		  ,A.[Party3_Name3_MailPropertyID]
		  ,A.[Party3_Name3_Address]
		  ,A.[Party3_Name3_PreDir]
		  ,A.[Party3_Name3_StreetNumber]
		  ,A.[Party3_Name3_StreetName]
		  ,A.[Party3_Name3_PostDir]
		  ,A.[Party3_Name3_StreetType]
		  ,A.[Party3_Name3_SuiteType]
		  ,A.[Party3_Name3_Suite]
		  ,A.[Party3_Name3_City]
		  ,A.[Party3_Name3_State]
		  ,A.[Party3_Name3_Zip]
		  ,A.[Party3_Name3_ZipPlus4]
		  ,A.[Party3_Name4_FullName]
		  ,A.[Party3_Name4_last_Company_Name]
		  ,A.[Party3_Name4_First_Name]
		  ,A.[Party3_Name4_Middle_Name]
		  ,A.[Party3_Name4_Suffix]
		  ,A.[Party3_Name4_Roll_Type]
		  ,A.[Party3_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name4_Account_Nbr]
		  ,A.[Party3_Name4_SSN_Nbr]
		  ,A.[Party3_Name4_MailPropertyID]
		  ,A.[Party3_Name4_Address]
		  ,A.[Party3_Name4_PreDir]
		  ,A.[Party3_Name4_StreetNumber]
		  ,A.[Party3_Name4_StreetName]
		  ,A.[Party3_Name4_PostDir]
		  ,A.[Party3_Name4_StreetType]
		  ,A.[Party3_Name4_SuiteType]
		  ,A.[Party3_Name4_Suite]
		  ,A.[Party3_Name4_City]
		  ,A.[Party3_Name4_State]
		  ,A.[Party3_Name4_Zip]
		  ,A.[Party3_Name4_ZipPlus4]
		  ,A.[Party4_Name1_FullName]
		  ,A.[Party4_Name1_last_Company_Name]
		  ,A.[Party4_Name1_First_Name]
		  ,A.[Party4_Name1_Middle_Name]
		  ,A.[Party4_Name1_Suffix]
		  ,A.[Party4_Name1_Roll_Type]
		  ,A.[Party4_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name1_Account_Nbr]
		  ,A.[Party4_Name1_SSN_Nbr]
		  ,A.[Party4_Name1_MailPropertyID]
		  ,A.[Party4_Name1_Address]
		  ,A.[Party4_Name1_PreDir]
		  ,A.[Party4_Name1_StreetNumber]
		  ,A.[Party4_Name1_StreetName]
		  ,A.[Party4_Name1_PostDir]
		  ,A.[Party4_Name1_StreetType]
		  ,A.[Party4_Name1_SuiteType]
		  ,A.[Party4_Name1_Suite]
		  ,A.[Party4_Name1_City]
		  ,A.[Party4_Name1_State]
		  ,A.[Party4_Name1_Zip]
		  ,A.[Party4_Name1_ZipPlus4]
		  ,A.[Party4_Name2_FullName]
		  ,A.[Party4_Name2_last_Company_Name]
		  ,A.[Party4_Name2_First_Name]
		  ,A.[Party4_Name2_Middle_Name]
		  ,A.[Party4_Name2_Suffix]
		  ,A.[Party4_Name2_Roll_Type]
		  ,A.[Party4_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name2_Account_Nbr]
		  ,A.[Party4_Name2_SSN_Nbr]
		  ,A.[Party4_Name2_MailPropertyID]
		  ,A.[Party4_Name2_Address]
		  ,A.[Party4_Name2_PreDir]
		  ,A.[Party4_Name2_StreetNumber]
		  ,A.[Party4_Name2_StreetName]
		  ,A.[Party4_Name2_PostDir]
		  ,A.[Party4_Name2_StreetType]
		  ,A.[Party4_Name2_SuiteType]
		  ,A.[Party4_Name2_Suite]
		  ,A.[Party4_Name2_City]
		  ,A.[Party4_Name2_State]
		  ,A.[Party4_Name2_Zip]
		  ,A.[Party4_Name2_ZipPlus4]
		  ,A.[Party4_Name3_FullName]
		  ,A.[Party4_Name3_last_Company_Name]
		  ,A.[Party4_Name3_First_Name]
		  ,A.[Party4_Name3_Middle_Name]
		  ,A.[Party4_Name3_Suffix]
		  ,A.[Party4_Name3_Roll_Type]
		  ,A.[Party4_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name3_Account_Nbr]
		  ,A.[Party4_Name3_SSN_Nbr]
		  ,A.[Party4_Name3_MailPropertyID]
		  ,A.[Party4_Name3_Address]
		  ,A.[Party4_Name3_PreDir]
		  ,A.[Party4_Name3_StreetNumber]
		  ,A.[Party4_Name3_StreetName]
		  ,A.[Party4_Name3_PostDir]
		  ,A.[Party4_Name3_StreetType]
		  ,A.[Party4_Name3_SuiteType]
		  ,A.[Party4_Name3_Suite]
		  ,A.[Party4_Name3_City]
		  ,A.[Party4_Name3_State]
		  ,A.[Party4_Name3_Zip]
		  ,A.[Party4_Name3_ZipPlus4]
		  ,A.[Party4_Name4_FullName]
		  ,A.[Party4_Name4_last_Company_Name]
		  ,A.[Party4_Name4_First_Name]
		  ,A.[Party4_Name4_Middle_Name]
		  ,A.[Party4_Name4_Suffix]
		  ,A.[Party4_Name4_Roll_Type]
		  ,A.[Party4_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name4_Account_Nbr]
		  ,A.[Party4_Name4_SSN_Nbr]
		  ,A.[Party4_Name4_MailPropertyID]
		  ,A.[Party4_Name4_Address]
		  ,A.[Party4_Name4_PreDir]
		  ,A.[Party4_Name4_StreetNumber]
		  ,A.[Party4_Name4_StreetName]
		  ,A.[Party4_Name4_PostDir]
		  ,A.[Party4_Name4_StreetType]
		  ,A.[Party4_Name4_SuiteType]
		  ,A.[Party4_Name4_Suite]
		  ,A.[Party4_Name4_City]
		  ,A.[Party4_Name4_State]
		  ,A.[Party4_Name4_Zip]
		  ,A.[Party4_Name4_ZipPlus4]
		  ,A.[PropertyID]
		  ,A.[AddressLine]
		  ,A.[PreDir]
		  ,A.[StreetNumber]
		  ,A.[StreetName]
		  ,A.[PostDir]
		  ,A.[StreetType]
		  ,A.[SuiteType]
		  ,A.[Suite]
		  ,A.[City]
		  ,A.[PropState]
		  ,A.[Zip]
		  ,A.[Plus4]
		  ,A.[property_id_sequence_number]
		  ,A.[legal_desc_apn_portion]
		  ,A.[legal_desc_apn]
		  ,A.[legal_desc_apn_arb]
		  ,A.[legal_desc_map_portion]
		  ,A.[legal_desc_map_unit_low]
		  ,A.[legal_desc_map_unit_high]
		  ,A.[legal_desc_map_lot_type]
		  ,A.[legal_desc_map_lot_type_low]
		  ,A.[legal_desc_map_lot_type_high]
		  ,A.[legal_desc_map_lot_low]
		  ,A.[legal_desc_map_lot_high]
		  ,A.[legal_desc_map_block]
		  ,A.[legal_desc_map_building]
		  ,A.[legal_desc_map_sublot]
		  ,A.[legal_desc_map_plat_subcode]
		  ,A.[legal_desc_map_plat_name]
		  ,A.[legal_desc_map_plat_number]
		  ,A.[legal_desc_map_plat_condo_id]
		  ,A.[legal_desc_map_plat_type_indicator]
		  ,A.[legal_desc_map_plat_book]
		  ,A.[legal_desc_map_plat_page]
		  ,A.[legal_desc_str_portion]
		  ,A.[legal_desc_str_government_lot]
		  ,A.[legal_desc_str_quarter]
		  ,A.[legal_desc_str_section]
		  ,A.[legal_desc_str_township]
		  ,A.[legal_desc_str_range]
		  ,A.[legal_desc_tct]
		  ,A.[legal_desc_district]
		  ,A.[legal_desc_municipality]
		  ,A.[legal_desc_swiss_code]
		  ,A.[legal_desc_easement_flag]
		  ,A.[legal_desc_easement_type]
		  ,A.[legal_type]
		  ,A.[legal_type_sequence]
		  ,A.[property_sequence]
		  ,A.[legal_desc_qualifier]
		  ,A.[legal_desc_map_city_block]
		  ,A.[legal_desc_application_number]
		  ,A.[legal_desc_tax_assessor_portion]
		  ,A.[legal_desc_tax_assessor_lot]
		  ,A.[legal_desc_tax_assessor_block]
		  ,A.[legal_desc_tax_assessor_section]
		  ,A.[FATimeStamp]
		  ,A.[FARecordType]
		  ,A.[FormattedAPN]
		  ,A.[InActiveFlag]
		  ,A.[StdLandUseCode]
		  ,A.[cmt_docnumber]
		  ,A.[cmt_id]
		  ,A.[PropertyClassID]
		  ,A.[OwnerStd1CorpInd]
		  ,A.[REFERENCE_id]
		  ,A.[Reference_recording_year]
		  ,A.[reference_recording_date]
		  ,A.[reference_doc_number]
		  ,A.[reference_book]
		  ,A.[reference_page]
		  ,A.[Fmt_Reference_Doc_Number]
		  ,A.[Fmt_Reference_BookPAge]
	--Select A.DocNbrSrce, A.Recordingdt, B.[MAX_INVL_RECDATE], B.INPUTSTARTDATE
	FROM     [Data].[dbo].[v_INVL] AS A WITH (NOLOCK) INNER JOIN
					  [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] AS B WITH (NOLOCK) ON A.PropertyID = B.PROPERTYID 
	WHERE  (B.PROPERTYID IS NOT NULL) AND (B.PROPERTYID NOT LIKE '') AND (B.PROPERTYID NOT LIKE '0') 
	AND (A.InActiveFlag IS NULL)
	and A.FARecordType not like 'D'
	and convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,INPUTSTARTDATE)
	AND (convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,[MAX_INVL_RECDATE])
	OR [MAX_INVL_RECDATE] is null)
	


		

	INSERT INTO [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
	SELECT NULL AS ROWNUM, B.[Input UniqueID] AS [INPUT KEY], A.[TransactionID]
		  ,A.[Fips]
		  ,A.[State]
		  ,A.[County]
		  ,A.[DocumentYear]
		  ,A.[Recordingdt]
		  ,A.[DocumentDt]
		  ,A.[doc_filing_date]
		  ,A.[DocNbrSrce]
		  ,A.[BookSrce]
		  ,A.[PaceSrce]
		  ,A.[Doc_Category]
		  ,A.[DocTypeID]
		  ,A.[DocType]
		  ,A.[DocumentTitle]
		  ,A.[case_number]
		  ,A.[case_book]
		  ,A.[case_page]
		  ,A.[date_of_death]
		  ,A.[account_number]
		  ,A.[amendment_number]
		  ,A.[attorney_bar_number]
		  ,A.[bond_number]
		  ,A.[lot_line_adjustment_number]
		  ,A.[certificate_number]
		  ,A.[claim_number]
		  ,A.[contract_number]
		  ,A.[corporation_number]
		  ,A.[excise_tax_number]
		  ,A.[federal_tax_lien_area]
		  ,A.[federal_tax_lien_area_phone]
		  ,A.[tax_last_day_for_refiling]
		  ,A.[tax_period_begin_date]
		  ,A.[tax_period_end_date]
		  ,A.[tax_amount]
		  ,A.[tax_interest_amount]
		  ,A.[tax_penalty_amount]
		  ,A.[judgment_amount]
		  ,A.[judgment_grand_total]
		  ,A.[judgment_court_fees]
		  ,A.[judgment_attorney_fees]
		  ,A.[judgment_principal_fees]
		  ,A.[judgment_interest_fees]
		  ,A.[judgment_filing_fees]
		  ,A.[judgment_per_diem_fees]
		  ,A.[judgment_late_fees]
		  ,A.[judgment_tax_fees]
		  ,A.[judgment_insurance_fees]
		  ,A.[judgment_other_fees]
		  ,A.[installment_judgment]
		  ,A.[license_number]
		  ,A.[lien_number]
		  ,A.[map_plat_id]
		  ,A.[mechanics_lien_number]
		  ,A.[ordinance_number]
		  ,A.[patent_number]
		  ,A.[permit_number]
		  ,A.[resolution_number]
		  ,A.[tax_account_serial_warrant_number]
		  ,A.[tax_type]
		  ,A.[trustees_sale_number]
		  ,A.[ucc_number]
		  ,A.[undersigned_same_as_borrower]
		  ,A.[amount_due]
		  ,A.[amount_of_default]
		  ,A.[bond_amount]
		  ,A.[cash_down_amount]
		  ,A.[contract_amount]
		  ,A.[collection_costs]
		  ,A.[unpaid_balance]
		  ,A.[unpaid_balance_as_of_modification_date]
		  ,A.[unpaid_prinicipal_amount]
		  ,A.[date_of_divorce]
		  ,A.[support_arrears_amount]
		  ,A.[support_payment_amount]
		  ,A.[support_total_amount]
		  ,A.[date_amount_due]
		  ,A.[date_stay_ordered]
		  ,A.[bankruptcy_case_number]
		  ,A.[bankruptcy_chapter]
		  ,A.[bankruptcy_type]
		  ,A.[bankruptcy_location]
		  ,A.[case_filed_in_county]
		  ,A.[case_court_type]
		  ,A.[case_original_number]
		  ,A.[case_original_court_type]
		  ,A.[case_status]
		  ,A.[date_bankruptcy_closed]
		  ,A.[date_bankruptcy_case_filed]
		  ,A.[date_bankruptcy_conversion]
		  ,A.[date_bankruptcy_discharged]
		  ,A.[date_bankruptcy_dismissed]
		  ,A.[date_bankruptcy_341_meeting]
		  ,A.[bankruptcy_341_meeting_time]
		  ,A.[requested_prepared_by_attorney_name_identifier]
		  ,A.[requested_prepared_by_attorney_last_company_name]
		  ,A.[requested_prepared_by_attorney_first_name]
		  ,A.[requested_prepared_by_attorney_middle_initial]
		  ,A.[requested_prepared_by_attorney_suffix]
		  ,A.[requested_prepared_by_attorney_address]
		  ,A.[requested_prepared_by_attorney_address_city]
		  ,A.[requested_prepared_by_attorney_address_state]
		  ,A.[requested_prepared_by_attorney_address_zip]
		  ,A.[requested_prepared_by_attorney_phone]
		  ,A.[Party1_Name1_FullName]
		  ,A.[Party1_Name1_last_Company_Name]
		  ,A.[Party1_Name1_First_Name]
		  ,A.[Party1_Name1_Middle_Name]
		  ,A.[Party1_Name1_Suffix]
		  ,A.[Party1_Name1_Roll_Type]
		  ,A.[Party1_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name1_Account_Nbr]
		  ,A.[Party1_Name1_SSN_Nbr]
		  ,A.[Party1_Name1_MailPropertyID]
		  ,A.[Party1_Name1_Address]
		  ,A.[Party1_Name1_PreDir]
		  ,A.[Party1_Name1_StreetNumber]
		  ,A.[Party1_Name1_StreetName]
		  ,A.[Party1_Name1_PostDir]
		  ,A.[Party1_Name1_StreetType]
		  ,A.[Party1_Name1_SuiteType]
		  ,A.[Party1_Name1_Suite]
		  ,A.[Party1_Name1_City]
		  ,A.[Party1_Name1_State]
		  ,A.[Party1_Name1_Zip]
		  ,A.[Party1_Name1_ZipPlus4]
		  ,A.[Party1_Name2_FullName]
		  ,A.[Party1_Name2_last_Company_Name]
		  ,A.[Party1_Name2_First_Name]
		  ,A.[Party1_Name2_Middle_Name]
		  ,A.[Party1_Name2_Suffix]
		  ,A.[Party1_Name2_Roll_Type]
		  ,A.[Party1_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name2_Account_Nbr]
		  ,A.[Party1_Name2_SSN_Nbr]
		  ,A.[Party1_Name2_MailPropertyID]
		  ,A.[Party1_Name2_Address]
		  ,A.[Party1_Name2_PreDir]
		  ,A.[Party1_Name2_StreetNumber]
		  ,A.[Party1_Name2_StreetName]
		  ,A.[Party1_Name2_PostDir]
		  ,A.[Party1_Name2_StreetType]
		  ,A.[Party1_Name2_SuiteType]
		  ,A.[Party1_Name2_Suite]
		  ,A.[Party1_Name2_City]
		  ,A.[Party1_Name2_State]
		  ,A.[Party1_Name2_Zip]
		  ,A.[Party1_Name2_ZipPlus4]
		  ,A.[Party1_Name3_FullName]
		  ,A.[Party1_Name3_last_Company_Name]
		  ,A.[Party1_Name3_First_Name]
		  ,A.[Party1_Name3_Middle_Name]
		  ,A.[Party1_Name3_Suffix]
		  ,A.[Party1_Name3_Roll_Type]
		  ,A.[Party1_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name3_Account_Nbr]
		  ,A.[Party1_Name3_SSN_Nbr]
		  ,A.[Party1_Name3_MailPropertyID]
		  ,A.[Party1_Name3_Address]
		  ,A.[Party1_Name3_PreDir]
		  ,A.[Party1_Name3_StreetNumber]
		  ,A.[Party1_Name3_StreetName]
		  ,A.[Party1_Name3_PostDir]
		  ,A.[Party1_Name3_StreetType]
		  ,A.[Party1_Name3_SuiteType]
		  ,A.[Party1_Name3_Suite]
		  ,A.[Party1_Name3_City]
		  ,A.[Party1_Name3_State]
		  ,A.[Party1_Name3_Zip]
		  ,A.[Party1_Name3_ZipPlus4]
		  ,A.[Party1_Name4_FullName]
		  ,A.[Party1_Name4_last_Company_Name]
		  ,A.[Party1_Name4_First_Name]
		  ,A.[Party1_Name4_Middle_Name]
		  ,A.[Party1_Name4_Suffix]
		  ,A.[Party1_Name4_Roll_Type]
		  ,A.[Party1_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name4_Account_Nbr]
		  ,A.[Party1_Name4_SSN_Nbr]
		  ,A.[Party1_Name4_MailPropertyID]
		  ,A.[Party1_Name4_Address]
		  ,A.[Party1_Name4_PreDir]
		  ,A.[Party1_Name4_StreetNumber]
		  ,A.[Party1_Name4_StreetName]
		  ,A.[Party1_Name4_PostDir]
		  ,A.[Party1_Name4_StreetType]
		  ,A.[Party1_Name4_SuiteType]
		  ,A.[Party1_Name4_Suite]
		  ,A.[Party1_Name4_City]
		  ,A.[Party1_Name4_State]
		  ,A.[Party1_Name4_Zip]
		  ,A.[Party1_Name4_ZipPlus4]
		  ,A.[Party2_Name1_FullName]
		  ,A.[Party2_Name1_last_Company_Name]
		  ,A.[Party2_Name1_First_Name]
		  ,A.[Party2_Name1_Middle_Name]
		  ,A.[Party2_Name1_Suffix]
		  ,A.[Party2_Name1_Roll_Type]
		  ,A.[Party2_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name1_Account_Nbr]
		  ,A.[Party2_Name1_SSN_Nbr]
		  ,A.[Party2_Name1_MailPropertyID]
		  ,A.[Party2_Name1_Address]
		  ,A.[Party2_Name1_PreDir]
		  ,A.[Party2_Name1_StreetNumber]
		  ,A.[Party2_Name1_StreetName]
		  ,A.[Party2_Name1_PostDir]
		  ,A.[Party2_Name1_StreetType]
		  ,A.[Party2_Name1_SuiteType]
		  ,A.[Party2_Name1_Suite]
		  ,A.[Party2_Name1_City]
		  ,A.[Party2_Name1_State]
		  ,A.[Party2_Name1_Zip]
		  ,A.[Party2_Name1_ZipPlus4]
		  ,A.[Party2_Name2_FullName]
		  ,A.[Party2_Name2_last_Company_Name]
		  ,A.[Party2_Name2_First_Name]
		  ,A.[Party2_Name2_Middle_Name]
		  ,A.[Party2_Name2_Suffix]
		  ,A.[Party2_Name2_Roll_Type]
		  ,A.[Party2_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name2_Account_Nbr]
		  ,A.[Party2_Name2_SSN_Nbr]
		  ,A.[Party2_Name2_MailPropertyID]
		  ,A.[Party2_Name2_Address]
		  ,A.[Party2_Name2_PreDir]
		  ,A.[Party2_Name2_StreetNumber]
		  ,A.[Party2_Name2_StreetName]
		  ,A.[Party2_Name2_PostDir]
		  ,A.[Party2_Name2_StreetType]
		  ,A.[Party2_Name2_SuiteType]
		  ,A.[Party2_Name2_Suite]
		  ,A.[Party2_Name2_City]
		  ,A.[Party2_Name2_State]
		  ,A.[Party2_Name2_Zip]
		  ,A.[Party2_Name2_ZipPlus4]
		  ,A.[Party2_Name3_FullName]
		  ,A.[Party2_Name3_last_Company_Name]
		  ,A.[Party2_Name3_First_Name]
		  ,A.[Party2_Name3_Middle_Name]
		  ,A.[Party2_Name3_Suffix]
		  ,A.[Party2_Name3_Roll_Type]
		  ,A.[Party2_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name3_Account_Nbr]
		  ,A.[Party2_Name3_SSN_Nbr]
		  ,A.[Party2_Name3_MailPropertyID]
		  ,A.[Party2_Name3_Address]
		  ,A.[Party2_Name3_PreDir]
		  ,A.[Party2_Name3_StreetNumber]
		  ,A.[Party2_Name3_StreetName]
		  ,A.[Party2_Name3_PostDir]
		  ,A.[Party2_Name3_StreetType]
		  ,A.[Party2_Name3_SuiteType]
		  ,A.[Party2_Name3_Suite]
		  ,A.[Party2_Name3_City]
		  ,A.[Party2_Name3_State]
		  ,A.[Party2_Name3_Zip]
		  ,A.[Party2_Name3_ZipPlus4]
		  ,A.[Party2_Name4_FullName]
		  ,A.[Party2_Name4_last_Company_Name]
		  ,A.[Party2_Name4_First_Name]
		  ,A.[Party2_Name4_Middle_Name]
		  ,A.[Party2_Name4_Suffix]
		  ,A.[Party2_Name4_Roll_Type]
		  ,A.[Party2_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name4_Account_Nbr]
		  ,A.[Party2_Name4_SSN_Nbr]
		  ,A.[Party2_Name4_MailPropertyID]
		  ,A.[Party2_Name4_Address]
		  ,A.[Party2_Name4_PreDir]
		  ,A.[Party2_Name4_StreetNumber]
		  ,A.[Party2_Name4_StreetName]
		  ,A.[Party2_Name4_PostDir]
		  ,A.[Party2_Name4_StreetType]
		  ,A.[Party2_Name4_SuiteType]
		  ,A.[Party2_Name4_Suite]
		  ,A.[Party2_Name4_City]
		  ,A.[Party2_Name4_State]
		  ,A.[Party2_Name4_Zip]
		  ,A.[Party2_Name4_ZipPlus4]
		  ,A.[Party3_Name1_FullName]
		  ,A.[Party3_Name1_last_Company_Name]
		  ,A.[Party3_Name1_First_Name]
		  ,A.[Party3_Name1_Middle_Name]
		  ,A.[Party3_Name1_Suffix]
		  ,A.[Party3_Name1_Roll_Type]
		  ,A.[Party3_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name1_Account_Nbr]
		  ,A.[Party3_Name1_SSN_Nbr]
		  ,A.[Party3_Name1_MailPropertyID]
		  ,A.[Party3_Name1_Address]
		  ,A.[Party3_Name1_PreDir]
		  ,A.[Party3_Name1_StreetNumber]
		  ,A.[Party3_Name1_StreetName]
		  ,A.[Party3_Name1_PostDir]
		  ,A.[Party3_Name1_StreetType]
		  ,A.[Party3_Name1_SuiteType]
		  ,A.[Party3_Name1_Suite]
		  ,A.[Party3_Name1_City]
		  ,A.[Party3_Name1_State]
		  ,A.[Party3_Name1_Zip]
		  ,A.[Party3_Name1_ZipPlus4]
		  ,A.[Party3_Name2_FullName]
		  ,A.[Party3_Name2_last_Company_Name]
		  ,A.[Party3_Name2_First_Name]
		  ,A.[Party3_Name2_Middle_Name]
		  ,A.[Party3_Name2_Suffix]
		  ,A.[Party3_Name2_Roll_Type]
		  ,A.[Party3_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name2_Account_Nbr]
		  ,A.[Party3_Name2_SSN_Nbr]
		  ,A.[Party3_Name2_MailPropertyID]
		  ,A.[Party3_Name2_Address]
		  ,A.[Party3_Name2_PreDir]
		  ,A.[Party3_Name2_StreetNumber]
		  ,A.[Party3_Name2_StreetName]
		  ,A.[Party3_Name2_PostDir]
		  ,A.[Party3_Name2_StreetType]
		  ,A.[Party3_Name2_SuiteType]
		  ,A.[Party3_Name2_Suite]
		  ,A.[Party3_Name2_City]
		  ,A.[Party3_Name2_State]
		  ,A.[Party3_Name2_Zip]
		  ,A.[Party3_Name2_ZipPlus4]
		  ,A.[Party3_Name3_FullName]
		  ,A.[Party3_Name3_last_Company_Name]
		  ,A.[Party3_Name3_First_Name]
		  ,A.[Party3_Name3_Middle_Name]
		  ,A.[Party3_Name3_Suffix]
		  ,A.[Party3_Name3_Roll_Type]
		  ,A.[Party3_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name3_Account_Nbr]
		  ,A.[Party3_Name3_SSN_Nbr]
		  ,A.[Party3_Name3_MailPropertyID]
		  ,A.[Party3_Name3_Address]
		  ,A.[Party3_Name3_PreDir]
		  ,A.[Party3_Name3_StreetNumber]
		  ,A.[Party3_Name3_StreetName]
		  ,A.[Party3_Name3_PostDir]
		  ,A.[Party3_Name3_StreetType]
		  ,A.[Party3_Name3_SuiteType]
		  ,A.[Party3_Name3_Suite]
		  ,A.[Party3_Name3_City]
		  ,A.[Party3_Name3_State]
		  ,A.[Party3_Name3_Zip]
		  ,A.[Party3_Name3_ZipPlus4]
		  ,A.[Party3_Name4_FullName]
		  ,A.[Party3_Name4_last_Company_Name]
		  ,A.[Party3_Name4_First_Name]
		  ,A.[Party3_Name4_Middle_Name]
		  ,A.[Party3_Name4_Suffix]
		  ,A.[Party3_Name4_Roll_Type]
		  ,A.[Party3_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name4_Account_Nbr]
		  ,A.[Party3_Name4_SSN_Nbr]
		  ,A.[Party3_Name4_MailPropertyID]
		  ,A.[Party3_Name4_Address]
		  ,A.[Party3_Name4_PreDir]
		  ,A.[Party3_Name4_StreetNumber]
		  ,A.[Party3_Name4_StreetName]
		  ,A.[Party3_Name4_PostDir]
		  ,A.[Party3_Name4_StreetType]
		  ,A.[Party3_Name4_SuiteType]
		  ,A.[Party3_Name4_Suite]
		  ,A.[Party3_Name4_City]
		  ,A.[Party3_Name4_State]
		  ,A.[Party3_Name4_Zip]
		  ,A.[Party3_Name4_ZipPlus4]
		  ,A.[Party4_Name1_FullName]
		  ,A.[Party4_Name1_last_Company_Name]
		  ,A.[Party4_Name1_First_Name]
		  ,A.[Party4_Name1_Middle_Name]
		  ,A.[Party4_Name1_Suffix]
		  ,A.[Party4_Name1_Roll_Type]
		  ,A.[Party4_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name1_Account_Nbr]
		  ,A.[Party4_Name1_SSN_Nbr]
		  ,A.[Party4_Name1_MailPropertyID]
		  ,A.[Party4_Name1_Address]
		  ,A.[Party4_Name1_PreDir]
		  ,A.[Party4_Name1_StreetNumber]
		  ,A.[Party4_Name1_StreetName]
		  ,A.[Party4_Name1_PostDir]
		  ,A.[Party4_Name1_StreetType]
		  ,A.[Party4_Name1_SuiteType]
		  ,A.[Party4_Name1_Suite]
		  ,A.[Party4_Name1_City]
		  ,A.[Party4_Name1_State]
		  ,A.[Party4_Name1_Zip]
		  ,A.[Party4_Name1_ZipPlus4]
		  ,A.[Party4_Name2_FullName]
		  ,A.[Party4_Name2_last_Company_Name]
		  ,A.[Party4_Name2_First_Name]
		  ,A.[Party4_Name2_Middle_Name]
		  ,A.[Party4_Name2_Suffix]
		  ,A.[Party4_Name2_Roll_Type]
		  ,A.[Party4_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name2_Account_Nbr]
		  ,A.[Party4_Name2_SSN_Nbr]
		  ,A.[Party4_Name2_MailPropertyID]
		  ,A.[Party4_Name2_Address]
		  ,A.[Party4_Name2_PreDir]
		  ,A.[Party4_Name2_StreetNumber]
		  ,A.[Party4_Name2_StreetName]
		  ,A.[Party4_Name2_PostDir]
		  ,A.[Party4_Name2_StreetType]
		  ,A.[Party4_Name2_SuiteType]
		  ,A.[Party4_Name2_Suite]
		  ,A.[Party4_Name2_City]
		  ,A.[Party4_Name2_State]
		  ,A.[Party4_Name2_Zip]
		  ,A.[Party4_Name2_ZipPlus4]
		  ,A.[Party4_Name3_FullName]
		  ,A.[Party4_Name3_last_Company_Name]
		  ,A.[Party4_Name3_First_Name]
		  ,A.[Party4_Name3_Middle_Name]
		  ,A.[Party4_Name3_Suffix]
		  ,A.[Party4_Name3_Roll_Type]
		  ,A.[Party4_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name3_Account_Nbr]
		  ,A.[Party4_Name3_SSN_Nbr]
		  ,A.[Party4_Name3_MailPropertyID]
		  ,A.[Party4_Name3_Address]
		  ,A.[Party4_Name3_PreDir]
		  ,A.[Party4_Name3_StreetNumber]
		  ,A.[Party4_Name3_StreetName]
		  ,A.[Party4_Name3_PostDir]
		  ,A.[Party4_Name3_StreetType]
		  ,A.[Party4_Name3_SuiteType]
		  ,A.[Party4_Name3_Suite]
		  ,A.[Party4_Name3_City]
		  ,A.[Party4_Name3_State]
		  ,A.[Party4_Name3_Zip]
		  ,A.[Party4_Name3_ZipPlus4]
		  ,A.[Party4_Name4_FullName]
		  ,A.[Party4_Name4_last_Company_Name]
		  ,A.[Party4_Name4_First_Name]
		  ,A.[Party4_Name4_Middle_Name]
		  ,A.[Party4_Name4_Suffix]
		  ,A.[Party4_Name4_Roll_Type]
		  ,A.[Party4_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name4_Account_Nbr]
		  ,A.[Party4_Name4_SSN_Nbr]
		  ,A.[Party4_Name4_MailPropertyID]
		  ,A.[Party4_Name4_Address]
		  ,A.[Party4_Name4_PreDir]
		  ,A.[Party4_Name4_StreetNumber]
		  ,A.[Party4_Name4_StreetName]
		  ,A.[Party4_Name4_PostDir]
		  ,A.[Party4_Name4_StreetType]
		  ,A.[Party4_Name4_SuiteType]
		  ,A.[Party4_Name4_Suite]
		  ,A.[Party4_Name4_City]
		  ,A.[Party4_Name4_State]
		  ,A.[Party4_Name4_Zip]
		  ,A.[Party4_Name4_ZipPlus4]
		  ,A.[PropertyID]
		  ,A.[AddressLine]
		  ,A.[PreDir]
		  ,A.[StreetNumber]
		  ,A.[StreetName]
		  ,A.[PostDir]
		  ,A.[StreetType]
		  ,A.[SuiteType]
		  ,A.[Suite]
		  ,A.[City]
		  ,A.[PropState]
		  ,A.[Zip]
		  ,A.[Plus4]
		  ,A.[property_id_sequence_number]
		  ,A.[legal_desc_apn_portion]
		  ,A.[legal_desc_apn]
		  ,A.[legal_desc_apn_arb]
		  ,A.[legal_desc_map_portion]
		  ,A.[legal_desc_map_unit_low]
		  ,A.[legal_desc_map_unit_high]
		  ,A.[legal_desc_map_lot_type]
		  ,A.[legal_desc_map_lot_type_low]
		  ,A.[legal_desc_map_lot_type_high]
		  ,A.[legal_desc_map_lot_low]
		  ,A.[legal_desc_map_lot_high]
		  ,A.[legal_desc_map_block]
		  ,A.[legal_desc_map_building]
		  ,A.[legal_desc_map_sublot]
		  ,A.[legal_desc_map_plat_subcode]
		  ,A.[legal_desc_map_plat_name]
		  ,A.[legal_desc_map_plat_number]
		  ,A.[legal_desc_map_plat_condo_id]
		  ,A.[legal_desc_map_plat_type_indicator]
		  ,A.[legal_desc_map_plat_book]
		  ,A.[legal_desc_map_plat_page]
		  ,A.[legal_desc_str_portion]
		  ,A.[legal_desc_str_government_lot]
		  ,A.[legal_desc_str_quarter]
		  ,A.[legal_desc_str_section]
		  ,A.[legal_desc_str_township]
		  ,A.[legal_desc_str_range]
		  ,A.[legal_desc_tct]
		  ,A.[legal_desc_district]
		  ,A.[legal_desc_municipality]
		  ,A.[legal_desc_swiss_code]
		  ,A.[legal_desc_easement_flag]
		  ,A.[legal_desc_easement_type]
		  ,A.[legal_type]
		  ,A.[legal_type_sequence]
		  ,A.[property_sequence]
		  ,A.[legal_desc_qualifier]
		  ,A.[legal_desc_map_city_block]
		  ,A.[legal_desc_application_number]
		  ,A.[legal_desc_tax_assessor_portion]
		  ,A.[legal_desc_tax_assessor_lot]
		  ,A.[legal_desc_tax_assessor_block]
		  ,A.[legal_desc_tax_assessor_section]
		  ,A.[FATimeStamp]
		  ,A.[FARecordType]
		  ,A.[FormattedAPN]
		  ,A.[InActiveFlag]
		  ,A.[StdLandUseCode]
		  ,A.[cmt_docnumber]
		  ,A.[cmt_id]
		  ,A.[PropertyClassID]
		  ,A.[OwnerStd1CorpInd]
		  ,A.[REFERENCE_id]
		  ,A.[Reference_recording_year]
		  ,A.[reference_recording_date]
		  ,A.[reference_doc_number]
		  ,A.[reference_book]
		  ,A.[reference_page]
		  ,A.[Fmt_Reference_Doc_Number]
		  ,A.[Fmt_Reference_BookPAge]
			From [data].[dbo].[v_Invl] as A with(NOLOCK)
			join [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] as B with(NOLOCK) on A.Party1_Name1_MailPropertyID = B.PropertyID
			where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
			AND (A.InActiveFlag IS NULL)
			and A.FARecordType not like 'D'
			and convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,INPUTSTARTDATE)
			AND (convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,[MAX_INVL_RECDATE])
			OR [MAX_INVL_RECDATE] is null)

			

	INSERT INTO [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
	SELECT NULL AS ROWNUM, B.[Input UniqueID] AS [INPUT KEY], A.[TransactionID]
		  ,A.[Fips]
		  ,A.[State]
		  ,A.[County]
		  ,A.[DocumentYear]
		  ,A.[Recordingdt]
		  ,A.[DocumentDt]
		  ,A.[doc_filing_date]
		  ,A.[DocNbrSrce]
		  ,A.[BookSrce]
		  ,A.[PaceSrce]
		  ,A.[Doc_Category]
		  ,A.[DocTypeID]
		  ,A.[DocType]
		  ,A.[DocumentTitle]
		  ,A.[case_number]
		  ,A.[case_book]
		  ,A.[case_page]
		  ,A.[date_of_death]
		  ,A.[account_number]
		  ,A.[amendment_number]
		  ,A.[attorney_bar_number]
		  ,A.[bond_number]
		  ,A.[lot_line_adjustment_number]
		  ,A.[certificate_number]
		  ,A.[claim_number]
		  ,A.[contract_number]
		  ,A.[corporation_number]
		  ,A.[excise_tax_number]
		  ,A.[federal_tax_lien_area]
		  ,A.[federal_tax_lien_area_phone]
		  ,A.[tax_last_day_for_refiling]
		  ,A.[tax_period_begin_date]
		  ,A.[tax_period_end_date]
		  ,A.[tax_amount]
		  ,A.[tax_interest_amount]
		  ,A.[tax_penalty_amount]
		  ,A.[judgment_amount]
		  ,A.[judgment_grand_total]
		  ,A.[judgment_court_fees]
		  ,A.[judgment_attorney_fees]
		  ,A.[judgment_principal_fees]
		  ,A.[judgment_interest_fees]
		  ,A.[judgment_filing_fees]
		  ,A.[judgment_per_diem_fees]
		  ,A.[judgment_late_fees]
		  ,A.[judgment_tax_fees]
		  ,A.[judgment_insurance_fees]
		  ,A.[judgment_other_fees]
		  ,A.[installment_judgment]
		  ,A.[license_number]
		  ,A.[lien_number]
		  ,A.[map_plat_id]
		  ,A.[mechanics_lien_number]
		  ,A.[ordinance_number]
		  ,A.[patent_number]
		  ,A.[permit_number]
		  ,A.[resolution_number]
		  ,A.[tax_account_serial_warrant_number]
		  ,A.[tax_type]
		  ,A.[trustees_sale_number]
		  ,A.[ucc_number]
		  ,A.[undersigned_same_as_borrower]
		  ,A.[amount_due]
		  ,A.[amount_of_default]
		  ,A.[bond_amount]
		  ,A.[cash_down_amount]
		  ,A.[contract_amount]
		  ,A.[collection_costs]
		  ,A.[unpaid_balance]
		  ,A.[unpaid_balance_as_of_modification_date]
		  ,A.[unpaid_prinicipal_amount]
		  ,A.[date_of_divorce]
		  ,A.[support_arrears_amount]
		  ,A.[support_payment_amount]
		  ,A.[support_total_amount]
		  ,A.[date_amount_due]
		  ,A.[date_stay_ordered]
		  ,A.[bankruptcy_case_number]
		  ,A.[bankruptcy_chapter]
		  ,A.[bankruptcy_type]
		  ,A.[bankruptcy_location]
		  ,A.[case_filed_in_county]
		  ,A.[case_court_type]
		  ,A.[case_original_number]
		  ,A.[case_original_court_type]
		  ,A.[case_status]
		  ,A.[date_bankruptcy_closed]
		  ,A.[date_bankruptcy_case_filed]
		  ,A.[date_bankruptcy_conversion]
		  ,A.[date_bankruptcy_discharged]
		  ,A.[date_bankruptcy_dismissed]
		  ,A.[date_bankruptcy_341_meeting]
		  ,A.[bankruptcy_341_meeting_time]
		  ,A.[requested_prepared_by_attorney_name_identifier]
		  ,A.[requested_prepared_by_attorney_last_company_name]
		  ,A.[requested_prepared_by_attorney_first_name]
		  ,A.[requested_prepared_by_attorney_middle_initial]
		  ,A.[requested_prepared_by_attorney_suffix]
		  ,A.[requested_prepared_by_attorney_address]
		  ,A.[requested_prepared_by_attorney_address_city]
		  ,A.[requested_prepared_by_attorney_address_state]
		  ,A.[requested_prepared_by_attorney_address_zip]
		  ,A.[requested_prepared_by_attorney_phone]
		  ,A.[Party1_Name1_FullName]
		  ,A.[Party1_Name1_last_Company_Name]
		  ,A.[Party1_Name1_First_Name]
		  ,A.[Party1_Name1_Middle_Name]
		  ,A.[Party1_Name1_Suffix]
		  ,A.[Party1_Name1_Roll_Type]
		  ,A.[Party1_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name1_Account_Nbr]
		  ,A.[Party1_Name1_SSN_Nbr]
		  ,A.[Party1_Name1_MailPropertyID]
		  ,A.[Party1_Name1_Address]
		  ,A.[Party1_Name1_PreDir]
		  ,A.[Party1_Name1_StreetNumber]
		  ,A.[Party1_Name1_StreetName]
		  ,A.[Party1_Name1_PostDir]
		  ,A.[Party1_Name1_StreetType]
		  ,A.[Party1_Name1_SuiteType]
		  ,A.[Party1_Name1_Suite]
		  ,A.[Party1_Name1_City]
		  ,A.[Party1_Name1_State]
		  ,A.[Party1_Name1_Zip]
		  ,A.[Party1_Name1_ZipPlus4]
		  ,A.[Party1_Name2_FullName]
		  ,A.[Party1_Name2_last_Company_Name]
		  ,A.[Party1_Name2_First_Name]
		  ,A.[Party1_Name2_Middle_Name]
		  ,A.[Party1_Name2_Suffix]
		  ,A.[Party1_Name2_Roll_Type]
		  ,A.[Party1_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name2_Account_Nbr]
		  ,A.[Party1_Name2_SSN_Nbr]
		  ,A.[Party1_Name2_MailPropertyID]
		  ,A.[Party1_Name2_Address]
		  ,A.[Party1_Name2_PreDir]
		  ,A.[Party1_Name2_StreetNumber]
		  ,A.[Party1_Name2_StreetName]
		  ,A.[Party1_Name2_PostDir]
		  ,A.[Party1_Name2_StreetType]
		  ,A.[Party1_Name2_SuiteType]
		  ,A.[Party1_Name2_Suite]
		  ,A.[Party1_Name2_City]
		  ,A.[Party1_Name2_State]
		  ,A.[Party1_Name2_Zip]
		  ,A.[Party1_Name2_ZipPlus4]
		  ,A.[Party1_Name3_FullName]
		  ,A.[Party1_Name3_last_Company_Name]
		  ,A.[Party1_Name3_First_Name]
		  ,A.[Party1_Name3_Middle_Name]
		  ,A.[Party1_Name3_Suffix]
		  ,A.[Party1_Name3_Roll_Type]
		  ,A.[Party1_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name3_Account_Nbr]
		  ,A.[Party1_Name3_SSN_Nbr]
		  ,A.[Party1_Name3_MailPropertyID]
		  ,A.[Party1_Name3_Address]
		  ,A.[Party1_Name3_PreDir]
		  ,A.[Party1_Name3_StreetNumber]
		  ,A.[Party1_Name3_StreetName]
		  ,A.[Party1_Name3_PostDir]
		  ,A.[Party1_Name3_StreetType]
		  ,A.[Party1_Name3_SuiteType]
		  ,A.[Party1_Name3_Suite]
		  ,A.[Party1_Name3_City]
		  ,A.[Party1_Name3_State]
		  ,A.[Party1_Name3_Zip]
		  ,A.[Party1_Name3_ZipPlus4]
		  ,A.[Party1_Name4_FullName]
		  ,A.[Party1_Name4_last_Company_Name]
		  ,A.[Party1_Name4_First_Name]
		  ,A.[Party1_Name4_Middle_Name]
		  ,A.[Party1_Name4_Suffix]
		  ,A.[Party1_Name4_Roll_Type]
		  ,A.[Party1_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party1_Name4_Account_Nbr]
		  ,A.[Party1_Name4_SSN_Nbr]
		  ,A.[Party1_Name4_MailPropertyID]
		  ,A.[Party1_Name4_Address]
		  ,A.[Party1_Name4_PreDir]
		  ,A.[Party1_Name4_StreetNumber]
		  ,A.[Party1_Name4_StreetName]
		  ,A.[Party1_Name4_PostDir]
		  ,A.[Party1_Name4_StreetType]
		  ,A.[Party1_Name4_SuiteType]
		  ,A.[Party1_Name4_Suite]
		  ,A.[Party1_Name4_City]
		  ,A.[Party1_Name4_State]
		  ,A.[Party1_Name4_Zip]
		  ,A.[Party1_Name4_ZipPlus4]
		  ,A.[Party2_Name1_FullName]
		  ,A.[Party2_Name1_last_Company_Name]
		  ,A.[Party2_Name1_First_Name]
		  ,A.[Party2_Name1_Middle_Name]
		  ,A.[Party2_Name1_Suffix]
		  ,A.[Party2_Name1_Roll_Type]
		  ,A.[Party2_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name1_Account_Nbr]
		  ,A.[Party2_Name1_SSN_Nbr]
		  ,A.[Party2_Name1_MailPropertyID]
		  ,A.[Party2_Name1_Address]
		  ,A.[Party2_Name1_PreDir]
		  ,A.[Party2_Name1_StreetNumber]
		  ,A.[Party2_Name1_StreetName]
		  ,A.[Party2_Name1_PostDir]
		  ,A.[Party2_Name1_StreetType]
		  ,A.[Party2_Name1_SuiteType]
		  ,A.[Party2_Name1_Suite]
		  ,A.[Party2_Name1_City]
		  ,A.[Party2_Name1_State]
		  ,A.[Party2_Name1_Zip]
		  ,A.[Party2_Name1_ZipPlus4]
		  ,A.[Party2_Name2_FullName]
		  ,A.[Party2_Name2_last_Company_Name]
		  ,A.[Party2_Name2_First_Name]
		  ,A.[Party2_Name2_Middle_Name]
		  ,A.[Party2_Name2_Suffix]
		  ,A.[Party2_Name2_Roll_Type]
		  ,A.[Party2_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name2_Account_Nbr]
		  ,A.[Party2_Name2_SSN_Nbr]
		  ,A.[Party2_Name2_MailPropertyID]
		  ,A.[Party2_Name2_Address]
		  ,A.[Party2_Name2_PreDir]
		  ,A.[Party2_Name2_StreetNumber]
		  ,A.[Party2_Name2_StreetName]
		  ,A.[Party2_Name2_PostDir]
		  ,A.[Party2_Name2_StreetType]
		  ,A.[Party2_Name2_SuiteType]
		  ,A.[Party2_Name2_Suite]
		  ,A.[Party2_Name2_City]
		  ,A.[Party2_Name2_State]
		  ,A.[Party2_Name2_Zip]
		  ,A.[Party2_Name2_ZipPlus4]
		  ,A.[Party2_Name3_FullName]
		  ,A.[Party2_Name3_last_Company_Name]
		  ,A.[Party2_Name3_First_Name]
		  ,A.[Party2_Name3_Middle_Name]
		  ,A.[Party2_Name3_Suffix]
		  ,A.[Party2_Name3_Roll_Type]
		  ,A.[Party2_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name3_Account_Nbr]
		  ,A.[Party2_Name3_SSN_Nbr]
		  ,A.[Party2_Name3_MailPropertyID]
		  ,A.[Party2_Name3_Address]
		  ,A.[Party2_Name3_PreDir]
		  ,A.[Party2_Name3_StreetNumber]
		  ,A.[Party2_Name3_StreetName]
		  ,A.[Party2_Name3_PostDir]
		  ,A.[Party2_Name3_StreetType]
		  ,A.[Party2_Name3_SuiteType]
		  ,A.[Party2_Name3_Suite]
		  ,A.[Party2_Name3_City]
		  ,A.[Party2_Name3_State]
		  ,A.[Party2_Name3_Zip]
		  ,A.[Party2_Name3_ZipPlus4]
		  ,A.[Party2_Name4_FullName]
		  ,A.[Party2_Name4_last_Company_Name]
		  ,A.[Party2_Name4_First_Name]
		  ,A.[Party2_Name4_Middle_Name]
		  ,A.[Party2_Name4_Suffix]
		  ,A.[Party2_Name4_Roll_Type]
		  ,A.[Party2_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party2_Name4_Account_Nbr]
		  ,A.[Party2_Name4_SSN_Nbr]
		  ,A.[Party2_Name4_MailPropertyID]
		  ,A.[Party2_Name4_Address]
		  ,A.[Party2_Name4_PreDir]
		  ,A.[Party2_Name4_StreetNumber]
		  ,A.[Party2_Name4_StreetName]
		  ,A.[Party2_Name4_PostDir]
		  ,A.[Party2_Name4_StreetType]
		  ,A.[Party2_Name4_SuiteType]
		  ,A.[Party2_Name4_Suite]
		  ,A.[Party2_Name4_City]
		  ,A.[Party2_Name4_State]
		  ,A.[Party2_Name4_Zip]
		  ,A.[Party2_Name4_ZipPlus4]
		  ,A.[Party3_Name1_FullName]
		  ,A.[Party3_Name1_last_Company_Name]
		  ,A.[Party3_Name1_First_Name]
		  ,A.[Party3_Name1_Middle_Name]
		  ,A.[Party3_Name1_Suffix]
		  ,A.[Party3_Name1_Roll_Type]
		  ,A.[Party3_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name1_Account_Nbr]
		  ,A.[Party3_Name1_SSN_Nbr]
		  ,A.[Party3_Name1_MailPropertyID]
		  ,A.[Party3_Name1_Address]
		  ,A.[Party3_Name1_PreDir]
		  ,A.[Party3_Name1_StreetNumber]
		  ,A.[Party3_Name1_StreetName]
		  ,A.[Party3_Name1_PostDir]
		  ,A.[Party3_Name1_StreetType]
		  ,A.[Party3_Name1_SuiteType]
		  ,A.[Party3_Name1_Suite]
		  ,A.[Party3_Name1_City]
		  ,A.[Party3_Name1_State]
		  ,A.[Party3_Name1_Zip]
		  ,A.[Party3_Name1_ZipPlus4]
		  ,A.[Party3_Name2_FullName]
		  ,A.[Party3_Name2_last_Company_Name]
		  ,A.[Party3_Name2_First_Name]
		  ,A.[Party3_Name2_Middle_Name]
		  ,A.[Party3_Name2_Suffix]
		  ,A.[Party3_Name2_Roll_Type]
		  ,A.[Party3_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name2_Account_Nbr]
		  ,A.[Party3_Name2_SSN_Nbr]
		  ,A.[Party3_Name2_MailPropertyID]
		  ,A.[Party3_Name2_Address]
		  ,A.[Party3_Name2_PreDir]
		  ,A.[Party3_Name2_StreetNumber]
		  ,A.[Party3_Name2_StreetName]
		  ,A.[Party3_Name2_PostDir]
		  ,A.[Party3_Name2_StreetType]
		  ,A.[Party3_Name2_SuiteType]
		  ,A.[Party3_Name2_Suite]
		  ,A.[Party3_Name2_City]
		  ,A.[Party3_Name2_State]
		  ,A.[Party3_Name2_Zip]
		  ,A.[Party3_Name2_ZipPlus4]
		  ,A.[Party3_Name3_FullName]
		  ,A.[Party3_Name3_last_Company_Name]
		  ,A.[Party3_Name3_First_Name]
		  ,A.[Party3_Name3_Middle_Name]
		  ,A.[Party3_Name3_Suffix]
		  ,A.[Party3_Name3_Roll_Type]
		  ,A.[Party3_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name3_Account_Nbr]
		  ,A.[Party3_Name3_SSN_Nbr]
		  ,A.[Party3_Name3_MailPropertyID]
		  ,A.[Party3_Name3_Address]
		  ,A.[Party3_Name3_PreDir]
		  ,A.[Party3_Name3_StreetNumber]
		  ,A.[Party3_Name3_StreetName]
		  ,A.[Party3_Name3_PostDir]
		  ,A.[Party3_Name3_StreetType]
		  ,A.[Party3_Name3_SuiteType]
		  ,A.[Party3_Name3_Suite]
		  ,A.[Party3_Name3_City]
		  ,A.[Party3_Name3_State]
		  ,A.[Party3_Name3_Zip]
		  ,A.[Party3_Name3_ZipPlus4]
		  ,A.[Party3_Name4_FullName]
		  ,A.[Party3_Name4_last_Company_Name]
		  ,A.[Party3_Name4_First_Name]
		  ,A.[Party3_Name4_Middle_Name]
		  ,A.[Party3_Name4_Suffix]
		  ,A.[Party3_Name4_Roll_Type]
		  ,A.[Party3_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party3_Name4_Account_Nbr]
		  ,A.[Party3_Name4_SSN_Nbr]
		  ,A.[Party3_Name4_MailPropertyID]
		  ,A.[Party3_Name4_Address]
		  ,A.[Party3_Name4_PreDir]
		  ,A.[Party3_Name4_StreetNumber]
		  ,A.[Party3_Name4_StreetName]
		  ,A.[Party3_Name4_PostDir]
		  ,A.[Party3_Name4_StreetType]
		  ,A.[Party3_Name4_SuiteType]
		  ,A.[Party3_Name4_Suite]
		  ,A.[Party3_Name4_City]
		  ,A.[Party3_Name4_State]
		  ,A.[Party3_Name4_Zip]
		  ,A.[Party3_Name4_ZipPlus4]
		  ,A.[Party4_Name1_FullName]
		  ,A.[Party4_Name1_last_Company_Name]
		  ,A.[Party4_Name1_First_Name]
		  ,A.[Party4_Name1_Middle_Name]
		  ,A.[Party4_Name1_Suffix]
		  ,A.[Party4_Name1_Roll_Type]
		  ,A.[Party4_Name1_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name1_Account_Nbr]
		  ,A.[Party4_Name1_SSN_Nbr]
		  ,A.[Party4_Name1_MailPropertyID]
		  ,A.[Party4_Name1_Address]
		  ,A.[Party4_Name1_PreDir]
		  ,A.[Party4_Name1_StreetNumber]
		  ,A.[Party4_Name1_StreetName]
		  ,A.[Party4_Name1_PostDir]
		  ,A.[Party4_Name1_StreetType]
		  ,A.[Party4_Name1_SuiteType]
		  ,A.[Party4_Name1_Suite]
		  ,A.[Party4_Name1_City]
		  ,A.[Party4_Name1_State]
		  ,A.[Party4_Name1_Zip]
		  ,A.[Party4_Name1_ZipPlus4]
		  ,A.[Party4_Name2_FullName]
		  ,A.[Party4_Name2_last_Company_Name]
		  ,A.[Party4_Name2_First_Name]
		  ,A.[Party4_Name2_Middle_Name]
		  ,A.[Party4_Name2_Suffix]
		  ,A.[Party4_Name2_Roll_Type]
		  ,A.[Party4_Name2_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name2_Account_Nbr]
		  ,A.[Party4_Name2_SSN_Nbr]
		  ,A.[Party4_Name2_MailPropertyID]
		  ,A.[Party4_Name2_Address]
		  ,A.[Party4_Name2_PreDir]
		  ,A.[Party4_Name2_StreetNumber]
		  ,A.[Party4_Name2_StreetName]
		  ,A.[Party4_Name2_PostDir]
		  ,A.[Party4_Name2_StreetType]
		  ,A.[Party4_Name2_SuiteType]
		  ,A.[Party4_Name2_Suite]
		  ,A.[Party4_Name2_City]
		  ,A.[Party4_Name2_State]
		  ,A.[Party4_Name2_Zip]
		  ,A.[Party4_Name2_ZipPlus4]
		  ,A.[Party4_Name3_FullName]
		  ,A.[Party4_Name3_last_Company_Name]
		  ,A.[Party4_Name3_First_Name]
		  ,A.[Party4_Name3_Middle_Name]
		  ,A.[Party4_Name3_Suffix]
		  ,A.[Party4_Name3_Roll_Type]
		  ,A.[Party4_Name3_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name3_Account_Nbr]
		  ,A.[Party4_Name3_SSN_Nbr]
		  ,A.[Party4_Name3_MailPropertyID]
		  ,A.[Party4_Name3_Address]
		  ,A.[Party4_Name3_PreDir]
		  ,A.[Party4_Name3_StreetNumber]
		  ,A.[Party4_Name3_StreetName]
		  ,A.[Party4_Name3_PostDir]
		  ,A.[Party4_Name3_StreetType]
		  ,A.[Party4_Name3_SuiteType]
		  ,A.[Party4_Name3_Suite]
		  ,A.[Party4_Name3_City]
		  ,A.[Party4_Name3_State]
		  ,A.[Party4_Name3_Zip]
		  ,A.[Party4_Name3_ZipPlus4]
		  ,A.[Party4_Name4_FullName]
		  ,A.[Party4_Name4_last_Company_Name]
		  ,A.[Party4_Name4_First_Name]
		  ,A.[Party4_Name4_Middle_Name]
		  ,A.[Party4_Name4_Suffix]
		  ,A.[Party4_Name4_Roll_Type]
		  ,A.[Party4_Name4_taxpayer_id_ssn_fein]
		  ,A.[Party4_Name4_Account_Nbr]
		  ,A.[Party4_Name4_SSN_Nbr]
		  ,A.[Party4_Name4_MailPropertyID]
		  ,A.[Party4_Name4_Address]
		  ,A.[Party4_Name4_PreDir]
		  ,A.[Party4_Name4_StreetNumber]
		  ,A.[Party4_Name4_StreetName]
		  ,A.[Party4_Name4_PostDir]
		  ,A.[Party4_Name4_StreetType]
		  ,A.[Party4_Name4_SuiteType]
		  ,A.[Party4_Name4_Suite]
		  ,A.[Party4_Name4_City]
		  ,A.[Party4_Name4_State]
		  ,A.[Party4_Name4_Zip]
		  ,A.[Party4_Name4_ZipPlus4]
		  ,A.[PropertyID]
		  ,A.[AddressLine]
		  ,A.[PreDir]
		  ,A.[StreetNumber]
		  ,A.[StreetName]
		  ,A.[PostDir]
		  ,A.[StreetType]
		  ,A.[SuiteType]
		  ,A.[Suite]
		  ,A.[City]
		  ,A.[PropState]
		  ,A.[Zip]
		  ,A.[Plus4]
		  ,A.[property_id_sequence_number]
		  ,A.[legal_desc_apn_portion]
		  ,A.[legal_desc_apn]
		  ,A.[legal_desc_apn_arb]
		  ,A.[legal_desc_map_portion]
		  ,A.[legal_desc_map_unit_low]
		  ,A.[legal_desc_map_unit_high]
		  ,A.[legal_desc_map_lot_type]
		  ,A.[legal_desc_map_lot_type_low]
		  ,A.[legal_desc_map_lot_type_high]
		  ,A.[legal_desc_map_lot_low]
		  ,A.[legal_desc_map_lot_high]
		  ,A.[legal_desc_map_block]
		  ,A.[legal_desc_map_building]
		  ,A.[legal_desc_map_sublot]
		  ,A.[legal_desc_map_plat_subcode]
		  ,A.[legal_desc_map_plat_name]
		  ,A.[legal_desc_map_plat_number]
		  ,A.[legal_desc_map_plat_condo_id]
		  ,A.[legal_desc_map_plat_type_indicator]
		  ,A.[legal_desc_map_plat_book]
		  ,A.[legal_desc_map_plat_page]
		  ,A.[legal_desc_str_portion]
		  ,A.[legal_desc_str_government_lot]
		  ,A.[legal_desc_str_quarter]
		  ,A.[legal_desc_str_section]
		  ,A.[legal_desc_str_township]
		  ,A.[legal_desc_str_range]
		  ,A.[legal_desc_tct]
		  ,A.[legal_desc_district]
		  ,A.[legal_desc_municipality]
		  ,A.[legal_desc_swiss_code]
		  ,A.[legal_desc_easement_flag]
		  ,A.[legal_desc_easement_type]
		  ,A.[legal_type]
		  ,A.[legal_type_sequence]
		  ,A.[property_sequence]
		  ,A.[legal_desc_qualifier]
		  ,A.[legal_desc_map_city_block]
		  ,A.[legal_desc_application_number]
		  ,A.[legal_desc_tax_assessor_portion]
		  ,A.[legal_desc_tax_assessor_lot]
		  ,A.[legal_desc_tax_assessor_block]
		  ,A.[legal_desc_tax_assessor_section]
		  ,A.[FATimeStamp]
		  ,A.[FARecordType]
		  ,A.[FormattedAPN]
		  ,A.[InActiveFlag]
		  ,A.[StdLandUseCode]
		  ,A.[cmt_docnumber]
		  ,A.[cmt_id]
		  ,A.[PropertyClassID]
		  ,A.[OwnerStd1CorpInd]
		  ,A.[REFERENCE_id]
		  ,A.[Reference_recording_year]
		  ,A.[reference_recording_date]
		  ,A.[reference_doc_number]
		  ,A.[reference_book]
		  ,A.[reference_page]
		  ,A.[Fmt_Reference_Doc_Number]
		  ,A.[Fmt_Reference_BookPAge]
			From [data].[dbo].[v_Invl] as A with(NOLOCK)
			join [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] as B with(NOLOCK) on A.Party2_Name1_MailPropertyID = B.PropertyID
			where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
			AND (A.InActiveFlag IS NULL)
			and A.FARecordType not like 'D'
			and convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,INPUTSTARTDATE)
			AND (convert(date,convert(varchar(10),A.Recordingdt)) > convert(date,[MAX_INVL_RECDATE])
			OR [MAX_INVL_RECDATE] is null)


			Select * From [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]


			Update [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
			Set
			REcordingDt = CONVERT(varchar(10), convert(date,REcordingDt,126), 101)
			,DocumentDt = CONVERT(varchar(10), convert(date,DocumentDt,126), 101)
			,doc_filing_date = CONVERT(varchar(10), convert(date,doc_filing_date,126), 101)
		



		
			Update [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
			Set ROWNUM = NULL

				UPDATE [zCust_ValonMortgage].[dbo].[t] 
				SET T.ROWNUM = R.RowNum2
				FROM [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL] t LEFT JOIN
				(SELECT * 
					,ROW_NUMBER() OVER(PARTITION BY [INPUT KEY] ORDER BY RecordingDt DESC) AS RowNum2
					FROM 
				[zCust_ValonMortgage].[dbo].[INVL_BULK_PULL] t  ) r ON t.[INPUT KEY] = r.[INPUT KEY] AND t.TransactionID = r.TransactionID
			 
				
		
		
			Select max(convert(int,ROWNUM )) from [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]


		Select * From [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
		where ROWNUM is null


		Select A.[Input Key], A.ROWNUM,A.TRANSACTIONID, A.DOCNBRSRCE, A.RECORDINGDT, A.DOC_CATEGORY From  [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL] as A 
		where [Input Key] in (
		Select [Input Key] from (
		Select [Input Key], ROWNUM, count(*) T From [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]
		Group by [Input Key], ROWNUM
		having count(*) > 1)A)
		Order by [Input Key],A.ROWNUM


		 Select top 100 * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]


		 Select * From [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL]

		
		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Set [# of Recordings] = NULL
		where convert(int,[# of Recordings]) > 0


		UPDATE [zCust_ValonMortgage].[dbo].[a]
		SET a.[# of Recordings] = b.NbrOfRecordings 
		--case when b.NbrOfRecordings > 3 then '3' else 
		--b.NbrOfRecordings 
		--end
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN (SELECT [INPUT KEY],MAX(ROWNUM) NbrOfRecordings FROM [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL] GROUP BY [INPUT KEY]) b
		on a.[Input UniqueID] = b.[INPUT KEY]

		Select max(convert(bigint,[# of Recordings])) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]

	
		--IF (Select count(*) from x_Custom_OUTPUT_S28
		--where [# of Recordings] > 0 ) > 0


		Update [zCust_ValonMortgage].[dbo].[A]
		Set
		A.[Record #] = '1'
		--,A.[TransactionID] = B.[TransactionID]
		--,A.[Fips] = B.[Fips]
		--,A.[State] = B.[State]
		--,A.[County] = B.[County]
		--,A.[DocumentYear] = B.[DocumentYear]
		,A.[Recordingdt] = B.[Recordingdt]
		,A.[DocumentDt] = B.[DocumentDt]
		,A.[doc_filing_date] = B.[doc_filing_date]
		,A.[DocNbrSrce] = B.[DocNbrSrce]
		,A.[BookSrce] = B.[BookSrce]
		,A.[PaceSrce] = B.[PaceSrce]
		,A.[Doc_Category] = B.[Doc_Category]
		,A.[DocTypeID] = B.[DocTypeID]
		,A.[DocType] = B.[DocType]
		,A.[DocumentTitle] = B.[DocumentTitle]
		--,A.[case_number] = B.[case_number]
		--,A.[case_book] = B.[case_book]
		--,A.[case_page] = B.[case_page]
		--,A.[date_of_death] = B.[date_of_death]
		--,A.[account_number] = B.[account_number]
		--,A.[amendment_number] = B.[amendment_number]
		--,A.[attorney_bar_number] = B.[attorney_bar_number]
		--,A.[bond_number] = B.[bond_number]
		--,A.[lot_line_adjustment_number] = B.[lot_line_adjustment_number]
		--,A.[certificate_number] = B.[certificate_number]
		--,A.[claim_number] = B.[claim_number]
		--,A.[contract_number] = B.[contract_number]
		--,A.[corporation_number] = B.[corporation_number]
		--,A.[excise_tax_number] = B.[excise_tax_number]
		,A.[federal_tax_lien_area] = B.[federal_tax_lien_area]
		,A.[federal_tax_lien_area_phone] = B.[federal_tax_lien_area_phone]
		,A.[tax_last_day_for_refiling] = B.[tax_last_day_for_refiling]
		,A.[tax_period_begin_date] = B.[tax_period_begin_date]
		,A.[tax_period_end_date] = B.[tax_period_end_date]
		,A.[tax_amount] = B.[tax_amount]
		,A.[tax_interest_amount] = B.[tax_interest_amount]
		,A.[tax_penalty_amount] = B.[tax_penalty_amount]
		,A.[judgment_amount] = B.[judgment_amount]
		--,A.[judgment_grand_total] = B.[judgment_grand_total]
		--,A.[license_number] = B.[license_number]
		,A.[lien_number] = B.[lien_number]
		,A.[map_plat_id] = B.[map_plat_id]
		,A.[mechanics_lien_number] = B.[mechanics_lien_number]
		,A.[ordinance_number] = B.[ordinance_number]
		,A.[patent_number] = B.[patent_number]
		,A.[permit_number] = B.[permit_number]
		,A.[resolution_number] = B.[resolution_number]
		,A.[tax_account_serial_warrant_number] = B.[tax_account_serial_warrant_number]
		,A.[tax_type] = B.[tax_type]
		,A.[trustees_sale_number] = B.[trustees_sale_number]
		,A.[ucc_number] = B.[ucc_number]
		,A.[undersigned_same_as_borrower] = B.[undersigned_same_as_borrower]
		,A.[amount_due] = B.[amount_due]
		,A.[amount_of_default] = B.[amount_of_default]
		,A.[bond_amount] = B.[bond_amount]
		,A.cash_down_amount = B.cash_down_amount
		,A.[contract_amount] = B.[contract_amount]
		,A.collection_costs = B.collection_costs
		,A.[unpaid_balance] = B.[unpaid_balance]
		,A.[unpaid_balance_as_of_modification_date] = B.[unpaid_balance_as_of_modification_date]
		,A.[unpaid_prinicipal_amount] = B.[unpaid_prinicipal_amount]
		--,A.[date_of_divorce] = B.[date_of_divorce]
		--,A.[support_arrears_amount] = B.[support_arrears_amount]
		--,A.[support_payment_amount] = B.[support_payment_amount]
		--,A.[support_total_amount] = B.[support_total_amount]
		--,A.[date_amount_due] = B.[date_amount_due]
		--,A.[date_stay_ordered] = B.[date_stay_ordered]
		--,A.[requested_prepared_by_attorney_name_identifier] = B.[requested_prepared_by_attorney_name_identifier]
		--,A.[requested_prepared_by_attorney_last_company_name] = B.[requested_prepared_by_attorney_last_company_name]
		--,A.[requested_prepared_by_attorney_first_name] = B.[requested_prepared_by_attorney_first_name]
		--,A.[requested_prepared_by_attorney_middle_initial] = B.[requested_prepared_by_attorney_middle_initial]
		--,A.[requested_prepared_by_attorney_suffix] = B.[requested_prepared_by_attorney_suffix]
		--,A.[requested_prepared_by_attorney_address] = B.[requested_prepared_by_attorney_address]
		--,A.[requested_prepared_by_attorney_address_city] = B.[requested_prepared_by_attorney_address_city]
		--,A.[requested_prepared_by_attorney_address_state] = B.[requested_prepared_by_attorney_address_state]
		--,A.[requested_prepared_by_attorney_address_zip] = B.[requested_prepared_by_attorney_address_zip]
		--,A.[requested_prepared_by_attorney_phone] = B.[requested_prepared_by_attorney_phone]
		,A.[Party1_Name1_FullName] = B.[Party1_Name1_FullName]
		,A.[Party1_Name1_last_Company_Name] = B.[Party1_Name1_last_Company_Name]
		,A.[Party1_Name1_First_Name] = B.[Party1_Name1_First_Name]
		,A.[Party1_Name1_Middle_Name] = B.[Party1_Name1_Middle_Name]
		,A.[Party1_Name1_Suffix] = B.[Party1_Name1_Suffix]
		,A.[Party1_Name1_Role_Type] = B.Party1_Name1_Roll_Type
		,A.[Party1_Name1_MailPropertyID] = B.[Party1_Name1_MailPropertyID]
		,A.[Party1_Name1_Address] = B.[Party1_Name1_Address]
		,A.[Party1_Name1_PreDir] = B.[Party1_Name1_PreDir]
		,A.[Party1_Name1_StreetNumber] = B.[Party1_Name1_StreetNumber]
		,A.[Party1_Name1_StreetName] = B.[Party1_Name1_StreetName]
		,A.[Party1_Name1_PostDir] = B.[Party1_Name1_PostDir]
		,A.[Party1_Name1_StreetType] = B.[Party1_Name1_StreetType]
		,A.[Party1_Name1_SuiteType] = B.[Party1_Name1_SuiteType]
		,A.[Party1_Name1_Suite] = B.[Party1_Name1_Suite]
		,A.[Party1_Name1_City] = B.[Party1_Name1_City]
		,A.[Party1_Name1_State] = B.[Party1_Name1_State]
		,A.[Party1_Name1_Zip] = B.[Party1_Name1_Zip]
		,A.[Party1_Name1_ZipPlus4] = B.[Party1_Name1_ZipPlus4]
		,A.[Party1_Name2_FullName] = B.[Party1_Name2_FullName]
		,A.[Party1_Name2_last_Company_Name] = B.[Party1_Name2_last_Company_Name]
		,A.[Party1_Name2_First_Name] = B.[Party1_Name2_First_Name]
		,A.[Party1_Name2_Middle_Name] = B.[Party1_Name2_Middle_Name]
		,A.[Party1_Name2_Suffix] = B.[Party1_Name2_Suffix]
		,A.[Party1_Name2_Role_Type] = B.[Party1_Name2_Roll_Type]
		,A.[Party1_Name2_MailPropertyID] = B.[Party1_Name2_MailPropertyID]
		,A.[Party1_Name2_Address] = B.[Party1_Name2_Address]
		,A.[Party1_Name2_PreDir] = B.[Party1_Name2_PreDir]
		,A.[Party1_Name2_StreetNumber] = B.[Party1_Name2_StreetNumber]
		,A.[Party1_Name2_StreetName] = B.[Party1_Name2_StreetName]
		,A.[Party1_Name2_PostDir] = B.[Party1_Name2_PostDir]
		,A.[Party1_Name2_StreetType] = B.[Party1_Name2_StreetType]
		,A.[Party1_Name2_SuiteType] = B.[Party1_Name2_SuiteType]
		,A.[Party1_Name2_Suite] = B.[Party1_Name2_Suite]
		,A.[Party1_Name2_City] = B.[Party1_Name2_City]
		,A.[Party1_Name2_State] = B.[Party1_Name2_State]
		,A.[Party1_Name2_Zip] = B.[Party1_Name2_Zip]
		,A.[Party1_Name2_ZipPlus4] = B.[Party1_Name2_ZipPlus4]
		,A.[Party2_Name1_FullName] = B.[Party2_Name1_FullName]
		,A.[Party2_Name1_last_Company_Name] = B.[Party2_Name1_last_Company_Name]
		,A.[Party2_Name1_First_Name] = B.[Party2_Name1_First_Name]
		,A.[Party2_Name1_Middle_Name] = B.[Party2_Name1_Middle_Name]
		,A.[Party2_Name1_Suffix] = B.[Party2_Name1_Suffix]
		,A.[Party2_Name1_Role_Type] = B.[Party2_Name1_Roll_Type]
		,A.[Party2_Name1_MailPropertyID] = B.[Party2_Name1_MailPropertyID]
		,A.[Party2_Name1_Address] = B.[Party2_Name1_Address]
		,A.[Party2_Name1_PreDir] = B.[Party2_Name1_PreDir]
		,A.[Party2_Name1_StreetNumber] = B.[Party2_Name1_StreetNumber]
		,A.[Party2_Name1_StreetName] = B.[Party2_Name1_StreetName]
		,A.[Party2_Name1_PostDir] = B.[Party2_Name1_PostDir]
		,A.[Party2_Name1_StreetType] = B.[Party2_Name1_StreetType]
		,A.[Party2_Name1_SuiteType] = B.[Party2_Name1_SuiteType]
		,A.[Party2_Name1_Suite] = B.[Party2_Name1_Suite]
		,A.[Party2_Name1_City] = B.[Party2_Name1_City]
		,A.[Party2_Name1_State] = B.[Party2_Name1_State]
		,A.[Party2_Name1_Zip] = B.[Party2_Name1_Zip]
		,A.[Party2_Name1_ZipPlus4] = B.[Party2_Name1_ZipPlus4]
		,A.[Party2_Name2_FullName] = B.[Party2_Name2_FullName]
		,A.[Party2_Name2_last_Company_Name] = B.[Party2_Name2_last_Company_Name]
		,A.[Party2_Name2_First_Name] = B.[Party2_Name2_First_Name]
		,A.[Party2_Name2_Middle_Name] = B.[Party2_Name2_Middle_Name]
		,A.[Party2_Name2_Suffix] = B.[Party2_Name2_Suffix]
		,A.[Party2_Name2_Role_Type] = B.[Party2_Name2_Roll_Type]
		,A.[Party2_Name2_MailPropertyID] = B.[Party2_Name2_MailPropertyID]
		,A.[Party2_Name2_Address] = B.[Party2_Name2_Address]
		,A.[Party2_Name2_PreDir] = B.[Party2_Name2_PreDir]
		,A.[Party2_Name2_StreetNumber] = B.[Party2_Name2_StreetNumber]
		,A.[Party2_Name2_StreetName] = B.[Party2_Name2_StreetName]
		,A.[Party2_Name2_PostDir] = B.[Party2_Name2_PostDir]
		,A.[Party2_Name2_StreetType] = B.[Party2_Name2_StreetType]
		,A.[Party2_Name2_SuiteType] = B.[Party2_Name2_SuiteType]
		,A.[Party2_Name2_Suite] = B.[Party2_Name2_Suite]
		,A.[Party2_Name2_City] = B.[Party2_Name2_City]
		,A.[Party2_Name2_State] = B.[Party2_Name2_State]
		,A.[Party2_Name2_Zip] = B.[Party2_Name2_Zip]
		,A.[Party2_Name2_ZipPlus4] = B.[Party2_Name2_ZipPlus4]
		--,A.[PropertyID] = B.[PropertyID]
		--,A.[AddressLine] = B.[AddressLine]
		--,A.[PreDir] = B.[PreDir]
		--,A.[StreetNumber] = B.[StreetNumber]
		--,A.[StreetName] = B.[StreetName]
		--,A.[PostDir] = B.[PostDir]
		--,A.[StreetType] = B.[StreetType]
		--,A.[SuiteType] = B.[SuiteType]
		--,A.[Suite] = B.[Suite]
		--,A.[City] = B.[City]
		--,A.[PropState] = B.[PropState]
		--,A.[Zip] = B.[Zip]
		--,A.[Plus4] = B.[Plus4]
		--,A.[FATimeStamp] = B.[FATimeStamp]
		--,A.[FARecordType] = B.[FARecordType]
		--,A.[FAFormattedAPN] = B.FormattedAPN
		--,A.[REFERENCE_id] = B.[REFERENCE_id]
	  ,A.[InactiveFlag] = B.InactiveFLag
	  ,A.[Reference_recording_year] = B.[Reference_recording_year]
	  ,A.[reference_recording_date] = B.[reference_recording_date]
	  ,A.[reference_doc_number] = B.[reference_doc_number]
	  ,A.[reference_book] = B.[reference_book]
	  ,A.[reference_page] = B.[reference_page]
	  ,A.[Fmt_Reference_Doc_Number] = B.[Fmt_Reference_Doc_Number]
	  ,A.[Fmt_Reference_BookPAge] = B.[Fmt_Reference_BookPAge]
		--Select B.*
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN  [zCust_ValonMortgage].[dbo].[INVL_BULK_PULL] as B 
			on a.[Input UniqueID] = b.[INPUT Key] 
			WHERE B.ROWNUM = 1

		
		 Select top 100 * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]

		----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[# of Recordings])) from [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ValonMortgage].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ValonMortgage].[sys].[tables] as A join [zCust_ValonMortgage].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S28'
			and B.Name not in ('Record #','TransactionID',
				--'Fips',
				--'State',
				'County',
				'DocumentYear',
				'Recordingdt',
				'DocumentDt',
				'doc_filing_date',
				'DocNbrSrce',
				'BookSrce',
				'PaceSrce',
				'Doc_Category',
				'DocTypeID',
				'DocType',
				'DocumentTitle',
				'case_number',
				'case_book',
				'case_page',
				'date_of_death',
				'account_number',
				'amendment_number',
				'attorney_bar_number',
				'bond_number',
				'lot_line_adjustment_number',
				'certificate_number',
				'claim_number',
				'contract_number',
				'corporation_number',
				'excise_tax_number',
				'federal_tax_lien_area',
				'federal_tax_lien_area_phone',
				'tax_last_day_for_refiling',
				'tax_period_begin_date',
				'tax_period_end_date',
				'tax_amount',
				'tax_interest_amount',
				'tax_penalty_amount',
				'judgment_amount',
				'judgment_grand_total',
				'license_number',
				'lien_number',
				'map_plat_id',
				'mechanics_lien_number',
				'ordinance_number',
				'patent_number',
				'permit_number',
				'resolution_number',
				'tax_account_serial_warrant_number',
				'tax_type',
				'trustees_sale_number',
				'ucc_number',
				'undersigned_same_as_borrower',
				'amount_due',
				'amount_of_default',
				'bond_amount',
				'cash_down_amount',

				'contract_amount',
				'collection_costs',
				'unpaid_balance',
				'unpaid_balance_as_of_modification_date',
				'unpaid_prinicipal_amount',
				'date_of_divorce',
				'support_arrears_amount',
				'support_payment_amount',
				'support_total_amount',
				'date_amount_due',
				'date_stay_ordered',
				'requested_prepared_by_attorney_name_identifier',
				'requested_prepared_by_attorney_last_company_name',
				'requested_prepared_by_attorney_first_name',
				'requested_prepared_by_attorney_middle_initial',
				'requested_prepared_by_attorney_suffix',
				'requested_prepared_by_attorney_address',
				'requested_prepared_by_attorney_address_city',
				'requested_prepared_by_attorney_address_state',
				'requested_prepared_by_attorney_address_zip',
				'requested_prepared_by_attorney_phone',
				'Party1_Name1_FullName',
				'Party1_Name1_last_Company_Name',
				'Party1_Name1_First_Name',
				'Party1_Name1_Middle_Name',
				'Party1_Name1_Suffix',
				'Party1_Name1_Role_Type',
				'Party1_Name1_MailPropertyID',
				'Party1_Name1_Address',
				'Party1_Name1_PreDir',
				'Party1_Name1_StreetNumber',
				'Party1_Name1_StreetName',
				'Party1_Name1_PostDir',
				'Party1_Name1_StreetType',
				'Party1_Name1_SuiteType',
				'Party1_Name1_Suite',
				'Party1_Name1_City',
				'Party1_Name1_State',
				'Party1_Name1_Zip',
				'Party1_Name1_ZipPlus4',
				'Party1_Name2_FullName',
				'Party1_Name2_last_Company_Name',
				'Party1_Name2_First_Name',
				'Party1_Name2_Middle_Name',
				'Party1_Name2_Suffix',
				'Party1_Name2_Role_Type',
				'Party1_Name2_MailPropertyID',
				'Party1_Name2_Address',
				'Party1_Name2_PreDir',
				'Party1_Name2_StreetNumber',
				'Party1_Name2_StreetName',
				'Party1_Name2_PostDir',
				'Party1_Name2_StreetType',
				'Party1_Name2_SuiteType',
				'Party1_Name2_Suite',
				'Party1_Name2_City',
				'Party1_Name2_State',
				'Party1_Name2_Zip',
				'Party1_Name2_ZipPlus4',
				'Party2_Name1_FullName',
				'Party2_Name1_last_Company_Name',
				'Party2_Name1_First_Name',
				'Party2_Name1_Middle_Name',
				'Party2_Name1_Suffix',
				'Party2_Name1_Role_Type',
				'Party2_Name1_MailPropertyID',
				'Party2_Name1_Address',
				'Party2_Name1_PreDir',
				'Party2_Name1_StreetNumber',
				'Party2_Name1_StreetName',
				'Party2_Name1_PostDir',
				'Party2_Name1_StreetType',
				'Party2_Name1_SuiteType',
				'Party2_Name1_Suite',
				'Party2_Name1_City',
				'Party2_Name1_State',
				'Party2_Name1_Zip',
				'Party2_Name1_ZipPlus4',
				'Party2_Name2_FullName',
				'Party2_Name2_last_Company_Name',
				'Party2_Name2_First_Name',
				'Party2_Name2_Middle_Name',
				'Party2_Name2_Suffix',
				'Party2_Name2_Role_Type',
				'Party2_Name2_MailPropertyID',
				'Party2_Name2_Address',
				'Party2_Name2_PreDir',
				'Party2_Name2_StreetNumber',
				'Party2_Name2_StreetName',
				'Party2_Name2_PostDir',
				'Party2_Name2_StreetType',
				'Party2_Name2_SuiteType',
				'Party2_Name2_Suite',
				'Party2_Name2_City',
				'Party2_Name2_State',
				'Party2_Name2_Zip',
				'Party2_Name2_ZipPlus4',
				--'PropertyID',
				'AddressLine',
				'PreDir',
				'StreetNumber',
				'StreetName',
				'PostDir',
				'StreetType',
				'SuiteType',
				'Suite',
				--'City',
				'PropState',
				'Zip',
				'Plus4',
				'FATimeStamp',
				'FARecordType',
				'FAFormattedAPN'
				,'REFERENCE_id'
				,'InActiveFlag'
				,'Reference_recording_year'
				,'reference_recording_date'
				,'reference_doc_number'
				,'reference_book'
				,'reference_page'
				,'Fmt_Reference_Doc_Number'
				,'Fmt_Reference_BookPAge')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		Select * From [zCust_ValonMortgage].[dbo].[BUILD_DOWN_COLUMNS]

		--Select * From x_Custom_OUTPUT_S28
				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ValonMortgage].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ValonMortgage].[dbo].[BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =   MAX(convert(int,[# of Recordings])) FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S28(
												' +  @FIELDLIST3 + '

												  ,[Record #],
												 [Recordingdt],
												[DocumentDt],
												[doc_filing_date],
												[DocNbrSrce],
												[BookSrce],
												[PaceSrce],
												[Doc_Category],
												[DocTypeID],
												[DocType],
												[DocumentTitle],
												[federal_tax_lien_area],
												[federal_tax_lien_area_phone],
												[tax_last_day_for_refiling],
												[tax_period_begin_date],
												[tax_period_end_date],
												[tax_amount],
												[tax_interest_amount],
												[tax_penalty_amount],
												[judgment_amount],
												[lien_number],
												[map_plat_id],
												[mechanics_lien_number],
												[ordinance_number],
												[patent_number],
												[permit_number],
												[resolution_number],
												[tax_account_serial_warrant_number],
												[tax_type],
												[trustees_sale_number],
												[ucc_number],
												[undersigned_same_as_borrower],
												[amount_due],
												[amount_of_default],
												[bond_amount],
												[cash_down_amount],
												[contract_amount],
												[collection_costs],
												[unpaid_balance],
												[unpaid_balance_as_of_modification_date],
												[unpaid_prinicipal_amount],
												[Party1_Name1_FullName],
												[Party1_Name1_last_Company_Name],
												[Party1_Name1_First_Name],
												[Party1_Name1_Middle_Name],
												[Party1_Name1_Suffix],
												[Party1_Name1_Role_Type],
												[Party1_Name1_MailPropertyID],
												[Party1_Name1_Address],
												[Party1_Name1_PreDir],
												[Party1_Name1_StreetNumber],
												[Party1_Name1_StreetName],
												[Party1_Name1_PostDir],
												[Party1_Name1_StreetType],
												[Party1_Name1_SuiteType],
												[Party1_Name1_Suite],
												[Party1_Name1_City],
												[Party1_Name1_State],
												[Party1_Name1_Zip],
												[Party1_Name1_ZipPlus4],
												[Party1_Name2_FullName],
												[Party1_Name2_last_Company_Name],
												[Party1_Name2_First_Name],
												[Party1_Name2_Middle_Name],
												[Party1_Name2_Suffix],
												[Party1_Name2_Role_Type],
												[Party1_Name2_MailPropertyID],
												[Party1_Name2_Address],
												[Party1_Name2_PreDir],
												[Party1_Name2_StreetNumber],
												[Party1_Name2_StreetName],
												[Party1_Name2_PostDir],
												[Party1_Name2_StreetType],
												[Party1_Name2_SuiteType],
												[Party1_Name2_Suite],
												[Party1_Name2_City],
												[Party1_Name2_State],
												[Party1_Name2_Zip],
												[Party1_Name2_ZipPlus4],
												[Party2_Name1_FullName],
												[Party2_Name1_last_Company_Name],
												[Party2_Name1_First_Name],
												[Party2_Name1_Middle_Name],
												[Party2_Name1_Suffix],
												[Party2_Name1_Role_Type],
												[Party2_Name1_MailPropertyID],
												[Party2_Name1_Address],
												[Party2_Name1_PreDir],
												[Party2_Name1_StreetNumber],
												[Party2_Name1_StreetName],
												[Party2_Name1_PostDir],
												[Party2_Name1_StreetType],
												[Party2_Name1_SuiteType],
												[Party2_Name1_Suite],
												[Party2_Name1_City],
												[Party2_Name1_State],
												[Party2_Name1_Zip],
												[Party2_Name1_ZipPlus4],
												[Party2_Name2_FullName],
												[Party2_Name2_last_Company_Name],
												[Party2_Name2_First_Name],
												[Party2_Name2_Middle_Name],
												[Party2_Name2_Suffix],
												[Party2_Name2_Role_Type],
												[Party2_Name2_MailPropertyID],
												[Party2_Name2_Address],
												[Party2_Name2_PreDir],
												[Party2_Name2_StreetNumber],
												[Party2_Name2_StreetName],
												[Party2_Name2_PostDir],
												[Party2_Name2_StreetType],
												[Party2_Name2_SuiteType],
												[Party2_Name2_Suite],
												[Party2_Name2_City],
												[Party2_Name2_State],
												[Party2_Name2_Zip],
												[Party2_Name2_ZipPlus4],
												[InactiveFlag],
												[Reference_recording_year],
												[reference_recording_date],
												[reference_doc_number],
												[reference_book],
												[reference_page],
												[Fmt_Reference_Doc_Number],
												[Fmt_Reference_BookPAge])
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												,B.[ROWNUM],
												B.[Recordingdt],
												B.[DocumentDt],
												B.[doc_filing_date],
												B.[DocNbrSrce],
												B.[BookSrce],
												B.[PaceSrce],
												B.[Doc_Category],
												B.[DocTypeID],
												B.[DocType],
												B.[DocumentTitle],
												B.[federal_tax_lien_area],
												B.[federal_tax_lien_area_phone],
												B.[tax_last_day_for_refiling],
												B.[tax_period_begin_date],
												B.[tax_period_end_date],
												B.[tax_amount],
												B.[tax_interest_amount],
												B.[tax_penalty_amount],
												B.[judgment_amount],
												B.[lien_number],
												B.[map_plat_id],
												B.[mechanics_lien_number],
												B.[ordinance_number],
												B.[patent_number],
												B.[permit_number],
												B.[resolution_number],
												B.[tax_account_serial_warrant_number],
												B.[tax_type],
												B.[trustees_sale_number],
												B.[ucc_number],
												B.[undersigned_same_as_borrower],
												B.[amount_due],
												B.[amount_of_default],
												B.[bond_amount],
												B.[cash_down_amount],
												B.[contract_amount],
												B.[collection_costs],
												B.[unpaid_balance],
												B.[unpaid_balance_as_of_modification_date],
												B.[unpaid_prinicipal_amount],
												B.[Party1_Name1_FullName],
												B.[Party1_Name1_last_Company_Name],
												B.[Party1_Name1_First_Name],
												B.[Party1_Name1_Middle_Name],
												B.[Party1_Name1_Suffix],
												B.[Party1_Name1_Roll_Type],
												B.[Party1_Name1_MailPropertyID],
												B.[Party1_Name1_Address],
												B.[Party1_Name1_PreDir],
												B.[Party1_Name1_StreetNumber],
												B.[Party1_Name1_StreetName],
												B.[Party1_Name1_PostDir],
												B.[Party1_Name1_StreetType],
												B.[Party1_Name1_SuiteType],
												B.[Party1_Name1_Suite],
												B.[Party1_Name1_City],
												B.[Party1_Name1_State],
												B.[Party1_Name1_Zip],
												B.[Party1_Name1_ZipPlus4],
												B.[Party1_Name2_FullName],
												B.[Party1_Name2_last_Company_Name],
												B.[Party1_Name2_First_Name],
												B.[Party1_Name2_Middle_Name],
												B.[Party1_Name2_Suffix],
												B.[Party1_Name2_Roll_Type],
												B.[Party1_Name2_MailPropertyID],
												B.[Party1_Name2_Address],
												B.[Party1_Name2_PreDir],
												B.[Party1_Name2_StreetNumber],
												B.[Party1_Name2_StreetName],
												B.[Party1_Name2_PostDir],
												B.[Party1_Name2_StreetType],
												B.[Party1_Name2_SuiteType],
												B.[Party1_Name2_Suite],
												B.[Party1_Name2_City],
												B.[Party1_Name2_State],
												B.[Party1_Name2_Zip],
												B.[Party1_Name2_ZipPlus4],
												B.[Party2_Name1_FullName],
												B.[Party2_Name1_last_Company_Name],
												B.[Party2_Name1_First_Name],
												B.[Party2_Name1_Middle_Name],
												B.[Party2_Name1_Suffix],
												B.[Party2_Name1_Roll_Type],
												B.[Party2_Name1_MailPropertyID],
												B.[Party2_Name1_Address],
												B.[Party2_Name1_PreDir],
												B.[Party2_Name1_StreetNumber],
												B.[Party2_Name1_StreetName],
												B.[Party2_Name1_PostDir],
												B.[Party2_Name1_StreetType],
												B.[Party2_Name1_SuiteType],
												B.[Party2_Name1_Suite],
												B.[Party2_Name1_City],
												B.[Party2_Name1_State],
												B.[Party2_Name1_Zip],
												B.[Party2_Name1_ZipPlus4],
												B.[Party2_Name2_FullName],
												B.[Party2_Name2_last_Company_Name],
												B.[Party2_Name2_First_Name],
												B.[Party2_Name2_Middle_Name],
												B.[Party2_Name2_Suffix],
												B.[Party2_Name2_Roll_Type],
												B.[Party2_Name2_MailPropertyID],
												B.[Party2_Name2_Address],
												B.[Party2_Name2_PreDir],
												B.[Party2_Name2_StreetNumber],
												B.[Party2_Name2_StreetName],
												B.[Party2_Name2_PostDir],
												B.[Party2_Name2_StreetType],
												B.[Party2_Name2_SuiteType],
												B.[Party2_Name2_Suite],
												B.[Party2_Name2_City],
												B.[Party2_Name2_State],
												B.[Party2_Name2_Zip],
												B.[Party2_Name2_ZipPlus4],
												B.[InactiveFlag],
												B.[Reference_recording_year],
												B.[reference_recording_date],
												B.[reference_doc_number],
												B.[reference_book],
												B.[reference_page],
												B.[Fmt_Reference_Doc_Number],
												B.[Fmt_Reference_BookPAge]

										--Select B.* 	
										
										FROM x_Custom_OUTPUT_S28 a JOIN  INVL_BULK_PULL as B 
										on a.[Input UniqueID] = b.[Input KEY]
										WHERE B.ROWNUM = ''' + @BeginNbrOfTrans6 + '''
										AND A.[Record #] = ''1''
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			Select top 1000 [Input UniqueID],[# of Recordings],[Record #], *
			From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] A
			where [# of Recordings] > 0
			Order by convert(int,A.[# of Recordings] ) desc,A.[Input UniqueID],convert(int,A.[Record #]) desc

			
			IF (Select count(*) From  [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
			where [# of Recordings] > 0) > 0

			BEGIN

			EXEC('

			--------DECODE Doc Type Category -----
			Select DOCTYPE, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DOCTYPE
			Order by DOCTYPE

			UPdate x_Custom_OUTPUT_S28
			Set DOCTYPE = case 
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJ'' then ''ABSTRACT OF JUDGMENT''
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJAMD'' then ''ABSTRACT OF JUDGMENT AMENDMENT''
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJASN'' then ''ABSTRACT OF JUDGMENT ASSIGNMENT''
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJFED'' then ''FEDERAL ABSTRACT OF JUDGMENT''
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJPRL'' then ''ABSTRACT OF JUDGMENT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''ABJ'' and DocType like ''ABJREL'' then ''ABSTRACT OF JUDGMENT  RELEASE''
			when [DOC_CATEGORY] like ''ACK'' and DocType like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [DOC_CATEGORY] like ''ACP'' and DocType like ''ACP'' then ''ACCEPTANCE''
			when [DOC_CATEGORY] like ''AFD'' and DocType like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [DOC_CATEGORY] like ''AFD'' and DocType like ''AFDTEE'' then ''AFFIDAVIT OF DEATH OF TRUSTEE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFF'' then ''AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFADD'' then ''AFFIDAVIT OF ADDRESS''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFAFX'' then ''AFFIDAVIT OF AFFIXTURE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFAUC'' then ''AFFIDAVIT OF AUCTIONEER''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFBKY'' then ''BANKRUPTCY AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFBUS'' then ''AFFIDAVIT OF CORPORATION''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCMC'' then ''AFFIDAVIT OF COMMENCEMENT/NON-COMMENCEMENT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCMP'' then ''AFFIDAVIT OF COMPLIANCE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCOV'' then ''AFFIDAVIT OF COVENANT AND AGREEMENT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCPR'' then ''COMMUNITY PROPERTY AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCPT'' then ''AFFIDAVIT OF COMPLETION''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFCUS'' then ''AFFIDAVIT OF CUSTODY OF MINOR''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFDED'' then ''AFFIDAVIT CONCERNING A DEED''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFDIV'' then ''AFFIDAVIT AS TO DIVORCE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFDOT'' then ''AFFIDAVIT AS TO DEED OF TRUST''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFEAS'' then ''AFFIDAVIT CONFINING EASEMENT IN TRACT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFERR'' then ''AFFIDAVIT OF SCRIVENERS ERROR/ERRONEOUS RECORDATION''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFETP'' then ''AFFIDAVIT OF ESTOPPEL''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFFOR'' then ''AFFIDAVIT OF FORFEITURE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFHEI'' then ''AFFIDAVIT OF HEIRSHIP''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFIDT'' then ''AFFIDAVIT OF IDENTITY''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFINH'' then ''AFFIDAVIT THAT NO INHERITANCE TAX IS DUE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFIST'' then ''AFFIDAVIT OF INTEREST''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFJDG'' then ''AFFIDAVIT AS TO JUDGMENT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFJTNTRM'' then ''AFFIDAVIT OF TERMINATION OF JOINT TENANCY <NO DEATH INVOLVED>''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLEN'' then ''AFFIDAVIT OF LIEN''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLENAGR'' then ''LIEN AGREEMENT AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLENREL'' then ''AFFIDAVIT OF RELEASE OF LIENS''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLOS'' then ''AFFIDAVIT OF LOST DOCUMENT <NOT DOT, MTG, NTE>''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLOSDOT'' then ''AFFIDAVIT OF LOST DEED OF TRUST''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLOSDTM'' then ''AFFIDAVIT OF LOST DEED OF TRUST/MORTGAGE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLOSMTG'' then ''AFFIDAVIT OF LOST MORTGAGE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFLOSNTE'' then ''AFFIDAVIT OF LOST NOTE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMAL'' then ''AFFIDAVIT OF MAILING''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMAP'' then ''MAP AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMAR'' then ''AFFIDAVIT OF MARITAL STATUS''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMGE'' then ''MORTGAGEES AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMLN'' then ''AFFIDAVIT FOR MECHANICS LIEN''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFMTGREL'' then ''AFFIDAVIT DOCUMENTING SATISFACTION OF MORTGAGE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFNAM'' then ''AFFIDAVIT OF SAME NAME''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFNCM'' then ''AFFIDAVIT OF NON-COMPLIANCE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFNMC'' then ''AFFIDAVIT OF NAME CHANGE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFOGL'' then ''OIL AND GAS LEASE AFFIDAVIT''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFPAY'' then ''AFFIDAVIT OF PAYMENT OF TAXES''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFPBL'' then ''AFFIDAVIT OF PUBLICATION''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFPOS'' then ''AFFIDAVIT OF POSSESSION''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFPUR'' then ''AFFIDAVIT OF PURCHASE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFSRV'' then ''AFFIDAVIT OF SERVICE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFTEE'' then ''AFFIDAVIT OF SUCCESSOR TRUSTEE''
			when [DOC_CATEGORY] like ''AFF'' and DocType like ''AFFTOD'' then ''TRANSFER ON DEATH AFFIDAVIT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGR'' then ''AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRADV'' then ''ADDITIONAL ADVANCE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRAER'' then ''AVIATION AGREEMENT (AIRSPACE)''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRAFR'' then ''AFFORDABLE HOUSING AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRAMD'' then ''AMENDMENT OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRANX'' then ''ANNEXATION AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRASN'' then ''ASSIGNMENT OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRASP'' then ''ASSUMPTION AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRATR'' then ''ATTORNMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRBLD'' then ''BUILDING & LOAN AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCDO'' then ''CONDOMINIUM AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCHT'' then ''CHATTEL SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCHTPRL'' then ''PARTIAL RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCHTREL'' then ''RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCPR'' then ''COMMUNITY PROPERTY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCPRMOD'' then ''MODIFICATION OF COMMUNITY PROPERTY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCPRPRL'' then ''PARTIAL RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCPRREL'' then ''RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCRL'' then ''CROSS COLLATERALIZATION AND CROSS DEFAULT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRCSD'' then ''CONSOLIDATION AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDED'' then ''AGREEMENT FOR DEED''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDEDMOD'' then ''MODIFICATION OF AGREEMENT FOR DEED''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDEDPRL'' then ''PARTIAL RELEASE OF AGREEMENT FOR DEED''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDFR'' then ''DEFERRAL AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDFRREL'' then ''RELEASE OF DEFERRAL AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDIV'' then ''DIVORCE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDOT'' then ''DEED OF TRUST AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDVL'' then ''DEVELOPMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDVLASN'' then ''ASSIGNMENT OF DEVELOPMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDVLASP'' then ''ASSUMPTION OF DEVELOPMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRDVLPRL'' then ''PARTIAL RELEASE OF DEVELOPMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRENC'' then ''ENCROACHMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRENG'' then ''ENERGY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRENV'' then ''ENVIRONMENTAL INDEMNITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRESC'' then ''ESCROW AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRFAC'' then ''FACILITIES AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRFML'' then ''FARMLAND DEVELOPMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRFOR'' then ''AGREEMENT TO FORFEIT PROPERTY''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRIDM'' then ''INDEMNITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRJOI'' then ''JOINDER AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLEN'' then ''LIEN AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLENAMD'' then ''AMENDMENT TO LIEN AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLENREL'' then ''RELEASE OF LIEN AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLIC'' then ''LICENSE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLICREL'' then ''CANCELLATION OF LICENSE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLLA'' then ''AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLLAMOD'' then ''MODIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLLARAT'' then ''RATIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLON'' then ''LOAN AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRLONMOD'' then ''LOAN MODIFICATION AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRMAI'' then ''ROAD MAINTENANCE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRMAR'' then ''MARRIAGE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRMER'' then ''MERGER AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRMOD'' then ''MODIFICATION OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRMTG'' then ''MORTGAGE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRNDA'' then ''NON-DISTURBANCE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRNEN'' then ''AGREEMENT NOT TO ENCUMBER''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGROGL'' then ''OIL AND GAS AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPAY'' then ''AGREEMENT FOR PAYMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPLD'' then ''NEGATIVE PLEDGE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPRL'' then ''PARTIAL RELEASE OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPUR'' then ''PURCHASE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPURREL'' then ''TERMINATION OF PURCHASE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRPWL'' then ''PARTY WALL AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRRAT'' then ''RATIFICATION OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRREG'' then ''REGULATORY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRREI'' then ''REINSTATEMENT OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRREL'' then ''RELEASE OF AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRRMB'' then ''AGREEMENT TO REIMBURSE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRRMBREL'' then ''RELEASE OF AGREEMENT TO REIMBURSE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSEC'' then ''SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSECASN'' then ''ASSIGNMENT OF SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSECREL'' then ''RELEASE OF SECURITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSEP'' then ''SEPARATION AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSET'' then ''SETTLEMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSETREL'' then ''RELEASE OF SETTLEMENT AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSIT'' then ''SITE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSITAMD'' then ''AMENDED SITE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLE'' then ''AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEAMD'' then ''AMENDMENT OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEASN'' then ''ASSIGNMENT OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEEXT'' then ''EXTENSION OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEMOD'' then ''MODIFICATION OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEPRL'' then ''PARTIAL RELEASE OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSLEREL'' then ''RELEASE OF AGREEMENT OF SALE''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRSWR'' then ''SEWER AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRUSE'' then ''USE AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRUTL'' then ''UTILITY AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRVIO'' then ''AGREEMENT TO CORRECT CODE VIOLATION''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRWTR'' then ''WATER AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRZON'' then ''ZONING AGREEMENT''
			when [DOC_CATEGORY] like ''AGR'' and DocType like ''AGRZONREL'' then ''RELEASE OF ZONING AGREEMENT''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALN'' then ''ASSESSMENT LIEN''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNCFD'' then ''COMMUNITY FACILITIES DISTRICT LIEN''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [DOC_CATEGORY] like ''AMD'' and DocType like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''ANM'' and DocType like ''ANM'' then ''ASSUMED NAME''
			when [DOC_CATEGORY] like ''ANM'' and DocType like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [DOC_CATEGORY] like ''APL'' and DocType like ''APL'' then ''APPLICATION''
			when [DOC_CATEGORY] like ''APL'' and DocType like ''APLAMD'' then ''APPLICATION AMENDMENT''
			when [DOC_CATEGORY] like ''APL'' and DocType like ''APLASN'' then ''APPLICATION ASSIGNMENT''
			when [DOC_CATEGORY] like ''ASR'' and DocType like ''ASR'' then ''ASSIGNMENT OF RENTS''
			when [DOC_CATEGORY] like ''ASR'' and DocType like ''ASRAMD'' then ''ASSIGNMENT OF RENTS AMENDMENT''
			when [DOC_CATEGORY] like ''ASR'' and DocType like ''ASRASN'' then ''ASSIGNMENT OF RENTS ASSIGNMENT''
			when [DOC_CATEGORY] like ''ASR'' and DocType like ''ASRPRL'' then ''ASSIGNMENT OF RENTS PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''ASR'' and DocType like ''ASRREL'' then ''ASSIGNMENT OF RENTS  RELEASE''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKY'' then ''BANKRUPTCY''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYAMD'' then ''BANKRUPTCY AMENDMENT''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYCNV'' then ''BANKRUPTCY CONVERSION''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYDIS'' then ''BANKRUPTCY DISCHARGE''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYDSM'' then ''BANKRUPTCY DISMISSAL''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYJDG'' then ''BANKRUPTCY JUDGMENT''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYORD'' then ''BANKRUPTCY ORDER''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYPRL'' then ''BANKRUPTCY PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYREL'' then ''BANKRUPTCY RELEASE''
			when [DOC_CATEGORY] like ''BKY'' and DocType like ''BKYSPL'' then ''BANKRUPTCY SPLIT''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BND'' then ''BOND''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDASN'' then ''BOND ASSIGNMENT''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDMLN'' then ''MECHANICS LIEN BOND''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDNTY'' then ''NOTARY BOND''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDPRL'' then ''BOND PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDREL'' then ''BOND RELEASE''
			when [DOC_CATEGORY] like ''BND'' and DocType like ''BNDSUR'' then ''SURETY BOND''
			when [DOC_CATEGORY] like ''BSL'' and DocType like ''BSL'' then ''BILL OF SALE''
			when [DOC_CATEGORY] like ''BSL'' and DocType like ''BSLASN'' then ''BILL OF SALE ASSIGNMENT''
			when [DOC_CATEGORY] like ''BSL'' and DocType like ''BSLMOD'' then ''BILL OF SALE MODIFICATION''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSAMD'' then ''AMENDED BUSINESS CERTIFICATE''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSAUT'' then ''BUSINESS SIGNING AUTHORIZATION''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSFIC'' then ''AFFIDAVIT OF DOING BUSINESS UNDER FICTITIOUS NAME''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSLIQ'' then ''NOTICE OF INTENDED TRANSFER OF RETAIL ALCOHOLIC BEVERAGE LICENSE''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSMER'' then ''BUSINESS MERGER''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSREL'' then ''RELEASE OF BUSINESS CERTIFICATE''
			when [DOC_CATEGORY] like ''BUS'' and DocType like ''BUSSLE'' then ''BUSINESS SALE''
			when [DOC_CATEGORY] like ''CAV'' and DocType like ''CAV'' then ''CAVEAT''
			when [DOC_CATEGORY] like ''CAV'' and DocType like ''CAVREL'' then ''CAVEAT RELEASE''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRACK'' then ''ACKNOWLEDGMENT OF DECLARATION OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRACP'' then ''ACCEPTANCE OF TERMS, COVENANT & CONDITIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRADP'' then ''ADOPTION & AFFIRMATION OF DECLARATION ESTABLISHING COVENANTS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRAMD'' then ''DECLARATION OF RESTRICTIONS AMENDMENT''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRANX'' then ''DECLARATION OF COVENANTS ANNEXATION''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRASN'' then ''ASSIGNMENT OF DECLARATION OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRBLD'' then ''DESIGNATION OF BUILDER UNDER DECLARATION OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRCNS'' then ''CONSENT TO DECLARATION OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRMOD'' then ''DECLARATION OF RESTRICTIONS MODIFICATION''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRPET'' then ''PETITION FOR ANNEXATION & DECLARATION OF COVENANT''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRPRL'' then ''DECLARATION OF RESTRICTIONS PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRRAT'' then ''COVENANTS & RESTRICTIONS RATIFICATION''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRREL'' then ''DECLARATION OF RESTRICTIONS RELEASE''
			when [DOC_CATEGORY] like ''CCR'' and DocType like ''CCRUSE'' then ''DECLARATION OF RESTRICTIONS ON USE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CER'' then ''CERTIFICATE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERAMD'' then ''CERTIFICATE AMENDMENT''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERASN'' then ''CERTIFICATE ASSIGNMENT''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERCMP'' then ''CERTIFICATE OF COMPLIANCE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERCMPHOA'' then ''CERTIFICATE OF COMPLIANCE <HOA>''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERCOR'' then ''CERTIFICATE OF CORRECTION''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERCPT'' then ''CERTIFICATE OF COMPLETION''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERDEA'' then ''DEATH CERTIFICATE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERDST'' then ''CERTIFICATE OF DISTRIBUTION''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERERR'' then ''CERTIFICATE  OF SCRIVENERS ERROR''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERLLA'' then ''CERTIFICATE OF LOT LINE ADJUSTMENTS''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERMAR'' then ''CERTIFICATE OF MARRIAGE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERNCM'' then ''CERTIFICATE OF NON-COMPLIANCE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERNCMHOA'' then ''CERTIFICATE OF NON-COMPLIANCE <HOA>''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERREL'' then ''CERTIFICATE OF CANCELLATION/RELEASE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERSLE'' then ''CERTIFICATE OF SALE <NOT TAX OR FORECLOSURE>''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERTOR'' then ''TORRENS CERTIFICATE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERTTL'' then ''CERTIFICATE OF TITLE''
			when [DOC_CATEGORY] like ''CER'' and DocType like ''CERWTR'' then ''CERTIFICATE OF WATER RIGHTS''
			when [DOC_CATEGORY] like ''CHJ'' and DocType like ''CHJ'' then ''CHANGE OF JUDGE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNS'' then ''CONSENT''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSCDO'' then ''CONSENT TO CONDOMINIUM CONVERSION''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSCUS'' then ''CONSENT OF PARENT FOR TEMPORARY CUSTODY''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSDED'' then ''CONSENT TO DEED''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSDOT'' then ''CONSENT TO DEED OF TRUST''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSLSE'' then ''LANDORDS CONSENT TO  LEASE ASSIGNMENT/SUBLEASE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSMAP'' then ''CONSENT TO MAP''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSMTG'' then ''CONSENT TO MORTGAGE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSNTE'' then ''CONSENT TO NOTE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSOGL'' then ''CONSENT TO OIL AND GAS LEASE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSOPT'' then ''CONSENT OF OPTIONEE''
			when [DOC_CATEGORY] like ''CNS'' and DocType like ''CNSRES'' then ''CONSENT & APPROVAL OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COV'' then ''COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVACK'' then ''ACKNOWLEGMENT OF COVENANTS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVAGR'' then ''COVENANT AGREEMENT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVAGRAMD'' then ''AMENDMENT OF COVENANT AGREEMENT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVAGRREL'' then ''RELEASE OF COVENANT AGREEMENT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVAMD'' then ''AMENDMENT OF COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVCNS'' then ''CONSENT TO COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVEAS'' then ''DECLARATION OF EASEMENTS COVENANTS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVENV'' then ''ENVIRONMENTAL COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVIMP'' then ''COVENANT OF IMPROVEMENTS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVLLA'' then ''DECLARATION OF BOUNDARY LINE ADJUSTMENT & COVENANTS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVMOD'' then ''COVENANT MODIFICATION''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVOPT'' then ''AFFORDABILITY COVENANT AND OPTION TO PURCHASE''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVPRK'' then ''COVENANT OF PARKING''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVPRL'' then ''PARTIAL RELEASE OF COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVREL'' then ''RELEASE OF COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVSLM'' then ''SUPPLEMENTAL DECLARATION OF COVENANTS''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVUSE'' then ''AGRICULTURAL STRUCTURE USE COVENANT''
			when [DOC_CATEGORY] like ''COV'' and DocType like ''COVVAR'' then ''VARIANCE/SETABCK COVENANT''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRP'' then ''CORPORATION''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPAMD'' then ''CORPORATION AMENDMENT''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPBYL'' then ''CORPORATE BYLAWS''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPBYLAMD'' then ''AMENDMENT TO CORPORATE BYLAWS''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPBYLREL'' then ''REVOCATION OF CORPORATE BYLAWS''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPNMC'' then ''CORPORATION NAME CHANGE''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPREI'' then ''CORPORATION REINSTATEMENT''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPREL'' then ''REVOCATION OF CORPORATION''
			when [DOC_CATEGORY] like ''CRP'' and DocType like ''CRPSPN'' then ''SUSPENSION OF CORPORATION''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTR'' then ''CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRAGL'' then ''WILLIAMSON ACT CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRAMD'' then ''CONTRACT AMENDMENT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRASN'' then ''CONTRACT ASSIGNMENT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRASP'' then ''CONTRACT ASSUMPTION''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRBRE'' then ''CONTRACT BREACH''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRCHT'' then ''PERSONAL PROPERTY CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRCHTASN'' then ''ASSIGNMENT OF PERSONAL PROPERTY CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRCST'' then ''CONSTRUCTION CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRDED'' then ''CONTRACT FOR DEED''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRDEDREL'' then ''CONTRACT FOR DEED RELEASE''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRENG'' then ''ENERGY CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRLON'' then ''LOAN CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRMAR'' then ''MARRIAGE CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRMOD'' then ''CONTRACT MODIFICATION''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTROGL'' then ''OIL & GAS CONTRACT''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRPRL'' then ''CONTRACT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRREI'' then ''CONTRACT REINSTATE''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRREL'' then ''CONTRACT RELEASE''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRSLE'' then ''CONTRACT OF SALE''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRUTL'' then ''CONTRACT FOR UTILITIES''
			when [DOC_CATEGORY] like ''CTR'' and DocType like ''CTRWTR'' then ''CONTRACT FOR WATER RIGHTS''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCL'' then ''DECLARATION''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLAGL'' then ''DECLARATION OF WILLIAMSON ACT RESTRICTED LAND''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLAMD'' then ''DECLARATION AMENDMENT''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLDEA'' then ''DECLARATION OF DEATH''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLMAR'' then ''DECLARATION REGARDING MARRIAGE''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLPRL'' then ''DECLARATION PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''DCL'' and DocType like ''DCLREL'' then ''DECLARATION RELEASE''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCR'' then ''DECREE''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRDEA'' then ''DECREE ESTABLISHING FACT OF DEATH''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRDIV'' then ''DECREE OF DIVORCE''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRDST'' then ''DECREE OF DISTRIBUTION''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRLFE'' then ''DECREE TERMINATING LIFE ESTATE''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRMOD'' then ''DECREE MODIFICATION''
			when [DOC_CATEGORY] like ''DCR'' and DocType like ''DCRQUI'' then ''QUIET TITLE DECREE''
			when [DOC_CATEGORY] like ''DSC'' and DocType like ''DSC'' then ''DISCLAIMER''
			when [DOC_CATEGORY] like ''DSM'' and DocType like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [DOC_CATEGORY] like ''DTM'' and DocType like ''DTM'' then ''MORTGAGE, DEED OF TRUST''
			when [DOC_CATEGORY] like ''DTM'' and DocType like ''DTM2'' then ''SECOND MORTGAGE, DEED OF TRUST''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EAS'' then ''EASEMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASAGR'' then ''EASEMENT AGREEMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASAMD'' then ''EASEMENT AMENDMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASASN'' then ''EASEMENT ASSIGNMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASCNS'' then ''CONSENT TO EASEMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASCNSDOT'' then ''BENEFICIARIES CONSENT TO EASEMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASCTR'' then ''EASEMENT CONTRACT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASDED'' then ''EASEMENT DEED''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASDEDAMD'' then ''DEED EASEMENT AMENDMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASPRL'' then ''EASEMENT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASRAT'' then ''RATIFICATION OF EASEMENT''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASREL'' then ''EASEMENT RELEASE''
			when [DOC_CATEGORY] like ''EAS'' and DocType like ''EASSUB'' then ''EASEMENT SUBORDINATION''
			when [DOC_CATEGORY] like ''ELN'' and DocType like ''ELN'' then ''ECONOMIC LIEN''
			when [DOC_CATEGORY] like ''ELN'' and DocType like ''ELNPRL'' then ''PARTIAL RELEASE OF ECONOMIC LIEN''
			when [DOC_CATEGORY] like ''ELN'' and DocType like ''ELNREL'' then ''RELEASE OF ECONOMIC LIEN''
			when [DOC_CATEGORY] like ''EXC'' and DocType like ''EXC'' then ''EXECUTION''
			when [DOC_CATEGORY] like ''EXC'' and DocType like ''EXCPRL'' then ''EXECUTION PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''EXC'' and DocType like ''EXCREL'' then ''EXECUTION RELEASE''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLN'' then ''FEDERAL TAX LIEN''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNAMD'' then ''FEDERAL TAX LIEN AMENDMENT''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNEST'' then ''FEDERAL ESTATE TAX LIEN''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNEXT'' then ''FEDERAL TAX LIEN EXTENSION''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNFIL'' then ''FEDERAL TAX LIEN REFILING''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNINH'' then ''FEDERAL INHERITANCE TAX LIEN''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNMOD'' then ''FEDERAL TAX LIEN MODIFICATION''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNNON'' then ''FEDERAL TAX LIEN NON-ATTACHMENT''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNPRL'' then ''FEDERAL TAX LIEN PARTIAL RELEASE ''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNREL'' then ''FEDERAL TAX LIEN  RELEASE ''
			when [DOC_CATEGORY] like ''FLN'' and DocType like ''FLNSUB'' then ''FEDERAL LIEN SUBORDINATION''
			when [DOC_CATEGORY] like ''INJ'' and DocType like ''INJ'' then ''INJUCTION''
			when [DOC_CATEGORY] like ''INJ'' and DocType like ''INJAMD'' then ''INJUCTION AMENDMENT''
			when [DOC_CATEGORY] like ''INJ'' and DocType like ''INJPRL'' then ''INJUCTION PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''INJ'' and DocType like ''INJREL'' then ''INJUCTION RELEASE''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDG'' then ''JUDGMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGAMD'' then ''JUDGMENT AMENDMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGASN'' then ''JUDGMENT ASSIGNMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGDEA'' then ''JUDGMENT DEATH''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGDIV'' then ''DIVORCE JUDGMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGDOM'' then ''JUDGMENT  <DOMESTIC MATTERS>''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGDOT'' then ''JUDGMENT REGARDING DEED OF TRUST''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGDST'' then ''JUDGMENT DISTRIBUTION''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGEVT'' then ''JUDGMENT OF POSSESSION & EVICTION''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGFED'' then ''FEDERAL JUDGMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGLEN'' then ''JUDGMENT LIEN''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGLENASN'' then ''ASSIGNMENT OF JUDGMENT LIEN''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGLENREL'' then ''JUDGMENT LIEN RELEASE''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGLISREL'' then ''JUDGMENT LIS PENDENS''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGMOD'' then ''JUDGMENT MODIFICATION''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGMTG'' then ''JUDGMENT AFFECTING MORTGAGE''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGPRL'' then ''JUDGMENT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGQUI'' then ''QUIET TITLE JUDGMENT''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGREL'' then ''JUDGMENT RELEASE''
			when [DOC_CATEGORY] like ''JDG'' and DocType like ''JDGSUB'' then ''JUDGMENT SUBORDINATION''
			when [DOC_CATEGORY] like ''JTV'' and DocType like ''JTV'' then ''JOINT VENTURE''
			when [DOC_CATEGORY] like ''JTV'' and DocType like ''JTVAMD'' then ''JOINT VENTURE AMENDMENT''
			when [DOC_CATEGORY] like ''JTV'' and DocType like ''JTVASN'' then ''JOINT VENTURE ASSIGNMENT''
			when [DOC_CATEGORY] like ''JTV'' and DocType like ''JTVREL'' then ''JOINT VENTURE DISSOLUTION''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LEN'' then ''LEIN <GENERAL>''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENAMD'' then ''LIEN AMENDMENT''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENASN'' then ''LIEN ASSIGNMENT''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCNT'' then ''COUNTY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCNTPRL'' then ''PARTIAL RELASE OF COUNTY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCNTREL'' then ''RELEASE OF COUNTY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCTY'' then ''CITY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCTYPRL'' then ''PARTIAL RELEASE OF CITY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENCTYREL'' then ''RELEASE OF CITY LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENDOJ'' then ''DEPARTMENT OF JUSTICE LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENDOJPRL'' then ''PARTIAL RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENDOJREL'' then ''RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENENV'' then ''ENVIRONMENTAL LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENEXT'' then ''LIEN EXTENSION''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENGRB'' then ''GARBAGE LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENMED'' then ''MEDICAL LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENMEDPRL'' then ''PARTIAL RELEASE OF MEDICAL LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENMEDREL'' then ''RELEASE OF MEDICAL LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENMOD'' then ''LIEN MODIFICATION''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENOGL'' then ''OIL & GAS LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENOGLREL'' then ''RELEASE OF OIL & GAS LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENORS'' then ''ORS LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENPPT'' then ''POSTPONED PROPERTY TAX LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENPRL'' then ''LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENRAT'' then ''RATIFICATION OF LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENREL'' then ''LIEN RELEASE''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENSLE'' then ''NOTICE OF SALE <LIEN>''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENSUB'' then ''LIEN SUBORDINATION''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENSWR'' then ''SEWER LIEN''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENUTL'' then ''UTILITY LIEN''
			when [DOC_CATEGORY] like ''LEV'' and DocType like ''LEV'' then ''LEVY''
			when [DOC_CATEGORY] like ''LEV'' and DocType like ''LEVPRL'' then ''LEVY PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LEV'' and DocType like ''LEVREL'' then ''LEVY RELEASE''
			when [DOC_CATEGORY] like ''LEV'' and DocType like ''LEVSLE'' then ''LEVY SALE''
			when [DOC_CATEGORY] like ''LIC'' and DocType like ''LIC'' then ''LICENSE''
			when [DOC_CATEGORY] like ''LIC'' and DocType like ''LICAMD'' then ''LICENSE AMENDMENT''
			when [DOC_CATEGORY] like ''LIC'' and DocType like ''LICASN'' then ''LICENSE ASSIGNMENT''
			when [DOC_CATEGORY] like ''LIC'' and DocType like ''LICREL'' then ''EXPIRATION OF LICENSE''
			when [DOC_CATEGORY] like ''LID'' and DocType like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LIS'' then ''LIS PENDENS''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISAMD'' then ''LIS PENDENS AMENDMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISASN'' then ''LIS PENDENS ASSIGNMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISHLN'' then ''LIS PENDENS <HOA>''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISHLNAMD'' then ''LIS PENDENS <HOA> AMENDMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISHLNASN'' then ''LIS PENDENS <HOA> ASSIGNMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISHLNPRL'' then ''LIS PENDENS <HOA> PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISHLNREL'' then ''LIS PENDENS <HOA> RELEASE''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISMLN'' then ''LIS PENDENS - MECHANICS LIEN''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISMLNAMD'' then ''LIS PENDENS <MECHANICS LIEN> AMENDMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISMLNASN'' then ''LIS PENDENS <MECHANICS LIEN> ASSIGNMENT''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISMLNPRL'' then ''LIS PENDENS <MECHANICS LIEN> PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISMLNREL'' then ''LIS PENDENS <MECHANICS LIEN> RELEASE''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISPRL'' then ''LIS PENDENS PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISPRO'' then ''LIS PENDENS - PROBATE ACTION''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISQUI'' then ''QUIET TITLE NOTICE OF LIS PENDENS''
			when [DOC_CATEGORY] like ''LIS'' and DocType like ''LISREL'' then ''LIS PENDENS RELEASE''
			when [DOC_CATEGORY] like ''LLC'' and DocType like ''LLC'' then ''LLC''
			when [DOC_CATEGORY] like ''LLC'' and DocType like ''LLCAGR'' then ''LIMITED LIABILITY COMPANY OPERATING AGREEMENT''
			when [DOC_CATEGORY] like ''LLC'' and DocType like ''LLCAMD'' then ''LLC AMENDMENT''
			when [DOC_CATEGORY] like ''LLC'' and DocType like ''LLCASN'' then ''LLC ASSIGNMENT''
			when [DOC_CATEGORY] like ''LLC'' and DocType like ''LLCREL'' then ''LLC RELEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSE'' then ''LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEAMD'' then ''LEASE AMENDMENT''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEASN'' then ''ASSIGNMENT OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEASNPRL'' then ''PARTIAL RELEASE OF ASSIGNMENT OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEASNREL'' then ''RELEASE OF ASSIGNMENT OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEASP'' then ''ASSUMPTION OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEBRE'' then ''BREACH OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEBREREL'' then ''RELEASE OF BREACH OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSECHT'' then ''EQUIPMENT LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEDSC'' then ''LEASE DISCLAIMER''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEEXT'' then ''LEASE EXTENSION''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEMASASN'' then ''ASSIGNMENT OF MASTER LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEMOD'' then ''LEASE MODIFICATION''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEOPT'' then ''LEASE OPTION''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEPRL'' then ''LEASE PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEQCL'' then ''QUITCLAIM OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSERAT'' then ''LEASE RATIFICATION''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSEREL'' then ''LEASE RELEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSERIP'' then ''RIPARIAN LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSESBL'' then ''SUBLEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSESLM'' then ''LEASE SUPPLEMENT''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSESUB'' then ''SUBORDINATION OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSESUBASN'' then ''ASSIGNMENT OF SUBORDINATION OF LEASE''
			when [DOC_CATEGORY] like ''LSE'' and DocType like ''LSESUBREL'' then ''SUBORDINATION OF LEASE RELEASE''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAP'' then ''MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPAGL'' then ''AGRICULTURAL MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPAMD'' then ''MAP AMENDMENT''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPANX'' then ''ANNEXATION MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPAPL'' then ''MAP APPLICATION''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPAPV'' then ''MAP APPROVAL''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPASM'' then ''ASSESSMENT DISTRICT MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPCDO'' then ''CONDOMINIUM MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPCEM'' then ''CEMETARY MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPCFD'' then ''COMMUNITY FACILITY DISTRICT MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPDIV'' then ''DIVISION OF LAND MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPGUR'' then ''MAP GUARANTY''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPMCL'' then ''MINING CLAIM MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPMOD'' then ''MAP MODIFICATION''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPPCL'' then ''PARCEL MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPRAT'' then ''MAP RATIFICATION''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPRVN'' then ''REVERSION TO ACERAGE MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPSBD'' then ''SUBDIVISION MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPSHP'' then ''SHORT PLAT''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPSPV'' then ''SUPERVISORS PLAT''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPSVY'' then ''SURVEY MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPTRA'' then ''TRACT MAP''
			when [DOC_CATEGORY] like ''MAP'' and DocType like ''MAPVAC'' then ''MAP VACATION''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLJTV'' then ''AFFIDAVIT OF MINING VENTURE AGREEMENT''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLJTVREL'' then ''MINING VENTURE AGREEMENT TERMINATION''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLLOC'' then ''CERTIFICATE OF LOCATION/NOTICE OF MINING LOCATION''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLNIH'' then ''NOTICE OF INTENTION TO HOLD <MINING CLAIM>''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLPAY'' then ''AFFIDAVIT OF EVIDENCE OF PAYMENT''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLREL'' then ''NOTICE OF ABANDONMENT OF MINING CLAIM''
			when [DOC_CATEGORY] like ''MCL'' and DocType like ''MCLWRK'' then ''AFFIDAVIT OF LABOR/PROOF OF LABOR''
			when [DOC_CATEGORY] like ''MEM'' and DocType like ''MEM'' then ''MEMORANDUM''
			when [DOC_CATEGORY] like ''MEM'' and DocType like ''MEMLEN'' then ''MEMORANDUM OF LIEN AFFECTING REAL PROPERTY''
			when [DOC_CATEGORY] like ''MEM'' and DocType like ''MEMSLE'' then ''MEMORANDUM OF SALE''
			when [DOC_CATEGORY] like ''MIN'' and DocType like ''MIN'' then ''MINERAL INTEREST''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLN'' then ''MECHANICS LIEN''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNAMD'' then ''MECHANICS LIEN AMENDMENT''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNASN'' then ''MECHANICS LIEN ASSIGNMENT''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNEXT'' then ''MECHANICS LIEN EXTENSION''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNMOD'' then ''MECHANICS LIEN MODIFICATION''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNPRL'' then ''MECHANICS LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''MLN'' and DocType like ''MLNREL'' then ''MECHANICS LIEN RELEASE''
			when [DOC_CATEGORY] like ''MTY'' and DocType like ''MTY'' then ''MILITARY''
			when [DOC_CATEGORY] like ''NOI'' and DocType like ''NOI'' then ''NOTICE OF INTENT''
			when [DOC_CATEGORY] like ''NOI'' and DocType like ''NOIRED'' then ''NOTICE OF INTENT TO REDEEM''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOT'' then ''NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTAMD'' then ''AMENDED NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTAPE'' then ''NOTICE OF APPEAL''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTATT'' then ''NOTICE OF ATTACHMENT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTBLD'' then ''NOTICE OF SUBSTANDARD BUILDING''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTBRE'' then ''NOTICE OF BREACH''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTBREREL'' then ''CANCELLATION OF NOTICE OF BREACH''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCMC'' then ''NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCMCPRL'' then ''PARTIAL RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCMCREL'' then ''RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCMP'' then ''NOTICE OF COMPLIANCE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCPRREL'' then ''NOTICE OF TERMINATION OF INTEREST IN COMMUNITY PROPERTY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCPT'' then ''NOTICE OF COMPLETION''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTCSE'' then ''NOTICE OF CESSATION''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDEA'' then ''NOTICE OF DEATH''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDLQ'' then ''NOTICE OF DELINQUENCY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDML'' then ''NOTICE OF DEMOLITION''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDOT'' then ''NOTICE REGARDING DEED OF TRUST''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDSB'' then ''NOTICE OF DISBURSEMENT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTDSC'' then ''DISCLAIMER NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTERR'' then ''NOTICE OF SCRIVENERS ERROR''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTEVT'' then ''NOTICE OF EVICTION''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTIST'' then ''NOTICE OF INTEREST''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTISTPRL'' then ''PARTIAL RELEASE OF NOTICE OF INTEREST''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTISTREL'' then ''RELEASE OF NOTICE OF INTEREST''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLFE'' then ''NOTICE OF LIFE ESTATE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLFEREL'' then ''RELEASE OF NOTICE OF LIFE ESTATE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLIB'' then ''NOTICE OF NON-LIABILITY ''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLIBREL'' then ''RELEASE OF NOTICE OF NON-LIABILITY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLID'' then ''NOTICE OF LOCAL IMPROVEMENT DISTRICT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLLA'' then ''NOTICE OF LOT MERGER''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTLLAREL'' then ''NOTICE OF LOT MERGER REVERSAL''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTMH'' then ''NOTICE OF MANUFACTURED HOME''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTMIN'' then ''NOTICE TO PRESERVE MINERAL RIGHTS''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTMTG'' then ''NOTICE REGARDING MORTGAGE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTNNR'' then ''NOTICE OF NON RESPONSIBILITY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTNNRREL'' then ''RELEASE OF NOTICE OF NON RESPONSIBILITY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTPLD'' then ''NOTICE OF PLEDGE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTPLDREL'' then ''RELEASE OF NOTICE OF PLEDGE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTPRL'' then ''PARTIAL RELEASE OF NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTQNT'' then ''QUARANTINED PROPERTY  NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTREL'' then ''RELEASE OF NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSET'' then ''NOTICE OF SETTLEMENT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSTO'' then ''STOP NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSVY'' then ''SURVEY NOTICE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSWR'' then ''NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSWRREL'' then ''RELEASE OF NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTSZD'' then ''NOTICE OF SEIZURE''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTTAX'' then ''NOTICE OF TAX''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTTAXREL'' then ''RESCISSION OF NOTICE OF TAX DEFAULTED PROPERTY''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTTRN'' then ''NOTICE OF TRANSFER''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTTRU'' then ''NOTICE OF TRUST''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTVIO'' then ''NOTICE OF VIOLATION''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTWTH'' then ''NOTICE TO WITHHOLD''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTWTR'' then ''NOTICE OF WATER RIGHT''
			when [DOC_CATEGORY] like ''NOT'' and DocType like ''NOTWTRREL'' then ''RELEASE OF NOTICE OF WATER RIGHT''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTE'' then ''PROMISSORY NOTE''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEADV'' then ''NOTE FOR ADVANCES''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEAMD'' then ''NOTE AMENDMENT''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEASN'' then ''NOTE ASSIGNMENT''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEASP'' then ''LIEN NOTE ASSUMPTION''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEPRL'' then ''LIEN NOTE PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEREI'' then ''REINSTATEMENT OF NOTE''
			when [DOC_CATEGORY] like ''NTE'' and DocType like ''NTEREL'' then ''NOTE RELEASE''
			when [DOC_CATEGORY] like ''OAT'' and DocType like ''OAT'' then ''OATH''
			when [DOC_CATEGORY] like ''ODN'' and DocType like ''ODN'' then ''ORDINANCE''
			when [DOC_CATEGORY] like ''ODN'' and DocType like ''ODNREL'' then ''ORDINANCE RELEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGL'' then ''OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLAMD'' then ''AMENDED OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLASN'' then ''ASSIGNMENT OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLDSC'' then ''DISCLAIMER OF OIL & GAS RIGHTS''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLINT'' then ''OIL & GAS INTEREST''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLMOD'' then ''MODIFICATION OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLOPT'' then ''OPTION FOR OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLOPTAMD'' then ''AMENDED OPTION FOR OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLPRA'' then ''PARTIAL ASSIGNMENT OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLPRL'' then ''PARTIAL RELEASE OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLQCL'' then ''QUITCLAIM OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLRAT'' then ''RATIFICATION OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLREL'' then ''RELEASE OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLRTL'' then ''OIL & GAS LEASE RENTAL ORDER''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLSTP'' then ''STIPULATION OF OIL & GAS''
			when [DOC_CATEGORY] like ''OGL'' and DocType like ''OGLSUB'' then ''SUBORDINATION OF OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPT'' then ''OPTION''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTAGR'' then ''RIGHT OF FIRST REFUSAL AGREEMENT''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTAMD'' then ''OPTION AMENDMENT''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTASN'' then ''OPTION ASSIGNMENT''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTEXT'' then ''OPTION EXTENSION''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTMOD'' then ''OPTION MODIFICATION''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTOGL'' then ''OPTION OIL & GAS''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTPRL'' then ''OPTION PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTREL'' then ''OPTION RELEASE''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTSUB'' then ''OPTION SUBORDINATION''
			when [DOC_CATEGORY] like ''OPT'' and DocType like ''OPTXER'' then ''EXERCISE OF OPTION''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORD'' then ''ORDER''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDAMD'' then ''ORDER AMENDMENT''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDASN'' then ''ORDER ASSIGNMENT''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDED'' then ''ORDER AFFECTING DEED''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDIV'' then ''DIVORCE ORDER''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDOM'' then ''ORDER <DOMESTIC MATTERS>''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDOT'' then ''ORDER FOR DEED OF TRUST''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDSM'' then ''ORDER DISMISSAL''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDDST'' then ''ORDER OF DISTRIBUTION''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDEVT'' then ''ORDER OF POSSESSION & EVICTION''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDJDG'' then ''ORDER AND JUDGMENT''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDJDGAMD'' then ''AMENDED ORDER & FINAL JUDGMENT''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDLEN'' then ''ORDER OF LIEN''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDMTG'' then ''ORDER AFFECTING MORTGAGE''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDPRL'' then ''ORDER PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDQUI'' then ''ORDER TO QUIET TITLE''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDREL'' then ''ORDER RELEASE''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDSLE'' then ''ORDER OF SALE''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDSLEAMD'' then ''ORDER OF SALE AMENDED''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDSUB'' then ''ORDER SUBORDINATION''
			when [DOC_CATEGORY] like ''ORD'' and DocType like ''ORDWRL'' then ''ORDER AND RELEASE OF LIEN''
			when [DOC_CATEGORY] like ''PER'' and DocType like ''PER'' then ''PERMIT''
			when [DOC_CATEGORY] like ''PER'' and DocType like ''PERAMD'' then ''PERMIT AMENDMENT''
			when [DOC_CATEGORY] like ''PER'' and DocType like ''PERAPL'' then ''PERMIT APPLICATION''
			when [DOC_CATEGORY] like ''PER'' and DocType like ''PERASN'' then ''PERMIT ASSIGNMENT''
			when [DOC_CATEGORY] like ''PER'' and DocType like ''PERREL'' then ''PERMIT RELEASE''
			when [DOC_CATEGORY] like ''PET'' and DocType like ''PET'' then ''PETITION''
			when [DOC_CATEGORY] like ''PET'' and DocType like ''PETDIV'' then ''DIVORCE PETITION''
			when [DOC_CATEGORY] like ''PET'' and DocType like ''PETREL'' then ''PETITION RELEASE''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POA'' then ''POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POAAFF'' then ''AFFIDAVIT AS TO POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POAAMD'' then ''POWER OF ATTORNEY AMENDMENT''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POALTD'' then ''LIMITED POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POAMOD'' then ''POWER OF ATTORNEY MODIFICATION''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POAPRL'' then ''POWER OF ATTORNEY PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POAREL'' then ''POWER OF ATTORNEY RELEASE''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POASBT'' then ''SUBSTITUTION OF POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POA'' and DocType like ''POASPC'' then ''SPECIAL POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLAMD'' then ''AMENDED POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLASN'' then ''ASSIGNMENT OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLMOD'' then ''MODIFICATION OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLPRL'' then ''PARTIAL RELEASE OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLRAT'' then ''RATIFICATION OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''POL'' and DocType like ''POLREL'' then ''RELEASE OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''PRL'' and DocType like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PRO'' then ''PROBATE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROAFF'' then ''PROBATE AFFIDAVIT''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROAMD'' then ''PROBATE AMENDMENT''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROCSV'' then ''PROBATE CONSERVATOR''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PRODCR'' then ''PROBATE DECREE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PRODCRREL'' then ''PROBATE DECREE RELEASE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PRODST'' then ''PROBATE DISTRIBUTION''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROGDN'' then ''PROBATE GUARDIANSHIP''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROGDNREL'' then ''PROBATE REVOCATION OF GUARDIANSHIP''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROICP'' then ''PROBATE INCOMPENTENCY''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROJDG'' then ''PROBATE JUDGMENT''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROJDGAMD'' then ''PROBATE JUDGMENT AMENDMENT''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROJDGPRL'' then ''PROBATE JUDGMENT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROJDGREL'' then ''PROBATE JUDGMENT RELEASE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROLET'' then ''PROBATE LETTERS''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROMOD'' then ''PROBATE MODIFICATION''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROORD'' then ''PROBATE ORDER''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROPET'' then ''PROBATE PETITION''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROREL'' then ''PROBATE DISCHARGE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROSLE'' then ''PROBATE SALE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROSLEREL'' then ''PROBATE SALE RELEASE''
			when [DOC_CATEGORY] like ''PRO'' and DocType like ''PROWAR'' then ''PROBATE WARD OF THE STATE''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTR'' then ''PARTNERSHIP''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRAFF'' then ''PARTNERSHIP AFFIDAVIT''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRAMD'' then ''PARTNERSHIP AMENDMENT''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRANM'' then ''PARTNERSHIP FICTITIOUS OR ASSUMED NAME''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRASN'' then ''PARTNERSHIP ASSIGNMENT''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRLLC'' then ''PARTNERSHIP LLC''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRNMC'' then ''PARTNERSHIP NAME CHANGE''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRPRL'' then ''PARTNERSHIP PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRREL'' then ''PARTNERSHIP DISSOLUTION''
			when [DOC_CATEGORY] like ''PTR'' and DocType like ''PTRSLE'' then ''PARTNERSHIP SALE''
			when [DOC_CATEGORY] like ''RED'' and DocType like ''RED'' then ''NOTICE OF REDEMPTION''
			when [DOC_CATEGORY] like ''REL'' and DocType like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [DOC_CATEGORY] like ''REL'' and DocType like ''RELAFF'' then ''AFFIDAVIT TO  RELEASE''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQDSM'' then ''REQUEST FOR DISMISSAL''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQPRLDOT'' then ''REQUEST FOR PARTIAL RELEASE OF DEED OF TRUST''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQPRLMTG'' then ''REQUEST FOR PARTIAL RELEASE OF MORTGAGE''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQRELDOT'' then ''REQUEST FOR DEED OF RELEASE & FULL RECONVEYANCE''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQRELMTG'' then ''REQUEST FOR RELEASE OF MORTGAGE''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQRELVAC'' then ''VACATION OF REQUEST FOR RELEASE OF DEED OF TRUST/MORTGAGE''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQUCC'' then ''UCC SEARCH REQUEST''
			when [DOC_CATEGORY] like ''REQ'' and DocType like ''REQWAI'' then ''REQUEST FOR WAIVER''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESACK'' then ''BUYERS ACKNOWLEGMENT OF AFFORDABLE DEED RESTRICTIONS  ''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESAFF'' then ''AFFIDAVIT FOR PESTICIDE RESTRICTIVE COVENANTS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESAGR'' then ''AGREEMENT FOR RESTRICTIVE COVENANTS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESAMD'' then ''RESTRICTIONS AMENDMENT''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESANX'' then ''RESTRICTIONS ANNEXATION''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESAPP'' then ''DECLARATION OF APPOINTMENT OF ARCHITECTURAL COMM. <RESTRICTIONS>''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESCNS'' then ''CONSENT TO RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESLLA'' then ''RESTRICTIVE COVENANT PERTAINING TO CONSOLIDATION OF LOTS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESPRK'' then ''DESIGNATION OF PARKING UNDER RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESREL'' then ''RESTRICTIONS RELEASE''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESSLE'' then ''RESALE RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESSTP'' then ''STIPULATION OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESSTR'' then ''SUBSTITUTION OF TRUSTEE UNDER RESTRICTIONS''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESTRN'' then ''RESTRICTIONS ON TRANSFER OF PROPERTY''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESUSE'' then ''USE RESTRICTION''
			when [DOC_CATEGORY] like ''RES'' and DocType like ''RESVAR'' then ''VARIANCE/SETBACK UNDER RESTRICTIONS''
			when [DOC_CATEGORY] like ''ROY'' and DocType like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [DOC_CATEGORY] like ''ROY'' and DocType like ''ROYAMD'' then ''AMENDED ROYALTY AGREEMENT''
			when [DOC_CATEGORY] like ''ROY'' and DocType like ''ROYASN'' then ''ASSIGNMENT OF ROYALTY INTEREST''
			when [DOC_CATEGORY] like ''ROY'' and DocType like ''ROYPRL'' then ''PARTIAL RELEASE OF ROYALTY INTEREST''
			when [DOC_CATEGORY] like ''ROY'' and DocType like ''ROYQCL'' then ''QUITCLAIM OF ROYALTY INTEREST''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQN'' then ''REQUEST FOR NOTICE''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNAGR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF AGREEMENT ''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNCTR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF CONTRACT ''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNDOT'' then ''REQUEST FOR NOTICE OF DEFAULT OF DEED OF TRUST''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNHLN'' then ''REQUEST FOR NOTICE OF SALE -HOA LIEN''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNLEN'' then ''REQUEST FOR NOTICE OF SALE -LIEN''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNMLN'' then ''REQUEST FOR NOTICE OF SALE -MECHANICS LIEN''
			when [DOC_CATEGORY] like ''RQN'' and DocType like ''RQNMTG'' then ''REQUEST FOR NOTICE OF DEFAULT OF MORTGAGE''
			when [DOC_CATEGORY] like ''RSL'' and DocType like ''RSL'' then ''RESOLUTION''
			when [DOC_CATEGORY] like ''SBT'' and DocType like ''SBTAGR'' then ''SUBSTITUTION AGREEMENT <NOT DOT/MTG>''
			when [DOC_CATEGORY] like ''SBT'' and DocType like ''SBTSTR'' then ''SUBSTITUTION OF TRUSTEE <GENERAL>''
			when [DOC_CATEGORY] like ''SBT'' and DocType like ''SBTWAS'' then ''SUBSTITUTION AND ASSIGNMENT''
			when [DOC_CATEGORY] like ''SHF'' and DocType like ''SHFSLE'' then ''SHERIFFS SALE''
			when [DOC_CATEGORY] like ''SLE'' and DocType like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''SLE'' and DocType like ''SLEASN'' then ''ASSIGNMENT OF SALE''
			when [DOC_CATEGORY] like ''SLE'' and DocType like ''SLEMOD'' then ''MODIFICATION OF SALE''
			when [DOC_CATEGORY] like ''SLE'' and DocType like ''SLENOI'' then ''NOTICE OF INTENDED SALE/INTENT TO SELL''
			when [DOC_CATEGORY] like ''SLE'' and DocType like ''SLEREL'' then ''CANCELLATION OF SALE''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLN'' then ''STATE TAX LIEN''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNAMD'' then ''STATE TAX LIEN AMENDMENT''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNEST'' then ''STATE ESTATE TAX LIEN''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNEXT'' then ''STATE TAX LIEN EXTENTION''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNINH'' then ''STATE INHERITANCE TAX LIEN''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNMOD'' then ''STATE TAX LIEN MODIFICATION''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNPRL'' then ''STATE TAX LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNREL'' then ''STATE TAX LIEN RELEASE''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNSBE'' then ''STATE BOARD OF EQUILIZATION LIEN''
			when [DOC_CATEGORY] like ''SLN'' and DocType like ''SLNSUB'' then ''STATE LIEN SUBORDINATION''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STM'' then ''STATEMENT''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMAUT'' then ''STATEMENT OF AUTHORITY''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMBRE'' then ''STATEMENT OF BREACH''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMCHA'' then ''STATEMENT OF CHANGE''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMCLO'' then ''DISCLOSURE STATEMENT''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMIDT'' then ''STATEMENT IDENTIFYING REAL PROPERTY''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMIST'' then ''STATEMENT OF INTEREST''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMLOC'' then ''STATEMENT OF LOCATION''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMMAR'' then ''STATEMENT OF UNRECORDED MARRIAGE''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMOWN'' then ''STATEMENT OF OWNERSHIP''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMPBL'' then ''STATEMENT OF PUBLICATION''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMREL'' then ''REVOCATION OF STATEMENT''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMWTR'' then ''STATEMENT OF CLAIM OF RIGHT TO USE PUBLIC WATERS''
			when [DOC_CATEGORY] like ''STM'' and DocType like ''STMXPL'' then ''EXPLANATORY STATEMENT''
			when [DOC_CATEGORY] like ''STP'' and DocType like ''STP'' then ''STIPULATION''
			when [DOC_CATEGORY] like ''STR'' and DocType like ''STRREQREL'' then ''SUBSTITUTION OF TRUSTEE AND REQUEST FOR FULL RECONVEYANCE''
			when [DOC_CATEGORY] like ''SUI'' and DocType like ''SUI'' then ''SUIT''
			when [DOC_CATEGORY] like ''SUI'' and DocType like ''SUIAMD'' then ''SUIT AMENDMENT''
			when [DOC_CATEGORY] like ''SUI'' and DocType like ''SUIQUI'' then ''SUIT QUIET TITLE''
			when [DOC_CATEGORY] like ''SUI'' and DocType like ''SUIVAC'' then ''SUIT VACATE''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPJDG'' then ''SUPPORT JUDGMENT''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPJDGAMD'' then ''AMENDED SUPPORT JUDGMENT''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPJDGPRL'' then ''PARTIAL RELEASE OF SUPPORT JUDGMENT''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPLEN'' then ''SUPPORT LIEN''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPLENPRL'' then ''SUPPORT LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPLENREL'' then ''SUPPORT LIEN RELEASE''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPORD'' then ''SUPPORT ORDER''
			when [DOC_CATEGORY] like ''SUP'' and DocType like ''SUPREL'' then ''SUPPORT RELEASE''
			when [DOC_CATEGORY] like ''SWD'' and DocType like ''SWD'' then ''SPECIAL WARRANTY DEED''
			when [DOC_CATEGORY] like ''TNM'' and DocType like ''TNM'' then ''TRADE NAME''
			when [DOC_CATEGORY] like ''TNM'' and DocType like ''TNMAMD'' then ''TRADE NAME AMENDMENT''
			when [DOC_CATEGORY] like ''TNM'' and DocType like ''TNMAPL'' then ''TRADE NAME APPLICATION''
			when [DOC_CATEGORY] like ''TNM'' and DocType like ''TNMREL'' then ''TRADE NAME RELEASE''
			when [DOC_CATEGORY] like ''TRU'' and DocType like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [DOC_CATEGORY] like ''TRU'' and DocType like ''TRUSTR'' then ''SUBSTITUTION OF TRUSTEE OF A TRUST''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCC'' then ''FINANCING STATEMENT''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCAMD'' then ''FINANCING STATEMENT AMENDMENT''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCASN'' then ''FINANCING STATEMENT ASSIGNMENT''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCASP'' then ''FINANCING STATEMENT ASSUMPTION OF LIABILITY''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCCON'' then ''FINANCING STATEMENT CONTINUATION''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCDSP'' then ''DISPOSITION OF FINANCING STATEMENT''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCMOD'' then ''FINANCING STATEMENT MODIFICATION''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCOGL'' then ''FINANCING STATEMENT - OIL & GAS LEASE COLLATERAL''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCOOP'' then ''FINANCING STATEMENT - COOP''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCPRA'' then ''FINANCING STATEMENT PARTIAL ASSIGNMENT''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCPRL'' then ''FINANCING STATEMENT PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCREL'' then ''FINANCING STATEMENT RELEASE''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCSUB'' then ''FINANCING STATEMENT SUBORDINATION''
			when [DOC_CATEGORY] like ''UCC'' and DocType like ''UCCTER'' then ''FINANCING STATEMENT TERMINATION''
			when [DOC_CATEGORY] like ''UNU'' and DocType like ''UNU'' then ''UNUSED BY COUNTY''
			when [DOC_CATEGORY] like ''VEC'' and DocType like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [DOC_CATEGORY] like ''VIT'' and DocType like ''VIT'' then ''VITAL''
			when [DOC_CATEGORY] like ''VLN'' and DocType like ''VLN'' then ''VENDORS LIEN''
			when [DOC_CATEGORY] like ''VLN'' and DocType like ''VLNPRL'' then ''VENDORS LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''VLN'' and DocType like ''VLNREL'' then ''VENDORS LIEN  RELEASE''
			when [DOC_CATEGORY] like ''VOI'' and DocType like ''VOID'' then ''VOID''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAI'' then ''WAIVER''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIAMD'' then ''AMENDMENT OF WAIVER''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIHOM'' then ''WAIVER OF HOMESTEAD''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIIST'' then ''WAIVER OF OWNERSHIP INTEREST''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAILEN'' then ''WAIVER OF LIEN''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAILIB'' then ''WAIVER OF PERSONAL LIABILITY''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAILRD'' then ''LANDLORDS WAIVER & CONSENT''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIMAP'' then ''WAIVER OF MAP''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIMGE'' then ''MORTGAGEES WAIVER & CONSENT''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIMLN'' then ''WAIVER OF MECHANICS LIEN''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIOPT'' then ''OPTION WAIVER''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIPRL'' then ''PARTIAL RELEASE OF WAIVER''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIREL'' then ''RELEASE OF WAIVER''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIRES'' then ''WAIVER OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAIRHT'' then ''WAIVER OF DOWER RIGHTS''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAISLN'' then ''WAIVER OF STATE TAX LIEN''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAISUB'' then ''WAIVER OF SUBORDINATION RIGHTS''
			when [DOC_CATEGORY] like ''WAI'' and DocType like ''WAITAX'' then ''WAIVER OF TAX''
			when [DOC_CATEGORY] like ''WRT'' and DocType like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			when [DOC_CATEGORY] like ''WRT'' and DocType like ''WRTPRL'' then ''WRIT PARTIAL RELEASE <NOT AN EXECUTION>''
			when [DOC_CATEGORY] like ''WRT'' and DocType like ''WRTREL'' then ''WRIT RELEASE <NOT AN EXECUTION>''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNENG'' then ''ASSESSMENT ENERGY LIEN''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNENGAMD'' then ''ASSESSMENT ENERGY LIEN AMENDMENT''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNENGREL'' then ''ASSESSMENT ENERGY LIEN RELEASE''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [DOC_CATEGORY] like ''ALN'' and DocType like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [DOC_CATEGORY] like ''AMD'' and DocType like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''ANM'' and DocType like ''ANM'' then ''ASSUMED NAME''
			when [DOC_CATEGORY] like ''ANM'' and DocType like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [DOC_CATEGORY] like ''APL'' and DocType like ''APL'' then ''APPLICATION''
			when [DOC_CATEGORY] like ''LEN'' and DocType like ''LENENF'' then ''CODE ENFORCEMENT LIEN''


			else DocType end





			Select DOCTYPE, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DOCTYPE
			Order by DOCTYPE


			--------DECODE Doc Type Category -----

			Select DOC_CATEGORY, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DOC_CATEGORY
			Order by DOC_CATEGORY


			
			Update  x_Custom_OUTPUT_S28
			Set DOC_CATEGORY = case 
			when [DOC_CATEGORY] like ''ABJ'' then ''ABSTRACT''
			when [DOC_CATEGORY] like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [DOC_CATEGORY] like ''ACP'' then ''ACCEPTANCE''
			when [DOC_CATEGORY] like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [DOC_CATEGORY] like ''AFF'' then ''AFFIDAVIT''
			when [DOC_CATEGORY] like ''AGR'' then ''AGREEMENT''
			when [DOC_CATEGORY] like ''ALN'' then ''ASSESSMENT LIEN''
			when [DOC_CATEGORY] like ''AMD'' then ''AMENDMENT''
			when [DOC_CATEGORY] like ''ANM'' then ''ASSUMED NAME''
			when [DOC_CATEGORY] like ''APL'' then ''APPLICATION''
			when [DOC_CATEGORY] like ''ASR'' then ''ASSIGNMENT or Rents''
			when [DOC_CATEGORY] like ''BKY'' then ''BANKRUPTCY''
			when [DOC_CATEGORY] like ''BND'' then ''BOND''
			when [DOC_CATEGORY] like ''BSL'' then ''BILL OF SALE''
			when [DOC_CATEGORY] like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [DOC_CATEGORY] like ''CAV'' then ''CAVEAT''
			when [DOC_CATEGORY] like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTION''
			when [DOC_CATEGORY] like ''CER'' then ''CERTIFICATE''
			when [DOC_CATEGORY] like ''CHJ'' then ''CHANGE OF JUDGE''
			when [DOC_CATEGORY] like ''CNS'' then ''CONSENT''
			when [DOC_CATEGORY] like ''COV'' then ''COVENANT''
			when [DOC_CATEGORY] like ''CRP'' then ''CORPORATION''
			when [DOC_CATEGORY] like ''CTR'' then ''CONTRACT''
			when [DOC_CATEGORY] like ''DCL'' then ''DECLARATION''
			when [DOC_CATEGORY] like ''DCR'' then ''DECREE''
			when [DOC_CATEGORY] like ''DSC'' then ''DISCLAIMER''
			when [DOC_CATEGORY] like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [DOC_CATEGORY] like ''EAS'' then ''EASEMENT''
			when [DOC_CATEGORY] like ''ELN'' then ''ECONOMIC LIEN''
			when [DOC_CATEGORY] like ''EXC'' then ''EXECUTION''
			when [DOC_CATEGORY] like ''FLN'' then ''FEDERAL TAX LIEN''
			when [DOC_CATEGORY] like ''HLN'' then ''HOA LIEN''
			when [DOC_CATEGORY] like ''HOM'' then ''DECLARATION OF HOMESTEAD''
			when [DOC_CATEGORY] like ''INJ'' then ''INJUCTION''
			when [DOC_CATEGORY] like ''JDG'' then ''JUDGMENT''
			when [DOC_CATEGORY] like ''JTV'' then ''JOINT VENTURE''
			when [DOC_CATEGORY] like ''LEN'' then ''LEIN <GENERAL>''
			when [DOC_CATEGORY] like ''LEV'' then ''LEVY''
			when [DOC_CATEGORY] like ''LIC'' then ''LICENSE''
			when [DOC_CATEGORY] like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [DOC_CATEGORY] like ''LIS'' then ''LIS PENDENS''
			when [DOC_CATEGORY] like ''LLC'' then ''LLC''
			when [DOC_CATEGORY] like ''LSE'' then ''LEASE''
			when [DOC_CATEGORY] like ''MAP'' then ''MAP''
			when [DOC_CATEGORY] like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [DOC_CATEGORY] like ''MEM'' then ''MEMORANDUM''
			when [DOC_CATEGORY] like ''MIN'' then ''MINERAL INTEREST''
			when [DOC_CATEGORY] like ''MLN'' then ''MECHANICS LIEN''
			when [DOC_CATEGORY] like ''MOD'' then ''MODIFICATION <UNSPECIFICED>''
			when [DOC_CATEGORY] like ''MTY'' then ''MILITARY''
			when [DOC_CATEGORY] like ''NOI'' then ''NOTICE OF INTENT''
			when [DOC_CATEGORY] like ''NOT'' then ''NOTICE''
			when [DOC_CATEGORY] like ''NTE'' then ''PROMISSORY NOTE''
			when [DOC_CATEGORY] like ''OAT'' then ''OATH''
			when [DOC_CATEGORY] like ''ODN'' then ''ORDINANCE''
			when [DOC_CATEGORY] like ''OGL'' then ''OIL & GAS LEASE''
			when [DOC_CATEGORY] like ''OPT'' then ''OPTION''
			when [DOC_CATEGORY] like ''ORD'' then ''ORDER''
			when [DOC_CATEGORY] like ''PER'' then ''PERMIT''
			when [DOC_CATEGORY] like ''PET'' then ''PETITION''
			when [DOC_CATEGORY] like ''POA'' then ''POWER OF ATTORNEY''
			when [DOC_CATEGORY] like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [DOC_CATEGORY] like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''PRO'' then ''PROBATE''
			when [DOC_CATEGORY] like ''PTR'' then ''PARTNERSHIP''
			when [DOC_CATEGORY] like ''RED'' then ''NOTICE OF REDEMPTION''
			when [DOC_CATEGORY] like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [DOC_CATEGORY] like ''REQ'' then ''REQUEST''
			when [DOC_CATEGORY] like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [DOC_CATEGORY] like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [DOC_CATEGORY] like ''RQN'' then ''REQUEST FOR NOTICE''
			when [DOC_CATEGORY] like ''RSL'' then ''RESOLUTION''
			when [DOC_CATEGORY] like ''SBT'' then ''SUBSTITUTION''
			when [DOC_CATEGORY] like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [DOC_CATEGORY] like ''SLN'' then ''STATE TAX LIEN''
			when [DOC_CATEGORY] like ''STM'' then ''STATEMENT''
			when [DOC_CATEGORY] like ''STP'' then ''STIPULATION''
			when [DOC_CATEGORY] like ''STR'' then ''SUBSTITUTION''
			when [DOC_CATEGORY] like ''SUI'' then ''SUIT''
			when [DOC_CATEGORY] like ''SUP'' then ''SUPPORT''
			when [DOC_CATEGORY] like ''TNM'' then ''TRADE NAME''
			when [DOC_CATEGORY] like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [DOC_CATEGORY] like ''UCC'' then ''FINANCING STATEMENT''
			when [DOC_CATEGORY] like ''UNU'' then ''UNUSED BY COUNTY''
			when [DOC_CATEGORY] like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [DOC_CATEGORY] like ''VIT'' then ''VITAL''
			when [DOC_CATEGORY] like ''VLN'' then ''VENDORS LIEN''
			when [DOC_CATEGORY] like ''VOI'' then ''VIOLATION''
			when [DOC_CATEGORY] like ''WAI'' then ''WAIVER''
			when [DOC_CATEGORY] like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			else [DOC_CATEGORY] end


			
			Select DOC_CATEGORY, count(*) From x_Custom_OUTPUT_S28
			where [# of Recordings] > 0
			Group by DOC_CATEGORY
			Order by DOC_CATEGORY

			
			')

			END

			
			Select top 1000 [Input UniqueID],[# of Recordings],[Record #], *
			From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] A
			where [# of Recordings] > 0
			Order by convert(int,A.[# of Recordings] ) desc,A.[Input UniqueID],convert(int,A.[Record #]) desc

		
		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Set [Run Date] = convert(date,getdate())

		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] 
		SET [INVL Coverage Status] = CASE WHEN [INVL Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_ValonMortgage].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a JOIN [zCust_ValonMortgage].[dbo].[a_ASP_IN_STD] b
		on a.[Input UniqueID] = b.Raw_ID
	


		Update [zCust_ValonMortgage].[dbo].[A]
		SET 
		A.[Property Status] = CASE WHEN 
		(B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END
		From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] as A 
		join [zCust_ValonMortgage].[dbo].[a_PropMatch_Work_FLANK] as B on a.[Input UniqueID] = b.RAW_ID
	

		UPDATE [zCust_ValonMortgage].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28] a join [zCust_ValonMortgage].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[Input UniqueID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		and (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

	


		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		SET [EVEnt Status] = case when [# of Recordings] > 0	THEN 'Event Found' ELSE 'Event Not Found' END
		
		
		Select [Property Status], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Address Standardization]

		Select [INVL Coverage Status], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [INVL Coverage Status]

		Select [Event Status ], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Event Status ]


		Select [Input UniqueID], count(*) From (
		Select [Input UniqueID],[Property Status],count(*) T From  [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Input UniqueID],[Property Status]
		--ORder by [Input UniqueID],[PropertyStatus]
		)A
		Group by [Input UniqueID]
		having count(*) > 1


		
		Select [Property Status], count(*) From (
		Select [Input UniqueID],[Property Status],count(*) T From  [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		Group by [Input UniqueID],[Property Status]
		--ORder by [Input UniqueID],[PropertyStatus]
		)A
		Group by [Property Status]
		Order by [Property Status]

		Select * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S28]
		--where [Input UniqueID] = 'bz2023 1136919'
		



END



