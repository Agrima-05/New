/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.Determine_Doc_id_to_run | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[Determine_Doc_id_to_run] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
/*
DECLARE	@return_value int,
		@ERROR varchar(500)

EXEC	lien_DTDB.[INFC].[drop_create_deed_tables]
		@ERROR = @ERROR OUTPUT
*/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'Determine_Doc_id_to_run'
		,N'Started'

	--
	--
	--
	-- get daily input from Lien_db
	--
	DECLARE @date DATETIME2 = (
			SELECT TOP 1 m_create_date
			FROM [lien].[ur].[document] d WITH (NOLOCK)
			ORDER BY doc_id DESC
			)

	TRUNCATE TABLE [lien_dtdb].[tmp].[reprocess_records_to_be_processed]


	INSERT INTO [LIEN_DTDB].[tmp].[reprocess_records_to_be_processed] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,[previous_doc_unique_id]
		,[update_type]
		,[doc_title]
		,[doc_type]
		,[dtdb_fix]
		)
	SELECT DISTINCT d.doc_id
		,d.m_update_date AS m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.[previous_doc_unique_id]
		,d.[update_type]
		,d.[doc_title]
		,d.[doc_type]
		,case when f.doc_id is not null then 1 else 0 end as dtdb_fix
	FROM [lien].[ur].[document] d WITH (NOLOCK,INDEX (PK_DOCUMENT))
	left join [lien_dtdb].[dbo].[DTDB_DocIdExtract_fix] f with(nolock,index(idx_doc_id)) on f.doc_id = d.doc_id
	outer apply (select case when substring(fips_code,3,3) >= '900' then 'IGNORE' else 'TAKE' end as fake_fips) dz 
	--WHERE d.m_create_date BETWEEN dateadd(hour, - 4, dateadd(day, - 1, @date))
	--		AND @date
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM [Lien].[dbo].[INFC_DocIdExtract]
			union 
			Select doc_id
			from [lien_dtdb].[dbo].[DTDB_DocIdExtract_fix]
			)

		AND m_status_id < 3
		AND d.source IN (
			'EPR'
			,'REDX'
			)
		AND d.doc_type IN (
			SELECT UR_VALUE AS Doc_type
			FROM [Lien_dtdb].[dbo].[UR_Document_Types] dt
			WHERE (dt.Delete_date IS NULL or dt.Delete_date > d.Recording_Date_D)
			and isnull(dt.deed_type,'') <> 'Z'
			
		    UNION ALL
			
			SELECT UR_DOC_TYPE AS Doc_type
			FROM [lien_DTDB].[dbo].[UR_RAS_Doc_Types] dt
			WHERE (dt.Delete_date IS NULL or dt.Delete_date > d.Recording_Date_D)
			
			UNION ALL
			
			SELECT Doc_type
			FROM [lien_dtdb].[dbo].[UR_PFC_Doc_Types] dt
			WHERE (dt.Delete_date IS NULL or dt.Delete_date > d.Recording_Date_D)
			)
		and dz.fake_fips = 'TAKE'

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'Determine_Doc_id_to_run'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


