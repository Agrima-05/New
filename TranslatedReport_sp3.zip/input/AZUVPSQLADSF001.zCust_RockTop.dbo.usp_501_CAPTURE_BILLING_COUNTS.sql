SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_RockTop].[dbo].[usp_501_CAPTURE_BILLING_COUNTS] 
	
AS
BEGIN

	SET NOCOUNT ON;



	----Fees - Initial portfolio baseline = $6,688.20 for up to 150k Input records
	----; Monthly Monitoring fee = $3,344.10 for up to 150k Input records; $5573.50 for up to 150,001-250,000 Input records

	 -----------------BILLING COUNTS-------------

		INSERT INTO [zCust_RockTop].[dbo].[INPUT_MONITOR_BILLING]([INPUTKEY]
      ,[ADDRESS]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[Start Date]
      ,[Monitoring Type]
      ,[DATE_RECEIVED]
      ,[DATE_DELETED]
      ,[FIPS]
      ,[PROPERTYID]
      ,[MAX_FATIMESTAMP]
      ,[PropertyStatus]
      ,[AddressStandardization])
		SELECT [INPUTKEY]
      ,[ADDRESS]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[Start Date]
      ,[Monitoring Type]
      ,[DATE_RECEIVED]
      ,[DATE_DELETED]
      ,[FIPS]
      ,[PROPERTYID]
      ,[MAX_FATIMESTAMP]
      ,[PropertyStatus]
      ,[AddressStandardization]
		FROM     [zCust_RockTop].[dbo].[INPUT_MONITOR]
		



END


