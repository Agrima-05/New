/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_MINING_CLAIM_Multi_Legals_INCR | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================      
-- Author:        <Author,,Name>      
-- Create date: <Create Date,,>      
-- Description:   <Description,,>      
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'      
-- =============================================      
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_MINING_CLAIM_Multi_Legals_INCR] @fips INT
	,@FeatureName AS VARCHAR(50)
	,@ServiceName AS VARCHAR(50)
	,@FormatId AS VARCHAR(10)
	,@Incremental_Flag BIT
AS
DECLARE @GetDynamicFormat tmpGetDynamicFormat

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_MINING_CLAIM_Multi_Legals_INCR'
	,N'Started'

INSERT INTO @GetDynamicFormat (
	[FeatureName]
	,[ServiceName]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[OutputField]
	,[LongDesc]
	,[Label]
	,[MsgLabel]
	,[Partner]
	,[PartnerType]
	,[WildStart]
	,[DataType]
	,[Required]
	,[Enumeration]
	,[TabIndex]
	,[FromField]
	,[DataTreeIndexes]
	,[FormatChar]
	,[_overlay]
	,[ROW4]
	)
EXEC [pet].[dbo].[GetDynamicFormat] @FeatureName --'TITLE_SERVICES'      
	,@ServiceName --'SUBDIVIDED'      
	,@FormatId --@PPLNT_PLAT_ID_FRMT      

UPDATE [PET].[pet_dbo].[t1]
SET t1._overlay = (
		SELECT count(1)
		FROM @GetDynamicFormat t2
		WHERE t2.ROW4 < t1.ROW4
			AND t1.Offset BETWEEN t2.Offset
				AND (t2.Offset + t2.[Length])
		)
FROM @GetDynamicFormat t1

SELECT 'ARB parms' AS aaaa
	,*
FROM @GetDynamicFormat

DECLARE @year_pos INT = (
		SELECT p.offset
		FROM @GetDynamicFormat p
		WHERE p.Field = 'Year'
		)
	,@Ref_id INT = NULL --13580129      

--IF object_id('Tempdb..Pet.pet_tmp.Incr_MINING_CLAIM_Multi_Legals_INCR_Temp3') IS NOT NULL  
DROP TABLE

IF EXISTS [Pet].[pet_tmp].[Incr_MINING_CLAIM_Multi_Legals_INCR_Temp3];
	SELECT a.REF_ID
		,a.NEO_APN
		,a.NEO_LAND_TYPE
		,a.NEO_TITLE_LEGAL
		,a._field
		--,Replace(Replace(Replace(ltrim(a._value), 'T', ''), 'C', ''), 'M', '') AS _value      
		,a._value
		,a.fips
		,a.row4
		,'' AS bookType
	INTO [Pet].[pet_tmp].[Incr_MINING_CLAIM_Multi_Legals_INCR_Temp3]
	FROM (
		SELECT
			--top 100       
			t.REF_ID
			,t.NEO_APN
			,t.NEO_LAND_TYPE
			,t.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL
			,Field AS _field
			,p.ROW4
			,substring(t.NEO_TITLE_LEGAL, Offset, [Length]) AS _value
			,t.fips
	FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (
				NOLOCK
				,INDEX (idx_fips_neoAPN)
				)
		cross APPLY (
			SELECT *
			FROM [pet].[dbo].[PET_neo_legals] t WITH (
					NOLOCK
					,INDEX (ix_fipsNEO)
					)
			WHERE t.fips = incr.fips
				AND t.neo_apn = incr.neo_apn
				and t.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
				AND t.NEO_LAND_TYPE IN ('MC')
			) t
		OUTER APPLY (
			SELECT *
			FROM @GetDynamicFormat -- where _overlay = 0       
			) p
	
		WHERE incr.fips = @fips
			AND incr.NEO_LAND_TYPE IN ('MC')
			--AND (  
			-- @Incremental_flag = 0  
			-- OR (  
			--  @Incremental_flag = 1  
			--  AND incr.neo_apn IS NOT NULL  
			--  )  
			-- )  
		) a
	WHERE isnull(a._value, '') > ''

--Select * from #temp      
CREATE UNIQUE INDEX ix_ref_id_field ON [Pet].[pet_tmp].[Incr_MINING_CLAIM_Multi_Legals_INCR_Temp3] (
	Fips
	,REF_ID
	,NEO_APN
	,NEO_TITLE_LEGAL
	,_field
	)

BEGIN TRANSACTION

INSERT INTO [PET].[dbo].[Pet_LabelColumns_Multi_Legals] (
	[REF_ID]
	,NEO_APN
	,[NEO_LAND_TYPE]
	,[NEO_TITLE_LEGAL]
	,[_field]
	,[_value]
	,fips
	,ROW4
	,bookType
	)
SELECT b.[REF_ID]
	,b.NEO_APN
	,b.[NEO_LAND_TYPE]
	,b.[NEO_TITLE_LEGAL]
	,b.[_field]
	,b.[_value]
	,b.fips
	,b.ROW4
	,b.bookType
FROM [Pet].[pet_tmp].[Incr_MINING_CLAIM_Multi_Legals_INCR_Temp3] b WITH (
		NOLOCK
		,INDEX (ix_ref_id_field)
		)
LEFT JOIN [PET].[dbo].[Pet_LabelColumns_Multi_Legals] c WITH (
		NOLOCK
		,INDEX (ix_FipsREfIDFieldValue)
		) ON c.Fips = b.Fips
	AND c.REF_ID = b.REF_ID
	AND c.NEO_APN = b.NEO_APN
	AND c.NEO_TITLE_LEGAL = b.NEO_TITLE_LEGAL
	AND c._field = b._field
WHERE c.ref_id IS NULL

COMMIT

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_MINING_CLAIM_Multi_Legals_INCR'
	,N'Ended'


