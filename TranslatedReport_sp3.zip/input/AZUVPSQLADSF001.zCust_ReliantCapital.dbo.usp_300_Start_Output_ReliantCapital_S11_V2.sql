SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_ReliantCapital].[dbo].[usp_300_Start_Output_ReliantCapital_S11_V2]


AS
BEGIN
	
	SET NOCOUNT ON;

	----20240716 - Per EC - ONLY run the  "-" records through S85---

	

		DROP TABLE [dbo].[x_Custom_OUTPUT_S11_V2]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S11_V2](
			[FIPS][varchar](5)NULL,
			[PROPERTYID][varchar](250)NULL,
			
			[INPUT Unique ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[PreForeclosure Coverage ][varchar](250)NULL,
			[Preforeclosure Thru Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Current Owner Doc Type][varchar](250)NULL,

			----20260205 Moved to Vertical layout----
			[Record Nbr][varchar](250) NULL,
			[PFCLRecording Date][varchar](250) NULL,
			[PFCLDocument Number][varchar](250) NULL,
			[PFCLDocument Type][varchar](250) NULL,
			[PFCLValue][varchar](250) NULL,
			[PFCLBorrower][varchar](250) NULL,
			[PFCLOriginal Recording Date][varchar](250) NULL,
			[PFCLOriginal Document Nbr][varchar](250) NULL,
			[PFCLOriginal Loan Amount][varchar](250) NULL,
			[PFCLTrusteeTelephoneNumber][varchar](250) NULL,
			[PFCLTrusteeFullStreetAddress][varchar](250) NULL,
			[PFCLTrusteeUnitNumber][varchar](250) NULL,
			[PFCLTrusteeCityName][varchar](250) NULL,
			[PFCLTrusteeStateCode][varchar](250) NULL,
			[PFCLTrusteeZipCode][varchar](250) NULL,
			[PFCLTrusteeZipplus4][varchar](250) NULL,
			[PFCLTrusteeFirstName&MiddleInitial][varchar](250) NULL,
			[PFCLTrusteeLastNameORCorporationName][varchar](250) NULL,
			[PFCLTrusteeCareofName][varchar](250) NULL,
			[PFCLTrusteeSaleNumber][varchar](250) NULL,
			[PFCLAuction Date][varchar](250) NULL,



			----------INTERNAL---------
			[Start Date][varchar](250)Null,
			[MAX_PFC_RECDATE]	[varchar](250)NULL,
			[Nbr of Transactions][varchar](250)Null
					
			
		) ON [PRIMARY]

		

	
		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] (
		  [INPUT Unique ID],
		  [INPUT Address],
			[INPUT City],
			[INPUT State],
			[INPUT Zip],
			FIPS,
			PROPERTYID,
			[MAX_PFC_RECDATE],
			[Start Date]  )
	
		Select 	
		[INPUTKEY]
		,[Address]
		,[City]
		,[State]
		,[ZipCODE]
		,FIPS
		,[PROPERTYID]
		,[MAX_PFC_RECDATE]
		,convert(Date,[Monitoring START DATE])
		--Select * 
	   
	   FROM [zCust_ReliantCapital].[dbo].[INPUT_MONITOR]
		where [Record Indicator] not like 'D'
		and [INPUTKEY] is not null
		and INPUTKEY not like '%-%'
		--and DATE_RECEIVED = convert(Date,getdate())
		


		  
	  
	  Select top 100 * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S11_V2 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S11_V2 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[Input Unique ID] = c.RAW_ID

		

		Update [zCust_ReliantCapital].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN [zCust_ReliantCapital].[dbo].[a_ASP_IN_STD] c
					ON a.[Input Unique ID] = c.RAW_ID


		
		Update [zCust_ReliantCapital].[dbo].[a]
		set 
		[PreForeclosure Coverage ] = B.ForeclosureActive
		--[PreForeclosure Coverage ] = B.ForeclosureActive
		,A.[Preforeclosure Thru Date] = convert(date,B.ForeclosureMaxRecordDate)
		--,A.[Deed Coverage] = B.DeedActive
		--,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE



		
		Update [zCust_ReliantCapital].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
			FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID



				
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_ReliantCapital].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_ReliantCapital].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_ReliantCapital].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

	
	
		------------------------------------------------------------------------

		   Update [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK] 
		   SET toUse = NULL
		   where toUse is not null

		 

		   ----PFC records---
		   ------20240715 - Per EC - Return All PFC recordings after their input date
		 
			UPDATE [zCust_ReliantCapital].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[Input Unique ID], B.[INPUT Start Date], A.PropertyID,A.Doc_Id,DocumentTypeDesc--, C.*
			FROM [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK] a JOIN [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] as B on 
			A.RAW_ID = B.[Input Unique ID]  
			join [zCust_ReliantCapital].[dbo].[w_FLANK_NOD] as C on A.RAW_ID = C.RAW_ID and A.Doc_Id = C.TransactionId
			left outer join [data].[dbo].[PROPERTY] as D with(NOLOCK) on B.FIPS = D.FIPS and B.PropertyID = D.PropertyiD
			where Doc_Src_Ind like 'R'
			and DocumentTypeDesc not like 'RELEASE' and DocumentTypeDesc not like 'Assignment%'
			and convert(date,A.recordingdate) >  convert(date,B.[Start Date])
			AND (convert(date,A.recordingdate) > B.MAX_PFC_RECDATE
			OR B.MAX_PFC_RECDATE is null)


		
		
	

		

		Truncate table [dbo].w_TransHist_FLANK_II

		INSERT INTO [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
						Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
						FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
						LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate,[PROPERTYID],REO,REOSALE )
		SELECT  Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
						Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
						FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
						LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate ,[PROPERTYID],REO,REOSALE
		FROM     [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK]
		WHERE  (ToUse = 'Y')


			UPDATE [zCust_ReliantCapital].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC) AS RowNum
				FROM 
			[zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II]
		Order by RAW_ID, RecordingDate

		Select * From [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Set [Nbr of Transactions] = NULL

		UPDATE [zCust_ReliantCapital].[dbo].[a]
		SET a.[Nbr of Transactions] = b.NbrOfRecordings
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings 
		FROM [zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) b
		on a.[Input Unique ID] = b.RAW_ID

		Select max(convert(int,[Nbr of Transactions])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]

		
		IF (Select max(convert(int,[Nbr of Transactions])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]) > 0 

		BEGIN


		
					UPDATE [zCust_ReliantCapital].[dbo].[a]
					SET 
					A.[Record Nbr] = b.REcordNumber
				
					,A.[PFCLRecording Date] = b.RecordingDate
					,A.[PFCLDocument Number] = b.DocumentNbr
					,A.[PFCLDocument Type] = b.DocumentType
					,A.[PFCLValue] = C.UNPAIDBALANCE
					,A.[PFCLBorrower] = b.BuyerBorrower
					,A.[PFCLOriginal Recording Date] = convert(date,b.OrigTransRecDate)
					,A.[PFCLOriginal Document Nbr] = b.OrigTransDocNumber
					,A.[PFCLOriginal Loan Amount] = C.OrigLoanAmt
					,A.[PFCLTrusteeTelephoneNumber] = C.TrusteePhone
					,A.[PFCLTrusteeFullStreetAddress] = C.TrusteeFullAddress
					,A.[PFCLTrusteeUnitNumber] = C.TrusteeAptNumber
					,A.[PFCLTrusteeCityName] = C.TrusteeCity
					,A.[PFCLTrusteeStateCode] = C.TrusteeState
					,A.[PFCLTrusteeZipCode] = C.TrusteeZip5
					,A.[PFCLTrusteeZipplus4] = C.TrusteeZip4
					,A.[PFCLTrusteeFirstName&MiddleInitial] = C.TrusteeFirstNameMiddleInitial
					,A.[PFCLTrusteeLastNameORCorporationName] = C.TrusteeLastNameorCorp
					,A.[PFCLTrusteeCareofName] = C.TrusteeMailCareOfName
					,A.[PFCLTrusteeSaleNumber] = C.TrusteeSalesNumber
					,A.[PFCLAuction Date] = C.AuctionDate


					--Select B.* , C.*
					FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN 
					[zCust_ReliantCapital].[dbo].[w_TransHist_FLANK_II] as B on 
					a.[Input Unique ID] = b.RAW_ID
					join [zCust_ReliantCapital].[dbo].[w_FLANK_NOD] as C on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
					and B.DOC_ID = C.Transactionid
					AND B.REcordNumber = '1' 

			

				----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[Nbr of Transactions])) from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ReliantCapital].[sys].[tables] as A join [zCust_ReliantCapital].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S11_V2'
			and B.Name not in ('Record Nbr','PFCLRecording Date','PFCLDocument Number','PFCLDocument Type','PFCLValue','PFCLBorrower',
'PFCLOriginal Recording Date','PFCLOriginal Document Nbr','PFCLOriginal Loan Amount','PFCLTrusteeTelephoneNumber','PFCLTrusteeFullStreetAddress',
'PFCLTrusteeUnitNumber','PFCLTrusteeCityName','PFCLTrusteeStateCode','PFCLTrusteeZipCode','PFCLTrusteeZipplus4','PFCLTrusteeFirstName&MiddleInitial',
'PFCLTrusteeLastNameORCorporationName','PFCLTrusteeCareofName','PFCLTrusteeSaleNumber','PFCLAuction Date')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.BUILD_DOWN_COLUMNS


				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ReliantCapital].[dbo].[BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[Nbr of Transactions])) FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S11_V2(
												' +  @FIELDLIST3 + '

												  ,[Record Nbr]
												  ,[PFCLRecording Date]
													,[PFCLDocument Number]
													,[PFCLDocument Type]
													,[PFCLValue]
													,[PFCLBorrower]
													,[PFCLOriginal Recording Date]
													,[PFCLOriginal Document Nbr]
													,[PFCLOriginal Loan Amount]
													,[PFCLTrusteeTelephoneNumber]
													,[PFCLTrusteeFullStreetAddress]
													,[PFCLTrusteeUnitNumber]
													,[PFCLTrusteeCityName]
													,[PFCLTrusteeStateCode]
													,[PFCLTrusteeZipCode]
													,[PFCLTrusteeZipplus4]
													,[PFCLTrusteeFirstName&MiddleInitial]
													,[PFCLTrusteeLastNameORCorporationName]
													,[PFCLTrusteeCareofName]
													,[PFCLTrusteeSaleNumber]
													,[PFCLAuction Date]
												 )
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												, b.REcordNumber
												, b.RecordingDate
												, b.DocumentNbr
												, b.DocumentType
												, C.UNPAIDBALANCE
												, b.BuyerBorrower
												, convert(date,b.OrigTransRecDate)
												, b.OrigTransDocNumber
												, C.OrigLoanAmt
												, C.TrusteePhone
												, C.TrusteeFullAddress
												, C.TrusteeAptNumber
												, C.TrusteeCity
												, C.TrusteeState
												, C.TrusteeZip5
												, C.TrusteeZip4
												, C.TrusteeFirstNameMiddleInitial
												, C.TrusteeLastNameorCorp
												, C.TrusteeMailCareOfName
												, C.TrusteeSalesNumber
												, C.AuctionDate

												
										--Select B.REcordNumber 	
										FROM x_Custom_OUTPUT_S11_V2 a JOIN 
										w_TransHist_FLANK_II as B on 
										a.[Input Unique ID] = b.RAW_ID
										join w_FLANK_NOD as C on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
										and B.DOC_ID = C.Transactionid
										WHERE B.REcordNumber = ''' + @BeginNbrOfTrans6 + '''
										AND A.[Record Nbr] = ''1''
										
										
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END



					
					Update [zCust_ReliantCapital].[dbo].[A]
					SET A.[PFCLDocument Type] = Upper(b.[Codedesc])
					from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a join [Global].[dbo].[lkup_Doc_Type] b with(NOLOCK)
					ON A.[PFCLDocument Type] = b.[DocTypeID]
					
		END

		Select top 100 [INPUT Unique ID],[Nbr of Transactions], [Record Nbr],[PFCLRecording Date]
		From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Order by  convert(int,[Nbr of Transactions]) desc,[INPUT Unique ID], [Record Nbr]  desc

		
		--Declare @BeginNbrOfTrans int
		--Declare @EndNbrOfTrans int

		--SET @BeginNbrOfTrans = 1
		--Select @EndNbrOfTrans = case when max(convert(int,[Nbr of Transactions])) is null then 1 else  
		--max(convert(int,[Nbr of Transactions])) end FROM x_Custom_OUTPUT_S11_V2
		

		--	WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
		--		BEGIN
				 
		--			DECLARE @RecNbr as varchar(5)
		--			SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [Record Nbr_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLRecording Date_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLDocument Number_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLDocument Type_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLValue_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLBorrower_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLOriginal Recording Date_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLOriginal Document Nbr_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLOriginal Loan Amount_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeTelephoneNumber_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeFullStreetAddress_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeUnitNumber_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeCityName_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeStateCode_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeZipCode_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeZipplus4_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeFirstName&MiddleInitial_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeLastNameORCorporationName_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeCareofName_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLTrusteeSaleNumber_' + @RecNbr + '] [varchar](250) NULL')
		--		EXEC('ALTER Table x_Custom_OUTPUT_S11_V2 ADD [PFCLAuction Date_' + @RecNbr + '] [varchar](250) NULL')

				
		--			EXEC('UPDATE a
		--			SET 
		--			A.[Record Nbr_' + @RecNbr + '] = b.REcordNumber
				
		--			,A.[PFCLRecording Date_' + @RecNbr + '] = b.RecordingDate
		--			,A.[PFCLDocument Number_' + @RecNbr + '] = b.DocumentNbr
		--			,A.[PFCLDocument Type_' + @RecNbr + '] = b.DocumentType
		--			,A.[PFCLValue_' + @RecNbr + '] = C.UNPAIDBALANCE
		--			,A.[PFCLBorrower_' + @RecNbr + '] = b.BuyerBorrower
		--			,A.[PFCLOriginal Recording Date_' + @RecNbr + '] = convert(date,b.OrigTransRecDate)
		--			,A.[PFCLOriginal Document Nbr_' + @RecNbr + '] = b.OrigTransDocNumber
		--			,A.[PFCLOriginal Loan Amount_' + @RecNbr + '] = C.OrigLoanAmt
		--			,A.[PFCLTrusteeTelephoneNumber_' + @RecNbr + '] = C.TrusteePhone
		--			,A.[PFCLTrusteeFullStreetAddress_' + @RecNbr + '] = C.TrusteeFullAddress
		--			,A.[PFCLTrusteeUnitNumber_' + @RecNbr + '] = C.TrusteeAptNumber
		--			,A.[PFCLTrusteeCityName_' + @RecNbr + '] = C.TrusteeCity
		--			,A.[PFCLTrusteeStateCode_' + @RecNbr + '] = C.TrusteeState
		--			,A.[PFCLTrusteeZipCode_' + @RecNbr + '] = C.TrusteeZip5
		--			,A.[PFCLTrusteeZipplus4_' + @RecNbr + '] = C.TrusteeZip4
		--			,A.[PFCLTrusteeFirstName&MiddleInitial_' + @RecNbr + '] = C.TrusteeFirstNameMiddleInitial
		--			,A.[PFCLTrusteeLastNameORCorporationName_' + @RecNbr + '] = C.TrusteeLastNameorCorp
		--			,A.[PFCLTrusteeCareofName_' + @RecNbr + '] = C.TrusteeMailCareOfName
		--			,A.[PFCLTrusteeSaleNumber_' + @RecNbr + '] = C.TrusteeSalesNumber
		--			,A.[PFCLAuction Date_' + @RecNbr + '] = C.AuctionDate


		--			--Select B.* , C.*
		--			FROM x_Custom_OUTPUT_S11_V2 a JOIN 
		--			w_TransHist_FLANK_II as B on 
		--			a.[Input Unique ID] = b.RAW_ID
		--			join w_FLANK_NOD as C on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
		--			and B.DOC_ID = C.Transactionid
		--			AND B.REcordNumber = ' + @BeginNbrOfTrans + '') 

									

		--			EXEC('
		--			Update A
		--			SET A.[PFCLDocument Type_' + @RecNbr + '] = Upper(b.[Codedesc])
		--			from x_Custom_OUTPUT_S11_V2 a join [Global].[dbo].[lkup_Doc_Type] b with(NOLOCK)
		--			ON A.[PFCLDocument Type_' + @RecNbr + '] = b.[DocTypeID]
		--			')


							


		--			SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
		--		END


		--END

		----------------------

		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] 
		SET [PreForeclosure Coverage ] = CASE WHEN [PreForeclosure Coverage ] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_ReliantCapital].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a JOIN [zCust_ReliantCapital].[dbo].[a_ASP_IN_STD] b
		on a.[Input Unique ID] = b.Raw_ID

		Update [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ReliantCapital].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2] a join [zCust_ReliantCapital].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[Input Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

	
		Update  [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Set [Event Status] = case when [Nbr of Transactions] > 0 then  'Event Found' else 'Event Not Found'
		end
		


		Select * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		where [Nbr of Transactions] > 0 and 
		[Event Status] = 'Event Not Found' 
		

		
		Select [Property Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Group by [Address Standardization]

		Select [Event Status], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Group by [Event Status]

		
		Select [PreForeclosure Coverage ], count(*) From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Group by [PreForeclosure Coverage ]

		Select * from [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		where [Property Status] like 'Property Not Found'

		Select top 1000 * From [zCust_ReliantCapital].[dbo].[x_Custom_OUTPUT_S11_V2]
		Order by convert(int,[Nbr of Transactions]) desc

	
	

END





