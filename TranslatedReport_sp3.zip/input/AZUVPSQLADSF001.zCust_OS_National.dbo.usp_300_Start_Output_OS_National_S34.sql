SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_300_Start_Output_OS_National_S34]


AS
BEGIN
	
	SET NOCOUNT ON;



		DROP TABLE [dbo].[x_Custom_OUTPUT_S34]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S34](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			
			[PROPERTYID][varchar](250)NULL,
			[INPUTKEY][varchar](250)NULL,
			[INPUT_Customer ID][varchar](250)NULL,
			[INPUT_Reference ID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[INPUT_CURRENTOWNER][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
		
			[HOA 1- Name][varchar](250)NULL,
			[HOA 1 - Type][varchar](250)NULL,
			[HOA 1- Contact Type 1][varchar](250)NULL,
			[HOA 1- Contact Name 1][varchar](250)NULL,
			[HOA 1- Address (Mailing)  1][varchar](250)NULL,
			[HOA 1- City (Mailing) 1][varchar](250)NULL,
			[HOA 1- State (Mailing) 1][varchar](250)NULL,
			[HOA 1- Zip (Mailing)  1][varchar](250)NULL,
			[HOA 1- Contact Cell Phone 1][varchar](250)NULL,
			[HOA 1- Contact Business Phone 1][varchar](250)NULL,
			[HOA 1- Contact Email 1][varchar](250)NULL,
			[HOA 1- Contact Type 2][varchar](250)NULL,
			[HOA 1- Contact Name 2][varchar](250)NULL,
			[HOA 1- Address (Mailing) 2][varchar](250)NULL,
			[HOA 1- City (Mailing) 2][varchar](250)NULL,
			[HOA 1- State (Mailing)2][varchar](250)NULL,
			[HOA 1- Zip (Mailing) 2][varchar](250)NULL,
			[HOA 1- Contact Cell Phone 2][varchar](250)NULL,
			[HOA 1- Contact Business Phone 2][varchar](250)NULL,
			[HOA 1- Contact Email 2][varchar](250)NULL,
			[HOA 1- Contact Type 3][varchar](250)NULL,
			[HOA 1- Contact Name 3][varchar](250)NULL,
			[HOA 1- Address (Mailing) 3][varchar](250)NULL,
			[HOA 1- City (Mailing) 3][varchar](250)NULL,
			[HOA 1- State (Mailing)3][varchar](250)NULL,
			[HOA 1- Zip (Mailing) 3][varchar](250)NULL,
			[HOA 1- Contact Cell Phone 3][varchar](250)NULL,
			[HOA 1- Contact Business Phone 3][varchar](250)NULL,
			[HOA 1- Contact Email 3][varchar](250)NULL,
			[HOA 1- Fee Value][varchar](250)NULL,
			[HOA 1- Fee Minimum Value][varchar](250)NULL,
			[HOA 1- Fee Maximum Value][varchar](250)NULL,
			[HOA 1- Fee Type][varchar](250)NULL,
			[HOA 1 - Fee Frequency][varchar](250)NULL,

				[HOA 2- Name][varchar](250)NULL,
			[HOA 2 - Type][varchar](250)NULL,
			[HOA 2- Contact Type 1][varchar](250)NULL,
			[HOA 2- Contact Name 1][varchar](250)NULL,
			[HOA 2- Address (Mailing)  1][varchar](250)NULL,
			[HOA 2- City (Mailing) 1][varchar](250)NULL,
			[HOA 2- State (Mailing) 1][varchar](250)NULL,
			[HOA 2- Zip (Mailing)  1][varchar](250)NULL,
			[HOA 2- Contact Cell Phone 1][varchar](250)NULL,
			[HOA 2- Contact Business Phone 1][varchar](250)NULL,
			[HOA 2- Contact Email 1][varchar](250)NULL,
			[HOA 2- Contact Type 2][varchar](250)NULL,
			[HOA 2- Contact Name 2][varchar](250)NULL,
			[HOA 2- Address (Mailing) 2][varchar](250)NULL,
			[HOA 2- City (Mailing) 2][varchar](250)NULL,
			[HOA 2- State (Mailing)2][varchar](250)NULL,
			[HOA 2- Zip (Mailing) 2][varchar](250)NULL,
			[HOA 2- Contact Cell Phone 2][varchar](250)NULL,
			[HOA 2- Contact Business Phone 2][varchar](250)NULL,
			[HOA 2- Contact Email 2][varchar](250)NULL,
			[HOA 2- Contact Type 3][varchar](250)NULL,
			[HOA 2- Contact Name 3][varchar](250)NULL,
			[HOA 2- Address (Mailing) 3][varchar](250)NULL,
			[HOA 2- City (Mailing) 3][varchar](250)NULL,
			[HOA 2- State (Mailing)3][varchar](250)NULL,
			[HOA 2- Zip (Mailing) 3][varchar](250)NULL,
			[HOA 2- Contact Cell Phone 3][varchar](250)NULL,
			[HOA 2- Contact Business Phone 3][varchar](250)NULL,
			[HOA 2- Contact Email 3][varchar](250)NULL,
			[HOA 2- Fee Value][varchar](250)NULL,
			[HOA 2- Fee Minimum Value][varchar](250)NULL,
			[HOA 2- Fee Maximum Value][varchar](250)NULL,
			[HOA 2- Fee Type][varchar](250)NULL,
			[HOA 2 - Fee Frequency][varchar](250)NULL,
			
			[HOA 3- Name][varchar](250)NULL,
			[HOA 3 - Type][varchar](250)NULL,
			[HOA 3- Contact Type 1][varchar](250)NULL,
			[HOA 3- Contact Name 1][varchar](250)NULL,
			[HOA 3- Address (Mailing)  1][varchar](250)NULL,
			[HOA 3- City (Mailing) 1][varchar](250)NULL,
			[HOA 3- State (Mailing) 1][varchar](250)NULL,
			[HOA 3- Zip (Mailing)  1][varchar](250)NULL,
			[HOA 3- Contact Cell Phone 1][varchar](250)NULL,
			[HOA 3- Contact Business Phone 1][varchar](250)NULL,
			[HOA 3- Contact Email 1][varchar](250)NULL,
			[HOA 3- Contact Type 2][varchar](250)NULL,
			[HOA 3- Contact Name 2][varchar](250)NULL,
			[HOA 3- Address (Mailing) 2][varchar](250)NULL,
			[HOA 3- City (Mailing) 2][varchar](250)NULL,
			[HOA 3- State (Mailing)2][varchar](250)NULL,
			[HOA 3- Zip (Mailing) 2][varchar](250)NULL,
			[HOA 3- Contact Cell Phone 2][varchar](250)NULL,
			[HOA 3- Contact Business Phone 2][varchar](250)NULL,
			[HOA 3- Contact Email 2][varchar](250)NULL,
			[HOA 3- Contact Type 3][varchar](250)NULL,
			[HOA 3- Contact Name 3][varchar](250)NULL,
			[HOA 3- Address (Mailing) 3][varchar](250)NULL,
			[HOA 3- City (Mailing) 3][varchar](250)NULL,
			[HOA 3- State (Mailing)3][varchar](250)NULL,
			[HOA 3- Zip (Mailing) 3][varchar](250)NULL,
			[HOA 3- Contact Cell Phone 3][varchar](250)NULL,
			[HOA 3- Contact Business Phone 3][varchar](250)NULL,
			[HOA 3- Contact Email 3][varchar](250)NULL,
			[HOA 3- Fee Value][varchar](250)NULL,
			[HOA 3- Fee Minimum Value][varchar](250)NULL,
			[HOA 3- Fee Maximum Value][varchar](250)NULL,
			[HOA 3- Fee Type][varchar](250)NULL,
			[HOA 3 - Fee Frequency][varchar](250)NULL,

			[HOA 4- Name][varchar](250)NULL,
			[HOA 4 - Type][varchar](250)NULL,
			[HOA 4- Contact Type 1][varchar](250)NULL,
			[HOA 4- Contact Name 1][varchar](250)NULL,
			[HOA 4- Address (Mailing)  1][varchar](250)NULL,
			[HOA 4- City (Mailing) 1][varchar](250)NULL,
			[HOA 4- State (Mailing) 1][varchar](250)NULL,
			[HOA 4- Zip (Mailing)  1][varchar](250)NULL,
			[HOA 4- Contact Cell Phone 1][varchar](250)NULL,
			[HOA 4- Contact Business Phone 1][varchar](250)NULL,
			[HOA 4- Contact Email 1][varchar](250)NULL,
			[HOA 4- Contact Type 2][varchar](250)NULL,
			[HOA 4- Contact Name 2][varchar](250)NULL,
			[HOA 4- Address (Mailing) 2][varchar](250)NULL,
			[HOA 4- City (Mailing) 2][varchar](250)NULL,
			[HOA 4- State (Mailing)2][varchar](250)NULL,
			[HOA 4- Zip (Mailing) 2][varchar](250)NULL,
			[HOA 4- Contact Cell Phone 2][varchar](250)NULL,
			[HOA 4- Contact Business Phone 2][varchar](250)NULL,
			[HOA 4- Contact Email 2][varchar](250)NULL,
			[HOA 4- Contact Type 3][varchar](250)NULL,
			[HOA 4- Contact Name 3][varchar](250)NULL,
			[HOA 4- Address (Mailing) 3][varchar](250)NULL,
			[HOA 4- City (Mailing) 3][varchar](250)NULL,
			[HOA 4- State (Mailing)3][varchar](250)NULL,
			[HOA 4- Zip (Mailing) 3][varchar](250)NULL,
			[HOA 4- Contact Cell Phone 3][varchar](250)NULL,
			[HOA 4- Contact Business Phone 3][varchar](250)NULL,
			[HOA 4- Contact Email 3][varchar](250)NULL,
			[HOA 4- Fee Value][varchar](250)NULL,
			[HOA 4- Fee Minimum Value][varchar](250)NULL,
			[HOA 4- Fee Maximum Value][varchar](250)NULL,
			[HOA 4- Fee Type][varchar](250)NULL,
			[HOA 4 - Fee Frequency][varchar](250)NULL
			
		) ON [PRIMARY]

		


		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] (
		[INPUTKey]
		,[INPUT_Customer ID],
			[INPUT_Reference ID],
			[INPUT_ADDRESS],
			[INPUT_CITY],
			[INPUT_STATE],
			[INPUT_ZIPCODE],
			[FIPS],
			[PROPERTYID],
			[INPUT_CURRENTOWNER]
	   )
	
		Select 	INPUTKEY
		,CUSTOMERID
		,UNIQUEID
		,[Address]
		,[City]
		,[State]
		,[ZipCODE]
		,FIPS
		,[PROPERTYID]
		,[INPUT_OWNER]
   
       --Select * 
	   
	   FROM [zCust_OS_National].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null


	

	  		
		------********ONLY RUN FULL PORTFOLIO on 5th of month or next bus day****-------
		DECLARE @TODAY date = convert(date,getdate())
		DECLARE @5th date = (Select top 1  [CalendarDate] FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc) 

		
		IF @TODAY <> @5th
		BEGIN
		
		Delete from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] as A join [zCust_OS_National].[dbo].[INPUT_MONITOR] as B on 
		A.INPUTKEY = B.INPUTKEY
		where B.DATE_RECEIVED < convert(Date,getdate())


		END
	  
	  Select top 100 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S34 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S34 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUTKey] = c.RAW_ID

		

		Update [zCust_OS_National].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[RUN Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKey] = c.RAW_ID


		
		Update [zCust_OS_National].[dbo].[a]
		set 
		A.[Coverage Status] = B.HOAActive
		--,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE

	
		------------------------------------------------------------------------
		Update [zCust_OS_National].[dbo].[A]
		Set 
		A.[HOA 1- Name] = B.[HOA1Name]
		,A.[HOA 1 - Type] = B.[HOA1Type]
		,A.[HOA 1- Contact Type 1] = B.[HOA1ContactType1]
		,A.[HOA 1- Contact Name 1] = B.[HOA1ContactName1]
		,A.[HOA 1- Address (Mailing)  1] = B.HOA1Address1
		,A.[HOA 1- City (Mailing) 1] = B.HOA1City1
		,A.[HOA 1- State (Mailing) 1] = B.HOA1State1
		,A.[HOA 1- Zip (Mailing)  1] = B.HOA1Zip1
		,A.[HOA 1- Contact Cell Phone 1] = B.HOA1ContactCellPhone1
		,A.[HOA 1- Contact Business Phone 1] = B.HOA1ContactBusinessPhone1
		,A.[HOA 1- Contact Email 1] = B.[HOA1ContactEmail1]
		,A.[HOA 1- Contact Type 2] = B.[HOA1ContactType2]
		,A.[HOA 1- Contact Name 2] = B.[HOA1ContactName2]
		,A.[HOA 1- Address (Mailing) 2] = B.HOA1Address2
		,A.[HOA 1- City (Mailing) 2] = B.HOA1City2
		,A.[HOA 1- State (Mailing)2] = B.HOA1State2
		,A.[HOA 1- Zip (Mailing) 2] = B.HOA1Zip2
		,A.[HOA 1- Contact Cell Phone 2] = B.HOA1ContactCellPhone2
		,A.[HOA 1- Contact Business Phone 2] = B.HOA1ContactBusinessPhone2
		,A.[HOA 1- Contact Email 2] = B.[HOA1ContactEmail2]
		,A.[HOA 1- Contact Type 3] = B.[HOA1ContactType3]
		,A.[HOA 1- Contact Name 3] = B.[HOA1ContactName3]
		,A.[HOA 1- Address (Mailing) 3] = B.HOA1Address3
		,A.[HOA 1- City (Mailing) 3] = B.HOA1City3
		,A.[HOA 1- State (Mailing)3] = B.HOA1State3
		,A.[HOA 1- Zip (Mailing) 3] = B.HOA1Zip3
		,A.[HOA 1- Contact Cell Phone 3] = B.HOA1ContactCellPhone3
		,A.[HOA 1- Contact Business Phone 3] = B.HOA1ContactBusinessPhone3
		,A.[HOA 1- Contact Email 3] = B.[HOA1ContactEmail3]
		,A.[HOA 1- Fee Value] = B.[HOA1FeeValue]
		,A.[HOA 1- Fee Minimum Value] = B.[HOA1FeeMinimumValue]
		,A.[HOA 1- Fee Maximum Value] = B.[HOA1FeeMaximumValue]
		,A.[HOA 1- Fee Type] = B.[HOA1FeeType]
		,A.[HOA 1 - Fee Frequency] = B.[HOA1FeeFrequency]

		,A.[HOA 2- Name] = B.[HOA2Name]
		,A.[HOA 2 - Type] = B.[HOA2Type]
		,A.[HOA 2- Contact Type 1] = B.[HOA2ContactType1]
		,A.[HOA 2- Contact Name 1] = B.[HOA2ContactName1]
		,A.[HOA 2- Address (Mailing)  1] = B.HOA2Address1
		,A.[HOA 2- City (Mailing) 1] = B.HOA2City1
		,A.[HOA 2- State (Mailing) 1] = B.HOA2State1
		,A.[HOA 2- Zip (Mailing)  1] = B.HOA2Zip1
		,A.[HOA 2- Contact Cell Phone 1] = B.HOA2ContactCellPhone1
		,A.[HOA 2- Contact Business Phone 1] = B.HOA2ContactBusinessPhone1
		,A.[HOA 2- Contact Email 1] = B.[HOA2ContactEmail1]
		,A.[HOA 2- Contact Type 2] = B.[HOA2ContactType2]
		,A.[HOA 2- Contact Name 2] = B.[HOA2ContactName2]
		,A.[HOA 2- Address (Mailing) 2] = B.HOA2Address2
		,A.[HOA 2- City (Mailing) 2] = B.HOA2City2
		,A.[HOA 2- State (Mailing)2] = B.HOA2State2
		,A.[HOA 2- Zip (Mailing) 2] = B.HOA2Zip2
		,A.[HOA 2- Contact Cell Phone 2] = B.HOA2ContactCellPhone2
		,A.[HOA 2- Contact Business Phone 2] = B.HOA2ContactBusinessPhone2
		,A.[HOA 2- Contact Email 2] = B.[HOA2ContactEmail2]
		,A.[HOA 2- Contact Type 3] = B.[HOA2ContactType3]
		,A.[HOA 2- Contact Name 3] = B.[HOA2ContactName3]
		,A.[HOA 2- Address (Mailing) 3] = B.HOA2Address3
		,A.[HOA 2- City (Mailing) 3] = B.HOA2City3
		,A.[HOA 2- State (Mailing)3] = B.HOA2State3
		,A.[HOA 2- Zip (Mailing) 3] = B.HOA2Zip3
		,A.[HOA 2- Contact Cell Phone 3] = B.HOA2ContactCellPhone3
		,A.[HOA 2- Contact Business Phone 3] = B.HOA2ContactBusinessPhone3
		,A.[HOA 2- Contact Email 3] = B.[HOA2ContactEmail3]
		,A.[HOA 2- Fee Value] = B.[HOA2FeeValue]
		,A.[HOA 2- Fee Minimum Value] = B.[HOA2FeeMinimumValue]
		,A.[HOA 2- Fee Maximum Value] = B.[HOA2FeeMaximumValue]
		,A.[HOA 2- Fee Type] = B.[HOA2FeeType]
		,A.[HOA 2 - Fee Frequency] = B.[HOA2FeeFrequency]


		,A.[HOA 3- Name] = B.[HOA3Name]
		,A.[HOA 3 - Type] = B.[HOA3Type]
		,A.[HOA 3- Contact Type 1] = B.[HOA3ContactType1]
		,A.[HOA 3- Contact Name 1] = B.[HOA3ContactName1]
		,A.[HOA 3- Address (Mailing)  1] = B.HOA3Address1
		,A.[HOA 3- City (Mailing) 1] = B.HOA3City1
		,A.[HOA 3- State (Mailing) 1] = B.HOA3State1
		,A.[HOA 3- Zip (Mailing)  1] = B.HOA3Zip1
		,A.[HOA 3- Contact Cell Phone 1] = B.HOA3ContactCellPhone1
		,A.[HOA 3- Contact Business Phone 1] = B.HOA3ContactBusinessPhone1
		,A.[HOA 3- Contact Email 1] = B.[HOA3ContactEmail1]
		,A.[HOA 3- Contact Type 2] = B.[HOA3ContactType2]
		,A.[HOA 3- Contact Name 2] = B.[HOA3ContactName2]
		,A.[HOA 3- Address (Mailing) 2] = B.HOA3Address2
		,A.[HOA 3- City (Mailing) 2] = B.HOA3City2
		,A.[HOA 3- State (Mailing)2] = B.HOA3State2
		,A.[HOA 3- Zip (Mailing) 2] = B.HOA3Zip2
		,A.[HOA 3- Contact Cell Phone 2] = B.HOA3ContactCellPhone2
		,A.[HOA 3- Contact Business Phone 2] = B.HOA3ContactBusinessPhone2
		,A.[HOA 3- Contact Email 2] = B.[HOA3ContactEmail2]
		,A.[HOA 3- Contact Type 3] = B.[HOA3ContactType3]
		,A.[HOA 3- Contact Name 3] = B.[HOA3ContactName3]
		,A.[HOA 3- Address (Mailing) 3] = B.HOA3Address3
		,A.[HOA 3- City (Mailing) 3] = B.HOA3City3
		,A.[HOA 3- State (Mailing)3] = B.HOA3State3
		,A.[HOA 3- Zip (Mailing) 3] = B.HOA3Zip3
		,A.[HOA 3- Contact Cell Phone 3] = B.HOA3ContactCellPhone3
		,A.[HOA 3- Contact Business Phone 3] = B.HOA3ContactBusinessPhone3
		,A.[HOA 3- Contact Email 3] = B.[HOA3ContactEmail3]
		,A.[HOA 3- Fee Value] = B.[HOA3FeeValue]
		,A.[HOA 3- Fee Minimum Value] = B.[HOA3FeeMinimumValue]
		,A.[HOA 3- Fee Maximum Value] = B.[HOA3FeeMaximumValue]
		,A.[HOA 3- Fee Type] = B.[HOA3FeeType]
		,A.[HOA 3 - Fee Frequency] = B.[HOA3FeeFrequency]

		,A.[HOA 4- Name] = B.[HOA4Name]
		,A.[HOA 4 - Type] = B.[HOA4Type]
		,A.[HOA 4- Contact Type 1] = B.[HOA4ContactType1]
		,A.[HOA 4- Contact Name 1] = B.[HOA4ContactName1]
		,A.[HOA 4- Address (Mailing)  1] = B.HOA4Address1
		,A.[HOA 4- City (Mailing) 1] = B.HOA4City1
		,A.[HOA 4- State (Mailing) 1] = B.HOA4State1
		,A.[HOA 4- Zip (Mailing)  1] = B.HOA4Zip1
		,A.[HOA 4- Contact Cell Phone 1] = B.HOA4ContactCellPhone1
		,A.[HOA 4- Contact Business Phone 1] = B.HOA4ContactBusinessPhone1
		,A.[HOA 4- Contact Email 1] = B.[HOA4ContactEmail1]
		,A.[HOA 4- Contact Type 2] = B.[HOA4ContactType2]
		,A.[HOA 4- Contact Name 2] = B.[HOA4ContactName2]
		,A.[HOA 4- Address (Mailing) 2] = B.HOA4Address2
		,A.[HOA 4- City (Mailing) 2] = B.HOA4City2
		,A.[HOA 4- State (Mailing)2] = B.HOA4State2
		,A.[HOA 4- Zip (Mailing) 2] = B.HOA4Zip2
		,A.[HOA 4- Contact Cell Phone 2] = B.HOA4ContactCellPhone2
		,A.[HOA 4- Contact Business Phone 2] = B.HOA4ContactBusinessPhone2
		,A.[HOA 4- Contact Email 2] = B.[HOA4ContactEmail2]
		,A.[HOA 4- Contact Type 3] = B.[HOA4ContactType3]
		,A.[HOA 4- Contact Name 3] = B.[HOA4ContactName3]
		,A.[HOA 4- Address (Mailing) 3] = B.HOA4Address3
		,A.[HOA 4- City (Mailing) 3] = B.HOA4City3
		,A.[HOA 4- State (Mailing)3] = B.HOA4State3
		,A.[HOA 4- Zip (Mailing) 3] = B.HOA4Zip3
		,A.[HOA 4- Contact Cell Phone 3] = B.HOA4ContactCellPhone3
		,A.[HOA 4- Contact Business Phone 3] = B.HOA4ContactBusinessPhone3
		,A.[HOA 4- Contact Email 3] = B.[HOA4ContactEmail3]
		,A.[HOA 4- Fee Value] = B.[HOA4FeeValue]
		,A.[HOA 4- Fee Minimum Value] = B.[HOA4FeeMinimumValue]
		,A.[HOA 4- Fee Maximum Value] = B.[HOA4FeeMaximumValue]
		,A.[HOA 4- Fee Type] = B.[HOA4FeeType]
		,A.[HOA 4 - Fee Frequency] = B.[HOA4FeeFrequency]

		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] as A join [data].[dbo].[v_HOA_Fulfillment_NEW] as B with(NOLOCK)
		on A.FIPS = B.FIPS 
		and A.PROPERTYID = B.PropertyID
	

	
	Select top 100 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]


		-----------------------TRanslate Codes-----------------
			
			------ ADD FEE TYPE DESCRIPTIONS
			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 1- Fee Type] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeType] b
			on a.[HOA 1- Fee Type] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 2- Fee Type] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeType] b
			on a.[HOA 2- Fee Type] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 3- Fee Type] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeType] b
			on a.[HOA 3- Fee Type] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 4- Fee Type] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeType] b
			on a.[HOA 4- Fee Type] = b.Code


			------ ADD FEE TYPE DESCRIPTIONS
			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 1 - Fee Frequency] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeFreqType] b
			on a.[HOA 1 - Fee Frequency] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 2 - Fee Frequency] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeFreqType] b
			on a.[HOA 2 - Fee Frequency] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 3 - Fee Frequency] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeFreqType] b
			on a.[HOA 3 - Fee Frequency] = b.Code

			UPDATE [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			SET [HOA 4 - Fee Frequency] = CodeDesc
			FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [Global].[dbo].[lkup_HOA_FeeFreqType] b
			on a.[HOA 4 - Fee Frequency] = b.Code


	
		------20231030 - Per Nicole - Found = Has an HOA
	



			Select [HOA 1 - Fee Frequency], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 1 - Fee Frequency]

			Select [HOA 2 - Fee Frequency], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 2 - Fee Frequency]

			Select [HOA 3 - Fee Frequency], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 3 - Fee Frequency]

			Select [HOA 4 - Fee Frequency], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 4 - Fee Frequency]

			Select [HOA 1- Fee Type], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 1- Fee Type]

			Select [HOA 2- Fee Type], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 2- Fee Type]

			Select [HOA 3- Fee Type], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 3- Fee Type]

			Select [HOA 4- Fee Type], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
			where [Transaction Status] like 'Event Found'
			Group by [HOA 4- Fee Type]



		----------------------

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_OS_National].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKey] = b.Raw_ID

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_OS_National].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34] a join [zCust_OS_National].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUTKey] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		Update  [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		Set [Transaction Status] = 
		case when 
		ISNULL([HOA 1- Name],'') not like '' OR 
		ISNULL([HOA 2- Name],'') not like '' OR
		ISNULL([HOA 3- Name],'') not like '' OR
		ISNULL([HOA 1 - Type],'') not like '' OR
		ISNULL([HOA 2 - Type],'') not like '' OR
		ISNULL([HOA 2 - Type],'') not like ''
		then 'Event Found'
		else 'Event Not Found' end




		Select [Property Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		Group by [Address Standardization]

		Select [Transaction Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		Group by [Transaction Status]

		Select [Coverage Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		Group by [Coverage Status]

		Select * from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S34]
		where [Property Status] like 'Property Not Found'


END





