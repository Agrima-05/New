SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_300_Start_Output_S11_ALL]


AS
BEGIN
	
	SET NOCOUNT ON;

	--------20230811 - Per Abhijit - checking with customer



		DROP TABLE [dbo].[x_Custom_OUTPUT_S11]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S11](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT DealID][varchar](250)NULL,
			[INPUT Solution ID][varchar](250)NULL,
			[INPUT Unique RecordID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,

			
			[INPUT Start Date][varchar](250)Null,
			-----Remove-----
			[PFCFLAG][varchar](250)Null,

			[Property Address][varchar](250)Null,
			[City][varchar](250)Null,
			[State][varchar](250)Null,
			[Zip Code][varchar](250)Null,
			[Report Date][varchar](250)Null,
			[Property Status][varchar](250)Null,
			[Address Standardization][varchar](250)Null,
			[Deed Coverage][varchar](250)Null,
			[Deed Thru Date][varchar](250)Null,
			[Deed Event Status][varchar](250)Null,
			[PreForeclosure Coverage ][varchar](250)Null,
			[Preforeclosure Thru Date][varchar](250)Null,
			[Preforeclosure Event Status][varchar](250)Null,

	
			[INPUT Date][varchar](250)Null,
			[INPUT Amount][varchar](250)Null,

			[Nbr of Transactions][varchar](250)Null
			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		

	  	INSERT INTO [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] ([INPUT DealID],[INPUT Solution ID],[INPUT Unique RecordID],[INPUT Address],[INPUT City],[INPUT State]
		,[INPUT Zip])
		Select 
		[Deal ID]
      ,[Solution ID]
      --,convert(bigint,[Unique RecordID])
	  ,[Unique RecordID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
     FROM 
	 --[dbo].INPUT_RAW_351184VND
	  --[dbo].INPUT_RAW_351325VND
	  INPUT_RAW_CUST
	  where ISNULL([Unique RecordID],'0') not like '0'
	and [Unique RecordID] not like ''
	and [Unique RecordID] is not null


	  
	  
	  Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as A 
	  Order by FIPS
	  
	
			

		UPDATE [zCust_SITUS_AMC].[dbo].[a] 
		SET 
		a.[PROPERTYID] = c.[PROPERTYID]
		,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Unique RecordID] = c.RAW_ID


		
		

		Update [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a JOIN [zCust_SITUS_AMC].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Unique RecordID] = c.RAW_ID


		
		Update [zCust_SITUS_AMC].[dbo].[a]
		set [PreForeclosure Coverage ] = B.ForeclosureActive
		,A.[Preforeclosure Thru Date] = convert(date,B.ForeclosureMaxRecordDate)
		,A.[Deed Coverage] = B.DeedActive
		,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE


		------FLAG PROPERTIES CURENTLY IN PFC----
		Update [zCust_SITUS_AMC].[dbo].[A]
		Set A.[PFCFLAG] = B.[PFCFLAG]
		--Select A.[INPUT Unique RecordID], A.PROPERTYID, A.PFCFLAG, B.PFCFlag
		From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a 
		JOIN  [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) 
		on A.FIPS = B.FIPS and A.PropertyID = B.PROPERTYID
		where A.PROPERTYID is not null and A.PROPERTYID not like ''
		and A.PROPERTYID not like '0'
		

		------PULL PFC DATA----ONLY FOR PROPERTIES FLAGGED AS PFCFLAG = Y in ASSESSOR SUPER
		--EXEC [dbo].[usp_502_Pull_FLANK_DATA_PFC] 

		-----PULL ALL PFC, REO & REO SALES for all matched properties
		EXEC [zCust_SITUS_AMC].[dbo].[usp_502_Pull_FLANK_DATA_PFC_ALL]


		
		------------------------------------------------------------------------

		   Update [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] SET toUse = NULL

		 

		   ----Foreclosure recods---
			UPDATE [zCust_SITUS_AMC].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[INPUT Unique RecordID], B.[INPUT Start Date], A.PropertyID--, C.*
			FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] a JOIN [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as B on 
			A.RAW_ID = B.[INPUT Unique RecordID]  
			join [zCust_SITUS_AMC].[dbo].[w_FLANK_NOD] as C on A.RAW_ID = C.RAW_ID and A.Doc_Id = C.TransactionId
			--join data.[dbo].[vAssessor_PREMIUM_NEW] as D with(NOLOCK) on B.FIPS = D.FIPS and B.PropertyID = D.PropertyiD
			where Doc_Src_Ind like 'R'
			and DocumentTypeDesc not like 'RELEASE' and DocumentTypeDesc not like 'Assignment%'
			--and convert(date,A.recordingdate) > convert(date,B.[INPUT Start Date])
			--Order by B.[INPUT Unique RecordID]
			--AND D.[PFCFlag] like 'Y'


			------REO & REO Sales---
			UPDATE [zCust_SITUS_AMC].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[INPUT Unique RecordID], B.[INPUT Start Date], A.*, C.*
			FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] a JOIN [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as B on 
			A.RAW_ID = B.[INPUT Unique RecordID] 
			join [zCust_SITUS_AMC].[dbo].[w_FLANK_DEEDS] as C on A.PropertyID = C.FAPropertyID and A.Doc_Id = C.TransactionId
			where Doc_Src_Ind like 'D'
			and (C.REO = 1 or C.REOSALE = 1)
			--and convert(date,A.recordingdate) > convert(date,B.[INPUT Start Date])
			--Order by B.[INPUT Unique RecordID]
		

		Select * From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
	where RAW_ID = '220270499'
		

		Truncate table [dbo].w_TransHist_FLANK_II

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
					Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
					FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
					--LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate
					--,
					[PROPERTYID] )
		SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
					Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
					FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
					--LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate 
					--,
					[PROPERTYID]
		FROM     [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
		WHERE  (ToUse = 'Y')


			UPDATE [zCust_SITUS_AMC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC) AS RowNum
				FROM 
			[zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II]
		Order by RAW_ID, RecordingDate

		Select * From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Set [Nbr of Transactions] = NULL

		UPDATE [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Nbr of Transactions] = b.NbrOfRecordings
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings 
		FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) b
		on a.[INPUT Unique RecordID] = b.RAW_ID

		Select max(convert(int,[Nbr of Transactions])) from [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]

			
		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = case when max(convert(int,[Nbr of Transactions])) is null then 1 else  
		max(convert(int,[Nbr of Transactions])) end FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Record Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Document Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Document Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Value_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Borrower/Buyer_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Lender/Seller_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Document Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Loan Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeTelephoneNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeFullStreetAddress_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeUnitNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeCityName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeStateCode_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeZipCode_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeZipplus4_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeFirstName&MiddleInitial_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeLastNameORCorporationName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeCareofName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeSaleNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Date_' + @RecNbr + '] [varchar](250) NULL')


				
					EXEC('UPDATE a
					SET 
					A.[Record Nbr_' + @RecNbr + '] = b.REcordNumber
					,A.[Recording Date_' + @RecNbr + '] = b.RecordingDate
					,A.[Document Nbr_' + @RecNbr + '] = b.DocumentNbr
					,A.[Document Type_' + @RecNbr + '] = b.DocumentType
					,A.[Value_' + @RecNbr + '] = b.Value
					,A.[Borrower/Buyer_' + @RecNbr + '] = b.BuyerBorrower
					,A.[Lender/Seller_' + @RecNbr + '] = b.SellerLender
					,A.[Original Recording Date_' + @RecNbr + '] = convert(date,b.OrigTransRecDate)
					,A.[Original Document Nbr_' + @RecNbr + '] = b.OrigTransDocNumber
					,A.[Original Loan Amount_' + @RecNbr + '] = B.OrigLoanAmount
					
					--Select B.* 
					FROM x_Custom_OUTPUT_S11 a JOIN 
					w_TransHist_FLANK_II as B on 
					a.[INPUT Unique RecordID] = b.RAW_ID
					WHERE B.Doc_Src_Ind like ''D''
					AND B.REcordNumber = ' + @BeginNbrOfTrans + '') 



					EXEC('UPDATE a
					SET 
					A.[Record Nbr_' + @RecNbr + '] = b.REcordNumber
					,A.[Recording Date_' + @RecNbr + '] = b.RecordingDate
					,A.[Document Nbr_' + @RecNbr + '] = b.DocumentNbr
					,A.[Document Type_' + @RecNbr + '] = b.DocumentType
					,A.[Value_' + @RecNbr + '] = b.Value
					,A.[Borrower/Buyer_' + @RecNbr + '] = b.BuyerBorrower
					,A.[Lender/Seller_' + @RecNbr + '] = b.SellerLender
					,A.[Original Recording Date_' + @RecNbr + '] = convert(date,b.OrigTransRecDate)
					,A.[Original Document Nbr_' + @RecNbr + '] = b.OrigTransDocNumber
					,A.[Original Loan Amount_' + @RecNbr + '] = B.OrigLoanAmount
					,A.[TrusteeTelephoneNumber_' + @RecNbr + '] = C.TrusteePhone
					,A.[TrusteeFullStreetAddress_' + @RecNbr + '] = C.TrusteeFullAddress
					,A.[TrusteeUnitNumber_' + @RecNbr + '] = C.TrusteeAptNumber
					,A.[TrusteeCityName_' + @RecNbr + '] = C.TrusteeCity
					,A.[TrusteeStateCode_' + @RecNbr + '] = C.TrusteeState
					,A.[TrusteeZipCode_' + @RecNbr + '] = C.TrusteeZip5
					,A.[TrusteeZipplus4_' + @RecNbr + '] = C.TrusteeZip4
					,A.[TrusteeFirstName&MiddleInitial_' + @RecNbr + '] = C.TrusteeFirstNameMiddleInitial
					,A.[TrusteeLastNameORCorporationName_' + @RecNbr + '] = C.TrusteeLastNameorCorp
					,A.[TrusteeCareofName_' + @RecNbr + '] = C.TrusteeMailCareOfName
					,A.[TrusteeSaleNumber_' + @RecNbr + '] = C.TrusteeSalesNumber
					,A.[Auction Date_' + @RecNbr + '] = case when ISDATE(C.AuctionDate) = 1 then convert(date,C.AuctionDate) else NULL end

					--Select B.*
					FROM x_Custom_OUTPUT_S11 a JOIN 
					w_TransHist_FLANK_II as B on 
					a.[INPUT Unique RecordID] = b.RAW_ID
					join w_FLANK_NOD as C on B.RAW_ID = C.RAW_ID and B.Doc_Id = C.TransactionID
					WHERE B.Doc_Src_Ind like ''R''
					AND B.REcordNumber = ' + @BeginNbrOfTrans + '') 
					
					

					EXEC('
					Update A
					SET A.[Document Type_' + @RecNbr + '] = Upper(b.[Codedesc])
					from x_Custom_OUTPUT_S11 a join [Global].[dbo].[lkup_Doc_Type] b with(NOLOCK)
					ON A.[Document Type_' + @RecNbr + '] = b.[DocTypeID]
					')


							


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END

		--Select   DOCTYPE, count(*) FRom (
		--Select [Document Type_001] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 0
		--Group by [Document Type_001]
		--UNION ALL
		--Select [Document Type_002] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 1
		--Group by [Document Type_002]
		--UNION ALL
		--Select [Document Type_003] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 2
		--Group by [Document Type_003])A
		--Group by   DOCTYPE
		--Order by   DOCTYPE


		----------------------

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] 
		SET [PreForeclosure Coverage ] = CASE WHEN [PreForeclosure Coverage ] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] 
		SET [Deed Coverage] = CASE WHEN [Deed Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a JOIN [zCust_SITUS_AMC].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique RecordID] = b.Raw_ID

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_SITUS_AMC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] a join [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique RecordID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		Update  [zCust_SITUS_AMC].[dbo].[A]
		Set A.[Deed Event Status] = 'Event Found'
		From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as A join [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] as B on 
		A.[INPUT Unique RecordID] = B.Raw_ID
		where [Nbr of Transactions] > 0
		and B.Doc_SRC_Ind like 'D'


		Update  [zCust_SITUS_AMC].[dbo].[A]
		Set A.[Preforeclosure Event Status] = 'Event Found'
		From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as A join [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK_II] as B on 
		A.[INPUT Unique RecordID] = B.Raw_ID
		where [Nbr of Transactions] > 0
		and B.Doc_SRC_Ind like 'R'

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Set [Deed Event Status] = 'Event Not Found'
		where ISNULL([Deed Event Status],'') like ''

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Set [Preforeclosure Event Status] = 'Event Not Found'
		where ISNULL([Preforeclosure Event Status],'') like ''


		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		where [Nbr of Transactions] > 0 and 
		[Preforeclosure Event Status] = 'Event Not Found' 
		and [Deed Event Status] = 'Event Not Found'

		
		--Select   DOCTYPE, count(*) FRom (
		--Select [Document Type_001] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 0
		--and [Deed Event Status] = 'Event Found'
		--Group by [Document Type_001]
		--UNION ALL
		--Select [Document Type_002] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 1
		--and [Deed Event Status] = 'Event Found'
		--Group by [Document Type_002]
		--UNION ALL
		--Select [Document Type_003] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 2
		--and [Deed Event Status] = 'Event Found'
		--Group by [Document Type_003])A
		--Group by   DOCTYPE
		--Order by   DOCTYPE


		--Select   DOCTYPE, count(*) FRom (
		--Select [Document Type_001] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 0
		--and [Preforeclosure Event Status] = 'Event Found'
		--Group by [Document Type_001]
		--UNION ALL
		--Select [Document Type_002] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 1
		--and [Preforeclosure Event Status] = 'Event Found'
		--Group by [Document Type_002]
		--UNION ALL
		--Select [Document Type_003] as DOCTYPE, count(*) as TOTAL  From x_Custom_OUTPUT_S11
		--where [Nbr of Transactions] > 2
		--and [Preforeclosure Event Status] = 'Event Found'
		--Group by [Document Type_003])A
		--Group by   DOCTYPE
		--Order by   DOCTYPE


		Select [Property Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Address Standardization]

		Select [Preforeclosure Event Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Preforeclosure Event Status]

		Select [Deed Event Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Deed Event Status]

		Select [PreForeclosure Coverage ], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [PreForeclosure Coverage ]

		Select [Deed Coverage], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Deed Coverage]

		Select * from [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		where [Property Status] like 'Property Not Found'

		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11]
		Order by convert(int,[Nbr of Transactions]) desc

		--Select * From w_TRanshist_FLANK_II
		--where RAW_ID = '220270483'
		--Order by REcordNumber desc

	
	

END





