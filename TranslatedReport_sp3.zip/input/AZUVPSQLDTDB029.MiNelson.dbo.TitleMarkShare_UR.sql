/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.TitleMarkShare_UR | type=P */







-- ===============================================================================================
-- Author:		My Phan
-- Create date: 4/01/2015
-- Description:	Create MarkShareTitle_Temp1 and MarkShareTitle_Temp2 tables for Markshare_Title job
-- ================================================================================================



CREATE PROCEDURE [MiNelson].[dbo].[TitleMarkShare_UR]
                 
AS 


SET NOCOUNT ON

BEGIN

 
 
 ---------------------------BK Data ---------------------------------
 



       IF OBJECT_ID('mktshr.Marketshare_Deed_BK') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK 

   
 
 select
  MTG1_CONSTRUCTION_LOAN,
  REO_SALE_FLAG, 
  REO_SALE ,
  TRANSACTION_TYPE,
  MTG1_MTG_AMOUNT ,
  Fips ,
  MTG1_EQUITY_FLAG ,
   MTG1_OTHER_SUBORDINATE_LOANS,
   MTG1_LENDER_LAST_NAME,
   TITLE_COMPANY_NAME   ,
        MULTI_APN, 
          RECORDING_DATE,
          SALE_DATE,
          case when (us_state = 'IN' and source_type = 'M' and Doc_nbr is null) then left(UR_REMARKS,20) else doc_nbr end  as DOC_NBR,
           Recording_Book,
           Recording_Page,
           DeedId,MTG1_DOC_NBR,
           DETAILED_DOC_TYPE,
           SALE_AMOUNT,
           MTG1_MTG_INTEREST_RATE_TYPE ,
           MTG1_MTG_LOAN_TYPE_CODE
  ,SELLER_NAME_PLAINTIFF_1
   ,BYR1_OWN_NAME,BYR1_CORP_IND ,SITUS_CITY,US_COUNTY,US_STATE ,SITUS_ZIP_CODE,
   TITLE_COMPANY_CODE,
         DEED_TYPE, UPDATED,
      FORCLOSURE,
      RESALE_NEW_CONSTRUCTION,
        MTG1_PRIVATE_PARTY_LENDER,
       SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Sales_Source_Ind,      ---------------------change 2/4/2016 to filter AZ affidavits
       REF_ID  ,                  ---------------------Added for update Attorney names 3/14/2016
   source_type, SRC_TBL, CLGX_UNIQUE_ID, MTG2_DOC_NBR, MTG2_MTG_AMOUNT, MTG2_CONSTRUCTION_LOAN, MTG2_EQUITY_FLAG, MTG2_LENDER_LAST_NAME, MTG2_MTG_INTEREST_RATE_TYPE
   ,[MTG1_RECORDING_DATE], [MTG1_DOC_DATE], [MTG1_RECORDING_BOOK],[MTG1_RECORDING_PAGE] , [MTG1_DETAILED_DOC_TYPE] ,[MTG1_LENDER_FIRST_NAME],[MTG1_LENDER_ADDRESS] ,[MTG1_LENDER_CITY] ,[MTG1_LENDER_STATE] ,[MTG1_LENDER_ZIP],[MTG1_MTG_COMPANY_CODE]
   , [MTG1_MTG_TERM_CODE] ,[MTG1_MTG_TERM_],[MTG1_MTG_DUE_DATE] , [MTG1_MTG_INTEREST_RATE] ,[MTG1_SELLER_CARRY_BACK]   ,[MTG1_REFI_FLAG]
    ,[MTG2_RECORDING_DATE]	,[MTG2_DOC_DATE]   ,[MTG2_RECORDING_BOOK]    ,[MTG2_RECORDING_PAGE]    ,[MTG2_DETAILED_DOC_TYPE]  ,[MTG2_LENDER_FIRST_NAME] ,[MTG2_LENDER_ADDRESS]  ,[MTG2_LENDER_CITY] ,[MTG2_LENDER_STATE]   ,[MTG2_LENDER_ZIp]
   ,[MTG2_MTG_COMPANY_CODE] ,[MTG2_MTG_LOAN_TYPE_CODE],[MTG2_MTG_TERM_CODE]  ,[MTG2_MTG_TERM]  ,[MTG2_MTG_DUE_DATE] ,[MTG2_MTG_INTEREST_RATE]   ,[MTG2_SELLER_CARRY_BACK]   ,[MTG2_PRIVATE_PARTY_LENDER] ,[MTG2_REFI_FLAG]   ,[MTG2_OTHER_SUBORDINATE_LOANS] 
    
 into [MiNelson].[mktshr].[Marketshare_Deed_BK]    
FROM [Deed].[dbo].[Deed] t
where isnull(Recording_Date,Sale_Date) >= '2022-01-01' 
and (source_type = 'E' )
and fips  in (select distinct fips from 
   [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver]
  where source = 'E')

   
  ----- change transaction type---

  update [MiNelson].[dbo].[a] set a.transaction_type = '9'
  , sale_amount = null
  --select b.INTER_FAMILY, b.TRANSACTION_TYPE, DOC_TRANSFER_TAX, b.DETAILED_DOC_TYPE, b.sale_amount,*
from [Minelson].[mktshr].[Marketshare_Deed_BK]    a
left join [deed].[dbo].[deed] b
on a.deedid = b.deedid
where a.fips --in (41005,41067,41051) --
between '41003' and '41071'
and b.Source_type = 'e'
and b.deed_type = 'g'
and b.Sale_code is null
and b.Sale_amount = (b.doc_transfer_tax)*1000/1.00



 update [MiNelson].[dbo].[a] 
 set a.transaction_type = '9'
  , a.sale_amount = null
--	select b.fips,b.US_COUNTY, b.APN_unformatted,b.DOC_NBR, b.INTER_FAMILY, b.TRANSACTION_TYPE, DOC_TRANSFER_TAX, 
--b.DETAILED_DOC_TYPE, b.sale_amount, b.MTG1_MTG_AMOUNT,a.* , b.*
from [Minelson].[mktshr].[Marketshare_Deed_BK] a
  left join [deed].[dbo].[deed] b
         on a.deedid = b.deedid
where a.us_state = 'WA' 
and left(a.recording_date, 7) >='2022-01'and b.[TRANSACTION_TYPE] in ('1')
and DOC_TRANSFER_TAX is not null and DOC_TRANSFER_TAX < 300
and (( b.DETAILED_DOC_TYPE = 'WD' and b.inter_family = 'y')
       or  (b.DETAILED_DOC_TYPE <> 'WD' ))

 -------------------------update original fields_---------------
 
     IF OBJECT_ID('mktshr.Marketshare_Deed_BK_Final') IS NOT NULL DROP TABLE  mktshr.Marketshare_Deed_BK_Final


 
 select * into   [MiNelson].[mktshr].[Marketshare_Deed_BK_Final]
 from  [MiNelson].[mktshr].[Marketshare_Deed_BK]




--------------------------------create Bk mtg1 and mtg2 report


IF OBJECT_ID('[dbo].[MarketShareTitle_Temp1]') IS NOT NULL DROP TABLE [dbo].[MarketShareTitle_Temp1]


select
	DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE,
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
       MTG1_PRIVATE_PARTY_LENDER,
       SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Sales_Source_Ind,
	   REF_ID,
       RECORDING_DATE,
       SALE_DATe, 
        UPDATED,
        Ass_ZipCode,
        Year_Built
     
   into [MiNelson].[dbo].[MarketShareTitle_Temp1]
from (

      SELECT
       1 as DeedSequence,
            case when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' -- Added 4/01/2015 
                           when (REO_SALE_FLAG = 1 Or REO_SALE = 'Y') and deed.TRANSACTION_TYPE != 4 then    -- Added "Cash Sale" split 2/27/2015 -- Added REO_Sale ='Y' 4/13/15
                                         case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'REO - Cash Sale' else 'REO' end
                           when MTG1_EQUITY_FLAG = 'Y' then 'Home Equity'
                           when MTG1_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
                                    else
                        case deed.TRANSACTION_TYPE 
                              when '1' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '2' then 'Refinance'
                              when '3' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Subdivision/Newhome - Cash Sale'
                                    else 'Subdivision/Newhome'
                                    end
                              when '4' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Timeshare - Cash Sale'
                                    else 'Timeshare'
                                    end
                              when '6' then 'Construction Loan'
                              when '7' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '9' then 'Refinance'
                              else ''
                        end
                  end as [Transaction Type],
            --isnull(deed.MTG1_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			case when (deed.MTG1_LENDER_LAST_NAME is null or deed.MTG1_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG1_LENDER_LAST_NAME end as [Lender],
            case when (deed.TITLE_COMPANY_NAME  is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
      
            'UNKNOWN' as [Attorney],
            MTG1_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                         isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                          case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN desc, deed.DeedId) as [rn],               -- Corrected problem with row_number 3/09/15----- 4/14 Add DeedID
            deed.DOC_NBR as [Sale Document number],
            deed.MTG1_DOC_NBR as [MGT Document number],
              deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
       --     (deed.MTG1_RECORDING_BOOK + '/' + deed.MTG1_RECORDING_PAGE) as 'Book/Page', -- change 7/6/2015 make unique keys
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change 7/6/2015 make unique keys
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG1_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG1_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG1_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
           -- case when deed.US_STATE = 'KS' ---------adding 4/29/15 ----------take out 5/4/15
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG1_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG1_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null or deed.MTG1_DETAILED_DOC_TYPE='VR' then 'YES'   -- Added 2/20/2015; Added VR check 20180815
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
case when deed.MTG1_MTG_LOAN_TYPE_CODE = 'CNV' then
        case 
            when NBR_OF_RES_UNITS = 1 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
            when NBR_OF_RES_UNITS = 2 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
            when NBR_OF_RES_UNITS = 3 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
            when NBR_OF_RES_UNITS = 4 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
            when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                    and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
            else 'NO'
        end
        else 'NO'
end as [Conforming],
            case when TRANSACTION_TYPE = '3' then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = '9' then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
           case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       deed.TITLE_COMPANY_CODE,
       --MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND ,
       Deed.MTG1_PRIVATE_PARTY_LENDER,
       Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Deed.Sales_Source_Ind,      ---------------------change 2/4/2016 to filter AZ affidavits
       Deed.REF_ID,	               ---------------------Added for update Attorney names 3/14/2016
       deed.RECORDING_DATE,
       deed.SALE_DATe,
       deed.UPDATED,
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
       assr.Year_Built  -----------------------------Added YearBuilt for HI fix
       
      FROM 
            [MiNelson].[mktshr].[Marketshare_Deed_BK_Final] deed with (Nolock)left outer join [Assr].[dbo].[Assr] assr with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  -----------9/8/15 change to use ref_id to join
                deed.REF_ID = assr.REF_ID
                              left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm  with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where
            deed.DETAILED_DOC_TYPE not in ('MO','RD','CD','DT') --, 'TE') -- Added back the 'TE' records on 4/06/15
        --  and (deed.FIPS  between 56001 and 56999)
   --      and deed.US_STATE = 'ME'
  --and isnull(deed.RECORDING_DATE,deed.SALE_DATE) >= '2013-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
      --      and (MULTI_APN != 'D' or MULTI_APN is Null) ---- 9/10/2024 get 1 record only by using rn =1 even if D
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9') -- Added TransType=9 on 4/07/15
              --   and not (Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null) -- Added Title_Company_Code is Null on 4/06/15 --4/17/15 take out take make filter for AZ
--and (Deed.DeedID >  (SELECT Max([Max_DeedId])FROM [mktshr].[MarketShare_Title_MaxDeedID])
 	--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16
	
 -- and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- take out BK data 8/20/2015  
  
	-- or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131	)) --- Add BK data 3/10/16 
--	  )   
--and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 --- remove 6/9
      )x
where
      rn = 1
--order by
--      [Sale Document number]


update [MiNelson].[dbo].[a]
set a.[Transaction Type] = 'Resale' 
 from [MiNelson].[dbo].[MarketShareTitle_Temp1] a
 where a.transaction_type = 1
 and ( MTG1_CONSTRUCTION_LOAN = 'Y' or MTG1_EQUITY_FLAG = 'Y' or MTG1_OTHER_SUBORDINATE_LOANS = 'Y'or MTG1_EQUITY_FLAG = 'Y')
  and a.[loan amount] <> 0 and a.[Sales Price] <> 0


------------------

IF OBJECT_ID('[dbo].[MarketShareTitle_Temp2]') IS NOT NULL DROP TABLE [dbo].[MarketShareTitle_Temp2]
      
-------------------------
-- Create 2nd mgt table

select
DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE, 
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
        MTG1_PRIVATE_PARTY_LENDER,
        SELLER_NAME_PLAINTIFF1_CORP_IND,
		sales_source_ind,
		REF_ID,
       RECORDING_DATE,
       SALE_DATe,
       UPDATED,
       Ass_ZipCode,
       Year_Built 
   
   into [MiNelson].[dbo].[MarketShareTitle_Temp2]
from (
  SELECT
       
     2 as DeedSequence,
            --case 
            ----when REO_SALE_FLAG = 1 then    -- Added "Cash Sale" split 2/27/2015
            ----                        case when deed.MTG1_MTG_AMOUNT is Null and mc.Fips is not Null then 'REO - Cash Sale'
            ----                        else 'REO'
            ----                        end
            --      when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity'
            --      when MTG2_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
            --      else
            --            case deed.TRANSACTION_TYPE 
            --                  when 1 then 'Resale'
            --                  when 2 then 'Refinance'
            --                  when 3 then 'Subdivision/Newhome'
            --                  when 4 then 'Timeshare'
            --                  when 6 then 'Construction Loan'
            --                  when 7 then 'Resale'
            --                  when 9 then 'Refinance'
            --                  else ''
            --            end
            --      end as [Transaction Type],
            case when MTG2_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                           when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                            when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity' ---------Added 4/23/15
                           else 'Other Subordinate Loan' end as [Transaction Type],  --- changed 4/1/2015
            --isnull(deed.MTG2_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			 case when (deed.MTG2_LENDER_LAST_NAME is null or deed.MTG2_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG2_LENDER_LAST_NAME end as [Lender],
            case when (deed.TITLE_COMPANY_NAME is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
  
         --and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null)
       deed.TITLE_COMPANY_CODE,
            'UNKNOWN' as [Attorney],
            MTG2_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                                isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                                case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN Desc, deed.DeedId) as [rn],     -- Corrected problem with row_number 3/09/15--- 4/14 add DeedID
            deed.DOC_NBR as [Sale Document number],
            deed.MTG2_DOC_NBR as [MGT Document number],
            deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
         --   (deed.MTG2_RECORDING_BOOK + '/' + deed.MTG2_RECORDING_PAGE) as 'Book/Page', --change to make uique keys 7/06/2015
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change to make unique keys 7/6/2015
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG2_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG2_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG2_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
    --      case when deed.US_STATE = 'KS' 
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG2_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG2_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null then 'YES'   -- Added 2/20/2015
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
            case when deed.MTG2_MTG_LOAN_TYPE_CODE = 'CNV' then
                  case 
                        when NBR_OF_RES_UNITS = 1 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        when NBR_OF_RES_UNITS = 2 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
                        when NBR_OF_RES_UNITS = 3 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
                        when NBR_OF_RES_UNITS = 4 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
                        when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                              and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        else 'NO'
                  end
                  else 'NO'
            end as [Conforming],
            case when TRANSACTION_TYPE = 3 then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = 9 then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
               case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND,
        Deed.MTG1_PRIVATE_PARTY_LENDER,
        Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
		Deed.Sales_Source_ind,
		Deed.REF_ID,
       deed.RECORDING_DATE,
       deed.SALE_DATe,
         deed.UPDATED, 
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
        assr.Year_Built ------------------------------Added yearBuilt for HI Fix
       
      FROM 
           [MiNelson].[mktshr].[Marketshare_Deed_BK_Final] deed with (Nolock) left outer join [Assr].[dbo].[Assr] assr  with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
                 deed.REF_ID = assr.REF_ID
                              left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where
            deed.DETAILED_DOC_TYPE not in ('MO','RD','CD','DT') --, 'TE') 
         --    and (deed.FIPS  between 56001 and 56999)
            --  and deed.US_STATE = 'ME'
   -- and isnull(deed.RECORDING_DATE,deed.SALE_DATE)  >= '2013-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
         --   and (MULTI_APN != 'D' or MULTI_APN is Null)
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9')
                 -- and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and deed.MTG2_LENDER_LAST_NAME is null)--4/17/15 take out take make filter for AZ
                  and deed.MTG2_MTG_AMOUNT is not null
    --  and (Deed.DeedID >   (SELECT Max([Max_DeedId])FROM [mktshr].[MarketShare_Title_MaxDeedID])
 			--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16


    --         and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- 8/20/215 take out BK data
				--or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131
				--												))  -----add BK data 3/10/2016
				-- --- BK data
				--)
			--	and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 -- remove 6/9

   )y
where
      rn = 1
--order by
--       [Sale Document number]
  

------

----------------------------------------------------------
---Union Results -----------------------------------------

IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable]


from 
(   
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp1]
       union
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp2]
)x
ORDER BY
       [County],
       [Sale Document number]

 Delete
			-- select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where TRANSACTION_TYPE = '9'   ---------------------- by MyPhan 10/11/2022
    and isnull([Sales Price],0) = 0 and isnull ([Loan Amount],0) =0

-----------------
   -------HI Fix--------------------changed to all states 20171130
       
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select * from [MiNelson].[mktshr].[Title_MarketShare_BuilderNames])
   --where State = 'HI' and [Transaction Type] = 'Resale' 
   --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from mktshr.Title_MarketShare_HI_BuilerNames)

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select * from [MiNelson].[mktshr].[Title_MarketShare_BuilderNames])
  --where State = 'HI' and [Transaction Type] = 'Resale - Cash Sale' 
 --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from mktshr.Title_MarketShare_HI_BuilerNames)

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where [Transaction Type] = 'Resale'
and [Seller Name] in (select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where [Transaction Type] = 'Resale - Cash Sale'
and [Seller Name] in (select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])


  update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])
  

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome'
and t.Builder in (Select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale - Cash Sale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
and t.Builder in (Select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder])

--Castiglione, Caroline Thursday, February 7, 2019 2:56 PM Market Share Report issues email
--Castiglione, Caroline Tuesday, February 26, 2019 8:15 AM NV- Frontier Estates email
--Alan Ratner <alan@zelmanassociates.com>, May 14, 2019 2:05 PM [External] RE: First American DataTree - Builder Sample email
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome'
and (t.Builder like 'OPEN DOOR%'
or t.Builder like 'OPENDOOR%'
or t.Builder in
('OENDOOR HOMES PHOENIX 2 LLC'
,'OOENDOOR HOMES PHOENIX 2 L'
,'OPEADOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR PROERW6 LLC'
,'QPENDOOR HOMES PHOENIX 2 L'
,'FRONTIER ESTATES LLC')
or left(t.Builder,12)='COLONY RIDGE')
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale - Cash Sale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
and (t.Builder like 'OPEN DOOR%'
or t.Builder like 'OPENDOOR%'
or t.Builder in
('OENDOOR HOMES PHOENIX 2 LLC'
,'OOENDOOR HOMES PHOENIX 2 L'
,'OPEADOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR PROERW6 LLC'
,'QPENDOOR HOMES PHOENIX 2 L'
,'FRONTIER ESTATES LLC')
or left(t.Builder,12)='COLONY RIDGE')
-----
-------------------------------------------------------------
---- Filter records Resale_CashSale where it is REO

delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] = 'Resale - Cash Sale' and
  ( FORCLOSURE = 'Y' or DEED_TYPE = 'U')
  
  -------------------------------------
  
   -----------------------------------------------------------
  ------Filter cashsale records with no sale price in disclosure states
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
  and [Sales Price] = 0 and State not in ('AZ','AK', 'ID', 'IN', 'KS', 'LA','ME','MS', 'MO', 'MT', 'NM', 'ND', 'TX', 'UT' ,'WY', 'HI')

  -----------------------------------------------------
  
  ------------------------------------------------------------------
  ----------------Update Transaction_Type = ''---------------------
  
  --select * from [dbo].[TitleMarketShare_BaseTable]
  --where [Transaction Type] = '' 
  
  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Transaction Type] =
  (case 
	when [Transaction Type] = '' and [Sales Price] = 0 and [Loan Amount] <> 0 then 'Refinance'
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'M' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Resale - Cash Sale' else 'Resale' end
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'N' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Subdivision/Newhome - Cash Sale' else 'Subdivision/Newhome' end
   else [Transaction Type]
   end)
   
   ----------------------------------------
   
   
  -----------------------------------------------------------------
  -----------------Filter Title_company_code 400 for IL------------
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  TRANSACTION_TYPE =4 
  and (TITLE_COMPANY_CODE <> '00400' or TITLE_COMPANY_CODE is null)
  and state = 'IL'
  
--get Title Company from dtocr_title_extract_lake_master_docNo for UNKNOWN records 2020-07-01
/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp];

SELECT d.Fmt_Doc_Nbr
	,d.FMT_Book_Page
	,m.DeedID
	,[Sale Document number]
	,[Book/Page]
	,DATE
	,m.Fips
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] m INNER JOIN [Deed].[dbo].[Deed] d on m.DeedID=d.DeedID
--CROSS APPLY MiNelson.[dbo].[fn_FmtDocBookPAge_tbl](m.Fips, convert(VARCHAR, DATE, 112), CASE 
--			WHEN PATINDEX('%/%', [Book/Page]) > 0
--				THEN substring([Book/Page], 1, PATINDEX('%/%', [Book/Page]) - 1)
--			ELSE NULL
--			END, CASE 
--			WHEN PATINDEX('%/%', [Book/Page]) > 0
--				THEN substring([Book/Page], PATINDEX('%/%', [Book/Page]) + 1, len([Book/Page]) - PATINDEX('%/%', [Book/Page]))
--			ELSE NULL
--			END, [Sale Document number]) d
WHERE [Title Company] IN ('N/A','NONE AVAILABLE','UNKNOWN')
	AND (m.DeedID NOT IN (Select DeedID from [MiNelson].[mktshr].[TitleMarketShare]) OR m.DeedID IN (Select DeedID from [MiNelson].[mktshr].[TitleMarketShare] where [Title Company] IN ('N/A','NONE AVAILABLE','UNKNOWN')))

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2];

SELECT DISTINCT *
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp]

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3];

SELECT t.*
	,documentnumber
	,TitleId
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2] t
INNER JOIN [MiNelson].[dbo].[Title_Rematch] r ON r.RECORDING_DATE = t.DATE
	AND r.Fips = t.Fips
	AND r.documentnumber = t.Fmt_Doc_Nbr
UNION
SELECT t.*
	,documentnumber
	,TitleId
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2] t
INNER JOIN [MiNelson].[dbo].[Title_Rematch] r ON r.RECORDING_DATE = t.DATE
	AND r.Fips = t.Fips
	AND r.documentnumber = t.Fmt_Book_Page

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4];

SELECT DeedID
	,recommended_value
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3] t
INNER JOIN [MiNelson].[dbo].[dtocr_title_extract_lake_master_docNo] d ON d.title_id = t.TitleId
WHERE recommended_value <> ''  and not(recommended_value  like '%ESCROW%' and	recommended_value not like '%TITLE%')

UPDATE [MiNelson].[dbo].[m]
SET [title company] = left(recommended_value, 60),UPDATED=GETDATE()
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] m
INNER JOIN [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4] t ON t.DeedID = m.DeedID
  --  -----------------------------------------------------------------------------

  ---- add change for Indiana
   update [MiNelson].[dbo].[a]
  set a.[Title Company]= l.title_company_name
  FROM [Minelson].[dbo].[TitleMarketShare_BaseTable] a
 left join  [Deed].[dbo].[deed] d
 on a.deedid = d.deedid 
left join  [Lien].[UR].[DOCUMENT] l
on d.ur_doc_id = l.doc_id
  where  
            (a.[Title Company] = 'unknown' and a.TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and a.State  in ('IN') 
                     and left(date,7) > '2022-08'
					 and l.title_company_name = 'NONE LISTED ON DOCUMENT'

  ----Filter unknown title, lender records for Non_AZ counties ------------------
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  
            ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and State not in ('AZ','HI')

--Delete
--  FROM [dbo].[TitleMarketShare_BaseTable]
--  where [Transaction Type] not in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
--  and   ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')        
--  and State = 'NV'

  --Delete 
  --FROM [dbo].[TitleMarketShare_BaseTable]
  --where  
  --          ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
  --          and State <> 'AZ'
  
   --Filter unknown title, lender records for AZ counties------------- --------- 
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  [Transaction Type] = 'Resale'
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
            ----------------------------------------------------------------------------------
  --Filter Timeshare when unknown Title for Timshare records in TX and AZ counties
  
          
             Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 -- where [Title Company] = 'unknown' and [transaction type]  = 'Timeshare' --- changed 4/23
 --            and (state = 'TX' or State = 'AZ')
  where [Title Company] = 'unknown' 
	and ([transaction type]  = 'Timeshare' or [Transaction Type]= 'Timeshare - Cash Sale' )
             and (state = 'TX' or State = 'AZ')
             
             
             Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where TRANSACTION_TYPE = '9'   ----------------------changed from 9 to '9' by MyPhan 11/21/2019
  and not ( [Sales Price] = 0 and [Loan Amount]is not null)
  
  alter table [dbo].[TitleMarketShare_BaseTable]
 Alter Column [Attorney] varchar(60)


  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Attorney = [Title Company]
  where TITLE_COMPANY_CODE = '00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Title Company] = 'ATTORNEY ONLY'
  where TITLE_COMPANY_CODE ='00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Property type] = 'unknown' and Corporate != 'YES'
   and state != 'NM'  ----- 10/16 take out NM state
   
 

----- Change Residential Indicator If LOAN_TYPE is FHA or VA and Residential indicator is NO and property type = vacant 
------then change the Residential indicator to YES  ---- 9/22/15

 update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
  where [loan Type] in( 'FHA', 'VA') and Residential = 'NO' and [property type] = 'vacant'
  
  
  -----------------------
  
  ----Change  When the Transaction type is Subdivision/Newhome or Subdivision/Newhome-Cash Sale ---> change Residential to Yes  --- 9/22/15

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] = 'vacant'

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] != 'vacant'

  ---------------------------
  
  ----Change If the Reverse Mortgage Indicator is ‘Y’ and Residential is NO --> change Residential to Y regardless of Property Type --- 9/22/15
 
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] = 'vacant'
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] != 'vacant'
  
  ----------------------
  
  
--  ---For these FIPS lets bypass the changes we put in on Friday:
--Dallas- 48113
--Hennepin-27053
--Philadelphia-42101
--Kern-6029
--Anchorage-2020
--Marion OH-39101
--St Clair IL-17163
--Shasta CA-6089
--Yakima WA-53077
--Erie OH-39043
--Spokane-53063
--Ramsey mn-27123

   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
     where [Property type] in ('vacant' , 'agricultural') and Corporate != 'YES' and residential = 'No' 
   and [loan to value] != 'No data' and round(convert(float,[loan Amount]/[SALEs price]*100),2) > 20
and state not in ( 'TX', 'UT')



    update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'YES'
   where [Loan type] in  ('Conventional', 'VA', 'FHA') and [Property type] in ('vacant' , 'agricultural')
   and residential = 'No' and (state not in ( 'TX', 'UT') or fips = 48113)
   and fips not in (27053, 42101, 6029,2020,39101,17163,6089,53077,39043)

 
 
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
 where state not in ( 'TX', 'UT') 
  and residential = 'Yes' and corporate = 'Yes' 
 and [Sales price] = 0
  and [transaction type] = 'Construction Loan'
  and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
  
  
  
delete from  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   where state not in ( 'TX', 'UT') 
    and [transaction type] in ('Subdivision/NewHome', 'Subdivision/NewHome - Cash Sale', 'REO', 'REO-CASH SALE')
and [sales price] = 0 and [loan Amount] = 0
and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)

--------------------

  
  ----------------------
  
  ---- Change If the Transaction Type is TimeShare or TimeShare - Cash -> change Residential Indicator to NO  --- 9/22/15
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set Residential = 'NO'
    where [Transaction Type] in ('Timeshare', 'Timeshare - Cash Sale') and Residential = 'YES'
    and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
    
    
    ---------------------------
    ---, If the Transaction Type is Construction Loan and the Detailed Doc type is CL and Corp Indicator is Y then make Residential =NO 
---This will take the builders and Construction companies out of the Residential bucket

    
    update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'NO'
    where [Transaction Type] = 'Construction Loan' and DETAILED_DOC_TYPE = 'CL' and Corporate = 'YES' and Residential = 'YES'
   and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
   
   --------------------------------
   
   
   
  ----I do have two changes to suggest, 1) for TX if Property type is Vacant and Buyer is corp change residential to NO 
  
  --select * from [dbo].[TitleMarketShare_BaseTable]
  --where [property type] = 'vacant' and Corporate = 'YES' and Residential = 'YES' and State = 'TX'
  
  ----and in IL if Property types is Apartment and number of residentiail units is less than 2 change to Condo
  ---- 10/15 add logic for IL
  
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set [Property Type] = 'Condominium', Residential = 'YES'
where [Property Type] = 'Apartment' and nbr_of_res_units <2
and State = 'IL'


 update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Condominium', Residential = 'YES'
 where [Property Type] = 'Apartment' and [Sales Price] < 300000 and [Transaction Type] in ('Resale', 'Resale - Cash Sale')
and State = 'IL'
  
   
   
 ---  If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’ and property type to single family
  --- For CA --- 10/20/2015
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   set [Property Type] = 'Single Family Residence', Residential = 'YES'
where [Property Type] = 'vacant' and Residential = 'NO'
and MTG1_CONSTRUCTION_LOAN is null and state = 'CA'


--These changes are for Oregon: ----------10/20/2015
--1) If Property type is Agricultural and Corporate is ‘NO’ and MTG1_COMSTRUCTION_LOAN is null  change RESIDENTIAL to YES
--2) If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’
--3) If Property type is Agricultural and NBR_OF_RES_UNITS is more than 0 change PROPERTY type to Single Family Residence and Residential =”YES’



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and Corporate = 'NO' and MTG1_CONSTRUCTION_LOAN is null
 
   
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and  [Property Type] = 'vacant'  and  Residential = 'NO'
 and MTG1_CONSTRUCTION_LOAN is null and Corporate = 'NO'



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and  nbr_of_res_units > 0 


--Here is one for PA  --- 10/21/15
--If Property type is “vacant’ and if sale price is greater than 10,000 change property type to ‘Single Family Residence’ change Residential to Yes

 
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'PA' and [Property Type] = 'vacant' and  Residential = 'NO'
and  [Sales Price] > 10000 

 --- Change for TX --- 10/22/2015
 --  If NBR_OF_RES_UNITS are null and Corporate Indicator is YES change and Residential is YES, change Residential to NO
   
    
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where State = 'TX' and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units is null

--for 48113, If NBR_OF_RES_UNITS = 0 and Corporate Indicator is YES  and Residential is YES, change Residential to NO   --- 10/22/2015

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where fips =48113 and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units = 0


----Change for MI -- 10/27/2015
--- if Property type is vacant and Corp indicator is NO change Residential to YES
---- if Property type is Amusement Recreation change residentail to Yes

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'vacant' and  Residential = 'NO'
and Corporate = 'NO'

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'Amusement Recreation' and  Residential = 'NO'



------------------------"Contruction loan" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT  distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'





------------------------"Home Equity" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select  distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'



--------------check duplicates-----------------------------

 IF OBJECT_ID('dbo.titlemarketshare_dup') IS NOT NULL 
 DROP TABLE dbo.titlemarketshare_dup


SELECT  
      
      DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate], COUNT (*) count
 into [MiNelson].[dbo].[titlemarketshare_dup]
  FROM [MiNelson].[dbo].[TitleMarketShare_Basetable]
  group by
        DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate]
        having COUNT (*) > 1
        
 
 ------------------Delete duplciates---------------------------
 
         Delete from [MiNelson].[dbo].[TitleMarketShare_Basetable]
        where DeedID in (
SELECT deedid
  FROM [MiNelson].[dbo].[titlemarketshare_dup])
  and deedsequence = 2
-----------------------------------------------------------

---------------Add Attorney name from RT--------------------------------------------------------

----------------------------------------------------------------------------------------



-----------------------------------------------------------------------
----- create RT table with only the columns that we need--------------------    
      
--      IF OBJECT_ID('[dbo].[Title_marketshare_RT]') IS NOT NULL DROP TABLE [dbo].[Title_marketshare_RT]


--SELECT[RECORDER_ID]
--      ,[FIPS]
--     ,SR_PROPERTY_ID,SR_UNIQUE_ID
--      ,[SR_DOC_NBR_FMT]
--      ,[SR_DOC_NBR_RAW]
--      , case when [SR_DOC_NBR_FMT] is null then null
--		 when ([SR_DOC_NBR_FMT] <> '' and len([SR_DOC_NBR_FMT]) >  2) then RIGHT(Rtrim([SR_DOC_NBR_FMT]), len([SR_DOC_NBR_FMT]) -2) else null end as RT_Doc_Nbr
--  ,SR_LAWYER_NAME,SR_LAWYER_CODE,SR_TITLE_CO_NAME,SR_TITLE_CO_CODE,SR_DATE_TRANSFER,SR_VAL_TRANSFER,SR_DATE_FILING
 
-- into  dbo.Title_marketshare_RT
-- FROM [ART].[dbo].[RT_Recorder]
-- where SR_DATE_TRANSFER >= '20130101'
 

    -----------------------------------------------------
  
  -------------------------------------------------- 
--           IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_ID

     
       
--       select r.SA_PROPERTY_ID, r.CLGX_UNIQUE_ID, c.* ,
--       case when c.[Book/Page] IS not null then RIGHT(c.[Book/Page], 4)
--       when c.[Sale Document number] IS null then null
--       when len(c.[Sale Document number])<4 then null
--       else RIGHT(Rtrim(c.[Sale Document number]), len(c.[Sale Document number]) -4) end as Deed_Doc_Nbr
--       into  dbo.TitleMarketShare_BaseTable_Attorney_ID from [dbo].[TitleMarketShare_BaseTable] c
--      left join Assr.dbo.PropertyReference r 
--       on c.FIPS = r.FIPS and c.REF_ID =r.REF_ID 
       
      
       
--           IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney
       
--       select r.[RECORDER_ID]
--      ,r.[FIPS] as RT_Fips
--      ,r.[SR_PROPERTY_ID]
--      ,r.[SR_DOC_NBR_FMT]
--      ,r.[SR_DOC_NBR_RAW]
--      ,r.[RT_Doc_Nbr]
--      ,r.[SR_LAWYER_NAME]
--      ,r.[SR_LAWYER_CODE]
--      ,r.[SR_TITLE_CO_NAME]
--      ,r.[SR_TITLE_CO_CODE]
--      ,r.[SR_DATE_TRANSFER]
--      ,r.[SR_VAL_TRANSFER]
--      ,r.[SR_DATE_FILING], I.* 
           
--     into dbo.TitleMarketShare_BaseTable_Attorney 
--     from dbo.TitleMarketShare_BaseTable_Attorney_ID I
--     left outer join dbo.Title_marketshare_RT r
--     on I.FIPS = r.Fips and I.SA_PROPERTY_ID = r.SR_PROPERTY_ID and right(I.Deed_Doc_Nbr,4) = right(r.RT_Doc_Nbr,4)  and  LEFT(CONVERT(varchar,I.RECORDING_DATE,112),8) =r.SR_DATE_TRANSFER
     
   
      
--  IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_final

--select * 
--  into dbo.TitleMarketShare_BaseTable_Attorney_final
--  from 
--(
--SELECT  
--DeedId, 
--[MGT Document number] ,
--[Loan Amount] ,
--Lender ,
--[Transaction Type] ,
--[Loan Type] ,
--[Adjustable Rate]
--,[SR_LAWYER_NAME]
--, row_number() over(partition by DeedId, [MGT Document number] ,[Loan Amount] ,Lender ,[Transaction Type] ,[Loan Type] ,[Adjustable Rate]
--      order by sr_lawyer_name desc) as [rn]
    
--from dbo.TitleMarketShare_BaseTable_Attorney
--)x
--where rn =1


-- ------------update attorney name--------------------


  

--update t1
--set  t1.Attorney =  t2.sr_lawyer_name
--From [dbo].[TitleMarketShare_BaseTable] t1
--left outer join dbo.TitleMarketShare_BaseTable_Attorney_final t2
--on t1.DeedID = t2.DeedID and  isnull (t1.[MGT Document number],'') = isnull(t2.[MGT Document number],'') and
--t1.[Loan Amount] = t2.[Loan Amount] and t1.Lender = t2.Lender and t1.[Transaction Type] = t2.[Transaction Type]
--and t1.[Loan Type] = t2.[Loan Type] and t1.[Adjustable Rate] = t2.[Adjustable Rate]
--where 

-- t1.attorney = 'UNKNOWN' and t2.sr_lawyer_name is not null 
--  and t2.sr_lawyer_name <> ''
--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
--  and  t2.SR_LAWYER_NAME not like '%FCU%'
--  and  t2.SR_LAWYER_NAME not like '%S&L%'
  
--   -- IF OBJECT_ID('[dbo].[Title_marketshare_RT]') IS NOT NULL DROP TABLE [dbo].[Title_marketshare_RT]

--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_ID
  
--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney

--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_final

   IF OBJECT_ID('dbo.titlemarketshare_dup') IS NOT NULL  DROP TABLE dbo.titlemarketshare_dup


  
------- Fix for Fulton GA

--update t1
--set  t1.Attorney =  t2.sr_lawyer_name
--From [dbo].[TitleMarketShare_BaseTable] t1
--inner join MiNelson.dbo.Fulton_GA_BK_to_RT_match t2
--on t1.DeedID = t2.DeedID
-- and t1.attorney = 'UNKNOWN'  and t2.sr_lawyer_name is not null 
--  and t2.sr_lawyer_name <> ''
--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
--  and  t2.SR_LAWYER_NAME not like '%FCU%'
--  and  t2.SR_LAWYER_NAME not like '%S&L%'

------- updating title company from OCR Raw File ----------------------



------------------------------------------------------------------

 --  IF OBJECT_ID('[dbo].[BK_TitleMarketShare_BaseTable_1]') IS NOT NULL  DROP TABLE [dbo].[BK_TitleMarketShare_BaseTable_1]

 --select * 
 --into  [dbo].[BK_TitleMarketShare_BaseTable_1]
 --from 
 -- [dbo].[TitleMarketShare_BaseTable]
  
 ----  select MAX(UPDATED)
 ----from  [dbo].[BK_TitleMarketShare_BaseTable_1]
  
 --     -- select * from [dbo].[BK_TitleMarketShare_BaseTable_1]


  ----------------------------already cut over --------------------------
   IF OBJECT_ID('[dbo].[UR_TitleMarketShare_BaseTable_1]') IS NOT NULL  DROP TABLE [dbo].[UR_TitleMarketShare_BaseTable_1]

  select a.* 
  into [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_1]
  from   [MiNelson].[dbo].[TitleMarketShare_BaseTable] a
  inner join 
   [Minelson].[mktshr].[TitleMarketShare_County_Source_CutOver] b
  on a.FIPS = b.fips
  where b.source = 'E' and CutOver = 'Y'
and (DeedID >  (SELECT Max([Max_DeedId])FROM [Minelson].[mktshr].[MarketShare_Title_MaxDeedID])
	or CONVERT(varchar(10), a.updated ,112) >= (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [Minelson].[mktshr].[MarketShare_Title_MaxDeedID])
	--(select MAX(rundate) from mktshr.TitleMarketShare )
	)
  and Date >= b.StartDate_UR
  


   ----------------------new cut over------------------------------
   union all
   (
    select a.* from    [MiNelson].[dbo].[TitleMarketShare_BaseTable] a
  inner join 
   [Minelson].[mktshr].[TitleMarketShare_County_Source_CutOver] b
  on a.FIPS = b.fips
  where b.source = 'E' and CutOver = 'N'
  and Date >= b.StartDate_UR
  )
  
 

--------------------------------------------------------------------------
------updating Zipcode and city------------------------------------------
---------------------------------------------------------------------------


IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]
from 
[MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_1]
   
  
  ----- add new column for title zipcode-------------------
  
  alter table   dbo.TitleMarketShare_BaseTable_zip add Title_ZipCode varchar(5)
  
   alter table   dbo.TitleMarketShare_BaseTable_zip add Title_city varchar(40)
   
  ----- when Deedid match then populate deed_zip to title_zip----------------
  
    create index ix_a on  [Minelson].[dbo].[TitleMarketShare_BaseTable_zip] (fips,[Zip Code])
  
  create index ix_b on  [Minelson].[dbo].[TitleMarketShare_BaseTable_zip] (fips, ass_Zipcode)
    
 create index ix_c on  [Minelson].[dbo].[TitleMarketShare_BaseTable_zip] (fips,title_zipcode)

   update [MiNelson].[dbo].[t]
   set t.Title_ZipCode = t.[zip code]
   from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
   inner join [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and t.[Zip Code] = z.ZIPCode

----When Deedid dont match update assr_zip to title_zip if it match---------------------------

update [MiNelson].[dbo].[t]
set t.Title_ZipCode = left(t.ass_Zipcode,5)
from 
  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  
     left join  [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and left(t.ass_Zipcode,5) = z.ZIPCode
  where z.ZIPCode is not null and t.[Zip Code] <> '' and t.ass_zipCode is not null
  and t.Title_ZipCode is null and z.ZIPCode is not null
 
 
 
 -----------------------------------------------------------
 
 ---update Preferred city name
 
 IF OBJECT_ID('dbo.ZIPPreferredCity') IS NOT NULL DROP TABLE dbo.ZIPPreferredCity 

 select distinct ZIPCode, Fips, PreferredCity
into [MiNelson].[dbo].[ZIPPreferredCity] 
from   [MiNelson].[dbo].[ZipFipsCityAll]
group by ZIPCode, Fips, PreferredCity

 ------------Update preferred city name--------------------
 
 
 update [MiNelson].[dbo].[t]
 set t.title_city = z.PreferredCity
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  inner join [MiNelson].[dbo].[ZIPPreferredCity] z
  on t.FIPS = z.Fips and t.title_zipcode = z.ZIPCode
 
 -------------------------------------------------------------
 ---Update Deed Zip in update table-----------------------
 
  
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip_update]
 
 -----152,279 with city name or zip different
select *
into [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_city <> t.City or t.Title_ZipCode <> t.[Zip Code]

union
select *
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_ZipCode is null and ( t.[Zip Code] is not null and t.[Zip Code] <> '')



 update [MiNelson].[dbo].[t] 
 set t.[Zip Code] = t.title_ZipCode , t.city = t.title_city
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is not null
 

update [MiNelson].[dbo].[t]
 set t.[Zip Code] = '' , t.city = ''
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is  null
 
 --- update Zip and city in orginal table------------------
 
 --update t
 --set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 --from  [dbo].[TitleMarketShare_BaseTable_zip] t
 --inner join [dbo].[TitleMarketShare_BaseTable_zip_update] u
 --on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 ----update base table ---------------------------------
 
  update [MiNelson].[dbo].[t]
 set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 from  [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_1] t
 inner join [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u
 on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip]
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip_update]
  IF OBJECT_ID('dbo.ZIPPreferredCity') IS NOT NULL DROP TABLE dbo.ZIPPreferredCity 



 

---- adding FMT_doc_nbr


   /*IF OBJECT_ID('Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc]') IS NOT NULL  */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc]


  SELECT a.*, b.[FMT_DOC_NBR],CMT_ID_Doc_nbr, b.[FMT_Book_Page],cmt_id_Book_Page, [FMT_MTG1_DOC_NBR], [FMT_MTG2_DOC_NBR],FMT_MTG1_Book_Page, FMT_MTG2_Book_Page
 into  [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc]
  FROM  [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_1] a
  left join  [Deed].[dbo].[Deed] b
  on a.deedid = b.deedid

-- update a
--  set a.[Title Company] = b.title_recommended_value
-- FROM Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
--OUTER APPLY (
--       SELECT top 1 *
--       FROM [MiNelson].[dbo].[UR_Raw_Title_Recording] b
--       WHERE b.Fips = a.Fips
--             AND b.document_number IN (
--                    a.FMT_DOC_NBR
--                    ,a.FMT_Book_Page
--                    ,a.FMT_MTG1_DOC_NBR
--                    ,a.FMT_MTG1_Book_Page
--                    )
--       ) b
--WHERE a.[Title Company] IN (
--             'NEW TITLE COMPANY NAME'
--             ,'NONE LISTED ON DOCUMENT'
--             )
--       AND len(b.title_recommended_value) < 40
--       AND b.title_recommended_value NOT IN (
--             'NEW TITLE COMPANY NAME'
--             ,'NONE LISTED ON DOCUMENT'
--             )
--       AND b.title_recommended_value IS NOT NULL

---------------updating using keyed New_titlecompanyName field

---------------------take out 6/15/2023 to run faster
--  update a
--  set a.[Title Company] = left(r.[new_title_company_name] ,60)
--  from Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
--  inner join [Lien].[UR].[DOCUMENT] r
--on a.fips = r.fips_code and a.FMT_DOC_NBR = r.cmt_docnumber
-- where  
--   a.[Title Company] in ( 'NEW TITLE COMPANY NAME')
--  and isnull(r.[new_title_company_name],'') <> ''

--   update a
--  set a.[Title Company] = left(r.[new_title_company_name] ,60)
--   from Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
--  inner join [Lien].[UR].[DOCUMENT] r
--on a.fips = r.fips_code and a.FMT_Book_Page= r.cmt_docnumber
-- where  
--   a.[Title Company] in ( 'NEW TITLE COMPANY NAME')
--  and isnull(r.[new_title_company_name],'') <> ''


  -------------------------------------------------------


  update [MiNelson].[dbo].[a]
  set a.[Title Company] = b.title_recommended_value
 -- select *
  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording] b
  on a.Fips = b.Fips
  and a.FMT_DOC_NBR = b.document_number
  and a.CMT_ID_DOC_NBR = b.cmt_id 
  and a.[Title Company] in ( 'NEW TITLE COMPANY NAME','NONE LISTED ON DOCUMENT')
  and  len(b.title_recommended_value) < 40
  and  b.title_recommended_value not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.title_recommended_value is not null
   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')


   update [MiNelson].[dbo].[a]
  set a.[Title Company] = b.title_recommended_value
     --  select * 
	   from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording] b
  on a.Fips = b.Fips
  and a.FMT_Book_Page = b.document_number
  and a.CMT_ID_Book_Page = b.cmt_id 
  and a.[Title Company] in ( 'NEW TITLE COMPANY NAME','NONE LISTED ON DOCUMENT')
  and  len(b.title_recommended_value) < 40
  and  b.title_recommended_value not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.title_recommended_value is not null
     and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

  update [MiNelson].[dbo].[a]
  set a.[Title Company] = b.title_recommended_value
     --  select * 
	   from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording] b
  on a.Fips = b.Fips
  and a.FMT_MTG1_DOC_NBR = b.document_number
 -- and a.CMT_ID_Book_Page = b.cmt_id 
  and a.[Title Company] in ( 'NEW TITLE COMPANY NAME','NONE LISTED ON DOCUMENT')
  and  len(b.title_recommended_value) < 40
  and  b.title_recommended_value not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.title_recommended_value is not null
   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

    update [MiNelson].[dbo].[a]
  set a.[Title Company] = b.title_recommended_value
     --  select * 
	   from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording] b
  on a.Fips = b.Fips
  and a.FMT_MTG1_Book_Page = b.document_number
  --and a.CMT_ID_Book_Page = b.cmt_id 
  and a.[Title Company] in ( 'NEW TITLE COMPANY NAME','NONE LISTED ON DOCUMENT')
  and  len(b.title_recommended_value) < 40
  and  b.title_recommended_value not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.title_recommended_value is not null
     and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

		  update [MiNelson].[dbo].[a] 
		  set a.[Title Company]  = left(b.[Title Company],60)
		  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b
  on a.Fips = b.Fips
  and a.FMT_DOC_NBR = b.document_number
  and a.[Title Company] in ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
 -- and  len(b.title_recommended_value) >= 40
  and  b.[Title Company] not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.[Title Company] is not null

    update [MiNelson].[dbo].[a] 
		  set a.[Title Company]  = left(b.[Title Company],60)
		  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b
  on a.Fips = b.Fips
  and a.FMT_Book_Page = b.document_number
  and a.[Title Company] in ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
 -- and  len(b.title_recommended_value) >= 40
  and  b.[Title Company] not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.[Title Company] is not null

    update [MiNelson].[dbo].[a] 
		  set a.[Title Company]  = left(b.[Title Company],60)
		  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b
  on a.Fips = b.Fips
  and a.FMT_MTG1_DOC_NBR = b.document_number
  and a.[Title Company] in ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
 -- and  len(b.title_recommended_value) >= 40
  and  b.[Title Company] not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.[Title Company] is not null

    update [MiNelson].[dbo].[a] 
		  set a.[Title Company]  = left(b.[Title Company],60)
		  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b
  on a.Fips = b.Fips
  and a.FMT_MTG1_Book_Page = b.document_number
  and a.[Title Company] in ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
 -- and  len(b.title_recommended_value) >= 40
  and  b.[Title Company] not in  ('NEW TITLE COMPANY NAME', 'NONE LISTED ON DOCUMENT')
  and b.[Title Company] is not null

  ----- Update from Deed BK
  
--select count (*)
--			 from Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
--where a.[Title Company] IN (
--             'NEW TITLE COMPANY NAME'
--            ,'NONE LISTED ON DOCUMENT'
--             )
  
update [MiNelson].[dbo].[a]
set a.[Title Company] = b.[TITLE_COMPANY_NAME]
from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
inner join [deed].[dbo].[deed] b
on a.fips = b.fips and a.fmt_doc_nbr = b.FMT_DOC_NBR
and b.Source_Type = 'B'
where a.[Title Company] IN (
             'NEW TITLE COMPANY NAME'
            ,'NONE LISTED ON DOCUMENT'
             )
			 and b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'


update [MiNelson].[dbo].[a]
set a.[Title Company] = b.[TITLE_COMPANY_NAME]
from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
inner join [deed].[dbo].[deed] b
on a.fips = b.fips and a.FMT_Book_Page = b.FMT_Book_Page
and b.Source_Type = 'B'
where a.[Title Company] IN (
             'NEW TITLE COMPANY NAME'
            ,'NONE LISTED ON DOCUMENT'
             )
			 and b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'

update [MiNelson].[dbo].[a]
set a.[Title Company] = b.[TITLE_COMPANY_NAME]
from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
inner join [deed].[dbo].[deed] b
on a.fips = b.fips and a.FMT_MTG1_DOC_NBR = b.FMT_MTG1_DOC_NBR
and b.Source_Type = 'B'
where a.[Title Company] IN (
             'NEW TITLE COMPANY NAME'
            ,'NONE LISTED ON DOCUMENT'
             )
			 and b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'

			 
update [MiNelson].[dbo].[a]
set a.[Title Company] = b.[TITLE_COMPANY_NAME]
from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
inner join [deed].[dbo].[deed] b
on a.fips = b.fips and a.FMT_MTG1_Book_Page = b.FMT_MTG1_Book_Page
and b.Source_Type = 'B'
where a.[Title Company] IN (
             'NEW TITLE COMPANY NAME'
            ,'NONE LISTED ON DOCUMENT'
             )
			 and b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'

--------using Trustee names

--update a
--  set a.[Title Company] = left(b.Trustee_name, 60)
--  --select count(*)
-- FROM Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
--OUTER APPLY (
--       SELECT top 1 *
--       FROM  Minelson.dbo.TC_Trustee b
--       WHERE b.Fips_code = a.Fips
--             AND b.cmt_docnumber IN (
--                    a.FMT_DOC_NBR
--                    ,a.FMT_Book_Page
--                    ,a.FMT_MTG1_DOC_NBR
--                    ,a.FMT_MTG1_Book_Page
--                    )
--       ) b
--WHERE a.[Title Company] IN ( 'NONE LISTED ON DOCUMENT', 'SIMPLIFILE'  )
--      -- AND len(b.Trustee_name) < 40
--       AND  b.name_identifier = 'C' 
-- and (b.Trustee_name  like '%title%'
--              or  b.Trustee_name   like '%ABSTRACT%'
--             or  b.Trustee_name  like '%SETTLEMENT%'
--             or b.Trustee_name  like '%closing%'
--              or b.Trustee_name  like '%escrow%' 
--              or b.Trustee_name  like '% ttl %' 
--              or b.Trustee_name  like '% t&E %'
--              or  b.Trustee_name    like '%ABS%'
--			  )

  update [MiNelson].[dbo].[a]
  set a.[Title Company] = left(b.Trustee_name, 60)
 -- select *
  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [Minelson].[dbo].[TC_Trustee] b
  on b.Fips_code = a.Fips
  and a.FMT_DOC_NBR = b.cmt_docnumber
   and a.[Title Company] in ( 'SIMPLIFILE','NONE LISTED ON DOCUMENT')
  --and  len(b.Trustee_name ) < 40
  and (b.Trustee_name  like '%title%'
              or  b.Trustee_name   like '%ABSTRACT%'
             or  b.Trustee_name  like '%SETTLEMENT%'
             or b.Trustee_name  like '%closing%'
            --  or b.Trustee_name  like '%escrow%' 
              or b.Trustee_name  like '% ttl %' 
              or b.Trustee_name  like '% t&E %'
              or  b.Trustee_name    like '%ABS%'
			  )
	and a.state not in ('WA', 'OR')

update [MiNelson].[dbo].[a]
  set a.[Title Company] = left(b.Trustee_name, 60)
 -- select *
  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [Minelson].[dbo].[TC_Trustee] b
  on b.Fips_code = a.Fips
  and a.FMT_Book_Page = b.cmt_docnumber
   and a.[Title Company] in ( 'SIMPLIFILE','NONE LISTED ON DOCUMENT')
  --and  len(b.Trustee_name ) < 40
  and (b.Trustee_name  like '%title%'
              or  b.Trustee_name   like '%ABSTRACT%'
             or  b.Trustee_name  like '%SETTLEMENT%'
             or b.Trustee_name  like '%closing%'
            --  or b.Trustee_name  like '%escrow%' 
              or b.Trustee_name  like '% ttl %' 
              or b.Trustee_name  like '% t&E %'
              or  b.Trustee_name    like '%ABS%'
			  )
	and a.state not in ('WA', 'OR')

update [MiNelson].[dbo].[a]
  set a.[Title Company] = left(b.Trustee_name, 60)
 -- select *
  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [Minelson].[dbo].[TC_Trustee] b
  on b.Fips_code = a.Fips
  and a.FMT_MTG1_DOC_NBR = b.cmt_docnumber
   and a.[Title Company] in ( 'SIMPLIFILE','NONE LISTED ON DOCUMENT')
  --and  len(b.Trustee_name ) < 40
  and (b.Trustee_name  like '%title%'
              or  b.Trustee_name   like '%ABSTRACT%'
             or  b.Trustee_name  like '%SETTLEMENT%'
             or b.Trustee_name  like '%closing%'
          --    or b.Trustee_name  like '%escrow%' 
              or b.Trustee_name  like '% ttl %' 
              or b.Trustee_name  like '% t&E %'
              or  b.Trustee_name    like '%ABS%'
			  )
	and a.state not in ('WA', 'OR')

update [MiNelson].[dbo].[a]
  set a.[Title Company] = left(b.Trustee_name, 60)
 -- select *
  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
  inner join [Minelson].[dbo].[TC_Trustee] b
  on b.Fips_code = a.Fips
  and a.FMT_MTG1_Book_Page = b.cmt_docnumber
   and a.[Title Company] in ( 'SIMPLIFILE','NONE LISTED ON DOCUMENT')
  --and  len(b.Trustee_name ) < 40
  and (b.Trustee_name  like '%title%'
              or  b.Trustee_name   like '%ABSTRACT%'
             or  b.Trustee_name  like '%SETTLEMENT%'
             or b.Trustee_name  like '%closing%'
           --   or b.Trustee_name  like '%escrow%' 
              or b.Trustee_name  like '% ttl %' 
              or b.Trustee_name  like '% t&E %'
              or  b.Trustee_name    like '%ABS%'
			  )
	and a.state not in ('WA', 'OR')

  IF OBJECT_ID('[dbo].[UR_TitleMarketShare_BaseTable]') IS NOT NULL  DROP TABLE [dbo].[UR_TitleMarketShare_BaseTable]
  

CREATE TABLE [dbo].[UR_TitleMarketShare_BaseTable](
	[DeedSequence] [int] NOT NULL,
	[Transaction Type] [varchar](31) NOT NULL,
	[Lender] [varchar](30) NOT NULL,
	[Title Company] [varchar](60) NOT NULL,
	[TITLE_COMPANY_CODE] [varchar](5) NULL,
	[Attorney] [varchar](60) NULL,
	[Sale Document number] [varchar](20) NULL,
	[MGT Document number] [varchar](12) NULL,
	[Book/Page] [varchar](13) NULL,
	[Sales Price] [decimal](13, 2) NOT NULL,
	[Loan Amount] [decimal](13, 2) NOT NULL,
	[Loan To Value] [varchar](16) NULL,
	[Date] [date] NULL,
	[Adjustable Rate] [varchar](3) NOT NULL,
	[Loan Type] [varchar](12) NOT NULL,
	[Reverse Mortgage] [varchar](3) NOT NULL,
	[Conforming] [varchar](3) NOT NULL,
	[Builder] [varchar](60) NULL,
	[Seller Name] [varchar](60) NOT NULL,
	[Buyer] [varchar](60) NOT NULL,
	[Residential] [varchar](3) NOT NULL,
	[Corporate] [varchar](3) NOT NULL,
	[City] [varchar](40) NOT NULL,
	[County] [varchar](36) NULL,
	[State] [char](2) NULL,
	[Zip Code] [varchar](5) NOT NULL,
	[FIPS] [int] NULL,
	[Census Tract #] [varchar](4) NOT NULL,
	[Property Type] [varchar](26) NOT NULL,
	[MTG1_CONSTRUCTION_LOAN] [char](1) NULL,
	[REO_SALE_FLAG] [bit] NULL,
	[MTG1_EQUITY_FLAG] [char](1) NULL,
	[MTG1_OTHER_SUBORDINATE_LOANS] [char](1) NULL,
	[TRANSACTION_TYPE] [char](1) NULL,
	[DETAILED_DOC_TYPE] [char](2) NULL,
	[DEED_TYPE] [char](1) NULL,
	[FORCLOSURE] [char](1) NULL,
	[RESALE_NEW_CONSTRUCTION] [char](1) NULL,
	[MULTI_APN] [char](1) NULL,
	[DeedID] [int] NOT NULL,
	[BYR1_CORP_IND] [char](1) NULL,
	[NBR_OF_RES_UNITS] [char](5) NULL,
	[MTG1_PRIVATE_PARTY_LENDER] [char](1) NULL,
	[SELLER_NAME_PLAINTIFF1_CORP_IND] [char](1) NULL,
	[Sales_Source_Ind] [char](3) NULL,
	[REF_ID] [numeric](12, 0) NULL,
	[RECORDING_DATE] [date] NULL,
	[SALE_DATe] [date] NULL,
	[UPDATED] [datetime] NULL,
	[Ass_ZipCode] [char](9) NULL,
	[Year_Built] [char](4) NULL
) ON [PRIMARY]


insert into [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable]
( [DeedSequence]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[TITLE_COMPANY_CODE]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_CONSTRUCTION_LOAN]
      ,[REO_SALE_FLAG]
      ,[MTG1_EQUITY_FLAG]
      ,[MTG1_OTHER_SUBORDINATE_LOANS]
      ,[TRANSACTION_TYPE]
      ,[DETAILED_DOC_TYPE]
      ,[DEED_TYPE]
      ,[FORCLOSURE]
      ,[RESALE_NEW_CONSTRUCTION]
      ,[MULTI_APN]
      ,[DeedID]
      ,[BYR1_CORP_IND]
      ,[NBR_OF_RES_UNITS]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[SELLER_NAME_PLAINTIFF1_CORP_IND]
      ,[Sales_Source_Ind]
      ,[REF_ID]
      ,[RECORDING_DATE]
      ,[SALE_DATe]
      ,[UPDATED]
      ,[Ass_ZipCode]
      ,[Year_Built]
 )
 (select  [DeedSequence]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[TITLE_COMPANY_CODE]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_CONSTRUCTION_LOAN]
      ,[REO_SALE_FLAG]
      ,[MTG1_EQUITY_FLAG]
      ,[MTG1_OTHER_SUBORDINATE_LOANS]
      ,[TRANSACTION_TYPE]
      ,[DETAILED_DOC_TYPE]
      ,[DEED_TYPE]
      ,[FORCLOSURE]
      ,[RESALE_NEW_CONSTRUCTION]
      ,[MULTI_APN]
      ,[DeedID]
      ,[BYR1_CORP_IND]
      ,[NBR_OF_RES_UNITS]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[SELLER_NAME_PLAINTIFF1_CORP_IND]
      ,[Sales_Source_Ind]
      ,[REF_ID]
      ,[RECORDING_DATE]
      ,[SALE_DATe]
      ,[UPDATED]
      ,[Ass_ZipCode]
      ,[Year_Built]
	  from [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc])
  --  select * 
  --  from  mktshr.[TitleMarketShare_County_Source_CutOver] b
  -- where b.source = 'B' and CutOver = 'N'
  

-----borrow from RT ---- adding 7/10/2018 by My Phan

  update [MiNelson].[dbo].[b]
  set b.[title company] = RT_TitleCo
 -- select *
  from  [MiNelson].[mktshr].[BK_vs_RT_Deedid] a
inner join [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] b
on a.deedid = b.deedid
where --b.fips in (15001,15003,15007,15009) and 
b.[title company] is null or b.[title company] in ('NONE AVAILABLE') and 
(RT_TitleCo not in ('','ATTORNEY ONLY', 'other', 'NOT AVAILABLE')
and  RT_TitleCo not like 'E TITLE LLC%'
and RT_TitleCo not like 'INDECOMM%' 
and RT_TitleCo not like 'Document%' 
and RT_TitleCo <> 'DPS' 
and RT_TitleCo not like 'SIMPLIFILE%' 
and RT_TitleCo not  like 'Certified Document%'
and RT_TitleCo not  like'SPL Inc'
and  RT_TitleCo not  like 'ATM corp%'
and RT_TitleCo not  like 'WorldWide%'
and RT_TitleCo not  like  'Texas Recording Services LLC%'
and RT_TitleCo not like 'Doc%'
and RT_TitleCo not  like  'DATA SEARCH%'
and RT_TitleCo not  like  'LENDER RECORDING%'
and RT_TitleCo not  like  'CCS RECORDING TEAM%'
and RT_TitleCo not  like  'Ameristar Info Network Llc%'
and RT_TitleCo not  like  'AMERISTAR INFORMATION NETWORK%'
and RT_TitleCo not like 'ISGN RECORDING DEPT%'
and RT_TitleCo not like 'LSI-LPS E RECORDING SOLUTIONS%'
and RT_TitleCo not like 'CSC DOCUMENT RECORDING%'
and RT_TitleCo not like 'CUSTOM RECORDING SOLUTIONS%'
and RT_TitleCo not like 'US RECORDINGS INC%'
and RT_TitleCo not like 'LSI E RECORDING SOLUTIONS%')

  --- borrow from india research Adding 7/10/2018 by My Phan
  

update [MiNelson].[dbo].[c]
set c.[title company] = b.title_company_on_doc
--select *
from  [MiNelson].[mktshr].[BK_vs_RT_Deedid] a
inner join [Minelson].[mktshr].[FAI_Result_eRecording_Weekly] b
on a.RT_fips = b.fips and (a.Recorder_id +1000000000) = b.Deedid
inner join [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] c 
on a.RT_fips = c.fips and c.Deedid = a.deedid 
where --b.fips in (15001,15003,15007,15009) and 
title_company_on_doc not in ('N/A', 'ACCOMMODATION') 
and ( c.[title company] in ('NONE AVAILABLE', 'ACCOMMODATION') 
 or c.[Title Company] like 'E TITLE LLC%'
or c.[Title Company] like 'INDECOMM%' 
or c.[Title Company] like 'Document%' 
or c.[Title Company] = 'DPS' 
or c.[Title Company] like 'SIMPLIFILE%' 
or c.[Title Company]  like 'Certified Document%'
or c.[Title Company]  like'SPL Inc'
or  c.[Title Company]  like 'ATM corp%'
or c.[Title Company]  like 'WorldWide%'
or c.[Title Company]  like  'Texas Recording Services LLC%'
or c.[Title Company] like 'Doc%'
or c.[Title Company]  like  'DATA SEARCH%'
or c.[Title Company]  like  'LENDER RECORDING%'
or c.[Title Company]  like  'CCS RECORDING TEAM%'
or c.[Title Company]  like  'Ameristar Info Network Llc%'
or c.[Title Company]  like  'AMERISTAR INFORMATION NETWORK%'
or c.[Title Company] like 'ISGN RECORDING DEPT%'
or c.[Title Company] like 'LSI-LPS E RECORDING SOLUTIONS%'
or c.[Title Company] like 'CSC DOCUMENT RECORDING%'
or c.[Title Company] like 'CUSTOM RECORDING SOLUTIONS%'
or c.[Title Company] like 'US RECORDINGS INC%'
or c.[Title Company] like 'LSI E RECORDING SOLUTIONS%')
 
 
-------------Update Opendoor to resale_cash 12/4/2019
--  select * from Minelson.[dbo].[BK_TitleMarketShare_BaseTable]

Update [MiNelson].[dbo].[m] 
Set [Transaction Type] = 'Resale - Cash Sale'
,Lender='UNKNOWN'
,[MGT Document number]=''
,[Sales Price]=case when state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY') then 0 else [Sales Price] end
,[Loan Amount]=0
,[Loan To Value]='No Data'
,[Adjustable Rate]='No'
,[Loan Type]='none'
,[Reverse Mortgage]='No'
,[Conforming]='No'
,MTG1_PRIVATE_PARTY_LENDER=null
--- select *
from 
 [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
inner join [MiNelson].[mktshr].[DirectHome] b on b.Buyer= m.Buyer
where  [Transaction Type] = 'Resale'
and [Sales Price]<1000000
and [Loan Amount]>10000000

-------------Estimated saleprice 12/11/2019 and Loan To Value
--select * from Minelson.[dbo].[BK_TitleMarketShare_BaseTable] 


Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * 1.0225
--- select *
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') ---Adding Indiana per Mike M 12/18/2019
   and [loan type] = 'FHA' 
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI')
   and [loan type] = 'FHA'
   and [Loan To Value]='No Data'

Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * .98
--- select *
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI' ) 
   and [loan type] = 'VA'
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI' ) 
   and [loan type] = 'VA'
   and [Loan To Value]='No Data'
   
Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * 1.33
--- select *
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') 
   and [loan type] not in ('FHA', 'VA'   ) 
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') 
   and [loan type] not in ('FHA', 'VA'   )
   and [Loan To Value]='No Data'


   ---- Remove low values 12/11/2019

   Delete a
 --  select b.[ARMS_LENGTH_ID],  a.*
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]    a 
inner join  [Deed].[dbo].[deed] b
	on a.deedid = b.deedid 
	    where [Transaction Type] in ('Resale', 'Resale - Cash Sale', 'Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale', 
								'REO', 'REO - Cash Sale')
   and ([Sales Price] <> 0 and [Sales Price] <5000)
  -- and  not (  [Loan Amount] <> 0 and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY'))
  -- and not (a.[Sales Price] = 0 and  b.ARMS_LENGTH_ID = 1)   
 --and not (a.[Sales Price] = 0 and [Loan Amount] > 4000) change 12/18/2019 remove per Mike M.
 and not ([Loan Amount] = 0 and [sales price] = 0 and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI')) --- 1/08/2020 not deleting cashsale for nondisclosure and HI

 ---- Update FA

 
Update [MiNelson].[dbo].[a]
set a.[Title Company] = 'FIRST AMERICAN TITLE'
,a.Attorney = 'UNKNOWN'
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  a
where [Title Company] = 'ATTORNEY ONLY' and Attorney like 'first American%'

   /*IF OBJECT_ID('Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc]') IS NOT NULL  */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_BaseTable_FMTDoc]
      IF OBJECT_ID('[dbo].[UR_TitleMarketShare_BaseTable_1]') IS NOT NULL  DROP TABLE [dbo].[UR_TitleMarketShare_BaseTable_1]

	--- update attorney from attorney field from Deed 7/12/2022

 
 update [MiNelson].[dbo].[a]
set a.Attorney = deed.Attorney_Full_Name
FROM  [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  left join [deed].[dbo].[deed] deed
  on a.deedid = deed.deedid		
  where a.Attorney = 'UNKNOWN' 
     and (deed.Attorney_Full_Name is not null
  and deed.Attorney_Full_Name not like 'ERECORDING%'
  and deed.Attorney_Full_Name not like 'SIMPLIFILE%'
  and deed.Attorney_Full_Name not like 'INDECOMM%'
 ) 
 
  update [MiNelson].[dbo].[a]
set a.Attorney = deed.Attorney_Firm_Name

FROM  [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  left join [deed].[dbo].[deed] deed
  on a.deedid = deed.deedid		
  where a.Attorney = 'UNKNOWN' 
     and (deed.Attorney_Full_Name is null and deed.Attorney_Firm_Name is not null)


 --  and left(a.[title company],10) <>  left(deed.Attorney_Full_Name,10)


 ---- take out 6/15/2023
--update a

--set a.Attorney = 
--(case when c.requested_prepared_by_attorney_middle_initial is not null 
--		then concat(requested_prepared_by_attorney_first_name,' ',requested_prepared_by_attorney_middle_initial,' ',requested_prepared_by_attorney_last_company_name) 
--	when (c.requested_prepared_by_attorney_first_name is not null and c.requested_prepared_by_attorney_middle_initial is null) 
--		then concat(requested_prepared_by_attorney_first_name,' ',requested_prepared_by_attorney_last_company_name) 
--else c.requested_prepared_by_attorney_last_company_name end )

--from Minelson.[dbo].[UR_TitleMarketShare_BaseTable] a
--inner join deed.dbo.deed b 
--on a.deedid = b.deedid 
--left join  [Lien].[UR].[DOCUMENT] c
--on b.ur_doc_id = c.doc_id
--where   a.attorney like 'UNKNOWN'
--and a.date >='2021-01-01'
--and b.Attorney_Full_Name is  null
--and  c.[requested_prepared_by_attorney_last_company_name] is not null
--and c.[requested_prepared_by_attorney_last_company_name] <> ''


update [MiNelson].[dbo].[a]
set a.Attorney = a.[Title company]
,a.[Title company] = 'ATTORNEY ONLY'
--select * 
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  where  ( [title company] like '% PLLC'
or [title company] like '% PLC'
or [Title Company] like 'LAW OFFICES OF %'
or ([Title Company] like '% PA' and [Title Company] not like '% of PA')
or [Title Company] like  '% ESQ'
or [Title Company] like '% LLP'
or [Title Company] like '% PC'
or [Title Company] like '% LPA'     
or [Title Company] like '% PL'    
or [Title Company] like '% PS'    
or [Title Company] like '% PSC'   
or [Title Company] like '% SC'    
or [Title Company] like '% LAW'   
or [Title Company] like '% LAW GROUP'
or [Title Company] like '% LAW FIRM'
or [Title Company] like '% LAW OFFICE'
or [Title Company] like '% FIRM %'
or [Title Company] like '% FIRM'
or [Title Company] like '% LEGAL SERVICES %'
or [Title Company] like '% LEGAL SERVICES'
or [Title Company] like '% LEGAL SVCS %'
or [Title Company] like '% LEGAL SVCS'
or [Title Company] like '% PARALEGAL SERVICES %'
or [Title Company] like '% PARALEGAL SERVICES'
or [Title Company] like '% PARALEGAL SVCS %'
or [Title Company] like '% PARALEGAL SVCS'
or [Title Company] like '% LICENSED ATTORNEY %'
or [Title Company] like '% LICENSED ATTORNEY'
or [Title Company] like '% ATTORNEY %'
or [Title Company] like '% ATTORNEY'
or [Title Company] like '% ATTORNEY AT LAW %'
or [Title Company] like '% ATTORNEY AT LAW'
or [Title Company] like '% ATTORNEYS AT LAW %'
or [Title Company] like '% ATTORNEYS AT LAW'
or [Title Company] like '% ATTORNEY-AT-LAW %'
or [Title Company] like '% ATTORNEY-AT-LAW'
or [Title Company] like '% ATTORNEYS-AT-LAW %'
or [Title Company] like '% ATTORNEYS-AT-LAW'
or [Title Company] like '% COUNSELLOR AT LAW %'
or [Title Company] like '% COUNSELLOR AT LAW'
or [Title Company] like '% ESQUIRE %'
or [Title Company] like '% ESQUIRE'
or [Title Company] like '% ESQ.'
         )


  and 
          ( [Title Company] not like '%title%'
              and  [Title Company]  not like '%ABSTRACT%'
              and  [Title Company] not like '%SETTLEMENT%'
              and [Title Company] not like '%closing%'
              and [Title Company] not like '%escrow%' 
              --and [Title Company] not like '%services%'
              and [Title Company] not like '% ttl %' 
              and [Title Company] not like '% t&E %'
              and  [Title Company]   not like '%ABS%'
              and   [Title Company]  not like '%#NAME%'
and  [Title Company]  not like '%CORPORATION%'
and  [Title Company]  not like '%DOCUMENT%'
and  [Title Company]  not like '%ENGINEER%'
and  [Title Company]  not like '%MORTGAGE%'
and  [Title Company]  not like '%PARTNERSHIP%'
and  [Title Company]  not like '%RECORDER%'
and  [Title Company]  not like '%SURVEY%'
and  [Title Company]  not like '%TITLE%'
and  [Title Company]  not like '%TOWNSHIP%'
and  [Title Company]  not like '%STATE OF%'
and  [Title Company]  not like '%OF PA%'
and  [Title Company]  not like '%PHILADELPHIA PA%'
and  [Title Company]  not like '%IRWIN PA%'
and  [Title Company]  not like '%CORAPOLIS PA%'
              )

	
---- change high loan value to 04/27/2022
update [MiNelson].[dbo].[a]
set a.[Loan Amount] = 0
FROM
       [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
	   inner join
  [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  inner join
       [Assr].[dbo].[Assr] c on
             b.Ref_Id = c.Ref_Id
             and b.Fips = c.Fips
where
   
  a.[Transaction Type] in ( 'Refinance')
       and a.[Loan Amount] > 10000000 
  and a.[Loan Amount] > (case when c.Total_Value_Calculated is not null then c.Total_Value_Calculated else 0 end)*10
     and (case when (a.[loan amount] is not null and c.Total_Value_Calculated is not null) then cast((100*a.[Loan Amount]/(c.Total_Value_Calculated+1)) as float) else null end ) > 1000
 and a.Residential = 'YES'


 ----- Update title company from RT 5/4/2022 --- take out 2/6/2023 since we dont have RT data anymore

-- --select *  FROM  Minelson.[dbo].[UR_TitleMarketShare_BaseTable] a

--	  update m
--	  set m.[Title Company] = r.SR_TITLE_CO_NAME
-- FROM Minelson.[dbo].[UR_TitleMarketShare_BaseTable] m 
--inner join 
--Deed.dbo.Deed ur
--on m.deedid = ur.deedid
--inner join
--[MiNelson].[dbo].[My_rt_doc_formats] r
--on ur.fips = r.fips and ur.FMT_DOC_NBR = r.FMT_DOC_NBR
--and ur.recording_date = (left(r.[SR_DATE_TRANSFER],4) + '-' + left(right(r.[SR_DATE_TRANSFER],4),2) + '-' + right(r.[SR_DATE_TRANSFER],2))
--where ur.source_type = 'E'
--and  m.[title company] in ('NONE LISTED ON DOCUMENT', 'NEW TITLE COMPANY NAME')
--and (sr_title_co_name  not like '@%'
--and sr_title_co_name  not like 'INDECOMM%' 
--and sr_title_co_name not like 'ATTORNEY ONLY'
--and sr_title_co_name not like  'Texas Recording Service%'
--and sr_title_co_name  not like  'DATA SEARCH%'
--and sr_title_co_name not like  'LENDER RECORDING%'
--and sr_title_co_name not like  'CCS RECORDING TEAM%'
--and sr_title_co_name not like  'Ameristar Info Network Llc%'
--and sr_title_co_name not like  'AMERISTAR INFORMATION NETWORK%'
--and sr_title_co_name not like 'ISGN RECORDING DEPT%'
--and sr_title_co_name not like 'LSI-LPS E RECORDING SOLUTIONS%'
--and sr_title_co_name not like 'CSC DOCUMENT RECORDING%'
--and sr_title_co_name not like 'CUSTOM RECORDING SOLUTIONS%'
--and sr_title_co_name not like 'US RECORDINGS INC%'
--and sr_title_co_name not like 'LSI E RECORDING SOLUTIONS%')

-- update m
--	  set m.[Title Company] = r.SR_TITLE_CO_NAME
--FROM  Minelson.[dbo].[UR_TitleMarketShare_BaseTable] m 
--inner join 
--Deed.dbo.Deed ur
--on m.deedid = ur.deedid
--inner join
--[MiNelson].[dbo].[My_rt_doc_formats] r
--on ur.fips = r.fips and ur.[FMT_Book_Page] = r.[FMT_Book_Page] and ur.recording_date = (left(r.[SR_DATE_TRANSFER],4) + '-' + left(right(r.[SR_DATE_TRANSFER],4),2) + '-' + right(r.[SR_DATE_TRANSFER],2))
--where m.[sale document number] is null and ur.source_type = 'E'
--and  m.[title company] in ('NONE LISTED ON DOCUMENT', 'NEW TITLE COMPANY NAME')
--and (sr_title_co_name  not like '@%'
--and sr_title_co_name  not like 'INDECOMM%' 
--and sr_title_co_name not like 'ATTORNEY ONLY'
--and sr_title_co_name not like  'Texas Recording Service%'
--and sr_title_co_name  not like  'DATA SEARCH%'
--and sr_title_co_name not like  'LENDER RECORDING%'
--and sr_title_co_name not like  'CCS RECORDING TEAM%'
--and sr_title_co_name not like  'Ameristar Info Network Llc%'
--and sr_title_co_name not like  'AMERISTAR INFORMATION NETWORK%'
--and sr_title_co_name not like 'ISGN RECORDING DEPT%'
--and sr_title_co_name not like 'LSI-LPS E RECORDING SOLUTIONS%'
--and sr_title_co_name not like 'CSC DOCUMENT RECORDING%'
--and sr_title_co_name not like 'CUSTOM RECORDING SOLUTIONS%'
--and sr_title_co_name not like 'US RECORDINGS INC%'
--and sr_title_co_name not like 'LSI E RECORDING SOLUTIONS%')


-------- Delete Covid Partial Claim HUD 6/29/2022

Delete a
--select a.* 
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
inner join [MiNelson].[mktshr].[LenderClean_BK] l on
a.Lender = l.Lender
where  --fips in  (41005,41067,41051) and 
left(date,7) >= '2022-01' and 
[Loan Amount] <50000
and [Lender Clean] != 'UNKNOWN'
and ([Lender Clean] = 'HUD'
                or [Lender Clean] like 'SECRETARY OF HOUSING%'
                or [Lender Clean] like 'FEDERAL HOUSING COMMISSIONER%'
                or [Lender Clean] like 'US DEPARTMENT OF HOUSING%'
                or [lender clean] like 'COMMISSIONER OF HOUSING%'
                or [lender clean] like 'SECRETARY OF THE US DEPARTMENT%'
                or [lender clean] like 'SECRETARY OF VETERANS AFFAIRS%'
                or [lender clean] like 'UNITED STATES OF AMERICA%'
                  or a.[Lender] like 'SECRETARY OF HOUSING%'
                or a.[Lender] like 'FEDERAL HOUSING COMMISSIONER%'
                or a.[Lender] like 'US DEPARTMENT OF HOUSING%'
                or a.[lender] like 'COMMISSIONER OF HOUSING%'
                or a.[lender] like 'SECRETARY OF THE US DEPARTMENT%'
                or a.[lender] like 'SECRETARY OF VETERANS AFFAIRS%'
                or a.[lender] like 'UNITED STATES OF AMERICA%'
                )
and a.[Lender] is not Null  
and [Transaction Type] not like 'Timeshare%'


---- Update loan type 6/29/2022

 update [MiNelson].[dbo].[a]
  set a.[Loan Type] = 'Conventional'
--select a.*
from  [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
inner join [Deed].[dbo].[deed] b
on a.deedid = b.deedid 
where [loan amount] <> 0 and [Loan Type] = 'none' 
and b.MTG1_DETAILED_DOC_TYPE in ('TR', 'MG')
and b.mtg1_construction_loan  is null
and Date > '2022-01-01' and Residential ='Yes'

 
 ----- update conforming 7/6/2022
 update [MiNelson].[dbo].[a]
set a.[Conforming] =  (case when a.[LOAN TYPE] = 'Conventional' then
                  case 
                        when a.NBR_OF_RES_UNITS = 1 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        when a.NBR_OF_RES_UNITS = 2 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
                        when a.NBR_OF_RES_UNITS = 3 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
                        when a.NBR_OF_RES_UNITS = 4 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
                        when (a.NBR_OF_RES_UNITS = 0 or a.NBR_OF_RES_UNITS is Null) 
                              and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        else 'NO'
                  end
                  else 'NO'
            end)
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  left join [deed].[dbo].[deed] deed
  on a.deedid = deed.deedid
   left  join [Assr].[dbo].[Assr] assr  with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
                 deed.REF_ID = assr.REF_ID
  left join [MiNelson].[mktshr].[ConformingLimits] cnf with (Nolock) on
                  deed.FIPS = cnf.fips

--- update upper case title company name 7/12/2022
update [MiNelson].[dbo].[a]
		set [Title Company] = Upper([Title Company])
		FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a

----- update Premier title for HI 10/4/2022

update [MiNelson].[dbo].[a]
set a.[Title Company] = 'PREMIER TITLE'
FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
where state = 'HI' and [title company] like 'PREMIER TITLE%'
  and [Title Company] <> 'PREMIER TITLE'

  ---------------update STA for AK 11/28/2023

  update [MiNelson].[dbo].[a]
set a.[Title Company] = 'STEWART TITLE OF ALASKA'
FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
where state = 'AK' and [title company] like 'STA%'


-----update TITLE GUARANTY OF HAWAII INC 9/6/2023

update [MiNelson].[dbo].[a] 
set a.[Title Company] = 'TITLE GUARANTY OF HAWAII INC'
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  where ([Title Company] like 'TITLE GUARANTY%' or [Title Company] = 'TG')
  and state = 'HI'

--- update HI Fips 1/3/2023


	    
	update [MiNelson].[dbo].[a]
	set a.Fips = 15007,
	a.County = 'KAUAI'
	--- select a.*
  FROM   [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and len(original_apn) = 18
  and a.fips <> 15007   and left(original_apn, 1) = '4'
 
    
	update [MiNelson].[dbo].[a]
	set a.Fips = 15001,
	a.County = 'HAWAII'
	--- select a.*
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and len(original_apn) = 18
  and a.fips <> 15001   and left(original_apn, 1) = '3'

		
			update [MiNelson].[dbo].[a]
	set a.Fips = 15009,
	a.County = 'MAUI'
	--- select a.*
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and len(original_apn) = 18
  and a.fips <> 15009   and left(original_apn, 1) = '2'


    

   
	update [MiNelson].[dbo].[a]
	set a.Fips = 15001,
	a.County = 'HAWAII'
	--- select a.*
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and a.fips <> 15001 
  and ((substring(original_apn,1,1) = '(' and substring(original_apn,2,1) = '3')
		or   (substring(original_apn,2,1) = '/' and substring(original_apn,1,1) = '3'))


  update [MiNelson].[dbo].[a]
	set a.Fips = 15007,
	a.County = 'KAUAI'
	--- select a.*
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and a.fips <> 15007
  and ((substring(original_apn,1,1) = '(' and substring(original_apn,2,1) = '4')
		or   (substring(original_apn,2,1) = '/' and substring(original_apn,1,1) = '4'))

  
  update [MiNelson].[dbo].[a]
	set a.Fips = 15009,
	a.County = 'MAUI'
	--- select a.*
  FROM [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  where state = 'HI' and date > '2022-01-01'
  and b.ref_id is null and original_apn is not null 
  and a.fips <> 15009
  and ((substring(original_apn,1,1) = '(' and substring(original_apn,2,1) = '2')
		or   (substring(original_apn,2,1) = '/' and substring(original_apn,1,1) = '2'))

		
		-------------------------Fix merging---------20230322

		
    /*IF OBJECT_ID('Minelson.dbo.Marketshare_WeeklyMergFix_Before') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Marketshare_WeeklyMergFix_Before]


  select * into [Minelson].[dbo].[Marketshare_WeeklyMergFix_Before]
 from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  where 
 [transaction type] in ( 'refinance', 'Resale - Cash Sale')

 
    /*IF OBJECT_ID('Minelson.dbo.Marketshare_WeeklyMergFix') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Marketshare_WeeklyMergFix]

  

   select a.DeedID as Refi_Deedid, b.DeedID as Resale_Deedid, a.[Transaction Type] as Refi_transc, b.[Transaction Type] as resale_trans,
 a.ref_id as Refi_Ref_id, b.Ref_ID as Resale_ref_id, a.[Sale Document number] as Refi_Sale_Document_number, b.[Sale Document number] as Resale_Sale_Document_number,
 a. [MGT Document number] as Refi_Mgt_Document_number,  b.[MGT Document number] as Resale_Mgt_Document_number
 ,a.lender as Refi_Lender, b.lender as resale_lender, a.[Loan Amount] as Refi_Loan_Amount, b.[Loan Amount] as Resale_Loan_Amount
 ,a.[Loan Type] as Refi_Loantype, b.[Loan Type] as Resale_Loantype, a.Conforming as Refi_conforming, b.Conforming as Resale_conforming
 ,a.[Adjustable Rate] as Refi_AdjustRate, b.[Adjustable Rate] as Resale_AdjustRate
 into [Minelson].[dbo].[Marketshare_WeeklyMergFix]
 from [Minelson].[dbo].[Marketshare_WeeklyMergFix_Before] a
 inner join  [Minelson].[dbo].[Marketshare_WeeklyMergFix_Before] b 
 on a.Ref_id = b.ref_id and a.date = b.date 
 where a.[transaction type] = 'Refinance' and a.[Loan Amount] <> 0 
 and b.[transaction type] = 'Resale - Cash Sale' 
 order by a.Ref_ID

 
 /*IF OBJECT_ID('Minelson.dbo.Marketshare_WeeklyRefi_NeedtoDelete') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Marketshare_WeeklyRefi_NeedtoDelete]


 select * into [Minelson].[dbo].[Marketshare_WeeklyRefi_NeedtoDelete]
 from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
 where deedid in ( select  refi_Deedid from [Minelson].[dbo].[Marketshare_WeeklyMergFix])
 and [Transaction Type] = 'Refinance' and a.[Loan Amount] <> 0 

 /*IF OBJECT_ID('Minelson.dbo.Marketshare_WeeklyResale_NeedtoMergMgt') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Marketshare_WeeklyResale_NeedtoMergMgt]

  select * into [Minelson].[dbo].[Marketshare_WeeklyResale_NeedtoMergMgt]
  from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  b
 where deedid in ( select  Resale_Deedid from [Minelson].[dbo].[Marketshare_WeeklyMergFix])
  and b.[transaction type] = 'Resale - Cash Sale' 
 


 update [MiNelson].[dbo].[a]
 set a.[Transaction Type] = 'Resale'
 , a.lender = b.Refi_Lender, a.[MGT Document number] = b.Refi_Mgt_Document_number
 , a.[Loan Amount] = b.Refi_Loan_Amount, a.[Loan Type] = b.Refi_Loantype, a.Conforming = b.Refi_conforming
  ,a.[Adjustable Rate] = b.Refi_AdjustRate

 from [Minelson].[dbo].[Marketshare_WeeklyResale_NeedtoMergMgt] a
 inner join [Minelson].[dbo].[Marketshare_WeeklyMergFix] b
on  a.deedid = b.Resale_deedid 


update [MiNelson].[dbo].[deed]
set deed.[Loan To Value] = (case when deed.[Loan Amount] is not Null and deed.[Sales Price] is not Null and deed.[Sales Price] != 0
                  then convert(varchar(15),round(convert(float,deed.[Loan Amount]/deed.[Sales Price]*100),2)) + '%'
                  else 'No Data'
            end)
from  [Minelson].[dbo].[Marketshare_WeeklyResale_NeedtoMergMgt] deed

--select * from   Minelson.[dbo].[UR_TitleMarketShare_BaseTable]

--select * from  Minelson.dbo.Marketshare_WeeklyResale_NeedtoMergMgt

--select *  from Minelson.dbo.Marketshare_WeeklyMergFix

--- delete refi
 --select * from Minelson.[dbo].[UR_TitleMarketShare_BaseTable] a
 --inner join  Minelson.dbo.Marketshare_WeeklyRefi_NeedtoDelete b
 --on a.deedid = b.deedid and a.DeedSequence = b.DeedSequence
 
  delete a from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
 inner join  [Minelson].[dbo].[Marketshare_WeeklyRefi_NeedtoDelete] b
 on a.deedid = b.deedid and a.DeedSequence = b.DeedSequence

  ---- update resale 
 --select  a.[Transaction Type] , b.[Transaction Type]
 --, a.lender , b.Lender, a.[MGT Document number] ,b.[MGT Document number]
 --, a.[Loan Amount] , b.[Loan Amount], a.[Loan Type] , b.[Loan Type] , a.Conforming , b.conforming

 --,a.[Adjustable Rate] , b.[Adjustable Rate]
 
 --,a.[Loan To Value], b.[Loan To Value]
 --from Minelson.[dbo].[UR_TitleMarketShare_BaseTable] a
 --inner join  Minelson.dbo.Marketshare_WeeklyResale_NeedtoMergMgt  b
 --on a.deedid = b.deedid and a.DeedSequence = b.DeedSequence
 
 update [MiNelson].[dbo].[a] 
 set a.[Transaction Type] = b.[Transaction Type]
 , a.lender = b.Lender, a.[MGT Document number] =b.[MGT Document number]
 , a.[Loan Amount] = b.[Loan Amount], a.[Loan Type] = b.[Loan Type] , a.Conforming = b.conforming
 ,a.[Adjustable Rate] = b.[Adjustable Rate]
 ,a.[Loan To Value]= b.[Loan To Value]
 from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
 inner join  [Minelson].[dbo].[Marketshare_WeeklyResale_NeedtoMergMgt]  b
 on a.deedid = b.deedid and a.DeedSequence = b.DeedSequence

 ----- remove cashsale in non disclosure state

delete a
  from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
    where date >= '2017-01-01' and 
	[Transaction Type] in ( 'Resale - Cash Sale')
  and residential = 'Yes' 
 and (left([seller name],5) = left(buyer,5)   
 or b.DETAILED_DOC_TYPE  in ( 'DI', 'CD','EX','AF','VL', 'AD', 'AN', 'ID', 'QC', 'GF'))
      and [Sales Price] = 0 and State  in ('AK', 'ID', 'IN', 'KS', 'LA','ME','MS', 'MO', 'MT', 'NM', 'ND', 'TX', 'UT' ,'WY')

---362,542
---	  select *   from Minelson.[dbo].[UR_TitleMarketShare_BaseTable]


------Remove HI duplicates Remove Torrens recording which start with 1 in docnumber 10/17/2023

delete a
--select a.*  
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
inner join  (
	select  y.DeedID , y.DeedSequence
 	from  (select a.*,  b.APN_unformatted 
		from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
		inner join [deed].[dbo].[deed] b
		on a.deedid = b.deedid
		where state = 'HI'-- and date > '2023-01-01' 
		and b.Ref_id is not null and b.APN_unformatted is not null
		and (substring ( a.[Sale Document number],5,1) = '8'  or right( a.[Sale Document number],1) = 'A')
	)x
	inner join 
   
	(select a.*, b.APN_unformatted 
		from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
		left join [deed].[dbo].[deed] b
		on a.deedid = b.deedid
		where state = 'HI' --and date > '2023-01-01' 
		and b.Ref_id is not null and b.APN_unformatted is not null
		and (substring ( a.[Sale Document number],5,1) = '1' or right( a.[Sale Document number],1) = 'T')
	)y
	on  x.fips = y.fips and x.ref_id = y.ref_id
	and x.APN_unformatted = y.APN_unformatted
	and x.[Transaction Type] =y.[Transaction Type]
	--and x.[Lender] = y.[Lender]
	--and x.[Title Company] =y.[Title Company]
	--and x.[Attorney] =y.[Attorney]
	and x.[Sales Price] = y.[Sales Price]
	and x.[Loan Amount] = y.[Loan Amount]
	and x.[Date] = y.[Date]
	--and x.[Builder] =y.[Builder]
	--and x.[Seller Name] =  y.[Seller Name]
	--and x.[Buyer] =y.[Buyer]
	and x.DeedID <> y.DeedID 
	and y.deedid is not null
)b
  on a.DeedID = b.DeedID and a.DeedSequence = b.DeedSequence


   ----- change to unknown for FAMS with City Lending 9/25/2024 per Janice Letcher and Tracy Wayland
   
update [MiNelson].[dbo].[a]
set [title company] =   'UNKNOWN'
-- select * 
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
where  ( [title company] like 'FIRST AMERICAN MORTGAGE%'or [title company] like 'FAMS%')
and lender like 'City Lending %' 

   --- update lender account 2026/07/22

update [MiNelson].[dbo].[a]
set lender  =   'UNKNOWN'
-- select *
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
where  
                lender like '%Account%'

                and lender not like '%Accounting%'

                and lender not like '%Accountan%'

                and lender not like '%Account'

                and lender not like '%Account llc%'

--- Change to Venture Title & Escrow for ID per Coreln 2024-12-18

update [MiNelson].[dbo].[a]
set [title company] =   'VENTURE TITLE & ESCROW'
-- select * 
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a
  where [title company] like 'VENTURE TITLE%'
  and state = 'ID'

------ change Residential type for HI 2025-03-12

 /*IF OBJECT_ID('Minelson.dbo.HI_Reset_Residential') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[HI_Reset_Residential]



select  '0' Set_By,  a.* ,  [IMPROVEMENT_VALUE_CALCULATED] ,[MKT_IMPROVEMENT_VALUE] ,[APPR_IMPROVEMENT_VALUE],[Land_Use], [PROPERTY_INDICATOR],assr.[created]
into [Minelson].[dbo].[HI_Reset_Residential]
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable] a 
inner join [Assr].[dbo].[Assr] assr with (Nolock) on
               a.FIPS = assr.FIPS and
              a.REF_ID = assr.REF_ID
where state = 'HI' and date >= '2023-11-01' and residential = 'NO'
and a.[transaction type] in ('Resale - Cash Sale', 'Resale', 'REO - Cash Sale', 'REO')


---  1)	Set Residential to Yes when and nbr_of_res_units <2 
---2)	Set Residential to Yes when Property Type = Agricultural and # of Buildings = 1 

update [MiNelson].[dbo].[a]
set a.set_by = '1' , a.Residential = 'YES'
--select *
from  [Minelson].[dbo].[HI_Reset_Residential] a
where  nbr_of_res_units <2 and  [Property Type] in ( 'Agricultural' )
and Fips = 15001


update [MiNelson].[dbo].[a]
set a.set_by = '1' , a.Residential = 'YES', a.[Property Type] = 'Unknown'
--select *
from  [Minelson].[dbo].[HI_Reset_Residential] a
where  nbr_of_res_units <2 and  [Property Type] in (  'Commercial')
and Fips = 15001


---3)	Set Residential to Yes when Property Type = Agricultural when improvement val is > 10,000


update [MiNelson].[dbo].[a]
set a.set_by = '3' , a.Residential = 'YES'
--select *
from  [Minelson].[dbo].[HI_Reset_Residential] a
where  [Property Type] = 'Agricultural' 
and [IMPROVEMENT_VALUE_CALCULATED] >10000 and set_by = '0'

---4)	Set Residential to Yes when Property Type = Agricultural when sale price is > 30,000

update [MiNelson].[dbo].[a]
set a.set_by = '4' , a.Residential = 'YES'
--select *
from  [Minelson].[dbo].[HI_Reset_Residential] a
where  [Property Type] = 'Agricultural' and set_by = '0'
and [Sales Price] > 80000 and fips = 15001


---- 5 set Residential to Y when Land_Use = 465
update [MiNelson].[dbo].[a]
set a.set_by = '5' , a.Residential = 'YES'
--select *
from  [Minelson].[dbo].[HI_Reset_Residential] a
where  Land_Use = '465'  and set_by = '0'

--- 6 Set prop_ind =10
update [MiNelson].[dbo].[a]
set a.set_by = '6' , a.Residential = 'YES' ,  a.[Property Type] = 'Unknown'
--select *
 from [Minelson].[dbo].[HI_Reset_Residential] a
where property_indicator = '10' and set_by = '0'

update [MiNelson].[dbo].[a]
set 
a.Residential = b.Residential,
a.[Property type] = b.[Property type]
--select a.Residential , b.Residential,a.[Property type] , b.[Property type]
 from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  a
 inner join [Minelson].[dbo].[HI_Reset_Residential] b
 on a.deedid = b.deedid and a.deedsequence = b.deedsequence
 where set_by <> '0'

  /*IF OBJECT_ID('Minelson.dbo.HI_Reset_Residential') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[HI_Reset_Residential]



  ---- delete future date
delete
from [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]  
where date >CONVERT(varchar(10), GETDATE(),126)

	update [MiNelson].[dbo].[a]
		set [county] = Upper([county])
		-- select *
		FROM  [Minelson].[dbo].[UR_TitleMarketShare_BaseTable]      a
		where county  COLLATE Latin1_General_CS_AS LIKE '%[abcdefghijklmnopqrstuvwxyz]%';


END  





