SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [zCust_WellsFargo].[dbo].[usp_300_Start_Output_S17]

AS
BEGIN
	
	SET NOCOUNT ON;

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,


			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT Unit Number][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,

			[SitusFullStreetAddress][varchar](250)NULL,
			[SitusHouseNbr][varchar](250)NULL,
			[SitusHouseNbrSuffix][varchar](250)NULL,
			[SitusDirectionLeft][varchar](250)NULL,
			[SitusStreet][varchar](250)NULL,
			[SitusMode][varchar](250)NULL,
			[SitusDirectionRight][varchar](250)NULL,
			[SitusUnitType][varchar](250)NULL,
			[SitusUnitNbr][varchar](250)NULL,
			[SitusCity][varchar](250)NULL,
			[SitusState][varchar](250)NULL,
			[SitusZIP5][varchar](250)NULL,
			[SitusZIP4][varchar](250)NULL,


			
			[Run Date][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[AVM Coverage][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
		
		
			[PowerFinalValue][varchar](250)NULL,
			[PowerHighValue][varchar](250)NULL,
			[PowerLowValue][varchar](250)NULL,
			[PowerConfidenceScore][varchar](250)NULL,
			[PowerStandardDeviation][varchar](250)NULL,
			[PowerValuationDate][varchar](250)NULL,
			[PowerVersion][varchar](250)NULL,

			[PremierFinalValue][varchar](250)NULL,
			[PremierHighValue][varchar](250)NULL,
			[PremierLowValue][varchar](250)NULL,
			[PremierConfidenceScore][varchar](250)NULL,
			[PremierStandardDeviation][varchar](250)NULL,
			[PremierValuationDate][varchar](250)NULL,
			[PremierVersion][varchar](250)NULL,

		
			[LastArmsLengthSaleRecordingDate][varchar](250)NULL,
			[LastArmsLengthSalePrice][varchar](250)NULL


			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],
		[INPUT Address],
		[INPUT Unit Number],
		[INPUT City],
		[INPUT State],
		[INPUT Zip])
		
		Select 
		seqid	
		,REPLACE(REPLACE((address ),'NULL ',''),'  ',' ')
		,REPLACE(REPLACE((unit_nbr ),'NULL ',''),'  ',' ')
		,city
		,state
		,zip5
		From [zCust_WellsFargo].[dbo].[INPUT_RAW_CUST_NEW]
		

		Select * From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]


		UPDATE [zCust_WellsFargo].[dbo].[a] 
		SET 
		a.WORK_REF_ID = c.REF_ID
		,A.PropertYID =C.PropertYID
		,A.FIPS = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		, a.[RUN Date] = convert(date,GetDate())
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_WellsFargo].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT Key] = c.RAW_ID

	
		
		Update [zCust_WellsFargo].[dbo].[a]
		SET 
		A.[SitusFullStreetAddress] = B.[SitusSTDFullStreetAddress]
		,A.[SitusHouseNbr] = B.[SitusSTDHouseNbr]
		,A.[SitusHouseNbrSuffix] = B.[SitusSTDHouseNbrSuffix]
		,A.[SitusDirectionLeft] = B.[SitusSTDDirectionLeft]
		,A.[SitusStreet] = B.[SitusSTDStreet]
		,A.[SitusMode] = B.[SitusSTDMode]
		,A.[SitusDirectionRight] = B.[SitusSTDDirectionRight]
		,A.[SitusUnitType] = B.[SitusSTDUnitType]
		,A.[SitusUnitNbr] = B.[SitusSTDUnitNbr]
		,A.[SitusCity] = B.[SitusSTDCity]
		,A.[SitusState] = B.[SitusSTDState]
		,A.[SitusZIP5] = B.[SitusSTDZIP5]
		,A.[SitusZIP4] = B.[SitusSTDZIP4]
		--,A.[LastArmsLengthSaleRecordingDate] = B.Currsalerecordingdate
		--,A.[LastArmsLengthSalePrice] = B.CurrSalesPrice
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[Property] as B with(NOLOCK)
		on A.FIPS = B.FIPS and A.PROPERTYID = B.PropertyID


		--UPDATE a 
		--SET 
		--A.[LastArmsLengthSaleRecordingDate] = B.Currsalerecordingdate
		--,A.[LastArmsLengthSalePrice] = B.CurrSalesPrice
		----Select top 10 * 
		--FROM x_Custom_OUTPUT a JOIN data.dbo.Property as B with(NOLOCK)
		--on A.FIPS = B.FIPS and A.PROPERTYID = B.PropertyID

	
	

		-------POWER AND PREMIER------
		Update [zCust_WellsFargo].[dbo].[a]
		set [AVM Coverage] = 1
		--Select B.*
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a JOIN 
		(Select FIPS, count(*) T from [data].[dbo].[vAVM_Holocron] with(NOLOCK)
		where FIPS in 
			(Select Distinct FIPS From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] with(NOLOCK)
			where FIPS is not null)
		Group by FIPS) B  
		ON a.FIPS = b.FIPS



		Update [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] 
		SET [AVM Coverage] = CASE WHEN [AVM Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_WellsFargo].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_WellsFargo].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID

		
		Update [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END
				

		UPDATE [zCust_WellsFargo].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a join [zCust_WellsFargo].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		

	--------POWER AND PREMIER------
	

		UPDATE [zCust_WellsFargo].[dbo].[A]
		SET 
	
		A.[PowerFinalValue] = convert(bigint,convert(Money,B.[POWER_FInal_Value]))
		,A.[PowerHighValue] = convert(bigint,convert(Money,B.[POWER_HIGH_Value]))
		,A.[PowerLowValue] = convert(bigint,convert(Money,B.[POWER_LOW_Value]))
		,A.[PowerConfidenceScore] = B.[POWER_CONFIDENCE_SCORE]
		,A.[PowerStandardDeviation] = B.[POWER_FORECAST_STANDARD_DEVIATION]
		,A.[PowerValuationDate] = Convert(date,B.[ValuationDate])
		,A.PowerVersion = '.001'	
		-----Added 20240502 per MS & BR--to pull from PROCISION & NO LONGER FLANK----
		,A.[LastArmsLengthSaleRecordingDate] = B.LASTKNOWNSALEDATE
		,A.[LastArmsLengthSalePrice] = B.LASTKNOWNSALEPRICE
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  B.POWER_FINAL_VALUE > 0


		------20230906 One time force per MS----------------------------------------
		
		--UPDATE x_Custom_OUTPUT_20230907
		--SET 
		--[PowerFinalValue] = NULL
		--,[PowerHighValue] = NULL
		--,[PowerLowValue] = NULL
		--,[PowerConfidenceScore] = NULL
		--,[PowerStandardDeviation] = NULL
		--,[PowerValuationDate] = NULL
		--,PowerVersion = NULL
		--,[PREMIERFinalValue] = NULL
		--,[PREMIERHighValue] = NULL
		--,[PREMIERLowValue] = NULL
		--,[PREMIERConfidenceScore] = NULL
		--,[PREMIERStandardDeviation] = NULL
		--,[PREMIERValuationDate] = NULL
		--,PremierVersion = NULL
		--,[Event Status] = NULL

		--UPDATE x_Custom_OUTPUT_20230907
		--set [Run Date] = convert(date,getdate())
		--,LastArmsLengthSaleRecordingDate = NULL
		--,LastArmsLengthSalePrice = NULL

		--Update A
		--Set	
		--A.[PowerFinalValue] = convert(bigint,convert(Money,B.[POWER_FInal_Value]))
		--,A.[PowerHighValue] = convert(bigint,convert(Money,B.[POWER_HIGH_Value]))
		--,A.[PowerLowValue] = convert(bigint,convert(Money,B.[POWER_LOW_Value]))
		--,A.[PowerConfidenceScore] = B.[POWER_CONFIDENCE_SCORE]
		--,A.[PowerStandardDeviation] = B.[POWER_FORECAST_STANDARD_DEVIATION]
		--,A.[PowerValuationDate] = Convert(date,B.[VALUE_AS_OF])
		--,A.PowerVersion = '.001'	
		----Select A.WORK_REF_ID,  A.[PowerFinalValue],A.[Run Date], B.[POWER_FInal_Value]
		--FROM x_Custom_OUTPUT_20230907 a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
		--where  B.POWER_FINAL_VALUE > 0

		--Update A
		--Set	
		--A.[PremierFinalValue] = convert(bigint,convert(Money,B.[Premier_FInal_Value]))
		--,A.[PremierHighValue] = convert(bigint,convert(Money,B.[Premier_HIGH_Value]))
		--,A.[PremierLowValue] = convert(bigint,convert(Money,B.[Premier_LOW_Value]))
		--,A.[PremierConfidenceScore] = B.[Premier_CONFIDENCE_SCORE]
		--,A.[PremierStandardDeviation] = B.[Premier_FORECAST_STANDARD_DEVIATION]
		--,A.[PremierValuationDate] = Convert(date,B.[VALUE_AS_OF])
		--,A.PremierVersion = '.001'	
		----Select A.WORK_REF_ID,  A.[PremierFinalValue],A.[Run Date], B.[Premier_FInal_Value]
		--FROM x_Custom_OUTPUT_20230907 a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
		--where  B.Premier_FINAL_VALUE > 0

		--Select * From x_Custom_OUTPUT_20230907

		--------Old populated but new is not
		--Select A.WORK_REF_ID,  A.[PowerFinalValue], B.[POWER_FInal_Value]
		--,A.PremierFinalValue, B.[Premier_FInal_Value]
		--FROM x_Custom_OUTPUT a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
		--where	
		--(A.[PowerFinalValue] > 0 and B.[POWER_FInal_Value] is null) OR
		--(A.PremierFinalValue > 0 and B.[Premier_FInal_Value] is null)
		
		--Select distinct A.WORK_REF_ID,  A.[PowerFinalValue], B.[POWER_FInal_Value]
		--,A.PremierFinalValue, B.[Premier_FInal_Value]
		--FROM x_Custom_OUTPUT a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
		--where	
		--(A.[PowerFinalValue] IS NULL and B.[POWER_FInal_Value] >0) OR
		--(A.PremierFinalValue IS NULL and B.[Premier_FInal_Value] >0) 

		--------Change in values > 1MM
		--Select A.[INPUT KEY],A.PROPERTYID,A.WORK_REF_ID,  A.[PowerFinalValue]
		--, convert(bigint,convert(Money,B.[POWER_FInal_Value])) as NEW_POWER_FINAL
		--,convert(bigint,convert(Money,B.[POWER_FInal_Value])) - A.[PowerFinalValue] as DIFF_POWER_FINAL
		--,A.PremierFinalValue 
		--, convert(bigint,convert(Money,B.[Premier_FInal_Value])) as NEW_PREMIER_FINAL
		--FROM x_Custom_OUTPUT a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
		--where	
		--(A.[PowerFinalValue] > 0 and B.[POWER_FInal_Value] > 0
		--AND ABS(A.[PowerFinalValue]-B.[POWER_FInal_Value]) > 1000000) 
		--OR
		--(A.PremierFinalValue > 0 and B.[Premier_FInal_Value] > 0
		--AND ABS(A.PremierFinalValue-B.[Premier_FInal_Value]) > 1000000) 
		--Order by ABS(convert(bigint,convert(Money,B.[POWER_FInal_Value])) - A.[PowerFinalValue])  desc
	
		
		---------------------------------------------------------------------------------------------------------------------

		UPDATE [zCust_WellsFargo].[dbo].[A]
		SET 
	
		A.[PREMIERFinalValue] = convert(bigint,convert(Money,B.[PREMIER_FInal_Value]))
		,A.[PREMIERHighValue] = convert(bigint,convert(Money,B.[PREMIER_HIGH_Value]))
		,A.[PREMIERLowValue] = convert(bigint,convert(Money,B.[PREMIER_LOW_Value]))
		,A.[PREMIERConfidenceScore] = B.[PREMIER_CONFIDENCE_SCORE]
		,A.[PREMIERStandardDeviation] = B.[PREMIER_FORECAST_STANDARD_DEVIATION]
		,A.[PREMIERValuationDate] = Convert(date,B.[ValuationDate])
		,A.PremierVersion = '.001'
			-----Added 20240502 per MS & BR--to pull from PROCISION & NO LONGER FLANK----
		,A.[LastArmsLengthSaleRecordingDate] = B.LASTKNOWNSALEDATE
		,A.[LastArmsLengthSalePrice] = B.LASTKNOWNSALEPRICE
	
		FROM [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where B.[PREMIER_FInal_Value] > 0

		--Select * From zCust_WellsFargo.dbo.x_Custom_OUTPUT

	--Select distinct 
	--A.WORK_REF_ID
	--,A.[PowerFinalValue] as '20230901_POWER_FINAL'
	--,B.POWER_FINAL_VALUE as '20230905_POWER_FINAL'
 --   ,A.PremierFinalValue as '20230901_POWER_FINAL'
	--,B.[Premier_Final_Value] as '20230905_POWER_FINAL'
	--,A.PremierValuationDate as InitialValuationDate
	--,Convert(date,B.VALUE_AS_OF) as CurrentValuationDate
	--FROM zCust_WellsFargo.dbo.x_Custom_OUTPUT a 
 --   JOIN zCust_WellsFargo.dbo.HOLOCRON_WF as B with(NOLOCK) 
 --   on A.WORK_REF_ID = B.REF_ID
 --   where  
 --   (A.[PowerFinalValue] > 0 and B.POWER_FINAL_VALUE is null) OR
 --   (A.PremierFinalValue > 0 and B.[Premier_Final_Value] is null)   
	----Order by convert(bigint,A.[PowerFinalValue]) desc

	--Select * into dbo.x_Custom_OUTPUT_20230907
	--from x_Custom_OUTPUT


	


	----Select  WORK_REF_ID, B.* from x_Custom_OUTPUT A
	----join INPUT_RAW_CUST_NEW as B on A.[INPUT KEY] = B.SEQID
	----where WORK_REF_ID in (
	----Select WORK_REF_ID from (
	----Select WORK_REF_ID, count(*) as T From x_Custom_OUTPUT as A 
	----where WORK_REF_ID is not null
	----Group by WORK_REF_ID
	----having count(*) > 1)A)
	----Order by WORK_REF_ID



	


		--------20230906 One time force per MS---
		--UPDATE A
		--SET 
	
		--A.[PREMIERFinalValue] = convert(bigint,convert(Money,B.[PREMIER_FInal_Value]))
		--,A.[PREMIERHighValue] = convert(bigint,convert(Money,B.[PREMIER_HIGH_Value]))
		--,A.[PREMIERLowValue] = convert(bigint,convert(Money,B.[PREMIER_LOW_Value]))
		--,A.[PREMIERConfidenceScore] = B.[PREMIER_CONFIDENCE_SCORE]
		--,A.[PREMIERStandardDeviation] = B.[PREMIER_FORECAST_STANDARD_DEVIATION]
		--,A.[PREMIERValuationDate] = Convert(date,B.VALUE_AS_OF)
		--,A.PremierVersion = '.001'
		
		--FROM x_Custom_OUTPUT a 
		--JOIN HOLOCRON_WF as B with(NOLOCK) 
		--on A.WORK_REF_ID = B.REF_ID
			
		--where B.[PREMIER_FInal_Value] > 0
	
	
			

		Update [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		SET [Event Status] = CASE WHEN [PREMIERFinalValue] > 0 OR  [PowerFinalValue] > 0 THEN 'Event Found' ELSE 'Event Not Found' END


		Select * From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event Found'
		and ([AVM Coverage] like 'Not%' or [Property Status] like '%not%' or [Property Status] like '%multiple%')

		Select * From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT] 
		where [Event Status] like 'Event Not Found'
		and [Property Status]  like 'Property Found'


		-----VALUE BUT NO CONF SCORE
		Select FIPS, [INPUT KEY],  PropertyID, 
		PremierFinalValue, PremierConfidenceScore
		,PowerFinalValue, PowerConfidenceScore, PowerValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event Found'
		and 
		(PremierFinalValue is not null and PremierConfidenceScore is null)
		OR
		(PowerFinalValue is not null and PowerConfidenceScore is null)


		------No Value but date----
		Select FIPS, [INPUT KEY],  PropertyID, 
		PremierFinalValue, PremierConfidenceScore
		,PowerFinalValue, PowerConfidenceScore, PowerValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event not Found'
		and PropertyID is not null
		and (PremierValuationDate is not null or PowerValuationDate is not null)
		

	

		------Has Final Value but missing some other field----
		Select FIPS, [INPUT KEY],  PropertyID, 
		PremierFinalValue, PremierConfidenceScore,PremierHighValue,PremierLowValue,PremierStandardDeviation,PremierValuationDate
		,PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,PowerValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where 
		--[INPUT KEY] like '572160'
		--PowerFinalValue > 0 
		(PremierFinalValue > 0 
			and 
			(PremierConfidenceScore is null or PremierHighValue is null or PremierLowValue is null or PremierStandardDeviation is null or PremierValuationDate is null)
		)
		OR
		(PowerFinalValue > 0 
			and 
			(PowerConfidenceScore is null or PowerHighValue is null or PowerLowValue is null or PowerStandardDeviation is null or PowerValuationDate is null)
		)

		
		------Checking Field Population----
		Select FIPS, [INPUT KEY],  PropertyID, 
		PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,PowerValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where 
		PowerFinalValue is null

			
		------Checking Field Population----
		Select FIPS, [INPUT KEY],  PropertyID, 
		PremierFinalValue, PremierConfidenceScore,PremierHighValue,PremierLowValue,PremierStandardDeviation,PremierValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where 
		PremierFinalValue is null


		------Checking Field Population----
		Select FIPS, [INPUT KEY],  PropertyID, 
		PremierFinalValue, PremierConfidenceScore,PremierHighValue,PremierLowValue,PremierStandardDeviation,PremierValuationDate
		,PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,PowerValuationDate
		From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		where 
		PremierFinalValue > 0 
		OR
		PowerFinalValue > 0 
		
		

		Select * From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]


		Select [Property Status], count(*) From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		Group by [Event Status]

		Select [AVM Coverage], count(*) From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		Group by [AVM Coverage]

		Select AddressStandardization, count(*) From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]
		Group by AddressStandardization
		
		Select top 10000 *  From [zCust_WellsFargo].[dbo].[x_Custom_OUTPUT]

END




