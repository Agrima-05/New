SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_TaxSource_Amrock].[dbo].[usp_300_Start_Output_AMROCK_V2]


AS
BEGIN
	
	SET NOCOUNT ON;


	-------*************IF MANUALLY SUBMITTING - UPDATE BATCH ID & RECORD COUNT & SEND AUTO EMAIL BELOW AFTER TAXSOURCE SUBMISSION!!!*****------
	--			DECLARE @query NVARCHAR(MAX)
	--			DECLARE @body NVARCHAR(MAX)
	--			DECLARE @body2 NVARCHAR(MAX)
	--			DECLARE @xml NVARCHAR(MAX)
	--			DECLARE @Subject NVARCHAR(MAX)
	--			DECLARE @DATE VARCHAR(10)
	--			DECLARE @tab char(1) = CHAR(9)
	--			DECLARE @query_attachment_filename NVARCHAR(MAX)
	--			Set @Date = Convert(varchar(10),Getdate(),112)
	--			Set @Subject = 'Amrock - Taxsource Batch submitted - ' + @Date 
	--			SET @body = 'BatchID: 15  Record Count:  0'
		

	--			-----------sp_send_dbmail example-------------
	--			EXEC msdb.dbo.sp_send_dbmail
	--			@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
	--			@query =  NULL,
	--			@body = @body,
	--			@body_format ='HTML',
	--			@recipients = 'GVistaunet@edatatrace.com;avancooney@firstam.com;MClooten@firstam.com;ahmartin@firstam.com',
	--			@copy_recipients = 'klowe@firstam.com;MicSmith@firstam.com',
	--			@importance = 'high',
	--			@subject = @subject,
	--			@attach_query_result_as_file = 0,
	--			@query_attachment_filename = @query_attachment_filename,
	--			@query_result_separator=@tab,
	--			@query_result_no_padding=1
	--					;
	
	--------Per Giang - 
	----	Production Test Credentials
	----	User:  DTAPI_DataAcq_Prod
	----	PSWD:  DataAcqDTAPI1@Prod

	----	UAT Credentials
	----	User:DTAPI_DataAcq_UAT
	----	PSWD:DataAcqDTAPI1@UAT

	---Per Giang 20210429--- 
	----The default is TaxsourceBlended if you don’t specify the last parameter. 
	----If you add TaxsourceAutomated to the end it will be TaxsourceAutomated. 
	----Or Taxsource for Taxsource product.
	----I.e.: TaxSourcePuller.exe 13 DTAPI_DataAcq_Prod DataAcqDTAPI1@Prod Taxsource Will submit Taxsource

----How will I know when a customer is supposed to run as “Taxsource” or “TaxsourceBlended”? 
------Nicole will need to tell you in the contract/ticket.

----Does submitting it like the below automatically trigger the Blended request? Yes.
----TaxSourcePuller.exe 13 DTAPI_DataAcq_Prod DataAcqDTAPI1@Prod



	----Per GIANG - USE UAT CREDENTIALS & NOTIFY BRIAN DIXON & MICHAEL CLOOTEN that you have pushed records in Manual counties so they initiate the process!!
	
	----D:\SupportTools\TaxSourceApiExeUAT
	----TaxSourcePuller.exe 7 DTAPI_DataAcq_UAT DataAcqDTAPI1@UAT
	----7 is the Batch ID

	-----Image puller if needed (this is PROD puller)--
	---On server 192:
	---D:\SupportTools\TaxSourceAPIImagePuller\Release
	---TaxSourceAPIImagePull.exe 9  (replace the 9 with the Batch number needed to run!!)


----	Hi Giang – What is the difference between the 3 types?

----1.	TaxsourceAutomated
----a.	This will only run the automated counties? I am not sure if this a limitation on coverage at the county level but I think it basically gives the data we already have in the database. Data should come back momentarily.
----b.	What if a manual county is submitted using this request type – will it just return an error code? – I think it will return the be low
----i.	{"StatusDescription":"Report generation completed.","MaxResultsCount":1,"LitePropertyList":null,"Reports":[{"PropertyId":71033832,"ReportName":"TaxSourceAutomated","ReportStatus":"Disallowed","ReferenceId":"7599","OrderItemId":0,"Data":{},"Message":"This report is not Available in this County."}]}

----2.	TaxsourceBlended
----a.	Will process both automated & manual counties? I don’t think there is any different as far as data availability. No one has told me the different (even the documentation) but best guess it’s sort of a “Costco membership” where they have up front a negotiated rate. For example, Taxsource charges you $1 if we already have the data (no manual research) and $20 if it become a manual job. TaxsourceBlended will charge you $3 for any report regardless of how we fulfil it. You can see that the customer will need to decide if they have more  automated or manual. I think that’s why one you are in one contract you can’t switch to the other to prevent customer uses Taxsource ($1)  when their batch is heavy on automated and use TaxsourceBlended when they have more manual research to get the $3 per record  instead of $20 as in Taxsource. Of course this is my deduction of what I saw but sales may have a better explanation. As far as our fulfillment concerns, there is no different between Taxsource and Taxsourceblended. Maybe that was why Nicole insisted we use Armrock’s account for blended to get us out of the complicate billing scheme.   


------20210510 - Per contract - Amrock is BLENDED!!!
----TaxSourcePuller.exe BATCHID DTAPI_AmrockTitleServices_Prod AmrockDTAPI1@Prod TaxsourceBlended

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
		[Id][int]NULL,
		[BatchId][int]NULL,
		[ExternalKey][varchar](10)NULL,
		[PropertyId][varchar](4000)NULL,
		[ReportName][varchar](4000)NULL,
		[ReportStatus][varchar](4000)NULL,
		[ReferenceId][varchar](4000)NULL,
		[OrderItemId][varchar](4000)NULL,
		[StreetAddress][varchar](4000)NULL,
		[City][varchar](4000)NULL,
		[State][varchar](4000)NULL,
		[Zip9][varchar](4000)NULL,
		[County][varchar](4000)NULL,
		[APN][varchar](4000)NULL,
		[StateFips][varchar](4000)NULL,
		[CountyFips][varchar](4000)NULL,
		[ReportAsOfDate][varchar](30)NULL,
		[AssessorsAlternateParcelIdentifier][varchar](4000)NULL,
		[ExtendedLegalDescription][varchar](4000)NULL,
		[LandUse][varchar](4000)NULL,
		[TraCode][varchar](4000)NULL,
		[TraName][varchar](4000)NULL,
		[OwnerNames][varchar](4000)NULL,
		[Errors][varchar](2000)NULL,
		[Message][varchar](4000)NULL,
		[Agency1_MismoAgencyCode][varchar](4000)NULL,
		[Agency1_Name][varchar](4000)NULL,
		[Agency1_AgencyType][varchar](4000)NULL,
		[Agency1_TaxCollectorUrl][varchar](4000)NULL,
		[Agency1_PhoneNumber][varchar](4000)NULL,
		[Agency1_FaxNumber][varchar](4000)NULL,
		[Agency1_Email][varchar](4000)NULL,
		[Agency1_MakePayableTo][varchar](4000)NULL,
		[Agency1_StreetAddress][varchar](4000)NULL,
		[Agency1_CityStateZip][varchar](4000)NULL,
		[Agency1_MailingStreet][varchar](4000)NULL,
		[Agency1_MailingCityStateZip][varchar](4000)NULL,
		[Agency1_TaxYearType][varchar](4000)NULL,
		[Agency1_TaxYearDates][varchar](4000)NULL,
		[Agency1_CurrentTaxYear][varchar](4000)NULL,
		[Agency1_CollectsInArrears][varchar](4000)NULL,
		[Agency1_DiscountAgency][varchar](4000)NULL,
		[Agency1_DuplicateBillRequired][varchar](4000)NULL,
		[Agency1_DuplicateBillFee][varchar](4000)NULL,
		[Agency1_ExternalAgencyNotes][varchar](4000)NULL,
		[TaxDetails_AsOfDate][varchar](30)NULL,
		[TaxDetails_SchoolDistrict][varchar](4000)NULL,
		[TaxDetails_TaxId][varchar](4000)NULL,
		[TaxDetails_DelinquentTaxes][varchar](4000)NULL,
		[TaxDetails_TaxReportStatus][varchar](4000)NULL,
		[TaxDetails_DelinquencyTaxSaleYear][varchar](4000)NULL,
		[TaxYear][varchar](4000)NULL,
		[TaxType][varchar](4000)NULL,
		[TaxSupplementalAPN][varchar](4000)NULL,
		[TotalTax][varchar](4000)NULL,
		[ImprovementValue][varchar](4000)NULL,
		[LandVal][varchar](4000)NULL,
		[AssessedTotalValue][varchar](4000)NULL,
		[AssessedYear][varchar](4000)NULL,
		[ExemptionType][varchar](4000)NULL,
		[ExemptionAmount][varchar](4000)NULL,
		[NetVal][varchar](4000)NULL,
		[CertificateOfPurchase][varchar](4000)NULL,
		[TaxInstallmentsMessage][varchar](4000)NULL,
		[TaxBillNumber][varchar](4000)NULL,
		[InstallmentDetail1_SequenceId][varchar](4000)NULL,
		[InstallmentDetail1_Amount][varchar](4000)NULL,
		[InstallmentDetail1_Status][varchar](4000)NULL,
		[InstallmentDetail1_PaymentDate][varchar](30)NULL,
		[InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[InstallmentDetail1_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail1_DueDate][varchar](30)NULL,
		[InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail1_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail1_DiscountDate][varchar](30)NULL,
		[InstallmentDetail1_Penalty][varchar](4000)NULL,
		[InstallmentDetail1_Interest][varchar](4000)NULL,
		[InstallmentDetail2_SequenceId][varchar](4000)NULL,
		[InstallmentDetail2_Amount][varchar](4000)NULL,
		[InstallmentDetail2_Status][varchar](4000)NULL,
		[InstallmentDetail2_PaymentDate][varchar](30)NULL,
		[InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[InstallmentDetail2_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail2_DueDate][varchar](30)NULL,
		[InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail2_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail2_DiscountDate][varchar](30)NULL,
		[InstallmentDetail2_Penalty][varchar](4000)NULL,
		[InstallmentDetail2_Interest][varchar](4000)NULL,
		[InstallmentDetail3_SequenceId][varchar](4000)NULL,
		[InstallmentDetail3_Amount][varchar](4000)NULL,
		[InstallmentDetail3_Status][varchar](4000)NULL,
		[InstallmentDetail3_PaymentDate][varchar](30)NULL,
		[InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[InstallmentDetail3_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail3_DueDate][varchar](30)NULL,
		[InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail3_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail3_DiscountDate][varchar](30)NULL,
		[InstallmentDetail3_Penalty][varchar](4000)NULL,
		[InstallmentDetail3_Interest][varchar](4000)NULL,
		[InstallmentDetail4_SequenceId][varchar](4000)NULL,
		[InstallmentDetail4_Amount][varchar](4000)NULL,
		[InstallmentDetail4_Status][varchar](4000)NULL,
		[InstallmentDetail4_PaymentDate][varchar](30)NULL,
		[InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[InstallmentDetail4_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail4_DueDate][varchar](30)NULL,
		[InstallmentDetail4_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail4_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail4_DiscountDate][varchar](30)NULL,
		[InstallmentDetail4_Penalty][varchar](4000)NULL,
		[InstallmentDetail4_Interest][varchar](4000)NULL,
		[OtherTaxDetails1_TaxYear][varchar](4000)NULL,

		[OtherTaxDetails1_TaxType][varchar](4000) NULL,


		[OtherTaxDetails1_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails1_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails1_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails1_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails1_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails2_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails2_TaxType][varchar](4000) NULL,

		[OtherTaxDetails2_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails2_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails2_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails2_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails2_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails3_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails3_TaxType][varchar](4000) NULL,

		[OtherTaxDetails3_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails3_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails3_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails3_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails3_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[AdditionalOtherTaxDetails][varchar](1)NULL,

		[RedemptionDetails1_Amount][varchar](30) NULL,
		[RedemptionDetails1_RedemptionDate][varchar](30) NULL,


		[RedemptionDetails1_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails2_Amount][varchar](30) NULL,
		[RedemptionDetails2_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails2_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails3_Amount][varchar](30) NULL,
		[RedemptionDetails3_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails3_PaymentGoodThrough][varchar](4000) NULL,
		
		-----Added 20210907 per Giang---
		[OtherTaxDetails1_Message][varchar](4000) NULL,
		[OtherTaxDetails2_Message][varchar](4000) NULL,
		[OtherTaxDetails3_Message][varchar](4000) NULL



			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		

	   INSERT INTO [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	   SELECT
		--A.ID,
		--A.BatchId,
		--[ExternalKey]
  --    ,[PropertyId]
  --    ,[ReportName]
  --    ,[ReportStatus]
  --    ,[ReferenceId]
  --    ,[OrderItemId]
  --    ,[StreetAddress]
  --    ,A.[City]
  --    ,A.[State]
  --    ,A.[Zip9]
  --    ,A.[County]
  --    ,A.[APN]
  --    ,[StateFips]
  --    ,[CountyFips]
  --    ,[ReportAsOfDate]
  --    ,[AssessorsAlternateParcelIdentifier]
  --    ,[ExtendedLegalDescription]
  --    ,[LandUse]
  --    ,[TraCode]
  --    ,[TraName]
  --    ,[OwnerNames]
  --    ,	convert(varchar(2000),Errors) as Errors
   --   ,[Message]
   --   ,[Agency1_MismoAgencyCode]
   --   ,[Agency1_Name]
   --   ,[Agency1_AgencyType]
   --   ,[Agency1_TaxCollectorUrl]
   --   ,[Agency1_PhoneNumber]
   --   ,[Agency1_FaxNumber]
   --   ,[Agency1_Email]
   --   ,[Agency1_MakePayableTo]
   --   ,[Agency1_StreetAddress]
   --   ,[Agency1_CityStateZip]
   --   ,[Agency1_MailingStreet]
   --   ,[Agency1_MailingCityStateZip]
   --   ,[Agency1_TaxYearType]
   --   ,[Agency1_TaxYearDates]
   --   ,[Agency1_CurrentTaxYear]
   --   ,[Agency1_CollectsInArrears]
   --   ,[Agency1_DiscountAgency]
   --   ,[Agency1_DuplicateBillRequired]
   --   ,[Agency1_DuplicateBillFee]
   --   ,[Agency1_ExternalAgencyNotes]
   --   ,[TaxDetails_AsOfDate]
   --   ,[TaxDetails_SchoolDistrict]
   --   ,[TaxDetails_TaxId]
   --   ,[TaxDetails_DelinquentTaxes]
   --   ,[TaxDetails_TaxReportStatus]
   --   ,[TaxDetails_DelinquencyTaxSaleYear]
   --   ,[TaxYear]
   --   ,[TaxType]
   --   ,[TaxSupplementalAPN]
   --   ,[TotalTax]
   --   ,[ImprovementValue]
   --   ,[LandVal]
   --   ,[AssessedTotalValue]
   --   ,[AssessedYear]
   --   ,[ExemptionType]
   --   ,[ExemptionAmount]
   --   ,[NetVal]
   --   ,[CertificateOfPurchase]
   --   ,[TaxInstallmentsMessage]
   --   ,[TaxBillNumber]
   --   ,[InstallmentDetail1_SequenceId]
   --   ,[InstallmentDetail1_Amount]
   --   ,[InstallmentDetail1_Status]
   --   ,[InstallmentDetail1_PaymentDate]
   --   ,[InstallmentDetail1_AmountDue]
   --   ,[InstallmentDetail1_PartialPayAmt]
   --   ,[InstallmentDetail1_DueDate]
   --   ,[InstallmentDetail1_DelinquentDate]
   --   ,[InstallmentDetail1_EstimatedAmountGoodThrough]
   --   ,[InstallmentDetail1_DiscountDate]
   --   ,[InstallmentDetail1_Penalty]
   --   ,[InstallmentDetail1_Interest]
   --   ,[InstallmentDetail2_SequenceId]
   --   ,[InstallmentDetail2_Amount]
   --   ,[InstallmentDetail2_Status]
   --   ,[InstallmentDetail2_PaymentDate]
   --   ,[InstallmentDetail2_AmountDue]
   --   ,[InstallmentDetail2_PartialPayAmt]
   --   ,[InstallmentDetail2_DueDate]
   --   ,[InstallmentDetail2_DelinquentDate]
   --   ,[InstallmentDetail2_EstimatedAmountGoodThrough]
   --   ,[InstallmentDetail2_DiscountDate]
   --   ,[InstallmentDetail2_Penalty]
   --   ,[InstallmentDetail2_Interest]
   --   ,[InstallmentDetail3_SequenceId]
   --   ,[InstallmentDetail3_Amount]
   --   ,[InstallmentDetail3_Status]
   --   ,[InstallmentDetail3_PaymentDate]
   --   ,[InstallmentDetail3_AmountDue]
   --   ,[InstallmentDetail3_PartialPayAmt]
   --   ,[InstallmentDetail3_DueDate]
   --   ,[InstallmentDetail3_DelinquentDate]
   --   ,[InstallmentDetail3_EstimatedAmountGoodThrough]
   --   ,[InstallmentDetail3_DiscountDate]
   --   ,[InstallmentDetail3_Penalty]
   --   ,[InstallmentDetail3_Interest]
   --   ,[InstallmentDetail4_SequenceId]
   --   ,[InstallmentDetail4_Amount]
   --   ,[InstallmentDetail4_Status]
   --   ,[InstallmentDetail4_PaymentDate]
   --   ,[InstallmentDetail4_AmountDue]
   --   ,[InstallmentDetail4_PartialPayAmt]
   --   ,[InstallmentDetail4_DueDate]
   --   ,[InstallmentDetail4_DelinquentDate]
   --   ,[InstallmentDetail4_EstimatedAmountGoodThrough]
   --   ,[InstallmentDetail4_DiscountDate]
   --   ,[InstallmentDetail4_Penalty]
   --   ,[InstallmentDetail4_Interest]
   --   ,[OtherTaxDetails1_TaxYear]
   --   ,[OtherTaxDetails1_TaxType]
   --   ,[OtherTaxDetails1_TaxSupplementalAPN]
   --   ,[OtherTaxDetails1_TotalTax]
   --   ,[OtherTaxDetails1_CertificateOfPurchase]
   --   ,[OtherTaxDetails1_TaxBillNumber]
   --   ,[OtherTaxDetails1_InstallmentDetail1_Amount]
   --   ,[OtherTaxDetails1_InstallmentDetail1_Status]
   --   ,[OtherTaxDetails1_InstallmentDetail1_AmountDue]
   --   ,[OtherTaxDetails1_InstallmentDetail1_DelinquentDate]
   --   ,[OtherTaxDetails1_InstallmentDetail2_Amount]
   --   ,[OtherTaxDetails1_InstallmentDetail2_Status]
   --   ,[OtherTaxDetails1_InstallmentDetail2_AmountDue]
   --   ,[OtherTaxDetails1_InstallmentDetail2_DelinquentDate]
   --   ,[OtherTaxDetails1_InstallmentDetail3_Amount]
   --   ,[OtherTaxDetails1_InstallmentDetail3_Status]
   --   ,[OtherTaxDetails1_InstallmentDetail3_AmountDue]
   --   ,[OtherTaxDetails1_InstallmentDetail3_DelinquentDate]
   --   ,[OtherTaxDetails1_InstallmentDetail4_Amount]
   --   ,[OtherTaxDetails1_InstallmentDetail4_Status]
   --   ,[OtherTaxDetails1_InstallmentDetail4_AmountDue]
   --   ,[OtherTaxDetails1_InstallmentDetail4_DelinquentDate]
   --   ,[OtherTaxDetails2_TaxYear]
   --   ,[OtherTaxDetails2_TaxType]
   --   ,[OtherTaxDetails2_TaxSupplementalAPN]
   --   ,[OtherTaxDetails2_TotalTax]
   --   ,[OtherTaxDetails2_CertificateOfPurchase]
   --   ,[OtherTaxDetails2_TaxBillNumber]
   --   ,[OtherTaxDetails2_InstallmentDetail1_Amount]
   --   ,[OtherTaxDetails2_InstallmentDetail1_Status]
   --   ,[OtherTaxDetails2_InstallmentDetail1_AmountDue]
   --   ,[OtherTaxDetails2_InstallmentDetail1_DelinquentDate]
   --   ,[OtherTaxDetails2_InstallmentDetail2_Amount]
   --   ,[OtherTaxDetails2_InstallmentDetail2_Status]
   --   ,[OtherTaxDetails2_InstallmentDetail2_AmountDue]
   --   ,[OtherTaxDetails2_InstallmentDetail2_DelinquentDate]
   --   ,[OtherTaxDetails2_InstallmentDetail3_Amount]
   --   ,[OtherTaxDetails2_InstallmentDetail3_Status]
   --   ,[OtherTaxDetails2_InstallmentDetail3_AmountDue]
   --   ,[OtherTaxDetails2_InstallmentDetail3_DelinquentDate]
   --   ,[OtherTaxDetails2_InstallmentDetail4_Amount]
   --   ,[OtherTaxDetails2_InstallmentDetail4_Status]
   --   ,[OtherTaxDetails2_InstallmentDetail4_AmountDue]
   --   ,[OtherTaxDetails2_InstallmentDetail4_DelinquentDate]
   --   ,[OtherTaxDetails3_TaxYear]
   --   ,[OtherTaxDetails3_TaxType]
   --   ,[OtherTaxDetails3_TaxSupplementalAPN]
   --   ,[OtherTaxDetails3_TotalTax]
   --   ,[OtherTaxDetails3_CertificateOfPurchase]
   --   ,[OtherTaxDetails3_TaxBillNumber]
   --   ,[OtherTaxDetails3_InstallmentDetail1_Amount]
   --   ,[OtherTaxDetails3_InstallmentDetail1_Status]
   --   ,[OtherTaxDetails3_InstallmentDetail1_AmountDue]
   --   ,[OtherTaxDetails3_InstallmentDetail1_DelinquentDate]
   --   ,[OtherTaxDetails3_InstallmentDetail2_Amount]
   --   ,[OtherTaxDetails3_InstallmentDetail2_Status]
   --   ,[OtherTaxDetails3_InstallmentDetail2_AmountDue]
   --   ,[OtherTaxDetails3_InstallmentDetail2_DelinquentDate]
   --   ,[OtherTaxDetails3_InstallmentDetail3_Amount]
   --   ,[OtherTaxDetails3_InstallmentDetail3_Status]
   --   ,[OtherTaxDetails3_InstallmentDetail3_AmountDue]
   --   ,[OtherTaxDetails3_InstallmentDetail3_DelinquentDate]
   --   ,[OtherTaxDetails3_InstallmentDetail4_Amount]
   --   ,[OtherTaxDetails3_InstallmentDetail4_Status]
   --   ,[OtherTaxDetails3_InstallmentDetail4_AmountDue]
   --   ,[OtherTaxDetails3_InstallmentDetail4_DelinquentDate]
   --   ,[AdditionalOtherTaxDetails]
	  --,[RedemptionDetails1_Amount]
	  --,[RedemptionDetails1_RedemptionDate]

   --   ,[RedemptionDetails1_PaymentGoodThrough]
   --   ,[RedemptionDetails2_Amount]
   --   ,[RedemptionDetails2_RedemptionDate]
   --   ,[RedemptionDetails2_PaymentGoodThrough]
   --   ,[RedemptionDetails3_Amount]
   --   ,[RedemptionDetails3_RedemptionDate]
   --   ,[RedemptionDetails3_PaymentGoodThrough]


		 REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') as Errors
		,REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		
		-----Added 20210907 per NH---
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_Message], CHAR(13), ''), CHAR(10), ''),'|','')

  
  ----20210907 - Per Giang
  ----I have created a new view OutputLayout5  using OutputLayout4 and expose 3 additional fields: OtherTaxDetails1_Message, OtherTaxDetails2_Message and OtherTaxDetails3_Message

  
		--Select 	A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		FROM [TaxSourceAPI].[dbo].[OutputLayout5] as A with(NOLOCK)
		join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
		and 
		(
				(ReportStatus is not null and ReportStatus not like 'Processing'
				AND DOCSTATUS is not null)
				OR
				(ReportStatus like 'Errored' and Errors is not null)
		)
		Order by ReportStatus,DOCSTATUS

		-------20210423 - Giang updated the view to populate "Errored" as the ReportStatus when the SubmissionStaus is Errored
		------and to populate the Multimatch/Unmatched etc into the Errors field

		

		--Select JSON_VALUE([PostBack], '$.ReportStatus') AS ReportStatus,SubmissionStatus,JSON_VALUE([PostBack], '$.ReportName') AS ReportName
		--,replace(replace(JSON_QUERY([PostBack], '$.Data.Errors'),'[',''),']','') AS Errors
		----A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[Property] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and JSON_VALUE([PostBack], '$.ReportStatus') is null

		


		--UPdate C
		--Set C.DOCSTATUS = NULL
		----Select A.BatchID, A.ExternalKey, PropertyID, ReportName, ReportStatus, C.DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--join TaxSourceAPI.[dbo].Property as C with(NOLOCK) on A.ExternalKey = C.ExternalKey
		--and A.BatchId = C.BatchId
		--where B.DATE_COMPLETED is null
		--and ReportStatus like 'Ready'
		----and C.DocStatus is null
		--AND A.DOCSTATUS like 'Error%'

		-----Image puller if needed (this is PROD puller)--
		---On server 192:
		---D:\SupportTools\TaxSourceAPIImagePuller\Release
		---TaxSourceAPIImagePull.exe 9  (replace the 9 with the Batch number needed to run!!)


		

		--Select A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and ReportStatus  like 'Ready'
		--AND DOCSTATUS like 'Error%'
		--Order by ReportStatus,DOCSTATUS



		--Select A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--join zCust_TaxSource_Amrock.dbo.INPUT_MONITOR_COMPLETED as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where ReportStatus like 'Ready'
		--AND DOCSTATUS like 'Err%'
		
		

		--Select *  FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--where ExternalKey in ('69344666','69280094','69278648','69277576','69239611','69452770','69451418','69421823')
		--And BatchID > 8

		--UPdate INPUT_MONITOR
		--Set BatchID = '10'
		----where 
		----Select * From INPUT_MONITOR
		--where  UniqueID in ('69344666','69280094','69278648','69277576','69239611','69452770','69451418','69421823')


		--Select * From TaxSourceAPI.[dbo].[Property]
		--where BatchID = 7

		--Select * From TaxSourceAPI.[dbo].[Batch]

		--Select BatchID, ExternalKey,ReportStatus, Errors , REFERENCEID  From  TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--where BatchID = 7

		--Select * From [TaxSourceAPI].[dbo].[Property]
		--where BatchId = 8

		--Delete from [TaxSourceAPI].[dbo].[Property]
		--where BatchId = 8

	
	
		Select BATCHID,count(*) as TOTAL From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
		Group by BATCHID

		--Select count(*) as TOTAL From INPUT_MONITOR
		

	  Select count(*) From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]


	  UPdate [zCust_TaxSource_Amrock].[dbo].[A]
	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
	  From  [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT] as B on 
	  A.UniqueID = B.[ExternalKey]


	  Insert into [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED]
	  Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
	  where DATE_COMPLETED is not null

	  --Select * From [INPUT_MONITOR_COMPLETED]


	  Delete from [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
	  --Select * 
	  From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as B on 
	  A.UniqueID = B.UniqueID
	  and A.BatchID = B.BatchID
	  where B.DATE_COMPLETED is not null


	  -------Copy pdf reports-----

	
	Select count(*) From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	where ReportStatus like 'Ready'

	Select * From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT] as A join [TaxSourceAPI].[dbo].[OutputLayout5] as B on 
	A.ExternalKey = B.ExternalKey
	and A.BatchId = B.BatchId
	where A.ReportStatus like 'Ready'
	and B.DocStatus like 'Err%'


	Truncate table REPORTS_TO_COPY

	Insert into [zCust_TaxSource_Amrock].[dbo].[REPORTS_TO_COPY]

	Select  D.ImageFolderPath + '\' + B.ExternalKey + '.pdf' as IMAGEPATH,NULL as COPIED
	 --into zCust_TaxSource_Amrock.dbo.REPORTS_TO_COPY
	 From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as A 
	 join [zCust_TaxSource_Amrock].[dbo].[x_custom_OUTPUT] as B on 
	 A.UniqueID = B.[ExternalKey]
	 and A.BatchID = B.BatchID
	 join [TaxSourceAPI].[dbo].[Property] as C on A.BatchID = C.BatchID
	 and A.UniqueID = C.ExternalKey
	 join [TaxSourceAPI].[dbo].[Batch] as D on A.BATCHID = D.Id
	 where B.ReportStatus like 'Ready'
	 and C.DocStatus like 'Complete'

	 -----No Image----
	 Select   B.ExternalKey ,B.ReportStatus,C.DocStatus
	 From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as A 
	 join [zCust_TaxSource_Amrock].[dbo].[x_custom_OUTPUT] as B on 
	 A.UniqueID = B.[ExternalKey]
	 and A.BatchID = B.BatchID
	 join [TaxSourceAPI].[dbo].[Property] as C on A.BatchID = C.BatchID
	 and A.UniqueID = C.ExternalKey
	 join [TaxSourceAPI].[dbo].[Batch] as D on A.BATCHID = D.Id
	 where B.ReportStatus like 'Ready'
	 and C.DocStatus like 'Err%'



	 ---------Stats request from Alan 20210504----

	 Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as A 
	 join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as B on A.UniqueID = B.UniqueID
	 and A.BATCHID = B.BATCHID

	 Select count(*) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
	 Select count(*) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED]
	 where BATCHID in (9,12)

	 Select   C.ReportStatus,C.DocStatus,Errors, count(*)
	 From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as A 
	 join [TaxSourceAPI].[dbo].[OutputLayout5] as C on A.BatchID = C.BatchID
	 and A.UniqueID = C.ExternalKey
	 where A.BATCHID in (9,12)
	 Group by C.ReportStatus,C.DocStatus,Errors
	 Order by C.ReportStatus,C.DocStatus,Errors


	 Select    A.*, C.ReportStatus, C.DocStatus, C.Errors
	 From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as A 
	 join [TaxSourceAPI].[dbo].[OutputLayout5] as C on A.BatchID = C.BatchID
	 and A.UniqueID = C.ExternalKey
	 where A.BATCHID in (9,12)
	AND DocStatus  like 'Complete'
	and DATE_COMPLETED = '202104081403'
	
	




	 


	 Select * From [zCust_TaxSource_Amrock].[dbo].[REPORTS_TO_COPY]
	 ORder by ImagePath

	

	Select * From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	 	
		
END





