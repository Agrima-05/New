SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Refresh DTDB data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_860_CreateDTDBListings]

AS
BEGIN

	SET NOCOUNT ON;

			DECLARE @MaxDt as datetime
			Select @MaxDt = Max(LoadDate) from [DTDBListings].[dbo].[Listings] with(NOLOCK)

			DROP TABLE IF EXISTS [DTDBListings].[dbo].[Listings_Batch]

			SELECT * INTO [DTDBListings].[dbo].[Listings_Batch]
			FROM [src_PlatLabs].[dbo].[vStdLayout_DTDB]
			WHERE mls_id in(Select mls_id from [src_PlatLabs].[dbo].[platlabs_update_config] where code like '%_39' and active = '1')
			and LoadDate > @MaxDt

			CREATE NONCLUSTERED INDEX [ix_MlsID_ListingID] ON [DTDBListings].[dbo].[Listings_Batch]
			([mls_id] ASC,
				[mls_listing_id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF)

			ALTER INDEX [ix_MLSIDListingID] ON [DTDBListings].[dbo].[Listings] REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		
			DELETE FROM [src_PlatLabs].[dbo].[a]
			FROM [DTDBListings].[dbo].[Listings] a JOIN [DTDBListings].[dbo].[Listings_Batch] b
			on a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id

			INSERT INTO [DTDBListings].[dbo].[Listings]([mls_id]
				  ,[mls_listing_id]
				  ,[PropertyID]
				  ,[REF_ID]
				  ,[APN]
				  ,[FIPS]
				  ,[school_district]
				  ,[elementary_school]
				  ,[junior_high_school]
				  ,[high_school]
				  ,[middle_school]
				  ,[videos_change_date]
				  ,[major_change_date]
				  ,[above_grade_finished_area]
				  ,[activation_date]
				  ,[active]
				  ,[additional_features]
				  ,[address]
				  ,[air_conditioning]
				  ,[allow_avm]
				  ,[allow_comments]
				  ,[annual_insurance]
				  ,[annual_maintenance]
				  ,[annual_management_fees]
				  ,[annual_tax]
				  ,[annual_utilities]
				  ,[appliances]
				  ,[approximate_age]
				  ,[area_name]
				  ,[area_name_minor]
				  ,[availability_date]
				  ,[basement_description]
				  ,[bathrooms]
				  ,[bathrooms_full]
				  ,[bathrooms_half]
				  ,[bathrooms_partial]
				  ,[bathrooms_quarter]
				  ,[bathrooms_three_quarter]
				  ,[bedrooms]
				  ,[below_grade_description]
				  ,[below_grade_finished_area]
				  ,[building_name]
				  ,[cancelled_date]
				  ,[ceiling_height]
				  ,[ceiling_height_str]
				  ,[city]
				  ,[close_date]
				  ,[commission_misc]
				  ,[community]
				  ,[condition]
				  ,[confidential_description]
				  ,[construction_materials]
				  ,[contingencies]
				  ,[contingent_date]
				  ,[contract_date]
				  ,[contract_status_change_date]
				  ,[country]
				  ,[country_code]
				  ,[county]
				  ,[created_date]
				  ,[cumulative_days_on_market]
				  ,[current_use]
				  ,[days_on_market]
				  ,[days_on_market_replication_date]
				  ,[den_description]
				  ,[description]
				  ,[design]
				  ,[dining_room_description]
				  ,[directions]
				  ,[disability_features]
				  ,[display_lat]
				  ,[display_lng]
				  ,[display_mls_number]
				  ,[documents_change_timestamp]
				  ,[door_features]
				  ,[down_payment_resource]
				  ,[driveway_description]
				  ,[exclusions]
				  ,[expiration_date]
				  ,[exterior_description]
				  ,[exterior_features]
				  ,[extras]
				  ,[family_room_description]
				  ,[fence_description]
				  ,[financial_information]
				  ,[fireplace_description]
				  ,[fireplaces]
				  ,[flooring_information]
				  ,[foreclosure_type]
				  ,[formatted_address]
				  ,[frontage_type]
				  ,[garage_description]
				  ,[garage_spaces]
				  ,[geocode_date]
				  ,[geocode_quality]
				  ,[green_features]
				  ,[has_basement]
				  ,[has_electricity]
				  ,[has_fireplace]
				  ,[has_garage]
				  ,[has_hoa]
				  ,[has_horse_property]
				  ,[has_mountain_view]
				  ,[has_open_house]
				  ,[has_pool]
				  ,[has_price_reduced]
				  ,[has_sewer]
				  ,[has_view]
				  ,[has_water]
				  ,[has_waterfront]
				  ,[has_waterview]
				  ,[heat_source]
				  ,[heat_type]
				  ,[hide_address]
				  ,[hoa_amenities]
				  ,[hoa_fee]
				  ,[hoa_fee_includes]
				  ,[hoa_frequency]
				  ,[hoa_name]
				  ,[hoa_phone]
				  ,[idx]
				  ,[improvements]
				  ,[interior_features]
				  ,[is_adult_community]
				  ,[is_boat_slip]
				  ,[is_business_with_real_estate]
				  ,[is_commercial]
				  ,[is_commercial_lease]
				  ,[is_condo]
				  ,[is_condo_townhouse]
				  ,[is_coop]
				  ,[is_cul_de_sac]
				  ,[is_duplex]
				  ,[is_farm_hobby]
				  ,[is_foreclosure]
				  ,[is_gated_community]
				  ,[is_golf_community]
				  ,[is_industrial]
				  ,[is_investment]
				  ,[is_loft]
				  ,[is_lot]
				  ,[is_mixed_use]
				  ,[is_mobile_home]
				  ,[is_model]
				  ,[is_multi_family]
				  ,[is_new_construction]
				  ,[is_on_golf_course]
				  ,[is_one_story]
				  ,[is_other]
				  ,[is_rental]
				  ,[is_residential_lease]
				  ,[is_shortsale]
				  ,[is_single_family]
				  ,[is_single_family_detached]
				  ,[is_three_plus_story]
				  ,[is_townhouse]
				  ,[is_two_story]
				  ,[kitchen]
				  ,[kitchen_description]
				  ,[kitchen_dimensions]
				  ,[kitchen_level]
				  ,[landscape]
				  ,[last_update_date]
				  ,[latitude]
				  ,[laundry_room_description]
				  ,[list_date]
				  ,[listing_agent_commission_rate]
				  ,[listing_agent_email]
				  ,[listing_agent_flat_fee]
				  ,[listing_agent_id]
				  ,[listing_agent_name]
				  ,[listing_agent_phone]
				  ,[listing_agent_uid]
				  ,[listing_agreement]
				  ,[listing_key]
				  ,[listing_office_id]
				  ,[listing_office_name]
				  ,[listing_office_phone]
				  ,[listing_office_uid]
				  ,[living_room_description]
				  ,[location]
				  ,[longitude]
				  ,[lot_description]
				  ,[lot_dimension]
				  ,[lot_size]
				  ,[lot_size_area]
				  ,[lot_size_display]
				  ,[lot_size_source]
				  ,[lot_size_square_feet]
				  ,[lot_size_units]
				  ,[market_name]
				  ,[master_bath_description]
				  ,[master_bedroom_description]
				  ,[master_bedroom_level]
				  ,[mls_create_date]
				  ,[mls_lat]
				  ,[mls_list_date]
				  ,[mls_lng]
				  ,[mls_property_sub_type]
				  ,[mls_property_type]
				  ,[mls_status]
				  ,[mls_update_date]
				  ,[modified_date]
				  ,[monthly_hoa_fee]
				  ,[neighborhood]
				  ,[normalized_hoa_frequency]
				  ,[occupant_type]
				  ,[off_market_date]
				  ,[on_market_date]
				  ,[open_house]
				  ,[original_listing_price]
				  ,[originating_system_name]
				  ,[outbuildings_description]
				  ,[ownership]
				  ,[parcel_number]
				  ,[parcel_number_public_record]
				  ,[parking_description]
				  ,[parking_spaces]
				  ,[patio_and_porch_features]
				  ,[pending_date]
				  ,[pets_allowed]
				  ,[photo_count]
				  ,[photo_date]
				  ,[pool_description]
				  ,[price]
				  ,[price_change_date]
				  ,[price_change_timestamp]
				  ,[price_display]
				  ,[price_per_square_foot]
				  ,[property_type]
				  ,[property_view_description]
				  ,[restrictions]
				  ,[road_frontage_description]
				  ,[roofing]
				  ,[rooms]
				  ,[rooms_description]
				  ,[rupid]
				  ,[sale_type]
				  ,[security_features]
				  ,[seller_concessions]
				  ,[selling_agent_commission_rate]
				  ,[selling_agent_flat_fee]
				  ,[sewer]
				  ,[sold_date]
				  ,[sold_price]
				  ,[source_create_date]
				  ,[source_system_key]
				  ,[source_system_name]
				  ,[square_feet]
				  ,[square_feet_of_land]
				  ,[square_feet_range]
				  ,[square_foot_source]
				  ,[state]
				  ,[status]
				  ,[status_change_date]
				  ,[stories_description]
				  ,[stories_total]
				  ,[street_direction]
				  ,[street_name]
				  ,[street_number]
				  ,[street_pre_direction]
				  ,[street_type]
				  ,[structure_type]
				  ,[style]
				  ,[subdivision]
				  ,[substructure]
				  ,[tax_legal_description]
				  ,[tax_year]
				  ,[tenant_pays]
				  ,[topography]
				  ,[total_units]
				  ,[township]
				  ,[uid]
				  ,[unit_number]
				  ,[utilities]
				  ,[utilities_available]
				  ,[virtual_tour]
				  ,[virtual_tour_branded]
				  ,[walk_score]
				  ,[water]
				  ,[water_frontage]
				  ,[waterfront_description]
				  ,[windows_description]
				  ,[withdrawn_date]
				  ,[year_built]
				  ,[year_built_source]
				  ,[zip]
				  ,[zoning]
				  ,[LoadDate]
				  ,[FeatureExteriorGeneral]
				  ,[FeatureExteriorStyle]
				  ,[FeatureExteriorPool]
				  ,[FeatureExteriorParking]
				  ,[FeatureInteriorAC]
				  ,[FeatureInteriorAppliances]
				  ,[FeatureInteriorBasement]
				  ,[FeatureInteriorDisability]
				  ,[FeatureInteriorGreen]
				  ,[FeatureInteriorFireplace]
				  ,[FeatureInteriorFlooring]
				  ,[FeatureInteriorGeneral]
				  ,[FeatureInteriorHeating]
				  ,[FeatureInteriorLaundry]
				  ,[FeatureInteriorRooms]
				  ,[ConstructionGeneral]
				  ,[constructinoRoofing]
				  ,[ConstructionWindows]
				  ,[LocationCounty]
				  ,[LocationHOAAmenities]
				  ,[LocationOriginatingMLS]
				  ,[LocationRoadAccess]
				  ,[LotCurrentUse]
				  ,[LotFencing]
				  ,[LotView]
				  ,[LotZoning]
				  ,[UtilitesSewer]
				  ,[UtilitiesUtilities]
				  ,[UtilitiesWater]
				  ,[FinancialBuyersAgentCompensation]
				  ,[FinancialNACompensation]
				  ,[FinancialSource]
				  ,[NormalizedAddress_CompleteAddress]
				  ,[NormalizedAddress_StreetNumber]
				  ,[NormalizedAddress_StreetPredirection]
				  ,[NormalizedAddress_StreetName]
				  ,[NormalizedAddress_StreetSuffix]
				  ,[NormalizedAddress_StreetPostdirection]
				  ,[NormalizedAddress_City]
				  ,[NormalizedAddress_State]
				  ,[NormalizedAddress_Zip]
				  ,[co_listing_agent_Name]
				  ,[co_listing_agent_email]
				  ,[co_listing_agent_phone]
				  ,[co_listing_agent_FirstName]
				  ,[co_listing_agent_LastName]
				  ,[co_listing_agent_License_Number]
				  ,[co_Selling_agent_Name]
				  ,[co_Selling_agent_email]
				  ,[co_Selling_agent_phone]
				  ,[co_Selling_agent_FirstName]
				  ,[co_Selling_agent_LastName]
				  ,[co_Selling_agent_License_Number]
				  ,[Selling_Agent_Name]
				  ,[Selling_Agent_email]
				  ,[Selling_Agent_phone]
				  ,[Selling_Agent_FirstName]
				  ,[Selling_Agent_LastName]
				  ,[Selling_Agent_license_number]
				  ,[Selling_Agent_office_ID]
				  ,[Selling_Agent_Office_Name]
				  ,[Selling_Agent_Office_Phone]
				  ,[List_Agent_Name]
				  ,[List_Agent_email]
				  ,[List_Agent_phone]
				  ,[List_Agent_FirstName]
				  ,[List_Agent_LastName]
				  ,[List_Agent_License_Number]
				  ,[List_Agent_Office_ID]
				  ,[List_Agent_Office_Name]
				  ,[List_Agent_Office_Phone]
				  ,[GeoData_CityName]
				  ,[GeoData_ZipName]
				  ,[GeoData_NeighborhoodName]
				  ,[GeoData_SchoolDistrictName]
				  ,[FALatitude]
				  ,[FALongitude]
				  ,[SitusLatitude]
				  ,[SitusLongitude]
				  ,[AVM]
				  ,[ValuationDate]
				  ,[Platlabs_Listdate]
			)
		Select [mls_id]
			  ,[mls_listing_id]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[APN]
			  ,[FIPS]
			  ,[school_district]
			  ,[elementary_school]
			  ,[junior_high_school]
			  ,[high_school]
			  ,[middle_school]
			  ,[videos_change_date]
			  ,[major_change_date]
			  ,[above_grade_finished_area]
			  ,[activation_date]
			  ,[active]
			  ,[additional_features]
			  ,[address]
			  ,[air_conditioning]
			  ,[allow_avm]
			  ,[allow_comments]
			  ,[annual_insurance]
			  ,[annual_maintenance]
			  ,[annual_management_fees]
			  ,[annual_tax]
			  ,[annual_utilities]
			  ,[appliances]
			  ,[approximate_age]
			  ,[area_name]
			  ,[area_name_minor]
			  ,[availability_date]
			  ,[basement_description]
			  ,[bathrooms]
			  ,[bathrooms_full]
			  ,[bathrooms_half]
			  ,[bathrooms_partial]
			  ,[bathrooms_quarter]
			  ,[bathrooms_three_quarter]
			  ,[bedrooms]
			  ,[below_grade_description]
			  ,[below_grade_finished_area]
			  ,[building_name]
			  ,[cancelled_date]
			  ,[ceiling_height]
			  ,[ceiling_height_str]
			  ,[city]
			  ,[close_date]
			  ,[commission_misc]
			  ,[community]
			  ,[condition]
			  ,[confidential_description]
			  ,[construction_materials]
			  ,[contingencies]
			  ,[contingent_date]
			  ,[contract_date]
			  ,[contract_status_change_date]
			  ,[country]
			  ,[country_code]
			  ,[county]
			  ,[created_date]
			  ,[cumulative_days_on_market]
			  ,[current_use]
			  ,[days_on_market]
			  ,[days_on_market_replication_date]
			  ,[den_description]
			  ,[description]
			  ,[design]
			  ,[dining_room_description]
			  ,[directions]
			  ,[disability_features]
			  ,[display_lat]
			  ,[display_lng]
			  ,[display_mls_number]
			  ,[documents_change_timestamp]
			  ,[door_features]
			  ,[down_payment_resource]
			  ,[driveway_description]
			  ,[exclusions]
			  ,[expiration_date]
			  ,[exterior_description]
			  ,[exterior_features]
			  ,[extras]
			  ,[family_room_description]
			  ,[fence_description]
			  ,[financial_information]
			  ,[fireplace_description]
			  ,[fireplaces]
			  ,[flooring_information]
			  ,[foreclosure_type]
			  ,[formatted_address]
			  ,[frontage_type]
			  ,[garage_description]
			  ,[garage_spaces]
			  ,[geocode_date]
			  ,[geocode_quality]
			  ,[green_features]
			  ,[has_basement]
			  ,[has_electricity]
			  ,[has_fireplace]
			  ,[has_garage]
			  ,[has_hoa]
			  ,[has_horse_property]
			  ,[has_mountain_view]
			  ,[has_open_house]
			  ,[has_pool]
			  ,[has_price_reduced]
			  ,[has_sewer]
			  ,[has_view]
			  ,[has_water]
			  ,[has_waterfront]
			  ,[has_waterview]
			  ,[heat_source]
			  ,[heat_type]
			  ,[hide_address]
			  ,[hoa_amenities]
			  ,[hoa_fee]
			  ,[hoa_fee_includes]
			  ,[hoa_frequency]
			  ,[hoa_name]
			  ,[hoa_phone]
			  ,[idx]
			  ,[improvements]
			  ,[interior_features]
			  ,[is_adult_community]
			  ,[is_boat_slip]
			  ,[is_business_with_real_estate]
			  ,[is_commercial]
			  ,[is_commercial_lease]
			  ,[is_condo]
			  ,[is_condo_townhouse]
			  ,[is_coop]
			  ,[is_cul_de_sac]
			  ,[is_duplex]
			  ,[is_farm_hobby]
			  ,[is_foreclosure]
			  ,[is_gated_community]
			  ,[is_golf_community]
			  ,[is_industrial]
			  ,[is_investment]
			  ,[is_loft]
			  ,[is_lot]
			  ,[is_mixed_use]
			  ,[is_mobile_home]
			  ,[is_model]
			  ,[is_multi_family]
			  ,[is_new_construction]
			  ,[is_on_golf_course]
			  ,[is_one_story]
			  ,[is_other]
			  ,[is_rental]
			  ,[is_residential_lease]
			  ,[is_shortsale]
			  ,[is_single_family]
			  ,[is_single_family_detached]
			  ,[is_three_plus_story]
			  ,[is_townhouse]
			  ,[is_two_story]
			  ,[kitchen]
			  ,[kitchen_description]
			  ,[kitchen_dimensions]
			  ,[kitchen_level]
			  ,[landscape]
			  ,[last_update_date]
			  ,[latitude]
			  ,[laundry_room_description]
			  ,[list_date]
			  ,[listing_agent_commission_rate]
			  ,[listing_agent_email]
			  ,[listing_agent_flat_fee]
			  ,[listing_agent_id]
			  ,[listing_agent_name]
			  ,[listing_agent_phone]
			  ,[listing_agent_uid]
			  ,[listing_agreement]
			  ,[listing_key]
			  ,[listing_office_id]
			  ,[listing_office_name]
			  ,[listing_office_phone]
			  ,[listing_office_uid]
			  ,[living_room_description]
			  ,[location]
			  ,[longitude]
			  ,[lot_description]
			  ,[lot_dimension]
			  ,[lot_size]
			  ,[lot_size_area]
			  ,[lot_size_display]
			  ,[lot_size_source]
			  ,[lot_size_square_feet]
			  ,[lot_size_units]
			  ,[market_name]
			  ,[master_bath_description]
			  ,[master_bedroom_description]
			  ,[master_bedroom_level]
			  ,[mls_create_date]
			  ,[mls_lat]
			  ,[mls_list_date]
			  ,[mls_lng]
			  ,[mls_property_sub_type]
			  ,[mls_property_type]
			  ,[mls_status]
			  ,[mls_update_date]
			  ,[modified_date]
			  ,[monthly_hoa_fee]
			  ,[neighborhood]
			  ,[normalized_hoa_frequency]
			  ,[occupant_type]
			  ,[off_market_date]
			  ,[on_market_date]
			  ,[open_house]
			  ,[original_listing_price]
			  ,[originating_system_name]
			  ,[outbuildings_description]
			  ,[ownership]
			  ,[parcel_number]
			  ,[parcel_number_public_record]
			  ,[parking_description]
			  ,[parking_spaces]
			  ,LEFT([patio_and_porch_features],250) [patio_and_porch_features]
			  ,[pending_date]
			  ,[pets_allowed]
			  ,[photo_count]
			  ,[photo_date]
			  ,[pool_description]
			  ,[price]
			  ,[price_change_date]
			  ,[price_change_timestamp]
			  ,[price_display]
			  ,[price_per_square_foot]
			  ,[property_type]
			  ,[property_view_description]
			  ,[restrictions]
			  ,[road_frontage_description]
			  ,[roofing]
			  ,[rooms]
			  ,[rooms_description]
			  ,[rupid]
			  ,[sale_type]
			  ,[security_features]
			  ,[seller_concessions]
			  ,[selling_agent_commission_rate]
			  ,[selling_agent_flat_fee]
			  ,[sewer]
			  ,[sold_date]
			  ,[sold_price]
			  ,[source_create_date]
			  ,[source_system_key]
			  ,[source_system_name]
			  ,[square_feet]
			  ,[square_feet_of_land]
			  ,[square_feet_range]
			  ,[square_foot_source]
			  ,[state]
			  ,[status]
			  ,[status_change_date]
			  ,[stories_description]
			  ,[stories_total]
			  ,[street_direction]
			  ,[street_name]
			  ,[street_number]
			  ,[street_pre_direction]
			  ,[street_type]
			  ,[structure_type]
			  ,[style]
			  ,[subdivision]
			  ,[substructure]
			  ,[tax_legal_description]
			  ,[tax_year]
			  ,[tenant_pays]
			  ,[topography]
			  ,[total_units]
			  ,[township]
			  ,[uid]
			  ,[unit_number]
			  ,[utilities]
			  ,[utilities_available]
			  ,[virtual_tour]
			  ,[virtual_tour_branded]
			  ,[walk_score]
			  ,[water]
			  ,[water_frontage]
			  ,[waterfront_description]
			  ,[windows_description]
			  ,[withdrawn_date]
			  ,[year_built]
			  ,[year_built_source]
			  ,[zip]
			  ,[zoning]
			  ,[LoadDate]
			  ,[FeatureExteriorGeneral]
			  ,[FeatureExteriorStyle]
			  ,[FeatureExteriorPool]
			  ,[FeatureExteriorParking]
			  ,[FeatureInteriorAC]
			  ,[FeatureInteriorAppliances]
			  ,[FeatureInteriorBasement]
			  ,[FeatureInteriorDisability]
			  ,[FeatureInteriorGreen]
			  ,[FeatureInteriorFireplace]
			  ,[FeatureInteriorFlooring]
			  ,[FeatureInteriorGeneral]
			  ,[FeatureInteriorHeating]
			  ,[FeatureInteriorLaundry]
			  ,[FeatureInteriorRooms]
			  ,[ConstructionGeneral]
			  ,[constructinoRoofing]
			  ,[ConstructionWindows]
			  ,[LocationCounty]
			  ,[LocationHOAAmenities]
			  ,[LocationOriginatingMLS]
			  ,[LocationRoadAccess]
			  ,[LotCurrentUse]
			  ,[LotFencing]
			  ,[LotView]
			  ,[LotZoning]
			  ,[UtilitesSewer]
			  ,[UtilitiesUtilities]
			  ,[UtilitiesWater]
			  ,[FinancialBuyersAgentCompensation]
			  ,[FinancialNACompensation]
			  ,[FinancialSource]
			  ,[NormalizedAddress_CompleteAddress]
			  ,[NormalizedAddress_StreetNumber]
			  ,[NormalizedAddress_StreetPredirection]
			  ,[NormalizedAddress_StreetName]
			  ,[NormalizedAddress_StreetSuffix]
			  ,[NormalizedAddress_StreetPostdirection]
			  ,[NormalizedAddress_City]
			  ,[NormalizedAddress_State]
			  ,[NormalizedAddress_Zip]
			  ,[co_listing_agent_Name]
			  ,[co_listing_agent_email]
			  ,[co_listing_agent_phone]
			  ,[co_listing_agent_FirstName]
			  ,[co_listing_agent_LastName]
			  ,[co_listing_agent_License_Number]
			  ,[co_Selling_agent_Name]
			  ,[co_Selling_agent_email]
			  ,[co_Selling_agent_phone]
			  ,[co_Selling_agent_FirstName]
			  ,[co_Selling_agent_LastName]
			  ,[co_Selling_agent_License_Number]
			  ,[Selling_Agent_Name]
			  ,[Selling_Agent_email]
			  ,[Selling_Agent_phone]
			  ,[Selling_Agent_FirstName]
			  ,[Selling_Agent_LastName]
			  ,[Selling_Agent_license_number]
			  ,[Selling_Agent_office_ID]
			  ,[Selling_Agent_Office_Name]
			  ,[Selling_Agent_Office_Phone]
			  ,[List_Agent_Name]
			  ,[List_Agent_email]
			  ,[List_Agent_phone]
			  ,[List_Agent_FirstName]
			  ,[List_Agent_LastName]
			  ,[List_Agent_License_Number]
			  ,[List_Agent_Office_ID]
			  ,[List_Agent_Office_Name]
			  ,[List_Agent_Office_Phone]
			  ,[GeoData_CityName]
			  ,[GeoData_ZipName]
			  ,[GeoData_NeighborhoodName]
			  ,[GeoData_SchoolDistrictName]
			  ,[FALatitude]
			  ,[FALongitude]
			  ,[SitusLatitude]
			  ,[SitusLongitude]
			  ,[AVM]
			  ,[ValuationDate]
			  ,[Platlabs_Listdate]
	 from [DTDBListings].[dbo].[Listings_Batch]

END




