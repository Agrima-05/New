/* Source: AZUVNSQLDTDB003.datatree.local | HOA | Staging.ImportSecondPassContacts | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [HOA].[Staging].[ImportSecondPassContacts]
AS
-- =============================================
-- Original Author:                            Ian Perez
-- Create date: 02/14/2016
-- Description:    Import Owner Association Contact Data from NEO/Plant 2nd pass HOA keying project into Staging 
-- ChangeLog: 06/10/2016 TDao - Improved phone numbers
--                                               12/21/2016 TDao - Remove obsolete Phones
--                                               04/18/2018 TDao - Re-write contacts to include CompanyName name
--                                    7/17/2018 TDao - Null check on SourcePK/Id
-- =============================================
DECLARE @regex VARCHAR(200) = '(?:\+?1)?-?\s*\(?(\d{3})?\)?(?:\.|-|\/)?\s*(?:\d-)?(\d{3})(?:\.|-|\s+)*(\d{4})(?:\s*[A-z]+\.?\s*(\d+))?'

SELECT DISTINCT *
INTO #KeyedLiens
FROM (
	SELECT SourceId
		,SourcePK
		,Cast(NULL AS VARCHAR(255)) AS CompanyName
		,NULLIF(HOAContact, '') AS NAME
		,NULLIF(LTRIM(RTRIM(h.HOA_Std_Street_Number) + ' ') + LTRIM(RTRIM(h.HOA_Std_Direction) + ' ') + LTRIM(RTRIM(h.HOA_Std_Street_Name) + ' ') + LTRIM(RTRIM(h.HOA_Std_Street_Type) + ' ') + LTRIM(RTRIM(h.HOA_Std_Post_Direction) + ' ') + LTRIM(RTRIM(h.HOA_Std_Unit_Type) + ' ') + LTRIM(RTRIM(h.HOA_Std_Unit) + ' '), '') AS [Address]
		,NULLIF(h.HOA_Std_City, '') AS City
		,NULLIF(h.HOA_Std_State, '') AS STATE
		,NULLIF(h.HOA_Std_Zip, '') AS Zip
		,NULLIF(h.HOA_Std_Plus4, '') AS Plus4
		,NULLIF(h.HOAEmail, '') AS Email
		,CASE 
			WHEN [SPDB].[dbo].[RegexIsMatch](h.HOAPhone, @regex, 0) = 1
				THEN CASE 
						WHEN [SPDB].[dbo].[RegexExtract](h.HOAPhone, @regex, 1, 0) <> ''
							THEN '(' + [SPDB].[dbo].[RegexExtract](h.HOAPhone, @regex, 1, 0) + ') '
						END + + [SPDB].[dbo].[RegexExtract](h.HOAPhone, @regex, 2, 0) + '-' + [SPDB].[dbo].[RegexExtract](h.HOAPhone, @regex, 3, 0)
			END AS Phone
		,1 AS ContactTypeId
		,NULL AS ContactId
	FROM [HOA].[dbo].[HOA_Lien] h
	WHERE HOA_Std_Verified = 1
		AND SourcePK IS NOT NULL
		AND SourceId IS NOT NULL
	) R

CREATE NONCLUSTERED INDEX #PKC ON #KeyedLiens (
	SourceId
	,SourcePK
	,ContactTypeId
	)

INSERT INTO #KeyedLiens
SELECT DISTINCT *
FROM (
	SELECT SourceId
		,SourcePK
		,NULLIF(MAName, '') AS CompanyName
		,NULLIF(MAContact, '') AS NAME
		,NULLIF(LTRIM(RTRIM(h.MA_Std_Street_Number) + ' ') + LTRIM(RTRIM(h.MA_Std_Direction) + ' ') + LTRIM(RTRIM(h.MA_Std_Street_Name) + ' ') + LTRIM(RTRIM(h.MA_Std_Street_Type) + ' ') + LTRIM(RTRIM(h.MA_Std_Post_Direction) + ' ') + LTRIM(RTRIM(h.MA_Std_Unit_Type) + ' ') + LTRIM(RTRIM(h.MA_Std_Unit) + ' '), '') AS [Address]
		,NULLIF(h.MA_Std_City, '') AS City
		,NULLIF(h.MA_Std_State, '') AS STATE
		,NULLIF(h.MA_Std_Zip, '') AS Zip
		,NULLIF(h.MA_Std_Plus4, '') AS Plus4
		,NULLIF(h.MAEmail, '') AS Email
		,CASE 
			WHEN [SPDB].[dbo].[RegexIsMatch](h.MAPhone, @regex, 0) = 1
				THEN CASE 
						WHEN [SPDB].[dbo].[RegexExtract](h.MAPhone, @regex, 1, 0) <> ''
							THEN '(' + [SPDB].[dbo].[RegexExtract](h.MAPhone, @regex, 1, 0) + ') '
						END + + [SPDB].[dbo].[RegexExtract](h.MAPhone, @regex, 2, 0) + '-' + [SPDB].[dbo].[RegexExtract](h.MAPhone, @regex, 3, 0)
			END AS Phone
		,2 AS ContactTypeId
		,NULL AS ContactId
	FROM [HOA].[dbo].[HOA_Lien] h
	WHERE MA_Std_Verified = 1
		AND SourcePK IS NOT NULL
		AND SourceId IS NOT NULL
	) R

INSERT INTO #KeyedLiens
SELECT DISTINCT *
FROM (
	SELECT SourceId
		,SourcePK
		,NULLIF(LAWName, '') AS CompanyName
		,NULLIF(LTRIM(RTRIM(LAWFirstName + ' ' + LTRIM(LAWMI)) + RTRIM(' ' + LTRIM(LawLastName) /*+ ' ' + LawSfx*/)), '') AS NAME
		,NULLIF(LTRIM(RTRIM(h.LAW_Std_Street_Number) + ' ') + LTRIM(RTRIM(h.LAW_Std_Direction) + ' ') + LTRIM(RTRIM(h.LAW_Std_Street_Name) + ' ') + LTRIM(RTRIM(h.LAW_Std_Street_Type) + ' ') + LTRIM(RTRIM(h.LAW_Std_Post_Direction) + ' ') + LTRIM(RTRIM(h.LAW_Std_Unit_Type) + ' ') + LTRIM(RTRIM(h.LAW_Std_Unit) + ' '), '') AS [Address]
		,NULLIF(h.LAW_Std_City, '') AS City
		,NULLIF(h.LAW_Std_State, '') AS STATE
		,NULLIF(h.LAW_Std_Zip, '') AS Zip
		,NULLIF(h.LAW_Std_Plus4, '') AS Plus4
		,NULLIF(h.LAWEMail, '') AS LAWEMail
		,CASE 
			WHEN [SPDB].[dbo].[RegexIsMatch](h.LAWPhone, @regex, 0) = 1
				THEN CASE 
						WHEN [SPDB].[dbo].[RegexExtract](h.LAWPhone, @regex, 1, 0) <> ''
							THEN '(' + [SPDB].[dbo].[RegexExtract](h.LAWPhone, @regex, 1, 0) + ') '
						END + + [SPDB].[dbo].[RegexExtract](h.LAWPhone, @regex, 2, 0) + '-' + [SPDB].[dbo].[RegexExtract](h.LAWPhone, @regex, 3, 0)
			END AS Phone
		,3 AS ContactTypeId
		,NULL AS ContactId
	FROM [HOA].[dbo].[HOA_Lien] h
	WHERE LAW_Std_Verified = 1
		AND SourcePK IS NOT NULL
		AND SourceId IS NOT NULL
	) R

INSERT INTO [HOA].[Staging].[Contact] (
	NAME
	,[Address]
	,City
	,[State]
	,Zip
	,Plus4
	,Email
	,BusinessPhoneNbr
	,InitialSourceId
	,SourcePK
	,ContactTypeId
	,CreateDate
	,CompanyName
	)
SELECT a.NAME
	,a.[Address]
	,a.City
	,a.[State]
	,a.Zip
	,a.Plus4
	,a.Email
	,a.Phone
	,MIN(a.SourceId) AS SourceId
	,MIN(a.SourcePK) AS SourcePK
	,MIN(a.ContactTypeId) AS ContactTypeId
	,getdate()
	,a.CompanyName
FROM #KeyedLiens a
LEFT JOIN [HOA].[Staging].[Contact] b ON (
		a.NAME = b.NAME
		OR (
			a.NAME IS NULL
			AND b.NAME IS NULL
			)
		)
	AND (
		a.[Address] = b.[Address]
		OR (
			a.[Address] IS NULL
			AND b.[Address] IS NULL
			)
		)
	AND (
		a.City = b.City
		OR (
			a.City IS NULL
			AND b.City IS NULL
			)
		)
	AND (
		a.[State] = b.[State]
		OR (
			a.[State] IS NULL
			AND b.[State] IS NULL
			)
		)
	AND (
		a.Zip = b.Zip
		OR (
			a.Zip IS NULL
			AND b.Zip IS NULL
			)
		)
	AND (
		a.Plus4 = b.Plus4
		OR (
			a.Plus4 IS NULL
			AND b.Plus4 IS NULL
			)
		)
	AND (
		a.Email = b.Email
		OR (
			a.Email IS NULL
			AND b.Email IS NULL
			)
		)
	AND (
		a.Phone = b.BusinessPhoneNbr
		OR a.Phone = b.CellPhoneNbr
		OR (
			a.Phone IS NULL
			AND b.BusinessPhoneNbr IS NULL
			AND b.CellPhoneNbr IS NULL
			)
		)
	AND (
		a.CompanyName = b.CompanyName
		OR (
			a.CompanyName IS NULL
			AND b.CompanyName IS NULL
			)
		)
WHERE b.Id IS NULL
GROUP BY a.NAME
	,a.[Address]
	,a.City
	,a.[State]
	,a.Zip
	,a.Plus4
	,a.Email
	,a.Phone
	,a.CompanyName

UPDATE [HOA].[Staging].[a]
SET ContactId = b.Id
FROM #KeyedLiens a
INNER JOIN [HOA].[Staging].[Contact] b ON (
		a.NAME = b.NAME
		OR (
			a.NAME IS NULL
			AND b.NAME IS NULL
			)
		)
	AND (
		a.[Address] = b.[Address]
		OR (
			a.[Address] IS NULL
			AND b.[Address] IS NULL
			)
		)
	AND (
		a.City = b.City
		OR (
			a.City IS NULL
			AND b.City IS NULL
			)
		)
	AND (
		a.[State] = b.[State]
		OR (
			a.[State] IS NULL
			AND b.[State] IS NULL
			)
		)
	AND (
		a.Zip = b.Zip
		OR (
			a.Zip IS NULL
			AND b.Zip IS NULL
			)
		)
	AND (
		a.Plus4 = b.Plus4
		OR (
			a.Plus4 IS NULL
			AND b.Plus4 IS NULL
			)
		)
	AND (
		a.Email = b.Email
		OR (
			a.Email IS NULL
			AND b.Email IS NULL
			)
		)
	AND (
		a.Phone = b.BusinessPhoneNbr
		OR a.Phone = b.CellPhoneNbr
		OR (
			a.Phone IS NULL
			AND b.BusinessPhoneNbr IS NULL
			AND b.CellPhoneNbr IS NULL
			)
		)
	AND (
		a.CompanyName = b.CompanyName
		OR (
			a.CompanyName IS NULL
			AND b.CompanyName IS NULL
			)
		)

UPDATE [HOA].[Staging].[a]
SET HOAContactId = b.ContactId
FROM [HOA].[OA].[HOALien] a
INNER JOIN #KeyedLiens b ON a.SourceId = b.SourceId
	AND a.SourcePK = b.SourcePK
	AND b.ContactTypeId = 1
WHERE a.HOAContactId IS NULL
	OR a.HOAContactId <> b.ContactId

UPDATE [HOA].[Staging].[a]
SET MAContactId = b.ContactId
FROM [HOA].[OA].[HOALien] a
INNER JOIN #KeyedLiens b ON a.SourceId = b.SourceId
	AND a.SourcePK = b.SourcePK
	AND b.ContactTypeId = 2
WHERE a.MAContactId IS NULL
	OR a.MAContactId <> b.ContactId

UPDATE [HOA].[Staging].[a]
SET LAWContactId = b.ContactId
FROM [HOA].[OA].[HOALien] a
INNER JOIN #KeyedLiens b ON a.SourceId = b.SourceId
	AND a.SourcePK = b.SourcePK
	AND b.ContactTypeId = 3
WHERE a.LAWContactId IS NULL
	OR a.LAWContactId <> b.ContactId

