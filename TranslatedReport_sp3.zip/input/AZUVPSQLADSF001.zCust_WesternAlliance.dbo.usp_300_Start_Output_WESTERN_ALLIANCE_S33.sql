SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_WesternAlliance].[dbo].[usp_300_Start_Output_WESTERN_ALLIANCE_S33]

AS
BEGIN
	
	SET NOCOUNT ON;

	------20251114 - Per WO  HOA Lien - Active HOA Liens Only

		DROP TABLE [dbo].[x_Custom_OUTPUT_S33]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S33](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [varchar](250) NULL,
			[PropertyID] [varchar](250) NULL,
			
			[INPUT Property ID][varchar](250)NULL,
			[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Super Lien State][varchar](250)NULL,
			[CoverageStatus_HOA_LIEN][varchar](250)NULL,
			[HAS_HOA_RECORD][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Current Owner Name 1][varchar](250)NULL,
			[Current Owner Name 2][varchar](250)NULL,
			[Ownership Change Date][varchar](250)NULL,
			[Current Owner Doc Type][varchar](250)NULL,



		[NbrofRecordings] [varchar](250) NULL,
		[Number of HOA Liens] [varchar](250) NULL,
		[NbrofRecordings_NOD_NOS] [varchar](250) NULL,
		NbrofRecordings_RELEASED [varchar](250) NULL,


			[HOA_Name] [varchar](250) NULL,
			[HOA_Type] [varchar](250) NULL,
			[HOA_Contact_Name] [varchar](250) NULL,
			[HOA_Address_Mailing] [varchar](250) NULL,
			[HOA_City_Mailing] [varchar](250) NULL,
			[HOA_State_Mailing] [varchar](250) NULL,
			[HOA_Zip_Mailing] [varchar](250) NULL,
			[HOA_Contact_Phone] [varchar](250) NULL,
			[HOA_Contact_Email] [varchar](255) NULL,
			[HOA_Fee_Value][varchar](255) NULL,
			[HOA_Fee_Minimum_Value][varchar](255) NULL,
			[HOA_Fee_Maximum_Value][varchar](255) NULL,
			[HOA_Fee_Type][varchar](255) NULL,
			[HOA_Fee_Frequency][varchar](255) NULL,
			
			--------------------REMOVE FROM CLIENT OUTPUT------
			
			[INPUT Start Date][varchar](250)Null,		
			[MAX_LIENDATE][varchar](250)Null	,
			[MAX_NODDATE][varchar](250)Null

		) ON [PRIMARY]

	
			
		/****** Object:  Index [NonClusteredIndex-20200131-124816]    Script Date: 1/31/2020 12:48:39 PM ******/
		CREATE NONCLUSTERED INDEX [NonClusteredIndex-20200131-124816] ON [dbo].[x_Custom_OUTPUT_S33]
		(
			[FIPS] ASC,
			[WORK_REF_ID] ASC,
			[PROPERTYID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		

		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33](
		[INPUT Property ID],
		[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip])
	  
		
		Select 
		[PropertyID]
		,[LoanID] 
		,left([PropertyStreet] ,250)
		,[PropertyCity] 
		,[PropertyState]
		,[PropertyZIPCode] 
		--,convert(DAte,[IssuanceDate] )
		
		From [zCust_WesternAlliance].[dbo].[INPUT_RAW_CUST]
		
	

		

	  Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
	  
		
		UPDATE [zCust_WesternAlliance].[dbo].[a] 
		SET 
		a.[PROPERTYID] = c.[PROPERTYID]
		,a.WORK_REF_ID = c.REF_ID
		,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--,a.[County Code] = RIGHT((CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END),3)
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [zCust_WesternAlliance].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Property ID] = c.RAW_ID

		

		Update [zCust_WesternAlliance].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Property ID] = c.RAW_ID


		
		
	
		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.[Current Owner Name 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner Name 2] = B.[OwnerStdNAME2FULL]
			FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID



				
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_WesternAlliance].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

	

	
		

	

		Update [zCust_WesternAlliance].[dbo].[A]
		Set A.[Super Lien State] = 'Y'
		--Select * 
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as A 
		join 
		(Select distinct left(FIPSCODE,2) as FIPS FROM [HOALIEN].[dbo].[SuperLienStates]
		Group by left(FIPSCODE,2))
		as B on 
		LEFT(A.FIPS,2) = B.FIPS

		

	

		------------------20190321 - Per NH - Use FirstAm_HOA Lien Coverage_190220.xlsx report to set In Coverage for HOA Lien!!!----------
		-------Imported report as [HOA_LIEN_COVERAGE_20190321]
		Update [zCust_WesternAlliance].[dbo].[a]
		set [CoverageStatus_HOA_LIEN] = 'Y'
		--Select * 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_COVERAGE_PER_NH_20190321] as B on 
		A.FIPS = B.FIPS
		

		
		
			


		----------------------------Populate HOA Data -----------------
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		[HOA_Name]= [HOA 1- Name]
      ,[HOA_Type]= [HOA 1 - Type]
      ,[HOA_Contact_Name] = [HOA 1- Contact Name 1]
      ,[HOA_Address_Mailing]= [HOA 1- Address (Mailing)  1]
      ,[HOA_City_Mailing]= [HOA 1- City (Mailing) 1]
      ,[HOA_State_Mailing] = [HOA 1- State (Mailing) 1]
      ,[HOA_Zip_Mailing]= [HOA 1- Zip (Mailing)  1]
      ,[HOA_Contact_Phone] = HOA1_Contact_Business_Phone_1
      ,[HOA_Contact_Email] = [HOA 1- Contact Email 1]
      ,[HOA_Fee_Value]= [HOA 1- Fee Value]
      ,[HOA_Fee_Minimum_Value]= [HOA 1- Fee Minimum Value]
      ,[HOA_Fee_Maximum_Value] = [HOA 1- Fee Maximum Value]
      ,[HOA_Fee_Type] = [HOA 1- Fee Type]
      ,[HOA_Fee_Frequency]= [HOA 1 - Fee Frequency]
	 --Select * 
	  FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [DATA].[dbo].[HOA_Fulfillment] as B with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.Work_REF_ID = b.REF_ID 
		where A.Work_REF_ID is not null
		AND A.[HAS_HOA_RECORD] is null


		UPDATE [zCust_WesternAlliance].[dbo].[A]
		Set A.HAS_HOA_RECORD = 'Y'
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [DATA].[dbo].[HOA_Fulfillment] as B with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.Work_REF_ID = b.REF_ID 
		where A.Work_REF_ID is not null
		AND 
		(
			([HOA 1- Name] is not null and  [HOA 1- Name] not like '')
			OR
			([HOA 1 - Type] is not null and  [HOA 1 - Type] not like '')
			OR
			([HOA 1- Contact Name 1] is not null and  [HOA 1- Contact Name 1] not like '')
			OR
			([HOA 1- Address (Mailing)  1] is not null and  [HOA 1- Address (Mailing)  1] not like '')
			OR
			([HOA 1- City (Mailing) 1] is not null and  [HOA 1- City (Mailing) 1] not like '')
			OR
			([HOA 1- State (Mailing) 1] is not null and  [HOA 1- State (Mailing) 1] not like '')
			OR
			([HOA 1- Zip (Mailing)  1] is not null and  [HOA 1- Zip (Mailing)  1] not like '')
		)
		AND HAS_HOA_RECORD is null
		

	
		
		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Set [INPUT Start Date] = convert(Date,[INPUT Start Date])


		Select FIPS, WORK_REF_ID, PROPERTYID, [INPUT Start Date], * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		where PropertyID is not null and [INPUT Start Date] is null

		Select top 1000 * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]

		ALTER TABLE x_Custom_OUTPUT_S33 add [INPUT Unique ID][varchar](250)NULL

		UPdate [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		set
		[INPUT Unique ID] = [INPUT Property ID]

		---------------------------------GET HOA LIENS---------------------------------
	
		EXEC [zCust_WesternAlliance].[dbo].[usp_100A_GET_HOA_LIEN]
		
		
		Select * From  [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA]

		Truncate table HOA_LIEN_DATA_II

		Insert into [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II]
		Select DISTINCT A.[ID],A.[Fips],A.[REF_ID]--A.[NEW_REF_ID]
		,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],
A.[RecordingYear],A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],
A.[NOD_NOS_Recorded_Document_Number],A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],
A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],
A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],
A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],
A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],
A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],
A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],
A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],
A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],
A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],
A.[LAW_Std_State],A.[LAW_Std_Zip],A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],A.[INPUTKEY],A.[RecordNumber]--,A.SUP
		
		--Select B.[INPUT Start Date], A.RecordingDate
		From [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA] as A join 
		[zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as B on 
		a.[INPUTKEY] = b.[INPUT Property ID]
		

		UPDATE [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II] SET REcordNumber = NULL

		UPDATE [zCust_WesternAlliance].[dbo].[t] SET REcordNumber = RowNum
		FROM [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY] ORDER BY convert(date,convert(varchar(10),RecordingDate)) DESC, Identifier DESC, DocumentID desc) AS RowNum
			FROM [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II] t ) r ON t.[INPUTKEY] = r.[INPUTKEY] and t.RecordingDate = r.RecordingDate and t.Identifier = r.Identifier
			and r.DocumentID = t.DocumentID


		Select INPUTKEY, RECORDNUMBER, * From [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II] A
		Order by A.INPUTKEY, A.Recordnumber



		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Set [Number of HOA Liens] = 0
		

		
		Update [zCust_WesternAlliance].[dbo].[A]
		Set A.[Number of HOA Liens] = B.TOTAL 
		--Select B.TOTAL
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN 
		(Select [INPUTKEY], count(*) as TOTAL From [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II] 
		Group by [INPUTKEY]) B
		on a.[INPUT Property ID] = b.[INPUTKEY]

		Select max([Number of HOA Liens]) FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]

	--Select * From x_Custom_OUTPUT_S33

	
			---- FILL IN LIENS 
		SET CONCAT_NULL_YIELDS_NULL OFF

		DECLARE @BeginNbrOfTrans int
		DECLARE @EndNbrOfTrans int
		DECLARE @RecNbr as varchar(5)

		--IF(Select max(convert(int,[Number of HOA Liens])) FROM x_Custom_OUTPUT_S33) > 0 
		IF(Select case when max(convert(int,[Number of HOA Liens])) = 0 then 1 else max([Number of HOA Liens]) end FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]) > 0 
		BEGIN

		SET @BeginNbrOfTrans = 1
		
		Select @EndNbrOfTrans =   case when MAX(convert(int,REcordNumber)) is null then 1 else 
							MAX(convert(int,REcordNumber)) end FROM [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II]
		--Select @EndNbrOfTrans =  MAX(convert(int,REcordNumber)) FROM HOA_LIEN_DATA_II

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					--EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienRecordNbr_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienDocType_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienRecordingDate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienRecordedDocumentNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienAmount_' + @RecNbr + '] [varchar](250) NULL')

					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienAgency_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienContactCompany_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienContactName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienAddressMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienCityMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienStateMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienZipMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_LienContactPhone_' + @RecNbr + '] [varchar](250) NULL')

							

				-----------20180827 - Added code PER NH to backfill the HOA Contact fields from the MA fields if the LAW fields are not populated-----
						
						SET CONCAT_NULL_YIELDS_NULL OFF 

						EXEC('UPDATE a
						SET 
						--a.HOA_LienRecordNbr_' + @RecNbr + ' = ' + @RecNbr + '
						--,A.HOA_LienDocType_' + @RecNbr + ' = B.DocType
						--,
						a.HOA_LienRecordingDate_' + @RecNbr + ' = convert(varchar(10),convert(datetime,convert(varchar(8),RecordingDate)),120)
						,a.HOA_LienRecordedDocumentNumber_' + @RecNbr + ' = DocumentID
						,a.HOA_LienAmount_' + @RecNbr + ' = LienAmount

						,a.HOA_LienName_' + @RecNbr + ' = B.HOANAME
						,a.HOA_LienAgency_' + @RecNbr + ' = B.MAName
						,a.HOA_LienContactCompany_' + @RecNbr + ' = B.lawname 
						,a.HOA_LienContactName_' + @RecNbr + ' = Case when (B.lawfirstname is null or B.lawfirstname like '''') and (B.lawlastname is null or B.lawlastname like '''') then B.MAContact 
						else REPLACE((B.lawfirstname + '' '' + B.lawmi + '' '' + B.lawlastname + '' '' + B.lawsfx),''  '','''') end
						,a.HOA_LienAddressMailing_' + @RecNbr + ' = case when B.[LAWAddress] is null or B.[LAWAddress] like '''' then B.MAAddress else B.[LAWAddress] end
						,a.HOA_LienCityMailing_' + @RecNbr + ' = case when B.[LAWCity] is null or B.[LAWCity] like '''' then B.MACity else B.[LAWCity] end
						,a.HOA_LienStateMailing_' + @RecNbr + ' = case when B.[LAWState] is null or B.[LAWState] like '''' then B.MAState else B.[LAWState] end 
						,a.HOA_LienZipMailing_' + @RecNbr + ' = case when B.[LAWZip] is null or B.[LAWZip] like '''' then B.MAZip else B.[LAWZip] end 
						,a.HOA_LienContactPhone_' + @RecNbr + ' = case when B.[LAWPHONE] is null or B.[LAWPHONE] like '''' then B.MAPhone else B.[LAWPHONE] end


						
						--,a.NOD_NOS_RecordingDate_' + @RecNbr + ' = convert(date,NOD_NOS_Recording_Date)
						--,a.NOD_NOS_RecordedDocumentNumber_' + @RecNbr + ' = NOD_NOS_Recorded_Document_Number
						--,a.NOD_NOS_DefaultAmount_' + @RecNbr + ' = NOD_NOS_Default_Amount
						--,a.HOA_TrusteeAttorneyName_' + @RecNbr + ' = LawName
						--,a.HOA_TrusteeAttorneyPhoneNumber_' + @RecNbr + ' = LawPhone
						--,a.HOA_AuctionDate_' + @RecNbr + ' = HOA_Auction_Date


						--,A.[HOA_SUP_' + @RecNbr + '] = B.[sup]
						
						--SET CONCAT_NULL_YIELDS_NULL OFF 
						--Select REPLACE((B.lawfirstname + '' '' + B.lawmi + '' '' + B.lawlastname + '' '' + B.lawsfx),''  '','''') 
						--Select a.[INPUT Property ID] , B.REcordNumber, B.*
						FROM x_Custom_OUTPUT_S33 a JOIN HOA_LIEN_DATA_II as B on 
						a.[INPUT Property ID] = b.[INPUTkey]
						WHERE B.REcordNumber = ' + @BeginNbrOfTrans + '') 

						--EXEC('
						--Update A
						--Set 
						--A.HOA_LienDocType_' + @RecNbr + ' = B.FULL_NAME
						--FROM x_Custom_OUTPUT_S33 a JOIN
						--zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as B with(NOLOCK) on 
						--A.HOA_LienDocType_' + @RecNbr + '  = B.HOA_DOC_TYPE
						--')

										
					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 
		END


	

		--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
		--where HOA_DOC_TYPE like 'LN%'

		--Select top 10 * From x_Custom_OUTPUT_S33

		-----------------Uncomment & Run----
		Select  A.FIPS, B.State, B.[County Name],WORK_REF_ID, A.[INPUT Property ID],A.[INPUT Address]
		--,A.OwnerStdName1Full
		,A.MAX_LIENDATE
		--, C.DATE_ADDED
		,[Number of HOA Liens]
		--,HOA_LienRecordingDate_001 ,HOA_LienRecordedDocumentNumber_001      ,HOA_LienAmount_001       ,HOA_LienName_001--, HOA_LienDocType_001--,[HOA_SUP_001]
		--,HOA_LienRecordingDate_002 ,HOA_LienRecordedDocumentNumber_002      ,HOA_LienAmount_002       ,HOA_LienName_002--, HOA_LienDocType_002--,[HOA_SUP_002]
		--,HOA_LienRecordingDate_003 ,HOA_LienRecordedDocumentNumber_003      ,HOA_LienAmount_003       ,HOA_LienName_003--, HOA_LienDocType_003--,[HOA_SUP_003]
		--,HOA_LienRecordingDate_004 ,HOA_LienRecordedDocumentNumber_004      ,HOA_LienAmount_004       ,HOA_LienName_004--, --HOA_LienDocType_004
		--,HOA_LienRecordingDate_005 ,HOA_LienRecordedDocumentNumber_005      ,HOA_LienAmount_005       ,HOA_LienName_005--, HOA_LienDocType_005
		--,HOA_LienRecordingDate_006 ,HOA_LienRecordedDocumentNumber_006      ,HOA_LienAmount_006       ,HOA_LienName_006--, HOA_LienDocType_006
		--,HOA_LienRecordingDate_007 ,HOA_LienRecordedDocumentNumber_007      ,HOA_LienAmount_007       ,HOA_LienName_007--, HOA_LienDocType_007
		--,HOA_LienRecordingDate_008 ,HOA_LienRecordedDocumentNumber_008      ,HOA_LienAmount_008       ,HOA_LienName_008--, HOA_LienDocType_008
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as A join [global].[dbo].[county] as B on A.FIPS = B.FIPSCODE
		--join Input_MONITOR as C on A.[INPUT Property ID] = C.INPUT Unique RecordID
		where [Number of HOA Liens] > 0
		--and HOA_LienDocType_001 is null
		Order by A.[Number of HOA Liens] desc







		Select DocType, count(*) From [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA_II]
		Group by DocType

		--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
		--where  HOA_DOC_TYPE in ( 'HALP','f7')





		----------------------------------------------GET NOD----------------------------------------
		truncate table HOA_NOD

		--Exec [dbo].[usp_211_Create_TransHist_Rev5]


		Update [zCust_WesternAlliance].[dbo].[w_TransHist]
		Set toUSE = NULL
		where ToUse is not null

		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET toUSE = 'Y'
		--Select * 
		from [zCust_WesternAlliance].[dbo].[w_TransHist] a 
		JOIN [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] b
		on a.Raw_ID = b.[INPUT Property ID]
		join [zCust_WesternAlliance].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Inst_Nbr
		WHERE 
			----------------------Changed 20181217 to include JUDGEMENTS as they contain the Auction Date info------------
			(Lis_Pendens_Type like '2' or Document_Type like 'JDG')
			AND 
			(convert(date,a.RecordingDate) > convert(date,b.[MAX_NODDATE])
			or convert(date,a.DocDate) > convert(date,b.[MAX_NODDATE])
			OR B.[MAX_NODDATE] is null)
			AND 
			(convert(date,a.RecordingDate) > convert(date,b.[INPUT Start Date])
			or convert(date,a.DocDate) > convert(date,b.[INPUT Start Date])
			OR B.[INPUT Start Date] is null)
			--AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) like '%' + left(A.BuyerBorrower,4) + '%'
			--AND A.BuyerBorrower is not null AND A.BuyerBorrower not like ''



		-------------------------REMOVE any that are NOT currently in PreFC (Status 1 or 6)
		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET toUSE = NULL
		--Select * 
		from [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_DM_DATA] b
		on a.REF_ID = b.PROPERTY_ID
		where B.STATUS not in ('1','6')
		and A.TOUSE = 'Y'


	
		------------------To remove released NOD/NOS records-----------
		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, B.*
		from [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN 
		(Select * From [zCust_WesternAlliance].[dbo].[w_TransHist]
		WHERE DocumentTypeDesc like '%Release%' or DocumentTypeDesc like '%Rescission%' 
		or DocumentType like '%REL%' or DocumentType like '%REC%'
		 ) as B on 
		A.RAW_ID = B.RAW_ID
		and A.DocumentNbr = B.OrigTransDocNumber
		--and A.REcordingDate = B.OrigTransRecDate
		where A.ToUse = 'Y'
		


		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, B.*
		from [zCust_WesternAlliance].[dbo].[w_TransHist] a 
		--JOIN x_Custom_OUTPUT_S33 b
		--on a.Raw_ID = B.[INPUT Property ID]
		join [zCust_WesternAlliance].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Ori_Inst_Nbr
		where A.ToUse = 'Y'
		AND C.Document_Type    like 'REC'



			------PULL ACTIVE HOA LIEN RECORDS-----IF multiple records per lien due to owners - pull only 1 owner per NH 20180322---
	 TRUNCATE TABLE  dbo.HOA_NOD_NOS

	 Insert into [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[NOD_NOS_Recorded_Document_Number],
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],C.[INPUT Property ID] ,NULL
	 --into dbo.HOA_NOD_NOS
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	 --on A.NEW_REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUT Unique RecordID
	 join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as C on B.RAW_ID = C.[INPUT Property ID]
	 join  [zCust_WesternAlliance].[dbo].[w_DM_Data] as D on A.REF_ID = D.Property_ID   

	 -------20191114 - Added to use new doc type lookup table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as E with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(E.DocType))
	
	 where B.REF_ID is not null
	 AND  E.HOA_Data_Type like 'NOD/NOS/REO'
	 AND 
	 (convert(DATE,convert(varchar(10),A.NOD_NOS_Recording_Date)) > convert(date,D.[Date_Transfer]) OR
	  D.[Date_Transfer] is null)
	 --and 
	 --AND OWNSequence = 1
	 and 
	 --(convert(DATE,convert(varchar(10),A.RecordingDate)) >= convert(date,C.CurrSaleRecordingDate)
	 --OR C.CurrSaleRecordingDate is null)
	 (convert(DATE,convert(varchar(10),A.NOD_NOS_Recording_Date)) > convert(date,C.[MAX_NODDATE])
	 OR C.[MAX_NODDATE] is null)
	 and A.NOD_NOS_Recording_Date is not null
	 and A.[IsHoaLienActive] = 1


	 ------------------Added 20180912 to pull from LIEN fields as NOD/NOS fields are not consistently populated in HOA Lien table......--------

	  Insert into [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select  A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment]
,convert(date,convert(varchar(10),A.[RecordingDate]))
,A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[DocumentId],
A.[LienAmount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],C.[INPUT Property ID] ,NULL
--	Select A.REF_ID, A.DocumentID, convert(date,convert(varchar(10),A.[RecordingDate]))
--,A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[DocumentId],D.[Date_Transfer], A.[RecordingDate], C.[MAX_NODDATE]
	 --into dbo.HOA_NOD_NOS
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	 --on A.NEW_REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUT Unique RecordID
	 join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as C on B.RAW_ID = C.[INPUT Property ID]
	 join  [zCust_WesternAlliance].[dbo].[w_DM_Data] as D on A.REF_ID = D.Property_ID  

	  -------20191114 - Added to use new doc type lookup table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as E with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(E.DocType))
	
	 where B.REF_ID is not null
	  AND  E.HOA_Data_Type like 'NOD/NOS/REO'
	 AND 
	 (convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,convert(datetime,D.[Date_Transfer])-183) OR
	  D.[Date_Transfer] is null)
	 And (convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,C.[MAX_NODDATE])
	 OR C.[MAX_NODDATE] is null)
	 and A.[RecordingDate] is not null
	  and A.[IsHoaLienActive] = 1






	  ------------------------------20180917 - Added to exclude NOD/NOS's that have been released--------------------
	  Delete from [zCust_WesternAlliance].[dbo].[A]
	  --Select A.[INPUT Property ID], A.DocumentID, A.REcordingdate, A.DocType,C.Released, C.ReleaseDocNumber, C.FATimestamp , C.NMD_document_number_Raw
	  From [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] as A join 
	  [Assr].[dbo].[Assr] as B with (NOLOCK) on A.REF_ID = B.REF_ID
	  join [data].[dbo].[HOA_Lien_Default_Sup] as C with(NOLOCK) on B.LIC_PropertyID = C.LIC_PropertyID
	  where Right(Fmt_NMD_document_number,4) = Right(DocumentID,4)
	  and C.Released = 'Y'



	  Delete from [zCust_WesternAlliance].[dbo].[A]
		--Select A.[INPUT Property ID], A.DocumentID, A.REcordingdate, A.DocType,C.DocumentID, C.DocType, C.REcordingDate,C.OAReference
		--,C.OAReferenceAlt
	  From [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] as A  
	  join [HOA].[dbo].[HOA_Lien] as C with(NOLOCK) on A.REF_ID = C.REF_ID
	  where 
	  (Right(LTRIM(RTRIM(A.DocumentID)),4) = Right(LTRIM(RTRIM(C.OAReference)),4)
	  OR
	  Right(LTRIM(RTRIM(A.DocumentID)),4) = Right(LTRIM(RTRIM(C.OAReferenceAlt)),4)
	  )
	   -------20191114 - Added to use new doc type lookup table---
	   and C.DocType in ( Select DocType From [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]
	   where 
	   ((HOA_Data_Type like 'NOD/NOS/REO/Release' or HOA_Data_Type like 'Partial Release') 
		or HOA_Data_Type like 'release'))
		




	  UPDATE [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_WesternAlliance].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,[INPUTKEY] ORDER BY NOD_NOS_Recording_Date DESC)  AS RowNum
			FROM 
		[zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] t  ) r ON t.REF_ID = r.REF_ID and t.[ID] = r.[ID] and t.[INPUTKEY] = r.[INPUTKEY]


		-----************************************************************************************************************

		
	
		---- GET NOD/NOS from HOA_LIEN

		INSERT INTO [zCust_WesternAlliance].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKEY],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
		,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		SELECT distinct a.FIPS,a.REF_ID,b.[INPUTKEY]
		,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
		,convert(varchar(8),a.RecordingDate,112),UPPER(DocumentTypeDesc),Value,HOAName,MAName,LawName,LawPhone,HOA_Auction_Date,ltrim(rtrim(OrigTransRecDate)),ltrim(rtrim(OrigTransDocNumber)),0
		 --Select * 
		 --,OWNLASTNAME,BuyerBorrower
		 FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[HOA_LIEN_DATA] b
		ON a.REF_ID = b.REF_ID 
		WHERE toUSE = 'Y' and a.OrigTransRecDate = convert(varchar(10),convert(datetime,convert(varchar(8),b.RecordingDate)),120)
		--and b.Released like '' and a.Released is null 
		--and a.REF_ID not in(Select Match_REF_ID from HOA_NOD)

		AND A.BuyerBorrower like '%' + B.OWNLastName + '%'
		AND B.OWNLastName is not null AND B.OWNLastName not like ''

		
		
		INSERT INTO [zCust_WesternAlliance].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKEY],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
		,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr]
		--,[SUP]
		)
		
		SELECT distinct B.FIPS,B.REF_ID,B.[INPUTKEY]
		,CASE WHEN B.[DocumentID] is null then 
		case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		WHEN B.[DocumentID] is NOT null then 
		case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		END
		,convert(varchar(8),B.NOD_NOS_Recording_Date,112)
		--,UPPER(DocumentTypeDesc)
		,UPPER(LTRIM(RTRIM(REPLACE(D.Full_Name,char(160),''))))
		-----20180720 - Per Bill - Lien Amount is Default Sup table is Default Amount---
		,LienAmount--,Value
		,HOAName,MAName,LawName,LawPhone,HOA_Auction_Date
		,NULL--,ltrim(rtrim(OrigTransRecDate))
		,NULL--,ltrim(rtrim(OrigTransDocNumber))
		,0
		--,[SUP]
		 --Select * 
		 --,C.InputBorrowerName,B.OWNLastName,C.OwnerStdName1Full
		 FROM [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] b
		 join [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705] as D
		 on B.DocType = D.[HOA_Doc_Type]
		 join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as C on B.[INPUTKEY] = C.[INPUT Property ID]
		
		 where 
		 (D.HOA_Data_Type   in ('NDF','NOD/NOS/REO/Release','Partial Release','PRL','REL','REQ','SBT','SLE')
		 OR 
		 (
			D.Full_Name like  '%notice%' 
			--OR
			--Full_Name like '%Release%' OR
			--Full_Name like '%Rescission%' OR
			--Full_Name like '%Cancella%' 
			))
		--AND (case when C.InputBorrowerName is null or C.InputBorrowerName like '' then C.OwnerStdName1Full else C.InputBorrowerName end) like '%' + B.OWNLastName + '%'
		--AND B.OWNLastName is not null AND B.OWNLastName not like ''
	
		
		
			INSERT INTO [zCust_WesternAlliance].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKEY],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
		,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		
		SELECT distinct B.FIPS,B.REF_ID,B.[INPUTKEY]
		,CASE WHEN B.[DocumentID] is null then 
		case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		WHEN B.[DocumentID] is NOT null then 
		case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		END
		,convert(varchar(8),B.NOD_NOS_Recording_Date,112)
		,UPPER(LTRIM(RTRIM(REPLACE(D.Full_Name,char(160),''))))
		,B.LienAmount--,Value
		,B.HOAName,B.MAName,B.LawName,B.LawPhone,HOA_Auction_Date
		,NULL--,ltrim(rtrim(OrigTransRecDate))
		,NULL--,ltrim(rtrim(OrigTransDocNumber))
		,0
		 FROM [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS] b
		-----Changed 20191114 to use new doc type table---
		 left outer join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
		 on B.DocType = D.DocType
		 Left outer join [zCust_WesternAlliance].[dbo].[HOA_NOD] as H on 
		B.[INPUTKEY] = H.[INPUTKEY] AND 
		B.RecordingDate = H.RecordingDate AND 
		Right((CASE WHEN B.[DocumentID] is null then 
		case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		WHEN B.[DocumentID] is NOT null then 
		case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		END),4) = Right(H.DocumentID,4)
			
		 where H.DocumentID is null AND 
		 D.HOA_Data_Type in ('NOD/NOS/REO')
		 And B.REF_ID not like '196878235'
		 AND B.DocumentId not in ('2019.12.23.2167','2020.1.3.902','2019.12.27.1324','2019.12.10.1971')
		AND B.IsHoaLienActive = 1
			  
	


		---- GET NOD/NOS from TRANSHIST

	
	
		INSERT INTO [zCust_WesternAlliance].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKEY],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
			,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		SELECT distinct a.FIPS,a.REF_ID,a.Raw_ID as RAW_ID
			,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
			,convert(varchar(8),a.RecordingDate,112)
			,UPPER(DocumentTypeDesc),isNULL(Value,0),NULL as HOAName,NULL as MAName,NULL as LawName,Null as LawPhone,Auction_Date,ltrim(rtrim(OrigTransRecDate)),ltrim(rtrim(OrigTransDocNumber)),0
		FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_Preforeclosure] b
		ON a.REF_ID = b.REF_ID and a.RecordingDate = b.Recording_Date
		join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as C on A.RAW_ID = C.[INPUT Property ID]
			WHERE toUSE = 'Y' and ([Lis_Pendens_Type] = 2 or [Trustee_Attorney_Plaintiff_Full1] like '%HOA%' or [Trustee_Attorney_Plaintiff_Full1] like '%HOMEO%') and Doc_Src_Ind = 'R' 
		--and Released is null
				and (DocumentTypeDesc like '%NOTICE%' --or DocumentTypeDesc Like 'Release'
				)
		--AND (Case when C.INPUTBORROWERNAME is not null and C.INPUTBORROWERNAME not like '' then C.INPUTBORROWERNAME else C.OWNERSTDNAME1FULL end) like '%' + left(A.BuyerBorrower,4) + '%'
		--AND A.BuyerBorrower is not null and A.BuyerBorrower not like ''


	  Delete from [zCust_WesternAlliance].[dbo].[A]
	  --Select B.[INPUT Property ID], A.RecordingDate, A.DocumentID--, B.MAX_NODDATE
	  From  [zCust_WesternAlliance].[dbo].[HOA_NOD] as A join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as B on A.[INPUTKEY] = B.[INPUT Property ID]
	  where convert(Date,B.MAX_NODDATE) >= convert(Date,A.RecordingDate)
	  --where convert(Date,B.[INPUT START DATE]) >= convert(Date,A.RecordingDate)


	  ---------20200922 - Per EC - Add code to not return any NOD/NOS that are > 10 years old - if there is not an open HOA Lien!!!

	  
	  Delete from [zCust_WesternAlliance].[dbo].[A]
	  --Select A.[INPUT Property ID], A.RecordingDate, A.DocumentID, B.MAX_NODDATE,[Number of HOA Liens]
	  From  [zCust_WesternAlliance].[dbo].[HOA_NOD] as A join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] as B on A.[INPUTKEY] = B.[INPUT Property ID]
	  where  convert(Date,A.RecordingDate) < convert(date,Getdate()-3650)
	  and [Number of HOA Liens] = 0


	  --Select * From HOA_NOD

	  Delete from [zCust_WesternAlliance].[dbo].[HOA_NOD]
	  where Document_Title_Text = 'NOTICE OF HOMEOWNERS ASSOCIATION'

			Update [zCust_WesternAlliance].[dbo].[HOA_NOD]
			Set ROwNbr = 0

		
			UPDATE [zCust_WesternAlliance].[dbo].[t] SET ROwNbr = RowNum
			FROM [zCust_WesternAlliance].[dbo].[HOA_NOD] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY],MATCH_REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_WesternAlliance].[dbo].[HOA_NOD] t ) r ON t.MATCH_REF_ID = r.MATCH_REF_ID AND t.DocumentID = r.DocumentID
			and t.[INPUTKEY] = r.[INPUTKEY]

		Select * From [zCust_WesternAlliance].[dbo].[HOA_NOD]
	

			---------------------BUILD DOWN----------


		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordNbr] [int]NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordingDate] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordedDocumentNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_DocType] [varchar](250) NULL')

		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_DefaultAmount] [varchar](250) NULL')
										
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_TrusteeAttorneyName] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_TrusteeAttorneyPhoneNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_AuctionDate] [varchar](250) NULL')

		--EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_OrigRecDate] [varchar](250) NULL')
		--EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_OrigDocNbr] [varchar](250) NULL')
		
		--------------Added 20190329 to track SUP records--------
		--EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_SUP] [varchar](1) NULL')


		/****** Object:  Index [NonClusteredIndex-20180712-100727]    Script Date: 8/31/2018 6:54:05 PM ******/
		CREATE UNIQUE NONCLUSTERED INDEX [NonClusteredIndex-NOD] ON [dbo].[x_Custom_OUTPUT_S33]
		(
			[NOD_NOS_RecordedDocumentNumber] ASC,
			[NOD_NOS_RecordingDate] ASC,
			[INPUT Property ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	

		Truncate table NOD_NOS_RELEASE_COMBINED

		
		Insert into [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED]([INPUTKEY],[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr]
	   --,[SUP]
	   )
	   Select A.[INPUT Property ID],NULL,convert(date,B.REcordingDate) as NOD_NOS_RecordingDate,B.DocumentID as NOD_NOS_RecordedDocumentNumber
		,B.Document_Title_Text as NOD_NOS_DocType
		, B.LienAmount as NOD_NOS_DefaultAmount
		, B.LawName as HOA_TrusteeAttorneyName
		,B.LawPhone as HOA_TrusteeAttorneyPhoneNumber
		,B.Auction_Date as HOA_AuctionDate
		,B.OrigRecDate as NOD_NOS_OrigRecDate
		,B.OrigDocNbr as NOD_NOS_OrigDocNbr
		--,B.[SUP]
		--,A.Work_REF_ID
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] A JOIN [zCust_WesternAlliance].[dbo].[HOA_NOD] as B 
		on A.[INPUT Property ID] = B.[INPUTKEY]


	

		
		UPdate [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Set [NbrofRecordings_NOD_NOS] = NULL
		
		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET a.[NbrofRecordings_NOD_NOS] = b.[NbrofRecordings_NOD_NOS]
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN (SELECT [INPUTKEY],count(*)  as [NbrofRecordings_NOD_NOS] FROM [zCust_WesternAlliance].[dbo].[HOA_NOD] 
		GROUP BY [INPUTKEY]) b
		on A.[INPUT Property ID] = B.[INPUTKEY]


		

			Update [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS_RELEASE]
			Set REcordNumber = 0

		
			UPDATE [zCust_WesternAlliance].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS_RELEASE] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY],REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_WesternAlliance].[dbo].[HOA_NOD_NOS_RELEASE] t ) r ON t.REF_ID = r.REF_ID AND (t.NOD_NOS_Recorded_Document_Number = r.NOD_NOS_Recorded_Document_Number 
			OR t.DocumentId = R.DocumentId)
			and t.[INPUTKEY] = r.[INPUTKEY]



		------------------------COMBINED NOD_NOS_RELEASE-----------
		Insert into [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED]([INPUTKEY],[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr]
	   --,[SUP]
	   )

	   Select 	distinct A.[INPUT Property ID],NULL,
	   convert(date,convert(varchar(10),B.REcordingDate,126))
		, B.NOD_NOS_Recorded_Document_Number
		,D.Full_Name
		, B.LienAmount
		, B.LawName
		, B.LawPhone
		,NULL
		,NULL
		,NULL
		--Select B.* 	
		--,[SUP]						
		FROM  [zCust_WesternAlliance].[dbo].[HOA_NOD_NOS_RELEASE] as B 
		join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] A 
		on A.[INPUT Property ID] = B.[INPUTKEY]
		join [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705] as D
		on B.DocType = D.[HOA_Doc_Type]
		



			Update [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED]
			Set REcordNumber = 0

		
			UPDATE [zCust_WesternAlliance].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUTKEY] ORDER BY [NOD_NOS_RecordingDate] DESC) AS RowNum
				FROM 
			[zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] t ) r ON t.[INPUTKEY] = r.[INPUTKEY] AND (t.[NOD_NOS_RecordedDocumentNumber] = r.[NOD_NOS_RecordedDocumentNumber])
			and t.[INPUTKEY] = r.[INPUTKEY]


			Update [zCust_WesternAlliance].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.[INPUT Property ID],A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_WesternAlliance].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			(A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Inst_Nbr OR 
			A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Book_Page 
			)
			where 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null


			
			Update [zCust_WesternAlliance].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.[INPUT Property ID],A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_WesternAlliance].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			A.NOD_NOS_RecordedDocumentNumber =
			left(Fmt_Inst_Nbr,len(Fmt_Inst_Nbr)-charindex('.',REVERSE(Fmt_Inst_Nbr))) + '.' 
			+ SUBSTRING(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1), PATINDEX('%[^0]%', Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)+'.'), LEN(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)))
			where A.NOD_NOS_RecordedDocumentNumber like '%.%.%'
			AND Fmt_Inst_Nbr like '%.%.%'
			AND 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null





		----------------20181004 - KL - Per NH - populate NOD/NOS fields first - then build down with what is left-------


		---********************Uncomment & RUN!!!!!!!!*********************************
		Update [zCust_WesternAlliance].[dbo].[A]
		Set 
		A.NOD_NOS_RecordNbr = B.REcordNumber
		,A.NOD_NOS_RecordingDate = B.NOD_NOS_RecordingDate
		,A.NOD_NOS_RecordedDocumentNumber = B.NOD_NOS_RecordedDocumentNumber
		,A.NOD_NOS_DocType = B.NOD_NOS_DocType
		,A.NOD_NOS_DefaultAmount = B.NOD_NOS_DefaultAmount
		,A.HOA_TrusteeAttorneyName = B.HOA_TrusteeAttorneyName
		,A.HOA_TrusteeAttorneyPhoneNumber = B.HOA_TrusteeAttorneyPhoneNumber
		,A.HOA_AuctionDate = B.HOA_AuctionDate
		--,A.NOD_NOS_OrigRecDate = B.NOD_NOS_OrigRecDate
		--,A.NOD_NOS_OrigDocNbr =  B.NOD_NOS_OrigDocNbr
		------------Added 20190329 to track SUP records----
		--,A.NOD_NOS_SUP = B.SUP
		--Select * 																	
		FROM  [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] as B 
		join [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] A 
		on A.[INPUT Property ID] = B.[INPUTKEY]
		WHERE B.REcordNumber = 1
		And A.NOD_NOS_RecordNbr is null
		

	


		UPdate [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Set [NbrofRecordings] = 0
		
		UPDATE [zCust_WesternAlliance].[dbo].[a]
		SET a.[NbrofRecordings] = b.NbrOfRecordings
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN (SELECT [INPUTKEY],count(*)  as NbrOfRecordings FROM [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED] 
		GROUP BY [INPUTKEY]) b
		on A.[INPUT Property ID] = B.[INPUTKEY]


		--Select MAX(convert(int,[NbrofRecordings_RELEASED])) FROM x_Custom_OUTPUT_S33
		--Select MAX(convert(int,NOD_NOS_RELEASE_COMBINED)) FROM x_Custom_OUTPUT_S33
		Select MAX(convert(int,[NbrofRecordings])) FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Select MAX(convert(int,[Number of HOA Liens])) FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]

		--Select FIPS,[INPUT Property ID], NbrofRecordings, NbrofRecordings_NOD_NOS, NOD_NOS_RecordNbr From x_Custom_OUTPUT_S33
		--order by convert(int,[NbrofRecordings]) desc


		----------------------------------------BUILD DOWN    COMBINED-----NOD_NOS_RELEASES PER NH 20181004------------------------------------
		IF (Select max(convert(int,RecordNumber)) from [zCust_WesternAlliance].[dbo].[NOD_NOS_RELEASE_COMBINED]) > 1
		BEGIN
		
		Truncate table dbo.RELEASE_BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_WesternAlliance].[dbo].[RELEASE_BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_WesternAlliance].[sys].[tables] as A join [zCust_WesternAlliance].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_Custom_OUTPUT_S33'
			and B.Name not in ('NOD_NOS_RecordNbr','NOD_NOS_RecordingDate ','NOD_NOS_RecordedDocumentNumber','NOD_NOS_DocType','NOD_NOS_DefaultAmount'
			,'HOA_TrusteeAttorneyName','HOA_TrusteeAttorneyPhoneNumber','HOA_AuctionDate'
			--,'NOD_NOS_OrigRecDate','NOD_NOS_OrigDocNbr'
			,'NOD_NOS_SUP')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.RELEASE_BUILD_DOWN_COLUMNS


		--If (Select MAX(convert(int,NbrofRecordings_RELEASED)) FROM x_Custom_OUTPUT_S33) > 0
		--BEGIN

		

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_WesternAlliance].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_WesternAlliance].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[NbrofRecordings])) FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_Custom_OUTPUT_S33(
												' +  @FIELDLIST3 + '

												  ,[NOD_NOS_RecordNbr]
												  ,[NOD_NOS_RecordingDate]
												  ,[NOD_NOS_RecordedDocumentNumber]
												  ,[NOD_NOS_DocType]
												  ,[NOD_NOS_DefaultAmount]
												  ,[HOA_TrusteeAttorneyName]
												  ,[HOA_TrusteeAttorneyPhoneNumber]
												  ,[HOA_AuctionDate]
												  --,[NOD_NOS_OrigRecDate]
												  --,[NOD_NOS_OrigDocNbr]
												  --,[NOD_NOS_SUP]
												  )
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												 ,B.REcordNumber
												  ,B.[NOD_NOS_RecordingDate]
												  ,B.[NOD_NOS_RecordedDocumentNumber]
												  ,B.[NOD_NOS_DocType]
												  ,B.[NOD_NOS_DefaultAmount]
												  ,B.[HOA_TrusteeAttorneyName]
												  ,B.[HOA_TrusteeAttorneyPhoneNumber]
												  ,B.[HOA_AuctionDate]
												  --,B.[NOD_NOS_OrigRecDate]
												  --,B.[NOD_NOS_OrigDocNbr]
												  --,B.[SUP]
										--Select B.* 	
										
										FROM  NOD_NOS_RELEASE_COMBINED as B 
										join x_Custom_OUTPUT_S33 A 
										on A.[INPUT Property ID] = B.[INPUTkey]
										WHERE 
										B.REcordNumber = ''' + @BeginNbrOfTrans6 + '''
										')
										

												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			
		--Select * From x_Custom_OUTPUT_S33
		--where NbrofRecordings > 0
		--Order by NOD_NOS_RecordNbr desc,INPUT Unique RecordID


		--Select count(*) FRom a_ASP_IN_STD

		

		Update  [zCust_WesternAlliance].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Property ID] = b.Raw_ID


		
	

		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		SET [Property Status] = CASE WHEN WORK_REF_ID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_WesternAlliance].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		--Select * 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] a join [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] b
		on a.[INPUT Property ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M' and a.Work_REF_ID is null

			

		UPDATE [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] 
		Set  [Event Status] = NULL

		


		--------------------Changed to ONLY return Event Found when HOA Lien, NOD/NOS, REscission/Release found per NH 20190125----
		UPDATE [zCust_WesternAlliance].[dbo].[A] 
		Set  A.[Event Status] = case when [Number of HOA Liens] > 0 OR NbrOfRecordings > 0
		or NbrofRecordings_RELEASED > 0
		then 'Event Found' ELSE 'Event Not Found' END
		--Select A.[INPUT Property ID] ,A.[HAS_HOA_RECORD],B.[HOA_FOUND]
		From   [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		as A 

		
						


		-----------------------UNCOMMENT & RUN to FIND MAX RECORD DATE-----------------
		IF  EXISTS (SELECT * FROM [zCust_WesternAlliance].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[FIND_MAX_RECORD]') AND type in (N'U'))
		DROP TABLE [dbo].[FIND_MAX_RECORD]

		IF(Select count(*) From  [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		where [Number of HOA Liens] > 0) > 0 
		BEGIN

		EXEC('Select A.* into [dbo].[FIND_MAX_RECORD]
		From 
		(
		Select [INPUT Property ID], WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT_S33
		where [Number of HOA Liens] > 0
		
		UNION ALL
		
		Select [INPUT Property ID], WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT_S33
		where NbrOfRecordings > 0
		)A

		join 
		(Select [INPUT Property ID],WORK_REF_ID,max(RECORD_DATE) as MAXDATE FROM (
		Select [INPUT Property ID], WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT_S33
		where [Number of HOA Liens] > 0
		
		UNION ALL
		
		Select [INPUT Property ID], WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT_S33
		where NbrOfRecordings > 0
		)A
		Group by [INPUT Property ID],WORK_REF_ID) B  
		on A.[INPUT Property ID] = B.[INPUT Property ID]
		and A.RECORD_DATE = B.MAXDATE

		


		Select DoCType, count(*) From [FIND_MAX_RECORD]
		Group by DocType

		')


		END

	
		
		--DECLARE @FIELDNAME varchar(200)
		--DECLARE CLEAN_cursor CURSOR FOR  
		--Select '[' + NAME + ']' From sys.columns
		--where Object_ID = 
		--(Select OBJECT_ID FROM sys.tables
		--where NAME = 'x_Custom_OUTPUT_S33')
		--and 
		--(NAME like '%DocType%' )
		--order by NAME

		--	OPEN CLEAN_cursor   
		--	FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME

		--	WHILE @@FETCH_STATUS = 0   
		--		BEGIN   
		--				EXEC('
		--				Select ' + @FIELDNAME + ', count(*) as TOTAL from  [x_Custom_OUTPUT_S33]
		--				Group by ' + @FIELDNAME + ' 
		--				')
			

		--			FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME   
		--		END   

		--CLOSE CLEAN_cursor   
		--DEALLOCATE CLEAN_cursor
		  



		UPDATE [zCust_WesternAlliance].[dbo].[A]
		Set A.HAS_HOA_RECORD = 'Y'
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]  as A 
		join [zCust_WesternAlliance].[dbo].[LIEN_TRACKING_HIST] as B on 
		A.[INPUT Property ID] = B.[INPUTKEY]
		where A.HAS_HOA_RECORD is null or A.HAS_HOA_RECORD like ''


		
		Select [Address Standardization], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [Address Standardization]
	

		Select [Event Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [Event Status]

		Select [Property Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [Property Status]

		Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		where [Event Status] like 'Event Found' and [Property Status] in ('Property Not Found','Multiple Properties Found')




		Select [Event Status], count(*) from (
		Select [INPUT Property ID],[Event Status], count(*) as TOTAL From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [INPUT Property ID],[Event Status])A
		Group  by [Event Status]

		--Select [CoverageStatus_PREFC], count(*) From x_Custom_OUTPUT_S33
		--Group by [CoverageStatus_PREFC]

		Select [CoverageStatus_HOA_LIEN], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [CoverageStatus_HOA_LIEN]

		Select count(*) From  [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		where [CoverageStatus_HOA_LIEN] = 'Y'
		and [HAS_HOA_RECORD] = 'Y'
		
		--Select [AddressMatch], count(*) From x_Custom_OUTPUT_S33
		--Group by [AddressMatch]

		Select [HAS_HOA_RECORD], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
		Group by [HAS_HOA_RECORD]

		--Select [Prioritization], count(*) From x_Custom_OUTPUT_S33
		--Group by [Prioritization]



	 
	 Select top 10000 [INPUT Property ID], WORK_REF_ID, PropertyID, [Number of HOA Liens], NbrofRecordings, [Event Status]
	 ,NbrofRecordings_NOD_NOS, *
	 From  [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33] A
	 Order by convert(int,A.[Number of HOA Liens]) desc, convert(int,A.[NbrofRecordings]) desc, A.[INPUT Property ID]

	

	Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S33]
	Order by [NbrofRecordings]desc,	[Number of HOA Liens] desc


END



