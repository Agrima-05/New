SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_StateBankIndia_CA].[dbo].[usp_300_Start_Output_StateBankofIndia_CA_S28]

AS
BEGIN
	
	SET NOCOUNT ON;

	

		DROP TABLE [dbo].[x_custom_OUTPUT_S28]

		CREATE TABLE [dbo].[x_custom_OUTPUT_S28](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
		[INPUT Unique ID][varchar](250)NULL,
		[INPUT Address][varchar](250)NULL,
		[INPUT City][varchar](250)NULL,
		[INPUT State][varchar](250)NULL,
		[INPUT Zip][varchar](250)NULL,
		[Property Address][varchar](250)NULL,
		[City][varchar](250)NULL,
		[State][varchar](250)NULL,
		[Zip Code][varchar](250)NULL,
		[Run Date][varchar](250)NULL,
		[Address Standardization][varchar](250)NULL,
		[INVL Coverage Status][varchar](250)NULL,
		[INVL Thru Date][varchar](250)NULL,
		[Property Status][varchar](250)NULL,
		[Event Status ][varchar](250)NULL,
		[Current Owner 1][varchar](250)NULL,
		[Current Owner 2][varchar](250)NULL,
		[Ownership Change Date][varchar](250)NULL,
		[Current Owner Doc Type][varchar](250)NULL,
		[Input Start Date][varchar](250)NULL,
		[Nbr of Recordings][varchar](250)NULL,
		[Record_Number] [varchar](250) NULL,
		[Recording_Date] [varchar](250) NULL,
		[Document_Date] [varchar](250) NULL,
		[Document_Filing_Date] [varchar](250) NULL,
		[Document_Number_Source] [varchar](250) NULL,
		[Book_Source] [varchar](250) NULL,
		[Page_Source] [varchar](250) NULL,
		[Document_Category] [varchar](250) NULL,
		[Document_Type] [varchar](250) NULL,
		[DocumentTitle] [varchar](250) NULL,
		[Federal_Tax_Lien_Area] [varchar](250) NULL,
		[Federal_Tax_Lien_Area_Phone] [varchar](250) NULL,
		[Tax_Last_Day_for_Refiling] [varchar](250) NULL,
		[Tax_Period_Begin_Date] [varchar](250) NULL,
		[Tax_Period_End_Date] [varchar](250) NULL,
		[Tax_Amount] [varchar](250) NULL,
		[Tax_Interest_Amount] [varchar](250) NULL,
		[Tax_Penalty_Amount] [varchar](250) NULL,
		[Judgment_Amount] [varchar](250) NULL,
		[Lien_Number] [varchar](250) NULL,
		[Map_Plat_ID] [varchar](250) NULL,
		[Mechanics_Lien_Number] [varchar](250) NULL,
		[Ordinance_Number] [varchar](250) NULL,
		[Patent_Number] [varchar](250) NULL,
		[Permit_Number] [varchar](250) NULL,
		[Resolution_Number] [varchar](250) NULL,
		[Tax_Account_Serial_Warrant_Number] [varchar](250) NULL,
		[Tax_Type] [varchar](250) NULL,
		[Trustees_Sale_Number] [varchar](250) NULL,
		[UCC_Number] [varchar](250) NULL,
		[Undersigned_Same_as_Borrower] [varchar](250) NULL,
		[Amount_Due] [varchar](250) NULL,
		[Amount_of_Default] [varchar](250) NULL,
		[Bond_Amount] [varchar](250) NULL,
		[Cash_Down_Amount] [varchar](250) NULL,
		[Contract_Amount] [varchar](250) NULL,
		[Collection_Costs] [varchar](250) NULL,
		[Unpaid_Balance] [varchar](250) NULL,
		[Unpaid_Balance_as_of_Modification_Date] [varchar](250) NULL,
		[Unpaid_Principal_Amount] [varchar](250) NULL,
		[Party1_Name1_FullName] [varchar](250) NULL,
		[Party1_Name1_last_Company_Name] [varchar](250) NULL,
		[Party1_Name1_First_Name] [varchar](250) NULL,
		[Party1_Name1_Middle_Name] [varchar](250) NULL,
		[Party1_Name1_Suffix] [varchar](250) NULL,
		[Party1_Name1_Role_Type] [varchar](250) NULL,
		[Party1_Name1_MailPropertyID] [varchar](250) NULL,
		[Party1_Name1_Address] [varchar](250) NULL,
		[Party1_Name1_PreDir] [varchar](250) NULL,
		[Party1_Name1_StreetNumber] [varchar](250) NULL,
		[Party1_Name1_StreetName] [varchar](250) NULL,
		[Party1_Name1_PostDir] [varchar](250) NULL,
		[Party1_Name1_StreetType] [varchar](250) NULL,
		[Party1_Name1_SuiteType] [varchar](250) NULL,
		[Party1_Name1_Suite] [varchar](250) NULL,
		[Party1_Name1_City] [varchar](250) NULL,
		[Party1_Name1_State] [varchar](250) NULL,
		[Party1_Name1_Zip] [varchar](250) NULL,
		[Party1_Name1_ZipPlus4] [varchar](250) NULL,
		[Party1_Name2_FullName] [varchar](250) NULL,
		[Party1_Name2_last_Company_Name] [varchar](250) NULL,
		[Party1_Name2_First_Name] [varchar](250) NULL,
		[Party1_Name2_Middle_Name] [varchar](250) NULL,
		[Party1_Name2_Suffix] [varchar](250) NULL,
		[Party1_Name2_Role_Type] [varchar](250) NULL,
		[Party1_Name2_MailPropertyID] [varchar](250) NULL,
		[Party1_Name2_Address] [varchar](250) NULL,
		[Party1_Name2_PreDir] [varchar](250) NULL,
		[Party1_Name2_StreetNumber] [varchar](250) NULL,
		[Party1_Name2_StreetName] [varchar](250) NULL,
		[Party1_Name2_PostDir] [varchar](250) NULL,
		[Party1_Name2_StreetType] [varchar](250) NULL,
		[Party1_Name2_SuiteType] [varchar](250) NULL,
		[Party1_Name2_Suite] [varchar](250) NULL,
		[Party1_Name2_City] [varchar](250) NULL,
		[Party1_Name2_State] [varchar](250) NULL,
		[Party1_Name2_Zip] [varchar](250) NULL,
		[Party1_Name2_ZipPlus4] [varchar](250) NULL,
		[Party2_Name1_FullName] [varchar](250) NULL,
		[Party2_Name1_last_Company_Name] [varchar](250) NULL,
		[Party2_Name1_First_Name] [varchar](250) NULL,
		[Party2_Name1_Middle_Name] [varchar](250) NULL,
		[Party2_Name1_Suffix] [varchar](250) NULL,
		[Party2_Name1_Role_Type] [varchar](250) NULL,
		[Party2_Name1_MailPropertyID] [varchar](250) NULL,
		[Party2_Name1_Address] [varchar](250) NULL,
		[Party2_Name1_PreDir] [varchar](250) NULL,
		[Party2_Name1_StreetNumber] [varchar](250) NULL,
		[Party2_Name1_StreetName] [varchar](250) NULL,
		[Party2_Name1_PostDir] [varchar](250) NULL,
		[Party2_Name1_StreetType] [varchar](250) NULL,
		[Party2_Name1_SuiteType] [varchar](250) NULL,
		[Party2_Name1_Suite] [varchar](250) NULL,
		[Party2_Name1_City] [varchar](250) NULL,
		[Party2_Name1_State] [varchar](250) NULL,
		[Party2_Name1_Zip] [varchar](250) NULL,
		[Party2_Name1_ZipPlus4] [varchar](250) NULL,
		[Party2_Name2_FullName] [varchar](250) NULL,
		[Party2_Name2_last_Company_Name] [varchar](250) NULL,
		[Party2_Name2_First_Name] [varchar](250) NULL,
		[Party2_Name2_Middle_Name] [varchar](250) NULL,
		[Party2_Name2_Suffix] [varchar](250) NULL,
		[Party2_Name2_Role_Type] [varchar](250) NULL,
		[Party2_Name2_MailPropertyID] [varchar](250) NULL,
		[Party2_Name2_Address] [varchar](250) NULL,
		[Party2_Name2_PreDir] [varchar](250) NULL,
		[Party2_Name2_StreetNumber] [varchar](250) NULL,
		[Party2_Name2_StreetName] [varchar](250) NULL,
		[Party2_Name2_PostDir] [varchar](250) NULL,
		[Party2_Name2_StreetType] [varchar](250) NULL,
		[Party2_Name2_SuiteType] [varchar](250) NULL,
		[Party2_Name2_Suite] [varchar](250) NULL,
		[Party2_Name2_City] [varchar](250) NULL,
		[Party2_Name2_State] [varchar](250) NULL,
		[Party2_Name2_Zip] [varchar](250) NULL,
		[Party2_Name2_ZipPlus4] [varchar](250) NULL,
		[InactiveFlag] [varchar](250) NULL,
		[Reference_recording_year] [varchar](250) NULL,
		[reference_recording_date] [varchar](250) NULL,
		[reference_doc_number] [varchar](250) NULL,
		[reference_book] [varchar](250) NULL,
		[reference_page] [varchar](250) NULL,
		[Fmt_Reference_Doc_Number] [varchar](250) NULL,
		[Fmt_Reference_BookPAge] [varchar](250) NULL,


			-----INTERNAL----
			[START DATE][varchar](250)NULL,
			[MAX_INVL_RECDATE][varchar](250)NULL

		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF

		  INSERT INTO [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] (  
		  [INPUT Unique ID],
		  [INPUT Address],
			[INPUT City],
			[INPUT State],
			[INPUT Zip],
			[Start Date] ,
			[Input Start Date],
			[MAX_INVL_RECDATE],
			FIPS,
			PROPERTYID)
	
			Select 
			INPUTKEY,
			ADDRESS,
			CITY,
			STATE,
			ZIPCODE,
			convert(Date,[Start Date]),
			convert(Date,[Start Date]),
			convert(Date,MAX_INVL_RECDATE),
			FIPS,
			PROPERTYID
			From [zCust_StateBankIndia_CA].[dbo].[INPUT_MONITOR]


		

		


		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--FROM x_custom_OUTPUT_S28 a JOIN 
		--a_PropMatch_Work_FLANK c on a.[INPUT Unique ID] = c.RAW_ID



		
		Update [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = Convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique ID] = c.RAW_ID







		Update [zCust_StateBankIndia_CA].[dbo].[a]
		set 
		A.[INVL Thru Date] = B.maxdate
		,A.[INVL Coverage Status] = case when B.FIPS is not null then 1 else 0 end
		--Select * 
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a 
			left outer JOIN (Select FIPS, Min(Recordingdt) as MinDate, Max(Recordingdt) as maxdate from [data].[dbo].[v_Invl] with(NOLOCK)
			where FIPS in (Select distinct FIPS from [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] where FIPS is not null and FIPS not like '' and FIPS not like '0')
			and recordingdt is not null and farecordtype not like 'D'
			Group by FIPS) B on 
			A.FIPS = B.FIPS

		

	UPDATE [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] 
	SET [INVL Thru Date] = ''
	WHERE [INVL Thru Date] = '1900-01-01'

	UPDATE [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] 
	SET [INVL Thru Date] = ''
	WHERE [INVL Thru Date] = '01/01/1900'

	UPDATE [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] 
	SET [INVL Thru Date] = CONVERT(varchar(10), convert(date,[INVL Thru Date],126), 101)
	WHERE [INVL Thru Date] not like ''


		
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
			FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID



				
		----Run this first in case FAOwnershipUpdateDt is null
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.CurrentSaleTransactionId = C.Transactionid
		where B.CurrentSaleTransactionId is not null
		and A.PROPERTYID is not null
		

		---Run this 2nd to pull most recent ownership change
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set 
		A.[Ownership Change Date] = convert(date,C.recordingdt)
		,A.[Current Owner Doc Type] = C.DocumentTypeCode
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on a.FIPS = b.FIPS 
		and A.PropertyID = B.PropertyID
		left outer join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		and B.FAOwnerTransactionId = C.Transactionid
		where B.FAOwnerTransactionId is not null
		and A.PROPERTYID is not null


		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set A.[Current Owner Doc Type] = B.CodeDesc
		--Select A.[Current Owner Doc Type] , B.CodeDesc
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a 
		JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		on A.[Current Owner Doc Type] = B.DocTypeID

	

	--------PULL INVL BULK---
	--Drop table dbo.INVL_BULK_PULL
	
	-----20240715 - 
	-----Per EC - 
	----1 - INVL Doc Categories to Monitor: ALN, BND, ELN, FLN, JDG, LEN, LID, MLN, NTE, SBT, SLN, TRU, UCC
	----2 - INVL Match will be from input address to all Main Property ID, Party 1 Name 1 & Name 2 Mail Address ID & Party 2 Name 1 Mailing Address IDs
	----3 - Pull ALL NON_INACTIVE INVL NOT USING THEIR INPUT DATE

	------20240805 - Per EC - Do NOT use their input date now
	-------20250909 - Per workorder - only return Doc Categories MLN, ABJ, JDG, LEN, FLN, SLN
	------For baseline we'll return ALL non-Inactive INVL recordings from Input Start Date - Current
	

		Truncate table dbo.INVL_BULK_PULL

		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]( [ROWNUM]
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		FROM     [Data].[dbo].[v_INVL] AS A WITH (NOLOCK) INNER JOIN
			[zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] AS B WITH (NOLOCK) ON A.PropertyID = B.PROPERTYID 
						
		WHERE  (B.PROPERTYID IS NOT NULL) AND (B.PROPERTYID NOT LIKE '') AND (B.PROPERTYID NOT LIKE '0') 
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		and A.recordingdt is not null 
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('MLN','ABJ','JDG','LEN','FLN','SLN')
		



		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      
      ,[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] as B with(NOLOCK) on A.Party1_Name1_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		and A.recordingdt is not null 
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('MLN','ABJ','JDG','LEN','FLN','SLN')

       


		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] as B with(NOLOCK) on A.Party1_Name2_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		and A.recordingdt is not null 
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('MLN','ABJ','JDG','LEN','FLN','SLN')


		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]( ROWNUM 
      ,[INPUT KEY]
      ,[TransactionID]
      ,[Fips]
      ,[State]
      ,[County]
      ,[DocumentYear]
      ,[Recordingdt]
      ,[DocumentDt]
      ,[doc_filing_date]
      ,[DocNbrSrce]
      ,[BookSrce]
      ,[PaceSrce]
      ,[Doc_Category]
      ,[DocTypeID]
      ,[DocType]
      ,[DocumentTitle]
      ,[case_number]
      ,[case_book]
      ,[case_page]
      ,[date_of_death]
      ,[account_number]
      ,[amendment_number]
      ,[attorney_bar_number]
      ,[bond_number]
      ,[lot_line_adjustment_number]
      ,[certificate_number]
      ,[claim_number]
      ,[contract_number]
      ,[corporation_number]
      ,[excise_tax_number]
      ,[federal_tax_lien_area]
      ,[federal_tax_lien_area_phone]
      ,[tax_last_day_for_refiling]
      ,[tax_period_begin_date]
      ,[tax_period_end_date]
      ,[tax_amount]
      ,[tax_interest_amount]
      ,[tax_penalty_amount]
      ,[judgment_amount]
      ,[judgment_grand_total]
      ,[judgment_court_fees]
      ,[judgment_attorney_fees]
      ,[judgment_principal_fees]
      ,[judgment_interest_fees]
      ,[judgment_filing_fees]
      ,[judgment_per_diem_fees]
      ,[judgment_late_fees]
      ,[judgment_tax_fees]
      ,[judgment_insurance_fees]
      ,[judgment_other_fees]
      ,[installment_judgment]
      ,[license_number]
      ,[lien_number]
      ,[map_plat_id]
      ,[mechanics_lien_number]
      ,[ordinance_number]
      ,[patent_number]
      ,[permit_number]
      ,[resolution_number]
      ,[tax_account_serial_warrant_number]
      ,[tax_type]
      ,[trustees_sale_number]
      ,[ucc_number]
      ,[undersigned_same_as_borrower]
      ,[amount_due]
      ,[amount_of_default]
      ,[bond_amount]
      ,[cash_down_amount]
      ,[contract_amount]
      ,[collection_costs]
      ,[unpaid_balance]
      ,[unpaid_balance_as_of_modification_date]
      ,[unpaid_prinicipal_amount]
      ,[date_of_divorce]
      ,[support_arrears_amount]
      ,[support_payment_amount]
      ,[support_total_amount]
      ,[date_amount_due]
      ,[date_stay_ordered]
      ,[bankruptcy_case_number]
      ,[bankruptcy_chapter]
      ,[bankruptcy_type]
      ,[bankruptcy_location]
      ,[case_filed_in_county]
      ,[case_court_type]
      ,[case_original_number]
      ,[case_original_court_type]
      ,[case_status]
      ,[date_bankruptcy_closed]
      ,[date_bankruptcy_case_filed]
      ,[date_bankruptcy_conversion]
      ,[date_bankruptcy_discharged]
      ,[date_bankruptcy_dismissed]
      ,[date_bankruptcy_341_meeting]
      ,[bankruptcy_341_meeting_time]
      ,[requested_prepared_by_attorney_name_identifier]
      ,[requested_prepared_by_attorney_last_company_name]
      ,[requested_prepared_by_attorney_first_name]
      ,[requested_prepared_by_attorney_middle_initial]
      ,[requested_prepared_by_attorney_suffix]
      ,[requested_prepared_by_attorney_address]
      ,[requested_prepared_by_attorney_address_city]
      ,[requested_prepared_by_attorney_address_state]
      ,[requested_prepared_by_attorney_address_zip]
      ,[requested_prepared_by_attorney_phone]
      ,[Party1_Name1_FullName]
      ,[Party1_Name1_last_Company_Name]
      ,[Party1_Name1_First_Name]
      ,[Party1_Name1_Middle_Name]
      ,[Party1_Name1_Suffix]
      ,[Party1_Name1_Roll_Type]
      ,[Party1_Name1_taxpayer_id_ssn_fein]
      ,[Party1_Name1_Account_Nbr]
      ,[Party1_Name1_SSN_Nbr]
      ,[Party1_Name1_MailPropertyID]
      ,[Party1_Name1_Address]
      ,[Party1_Name1_PreDir]
      ,[Party1_Name1_StreetNumber]
      ,[Party1_Name1_StreetName]
      ,[Party1_Name1_PostDir]
      ,[Party1_Name1_StreetType]
      ,[Party1_Name1_SuiteType]
      ,[Party1_Name1_Suite]
      ,[Party1_Name1_City]
      ,[Party1_Name1_State]
      ,[Party1_Name1_Zip]
      ,[Party1_Name1_ZipPlus4]
      ,[Party1_Name2_FullName]
      ,[Party1_Name2_last_Company_Name]
      ,[Party1_Name2_First_Name]
      ,[Party1_Name2_Middle_Name]
      ,[Party1_Name2_Suffix]
      ,[Party1_Name2_Roll_Type]
      ,[Party1_Name2_taxpayer_id_ssn_fein]
      ,[Party1_Name2_Account_Nbr]
      ,[Party1_Name2_SSN_Nbr]
      ,[Party1_Name2_MailPropertyID]
      ,[Party1_Name2_Address]
      ,[Party1_Name2_PreDir]
      ,[Party1_Name2_StreetNumber]
      ,[Party1_Name2_StreetName]
      ,[Party1_Name2_PostDir]
      ,[Party1_Name2_StreetType]
      ,[Party1_Name2_SuiteType]
      ,[Party1_Name2_Suite]
      ,[Party1_Name2_City]
      ,[Party1_Name2_State]
      ,[Party1_Name2_Zip]
      ,[Party1_Name2_ZipPlus4]
      ,[Party1_Name3_FullName]
      ,[Party1_Name3_last_Company_Name]
      ,[Party1_Name3_First_Name]
      ,[Party1_Name3_Middle_Name]
      ,[Party1_Name3_Suffix]
      ,[Party1_Name3_Roll_Type]
      ,[Party1_Name3_taxpayer_id_ssn_fein]
      ,[Party1_Name3_Account_Nbr]
      ,[Party1_Name3_SSN_Nbr]
      ,[Party1_Name3_MailPropertyID]
      ,[Party1_Name3_Address]
      ,[Party1_Name3_PreDir]
      ,[Party1_Name3_StreetNumber]
      ,[Party1_Name3_StreetName]
      ,[Party1_Name3_PostDir]
      ,[Party1_Name3_StreetType]
      ,[Party1_Name3_SuiteType]
      ,[Party1_Name3_Suite]
      ,[Party1_Name3_City]
      ,[Party1_Name3_State]
      ,[Party1_Name3_Zip]
      ,[Party1_Name3_ZipPlus4]
      ,[Party1_Name4_FullName]
      ,[Party1_Name4_last_Company_Name]
      ,[Party1_Name4_First_Name]
      ,[Party1_Name4_Middle_Name]
      ,[Party1_Name4_Suffix]
      ,[Party1_Name4_Roll_Type]
      ,[Party1_Name4_taxpayer_id_ssn_fein]
      ,[Party1_Name4_Account_Nbr]
      ,[Party1_Name4_SSN_Nbr]
      ,[Party1_Name4_MailPropertyID]
      ,[Party1_Name4_Address]
      ,[Party1_Name4_PreDir]
      ,[Party1_Name4_StreetNumber]
      ,[Party1_Name4_StreetName]
      ,[Party1_Name4_PostDir]
      ,[Party1_Name4_StreetType]
      ,[Party1_Name4_SuiteType]
      ,[Party1_Name4_Suite]
      ,[Party1_Name4_City]
      ,[Party1_Name4_State]
      ,[Party1_Name4_Zip]
      ,[Party1_Name4_ZipPlus4]
      ,[Party2_Name1_FullName]
      ,[Party2_Name1_last_Company_Name]
      ,[Party2_Name1_First_Name]
      ,[Party2_Name1_Middle_Name]
      ,[Party2_Name1_Suffix]
      ,[Party2_Name1_Roll_Type]
      ,[Party2_Name1_taxpayer_id_ssn_fein]
      ,[Party2_Name1_Account_Nbr]
      ,[Party2_Name1_SSN_Nbr]
      ,[Party2_Name1_MailPropertyID]
      ,[Party2_Name1_Address]
      ,[Party2_Name1_PreDir]
      ,[Party2_Name1_StreetNumber]
      ,[Party2_Name1_StreetName]
      ,[Party2_Name1_PostDir]
      ,[Party2_Name1_StreetType]
      ,[Party2_Name1_SuiteType]
      ,[Party2_Name1_Suite]
      ,[Party2_Name1_City]
      ,[Party2_Name1_State]
      ,[Party2_Name1_Zip]
      ,[Party2_Name1_ZipPlus4]
      ,[Party2_Name2_FullName]
      ,[Party2_Name2_last_Company_Name]
      ,[Party2_Name2_First_Name]
      ,[Party2_Name2_Middle_Name]
      ,[Party2_Name2_Suffix]
      ,[Party2_Name2_Roll_Type]
      ,[Party2_Name2_taxpayer_id_ssn_fein]
      ,[Party2_Name2_Account_Nbr]
      ,[Party2_Name2_SSN_Nbr]
      ,[Party2_Name2_MailPropertyID]
      ,[Party2_Name2_Address]
      ,[Party2_Name2_PreDir]
      ,[Party2_Name2_StreetNumber]
      ,[Party2_Name2_StreetName]
      ,[Party2_Name2_PostDir]
      ,[Party2_Name2_StreetType]
      ,[Party2_Name2_SuiteType]
      ,[Party2_Name2_Suite]
      ,[Party2_Name2_City]
      ,[Party2_Name2_State]
      ,[Party2_Name2_Zip]
      ,[Party2_Name2_ZipPlus4]
      ,[Party2_Name3_FullName]
      ,[Party2_Name3_last_Company_Name]
      ,[Party2_Name3_First_Name]
      ,[Party2_Name3_Middle_Name]
      ,[Party2_Name3_Suffix]
      ,[Party2_Name3_Roll_Type]
      ,[Party2_Name3_taxpayer_id_ssn_fein]
      ,[Party2_Name3_Account_Nbr]
      ,[Party2_Name3_SSN_Nbr]
      ,[Party2_Name3_MailPropertyID]
      ,[Party2_Name3_Address]
      ,[Party2_Name3_PreDir]
      ,[Party2_Name3_StreetNumber]
      ,[Party2_Name3_StreetName]
      ,[Party2_Name3_PostDir]
      ,[Party2_Name3_StreetType]
      ,[Party2_Name3_SuiteType]
      ,[Party2_Name3_Suite]
      ,[Party2_Name3_City]
      ,[Party2_Name3_State]
      ,[Party2_Name3_Zip]
      ,[Party2_Name3_ZipPlus4]
      ,[Party2_Name4_FullName]
      ,[Party2_Name4_last_Company_Name]
      ,[Party2_Name4_First_Name]
      ,[Party2_Name4_Middle_Name]
      ,[Party2_Name4_Suffix]
      ,[Party2_Name4_Roll_Type]
      ,[Party2_Name4_taxpayer_id_ssn_fein]
      ,[Party2_Name4_Account_Nbr]
      ,[Party2_Name4_SSN_Nbr]
      ,[Party2_Name4_MailPropertyID]
      ,[Party2_Name4_Address]
      ,[Party2_Name4_PreDir]
      ,[Party2_Name4_StreetNumber]
      ,[Party2_Name4_StreetName]
      ,[Party2_Name4_PostDir]
      ,[Party2_Name4_StreetType]
      ,[Party2_Name4_SuiteType]
      ,[Party2_Name4_Suite]
      ,[Party2_Name4_City]
      ,[Party2_Name4_State]
      ,[Party2_Name4_Zip]
      ,[Party2_Name4_ZipPlus4]
      ,[Party3_Name1_FullName]
      ,[Party3_Name1_last_Company_Name]
      ,[Party3_Name1_First_Name]
      ,[Party3_Name1_Middle_Name]
      ,[Party3_Name1_Suffix]
      ,[Party3_Name1_Roll_Type]
      ,[Party3_Name1_taxpayer_id_ssn_fein]
      ,[Party3_Name1_Account_Nbr]
      ,[Party3_Name1_SSN_Nbr]
      ,[Party3_Name1_MailPropertyID]
      ,[Party3_Name1_Address]
      ,[Party3_Name1_PreDir]
      ,[Party3_Name1_StreetNumber]
      ,[Party3_Name1_StreetName]
      ,[Party3_Name1_PostDir]
      ,[Party3_Name1_StreetType]
      ,[Party3_Name1_SuiteType]
      ,[Party3_Name1_Suite]
      ,[Party3_Name1_City]
      ,[Party3_Name1_State]
      ,[Party3_Name1_Zip]
      ,[Party3_Name1_ZipPlus4]
      ,[Party3_Name2_FullName]
      ,[Party3_Name2_last_Company_Name]
      ,[Party3_Name2_First_Name]
      ,[Party3_Name2_Middle_Name]
      ,[Party3_Name2_Suffix]
      ,[Party3_Name2_Roll_Type]
      ,[Party3_Name2_taxpayer_id_ssn_fein]
      ,[Party3_Name2_Account_Nbr]
      ,[Party3_Name2_SSN_Nbr]
      ,[Party3_Name2_MailPropertyID]
      ,[Party3_Name2_Address]
      ,[Party3_Name2_PreDir]
      ,[Party3_Name2_StreetNumber]
      ,[Party3_Name2_StreetName]
      ,[Party3_Name2_PostDir]
      ,[Party3_Name2_StreetType]
      ,[Party3_Name2_SuiteType]
      ,[Party3_Name2_Suite]
      ,[Party3_Name2_City]
      ,[Party3_Name2_State]
      ,[Party3_Name2_Zip]
      ,[Party3_Name2_ZipPlus4]
      ,[Party3_Name3_FullName]
      ,[Party3_Name3_last_Company_Name]
      ,[Party3_Name3_First_Name]
      ,[Party3_Name3_Middle_Name]
      ,[Party3_Name3_Suffix]
      ,[Party3_Name3_Roll_Type]
      ,[Party3_Name3_taxpayer_id_ssn_fein]
      ,[Party3_Name3_Account_Nbr]
      ,[Party3_Name3_SSN_Nbr]
      ,[Party3_Name3_MailPropertyID]
      ,[Party3_Name3_Address]
      ,[Party3_Name3_PreDir]
      ,[Party3_Name3_StreetNumber]
      ,[Party3_Name3_StreetName]
      ,[Party3_Name3_PostDir]
      ,[Party3_Name3_StreetType]
      ,[Party3_Name3_SuiteType]
      ,[Party3_Name3_Suite]
      ,[Party3_Name3_City]
      ,[Party3_Name3_State]
      ,[Party3_Name3_Zip]
      ,[Party3_Name3_ZipPlus4]
      ,[Party3_Name4_FullName]
      ,[Party3_Name4_last_Company_Name]
      ,[Party3_Name4_First_Name]
      ,[Party3_Name4_Middle_Name]
      ,[Party3_Name4_Suffix]
      ,[Party3_Name4_Roll_Type]
      ,[Party3_Name4_taxpayer_id_ssn_fein]
      ,[Party3_Name4_Account_Nbr]
      ,[Party3_Name4_SSN_Nbr]
      ,[Party3_Name4_MailPropertyID]
      ,[Party3_Name4_Address]
      ,[Party3_Name4_PreDir]
      ,[Party3_Name4_StreetNumber]
      ,[Party3_Name4_StreetName]
      ,[Party3_Name4_PostDir]
      ,[Party3_Name4_StreetType]
      ,[Party3_Name4_SuiteType]
      ,[Party3_Name4_Suite]
      ,[Party3_Name4_City]
      ,[Party3_Name4_State]
      ,[Party3_Name4_Zip]
      ,[Party3_Name4_ZipPlus4]
      ,[Party4_Name1_FullName]
      ,[Party4_Name1_last_Company_Name]
      ,[Party4_Name1_First_Name]
      ,[Party4_Name1_Middle_Name]
      ,[Party4_Name1_Suffix]
      ,[Party4_Name1_Roll_Type]
      ,[Party4_Name1_taxpayer_id_ssn_fein]
      ,[Party4_Name1_Account_Nbr]
      ,[Party4_Name1_SSN_Nbr]
      ,[Party4_Name1_MailPropertyID]
      ,[Party4_Name1_Address]
      ,[Party4_Name1_PreDir]
      ,[Party4_Name1_StreetNumber]
      ,[Party4_Name1_StreetName]
      ,[Party4_Name1_PostDir]
      ,[Party4_Name1_StreetType]
      ,[Party4_Name1_SuiteType]
      ,[Party4_Name1_Suite]
      ,[Party4_Name1_City]
      ,[Party4_Name1_State]
      ,[Party4_Name1_Zip]
      ,[Party4_Name1_ZipPlus4]
      ,[Party4_Name2_FullName]
      ,[Party4_Name2_last_Company_Name]
      ,[Party4_Name2_First_Name]
      ,[Party4_Name2_Middle_Name]
      ,[Party4_Name2_Suffix]
      ,[Party4_Name2_Roll_Type]
      ,[Party4_Name2_taxpayer_id_ssn_fein]
      ,[Party4_Name2_Account_Nbr]
      ,[Party4_Name2_SSN_Nbr]
      ,[Party4_Name2_MailPropertyID]
      ,[Party4_Name2_Address]
      ,[Party4_Name2_PreDir]
      ,[Party4_Name2_StreetNumber]
      ,[Party4_Name2_StreetName]
      ,[Party4_Name2_PostDir]
      ,[Party4_Name2_StreetType]
      ,[Party4_Name2_SuiteType]
      ,[Party4_Name2_Suite]
      ,[Party4_Name2_City]
      ,[Party4_Name2_State]
      ,[Party4_Name2_Zip]
      ,[Party4_Name2_ZipPlus4]
      ,[Party4_Name3_FullName]
      ,[Party4_Name3_last_Company_Name]
      ,[Party4_Name3_First_Name]
      ,[Party4_Name3_Middle_Name]
      ,[Party4_Name3_Suffix]
      ,[Party4_Name3_Roll_Type]
      ,[Party4_Name3_taxpayer_id_ssn_fein]
      ,[Party4_Name3_Account_Nbr]
      ,[Party4_Name3_SSN_Nbr]
      ,[Party4_Name3_MailPropertyID]
      ,[Party4_Name3_Address]
      ,[Party4_Name3_PreDir]
      ,[Party4_Name3_StreetNumber]
      ,[Party4_Name3_StreetName]
      ,[Party4_Name3_PostDir]
      ,[Party4_Name3_StreetType]
      ,[Party4_Name3_SuiteType]
      ,[Party4_Name3_Suite]
      ,[Party4_Name3_City]
      ,[Party4_Name3_State]
      ,[Party4_Name3_Zip]
      ,[Party4_Name3_ZipPlus4]
      ,[Party4_Name4_FullName]
      ,[Party4_Name4_last_Company_Name]
      ,[Party4_Name4_First_Name]
      ,[Party4_Name4_Middle_Name]
      ,[Party4_Name4_Suffix]
      ,[Party4_Name4_Roll_Type]
      ,[Party4_Name4_taxpayer_id_ssn_fein]
      ,[Party4_Name4_Account_Nbr]
      ,[Party4_Name4_SSN_Nbr]
      ,[Party4_Name4_MailPropertyID]
      ,[Party4_Name4_Address]
      ,[Party4_Name4_PreDir]
      ,[Party4_Name4_StreetNumber]
      ,[Party4_Name4_StreetName]
      ,[Party4_Name4_PostDir]
      ,[Party4_Name4_StreetType]
      ,[Party4_Name4_SuiteType]
      ,[Party4_Name4_Suite]
      ,[Party4_Name4_City]
      ,[Party4_Name4_State]
      ,[Party4_Name4_Zip]
      ,[Party4_Name4_ZipPlus4]
      ,[PropertyID]
      ,[AddressLine]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[PropState]
      ,[Zip]
      ,[Plus4]
      ,[property_id_sequence_number]
      ,[legal_desc_apn_portion]
      ,[legal_desc_apn]
      ,[legal_desc_apn_arb]
      ,[legal_desc_map_portion]
      ,[legal_desc_map_unit_low]
      ,[legal_desc_map_unit_high]
      ,[legal_desc_map_lot_type]
      ,[legal_desc_map_lot_type_low]
      ,[legal_desc_map_lot_type_high]
      ,[legal_desc_map_lot_low]
      ,[legal_desc_map_lot_high]
      ,[legal_desc_map_block]
      ,[legal_desc_map_building]
      ,[legal_desc_map_sublot]
      ,[legal_desc_map_plat_subcode]
      ,[legal_desc_map_plat_name]
      ,[legal_desc_map_plat_number]
      ,[legal_desc_map_plat_condo_id]
      ,[legal_desc_map_plat_type_indicator]
      ,[legal_desc_map_plat_book]
      ,[legal_desc_map_plat_page]
      ,[legal_desc_str_portion]
      ,[legal_desc_str_government_lot]
      ,[legal_desc_str_quarter]
      ,[legal_desc_str_section]
      ,[legal_desc_str_township]
      ,[legal_desc_str_range]
      ,[legal_desc_tct]
      ,[legal_desc_district]
      ,[legal_desc_municipality]
      ,[legal_desc_swiss_code]
      ,[legal_desc_easement_flag]
      ,[legal_desc_easement_type]
      ,[legal_type]
      ,[legal_type_sequence]
      ,[property_sequence]
      ,[legal_desc_qualifier]
      ,[legal_desc_map_city_block]
      ,[legal_desc_application_number]
      ,[legal_desc_tax_assessor_portion]
      ,[legal_desc_tax_assessor_lot]
      ,[legal_desc_tax_assessor_block]
      ,[legal_desc_tax_assessor_section]
      ,[FATimeStamp]
      ,[FARecordType]
      ,[FormattedAPN]
      ,[InActiveFlag]
      ,[StdLandUseCode]
      ,[cmt_docnumber]
      ,[cmt_id]
      ,[PropertyClassID]
      ,[OwnerStd1CorpInd]
      ,[REFERENCE_id]
      ,[Reference_recording_year]
      ,[reference_recording_date]
      ,[reference_doc_number]
      ,[reference_book]
      ,[reference_page]
      ,[Fmt_Reference_Doc_Number]
      ,[Fmt_Reference_BookPAge])

		SELECT NULL AS ROWNUM, B.[INPUT Unique ID]
      ,[TransactionID]
      ,A.[Fips]
      ,A.[State]
      ,A.[County]
      ,A.[DocumentYear]
      ,A.[Recordingdt]
      ,A.[DocumentDt]
      ,A.[doc_filing_date]
      ,A.[DocNbrSrce]
      ,A.[BookSrce]
      ,A.[PaceSrce]
      ,A.[Doc_Category]
      ,A.[DocTypeID]
      ,A.[DocType]
      ,A.[DocumentTitle]
      ,A.[case_number]
      ,A.[case_book]
      ,A.[case_page]
      ,A.[date_of_death]
      ,A.[account_number]
      ,A.[amendment_number]
      ,A.[attorney_bar_number]
      ,A.[bond_number]
      ,A.[lot_line_adjustment_number]
      ,A.[certificate_number]
      ,A.[claim_number]
      ,A.[contract_number]
      ,A.[corporation_number]
      ,A.[excise_tax_number]
      ,A.[federal_tax_lien_area]
      ,A.[federal_tax_lien_area_phone]
      ,A.[tax_last_day_for_refiling]
      ,A.[tax_period_begin_date]
      ,A.[tax_period_end_date]
      ,A.[tax_amount]
      ,A.[tax_interest_amount]
      ,A.[tax_penalty_amount]
      ,A.[judgment_amount]
      ,A.[judgment_grand_total]
      ,A.[judgment_court_fees]
      ,A.[judgment_attorney_fees]
      ,A.[judgment_principal_fees]
      ,A.[judgment_interest_fees]
      ,A.[judgment_filing_fees]
      ,A.[judgment_per_diem_fees]
      ,A.[judgment_late_fees]
      ,A.[judgment_tax_fees]
      ,A.[judgment_insurance_fees]
      ,A.[judgment_other_fees]
      ,A.[installment_judgment]
      ,A.[license_number]
      ,A.[lien_number]
      ,A.[map_plat_id]
      ,A.[mechanics_lien_number]
      ,A.[ordinance_number]
      ,A.[patent_number]
      ,A.[permit_number]
      ,A.[resolution_number]
      ,A.[tax_account_serial_warrant_number]
      ,A.[tax_type]
      ,A.[trustees_sale_number]
      ,A.[ucc_number]
      ,A.[undersigned_same_as_borrower]
      ,A.[amount_due]
      ,A.[amount_of_default]
      ,A.[bond_amount]
      ,A.[cash_down_amount]
      ,A.[contract_amount]
      ,A.[collection_costs]
      ,A.[unpaid_balance]
      ,A.[unpaid_balance_as_of_modification_date]
      ,A.[unpaid_prinicipal_amount]
      ,A.[date_of_divorce]
      ,A.[support_arrears_amount]
      ,A.[support_payment_amount]
      ,A.[support_total_amount]
      ,A.[date_amount_due]
      ,A.[date_stay_ordered]
      ,A.[bankruptcy_case_number]
      ,A.[bankruptcy_chapter]
      ,A.[bankruptcy_type]
      ,A.[bankruptcy_location]
      ,A.[case_filed_in_county]
      ,A.[case_court_type]
      ,A.[case_original_number]
      ,A.[case_original_court_type]
      ,A.[case_status]
      ,A.[date_bankruptcy_closed]
      ,A.[date_bankruptcy_case_filed]
      ,A.[date_bankruptcy_conversion]
      ,A.[date_bankruptcy_discharged]
      ,A.[date_bankruptcy_dismissed]
      ,A.[date_bankruptcy_341_meeting]
      ,A.[bankruptcy_341_meeting_time]
      ,A.[requested_prepared_by_attorney_name_identifier]
      ,A.[requested_prepared_by_attorney_last_company_name]
      ,A.[requested_prepared_by_attorney_first_name]
      ,A.[requested_prepared_by_attorney_middle_initial]
      ,A.[requested_prepared_by_attorney_suffix]
      ,A.[requested_prepared_by_attorney_address]
      ,A.[requested_prepared_by_attorney_address_city]
      ,A.[requested_prepared_by_attorney_address_state]
      ,A.[requested_prepared_by_attorney_address_zip]
      ,A.[requested_prepared_by_attorney_phone]
      ,A.[Party1_Name1_FullName]
      ,A.[Party1_Name1_last_Company_Name]
      ,A.[Party1_Name1_First_Name]
      ,A.[Party1_Name1_Middle_Name]
      ,A.[Party1_Name1_Suffix]
      ,A.[Party1_Name1_Roll_Type]
      ,A.[Party1_Name1_taxpayer_id_ssn_fein]
      ,A.[Party1_Name1_Account_Nbr]
      ,A.[Party1_Name1_SSN_Nbr]
      ,A.[Party1_Name1_MailPropertyID]
      ,A.[Party1_Name1_Address]
      ,A.[Party1_Name1_PreDir]
      ,A.[Party1_Name1_StreetNumber]
      ,A.[Party1_Name1_StreetName]
      ,A.[Party1_Name1_PostDir]
      ,A.[Party1_Name1_StreetType]
      ,A.[Party1_Name1_SuiteType]
      ,A.[Party1_Name1_Suite]
      ,A.[Party1_Name1_City]
      ,A.[Party1_Name1_State]
      ,A.[Party1_Name1_Zip]
      ,A.[Party1_Name1_ZipPlus4]
      ,A.[Party1_Name2_FullName]
      ,A.[Party1_Name2_last_Company_Name]
      ,A.[Party1_Name2_First_Name]
      ,A.[Party1_Name2_Middle_Name]
      ,A.[Party1_Name2_Suffix]
      ,A.[Party1_Name2_Roll_Type]
      ,A.[Party1_Name2_taxpayer_id_ssn_fein]
      ,A.[Party1_Name2_Account_Nbr]
      ,A.[Party1_Name2_SSN_Nbr]
      ,A.[Party1_Name2_MailPropertyID]
      ,A.[Party1_Name2_Address]
      ,A.[Party1_Name2_PreDir]
      ,A.[Party1_Name2_StreetNumber]
      ,A.[Party1_Name2_StreetName]
      ,A.[Party1_Name2_PostDir]
      ,A.[Party1_Name2_StreetType]
      ,A.[Party1_Name2_SuiteType]
      ,A.[Party1_Name2_Suite]
      ,A.[Party1_Name2_City]
      ,A.[Party1_Name2_State]
      ,A.[Party1_Name2_Zip]
      ,A.[Party1_Name2_ZipPlus4]
      ,A.[Party1_Name3_FullName]
      ,A.[Party1_Name3_last_Company_Name]
      ,A.[Party1_Name3_First_Name]
      ,A.[Party1_Name3_Middle_Name]
      ,A.[Party1_Name3_Suffix]
      ,A.[Party1_Name3_Roll_Type]
      ,A.[Party1_Name3_taxpayer_id_ssn_fein]
      ,A.[Party1_Name3_Account_Nbr]
      ,A.[Party1_Name3_SSN_Nbr]
      ,A.[Party1_Name3_MailPropertyID]
      ,A.[Party1_Name3_Address]
      ,A.[Party1_Name3_PreDir]
      ,A.[Party1_Name3_StreetNumber]
      ,A.[Party1_Name3_StreetName]
      ,A.[Party1_Name3_PostDir]
      ,A.[Party1_Name3_StreetType]
      ,A.[Party1_Name3_SuiteType]
      ,A.[Party1_Name3_Suite]
      ,A.[Party1_Name3_City]
      ,A.[Party1_Name3_State]
      ,A.[Party1_Name3_Zip]
      ,A.[Party1_Name3_ZipPlus4]
      ,A.[Party1_Name4_FullName]
      ,A.[Party1_Name4_last_Company_Name]
      ,A.[Party1_Name4_First_Name]
      ,A.[Party1_Name4_Middle_Name]
      ,A.[Party1_Name4_Suffix]
      ,A.[Party1_Name4_Roll_Type]
      ,A.[Party1_Name4_taxpayer_id_ssn_fein]
      ,A.[Party1_Name4_Account_Nbr]
      ,A.[Party1_Name4_SSN_Nbr]
      ,A.[Party1_Name4_MailPropertyID]
      ,A.[Party1_Name4_Address]
      ,A.[Party1_Name4_PreDir]
      ,A.[Party1_Name4_StreetNumber]
      ,A.[Party1_Name4_StreetName]
      ,A.[Party1_Name4_PostDir]
      ,A.[Party1_Name4_StreetType]
      ,A.[Party1_Name4_SuiteType]
      ,A.[Party1_Name4_Suite]
      ,A.[Party1_Name4_City]
      ,A.[Party1_Name4_State]
      ,A.[Party1_Name4_Zip]
      ,A.[Party1_Name4_ZipPlus4]
      ,A.[Party2_Name1_FullName]
      ,A.[Party2_Name1_last_Company_Name]
      ,A.[Party2_Name1_First_Name]
      ,A.[Party2_Name1_Middle_Name]
      ,A.[Party2_Name1_Suffix]
      ,A.[Party2_Name1_Roll_Type]
      ,A.[Party2_Name1_taxpayer_id_ssn_fein]
      ,A.[Party2_Name1_Account_Nbr]
      ,A.[Party2_Name1_SSN_Nbr]
      ,A.[Party2_Name1_MailPropertyID]
      ,A.[Party2_Name1_Address]
      ,A.[Party2_Name1_PreDir]
      ,A.[Party2_Name1_StreetNumber]
      ,A.[Party2_Name1_StreetName]
      ,A.[Party2_Name1_PostDir]
      ,A.[Party2_Name1_StreetType]
      ,A.[Party2_Name1_SuiteType]
      ,A.[Party2_Name1_Suite]
      ,A.[Party2_Name1_City]
      ,A.[Party2_Name1_State]
      ,A.[Party2_Name1_Zip]
      ,A.[Party2_Name1_ZipPlus4]
      ,A.[Party2_Name2_FullName]
      ,A.[Party2_Name2_last_Company_Name]
      ,A.[Party2_Name2_First_Name]
      ,A.[Party2_Name2_Middle_Name]
      ,A.[Party2_Name2_Suffix]
      ,A.[Party2_Name2_Roll_Type]
      ,A.[Party2_Name2_taxpayer_id_ssn_fein]
      ,A.[Party2_Name2_Account_Nbr]
      ,A.[Party2_Name2_SSN_Nbr]
      ,A.[Party2_Name2_MailPropertyID]
      ,A.[Party2_Name2_Address]
      ,A.[Party2_Name2_PreDir]
      ,A.[Party2_Name2_StreetNumber]
      ,A.[Party2_Name2_StreetName]
      ,A.[Party2_Name2_PostDir]
      ,A.[Party2_Name2_StreetType]
      ,A.[Party2_Name2_SuiteType]
      ,A.[Party2_Name2_Suite]
      ,A.[Party2_Name2_City]
      ,A.[Party2_Name2_State]
      ,A.[Party2_Name2_Zip]
      ,A.[Party2_Name2_ZipPlus4]
      ,A.[Party2_Name3_FullName]
      ,A.[Party2_Name3_last_Company_Name]
      ,A.[Party2_Name3_First_Name]
      ,A.[Party2_Name3_Middle_Name]
      ,A.[Party2_Name3_Suffix]
      ,A.[Party2_Name3_Roll_Type]
      ,A.[Party2_Name3_taxpayer_id_ssn_fein]
      ,A.[Party2_Name3_Account_Nbr]
      ,A.[Party2_Name3_SSN_Nbr]
      ,A.[Party2_Name3_MailPropertyID]
      ,A.[Party2_Name3_Address]
      ,A.[Party2_Name3_PreDir]
      ,A.[Party2_Name3_StreetNumber]
      ,A.[Party2_Name3_StreetName]
      ,A.[Party2_Name3_PostDir]
      ,A.[Party2_Name3_StreetType]
      ,A.[Party2_Name3_SuiteType]
      ,A.[Party2_Name3_Suite]
      ,A.[Party2_Name3_City]
      ,A.[Party2_Name3_State]
      ,A.[Party2_Name3_Zip]
      ,A.[Party2_Name3_ZipPlus4]
      ,A.[Party2_Name4_FullName]
      ,A.[Party2_Name4_last_Company_Name]
      ,A.[Party2_Name4_First_Name]
      ,A.[Party2_Name4_Middle_Name]
      ,A.[Party2_Name4_Suffix]
      ,A.[Party2_Name4_Roll_Type]
      ,A.[Party2_Name4_taxpayer_id_ssn_fein]
      ,A.[Party2_Name4_Account_Nbr]
      ,A.[Party2_Name4_SSN_Nbr]
      ,A.[Party2_Name4_MailPropertyID]
      ,A.[Party2_Name4_Address]
      ,A.[Party2_Name4_PreDir]
      ,A.[Party2_Name4_StreetNumber]
      ,A.[Party2_Name4_StreetName]
      ,A.[Party2_Name4_PostDir]
      ,A.[Party2_Name4_StreetType]
      ,A.[Party2_Name4_SuiteType]
      ,A.[Party2_Name4_Suite]
      ,A.[Party2_Name4_City]
      ,A.[Party2_Name4_State]
      ,A.[Party2_Name4_Zip]
      ,A.[Party2_Name4_ZipPlus4]
      ,A.[Party3_Name1_FullName]
      ,A.[Party3_Name1_last_Company_Name]
      ,A.[Party3_Name1_First_Name]
      ,A.[Party3_Name1_Middle_Name]
      ,A.[Party3_Name1_Suffix]
      ,A.[Party3_Name1_Roll_Type]
      ,A.[Party3_Name1_taxpayer_id_ssn_fein]
      ,A.[Party3_Name1_Account_Nbr]
      ,A.[Party3_Name1_SSN_Nbr]
      ,A.[Party3_Name1_MailPropertyID]
      ,A.[Party3_Name1_Address]
      ,A.[Party3_Name1_PreDir]
      ,A.[Party3_Name1_StreetNumber]
      ,A.[Party3_Name1_StreetName]
      ,A.[Party3_Name1_PostDir]
      ,A.[Party3_Name1_StreetType]
      ,A.[Party3_Name1_SuiteType]
      ,A.[Party3_Name1_Suite]
      ,A.[Party3_Name1_City]
      ,A.[Party3_Name1_State]
      ,A.[Party3_Name1_Zip]
      ,A.[Party3_Name1_ZipPlus4]
      ,A.[Party3_Name2_FullName]
      ,A.[Party3_Name2_last_Company_Name]
      ,A.[Party3_Name2_First_Name]
      ,A.[Party3_Name2_Middle_Name]
      ,A.[Party3_Name2_Suffix]
      ,A.[Party3_Name2_Roll_Type]
      ,A.[Party3_Name2_taxpayer_id_ssn_fein]
      ,A.[Party3_Name2_Account_Nbr]
      ,A.[Party3_Name2_SSN_Nbr]
      ,A.[Party3_Name2_MailPropertyID]
      ,A.[Party3_Name2_Address]
      ,A.[Party3_Name2_PreDir]
      ,A.[Party3_Name2_StreetNumber]
      ,A.[Party3_Name2_StreetName]
      ,A.[Party3_Name2_PostDir]
      ,A.[Party3_Name2_StreetType]
      ,A.[Party3_Name2_SuiteType]
      ,A.[Party3_Name2_Suite]
      ,A.[Party3_Name2_City]
      ,A.[Party3_Name2_State]
      ,A.[Party3_Name2_Zip]
      ,A.[Party3_Name2_ZipPlus4]
      ,A.[Party3_Name3_FullName]
      ,A.[Party3_Name3_last_Company_Name]
      ,A.[Party3_Name3_First_Name]
      ,A.[Party3_Name3_Middle_Name]
      ,A.[Party3_Name3_Suffix]
      ,A.[Party3_Name3_Roll_Type]
      ,A.[Party3_Name3_taxpayer_id_ssn_fein]
      ,A.[Party3_Name3_Account_Nbr]
      ,A.[Party3_Name3_SSN_Nbr]
      ,A.[Party3_Name3_MailPropertyID]
      ,A.[Party3_Name3_Address]
      ,A.[Party3_Name3_PreDir]
      ,A.[Party3_Name3_StreetNumber]
      ,A.[Party3_Name3_StreetName]
      ,A.[Party3_Name3_PostDir]
      ,A.[Party3_Name3_StreetType]
      ,A.[Party3_Name3_SuiteType]
      ,A.[Party3_Name3_Suite]
      ,A.[Party3_Name3_City]
      ,A.[Party3_Name3_State]
      ,A.[Party3_Name3_Zip]
      ,A.[Party3_Name3_ZipPlus4]
      ,A.[Party3_Name4_FullName]
      ,A.[Party3_Name4_last_Company_Name]
      ,A.[Party3_Name4_First_Name]
      ,A.[Party3_Name4_Middle_Name]
      ,A.[Party3_Name4_Suffix]
      ,A.[Party3_Name4_Roll_Type]
      ,A.[Party3_Name4_taxpayer_id_ssn_fein]
      ,A.[Party3_Name4_Account_Nbr]
      ,A.[Party3_Name4_SSN_Nbr]
      ,A.[Party3_Name4_MailPropertyID]
      ,A.[Party3_Name4_Address]
      ,A.[Party3_Name4_PreDir]
      ,A.[Party3_Name4_StreetNumber]
      ,A.[Party3_Name4_StreetName]
      ,A.[Party3_Name4_PostDir]
      ,A.[Party3_Name4_StreetType]
      ,A.[Party3_Name4_SuiteType]
      ,A.[Party3_Name4_Suite]
      ,A.[Party3_Name4_City]
      ,A.[Party3_Name4_State]
      ,A.[Party3_Name4_Zip]
      ,A.[Party3_Name4_ZipPlus4]
      ,A.[Party4_Name1_FullName]
      ,A.[Party4_Name1_last_Company_Name]
      ,A.[Party4_Name1_First_Name]
      ,A.[Party4_Name1_Middle_Name]
      ,A.[Party4_Name1_Suffix]
      ,A.[Party4_Name1_Roll_Type]
      ,A.[Party4_Name1_taxpayer_id_ssn_fein]
      ,A.[Party4_Name1_Account_Nbr]
      ,A.[Party4_Name1_SSN_Nbr]
      ,A.[Party4_Name1_MailPropertyID]
      ,A.[Party4_Name1_Address]
      ,A.[Party4_Name1_PreDir]
      ,A.[Party4_Name1_StreetNumber]
      ,A.[Party4_Name1_StreetName]
      ,A.[Party4_Name1_PostDir]
      ,A.[Party4_Name1_StreetType]
      ,A.[Party4_Name1_SuiteType]
      ,A.[Party4_Name1_Suite]
      ,A.[Party4_Name1_City]
      ,A.[Party4_Name1_State]
      ,A.[Party4_Name1_Zip]
      ,A.[Party4_Name1_ZipPlus4]
      ,A.[Party4_Name2_FullName]
      ,A.[Party4_Name2_last_Company_Name]
      ,A.[Party4_Name2_First_Name]
      ,A.[Party4_Name2_Middle_Name]
      ,A.[Party4_Name2_Suffix]
      ,A.[Party4_Name2_Roll_Type]
      ,A.[Party4_Name2_taxpayer_id_ssn_fein]
      ,A.[Party4_Name2_Account_Nbr]
      ,A.[Party4_Name2_SSN_Nbr]
      ,A.[Party4_Name2_MailPropertyID]
      ,A.[Party4_Name2_Address]
      ,A.[Party4_Name2_PreDir]
      ,A.[Party4_Name2_StreetNumber]
      ,A.[Party4_Name2_StreetName]
      ,A.[Party4_Name2_PostDir]
      ,A.[Party4_Name2_StreetType]
      ,A.[Party4_Name2_SuiteType]
      ,A.[Party4_Name2_Suite]
      ,A.[Party4_Name2_City]
      ,A.[Party4_Name2_State]
      ,A.[Party4_Name2_Zip]
      ,A.[Party4_Name2_ZipPlus4]
      ,A.[Party4_Name3_FullName]
      ,A.[Party4_Name3_last_Company_Name]
      ,A.[Party4_Name3_First_Name]
      ,A.[Party4_Name3_Middle_Name]
      ,A.[Party4_Name3_Suffix]
      ,A.[Party4_Name3_Roll_Type]
      ,A.[Party4_Name3_taxpayer_id_ssn_fein]
      ,A.[Party4_Name3_Account_Nbr]
      ,A.[Party4_Name3_SSN_Nbr]
      ,A.[Party4_Name3_MailPropertyID]
      ,A.[Party4_Name3_Address]
      ,A.[Party4_Name3_PreDir]
      ,A.[Party4_Name3_StreetNumber]
      ,A.[Party4_Name3_StreetName]
      ,A.[Party4_Name3_PostDir]
      ,A.[Party4_Name3_StreetType]
      ,A.[Party4_Name3_SuiteType]
      ,A.[Party4_Name3_Suite]
      ,A.[Party4_Name3_City]
      ,A.[Party4_Name3_State]
      ,A.[Party4_Name3_Zip]
      ,A.[Party4_Name3_ZipPlus4]
      ,A.[Party4_Name4_FullName]
      ,A.[Party4_Name4_last_Company_Name]
      ,A.[Party4_Name4_First_Name]
      ,A.[Party4_Name4_Middle_Name]
      ,A.[Party4_Name4_Suffix]
      ,A.[Party4_Name4_Roll_Type]
      ,A.[Party4_Name4_taxpayer_id_ssn_fein]
      ,A.[Party4_Name4_Account_Nbr]
      ,A.[Party4_Name4_SSN_Nbr]
      ,A.[Party4_Name4_MailPropertyID]
      ,A.[Party4_Name4_Address]
      ,A.[Party4_Name4_PreDir]
      ,A.[Party4_Name4_StreetNumber]
      ,A.[Party4_Name4_StreetName]
      ,A.[Party4_Name4_PostDir]
      ,A.[Party4_Name4_StreetType]
      ,A.[Party4_Name4_SuiteType]
      ,A.[Party4_Name4_Suite]
      ,A.[Party4_Name4_City]
      ,A.[Party4_Name4_State]
      ,A.[Party4_Name4_Zip]
      ,A.[Party4_Name4_ZipPlus4]
      ,A.[PropertyID]
      ,A.[AddressLine]
      ,A.[PreDir]
      ,A.[StreetNumber]
      ,A.[StreetName]
      ,A.[PostDir]
      ,A.[StreetType]
      ,A.[SuiteType]
      ,A.[Suite]
      ,A.[City]
      ,A.[PropState]
      ,A.[Zip]
      ,A.[Plus4]
      ,A.[property_id_sequence_number]
      ,A.[legal_desc_apn_portion]
      ,A.[legal_desc_apn]
      ,A.[legal_desc_apn_arb]
      ,A.[legal_desc_map_portion]
      ,A.[legal_desc_map_unit_low]
      ,A.[legal_desc_map_unit_high]
      ,A.[legal_desc_map_lot_type]
      ,A.[legal_desc_map_lot_type_low]
      ,A.[legal_desc_map_lot_type_high]
      ,A.[legal_desc_map_lot_low]
      ,A.[legal_desc_map_lot_high]
      ,A.[legal_desc_map_block]
      ,A.[legal_desc_map_building]
      ,A.[legal_desc_map_sublot]
      ,A.[legal_desc_map_plat_subcode]
      ,A.[legal_desc_map_plat_name]
      ,A.[legal_desc_map_plat_number]
      ,A.[legal_desc_map_plat_condo_id]
      ,A.[legal_desc_map_plat_type_indicator]
      ,A.[legal_desc_map_plat_book]
      ,A.[legal_desc_map_plat_page]
      ,A.[legal_desc_str_portion]
      ,A.[legal_desc_str_government_lot]
      ,A.[legal_desc_str_quarter]
      ,A.[legal_desc_str_section]
      ,A.[legal_desc_str_township]
      ,A.[legal_desc_str_range]
      ,A.[legal_desc_tct]
      ,A.[legal_desc_district]
      ,A.[legal_desc_municipality]
      ,A.[legal_desc_swiss_code]
      ,A.[legal_desc_easement_flag]
      ,A.[legal_desc_easement_type]
      ,A.[legal_type]
      ,A.[legal_type_sequence]
      ,A.[property_sequence]
      ,A.[legal_desc_qualifier]
      ,A.[legal_desc_map_city_block]
      ,A.[legal_desc_application_number]
      ,A.[legal_desc_tax_assessor_portion]
      ,A.[legal_desc_tax_assessor_lot]
      ,A.[legal_desc_tax_assessor_block]
      ,A.[legal_desc_tax_assessor_section]
      ,A.[FATimeStamp]
      ,A.[FARecordType]
      ,A.[FormattedAPN]
      ,A.[InActiveFlag]
      ,A.[StdLandUseCode]
      ,A.[cmt_docnumber]
      ,A.[cmt_id]
      ,A.[PropertyClassID]
      ,A.[OwnerStd1CorpInd]
      ,A.[REFERENCE_id]
      ,A.[Reference_recording_year]
      ,A.[reference_recording_date]
      ,A.[reference_doc_number]
      ,A.[reference_book]
      ,A.[reference_page]
      ,A.[Fmt_Reference_Doc_Number]
      ,A.[Fmt_Reference_BookPAge]

		From [data].[dbo].[v_Invl] as A with(NOLOCK)
		join [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] as B with(NOLOCK) on A.Party2_Name1_MailPropertyID = B.PropertyID
		where B.PropertyID is not null and B.PropertyID not like '' and B.PropertyID not like '0'
		AND (A.InActiveFlag IS NULL)
		and A.FARecordType not like 'D'
		and A.recordingdt is not null 
		AND CONVERT(date, A.Recordingdt) > CONVERT(date, B.[START DATE])
		AND (CONVERT(date, A.Recordingdt) > CONVERT(date, B.MAX_INVL_RECDATE)
			OR B.MAX_INVL_RECDATE is null)
		AND A.Doc_Category in ('MLN','ABJ','JDG','LEN','FLN','SLN')


		
		Select [INPUT KEY], A.FIPS,B.REF_ID--,Party1_Name1_MailPropertyID,Party1_Name2_MailPropertyID
		--,Party2_Name1_MailPropertyID,Party2_Name2_MailPropertyID
		,Recordingdt, DocType, Doc_Category, DocumentTitle, DocNbrSrce 
		,C.State, C.[County Name], Fmt_Reference_Doc_Number
		From [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL] as A 
		join [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] as B on A.[INPUT KEY] = B.RAW_ID
		join [global].[dbo].[county] as C with(NOLOCK) on B.FIPS = C.FIPSCODE
		Order by [INPUT KEY], Recordingdt desc


		Delete from [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]
		where Doc_Category in ('LEV','ASR','UCC')


		--Select top 10 * from 
		--(Select FIPS, STATE, County,DTDB_Ref_ID,Recordingdt, Doc_Category, DocType, DocumentTitle, DocNbrSrce, Fmt_Reference_Doc_Number
		--,amount_due, amount_of_default, judgment_amount, unpaid_prinicipal_amount
		--From data.dbo.v_INVL with(NOLOCK)
		--where 
		--FIPS like '48%'
		--and Doc_Category like 'MLN'
		--and DocType like 'MLNREL'
		--and Recordingdt > 20210101)A
		--join 
		--(Select FIPS, STATE, County,DTDB_Ref_ID,Recordingdt, Doc_Category, DocType, DocumentTitle, DocNbrSrce, cmt_docnumber
		--,amount_due, amount_of_default, judgment_amount, unpaid_prinicipal_amount
		--From data.dbo.v_INVL with(NOLOCK)
		--where 
		--FIPS like '48%'
		--and Doc_Category like 'AFF'
		--and DocType like 'AFFMLN'
		--and Recordingdt > 20210101)B on 
		--A.FIPS = B.FIPS and A.DTDB_Ref_ID = B.DTDB_Ref_ID
		--and A.Fmt_Reference_Doc_Number = B.cmt_docnumber


		--Select FIPS, STATE, County,DTDB_Ref_ID,Recordingdt, Doc_Category, DocType, DocumentTitle, DocNbrSrce, Fmt_Reference_Doc_Number
		--,amount_due, amount_of_default, judgment_amount, unpaid_prinicipal_amount
		--From data.dbo.v_INVL with(NOLOCK)
		--where 
		--FIPS like '48%'
		--and DTDB_REF_ID = 129568597
		--Order by Recordingdt desc



		---------20240202 -----REMOVE ALL RECORDS IF ONLY RELEASES PRESENT per EC:
		--Delete from A
		----Select * 
		--From INVL_BULK_PULL as A 
		--join (
		--Select A.[INPUT KEY] , A.TOTAL_ALL ,B.TOTAL_REL ,A.TOTAL_ALL - B.TOTAL_REL as [DIFF] 
		--from 
		--(Select [INPUT KEY],  count(*) as TOTAL_ALL From INVL_BULK_PULL with(NOLOCK)
		--Group by [INPUT KEY])A

		--left outer join 
		--(Select [INPUT KEY],  count(*) as TOTAL_REL From INVL_BULK_PULL  with(NOLOCK)
		--where LTRIM(RTRIM(DocType)) in ('ABJPRL','ABJREL','AFFLENREL','AGRCHTPRL','AGRCHTREL','AGRCPRPRL','AGRCPRREL','AGRDEDPRL'
		--,'AGRDFRREL','AGRDVLPRL','AGRLENREL','AGRPRL','AGRREL','AGRRMBREL','AGRSECREL','AGRSETREL','AGRSLEPRL','AGRSLEREL','AGRZONREL','ALNENGREL'
		--,'ALNPRL','ALNREL','ANMREL','ASRPRL','ASRREL','BKYPRL','BKYREL','BNDPRL','BNDREL','BUSREL','CAVREL','CCRPRL','CCRREL','CERREL','COVAGRREL'
		--,'COVPRL','COVREL','CTRDEDREL','CTRPRL','CTRREL','DCLPRL','DCLREL','EASPRL','EASREL','ELNPRL','ELNREL','EXCPRL','EXCREL','FLNPRL','FLNREL'
		--,'INJPRL','INJREL','JDGLENREL','JDGPRL','JDGREL','LENCNTPRL','LENCNTREL','LENCTYPRL','LENCTYREL','LENDOJPRL','LENDOJREL','LENMEDPRL'
		--,'LENMEDREL','LENOGLREL','LENPRL','LENREL','LEVPRL','LEVREL','LISHLNPRL','LISHLNREL','LISMLNPRL','LISMLNREL','LISMTGPRL','LISMTGREL'
		--,'LISPRL','LISREL','LLCREL','LSEASNPRL','LSEASNREL','LSEBREREL','LSEPRL','LSEREL','LSESUBREL','MLNPRL','MLNREL','NOTCMCPRL','NOTCMCREL'
		--,'NOTISTPRL','NOTISTREL','NOTLFEREL','NOTLIBREL','NOTNNRREL','NOTPLDREL','NOTPRL','NOTREL','NOTSWRREL','NOTWTRREL','NTEPRL','NTEREL'
		--,'ODNREL','OGLPRL','OGLREL','OPTPRL','OPTREL','ORDPRL','ORDREL','ORDWRL','PERREL','PETREL','POAPRL','POAREL','POLPRL','POLREL','PRL'
		--,'PRODCRREL','PROJDGPRL','PROJDGREL','PROSLEREL','PTRPRL','REL','RELAFF','REQPRLDOT','REQPRLMTG','REQRELDOT','REQRELMTG','REQRELVAC','RESREL'
		--,'ROYPRL','SLNPRL','SLNREL','SUPJDGPRL','SUPLENPRL','SUPLENREL','SUPREL','TNMREL','UCCPRL','UCCREL','VLNPRL','VLNREL','WAIPRL','WAIREL'
		--,'WRTPRL','WRTREL')
		--Group by [INPUT KEY])B
		--on A.[INPUT KEY] = B.[INPUT KEY])B 
		--on A.[INPUT KEY] = B.[INPUT KEY]
		--where B.[DIFF] = 0


		Update [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]
		Set
		Recordingdt = CONVERT(varchar(10), convert(date,Recordingdt,126), 101)
		,DocumentDt = CONVERT(varchar(10), convert(date,DocumentDt,126), 101)
		,doc_filing_date = CONVERT(varchar(10), convert(date,doc_filing_date,126), 101)
		



		
		Update [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]
		Set ROWNUM = NULL

			UPDATE [zCust_StateBankIndia_CA].[dbo].[t] 
			SET T.ROWNUM = R.RowNum2
			FROM [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUT KEY] ORDER BY REcordingDt DESC) AS RowNum2
				FROM 
			[zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL] t  ) r ON t.[INPUT KEY] = r.[INPUT KEY] AND t.TransactionID = r.TransactionID
			 
				
		
		
		Select max(convert(int,ROWNUM )) from [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]


		Select * From [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]
		where ROWNUM is null

		Select A.* From  [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL] as A 
		join (
		Select [INPUT KEY], ROWNUM, count(*) T From [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL]
		Group by [INPUT KEY], ROWNUM
		having count(*) > 1) B on A.[INPUT KEY] = B.[INPUT KEY]
		and A.ROWNUM = B.ROWNUM
		Order by A.[INPUT KEY]

		
		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Set [Nbr of Recordings] = NULL
		where convert(int,[Nbr of Recordings]) > 0


		UPDATE [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Nbr of Recordings] = 
		--case when b.NbrOfRecordings > 30 then '30' else 
		b.NbrOfRecordings 
		--end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a JOIN (SELECT [INPUT KEY],MAX(ROWNUM) NbrOfRecordings FROM [zCust_StateBankIndia_CA].[dbo].[INVL_BULK_PULL] GROUP BY [INPUT KEY]) b
		on a.[INPUT Unique ID] = b.[INPUT KEY]

		Select max(convert(bigint,[Nbr of Recordings])) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]

		--Select * From x_custom_OUTPUT_S28

		IF (Select count(*) from [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		where [Nbr of Recordings] > 0 ) > 0

		BEGIN
			
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Record_Number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [DocumentYear] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Recording_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Filing_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Number_Source] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Book_Source] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Page_Source] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Category] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Type_ID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Document_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [DocumentTitle] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [case_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [case_book] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [case_page] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [date_of_death] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [account_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [amendment_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [attorney_bar_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [bond_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [lot_line_adjustment_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [certificate_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [claim_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [contract_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [corporation_number] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [excise_tax_number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Federal_Tax_Lien_Area] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Federal_Tax_Lien_Area_Phone] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Last_Day_for_Refiling] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Period_Begin_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Period_End_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Interest_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Penalty_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Judgment_Amount] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [judgment_grand_total] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [installment_judgment] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [license_number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Lien_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Map_Plat_ID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Mechanics_Lien_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Ordinance_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Patent_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Permit_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Resolution_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Account_Serial_Warrant_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Tax_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Trustees_Sale_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [UCC_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Undersigned_Same_as_Borrower] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Amount_Due] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Amount_of_Default] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Bond_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Cash_Down_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Contract_Amount] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Collection_Costs] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Unpaid_Balance] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Unpaid_Balance_as_of_Modification_Date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Unpaid_Principal_Amount] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [date_of_divorce] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [support_arrears_amount] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [support_payment_amount] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [support_total_amount] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [date_Amount_Due] [varchar](250) NULL')
			----EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [date_stay_ordered] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_FullName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_last_Company_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_First_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Middle_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Suffix] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Role_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_MailPropertyID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Address] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_PreDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_StreetNumber] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_StreetName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_PostDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_StreetType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_SuiteType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Suite] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_City] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_State] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_Zip] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name1_ZipPlus4] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_FullName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_last_Company_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_First_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Middle_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Suffix] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Role_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_MailPropertyID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Address] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_PreDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_StreetNumber] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_StreetName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_PostDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_StreetType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_SuiteType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Suite] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_City] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_State] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_Zip] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party1_Name2_ZipPlus4] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_FullName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_last_Company_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_First_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Middle_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Suffix] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Role_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_MailPropertyID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Address] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_PreDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_StreetNumber] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_StreetName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_PostDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_StreetType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_SuiteType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Suite] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_City] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_State] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_Zip] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name1_ZipPlus4] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_FullName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_last_Company_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_First_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Middle_Name] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Suffix] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Role_Type] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_MailPropertyID] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Address] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_PreDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_StreetNumber] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_StreetName] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_PostDir] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_StreetType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_SuiteType] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Suite] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_City] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_State] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_Zip] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Party2_Name2_ZipPlus4] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [InactiveFlag] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Reference_recording_year] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [reference_recording_date] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [reference_doc_number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [reference_book] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [reference_page] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Fmt_Reference_Doc_Number] [varchar](250) NULL')
			--EXEC('ALTER Table x_custom_OUTPUT_S28 ADD [Fmt_Reference_BookPAge] [varchar](250) NULL')







			EXEC('UPDATE a
			SET 
				A. [Record_Number] = B.ROWNUM
				--,A.[DocumentYear] = B.DocumentYear
				,A.[Recording_Date] = B.Recordingdt
				,A.[Document_Date] = B.DocumentDt
				,A.[Document_Filing_Date] = B.doc_filing_date
				,A.[Document_Number_Source] = B.DocNbrSrce
				,A.[Book_Source] = B.BookSrce
				,A.[Page_Source] = B.PaceSrce
				,A.[Document_Category] = B.Doc_Category
				--,A.[Document_Type_ID] = B.DocTypeID
				,A.[Document_Type] = B.DocType
				,A.[DocumentTitle] = B.DocumentTitle
				--,A.[case_number] = B.case_number
				--,A.[case_book] = B.case_book
				--,A.[case_page] = B.case_page
				--,A.[date_of_death] = B.date_of_death
				--,A.[account_number] = B.account_number
				--,A.[amendment_number] = B.amendment_number
				--,A.[attorney_bar_number] = B.attorney_bar_number
				--,A.[bond_number] = B.bond_number
				--,A.[lot_line_adjustment_number] = B.lot_line_adjustment_number
				--,A.[certificate_number] = B.certificate_number
				--,A.[claim_number] = B.claim_number
				--,A.[contract_number] = B.contract_number
				--,A.[corporation_number] = B.corporation_number
				--,A.[excise_tax_number] = B.excise_tax_number
				,A.[Federal_Tax_Lien_Area] = B.Federal_Tax_Lien_Area
				,A.[Federal_Tax_Lien_Area_Phone] = B.Federal_Tax_Lien_Area_Phone
				,A.[Tax_Last_Day_for_Refiling] = B.Tax_Last_Day_for_Refiling
				,A.[Tax_Period_Begin_Date] = B.Tax_Period_Begin_Date
				,A.[Tax_Period_End_Date] = B.Tax_Period_End_Date
				,A.[Tax_Amount] = B.Tax_Amount
				,A.[Tax_Interest_Amount] = B.Tax_Interest_Amount
				,A.[Tax_Penalty_Amount] = B.Tax_Penalty_Amount
				,A.[Judgment_Amount] = B.Judgment_Amount
				--,A.[judgment_grand_total] = B.judgment_grand_total
				--,A.[installment_judgment] = B.installment_judgment
				--,A.[license_number] = B.license_number
				,A.[Lien_Number] = B.Lien_Number
				,A.[Map_Plat_ID] = B.Map_Plat_ID
				,A.[Mechanics_Lien_Number] = B.Mechanics_Lien_Number
				,A.[Ordinance_Number] = B.Ordinance_Number
				,A.[Patent_Number] = B.Patent_Number
				,A.[Permit_Number] = B.Permit_Number
				,A.[Resolution_Number] = B.Resolution_Number
				,A.[Tax_Account_Serial_Warrant_Number] = B.Tax_Account_Serial_Warrant_Number
				,A.[Tax_Type] = B.Tax_Type
				,A.[Trustees_Sale_Number] = B.Trustees_Sale_Number
				,A.[UCC_Number] = B.UCC_Number
				,A.[Undersigned_Same_as_Borrower] = B.Undersigned_Same_as_Borrower
				,A.[Amount_Due] = B.Amount_Due
				,A.[Amount_of_Default] = B.Amount_of_Default
				,A.[Bond_Amount] = B.Bond_Amount
				,A.[Cash_Down_Amount] = B.Cash_Down_Amount
				,A.[Contract_Amount] = B.Contract_Amount
				,A.[Collection_Costs] = B.Collection_Costs
				,A.[Unpaid_Balance] = B.Unpaid_Balance
				,A.[Unpaid_Balance_as_of_Modification_Date] = B.Unpaid_Balance_as_of_Modification_Date
				,A.[Unpaid_Principal_Amount] = B.unpaid_prinicipal_amount
				--,A.[date_of_divorce] = B.date_of_divorce
				--,A.[support_arrears_amount] = B.support_arrears_amount
				--,A.[support_payment_amount] = B.support_payment_amount
				--,A.[support_total_amount] = B.support_total_amount
				--,A.[date_Amount_Due] = B.date_Amount_Due
				--,A.[date_stay_ordered] = B.date_stay_ordered
				
				,A.[Party1_Name1_FullName] = B.[Party1_Name1_FullName]
				,A.[Party1_Name1_last_Company_Name] = B.[Party1_Name1_last_Company_Name]
				,A.[Party1_Name1_First_Name] = B.[Party1_Name1_First_Name]
				,A.[Party1_Name1_Middle_Name] = B.[Party1_Name1_Middle_Name]
				,A.[Party1_Name1_Suffix] = B.[Party1_Name1_Suffix]
				,A.[Party1_Name1_Role_Type] = B.[Party1_Name1_Roll_Type]
				,A.[Party1_Name1_MailPropertyID] = B.[Party1_Name1_MailPropertyID]
				,A.[Party1_Name1_Address] = B.[Party1_Name1_Address]
				,A.[Party1_Name1_PreDir] = B.[Party1_Name1_PreDir]
				,A.[Party1_Name1_StreetNumber] = B.[Party1_Name1_StreetNumber]
				,A.[Party1_Name1_StreetName] = B.[Party1_Name1_StreetName]
				,A.[Party1_Name1_PostDir] = B.[Party1_Name1_PostDir]
				,A.[Party1_Name1_StreetType] = B.[Party1_Name1_StreetType]
				,A.[Party1_Name1_SuiteType] = B.[Party1_Name1_SuiteType]
				,A.[Party1_Name1_Suite] = B.[Party1_Name1_Suite]
				,A.[Party1_Name1_City] = B.[Party1_Name1_City]
				,A.[Party1_Name1_State] = B.[Party1_Name1_State]
				,A.[Party1_Name1_Zip] = B.[Party1_Name1_Zip]
				,A.[Party1_Name1_ZipPlus4] = B.[Party1_Name1_ZipPlus4]
				,A.[Party1_Name2_FullName] = B.[Party1_Name2_FullName]
				,A.[Party1_Name2_last_Company_Name] = B.[Party1_Name2_last_Company_Name]
				,A.[Party1_Name2_First_Name] = B.[Party1_Name2_First_Name]
				,A.[Party1_Name2_Middle_Name] = B.[Party1_Name2_Middle_Name]
				,A.[Party1_Name2_Suffix] = B.[Party1_Name2_Suffix]
				,A.[Party1_Name2_Role_Type] = B.[Party1_Name2_Roll_Type]
				,A.[Party1_Name2_MailPropertyID] = B.[Party1_Name2_MailPropertyID]
				,A.[Party1_Name2_Address] = B.[Party1_Name2_Address]
				,A.[Party1_Name2_PreDir] = B.[Party1_Name2_PreDir]
				,A.[Party1_Name2_StreetNumber] = B.[Party1_Name2_StreetNumber]
				,A.[Party1_Name2_StreetName] = B.[Party1_Name2_StreetName]
				,A.[Party1_Name2_PostDir] = B.[Party1_Name2_PostDir]
				,A.[Party1_Name2_StreetType] = B.[Party1_Name2_StreetType]
				,A.[Party1_Name2_SuiteType] = B.[Party1_Name2_SuiteType]
				,A.[Party1_Name2_Suite] = B.[Party1_Name2_Suite]
				,A.[Party1_Name2_City] = B.[Party1_Name2_City]
				,A.[Party1_Name2_State] = B.[Party1_Name2_State]
				,A.[Party1_Name2_Zip] = B.[Party1_Name2_Zip]
				,A.[Party1_Name2_ZipPlus4] = B.[Party1_Name2_ZipPlus4]
				,A.[Party2_Name1_FullName] = B.[Party2_Name1_FullName]
				,A.[Party2_Name1_last_Company_Name] = B.[Party2_Name1_last_Company_Name]
				,A.[Party2_Name1_First_Name] = B.[Party2_Name1_First_Name]
				,A.[Party2_Name1_Middle_Name] = B.[Party2_Name1_Middle_Name]
				,A.[Party2_Name1_Suffix] = B.[Party2_Name1_Suffix]
				,A.[Party2_Name1_Role_Type] = B.[Party2_Name1_Roll_Type]
				,A.[Party2_Name1_MailPropertyID] = B.[Party2_Name1_MailPropertyID]
				,A.[Party2_Name1_Address] = B.[Party2_Name1_Address]
				,A.[Party2_Name1_PreDir] = B.[Party2_Name1_PreDir]
				,A.[Party2_Name1_StreetNumber] = B.[Party2_Name1_StreetNumber]
				,A.[Party2_Name1_StreetName] = B.[Party2_Name1_StreetName]
				,A.[Party2_Name1_PostDir] = B.[Party2_Name1_PostDir]
				,A.[Party2_Name1_StreetType] = B.[Party2_Name1_StreetType]
				,A.[Party2_Name1_SuiteType] = B.[Party2_Name1_SuiteType]
				,A.[Party2_Name1_Suite] = B.[Party2_Name1_Suite]
				,A.[Party2_Name1_City] = B.[Party2_Name1_City]
				,A.[Party2_Name1_State] = B.[Party2_Name1_State]
				,A.[Party2_Name1_Zip] = B.[Party2_Name1_Zip]
				,A.[Party2_Name1_ZipPlus4] = B.[Party2_Name1_ZipPlus4]
				,A.[Party2_Name2_FullName] = B.[Party2_Name2_FullName]
				,A.[Party2_Name2_last_Company_Name] = B.[Party2_Name2_last_Company_Name]
				,A.[Party2_Name2_First_Name] = B.[Party2_Name2_First_Name]
				,A.[Party2_Name2_Middle_Name] = B.[Party2_Name2_Middle_Name]
				,A.[Party2_Name2_Suffix] = B.[Party2_Name2_Suffix]
				,A.[Party2_Name2_Role_Type] = B.[Party2_Name2_Roll_Type]
				,A.[Party2_Name2_MailPropertyID] = B.[Party2_Name2_MailPropertyID]
				,A.[Party2_Name2_Address] = B.[Party2_Name2_Address]
				,A.[Party2_Name2_PreDir] = B.[Party2_Name2_PreDir]
				,A.[Party2_Name2_StreetNumber] = B.[Party2_Name2_StreetNumber]
				,A.[Party2_Name2_StreetName] = B.[Party2_Name2_StreetName]
				,A.[Party2_Name2_PostDir] = B.[Party2_Name2_PostDir]
				,A.[Party2_Name2_StreetType] = B.[Party2_Name2_StreetType]
				,A.[Party2_Name2_SuiteType] = B.[Party2_Name2_SuiteType]
				,A.[Party2_Name2_Suite] = B.[Party2_Name2_Suite]
				,A.[Party2_Name2_City] = B.[Party2_Name2_City]
				,A.[Party2_Name2_State] = B.[Party2_Name2_State]
				,A.[Party2_Name2_Zip] = B.[Party2_Name2_Zip]
				,A.[Party2_Name2_ZipPlus4] = B.[Party2_Name2_ZipPlus4]
				,A.[InactiveFlag] = B.[InactiveFlag]
				,A.[Reference_recording_year] = B.[Reference_recording_year]
				,A.[reference_recording_date] = B.[reference_recording_date]
				,A.[reference_doc_number] = B.[reference_doc_number]
				,A.[reference_book] = B.[reference_book]
				,A.[reference_page] = B.[reference_page]
				,A.[Fmt_Reference_Doc_Number] = B.[Fmt_Reference_Doc_Number]
				,A.[Fmt_Reference_BookPAge] = B.[Fmt_Reference_BookPAge]


				--Select * from x_custom_OUTPUT_S28

			FROM x_custom_OUTPUT_S28 a JOIN  INVL_BULK_PULL as B 
			on a.[INPUT Unique ID] = b.[INPUT KEY]
			WHERE B.ROWNUM = 1
			')

		END
		
		----------------------------------------BUILD DOWN    ------------------------------------
		IF (Select max(convert(int,[Nbr of Recordings])) from [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]) > 1
		BEGIN
		
		Truncate table dbo.BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_StateBankIndia_CA].[dbo].[BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_StateBankIndia_CA].[sys].[tables] as A join [zCust_StateBankIndia_CA].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_custom_OUTPUT_S28'
			and B.Name not in ('Record_Number'
			,'Recording_Date',	'Document_Date',	'Document_Filing_Date',	'Document_Number_Source',	'Book_Source',	'Page_Source',	'Document_Category',
			'Document_Type',	'DocumentTitle',	'Federal_Tax_Lien_Area',	'Federal_Tax_Lien_Area_Phone',	'Tax_Last_Day_for_Refiling',	'Tax_Period_Begin_Date',	
			'Tax_Period_End_Date',	'Tax_Amount',	'Tax_Interest_Amount',	'Tax_Penalty_Amount',	'Judgment_Amount',	'Lien_Number',	'Map_Plat_ID',
			'Mechanics_Lien_Number',	'Ordinance_Number',	'Patent_Number',	'Permit_Number',	'Resolution_Number',	'Tax_Account_Serial_Warrant_Number',	
			'Tax_Type',	'Trustees_Sale_Number',	'UCC_Number',	'Undersigned_Same_as_Borrower',	'Amount_Due',	'Amount_of_Default',	'Bond_Amount',	
			'Cash_Down_Amount',	'Contract_Amount',	'Collection_Costs',	'Unpaid_Balance',	'Unpaid_Balance_as_of_Modification_Date',	'Unpaid_Principal_Amount',
			'Party1_Name1_FullName',	'Party1_Name1_last_Company_Name',	'Party1_Name1_First_Name',	'Party1_Name1_Middle_Name',	'Party1_Name1_Suffix',	
			'Party1_Name1_Role_Type',	'Party1_Name1_MailPropertyID',	'Party1_Name1_Address',	'Party1_Name1_PreDir',	'Party1_Name1_StreetNumber',	
			'Party1_Name1_StreetName',	'Party1_Name1_PostDir',	'Party1_Name1_StreetType',	'Party1_Name1_SuiteType',	'Party1_Name1_Suite',	'Party1_Name1_City',
			'Party1_Name1_State',	'Party1_Name1_Zip',	'Party1_Name1_ZipPlus4',	'Party1_Name2_FullName',	'Party1_Name2_last_Company_Name',	
			'Party1_Name2_First_Name',	'Party1_Name2_Middle_Name',	'Party1_Name2_Suffix',	'Party1_Name2_Role_Type',	'Party1_Name2_MailPropertyID',
			'Party1_Name2_Address',	'Party1_Name2_PreDir',	'Party1_Name2_StreetNumber',	'Party1_Name2_StreetName',	'Party1_Name2_PostDir',	'Party1_Name2_StreetType',
			'Party1_Name2_SuiteType',	'Party1_Name2_Suite',	'Party1_Name2_City',	'Party1_Name2_State',	'Party1_Name2_Zip',	'Party1_Name2_ZipPlus4',
			'Party2_Name1_FullName',	'Party2_Name1_last_Company_Name',	'Party2_Name1_First_Name',	'Party2_Name1_Middle_Name',	'Party2_Name1_Suffix',	
			'Party2_Name1_Role_Type',	'Party2_Name1_MailPropertyID',	'Party2_Name1_Address',	'Party2_Name1_PreDir',	'Party2_Name1_StreetNumber',	
			'Party2_Name1_StreetName',	'Party2_Name1_PostDir',	'Party2_Name1_StreetType',	'Party2_Name1_SuiteType',	'Party2_Name1_Suite',	'Party2_Name1_City',
			'Party2_Name1_State',	'Party2_Name1_Zip',	'Party2_Name1_ZipPlus4',	'Party2_Name2_FullName',	'Party2_Name2_last_Company_Name',	'Party2_Name2_First_Name',	
			'Party2_Name2_Middle_Name',	'Party2_Name2_Suffix',	'Party2_Name2_Role_Type',	'Party2_Name2_MailPropertyID',	'Party2_Name2_Address',	'Party2_Name2_PreDir',
			'Party2_Name2_StreetNumber',	'Party2_Name2_StreetName',	'Party2_Name2_PostDir',	'Party2_Name2_StreetType',	'Party2_Name2_SuiteType',	'Party2_Name2_Suite',	
			'Party2_Name2_City',	'Party2_Name2_State',	'Party2_Name2_Zip',	'Party2_Name2_ZipPlus4',	'InactiveFlag',	'Reference_recording_year',	
			'reference_recording_date',	'reference_doc_number',	'reference_book',	'reference_page',	'Fmt_Reference_Doc_Number',	'Fmt_Reference_BookPAge')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.BUILD_DOWN_COLUMNS

		--Select * From x_custom_OUTPUT_S28


				

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_StateBankIndia_CA].[dbo].[BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_StateBankIndia_CA].[dbo].[BUILD_DOWN_COLUMNS])



								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[Nbr of Recordings])) FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

										--Select * From x_custom_OUTPUT_S28
				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_custom_OUTPUT_S28(
												' +  @FIELDLIST3 + '

												    ,[Record_Number]
												    ,[Recording_Date]
													,[Document_Date]
													,[Document_Filing_Date]
													,[Document_Number_Source]
													,[Book_Source]
													,[Page_Source]
													,[Document_Category]
													,[Document_Type]
													,[DocumentTitle]
													,[Federal_Tax_Lien_Area]
													,[Federal_Tax_Lien_Area_Phone]
													,[Tax_Last_Day_for_Refiling]
													,[Tax_Period_Begin_Date]
													,[Tax_Period_End_Date]
													,[Tax_Amount]
													,[Tax_Interest_Amount]
													,[Tax_Penalty_Amount]
													,[Judgment_Amount]
													,[Lien_Number]
													,[Map_Plat_ID]
													,[Mechanics_Lien_Number]
													,[Ordinance_Number]
													,[Patent_Number]
													,[Permit_Number]
													,[Resolution_Number]
													,[Tax_Account_Serial_Warrant_Number]
													,[Tax_Type]
													,[Trustees_Sale_Number]
													,[UCC_Number]
													,[Undersigned_Same_as_Borrower]
													,[Amount_Due]
													,[Amount_of_Default]
													,[Bond_Amount]
													,[Cash_Down_Amount]
													,[Contract_Amount]
													,[Collection_Costs]
													,[Unpaid_Balance]
													,[Unpaid_Balance_as_of_Modification_Date]
													,[Unpaid_Principal_Amount]
													,[Party1_Name1_FullName]
													,[Party1_Name1_last_Company_Name]
													,[Party1_Name1_First_Name]
													,[Party1_Name1_Middle_Name]
													,[Party1_Name1_Suffix]
													,[Party1_Name1_Role_Type]
													,[Party1_Name1_MailPropertyID]
													,[Party1_Name1_Address]
													,[Party1_Name1_PreDir]
													,[Party1_Name1_StreetNumber]
													,[Party1_Name1_StreetName]
													,[Party1_Name1_PostDir]
													,[Party1_Name1_StreetType]
													,[Party1_Name1_SuiteType]
													,[Party1_Name1_Suite]
													,[Party1_Name1_City]
													,[Party1_Name1_State]
													,[Party1_Name1_Zip]
													,[Party1_Name1_ZipPlus4]
													,[Party1_Name2_FullName]
													,[Party1_Name2_last_Company_Name]
													,[Party1_Name2_First_Name]
													,[Party1_Name2_Middle_Name]
													,[Party1_Name2_Suffix]
													,[Party1_Name2_Role_Type]
													,[Party1_Name2_MailPropertyID]
													,[Party1_Name2_Address]
													,[Party1_Name2_PreDir]
													,[Party1_Name2_StreetNumber]
													,[Party1_Name2_StreetName]
													,[Party1_Name2_PostDir]
													,[Party1_Name2_StreetType]
													,[Party1_Name2_SuiteType]
													,[Party1_Name2_Suite]
													,[Party1_Name2_City]
													,[Party1_Name2_State]
													,[Party1_Name2_Zip]
													,[Party1_Name2_ZipPlus4]
													,[Party2_Name1_FullName]
													,[Party2_Name1_last_Company_Name]
													,[Party2_Name1_First_Name]
													,[Party2_Name1_Middle_Name]
													,[Party2_Name1_Suffix]
													,[Party2_Name1_Role_Type]
													,[Party2_Name1_MailPropertyID]
													,[Party2_Name1_Address]
													,[Party2_Name1_PreDir]
													,[Party2_Name1_StreetNumber]
													,[Party2_Name1_StreetName]
													,[Party2_Name1_PostDir]
													,[Party2_Name1_StreetType]
													,[Party2_Name1_SuiteType]
													,[Party2_Name1_Suite]
													,[Party2_Name1_City]
													,[Party2_Name1_State]
													,[Party2_Name1_Zip]
													,[Party2_Name1_ZipPlus4]
													,[Party2_Name2_FullName]
													,[Party2_Name2_last_Company_Name]
													,[Party2_Name2_First_Name]
													,[Party2_Name2_Middle_Name]
													,[Party2_Name2_Suffix]
													,[Party2_Name2_Role_Type]
													,[Party2_Name2_MailPropertyID]
													,[Party2_Name2_Address]
													,[Party2_Name2_PreDir]
													,[Party2_Name2_StreetNumber]
													,[Party2_Name2_StreetName]
													,[Party2_Name2_PostDir]
													,[Party2_Name2_StreetType]
													,[Party2_Name2_SuiteType]
													,[Party2_Name2_Suite]
													,[Party2_Name2_City]
													,[Party2_Name2_State]
													,[Party2_Name2_Zip]
													,[Party2_Name2_ZipPlus4]
													,[InactiveFlag]
													,[Reference_recording_year]
													,[reference_recording_date]
													,[reference_doc_number]
													,[reference_book]
													,[reference_page]
													,[Fmt_Reference_Doc_Number]
													,[Fmt_Reference_BookPAge]


													)
												  
											  Select 
											
											   ' +  @FIELDLIST4 + '

												,B.ROWNUM
												--,B.DocumentYear
												,B.Recordingdt
												,B.DocumentDt
												,B.doc_filing_date
												,B.DocNbrSrce
												,B.BookSrce
												,B.PaceSrce
												,B.Doc_Category
												--,B.DocTypeID
												,B.DocType
												,B.DocumentTitle
												--,B.case_number
												--,B.case_book
												--,B.case_page
												--,B.date_of_death
												--,B.account_number
												--,B.amendment_number
												--,B.attorney_bar_number
												--,B.bond_number
												--,B.lot_line_adjustment_number
												--,B.certificate_number
												--,B.claim_number
												--,B.contract_number
												--,B.corporation_number
												--,B.excise_tax_number
												,B.Federal_Tax_Lien_Area
												,B.Federal_Tax_Lien_Area_Phone
												,B.Tax_Last_Day_for_Refiling
												,B.Tax_Period_Begin_Date
												,B.Tax_Period_End_Date
												,B.Tax_Amount
												,B.Tax_Interest_Amount
												,B.Tax_Penalty_Amount
												,B.Judgment_Amount
												--,B.judgment_grand_total
												--,B.installment_judgment
												--,B.license_number
												,B.Lien_Number
												,B.Map_Plat_ID
												,B.Mechanics_Lien_Number
												,B.Ordinance_Number
												,B.Patent_Number
												,B.Permit_Number
												,B.Resolution_Number
												,B.Tax_Account_Serial_Warrant_Number
												,B.Tax_Type
												,B.Trustees_Sale_Number
												,B.UCC_Number
												,B.Undersigned_Same_as_Borrower
												,B.Amount_Due
												,B.Amount_of_Default
												,B.Bond_Amount
												,B.Cash_Down_Amount
												,B.Contract_Amount
												,B.Collection_Costs
												,B.Unpaid_Balance
												,B.Unpaid_Balance_as_of_Modification_Date
												,B.unpaid_prinicipal_amount
												--,B.date_of_divorce
												--,B.support_arrears_amount
												--,B.support_payment_amount
												--,B.support_total_amount
												--,B.date_Amount_Due
												--,B.date_stay_ordered
												,B.[Party1_Name1_FullName]
												,B.[Party1_Name1_last_Company_Name]
												,B.[Party1_Name1_First_Name]
												,B.[Party1_Name1_Middle_Name]
												,B.[Party1_Name1_Suffix]
												,B.[Party1_Name1_Roll_Type]
												,B.[Party1_Name1_MailPropertyID]
												,B.[Party1_Name1_Address]
												,B.[Party1_Name1_PreDir]
												,B.[Party1_Name1_StreetNumber]
												,B.[Party1_Name1_StreetName]
												,B.[Party1_Name1_PostDir]
												,B.[Party1_Name1_StreetType]
												,B.[Party1_Name1_SuiteType]
												,B.[Party1_Name1_Suite]
												,B.[Party1_Name1_City]
												,B.[Party1_Name1_State]
												,B.[Party1_Name1_Zip]
												,B.[Party1_Name1_ZipPlus4]
												,B.[Party1_Name2_FullName]
												,B.[Party1_Name2_last_Company_Name]
												,B.[Party1_Name2_First_Name]
												,B.[Party1_Name2_Middle_Name]
												,B.[Party1_Name2_Suffix]
												,B.[Party1_Name2_Roll_Type]
												,B.[Party1_Name2_MailPropertyID]
												,B.[Party1_Name2_Address]
												,B.[Party1_Name2_PreDir]
												,B.[Party1_Name2_StreetNumber]
												,B.[Party1_Name2_StreetName]
												,B.[Party1_Name2_PostDir]
												,B.[Party1_Name2_StreetType]
												,B.[Party1_Name2_SuiteType]
												,B.[Party1_Name2_Suite]
												,B.[Party1_Name2_City]
												,B.[Party1_Name2_State]
												,B.[Party1_Name2_Zip]
												,B.[Party1_Name2_ZipPlus4]
												,B.[Party2_Name1_FullName]
												,B.[Party2_Name1_last_Company_Name]
												,B.[Party2_Name1_First_Name]
												,B.[Party2_Name1_Middle_Name]
												,B.[Party2_Name1_Suffix]
												,B.[Party2_Name1_Roll_Type]
												,B.[Party2_Name1_MailPropertyID]
												,B.[Party2_Name1_Address]
												,B.[Party2_Name1_PreDir]
												,B.[Party2_Name1_StreetNumber]
												,B.[Party2_Name1_StreetName]
												,B.[Party2_Name1_PostDir]
												,B.[Party2_Name1_StreetType]
												,B.[Party2_Name1_SuiteType]
												,B.[Party2_Name1_Suite]
												,B.[Party2_Name1_City]
												,B.[Party2_Name1_State]
												,B.[Party2_Name1_Zip]
												,B.[Party2_Name1_ZipPlus4]
												,B.[Party2_Name2_FullName]
												,B.[Party2_Name2_last_Company_Name]
												,B.[Party2_Name2_First_Name]
												,B.[Party2_Name2_Middle_Name]
												,B.[Party2_Name2_Suffix]
												,B.[Party2_Name2_Roll_Type]
												,B.[Party2_Name2_MailPropertyID]
												,B.[Party2_Name2_Address]
												,B.[Party2_Name2_PreDir]
												,B.[Party2_Name2_StreetNumber]
												,B.[Party2_Name2_StreetName]
												,B.[Party2_Name2_PostDir]
												,B.[Party2_Name2_StreetType]
												,B.[Party2_Name2_SuiteType]
												,B.[Party2_Name2_Suite]
												,B.[Party2_Name2_City]
												,B.[Party2_Name2_State]
												,B.[Party2_Name2_Zip]
												,B.[Party2_Name2_ZipPlus4]
												,B.[InactiveFlag]
												,B.[Reference_recording_year]
												,B.[reference_recording_date]
												,B.[reference_doc_number]
												,B.[reference_book]
												,B.[reference_page]
												,B.[Fmt_Reference_Doc_Number]
												,B.[Fmt_Reference_BookPAge]








										--Select B.[unpaid_prinicipal_amount]
										--Select B.*
										FROM x_custom_OUTPUT_S28 a JOIN  INVL_BULK_PULL as B 
										on a.[INPUT Unique ID] = b.[INPUT KEY]
										WHERE B.ROWNUM = ''' + @BeginNbrOfTrans6 + '''
										AND A.[Record_Number] = ''1''
										')
										
										
												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

						
			--END

			END

			--Select [INPUT Unique ID],[Number_of_Recordings],[Record_Number] From x_custom_OUTPUT_S28
			--where [Number_of_Recordings] > 0
			--Order by [INPUT Unique ID],[Record_Number]

			
			IF (Select count(*) From  [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
			where [Nbr of Recordings] > 0) > 0

			BEGIN

			EXEC('

			--------DECODE Doc Type Category -----
			Select Document_Type, count(*) From x_custom_OUTPUT_S28
			where [Nbr of Recordings] > 0
			Group by Document_Type
			Order by Document_Type

			UPdate x_custom_OUTPUT_S28
			Set Document_Type = case 
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJ'' then ''ABSTRACT OF JUDGMENT''
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJAMD'' then ''ABSTRACT OF JUDGMENT AMENDMENT''
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJASN'' then ''ABSTRACT OF JUDGMENT ASSIGNMENT''
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJFED'' then ''FEDERAL ABSTRACT OF JUDGMENT''
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJPRL'' then ''ABSTRACT OF JUDGMENT PARTIAL RELEASE''
			when [Document_Category] like ''ABJ'' and Document_Type like ''ABJREL'' then ''ABSTRACT OF JUDGMENT  RELEASE''
			when [Document_Category] like ''ACK'' and Document_Type like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [Document_Category] like ''ACP'' and Document_Type like ''ACP'' then ''ACCEPTANCE''
			when [Document_Category] like ''AFD'' and Document_Type like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [Document_Category] like ''AFD'' and Document_Type like ''AFDTEE'' then ''AFFIDAVIT OF DEATH OF TRUSTEE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFF'' then ''AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFADD'' then ''AFFIDAVIT OF ADDRESS''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFAFX'' then ''AFFIDAVIT OF AFFIXTURE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFAUC'' then ''AFFIDAVIT OF AUCTIONEER''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFBKY'' then ''BANKRUPTCY AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFBUS'' then ''AFFIDAVIT OF CORPORATION''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCMC'' then ''AFFIDAVIT OF COMMENCEMENT/NON-COMMENCEMENT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCMP'' then ''AFFIDAVIT OF COMPLIANCE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCOV'' then ''AFFIDAVIT OF COVENANT AND AGREEMENT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCPR'' then ''COMMUNITY PROPERTY AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCPT'' then ''AFFIDAVIT OF COMPLETION''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFCUS'' then ''AFFIDAVIT OF CUSTODY OF MINOR''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFDED'' then ''AFFIDAVIT CONCERNING A DEED''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFDIV'' then ''AFFIDAVIT AS TO DIVORCE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFDOT'' then ''AFFIDAVIT AS TO DEED OF TRUST''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFEAS'' then ''AFFIDAVIT CONFINING EASEMENT IN TRACT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFERR'' then ''AFFIDAVIT OF SCRIVENERS ERROR/ERRONEOUS RECORDATION''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFETP'' then ''AFFIDAVIT OF ESTOPPEL''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFFOR'' then ''AFFIDAVIT OF FORFEITURE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFHEI'' then ''AFFIDAVIT OF HEIRSHIP''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFIDT'' then ''AFFIDAVIT OF IDENTITY''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFINH'' then ''AFFIDAVIT THAT NO INHERITANCE TAX IS DUE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFIST'' then ''AFFIDAVIT OF INTEREST''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFJDG'' then ''AFFIDAVIT AS TO JUDGMENT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFJTNTRM'' then ''AFFIDAVIT OF TERMINATION OF JOINT TENANCY <NO DEATH INVOLVED>''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLEN'' then ''AFFIDAVIT OF LIEN''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLENAGR'' then ''LIEN AGREEMENT AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLENREL'' then ''AFFIDAVIT OF RELEASE OF LIENS''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLOS'' then ''AFFIDAVIT OF LOST DOCUMENT <NOT DOT, MTG, NTE>''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLOSDOT'' then ''AFFIDAVIT OF LOST DEED OF TRUST''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLOSDTM'' then ''AFFIDAVIT OF LOST DEED OF TRUST/MORTGAGE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLOSMTG'' then ''AFFIDAVIT OF LOST MORTGAGE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFLOSNTE'' then ''AFFIDAVIT OF LOST NOTE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMAL'' then ''AFFIDAVIT OF MAILING''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMAP'' then ''MAP AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMAR'' then ''AFFIDAVIT OF MARITAL STATUS''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMGE'' then ''MORTGAGEES AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMLN'' then ''AFFIDAVIT FOR MECHANICS LIEN''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFMTGREL'' then ''AFFIDAVIT DOCUMENTING SATISFACTION OF MORTGAGE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFNAM'' then ''AFFIDAVIT OF SAME NAME''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFNCM'' then ''AFFIDAVIT OF NON-COMPLIANCE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFNMC'' then ''AFFIDAVIT OF NAME CHANGE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFOGL'' then ''OIL AND GAS LEASE AFFIDAVIT''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFPAY'' then ''AFFIDAVIT OF PAYMENT OF TAXES''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFPBL'' then ''AFFIDAVIT OF PUBLICATION''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFPOS'' then ''AFFIDAVIT OF POSSESSION''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFPUR'' then ''AFFIDAVIT OF PURCHASE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFSRV'' then ''AFFIDAVIT OF SERVICE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFTEE'' then ''AFFIDAVIT OF SUCCESSOR TRUSTEE''
			when [Document_Category] like ''AFF'' and Document_Type like ''AFFTOD'' then ''TRANSFER ON DEATH AFFIDAVIT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGR'' then ''AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRADV'' then ''ADDITIONAL ADVANCE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRAER'' then ''AVIATION AGREEMENT (AIRSPACE)''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRAFR'' then ''AFFORDABLE HOUSING AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRAMD'' then ''AMENDMENT OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRANX'' then ''ANNEXATION AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRASN'' then ''ASSIGNMENT OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRASP'' then ''ASSUMPTION AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRATR'' then ''ATTORNMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRBLD'' then ''BUILDING & LOAN AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCDO'' then ''CONDOMINIUM AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCHT'' then ''CHATTEL SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCHTPRL'' then ''PARTIAL RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCHTREL'' then ''RELEASE OF CHATTEL SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCPR'' then ''COMMUNITY PROPERTY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCPRMOD'' then ''MODIFICATION OF COMMUNITY PROPERTY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCPRPRL'' then ''PARTIAL RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCPRREL'' then ''RELEASE OF COMMUNITY PROPERTY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCRL'' then ''CROSS COLLATERALIZATION AND CROSS DEFAULT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRCSD'' then ''CONSOLIDATION AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDED'' then ''AGREEMENT FOR DEED''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDEDMOD'' then ''MODIFICATION OF AGREEMENT FOR DEED''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDEDPRL'' then ''PARTIAL RELEASE OF AGREEMENT FOR DEED''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDFR'' then ''DEFERRAL AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDFRREL'' then ''RELEASE OF DEFERRAL AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDIV'' then ''DIVORCE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDOT'' then ''DEED OF TRUST AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDVL'' then ''DEVELOPMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDVLASN'' then ''ASSIGNMENT OF DEVELOPMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDVLASP'' then ''ASSUMPTION OF DEVELOPMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRDVLPRL'' then ''PARTIAL RELEASE OF DEVELOPMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRENC'' then ''ENCROACHMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRENG'' then ''ENERGY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRENV'' then ''ENVIRONMENTAL INDEMNITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRESC'' then ''ESCROW AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRFAC'' then ''FACILITIES AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRFML'' then ''FARMLAND DEVELOPMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRFOR'' then ''AGREEMENT TO FORFEIT PROPERTY''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRIDM'' then ''INDEMNITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRJOI'' then ''JOINDER AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLEN'' then ''LIEN AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLENAMD'' then ''AMENDMENT TO LIEN AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLENREL'' then ''RELEASE OF LIEN AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLIC'' then ''LICENSE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLICREL'' then ''CANCELLATION OF LICENSE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLLA'' then ''AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLLAMOD'' then ''MODIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLLARAT'' then ''RATIFICATION OF AGREEMENT FOR BOUNDARY/LOT LINE ADJUSTMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLON'' then ''LOAN AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRLONMOD'' then ''LOAN MODIFICATION AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRMAI'' then ''ROAD MAINTENANCE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRMAR'' then ''MARRIAGE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRMER'' then ''MERGER AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRMOD'' then ''MODIFICATION OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRMTG'' then ''MORTGAGE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRNDA'' then ''NON-DISTURBANCE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRNEN'' then ''AGREEMENT NOT TO ENCUMBER''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGROGL'' then ''OIL AND GAS AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPAY'' then ''AGREEMENT FOR PAYMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPLD'' then ''NEGATIVE PLEDGE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPRL'' then ''PARTIAL RELEASE OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPUR'' then ''PURCHASE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPURREL'' then ''TERMINATION OF PURCHASE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRPWL'' then ''PARTY WALL AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRRAT'' then ''RATIFICATION OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRREG'' then ''REGULATORY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRREI'' then ''REINSTATEMENT OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRREL'' then ''RELEASE OF AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRRMB'' then ''AGREEMENT TO REIMBURSE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRRMBREL'' then ''RELEASE OF AGREEMENT TO REIMBURSE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSEC'' then ''SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSECASN'' then ''ASSIGNMENT OF SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSECREL'' then ''RELEASE OF SECURITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSEP'' then ''SEPARATION AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSET'' then ''SETTLEMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSETREL'' then ''RELEASE OF SETTLEMENT AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSIT'' then ''SITE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSITAMD'' then ''AMENDED SITE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLE'' then ''AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEAMD'' then ''AMENDMENT OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEASN'' then ''ASSIGNMENT OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEEXT'' then ''EXTENSION OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEMOD'' then ''MODIFICATION OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEPRL'' then ''PARTIAL RELEASE OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSLEREL'' then ''RELEASE OF AGREEMENT OF SALE''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRSWR'' then ''SEWER AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRUSE'' then ''USE AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRUTL'' then ''UTILITY AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRVIO'' then ''AGREEMENT TO CORRECT CODE VIOLATION''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRWTR'' then ''WATER AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRZON'' then ''ZONING AGREEMENT''
			when [Document_Category] like ''AGR'' and Document_Type like ''AGRZONREL'' then ''RELEASE OF ZONING AGREEMENT''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALN'' then ''ASSESSMENT LIEN''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNCFD'' then ''COMMUNITY FACILITIES DISTRICT LIEN''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [Document_Category] like ''AMD'' and Document_Type like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [Document_Category] like ''ANM'' and Document_Type like ''ANM'' then ''ASSUMED NAME''
			when [Document_Category] like ''ANM'' and Document_Type like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [Document_Category] like ''APL'' and Document_Type like ''APL'' then ''APPLICATION''
			when [Document_Category] like ''APL'' and Document_Type like ''APLAMD'' then ''APPLICATION AMENDMENT''
			when [Document_Category] like ''APL'' and Document_Type like ''APLASN'' then ''APPLICATION ASSIGNMENT''
			when [Document_Category] like ''ASR'' and Document_Type like ''ASR'' then ''ASSIGNMENT OF RENTS''
			when [Document_Category] like ''ASR'' and Document_Type like ''ASRAMD'' then ''ASSIGNMENT OF RENTS AMENDMENT''
			when [Document_Category] like ''ASR'' and Document_Type like ''ASRASN'' then ''ASSIGNMENT OF RENTS ASSIGNMENT''
			when [Document_Category] like ''ASR'' and Document_Type like ''ASRPRL'' then ''ASSIGNMENT OF RENTS PARTIAL RELEASE''
			when [Document_Category] like ''ASR'' and Document_Type like ''ASRREL'' then ''ASSIGNMENT OF RENTS  RELEASE''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKY'' then ''BANKRUPTCY''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYAMD'' then ''BANKRUPTCY AMENDMENT''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYCNV'' then ''BANKRUPTCY CONVERSION''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYDIS'' then ''BANKRUPTCY DISCHARGE''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYDSM'' then ''BANKRUPTCY DISMISSAL''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYJDG'' then ''BANKRUPTCY JUDGMENT''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYORD'' then ''BANKRUPTCY ORDER''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYPRL'' then ''BANKRUPTCY PARTIAL RELEASE''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYREL'' then ''BANKRUPTCY RELEASE''
			when [Document_Category] like ''BKY'' and Document_Type like ''BKYSPL'' then ''BANKRUPTCY SPLIT''
			when [Document_Category] like ''BND'' and Document_Type like ''BND'' then ''BOND''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDASN'' then ''BOND ASSIGNMENT''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDMLN'' then ''MECHANICS LIEN BOND''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDNTY'' then ''NOTARY BOND''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDPRL'' then ''BOND PARTIAL RELEASE''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDREL'' then ''BOND RELEASE''
			when [Document_Category] like ''BND'' and Document_Type like ''BNDSUR'' then ''SURETY BOND''
			when [Document_Category] like ''BSL'' and Document_Type like ''BSL'' then ''BILL OF SALE''
			when [Document_Category] like ''BSL'' and Document_Type like ''BSLASN'' then ''BILL OF SALE ASSIGNMENT''
			when [Document_Category] like ''BSL'' and Document_Type like ''BSLMOD'' then ''BILL OF SALE MODIFICATION''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSAMD'' then ''AMENDED BUSINESS CERTIFICATE''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSAUT'' then ''BUSINESS SIGNING AUTHORIZATION''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSFIC'' then ''AFFIDAVIT OF DOING BUSINESS UNDER FICTITIOUS NAME''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSLIQ'' then ''NOTICE OF INTENDED TRANSFER OF RETAIL ALCOHOLIC BEVERAGE LICENSE''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSMER'' then ''BUSINESS MERGER''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSREL'' then ''RELEASE OF BUSINESS CERTIFICATE''
			when [Document_Category] like ''BUS'' and Document_Type like ''BUSSLE'' then ''BUSINESS SALE''
			when [Document_Category] like ''CAV'' and Document_Type like ''CAV'' then ''CAVEAT''
			when [Document_Category] like ''CAV'' and Document_Type like ''CAVREL'' then ''CAVEAT RELEASE''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRACK'' then ''ACKNOWLEDGMENT OF DECLARATION OF RESTRICTIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRACP'' then ''ACCEPTANCE OF TERMS, COVENANT & CONDITIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRADP'' then ''ADOPTION & AFFIRMATION OF DECLARATION ESTABLISHING COVENANTS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRAMD'' then ''DECLARATION OF RESTRICTIONS AMENDMENT''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRANX'' then ''DECLARATION OF COVENANTS ANNEXATION''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRASN'' then ''ASSIGNMENT OF DECLARATION OF RESTRICTIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRBLD'' then ''DESIGNATION OF BUILDER UNDER DECLARATION OF RESTRICTIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRCNS'' then ''CONSENT TO DECLARATION OF RESTRICTIONS''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRMOD'' then ''DECLARATION OF RESTRICTIONS MODIFICATION''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRPET'' then ''PETITION FOR ANNEXATION & DECLARATION OF COVENANT''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRPRL'' then ''DECLARATION OF RESTRICTIONS PARTIAL RELEASE''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRRAT'' then ''COVENANTS & RESTRICTIONS RATIFICATION''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRREL'' then ''DECLARATION OF RESTRICTIONS RELEASE''
			when [Document_Category] like ''CCR'' and Document_Type like ''CCRUSE'' then ''DECLARATION OF RESTRICTIONS ON USE''
			when [Document_Category] like ''CER'' and Document_Type like ''CER'' then ''CERTIFICATE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERAMD'' then ''CERTIFICATE AMENDMENT''
			when [Document_Category] like ''CER'' and Document_Type like ''CERASN'' then ''CERTIFICATE ASSIGNMENT''
			when [Document_Category] like ''CER'' and Document_Type like ''CERCMP'' then ''CERTIFICATE OF COMPLIANCE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERCMPHOA'' then ''CERTIFICATE OF COMPLIANCE <HOA>''
			when [Document_Category] like ''CER'' and Document_Type like ''CERCOR'' then ''CERTIFICATE OF CORRECTION''
			when [Document_Category] like ''CER'' and Document_Type like ''CERCPT'' then ''CERTIFICATE OF COMPLETION''
			when [Document_Category] like ''CER'' and Document_Type like ''CERDEA'' then ''DEATH CERTIFICATE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERDST'' then ''CERTIFICATE OF DISTRIBUTION''
			when [Document_Category] like ''CER'' and Document_Type like ''CERERR'' then ''CERTIFICATE  OF SCRIVENERS ERROR''
			when [Document_Category] like ''CER'' and Document_Type like ''CERLLA'' then ''CERTIFICATE OF LOT LINE ADJUSTMENTS''
			when [Document_Category] like ''CER'' and Document_Type like ''CERMAR'' then ''CERTIFICATE OF MARRIAGE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERNCM'' then ''CERTIFICATE OF NON-COMPLIANCE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERNCMHOA'' then ''CERTIFICATE OF NON-COMPLIANCE <HOA>''
			when [Document_Category] like ''CER'' and Document_Type like ''CERREL'' then ''CERTIFICATE OF CANCELLATION/RELEASE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERSLE'' then ''CERTIFICATE OF SALE <NOT TAX OR FORECLOSURE>''
			when [Document_Category] like ''CER'' and Document_Type like ''CERTOR'' then ''TORRENS CERTIFICATE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERTTL'' then ''CERTIFICATE OF TITLE''
			when [Document_Category] like ''CER'' and Document_Type like ''CERWTR'' then ''CERTIFICATE OF WATER RIGHTS''
			when [Document_Category] like ''CHJ'' and Document_Type like ''CHJ'' then ''CHANGE OF JUDGE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNS'' then ''CONSENT''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSCDO'' then ''CONSENT TO CONDOMINIUM CONVERSION''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSCUS'' then ''CONSENT OF PARENT FOR TEMPORARY CUSTODY''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSDED'' then ''CONSENT TO DEED''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSDOT'' then ''CONSENT TO DEED OF TRUST''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSLSE'' then ''LANDORDS CONSENT TO  LEASE ASSIGNMENT/SUBLEASE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSMAP'' then ''CONSENT TO MAP''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSMTG'' then ''CONSENT TO MORTGAGE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSNTE'' then ''CONSENT TO NOTE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSOGL'' then ''CONSENT TO OIL AND GAS LEASE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSOPT'' then ''CONSENT OF OPTIONEE''
			when [Document_Category] like ''CNS'' and Document_Type like ''CNSRES'' then ''CONSENT & APPROVAL OF RESTRICTIONS''
			when [Document_Category] like ''COV'' and Document_Type like ''COV'' then ''COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVACK'' then ''ACKNOWLEGMENT OF COVENANTS''
			when [Document_Category] like ''COV'' and Document_Type like ''COVAGR'' then ''COVENANT AGREEMENT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVAGRAMD'' then ''AMENDMENT OF COVENANT AGREEMENT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVAGRREL'' then ''RELEASE OF COVENANT AGREEMENT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVAMD'' then ''AMENDMENT OF COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVCNS'' then ''CONSENT TO COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVEAS'' then ''DECLARATION OF EASEMENTS COVENANTS''
			when [Document_Category] like ''COV'' and Document_Type like ''COVENV'' then ''ENVIRONMENTAL COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVIMP'' then ''COVENANT OF IMPROVEMENTS''
			when [Document_Category] like ''COV'' and Document_Type like ''COVLLA'' then ''DECLARATION OF BOUNDARY LINE ADJUSTMENT & COVENANTS''
			when [Document_Category] like ''COV'' and Document_Type like ''COVMOD'' then ''COVENANT MODIFICATION''
			when [Document_Category] like ''COV'' and Document_Type like ''COVOPT'' then ''AFFORDABILITY COVENANT AND OPTION TO PURCHASE''
			when [Document_Category] like ''COV'' and Document_Type like ''COVPRK'' then ''COVENANT OF PARKING''
			when [Document_Category] like ''COV'' and Document_Type like ''COVPRL'' then ''PARTIAL RELEASE OF COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVREL'' then ''RELEASE OF COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVSLM'' then ''SUPPLEMENTAL DECLARATION OF COVENANTS''
			when [Document_Category] like ''COV'' and Document_Type like ''COVUSE'' then ''AGRICULTURAL STRUCTURE USE COVENANT''
			when [Document_Category] like ''COV'' and Document_Type like ''COVVAR'' then ''VARIANCE/SETABCK COVENANT''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRP'' then ''CORPORATION''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPAMD'' then ''CORPORATION AMENDMENT''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPBYL'' then ''CORPORATE BYLAWS''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPBYLAMD'' then ''AMENDMENT TO CORPORATE BYLAWS''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPBYLREL'' then ''REVOCATION OF CORPORATE BYLAWS''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPNMC'' then ''CORPORATION NAME CHANGE''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPREI'' then ''CORPORATION REINSTATEMENT''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPREL'' then ''REVOCATION OF CORPORATION''
			when [Document_Category] like ''CRP'' and Document_Type like ''CRPSPN'' then ''SUSPENSION OF CORPORATION''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTR'' then ''CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRAGL'' then ''WILLIAMSON ACT CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRAMD'' then ''CONTRACT AMENDMENT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRASN'' then ''CONTRACT ASSIGNMENT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRASP'' then ''CONTRACT ASSUMPTION''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRBRE'' then ''CONTRACT BREACH''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRCHT'' then ''PERSONAL PROPERTY CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRCHTASN'' then ''ASSIGNMENT OF PERSONAL PROPERTY CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRCST'' then ''CONSTRUCTION CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRDED'' then ''CONTRACT FOR DEED''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRDEDREL'' then ''CONTRACT FOR DEED RELEASE''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRENG'' then ''ENERGY CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRLON'' then ''LOAN CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRMAR'' then ''MARRIAGE CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRMOD'' then ''CONTRACT MODIFICATION''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTROGL'' then ''OIL & GAS CONTRACT''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRPRL'' then ''CONTRACT PARTIAL RELEASE''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRREI'' then ''CONTRACT REINSTATE''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRREL'' then ''CONTRACT RELEASE''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRSLE'' then ''CONTRACT OF SALE''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRUTL'' then ''CONTRACT FOR UTILITIES''
			when [Document_Category] like ''CTR'' and Document_Type like ''CTRWTR'' then ''CONTRACT FOR WATER RIGHTS''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCL'' then ''DECLARATION''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLAGL'' then ''DECLARATION OF WILLIAMSON ACT RESTRICTED LAND''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLAMD'' then ''DECLARATION AMENDMENT''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLDEA'' then ''DECLARATION OF DEATH''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLMAR'' then ''DECLARATION REGARDING MARRIAGE''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLPRL'' then ''DECLARATION PARTIAL RELEASE''
			when [Document_Category] like ''DCL'' and Document_Type like ''DCLREL'' then ''DECLARATION RELEASE''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCR'' then ''DECREE''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRDEA'' then ''DECREE ESTABLISHING FACT OF DEATH''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRDIV'' then ''DECREE OF DIVORCE''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRDST'' then ''DECREE OF DISTRIBUTION''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRLFE'' then ''DECREE TERMINATING LIFE ESTATE''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRMOD'' then ''DECREE MODIFICATION''
			when [Document_Category] like ''DCR'' and Document_Type like ''DCRQUI'' then ''QUIET TITLE DECREE''
			when [Document_Category] like ''DSC'' and Document_Type like ''DSC'' then ''DISCLAIMER''
			when [Document_Category] like ''DSM'' and Document_Type like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [Document_Category] like ''DTM'' and Document_Type like ''DTM'' then ''MORTGAGE, DEED OF TRUST''
			when [Document_Category] like ''DTM'' and Document_Type like ''DTM2'' then ''SECOND MORTGAGE, DEED OF TRUST''
			when [Document_Category] like ''EAS'' and Document_Type like ''EAS'' then ''EASEMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASAGR'' then ''EASEMENT AGREEMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASAMD'' then ''EASEMENT AMENDMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASASN'' then ''EASEMENT ASSIGNMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASCNS'' then ''CONSENT TO EASEMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASCNSDOT'' then ''BENEFICIARIES CONSENT TO EASEMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASCTR'' then ''EASEMENT CONTRACT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASDED'' then ''EASEMENT DEED''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASDEDAMD'' then ''DEED EASEMENT AMENDMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASPRL'' then ''EASEMENT PARTIAL RELEASE''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASRAT'' then ''RATIFICATION OF EASEMENT''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASREL'' then ''EASEMENT RELEASE''
			when [Document_Category] like ''EAS'' and Document_Type like ''EASSUB'' then ''EASEMENT SUBORDINATION''
			when [Document_Category] like ''ELN'' and Document_Type like ''ELN'' then ''ECONOMIC LIEN''
			when [Document_Category] like ''ELN'' and Document_Type like ''ELNPRL'' then ''PARTIAL RELEASE OF ECONOMIC LIEN''
			when [Document_Category] like ''ELN'' and Document_Type like ''ELNREL'' then ''RELEASE OF ECONOMIC LIEN''
			when [Document_Category] like ''EXC'' and Document_Type like ''EXC'' then ''EXECUTION''
			when [Document_Category] like ''EXC'' and Document_Type like ''EXCPRL'' then ''EXECUTION PARTIAL RELEASE''
			when [Document_Category] like ''EXC'' and Document_Type like ''EXCREL'' then ''EXECUTION RELEASE''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLN'' then ''FEDERAL TAX LIEN''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNAMD'' then ''FEDERAL TAX LIEN AMENDMENT''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNEST'' then ''FEDERAL ESTATE TAX LIEN''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNEXT'' then ''FEDERAL TAX LIEN EXTENSION''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNFIL'' then ''FEDERAL TAX LIEN REFILING''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNINH'' then ''FEDERAL INHERITANCE TAX LIEN''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNMOD'' then ''FEDERAL TAX LIEN MODIFICATION''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNNON'' then ''FEDERAL TAX LIEN NON-ATTACHMENT''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNPRL'' then ''FEDERAL TAX LIEN PARTIAL RELEASE ''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNREL'' then ''FEDERAL TAX LIEN  RELEASE ''
			when [Document_Category] like ''FLN'' and Document_Type like ''FLNSUB'' then ''FEDERAL LIEN SUBORDINATION''
			when [Document_Category] like ''INJ'' and Document_Type like ''INJ'' then ''INJUCTION''
			when [Document_Category] like ''INJ'' and Document_Type like ''INJAMD'' then ''INJUCTION AMENDMENT''
			when [Document_Category] like ''INJ'' and Document_Type like ''INJPRL'' then ''INJUCTION PARTIAL RELEASE''
			when [Document_Category] like ''INJ'' and Document_Type like ''INJREL'' then ''INJUCTION RELEASE''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDG'' then ''JUDGMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGAMD'' then ''JUDGMENT AMENDMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGASN'' then ''JUDGMENT ASSIGNMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGDEA'' then ''JUDGMENT DEATH''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGDIV'' then ''DIVORCE JUDGMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGDOM'' then ''JUDGMENT  <DOMESTIC MATTERS>''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGDOT'' then ''JUDGMENT REGARDING DEED OF TRUST''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGDST'' then ''JUDGMENT DISTRIBUTION''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGEVT'' then ''JUDGMENT OF POSSESSION & EVICTION''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGFED'' then ''FEDERAL JUDGMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGLEN'' then ''JUDGMENT LIEN''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGLENASN'' then ''ASSIGNMENT OF JUDGMENT LIEN''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGLENREL'' then ''JUDGMENT LIEN RELEASE''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGLISREL'' then ''JUDGMENT LIS PENDENS''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGMOD'' then ''JUDGMENT MODIFICATION''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGMTG'' then ''JUDGMENT AFFECTING MORTGAGE''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGPRL'' then ''JUDGMENT PARTIAL RELEASE''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGQUI'' then ''QUIET TITLE JUDGMENT''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGREL'' then ''JUDGMENT RELEASE''
			when [Document_Category] like ''JDG'' and Document_Type like ''JDGSUB'' then ''JUDGMENT SUBORDINATION''
			when [Document_Category] like ''JTV'' and Document_Type like ''JTV'' then ''JOINT VENTURE''
			when [Document_Category] like ''JTV'' and Document_Type like ''JTVAMD'' then ''JOINT VENTURE AMENDMENT''
			when [Document_Category] like ''JTV'' and Document_Type like ''JTVASN'' then ''JOINT VENTURE ASSIGNMENT''
			when [Document_Category] like ''JTV'' and Document_Type like ''JTVREL'' then ''JOINT VENTURE DISSOLUTION''
			when [Document_Category] like ''LEN'' and Document_Type like ''LEN'' then ''LEIN <GENERAL>''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENAMD'' then ''LIEN AMENDMENT''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENASN'' then ''LIEN ASSIGNMENT''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCNT'' then ''COUNTY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCNTPRL'' then ''PARTIAL RELASE OF COUNTY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCNTREL'' then ''RELEASE OF COUNTY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCTY'' then ''CITY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCTYPRL'' then ''PARTIAL RELEASE OF CITY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENCTYREL'' then ''RELEASE OF CITY LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENDOJ'' then ''DEPARTMENT OF JUSTICE LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENDOJPRL'' then ''PARTIAL RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENDOJREL'' then ''RELEASE OF DEPARTMENT OF JUSTICE LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENENV'' then ''ENVIRONMENTAL LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENEXT'' then ''LIEN EXTENSION''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENGRB'' then ''GARBAGE LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENMED'' then ''MEDICAL LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENMEDPRL'' then ''PARTIAL RELEASE OF MEDICAL LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENMEDREL'' then ''RELEASE OF MEDICAL LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENMOD'' then ''LIEN MODIFICATION''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENOGL'' then ''OIL & GAS LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENOGLREL'' then ''RELEASE OF OIL & GAS LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENORS'' then ''ORS LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENPPT'' then ''POSTPONED PROPERTY TAX LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENPRL'' then ''LIEN PARTIAL RELEASE''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENRAT'' then ''RATIFICATION OF LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENREL'' then ''LIEN RELEASE''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENSLE'' then ''NOTICE OF SALE <LIEN>''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENSUB'' then ''LIEN SUBORDINATION''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENSWR'' then ''SEWER LIEN''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENUTL'' then ''UTILITY LIEN''
			when [Document_Category] like ''LEV'' and Document_Type like ''LEV'' then ''LEVY''
			when [Document_Category] like ''LEV'' and Document_Type like ''LEVPRL'' then ''LEVY PARTIAL RELEASE''
			when [Document_Category] like ''LEV'' and Document_Type like ''LEVREL'' then ''LEVY RELEASE''
			when [Document_Category] like ''LEV'' and Document_Type like ''LEVSLE'' then ''LEVY SALE''
			when [Document_Category] like ''LIC'' and Document_Type like ''LIC'' then ''LICENSE''
			when [Document_Category] like ''LIC'' and Document_Type like ''LICAMD'' then ''LICENSE AMENDMENT''
			when [Document_Category] like ''LIC'' and Document_Type like ''LICASN'' then ''LICENSE ASSIGNMENT''
			when [Document_Category] like ''LIC'' and Document_Type like ''LICREL'' then ''EXPIRATION OF LICENSE''
			when [Document_Category] like ''LID'' and Document_Type like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [Document_Category] like ''LIS'' and Document_Type like ''LIS'' then ''LIS PENDENS''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISAMD'' then ''LIS PENDENS AMENDMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISASN'' then ''LIS PENDENS ASSIGNMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISHLN'' then ''LIS PENDENS <HOA>''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISHLNAMD'' then ''LIS PENDENS <HOA> AMENDMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISHLNASN'' then ''LIS PENDENS <HOA> ASSIGNMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISHLNPRL'' then ''LIS PENDENS <HOA> PARTIAL RELEASE''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISHLNREL'' then ''LIS PENDENS <HOA> RELEASE''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISMLN'' then ''LIS PENDENS - MECHANICS LIEN''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISMLNAMD'' then ''LIS PENDENS <MECHANICS LIEN> AMENDMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISMLNASN'' then ''LIS PENDENS <MECHANICS LIEN> ASSIGNMENT''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISMLNPRL'' then ''LIS PENDENS <MECHANICS LIEN> PARTIAL RELEASE''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISMLNREL'' then ''LIS PENDENS <MECHANICS LIEN> RELEASE''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISPRL'' then ''LIS PENDENS PARTIAL RELEASE''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISPRO'' then ''LIS PENDENS - PROBATE ACTION''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISQUI'' then ''QUIET TITLE NOTICE OF LIS PENDENS''
			when [Document_Category] like ''LIS'' and Document_Type like ''LISREL'' then ''LIS PENDENS RELEASE''
			when [Document_Category] like ''LLC'' and Document_Type like ''LLC'' then ''LLC''
			when [Document_Category] like ''LLC'' and Document_Type like ''LLCAGR'' then ''LIMITED LIABILITY COMPANY OPERATING AGREEMENT''
			when [Document_Category] like ''LLC'' and Document_Type like ''LLCAMD'' then ''LLC AMENDMENT''
			when [Document_Category] like ''LLC'' and Document_Type like ''LLCASN'' then ''LLC ASSIGNMENT''
			when [Document_Category] like ''LLC'' and Document_Type like ''LLCREL'' then ''LLC RELEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSE'' then ''LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEAMD'' then ''LEASE AMENDMENT''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEASN'' then ''ASSIGNMENT OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEASNPRL'' then ''PARTIAL RELEASE OF ASSIGNMENT OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEASNREL'' then ''RELEASE OF ASSIGNMENT OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEASP'' then ''ASSUMPTION OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEBRE'' then ''BREACH OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEBREREL'' then ''RELEASE OF BREACH OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSECHT'' then ''EQUIPMENT LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEDSC'' then ''LEASE DISCLAIMER''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEEXT'' then ''LEASE EXTENSION''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEMASASN'' then ''ASSIGNMENT OF MASTER LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEMOD'' then ''LEASE MODIFICATION''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEOPT'' then ''LEASE OPTION''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEPRL'' then ''LEASE PARTIAL RELEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEQCL'' then ''QUITCLAIM OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSERAT'' then ''LEASE RATIFICATION''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSEREL'' then ''LEASE RELEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSERIP'' then ''RIPARIAN LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSESBL'' then ''SUBLEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSESLM'' then ''LEASE SUPPLEMENT''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSESUB'' then ''SUBORDINATION OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSESUBASN'' then ''ASSIGNMENT OF SUBORDINATION OF LEASE''
			when [Document_Category] like ''LSE'' and Document_Type like ''LSESUBREL'' then ''SUBORDINATION OF LEASE RELEASE''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAP'' then ''MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPAGL'' then ''AGRICULTURAL MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPAMD'' then ''MAP AMENDMENT''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPANX'' then ''ANNEXATION MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPAPL'' then ''MAP APPLICATION''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPAPV'' then ''MAP APPROVAL''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPASM'' then ''ASSESSMENT DISTRICT MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPCDO'' then ''CONDOMINIUM MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPCEM'' then ''CEMETARY MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPCFD'' then ''COMMUNITY FACILITY DISTRICT MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPDIV'' then ''DIVISION OF LAND MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPGUR'' then ''MAP GUARANTY''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPMCL'' then ''MINING CLAIM MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPMOD'' then ''MAP MODIFICATION''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPPCL'' then ''PARCEL MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPRAT'' then ''MAP RATIFICATION''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPRVN'' then ''REVERSION TO ACERAGE MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPSBD'' then ''SUBDIVISION MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPSHP'' then ''SHORT PLAT''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPSPV'' then ''SUPERVISORS PLAT''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPSVY'' then ''SURVEY MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPTRA'' then ''TRACT MAP''
			when [Document_Category] like ''MAP'' and Document_Type like ''MAPVAC'' then ''MAP VACATION''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLJTV'' then ''AFFIDAVIT OF MINING VENTURE AGREEMENT''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLJTVREL'' then ''MINING VENTURE AGREEMENT TERMINATION''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLLOC'' then ''CERTIFICATE OF LOCATION/NOTICE OF MINING LOCATION''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLNIH'' then ''NOTICE OF INTENTION TO HOLD <MINING CLAIM>''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLPAY'' then ''AFFIDAVIT OF EVIDENCE OF PAYMENT''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLREL'' then ''NOTICE OF ABANDONMENT OF MINING CLAIM''
			when [Document_Category] like ''MCL'' and Document_Type like ''MCLWRK'' then ''AFFIDAVIT OF LABOR/PROOF OF LABOR''
			when [Document_Category] like ''MEM'' and Document_Type like ''MEM'' then ''MEMORANDUM''
			when [Document_Category] like ''MEM'' and Document_Type like ''MEMLEN'' then ''MEMORANDUM OF LIEN AFFECTING REAL PROPERTY''
			when [Document_Category] like ''MEM'' and Document_Type like ''MEMSLE'' then ''MEMORANDUM OF SALE''
			when [Document_Category] like ''MIN'' and Document_Type like ''MIN'' then ''MINERAL INTEREST''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLN'' then ''MECHANICS LIEN''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNAMD'' then ''MECHANICS LIEN AMENDMENT''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNASN'' then ''MECHANICS LIEN ASSIGNMENT''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNEXT'' then ''MECHANICS LIEN EXTENSION''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNMOD'' then ''MECHANICS LIEN MODIFICATION''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNPRL'' then ''MECHANICS LIEN PARTIAL RELEASE''
			when [Document_Category] like ''MLN'' and Document_Type like ''MLNREL'' then ''MECHANICS LIEN RELEASE''
			when [Document_Category] like ''MTY'' and Document_Type like ''MTY'' then ''MILITARY''
			when [Document_Category] like ''NOI'' and Document_Type like ''NOI'' then ''NOTICE OF INTENT''
			when [Document_Category] like ''NOI'' and Document_Type like ''NOIRED'' then ''NOTICE OF INTENT TO REDEEM''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOT'' then ''NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTAMD'' then ''AMENDED NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTAPE'' then ''NOTICE OF APPEAL''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTATT'' then ''NOTICE OF ATTACHMENT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTBLD'' then ''NOTICE OF SUBSTANDARD BUILDING''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTBRE'' then ''NOTICE OF BREACH''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTBREREL'' then ''CANCELLATION OF NOTICE OF BREACH''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCMC'' then ''NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCMCPRL'' then ''PARTIAL RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCMCREL'' then ''RELEASE OF NOTICE OF COMMENCEMENT <WORK/CONSTRUCTION>''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCMP'' then ''NOTICE OF COMPLIANCE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCPRREL'' then ''NOTICE OF TERMINATION OF INTEREST IN COMMUNITY PROPERTY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCPT'' then ''NOTICE OF COMPLETION''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTCSE'' then ''NOTICE OF CESSATION''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDEA'' then ''NOTICE OF DEATH''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDLQ'' then ''NOTICE OF DELINQUENCY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDML'' then ''NOTICE OF DEMOLITION''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDOT'' then ''NOTICE REGARDING DEED OF TRUST''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDSB'' then ''NOTICE OF DISBURSEMENT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTDSC'' then ''DISCLAIMER NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTERR'' then ''NOTICE OF SCRIVENERS ERROR''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTEVT'' then ''NOTICE OF EVICTION''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTIST'' then ''NOTICE OF INTEREST''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTISTPRL'' then ''PARTIAL RELEASE OF NOTICE OF INTEREST''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTISTREL'' then ''RELEASE OF NOTICE OF INTEREST''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLFE'' then ''NOTICE OF LIFE ESTATE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLFEREL'' then ''RELEASE OF NOTICE OF LIFE ESTATE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLIB'' then ''NOTICE OF NON-LIABILITY ''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLIBREL'' then ''RELEASE OF NOTICE OF NON-LIABILITY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLID'' then ''NOTICE OF LOCAL IMPROVEMENT DISTRICT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLLA'' then ''NOTICE OF LOT MERGER''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTLLAREL'' then ''NOTICE OF LOT MERGER REVERSAL''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTMH'' then ''NOTICE OF MANUFACTURED HOME''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTMIN'' then ''NOTICE TO PRESERVE MINERAL RIGHTS''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTMTG'' then ''NOTICE REGARDING MORTGAGE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTNNR'' then ''NOTICE OF NON RESPONSIBILITY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTNNRREL'' then ''RELEASE OF NOTICE OF NON RESPONSIBILITY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTPLD'' then ''NOTICE OF PLEDGE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTPLDREL'' then ''RELEASE OF NOTICE OF PLEDGE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTPRL'' then ''PARTIAL RELEASE OF NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTQNT'' then ''QUARANTINED PROPERTY  NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTREL'' then ''RELEASE OF NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSET'' then ''NOTICE OF SETTLEMENT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSTO'' then ''STOP NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSVY'' then ''SURVEY NOTICE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSWR'' then ''NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSWRREL'' then ''RELEASE OF NOTICE OF SEWER CONNECTION REQUIREMENT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTSZD'' then ''NOTICE OF SEIZURE''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTTAX'' then ''NOTICE OF TAX''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTTAXREL'' then ''RESCISSION OF NOTICE OF TAX DEFAULTED PROPERTY''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTTRN'' then ''NOTICE OF TRANSFER''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTTRU'' then ''NOTICE OF TRUST''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTVIO'' then ''NOTICE OF VIOLATION''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTWTH'' then ''NOTICE TO WITHHOLD''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTWTR'' then ''NOTICE OF WATER RIGHT''
			when [Document_Category] like ''NOT'' and Document_Type like ''NOTWTRREL'' then ''RELEASE OF NOTICE OF WATER RIGHT''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTE'' then ''PROMISSORY NOTE''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEADV'' then ''NOTE FOR ADVANCES''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEAMD'' then ''NOTE AMENDMENT''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEASN'' then ''NOTE ASSIGNMENT''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEASP'' then ''LIEN NOTE ASSUMPTION''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEPRL'' then ''LIEN NOTE PARTIAL RELEASE''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEREI'' then ''REINSTATEMENT OF NOTE''
			when [Document_Category] like ''NTE'' and Document_Type like ''NTEREL'' then ''NOTE RELEASE''
			when [Document_Category] like ''OAT'' and Document_Type like ''OAT'' then ''OATH''
			when [Document_Category] like ''ODN'' and Document_Type like ''ODN'' then ''ORDINANCE''
			when [Document_Category] like ''ODN'' and Document_Type like ''ODNREL'' then ''ORDINANCE RELEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGL'' then ''OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLAMD'' then ''AMENDED OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLASN'' then ''ASSIGNMENT OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLDSC'' then ''DISCLAIMER OF OIL & GAS RIGHTS''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLINT'' then ''OIL & GAS INTEREST''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLMOD'' then ''MODIFICATION OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLOPT'' then ''OPTION FOR OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLOPTAMD'' then ''AMENDED OPTION FOR OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLPRA'' then ''PARTIAL ASSIGNMENT OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLPRL'' then ''PARTIAL RELEASE OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLQCL'' then ''QUITCLAIM OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLRAT'' then ''RATIFICATION OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLREL'' then ''RELEASE OF OIL & GAS LEASE''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLRTL'' then ''OIL & GAS LEASE RENTAL ORDER''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLSTP'' then ''STIPULATION OF OIL & GAS''
			when [Document_Category] like ''OGL'' and Document_Type like ''OGLSUB'' then ''SUBORDINATION OF OIL & GAS LEASE''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPT'' then ''OPTION''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTAGR'' then ''RIGHT OF FIRST REFUSAL AGREEMENT''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTAMD'' then ''OPTION AMENDMENT''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTASN'' then ''OPTION ASSIGNMENT''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTEXT'' then ''OPTION EXTENSION''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTMOD'' then ''OPTION MODIFICATION''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTOGL'' then ''OPTION OIL & GAS''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTPRL'' then ''OPTION PARTIAL RELEASE''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTREL'' then ''OPTION RELEASE''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTSUB'' then ''OPTION SUBORDINATION''
			when [Document_Category] like ''OPT'' and Document_Type like ''OPTXER'' then ''EXERCISE OF OPTION''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORD'' then ''ORDER''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDAMD'' then ''ORDER AMENDMENT''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDASN'' then ''ORDER ASSIGNMENT''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDED'' then ''ORDER AFFECTING DEED''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDIV'' then ''DIVORCE ORDER''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDOM'' then ''ORDER <DOMESTIC MATTERS>''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDOT'' then ''ORDER FOR DEED OF TRUST''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDSM'' then ''ORDER DISMISSAL''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDDST'' then ''ORDER OF DISTRIBUTION''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDEVT'' then ''ORDER OF POSSESSION & EVICTION''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDJDG'' then ''ORDER AND JUDGMENT''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDJDGAMD'' then ''AMENDED ORDER & FINAL JUDGMENT''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDLEN'' then ''ORDER OF LIEN''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDMTG'' then ''ORDER AFFECTING MORTGAGE''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDPRL'' then ''ORDER PARTIAL RELEASE''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDQUI'' then ''ORDER TO QUIET TITLE''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDREL'' then ''ORDER RELEASE''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDSLE'' then ''ORDER OF SALE''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDSLEAMD'' then ''ORDER OF SALE AMENDED''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDSUB'' then ''ORDER SUBORDINATION''
			when [Document_Category] like ''ORD'' and Document_Type like ''ORDWRL'' then ''ORDER AND RELEASE OF LIEN''
			when [Document_Category] like ''PER'' and Document_Type like ''PER'' then ''PERMIT''
			when [Document_Category] like ''PER'' and Document_Type like ''PERAMD'' then ''PERMIT AMENDMENT''
			when [Document_Category] like ''PER'' and Document_Type like ''PERAPL'' then ''PERMIT APPLICATION''
			when [Document_Category] like ''PER'' and Document_Type like ''PERASN'' then ''PERMIT ASSIGNMENT''
			when [Document_Category] like ''PER'' and Document_Type like ''PERREL'' then ''PERMIT RELEASE''
			when [Document_Category] like ''PET'' and Document_Type like ''PET'' then ''PETITION''
			when [Document_Category] like ''PET'' and Document_Type like ''PETDIV'' then ''DIVORCE PETITION''
			when [Document_Category] like ''PET'' and Document_Type like ''PETREL'' then ''PETITION RELEASE''
			when [Document_Category] like ''POA'' and Document_Type like ''POA'' then ''POWER OF ATTORNEY''
			when [Document_Category] like ''POA'' and Document_Type like ''POAAFF'' then ''AFFIDAVIT AS TO POWER OF ATTORNEY''
			when [Document_Category] like ''POA'' and Document_Type like ''POAAMD'' then ''POWER OF ATTORNEY AMENDMENT''
			when [Document_Category] like ''POA'' and Document_Type like ''POALTD'' then ''LIMITED POWER OF ATTORNEY''
			when [Document_Category] like ''POA'' and Document_Type like ''POAMOD'' then ''POWER OF ATTORNEY MODIFICATION''
			when [Document_Category] like ''POA'' and Document_Type like ''POAPRL'' then ''POWER OF ATTORNEY PARTIAL RELEASE''
			when [Document_Category] like ''POA'' and Document_Type like ''POAREL'' then ''POWER OF ATTORNEY RELEASE''
			when [Document_Category] like ''POA'' and Document_Type like ''POASBT'' then ''SUBSTITUTION OF POWER OF ATTORNEY''
			when [Document_Category] like ''POA'' and Document_Type like ''POASPC'' then ''SPECIAL POWER OF ATTORNEY''
			when [Document_Category] like ''POL'' and Document_Type like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLAMD'' then ''AMENDED POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLASN'' then ''ASSIGNMENT OF POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLMOD'' then ''MODIFICATION OF POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLPRL'' then ''PARTIAL RELEASE OF POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLRAT'' then ''RATIFICATION OF POOLING AGREEMENT''
			when [Document_Category] like ''POL'' and Document_Type like ''POLREL'' then ''RELEASE OF POOLING AGREEMENT''
			when [Document_Category] like ''PRL'' and Document_Type like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [Document_Category] like ''PRO'' and Document_Type like ''PRO'' then ''PROBATE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROAFF'' then ''PROBATE AFFIDAVIT''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROAMD'' then ''PROBATE AMENDMENT''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROCSV'' then ''PROBATE CONSERVATOR''
			when [Document_Category] like ''PRO'' and Document_Type like ''PRODCR'' then ''PROBATE DECREE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PRODCRREL'' then ''PROBATE DECREE RELEASE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PRODST'' then ''PROBATE DISTRIBUTION''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROGDN'' then ''PROBATE GUARDIANSHIP''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROGDNREL'' then ''PROBATE REVOCATION OF GUARDIANSHIP''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROICP'' then ''PROBATE INCOMPENTENCY''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROJDG'' then ''PROBATE JUDGMENT''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROJDGAMD'' then ''PROBATE JUDGMENT AMENDMENT''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROJDGPRL'' then ''PROBATE JUDGMENT PARTIAL RELEASE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROJDGREL'' then ''PROBATE JUDGMENT RELEASE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROLET'' then ''PROBATE LETTERS''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROMOD'' then ''PROBATE MODIFICATION''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROORD'' then ''PROBATE ORDER''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROPET'' then ''PROBATE PETITION''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROREL'' then ''PROBATE DISCHARGE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROSLE'' then ''PROBATE SALE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROSLEREL'' then ''PROBATE SALE RELEASE''
			when [Document_Category] like ''PRO'' and Document_Type like ''PROWAR'' then ''PROBATE WARD OF THE STATE''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTR'' then ''PARTNERSHIP''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRAFF'' then ''PARTNERSHIP AFFIDAVIT''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRAMD'' then ''PARTNERSHIP AMENDMENT''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRANM'' then ''PARTNERSHIP FICTITIOUS OR ASSUMED NAME''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRASN'' then ''PARTNERSHIP ASSIGNMENT''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRLLC'' then ''PARTNERSHIP LLC''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRNMC'' then ''PARTNERSHIP NAME CHANGE''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRPRL'' then ''PARTNERSHIP PARTIAL RELEASE''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRREL'' then ''PARTNERSHIP DISSOLUTION''
			when [Document_Category] like ''PTR'' and Document_Type like ''PTRSLE'' then ''PARTNERSHIP SALE''
			when [Document_Category] like ''RED'' and Document_Type like ''RED'' then ''NOTICE OF REDEMPTION''
			when [Document_Category] like ''REL'' and Document_Type like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [Document_Category] like ''REL'' and Document_Type like ''RELAFF'' then ''AFFIDAVIT TO  RELEASE''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQDSM'' then ''REQUEST FOR DISMISSAL''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQPRLDOT'' then ''REQUEST FOR PARTIAL RELEASE OF DEED OF TRUST''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQPRLMTG'' then ''REQUEST FOR PARTIAL RELEASE OF MORTGAGE''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQRELDOT'' then ''REQUEST FOR DEED OF RELEASE & FULL RECONVEYANCE''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQRELMTG'' then ''REQUEST FOR RELEASE OF MORTGAGE''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQRELVAC'' then ''VACATION OF REQUEST FOR RELEASE OF DEED OF TRUST/MORTGAGE''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQUCC'' then ''UCC SEARCH REQUEST''
			when [Document_Category] like ''REQ'' and Document_Type like ''REQWAI'' then ''REQUEST FOR WAIVER''
			when [Document_Category] like ''RES'' and Document_Type like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESACK'' then ''BUYERS ACKNOWLEGMENT OF AFFORDABLE DEED RESTRICTIONS  ''
			when [Document_Category] like ''RES'' and Document_Type like ''RESAFF'' then ''AFFIDAVIT FOR PESTICIDE RESTRICTIVE COVENANTS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESAGR'' then ''AGREEMENT FOR RESTRICTIVE COVENANTS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESAMD'' then ''RESTRICTIONS AMENDMENT''
			when [Document_Category] like ''RES'' and Document_Type like ''RESANX'' then ''RESTRICTIONS ANNEXATION''
			when [Document_Category] like ''RES'' and Document_Type like ''RESAPP'' then ''DECLARATION OF APPOINTMENT OF ARCHITECTURAL COMM. <RESTRICTIONS>''
			when [Document_Category] like ''RES'' and Document_Type like ''RESCNS'' then ''CONSENT TO RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESLLA'' then ''RESTRICTIVE COVENANT PERTAINING TO CONSOLIDATION OF LOTS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESPRK'' then ''DESIGNATION OF PARKING UNDER RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESREL'' then ''RESTRICTIONS RELEASE''
			when [Document_Category] like ''RES'' and Document_Type like ''RESSLE'' then ''RESALE RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESSTP'' then ''STIPULATION OF RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESSTR'' then ''SUBSTITUTION OF TRUSTEE UNDER RESTRICTIONS''
			when [Document_Category] like ''RES'' and Document_Type like ''RESTRN'' then ''RESTRICTIONS ON TRANSFER OF PROPERTY''
			when [Document_Category] like ''RES'' and Document_Type like ''RESUSE'' then ''USE RESTRICTION''
			when [Document_Category] like ''RES'' and Document_Type like ''RESVAR'' then ''VARIANCE/SETBACK UNDER RESTRICTIONS''
			when [Document_Category] like ''ROY'' and Document_Type like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [Document_Category] like ''ROY'' and Document_Type like ''ROYAMD'' then ''AMENDED ROYALTY AGREEMENT''
			when [Document_Category] like ''ROY'' and Document_Type like ''ROYASN'' then ''ASSIGNMENT OF ROYALTY INTEREST''
			when [Document_Category] like ''ROY'' and Document_Type like ''ROYPRL'' then ''PARTIAL RELEASE OF ROYALTY INTEREST''
			when [Document_Category] like ''ROY'' and Document_Type like ''ROYQCL'' then ''QUITCLAIM OF ROYALTY INTEREST''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQN'' then ''REQUEST FOR NOTICE''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNAGR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF AGREEMENT ''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNCTR'' then ''REQUEST FOR COPY OF NOTICE OF DEFAULT OF CONTRACT ''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNDOT'' then ''REQUEST FOR NOTICE OF DEFAULT OF DEED OF TRUST''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNHLN'' then ''REQUEST FOR NOTICE OF SALE -HOA LIEN''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNLEN'' then ''REQUEST FOR NOTICE OF SALE -LIEN''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNMLN'' then ''REQUEST FOR NOTICE OF SALE -MECHANICS LIEN''
			when [Document_Category] like ''RQN'' and Document_Type like ''RQNMTG'' then ''REQUEST FOR NOTICE OF DEFAULT OF MORTGAGE''
			when [Document_Category] like ''RSL'' and Document_Type like ''RSL'' then ''RESOLUTION''
			when [Document_Category] like ''SBT'' and Document_Type like ''SBTAGR'' then ''SUBSTITUTION AGREEMENT <NOT DOT/MTG>''
			when [Document_Category] like ''SBT'' and Document_Type like ''SBTSTR'' then ''SUBSTITUTION OF TRUSTEE <GENERAL>''
			when [Document_Category] like ''SBT'' and Document_Type like ''SBTWAS'' then ''SUBSTITUTION AND ASSIGNMENT''
			when [Document_Category] like ''SHF'' and Document_Type like ''SHFSLE'' then ''SHERIFFS SALE''
			when [Document_Category] like ''SLE'' and Document_Type like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [Document_Category] like ''SLE'' and Document_Type like ''SLEASN'' then ''ASSIGNMENT OF SALE''
			when [Document_Category] like ''SLE'' and Document_Type like ''SLEMOD'' then ''MODIFICATION OF SALE''
			when [Document_Category] like ''SLE'' and Document_Type like ''SLENOI'' then ''NOTICE OF INTENDED SALE/INTENT TO SELL''
			when [Document_Category] like ''SLE'' and Document_Type like ''SLEREL'' then ''CANCELLATION OF SALE''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLN'' then ''STATE TAX LIEN''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNAMD'' then ''STATE TAX LIEN AMENDMENT''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNEST'' then ''STATE ESTATE TAX LIEN''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNEXT'' then ''STATE TAX LIEN EXTENTION''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNINH'' then ''STATE INHERITANCE TAX LIEN''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNMOD'' then ''STATE TAX LIEN MODIFICATION''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNPRL'' then ''STATE TAX LIEN PARTIAL RELEASE''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNREL'' then ''STATE TAX LIEN RELEASE''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNSBE'' then ''STATE BOARD OF EQUILIZATION LIEN''
			when [Document_Category] like ''SLN'' and Document_Type like ''SLNSUB'' then ''STATE LIEN SUBORDINATION''
			when [Document_Category] like ''STM'' and Document_Type like ''STM'' then ''STATEMENT''
			when [Document_Category] like ''STM'' and Document_Type like ''STMAUT'' then ''STATEMENT OF AUTHORITY''
			when [Document_Category] like ''STM'' and Document_Type like ''STMBRE'' then ''STATEMENT OF BREACH''
			when [Document_Category] like ''STM'' and Document_Type like ''STMCHA'' then ''STATEMENT OF CHANGE''
			when [Document_Category] like ''STM'' and Document_Type like ''STMCLO'' then ''DISCLOSURE STATEMENT''
			when [Document_Category] like ''STM'' and Document_Type like ''STMIDT'' then ''STATEMENT IDENTIFYING REAL PROPERTY''
			when [Document_Category] like ''STM'' and Document_Type like ''STMIST'' then ''STATEMENT OF INTEREST''
			when [Document_Category] like ''STM'' and Document_Type like ''STMLOC'' then ''STATEMENT OF LOCATION''
			when [Document_Category] like ''STM'' and Document_Type like ''STMMAR'' then ''STATEMENT OF UNRECORDED MARRIAGE''
			when [Document_Category] like ''STM'' and Document_Type like ''STMOWN'' then ''STATEMENT OF OWNERSHIP''
			when [Document_Category] like ''STM'' and Document_Type like ''STMPBL'' then ''STATEMENT OF PUBLICATION''
			when [Document_Category] like ''STM'' and Document_Type like ''STMREL'' then ''REVOCATION OF STATEMENT''
			when [Document_Category] like ''STM'' and Document_Type like ''STMWTR'' then ''STATEMENT OF CLAIM OF RIGHT TO USE PUBLIC WATERS''
			when [Document_Category] like ''STM'' and Document_Type like ''STMXPL'' then ''EXPLANATORY STATEMENT''
			when [Document_Category] like ''STP'' and Document_Type like ''STP'' then ''STIPULATION''
			when [Document_Category] like ''STR'' and Document_Type like ''STRREQREL'' then ''SUBSTITUTION OF TRUSTEE AND REQUEST FOR FULL RECONVEYANCE''
			when [Document_Category] like ''SUI'' and Document_Type like ''SUI'' then ''SUIT''
			when [Document_Category] like ''SUI'' and Document_Type like ''SUIAMD'' then ''SUIT AMENDMENT''
			when [Document_Category] like ''SUI'' and Document_Type like ''SUIQUI'' then ''SUIT QUIET TITLE''
			when [Document_Category] like ''SUI'' and Document_Type like ''SUIVAC'' then ''SUIT VACATE''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPJDG'' then ''SUPPORT JUDGMENT''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPJDGAMD'' then ''AMENDED SUPPORT JUDGMENT''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPJDGPRL'' then ''PARTIAL RELEASE OF SUPPORT JUDGMENT''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPLEN'' then ''SUPPORT LIEN''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPLENPRL'' then ''SUPPORT LIEN PARTIAL RELEASE''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPLENREL'' then ''SUPPORT LIEN RELEASE''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPORD'' then ''SUPPORT ORDER''
			when [Document_Category] like ''SUP'' and Document_Type like ''SUPREL'' then ''SUPPORT RELEASE''
			when [Document_Category] like ''SWD'' and Document_Type like ''SWD'' then ''SPECIAL WARRANTY DEED''
			when [Document_Category] like ''TNM'' and Document_Type like ''TNM'' then ''TRADE NAME''
			when [Document_Category] like ''TNM'' and Document_Type like ''TNMAMD'' then ''TRADE NAME AMENDMENT''
			when [Document_Category] like ''TNM'' and Document_Type like ''TNMAPL'' then ''TRADE NAME APPLICATION''
			when [Document_Category] like ''TNM'' and Document_Type like ''TNMREL'' then ''TRADE NAME RELEASE''
			when [Document_Category] like ''TRU'' and Document_Type like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [Document_Category] like ''TRU'' and Document_Type like ''TRUSTR'' then ''SUBSTITUTION OF TRUSTEE OF A TRUST''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCC'' then ''FINANCING STATEMENT''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCAMD'' then ''FINANCING STATEMENT AMENDMENT''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCASN'' then ''FINANCING STATEMENT ASSIGNMENT''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCASP'' then ''FINANCING STATEMENT ASSUMPTION OF LIABILITY''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCCON'' then ''FINANCING STATEMENT CONTINUATION''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCDSP'' then ''DISPOSITION OF FINANCING STATEMENT''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCMOD'' then ''FINANCING STATEMENT MODIFICATION''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCOGL'' then ''FINANCING STATEMENT - OIL & GAS LEASE COLLATERAL''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCOOP'' then ''FINANCING STATEMENT - COOP''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCPRA'' then ''FINANCING STATEMENT PARTIAL ASSIGNMENT''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCPRL'' then ''FINANCING STATEMENT PARTIAL RELEASE''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCREL'' then ''FINANCING STATEMENT RELEASE''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCSUB'' then ''FINANCING STATEMENT SUBORDINATION''
			when [Document_Category] like ''UCC'' and Document_Type like ''UCCTER'' then ''FINANCING STATEMENT TERMINATION''
			when [Document_Category] like ''UNU'' and Document_Type like ''UNU'' then ''UNUSED BY COUNTY''
			when [Document_Category] like ''VEC'' and Document_Type like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [Document_Category] like ''VIT'' and Document_Type like ''VIT'' then ''VITAL''
			when [Document_Category] like ''VLN'' and Document_Type like ''VLN'' then ''VENDORS LIEN''
			when [Document_Category] like ''VLN'' and Document_Type like ''VLNPRL'' then ''VENDORS LIEN PARTIAL RELEASE''
			when [Document_Category] like ''VLN'' and Document_Type like ''VLNREL'' then ''VENDORS LIEN  RELEASE''
			when [Document_Category] like ''VOI'' and Document_Type like ''VOID'' then ''VOID''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAI'' then ''WAIVER''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIAMD'' then ''AMENDMENT OF WAIVER''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIHOM'' then ''WAIVER OF HOMESTEAD''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIIST'' then ''WAIVER OF OWNERSHIP INTEREST''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAILEN'' then ''WAIVER OF LIEN''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAILIB'' then ''WAIVER OF PERSONAL LIABILITY''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAILRD'' then ''LANDLORDS WAIVER & CONSENT''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIMAP'' then ''WAIVER OF MAP''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIMGE'' then ''MORTGAGEES WAIVER & CONSENT''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIMLN'' then ''WAIVER OF MECHANICS LIEN''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIOPT'' then ''OPTION WAIVER''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIPRL'' then ''PARTIAL RELEASE OF WAIVER''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIREL'' then ''RELEASE OF WAIVER''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIRES'' then ''WAIVER OF RESTRICTIONS''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAIRHT'' then ''WAIVER OF DOWER RIGHTS''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAISLN'' then ''WAIVER OF STATE TAX LIEN''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAISUB'' then ''WAIVER OF SUBORDINATION RIGHTS''
			when [Document_Category] like ''WAI'' and Document_Type like ''WAITAX'' then ''WAIVER OF TAX''
			when [Document_Category] like ''WRT'' and Document_Type like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			when [Document_Category] like ''WRT'' and Document_Type like ''WRTPRL'' then ''WRIT PARTIAL RELEASE <NOT AN EXECUTION>''
			when [Document_Category] like ''WRT'' and Document_Type like ''WRTREL'' then ''WRIT RELEASE <NOT AN EXECUTION>''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNENG'' then ''ASSESSMENT ENERGY LIEN''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNENGAMD'' then ''ASSESSMENT ENERGY LIEN AMENDMENT''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNENGREL'' then ''ASSESSMENT ENERGY LIEN RELEASE''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNPRL'' then ''ASSESSMENT LIEN PARTIAL RELEASE''
			when [Document_Category] like ''ALN'' and Document_Type like ''ALNREL'' then ''ASSESSMENT LIEN RELEASE''
			when [Document_Category] like ''AMD'' and Document_Type like ''AMD'' then ''AMENDMENT <UNSPECIFIED>''
			when [Document_Category] like ''ANM'' and Document_Type like ''ANM'' then ''ASSUMED NAME''
			when [Document_Category] like ''ANM'' and Document_Type like ''ANMREL'' then ''RELEASE OF ASSUMED NAME''
			when [Document_Category] like ''APL'' and Document_Type like ''APL'' then ''APPLICATION''
			when [Document_Category] like ''LEN'' and Document_Type like ''LENENF'' then ''CODE ENFORCEMENT LIEN''


			else Document_Type end





			Select Document_Type, count(*) From x_custom_OUTPUT_S28
			where [Nbr of Recordings] > 0
			Group by Document_Type
			Order by Document_Type


			--------DECODE Doc Type Category -----

			Select Document_Category, count(*) From x_custom_OUTPUT_S28
			where [Nbr of Recordings] > 0
			Group by Document_Category
			Order by Document_Category


			
			Update  x_custom_OUTPUT_S28
			Set Document_Category = case 
			when [Document_Category] like ''ABJ'' then ''ABSTRACT''
			when [Document_Category] like ''ACK'' then ''ACKNOWLEDGEMENT''
			when [Document_Category] like ''ACP'' then ''ACCEPTANCE''
			when [Document_Category] like ''AFD'' then ''AFFIDAVIT OF DEATH''
			when [Document_Category] like ''AFF'' then ''AFFIDAVIT''
			when [Document_Category] like ''AGR'' then ''AGREEMENT''
			when [Document_Category] like ''ALN'' then ''ASSESSMENT LIEN''
			when [Document_Category] like ''AMD'' then ''AMENDMENT''
			when [Document_Category] like ''ANM'' then ''ASSUMED NAME''
			when [Document_Category] like ''APL'' then ''APPLICATION''
			when [Document_Category] like ''ASR'' then ''ASSIGNMENT or Rents''
			when [Document_Category] like ''BKY'' then ''BANKRUPTCY''
			when [Document_Category] like ''BND'' then ''BOND''
			when [Document_Category] like ''BSL'' then ''BILL OF SALE''
			when [Document_Category] like ''BUS'' then ''BUSINESS CERTIFICATE''
			when [Document_Category] like ''CAV'' then ''CAVEAT''
			when [Document_Category] like ''CCR'' then ''DECLARATION OF COVENANTS, CONDITIONS & RESTRICTION''
			when [Document_Category] like ''CER'' then ''CERTIFICATE''
			when [Document_Category] like ''CHJ'' then ''CHANGE OF JUDGE''
			when [Document_Category] like ''CNS'' then ''CONSENT''
			when [Document_Category] like ''COV'' then ''COVENANT''
			when [Document_Category] like ''CRP'' then ''CORPORATION''
			when [Document_Category] like ''CTR'' then ''CONTRACT''
			when [Document_Category] like ''DCL'' then ''DECLARATION''
			when [Document_Category] like ''DCR'' then ''DECREE''
			when [Document_Category] like ''DSC'' then ''DISCLAIMER''
			when [Document_Category] like ''DSM'' then ''NOTICE OF DISMISSAL''
			when [Document_Category] like ''EAS'' then ''EASEMENT''
			when [Document_Category] like ''ELN'' then ''ECONOMIC LIEN''
			when [Document_Category] like ''EXC'' then ''EXECUTION''
			when [Document_Category] like ''FLN'' then ''FEDERAL TAX LIEN''
			when [Document_Category] like ''HLN'' then ''HOA LIEN''
			when [Document_Category] like ''HOM'' then ''DECLARATION OF HOMESTEAD''
			when [Document_Category] like ''INJ'' then ''INJUCTION''
			when [Document_Category] like ''JDG'' then ''JUDGMENT''
			when [Document_Category] like ''JTV'' then ''JOINT VENTURE''
			when [Document_Category] like ''LEN'' then ''LEIN <GENERAL>''
			when [Document_Category] like ''LEV'' then ''LEVY''
			when [Document_Category] like ''LIC'' then ''LICENSE''
			when [Document_Category] like ''LID'' then ''IMPROVEMENT DISTRICT LIEN''
			when [Document_Category] like ''LIS'' then ''LIS PENDENS''
			when [Document_Category] like ''LLC'' then ''LLC''
			when [Document_Category] like ''LSE'' then ''LEASE''
			when [Document_Category] like ''MAP'' then ''MAP''
			when [Document_Category] like ''MCL'' then ''AFFIDAVIT OF LODE MINIING''
			when [Document_Category] like ''MEM'' then ''MEMORANDUM''
			when [Document_Category] like ''MIN'' then ''MINERAL INTEREST''
			when [Document_Category] like ''MLN'' then ''MECHANICS LIEN''
			when [Document_Category] like ''MOD'' then ''MODIFICATION <UNSPECIFICED>''
			when [Document_Category] like ''MTY'' then ''MILITARY''
			when [Document_Category] like ''NOI'' then ''NOTICE OF INTENT''
			when [Document_Category] like ''NOT'' then ''NOTICE''
			when [Document_Category] like ''NTE'' then ''PROMISSORY NOTE''
			when [Document_Category] like ''OAT'' then ''OATH''
			when [Document_Category] like ''ODN'' then ''ORDINANCE''
			when [Document_Category] like ''OGL'' then ''OIL & GAS LEASE''
			when [Document_Category] like ''OPT'' then ''OPTION''
			when [Document_Category] like ''ORD'' then ''ORDER''
			when [Document_Category] like ''PER'' then ''PERMIT''
			when [Document_Category] like ''PET'' then ''PETITION''
			when [Document_Category] like ''POA'' then ''POWER OF ATTORNEY''
			when [Document_Category] like ''POL'' then ''DECLARATION OF POOLING AGREEMENT''
			when [Document_Category] like ''PRL'' then ''PARTIAL RELEASE <UNSPECIFIED>''
			when [Document_Category] like ''PRO'' then ''PROBATE''
			when [Document_Category] like ''PTR'' then ''PARTNERSHIP''
			when [Document_Category] like ''RED'' then ''NOTICE OF REDEMPTION''
			when [Document_Category] like ''REL'' then ''NOTICE OF CANCELLATION or DISCHARGE or RELEASE or TERMINATION''
			when [Document_Category] like ''REQ'' then ''REQUEST''
			when [Document_Category] like ''RES'' then ''NOTICE OF RESTRICTIONS''
			when [Document_Category] like ''ROY'' then ''ROYALTY INTEREST/AGREEMENT''
			when [Document_Category] like ''RQN'' then ''REQUEST FOR NOTICE''
			when [Document_Category] like ''RSL'' then ''RESOLUTION''
			when [Document_Category] like ''SBT'' then ''SUBSTITUTION''
			when [Document_Category] like ''SLE'' then ''NOTICE OF SALE <UNSPECIFIED>''
			when [Document_Category] like ''SLN'' then ''STATE TAX LIEN''
			when [Document_Category] like ''STM'' then ''STATEMENT''
			when [Document_Category] like ''STP'' then ''STIPULATION''
			when [Document_Category] like ''STR'' then ''SUBSTITUTION''
			when [Document_Category] like ''SUI'' then ''SUIT''
			when [Document_Category] like ''SUP'' then ''SUPPORT''
			when [Document_Category] like ''TNM'' then ''TRADE NAME''
			when [Document_Category] like ''TRU'' then ''TRUST AGREEMENT/DECLARATION OF TRUST''
			when [Document_Category] like ''UCC'' then ''FINANCING STATEMENT''
			when [Document_Category] like ''UNU'' then ''UNUSED BY COUNTY''
			when [Document_Category] like ''VEC'' then ''VEHICLE CHANGE OF TITLE''
			when [Document_Category] like ''VIT'' then ''VITAL''
			when [Document_Category] like ''VLN'' then ''VENDORS LIEN''
			when [Document_Category] like ''VOI'' then ''VIOLATION''
			when [Document_Category] like ''WAI'' then ''WAIVER''
			when [Document_Category] like ''WRT'' then ''WRIT <NOT AN EXECUTION>''
			else [Document_Category] end


			
			Select Document_Category, count(*) From x_custom_OUTPUT_S28
			where [Nbr of Recordings] > 0
			Group by Document_Category
			Order by Document_Category


				
			


			
			')

			END

			Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]

			Select [Document_Type], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
			where [Nbr of Recordings] > 0
			Group by [Document_Type]
			Order by [Document_Type]


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] 
		SET [INVL Coverage Status] = CASE WHEN [INVL Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique ID] = b.Raw_ID
		
	


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_StateBankIndia_CA].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28] a join [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		and (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		SET [Event Status] = case when [Nbr of Recordings] > 0	THEN 'Event Found' ELSE 'Event Not Found' END
		
		
		Select [Property Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Group by [Address Standardization]

		Select [INVL Coverage Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Group by [INVL Coverage Status]

		Select [Event Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Group by [Event Status]

		--Select [INPUT Unique ID], count(*) From x_custom_OUTPUT_S28
		--Group by [INPUT Unique ID]

		Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S28]
		Order by convert(int,[Nbr of Recordings]) desc

	



END



