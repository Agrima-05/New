SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_300_Start_Output_OS_National_S84]


AS
BEGIN
	
	SET NOCOUNT ON;

	

	--------20231105 - Per Nicole - returning record where  EARLIESTDELINQUENTYEAR > 0

		DROP TABLE [dbo].[x_Custom_OUTPUT_S84]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S84](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
		
		
			[INPUTKEY][varchar](250)NULL,
			[INPUT_Customer ID][varchar](250)NULL,
			[INPUT_UniqueID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[INPUT_CURRENTOWNER][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
			[SOURCE_AS_OF_DATE][varchar](250)NULL,
			[EARLIEST_YEAR_OF_DELINQUENCY][varchar](250)NULL,
			[TOTAL_DELINQUENCY_AMOUNT][varchar](250)NULL,
			[NBR_OF_DELINQ_PAYMENTS][varchar](250)NULL
					
		) ON [PRIMARY]

		


		SET CONCAT_NULL_YIELDS_NULL OFF
		
		
		INSERT INTO [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] ([INPUTKEY],
		[INPUT_Customer ID],
		[INPUT_UniqueID],
		[INPUT_ADDRESS],
		[INPUT_CITY],
		[INPUT_STATE],
		[INPUT_ZIPCODE],
		FIPS,
		PROPERTYID,
		[INPUT_CURRENTOWNER]
		)
	
		Select 	INPUTKEY
		,CustomerID
		,[UniqueId]
		,[Address]
		,[City]
		,[State]
		,ZIPCODE
		,FIPS
		,[PROPERTYID]
		,[INPUT_OWNER]
		--Select * 
	   	FROM [zCust_OS_National].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null


		 		
		------********ONLY RUN FULL PORTFOLIO on 5th of month or next bus day****-------
		DECLARE @TODAY date = convert(date,getdate())
		DECLARE @5th date = (Select top 1  [CalendarDate] FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc) 

		
		IF @TODAY <> @5th
		BEGIN
		
		Delete from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] as A join [zCust_OS_National].[dbo].[INPUT_MONITOR] as B on 
		A.INPUTKEY = B.INPUTKEY
		where B.DATE_RECEIVED < convert(Date,getdate())


		END
	
     

	  Select count(*) From [zCust_OS_National].[dbo].[INPUT_MONITOR]

  
	  Select count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]

	  Select top 100 *  From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
	  
				

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		----,a.[County Code] = RIGHT((CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END),3)
		--FROM x_Custom_OUTPUT_S84 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUTKey] = c.RAW_ID

		

		Update [zCust_OS_National].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKey] = c.RAW_ID


		Update [zCust_OS_National].[dbo].[a]
		set [Coverage Status] = 1
		--Select * 	
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] a 
			JOIN (Select FIPS, count(*) as TOTAL From [data].[dbo].[vDBS_TAX] as B with(NOLOCK) 
			Group by FIPS)B
			on A.FIPS = B.FIPS

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		set [Coverage Status] = 0
		where [Coverage Status] is null

	
		Update [zCust_OS_National].[dbo].[A]
		Set
		A.[SOURCE_AS_OF_DATE] = B.DelinquencyAsOfDate
		,A.[EARLIEST_YEAR_OF_DELINQUENCY] = B.EARLIESTDELINQUENTYEAR
		,A.[TOTAL_DELINQUENCY_AMOUNT] = B.TOTALDELINQAMOUNT
		,A.[NBR_OF_DELINQ_PAYMENTS] = B.NOOFDELINQPAYMENTSINSYSTEM		
		--Select B.FAPropertyID, B.EARLIESTDELINQUENTYEAR
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] a 
		JOIN  [data].[dbo].[vDBS_TAX] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PROPERTYID = B.FAPropertyID
		where B.EARLIESTDELINQUENTYEAR > 0
		and B.UCID not like 'D'
		--Order by A.PROPERTYID

	




		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END
		
		Update  [zCust_OS_National].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKey] = b.Raw_ID

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		SET [Property Status] = CASE WHEN PROPERTYID is not null and PROPERTYID not like '0'
		and PROPERTYID not like ''
		THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_OS_National].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] a join [zCust_OS_National].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUTKey] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84] 
		SET [Transaction Status] = CASE WHEN EARLIEST_YEAR_OF_DELINQUENCY > 0 THEN 'Event Found' ELSE 'Event Not Found' END
		



		Select [Coverage Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		Group by [Coverage Status]

		Select [Property Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		Group by [Address Standardization]

		Select [Transaction Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		Group by [Transaction Status]

		Select top 100 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S84]
		


END

