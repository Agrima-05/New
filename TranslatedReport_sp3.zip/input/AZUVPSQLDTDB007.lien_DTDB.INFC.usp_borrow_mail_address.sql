/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_borrow_mail_address | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE
	

 PROCEDURE [lien_DTDB].[INFC].[usp_borrow_mail_address] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'usp_borrow_mail_address'
		,N'Started'

	/*

select top 100 a.recording_date ,ur_doc_id
,BYR1_OWN_NAME
,BYR2_OWN_NAME
,BYR3_OWN_NAME
,BYR4_OWN_NAME
,MA_HOUSE_NBR, MA_HOUSE_NBR_SUFFIX, MA_STREET_DIRECTION, MA_STREET_NAME, MA_MODE, MA_QUADRANT, MA_APARTMENT_UNIT, MA_CITY
, * from deed.dbo.deed a
 
where fips = 6037 and ref_id = 9342276

order by a.recording_date


select top 100 fips, ref_id
,OWN_NAME1_FULL, OWN_NAME2_FULL, OWN_NAME3_FULL, OWN_NAME4_FULL
,MAIL_HOUSE_NBR, MAIL_HOUSE_NBR_2, MAIL_HOUSE_NBR_SUFFIX, MAIL_DIRECTION, MAIL_STREET_NAME, MAIL_MODE, MAIL_QUADRANT, MAIL_UNIT_NBR, MAIL_CITY, MAIL_STATE, MAIL_ZIP_CODE, MAIL_CARRIER_CODE
,* from assr.dbo.assr a with(nolock)
where a.ref_id = 9342276
*/
	--
	--Populates Mail address of the deed from Owner Mail address on SSR
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[usp_borrow_mail_address_temp]
		SELECT 'deed' AS _deed
			,try_cast('' AS VARCHAR(100)) AS update_from
			,d.fips
			,d.deedid
			,0 AS borrow_id
			,d.ur_doc_id
			,d.ur_name_id
			,d.recording_date
			,d.ref_id
			,d.INTER_FAMILY
			,d.clgx_unique_id
			,d.BYR1_OWN_NAME
			,d.BYR2_OWN_NAME
			,d.BYR3_OWN_NAME
			,d.BYR4_OWN_NAME
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
		INTO [lien_dtdb].[tmp].[usp_borrow_mail_address_temp]
		FROM [lien_dtdb].[infc].[deed_work] d WITH (
				NOLOCK
				,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
				)
		OUTER APPLY (
			SELECT ld.doc_id
				,ld.doc_type
			FROM [lien].[ur].[document] ld WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			WHERE ld.doc_id = d.ur_doc_id
			) ld
		WHERE ref_id IS NOT NULL
			--and ref_id = 11717299
			--and d.deed_type not in ('T')
			AND d.source_type IN ('e')
			AND (isnull(d.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
			AND (
				isnull(d.MA_HOUSE_NBR, '') = ''
				AND isnull(d.MA_STREET_NAME, '') = ''
				)
			AND (
				ld.doc_type IN (
					'AFD'
					,'AFFDCV'
					,'AFFTOD'
					,'DEDADM'
					,'DEDAMD'
					,'DEDDST'
					,'DEDDSTAMD'
					,'DEDEXR'
					,'DEDFID'
					,'DEDGDN'
					,'DEDGFT'
					,'DEDLFE'
					,'DEDREP'
					,'DEDTOD'
					,'PROAFF'
					,'QCDDST'
					,'QCDEXR'
					,'QCDFAM'
					,'QCDLFE'
					,'QCDPRO'
					,'QCDTOD'
					,'QCDTRU'
					,'SLEMOD'
					)
				OR (d.INTER_FAMILY = 'Y')
				)
		OPTION (
			RECOMPILE
			,MAXDOP 16
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--AND d.ref_id = 9342276
	----and d.BYR1_OWN_NAME = ar.OWN_NAME1_FULL
	----and ar.MAIL_HOUSE_NBR is not null
	--1.
	CREATE INDEX idx_null ON [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] (MA_HOUSE_NBR)

	CREATE UNIQUE INDEX idx_deedid ON [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] (deedid)

	CREATE INDEX idx_fips_clgx ON [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] (
		fips
		,clgx_unique_id
		)

	/*
select  format(count(*), '##,##0') as cnt FROM lien_dtdb.tmp.usp_borrow_mail_address_temp a with(nolock,index(idx_null))
WHERE a.MA_HOUSE_NBR IS NULL
*/
	DROP TABLE

	IF EXISTS #assr
		SELECT fips
			,ref_id
			,AssrID
			,ar.OWN_NAME1_FULL
			,ar.OWN_NAME2_FULL
			,ar.OWN_NAME3_FULL
			,ar.OWN_NAME4_FULL
			,ar.MAIL_HOUSE_NBR
			,ar.MAIL_HOUSE_NBR_2
			,ar.MAIL_HOUSE_NBR_SUFFIX
			,ar.MAIL_DIRECTION
			,ar.MAIL_STREET_NAME
			,ar.MAIL_MODE
			,ar.MAIL_QUADRANT
			,ar.MAIL_UNIT_NBR
			,ar.MAIL_CITY
			,ar.MAIL_STATE
			,ar.MAIL_ZIP_CODE
			,ar.MAIL_CARRIER_CODE
		INTO #assr
		FROM [assr].[dbo].[assr] ar
		WHERE ar.ref_id IN (
				SELECT DISTINCT ref_id
				FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp]
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_ref_id ON #assr (ref_id)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = NULL
		,a.MA_HOUSE_NBR = ar.MAIL_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = ar.MAIL_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = ar.MAIL_DIRECTION
		,a.MA_STREET_NAME = ar.MAIL_STREET_NAME
		,a.MA_MODE = ar.MAIL_MODE
		,a.MA_QUADRANT = ar.MAIL_QUADRANT
		,a.MA_APARTMENT_UNIT = ar.MAIL_UNIT_NBR
		,a.MA_CITY = ar.MAIL_CITY
		,a.MA_STATE = ar.MAIL_STATE
		,a.MA_ZIP_CODE = ar.MAIL_ZIP_CODE
		,a.MA_CARRIER_CODE = ar.MAIL_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = (SELECT [spdb].[dbo].[fn_RNS_GetFullSTDStreetAddress](ar.MAIL_HOUSE_NBR, ar.MAIL_DIRECTION, ar.MAIL_STREET_NAME, ar.MAIL_MODE, ar.MAIL_QUADRANT, NULL, ar.MAIL_UNIT_NBR)) --aa.out_address
		,a.update_from = 'ASSR'
		,a.borrow_id = ar.AssrID
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_null)
			)
	CROSS APPLY (
		SELECT ar.assrid
			,ar.OWN_NAME1_FULL
			,ar.OWN_NAME2_FULL
			,ar.OWN_NAME3_FULL
			,ar.OWN_NAME4_FULL
			,ar.MAIL_HOUSE_NBR
			,ar.MAIL_HOUSE_NBR_2
			,ar.MAIL_HOUSE_NBR_SUFFIX
			,ar.MAIL_DIRECTION
			,ar.MAIL_STREET_NAME
			,ar.MAIL_MODE
			,ar.MAIL_QUADRANT
			,ar.MAIL_UNIT_NBR
			,ar.MAIL_CITY
			,ar.MAIL_STATE
			,ar.MAIL_ZIP_CODE
			,ar.MAIL_CARRIER_CODE
		--,a.out_address
		FROM #assr ar WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		WHERE ar.ref_id = a.ref_id

				AND 
			(
			(a.BYR1_OWN_NAME in (ar.OWN_NAME1_FULL,ar.OWN_NAME2_FULL,ar.OWN_NAME3_FULL,ar.OWN_NAME4_FULL) and BYR1_OWN_NAME  is not null)
			or 
			(a.BYR2_OWN_NAME in (ar.OWN_NAME1_FULL,ar.OWN_NAME2_FULL,ar.OWN_NAME3_FULL,ar.OWN_NAME4_FULL) and a.BYR2_OWN_NAME is not null)
			or 
			(a.BYR3_OWN_NAME in (ar.OWN_NAME1_FULL,ar.OWN_NAME2_FULL,ar.OWN_NAME3_FULL,ar.OWN_NAME4_FULL) and a.BYR3_OWN_NAME is not null)
			or 
			(a.BYR4_OWN_NAME in (ar.OWN_NAME1_FULL,ar.OWN_NAME2_FULL,ar.OWN_NAME3_FULL,ar.OWN_NAME4_FULL) and a.BYR4_OWN_NAME is not null)
			)
			AND ar.MAIL_HOUSE_NBR IS NOT NULL
		) ar
	--OUTER APPLY (
	--	SELECT spdb.dbo.fn_RNS_GetFullSTDStreetAddress(ar.MAIL_HOUSE_NBR, ar.MAIL_DIRECTION, ar.MAIL_STREET_NAME, ar.MAIL_MODE, ar.MAIL_QUADRANT, NULL, ar.MAIL_UNIT_NBR) AS out_address
	--	) aa
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		


	OPTION (
		RECOMPILE
		,MAXDOP 16
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--
	-- Update the mailing address from the prior deed
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = prr.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR = prr.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = prr.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = prr.MA_STREET_DIRECTION
		,a.MA_STREET_NAME = prr.MA_STREET_NAME
		,a.MA_MODE = prr.MA_MODE
		,a.MA_QUADRANT = prr.MA_QUADRANT
		,a.MA_APARTMENT_UNIT = prr.MA_APARTMENT_UNIT
		,a.MA_CITY = prr.MA_CITY
		,a.MA_STATE = prr.MA_STATE
		,a.MA_ZIP_CODE = prr.MA_ZIP_CODE
		,a.MA_CARRIER_CODE = prr.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = prr.MA_ORIGINAL_MAILING_ADDRESS
		,a.update_from = 'Prior_deed'
		,a.borrow_id = prr.DeedID
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] d WITH (
			NOLOCK
			,INDEX (idx_deedid)
			) ON d.deedid = a.deedid
	OUTER APPLY (
		SELECT TOP 1 p.recording_date
			,p.deedid
			,p.source_type
			,p.clgx_unique_id
			,p.BYR1_OWN_NAME
			,p.BYR2_OWN_NAME
			,p.BYR3_OWN_NAME
			,p.BYR4_OWN_NAME
			,p.MA_HOUSE_NBR_PREFIX
			,p.MA_HOUSE_NBR
			,p.MA_HOUSE_NBR_SUFFIX
			,p.MA_STREET_DIRECTION
			,p.MA_STREET_NAME
			,p.MA_MODE
			,p.MA_QUADRANT
			,p.MA_APARTMENT_UNIT
			,p.MA_CITY
			,p.MA_STATE
			,p.MA_ZIP_CODE
			,p.MA_CARRIER_CODE
			,p.MA_ORIGINAL_MAILING_ADDRESS
		FROM [deed].[dbo].[deed] p WITH (
				NOLOCK
				,INDEX (Idx_Deed_Fips_RefID_RecordDate_Include)
				)
		--OUTER APPLY (
		--	SELECT spdb.dbo.fn_RNS_GetFullSTDStreetAddress(p.MA_HOUSE_NBR, p.MA_STREET_DIRECTION, p.MA_STREET_NAME, p.MA_MODE, p.MA_QUADRANT, NULL, p.MA_APARTMENT_UNIT) AS out_address
		--	) m
		WHERE p.fips = d.fips
			AND p.ref_id = d.ref_id
			AND p.recording_date <= d.recording_date
			AND p.clgx_unique_id <> d.clgx_unique_id
		ORDER BY p.recording_date DESC
		) prr
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		AND prr.MA_STREET_NAME IS NOT NULL
		AND prr.deedid IS NOT NULL
		AND (
			d.BYR1_OWN_NAME IN (
				prr.BYR1_OWN_NAME
				,prr.BYR2_OWN_NAME
				,prr.BYR3_OWN_NAME
				,prr.BYR4_OWN_NAME
				)
			OR d.BYR2_OWN_NAME IN (
				prr.BYR1_OWN_NAME
				,prr.BYR2_OWN_NAME
				,prr.BYR3_OWN_NAME
				,prr.BYR4_OWN_NAME
				)
			OR d.BYR3_OWN_NAME IN (
				prr.BYR1_OWN_NAME
				,prr.BYR2_OWN_NAME
				,prr.BYR3_OWN_NAME
				,prr.BYR4_OWN_NAME
				)
			OR d.BYR4_OWN_NAME IN (
				prr.BYR1_OWN_NAME
				,prr.BYR2_OWN_NAME
				,prr.BYR3_OWN_NAME
				,prr.BYR4_OWN_NAME
				)
			)
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);




DROP TABLE if exists [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type]
select a.codevalue
into [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type]
from (
			SELECT 'BORROWER' as CodeValue
			union all 
			SELECT 'MORTGAGOR/BORROWER' as CodeValue
			union all 
			SELECT 'TRUSTOR' as CodeValue
			union all 
			SELECT 'TRUSTOR' as CodeValue
) a	



	
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = ln.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR = ln.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = ln.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = ln.MA_STREET_DIRECTION
		,a.MA_STREET_NAME = ln.MA_STREET_NAME
		,a.MA_MODE = ln.MA_MODE
		,a.MA_QUADRANT = ln.MA_QUADRANT
		,a.MA_APARTMENT_UNIT = ln.MA_APARTMENT_UNIT
		,a.MA_CITY = ln.MA_CITY
		,a.MA_STATE = ln.MA_STATE
		,a.MA_ZIP_CODE = ln.MA_ZIP_CODE
		,a.MA_CARRIER_CODE = ln.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = addr.out_address
		,a.update_from = 'Concurr_mtg1'
		,a.borrow_id = ln.Name_id
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_fips_clgx)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] d WITH (
			NOLOCK
			,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
			) ON d.fips = a.fips
		AND d.CLGX_UNIQUE_ID = a.CLGX_UNIQUE_ID
	OUTER APPLY (
		SELECT TOP 1 n.name_id
			,lns.*
		FROM [lien].[ur].[NAME] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		OUTER APPLY (
			SELECT TOP 1 '' AS MA_HOUSE_NBR_PREFIX
				,substring(upper(ltrim(rtrim(isnull(lns.HouseNumber, '')))), 1, 10) AS MA_HOUSE_NBR
				,'' AS MA_HOUSE_NBR_SUFFIX
				,substring(upper(ltrim(rtrim(isnull(lns.Direction, '')))), 1, 2) AS MA_STREET_DIRECTION
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Name, '')))), 1, 30) AS MA_STREET_NAME
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Type, '')))), 1, 5) AS MA_MODE
				,substring(upper(ltrim(rtrim(isnull(lns.Post_Direction, '')))), 1, 2) AS MA_QUADRANT
				,substring(upper(ltrim(rtrim(isnull(lns.Unit, '')))), 1, 11) AS MA_APARTMENT_UNIT
				,substring(upper(ltrim(rtrim(isnull(lns.City, '')))), 1, 40) AS MA_CITY
				,substring(upper(ltrim(rtrim(isnull(lns.STATE, '')))), 1, 2) AS MA_STATE
				,substring(upper(ltrim(rtrim(isnull(lns.Zip, '')))) + UPPER(ltrim(rtrim(isnull(lns.Plus4, '')))), 1, 9) AS MA_ZIP_CODE
				,substring(upper(ltrim(rtrim(isnull(lns.CRRT, '')))), 1, 4) AS MA_CARRIER_CODE
			FROM [lien].[ur].[NAME_STD_ADDRESS] lns WITH (
					NOLOCK
					,INDEX (PK_Name_Std_Address)
					)
			WHERE lns.Name_id = n.Name_id
			) lns
		WHERE n.doc_id = d.mtg1_ur_doc_id
	and n.role_type in (select codevalue from [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type])
			AND n.[address] IS NOT NULL
		) ln
	OUTER APPLY (
		SELECT [spdb].[dbo].[fn_RNS_GetFullSTDStreetAddress](ln.MA_HOUSE_NBR, ln.MA_STREET_DIRECTION, ln.MA_STREET_NAME, ln.MA_MODE, ln.MA_QUADRANT, NULL, ln.MA_APARTMENT_UNIT) AS out_address
		) addr
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		AND d.mtg1_ur_doc_id IS NOT NULL
		AND ln.Name_id IS NOT NULL



	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = ln.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR = ln.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = ln.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = ln.MA_STREET_DIRECTION
		,a.MA_STREET_NAME = ln.MA_STREET_NAME
		,a.MA_MODE = ln.MA_MODE
		,a.MA_QUADRANT = ln.MA_QUADRANT
		,a.MA_APARTMENT_UNIT = ln.MA_APARTMENT_UNIT
		,a.MA_CITY = ln.MA_CITY
		,a.MA_STATE = ln.MA_STATE
		,a.MA_ZIP_CODE = ln.MA_ZIP_CODE
		,a.MA_CARRIER_CODE = ln.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = addr.out_address
		,a.update_from = 'Concurr_mtg2'
		,a.borrow_id = ln.Name_id
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_fips_clgx)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] d WITH (
			NOLOCK
			,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
			) ON d.fips = a.fips
		AND d.CLGX_UNIQUE_ID = a.CLGX_UNIQUE_ID
	OUTER APPLY (
		SELECT TOP 1 n.name_id
			,lns.*
		FROM [lien].[ur].[NAME] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		OUTER APPLY (
			SELECT TOP 1 '' AS MA_HOUSE_NBR_PREFIX
				,substring(upper(ltrim(rtrim(isnull(lns.HouseNumber, '')))), 1, 10) AS MA_HOUSE_NBR
				,'' AS MA_HOUSE_NBR_SUFFIX
				,substring(upper(ltrim(rtrim(isnull(lns.Direction, '')))), 1, 2) AS MA_STREET_DIRECTION
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Name, '')))), 1, 30) AS MA_STREET_NAME
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Type, '')))), 1, 5) AS MA_MODE
				,substring(upper(ltrim(rtrim(isnull(lns.Post_Direction, '')))), 1, 2) AS MA_QUADRANT
				,substring(upper(ltrim(rtrim(isnull(lns.Unit, '')))), 1, 11) AS MA_APARTMENT_UNIT
				,substring(upper(ltrim(rtrim(isnull(lns.City, '')))), 1, 40) AS MA_CITY
				,substring(upper(ltrim(rtrim(isnull(lns.STATE, '')))), 1, 2) AS MA_STATE
				,substring(upper(ltrim(rtrim(isnull(lns.Zip, '')))) + UPPER(ltrim(rtrim(isnull(lns.Plus4, '')))), 1, 9) AS MA_ZIP_CODE
				,substring(upper(ltrim(rtrim(isnull(lns.CRRT, '')))), 1, 4) AS MA_CARRIER_CODE
			FROM [lien].[ur].[NAME_STD_ADDRESS] lns WITH (
					NOLOCK
					,INDEX (PK_Name_Std_Address)
					)
			WHERE lns.Name_id = n.Name_id
			) lns
		WHERE n.doc_id = d.mtg2_ur_doc_id
		and n.role_type in (select codevalue from [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type])
			AND n.[address] IS NOT NULL
		) ln
	
	OUTER APPLY (
		SELECT [spdb].[dbo].[fn_RNS_GetFullSTDStreetAddress](ln.MA_HOUSE_NBR, ln.MA_STREET_DIRECTION, ln.MA_STREET_NAME, ln.MA_MODE, ln.MA_QUADRANT, NULL, ln.MA_APARTMENT_UNIT) AS out_address
		) addr
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		AND d.mtg2_ur_doc_id IS NOT NULL
		AND ln.Name_id IS NOT NULL

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = ln.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR = ln.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = ln.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = ln.MA_STREET_DIRECTION
		,a.MA_STREET_NAME = ln.MA_STREET_NAME
		,a.MA_MODE = ln.MA_MODE
		,a.MA_QUADRANT = ln.MA_QUADRANT
		,a.MA_APARTMENT_UNIT = ln.MA_APARTMENT_UNIT
		,a.MA_CITY = ln.MA_CITY
		,a.MA_STATE = ln.MA_STATE
		,a.MA_ZIP_CODE = ln.MA_ZIP_CODE
		,a.MA_CARRIER_CODE = ln.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = addr.out_address
		,a.update_from = 'Concurr_mtg3'
		,a.borrow_id = ln.Name_id
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_fips_clgx)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] d WITH (
			NOLOCK
			,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
			) ON d.fips = a.fips
		AND d.CLGX_UNIQUE_ID = a.CLGX_UNIQUE_ID
	OUTER APPLY (
		SELECT TOP 1 n.name_id
			,lns.*
		FROM [lien].[ur].[NAME] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		OUTER APPLY (
			SELECT TOP 1 '' AS MA_HOUSE_NBR_PREFIX
				,substring(upper(ltrim(rtrim(isnull(lns.HouseNumber, '')))), 1, 10) AS MA_HOUSE_NBR
				,'' AS MA_HOUSE_NBR_SUFFIX
				,substring(upper(ltrim(rtrim(isnull(lns.Direction, '')))), 1, 2) AS MA_STREET_DIRECTION
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Name, '')))), 1, 30) AS MA_STREET_NAME
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Type, '')))), 1, 5) AS MA_MODE
				,substring(upper(ltrim(rtrim(isnull(lns.Post_Direction, '')))), 1, 2) AS MA_QUADRANT
				,substring(upper(ltrim(rtrim(isnull(lns.Unit, '')))), 1, 11) AS MA_APARTMENT_UNIT
				,substring(upper(ltrim(rtrim(isnull(lns.City, '')))), 1, 40) AS MA_CITY
				,substring(upper(ltrim(rtrim(isnull(lns.STATE, '')))), 1, 2) AS MA_STATE
				,substring(upper(ltrim(rtrim(isnull(lns.Zip, '')))) + UPPER(ltrim(rtrim(isnull(lns.Plus4, '')))), 1, 9) AS MA_ZIP_CODE
				,substring(upper(ltrim(rtrim(isnull(lns.CRRT, '')))), 1, 4) AS MA_CARRIER_CODE
			FROM [lien].[ur].[NAME_STD_ADDRESS] lns WITH (
					NOLOCK
					,INDEX (PK_Name_Std_Address)
					)
			WHERE lns.Name_id = n.Name_id
			) lns
		WHERE n.doc_id = d.mtg3_ur_doc_id
		and n.role_type in (select codevalue from [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type])
			AND n.[address] IS NOT NULL
		) ln

	OUTER APPLY (
		SELECT [spdb].[dbo].[fn_RNS_GetFullSTDStreetAddress](ln.MA_HOUSE_NBR, ln.MA_STREET_DIRECTION, ln.MA_STREET_NAME, ln.MA_MODE, ln.MA_QUADRANT, NULL, ln.MA_APARTMENT_UNIT) AS out_address
		) addr
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		AND d.mtg3_ur_doc_id IS NOT NULL
		AND ln.Name_id IS NOT NULL

	--
	--
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MA_HOUSE_NBR_PREFIX = ln.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR = ln.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX = ln.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION = ln.MA_STREET_DIRECTION
		,a.MA_STREET_NAME = ln.MA_STREET_NAME
		,a.MA_MODE = ln.MA_MODE
		,a.MA_QUADRANT = ln.MA_QUADRANT
		,a.MA_APARTMENT_UNIT = ln.MA_APARTMENT_UNIT
		,a.MA_CITY = ln.MA_CITY
		,a.MA_STATE = ln.MA_STATE
		,a.MA_ZIP_CODE = ln.MA_ZIP_CODE
		,a.MA_CARRIER_CODE = ln.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS = addr.out_address
		,a.update_from = 'Concurr_mtg4'
		,a.borrow_id = ln.Name_id
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_fips_clgx)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] d WITH (
			NOLOCK
			,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
			) ON d.fips = a.fips
		AND d.CLGX_UNIQUE_ID = a.CLGX_UNIQUE_ID
	OUTER APPLY (
		SELECT TOP 1 n.name_id
			,lns.*
		FROM [lien].[ur].[NAME] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		OUTER APPLY (
			SELECT TOP 1 '' AS MA_HOUSE_NBR_PREFIX
				,substring(upper(ltrim(rtrim(isnull(lns.HouseNumber, '')))), 1, 10) AS MA_HOUSE_NBR
				,'' AS MA_HOUSE_NBR_SUFFIX
				,substring(upper(ltrim(rtrim(isnull(lns.Direction, '')))), 1, 2) AS MA_STREET_DIRECTION
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Name, '')))), 1, 30) AS MA_STREET_NAME
				,substring(upper(ltrim(rtrim(isnull(lns.Street_Type, '')))), 1, 5) AS MA_MODE
				,substring(upper(ltrim(rtrim(isnull(lns.Post_Direction, '')))), 1, 2) AS MA_QUADRANT
				,substring(upper(ltrim(rtrim(isnull(lns.Unit, '')))), 1, 11) AS MA_APARTMENT_UNIT
				,substring(upper(ltrim(rtrim(isnull(lns.City, '')))), 1, 40) AS MA_CITY
				,substring(upper(ltrim(rtrim(isnull(lns.STATE, '')))), 1, 2) AS MA_STATE
				,substring(upper(ltrim(rtrim(isnull(lns.Zip, '')))) + UPPER(ltrim(rtrim(isnull(lns.Plus4, '')))), 1, 9) AS MA_ZIP_CODE
				,substring(upper(ltrim(rtrim(isnull(lns.CRRT, '')))), 1, 4) AS MA_CARRIER_CODE
			FROM [lien].[ur].[NAME_STD_ADDRESS] lns WITH (
					NOLOCK
					,INDEX (PK_Name_Std_Address)
					)
			WHERE lns.Name_id = n.Name_id
			) lns
		WHERE n.doc_id = d.mtg4_ur_doc_id
		and n.role_type in (select codevalue from [lien_dtdb].[tmp].[usp_borrow_mail_address_mtg_buyer_Role_type])
			AND n.[address] IS NOT NULL
		) ln

	OUTER APPLY (
		SELECT [spdb].[dbo].[fn_RNS_GetFullSTDStreetAddress](ln.MA_HOUSE_NBR, ln.MA_STREET_DIRECTION, ln.MA_STREET_NAME, ln.MA_MODE, ln.MA_QUADRANT, NULL, ln.MA_APARTMENT_UNIT) AS out_address
		) addr
	WHERE (isnull(a.MA_ORIGINAL_MAILING_ADDRESS, '') = '')
		AND d.mtg4_ur_doc_id IS NOT NULL
		AND ln.Name_id IS NOT NULL

	--
	--update deed work
	--
	UPDATE [lien_DTDB].[INFC].[b]
	SET b.MA_HOUSE_NBR_PREFIX = a.MA_HOUSE_NBR_PREFIX
		,b.MA_HOUSE_NBR = a.MA_HOUSE_NBR
		,b.MA_HOUSE_NBR_SUFFIX = a.MA_HOUSE_NBR_SUFFIX
		,b.MA_STREET_DIRECTION = a.MA_STREET_DIRECTION
		,b.MA_STREET_NAME = a.MA_STREET_NAME
		,b.MA_MODE = a.MA_MODE
		,b.MA_QUADRANT = a.MA_QUADRANT
		,b.MA_APARTMENT_UNIT = a.MA_APARTMENT_UNIT
		,b.MA_CITY = a.MA_CITY
		,b.MA_STATE = a.MA_STATE
		,b.MA_ZIP_CODE = a.MA_ZIP_CODE
		,b.MA_CARRIER_CODE = a.MA_CARRIER_CODE
		,b.MA_ORIGINAL_MAILING_ADDRESS = a.MA_ORIGINAL_MAILING_ADDRESS
	FROM [lien_dtdb].[tmp].[usp_borrow_mail_address_temp] a WITH (
			NOLOCK
			,INDEX (idx_fips_clgx)
			)
	INNER JOIN [lien_dtdb].[infc].[deed_work] b WITH (
			NOLOCK
			,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
			) ON b.fips = a.fips
		AND b.CLGX_UNIQUE_ID = a.CLGX_UNIQUE_ID

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'usp_borrow_mail_address'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


