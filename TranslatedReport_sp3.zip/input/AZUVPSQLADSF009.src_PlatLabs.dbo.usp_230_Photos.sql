SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	parse Photo Links
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_230_Photos]

AS
BEGIN


	SET NOCOUNT ON;

		declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		TRUNCATE TABLE photos.RawPhotoLinks_batch


		INSERT INTO [src_platlabs].[photos].[RawPhotoLinks_batch]
		select [uid]
			  ,[mls_id]
			  ,[mls_listing_id]
			  ,[photo_count]
			  ,[photo_date]
			  ,NULL
			  ,[sequence_number]
			  ,[small]
			  ,[medium]
			  ,[large]
			  ,[xlarge]
			  ,[native] 
			  ,[source_url]
			  ,[modified_date]
			  ,Getdate() as LoadDate
		from (Select [uid],mls_id,mls_listing_id,[photo_count],[photo_date],[photos] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK)) info
		CROSS APPLY OPENJSON(Photos) WITH(
			   [large] varchar(500)
			 , [medium] varchar(500)
			 , [modified_date] datetime
			 , [sequence_number] int
			 , [small] varchar(500)
			 , [source_url] nvarchar(500)
			 , [xlarge] varchar(500)
			 , [native] varchar(500)
			 ) as Photo_array
		order by mls_id,mls_listing_id;

		Delete from [src_PlatLabs].[photos].[RawPhotoLinks]
		where [uid] in(Select [uid] from [src_PlatLabs].[photos].[RawPhotoLinks_Batch] with(NOLOCK))

		Delete from [src_PlatLabs].[photos].[RawPhotoLinks_to_2025]
		where [uid] in(Select [uid] from [src_PlatLabs].[photos].[RawPhotoLinks_Batch] with(NOLOCK))

		insert into [src_PlatLabs].[photos].[RawPhotoLinks]
		Select * from [src_PlatLabs].[photos].[RawPhotoLinks_Batch] with(NOLOCK)



		--Delete from photos.RawPhotoLinks_25
		--FROM photos.RawPhotoLinks_25 a JOIN [photos].[RawPhotoLinks_Batch] b
		--on a.mls_id = b.mls_id
		--	and a.mls_listing_id = b.mls_listing_id

		--INSERT INTO photos.RawPhotoLinks_25
		--select [mls_id],[mls_listing_id], string_agg(cast(COALESCE([sourceURL],[native],[small],[medium],[large],[xlarge]) as nvarchar(max)) , ',') within group (order by [mls_id],[mls_listing_id],[sequence_number]) as PhotoLinks
		--from [photos].[RawPhotoLinks_Batch]
		--WHERE sequence_number <= 25
		--group by [mls_id],[mls_listing_id]

			DROP INDEX [ix_MLSID_ListingID] ON [photos].[RawPhotoLinks_25]

			TRUNCATE TABLE [photos].[RawPhotoLinks_25]

			--INSERT INTO photos.RawPhotoLinks_25
			--select a.[mls_id],a.[mls_listing_id], string_agg(cast(COALESCE([source_url],[native],[small],[medium],[large],[xlarge]) as nvarchar(max)) , ',') within group (order by a.[mls_id],a.[mls_listing_id],[sequence_number]) as PhotoLinks
			--from [photos].[RawPhotoLinks] a with(NOLOCK) JOIN 
			--	(Select mls_id,mls_listing_id from listing.listingFull with(NOLOCK) Where mls_id in(Select mls_id from dbo.platlabs_update_config with(NOLOCK) where active = '1' and code like '%_39') 
			--		and [status] in('Active','Backup','Contingent','Pending','Coming Soon')) b
			--on a.mls_id = b.mls_id
			--and a.mls_listing_id = b.mls_listing_id
			--WHERE sequence_number <= 25
			--group by a.[mls_id],a.[mls_listing_id]

			CREATE UNIQUE NONCLUSTERED INDEX [ix_MLSID_ListingID] ON [photos].[RawPhotoLinks_25]
			([mls_id] ASC,[mls_listing_id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]

			INSERT INTO [src_PlatLabs].[photos].[RawPhotoLinks_25]
			select a.[mls_id],a.[mls_listing_id], string_agg(cast(COALESCE([source_url],[native],[small],[medium],[large],[xlarge]) as nvarchar(max)) , ',') within group (order by a.[mls_id],a.[mls_listing_id],[sequence_number]) as PhotoLinks
			from [src_PlatLabs].[photos].[RawPhotoLinks] a with(NOLOCK) JOIN 
				(Select mls_id,mls_listing_id from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK) Where mls_id in(Select mls_id from [src_PlatLabs].[dbo].[platlabs_update_config]  with(NOLOCK) where active = '1' and code like '%_39') 
					and [status] in('Active','Backup','Contingent','Pending','Coming Soon')) b
			on a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id
			WHERE sequence_number <= 25
			group by a.[mls_id],a.[mls_listing_id]


		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END

