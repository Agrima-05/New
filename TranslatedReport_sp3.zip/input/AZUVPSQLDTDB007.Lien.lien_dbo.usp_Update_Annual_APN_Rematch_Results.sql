/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | lien_dbo.usp_Update_Annual_APN_Rematch_Results | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */


create PROCEDURE [Lien].[lien_dbo].[usp_Update_Annual_APN_Rematch_Results] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Update_Annual_APN_Rematch_Resutls'
		,N'Started'

	DROP TABLE

	IF EXISTS #Updt
		SELECT *
		INTO #Updt
		FROM [Lien].[dbo].[Match_Results_New]
		WHERE Update_Status = 'I'

	CREATE INDEX idx ON #updt (property_id)

	BEGIN TRANSACTION

	UPDATE [Lien].[lien_dbo].[a]
	SET a.Ref_id = isnull(b.Ref_id, 0)
		,a.Fips = isnull(b.b_fips, a.Fips)
		,a.Match_code = ''
		,a.updated = getdate() --@UpdateDate
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.updated
		,'Update Annual APN Rematch Resutls' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	FROM [lien].[UR].[PROPERTY_APN_MAtCH] a
	INNER JOIN #updt b ON b.Property_id = a.Property_id

	DELETE
	FROM [lien].[ur].[propertyheader]
	WHERE doc_id IN (
			SELECT doc_id
			FROM #updt
			)

	UPDATE [Lien].[lien_dbo].[a]
	SET a.Update_status = 'U'
	FROM [Lien].[dbo].[Match_Results_New] a
	INNER JOIN #Updt b ON b.Property_id = a.Property_id

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'Update_Annual_APN_Rematch_Resutls'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


