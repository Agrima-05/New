/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | lien_dbo.usp_create_Pet_Apn_Match_input | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Lien].[lien_dbo].[usp_create_Pet_Apn_Match_input] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
select top 100 m_create_date, * from lien.ur.document
order by doc_id desc

who  date  change  
Marie 2025/01/31 Initial Creation  
  

DECLARE	@ERROR varchar(500)

EXEC	Lien.[lien_dbo].usp_create_Pet_Apn_Match_input @fileid = ? , @ERROR = @ERROR OUTPUT

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT  
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_create_Pet_Apn_Match_input'
		,N'Started'

	--DECLARE @SQL VARCHAR(MAX)  
	-- ,@LinkSvr VARCHAR(100) = ''  
	--EXEC Lien.[LEAP].[AddLeapLog] N'info'  
	-- ,N'usp_UpdateAPNMatch'  
	-- ,N'Started'  
	-- tep testing
	--DROP TABLE
	--IF EXISTS #Temp
	--	SELECT TOP 10 pa.property_id
	--	INTO #temp
	--	FROM lien.[UR].[PROPERTY_APN_MAtCH] pa WITH (
	--			NOLOCK
	--			,INDEX (ix_propid_Ref_Code_apn)
	--			)
	--	ORDER BY pa.Property_id DESC
	--DELETE pa
	--FROM lien.[UR].[PROPERTY_APN_MAtCH] pa
	--WHERE property_id IN (
	--		SELECT property_id
	--		FROM #temp
	--		)
	-- real code begin
	DROP TABLE

	IF EXISTS [lien].[lien_tmp].[usp_create_Pet_Apn_Match_input_table]
		SELECT p.property_id
		INTO [lien].[lien_tmp].[usp_create_Pet_Apn_Match_input_table]
		FROM [lien].[ur].[property] p WITH (
				NOLOCK
				,INDEX (idx_apn_property_id)
				)
		LEFT JOIN [lien].[UR].[PROPERTY_APN_MAtCH] pa WITH (
				NOLOCK
				,INDEX (ix_propid_Ref_Code_apn)
				) ON pa.property_id = p.property_id
		WHERE p.legal_desc_apn IS NOT NULL
			AND pa.property_id IS NULL
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	TRUNCATE TABLE [Lien].[tmp].[Pet_Apn_Match]

	INSERT INTO [Lien].[tmp].[Pet_Apn_Match] (
		FileID
		,ID
		,[Fips]
		,[Apn]
		,[Apn_Seq]
		,[_apn]
		,[ca_apn1]
		,[ca_apn2]
		,[ca_apn3]
		,[spaceAPN]
		,[_add_apn_match]
		,[Created]
		,[Updated]
		,[Use_Actual_Fips]
		)
	SELECT @FileID AS FileID
		,
		----	select 	1 as fileid ,
		p.property_id AS ID
		,b.fips AS Fips
		,substring(p.legal_desc_apn, 1, 60) AS APN
		,cast(1 AS VARCHAR(3)) AS Apn_Seq
		,substring(REplace(REplace(replace(replace(p.legal_desc_apn, ' ', ''), '-', ''), '.', ''), '/', ''), 1, 60) AS _apn
		,substring(p.legal_desc_apn + '-000', 1, 60) AS ca_apn1
		,substring(p.legal_desc_apn + '-00', 1, 60) AS ca_apn2
		,substring(p.legal_desc_apn + '-0', 1, 60) AS ca_apn3
		,substring(try_cast(replace(ltrim(rtrim(p.legal_desc_apn)), ' ', '') AS VARCHAR(60)), 1, 60) AS spaceAPN
		,CASE 
			WHEN b.fips IN (
					12097
					,12059
					,8069
					,41035
					,12005
					)
				AND substring(p.legal_desc_apn, 1, 1) = 'R'
				THEN substring(p.legal_desc_apn, 2, 59)
			WHEN b.fips IN (55025)
				AND substring(p.legal_desc_apn, 4, 1) IN (
					'/'
					,'-'
					)
				THEN substring(p.legal_desc_apn, 5, 60)
			WHEN b.fips IN (
					8001
					,53011
					)
				AND substring(p.legal_desc_apn, 1, 1) = '0'
				THEN substring(p.legal_desc_apn, 2, 59)
			WHEN b.fips IN (56039)
				AND substring(p.legal_desc_apn, 1, 2) = '22'
				THEN substring(p.legal_desc_apn, 3, 60)
			WHEN b.fips IN (26093)
				AND substring(p.legal_desc_apn, 1, 2) = '47'
				THEN substring(p.legal_desc_apn, 3, 60)
			WHEN b.fips IN (6001)
				AND len(ltrim(rtrim(p.legal_desc_apn))) IN (15)
				THEN substring(rtrim(ltrim(p.legal_desc_apn)), 1, 3) + ' ' + substring(ltrim(rtrim(p.legal_desc_apn)), 4, 60)
			WHEN b.fips IN (6001)
				AND len(ltrim(rtrim(p.legal_desc_apn))) IN (12)
				THEN substring(ltrim(rtrim(p.legal_desc_apn)), 1, 3) + ' ' + substring(ltrim(rtrim(p.legal_desc_apn)), 4, 60) + '-00'
			ELSE NULL
			END AS _add_apn_match
		,getdate() AS Created
		,getdate() AS Updated
		,pp.Use_Actual_Fips
	FROM [lien].[UR].[PROPERTY] p WITH (
			NOLOCK
			,INDEX (PK_PROPERTY)
			)
	LEFT JOIN [lien].[UR].[PROPERTY_APN_MAtCH] pa WITH (
			NOLOCK
			,INDEX (ix_propid_Ref_Code_apn)
			) ON pa.Property_id = p.Property_id
	LEFT JOIN [lien].[ur].[DOCUMENT] d WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = p.doc_id
	OUTER APPLY (
		SELECT try_cast(d.fips_code AS INT) AS Fips
		) b
	OUTER APPLY (
		SELECT CASE 
				WHEN substring(p.legal_desc_apn, 1, 1) = '('
					AND d.fips_code BETWEEN '15000'
						AND '16000'
					THEN substring(p.legal_desc_apn, 2, 1)
				WHEN (
						substring(p.legal_desc_apn, 2, 1) IN ('/')
						OR len(p.legal_desc_apn) = 18
						)
					AND d.fips_code BETWEEN '15000'
						AND '16000'
					THEN substring(p.legal_desc_apn, 1, 1)
				ELSE NULL
				END AS _island
		) d1
	OUTER APPLY (
		SELECT ltrim(rtrim(LEFT(p.legal_desc_apn, 60))) AS apn
			,CASE 
				WHEN d1._island = '1'
					THEN '15003'
				WHEN d1._island = '2'
					THEN '15009'
				WHEN d1._island = '3'
					THEN '15001'
				WHEN d1._island = '4'
					THEN '15007'
				WHEN p.legal_desc_district = '1'
					THEN '36061' -- New York / Manhattan  
				WHEN p.legal_desc_district = '2'
					THEN '36005' -- Bronx  
				WHEN p.legal_desc_district = '3'
					THEN '36047' -- Kings / Brooklyn  
				WHEN p.legal_desc_district = '4'
					THEN '36081' -- Queens  
						--WHEN ct.Fips_code IS NOT NULL
						--	THEN ct.FIPS_CODE
				ELSE d.fips_code
				END AS _new_fips_code
			,CASE 
				WHEN d1._island IN (
						'1'
						,'2'
						,'3'
						,'4'
						)
					OR p.legal_desc_district IN (
						'1'
						,'2'
						,'3'
						,'4'
						)
					--or ct.Fips_code IS NOT NULL
					THEN 1
				ELSE 0
				END AS Use_Actual_Fips
		) pp
	WHERE p.property_id IN (
			SELECT property_id
			FROM [lien].[lien_tmp].[usp_create_Pet_Apn_Match_input_table]
			)
	--WHERE [legal_desc_apn] IS NOT NULL
	--	AND pa.Property_id IS NULL
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_create_Pet_Apn_Match_input'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK  
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


