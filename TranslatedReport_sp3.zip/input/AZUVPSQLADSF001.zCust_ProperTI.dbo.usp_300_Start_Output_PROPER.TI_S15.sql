SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_ProperTI].[dbo].[usp_300_Start_Output_PROPER.TI_S15]

AS
BEGIN
	
	-----20240201 - Per Nicole:
	---Populate listing fields for On Market properties only using the listing marked as current listing ind
	----Use Max List Price for "Orig" price


	------20240314 - Change per Nicole
	
----Yes, include off market status, too. Although we only send them Off Market or Sold one time per listing 
----(don’t continue to send Sold over and over just because the property is in the portfolio).

-----20240321 - Change per Nicole
-----Listing - Return when property goes on sale/is in an active listing stat AFTER the start date


		DROP TABLE [dbo].[X_CUSTOM_OUTPUT_S15]

		CREATE TABLE [dbo].[X_CUSTOM_OUTPUT_S15](
			[INPUTKEY][varchar](250)NULL,
			
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			
			[INPUT_Reference ID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			------Added 20240730 per NH-----
			[DTDB RefID][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
			[StartDate][varchar](250)NULL,

			[Status][varchar](250)NULL,
			[DaysOnMarket][varchar](250)NULL,
			[Orig List Price][varchar](250)NULL,
			[Current List Price][varchar](250)NULL,

			------INTERNAL-----
			[ONMARKET][varchar](250)NULL,
			[LISTDATE][varchar](250)NULL

		) ON [PRIMARY]

		



		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] (
		INPUTKEY,
		FIPS,
		PROPERTYID,
		[INPUT_Reference ID],
		[INPUT_ADDRESS],
		[INPUT_CITY],
		[INPUT_STATE],
		[INPUT_ZIPCODE]
		,[StartDate]
		,[DTDB RefID])

		Select 	
		INPUTKEY
		,FIPS
		,PROPERTYID,
		[INPUTKEY],
		[Address],
		[City],
		[State],
		[ZipCODE]
		,convert(date,[Start Date])
		,REF_ID
		--Select * 
	   
		FROM [zCust_ProperTI].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null

		Select * From [zCust_ProperTI].[dbo].[INPUT_MONITOR]

		
	
		
		Select count(*) From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]

	
		Select top 100 * From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]

	

		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM X_CUSTOM_OUTPUT_S15 a JOIN 
		--[dbo].a_PropMatch_Work_FLANK c on a.[INPUTKEY] = c.RAW_ID


		Update [zCust_ProperTI].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] a JOIN 
		[zCust_ProperTI].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKEY] = c.RAW_ID

			-----

		Update [zCust_ProperTI].[dbo].[a]
		set [Coverage Status] = B.MLSActive
		--,A.[Mortgage Start Date] = case when ISNULL(B.SamMinRecordDate,'') like '' then NULL else convert(date,B.SamMinRecordDate) end
		--,A.[Coverage Status] = case when ISNULL(B.SamMaxRecordDate,'') like '' then NULL else convert(date,B.SamMaxRecordDate) end 
		--Select MLSActive 
		FROM [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE


		Update [zCust_ProperTI].[dbo].[A]
		Set
		A.[Status] = B.Status
		,A.[DaysOnMarket] = B.FACalculatedDaysOnMarket
		,A.[Orig List Price] = B.MaxListPrice
		,A.[Current List Price] = B.CurrentListingPrice
		,A.[LISTDATE] = B.CurrentOriginalListingDate
		--Select A.INPUTKEY,B.Status,C.TRACKED_LISTING_STATUS
		From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] as A 
		join [data].[dbo].[vListings_Current_NEW_STD] as B With(NOLOCK) on 
		A.FIPS = B.FIPS
		and A.PROPERTYID = B.PropertyID
		join [zCust_ProperTI].[dbo].[INPUT_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
		where ISNULL(A.PROPERTYID,'0') not like '0'
		and B.[Add,Change,DeleteIndicator] not like 'D'
		and B.CurrentListingInd like 'Y'
		--and B.Status in ('Active','Pending','Contingent')
		--and ISNULL(B.Status,'') <> ISNULL(C.TRACKED_LISTING_STATUS,'')

		-----Added 20240321 per NH - USE THEIR INPUT DATE!!!---
		AND convert(date,B.CurrentOriginalListingDate) > convert(date,A.StartDate)
	

		Update [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		Set [ONMARKET] = 'Y'
		where status in ('Active','Pending','Contingent')


			

		----------------------

		Update [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_ProperTI].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] a JOIN 
		[zCust_ProperTI].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKEY] = b.Raw_ID

		Update [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ProperTI].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] a join [zCust_ProperTI].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUTKEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 



		
		------*****20240314 - Per NH - ANY STATUS CHANGE*****-----
		-------20240321 - CHANGE PER NH - ONLY CHANGE FROM ON MARKET TO OFF MARKET & VICE VERSA****-----
		----AND Use LIst Date!!!!*****

		Update  [zCust_ProperTI].[dbo].[A]
		SET [Transaction Status] = CASE WHEN ISNULL(A.[ONMARKET],'') <> ISNULL(C.[ONMARKET],'') 
		
		then 'Event Found' else 'Event Not Found' end
		--CASE WHEN Status in ('Active','Pending','Contingent') then 'Event Found' else 'Event Not Found' end
		From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] as A 
		join  [zCust_ProperTI].[dbo].[INPUT_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
		--where ISNULL(A.[Status],'') <> ISNULL(C.TRACKED_LISTING_STATUS,'')
		
		

		Select [Property Status], count(*) From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		Group by [Address Standardization]
		
		Select [Transaction Status], count(*) From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		Group by [Transaction Status]

		Select [Coverage Status], count(*) From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		Group by [Coverage Status]

		Select * From  [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15] as A 
		Order by Status


		

		Select * From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S15]
		

END


