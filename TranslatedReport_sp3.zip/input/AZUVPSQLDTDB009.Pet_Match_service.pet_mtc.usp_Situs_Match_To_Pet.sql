/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.usp_Situs_Match_To_Pet | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- ============================================= 
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
 CREATE   PROCEDURE [Pet_Match_service].[pet_mtc].[usp_Situs_Match_To_Pet] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	12/6/21		Change translated Fips routine call to table value function call
paul	200220721   add commentss on zip in match logic
******************************************************************************************************************/
BEGIN TRY
	-- declare @fileid INT = 2
	DECLARE @msg VARCHAR(500) = 'usp_Situs_Match_To_Pet - fileid: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Started'

	--select top 100 * from pet.pet_mtc.Std_Address
	--
	-- Situs match -- add fips when no fips was supplied by address std
	--
	--select  format(count(*), '##,##0') as cnt from pet.pet_mtc.Std_Address
	--select 69312 - 66112  = 3200
	UPDATE [Pet_Match_service].[pet_mtc].[p]
	SET p.ref_id = NULL
		,p.Match_code = NULL
		,p.Match_fips = NULL
		,p.Use_Actual_Fips = isnull(p.Use_Actual_Fips, 0)
		,p.legal_desc_address = ltrim(rtrim(isnull(legal_desc_address, '')))
		,p.legal_desc_address_city = ltrim(rtrim(isnull(legal_desc_address_city, '')))
		,p.legal_desc_address_state = ltrim(rtrim(isnull(legal_desc_address_state, '')))
		,p.legal_desc_address_zip = ltrim(rtrim(isnull(legal_desc_address_zip, '')))
		,p.legal_desc_map_unit_low = ltrim(rtrim(isnull(legal_desc_map_unit_low, '')))
		,p.Raw_Address = ltrim(rtrim(isnull(Raw_Address, '')))
		,p.HouseNumber = ltrim(rtrim(isnull(HouseNumber, '')))
		,p.Street_Number = ltrim(rtrim(isnull(Street_Number, '')))
		,p.Direction = ltrim(rtrim(isnull(Direction, '')))
		,p.Street_Name = ltrim(rtrim(isnull(Street_Name, '')))
		,p.Street_Type = ltrim(rtrim(isnull(Street_Type, '')))
		,p.Post_Direction = ltrim(rtrim(isnull(Post_Direction, '')))
		,p.Unit_Type = ltrim(rtrim(isnull(Unit_Type, '')))
		,p.Unit = ltrim(rtrim(isnull(Unit, '')))
		,p.City = ltrim(rtrim(isnull(City, '')))
		,p.STATE = ltrim(rtrim(isnull(STATE, '')))
		,p.Zip = ltrim(rtrim(isnull(Zip, '')))
		,p.Plus4 = ltrim(rtrim(isnull(Plus4, '')))
		,p.CountyName = ltrim(rtrim(isnull(CountyName, '')))
		,p.PlaceName = ltrim(rtrim(isnull(PlaceName, '')))
	FROM [PET_Match_Service].[pet_mtc].[Std_Address] p WITH (
			NOLOCK
			,INDEX (idx_file_id)
			)
	WHERE p.fileid = @fileid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);





	-- select * from pet.pet_mtc.Std_Address where ref_id is not null -- 59
	-----------------------------------------------------------------------
	DROP TABLE

	IF EXISTS #Situs_match2
		SELECT a.fileid
			,a.[ID]
			,a.[FIPS]
			,a.sf_address
			,a.[HouseNumber]
			,a.[Street_Number]
			,a.[Direction]
			,a.[Street_Name]
			,a.[Street_Type]
			,a.[Post_Direction]
			,a.[Unit_Type]
			,a.[Unit]
			,a.[City]
			,a.[State]
			,a.[Zip]
			,a.[Plus4]
			,p.Fips AS Match_fips
			,p.Ref_id AS P_ref_id
			,p.fips AS p_fips
			,p.StreetNumber AS p_StreetNumber
			,p.pre_Direction AS p_pre_Direction
			,p.StreetName AS p_StreetName
			,p.Street_Type AS p_street_type
			,p.Post_Direction AS p_Post_direction
			,p.Unit AS P_Unit
			,p.city AS p_city
			,p.STATE AS p_state
			,p.zip AS p_zip
			,ROW_NUMBER() OVER (
				PARTITION BY a.id ORDER BY (p.ref_id)
				) AS ROW4
		INTO #Situs_match2
		FROM [PET_Match_Service].[pet_mtc].[Std_Address] a WITH (
				NOLOCK
				,INDEX (idx_fileid_ref_id)
				)
		INNER JOIN [Pet].[dbo].[Translate_fips] tf WITH (
				NOLOCK
				,INDEX (ixc_fips)
				) ON tf.fips = a.fips
			AND (
				isnull(a.Use_Actual_Fips, 0) = 0
				OR (
					isnull(a.Use_Actual_Fips, 0) = 1
					AND tf.TranslatedFips = a.fips
					)
				)
		INNER JOIN [Pet].[dbo].[Pet] p WITH (
				NOLOCK
				,INDEX (idx_fips_address)
				) ON p.fips = tf.TranslatedFips
			AND p.Addr_Dup_Ind = 0
			AND p.StreetNumber = a.Street_Number
			AND a.Street_Number > ''
			AND p.pre_Direction = a.Direction
			AND p.StreetName = a.Street_Name
			AND a.Street_Name > ''
			AND p.Street_Type = a.Street_Type
			AND p.Post_Direction = a.Post_Direction
			AND (
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(substring([SPDB].[dbo].[RegexReplace](p.Unit, '(\/| |-|\.)|&|\#|', '', 0), 1, 60), 'hwy', ''), 'loop', ''), 'no', ''), 'nr', ''), 'ph', ''), 'pl', ''), 'ROAD', ''), 'sr', '') = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(substring([SPDB].[dbo].[RegexReplace](a.Unit, '(\/| |-|\.)|&|\#|', '', 0), 1, 60), 'hwy', ''), 'loop', ''), 'no', ''), 'nr', ''), 'ph', ''), 'pl', ''), 'ROAD', ''), 'sr', '')
				AND (
					(
						p.Unit > ''
						AND p.Unit_Ind = 1
						)
					OR (
						p.Unit = ''
						AND p.Unit_Ind = 0
						)
					)
				)
			AND (
				(
					a.STATE = p.STATE
					AND (
						(
							(
								p.City = a.PlaceName
								AND a.PlaceName > ''
								)
							--AND (
							--	a.PlaceName IS NOT NULL
							--	OR p.City IS NOT NULL
							--	)
							)
						OR p.city = a.city
						)
					)
				OR (
					p.STATE = a.STATE
					AND a.STATE > ''
					AND p.ZIP = a.ZIP
					AND a.zip > ''
					)
				)
			and (
			p.AddressMatchResults LIKE '%AS01%' OR p.AddressMatchResults LIKE '%AS02%' OR p.AddressMatchResults LIKE '%AS03%'
			)
		WHERE a.fileid = @fileid
			AND a.Ref_id IS NULL
			and (
			a.AddressMatchResults LIKE '%AS01%' OR a.AddressMatchResults LIKE '%AS02%' OR a.AddressMatchResults LIKE '%AS03%'
			)
		--AND p.Addr_Dup_Ind = 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--select top 100 * from #Situs_match2
	CREATE INDEX idx_file_id ON #Situs_match2 (id)

	UPDATE [Pet_Match_service].[pet_mtc].[l]
	SET l.Ref_id = p.Ref_id
		,l.Match_Fips = p.fips
		,l.Match_code = 'S020'
		,l.HouseNumber = p.StreetNumber
		,l.Street_Number = p.StreetNumber
		,l.Direction = p.Pre_Direction
		,l.Street_Name = p.StreetName
		,l.Street_Type = p.Street_Type
		,l.Post_Direction = p.Post_Direction
		,l.Unit_Type = p.Unit_Type
		,l.Unit = p.Unit
		,l.City = p.City
		,l.STATE = p.STATE
		,l.Zip = p.Zip
		,l.Plus4 = p.Plus4
	FROM #Situs_match2 t WITH (
			NOLOCK
			,INDEX (idx_file_id)
			)
	INNER JOIN [PET_Match_Service].[pet_mtc].[Std_Address] l WITH (
			NOLOCK
			,INDEX (idx_file_id)
			) ON l.fileid = t.fileid
		AND l.id = t.id
	CROSS APPLY (
		SELECT max(row4) AS row4
		FROM #Situs_match2 m
		WHERE m.fileid = t.fileid
			AND m.id = t.id
		) m
	INNER JOIN [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			) ON p.fips = t.match_fips
		AND p.ref_id = t.P_ref_id
	WHERE m.ROW4 = 1
	OPTION (
		RECOMPILE
		,MAXDOP 8
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	-- 6091
	-----------------------------------------------------------------------
	-- select sum(1) as cnt , sum(case when ref_id > 0 then 1 else 0 end) as match_cnt  from pet.pet_mtc.Std_Address where fips = 42003
	-- select 1994 -	1575 == 419
	-- do un std match for selected counties
	DECLARE @42003_cnt INT = (
			SELECT count(1) AS cnt
			FROM [PET_Match_Service].[pet_mtc].[Std_Address] p WITH (
					NOLOCK
					,INDEX (idx_file_id)
					)
			WHERE p.fileid = 25 --@fileid
				AND p.fips = 42003
			)

	IF @42003_cnt > 0
	BEGIN
		DROP TABLE

		IF EXISTS #trans_fips
			SELECT 42003 AS fips
			INTO #trans_fips

		DROP TABLE

		IF EXISTS #prop_addr
			SELECT p.fileid
				,p.Id
				,(
					SELECT fips
					FROM #trans_fips
					) AS Fips
				,p.legal_desc_address
				,p.legal_desc_address_city
				,p.legal_desc_address_state
				,p.legal_desc_address_zip
			INTO #prop_addr
			FROM [PET_Match_Service].[pet_mtc].[Std_Address] p WITH (
					NOLOCK
					,INDEX (ix_Fileid_Fips)
					)
			WHERE p.fileid = @fileid
				AND p.fips = 42003
				AND isnull(p.ref_id, 0) = 0

		DROP TABLE

		IF EXISTS [PET_Match_Service].[pet_tmp].[situs_match_Service_pet]
			SELECT /*ROW_ID
		,*/ REF_ID
				,FIPS
				,UNFORMATTED_APN
				,StreetNumber
				,Pre_Direction
				,StreetName
				,Street_Type
				,Post_Direction
				,Unit_Type
				,Unit
				,City
				,STATE
				,Zip
				,Plus4
				,Full_Address
				,SF_Address
				,SF_City
				,SF_Unit
				,SF_Address_5
				,AddressCity
				,Unit_Ind
			--,TranslatedFips
			INTO [PET_Match_Service].[pet_tmp].[situs_match_Service_pet]
			FROM [PET].[dbo].[PET] p WITH (
					NOLOCK
					,INDEX (ix_Fips)
					)
			WHERE p.Fips = 42003
			OPTION (
				RECOMPILE
				,MAXDOP 8
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

		/****** Object:  Index [ix_Fileid_Fips_addr_city]    Script Date: 6/1/2022 11:16:31 AM ******/
		CREATE NONCLUSTERED INDEX [ix_Fileid_Fips_addr_city] ON [PET_Match_Service].[pet_tmp].[situs_match_Service_pet] (
			[Fips] ASC
			,[SF_Address] ASC
			,[SF_City] ASC
			,[SF_Unit] ASC
			) INCLUDE (
			[Unit_Ind]
			,[Full_Address]
			,[REF_ID]
			,[UNFORMATTED_APN]
			,[StreetNumber]
			,[Pre_Direction]
			,[StreetName]
			,[Street_Type]
			,[Post_Direction]
			,[Unit_Type]
			,[Unit]
			,[City]
			,[State]
			,[Zip]
			,[Plus4]
			)

		/****** Object:  Index [ix_Translatedfips_addr_city_5]    Script Date: 6/1/2022 11:16:32 AM ******/
		CREATE NONCLUSTERED INDEX [ix_Fileid_Fips_addr_city_5] ON [PET_Match_Service].[pet_tmp].[situs_match_Service_pet] (
			[Fips] ASC
			,[SF_Address_5] ASC
			) INCLUDE (
			[Unit_Ind]
			,[Full_Address]
			,[REF_ID]
			,[UNFORMATTED_APN]
			,[StreetNumber]
			,[Pre_Direction]
			,[StreetName]
			,[Street_Type]
			,[Post_Direction]
			,[Unit_Type]
			,[Unit]
			,[City]
			,[State]
			,[Zip]
			,[Plus4]
			,[SF_Address]
			,[SF_City]
			,[SF_Unit]
			)

		/****** Object:  Index [IX_TranslatedFips_SF_Unit]    Script Date: 6/1/2022 11:16:33 AM ******/
		CREATE NONCLUSTERED INDEX [ix_Fileid_Fips_SF_Unit] ON [PET_Match_Service].[pet_tmp].[situs_match_Service_pet] (
			[Fips] ASC
			,[SF_Unit] ASC
			) INCLUDE (
			[SF_Address]
			,[SF_City]
			,[Unit_Ind]
			,[Full_Address]
			,[REF_ID]
			,[UNFORMATTED_APN]
			,[StreetNumber]
			,[Pre_Direction]
			,[StreetName]
			,[Street_Type]
			,[Post_Direction]
			,[Unit_Type]
			,[Unit]
			,[City]
			,[State]
			,[Zip]
			,[Plus4]
			)

		--select top 100 * from #prop_addr
		DROP TABLE

		IF EXISTS #prop_addr_results;
			WITH Temp_Prop
			AS (
				SELECT 'Property' AS _Property
					,p.fileid
					,p.Id
					,p.fips
					,p.legal_desc_address
					,p.legal_desc_address_city
					,aa._legal_desc_address
					,aa._legal_desc_address_city
					,PATINDEX('%[,]%', aa._legal_desc_address) AS CommaPoint
					,SUBSTRING(aa._legal_desc_address, PATINDEX('%[,]%', aa._legal_desc_address), LEN(aa._legal_desc_address)) AS _afterComma
					,CASE 
						WHEN PATINDEX('%[,]%', aa._legal_desc_address) > 0
							THEN SUBSTRING(aa._legal_desc_address, 1, PATINDEX('%[,]%', aa._legal_desc_address) - 1)
						ELSE aa._legal_desc_address
						END AS N_legal_desc_address_comma
					,nullif(CASE 
							WHEN PATINDEX('%[,]%', aa._legal_desc_address) > 0
								THEN substring(aa._legal_desc_address_city, PATINDEX('%[,]%', aa._legal_desc_address) + 1, len(aa._legal_desc_address_city))
							ELSE CASE 
									WHEN substring(substring(aa._legal_desc_address_city, len(aa._legal_desc_address) + 1, len(aa._legal_desc_address_city)), 1, 1) IN (',')
										THEN ltrim(Rtrim(substring(aa._legal_desc_address_city, len(aa._legal_desc_address) + 2, len(aa._legal_desc_address_city))))
									ELSE Ltrim(Rtrim(substring(aa._legal_desc_address_city, len(aa._legal_desc_address) + 1, len(aa._legal_desc_address_city))))
									END
							END, '') AS N_legal_desc_address_city
					,p.legal_desc_address_state
					,p.legal_desc_address_zip
				FROM #prop_addr p
				OUTER APPLY (
					SELECT Replace(Replace(legal_desc_address, '(City,)', ''), ' , ', '') AS _legal_desc_address
						,Replace(Replace(legal_desc_address_city, '(City,)', ''), ' , ', '') AS _legal_desc_address_city
					) aa
				)
				,DTOCR_PRoperty_Addr
			AS (
				SELECT a.*
					,substring(legal_desc_address, 1, 5) AS legal_desc_address_5
				FROM (
					--SELECT CASE WHEN @Fips BETWEEN 15000 AND 15998 THEN 15999 ELSE @Fips END AS Fips
					SELECT p.Fips
						,p.fileid
						,p.Id
						,cast(0 AS INT) AS Ref_id
						,'    ' AS Match_code
						,cast(substring(b._legal_desc_address, 1, 200) AS VARCHAR(200)) AS legal_desc_address
						,cast(substring(legal_desc_address_city, 1, 200) AS VARCHAR(200)) AS legal_desc_address_city
						,isnull(cast(substring(_unit, 1, 200) AS VARCHAR(200)), '') AS _Unit
					FROM (
						SELECT -- q.doc_id
							--,q.doc_unique_id
							q.Id
							,q.fileid
							--case when tp.doc_id is not null then tpa._address else qa._address end as legal_desc_address
							,coalesce(tpa._address, qa._address) AS legal_desc_address
							--,case when tp.doc_id is not null then tp.N_legal_desc_address_city else q.legal_desc_address_city end as legal_desc_address_city
							,coalesce(q.N_legal_desc_address_city, q.legal_desc_address_city) AS legal_desc_address_city
							--,case when tp.doc_id is not null then tpa._unit else qa._unit end as _unit
							,coalesce(tpa._unit, qa._unit) AS _unit
							,q.legal_desc_address_state
							,q.legal_desc_address_zip
							,q.fips
						--,qa._Unit
						--,qa._address
						--,tpa._Unit
						--,tpa._address
						FROM Temp_Prop Q
						--LEFT JOIN #temp_Prop tp	ON tp.doc_id = q.doc_id
						OUTER APPLY (
							SELECT *
							FROM [SPDB].[EPRVDB].[TFN_REmoveUnitFromAddress](q.legal_desc_address)
							) qa
						OUTER APPLY (
							SELECT *
							FROM [SPDB].[EPRVDB].[TFN_REmoveUnitFromAddress](q.N_legal_desc_address_comma)
							) tpa
							--where q.doc_id in (select doc_id from #Temp_Prop) 
						) p
					--LEFT JOIN pet.dbo.dtocr_document d
					--	ON d.doc_id = p.doc_id
					--OUTER APPLY (
					--	SELECT PET.[dbo].[SF_Address_Abrev](legal_desc_address) AS _legal_desc_address
					--	) ll
					OUTER APPLY (
						SELECT REplace(REplace(REplace(REplace(REplace(REplace(REplace(Replace(Replace(Replace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace(REplace
																																--(REplace
																																--(REplace
																																--(REplace
																																(legal_desc_address, ' Avenue', ' Ave'), ' Road', ' rd'), 'Drive', ' Dr'), ' Boulevard', ' Blvd'), ' Circle', ' Cir'), ' NORTHEAST ', ' NE'), ' NORTH EAST ', ' NE'), ' SOUTH EAST ', ' SE'), ' LANE', ' LN'), ' Court', ' CT'), ' HIGHWAY', ' HWY'), ' Valley', ' VLY'), ' Point', ' PT'), ' Place', ' PL'), ' EAST', ' E'), ' NORTH', ' N'), ' SOUTH', ' S')
																--,' CREEK ',' CRK' )
																--,' WAY,',' WAY')
																--,' SOUTHEAST',' SE')
																, ' Terrace', ' Tr'), ' HIGHWAY', ' Hwy'), ' Parkway', ' Pkwy'), ' Trail', ' trl'), ' Street', ' St'), ' West ', ' W '), '.', ' '), '  ', ' '), '  ', ' ') AS _legal_desc_address
						) b
					WHERE /* fips = 12119 and */ legal_desc_address IS NOT NULL
						--AND NOT (legal_desc_address = legal_desc_address_city)
					) a
				)
			SELECT o.Fips
				,o.Id
				,o.fileid
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.REF_ID
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.REF_ID
					ELSE o.REF_ID
					END AS REF_ID
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN 'm001'
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN 'm002'
					ELSE o.Match_code
					END AS Match_code
				,o.legal_desc_address
				,o.legal_desc_address_city
				,o._Unit
				,o.legal_desc_address_5
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.StreetNumber
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.StreetNumber
					END AS StreetNumber
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Pre_Direction
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Pre_Direction
					END AS Pre_Direction
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.StreetName
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.StreetName
					END AS StreetName
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Street_Type
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Street_Type
					END AS Street_Type
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Post_Direction
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Post_Direction
					END AS Post_Direction
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Unit_Type
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Unit_Type
					END AS Unit_Type
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Unit
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Unit
					END AS Unit
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.City
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.City
					END AS City
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.[State]
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.[State]
					END AS [State]
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Zip
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Zip
					END AS Zip
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Plus4
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Plus4
					END AS Plus4
				,CASE 
					WHEN p1.FIPS IS NOT NULL
						AND p1.match_cnt = 1
						THEN p1.Unformatted_apn
					WHEN p2.FIPS IS NOT NULL
						AND p2.match_cnt = 1
						THEN p2.Unformatted_apn
					END AS APN
			INTO #prop_addr_results
			FROM DTOCR_Property_Addr o
			OUTER APPLY (
				SELECT TOP 1 *
					,COUNT(*) OVER () AS match_cnt
				FROM [PET_Match_Service].[pet_tmp].[situs_match_Service_pet] p WITH (
						NOLOCK
						,INDEX ([ix_Fileid_Fips_SF_Unit])
						)
				WHERE p.Fips = o.fips
					AND o.legal_desc_address LIKE RTRIM(p.SF_Address) + '%'
					AND o.legal_desc_address_city LIKE RTRIM(p.SF_City) + '%'
					AND p.SF_Unit = o._Unit
					AND NOT (
						p.Unit_ind = 1
						AND o._Unit = ''
						)
					AND p.Full_Address IS NOT NULL
				) p1
			OUTER APPLY (
				SELECT TOP 1 *
					,COUNT(*) OVER () AS match_cnt
				FROM [PET_Match_Service].[pet_tmp].[situs_match_Service_pet] p WITH (
						NOLOCK
						,INDEX ([ix_Fileid_Fips_SF_Unit])
						)
				WHERE p.Fips = o.fips
					AND o.legal_desc_address LIKE RTRIM(p.SF_Address) + '%'
					AND p.SF_Unit = o._Unit
					AND NOT (
						p.Unit_ind = 1
						AND o._Unit = ''
						)
					AND p.Full_Address IS NOT NULL
				) p2
			OPTION (
				RECOMPILE
				,MAXDOP 8
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

		-- select  * from #prop_addr_results
		CREATE INDEX ixa ON #prop_addr_results (
			fileid
			,Id
			)

		CREATE INDEX ixb ON #prop_addr_results (fips)

		UPDATE [Pet_Match_service].[pet_mtc].[a]
		SET a.Street_Number = m.StreetNumber
			,a.Direction = m.Pre_Direction
			,a.Street_Name = m.StreetName
			,a.Street_Type = m.Street_Type
			,a.Post_Direction = m.Post_Direction
			,a.Unit_Type = m.Unit_Type
			,a.Unit = m.Unit
			,a.City = m.City
			,a.STATE = m.STATE
			,a.Zip = m.Zip
			,a.Plus4 = m.Plus4
			,a.match_fips = m.fips
			,a.Ref_id = m.REF_ID
			,a.MAtch_code = 'S030'
		FROM [PET_Match_Service].[pet_mtc].[Std_Address] a WITH (
				NOLOCK
				,INDEX (idx_file_id)
				)
		INNER JOIN #prop_addr_results m WITH (
				NOLOCK
				,INDEX (ixa)
				) ON m.fileid = a.fileid
			AND m.Id = a.id
		WHERE m.fips = 42003
			AND isnull(a.ref_id, 0) = 0
			AND isnull(m.REF_ID, 0) > 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);
	END

	INSERT INTO [PET_Match_Service].[pet_mtc].[Std_Address_Result] (
		[Fileid]
		,[ID]
		,[FIPS]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STATE]
		,[Zip]
		,[Plus4]
		,[Match_fips]
		,[Ref_id]
		,[Match_code]
		)
	SELECT [Fileid]
		,[ID]
		,[FIPS]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STATE]
		,[Zip]
		,[Plus4]
		,[Match_fips]
		,[Ref_id]
		,[Match_code]
	FROM [PET_Match_Service].[pet_mtc].[Std_Address] a WITH (
			NOLOCK
			,INDEX (idx_file_id)
			)
	WHERE a.fileid = @fileid

	--and m.Ref_id > 0
	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

