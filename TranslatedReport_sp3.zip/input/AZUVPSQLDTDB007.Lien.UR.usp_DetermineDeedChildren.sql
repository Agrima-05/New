/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_DetermineDeedChildren | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- ================================= ============
-- Author:        <Author,,Name>
-- Create date: <Create Date,,> 
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- ============================================= 
create PROCEDURE [Lien].[UR].[usp_DetermineDeedChildren]
AS
/****** Object:  Table [dbo].[paul_test]    Script Date: 4/18/2023 10:13:59 AM ******/
--truncate table [Lien].[tmp].[DeedChildren_Input]
--INSERT INTO [Lien].[tmp].[DeedChildren_Input] (
--	[doc_id]
--	,[fips]
--	,[doc_type]
--	,[_Y_doc_id]
--	)
--SELECT 104948377  doc_id
--	,6065 as fips
--	,'DEDGRT' as doc_type
--    --,104948377 as   _Y_doc_id
--	,127407992 as _Y_doc_id
--select 	[doc_id]
--	,[fips]
--	,[doc_type]
--	,[_Y_doc_id]
--FROM lien.tmp.reprocess_records_to_be_set_to_4
--select * from lien.tmp.reprocess_records_to_be_set_to_4 where _Y_doc_id = 211726595
--select * from lien.tmp.reprocess_Docids_And_Deedids_linked_to_records_to_be_set_to_4  where Y_doc_id = 211726595
--CREATE TABLE lien.[tmp].[DeedChildren_Output](
-- select * from [Lien].[tmp].[DeedChildren_Input] 
TRUNCATE TABLE [lien].[tmp].[DeedChildren_Output]    

INSERT INTO [Lien].[tmp].[DeedChildren_Output] (
	[DeedID]
	,[deed_type]
	,[FIPS]
	,[_type]
	,[ur_doc_id]
	,[CLGX_UNIQUE_ID]
	,[SRC_TBL]
	,[Y_doc_id]
	)
SELECT a.*
FROM (
	SELECT d.DeedID  
		,d.deed_type
		,d.FIPS 
		,dd._type
		,dd.ur_doc_id 
		,d.CLGX_UNIQUE_ID
		,d.SRC_TBL
		,f._Y_doc_id AS Y_doc_id
	FROM [Lien].[tmp].[DeedChildren_Input] f WITH (INDEX (idx)  )
	INNER JOIN [deed].[dbo].[deed] d WITH (
			INDEX (idx_ur_doc_id)
			,NOLOCK
			) ON ur_doc_id = f.doc_id
	OUTER APPLY (
		SELECT 'd' AS _type
			,d.ur_doc_id
		
		UNION ALL
		
		SELECT 't1' AS _type
			,d.mtg1_ur_doc_id
		
		UNION ALL
		
		SELECT 't2' AS _type
			,d.mtg2_ur_doc_id
		
		UNION ALL
		
		SELECT 't3' AS _type
			,d.mtg3_ur_doc_id
		
		UNION ALL
		
		SELECT 't4' AS _type
			,d.mtg4_ur_doc_id
		) dd
	
	UNION ALL
	
	SELECT d.DeedID
		,d.deed_type
		,d.FIPS
		,dd._type
		,dd.ur_doc_id 
		,d.CLGX_UNIQUE_ID
		,d.SRC_TBL
		,f._Y_doc_id
	FROM [Lien].[tmp].[DeedChildren_Input] f WITH (INDEX (idx)  )
	INNER JOIN [deed].[dbo].[deed] d WITH (
			INDEX (idx_mtg1_ur_doc_id)
			,NOLOCK
			) ON mtg1_ur_doc_id = f.doc_id
	OUTER APPLY (
		SELECT 'd' AS _type
			,d.ur_doc_id
		
		UNION ALL
		
		SELECT 't1' AS _type
			,d.mtg1_ur_doc_id
		
		UNION ALL
		
		SELECT 't2' AS _type
			,d.mtg2_ur_doc_id
		
		UNION ALL
		
		SELECT 't3' AS _type
			,d.mtg3_ur_doc_id
		
		UNION ALL
		
		SELECT 't4' AS _type
			,d.mtg4_ur_doc_id
		) dd
	
	UNION ALL
	
	SELECT d.DeedID
		,d.deed_type
		,d.FIPS
		,dd._type
		,dd.ur_doc_id 
		,d.CLGX_UNIQUE_ID
		,d.SRC_TBL
		,f._Y_doc_id
	FROM [Lien].[tmp].[DeedChildren_Input] f WITH (INDEX (idx)  )
	INNER JOIN [deed].[dbo].[deed] d WITH (
			INDEX (idx_mtg2_ur_doc_id)
			,NOLOCK
			) ON mtg2_ur_doc_id = f.doc_id
	OUTER APPLY (
		SELECT 'd' AS _type
			,d.ur_doc_id
		
		UNION ALL
		
		SELECT 't1' AS _type
			,d.mtg1_ur_doc_id
		
		UNION ALL
		
		SELECT 't2' AS _type
			,d.mtg2_ur_doc_id
		
		UNION ALL
		
		SELECT 't3' AS _type
			,d.mtg3_ur_doc_id
		
		UNION ALL
		
		SELECT 't4' AS _type
			,d.mtg4_ur_doc_id
		) dd
	
	UNION ALL
	
	SELECT d.DeedID
		,d.deed_type
		,d.FIPS
		,dd._type
		,dd.ur_doc_id 
		,d.CLGX_UNIQUE_ID
		,d.SRC_TBL
		,f._Y_doc_id
	FROM [Lien].[tmp].[DeedChildren_Input] f WITH (INDEX (idx)  )
	INNER JOIN [deed].[dbo].[deed] d WITH (
			INDEX (idx_mtg3_ur_doc_id)
			,NOLOCK
			) ON mtg3_ur_doc_id = f.doc_id
	OUTER APPLY (
		SELECT 'd' AS _type
			,d.ur_doc_id
		
		UNION ALL
		
		SELECT 't1' AS _type
			,d.mtg1_ur_doc_id
		
		UNION ALL
		
		SELECT 't2' AS _type
			,d.mtg2_ur_doc_id
		
		UNION ALL
		
		SELECT 't3' AS _type
			,d.mtg3_ur_doc_id
		
		UNION ALL
		
		SELECT 't4' AS _type
			,d.mtg4_ur_doc_id
		) dd
	
	UNION ALL
	
	SELECT d.DeedID
		,d.deed_type
		,d.FIPS
		,dd._type
		,dd.ur_doc_id 
		,d.CLGX_UNIQUE_ID
		,d.SRC_TBL
		,f._Y_doc_id
	FROM [Lien].[tmp].[DeedChildren_Input] f WITH (INDEX (idx)  )
	INNER JOIN [deed].[dbo].[deed] d WITH (
			INDEX (idx_mtg4_ur_doc_id)
			,NOLOCK
			) ON mtg4_ur_doc_id = f.doc_id
	OUTER APPLY (
		SELECT 'd' AS _type
			,d.ur_doc_id
		
		UNION ALL
		
		SELECT 't1' AS _type
			,d.mtg1_ur_doc_id
		
		UNION ALL
		
		SELECT 't2' AS _type
			,d.mtg2_ur_doc_id
		
		UNION ALL
		
		SELECT 't3' AS _type
			,d.mtg3_ur_doc_id
		
		UNION ALL
		
		SELECT 't4' AS _type
			,d.mtg4_ur_doc_id
		) dd
	) a
WHERE a.UR_Doc_Id IS NOT NULL

--SELECT * FROM lien.[tmp].[DeedChildren_Output]    


