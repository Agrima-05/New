/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Set_INFC_RunDates_Success | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */




-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>   
-- Description: <Description,,>  
-- =============================================  
CREATE PROCEDURE [Lien].[UR].[usp_Set_INFC_RunDates_Success] (
	@date_from DATETIME2 = null
	,@date_to DATETIME2 = null
	 ,@ERROR VARCHAR(500) OUTPUT
	)
AS
BEGIN TRY
EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_Set_INFC_RunDates_Success'
	,N'Started'

IF @date_from IS NULL
	OR @date_to IS NULL
	--or isdate(@date_from) = 0  
	--or isdate(@date_to) = 0  
BEGIN
	RAISERROR (
			'Please provide Input dates'
			,0
			,1
			,' '
			,0
			)

	RETURN
END

/******************************************************************************************************************  
CHANGE LOG:  
==========  
who  date  change  
paul 2022/06.08 create inital program  
This SP is called by the application that extract the doc_id's - UR to INFC process after it success fully processed the doc_ids  
Lien.UR.usp_Create_INFC_DocIdExtract created the extract list of doc_ids and display a date from and to  
This routine use the date from and to to update the control record to state that we successfully processed the doc_id's  
******************************************************************************************************************/
-- DECLARE   @date_from DATETIME = N'20221223 04:53:52.887' ,@date_to DATETIME = N'20221223 11:07:13.737'  
--SELECT @date_from AS N'@date_from'  
-- ,@date_to AS N'@date_to'  
--  
-- if date from and to is not provided then we retrieve the data between the last 2 extracts  
--  
--select @date_from as N'@date_from'  
--,@date_to as N'@date_to'  
--select a.*  
UPDATE [Lien].[UR].[a]
SET a.INFC_Extract_date = getdate()
FROM [Lien].[UR].[document_transaction_log_tracker] a
WHERE m_update_date > @date_from
	AND m_update_date <= @date_to

EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_Set_INFC_RunDates_Success'
	,N'Ended'

	
/****** Object:  StoredProcedure [UR].[usp_INFC_ETL_END]    Script Date: 7/6/2023 2:34:16 PM ******/
SET ANSI_NULLS ON

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	ROLLBACK
END CATCH

