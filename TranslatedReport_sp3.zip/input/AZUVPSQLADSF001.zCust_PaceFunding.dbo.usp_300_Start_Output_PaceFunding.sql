SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_PaceFunding].[dbo].[usp_300_Start_Output_PaceFunding]


AS
BEGIN
	
	SET NOCOUNT ON;



------	Notes Per CL - 20220601
----Hi Charysse – To summarize #’s 1, 2 & 4 below – they want to know:

----•	When a record goes On Market
----•	When a record that was previously sent to them as On Market goes Off Market (Fail or Sold)
----•	When a record that was previously sent to them as On Market OR Fail – goes to Sold


----1.	We would be monitoring for Status changes only & only when the status goes from On Market to Off Market or vice versa – correct (not all of the possible changes in between?)? On to off. 
----a.	Or Off to On? – ACTIVE to SOLD or FAIL
----2.	They understand that the status may go from on market – to Fail & then later to Sold - correct?  Do they also want the Sold update if there is one? YES
----3.	At what point do we stop monitoring the property (only when they send us a Delete record for that property?) they will send us a delete when they want us to stop. When they remove it. 
----4.	If the property is currently NOT listed – am I still to populate the 4 listing fields with the information from the old listing marked as CurrentListingInd = 1 (if there is one)?  Or is the OnMarket listing the starting point for tracking? No just flag it as isolated = N ON Market is the starting point. 



----For the ongoing monitor – below are the notes from the 20220328 email thread.  The items in Red are the outstanding questions so far:

----1.	We would be monitoring for Status changes only & only when the status goes from On Market to Off Market or vice versa – correct (not all of the possible changes in between?)? On to off. 
----a.	Or Off to On? – ACTIVE to SOLD or FAIL
----2.	They understand that the status may go from on market – to Fail & then later to Sold - correct?  Do they also want the Sold update if there is one? YES
----3.	At what point do we stop monitoring the property (only when they send us a Delete record for that property?) they will send us a delete when they want us to stop. When they remove it. 
----4.	If the property is currently NOT listed – am I still to populate the 4 listing fields with the information from the old listing marked as CurrentListingInd = 1 (if there is one)?  Or is the OnMarket listing the starting point for tracking? No just flag it as isolated = N ON Market is the starting point. 
----5.	It sounds like this may be a mailer company – do we need to apply Mailing criteria? These are their current customers of PACE liens. NO, remember they are NOT mailing, and we’re not even giving mailing information. 
----6.	What will the frequency of portfolio updates be? Weekly
----a.	We will need to automate the process: I will work with them on this.
----i.	File exchanges via SFTP (I can create one – just let me know)
----ii.	All Input files should be in same standardized format:
----1.	Either Pipe delimited txt file or csv file
----2.	With Unique ID per record
----3.	Same unique fields/column headers in the same order
----4.	Standardized input file naming convention
----iii.	Expected file upload frequency & volume (so we know how often/when to monitor the SFTP site for new files)
----iv.	Email distribution list for notifications & what notifications are required (upload, download etc)
 

 ------20220616 -Per CL - Extract ALL records  - but don't bring forward old data 
 ------- just populate Event Found data (other records will only have input fields populated)






		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[WORK_REF_ID] [bigint] NULL,
			
			[Input Unique ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[RunDate][varchar](250)NULL,
			[IsListed][varchar](250)NULL,
			[OrignalListingDate][varchar](250)NULL,
			[CurrentListingStatus][varchar](250)NULL,
			[LastListingStatusChangeDate][varchar](250)NULL,
			[LastListingStatusChange][varchar](250)NULL,
			[ListingTrackingID][varchar](250)NULL,
			[FAUniqueListingIdentifierRefID][varchar](250)NULL			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] ([Input Unique ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]	,
		FIPS,
		PROPERTYID)
		

		Select 
		[INPUTKEY]
      ,[INPUTADDRESS]
      ,[INPUTCITY]
      ,[INPUTSTATE]
      ,[INPUTZIP]
	  ,FIPS
	  ,PROPERTYID
       FROM [zCust_PaceFunding].[dbo].[INPUT_MONITOR]

		
		Select * From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]

		-------20220601 - Per CL - Only return records where the listing status (on market to off, off to on or Fail to Sold)
		-----OR NEW input record
	
	

	 				

		--UPDATE a 
		--SET a.[PROPERTYID] = c.[PROPERTYID]
		----,a.WORK_REF_ID = c.REF_ID
		--	,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT a JOIN a_PropMatch_WORK c on a.[INPUT UNIQUE ID] = c.RAW_ID

		
		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Set RunDate = convert(date,GetDate())
		
		
		--Update a
		--SET 
		----a.[Property Address] = c.FullStreetAddress
		----, a.City = c.City
		----, a.[State] = c.[State]
		----, a.[Zip Code] = c.Zip + c.Zip4
		----, 
		--a.RunDate = convert(date,GetDate())
		----, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT a JOIN a_ASP_IN_STD c
		--			ON a.[INPUT UNIQUE ID] = c.RAW_ID


		Update [zCust_PaceFunding].[dbo].[A]
		set 
		[Coverage Status] = B.MLSActive
		From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] a 
		JOIN [Global].[dbo].[COunty] as B on 
		A.FIPS = B.FIPSCODE


		
		UPDATE [zCust_PaceFunding].[dbo].[a]
		SET 
		A.[IsListed] = case when  B.Status in ('Active','Pending','Contingent') then 'Y' else 'N' end 
		,A.[OrignalListingDate] = B.CurrentOriginalListingDate
		,A.[CurrentListingStatus] = B.Status
		,A.[LastListingStatusChangeDate] = B.LastListingStatusChangeDate
		,A.[LastListingStatusChange] = B.LastListingStatusChange
		,A.[ListingTrackingID] = B.ListingTrackingID
		,A.[FAUniqueListingIdentifierRefID] = B.FAUniqueListingIdentifierRefID
		--Select C.[CurrentListingStatus] ,B.Status
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[vListings_Current_NEW_STD] as B with(NOLOCK)
		on A.FIPS = B.FIPS  and 
		a.PROPERTYID = b.PROPERTYID
		join [zCust_PaceFunding].[dbo].[INPUT_MONITOR] as C with(NOLOCK) On A.[Input Unique ID] = C.INPUTKEY
		where A.PROPERTYID is not null and A.PROPERTYID not like '' and A.PROPERTYID not like '0'
		AND B.CurrentListingInd like 'Y'
		AND B.[Add,Change,DeleteIndicator] not like 'D'
		AND 
		(
			(C.[CurrentListingStatus] is null AND  B.Status in ('Active','Pending','Contingent')  ) OR
			(C.[CurrentListingStatus] in ('Active','Pending','Contingent') and B.Status in ('Fail','Sold')) OR
			(C.[CurrentListingStatus] in ('Fail') and B.Status in ('Sold')) OR
			(C.[CurrentListingStatus] in ('Fail','Sold') and B.Status in ('Active','Pending','Contingent')) 
		
		)

			
		------Only used this for the Initial Extract!!----
		--UPDATE x_Custom_OUTPUT
		--SET 
		--[IsListed] = case when  ISNULL([IsListed],'')  like '' then 'N' else [IsListed] end 

		
		Select [IsListed], count(*)  from [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [IsListed]

				
		Select top 100000 * From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]

		----------------------

		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_PaceFunding].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] a join [zCust_PaceFunding].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT UNIQUE ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		AND (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 


	

		Update [zCust_PaceFunding].[dbo].[A]
		SET A.[Event Status] = 'Event Found' 
		--Select A.CurrentListingStatus, B.CurrentListingStatus
		From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] as A join [zCust_PaceFunding].[dbo].[INPUT_MONITOR] as B on 
		A.[Input Unique ID] = B.INPUTKEY
		WHERE 
		(
			(B.[CurrentListingStatus] is null AND  A.CurrentListingStatus in ('Active','Pending','Contingent')  ) OR
			(B.[CurrentListingStatus] in ('Active','Pending','Contingent') and A.CurrentListingStatus in ('Fail','Sold')) OR
			(B.[CurrentListingStatus] in ('Fail') and A.CurrentListingStatus in ('Sold')) OR
			(B.[CurrentListingStatus] in ('Fail','Sold') and A.CurrentListingStatus in ('Active','Pending','Contingent')) 
		
		)

		UPdate [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Set [Event Status] = 'Event Not Found'
		where [Event Status] is null

			
		Update  [zCust_PaceFunding].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_PaceFunding].[dbo].[a_ASP_IN_STD] b
		on a.[Input Unique ID] = b.Raw_ID

		
	
		Select [Property Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

		Select [Coverage Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [Coverage Status]

		Select AddressStandardization, count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Group by AddressStandardization

		Select [Event Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]
		Group by [Event Status]


		Select * From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT]



END




