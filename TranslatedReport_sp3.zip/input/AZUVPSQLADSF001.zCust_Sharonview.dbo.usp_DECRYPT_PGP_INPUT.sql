SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [zCust_Sharonview].[dbo].[usp_DECRYPT_PGP_INPUT] 
	
AS
BEGIN

	EXEC msdb.dbo.sp_start_job N'Sharonview_Decrypt_PGP' ; 

			
		
END




