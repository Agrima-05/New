/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.usp_Match_request_complete | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

 create   PROCEDURE [Pet_Match_service].[pet_mtc].[usp_Match_request_complete] @fileid INT
AS
DECLARE @msg VARCHAR(500) = 'usp_APN_Match_request_complete - fileid: ' + try_cast(@fileid AS VARCHAR(20))

EXEC [pet_Match_Service].[pet_mtc].[Add_match_Log] N'info'
	,@msg
	,N'Started'

BEGIN TRANSACTION

UPDATE [Pet_Match_service].[pet_mtc].[a]
SET a.req_status = 'C'
	,a.Updated = getdate()
FROM [PET_Match_Service].[pet_mtc].[match_Request] a
WHERE a.Fileid = @fileid

COMMIT

EXEC [pet_Match_Service].[pet_mtc].[Add_match_Log] N'info'
	,@msg
	,N'Ended'

