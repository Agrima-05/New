SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_Pinnacle].[dbo].[usp_502_Pull_FLANK_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK
		UPDATE [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK]
		SET FIPS = '0' + FIPS
		WHERE LEN(FIPS)=4

		

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end as DocNbrSrce
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower
		, CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END as BuyerBorrower2
		
		,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SaleDate,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,a.Loan1LenderName as NewLenderAssignee
		,A.Buyer1FirstName,A.Buyer1FirstNameMiddleInitial,A.Buyer1LastName, A.Buyer1LastNameOrCorpName
		INTO [zCust_Pinnacle].[dbo].[w_FLANK_DEEDS]
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.DeedTransactionType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES

		IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end as DocNbrSrce
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower
		, case when Borrower2FullName is null then Borrower2CompanyName else Borrower2FullName end as BuyerBorrower2
		,LenderName AS SellerLender,LoanAmount,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.LenderName as NewLenderAssignee,ContractDate
		,A.Borrower1FirstName,A.Borrower1FirstNameMiddleInitial,A.Borrower1LastName,A.Borrower1LastNameMiddleInitial
		INTO [zCust_Pinnacle].[dbo].[w_FLANK_MTG]
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d  with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.LoanTransType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_Pinnacle].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,Loan1TransactionID,FAPropertyID,Loan1RecordingDt
		--,Loan1Document
		,case when ISNULL(A.Loan1CMTIDInstNbr,'') like '' then  Loan1Document else A.Loan1CMTIDInstNbr end as Loan1Document
		,Loan1Book,Loan1Page,NULL,NULL
		,left((CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END),70) as BuyerBorrower
		,left((CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END),70) as BuyerBorrower2
		,left(Loan1LenderName,40) AS SellerLender
		,Loan1Amount,Loan1DocumentTypeCode,d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,left(a.Loan1LenderName,40) as NewLenderAssignee,NULL
		,left(A.Buyer1FirstName,40)
		,left(A.Buyer1FirstNameMiddleInitial,40)
		,left(A.Buyer1LastName,60)
		,left(A.Buyer1LastNameOrCorpName,40)
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		ORDER BY RAW_ID,RecordingDt 


		INSERT INTO [zCust_Pinnacle].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,Loan2TransactionID,FAPropertyID,Loan2RecordingDt
		--,Loan2Document
		,case when ISNULL(A.Loan2CMTIDInstNbr,'') like '' then  Loan2Document else A.Loan2CMTIDInstNbr end 
		,Loan2Book,Loan2Page,NULL,NULL
		,LEFT((CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END),70) as BuyerBorrower
		,LEFT((CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END),70) as BuyerBorrower2
		,left(Loan2LenderName,40) AS SellerLender,Loan2Amount,Loan2DocumentTypeCode,d.CodeDesc as DocType
		,Loan2TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,left(a.Loan2LenderName,40) as NewLenderAssignee,NULL
		,left(A.Buyer1FirstName,40)
		,left(A.Buyer1FirstNameMiddleInitial,40)
		,left(A.Buyer1LastName,60)
		,left(A.Buyer1LastNameOrCorpName,40)
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		ORDER BY RAW_ID,RecordingDt 

		----ASSIGN/REL

		

		IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end as DocNbrSrce
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt
		,case when ISNULL(A.OrigLoanCMTIDInstNbr,'') like '' then   OrigDeedDocNbr else A.OrigLoanCMTIDInstNbr end as OrigDeedDocNbr
		,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'A' as DocSrcInd,[ChronoKey],Assignee,AssignorName as Assignor,REF_ID
		,a.Assignee1CompanyName as NewLenderAssignee,AssignorName as OldLenderAssignor
		,A.Loan_FA_YearDocNbrFmt
		INTO [zCust_Pinnacle].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		


		INSERT INTO [zCust_Pinnacle].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt
		,case when ISNULL(A.CMTIDInstNbr,'') like '' then  DocNbrSrce else A.CMTIDInstNbr end
		,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt
		,case when ISNULL(A.OrigLoanCMTIDInstNbr,'') like '' then   OrigDeedDocNbr else A.OrigLoanCMTIDInstNbr end
		,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'R' as DocSrcInd,[ChronoKey],NULL,NULL,REF_ID
		,a.OrigLenderBen as NewLenderAssignee, NULL
		,A.Loan_FA_YearDocNbrFmt
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		UPDATE [zCust_Pinnacle].[dbo].[w_Flank_ASR]
		SET OrigDeedRecordingDt = NULL
		where isDATE(OrigDeedRecordingDt)=0

		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_Pinnacle].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType,REF_ID
		INTO [zCust_Pinnacle].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_Pinnacle].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentType = d.DocTypeID
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		


		---- CREATE TransHist 

		TRUNCATE TABLE w_TransHist_FLANK

		INSERT INTO [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate]
			  ,[BuyerBorrowerFirstNameMI]
			  ,[BuyerBorrowerLastNameMI]
			  ,[BuyerBorrower2])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			   ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,SaleDate
			  ,Buyer1FirstNameMiddleInitial
			  ,Buyer1LastNameOrCorpName
			  ,[BuyerBorrower2]
		FROM [zCust_Pinnacle].[dbo].[w_FLANK_DEEDS]


		INSERT INTO [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			   ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate] 
			  ,[BuyerBorrowerFirstNameMI]
			  ,[BuyerBorrowerLastNameMI]
			  ,[BuyerBorrower2])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			   ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,ContractDate
			  ,Borrower1FirstNameMiddleInitial
			  ,Borrower1LastNameMiddleInitial
			  ,[BuyerBorrower2]
		FROM [zCust_Pinnacle].[dbo].[w_FLANK_MTG]

		INSERT INTO [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			   ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[OrigLoanFAYearFmtDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			   ,[BookSrce]
			  ,[PageSrce]
			  ,left([BuyerBorrower],250)
			  ,NULL
			  ,NULL
			  ,OrigDeedRecordingDt
			  ,case When OrigDeedDocNbr is null then OrigDeedBook + '.' + OrigDeedPage ELSE  OrigDeedDocNbr END
			  ,Loan_FA_YearDocNbrFmt
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,left(Assignee,250)
			  ,left(Assignor,250)
			  ,[OrigLoanAmt]
		FROM [zCust_Pinnacle].[dbo].[w_FLANK_ASR]

		INSERT INTO [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			   ,[BookSrce]
			  ,[PageSrce]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct FIPS
			  ,FAPropertyID
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			   ,[BookSrce]
			  ,[PageSrce]
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigNODDocumentNbr
			  ,NULL
			  ,NULL
			  ,'B'
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,OrigBeneficiaryLender
			  ,NULL
			  ,OrigLoanAmt
		FROM [zCust_Pinnacle].[dbo].[w_FLANK_NOD]

		UPDATE [zCust_Pinnacle].[dbo].[a]
		SET FA_DocNbrFmt = c.FA_DocNbrFmt
		,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		,FA_BookPageFmt = c.FA_BookPageFmt
		,FA_YearBookPageFmt = c.FA_YearBookPageFmt
        ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
        ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
        ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
        ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
        ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		FROM [zCust_Pinnacle].[dbo].[w_TransHist_FLANK] a 
		JOIN [global].[dbo].[Transaction_Master] c with(NOLOCK)
		on a.FIPS = c.FIPS
		and a.Doc_Id = c.TransactionID
		Where C.FIPS in(Select Distinct FIPS from [zCust_Pinnacle].[dbo].[w_TransHist_FLANK])

		--UPDATE a 
		--set a.REF_ID = b.REF_ID
		--FROM w_transHist_Flank a JOIN a_PropMatch_Work_FLANK b
		--on convert(int,a.Fips) = convert(int,b.Fips)
		--and a.ref_id = b.propertyID

		  UPDATE [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]
		  SET CmtID = case when FA_CMTID_YearDocNum is not null then FA_CMTID_YearDocNum
			WHEN FA_CMTID_BookPage is not null then FA_CMTID_BookPage
			WHEN FA_CMTID_YearDAteDocNum is not null then FA_CMTID_YearDAteDocNum
			WHEN FA_CMTID_DocNum is not null then FA_CMTID_DocNum
			WHEN FA_CMTID_YearBookPage is not null then FA_CMTID_YearBookPage
			END

		  UPDATE [zCust_Pinnacle].[dbo].[w_TransHist_FLANK]
		  SET CmtID = 1091
		  WHERE FIPS = 17031
END





