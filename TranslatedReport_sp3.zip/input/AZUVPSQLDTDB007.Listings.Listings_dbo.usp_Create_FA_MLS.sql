/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Create_FA_MLS | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Create_FA_MLS] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation





******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Create_FA_MLS'

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'

	DECLARE @update_flag_date VARCHAR(10) = try_cast(getdate() AS DATE)

	DELETE
	FROM [LISTINGS].[Listings_dbo].[FA_MLS]
	WHERE update_flag_date = @update_flag_date

	--TRUNCATE TABLE [LISTINGS].[Listings_dbo].[FA_MLS] -- ??????????????????????????????????????????? remove when we run multiple days

	INSERT INTO [LISTINGS].[Listings_dbo].[FA_MLS] (
		[Property_ID]
		,[MLS_ID]
		,[APN]
		,[MLS_STATUS]
		,[MLS_LIST_DATE]
		,[SOLD_DATE]
		,[MLS_DAYS_ON_MARKET]
		,[HOUSE_NBR]
		,[STREET]
		,[CITY]
		,[STATE]
		,[ZIP]
		,[COUNTY_NAME]
		,[MLS_AREA]
		,[ZONING]
		,[PROPERTY_DETAILS]
		,[NBR_BEDRMS]
		,[NBR_BATH]
		,[HOME_SIZE]
		,[LOT_SIZE]
		,[LOT_FTRS]
		,[MLS_LIST_PRICE]
		,[SOLD_PRICE]
		,[PRICE_PER_SQFT]
		,[PROPERTY_TYPE]
		,[PROPERTY_SUB_TYPE]
		,[YEAR_BUILT]
		,[NEIGHBORHOOD]
		,[STYLE]
		,[NBR_STORIES]
		,[NBR_GRG]
		,[SCHOOL_DISTRICT]
		,[ELEMENTARY_SCHOOL]
		,[MIDDLE_SCHOOL]
		,[HIGH_SCHOOL]
		,[FIREPLACE_FTRS]
		,[HEATING_FTRS]
		,[EXTERIOR_CONSTRUCTION]
		,[ROOFING]
		,[INTERIOR_FTRS]
		,[EXTERIOR_FTRS]
		,[UTILITY_PRESENT]
		,[COOLING_FTRS]
		,[TOPOGRAPHY]
		,[PARCEL_ACCESS]
		,[MLS_INCLUSIONS]
		,[SUBDIVISION]
		,[RANGE_AIRCONDITIONERS]
		,[WATER_HEATERS]
		,[ENERGY_INFO]
		,[PARKING_FTRS]
		,[APX_LOT_DIMENSIONS]
		,[COMMUNITY_FTRS]
		,[POOL_FTRS]
		,[WATER_FRONT_FTRS]
		,[AIR_CONDITIONERS]
		,[VIEW_1]
		,[EXISTING_STRUCTURES]
		,[MASTER_BEDROOM]
		,[COMPLEX_FTRS]
		,[PRESENT_USE]
		,[APX_LOT_IS_L85]
		,[APPLIANCES]
		,[WATER]
		,[FARM_IMPROVEMENT]
		,[WATER_ACCESS]
		,[WATER_HEATER]
		,[SEWER]
		,[OTHER_FTRS]
		,[BSMT_FIN_SQFT]
		,[MLS_OFFICE_NAME]
		,[MLS_OFFICE_EMAIL]
		,[MLS_OFFICE_ADDRESS]
		,[MLS_OFFICE_PHONE]
		,[MLS_LISTING_AGENT_LICENSE_NBR]
		,[MLS_LISTING_AGENT_NAME]
		,[MLS_LISTING_AGENT_ADDRESS]
		,[MLS_LISTING_AGENT_PHONE]
		,[MLS_LISTING_AGENT_COMPANY]
		,[MLS_LISTING_AGENT_EMAIL]
		,[MLS_NAME]
		,[UPDATE_FLAG]
		,[UPDATE_FLAG_DATE]
		,[Fips]
		,[Flag]
		,[REF_ID]
		,[Created]
		,[Updated]
		,[MATCH_CODE]
		,[Raw_Std_Addrid]
		,[PROVIDER_TYPE]
		,[LISTING_AGENT_PHONE1]
		,[LISTING_AGENT_PHONE1_DESCRIPTION]
		,[LISTING_AGENT_PHONE2]
		,[LISTING_AGENT_PHONE2_DESCRIPTION]
		,[LISTING_AGENT_PHONE3]
		,[LISTING_AGENT_PHONE3_DESCRIPTION]
		,[LISTING_AGENT_PHONE4]
		,[LISTING_AGENT_PHONE4_DESCRIPTION]
		,[LISTING_AGENT_PHONE5]
		,[LISTING_AGENT_PHONE5_DESCRIPTION]
		,[LISTING_AGENT2_FULL_NAME]
		,[LISTING_AGENT2_LICENSE_NBR]
		,[LISTING_AGENT2_COMPANY]
		,[LISTING_AGENT2_ADDRESS]
		,[LISTING_AGENT2_PHONE1]
		,[LISTING_AGENT2_PHONE1_DESCRIPTION]
		,[LISTING_AGENT2_PHONE2]
		,[LISTING_AGENT2_PHONE2_DESCRIPTION]
		,[LISTING_AGENT2_PHONE3]
		,[LISTING_AGENT2_PHONE3_DESCRIPTION]
		,[LISTING_AGENT2_PHONE4]
		,[LISTING_AGENT2_PHONE4_DESCRIPTION]
		,[LISTING_AGENT2_PHONE5]
		,[LISTING_AGENT2_PHONE5_DESCRIPTION]
		,[LISTING_AGENT2_EMAIL]
		,[LISTING_OFFICE2_NAME]
		,[LISTING_OFFICE2_ADDRESS]
		,[LISTING_OFFICE2_PHONE]
		,[LISTING_OFFICE2_EMAIL]
		,[SEL_AGENT_FULL_NAME]
		,[SEL_AGENT_LICENSE_NBR]
		,[SEL_AGENT_COMPANY]
		,[SEL_AGENT_ADDRESS]
		,[SEL_AGENT_PHONE1]
		,[SEL_AGENT_PHONE1_DESCRIPTION]
		,[SEL_AGENT_PHONE2]
		,[SEL_AGENT_PHONE2_DESCRIPTION]
		,[SEL_AGENT_PHONE3]
		,[SEL_AGENT_PHONE3_DESCRIPTION]
		,[SEL_AGENT_PHONE4]
		,[SEL_AGENT_PHONE4_DESCRIPTION]
		,[SEL_AGENT_PHONE5]
		,[SEL_AGENT_PHONE5_DESCRIPTION]
		,[SEL_AGENT_EMAIL]
		,[SEL_OFFICE_NAME]
		,[SEL_OFFICE_ADDRESS]
		,[SEL_OFFICE_PHONE]
		,[SEL_OFFICE_EMAIL]
		,[SEL_AGENT2_FULL_NAME]
		,[SEL_AGENT2_LICENSE_NBR]
		,[SEL_AGENT2_COMPANY]
		,[SEL_AGENT2_ADDRESS]
		,[SEL_AGENT2_EMAIL]
		,[SEL_AGENT2_PHONE1]
		,[SEL_AGENT2_PHONE1_DESCRIPTION]
		,[SEL_AGENT2_PHONE2]
		,[SEL_AGENT2_PHONE2_DESCRIPTION]
		,[SEL_AGENT2_PHONE3]
		,[SEL_AGENT2_PHONE3_DESCRIPTION]
		,[SEL_AGENT2_PHONE4]
		,[SEL_AGENT2_PHONE4_DESCRIPTION]
		,[SEL_AGENT2_PHONE5]
		,[SEL_AGENT2_PHONE5_DESCRIPTION]
		,[SEL_OFFICE2_NAME]
		,[SEL_OFFICE2_ADDRESS]
		,[SEL_OFFICE2_PHONE]
		,[SEL_OFFICE2_EMAIL]
		,[Original_UPDATE_FLAG_DATE]
		,[Raw_Address]
		)
	SELECT a.[Property_ID]
		,a.[MLS_ID]
		,a.[APN]
		,a.[MLS_STATUS]
		,a.[MLS_LIST_DATE]
		,a.[SOLD_DATE]
		,a.[MLS_DAYS_ON_MARKET]
		,a.[HOUSE_NBR]           --              looking for the missing house number
		--,b.HouseNumber as house_nbr
		,a.[STREET]
		,a.[CITY]
		,a.[STATE_1]
		,a.[ZIP]
		,a.[COUNTY_NAME]
		--,b.[CITY]
		--,b.STD_State AS [STATE]
		--,b.[ZIP]
		--,b.[COUNTYNAME]
		,a.[MLS_AREA]
		,a.[ZONING]
		,a.[PROPERTY_DETAILS]
		,a.[NBR_BEDRMS]
		,a.[NBR_BATH]
		,a.[HOME_SIZE]
		,a.[LOT_SIZE]
		,a.[LOT_FTRS]
		,a.[MLS_LIST_PRICE]
		,a.[SOLD_PRICE]
		,a.[PRICE_PER_SQFT]
		,a.[PROPERTY_TYPE]
		,a.[PROPERTY_SUB_TYPE]
		,a.[YEAR_BUILT]
		,a.[NEIGHBORHOOD]
		,a.[STYLE]
		,a.[NBR_STORIES]
		,a.[NBR_GRG]
		,a.[SCHOOL_DISTRICT]
		,a.[ELEMENTARY_SCHOOL]
		,a.[MIDDLE_SCHOOL]
		,a.[HIGH_SCHOOL]
		,a.[FIREPLACE_FTRS]
		,a.[HEATING_FTRS]
		,a.[EXTERIOR_CONSTRUCTION]
		,a.[ROOFING]
		,a.[INTERIOR_FTRS]
		,a.[EXTERIOR_FTRS]
		,a.[UTILITY_PRESENT]
		,a.[COOLING_FTRS]
		,a.[TOPOGRAPHY]
		,a.[PARCEL_ACCESS]
		,a.[MLS_INCLUSIONS]
		,a.[SUBDIVISION]
		,a.[RANGE_AIRCONDITIONERS]
		,a.[WATER_HEATERS]
		,a.[ENERGY_INFO]
		,a.[PARKING_FTRS]
		,a.[APX_LOT_DIMENSIONS]
		,a.[COMMUNITY_FTRS]
		,a.[POOL_FTRS]
		,a.[WATER_FRONT_FTRS]
		,a.[AIR_CONDITIONERS]
		,a.[VIEW_1]
		,a.[EXISTING_STRUCTURES]
		,a.[MASTER_BEDROOM]
		,a.[COMPLEX_FTRS]
		,a.[PRESENT_USE]
		,a.[APX_LOT_IS_L85]
		,a.[APPLIANCES]
		,a.[WATER]
		,a.[FARM_IMPROVEMENT]
		,a.[WATER_ACCESS]
		,a.[WATER_HEATER]
		,a.[SEWER]
		,a.[OTHER_FTRS]
		,a.[BSMT_FIN_SQFT]
		,a.[MLS_OFFICE_NAME]
		,a.[MLS_OFFICE_EMAIL]
		,a.[MLS_OFFICE_ADDRESS]
		,a.[MLS_OFFICE_PHONE]
		,a.[MLS_LISTING_AGENT_LICENSE_NBR]
		,a.[MLS_LISTING_AGENT_NAME]
		,a.[MLS_LISTING_AGENT_ADDRESS]
		,a.[MLS_LISTING_AGENT_PHONE]
		,a.[MLS_LISTING_AGENT_COMPANY]
		,a.[MLS_LISTING_AGENT_EMAIL]
		,a.[MLS_NAME]
		,a.[UPDATE_FLAG]
		,a.[UPDATE_FLAG_DATE]
		,f.Fips AS [Fips]
		,0 AS [Flag]
		,f.REF_ID AS ref_id
		,getdate() AS [Created]
		,getdate() AS [Updated]
		,b.[MATCH_CODE]
		,b.row_id AS [Raw_Std_Addrid]
		,a.[PROVIDER_TYPE]
		,a.[LISTING_AGENT_PHONE1]
		,a.[LISTING_AGENT_PHONE1_DESCRIPTION]
		,a.[LISTING_AGENT_PHONE2]
		,a.[LISTING_AGENT_PHONE2_DESCRIPTION]
		,a.[LISTING_AGENT_PHONE3]
		,a.[LISTING_AGENT_PHONE3_DESCRIPTION]
		,a.[LISTING_AGENT_PHONE4]
		,a.[LISTING_AGENT_PHONE4_DESCRIPTION]
		,a.[LISTING_AGENT_PHONE5]
		,a.[LISTING_AGENT_PHONE5_DESCRIPTION]
		,a.[LISTING_AGENT2_FULL_NAME]
		,a.[LISTING_AGENT2_LICENSE_NBR]
		,a.[LISTING_AGENT2_COMPANY]
		,a.[LISTING_AGENT2_ADDRESS]
		,a.[LISTING_AGENT2_PHONE1]
		,a.[LISTING_AGENT2_PHONE1_DESCRIPTION]
		,a.[LISTING_AGENT2_PHONE2]
		,a.[LISTING_AGENT2_PHONE2_DESCRIPTION]
		,a.[LISTING_AGENT2_PHONE3]
		,a.[LISTING_AGENT2_PHONE3_DESCRIPTION]
		,a.[LISTING_AGENT2_PHONE4]
		,a.[LISTING_AGENT2_PHONE4_DESCRIPTION]
		,a.[LISTING_AGENT2_PHONE5]
		,a.[LISTING_AGENT2_PHONE5_DESCRIPTION]
		,a.[LISTING_AGENT2_EMAIL]
		,a.[LISTING_OFFICE2_NAME]
		,a.[LISTING_OFFICE2_ADDRESS]
		,a.[LISTING_OFFICE2_PHONE]
		,a.[LISTING_OFFICE2_EMAIL]
		,a.[SEL_AGENT_FULL_NAME]
		,a.[SEL_AGENT_LICENSE_NBR]
		,a.[SEL_AGENT_COMPANY]
		,a.[SEL_AGENT_ADDRESS]
		,a.[SEL_AGENT_PHONE1]
		,a.[SEL_AGENT_PHONE1_DESCRIPTION]
		,a.[SEL_AGENT_PHONE2]
		,a.[SEL_AGENT_PHONE2_DESCRIPTION]
		,a.[SEL_AGENT_PHONE3]
		,a.[SEL_AGENT_PHONE3_DESCRIPTION]
		,a.[SEL_AGENT_PHONE4]
		,a.[SEL_AGENT_PHONE4_DESCRIPTION]
		,a.[SEL_AGENT_PHONE5]
		,a.[SEL_AGENT_PHONE5_DESCRIPTION]
		,a.[SEL_AGENT_EMAIL]
		,a.[SEL_OFFICE_NAME]
		,a.[SEL_OFFICE_ADDRESS]
		,a.[SEL_OFFICE_PHONE]
		,a.[SEL_OFFICE_EMAIL]
		,a.[SEL_AGENT2_FULL_NAME]
		,a.[SEL_AGENT2_LICENSE_NBR]
		,a.[SEL_AGENT2_COMPANY]
		,a.[SEL_AGENT2_ADDRESS]
		,a.[SEL_AGENT2_EMAIL]
		,a.[SEL_AGENT2_PHONE1]
		,a.[SEL_AGENT2_PHONE1_DESCRIPTION]
		,a.[SEL_AGENT2_PHONE2]
		,a.[SEL_AGENT2_PHONE2_DESCRIPTION]
		,a.[SEL_AGENT2_PHONE3]
		,a.[SEL_AGENT2_PHONE3_DESCRIPTION]
		,a.[SEL_AGENT2_PHONE4]
		,a.[SEL_AGENT2_PHONE4_DESCRIPTION]
		,a.[SEL_AGENT2_PHONE5]
		,a.[SEL_AGENT2_PHONE5_DESCRIPTION]
		,a.[SEL_OFFICE2_NAME]
		,a.[SEL_OFFICE2_ADDRESS]
		,a.[SEL_OFFICE2_PHONE]
		,a.[SEL_OFFICE2_EMAIL]
		,@update_flag_date AS [Original_UPDATE_FLAG_DATE]
		,a.[Raw_Address]
	FROM [LISTINGS].[Listings_dbo].[FA_MLS_Wrk] a WITH (
			NOLOCK
			,INDEX (idx_raw_address)
			)
	LEFT JOIN [LISTINGS].[Listings_dbo].[Listings_Raw_Std_Address] b WITH (
			NOLOCK
			,INDEX (Idx_RawAddress)
			) ON b.Raw_Address = a.Raw_Address
	OUTER APPLY (
		SELECT nullif(lr.fips,0) as Fips
			,nullif(lr.ref_id,0) as Ref_id
		FROM [LISTINGS].[Listings_tmp].[Pet_Apn_Match_result] lr WITH (
				NOLOCK
				,INDEX (idx_id_2)
				)
		WHERE lr.id = a.row_id
			AND (
				(
					b.Raw_STREET > ''
					AND lr.Street_Number = b.Street_Number
					AND lr.Street_Name = b.Street_Name
					AND lr.Direction = b.Direction
					AND lr.unit = b.unit
					)
				OR Raw_STREET = ''
				)
		) lr
	OUTER APPLY (
		SELECT TOP 1 nullif(c.fips,0) as Fips
			,nullif(c.ref_id,0) as Ref_id
		FROM [famls].[dbo].[fa_mls] c WITH (
				NOLOCK
				,INDEX (idx_property_id)
				)
		WHERE c.property_id = a.property_id
			AND c.MLS_ID = a.MLS_ID
		ORDER BY c.update_flag_date DESC
		) c
	OUTER APPLY (
		SELECT CASE 
				WHEN b.REF_ID IS NOT NULL
					THEN b.fips
				WHEN lr.ref_id IS NOT NULL
					THEN lr.fips
				WHEN c.REF_ID IS NOT NULL
					THEN c.fips
				ELSE coalesce(b.fips, c.fips)
				END AS fips
			,CASE 
				WHEN b.REF_ID IS NOT NULL
					THEN b.REF_ID
				WHEN lr.ref_id IS NOT NULL
					THEN lr.ref_id
				WHEN c.REF_ID IS NOT NULL
					THEN c.REF_ID
				ELSE NULL
				END AS ref_id
		) f
	--WHERE b.Raw_Address IS NOT NULL
	--	AND b.fips > 0
	WHERE f.fips > 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


