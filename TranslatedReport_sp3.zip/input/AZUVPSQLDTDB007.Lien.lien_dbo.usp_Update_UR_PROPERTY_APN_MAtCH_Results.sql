/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | lien_dbo.usp_Update_UR_PROPERTY_APN_MAtCH_Results | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Lien].[lien_dbo].[usp_Update_UR_PROPERTY_APN_MAtCH_Results] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who  date  change  
Marie 2025/01/31 Initial Creation  
  
******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT  
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Update_UR_PROPERTY_APN_MAtCH_Results'
		,N'Started'

	--DECLARE @SQL VARCHAR(MAX)  
	-- ,@LinkSvr VARCHAR(100) = ''  
	--EXEC Lien.[LEAP].[AddLeapLog] N'info'  
	-- ,N'usp_UpdateAPNMatch'  
	-- ,N'Started'  
	--DROP TABLE if exists #Temp
	--select p.property_id
	--into #temp
	--FROM lien.[UR].[PROPERTY] p with(nolock,index(PK_PROPERTY))
	--LEFT JOIN lien.[UR].[PROPERTY_APN_MAtCH] pa with(nolock,index(ix_propid_Ref_Code_apn ))ON pa.Property_id = p.Property_id
	--where p.[legal_desc_apn] IS NOT NULL
	--and pa.Property_id is null
	-- declare @fileid int = 42
	INSERT INTO [lien].[UR].[PROPERTY_APN_MAtCH] (
		[Property_id]
		,[DOC_ID]
		,[Fips]
		,[Ref_id]
		,[Match_code]
		,[Apn]
		,[Created]
		,[Updated]
		,[Use_Actual_Fips]
		)
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.Created
		,'usp_Update_UR_PROPERTY_APN_MAtCH_Results' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	SELECT -- [Fileid]
		[id] AS property_id
		,p.doc_id
		,coalesce(a.Match_Fips, a.fips) AS [Fips]
		,ar.[Ref_id]
		,substring(a.Apn_type, 1, 4) AS [Match_code]
		,a.[APN]
		,getdate() AS [Created]
		,getdate() AS [Updated]
		,NULL AS [Use_Actual_Fips]
	FROM [Lien].[tmp].[Pet_Apn_Match_result] a WITH (
			NOLOCK
			,INDEX (idx_id)
			)
	OUTER APPLY (
		SELECT doc_id
		FROM [lien].[ur].[property] p WITH (
				NOLOCK
				,INDEX (PK_PROPERTY)
				)
		WHERE p.property_id = a.id
		) p
	outer apply (Select assrid, ref_id, fips  from [assr].[dbo].[assr] ar with(nolock,index(IDX_Assr_Ref_ID))
		where ar.ref_id = a.ref_id
	) ar

	WHERE a.fileid = @fileid

	--select * from lien.[tmp].[Pet_Apn_Match_result]
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Update_UR_PROPERTY_APN_MAtCH_Results'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK  
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


