/* Source: AZUVPSQLDRGN004.datatree.local | NameParser | dbo.GetCleanup | type=P */
CREATE PROCEDURE [NameParser].[dbo].[GetCleanup] (@Type VARCHAR(200))
AS
	DECLARE @Result VARCHAR(MAX) = ''
	SELECT @Result = @Result + '|' + Value
	FROM [NameParser].[dbo].[Cleanup]
	WHERE Type = @Type
	SELECT CASE WHEN LEN(@Result) > 1 THEN ISNULL('\b(' + RIGHT(@Result, LEN(@Result) - 1) + ')\b', '') END AS Pattern

