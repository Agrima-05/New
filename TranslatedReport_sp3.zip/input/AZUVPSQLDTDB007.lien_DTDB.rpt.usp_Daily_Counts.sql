/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | rpt.usp_Daily_Counts | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

/*
-- =============================================
USE [LIEN_DTDB]
GO

DECLARE	@return_value int

EXEC	@return_value = [rpt].[usp_Daily_Counts]

SELECT	'Return Value' = @return_value

GO

-- =============================================
*/
CREATE PROCEDURE [lien_DTDB].[rpt].[usp_Daily_Counts]
AS
BEGIN
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[lien_doc_ids]
		SELECT doc_id
			,m_update_date
			,fips_code
			,Fips
			,Instrument_nbr
			,recording_date_d
			,m_status_id
			,reprocess_flag
			,ur_matrix
			,previous_doc_unique_id
			,update_type
			,doc_title
			,doc_type
			,try_cast(0 AS INT) AS non_dtdb_doctype
			,try_cast(0 AS INT) AS deed_input
			,try_cast(0 AS INT) AS ras_input
			,try_cast(0 AS INT) AS PFC_input
			,try_cast(0 AS INT) AS HOA_input
			,try_cast(0 AS INT) AS LEAP_input
			,try_cast(0 AS INT) AS PACE_input
			,try_cast(0 AS INT) AS Fips_not_deployed
			,try_cast(0 AS INT) AS M_status_id_3
			,try_cast(0 AS INT) AS M_status_id_4
			,try_cast(0 AS INT) AS M_status_id_5
			,try_cast(0 AS INT) AS M_status_id_6
			,try_cast(0 AS INT) AS M_status_id_7
			,try_cast(0 AS INT) AS M_status_id_1
			,try_cast(0 AS INT) AS relative_included
			,try_cast(0 AS INT) AS Docid_with_Prop_Ref_Name
			,try_cast(0 AS INT) AS Dupl_deed
			,try_cast(0 AS INT) AS Dupl_Mtg
			,try_cast(0 AS INT) AS Dupl_Ras
			,try_cast(0 AS INT) AS Dupl_Pfc
			,try_cast(0 AS INT) AS DeedRecord
			,try_cast(0 AS INT) AS Concurr_mtg
			,try_cast(0 AS INT) AS Stand_alone_mtg
			,try_cast(0 AS INT) AS PFC_extracted
			,try_cast(0 AS INT) AS Ras_extracted
		INTO [lien_dtdb].[tmp].[lien_doc_ids]
		FROM [lien].[tmp].[reprocess_records_to_be_processed]

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[lien_dtdb_doc_ids]
		SELECT doc_id
			,m_update_date
			,fips_code
			,Fips
			,Instrument_nbr
			,recording_date_d
			,m_status_id
			,reprocess_flag
			,ur_matrix
			,previous_doc_unique_id
			,update_type
			,doc_title
			,doc_type
			,try_cast(0 AS INT) AS non_dtdb_doctype
			,try_cast(0 AS INT) AS deed_input
			,try_cast(0 AS INT) AS ras_input
			,try_cast(0 AS INT) AS PFC_input
			,try_cast(0 AS INT) AS HOA_input
			,try_cast(0 AS INT) AS LEAP_input
			,try_cast(0 AS INT) AS PACE_input
			,try_cast(0 AS INT) AS Fips_not_deployed
			,try_cast(0 AS INT) AS M_status_id_3
			,try_cast(0 AS INT) AS M_status_id_4
			,try_cast(0 AS INT) AS M_status_id_5
			,try_cast(0 AS INT) AS M_status_id_6
			,try_cast(0 AS INT) AS M_status_id_7
			,try_cast(0 AS INT) AS M_status_id_1
			,try_cast(0 AS INT) AS Relative_included
			,try_cast(0 AS INT) AS Docid_with_Prop_Ref_Name
			,try_cast(0 AS INT) AS Dupl_deed
			,try_cast(0 AS INT) AS Dupl_Mtg
			,try_cast(0 AS INT) AS Dupl_Ras
			,try_cast(0 AS INT) AS Dupl_Pfc
			,try_cast(0 AS INT) AS DeedRecord
			,try_cast(0 AS INT) AS Concurr_mtg
			,try_cast(0 AS INT) AS Stand_alone_mtg
			,try_cast(0 AS INT) AS PFC_extracted
			,try_cast(0 AS INT) AS Ras_extracted
		INTO [lien_dtdb].[tmp].[lien_dtdb_doc_ids]
		FROM [Lien_dtdb].[tmp].[reprocess_records_to_be_processed]

	DROP TABLE

	IF EXISTS #valid_doc_type
		SELECT a.*
		INTO #valid_doc_type
		FROM (
			SELECT 'deed' AS _dest
				,UR_VALUE AS Doc_type
			FROM [LIEN_DTDB].[dbo].[UR_Document_Types]
			WHERE DEED_TYPE NOT IN ('Z')
				AND Delete_date IS NULL
			
			UNION ALL
			
			SELECT 'pfc' AS _dest
				,Doc_type
			FROM [lien_DTDB].[dbo].[UR_PFC_Doc_Types]
			WHERE Delete_date IS NULL
			
			UNION ALL
			
			SELECT 'ras'
				,UR_DOC_TYPE AS Doc_type
			FROM [lien_DTDB].[dbo].[UR_RAS_Doc_Types]
			WHERE Delete_date IS NULL
			
			UNION ALL
			
			SELECT 'hoa'
				,Doc_type
			FROM [lien_dtdb].[infc].[doc_type_hoa]
			
			UNION ALL
			
			SELECT 'leap'
				,doc_type
			FROM [lien_dtdb].[infc].[doc_type_leap]
			
			UNION ALL
			
			SELECT 'PACE' AS _Pace
				,Code AS doc_type
			FROM [Lien].[PACE].[DocType]
			) a

	CREATE INDEX idx_doc_type ON #valid_doc_type (doc_type)

	DROP TABLE

	IF EXISTS #relatives
		SELECT DISTINCT a.doc_id
		INTO #relatives
		FROM (
			SELECT doc_id
			FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
			
			EXCEPT
			
			SELECT doc_id
			FROM [lien].[tmp].[reprocess_records_to_be_processed]
			) a

	CREATE INDEX idx_doc_id ON #relatives (doc_id)

	DROP TABLE

	IF EXISTS #mtg_doc_ids
		SELECT DISTINCT a.doc_id
		INTO #mtg_doc_ids
		FROM (
			SELECT DISTINCT d1.doc_id
			FROM [Lien_dtdb].[infc].[Deed_work] d
			OUTER APPLY (
				SELECT mtg1_ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS doc_id
				) d1
			WHERE d1.doc_id IS NOT NULL
				AND d.DEED_TYPE <> 'T'
			
			UNION ALL
			
			SELECT ur_doc_id
			FROM [Lien_dtdb].[infc].[Deed_work] d
			WHERE d.DEED_TYPE = 'T'
			) a

	DROP TABLE

	IF EXISTS #concurr_mtg
		SELECT DISTINCT d1.doc_id
		INTO #concurr_mtg
		FROM [Lien_dtdb].[infc].[Deed_work] d
		OUTER APPLY (
			SELECT mtg1_ur_doc_id AS doc_id
			
			UNION ALL
			
			SELECT mtg2_ur_doc_id AS doc_id
			
			UNION ALL
			
			SELECT mtg3_ur_doc_id AS doc_id
			
			UNION ALL
			
			SELECT mtg4_ur_doc_id AS doc_id
			) d1
		WHERE d1.doc_id IS NOT NULL
			AND d.DEED_TYPE <> 'T'

	CREATE INDEX idx_doc_id ON #concurr_mtg (doc_id)

	DROP TABLE

	IF EXISTS #stand_alone_deed
		SELECT DISTINCT ur_doc_id AS doc_id
		INTO #stand_alone_deed
		FROM [Lien_dtdb].[infc].[Deed_work] dr
		WHERE DEED_TYPE <> 'T'

	--AND dr.mtg1_ur_doc_id IS NULL
	--AND dr.mtg2_ur_doc_id IS NULL
	--AND dr.mtg3_ur_doc_id IS NULL
	--AND dr.mtg4_ur_doc_id IS NULL
	CREATE INDEX idx_doc_id ON #stand_alone_deed (doc_id)

	DROP TABLE

	IF EXISTS #Standalone_mtg
		SELECT DISTINCT ur_doc_id AS doc_id
		INTO #Standalone_mtg
		FROM [lien_dtdb].[infc].[deed_work] sa WITH (NOLOCK)
		WHERE sa.DEED_TYPE = 'T'

	CREATE INDEX idx_doc_id ON #Standalone_mtg (doc_id)

	-- nessie
	UPDATE [lien_DTDB].[rpt].[a]
	SET a.non_dtdb_doctype = CASE 
			WHEN dt._dest IS NULL
				THEN 1
			ELSE 0
			END
		,a.deed_input = CASE 
			WHEN dt._dest = 'deed'
				THEN 1
			ELSE 0
			END
		,a.ras_input = CASE 
			WHEN dt._dest = 'ras'
				THEN 1
			ELSE 0
			END
		,a.pfc_input = CASE 
			WHEN dt._dest = 'pfc'
				THEN 1
			ELSE 0
			END
		,a.HOA_input = CASE 
			WHEN dt._dest = 'HOA'
				THEN 1
			ELSE 0
			END
		,a.leap_input = CASE 
			WHEN dt._dest = 'leap'
				THEN 1
			ELSE 0
			END
		,a.pace_input = CASE 
			WHEN dt._dest = 'pace'
				THEN 1
			ELSE 0
			END
		,a.Fips_not_deployed = CASE 
			WHEN f.fips IS NULL
				THEN 1
			ELSE 0
			END
		,a.M_status_id_3 = CASE 
			WHEN a.m_status_id = 3
				THEN 1
			ELSE 0
			END
		,a.M_status_id_4 = CASE 
			WHEN a.m_status_id = 4
				THEN 1
			ELSE 0
			END
		,a.M_status_id_5 = CASE 
			WHEN a.m_status_id = 5
				THEN 1
			ELSE 0
			END
		,a.M_status_id_6 = CASE 
			WHEN a.m_status_id = 6
				THEN 1
			ELSE 0
			END
		,a.M_status_id_7 = CASE 
			WHEN a.m_status_id = 7
				THEN 1
			ELSE 0
			END
		,a.M_status_id_1 = CASE 
			WHEN a.m_status_id = 1
				THEN 1
			ELSE 0
			END
		,a.Relative_included = CASE 
			WHEN rel.doc_id IS NOT NULL
				THEN 1
			ELSE 0
			END
		,a.Docid_with_Prop_Ref_Name = CASE 
			WHEN pnr.doc_id IS NOT NULL
				THEN 1
			ELSE 0
			END
		,a.Dupl_deed = CASE 
			WHEN dd.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Dupl_Mtg = CASE 
			WHEN dm.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Dupl_ras = CASE 
			WHEN isnull(ras.doc_id, 0) = 0
				THEN 0
			ELSE 1
			END
		,a.Dupl_pfc = CASE 
			WHEN isnull(pfc.doc_id, 0) = 0
				THEN 0
			ELSE 1
			END
		,a.DeedRecord = CASE 
			WHEN dr.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Concurr_mtg = CASE 
			WHEN cm.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Stand_alone_mtg = CASE 
			WHEN sa.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.PFC_extracted = CASE 
			WHEN p.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Ras_extracted = CASE 
			WHEN r.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
	FROM [lien_dtdb].[tmp].[lien_doc_ids] a
	OUTER APPLY (
		SELECT *
		FROM #valid_doc_type dt WITH (
				NOLOCK
				,INDEX (idx_doc_type)
				)
		WHERE dt.Doc_type = a.Doc_type
		) dt
	OUTER APPLY (
		SELECT fips
		FROM [lIEN_DTDB].[INFC].[UR_Deployed_Fips] f WITH (
				NOLOCK
				,INDEX (IDX_fips_ci)
				)
		WHERE f.fips = a.Fips
		) f
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #relatives r WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE r.doc_id = a.doc_id
		) rel
	OUTER APPLY (
		SELECT doc_id
		FROM [lien_dtdb].[tmp].[prop_name_cnt] pnr WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE pnr.doc_id = a.doc_id
		) pnr
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [Lien_dtdb].[tmp].[delete_duplicate_deed] dd WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dd.ur_doc_id = a.doc_id
			AND ur_doc_id NOT IN (
				SELECT DISTINCT doc_id
				FROM #stand_alone_deed WITH (NOLOCK)
				)
		) dd
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_mtg] dm WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dm.ur_doc_id = a.doc_id
			AND ur_doc_id NOT IN (
				SELECT doc_id
				FROM #mtg_doc_ids
				)
		) dm
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #stand_alone_deed dr WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dr.doc_id = a.doc_id
		) dr
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #concurr_mtg cm WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE cm.doc_id = a.doc_id
		) cm
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #Standalone_mtg sa WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE sa.doc_id = a.doc_id
		) sa
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[infc].[PFC_work] p WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE p.ur_doc_id = a.doc_id
		) p
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[infc].[Ras_work] r WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE r.ur_doc_id = a.doc_id
		) r
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_ras] ras WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE ras.ur_doc_id = a.doc_id
			AND ras.ur_doc_id NOT IN (
				SELECT ur_doc_id
				FROM [lien_dtdb].[infc].[ras_work]
				)
		) ras
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_pfc] pfc WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE pfc.ur_doc_id = a.doc_id
			AND pfc.ur_doc_id NOT IN (
				SELECT ur_doc_id
				FROM [lien_dtdb].[infc].[pfc_work]
				)
		) pfc

	UPDATE [lien_DTDB].[rpt].[a]
	SET a.non_dtdb_doctype = CASE 
			WHEN dt._dest IS NULL
				THEN 1
			ELSE 0
			END
		,a.deed_input = CASE 
			WHEN dt._dest = 'deed'
				THEN 1
			ELSE 0
			END
		,a.ras_input = CASE 
			WHEN dt._dest = 'ras'
				THEN 1
			ELSE 0
			END
		,a.pfc_input = CASE 
			WHEN dt._dest = 'pfc'
				THEN 1
			ELSE 0
			END
		,a.HOA_input = CASE 
			WHEN dt._dest = 'HOA'
				THEN 1
			ELSE 0
			END
		,a.leap_input = CASE 
			WHEN dt._dest = 'leap'
				THEN 1
			ELSE 0
			END
		,a.pace_input = CASE 
			WHEN dt._dest = 'pace'
				THEN 1
			ELSE 0
			END
		,a.Fips_not_deployed = CASE 
			WHEN f.fips IS NULL
				THEN 1
			ELSE 0
			END
		,a.M_status_id_3 = CASE 
			WHEN a.m_status_id = 3
				THEN 1
			ELSE 0
			END
		,a.M_status_id_4 = CASE 
			WHEN a.m_status_id = 4
				THEN 1
			ELSE 0
			END
		,a.M_status_id_5 = CASE 
			WHEN a.m_status_id = 5
				THEN 1
			ELSE 0
			END
		,a.M_status_id_6 = CASE 
			WHEN a.m_status_id = 6
				THEN 1
			ELSE 0
			END
		,a.M_status_id_7 = CASE 
			WHEN a.m_status_id = 7
				THEN 1
			ELSE 0
			END
		,a.M_status_id_1 = CASE 
			WHEN a.m_status_id = 1
				THEN 1
			ELSE 0
			END
		,a.Relative_included = CASE 
			WHEN rel.doc_id IS NOT NULL
				THEN 1
			ELSE 0
			END
		,a.Docid_with_Prop_Ref_Name = CASE 
			WHEN pnr.doc_id IS NOT NULL
				THEN 1
			ELSE 0
			END
		,a.Dupl_deed = CASE 
			WHEN dd.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Dupl_Mtg = CASE 
			WHEN dm.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Dupl_ras = CASE 
			WHEN isnull(ras.doc_id, 0) > 0
				THEN 1
			ELSE 0
			END
		,a.Dupl_pfc = CASE 
			WHEN isnull(pfc.doc_id, 0) > 0
				THEN 1
			ELSE 0
			END
		,a.DeedRecord = CASE 
			WHEN dr.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Concurr_mtg = CASE 
			WHEN cm.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Stand_alone_mtg = CASE 
			WHEN sa.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.PFC_extracted = CASE 
			WHEN p.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
		,a.Ras_extracted = CASE 
			WHEN r.doc_id = a.doc_id
				THEN 1
			ELSE 0
			END
	FROM [lien_dtdb].[tmp].[lien_dtdb_doc_ids] a
	OUTER APPLY (
		SELECT *
		FROM #valid_doc_type dt WITH (
				NOLOCK
				,INDEX (idx_doc_type)
				)
		WHERE dt.Doc_type = a.Doc_type
		) dt
	OUTER APPLY (
		SELECT fips
		FROM [lIEN_DTDB].[INFC].[UR_Deployed_Fips] f WITH (
				NOLOCK
				,INDEX (IDX_fips_ci)
				)
		WHERE f.fips = a.Fips
		) f
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #relatives r WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE r.doc_id = a.doc_id
		) rel
	OUTER APPLY (
		SELECT doc_id
		FROM [lien_dtdb].[tmp].[prop_name_cnt] pnr WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE pnr.doc_id = a.doc_id
		) pnr
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [Lien_dtdb].[tmp].[delete_duplicate_deed] dd WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dd.ur_doc_id = a.doc_id
			AND ur_doc_id NOT IN (
				SELECT DISTINCT doc_id
				FROM #stand_alone_deed WITH (NOLOCK)
				)
		) dd
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_mtg] dm WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dm.ur_doc_id = a.doc_id
			AND ur_doc_id NOT IN (
				SELECT doc_id
				FROM #mtg_doc_ids
				)
		) dm
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #stand_alone_deed dr WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE dr.doc_id = a.doc_id
		) dr
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #concurr_mtg cm WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE cm.doc_id = a.doc_id
		) cm
	OUTER APPLY (
		SELECT DISTINCT doc_id
		FROM #Standalone_mtg sa WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		WHERE sa.doc_id = a.doc_id
		) sa
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[infc].[PFC_work] p WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE p.ur_doc_id = a.doc_id
		) p
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[infc].[Ras_work] r WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE r.ur_doc_id = a.doc_id
		) r
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_ras] ras WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE ras.ur_doc_id = a.doc_id
			AND ras.ur_doc_id NOT IN (
				SELECT ur_doc_id
				FROM [lien_dtdb].[infc].[ras_work]
				)
		) ras
	OUTER APPLY (
		SELECT DISTINCT ur_doc_id AS doc_id
		FROM [lien_dtdb].[tmp].[delete_duplicate_pfc] pfc WITH (
				NOLOCK
				,INDEX (idx_ur_doc_id)
				)
		WHERE pfc.ur_doc_id = a.doc_id
			AND pfc.ur_doc_id NOT IN (
				SELECT ur_doc_id
				FROM [lien_dtdb].[infc].[pfc_work]
				)
		) pfc

	DECLARE @date VARCHAR(20) = replace(replace(replace(replace(cast(getdate() AS DATETIME2), '-', ''), ' ', ''), ':', ''), '.', '')
	DECLARE @sql VARCHAR(max) = N'


SELECT *
INTO lien_dtdb.rpt.lien_dtdb_doc_ids_' + @date + '
FROM lien_dtdb.tmp.lien_dtdb_doc_ids

--
SELECT *
INTO lien_dtdb.rpt.lien_doc_ids_' + @date + '
FROM lien_dtdb.tmp.lien_doc_ids

'

	--Select @sql as N'@sql'
	EXEC (@sql)

	TRUNCATE TABLE [LIEN_DTDB].[rpt].[lien_doc_ids_report]

	TRUNCATE TABLE [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report]

	INSERT INTO [LIEN_DTDB].[rpt].[lien_doc_ids_report] (
		doc_id
		,m_update_date
		,fips_code
		,Fips
		,Instrument_nbr
		,recording_date_d
		,m_status_id
		,reprocess_flag
		,ur_matrix
		,previous_doc_unique_id
		,update_type
		,doc_title
		,doc_type
		,non_dtdb_doctype
		,deed_input
		,ras_input
		,PFC_input
		,HOA_input
		,LEAP_input
		,PACE_input
		,Fips_not_deployed
		,M_status_id_3
		,M_status_id_4
		,M_status_id_5
		,M_status_id_6
		,M_status_id_7
		,M_status_id_1
		,relative_included
		,Docid_with_Prop_Ref_Name
		,Dupl_deed
		,Dupl_Mtg
		,Dupl_Ras
		,Dupl_Pfc
		,DeedRecord
		,Concurr_mtg
		,Stand_alone_mtg
		,PFC_extracted
		,Ras_extracted
		)
	SELECT doc_id
		,m_update_date
		,fips_code
		,Fips
		,Instrument_nbr
		,recording_date_d
		,m_status_id
		,reprocess_flag
		,ur_matrix
		,previous_doc_unique_id
		,update_type
		,doc_title
		,doc_type
		,non_dtdb_doctype
		,deed_input
		,ras_input
		,PFC_input
		,HOA_input
		,LEAP_input
		,PACE_input
		,Fips_not_deployed
		,M_status_id_3
		,M_status_id_4
		,M_status_id_5
		,M_status_id_6
		,M_status_id_7
		,M_status_id_1
		,relative_included
		,Docid_with_Prop_Ref_Name
		,Dupl_deed
		,Dupl_Mtg
		,Dupl_Ras
		,Dupl_Pfc
		,DeedRecord
		,Concurr_mtg
		,Stand_alone_mtg
		,PFC_extracted
		,Ras_extracted
	FROM [lien_dtdb].[tmp].[lien_doc_ids]

	INSERT INTO [LIEN_DTDB].[rpt].[lien_dtdb_doc_ids_Report] (
		doc_id
		,m_update_date
		,fips_code
		,Fips
		,Instrument_nbr
		,recording_date_d
		,m_status_id
		,reprocess_flag
		,ur_matrix
		,previous_doc_unique_id
		,update_type
		,doc_title
		,doc_type
		,non_dtdb_doctype
		,deed_input
		,ras_input
		,PFC_input
		,HOA_input
		,LEAP_input
		,PACE_input
		,Fips_not_deployed
		,M_status_id_3
		,M_status_id_4
		,M_status_id_5
		,M_status_id_6
		,M_status_id_7
		,M_status_id_1
		,Relative_included
		,Docid_with_Prop_Ref_Name
		,Dupl_deed
		,Dupl_Mtg
		,Dupl_Ras
		,Dupl_Pfc
		,DeedRecord
		,Concurr_mtg
		,Stand_alone_mtg
		,PFC_extracted
		,Ras_extracted
		)
	SELECT doc_id
		,m_update_date
		,fips_code
		,Fips
		,Instrument_nbr
		,recording_date_d
		,m_status_id
		,reprocess_flag
		,ur_matrix
		,previous_doc_unique_id
		,update_type
		,doc_title
		,doc_type
		,non_dtdb_doctype
		,deed_input
		,ras_input
		,PFC_input
		,HOA_input
		,LEAP_input
		,PACE_input
		,Fips_not_deployed
		,M_status_id_3
		,M_status_id_4
		,M_status_id_5
		,M_status_id_6
		,M_status_id_7
		,M_status_id_1
		,Relative_included
		,Docid_with_Prop_Ref_Name
		,Dupl_deed
		,Dupl_Mtg
		,Dupl_Ras
		,Dupl_Pfc
		,DeedRecord
		,Concurr_mtg
		,Stand_alone_mtg
		,PFC_extracted
		,Ras_extracted
	FROM [lien_dtdb].[tmp].[lien_dtdb_doc_ids]

	-- run report and email
	EXEC [LIEN_DTDB].[rpt].[usp_Daily_Capture_Report_v4]
END


