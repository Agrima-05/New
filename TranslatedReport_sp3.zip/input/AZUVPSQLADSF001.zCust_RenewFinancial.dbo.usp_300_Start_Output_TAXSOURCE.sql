SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE PROCEDURE [zCust_RenewFinancial].[dbo].[usp_300_Start_Output_TAXSOURCE]


AS
BEGIN
	
	SET NOCOUNT ON;

	
----DTAPI Production credentials for the Renew Account:
-----20211101 - NO PDFS needed per Nicole

			----Account Number:
			----	2016111
			----Username:
			----	DTAPI_Renew-ADS_Prod
			----Password:
			----	RenewDTAPI1@Prod
			----Products Enabled:
			----	TaxSourceAutomated     
			
			
			---Per Giang 20210429--- 
	----The default is TaxsourceBlended if you don’t specify the last parameter. 
	----If you add TaxsourceAutomated to the end it will be TaxsourceAutomated. 
	----Or Taxsource for Taxsource product.
	----I.e.: TaxSourcePuller.exe 13 DTAPI_DataAcq_Prod DataAcqDTAPI1@Prod Taxsource Will submit Taxsource
                              

----Brian…
----D:\SupportTools\TaxSourceApiExe
----TaxSourcePuller.exe 40 DTAPI_Renew-ADS_Prod RenewDTAPI1@Prod TaxSourceAutomated 

-----*************IF MANUALLY SUBMITTING - UPDATE BATCH ID & RECORD COUNT & SEND AUTO EMAIL BELOW AFTER TAXSOURCE SUBMISSION!!!*****------
				--DECLARE @query NVARCHAR(MAX)
				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @body2 NVARCHAR(MAX)
				--DECLARE @xml NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				--DECLARE @DATE VARCHAR(10)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				--Set @Date = Convert(varchar(10),Getdate(),112)
				--Set @Subject = 'Voyager - Taxsource Batch submitted - ' + @Date 
				--SET @body = 'BatchID: 15  Record Count:  0'
		

				-------------sp_send_dbmail example-------------
				--EXEC msdb.dbo.sp_send_dbmail
				--@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				--@query =  NULL,
				--@body = @body,
				--@body_format ='HTML',
				--@recipients = 'GVistaunet@edatatrace.com;avancooney@firstam.com;MClooten@firstam.com;ahmartin@firstam.com',
				--@copy_recipients = 'klowe@firstam.com;MicSmith@firstam.com',
				--@importance = 'high',
				--@subject = @subject,
				--@attach_query_result_as_file = 0,
				--@query_attachment_filename = @query_attachment_filename,
				--@query_result_separator=@tab,
				--@query_result_no_padding=1
				--		;
	


		DROP TABLE [dbo].[x_Custom_OUTPUT]

	

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
		[Id][bigint]NULL,
		[BatchId][int]NULL,
		[ExternalKey][varchar](20)NULL,
		[PropertyId][varchar](4000)NULL,
		[ReportName][varchar](4000)NULL,
		[ReportStatus][varchar](4000)NULL,
		[ReferenceId][varchar](4000)NULL,
		[OrderItemId][varchar](4000)NULL,
		[StreetAddress][varchar](4000)NULL,
		[City][varchar](4000)NULL,
		[State][varchar](4000)NULL,
		[Zip9][varchar](4000)NULL,
		[County][varchar](4000)NULL,
		[APN][varchar](4000)NULL,
		[StateFips][varchar](4000)NULL,
		[CountyFips][varchar](4000)NULL,
		[ReportAsOfDate][varchar](30)NULL,
		[AssessorsAlternateParcelIdentifier][varchar](4000)NULL,
		[ExtendedLegalDescription][varchar](4000)NULL,
		[LandUse][varchar](4000)NULL,
		[TraCode][varchar](4000)NULL,
		[TraName][varchar](4000)NULL,
		[OwnerNames][varchar](4000)NULL,
		[Errors][varchar](2000)NULL,
		[Message][varchar](4000)NULL,
		[Agency1_MismoAgencyCode][varchar](4000)NULL,
		[Agency1_Name][varchar](4000)NULL,
		[Agency1_AgencyType][varchar](4000)NULL,
		[Agency1_TaxCollectorUrl][varchar](4000)NULL,
		[Agency1_PhoneNumber][varchar](4000)NULL,
		[Agency1_FaxNumber][varchar](4000)NULL,
		[Agency1_Email][varchar](4000)NULL,
		[Agency1_MakePayableTo][varchar](4000)NULL,
		[Agency1_StreetAddress][varchar](4000)NULL,
		[Agency1_CityStateZip][varchar](4000)NULL,
		[Agency1_MailingStreet][varchar](4000)NULL,
		[Agency1_MailingCityStateZip][varchar](4000)NULL,
		[Agency1_TaxYearType][varchar](4000)NULL,
		[Agency1_TaxYearDates][varchar](4000)NULL,
		[Agency1_CurrentTaxYear][varchar](4000)NULL,
		[Agency1_CollectsInArrears][varchar](4000)NULL,
		[Agency1_DiscountAgency][varchar](4000)NULL,
		[Agency1_DuplicateBillRequired][varchar](4000)NULL,
		[Agency1_DuplicateBillFee][varchar](4000)NULL,
		[Agency1_ExternalAgencyNotes][varchar](4000)NULL,
		[TaxDetails_AsOfDate][varchar](30)NULL,
		[TaxDetails_SchoolDistrict][varchar](4000)NULL,
		[TaxDetails_TaxId][varchar](4000)NULL,
		[TaxDetails_DelinquentTaxes][varchar](4000)NULL,
		[TaxDetails_TaxReportStatus][varchar](4000)NULL,
		[TaxDetails_DelinquencyTaxSaleYear][varchar](4000)NULL,
		[TaxYear][varchar](4000)NULL,
		[TaxType][varchar](4000)NULL,
		[TaxSupplementalAPN][varchar](4000)NULL,
		[TotalTax][varchar](4000)NULL,
		[ImprovementValue][varchar](4000)NULL,
		[LandVal][varchar](4000)NULL,
		[AssessedTotalValue][varchar](4000)NULL,
		[AssessedYear][varchar](4000)NULL,
		[ExemptionType][varchar](4000)NULL,
		[ExemptionAmount][varchar](4000)NULL,
		[NetVal][varchar](4000)NULL,
		[CertificateOfPurchase][varchar](4000)NULL,
		[TaxInstallmentsMessage][varchar](4000)NULL,
		[TaxBillNumber][varchar](4000)NULL,
		[InstallmentDetail1_SequenceId][varchar](4000)NULL,
		[InstallmentDetail1_Amount][varchar](4000)NULL,
		[InstallmentDetail1_Status][varchar](4000)NULL,
		[InstallmentDetail1_PaymentDate][varchar](30)NULL,
		[InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[InstallmentDetail1_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail1_DueDate][varchar](30)NULL,
		[InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail1_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail1_DiscountDate][varchar](30)NULL,
		[InstallmentDetail1_Penalty][varchar](4000)NULL,
		[InstallmentDetail1_Interest][varchar](4000)NULL,
		[InstallmentDetail2_SequenceId][varchar](4000)NULL,
		[InstallmentDetail2_Amount][varchar](4000)NULL,
		[InstallmentDetail2_Status][varchar](4000)NULL,
		[InstallmentDetail2_PaymentDate][varchar](30)NULL,
		[InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[InstallmentDetail2_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail2_DueDate][varchar](30)NULL,
		[InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail2_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail2_DiscountDate][varchar](30)NULL,
		[InstallmentDetail2_Penalty][varchar](4000)NULL,
		[InstallmentDetail2_Interest][varchar](4000)NULL,
		[InstallmentDetail3_SequenceId][varchar](4000)NULL,
		[InstallmentDetail3_Amount][varchar](4000)NULL,
		[InstallmentDetail3_Status][varchar](4000)NULL,
		[InstallmentDetail3_PaymentDate][varchar](30)NULL,
		[InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[InstallmentDetail3_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail3_DueDate][varchar](30)NULL,
		[InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail3_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail3_DiscountDate][varchar](30)NULL,
		[InstallmentDetail3_Penalty][varchar](4000)NULL,
		[InstallmentDetail3_Interest][varchar](4000)NULL,
		[InstallmentDetail4_SequenceId][varchar](4000)NULL,
		[InstallmentDetail4_Amount][varchar](4000)NULL,
		[InstallmentDetail4_Status][varchar](4000)NULL,
		[InstallmentDetail4_PaymentDate][varchar](30)NULL,
		[InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[InstallmentDetail4_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail4_DueDate][varchar](30)NULL,
		[InstallmentDetail4_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail4_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail4_DiscountDate][varchar](30)NULL,
		[InstallmentDetail4_Penalty][varchar](4000)NULL,
		[InstallmentDetail4_Interest][varchar](4000)NULL,
		[OtherTaxDetails1_TaxYear][varchar](4000)NULL,

		[OtherTaxDetails1_TaxType][varchar](4000) NULL,


		[OtherTaxDetails1_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails1_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails1_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails1_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails1_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails1_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails2_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails2_TaxType][varchar](4000) NULL,

		[OtherTaxDetails2_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails2_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails2_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails2_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails2_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails2_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[OtherTaxDetails3_TaxYear][varchar](4000)NULL,
		
		[OtherTaxDetails3_TaxType][varchar](4000) NULL,

		[OtherTaxDetails3_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails3_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails3_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails3_TaxBillNumber][varchar](4000)NULL,

		[OtherTaxDetails3_InstallmentDetail1_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Amount][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_Status][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[OtherTaxDetails3_InstallmentDetail4_DelinquentDate][varchar](30)NULL,


		[AdditionalOtherTaxDetails][varchar](1)NULL,

		[RedemptionDetails1_Amount][varchar](30) NULL,
		[RedemptionDetails1_RedemptionDate][varchar](30) NULL,


		[RedemptionDetails1_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails2_Amount][varchar](30) NULL,
		[RedemptionDetails2_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails2_PaymentGoodThrough][varchar](4000) NULL,
		[RedemptionDetails3_Amount][varchar](30) NULL,
		[RedemptionDetails3_RedemptionDate][varchar](30) NULL,
		[RedemptionDetails3_PaymentGoodThrough][varchar](4000) NULL,

		-----Added 20210907 per Giang---
		[OtherTaxDetails1_Message][varchar](4000) NULL,
		[OtherTaxDetails2_Message][varchar](4000) NULL,
		[OtherTaxDetails3_Message][varchar](4000) NULL


			
			
		) ON [PRIMARY]


		--DROP TABLE [dbo].[x_Custom_OUTPUT_JSON]

		--CREATE TABLE [dbo].[x_Custom_OUTPUT_JSON](
		--[Id][int]NULL,
		--[BatchId][int]NULL,
		--[ExternalKey][varchar](10)NULL,
		--[Postback][varchar](max) NULL
		--) ON [PRIMARY]

		--SET CONCAT_NULL_YIELDS_NULL OFF

	 --  INSERT INTO [x_Custom_OUTPUT_JSON]
	 --  SELECT 
	 --   REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
		--,[PostBack]
		----,Errors
		--FROM TaxSourceAPI.[dbo].[OutputLayout5] as A with(NOLOCK)
		--join zCust_RenewFinancial.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
		--and A.ExternalKey = B.UniqueID
		--where B.DATE_COMPLETED is null
		--and 
		--(
		--		(ReportStatus is not null and ReportStatus not like 'Processing'
		--		--AND DOCSTATUS is not null
		--		)
		--		OR
		--		(ReportStatus like 'Errored' and Errors is not null)
		--)
		--AND isnull([PostBack],'') not like ''
		--Order by ReportStatus,DOCSTATUS
		
		----Select * From [x_Custom_OUTPUT_JSON]


	   --INSERT INTO x_Custom_OUTPUT
	 --  SELECT
		-- REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') as Errors
		--,REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,left(REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|',''),3800)
		--,REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|','')
		--,left(REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|',''),3800)
		--,REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')

		-------Added 20210907 per NH---
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_Message], CHAR(13), ''), CHAR(10), ''),'|','')
		--,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_Message], CHAR(13), ''), CHAR(10), ''),'|','')

   INSERT INTO [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT]
  Select
   LEFT(REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|',''),8)
,LEFT(REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|',''),8)
,LEFT(REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|',''),20)
,LEFT(REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') ,2000)
,LEFT(REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,left(REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|',''),3800)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,left(REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|',''),3800)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|',''),1)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|',''),30)
,LEFT(REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails1_Message], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails2_Message], CHAR(13), ''), CHAR(10), ''),'|',''),4000)
,LEFT(REPLACE(REPLACE(REPLACE([OtherTaxDetails3_Message], CHAR(13), ''), CHAR(10), ''),'|',''),4000)



  ----20210907 - Per Giang
  ----I have created a new view OutputLayout5  using OutputLayout4 and expose 3 additional fields: OtherTaxDetails1_Message, OtherTaxDetails2_Message and OtherTaxDetails3_Message

  --Select UniqueID, count(*) From INPUT_MONITOR
  --Group by UniqueID
  --having count(*) > 1

  --Select * From INPUT_MONITOR
  --where UniqueID = 'FL-00080821'

  --Select count(*) From zCust_RenewFinancial.dbo.INPUT_MONITOR
  --Select DATE_ADDED,count(*) From zCust_RenewFinancial.dbo.INPUT_MONITOR_COMPLETED
  --Group by DATE_ADDED
  --Order by DATE_ADDED desc

		--Select 	A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
		--FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
		--Select A.BatchID, A.ExternalKey,PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
		FROM [TaxSourceAPI].[dbo].[OutputLayout6] as A with(NOLOCK)
		join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BATCHID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
--		and  A.ExternalKey  
--		--Select * From INPUT_MONITOR where  UniqueID
--		not in ('FL-00425808','FL-00159256','FL-00415125','FL-00152585','FL-00191292','FL-00158278','FL-00200322','FL-00426420','FL-00413174',
--'FL-00192477','FL-00415260','FL-00181005','FL-00211803','FL-00220160','FL-00209048','FL-00210102','FL-00202644','FL-00156924','FL-00062358','FL-00406137',
--'FL-00093654','FL-00417588','FL-00217080','FL-00406112','FL-00407386','FL-00109554','FL-00157247','FL-00083256','FL-00424684','FL-00221257','FL-00400567',
--'FL-00205455','FL-00208729','FL-00400926','FL-00402457','FL-00208286','FL-00403436','FL-00187914','FL-00083951','FL-00206847','FL-00211621','FL-00200144',
--'FL-00089617','FL-00411939','FL-00180700','FL-00219534','FL-00408916','FL-00411963','FL-00405615','FL-00407683','FL-00408497','FL-00414314','FL-00408505',
--'FL-00410960','FL-00411873','FL-00179465','FL-00404670','FL-00408402','FL-00412817','FL-00173739','FL-00216645','FL-00402327','FL-00188423','FL-00414811',
--'FL-00410529','FL-00408276','FL-00410517','FL-00407223','FL-00409212','FL-00408110','FL-00408076','FL-00179364','FL-00417010','FL-00187499','FL-00409194','FL-00406313',
--'FL-00407196','FL-00403200','FL-00219268','FL-00410450','FL-00411299','FL-00410427','FL-00182578')

		and 
			
		(
				(ReportStatus like 'Ready' and ReportStatus not like 'Processing'
				AND DOCSTATUS is not null)
				--OR
				--(Submission_Count >= 2)
		)
		Order by ReportStatus,DOCSTATUS

	



	
		-------20220606 - Used to not return true errors that need to be rerun per Michael Clooten
		--and ReportStatus  like 'Error%'
		--and Errors like '%found%'
		-------20220613 - One time manual pull--
		--and ReportStatus like 'Cancelled'
	


		Select count(*) From [zCust_RenewFinancial].[dbo].[x_custom_OUTPUT]

	Select * From  [zCust_RenewFinancial].[dbo].[INPUT_IN]
	Select * From  [zCust_RenewFinancial].[dbo].[x_custom_OUTPUT]
	where ISNULL(ERRORS,'') not like ''
	Order by Errors

	Select * from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]


	------Returned----
	--Select A.FIPS, C.State, C.[County Name], A.* From INPUT_MONITOR as A 
	--join x_Custom_OUTPUT as B on A.UniqueID = B.ExternalKey
	--join global.dbo.county as C with(NOLOCK) on A.FIPS = C.FIPSCODE
	--Order by A.FIPS

	--Select A.FIPS, C.State, C.[County Name], A.* From INPUT_MONITOR_COMPLETED as A 
	--join x_Custom_OUTPUT as B on A.UniqueID = B.ExternalKey
	--and A.BATCHID = B.BatchId
	--join global.dbo.county as C with(NOLOCK) on A.FIPS = C.FIPSCODE
	--Order by A.FIPS


	----Outstanding----
	Select A.FIPS, C.State, C.[County Name], A.* From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	left outer join [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT] as B on A.UniqueID = B.ExternalKey
	join [global].[dbo].[county] as C with(NOLOCK) on A.FIPS = C.FIPSCODE
	where B.ExternalKey is null
	Order by A.FIPS


	Select FIPS,ExternalKey,B.BATCHID,B.REF_ID
	,B.Address, B.City, B.State, B.Zip
	,ReportStatus, Errors, DOCSTATUS , PostBack
	FROM [TaxSourceAPI].[dbo].[OutputLayout5] as A with(NOLOCK)
		join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
		Order by FIPS,ReportStatus,DOCSTATUS

		Select B.FIPS, ExternalKey, B.BatchId, B.Address, B.City, B.State, B.Zip, REF_ID, SubmissionStatus, Request, Response, PostBack, SubmittedDate
		 From [TaxSourceAPI].[dbo].[Property] as A with(NOLOCK)
		join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
		Order by B.FIPS, A.Response
		


	Select count(*) From 	[zCust_RenewFinancial].[dbo].[INPUT_IN]

	  Select A.* From [TaxSourceAPI].[dbo].[Property] as A with(NOLOCK)
	  join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.ExternalKey = B.UNIQUEID
	  and A.BatchId = B.BATCHID



	  Select State,count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
	  Group by State
	  Order by State
	
	
		--Select BATCHID,count(*) as TOTAL From INPUT_MONITOR
		--Group by BATCHID

		--Select count(*) as TOTAL From INPUT_MONITOR
		

	  Select count(*) From [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT]

	  Select ReportStatus,Errors, count(*) From [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT]
	  Group by ReportStatus,Errors
	  Order by ReportStatus,Errors


	  UPdate [zCust_RenewFinancial].[dbo].[A]
	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
	  From  [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_RenewFinancial].[dbo].[x_Custom_OUTPUT] as B on 
	  A.UniqueID = B.[ExternalKey]


	INSERT INTO [zCust_RenewFinancial].[dbo].[INPUT_MONITOR_COMPLETED](UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID)
SELECT UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID
FROM     [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
WHERE  (DATE_COMPLETED IS NOT NULL)
	  --Select * From [INPUT_MONITOR_COMPLETED]


	  Delete from [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
	  --Select * 
	  From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR_COMPLETED] as B on 
	  A.UniqueID = B.UniqueID
	  and A.BatchID = B.BatchID
	  where B.DATE_COMPLETED is not null


	  Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
	  Select A.FIPS, B.State, B.[County Name], count(*) as TOTAL From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as A 
	  join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
	  Group by A.FIPS, B.State, B.[County Name]
	  ORder by count(*) desc
	  

	


--	  ----------------------INSERT ERRORS/Non-RETURNED RECORDS ----ONLY RUN THIS AS A LAST STEP WHEN ALL ATTEMPTS ARE COMPLETE per TAXSOURCE TEAM----

	  
--	   INSERT INTO x_Custom_OUTPUT
--	   SELECT
--		 REPLACE(REPLACE(REPLACE(A.ID, CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.BatchId, CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ExternalKey], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([PropertyId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ReportName], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ReferenceId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OrderItemId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.[City], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.[State], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.[Zip9], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.[County], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(A.[APN], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([StateFips], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([CountyFips], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ReportAsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([AssessorsAlternateParcelIdentifier], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ExtendedLegalDescription], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([LandUse], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TraCode], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TraName], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OwnerNames], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE(convert(varchar(2000),Errors), CHAR(13), ''), CHAR(10), ''),'|','') as Errors
--		,REPLACE(REPLACE(REPLACE([Message], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_MismoAgencyCode], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_Name], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_AgencyType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_TaxCollectorUrl], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_PhoneNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_FaxNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_Email], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_MakePayableTo], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_StreetAddress], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_CityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_MailingStreet], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_MailingCityStateZip], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_TaxYearDates], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_CurrentTaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_CollectsInArrears], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_DiscountAgency], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillRequired], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_DuplicateBillFee], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([Agency1_ExternalAgencyNotes], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_AsOfDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_SchoolDistrict], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquentTaxes], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_TaxReportStatus], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxDetails_DelinquencyTaxSaleYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ImprovementValue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([LandVal], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([AssessedTotalValue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([AssessedYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ExemptionType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([ExemptionAmount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([NetVal], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxInstallmentsMessage], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail1_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail2_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail3_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_SequenceId], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PaymentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_PartialPayAmt], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DueDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_EstimatedAmountGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_DiscountDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Penalty], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([InstallmentDetail4_Interest], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxYear], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxType], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxSupplementalAPN], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TotalTax], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_CertificateOfPurchase], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_TaxBillNumber], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail1_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail2_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail3_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_Status], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_AmountDue], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_InstallmentDetail4_DelinquentDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([AdditionalOtherTaxDetails], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails1_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails2_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_Amount], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_RedemptionDate], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([RedemptionDetails3_PaymentGoodThrough], CHAR(13), ''), CHAR(10), ''),'|','')

--		-----Added 20210907 per NH---
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails1_Message], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails2_Message], CHAR(13), ''), CHAR(10), ''),'|','')
--		,REPLACE(REPLACE(REPLACE([OtherTaxDetails3_Message], CHAR(13), ''), CHAR(10), ''),'|','')

  
--  ----20210907 - Per Giang
--  ----I have created a new view OutputLayout5  using OutputLayout4 and expose 3 additional fields: OtherTaxDetails1_Message, OtherTaxDetails2_Message and OtherTaxDetails3_Message


--		--Select 	A.BatchID, ExternalKey, PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
--		------FROM TaxSourceAPI.[dbo].[OutputLayout4] as A with(NOLOCK)
--		--Select A.BatchID, A.ExternalKey,PropertyID, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
--		--Select 
--		--C.*
--		--A.BatchID, ExternalKey, PropertyID,A.OrderItemId, ReportName, ReportStatus, B.[Reference ID],A.[ReferenceId] , FIPS, REF_ID,DOCSTATUS, Errors
--		FROM TaxSourceAPI.[dbo].[OutputLayout6] as A with(NOLOCK)
--		join zCust_RenewFinancial.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
--		and A.ExternalKey = B.UniqueID
--		--join [TaxSourceAPI].[dbo].[Property] as C with(NOLOCK) on A.BatchId = C.BatchId and A.ExternalKey = C.ExternalKey
--		where B.DATE_COMPLETED is null
--		--and A.reportStatus is null
--		--and A.OrderItemId is null
--		and 
--		ReportStatus like 'NotAvailable'
--		Order by ReportStatus,DOCSTATUS

	

--	  UPdate A
--	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
--	  From  INPUT_MONITOR as A 
--	  join x_Custom_OUTPUT as B on 
--	  A.UniqueID = B.[ExternalKey]


--	INSERT INTO INPUT_MONITOR_COMPLETED(UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID)
--SELECT UniqueID, [Reference ID], Address, City, State, Zip, APN, DATE_ADDED, DATE_COMPLETED, FIPS, REF_ID, BATCHID
--FROM     INPUT_MONITOR
--WHERE  (DATE_COMPLETED IS NOT NULL)
--	  --Select * From [INPUT_MONITOR_COMPLETED]


--	  Delete from INPUT_MONITOR
--	  --Select * 
--	  From INPUT_MONITOR as A 
--	  join [INPUT_MONITOR_COMPLETED] as B on 
--	  A.UniqueID = B.UniqueID
--	  and A.BatchID = B.BatchID
--	  where B.DATE_COMPLETED is not null

--	  Select * From INPUT_MONITOR


--	  Select A.FIPS, B.State, B.[County Name], count(*) as TOTAL From INPUT_MONITOR as A 
--	  join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
--	  Group by A.FIPS, B.State, B.[County Name]
--	  ORder by count(*) desc
	  

	
--		--Select A.*		
--		--FROM [TaxSourceAPI].[dbo].[Property] as A with(NOLOCK)
--		--join zCust_RenewFinancial.dbo.INPUT_MONITOR as B on A.BatchID = B.BatchID
--		--and A.ExternalKey = B.UniqueID
--		--where B.DATE_COMPLETED is null
--		--and A.ExternalKey = 'FL-00203062'
	

--	  -------Copy pdf reports-----
--	  -----No PDF's per Nicole----

	
--	--Select count(*) From x_Custom_OUTPUT
--	--where ReportStatus like 'Ready'

--	--Select * From x_Custom_OUTPUT as A join TaxSourceAPI.[dbo].[OutputLayout5] as B on 
--	--A.ExternalKey = B.ExternalKey
--	--and A.BatchId = B.BatchId
--	--where A.ReportStatus like 'Ready'
--	--and B.DocStatus like 'Err%'


--	--Truncate table REPORTS_TO_COPY

--	--Insert into REPORTS_TO_COPY

--	--Select  D.ImageFolderPath + '\' + B.ExternalKey + '.pdf' as IMAGEPATH,NULL as COPIED
--	-- --into zCust_RenewFinancial.dbo.REPORTS_TO_COPY
--	-- From [INPUT_MONITOR_COMPLETED] as A 
--	-- join x_custom_OUTPUT as B on 
--	-- A.UniqueID = B.[ExternalKey]
--	-- and A.BatchID = B.BatchID
--	-- join TaxSourceAPI.[dbo].[Property] as C on A.BatchID = C.BatchID
--	-- and A.UniqueID = C.ExternalKey
--	-- join TaxSourceAPI.[dbo].[Batch] as D on A.BATCHID = D.Id
--	-- where B.ReportStatus like 'Ready'
--	-- and C.DocStatus like 'Complete'

--	-- -----No Image----
--	-- Select   B.ExternalKey ,B.ReportStatus,C.DocStatus
--	-- From [INPUT_MONITOR_COMPLETED] as A 
--	-- join x_custom_OUTPUT as B on 
--	-- A.UniqueID = B.[ExternalKey]
--	-- and A.BatchID = B.BatchID
--	-- join TaxSourceAPI.[dbo].[Property] as C on A.BatchID = C.BatchID
--	-- and A.UniqueID = C.ExternalKey
--	-- join TaxSourceAPI.[dbo].[Batch] as D on A.BATCHID = D.Id
--	-- where B.ReportStatus like 'Ready'
--	-- and C.DocStatus like 'Err%'



--	 -----------Stats request from Alan 20210504----

--	 --Select * From [INPUT_MONITOR_COMPLETED] as A 
--	 --join [INPUT_MONITOR] as B on A.UniqueID = B.UniqueID
--	 --and A.BATCHID = B.BATCHID

--	 --Select count(*) From [INPUT_MONITOR]
--	 --Select count(*) From [INPUT_MONITOR_COMPLETED]
--	 --where BATCHID in (9,12)

--	 --Select   C.ReportStatus,C.DocStatus,Errors, count(*)
--	 --From [INPUT_MONITOR_COMPLETED] as A 
--	 --join TaxSourceAPI.[dbo].[OutputLayout4] as C on A.BatchID = C.BatchID
--	 --and A.UniqueID = C.ExternalKey
--	 --where A.BATCHID in (9,12)
--	 --Group by C.ReportStatus,C.DocStatus,Errors
--	 --Order by C.ReportStatus,C.DocStatus,Errors


--	-- Select    A.*, C.ReportStatus, C.DocStatus, C.Errors
--	-- From [INPUT_MONITOR_COMPLETED] as A 
--	-- join TaxSourceAPI.[dbo].[OutputLayout4] as C on A.BatchID = C.BatchID
--	-- and A.UniqueID = C.ExternalKey
--	-- where A.BATCHID in (9,12)
--	--AND DocStatus  like 'Complete'
--	--and DATE_COMPLETED = '202104081403'
	
	

--	 Select * From zCust_RenewFinancial.dbo.REPORTS_TO_COPY
--	 ORder by ImagePath

	

	 	
		
END





