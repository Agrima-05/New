SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_300_Start_Output_SERVICEMAC_S86]


AS
BEGIN
	
	SET NOCOUNT ON;

	

		DROP TABLE [dbo].[x_Custom_OUTPUT_S86]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S86](
			[FIPS][varchar](5)NULL,
			[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
		
		
		[INPUT KEY][varchar](250)NULL,
		[INPUT Address][varchar](250)NULL,
		[INPUT City][varchar](250)NULL,
		[INPUT State][varchar](250)NULL,
		[INPUT Zip][varchar](250)NULL,
		--[INPUT Borrwer Name][varchar](250)NULL,
		
		--[INPUT Start Date][varchar](250)NULL,

		[Property Address][varchar](250)NULL,
		[City][varchar](250)NULL,
		[State][varchar](250)NULL,
		[Zip Code][varchar](250)NULL,
		--[County Code][varchar](250)NULL,
		[Run Date][varchar](250)NULL,
		[Address Standardization][varchar](250)NULL,
		[PACE Lien Coverage][varchar](250)NULL,
		[Property Status][varchar](250)NULL,
		[Event Status][varchar](250)NULL,
		[Total # of PACE records][varchar](250)NULL

		-----INTERNAL----
		,[MAX_PACE_RECDATE]	[varchar](250)NULL
		,[DATE_ADDED]	[varchar](250)NULL
		) ON [PRIMARY]

		

		  INSERT INTO [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] ([INPUT KEY],
[INPUT Address],
[INPUT City],
[INPUT State],
[INPUT Zip],
FIPS, WORK_REF_ID, PROPERTYID,[MAX_PACE_RECDATE]
,[DATE_ADDED]
	   )
	
		Select 	[UniqueId]
         ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
    ,FIPS
	,[REF_ID]
      ,[PROPERTYID]
      ,[MAX_PACE_RECDATE]
	  ,[DATE_RECEIVED]
       --Select * 
	   
	   FROM [zCust_ServiceMac].[dbo].[INPUT_MONITOR]
		where REcordIndicator not like 'D'
		and UniqueID is not null
	
     

	  Select count(*) From [zCust_ServiceMac].[dbo].[INPUT_MONITOR]

  
	  Select count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]

	  Select top 100 *  From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
	  
				

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		----,a.[County Code] = RIGHT((CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END),3)
		--FROM x_Custom_OUTPUT_S86 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUT Key] = c.RAW_ID

		

		Update [zCust_ServiceMac].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a JOIN [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


		Update [zCust_ServiceMac].[dbo].[a]
		set [PACE Lien Coverage] = 1
		--Select * 	
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a 
			JOIN (Select FIPS, count(*) as TOTAL From [data].[dbo].[vPACE_LIEN] as B with(NOLOCK) 
			Group by FIPS)B
			on A.FIPS = B.FIPS

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		set [PACE Lien Coverage] = 0
		where [PACE Lien Coverage] is null


		--------Initial - Return ALL records -------
		------Ongoing - All NEWLY ADDED records AND all records with a new PACE Recording----

		--Update a
		--set [Total # of PACE records] = B.TOTAL
		----Select * 	
		--FROM x_Custom_OUTPUT_S86 a 
		--	join 
		--		(Select A.FIPS, A.PropertyID,count(*) as TOTAL from 
		--			(Select A.FIPS, A.PropertyID, B.[Recording Date], B.DocumentNumber ,count(*) as TOTAL
		--			FROM x_Custom_OUTPUT_S86 a 
		--			JOIN data.dbo.vPACE_LIEN as B with(NOLOCK) 
		--			on A.FIPS = B.FIPS
		--			and A.PROPERTYID = B.PropertyID
		--			where ISNULL(A.PropertyID,'0') not like '0'
		--			--and B.[Open Lien Indicator] like 'Y'
		--				and 
		--				B.[FAUCID Flag] not like 'D'
		--			and (convert(date,B.[Recording Date]) > convert(date,A.[MAX_PACE_RECDATE])
		--			OR convert(date,A.[MAX_PACE_RECDATE]) is null)
		--			Group by A.FIPS, A.PropertyID, B.[Recording Date], B.DocumentNumber) A 
		--			Group by A.FIPS, A.PropertyID
		--		)B
		--	on A.PROPERTYID = B.PROPERTYID

			
		

		Truncate table dbo.PACE_DATA_PULL

		

		Insert into [zCust_ServiceMac].[dbo].[PACE_DATA_PULL]([INPUT KEY],
[FIPS],
[PropertyID],
[APN],
[APNSeqNbr],
[OldAPN],
[OldApnIndicator],
[TaxAccountNumber],
[SitusFullStreetAddress],
[SitusHouseNbr],
[SitusHouseNbrSuffix],
[SitusDirectionLeft],
[SitusStreet],
[SitusMode],
[SitusDirectionRight],
[SitusUnitType],
[SitusUnitNbr],
[SitusCity],
[SitusState],
[SitusZIP5],
[SitusZIP4],
[SitusCarrierCode],
[Owner1LastName],
[Owner1FirstName],
[Owner1MiddleName],
[Owner1Suffix],
[Owner2LastName],
[Owner2FirstName],
[Owner2MiddleName],
[Owner2Suffix],
[Pace ID],
[TransactionType],
[Doc Type],
[Loan Type],
[Recording Date],
[Document Date],
[Identifier],
[DocumentNumber],
[Book],
[Page],
[Book and Page Formatted],
[Financed Amount],
[Interest Rate],
[Lien Number],
[Adjustable Percent],
[Loan Amount],
[Loan Amount Credit Limit],
[Assessment Date],
[Loan Maturity Date],
[Tax Begin Date],
[Tax End Date],
[PrePayment],
[PrePayment Interest],
[PrePayment Increments],
[Program Name],
[Authority Name],
[Authority Address],
[Authority City],
[Authority State],
[Authority Zip],
[Authority Phone Number],
[Authority Email Website],
[Administrator Last Name Co Name],
[Administrator First Name],
[Administrator Middle Initial],
[Administrator Suffix],
[Administrator Address],
[Administrator City],
[Administrator State],
[Administrator Zip],
[Original Recording Date],
[Original Document Number],
[Original Document Number Formatted],
[Original Book number],
[Original Page number],
[Original Book and Page Formatted],
[Open Lien Indicator],
[Source Type],
[FAUCID Flag],
[FA Timestamp],
[FATimestamp],
[CMTID],
[CMTIDInstrumentNumber],
[ProgramName],
[RecordNumber])
		Select  A.[INPUT KEY],
A.[FIPS],
A.[PropertyID],
[APN],
[APNSeqNbr],
[OldAPN],
[OldApnIndicator],
[TaxAccountNumber],
[SitusFullStreetAddress],
[SitusHouseNbr],
[SitusHouseNbrSuffix],
[SitusDirectionLeft],
[SitusStreet],
[SitusMode],
[SitusDirectionRight],
[SitusUnitType],
[SitusUnitNbr],
[SitusCity],
[SitusState],
[SitusZIP5],
[SitusZIP4],
[SitusCarrierCode],
[Owner1LastName],
[Owner1FirstName],
[Owner1MiddleName],
[Owner1Suffix],
[Owner2LastName],
[Owner2FirstName],
[Owner2MiddleName],
[Owner2Suffix],
[Pace ID],
[TransactionType],
[Doc Type],
[Loan Type],
[Recording Date],
[Document Date],
[Identifier],
[DocumentNumber],
[Book],
[Page],
[Book and Page Formatted],
[Financed Amount],
[Interest Rate],
[Lien Number],
[Adjustable Percent],
[Loan Amount],
[Loan Amount Credit Limit],
[Assessment Date],
[Loan Maturity Date],
[Tax Begin Date],
[Tax End Date],
[PrePayment],
[PrePayment Interest],
[PrePayment Increments],
[Program Name],
[Authority Name],
[Authority Address],
[Authority City],
[Authority State],
[Authority Zip],
[Authority Phone Number],
[Authority Email Website],
[Administrator Last Name Co Name],
[Administrator First Name],
[Administrator Middle Initial],
[Administrator Suffix],
[Administrator Address],
[Administrator City],
[Administrator State],
[Administrator Zip],
[Original Recording Date],
[Original Document Number],
[Original Document Number Formatted],
[Original Book number],
[Original Page number],
[Original Book and Page Formatted],
[Open Lien Indicator],
[Source Type],
[FAUCID Flag],
[FA Timestamp],
[FATimestamp],
[CMTID],
[CMTIDInstrumentNumber],
[ProgramName]
		,ROW_NUMBER() OVER (Partition by A.[INPUT KEY] Order by A.[INPUT KEY], B.[Recording Date],B.DocumentNumber) as RecordNumber
		--into dbo.PACE_DATA_PULL
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a 
			JOIN [data].[dbo].[vPACE_LIEN] as B with(NOLOCK) 
			on A.FIPS = B.FIPS
			and A.PROPERTYID = B.PropertyID
			where ISNULL(A.PropertyID,'0') not like '0'
			and 
			-----used for NEWLY added records ONLY AND records with NO previous recordings----
			B.[Open Lien Indicator] like 'Y'
			and (A.DATE_ADDED > Getdate()-3 OR convert(date,A.[MAX_PACE_RECDATE]) is null)
			and B.[FAUCID Flag] not like 'D'
			AND B.[Recording Date] is not null
			--and (convert(date,B.[Recording Date]) > convert(date,A.[MAX_PACE_RECDATE])
			--		OR convert(date,A.[MAX_PACE_RECDATE]) is null)
			--Order by A.[INPUT KEY]
			


			
		Insert into [zCust_ServiceMac].[dbo].[PACE_DATA_PULL]([INPUT KEY],
[FIPS],
[PropertyID],
[APN],
[APNSeqNbr],
[OldAPN],
[OldApnIndicator],
[TaxAccountNumber],
[SitusFullStreetAddress],
[SitusHouseNbr],
[SitusHouseNbrSuffix],
[SitusDirectionLeft],
[SitusStreet],
[SitusMode],
[SitusDirectionRight],
[SitusUnitType],
[SitusUnitNbr],
[SitusCity],
[SitusState],
[SitusZIP5],
[SitusZIP4],
[SitusCarrierCode],
[Owner1LastName],
[Owner1FirstName],
[Owner1MiddleName],
[Owner1Suffix],
[Owner2LastName],
[Owner2FirstName],
[Owner2MiddleName],
[Owner2Suffix],
[Pace ID],
[TransactionType],
[Doc Type],
[Loan Type],
[Recording Date],
[Document Date],
[Identifier],
[DocumentNumber],
[Book],
[Page],
[Book and Page Formatted],
[Financed Amount],
[Interest Rate],
[Lien Number],
[Adjustable Percent],
[Loan Amount],
[Loan Amount Credit Limit],
[Assessment Date],
[Loan Maturity Date],
[Tax Begin Date],
[Tax End Date],
[PrePayment],
[PrePayment Interest],
[PrePayment Increments],
[Program Name],
[Authority Name],
[Authority Address],
[Authority City],
[Authority State],
[Authority Zip],
[Authority Phone Number],
[Authority Email Website],
[Administrator Last Name Co Name],
[Administrator First Name],
[Administrator Middle Initial],
[Administrator Suffix],
[Administrator Address],
[Administrator City],
[Administrator State],
[Administrator Zip],
[Original Recording Date],
[Original Document Number],
[Original Document Number Formatted],
[Original Book number],
[Original Page number],
[Original Book and Page Formatted],
[Open Lien Indicator],
[Source Type],
[FAUCID Flag],
[FA Timestamp],
[FATimestamp],
[CMTID],
[CMTIDInstrumentNumber],
[ProgramName],
[RecordNumber])
		Select  A.[INPUT KEY],
A.[FIPS],
A.[PropertyID],
[APN],
[APNSeqNbr],
[OldAPN],
[OldApnIndicator],
[TaxAccountNumber],
[SitusFullStreetAddress],
[SitusHouseNbr],
[SitusHouseNbrSuffix],
[SitusDirectionLeft],
[SitusStreet],
[SitusMode],
[SitusDirectionRight],
[SitusUnitType],
[SitusUnitNbr],
[SitusCity],
[SitusState],
[SitusZIP5],
[SitusZIP4],
[SitusCarrierCode],
[Owner1LastName],
[Owner1FirstName],
[Owner1MiddleName],
[Owner1Suffix],
[Owner2LastName],
[Owner2FirstName],
[Owner2MiddleName],
[Owner2Suffix],
[Pace ID],
[TransactionType],
[Doc Type],
[Loan Type],
[Recording Date],
[Document Date],
[Identifier],
[DocumentNumber],
[Book],
[Page],
[Book and Page Formatted],
[Financed Amount],
[Interest Rate],
[Lien Number],
[Adjustable Percent],
[Loan Amount],
[Loan Amount Credit Limit],
[Assessment Date],
[Loan Maturity Date],
[Tax Begin Date],
[Tax End Date],
[PrePayment],
[PrePayment Interest],
[PrePayment Increments],
[Program Name],
[Authority Name],
[Authority Address],
[Authority City],
[Authority State],
[Authority Zip],
[Authority Phone Number],
[Authority Email Website],
[Administrator Last Name Co Name],
[Administrator First Name],
[Administrator Middle Initial],
[Administrator Suffix],
[Administrator Address],
[Administrator City],
[Administrator State],
[Administrator Zip],
[Original Recording Date],
[Original Document Number],
[Original Document Number Formatted],
[Original Book number],
[Original Page number],
[Original Book and Page Formatted],
[Open Lien Indicator],
[Source Type],
[FAUCID Flag],
[FA Timestamp],
[FATimestamp],
[CMTID],
[CMTIDInstrumentNumber],
[ProgramName]
		,ROW_NUMBER() OVER (Partition by A.[INPUT KEY] Order by A.[INPUT KEY], B.[Recording Date],B.DocumentNumber) as RecordNumber
		--into dbo.PACE_DATA_PULL
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a 
			JOIN [data].[dbo].[vPACE_LIEN] as B with(NOLOCK) 
			on A.FIPS = B.FIPS
			and A.PROPERTYID = B.PropertyID
			where ISNULL(A.PropertyID,'0') not like '0'
			--and 
			-----used for Records WITH previous recordings----
			--B.[Open Lien Indicator] like 'Y'
			--and (A.DATE_ADDED > Getdate()-3 OR convert(date,A.[MAX_PACE_RECDATE]) is null)
			--and B.[FAUCID Flag] not like 'D'
			AND B.[Recording Date] is not null
			and (convert(date,B.[Recording Date]) > convert(date,A.[MAX_PACE_RECDATE])
					and convert(date,A.[MAX_PACE_RECDATE]) is NOT null)
			--Order by A.[INPUT KEY]
			


		Update [zCust_ServiceMac].[dbo].[PACE_DATA_PULL]
		Set RecordNumber = NULL

		UPDATE [zCust_ServiceMac].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_ServiceMac].[dbo].[PACE_DATA_PULL] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY [INPUT KEY] ORDER BY [Recording Date] DESC, ISNULL(DocumentNumber,'0') Desc) AS RowNum
				FROM 
			[zCust_ServiceMac].[dbo].[PACE_DATA_PULL] t  ) r ON  ISNULL(t.DocumentNumber,'0') = ISNULL(r.DocumentNumber,'0')
				and r.[INPUT KEY] = t.[INPUT KEY]
				AND R.[Recording Date] = T.[Recording Date]


				Select [INPUT KEY], DocumentNumber,[Recording Date],RecordNumber, PROPERTYID From [zCust_ServiceMac].[dbo].[PACE_DATA_PULL]
				Order by [INPUT KEY]
				

				



		Update [zCust_ServiceMac].[dbo].[a]
		set [Total # of PACE records] = B.MAXREC
		--Select * 	
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a 
			join (	Select [INPUT KEY], Max(convert(bigint,REcordNumber)) as MAXREC From [zCust_ServiceMac].[dbo].[PACE_DATA_PULL]
			Group by [INPUT KEY] ) as B on 
			A.[INPUT KEY] = B.[INPUT KEY]


		



			--Select * From PACE_DATA_PULL
			--Order by [INPUT KEY]

		

		Select max(convert(int,[Total # of PACE records])) from [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]

			
		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = max(convert(int,[Total # of PACE records])) FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner1LastName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner1FirstName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner1MiddleName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner1Suffix_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner2LastName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner2FirstName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner2MiddleName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Owner2Suffix_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [TransactionType_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Loan Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Document Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Identifier_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [DocumentNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Book_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Page_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Book and Page Formatted_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Financed Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Interest Rate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Lien Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Adjustable Percent_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Loan Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Loan Amount Credit Limit_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Assessment Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Loan Maturity Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Tax Begin Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Tax End Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [PrePayment_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [PrePayment Interest_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [PrePayment Increments_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Program Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority Address_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority City_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority State_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority Zip_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority Phone Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Authority Email Website_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator Last Name Co Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator First Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator Middle Initial_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator Suffix_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator Address_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator City_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator State_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Administrator Zip_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Document Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Document Number Formatted_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Book number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Page number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S86 ADD [Original Book and Page Formatted_' + @RecNbr + '] [varchar](250) NULL')

				
				

					EXEC('UPDATE a
					SET 
					A.[Record Number_' + @RecNbr + '] = ''' + @RecNbr + '''
					,A.[Owner1LastName_' + @RecNbr + '] = b.[Owner1LastName]
					,A.[Owner1FirstName_' + @RecNbr + '] = b.[Owner1FirstName]
					,A.[Owner1MiddleName_' + @RecNbr + '] = b.[Owner1MiddleName]
					,A.[Owner1Suffix_' + @RecNbr + '] = b.[Owner1Suffix]
					,A.[Owner2LastName_' + @RecNbr + '] = b.[Owner2LastName]
					,A.[Owner2FirstName_' + @RecNbr + '] = b.[Owner2FirstName]
					,A.[Owner2MiddleName_' + @RecNbr + '] = b.[Owner2MiddleName]
					,A.[Owner2Suffix_' + @RecNbr + '] = b.[Owner2Suffix]
					,A.[TransactionType_' + @RecNbr + '] = b.[TransactionType]
					,A.[Doc Type_' + @RecNbr + '] = b.[Doc Type]
					,A.[Loan Type_' + @RecNbr + '] = b.[Loan Type]
					,A.[Recording Date_' + @RecNbr + '] = b.[Recording Date]
					,A.[Document Date_' + @RecNbr + '] = b.[Document Date]
					,A.[Identifier_' + @RecNbr + '] = b.[Identifier]
					,A.[DocumentNumber_' + @RecNbr + '] = b.[DocumentNumber]
					,A.[Book_' + @RecNbr + '] = b.[Book]
					,A.[Page_' + @RecNbr + '] = b.[Page]
					,A.[Book and Page Formatted_' + @RecNbr + '] = b.[Book and Page Formatted]
					,A.[Financed Amount_' + @RecNbr + '] = b.[Financed Amount]
					,A.[Interest Rate_' + @RecNbr + '] = b.[Interest Rate]
					,A.[Lien Number_' + @RecNbr + '] = b.[Lien Number]
					,A.[Adjustable Percent_' + @RecNbr + '] = b.[Adjustable Percent]
					,A.[Loan Amount_' + @RecNbr + '] = b.[Loan Amount]
					,A.[Loan Amount Credit Limit_' + @RecNbr + '] = b.[Loan Amount Credit Limit]
					,A.[Assessment Date_' + @RecNbr + '] = b.[Assessment Date]
					,A.[Loan Maturity Date_' + @RecNbr + '] = b.[Loan Maturity Date]
					,A.[Tax Begin Date_' + @RecNbr + '] = b.[Tax Begin Date]
					,A.[Tax End Date_' + @RecNbr + '] = b.[Tax End Date]
					,A.[PrePayment_' + @RecNbr + '] = b.[PrePayment]
					,A.[PrePayment Interest_' + @RecNbr + '] = b.[PrePayment Interest]
					,A.[PrePayment Increments_' + @RecNbr + '] = b.[PrePayment Increments]
					,A.[Program Name_' + @RecNbr + '] = b.[Program Name]
					,A.[Authority Name_' + @RecNbr + '] = b.[Authority Name]
					,A.[Authority Address_' + @RecNbr + '] = b.[Authority Address]
					,A.[Authority City_' + @RecNbr + '] = b.[Authority City]
					,A.[Authority State_' + @RecNbr + '] = b.[Authority State]
					,A.[Authority Zip_' + @RecNbr + '] = b.[Authority Zip]
					,A.[Authority Phone Number_' + @RecNbr + '] = b.[Authority Phone Number]
					,A.[Authority Email Website_' + @RecNbr + '] = b.[Authority Email Website]
					,A.[Administrator Last Name Co Name_' + @RecNbr + '] = b.[Administrator Last Name Co Name]
					,A.[Administrator First Name_' + @RecNbr + '] = b.[Administrator First Name]
					,A.[Administrator Middle Initial_' + @RecNbr + '] = b.[Administrator Middle Initial]
					,A.[Administrator Suffix_' + @RecNbr + '] = b.[Administrator Suffix]
					,A.[Administrator Address_' + @RecNbr + '] = b.[Administrator Address]
					,A.[Administrator City_' + @RecNbr + '] = b.[Administrator City]
					,A.[Administrator State_' + @RecNbr + '] = b.[Administrator State]
					,A.[Administrator Zip_' + @RecNbr + '] = b.[Administrator Zip]
					,A.[Original Recording Date_' + @RecNbr + '] = b.[Original Recording Date]
					,A.[Original Document Number_' + @RecNbr + '] = b.[Original Document Number]
					,A.[Original Document Number Formatted_' + @RecNbr + '] = b.[Original Document Number Formatted]
					,A.[Original Book number_' + @RecNbr + '] = b.[Original Book number]
					,A.[Original Page number_' + @RecNbr + '] = b.[Original Page number]
					,A.[Original Book and Page Formatted_' + @RecNbr + '] = b.[Original Book and Page Formatted]

					--Select A.PropertyID, count(*)
					FROM x_Custom_OUTPUT_S86 a JOIN 
					PACE_DATA_PULL as B on 
					a.[INPUT KEY] = b.[INPUT KEY] 
					--Group by A.PropertyID
					--Having count(*) > 1
					Where B.REcordNumber = ' + @BeginNbrOfTrans + '') 


					
					EXEC('UPDATE x_Custom_OUTPUT_S86
					SET 
					[Doc Type_' + @RecNbr + '] = 
					case 
					when [Doc Type_' + @RecNbr + '] like ''AGRENG'' then ''Agreement to Obtain PACE Loan ''
					when [Doc Type_' + @RecNbr + '] like ''AGRENGAMD'' then ''Amendment to Agreement to Obtain PACE Loan''
					when [Doc Type_' + @RecNbr + '] like ''AGRENGREL'' then ''Release of Agreement to Obtain PACE Loan ''
					when [Doc Type_' + @RecNbr + '] like ''ALNENG'' then ''Notice of Assessment Tax Lien - Energy Lien''
					when [Doc Type_' + @RecNbr + '] like ''ALNENGAMD'' then ''Amendment to Notice of Assessment Tax Lien  - Energy Lien''
					when [Doc Type_' + @RecNbr + '] like ''ALNENGREL'' then ''Release of Notice of Assessment Tax Lien  - Energy Lien''
					when [Doc Type_' + @RecNbr + '] like ''CTRASM'' then ''Contractual Assessment - Energy Lien''
					when [Doc Type_' + @RecNbr + '] like ''CTRASMAMD'' then ''Amendment to Contractual Assessment - Energy Lien''
					when [Doc Type_' + @RecNbr + '] like ''CTRASMREL'' then ''Release of Contractual Assessment - Energy Lien''
					ELSE [Doc Type_' + @RecNbr + '] end
					')

						
					EXEC('UPDATE x_Custom_OUTPUT_S86
					SET 
					[Loan Type_' + @RecNbr + '] = 
					case 
					when [Loan Type_' + @RecNbr + '] like ''PD'' then ''DOORS/WINDOWS/SKYLIGHTS''
					when [Loan Type_' + @RecNbr + '] like ''PE'' then ''ELECTRIC VEHICLE CHARGING SYSTEM''
					when [Loan Type_' + @RecNbr + '] like ''PF'' then ''FIXTURES/APPLIANCES''
					when [Loan Type_' + @RecNbr + '] like ''PH'' then ''HVAC (HEATING, AIR CONDITIONING/COOLING or both)''
					when [Loan Type_' + @RecNbr + '] like ''PI'' then ''IRRIGATION''
					when [Loan Type_' + @RecNbr + '] like ''PL'' then ''LANDSCAPING/TURF''
					when [Loan Type_' + @RecNbr + '] like ''PM'' then ''MULTIPLE''
					when [Loan Type_' + @RecNbr + '] like ''PN'' then ''INSULATION/AIR SEALING''
					when [Loan Type_' + @RecNbr + '] like ''PR'' then ''ROOF/ROOFING''
					when [Loan Type_' + @RecNbr + '] like ''PS'' then ''SOLAR''
					when [Loan Type_' + @RecNbr + '] like ''PU'' then ''UNDEFINED''
					when [Loan Type_' + @RecNbr + '] like ''PV'' then ''DUCTS/VENTILATION/FANS''
					ELSE [Loan Type_' + @RecNbr + '] end
					')
							


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END


				--Select max(convert(int,[Total # of PACE records])) from x_Custom_OUTPUT_S86
			
				--Select [Doc Type_001], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 0
				--Group BY [Doc Type_001]
				--Order by [Doc Type_001]

				--Select [Doc Type_002], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 1
				--Group BY [Doc Type_002]
				--Order by [Doc Type_002]

				
				--Select [Doc Type_003], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 2
				--Group BY [Doc Type_003]
				--Order by [Doc Type_003]

				--Select [Doc Type_006], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 5
				--Group BY [Doc Type_006]
				--Order by [Doc Type_006]

				--Select [Loan Type_001], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 0
				--Group BY [Loan Type_001]
				--Order by [Loan Type_001]

				--Select [Loan Type_002], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 1
				--Group BY [Loan Type_002]
				--Order by [Loan Type_002]

				
				--Select [Loan Type_003], count(*) From [x_Custom_OUTPUT_S86]
				--where [Total # of PACE records] > 2
				--Group BY [Loan Type_003]
				--Order by [Loan Type_003]



		Select top 10000 * From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		Order by convert(int,[Total # of PACE records]) desc
	 	

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] 
		SET [PACE Lien Coverage] = CASE WHEN [PACE Lien Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END
		
		Update  [zCust_ServiceMac].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a JOIN [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT KEY] = b.Raw_ID

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		SET [Property Status] = CASE WHEN PROPERTYID is not null and PROPERTYID not like '0'
		and PROPERTYID not like ''
		THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_ServiceMac].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] a join [zCust_ServiceMac].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT KEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		Update [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86] 
		SET [Event Status] = CASE WHEN [Total # of PACE records] > 0 THEN 'Event Found' ELSE 'Event Not Found' END
		

		-------DELETING RECORDS WITH NO EVENTS AND NOT NEWLY ADDED----
		Delete from [zCust_ServiceMac].[dbo].[X_CUSTOM_OUTPUT_S12]
		where [Event Status] like 'Event Not Found'
		and DATE_ADDED < Getdate()-5



		Select [PACE Lien Coverage], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		Group by [PACE Lien Coverage]

		Select [Property Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		Group by [Address Standardization]

		Select [Event Status], count(*) From [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
		Group by [Event Status]

	Select top 1000 * FRom [zCust_ServiceMac].[dbo].[x_Custom_OUTPUT_S86]
	Order by convert(bigint,[Total # of PACE records]) desc
	

END
