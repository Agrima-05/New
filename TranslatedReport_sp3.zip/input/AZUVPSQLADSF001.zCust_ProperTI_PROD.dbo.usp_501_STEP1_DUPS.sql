SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_ProperTI_PROD].[dbo].[usp_501_STEP1_DUPS] 
		
	
AS
BEGIN

	SET NOCOUNT ON;


				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @body5 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml1 NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)


	-----Verify Missing Deletes in portfolio---
	
	IF(
		
		
		(Select count(*) T From (
		Select A.*, B.DATE_RECEIVED
		From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.REFERENCE_ID = B.INPUTKEY
		where A.REFERENCE_ID is not null 
		and A.[Monitoring_Type] like 'D%'
		And B.INPUTKEY is null)A) )> 0


		BEGIN


	


				--DECLARE @query NVARCHAR(MAX)
				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @body1 NVARCHAR(MAX)
				--DECLARE @body2 NVARCHAR(MAX)
				--DECLARE @body3 NVARCHAR(MAX)
				--DECLARE @body4 NVARCHAR(MAX)
				--DECLARE @body5 NVARCHAR(MAX)
				--DECLARE @importance NVARCHAR(MAX)
				--DECLARE @xml1 NVARCHAR(MAX)
				--DECLARE @xml2 NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				--DECLARE @DATE VARCHAR(10)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Proper.TI PROD  - DELETE RECORDS NOT IN PORTFOLIO - SEE BELOW!!! - ' + @Date 
				
				SET @body1 = '<html><body><H3>DELETE RECORDS NOT IN PORTFOLIO - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> reference_id  </th> <th> street_address </th> <th> city </th> <th> state   </th> <th> zip_code  </th> <th> county  </th> <th> start_date   </th> <th> monitoring_type  </th> <th> DATE_RECEIVED </th></tr>' 
				
			

				SET @xml1 = 
				CAST(( 
					Select reference_id as 'td','', street_address as 'td','', city as 'td','', state as 'td','', zip_code as 'td','', county as 'td','', start_date  as 'td','', monitoring_type  as 'td','', DATE_RECEIVED as 'td',''
					FROM (
					Select A.*, B.DATE_RECEIVED
					From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
					left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
					A.REFERENCE_ID = B.INPUTKEY
					where A.REFERENCE_ID is not null 
					and A.[Monitoring_Type] like 'D%'
					And B.INPUTKEY is null)A
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


					
			


				Set @body3 = @body1 + @XML1 +'</table></body></html> <BR/><BR/>
				'
				


				

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body3 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

	END		



	IF(
		
		-----Verify Add record is NOT already in portfolio---
		Select count(*) T From (
		Select A.*, B.DATE_RECEIVED
		From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.[REFERENCE_ID] = B.INPUTKEY
		where A.[REFERENCE_ID] is not null and A.[Monitoring_Type] like 'A%')A )> 0


		BEGIN


	


				--DECLARE @query NVARCHAR(MAX)
				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @body1 NVARCHAR(MAX)
				--DECLARE @body2 NVARCHAR(MAX)
				--DECLARE @body3 NVARCHAR(MAX)
				--DECLARE @body4 NVARCHAR(MAX)
				--DECLARE @body5 NVARCHAR(MAX)
				--DECLARE @importance NVARCHAR(MAX)
				--DECLARE @xml1 NVARCHAR(MAX)
				--DECLARE @xml2 NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				--DECLARE @DATE VARCHAR(10)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Proper.TI PROD  - ADD RECORD ALREADY IN PORTFOLIO - SEE BELOW!!! - ' + @Date 
			
					
				SET @body2 = '<html><body><H3>ADD RECORDS ALREADY IN PORTFOLIO - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> reference_id  </th> <th> street_address </th> <th> city </th> <th> state   </th> <th> zip_code  </th> <th> county  </th> <th> start_date   </th> <th> monitoring_type  </th> <th> DATE_RECEIVED </th></tr>' 
				
			

				SET @xml2 = 
				CAST(( 
					Select reference_id as 'td','', street_address as 'td','', city as 'td','', state as 'td','', zip_code as 'td','', county as 'td','', start_date  as 'td','', monitoring_type  as 'td','', DATE_RECEIVED as 'td',''
					FROM (
					Select A.*, B.DATE_RECEIVED
					From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
					join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
					A.[REFERENCE_ID] = B.INPUTKEY
					where A.[REFERENCE_ID] is not null and A.[Monitoring_Type] like 'A%')A
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))



				
				Set @body4 = @body2 + @XML2 +'</table></body></html> <BR/><BR/>
				'
				



				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body4 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

	END		
		
		
END



