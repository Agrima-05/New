SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Parse GeoData
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_240_GeoData]

AS
BEGIN


	SET NOCOUNT ON;

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		TRUNCATE TABLE [geodata].[RawGeoData_Batch]

		INSERT INTO [src_PlatLabs].[geodata].[RawGeoData_Batch]([uid],[mls_id],[mls_listing_id],[modified_date],[geo_data],[city_id]
			  ,[city_name],[zip_id],[zip_name],[neighborhood_id],[neighborhood_name],[school_district_id],[school_district_name]
			  ,[LoadDate])
		select [uid],[mls_id],[mls_listing_id],[modified_date],[geo_data],[city_id]
			  ,[city_name],[zip_id],[zip_name],[neighborhood_id],[neighborhood_name]
			  ,[school_district_id],[school_district_name]
			  ,GetDATE()
		from (Select [uid],mls_id,mls_listing_id,[modified_date],[geo_data] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK)) info
		CROSS APPLY OPENJSON([geo_data]) WITH(
		city_id varchar(100)
		,city_name varchar(100)
		,zip_id varchar(100)
		,zip_name varchar(20)
		,neighborhood_id varchar(100)
		,neighborhood_name varchar(100)
		,school_district_id varchar(100)
		,school_district_name varchar(100)

			 ) as GeoData_array
		order by mls_id,mls_listing_id;

		DELETE FROM [src_PlatLabs].[geodata].[RawGeoData]
		WHERE [uid] in(Select [uid] from [src_PlatLabs].[geodata].[RawGeoData_Batch])

		INSERT INTO [src_PlatLabs].[geodata].[RawGeoData]
		Select * from [src_PlatLabs].[geodata].[RawGeoData_Batch]

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




