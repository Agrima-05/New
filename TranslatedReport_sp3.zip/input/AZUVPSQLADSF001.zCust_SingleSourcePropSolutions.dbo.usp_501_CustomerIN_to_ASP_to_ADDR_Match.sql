SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_SingleSourcePropSolutions].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
	
AS
BEGIN

			   -------Single Source Property Solution---

		TRUNCATE TABLE INPUT_IN
		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]([InputKey],[Address],[City],[State],[Zip]	)
		
		Select [Unique ID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
      
		FROM [zCust_SingleSourcePropSolutions].[dbo].[INPUT_RAW_CUST]

		Select * From [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]

		Select Inputkey, count(*) From [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]
		Group by Inputkey
		Having count(*) > 1

		Select * From [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]
		where Address like '%  %'
		OR City like '%  %'
		Or Inputkey like '%e%'

	
		
		Select * From [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]
		where len([state])>2

		UPDATE [zCust_SingleSourcePropSolutions].[dbo].[a] 
		SET a.[State] = b.[State]
		FROM [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[State] = b.[StateName]
		where len(a.[state])>2 

		UPDATE [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN] 
		SET [State] = NULL
		where len([state])>2

    EXEC [zCust_SingleSourcePropSolutions].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

		
			IF (SELECT COUNT(*) FROM [zCust_SingleSourcePropSolutions].[dbo].[SSPS_S12_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_SingleSourcePropSolutions].[dbo].[SSPS_S12_STD])
					END
			END

				



    EXEC [zCust_SingleSourcePropSolutions].[dbo].[usp_100c_sp_ASP_Cust_STD]


	

	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_SingleSourcePropSolutions'
	EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_SingleSourcePropSolutions'

	

	Select CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_SingleSourcePropSolutions].[dbo].[a_PropMatch_WORK]
	group by CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END 

	Select CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
	from [zCust_SingleSourcePropSolutions].[dbo].[a_PropMatch_WORK_FLANK]
	group by CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END 

	


	EXEC [zCust_SingleSourcePropSolutions].[dbo].[usp_502_Pull_DTDB_DATA_V2]
	EXEC [zCust_SingleSourcePropSolutions].[dbo].[usp_502_Pull_FLANK_DATA]


	




END



