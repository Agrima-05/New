SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_NTC].[dbo].[usp_300_Start_Output_NTC_REL_STEP2]

AS
BEGIN
	
	SET NOCOUNT ON;

	

----	20240909 - Solution Notes:
----Doc retrieval of the REL is REQUIRED
----RETURN ALL RELEASES where there is a doc

-----Step 2 - NULL Mtg fields for those with no image & set FLAG.   Then find other recordings for those with image
	

		-------FIND REL----
			
	
		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'R'
		--Select A.RAW_ID, A.RecordingDate, A.Value,A.OrigTransRecDate,A.OrigTransValue, A.[OrigTransDocNumber],A.OrigTransBkPg
		--,B.RecordingDate, B.Value, B.DocumentNbr
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate, DocDate,DocumentNbr From [zCust_NTC].[dbo].[w_TransHist_II] as A ) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind in ('R')
		and A.DocumentType like '%REL%'
		
		--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate)
		and 
		(
		--(convert(money,A.OrigTransValue) = convert(money,B.Value) and ISNULL(A.OrigTransValue,'') not like '')
		--OR 
			(REPLACE(REPLACE(A.[OrigTransDocNumber],'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate OR A.OrigDoc_Id = B.Doc_Id)
			)
			OR
			REPLACE(REPLACE(A.OrigTransBkPg,'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--)
			OR A.OrigDoc_Id = B.Doc_Id

		)

	

	

		
		Select ToUse, count(*) From [zCust_NTC].[dbo].[w_TransHist]
		where ToUse is not null
		Group by ToUse

		Select RAW_ID, count(*) From [zCust_NTC].[dbo].[w_TransHist]
		where ToUse is not null
		Group by RAW_ID
		Order by count(*) Desc

		--Select * From w_TransHist
		--where RAW_ID = 430031106
		--and ToUse is not null
		--Order by RecordingDate 

		--Select * From w_RAS
		--where REF_ID = 97065568

	

	---------------------NOW PULL IMAGES REL---------------------------
		
	
		Truncate table w_TransHist_II

		INSERT INTO [zCust_NTC].[dbo].[w_TransHist_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,OrigTransBkPg, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					--,Borrower1,Borrower2
					, OrigTransValue
					)
		SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,OrigTransBkPg, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					, OrigTransValue
					--,Borrower1,Borrower2
		FROM     [zCust_NTC].[dbo].[w_TransHist]
		WHERE  (ToUse  like 'R')
		


		Truncate table [z_Images_To_Pull]

		-----Inserting all subsequent images to pull
		INSERT INTO [zCust_NTC].[dbo].[z_Images_To_Pull]
		(INPUTKEY
		,[Fips]
		,[DocumentNbr]
		,[CmtId]
		,[RecordingDate]
		,[ImageName]
		,[DOCTYPE]
		)
		SELECT 
		A.RAW_ID
		,RIGHT(('0' + convert(varchar(5),A.[Fips])),5)
		,A.DocumentNbr
		,case when [CmtId] is null then '0' else [CmtId] end
		,[RecordingDate]
		--,A.RAW_ID + '_' + right(('000' + A.RecordNumber),3)
		,A.RAW_ID + '_' + 'REL' + '_' +  A.DocumentNbr
		,'REL'
		--Select  A.DocumentNbr, A.FMT_DOC_NBR, A.FMT_Book_Page, A.BookSrce, A.PageSrce,A.DocumentType
		From [zCust_NTC].[dbo].[w_TransHist_II] as A join [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] as B on A.RAW_ID = B.[Unique ID]
		where A.ToUse like 'R'
		Order by A.RAW_ID


		Select ImageName ,[DOCTYPE]
		--,left(right(ImageName,len(ImageName)-10),charindex('_',right(ImageName,len(ImageName)-10))-1)
		From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Order by [DOCTYPE]


		Select XOSStatus, count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XOSStatus
	

		Select * From [zCust_NTC].[dbo].[z_Images_To_Pull]
		where XOSStatus is null


		Update [zCust_NTC].[dbo].[A]
		Set 
		A.[MTGMATCHED_NOREL] = 'Y'
		--Select * 
		From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] as A 
		left outer join
		(Select A.RAW_ID, count(*) T
		From [zCust_NTC].[dbo].[w_TransHist_II] as A
		where A.ToUse like 'R'
		Group by A.RAW_ID) B 
		on A.[Unique ID] = B.RAW_ID
		where B.RAW_ID is null
		




		---------------------NOW PULL IMAGES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



		
		



END






