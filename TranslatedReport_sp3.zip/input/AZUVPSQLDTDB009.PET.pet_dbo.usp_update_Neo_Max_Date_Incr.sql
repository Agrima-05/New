/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_update_Neo_Max_Date_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_update_Neo_Max_Date_Incr] @Fips INT
	--,@Neo_Counties VARCHAR(5)        
	--,@Land_Id_Ind VARCHAR(6)        
	--,@Neo_server VARCHAR(100)        
	--,@LLL_update_date datetime    
	--,@update_count int output    
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************        
CHANGE LOG:        
==========        
who  date  change        
         
******************************************************************************************************************/
BEGIN TRY
	SET NOCOUNT ON

	-- SELECT * FROM pet.Pet_tmp.Pet_Incremental_Counties        
	--DECLARE @Fips INT = 2020        
	-- ,@Neo_Counties VARCHAR(5) = 'AK03'        
	-- ,@Land_Id_Ind VARCHAR(6) = 'FLNS'        
	-- ,@Neo_server VARCHAR(100) = '[AZUVNSQLDTLM008.DATATRACE.LOCAL]'        
	--    select count(1) FROM [AZUVNSQLDTLM009.DATATRACE.LOCAL].[Neo].[FL55].[LVL_land_links]  where LLL_update_date >  '20230223 00:29:10.000' order by LLL_update_date desc    
	-- there must be a while to updatge hte pet_counties table if no update found on LVL_land_links    
	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_update_Neo_Max_Date_Incr'
		,N'Started'

	IF @@SERVERNAME = 'AZUVNSQLDTDB003'
	BEGIN
		UPDATE [PET].[pet_dbo].[a]
		SET a.Stage_Max_NEO_Update_date =isnull(b.Max_NEO_Update_date,getdate())
		FROM [pet].[dbo].[pet_counties] a
		INNER JOIN [pet].[Pet_tmp].[Pet_Incremental_Counties] b ON b.fips = a.fips
		WHERE a.fips = @fips
	END
	ELSE
	BEGIN
		UPDATE [PET].[pet_dbo].[a]
		SET a.Prod_Max_Neo_Update_Date = isnull(b.Max_NEO_Update_date,getdate())
		FROM [pet].[dbo].[pet_counties] a
		INNER JOIN [pet].[Pet_tmp].[Pet_Incremental_Counties] b ON b.fips = a.fips
		WHERE a.fips = @fips
	END

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_update_Neo_Max_Date_Incr'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


