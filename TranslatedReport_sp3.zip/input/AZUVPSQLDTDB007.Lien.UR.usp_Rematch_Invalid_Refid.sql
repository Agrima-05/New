/* Source: DWS-ETL01.DATATREE.LOCAL | lien | UR.usp_Rematch_Invalid_Refid | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================  
-- Author:  Marie Pretorius  
-- Create date: 2023-02-06  
-- Description: Update Standard Lender Names  
-- =============================================  
CREATE PROCEDURE [Lien].[UR].[usp_Rematch_Invalid_Refid] @fips_code VARCHAR(5)
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who    date			change  
we need to create a code table  

******************************************************************************************************************/
--declare @ERROR VARCHAR(500)   ,@fips_code VARCHAR(5) = 12109
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Rematch_Invalid_Refid'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien].[tmp].[usp_Rematch_Invalid_Refid_doc_id]
		SELECT doc_id
		INTO [lien].[tmp].[usp_Rematch_Invalid_Refid_doc_id]
		FROM [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (ix_Fips_m_create_date)
				)
		WHERE d.fips_code = @fips_code
			AND d.m_status_id = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--DROP TABLE
	--IF EXISTS lien.tmp.usp_Rematch_Invalid_Refid_reset_match
	--	SELECT pa.Property_id
	--		,DOC_ID
	--	--,ar.*
	--	INTO lien.tmp.usp_Rematch_Invalid_Refid_reset_match
	--	FROM lien.ur.PROPERTY_APN_MATCH pa WITH (
	--			NOLOCK
	--			,INDEX (idx_doc_id)
	--			)
	--	OUTER APPLY (
	--		SELECT ref_id
	--		FROM assr.dbo.assr WITH (
	--				NOLOCK
	--				,INDEX (IDX_Assr_Ref_ID)
	--				)
	--		WHERE ref_id = pa.ref_id
	--		) ar
	--	WHERE pa.doc_id IN (
	--			SELECT doc_id
	--			FROM lien.tmp.usp_Rematch_Invalid_Refid_doc_id
	--			)
	--		AND pa.ref_id > 0
	--		AND ar.ref_id IS NULL
	--   OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));
	DROP TABLE

	IF EXISTS [lien].[tmp].[usp_Rematch_Invalid_Refid_reset_match]
		SELECT DOC_ID
		--,ar.*
		INTO [lien].[tmp].[usp_Rematch_Invalid_Refid_reset_match]
		FROM [lien].[ur].[propertyheader] ph WITH (
				NOLOCK
				,INDEX (ix_doc_id)
				)
		OUTER APPLY (
			SELECT ref_id
			FROM [assr].[dbo].[assr] WITH (
					NOLOCK
					,INDEX (IDX_Assr_Ref_ID)
					)
			WHERE ref_id = pa_ref_id
			) ara
		OUTER APPLY (
			SELECT ref_id
			FROM [assr].[dbo].[assr] WITH (
					NOLOCK
					,INDEX (IDX_Assr_Ref_ID)
					)
			WHERE ref_id = ps_ref_id
			) ars
		OUTER APPLY (
			SELECT ref_id
			FROM [assr].[dbo].[assr] WITH (
					NOLOCK
					,INDEX (IDX_Assr_Ref_ID)
					)
			WHERE ref_id = pl_ref_id
			) arl
		WHERE ph.doc_id IN (
				SELECT doc_id
				FROM [lien].[tmp].[usp_Rematch_Invalid_Refid_doc_id]
				)
			AND (
				(
					isnull(pa_ref_id, 0) > 0
					AND ara.ref_id IS NULL
					)
				OR (
					isnull(ps_ref_id, 0) > 0
					AND ars.ref_id IS NULL
					)
				OR (
					isnull(pl_ref_id, 0) > 0
					AND arl.ref_id IS NULL
					)
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	DROP TABLE

	IF EXISTS [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc_id]
		SELECT doc_id
		INTO [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc_id]
		FROM [lien].[ur].[propertyheader] ph WITH (
				NOLOCK
				,INDEX (ix_doc_id)
				)
		WHERE doc_id IN (
				SELECT doc_id
				FROM [lien].[tmp].[usp_Rematch_Invalid_Refid_doc_id]
				)
			AND isnull(pa_ref_id, 0) = 0
			AND isnull(ps_Ref_id, 0) = 0
			AND isnull(pl_Ref_id, 0) = 0
			and (ph.legal_desc_address is not null or ph.legal_desc_apn is not null)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	-- declare @ERROR VARCHAR(500)  
	DROP TABLE

	IF EXISTS [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc]
		SELECT doc_id
		INTO [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc]
		FROM [lien].[ur].[document](NOLOCK)
		WHERE doc_id IN (
				SELECT DISTINCT doc_id
				FROM [lien].[tmp].[usp_Rematch_Invalid_Refid_reset_match]
				
				UNION ALL
				
				SELECT doc_id
				FROM [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc_id]
				)
			AND m_status_id = 1

	---------------------------------------------------------------the above needs to change for every fix --------------------->>>>>>>>>>>
	CREATE INDEX idx_doc_id ON [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc] (doc_id)

	-- declare @fips_code varchar (5) = '12109'
	INSERT INTO [lien].[UR].[Fix_Request] (
		[doc_id]
		,[m_status_id]
		,[del_PROPERTY_APN_MATCH]
		,[del_PROPERTY_Std_Address]
		,[del_PROPERTYHeader]
		,[del_REFERENCE_Match]
		,[del_NAME_STD_ADDRESS]
		,[update_status]
		,[process_date]
		,[set_m_status_id_to]
		,[reprocess_flag]
		,[reprocess_reason]
		)
	--,[action]
	SELECT d.[doc_id]
		,d.[m_status_id]
		,1 AS [del_PROPERTY_APN_MATCH]
		,1 AS [del_PROPERTY_Std_Address]
		,1 AS [del_PROPERTYHeader]
		,1 AS [del_REFERENCE_Match]
		,0 AS [del_NAME_STD_ADDRESS]
		,NULL AS [update_status]
		,getdate() AS [process_date]
		,d.[m_status_id] AS [set_m_status_id_to]
		,0 AS [reprocess_flag]
		,'Post Production Rematch for :' + @fips_code AS [reprocess_reason]
	--,NULL AS [action]
	FROM [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			)
	WHERE doc_id IN (
			SELECT doc_id
			FROM [lien].[tmp].[usp_Rematch_Invalid_Refid_prop_doc]
			)

	-- EXEC lien.[UR].[usp_process_lien_fix_starter]

	--  
	--  
	--  
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Rematch_Invalid_Refid'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
		--ROLLBACK
END CATCH


