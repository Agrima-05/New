/* Source: DWS-ETL01.DATATREE.LOCAL | SPDB | dbo.usp_cmt_tables_rename | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
-- ===================================================================================================
-- Author:		Russell Yoshikawa/kpandya
-- Create date: 2020-01-10
-- Description:	
--
-- Date		Changed By			Change Request #	Description
-- --------	------------------	----------------	-------------------------------------------------

-- ===================================================================================================
CREATE   PROCEDURE [SPDB].[dbo].[usp_cmt_tables_rename]
AS
BEGIN
	BEGIN TRY

		--dbo.tbl_county_method_type
		EXEC SP_RENAME 'dbo.tbl_county_method_type','tbl_county_method_type_rn'
		EXEC SP_RENAME 'dbo.tbl_county_method_type_new','tbl_county_method_type'
		EXEC SP_RENAME 'dbo.tbl_county_method_type_rn','tbl_county_method_type_new'

		--dbo.tbl_county
		EXEC SP_RENAME 'dbo.tbl_county','tbl_county_rn'
		EXEC SP_RENAME 'dbo.tbl_county_new','tbl_county'
		EXEC SP_RENAME 'dbo.tbl_county_rn','tbl_county_new'

		--dbo.tbl_state
		EXEC SP_RENAME 'dbo.tbl_state','tbl_state_rn'
		EXEC SP_RENAME 'dbo.tbl_state_new','tbl_state'
		EXEC SP_RENAME 'dbo.tbl_state_rn','tbl_state_new'

		--dbo.tbl_method_index
		EXEC SP_RENAME 'dbo.tbl_method_index','tbl_method_index_rn'
		EXEC SP_RENAME 'dbo.tbl_method_index_new','tbl_method_index'
		EXEC SP_RENAME 'dbo.tbl_method_index_rn','tbl_method_index_new'

		--dbo.tbl_index_types
		EXEC SP_RENAME 'dbo.tbl_index_types','tbl_index_types_rn'
		EXEC SP_RENAME 'dbo.tbl_index_types_new','tbl_index_types'
		EXEC SP_RENAME 'dbo.tbl_index_types_rn','tbl_index_types_new'

		--dbo.tbl_document_type
		EXEC SP_RENAME 'dbo.tbl_document_type','tbl_document_type_new_rn'
		EXEC SP_RENAME 'dbo.tbl_document_type_new','tbl_document_type'
		EXEC SP_RENAME 'dbo.tbl_document_type_new_rn','tbl_document_type_new'

		--dbo.tbl_cmt_document_ranges
		EXEC SP_RENAME 'dbo.tbl_cmt_document_ranges','tbl_cmt_document_ranges_rn'
		EXEC SP_RENAME 'dbo.tbl_cmt_document_ranges_new','tbl_cmt_document_ranges'
		EXEC SP_RENAME 'dbo.tbl_cmt_document_ranges_rn','tbl_cmt_document_ranges_new'

		EXEC [SPDB].[dbo].[usp_cmt_index_rebuild]

	END TRY
	BEGIN CATCH
		THROW; 
	END CATCH
END

