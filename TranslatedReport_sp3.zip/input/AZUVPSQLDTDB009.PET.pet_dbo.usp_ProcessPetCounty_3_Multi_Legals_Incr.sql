/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_3_Multi_Legals_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================  
-- Author:        <Author,,Name>  
-- Create date: <Create Date,,>   
-- Description:   <Description,,>   
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'  
-- =============================================  
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_3_Multi_Legals_Incr]
	--declare  
	@fips INT --= 4007  
	,@incremental_flag INT
	,@ERROR VARCHAR(500) OUTPUT
	--,@outfips INT OUTPUT  
AS
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who  date  change  
paul 20220816 change the delete of Pet_LabelColumns to Pet_LabelColumns_Multi_Legals  
paul 20220909 call usp_ProcessPetCounty_3 before we do this procedure so that the PET values cna be correct  
     Informatica is calling usp_Pet_Neo_Legal_Parse which does not ahve the latest changes that thse  
     modules have  
******************************************************************************************************************/
BEGIN TRY
	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_ProcessPetCounty_3_Multi_Legals_Incr'
		,N'Started'

	--EXEC pet.[dbo].[usp_ProcessPetCounty_3]  @fips = @fips,  @outfips = @outfips OUTPUT  
	DECLARE @fips_c CHAR(5) = right('00000' + cast(@fips AS VARCHAR), 5)
	DECLARE @in_state VARCHAR(2)
	DECLARE @in_county VARCHAR(2)

	SELECT @fips AS 'Start of Processing'

	--SELECT @in_state = a.state_a  
	-- ,@in_county = a.DtCountyId  
	--FROM PET.[dbo].[TFN_FipsToStateCountyID](@fips_c) a  
	SELECT @in_state = a.STATE
		,@in_county = ltrim(rtrim(a.DtCountyId))
	FROM [EPR_VDB].[dbo].[TFN_FipsToStateCountyID_NEO](@fips_c) a

	IF @in_state = 'HI'
	BEGIN
		SET @in_county = 'HI'
	END

	IF @in_state = 'AZ'
		AND @in_county = '13'
	BEGIN
		SET @in_county = 'YV'
	END

	--SELECT @in_state AS in_state  
	-- ,@in_county AS in_county  
	--SET @in_state = 'CA' -- Change these two values to select a different county  
	--SET @in_county = 'OR' -- Change these two values to select a different county  
	-- Get Format Codes for County  
	--Stage  
	DECLARE @PPLNT_ARB_APN_SUPP CHAR(2)
		,@PPLNT_PLAT_ID_FRMT CHAR(1)
		,@FormatSectional VARCHAR(10)
		,@abstract CHAR(1) = '1'
		,@miningClaim CHAR(1) = '1'

	SELECT @PPLNT_ARB_APN_SUPp = p.PPLNT_ARB_APN_SUPp
		,@PPLNT_PLAT_ID_FRMT = p.PPLNT_PLAT_ID_FRMT
		,@FormatSectional = dtcc.FormatSectional
	FROM [PET].[TR00].[PL_PLANT_PARAM] p WITH (NOLOCK)
	JOIN [PET].[TR00].[TR_COUNTY] c WITH (NOLOCK) ON c.TCNTY_ST = p.[PPLNT_ST]
		AND c.TCNTY_CTY = p.[PPLNT_CTY]
	JOIN [PET].[dbo].[County] dtcc WITH (NOLOCK) ON c.TCNTY_CTY_FIPS = dtcc.CountyFips
		AND c.TCNTY_ST_FIPS = dtcc.StateFips
	WHERE p.[PPLNT_ST] = @in_state
		AND p.[PPLNT_CTY] = @in_county

	SELECT /*TOP 1*/ c.[TCNTY_CTY_NM]
		,p.[PPLNT_ST]
		,p.[PPLNT_CTY]
		,p.PPLNT_INST_FMT
		,p.PPLNT_RFINST_FMT
		,p.PPLNT_INST_AL_FMT
		,p.PPLNT_CASE_SUPP
		,p.PPLNT_RFINSTAL_FMT
		,p.PPLNT_TRACT_FMT
		,p.PPLNT_SUB_FMT
		,p.PPLNT_CONDO_FMT
		,p.PPLNT_ARB_APN_SUPP
		,p.PPLNT_PLAT_ID_FRMT
		,p.PPLNT_RAN_SUPP
		,p.PPLNT_MIN_SUPP
		,dtcc.FormatSubdivided
		,dtcc.FormatSectional
	FROM [PET].[TR00].[PL_PLANT_PARAM] p WITH (NOLOCK)
	JOIN [PET].[TR00].[TR_COUNTY] c WITH (NOLOCK) ON c.TCNTY_ST = p.[PPLNT_ST]
		AND c.TCNTY_CTY = p.[PPLNT_CTY]
	JOIN [PET].[dbo].[County] dtcc WITH (NOLOCK) ON c.TCNTY_CTY_FIPS = dtcc.CountyFips
		AND c.TCNTY_ST_FIPS = dtcc.StateFips
	WHERE p.[PPLNT_ST] = @in_state
		AND p.[PPLNT_CTY] = @in_county

	SELECT @PPLNT_ARB_APN_SUPP AS PPLNT_ARB_APN_SUPP
		,@PPLNT_PLAT_ID_FRMT AS PPLNT_PLAT_ID_FRMT
		,@FormatSectional AS FormatSectional
		,@abstract AS abstract
		,@miningClaim AS miningClaim

	DECLARE @FeatureName AS VARCHAR(50)
		,@ServiceName AS VARCHAR(50)
		,@FormatId AS VARCHAR(10)
		,@return_value INT
	DECLARE @year_pos INT

	--= (  
	-- SELECT p.offset  
	-- FROM PET.dbo.tmp_GetDynamicFormat p  
	-- WHERE p.Field = 'Year'  
	-- )  
	--,@Ref_id INT = NULL --13580129  
	--DELETE  
	--FROM [PET].[dbo].Pet_LabelColumns_Multi_Legals  
	--WHERE fips = @fips  
	--DECLARE @partition_number INT = $PARTITION.PET_Partition_FipsPF(@fips)
	DELETE Labels
	FROM [PET].[dbo].[Pet_LabelColumns_Multi_Legals] Labels
	INNER JOIN [pet].[pet_tmp].[Pet_Incremental_Add] AS PetAdd WITH (
			NOLOCK
			,INDEX (idx_fips_neoAPN)
			) ON Labels.Fips = PetAdd.Fips
		AND Labels.Neo_Apn = PetAdd.Neo_Apn

	--TRUNCATE TABLE DBO.Pet_LabelColumns_Multi_Legals  
	--WITH (PARTITIONS(@partition_number))  
	SET @FeatureName = 'TITLE_SERVICES'
	/* Subdivided begin --------------------------------------------------------------------------------------------------------------------------------------------*/
	SET @ServiceName = 'SUBDIVIDED'
	SET @FormatId = @PPLNT_PLAT_ID_FRMT

	IF @fips IN (
			6001
			,6093
			,6013
			,6029
			,6037
			,6059
			,6065
			,6083
			,6071
			,6075
			,6073
			,6081
			,6111
			) --( /*6001,6093,6013,6029,6037,6059,*/6065/*,6083,6071,6075,6073,6081,6111*/)  
	BEGIN
		EXEC @return_value = [pet].[pet_dbo].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_INCR] @fips
			,@FeatureName
			,@ServiceName
			,@FormatId
			,@incremental_flag
	END
	ELSE
	BEGIN
		EXEC @return_value = [pet].[pet_dbo].[usp_ProcessPetCounty_subdivided_Multi_Legals_INCR] @fips
			,@FeatureName
			,@ServiceName
			,@FormatId
			,@incremental_flag
	END

	/* subdivided end   ---------------------------------------------------------------------------------------------------------------------------------------------*/
	----/* SECTIONAL begin ----------------------------------------------------------------------------------------------------------------------------------------------*/  
	SET @ServiceName = 'SECTIONAL'
	SET @FormatId = @FormatSectional

	EXEC @return_value = [pet_dbo].[usp_ProcessPetCounty_Sectional_Multi_Legals_INCR] @fips
		,@FeatureName
		,@ServiceName
		,@FormatId
		,@incremental_flag

	/* arb */
	SET @ServiceName = 'ARB'
	SET @FormatId = @PPLNT_ARB_APN_SUPP

	EXEC @return_value = [pet_dbo].[usp_ProcessPetCounty_ARB_Multi_Legals_INCR] @fips
		,@FeatureName
		,@ServiceName
		,@FormatId
		,@incremental_flag

	/* abstract  */
	SET @ServiceName = 'ABSTRACT'
	SET @FormatId = @abstract

	EXEC @return_value = [pet_dbo].[usp_ProcessPetCounty_Abstract_Multi_Legals_INCR] @fips
		,@FeatureName
		,@ServiceName
		,@FormatId
		,@incremental_flag

	/* Mining Claim */
	SET @ServiceName = 'MINING_CLAIM'
	SET @FormatId = @miningClaim

	EXEC @return_value = [pet_dbo].[usp_ProcessPetCounty_MINING_CLAIM_Multi_Legals_INCR] @fips
		,@FeatureName
		,@ServiceName
		,@FormatId
		,@incremental_flag

	--Return  
	-- IF object_id('Tempdb..pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp') IS NOT NULL
	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_temp];
		SELECT c.ref_id
			,c.NEO_APN
			,c.NEO_TITLE_LEGAL
			,c.Fips
			,CASE 
				--WHEN c.Fips IN (  
				--  6001  
				--  ,6093  
				--  ,6013  
				--  ,6029  
				--  ,6037  
				--  ,6059  
				--  ,6065  
				--  ,6083  
				--  ,6071  
				--  ,6075  
				--  ,6073  
				--  ,6081  
				--  ,6111  
				--  )  
				-- AND c._field LIKE '%Sublot%'  
				-- THEN Replace(Replace(Replace(c._field, 'Sublot', 'Unit'), 'lot', 'Building'), 'Block', 'Lot')  
				WHEN c._field LIKE '%Block%'
					AND lla_ind = 1
					THEN 'Parcel'
				ELSE c._field
				END AS _field
			,c._value
			,c.lla_ind
			,c.BookType
		INTO [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_temp]
		FROM (
			SELECT a.ref_id
				,a.NEO_APN
				,a.NEO_TITLE_LEGAL
				,a.Fips
				,a._field
				,a._value
				,CASE 
					WHEN l2.REf_id IS NOT NULL
						THEN 1
					ELSE 0
					END AS lla_ind
				,a.BookType
			FROM [PET].[DBO].[Pet_LabelColumns_Multi_Legals] a WITH (
					NOLOCK
					,INDEX (ix_FipsREfIDFieldValue)
					)
			CROSS APPLY (
				SELECT TOP 1 *
				FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (
						NOLOCK
						,INDEX (idx_fips_neoAPN)
						)
				WHERE incr.fips = a.fips
					AND incr.neo_apn = a.neo_apn
				) incr
			LEFT JOIN [PET].[DBO].[Pet_LabelColumns_Multi_Legals] l2 WITH (
					NOLOCK
					,INDEX (ix_FipsREfIDFieldValue)
					) ON l2.Fips = a.fips
				AND l2.REf_id = a.REf_id
				AND l2.NEO_APN = a.NEO_APN
				AND l2.NEO_TITLE_LEGAL = a.NEO_TITLE_LEGAL
				AND l2._Field = 'Block'
				AND l2._value = '  LLA '
			WHERE a.fips = @fips
				--AND (
				-- @incremental_flag = 0
				-- OR (
				--  @incremental_flag = 1
				--  AND incr.neo_apn IS NOT NULL -- this means I found it on the incremental table  
				--  )
				-- )
			) c

	CREATE INDEX ix_Field ON [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_temp] (_field)

	--select top 100 * from pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp  
	-- IF object_id('Tempdb..pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp2') IS NOT NULL
	--DROP TABLE
	--IF EXISTS pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2;
	TRUNCATE TABLE [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2]

	INSERT INTO [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2] (
		ref_id
		,NEO_APN
		,NEO_TITLE_LEGAL
		,Fips
		,_field
		,_value
		,lla_ind
		,BookType
		,GranteeName
		,abstract
		,AcPage
		,acres
		,acresThru
		,Apn
		,Apn2
		,Apn3
		,Apn4
		,Apn5
		,Apn6
		,Apn7
		,Apn8
		,Apn9
		,APNPart1
		,APNPart2
		,APNPart3
		,ApnPin5
		,Area
		,AreaName
		,AreaPart2
		,AreaPart3
		,Block
		,Block2
		,Book
		,Book2
		,Book3
		,City
		,County
		,District
		,EMPTY
		,EMPTY2
		,Extension
		,GovernmentLot
		,Half
		,HalfQuarter
		,Indicator
		,Instrument
		,Instrument2
		,Lot
		,Lot2
		,Map
		,MapCode
		,MapPage
		,MiningClaim
		,MiningDistrict
		,MuniCode
		,Page
		,Page2
		,Parcel
		,Parcel2
		,Parcel2Split
		,ParcelCut1
		,ParcelCut2
		,ParcelCut3
		,ParcelSplit
		,ParcelSplit2
		,Plat
		,Quadrant
		,Quarter
		,Quarter2
		,Range
		,Range2
		,RangeDir
		,RangeDirection
		,RangeDirectionHalf
		,RangeHalf
		,RangeNumber
		,Reception
		,Section
		,Section2
		,SectionalArb
		,SectionPart2
		,Slide
		,SubBlock
		,Subdivision
		,Sublot
		,Suffix
		,SWISPicked
		,Taxlot
		,Timeshare
		,TorTeeName
		,Township
		,TownshipDir
		,Townshipnumber
		,TownshipDirection
		,TownshipDirectionHalf
		,TownshipHalf
		,TownshipRange
		,Tract
		,TractId
		,Unit
		,WardQualifier
		,Ward
		,Year
		,YYMMDD
		,Label_seq
		,ApnPin1
		,ApnPin2
		,ApnPin3
		,ApnPin4
		,GrantorName
		,Apn1
		,QQ
		)
	SELECT t.*
		,CASE 
			WHEN _field = 'GranteeName'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS GranteeName
		,CASE 
			WHEN _field = 'abstract'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS abstract
		,CASE 
			WHEN _field = 'AcPage'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS AcPage
		,CASE 
			WHEN _field = 'acres'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS acres
		,CASE 
			WHEN _field = 'acresThru'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS acresThru
		,CASE 
			WHEN _field = 'Apn'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn
		,CASE 
			WHEN _field = 'Apn2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn2
		,CASE 
			WHEN _field = 'Apn3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn3
		,CASE 
			WHEN _field = 'Apn4'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn4
		,CASE 
			WHEN _field = 'Apn5'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn5
		,CASE 
			WHEN _field = 'Apn6'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn6
		,CASE 
			WHEN _field = 'Apn7'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn7
		,CASE 
			WHEN _field = 'Apn8'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn8
		,CASE 
			WHEN _field = 'Apn9'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn9
		,CASE 
			WHEN _field = 'APNPart1'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS APNPart1
		,CASE 
			WHEN _field = 'APNPart2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS APNPart2
		,CASE 
			WHEN _field = 'APNPart3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS APNPart3
		,CASE 
			WHEN _field = 'ApnPin5'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ApnPin5
		,CASE 
			WHEN _field = 'Area'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Area
		,CASE 
			WHEN _field = 'AreaName'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS AreaName
		,CASE 
			WHEN _field = 'AreaPart2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS AreaPart2
		,CASE 
			WHEN _field = 'AreaPart3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS AreaPart3
		,CASE 
			WHEN _field = 'Block'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Block
		,CASE 
			WHEN _field = 'Block2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Block2
		,CASE 
			WHEN _field = 'Book'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Book
		,CASE 
			WHEN _field = 'Book2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Book2
		,CASE 
			WHEN _field = 'Book3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Book3
		,CASE 
			WHEN _field = 'City'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS City
		,CASE 
			WHEN _field = 'County'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS County
		,CASE 
			WHEN _field = 'District'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS District
		,CASE 
			WHEN _field = 'EMPTY'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS EMPTY
		,CASE 
			WHEN _field = 'EMPTY2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS EMPTY2
		,CASE 
			WHEN _field = 'Extension'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Extension
		,CASE 
			WHEN _field = 'GovernmentLot'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS GovernmentLot
		--,case when _field = 'Group' then rtrim(ltrim(try_cast(_value as varchar(30)))) else null end as Group 
		,CASE 
			WHEN _field = 'Half'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Half
		,CASE 
			WHEN _field = 'HalfQuarter'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS HalfQuarter
		,CASE 
			WHEN _field = 'Indicator'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Indicator
		,CASE 
			WHEN _field = 'Instrument'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Instrument
		,CASE 
			WHEN _field = 'Instrument2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Instrument2
		,CASE 
			WHEN _field = 'Lot'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Lot
		,CASE 
			WHEN _field = 'Lot2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Lot2
		,CASE 
			WHEN _field = 'Map'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Map
		,CASE 
			WHEN _field = 'MapCode'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS MapCode
		,CASE 
			WHEN _field = 'MapPage'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS MapPage
		,CASE 
			WHEN _field = 'MiningClaim'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS MiningClaim
		,CASE 
			WHEN _field = 'MiningDistrict'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS MiningDistrict
		,CASE 
			WHEN _field = 'MuniCode'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS MuniCode
		,CASE 
			WHEN _field = 'Page'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Page
		,CASE 
			WHEN _field = 'Page2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Page2
		,CASE 
			WHEN _field = 'Parcel'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Parcel
		,CASE 
			WHEN _field = 'Parcel2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Parcel2
		,CASE 
			WHEN _field = 'Parcel2Split'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Parcel2Split
		,CASE 
			WHEN _field = 'ParcelCut1'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ParcelCut1
		,CASE 
			WHEN _field = 'ParcelCut2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ParcelCut2
		,CASE 
			WHEN _field = 'ParcelCut3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ParcelCut3
		,CASE 
			WHEN _field = 'ParcelSplit'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ParcelSplit
		,CASE 
			WHEN _field = 'ParcelSplit2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ParcelSplit2
		,CASE 
			WHEN _field = 'Plat'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Plat
		,CASE 
			WHEN _field = 'Quadrant'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Quadrant
		,CASE 
			WHEN _field = 'Quarter'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Quarter
		,CASE 
			WHEN _field = 'Quarter2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Quarter2
		,CASE 
			WHEN _field = 'Range'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Range
		,CASE 
			WHEN _field = 'Range2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Range2
		,CASE 
			WHEN _field = 'RangeDir'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS RangeDir
		,CASE 
			WHEN _field = 'RangeDirection'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS RangeDirection
		,CASE 
			WHEN _field = 'RangeDirectionHalf'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS RangeDirectionHalf
		,CASE 
			WHEN _field = 'RangeHalf'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS RangeHalf
		,CASE 
			WHEN _field = 'RangeNumber'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS RangeNumber
		,CASE 
			WHEN _field = 'Reception'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Reception
		,CASE 
			WHEN _field = 'Section'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Section
		,CASE 
			WHEN _field = 'Section2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Section2
		,CASE 
			WHEN _field = 'SectionalArb'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS SectionalArb
		,CASE 
			WHEN _field = 'SectionPart2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS SectionPart2
		,CASE 
			WHEN _field = 'Slide'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Slide
		,CASE 
			WHEN _field = 'SubBlock'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS SubBlock
		,CASE 
			WHEN _field = 'Subdivision'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Subdivision
		,CASE 
			WHEN _field = 'Sublot'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Sublot
		,CASE 
			WHEN _field = 'Suffix'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Suffix
		,CASE 
			WHEN _field = 'SWISPicked'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS SWISPicked
		,CASE 
			WHEN _field = 'Taxlot'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Taxlot
		,CASE 
			WHEN _field = 'Timeshare'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Timeshare
		,CASE 
			WHEN _field = 'TorTeeName'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TorTeeName
		,CASE 
			WHEN _field = 'Township'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Township
		,CASE 
			WHEN _field = 'TownshipDir'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TownshipDir
		,CASE 
			WHEN _field = 'Townshipnumber'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Townshipnumber
		,CASE 
			WHEN _field = 'TownshipDirection'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TownshipDirection
		,CASE 
			WHEN _field = 'TownshipDirectionHalf'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TownshipDirectionHalf
		,CASE 
			WHEN _field = 'TownshipHalf'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TownshipHalf
		,CASE 
			WHEN _field = 'TownshipRange'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TownshipRange
		,CASE 
			WHEN _field = 'Tract'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Tract
		,CASE 
			WHEN _field = 'TractId'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS TractId
		,CASE 
			WHEN _field = 'Unit'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Unit
		,CASE 
			WHEN _field = 'WardQualifier'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS WardQualifier
		,CASE 
			WHEN _field = 'Ward'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Ward
		,CASE 
			WHEN _field = 'Year'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Year
		,CASE 
			WHEN _field = 'YYMMDD'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS YYMMDD
		,CASE 
			WHEN Label_seq IS NULL
				THEN 23
			ELSE Label_seq
			END AS Label_seq
		,CASE 
			WHEN _field = 'ApnPin1'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ApnPin1
		,CASE 
			WHEN _field = 'ApnPin2'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ApnPin2
		,CASE 
			WHEN _field = 'ApnPin3'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ApnPin3
		,CASE 
			WHEN _field = 'ApnPin4'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS ApnPin4
		,CASE 
			WHEN _field = 'GrantorName'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS GrantorName
		,CASE 
			WHEN _field = 'Apn1'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS Apn1
		,CASE 
			WHEN _field = 'QQ'
				THEN rtrim(ltrim(try_cast(_value AS VARCHAR(30))))
			ELSE NULL
			END AS QQ
	--INTO pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2
	FROM [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_temp] t WITH (
			NOLOCK
			,INDEX (ix_Field)
			)
	LEFT JOIN [PET].[dbo].[Label_seq] p WITH (
			NOLOCK
			,INDEX ([ClusteredIndex-20170525-163624])
			) ON p.Label = t._field
	ORDER BY t.REF_ID
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	SELECT TOP 100 *
	FROM [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2]

	--CREATE INDEX ix_ref_id ON pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_Temp2 (
	--	Fips
	--	,ref_id
	--	,NEO_APN
	--	,NEO_TITLE_LEGAL
	--	)
	--SELECT TOP 100 *  
	--FROM pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp2  
	--WHERE Label_seq = 23  
	-- IF object_id('Tempdb..pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp3') IS NOT NULL
	--DROP TABLE
	--IF EXISTS pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp3;
	TRUNCATE TABLE [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_INCR_Temp3]

	INSERT INTO [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_INCR_Temp3] (
		Fips
		,ref_id
		,neo_apn
		,NEO_TITLE_LEGAL
		,Label1
		,Value1
		,Label2
		,Value2
		,Label3
		,Value3
		,Label4
		,Value4
		,Label5
		,Value5
		,Label6
		,Value6
		,Label7
		,Value7
		,Label8
		,Value8
		,Label9
		,Value9
		,Label10
		,Value10
		,Label11
		,Value11
		,Label12
		,Value12
		,Label13
		,Value13
		,Label14
		,Value14
		,Label15
		,Value15
		,Label16
		,Value16
		,Label17
		,Value17
		,Label18
		,Value18
		,Label19
		,Value19
		,Label20
		,Value20
		,Label21
		,Value21
		,Label22
		,Value22
		,Label23
		,Value23
		,GranteeName
		,abstract
		,AcPage
		,acres
		,acresThru
		,Apn
		,Apn2
		,Apn3
		,Apn4
		,Apn5
		,Apn6
		,Apn7
		,Apn8
		,Apn9
		,APNPart1
		,APNPart2
		,APNPart3
		,ApnPin5
		,Area
		,AreaName
		,AreaPart2
		,AreaPart3
		,Block
		,Block2
		,Book
		,Book2
		,Book3
		,City
		,County
		,District
		,EMPTY
		,EMPTY2
		,Extension
		,GovernmentLot
		,Half
		,HalfQuarter
		,Indicator
		,Instrument
		,Instrument2
		,Lot
		,Lot2
		,Map
		,MapCode
		,MapPage
		,MiningClaim
		,MiningDistrict
		,MuniCode
		,Page
		,Page2
		,Parcel
		,Parcel2
		,Parcel2Split
		,ParcelCut1
		,ParcelCut2
		,ParcelCut3
		,ParcelSplit
		,ParcelSplit2
		,Plat
		,Quadrant
		,Quarter
		,Quarter2
		,Range
		,Range2
		,RangeDir
		,RangeDirection
		,RangeDirectionHalf
		,RangeHalf
		,RangeNumber
		,Reception
		,Section
		,Section2
		,SectionalArb
		,SectionPart2
		,Slide
		,SubBlock
		,Subdivision
		,Sublot
		,Suffix
		,SWISPicked
		,Taxlot
		,Timeshare
		,TorTeeName
		,Township
		,TownshipDir
		,TownshipNumber
		,TownshipDirection
		,TownshipDirectionHalf
		,TownshipHalf
		,TownshipRange
		,Tract
		,TractId
		,Unit
		,WardQualifier
		,Ward
		,Year
		,YYMMDD
		,BookType
		,ApnPin1
		,ApnPin2
		,ApnPin3
		,ApnPin4
		,GrantorName
		,Apn1
		,QQ
		)
	SELECT t.Fips
		,t.ref_id
		,t.neo_apn
		,t.NEO_TITLE_LEGAL
		,max(CASE 
				WHEN t.Label_seq = 1
					THEN _field
				ELSE NULL
				END) AS Label1
		,max(CASE 
				WHEN t.Label_seq = 1
					THEN _value
				ELSE NULL
				END) AS Value1
		,max(CASE 
				WHEN t.Label_seq = 2
					THEN _field
				ELSE NULL
				END) AS Label2
		,max(CASE 
				WHEN t.Label_seq = 2
					THEN _value
				ELSE NULL
				END) AS Value2
		,max(CASE 
				WHEN t.Label_seq = 3
					THEN _field
				ELSE NULL
				END) AS Label3
		,max(CASE 
				WHEN t.Label_seq = 3
					THEN _value
				ELSE NULL
				END) AS Value3
		,max(CASE 
				WHEN t.Label_seq = 4
					THEN _field
				ELSE NULL
				END) AS Label4
		,max(CASE 
				WHEN t.Label_seq = 4
					THEN _value
				ELSE NULL
				END) AS Value4
		,max(CASE 
				WHEN t.Label_seq = 5
					THEN _field
				ELSE NULL
				END) AS Label5
		,max(CASE 
				WHEN t.Label_seq = 5
					THEN _value
				ELSE NULL
				END) AS Value5
		,max(CASE 
				WHEN t.Label_seq = 6
					THEN _field
				ELSE NULL
				END) AS Label6
		,max(CASE 
				WHEN t.Label_seq = 6
					THEN _value
				ELSE NULL
				END) AS Value6
		,max(CASE 
				WHEN t.Label_seq = 7
					THEN _field
				ELSE NULL
				END) AS Label7
		,max(CASE 
				WHEN t.Label_seq = 7
					THEN _value
				ELSE NULL
				END) AS Value7
		,max(CASE 
				WHEN t.Label_seq = 8
					THEN _field
				ELSE NULL
				END) AS Label8
		,max(CASE 
				WHEN t.Label_seq = 8
					THEN _value
				ELSE NULL
				END) AS Value8
		,max(CASE 
				WHEN t.Label_seq = 9
					THEN _field
				ELSE NULL
				END) AS Label9
		,max(CASE 
				WHEN t.Label_seq = 9
					THEN _value
				ELSE NULL
				END) AS Value9
		,max(CASE 
				WHEN t.Label_seq = 10
					THEN _field
				ELSE NULL
				END) AS Label10
		,max(CASE 
				WHEN t.Label_seq = 10
					THEN _value
				ELSE NULL
				END) AS Value10
		,max(CASE 
				WHEN t.Label_seq = 11
					THEN _field
				ELSE NULL
				END) AS Label11
		,max(CASE 
				WHEN t.Label_seq = 11
					THEN _value
				ELSE NULL
				END) AS Value11
		,max(CASE 
				WHEN t.Label_seq = 12
					THEN _field
				ELSE NULL
				END) AS Label12
		,max(CASE 
				WHEN t.Label_seq = 12
					THEN _value
				ELSE NULL
				END) AS Value12
		,max(CASE 
				WHEN t.Label_seq = 13
					THEN _field
				ELSE NULL
				END) AS Label13
		,max(CASE 
				WHEN t.Label_seq = 13
					THEN _value
				ELSE NULL
				END) AS Value13
		,max(CASE 
				WHEN t.Label_seq = 14
					THEN _field
				ELSE NULL
				END) AS Label14
		,max(CASE 
				WHEN t.Label_seq = 14
					THEN _value
				ELSE NULL
				END) AS Value14
		,max(CASE 
				WHEN t.Label_seq = 15
					THEN _field
				ELSE NULL
				END) AS Label15
		,max(CASE 
				WHEN t.Label_seq = 15
					THEN _value
				ELSE NULL
				END) AS Value15
		,max(CASE 
				WHEN t.Label_seq = 16
					THEN _field
				ELSE NULL
				END) AS Label16
		,max(CASE 
				WHEN t.Label_seq = 16
					THEN _value
				ELSE NULL
				END) AS Value16
		,max(CASE 
				WHEN t.Label_seq = 17
					THEN _field
				ELSE NULL
				END) AS Label17
		,max(CASE 
				WHEN t.Label_seq = 17
					THEN _value
				ELSE NULL
				END) AS Value17
		,max(CASE 
				WHEN t.Label_seq = 18
					THEN _field
				ELSE NULL
				END) AS Label18
		,max(CASE 
				WHEN t.Label_seq = 18
					THEN _value
				ELSE NULL
				END) AS Value18
		,max(CASE 
				WHEN t.Label_seq = 19
					THEN _field
				ELSE NULL
				END) AS Label19
		,max(CASE 
				WHEN t.Label_seq = 19
					THEN _value
				ELSE NULL
				END) AS Value19
		,max(CASE 
				WHEN t.Label_seq = 20
					THEN _field
				ELSE NULL
				END) AS Label20
		,max(CASE 
				WHEN t.Label_seq = 20
					THEN _value
				ELSE NULL
				END) AS Value20
		,max(CASE 
				WHEN t.Label_seq = 21
					THEN _field
				ELSE NULL
				END) AS Label21
		,max(CASE 
				WHEN t.Label_seq = 21
					THEN _value
				ELSE NULL
				END) AS Value21
		,max(CASE 
				WHEN t.Label_seq = 22
					THEN _field
				ELSE NULL
				END) AS Label22
		,max(CASE 
				WHEN t.Label_seq = 22
					THEN _value
				ELSE NULL
				END) AS Value22
		,max(CASE 
				WHEN t.Label_seq = 23
					THEN _field
				ELSE NULL
				END) AS Label23
		,max(CASE 
				WHEN t.Label_seq = 23
					THEN _value
				ELSE NULL
				END) AS Value23
		,max(GranteeName) AS GranteeName
		-- nessie 
		,max(abstract) AS abstract
		,max(AcPage) AS AcPage
		,max(acres) AS acres
		,max(acresThru) AS acresThru
		,max(Apn) AS Apn
		,max(Apn2) AS Apn2
		,max(Apn3) AS Apn3
		,max(Apn4) AS Apn4
		,max(Apn5) AS Apn5
		,max(Apn6) AS Apn6
		,max(Apn7) AS Apn7
		,max(Apn8) AS Apn8
		,max(Apn9) AS Apn9
		,max(APNPart1) AS APNPart1
		,max(APNPart2) AS APNPart2
		,max(APNPart3) AS APNPart3
		,max(ApnPin5) AS ApnPin5
		,max(Area) AS Area
		,max(AreaName) AS AreaName
		,max(AreaPart2) AS AreaPart2
		,max(AreaPart3) AS AreaPart3
		,max(Block) AS Block
		,max(Block2) AS Block2
		,max(Book) AS Book
		,max(Book2) AS Book2
		,max(Book3) AS Book3
		,max(City) AS City
		,max(County) AS County
		,max(District) AS District
		,max(EMPTY) AS EMPTY
		,max(EMPTY2) AS EMPTY2
		,max(Extension) AS Extension
		,max(GovernmentLot) AS GovernmentLot
		--,max(Group) as Group
		,max(Half) AS Half
		,max(HalfQuarter) AS HalfQuarter
		,max(Indicator) AS Indicator
		,max(Instrument) AS Instrument
		,max(Instrument2) AS Instrument2
		,max(Lot) AS Lot
		,max(Lot2) AS Lot2
		,max(Map) AS Map
		,max(MapCode) AS MapCode
		,max(MapPage) AS MapPage
		,max(MiningClaim) AS MiningClaim
		,max(MiningDistrict) AS MiningDistrict
		,max(MuniCode) AS MuniCode
		,max(Page) AS Page
		,max(Page2) AS Page2
		,max(Parcel) AS Parcel
		,max(Parcel2) AS Parcel2
		,max(Parcel2Split) AS Parcel2Split
		,max(ParcelCut1) AS ParcelCut1
		,max(ParcelCut2) AS ParcelCut2
		,max(ParcelCut3) AS ParcelCut3
		,max(ParcelSplit) AS ParcelSplit
		,max(ParcelSplit2) AS ParcelSplit2
		,max(Plat) AS Plat
		,max(Quadrant) AS Quadrant
		,max(Quarter) AS Quarter
		,max(Quarter2) AS Quarter2
		,max(Range) AS Range
		,max(Range2) AS Range2
		,max(RangeDir) AS RangeDir
		,max(RangeDirection) AS RangeDirection
		,max(RangeDirectionHalf) AS RangeDirectionHalf
		,max(RangeHalf) AS RangeHalf
		,max(RangeNumber) AS RangeNumber
		,max(Reception) AS Reception
		,max(Section) AS Section
		,max(Section2) AS Section2
		,max(SectionalArb) AS SectionalArb
		,max(SectionPart2) AS SectionPart2
		,max(Slide) AS Slide
		,max(SubBlock) AS SubBlock
		,max(Subdivision) AS Subdivision
		,max(Sublot) AS Sublot
		,max(Suffix) AS Suffix
		,max(SWISPicked) AS SWISPicked
		,max(Taxlot) AS Taxlot
		,max(Timeshare) AS Timeshare
		,max(TorTeeName) AS TorTeeName
		,max(Township) AS Township
		,max(TownshipDir) AS TownshipDir
		,max(TownshipNumber) AS TownshipNumber
		,max(TownshipDirection) AS TownshipDirection
		,max(TownshipDirectionHalf) AS TownshipDirectionHalf
		,max(TownshipHalf) AS TownshipHalf
		,max(TownshipRange) AS TownshipRange
		,max(Tract) AS Tract
		,max(TractId) AS TractId
		,max(Unit) AS Unit
		,max(WardQualifier) AS WardQualifier
		,max(Ward) AS Ward
		,max(Year) AS Year
		,max(YYMMDD) AS YYMMDD
		-- spanner
		,max(BookType) AS BookType
		--INTO pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Temp3
		--select top 10 * 
		,max(ApnPin1) AS ApnPin1
		,max(ApnPin2) AS ApnPin2
		,max(ApnPin3) AS ApnPin3
		,max(ApnPin4) AS ApnPin4
		,max(GrantorName) AS GrantorName
		,max(Apn1) AS Apn1
		,max(QQ) AS QQ
	--into pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_INCR_Temp3
	FROM [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_INCR_Temp2] t WITH (
			NOLOCK
			,INDEX (ix_ref_id)
			)
	GROUP BY t.Fips
		,t.ref_id
		,t.neo_apn
		,t.NEO_TITLE_LEGAL
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	-- select top 100 WardQualifier, Ward ,* from pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Temp3 where ref_id in (84715338)
	--CREATE UNIQUE CLUSTERED INDEX ix_ref_id ON pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_INCR_Temp3 (
	--Fips
	--,ref_id
	--,NEO_APN
	--,NEO_TITLE_LEGAL
	--)
	UPDATE [PET].[pet_dbo].[pl]
	SET pl.Label1 = Ltrim(rtrim(t3.Label1))
		,pl.Value1 = Ltrim(rtrim(t3.Value1))
		,pl.Label2 = Ltrim(rtrim(t3.Label2))
		,pl.Value2 = Ltrim(rtrim(t3.Value2))
		,pl.Label3 = Ltrim(rtrim(t3.Label3))
		,pl.Value3 = Ltrim(rtrim(t3.Value3))
		,pl.Label4 = Ltrim(rtrim(t3.Label4))
		,pl.Value4 = Ltrim(rtrim(t3.Value4))
		,pl.Label5 = Ltrim(rtrim(t3.Label5))
		,pl.Value5 = Ltrim(rtrim(t3.Value5))
		,pl.Label6 = Ltrim(rtrim(t3.Label6))
		,pl.Value6 = Ltrim(rtrim(t3.Value6))
		,pl.Label7 = Ltrim(rtrim(t3.Label7))
		,pl.Value7 = Ltrim(rtrim(t3.Value7))
		,pl.Label8 = Ltrim(rtrim(t3.Label8))
		,pl.Value8 = Ltrim(rtrim(t3.Value8))
		,pl.Label9 = Ltrim(rtrim(t3.Label9))
		,pl.Value9 = Ltrim(rtrim(t3.Value9))
		,pl.Label10 = Ltrim(rtrim(t3.Label10))
		,pl.Value10 = Ltrim(rtrim(t3.Value10))
		,pl.Label11 = Ltrim(rtrim(t3.Label11))
		,pl.Value11 = Ltrim(rtrim(t3.Value11))
		,pl.Label12 = Ltrim(rtrim(t3.Label12))
		,pl.Value12 = Ltrim(rtrim(t3.Value12))
		,pl.Label13 = Ltrim(rtrim(t3.Label13))
		,pl.Value13 = Ltrim(rtrim(t3.Value13))
		,pl.Label14 = Ltrim(rtrim(t3.Label14))
		,pl.Value14 = Ltrim(rtrim(t3.Value14))
		,pl.Label15 = Ltrim(rtrim(t3.Label15))
		,pl.Value15 = Ltrim(rtrim(t3.Value15))
		,pl.Label16 = Ltrim(rtrim(t3.Label16))
		,pl.Value16 = Ltrim(rtrim(t3.Value16))
		,pl.Label17 = Ltrim(rtrim(t3.Label17))
		,pl.Value17 = Ltrim(rtrim(t3.Value17))
		,pl.Label18 = Ltrim(rtrim(t3.Label18))
		,pl.Value18 = Ltrim(rtrim(t3.Value18))
		,pl.Label19 = Ltrim(rtrim(t3.Label19))
		,pl.Value19 = Ltrim(rtrim(t3.Value19))
		,pl.Label20 = Ltrim(rtrim(t3.Label20))
		,pl.Value20 = Ltrim(rtrim(t3.Value20))
		,pl.Label21 = Ltrim(rtrim(t3.Label21))
		,pl.Value21 = Ltrim(rtrim(t3.Value21))
		,pl.Label22 = Ltrim(rtrim(t3.Label22))
		,pl.Value22 = Ltrim(rtrim(t3.Value22))
		,pl.Label23 = Ltrim(rtrim(t3.Label23))
		,pl.Value23 = Ltrim(rtrim(t3.Value23))
		,pl.GranteeName = t3.GranteeName
		,pl.abstract = t3.abstract
		,pl.AcPage = t3.AcPage
		,pl.acres = t3.acres
		,pl.acresThru = t3.acresThru
		,pl.Apn = t3.Apn
		,pl.Apn2 = t3.Apn2
		,pl.Apn3 = t3.Apn3
		,pl.Apn4 = t3.Apn4
		,pl.Apn5 = t3.Apn5
		,pl.Apn6 = t3.Apn6
		,pl.Apn7 = t3.Apn7
		,pl.Apn8 = t3.Apn8
		,pl.Apn9 = t3.Apn9
		,pl.APNPart1 = t3.APNPart1
		,pl.APNPart2 = t3.APNPart2
		,pl.APNPart3 = t3.APNPart3
		,pl.ApnPin5 = t3.ApnPin5
		,pl.Area = t3.Area
		,pl.AreaName = t3.AreaName
		,pl.AreaPart2 = t3.AreaPart2
		,pl.AreaPart3 = t3.AreaPart3
		,pl.Block = t3.Block
		,pl.Block2 = t3.Block2
		,pl.Book = t3.Book
		,pl.Book2 = t3.Book2
		,pl.Book3 = t3.Book3
		,pl.City = t3.City
		,pl.County = t3.County
		,pl.District = t3.District
		,pl.EMPTY = t3.EMPTY
		,pl.EMPTY2 = t3.EMPTY2
		,pl.Extension = t3.Extension
		,pl.GovernmentLot = t3.GovernmentLot
		--,pl.Group = t3.Group
		,pl.Half = t3.Half
		,pl.HalfQuarter = t3.HalfQuarter
		,pl.Indicator = t3.Indicator
		,pl.Instrument = t3.Instrument
		,pl.Instrument2 = t3.Instrument2
		,pl.Lot = t3.Lot
		,pl.Lot2 = t3.Lot2
		,pl.Map = t3.Map
		,pl.MapCode = t3.MapCode
		,pl.MapPage = t3.MapPage
		,pl.MiningClaim = t3.MiningClaim
		,pl.MiningDistrict = t3.MiningDistrict
		,pl.MuniCode = t3.MuniCode
		,pl.Page = t3.Page
		,pl.Page2 = t3.Page2
		,pl.Parcel = t3.Parcel
		,pl.Parcel2 = t3.Parcel2
		,pl.Parcel2Split = t3.Parcel2Split
		,pl.ParcelCut1 = t3.ParcelCut1
		,pl.ParcelCut2 = t3.ParcelCut2
		,pl.ParcelCut3 = t3.ParcelCut3
		,pl.ParcelSplit = t3.ParcelSplit
		,pl.ParcelSplit2 = t3.ParcelSplit2
		,pl.Plat = t3.Plat
		,pl.Quadrant = t3.Quadrant
		,pl.Quarter = t3.Quarter
		,pl.Quarter2 = t3.Quarter2
		,pl.Range = t3.Range
		,pl.Range2 = t3.Range2
		,pl.RangeDir = t3.RangeDir
		,pl.RangeDirection = t3.RangeDirection
		,pl.RangeDirectionHalf = t3.RangeDirectionHalf
		,pl.RangeHalf = t3.RangeHalf
		,pl.RangeNumber = t3.RangeNumber
		,pl.Reception = t3.Reception
		,pl.Section = t3.Section
		,pl.Section2 = t3.Section2
		,pl.SectionalArb = t3.SectionalArb
		,pl.SectionPart2 = t3.SectionPart2
		,pl.Slide = t3.Slide
		,pl.SubBlock = t3.SubBlock
		,pl.Subdivision = t3.Subdivision
		,pl.Sublot = t3.Sublot
		,pl.Suffix = t3.Suffix
		,pl.SWISPicked = t3.SWISPicked
		,pl.Taxlot = t3.Taxlot
		,pl.Timeshare = t3.Timeshare
		,pl.TorTeeName = t3.TorTeeName
		,pl.Township = t3.Township
		,pl.TownshipDir = t3.TownshipDir
		,pl.TownshipNUmber = t3.TownshipNumber
		,pl.TownshipDirection = t3.TownshipDirection
		,pl.TownshipDirectionHalf = t3.TownshipDirectionHalf
		,pl.TownshipHalf = t3.TownshipHalf
		,pl.TownshipRange = t3.TownshipRange
		,pl.Tract = t3.Tract
		,pl.TractId = t3.TractId
		,pl.Unit = t3.Unit
		,pl.WardQualifier = Replace(replace(replace(t3.WardQualifier, '-', ''), '.', ''), ' ', '')
		,pl.Ward = t3.ward
		,pl.Year = t3.Year
		,pl.YYMMDD = t3.YYMMDD
		,pl.ApnPin1 = t3.ApnPin1
		,pl.ApnPin2 = t3.ApnPin2
		,pl.ApnPin3 = t3.ApnPin3
		,pl.ApnPin4 = t3.ApnPin4
		,pl.GrantorName = t3.GrantorName
		,pl.Apn1 = t3.Apn1
		,pl.QQ = t3.QQ
		--select * from pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Temp3 where ref_id in (8947156, 8951540, 8955986, 8957494)
		,pl.BookType = t3.BookType
	FROM [PET].[dbo].[PET_NEO_LEGALS] pl WITH (INDEX (Ixuc_fips_ref_id_neo_legal))
	INNER JOIN [pet].[pet_tmp].[usp_ProcessPetCounty_3_Multi_Legals_incr_Temp3] t3 WITH (
			NOLOCK
			,INDEX (ix_ref_id)
			) ON pl.fips = t3.fips
		AND pl.ref_id = t3.ref_id
		AND Pl.NEO_APN = t3.NEO_APN
		AND pl.NEO_TITLE_LEGAL = t3.NEO_TITLE_LEGAL
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	DECLARE @PLN_STATE CHAR(2)
	DECLARE @PLN_COUNTY CHAR(2)

	SELECT @PLN_STATE = substring(pc.Neo_counties, 1, 2)
		,@PLN_COUNTY = substring(pc.Neo_counties, 3, 2)
	FROM [pet].[dbo].[pet_counties] pc WITH (
			NOLOCK
			,INDEX (idxc_fips)
			)
	WHERE pc.fips = @fips
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [PET].[pet_dbo].[p]
	SET p.Reception = p1.Reception
		--,null as legal_desc_abstract_acreage
		--,null as legal_desc_abstract_number
		--,null as legal_desc_apn
		--,null as legal_desc_arb
		,p.legal_desc_map_block = p2.legal_desc_map_block
		,p.legal_desc_map_building = NULL
		,p.legal_desc_map_lot_low = p2.legal_desc_map_lot_low
		,p.legal_desc_map_lot_type = NULL
		,p.legal_desc_map_lot_type_low = NULL
		,p.legal_desc_map_plat_book = p2.legal_desc_map_plat_book
		,p.legal_desc_map_plat_condo_id = NULL
		,p.legal_desc_map_plat_type_indicator = p0.PLN_EPR_PLAT_CODE
		,p.legal_desc_map_plat_number = p2.legal_desc_map_plat_number
		,p.legal_desc_map_unit_low = p2.legal_desc_map_unit_low
		,p.legal_desc_str_section = NULL
		,p.legal_desc_map_plat_page = p2.legal_desc_map_plat_page
		,p.legal_desc_map_sublot = p2.legal_desc_map_sublot
		,p.Book_Page_Block_lot = p3.Book_Page_Block_lot
		,p.Plat_NBR_block_lot = p3.Plat_NBR_block_lot
		,p.PLAT_NBR_Lot = p3.PLAT_NBR_Lot
		,p.MUNI_BLOCK_LOT_QUALIFIER = p3.MUNI_BLOCK_LOT_QUALIFIER
		,p.legal_desc_municipality = p2.legal_desc_municipality
		,p.SubBlock = p2.SubBlock
		,p.Sublot = p2.Sublot
		--,p.WardQualifier = p2.WardQualifier
		,p.Book_Page_lot = p3.Book_Page_lot
	FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (
			NOLOCK
			,INDEX (idx_fips_neoAPN)
			)
	INNER JOIN [pet].[dbo].[pet_neo_legals] p WITH (
			NOLOCK
			,INDEX (ix_fipsNEO)
			) ON p.fips = incr.fips
		AND p.neo_apn = incr.neo_apn
		AND p.NEO_LAND_TYPE = incr.NEO_LAND_TYPE
		AND p.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
	OUTER APPLY (
		SELECT TOP 1 p0.PLN_ROW_ID
			,p0.PLN_PLAT_ID_SUB_CODE
			,p0.PLN_PLAT_NAME
			,p0.PLN_EPR_BOOK
			,p0.PLN_EPR_PLAT_CODE
		FROM [EPR_VDB].[dbo].[PlatName_EPR] p0 WITH (
				NOLOCK
				,INDEX (IDX_PlatName_EPR__PLN_STATE__PLN_COUNTY__PLN_PLAT_ID__EPR_PLAT_TYPE_IND__PLN_PLAT_ID_SUB_CODE)
				)
		WHERE p0.PLN_STATE = @PLN_STATE
			AND p0.PLN_COUNTY = @PLN_COUNTY
			AND p0.PLN_PLAT_ID = p.NEO_TITLE_LEGAL_18
			AND p0.PLN_NAME_TYPE = 'P'
		) p0
	OUTER APPLY (
		SELECT CASE 
				WHEN p.Label9 = 'Reception'
					AND p.Value9 IS NOT NULL
					AND PATINDEX('% %', ltrim(rtrim(p.Value9))) = 0
					THEN ltrim(rtrim(p.Value9))
				ELSE ''
				END AS Reception
			--,CASE 
			--	WHEN p.label17 = 'WardQualifier'
			--		THEN Replace(replace(replace(value17, '-', ''), '.', ''), ' ', '')
			--	ELSE NULL
			--	END AS WardQualifier
		) p1
	OUTER APPLY (
		SELECT CASE 
				WHEN p.Label4 = 'Block'
					THEN p.VALUe4
				ELSE ''
				END AS legal_desc_map_block
			,CASE 
				WHEN p.Label6 = 'Lot'
					THEN p.VALUe6
				ELSE ''
				END AS legal_desc_map_lot_low
			,CASE 
				WHEN p.fips BETWEEN 53000
						AND 54000
					THEN CASE 
							WHEN substring(Value1, 1, 1) IN (
									'P'
									,'C'
									)
								AND isnumeric(substring(Value1, 2, 1)) = 1
								THEN substring(Value1, 2, 10)
							ELSE Value1
							END
				WHEN p.fips BETWEEN 55000
						AND 56000
					THEN CASE 
							WHEN substring(Value1, 1, 3) IN ('CSM')
								AND isnumeric(substring(Value1, 4, 1)) = 1
								THEN substring(Value1, 4, 10)
							ELSE Value1
							END
				WHEN p.fips BETWEEN 32003
						AND 32003
					THEN CASE 
							WHEN substring(Value1, 1, 2) IN ('PM')
								AND isnumeric(substring(Value1, 3, 1)) = 1
								THEN substring(Value1, 3, 10)
							ELSE Value1
							END
				WHEN p.Label1 IN (
						'YYMMDD'
						,'Block2'
						)
					OR (
						Label1 IN ('Tract')
						AND p.fips NOT IN (
							6037
							,6081
							,6025
							,15999
							,6029
							,6001
							,6013
							,6059
							,6065
							,6067
							,6075
							,6071
							,6073
							,6083
							,6111
							)
						)
					OR (
						p.Label1 IN ('Book')
						AND p1.Reception = ''
						)
					THEN
						--CASE 
						--		WHEN p0.PLN_PLAT_NAME IS NOT NULL
						--			AND p0.PLN_EPR_BOOK IS NOT NULL
						--			AND p.Label1 IN ('Book') --,'YYMMDD')
						--			THEN p0.PLN_EPR_BOOK
						--		ELSE 
						value1
						--END
				ELSE ''
				END AS legal_desc_map_plat_book
			,CASE 
				WHEN p.Label3 IN ('AcPage')
					OR (
						p.label3 IN ('TractId')
						AND p.fips NOT IN (
							6037
							,6081
							,6025
							,15999
							,6029
							,6001
							,6013
							,6059
							,6065
							,6067
							,6075
							,6071
							,6073
							,6083
							,6111
							)
						)
					OR (
						p.Label3 IN ('Page')
						AND p1.Reception = ''
						)
					THEN p.VALUe3
				WHEN p.Label17 = 'Subdivision'
					THEN p.VALUe17
				ELSE ''
				END AS legal_desc_map_plat_page
			,CASE 
				WHEN p.Label1 IN (
						'Year'
						,'YYMMDD'
						)
					AND Label2 = 'Instrument'
					THEN p.VALUe1 + '-' + p.Value2
				WHEN p1.Reception > ''
					THEN p1.Reception --ltrim(rtrim(Value9))
				WHEN p.Label1 IS NULL
					AND Label3 = 'Page'
					THEN p.VALUe3
				WHEN p.Label1 = 'Tract'
					AND p.fips IN (
						6037
						,6081
						,6025
						,15999
						,6029
						,6001
						,6013
						,6059
						,6065
						,6067
						,6075
						,6071
						,6073
						,6083
						,6111
						)
					THEN CASE 
							WHEN p.Label3 IS NULL
								THEN CASE 
										WHEN substring(ltrim(value1), 1, 1) IN (
												'W'
												,'T'
												)
											THEN substring(ltrim(value1), 2, 20)
										ELSE value1
										END
							ELSE CASE 
									WHEN substring(ltrim(value1), 1, 1) IN (
											'W'
											,'T'
											)
										THEN substring(ltrim(value1), 2, 20)
									ELSE value1
									END + '-' + p.Value3
							END
				WHEN p.Label8 = 'Plat'
					THEN p.VALUe8
				ELSE ''
				END AS legal_desc_map_plat_number
			,CASE 
				WHEN p.Label7 = 'SUBLOT'
					THEN p.value7
				ELSE ''
				END legal_desc_map_sublot
			,CASE 
				WHEN p.label7 = 'UNIT'
					THEN p.value7
				ELSE ''
				END AS legal_desc_map_unit_low
			,BookType AS out_bookType
			,CASE 
				WHEN p.label1 = 'MuniCode'
					THEN p.value1
				ELSE NULL
				END AS legal_desc_municipality
			,CASE 
				WHEN p.label5 = 'SubBlock'
					THEN p.value5
				ELSE NULL
				END AS SubBlock
			,CASE 
				WHEN p.label7 = 'Sublot'
					THEN p.value7
				ELSE NULL
				END AS Sublot
			--,CASE 
			--	WHEN isnumeric(substring(p1.WardQualifier, 1, 1)) = 0
			--		THEN substring(p1.WardQualifier, 1, 1) + ISNULL(SPDB.dbo.RegexExtract(substring(p1.WardQualifier, 2, 20), '(^0+.*)', '1', 0), '')
			--	ELSE ISNULL(SPDB.dbo.RegexExtract(p1.WardQualifier, '(^0+.*)', '1', 0), '')
			--	END AS WardQualifier
			--,try_cast( d.fips_code as int) as fips
		) p2
	OUTER APPLY (
		SELECT 'pb' + isnull(p2.legal_desc_map_plat_book, '') + 'pg' + isnull(p2.legal_desc_map_plat_page, '') + 'bl' + isnull(p2.legal_desc_map_block, '') + 'LT' + isnull(p2.legal_desc_map_lot_low, '') AS Book_Page_Block_lot
			,'PN' + isnull(p2.legal_desc_map_plat_number, '') + 'Bl' + isnull(p2.legal_desc_map_block, '') + 'LT' + isnull(p2.legal_desc_map_lot_low, '') AS Plat_NBR_block_lot
			,'pn' + isnull(p2.legal_desc_map_plat_number, '') + 'LT' + isnull(p2.legal_desc_map_lot_low, '') AS PLAT_NBR_Lot
			,'MC' + isnull(p2.legal_desc_municipality, '') + 'BL' + isnull(p2.legal_desc_map_block, '') + 'SB' + isnull(p2.SubBlock, '') + 'LT' + isnull(p2.legal_desc_map_lot_low, '') + 'Sl' + isnull(p2.Sublot, '') + 'WQ' + isnull(p.WardQualifier, '') AS MUNI_BLOCK_LOT_QUALIFIER
			,'pb' + isnull(p2.legal_desc_map_plat_book, '') + 'pg' + isnull(p2.legal_desc_map_plat_page, '') + 'LT' + isnull(p2.legal_desc_map_lot_low, '') AS Book_Page_lot
		) p3
	WHERE p.fips = @fips
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_ProcessPetCounty_3_Multi_Legals_Incr'
		,N'Ended'
		--SET @outfips = @fips  
		----select * from PET.dbo.Pet_LableColumns  
		--if object_id('Tempdb..pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp_idx') is not null  
		-- drop table  pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp_idx;  
		--Select ref_id   
		--      into pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp_idx  
		-- FROM PET.dbo.Pet_LableColumns --pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp  
		-- where fips in (6059,6065) and _field = 'Sublot'  
		-- and fips = @fips  
		--Create unique index ix_ref_id on pet.pet_tmp.usp_ProcessPetCounty_3_Multi_Legals_Incr_temp_idx (REf_id)  
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


