/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_UpdateReferenceMatch_fips | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- ============================================= 
-- Author:		<Sunwoo Park>
-- Create date: <2026-02-23> 
-- Description:	<Nova ref rematch>  
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_UpdateReferenceMatch_fips] (
	@fips INT
	,@annual BIT = 0
	,@ERROR VARCHAR(500) = NULL OUTPUT
	)
AS
DECLARE @Txt VARCHAR(50)

BEGIN TRY
	SET @Txt = CONCAT (
			'usp_UpdateReferenceMatch_fips - '
			,@fips
			)

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Started'

	-- declare @fips INT = 45075,@annual BIT = 1 ,@ERROR VARCHAR(500) = null 
	--SELECT r.REFERENCE_id
	--INTO #ref
	--FROM Lien.UR.REFERENCE r WITH (
	--		NOLOCK
	--		,INDEX (PK_REFERENCE)
	--		)
	--LEFT JOIN Lien.UR.REFERENCE_Match rm WITH (
	--		NOLOCK
	--		,INDEX (ix_ref)
	--		) ON rm.REFERENCE_id = r.REFERENCE_id
	--WHERE rm.REFERENCE_id IS NULL
	TRUNCATE TABLE [lien].[tmp].[usp_UpdateReferenceMatch_fips_match]

	INSERT INTO [lien].[tmp].[usp_UpdateReferenceMatch_fips_match] (
		REFERENCE_id
		,fips_code
		,doc_id
		,UR_Doc_Type
		)
	SELECT rm.REFERENCE_id
		,right('00' + try_cast(@fips AS VARCHAR(5)), 5) AS fips_code
		,rd.doc_id
		,CASE 
			WHEN pfc.PRE_FORECLOSURE_CODE IS NOT NULL
				THEN 'PFC'
			WHEN ras.DTDB_DETAILED_DOCUMENT_TYPE IS NOT NULL
				THEN 'RAS'
			WHEN deed.DETAILED_DOCUMENT_TYPE IS NOT NULL
				THEN 'DEED'
			ELSE 'NONE'
			END AS UR_Doc_Type
	--INTO lien.tmp.usp_UpdateReferenceMatch_fips_match
	FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_rematch_input] rd -- these are do_ids that were identified to be rematched
	INNER JOIN [lien].[ur].[reference] rm WITH (
			NOLOCK
			,INDEX (ix_doc_id)
			) ON rm.doc_id = rd.doc_id
	LEFT JOIN [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = rd.doc_id
	LEFT JOIN [Lien_DTDB].[dbo].[UR_PFC_Doc_Types] pfc WITH (
			NOLOCK
			,INDEX (idx_doc_type)
			) ON d.doc_type = pfc.doc_type
		AND pfc.delete_date IS NULL
	LEFT JOIN [Lien_DTDB].[dbo].[UR_RAS_Doc_Types] ras WITH (
			NOLOCK
			,INDEX (idx_ur_doc_type)
			) ON d.doc_type = ras.ur_doc_type
		AND ras.delete_date IS NULL
	LEFT JOIN [Lien_DTDB].[dbo].[UR_Document_Types] deed WITH (
			NOLOCK
			,INDEX (idx_doc_type)
			) ON d.doc_type = deed.ur_value
		AND deed.delete_date IS NULL

	--CREATE INDEX idx_fips ON lien.tmp.usp_UpdateReferenceMatch_fips_match (fips_code)
	--CREATE INDEX ix_ref_id ON lien.tmp.usp_UpdateReferenceMatch_fips_match (REFERENCE_id)
	--
	-- here the logic start that you  wnat to run by fips
	--
	truncate table [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp]

	insert into [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp] (
	aaaa, doc_id, REFERENCE_id, fips, doc_unique_id, reference_id_sequence_number, reference_type_code, reference_book, reference_page, _bookPage, reference_recording_year, reference_doc_number, reference_recording_date, _reference_recording_date, reference_questionable_indicator, batch, bucket, nova_doc_id, Nova_Doc_Number, Nova_REF_ID, Nova_Property_Id, Nova_Cmt_Id, Sr_Unique_Id, Doc_Src_Ind, Updated, Created, Orig_Src
	)

	


		SELECT l.aaaa
			,l.doc_id
			,l.REFERENCE_id
			,l.fips
			,l.doc_unique_id
			,ROW_NUMBER() OVER (
				PARTITION BY REFERENCE_id ORDER BY (
						SELECT 0
						)
				) AS reference_id_sequence_number
			,l.reference_type_code
			,l.reference_book
			,l.reference_page
			,l._bookPage
			,l.reference_recording_year
			,l.reference_doc_number
			,l.reference_recording_date
			,l._reference_recording_date
			,l.reference_questionable_indicator
			,l.batch
			,l.bucket
			,l.nova_doc_id
			,l.Nova_Doc_Number
			,l.Nova_REF_ID
			,l.Nova_Property_Id
			,l.Nova_Cmt_Id
			,l.Sr_Unique_Id
			,l.Doc_Src_Ind
			,l.Updated
			,l.Created
			,l.Orig_Src
		--INTO lien.tmp.usp_UpdateReferenceMatch_fips_temp
		--,ROW4
		FROM (
			SELECT k.aaaa
				,k.doc_id
				,k.REFERENCE_id
				,k.fips
				,k.doc_unique_id
				,k.reference_id_sequence_number
				,k.reference_type_code
				,k.reference_book
				,k.reference_page
				,k._bookPage
				,k.reference_recording_year
				,k.reference_doc_number
				,k.reference_recording_date
				,k._reference_recording_date
				,k.reference_questionable_indicator
				,k.batch
				,k.bucket
				,k.nova_doc_id
				,k.Nova_Doc_Number
				,k.Nova_REF_ID
				,k.Nova_Property_Id
				,k.Nova_Cmt_Id
				,k.Sr_Unique_Id
				,k.Doc_Src_Ind
				,k.Orig_Src
				,getdate() AS Updated
				,getdate() AS Created
				,ROW_NUMBER() OVER (
					PARTITION BY k.doc_id
					,k.REFERENCE_id
					,k.Sr_Unique_Id ORDER BY k.Fmt_Reference_Doc_Number
						,k.Fmt_BookPAge
					) AS ROW4
			--into Lien.UR.REFERENCE_Match
			FROM (
				SELECT d.orig_src AS aaaa
					,a.doc_id
					,a.REFERENCE_id
					,a.fips AS fips
					,a.doc_unique_id
					,a.reference_id_sequence_number
					,a.reference_type_code
					,a.reference_book
					,a.reference_page
					,a._bookPage
					,a.reference_recording_year
					,a.reference_doc_number
					,a.reference_recording_date
					,a._reference_recording_date
					,a.reference_questionable_indicator
					,a.batch
					,a.bucket
					,a.Fmt_Reference_Doc_Number
					,a.Fmt_BookPAge
					,d.Doc_Id AS nova_doc_id
					,d.Doc_Number AS Nova_Doc_Number
					,d.REF_ID AS Nova_REF_ID
					,d.Property_Id AS Nova_Property_Id
					,d.Cmt_Id AS Nova_Cmt_Id
					,d.Sr_Unique_Id
					,d.Doc_Src_Ind
					,d.Orig_Src
				FROM (
					SELECT r.[doc_id]
						,r.REFERENCE_id
						,aaa.fips_code AS fips
						,r.[doc_unique_id]
						,r.[reference_id_sequence_number]
						,r.[reference_type_code]
						,r.[reference_book]
						,r.[reference_page]
						,CASE 
							WHEN r.[reference_book] IS NOT NULL
								AND r.[reference_page] IS NOT NULL
								THEN r.[reference_book] + '.' + r.[reference_page]
							ELSE NULL
							END _bookPage
						,r.[reference_recording_year]
						,r.[reference_doc_number]
						,r.[reference_recording_date]
						,CASE 
							WHEN isdate(r.[reference_recording_date]) = 1
								THEN cast(r.[reference_recording_date] AS DATE)
							ELSE NULL
							END AS _reference_recording_date
						,(
							SELECT [spdb].[eprvdb].[fn_DTOCR_RecordingDate](r.[reference_recording_date])
							) AS reference_recording_date_d
						,r.[reference_questionable_indicator]
						,r.[batch]
						,r.[bucket]
						,r.Fmt_Reference_Doc_Number
						,r.Fmt_BookPAge
						,aaa.ur_doc_type
					FROM [Lien].[UR].[REFERENCE] r WITH (NOLOCK)
					INNER JOIN [lien].[tmp].[usp_UpdateReferenceMatch_fips_match] aaa WITH (
							NOLOCK
							,INDEX (ix_ref_id)
							) ON aaa.REFERENCE_id = r.REFERENCE_id
						--WHERE aaa.fips_code = @fips_a
						--WHERE r.doc_id = 18883673
					) a
				OUTER APPLY (
					SELECT *
					FROM (
						SELECT d.*
						FROM [assr].[dbo].[Translate_Fips] tf WITH (NOLOCK)
						INNER JOIN [NovaDimDoc].[dbo].[DIM_NOVA_DOCUMENT] d WITH (NOLOCK) ON d.fips = tf.TranslatedFips
						WHERE tf.fips = a.fips
							AND d.Doc_Number = a.Fmt_Reference_Doc_Number --a.[reference_doc_number]
							--AND (
							--	(
							--		d.Recording_Date = a.reference_recording_date_d
							--		AND a.reference_recording_date_d IS NOT NULL
							--		)
							--	OR (
							--		a.reference_recording_date_d IS NULL
							--		AND d.Fips = a.fips
							--		)
							--	)
							AND Doc_Src_Ind <> 'D'
							AND (
								a.ur_doc_type = 'PFC'
								AND d.Orig_Src IN (
									'BKS'
									,'BKD'
									,'BKP'
									,'CLD'
									,'CLP'
									,'DQD'
									,'EPP'
									,'EPM'
									,'EPD'
									,'MPP'
									,'MPM'
									,'MPD'
									)
								OR a.ur_doc_type <> 'PFC'
								)
							AND (
								(
									SELECT count(1)
									FROM [assr].[dbo].[assr] ar WITH (
											NOLOCK
											,INDEX (IDX_Assr_Ref_ID)
											)
									WHERE ar.ref_id = d.ref_id
									) > 0
								OR isnull(d.ref_id, 0) = 0
								)
						
						UNION ALL
						
						SELECT d.*
						FROM [assr].[dbo].[Translate_Fips] tf WITH (NOLOCK)
						INNER JOIN [NovaDimDoc].[dbo].[DIM_NOVA_DOCUMENT] d WITH (NOLOCK) ON d.fips = tf.TranslatedFips
						WHERE tf.Fips = a.Fips --a.fips
							AND d.Doc_Number = a.Fmt_BookPAge -- a._bookPage
							--AND (
							--	(
							--		d.Recording_Date = a.reference_recording_date_d
							--		AND a.reference_recording_date_d IS NOT NULL
							--		)
							--	OR (
							--		a.reference_recording_date_d IS NULL
							--		AND d.Fips = a.fips
							--		)
							--	)
							AND Doc_Src_Ind <> 'D'
							AND (
								a.ur_doc_type = 'PFC'
								AND d.Orig_Src IN (
									'BKS'
									,'BKD'
									,'BKP'
									,'CLD'
									,'CLP'
									,'DQD'
									,'EPP'
									,'EPM'
									,'EPD'
									,'MPP'
									,'MPM'
									,'MPD'
									)
								OR a.ur_doc_type <> 'PFC'
								)
							AND (
								(
									SELECT count(1)
									FROM [assr].[dbo].[assr] ar WITH (
											NOLOCK
											,INDEX (IDX_Assr_Ref_ID)
											)
									WHERE ar.ref_id = d.ref_id
									) > 0
								OR isnull(d.ref_id, 0) = 0
								)
						) d
					) d
					--WHERE d.Doc_Id IS NOT NULL
				) k
			) l
		WHERE row4 = 1

	--CREATE INDEX idx_doc_id ON lien.tmp.usp_UpdateReferenceMatch_fips_temp (doc_id) include (reference_id)

	BEGIN TRANSACTION

	--	identify the records for which a match was found
	--	select  * from lien.tmp.usp_UpdateReferenceMatch_fips_temp
	--where nova_doc_id is not null
	--	Delete those records from Lien.ur.Reference_match
	--select rm.*
	--,ft.*
	--SELECT rm.doc_id,rm.nova_doc_id
	--	,rm.reference_id_sequence_number
	--	,rm.Nova_Doc_Number
	--	,rm.Nova_REF_ID
	--	,ft.nova_doc_id
	--	,ft.reference_id_sequence_number
	--	,ft.Nova_Doc_Number
	--	,ft.Nova_REF_ID
	IF @annual = 1
	BEGIN
		--The result set should include the following scenarios:
		--Create a result when a new nova_doc_id is found for an existing Reference_Match record.
		--For an existing reference_seq number, create a result whenever the doc_id in Reference_Match differs from the doc_id found in NOVA, regardless of whether the NOVA record already has a ref_id.
		--Include all new matches that did not previously exist in the result set.
		--If the doc_id is different (which also means the ref_id is different), add it to the result set. This covers scenarios where, for example, a mortgage record was deleted and then reinserted into NOVA, resulting in a new doc_id.

		truncate table [lien].[tmp].[usp_UpdateReferenceMatch_fips_match_result]

		insert into [lien].[tmp].[usp_UpdateReferenceMatch_fips_match_result] (
		doc_id, reference_id, reference_id_sequence_number
		)

		
 
			SELECT rm.doc_id
				,rm.reference_id
				,rm.reference_id_sequence_number
			--INTO lien.tmp.usp_UpdateReferenceMatch_fips_match_result
			FROM [Lien].[ur].[Reference_match] rm WITH (
					NOLOCK
					,INDEX (id_doc_id)
					)
			CROSS APPLY (
				SELECT *
				FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp] ft WITH (
						NOLOCK
						,INDEX (idx_doc_id)
						)
				WHERE ft.doc_id = rm.doc_id
					-- if we dont include the test below, then it would include all records for reference_id and sequence_number, even if there was no change
					AND ft.reference_id = rm.reference_id
					AND ft.reference_id_sequence_number = rm.reference_id_sequence_number
				) ft
			WHERE isnull(rm.nova_doc_id, 0) <> isnull(ft.nova_doc_id, 0)

		--CREATE INDEX idx_doc_id ON lien.tmp.usp_UpdateReferenceMatch_fips_match_result (doc_id) include (
		--	reference_id
		--	,reference_id_sequence_number
		--	)

		-- delete from Lien.ur.Reference_match where we found  an new match for reference_id and sequence_number
		DELETE rm
		FROM [Lien].[ur].[Reference_match] rm WITH (
				NOLOCK
				,INDEX (id_doc_id)
				)
		CROSS APPLY (
			SELECT *
			FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_match_result] ft WITH (
					NOLOCK
					,INDEX (idx_doc_id)
					)
			WHERE ft.doc_id = rm.doc_id
				AND ft.reference_id = rm.reference_id
				AND ft.reference_id_sequence_number = rm.reference_id_sequence_number
			) ft

		-- delete from lien.tmp.usp_UpdateReferenceMatch_fips_temp where the record is not on lien.tmp.usp_UpdateReferenceMatch_fips_match_result
		-- delete from temp where it is not a replacement for the same reference_id and seq_nbr - was not found on results
		DELETE rm
		FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp] rm WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		OUTER APPLY (
			SELECT *
			FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_match_result] ft WITH (
					NOLOCK
					,INDEX (idx_doc_id)
					)
			WHERE ft.doc_id = rm.doc_id
				AND ft.reference_id = rm.reference_id
				AND ft.reference_id_sequence_number = rm.reference_id_sequence_number
			) ft
		WHERE ft.doc_id IS NULL
	END

	--	insert them back from lien.tmp.usp_UpdateReferenceMatch_fips_temp
	INSERT INTO [Lien].[UR].[REFERENCE_Match] (
		[aaaa]
		,[doc_id]
		,[REFERENCE_id]
		,[fips]
		,[doc_unique_id]
		,[reference_id_sequence_number]
		,[reference_type_code]
		,[reference_book]
		,[reference_page]
		,[_bookPage]
		,[reference_recording_year]
		,[reference_doc_number]
		,[reference_recording_date]
		,[_reference_recording_date]
		,[reference_questionable_indicator]
		,[batch]
		,[bucket]
		,[nova_doc_id]
		,[Nova_Doc_Number]
		,[Nova_REF_ID]
		,[Nova_Property_Id]
		,[Nova_Cmt_Id]
		,[Sr_Unique_Id]
		,[Doc_Src_Ind]
		,[Updated]
		,[Created]
		)
	OUTPUT inserted.Doc_id
		,NULL AS Name_id
		,NULL AS property_id
		,NULL AS reference_id
		,inserted.Created
		,'usp_UpdateReferenceMatch' AS Process_name
	INTO [lien].[ur].[document_transaction_log]
	SELECT isnull(t.aaaa, '') AS aaaa
		,t.doc_id
		,t.REFERENCE_id
		,t.fips
		,t.doc_unique_id
		,ROW_NUMBER() OVER (
			PARTITION BY REFERENCE_id ORDER BY (
					SELECT 0
					)
			) AS reference_id_sequence_number
		,t.reference_type_code
		,t.reference_book
		,t.reference_page
		,t._bookPage
		,t.reference_recording_year
		,t.reference_doc_number
		,t.reference_recording_date
		,t._reference_recording_date
		,t.reference_questionable_indicator
		,t.batch
		,t.bucket
		,t.nova_doc_id
		,t.Nova_Doc_Number
		,t.Nova_REF_ID
		,t.Nova_Property_Id
		,t.Nova_Cmt_Id
		,t.Sr_Unique_Id
		,t.Doc_Src_Ind
		,t.Updated
		,t.Created
	FROM [lien].[tmp].[usp_UpdateReferenceMatch_fips_temp] t
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	COMMIT

	--	Inset a lien_fix record for all those inserted so that the ras/pfc can be deleted
	-- end transaction 
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,@Txt
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END
END CATCH


