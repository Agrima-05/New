SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [xVJ].[dbo].[test_usp_800_2]
AS
BEGIN

	SELECT GETDATE()

	/*
	TRUNCATE TABLE [xVJ].dbo.[temp_listingFull_WORKING_v3]

		--drop index [temp_ix_MLSIDListingID] on [xVJ].dbo.[temp_listingFull_WORKING_v3]
		/*
		CREATE NONCLUSTERED INDEX [temp_ix_MLSIDListingID] ON [xVJ].dbo.[temp_listingFull_WORKING_v3]
		([mls_id] ASC,[mls_listing_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
		*/

		DECLARE @MinID INT, @MaxID INT, @LoopSize INT, @StartID INT, @EndID INT

		Select @MinID = MIN(mls_id), @MaxID = MAX(mls_id) from [src_Platlabs].[listing].[ListingsRaw] WITH(NOLOCK)

		SET @LoopSize = 50
		SET @StartID = @MinID

		declare @note_start_time datetime = getdate()

	WHILE @StartID <= @MaxID
	BEGIN
	SET @EndID = @StartID + @LoopSize
				
		INSERT INTO [xVJ].[dbo].[temp_listingFull_WORKING_v3](normalized_address
		,photos
		,geo_data
		,features
		,agents_listing_agent
		,agents_co_listing_agent
		,agents_selling_agent
		,agents_co_selling_agent
		,school_district
		,elementary_school
		,junior_high_school
		,high_school
		,middle_school
		,videos_change_date
		,major_change_date
		,above_grade_finished_area
		,activation_date
		,active
		,additional_features
		,[address]
		,air_conditioning
		,allow_avm
		,allow_comments
		,annual_insurance
		,annual_maintenance
		,annual_management_fees
		,annual_tax
		,annual_utilities
		,appliances
		,approximate_age
		,area_name
		,area_name_minor
		,availability_date
		,basement_description
		,bathrooms
		,bathrooms_full
		,bathrooms_half
		,bathrooms_partial
		,bathrooms_quarter
		,bathrooms_three_quarter
		,bedrooms
		,below_grade_description
		,below_grade_finished_area
		,building_name
		,cancelled_date
		,ceiling_height
		,ceiling_height_str
		,city
		,close_date
		,commission_misc
		,community
		,condition
		,confidential_description
		,construction_materials
		,contingencies
		,contingent_date
		,contract_date
		,contract_status_change_date
		,country
		,country_code
		,county
		,created_date
		,cumulative_days_on_market
		,current_use
		,days_on_market
		,days_on_market_replication_date
		,den_description
		,[description]
		,design
		,dining_room_description
		,directions
		,disability_features
		,display_lat
		,display_lng
		,display_mls_number
		,documents_change_timestamp
		,door_features
		,down_payment_resource
		,driveway_description
		,exclusions
		,expiration_date
		,exterior_description
		,exterior_features
		,extras
		,family_room_description
		,fence_description
		,financial_information
		,fireplace_description
		,fireplaces
		,flooring_information
		,foreclosure_type
		,formatted_address
		,frontage_type
		,garage_description
		,garage_spaces
		,geocode_date
		,geocode_quality
		,green_features
		,has_basement
		,has_electricity
		,has_fireplace
		,has_garage
		,has_hoa
		,has_horse_property
		,has_mountain_view
		,has_open_house
		,has_pool
		,has_price_reduced
		,has_sewer
		,has_view
		,has_water
		,has_waterfront
		,has_waterview
		,heat_source
		,heat_type
		,hide_address
		,hoa_amenities
		,hoa_fee
		,hoa_fee_includes
		,hoa_frequency
		,hoa_name
		,hoa_phone
		,idx
		,improvements
		,interior_features
		,is_adult_community
		,is_boat_slip
		,is_business_with_real_estate
		,is_commercial
		,is_commercial_lease
		,is_condo
		,is_condo_townhouse
		,is_coop
		,is_cul_de_sac
		,is_duplex
		,is_farm_hobby
		,is_foreclosure
		,is_gated_community
		,is_golf_community
		,is_industrial
		,is_investment
		,is_loft
		,is_lot
		,is_mixed_use
		,is_mobile_home
		,is_model
		,is_multi_family
		,is_new_construction
		,is_on_golf_course
		,is_one_story
		,is_other
		,is_rental
		,is_residential_lease
		,is_shortsale
		,is_single_family
		,is_single_family_detached
		,is_three_plus_story
		,is_townhouse
		,is_two_story
		,kitchen
		,kitchen_description
		,kitchen_dimensions
		,kitchen_level
		,landscape
		,last_update_date
		,latitude
		,laundry_room_description
		,list_date
		,listing_agent_commission_rate
		,listing_agent_email
		,listing_agent_flat_fee
		,listing_agent_id
		,listing_agent_name
		,listing_agent_phone
		,listing_agent_uid
		,listing_agreement
		,listing_key
		,listing_office_id
		,listing_office_name
		,listing_office_phone
		,listing_office_uid
		,living_room_description
		,[location]
		,longitude
		,lot_description
		,lot_dimension
		,lot_size
		,lot_size_area
		,lot_size_display
		,lot_size_source
		,lot_size_square_feet
		,lot_size_units
		,market_name
		,master_bath_description
		,master_bedroom_description
		,master_bedroom_level
		,mls_create_date
		,mls_id
		,mls_lat
		,mls_list_date
		,mls_listing_id
		,mls_lng
		,mls_property_sub_type
		,mls_property_type
		,mls_status
		,mls_update_date
		,modified_date
		,monthly_hoa_fee
		,neighborhood
		,normalized_hoa_frequency
		,occupant_type
		,off_market_date
		,on_market_date
		,open_house
		,original_listing_price
		,originating_system_name
		,outbuildings_description
		,[ownership]
		,parcel_number
		,parcel_number_public_record
		,parking_description
		,parking_spaces
		,patio_and_porch_features
		,pending_date
		,pets_allowed
		,photo_count
		,photo_date
		,pool_description
		,price
		,price_change_date
		,price_change_timestamp
		,price_display
		,price_per_square_foot
		,property_type
		,property_view_description
		,restrictions
		,road_frontage_description
		,roofing
		,rooms
		,rooms_description
		,rupid
		,sale_type
		,security_features
		,seller_concessions
		,selling_agent_commission_rate
		,selling_agent_flat_fee
		,sewer
		,sold_date
		,sold_price
		,source_create_date
		,source_system_key
		,source_system_name
		,square_feet
		,square_feet_of_land
		,square_feet_range
		,square_foot_source
		,[state]
		,[status]
		,status_change_date
		,stories_description
		,stories_total
		,street_direction
		,street_name
		,street_number
		,street_pre_direction
		,street_type
		,structure_type
		,style
		,subdivision
		,substructure
		,tax_legal_description
		,tax_year
		,tenant_pays
		,topography
		,total_units
		,township
		,[uid]
		,unit_number
		,utilities
		,utilities_available
		,virtual_tour
		,virtual_tour_branded
		,walk_score
		,water
		,water_frontage
		,waterfront_description
		,windows_description
		,withdrawn_date
		,year_built
		,year_built_source
		,zip
		,zoning
		,LoadDate
		,PropertyID
		,REF_ID
		,FIPS
		,buyer_financing
		,energy_source
		,finished_area
		,furnished
		,has_irrigation_water_rights
		,is_land_lease
		,originating_system_id
		,possession
		,seller_concessions_comments
		,special_listing_conditions
		,tenant_total_expenses
		,unfinished_area
		,water_body_name
		,zoning_description
		,NormalizedAddress_CompleteAddress
		,NormalizedAddress_StreetNumber
		,NormalizedAddress_StreetPredirection
		,NormalizedAddress_StreetName
		,NormalizedAddress_StreetSuffix
		,NormalizedAddress_StreetPostdirection
		,NormalizedAddress_City
		,NormalizedAddress_State
		,NormalizedAddress_Zip
		,GeoData_City_Name
		,GeoData_Zip_Name
		,GeoData_Neighborhood_Name
		,GeoData_School_District_Name
		,co_listing_agent_Name
		,co_listing_agent_email
		,co_listing_agent_phone
		,co_listing_agent_FirstName
		,co_listing_agent_LastName
		,co_listing_agent_License_Number
		,co_Selling_agent_Name
		,co_Selling_agent_email
		,co_Selling_agent_phone
		,co_Selling_agent_FirstName
		,co_Selling_agent_LastName
		,co_Selling_agent_License_Number
		,Selling_Agent_Name
		,Selling_Agent_email
		,Selling_Agent_phone
		,Selling_Agent_FirstName
		,Selling_Agent_LastName
		,Selling_Agent_license_number
		,Sell_Agent_Office_ID
		,Sell_Agent_Office_Name
		,Sell_Agent_Office_Phone
		,List_Agent_Name
		,List_Agent_email
		,List_Agent_phone
		,List_Agent_FirstName
		,List_Agent_LastName
		,List_Agent_License_Number
		,List_Agent_Office_ID
		,List_Agent_Office_Name
		,List_Agent_Office_Phone
		)
		Select Distinct  zz.*
		,NA.NormalizedAddress_CompleteAddress
		,NA.NormalizedAddress_StreetNumber
		,NA.NormalizedAddress_StreetPredirection
		,NA.NormalizedAddress_StreetName
		,NA.NormalizedAddress_StreetSuffix
		,NA.NormalizedAddress_StreetPostdirection
		,NA.NormalizedAddress_City
		,NA.NormalizedAddress_State
		,NA.NormalizedAddress_Zip
		,GD.[city_name] [GeoData_City_Name]
		,GD.[zip_name] [GeoData_Zip_Name]
		,GD.[neighborhood_name] [GeoData_Neighborhood_Name]
		,GD.[school_district_name] [GeoData_School_District_Name]
		,ClA.[CoAgentName] [co_listing_agent_Name]
		,ClA.AgentEmail [co_listing_agent_email]
		,ClA.[AgentPhone] [co_listing_agent_phone]
		,ClA.[FirstName] [co_listing_agent_FirstName]
		,ClA.[LastName] [co_listing_agent_LastName]
		,ClA.[LicenseNumber] [co_listing_agent_License_Number]
		,CsA.[SellingAgentFullName] [co_Selling_agent_Name]
		,CsA.[Email] [co_Selling_agent_email]
		,CsA.[CoSellAgentPhone] [co_Selling_agent_phone]
		,CsA.[FirstName] [co_Selling_agent_FirstName]
		,CsA.[LastName] [co_Selling_agent_LastName]
		,CsA.[LicenseNumber] [co_Selling_agent_License_Number]
		,SA.[agent_ListAgentFullName] [Selling_Agent_Name]
		,SA.[agent_Email] [Selling_Agent_email]
		,SA.[agent_Phone] [Selling_Agent_phone]
		,SA.[agent_FirstName] [Selling_Agent_FirstName]
		,SA.[agent_LastName] [Selling_Agent_LastName]
		,SA.[agent_LicenseNumber] [Selling_Agent_license_number]
		,SA.[office_id] [Sell_Agent_Office_ID]
		,SA.[office_name] [Sell_Agent_Office_Name]
		,SA.[office_phone] [Sell_Agent_Office_Phone]
		,LA.[agent_ListAgentFullName] [List_Agent_Name]
		,LA.[agent_Email] [List_Agent_email]
		,LA.[agent_Phone] [List_Agent_phone]
		,LA.[agent_FirstName] [List_Agent_FirstName]
		,LA.[agent_LastName] [List_Agent_LastName]
		,LA.[agent_LicenseNumber] [List_Agent_License_Number]
		,LA.[office_id] [List_Agent_Office_ID]
		,LA.[office_name] [List_Agent_Office_Name]
		,LA.[office_phone] [List_Agent_Office_Phone]
		FROM [src_Platlabs].[listing].[ListingsRaw] zz
		LEFT OUTER JOIN [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData] NA on zz.mls_id = NA.mls_id and zz.mls_listing_id = NA.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[geodata].[RawGeoData] GD on zz.mls_id = GD.mls_id and zz.mls_listing_id = GD.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[agent].[CoSellingAgents] CsA on zz.mls_id = CsA.mls_id and zz.mls_listing_id = CsA.[mls_listing_id]
		LEFT OUTER JOIN [src_PlatLabs].[agent].[CoAgent_Batch] ClA on zz.mls_id = ClA.mls_id and zz.mls_listing_id = ClA.[mls_listing_id]
		LEFT OUTER JOIN [src_PlatLabs].[agent].[SellingAgents] SA ON zz.mls_id = SA.mls_id and zz.mls_listing_id = SA.mls_listing_id
		LEFT OUTER JOIN [src_PlatLabs].[agent].[ListAgents] LA ON zz.mls_id = LA.mls_id and zz.mls_listing_id = LA.mls_listing_id
		--LEFT OUTER JOIN (Select a.[uid],a.[mls_id],a.[mls_listing_id],a.[SellingAgentFullName],a.[FirstName],a.[LastName],a.[Email],a.[Phone],a.[LicenseNumber],a.[LoadDate],SellAgent_Array.id OfficeID,SellAgent_Array.name OfficeName,SellAgent_Array.Phone OfficePhone
		-- from [src_PlatLabs].[agent].[SellingAgents] a
		--CROSS APPLY OPENJSON([office]) WITH(
		--id varchar(500)
		--  ,uid varchar(20)
		--  ,name varchar(100)
		--  ,phone varchar(20)
		-- ) as SellAgent_Array) SA on zz.mls_id = SA.mls_id and zz.mls_listing_id = SA.[mls_listing_id]
		--LEFT OUTER JOIN (Select a.[uid],a.[mls_id],a.[mls_listing_id],a.[ListAgentFullName],a.[FirstName],a.[LastName],a.[Email],a.[Phone],a.[LicenseNumber],a.[LoadDate],ListAgent_Array.id OfficeID,ListAgent_Array.name OfficeName,ListAgent_Array.Phone OfficePhone
		-- from [src_PlatLabs].[agent].[ListAgents] a
		--CROSS APPLY OPENJSON([office]) WITH(
		--id varchar(500)
		--  ,uid varchar(20)
		--  ,name varchar(100)
		--  ,phone varchar(20)
		-- ) as ListAgent_Array) LA on zz.mls_id = LA.mls_id and zz.mls_listing_id = LA.[mls_listing_id]
		WHERE zz.LoadDate > (Select MAX(LoadDate) from [src_PlatLabs].[listing].[ListingFull])
		AND zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureExteriorGeneral = a.General
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_a] a ON zz.mls_id = a.MLSID
		and zz.mls_listing_id = a.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureExteriorStyle = b.[Style]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_b] b ON zz.mls_id = b.MLSID
		and zz.mls_listing_id = b.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureExteriorPool = c.[Pool]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_c] c ON zz.mls_id = c.MLSID
		and zz.mls_listing_id = c.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureExteriorParking = d.[Parking]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_d] d ON zz.mls_id = d.MLSID
		and zz.mls_listing_id = d.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorAppliances = e.[AC]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_e] e ON zz.mls_id = e.MLSID
		and zz.mls_listing_id = e.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	


		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorAppliances = f.[Appliances]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_f] f ON zz.mls_id = f.MLSID
		and zz.mls_listing_id = f.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	


		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorBasement = g.[Basement]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_g] g ON zz.mls_id = g.MLSID
		and zz.mls_listing_id = g.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	


		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorDisability = h.[DisabilityFeature]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_h] h ON zz.mls_id = h.MLSID
		and zz.mls_listing_id = h.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorGreen = i.[EcoGreenFeature]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_i] i ON zz.mls_id = i.MLSID
		and zz.mls_listing_id = i.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorFireplace = j.[Fireplace]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_j] j ON zz.mls_id = j.MLSID
		and zz.mls_listing_id = j.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorFlooring = k.[Flooring]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_k] k ON zz.mls_id = k.MLSID
		and zz.mls_listing_id = k.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorGeneral = l.[General]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_l] l ON zz.mls_id = l.MLSID
		and zz.mls_listing_id = l.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorHeating = m.[Heating]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_m] m ON zz.mls_id = m.MLSID
		and zz.mls_listing_id = m.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorLaundry = n.[Laundry]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_n] n ON zz.mls_id = n.MLSID
		and zz.mls_listing_id = n.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FeatureInteriorRooms = o.[Rooms]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_o] o ON zz.mls_id = o.MLSID
		and zz.mls_listing_id = o.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.ConstructionGeneral = p.[General]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_p] p ON zz.mls_id = p.MLSID
		and zz.mls_listing_id = p.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.constructinoRoofing = q.[Roofing]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_q] q ON zz.mls_id = q.MLSID
		and zz.mls_listing_id = q.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.ConstructionWindows = r.[windows]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_r] r ON zz.mls_id = r.MLSID
		and zz.mls_listing_id = r.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LocationCounty = s.[County]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_s] s ON zz.mls_id = s.MLSID
		and zz.mls_listing_id = s.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LocationHOAAmenities = t.HOAAmenities
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_t] t ON zz.mls_id = t.MLSID
		and zz.mls_listing_id = t.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LocationOriginatingMLS = u.[OriginatingMLS]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_u] u ON zz.mls_id = u.MLSID
		and zz.mls_listing_id = u.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LocationRoadAccess = v.[RoadAccess]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_v] v ON zz.mls_id = v.MLSID
		and zz.mls_listing_id = v.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LotCurrentUse = w.CurrentUse
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_w] w ON zz.mls_id = w.MLSID
		and zz.mls_listing_id = w.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LotFencing = x.Fencing
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_x] x ON zz.mls_id = x.MLSID
		and zz.mls_listing_id = x.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LotView = y.[view]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_y] y ON zz.mls_id = y.MLSID
		and zz.mls_listing_id = y.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.LotZoning = z.zoning
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_z] z ON zz.mls_id = z.MLSID
		and zz.mls_listing_id = z.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.UtilitesSewer = aa.Sewer
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_aa] aa ON zz.mls_id = aa.MLSID
		and zz.mls_listing_id = aa.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.UtilitiesUtilities = ab.Utilities
		FROM [src_Platlabs].[listing].[listingFull_WORKING] zz
		JOIN [src_Platlabs].[dbo].[Table_ab] ab ON zz.mls_id = ab.MLSID
		and zz.mls_listing_id = ab.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.UtilitiesWater = ac.Water
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_ac] ac ON zz.mls_id = ac.MLSID
		and zz.mls_listing_id = ac.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FinancialBuyersAgentCompensation = ad.BuyersAgentCompensation
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_ad] ad ON zz.mls_id = ad.MLSID
		and zz.mls_listing_id = ad.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FinancialNACompensation = ae.NACompensation
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_ae] ae ON zz.mls_id = ae.MLSID
		and zz.mls_listing_id = ae.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		UPDATE [xVJ].[dbo].[zz]
		SET zz.FinancialSource = af.[Source]
		FROM [xVJ].[dbo].[temp_listingFull_WORKING_v3] zz
		JOIN [src_Platlabs].[dbo].[Table_af] af ON zz.mls_id = af.MLSID
		and zz.mls_listing_id = af.MLS_LISTING_ID
		where zz.mls_id BETWEEN @StartID AND @EndID	

		SET @StartID = @EndID + 1
	END

				--Purposefully capturing the start and end time of this module
				declare @note_end_time datetime = getdate()
				declare @listingCount int
				set @listingCount = (select count(*) from [src_PlatLabs].[listing].[listingFull_WORKING] with(nolock))
				insert into [xVJ].[dbo].[temp_track_proc] values ('test_usp_800_2', @note_start_time, @note_end_time, getdate(), @listingCount)

	/*
	DECLARE @MinID INT, @MaxID INT, @LoopSize INT, @StartID INT, @EndID INT

Select @MinID = MIN(mls_id), @MaxID = MAX(mls_id) from [src_Platlabs].[listing].[ListingsRaw] WITH(NOLOCK)

SET @LoopSize = 50
SET @StartID = @MinID

declare @note_start_time datetime = getdate()

WHILE @StartID <= @MaxID
BEGIN
	SET @EndID = @StartID + @LoopSize
	
	INSERT INTO [xVJ].dbo.[temp_listingFull_WORKING_v3]
Select Distinct zz.*,a.[General] as FeatureExteriorGeneral, b.[Style] as FeatureExteriorStyle, c.[Pool] as FeatureExteriorPool, d.[Parking] as FeatureExteriorParking
, e.[AC] as FeatureInteriorAC, f.[Appliances]  as FeatureInteriorAppliances, [Basement] as FeatureInteriorBasement, [DisabilityFeature] as FeatureInteriorDisability, [EcoGreenFeature] as FeatureInteriorGreen
, [Fireplace] as FeatureInteriorFireplace, [Flooring] as FeatureInteriorFlooring, l.[General] as FeatureInteriorGeneral, [Heating] as FeatureInteriorHeating, [Laundry] as FeatureInteriorLaundry, o.[Rooms] as FeatureInteriorRooms
, p.[General] as ConstructionGeneral,q.[Roofing] as constructinoRoofing, r.[windows] as ConstructionWindows, s.[County] as LocationCounty, [HOAAmenities] as LocationHOAAmenities, [OriginatingMLS] as LocationOriginatingMLS, [RoadAccess] as LocationRoadAccess
,CurrentUse as LotCurrentUse, Fencing as LotFencing, [view] as LotView, z.zoning as LotZoning
,aa.Sewer as UtilitesSewer, ab.Utilities as UtilitiesUtilities, ac.Water as UtilitiesWater
,ad.BuyersAgentCompensation as FinancialBuyersAgentCompensation,ae.NACompensation as FinancialNACompensation, af.[Source] as FinancialSource
,NA.NormalizedAddress_CompleteAddress
,NA.NormalizedAddress_StreetNumber
,NA.NormalizedAddress_StreetPredirection
,NA.NormalizedAddress_StreetName
,NA.NormalizedAddress_StreetSuffix
,NA.NormalizedAddress_StreetPostdirection
,NA.NormalizedAddress_City
,NA.NormalizedAddress_State
,NA.NormalizedAddress_Zip
,GD.[city_name] [GeoData_City_Name]
,GD.[zip_name] [GeoData_Zip_Name]
,GD.[neighborhood_name] [GeoData_Neighborhood_Name]
,GD.[school_district_name] [GeoData_School_District_Name]
,ClA.[CoAgentName] [co_listing_agent_Name]
,ClA.[Email] [co_listing_agent_email]
,ClA.[Phone] [co_listing_agent_phone]
,ClA.[FirstName] [co_listing_agent_FirstName]
,ClA.[LastName] [co_listing_agent_LastName]
,ClA.[LicenseNumber] [co_listing_agent_License_Number]
,CsA.[SellingAgentFullName] [co_Selling_agent_Name]
,CsA.[Email] [co_Selling_agent_email]
,CsA.[Phone] [co_Selling_agent_phone]
,CsA.[FirstName] [co_Selling_agent_FirstName]
,CsA.[LastName] [co_Selling_agent_LastName]
,CsA.[LicenseNumber] [co_Selling_agent_License_Number]
,SA.[SellingAgentFullName] [Selling_Agent_Name]
,SA.[Email] [Selling_Agent_email]
,SA.[Phone] [Selling_Agent_phone]
,SA.[FirstName] [Selling_Agent_FirstName]
,SA.[LastName] [Selling_Agent_LastName]
,SA.[LicenseNumber] [Selling_Agent_license_number]
,SA.[OfficeID] [Sell_Agent_Office_ID]
,SA.[OfficeName] [Sell_Agent_Office_Name]
,SA.[OfficePhone] [Sell_Agent_Office_Phone]
,LA.[ListAgentFullName] [List_Agent_Name]
,LA.[Email] [List_Agent_email]
,LA.[Email] [List_Agent_phone]
,LA.[FirstName] [List_Agent_FirstName]
,LA.[LastName] [List_Agent_LastName]
,LA.[LicenseNumber] [List_Agent_License_Number]
,LA.OfficeID [List_Agent_Office_ID]
,LA.OfficeName [List_Agent_Office_Name]
,LA.OfficePhone [List_Agent_Office_Phone]

FROM [src_Platlabs].[listing].[ListingsRaw] zz
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_A a ON zz.MLS_ID = a.MLSID and zz.MLS_LISTING_ID = a.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_B b ON zz.MLS_ID = b.MLSID and zz.MLS_LISTING_ID = b.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_C c ON zz.MLS_ID = c.MLSID and zz.MLS_LISTING_ID = c.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_D d ON zz.MLS_ID = d.MLSID and zz.MLS_LISTING_ID = d.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_E e ON zz.MLS_ID = e.MLSID and zz.MLS_LISTING_ID = e.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_F f ON zz.MLS_ID = f.MLSID and zz.MLS_LISTING_ID = f.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_G g ON zz.MLS_ID = g.MLSID and zz.MLS_LISTING_ID = g.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_H h ON zz.MLS_ID = h.MLSID and zz.MLS_LISTING_ID = h.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_I i ON zz.MLS_ID = i.MLSID and zz.MLS_LISTING_ID = i.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_J j ON zz.MLS_ID = j.MLSID and zz.MLS_LISTING_ID = j.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_K k ON zz.MLS_ID = k.MLSID and zz.MLS_LISTING_ID = k.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_L l ON zz.MLS_ID = l.MLSID and zz.MLS_LISTING_ID = l.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_M m ON zz.MLS_ID = m.MLSID and zz.MLS_LISTING_ID = m.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_N n ON zz.MLS_ID = n.MLSID and zz.MLS_LISTING_ID = n.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_O o ON zz.MLS_ID = o.MLSID and zz.MLS_LISTING_ID = o.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_P p ON zz.MLS_ID = p.MLSID and zz.MLS_LISTING_ID = p.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_Q q ON zz.MLS_ID = q.MLSID and zz.MLS_LISTING_ID = q.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_R r ON zz.MLS_ID = r.MLSID and zz.MLS_LISTING_ID = r.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_S s ON zz.MLS_ID = s.MLSID and zz.MLS_LISTING_ID = s.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_T t ON zz.MLS_ID = t.MLSID and zz.MLS_LISTING_ID = t.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_U u ON zz.MLS_ID = u.MLSID and zz.MLS_LISTING_ID = u.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_V v ON zz.MLS_ID = v.MLSID and zz.MLS_LISTING_ID = v.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_W w ON zz.MLS_ID = w.MLSID and zz.MLS_LISTING_ID = w.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_X x ON zz.MLS_ID = x.MLSID and zz.MLS_LISTING_ID = x.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_Y y ON zz.MLS_ID = y.MLSID and zz.MLS_LISTING_ID = y.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_z z ON zz.MLS_ID = z.MLSID and zz.MLS_LISTING_ID = z.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_aa aa ON zz.MLS_ID = aa.MLSID and zz.MLS_LISTING_ID = aa.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_ab ab ON zz.MLS_ID = ab.MLSID and zz.MLS_LISTING_ID = ab.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_ac ac ON zz.MLS_ID = ac.MLSID and zz.MLS_LISTING_ID = ac.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_ad ad ON zz.MLS_ID = ad.MLSID and zz.MLS_LISTING_ID = ad.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_ae ae ON zz.MLS_ID = ae.MLSID and zz.MLS_LISTING_ID = ae.MLS_LISTING_ID
	LEFT OUTER JOIN [src_Platlabs].dbo.Table_af af ON zz.MLS_ID = af.MLSID and zz.MLS_LISTING_ID = af.MLS_LISTING_ID
	LEFT OUTER JOIN [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData] NA on zz.mls_id = NA.mls_id and zz.mls_listing_id = NA.mls_listing_id
	LEFT OUTER JOIN [src_PlatLabs].[geodata].[RawGeoData] GD on zz.mls_id = GD.mls_id and zz.mls_listing_id = GD.mls_listing_id
	LEFT OUTER JOIN [src_PlatLabs].[agent].[CoSellingAgents] CsA on zz.mls_id = CsA.mls_id and zz.mls_listing_id = CsA.[mls_listing_id]
	LEFT OUTER JOIN [src_PlatLabs].[agent].[CoAgent_Batch] ClA on zz.mls_id = ClA.mls_id and zz.mls_listing_id = ClA.[mls_listing_id]
	LEFT OUTER JOIN (Select a.[uid],a.[mls_id],a.[mls_listing_id],a.[SellingAgentFullName],a.[FirstName],a.[LastName],a.[Email],a.[Phone],a.[LicenseNumber],a.[LoadDate],SellAgent_Array.id OfficeID,SellAgent_Array.name OfficeName,SellAgent_Array.Phone OfficePhone
					 from [src_PlatLabs].[agent].[SellingAgents] a
CROSS APPLY OPENJSON([office]) WITH(
		id varchar(500)
		  ,uid varchar(20)
		  ,name varchar(100)
		  ,phone varchar(20)
		 ) as SellAgent_Array) SA on zz.mls_id = SA.mls_id and zz.mls_listing_id = SA.[mls_listing_id]
	LEFT OUTER JOIN (Select a.[uid],a.[mls_id],a.[mls_listing_id],a.[ListAgentFullName],a.[FirstName],a.[LastName],a.[Email],a.[Phone],a.[LicenseNumber],a.[LoadDate],ListAgent_Array.id OfficeID,ListAgent_Array.name OfficeName,ListAgent_Array.Phone OfficePhone
					 from [src_PlatLabs].[agent].[ListAgents] a
CROSS APPLY OPENJSON([office]) WITH(
		id varchar(500)
		  ,uid varchar(20)
		  ,name varchar(100)
		  ,phone varchar(20)
		 ) as ListAgent_Array) LA on zz.mls_id = LA.mls_id and zz.mls_listing_id = LA.[mls_listing_id]
WHERE zz.mls_id IN (Select mls_id from [src_Platlabs].[listing].[ListingsRaw] WITH(NOLOCK))
	AND zz.mls_id BETWEEN @StartID AND @EndID
	--AND zz.LoadDate > (Select MAX(LoadDate) from [src_Platlabs].[listing].[ListingFull])
	
	SET @StartID = @EndID + 1
	
END
	
declare @note_end_time datetime = getdate()
declare @listingCount int
set @listingCount = (select count(*) from [xVJ].dbo.[temp_listingFull_WORKING_v3] with(nolock))
insert into [xVJ].dbo.[temp_track_proc] values ('test_usp_800_2', @note_start_time, @note_end_time, getdate(), @listingCount)

update [xVJ].dbo.[temp_listingFull_WORKING_v3]
SET has_Pool = 'true'
where has_pool is null and pool_description is not null and pool_description not like 'None'

update [xVJ].dbo.[temp_listingFull_WORKING_v3]
SET has_basement = 'true'
where has_basement is null and basement_description is not null and basement_description not like 'None'

update [xVJ].dbo.[temp_listingFull_WORKING_v3]
SET has_fireplace = 'true'
where has_fireplace is null and fireplace_description is not null and fireplace_description not like 'None'

update [xVJ].dbo.[temp_listingFull_WORKING_v3]
SET has_garage = 'true'
where has_garage is null and (parking_description like 'Garage %' or parking_description like '%, Garage%')


UPDATE a
SET a.List_Agent_email = b.email
,a.List_Agent_FirstName = b.firstname
,a.List_Agent_LastName = b.lastname
,a.List_Agent_License_Number = b.licensenumber
,a.List_Agent_Name = b.ListAgentFullName
,a.List_Agent_Office_ID = b.office
,a.List_Agent_phone = b.Phone
FROM [xVJ].dbo.[temp_listingFull_WORKING_v3] a JOIN [src_Platlabs].[agent].[ListAgents] b
on a.mls_id = b.mls_id
and a.mls_listing_id = b.mls_listing_id
where List_Agent_Name is NULL

update a
SET a.[status] = b.[Status]
,a.[modified_date] = CASE WHEN a.[modified_date] < CAST(GETDATE() as date) THEN GETDATE() ELSE a.[modified_date] END
from [xVJ].dbo.[temp_listingFull_WORKING_v3] a with(NOLOCK) JOIN [Global].dbo.lkup_StdStatus b with(NOLOCK)
on a.MLS_Status = b.MLS_Status
WHERE a.[Status] != b.[Status]

*/
*/
END
