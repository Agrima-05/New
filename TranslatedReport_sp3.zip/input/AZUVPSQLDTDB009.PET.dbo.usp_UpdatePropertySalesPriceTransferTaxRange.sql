/* Source: DWS-ETL02.DATATREE.LOCAL | PET | dbo.usp_UpdatePropertySalesPriceTransferTaxRange | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =================================================================================================
-- Author:		Henk de Weerdt
-- Create date: 3/15/2023
-- Description:	This stored procedure updates the table PropertySalesPriceTransferTaxRange from Bill Rice's
--				Holocron table.
--				This SP is scheduled to run every Saturday morning to refresh the PET data.
--
-- Input:		Fips_code optional. If fips_code provided, then only that county will be updated.
--				If zero, then all counties that are available will be updated.
--
-- Returns:		Nothing for now. :-)
-- =================================================================================================
CREATE    PROCEDURE [PET].[dbo].[usp_UpdatePropertySalesPriceTransferTaxRange]
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
+-------+-----------+----------------------------------------------------------------------------------------------
henk	03/15/2023	Initial version
henk	02/21/2024	Changed the source from Bill Rice's server using tables Data & Holocron
					The SSIS package will retrieve the data and store in the tmp table
					This SP will do all of the counties. Removed single fips option
henk	02/27/2024	Add update on TransferTaxMin < 1.0
henk	04/16/2024	Change tax rate from UR_TaxRates to the TaxRate_County table
					Implement WA state tax rules and add city tax for CARV
henk	06/20/2024	Changed the default tax to 1.1 / 1000
henk	06/21/2024	Add Hawaii
henk	06/27/2024	Add range adjustment (0.25 on min and 1.75 on max)
henk	06/28/2024	Fix typo on SalesPriceMin
henk	06/26/2025	Add San Fransisco CA
******************************************************************************************************************/
BEGIN
	SET NOCOUNT ON;

	--/******************************************************************************************************************
	--	Setup tax rates
	--******************************************************************************************************************/
	DROP TABLE

	IF EXISTS #temp
		SELECT *
			,ROW_NUMBER() OVER (
				PARTITION BY FIPS ORDER BY FIPS
					,Date_from DESC
				) AS ROW4
		INTO #temp
		FROM [PET].[dbo].[TaxRate_county]
		WHERE taxrate IS NOT NULL

		CREATE UNIQUE INDEX IDX ON #temp(fips,ROW4)

	/******************************************************************************************************************
		Insert latest Sales price into tmp partitions for unique Fips_code and RefId (All counties)
	******************************************************************************************************************/
	DECLARE @partition_list VARCHAR(max)

	SELECT @partition_list = STUFF((
				SELECT CONCAT (
						','
						,$PARTITION.PET_Partition_FipsPF(Fips_code)
						)
				FROM (
					SELECT DISTINCT Fips_code
					FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange](NOLOCK)
					) a
				FOR XML PATH('')
				), 1, 1, '')

	SELECT @partition_list AS '@partition_list'

	IF @partition_list IS NULL
	BEGIN
		SELECT 'Temp table is empty... Exiting procedure'

		RETURN
	END

	/******************************************************************************************************************
		Update tax rates based on the new sales price
	******************************************************************************************************************/
	BEGIN TRY
		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = SalesPriceMin * TaxRate / 1000.0
			,TransferTaxMax = SalesPriceMax * TaxRate / 1000.0
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		INNER JOIN #temp t with(nolock,index(IDX)) ON t.fips = pst.Fips_code
			AND ROW4 = 1

		-- Washington State
		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = CASE 
				WHEN SalesPriceMin > 3000000.00
					THEN 59550.0 + SalesPriceMin * 0.03 -- 3%
				WHEN SalesPriceMin > 1500000.00
					THEN 18300.0 + SalesPriceMin * 0.0275 -- 2.75%
				WHEN SalesPriceMin > 500000.00
					THEN 5500.0 + SalesPriceMin * 0.0128 -- 1.28%
				ELSE SalesPriceMin * 0.011 -- 1.1%
				END
			,TransferTaxMax = CASE 
				WHEN SalesPriceMax > 3000000.00
					THEN 59550.0 + SalesPriceMax * 0.03 -- 3%
				WHEN SalesPriceMax > 1500000.00
					THEN 18300.0 + SalesPriceMax * 0.0275 -- 2.75%
				WHEN SalesPriceMax > 500000.00
					THEN 5500.0 + SalesPriceMax * 0.0128 -- 1.28%
				ELSE SalesPriceMax * 0.011 -- 1.1%
				END
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		WHERE pst.Fips_code BETWEEN 53000
				AND 54000

		-- Riverside City
		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = SalesPriceMin * 2.2 /1000.0
			,TransferTaxMax = SalesPriceMax * 2.2 /1000.0
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		JOIN [PET].[dbo].[PET] p ON p.FIPS = 6065
			AND p.City = 'Riverside'
		WHERE pst.Fips_code = 6065

		--San Fransisco CA
		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = CASE         
				WHEN SalesPriceMin <= 250000.00
					THEN SalesPriceMin / 500 * 2.50        
				WHEN SalesPriceMin <= 1000000.00           
					THEN SalesPriceMin / 500 * 3.40         
				WHEN SalesPriceMin <= 5000000.00
					THEN SalesPriceMin / 500 * 3.75
				WHEN SalesPriceMin <= 10000000.00
					THEN SalesPriceMin / 500 * 11.25
				WHEN SalesPriceMin <= 25000000.00
					THEN SalesPriceMin / 500 * 27.50
				ELSE SalesPriceMin / 500 * 30.00         
				END
			,TransferTaxMax = CASE         
				WHEN SalesPriceMin <= 250000.00
					THEN SalesPriceMin / 500 * 2.50        
				WHEN SalesPriceMin <= 1000000.00           
					THEN SalesPriceMin / 500 * 3.40         
				WHEN SalesPriceMin <= 5000000.00
					THEN SalesPriceMin / 500 * 3.75
				WHEN SalesPriceMin <= 10000000.00
					THEN SalesPriceMin / 500 * 11.25
				WHEN SalesPriceMin <= 25000000.00
					THEN SalesPriceMin / 500 * 27.50
				ELSE SalesPriceMin / 500 * 30.00         

				END
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		WHERE pst.Fips_code = 6075

		--Hawaii FIPS 15000 through 16000
		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = CASE         
				WHEN SalesPriceMin >= 10000000.00           
					THEN SalesPriceMin / 100 * 1.25         
				WHEN SalesPriceMin >= 6000000.00           
					THEN SalesPriceMin / 100 * 1.10         
				WHEN SalesPriceMin >= 4000000.00
					THEN SalesPriceMin / 100 * 0.85
				WHEN SalesPriceMin >= 2000000.00
					THEN SalesPriceMin / 100 * 0.60
				WHEN SalesPriceMin >= 1000000
					THEN SalesPriceMin / 100 * 0.40
				WHEN SalesPriceMin >= 600000.00
					THEN SalesPriceMin / 100 * .25
				ELSE SalesPriceMin / 100 * 0.15         
				END
			,TransferTaxMax = CASE         
				WHEN SalesPriceMax >= 10000000.00           
					THEN SalesPriceMax / 100 * 1.25         
				WHEN SalesPriceMax >= 6000000.00           
					THEN SalesPriceMax / 100 * 1.10         
				WHEN SalesPriceMax >= 4000000.00
					THEN SalesPriceMax / 100 * 0.85
				WHEN SalesPriceMax >= 2000000.00
					THEN SalesPriceMax / 100 * 0.60
				WHEN SalesPriceMax >= 1000000
					THEN SalesPriceMax / 100 * 0.40
				WHEN SalesPriceMax >= 600000.00
					THEN SalesPriceMax / 100 * .25
				ELSE SalesPriceMax / 100 * 0.15         
				END
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		WHERE pst.Fips_code BETWEEN 15000
				AND 16000

		UPDATE [PET].[dbo].[pst]
		SET TransferTaxMin = SalesPriceMin * 1.1/1000.0
			,TransferTaxMax = SalesPriceMax * 1.1/1000.0
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst
		WHERE isnull(TransferTaxMin, 0.0) < 1.0

		/******************************************************************************************************************
			Adjust range (0.25 on min and 1.75 on max)
		******************************************************************************************************************/
		UPDATE [PET].[dbo].[pst]
			SET SalesPriceMin = SalesPriceMin * 0.25
			,SalesPriceMax = SalesPriceMax * 1.75
			,TransferTaxMin = TransferTaxMin * 0.25
			,TransferTaxMax = TransferTaxMax * 1.75
		FROM [PET].[tmp].[PropertySalesPriceTransferTaxRange] pst

		/******************************************************************************************************************
			Switch all partitions from tmp to dbo for use by Calico SP
		******************************************************************************************************************/
		DECLARE @sqlCmd VARCHAR(MAX) = ''

		SELECT @sqlCmd = @sqlCmd + 'TRUNCATE TABLE dbo.PropertySalesPriceTransferTaxRange WITH (PARTITIONS(' + value + '));
		ALTER TABLE tmp.PropertySalesPriceTransferTaxRange SWITCH PARTITION ' + value + ' TO dbo.PropertySalesPriceTransferTaxRange PARTITION ' + value + '; '
		FROM [PET].[dbo].[string_split](@partition_list, ',')

		SELECT @sqlCmd

		EXEC (@sqlCmd)
	END TRY

	BEGIN CATCH
		PRINT 'In catch block.';

		THROW;
	END CATCH
END



