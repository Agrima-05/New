/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | LEAP.usp_Recapture_Rejects | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Lien].[LEAP].[usp_Recapture_Rejects] 
AS
SET NOCOUNT ON

BEGIN

--declare @Leap_id INT = 253994

	/*IF object_id('Tempdb..#Leap_id') IS NOT NULL
		*/
DROP TABLE IF EXISTS #Leap_id;

	SELECT DISTINCT Leap_id
	INTO #leap_id
	FROM [Lien].[LEAP].[LEAP_RejectRecords]
	WHERE UpdateTimestamp IS NOT NULL

	CREATE INDEX ix_leap_id ON #leap_id (Leap_id)

	--
	-- One Leap_id can have more than one Reject record
	--
	/*IF object_id('Tempdb..#id') IS NOT NULL
		*/
DROP TABLE IF EXISTS #id;

	SELECT k.id
	INTO #id
	FROM [lien].[leap].[leap_key_ids] k
	INNER JOIN #leap_id l ON l.leap_id = k.leap_id

	CREATE INDEX ix_id ON #id (id)

	BEGIN TRANSACTION

	DELETE s
	FROM [lien].[leap].[leap_new] s
	INNER JOIN #leap_id i ON i.leap_id = s.leap_id

	DELETE s
	FROM [lien].[LEAP].[Leap_New_Parties] s
	INNER JOIN #leap_id i ON i.leap_id = s.leap_id

	DELETE s
	FROM [lien].[LEAP].[Leap_New_Property] s
	INNER JOIN #leap_id i ON i.leap_id = s.leap_id

	DELETE s
	FROM [lien].[LEAP].[Leap_New_Reference] s
	INNER JOIN #leap_id i ON i.leap_id = s.leap_id

	DELETE s
	FROM [lien].[LEAP].[LEAP_KEY_IDS] s
	INNER JOIN #id i ON i.id = s.id

	DELETE s
	FROM [lien].[LEAP].[LEAP_KEYS] s
	INNER JOIN #leap_id i ON i.leap_id = s.Leap_id

	DELETE s
	FROM [lien].[leap].[leap] s
	INNER JOIN #id i ON i.id = s.id

	INSERT INTO [Lien].[LEAP].[LEAP] (
		[State]
		,[County]
		,[Fips]
		,[Vendor_Code]
		,[Recording_Doc_Nbr]
		,[Recording_Book_Nbr]
		,[Recording_Page_Nbr]
		,[Recording_Date]
		,[Document_Type]
		,[Document_Code]
		,[Correction_Indicator]
		,[Lien_Issuing_Agency]
		,[Federal_Tax_Lien_Area]
		,[Tax_Lien_Serial_Nbr]
		,[Party1_FirstName]
		,[Party1_MiddleName]
		,[Party1_LastName]
		,[Party1_NameSuffix]
		,[Party1_Alias_Name_Type]
		,[Party1_Mail_Street_Addr]
		,[Party1_Mail_City]
		,[Party1_Mail_State]
		,[Party1_Mail_Zip_Code]
		,[Party1_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party1_Account_Nbr]
		,[Party1_SSN_Nbr]
		,[Party1_Driver_License_Nbr]
		,[Party1_Driver_License_State]
		,[Additional_Judgement_Debtors]
		,[Kind_Of_Tax]
		,[Tax_Period_Minimum]
		,[Tax_Period_Maximum]
		,[Last_Day_For_Refiling]
		,[Total_Lien_Estimated_Amount]
		,[Federal_Tax_Lien_Prepared_Signed_City_Name]
		,[Federal_Tax_Lien_Prepared_Signed_State_Code]
		,[Federal_Tax_Lien_Energy_Doc_Date]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Doc_Page]
		,[Reference_Energy_Recording_Date]
		,[Court_Case_Number]
		,[Party2_First_Name]
		,[Party2_Middle_Name]
		,[Party2_Last_Name]
		,[Party2_Name_Suffix]
		,[Party2_Mailing_Street]
		,[Party2_Mailing_City]
		,[Party2_Mailing_State]
		,[Party2_Mailing_Zip]
		,[Party2_Mailing_ZipPlus4]
		,[Party2_SSN_Number]
		,[Party3_First_Name]
		,[Party3_Middle_Name]
		,[Party3_Last_Name]
		,[Party3_Name_Suffix]
		,[Divorce_Decree_Filing_Date]
		,[Property_Address]
		,[Property_City]
		,[Property_State]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[Respondent_SSN_Number]
		,[Attorney_Name]
		,[Attorney_Phone_Number]
		,[Attorney_Flag]
		,[Judgment_Creditor]
		,[Assignee_Of_Record]
		,[Abstract_Issued_Date]
		,[Creditor_Name]
		,[Producer_Email_Address]
		,[Solar_Energy_TermExpire_Date]
		,[Solar_Energy_Type_Of_Agreement]
		,[Installment_Judgment]
		,[Stay_Ordered]
		,[Stay_Ordered_Date]
		,[Interest_Rate]
		,[Back_Support_Amount]
		,[Apn]
		,[Apn_Portion_Indicator]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Apn_Research_Indicator]
		,[Lot]
		,[Block]
		,[Tract_Name]
		,[Parcel]
		,[Parcel_Map_Book]
		,[Parcel_Map_Page]
		,[Section]
		,[Township]
		,[Range]
		,[Unit_Number]
		,[Municipality_Code]
		,[District_Number]
		,[District_Suffix_Number]
		,[Land_Lot]
		,[Party_1A_First_Name]
		,[Party_1A_Middle_Name_or_Initial]
		,[Party_1A_Last_Name]
		,[Party_1A_Name_Suffix]
		,[Party_1B_First_Name]
		,[Party_1B_Middle_Name_or_Initial]
		,[Party_1B_Last_Name]
		,[Party_1B_Name_Suffix]
		,[Party_1C_First_Name]
		,[Party_1C_Middle_Name_or_Initial]
		,[Party_1C_Last_Name]
		,[Party_1C_Name_Suffix]
		,[Party1_ETAL_Indicator]
		,[Created_Date]
		,[Party1_Company_Name]
		,[Party2_Company_Name]
		,[Party3_Company_Name]
		,[Party1A_Company_Name]
		,[Party1B_Company_Name]
		,[Party1C_Company_Name]
		,[Party1A_Alias_Name_Type]
		,[Party1B_Alias_Name_Type]
		,[Party1C_Alias_Name_Type]
		)
	SELECT [State]
		,[County]
		,[Fips]
		,[Vendor_Code]
		,[Recording_Doc_Nbr]
		,[Recording_Book_Nbr]
		,[Recording_Page_Nbr]
		,[Recording_Date]
		,[Document_Type]
		,[Document_Code]
		,[Correction_Indicator]
		,[Lien_Issuing_Agency]
		,[Federal_Tax_Lien_Area]
		,[Tax_Lien_Serial_Nbr]
		,[Party1_FirstName]
		,[Party1_MiddleName]
		,[Party1_LastName]
		,[Party1_NameSuffix]
		,[Party1_Alias_Name_Type]
		,[Party1_Mail_Street_Addr]
		,[Party1_Mail_City]
		,[Party1_Mail_State]
		,[Party1_Mail_Zip_Code]
		,[Party1_Mail_Zip_Plus4]
		,[Foreign_Addr_Part1]
		,[Foreign_Addr_Part2]
		,[Foreign_Addr_Part3]
		,[Party1_Account_Nbr]
		,[Party1_SSN_Nbr]
		,[Party1_Driver_License_Nbr]
		,[Party1_Driver_License_State]
		,[Additional_Judgement_Debtors]
		,[Kind_Of_Tax]
		,[Tax_Period_Minimum]
		,[Tax_Period_Maximum]
		,[Last_Day_For_Refiling]
		,[Total_Lien_Estimated_Amount]
		,[Federal_Tax_Lien_Prepared_Signed_City_Name]
		,[Federal_Tax_Lien_Prepared_Signed_State_Code]
		,[Federal_Tax_Lien_Energy_Doc_Date]
		,[Reference_Energy_Doc_Number]
		,[Reference_Energy_Doc_Book]
		,[Reference_Energy_Doc_Page]
		,[Reference_Energy_Recording_Date]
		,[Court_Case_Number]
		,[Party2_First_Name]
		,[Party2_Middle_Name]
		,[Party2_Last_Name]
		,[Party2_Name_Suffix]
		,[Party2_Mailing_Street]
		,[Party2_Mailing_City]
		,[Party2_Mailing_State]
		,[Party2_Mailing_Zip]
		,[Party2_Mailing_ZipPlus4]
		,[Party2_SSN_Number]
		,[Party3_First_Name]
		,[Party3_Middle_Name]
		,[Party3_Last_Name]
		,[Party3_Name_Suffix]
		,[Divorce_Decree_Filing_Date]
		,[Property_Address]
		,[Property_City]
		,[Property_State]
		,[Property_Zip_Code]
		,[Property_Zip_Plus4]
		,[Respondent_SSN_Number]
		,[Attorney_Name]
		,[Attorney_Phone_Number]
		,[Attorney_Flag]
		,[Judgment_Creditor]
		,[Assignee_Of_Record]
		,[Abstract_Issued_Date]
		,[Creditor_Name]
		,[Producer_Email_Address]
		,[Solar_Energy_TermExpire_Date]
		,[Solar_Energy_Type_Of_Agreement]
		,[Installment_Judgment]
		,[Stay_Ordered]
		,[Stay_Ordered_Date]
		,[Interest_Rate]
		,[Back_Support_Amount]
		,[Apn]
		,[Apn_Portion_Indicator]
		,[Multiple_Record_Indicator1]
		,[Multiple_Record_Indicator2]
		,[Apn_Research_Indicator]
		,[Lot]
		,[Block]
		,[Tract_Name]
		,[Parcel]
		,[Parcel_Map_Book]
		,[Parcel_Map_Page]
		,[Section]
		,[Township]
		,[Range]
		,[Unit_Number]
		,[Municipality_Code]
		,[District_Number]
		,[District_Suffix_Number]
		,[Land_Lot]
		,[Party_1A_First_Name]
		,[Party_1A_Middle_Name_or_Initial]
		,[Party_1A_Last_Name]
		,[Party_1A_Name_Suffix]
		,[Party_1B_First_Name]
		,[Party_1B_Middle_Name_or_Initial]
		,[Party_1B_Last_Name]
		,[Party_1B_Name_Suffix]
		,[Party_1C_First_Name]
		,[Party_1C_Middle_Name_or_Initial]
		,[Party_1C_Last_Name]
		,[Party_1C_Name_Suffix]
		,[Party1_ETAL_Indicator]
		,getdate() AS [Created_Date]
		,[Party1_Company_Name]
		,[Party2_Company_Name]
		,[Party3_Company_Name]
		,[Party1A_Company_Name]
		,[Party1B_Company_Name]
		,[Party1C_Company_Name]
		,[Party1A_Alias_Name_Type]
		,[Party1B_Alias_Name_Type]
		,[Party1C_Alias_Name_Type]
	FROM [lien].[LEAP].[LEAP_RejectRecords] s
	INNER JOIN #id i ON i.id = s.id

	DELETE s
	FROM [lien].[LEAP].[LEAP_RejectRecords] s
	INNER JOIN #id i ON i.id = s.id

	DELETE s
	FROM [lien].[LEAP].[LEAP_REJECTS] s
	INNER JOIN #id i ON i.id = s.id

	COMMIT
END

