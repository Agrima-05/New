SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_501_CAPTURE_BILLING_COUNTS] 
	
AS
BEGIN

	SET NOCOUNT ON;


	 -----------------BILLING COUNTS-------------

	Insert into [zCust_OS_National].[dbo].[INPUT_MONITOR_BILLING](
	[INPUTKEY],	[CustomerID] ,	[UniqueID] ,	[ADDRESS] ,	[CITY] ,	[STATE] ,	[ZIPCODE] ,	[DATE_RECEIVED] ,	[PROPERTYID]  )
	Select [INPUTKEY],	[CustomerID] ,	[UniqueID] ,	[ADDRESS] ,	[CITY] ,	[STATE] ,	[ZIPCODE] ,	[DATE_RECEIVED] ,	[PROPERTYID] 
	From [zCust_OS_National].[dbo].[INPUT_MONITOR] 
	where PropertyID is not null and propertyID not like '' and propertyID not like '0'



END


