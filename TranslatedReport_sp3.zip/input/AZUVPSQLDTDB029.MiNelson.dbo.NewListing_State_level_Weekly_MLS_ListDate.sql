/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.NewListing_State_level_Weekly_MLS_ListDate | type=P */


-- ===============================================================================================
-- Author:		My Phan
-- Create date: 4/20/2020
-- Description:	Create New Listing Trends for weekly by state level
-- ================================================================================================
CREATE PROCEDURE [MiNelson].[dbo].[NewListing_State_level_Weekly_MLS_ListDate]
AS
SET NOCOUNT ON

BEGIN



--select * from  Minelson.dbo.Listing_trends_State_Platlabs_Active


DROP TABLE if exists #listingDeleted
			SELECT DISTINCT listing_id
			into #listingDeleted
			FROM [fa_listing].[dbo].[ListingRow] WITH (NOLOCK	,INDEX (idx_listing_deleted))
			WHERE listing_deleted = 1

		



	/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_Finance') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_Finance]

	SELECT c.*
		,coalesce(Active_yearMonth_New, Active_yearMonth, Pending_yearMonth, Contingent_yearMonth, Sold_yearMonth, Fail_yearMonth) AS sort_month
	INTO [Minelson].[dbo].[ListingTrends_raw_Finance]
	FROM (
		SELECT DISTINCT b.new
			,Active_yearMonth_New
			,Active_yearMonth
			,Pending_yearMonth
			,Sold_yearMonth
			,Fail_yearMonth
			,Contingent_yearMonth
			,Listing_ID
			,Fips
			,MLS_Listing_Number
			,Ref_id
			,MLS_STATUS_STD
			,MLS_LIST_PRICE_STD
			,MLS_LIST_DATE_STD
			,Home_Size_STD
			,Price_Per_SQFT_STD
			,AddrId
			,UpdateSeq
		FROM (
			SELECT CASE 
					WHEN UpdateSeq = 1
						THEN 'Yes'
					ELSE NULL
					END new
				,CASE 
					WHEN MLS_STATUS_STD = 'Active'
						AND UpdateSeq = 1
						THEN MLS_List_Date_STD
					ELSE NULL
					END AS Active_yearMonth_New
				,CASE 
					WHEN MLS_STATUS_STD = 'Active'
						THEN convert(DATE, [UpdateTimestamp])
					ELSE NULL
					END AS Active_yearMonth
				,CASE 
					WHEN MLS_STATUS_STD = 'Pending'
						THEN convert(DATE, [UpdateTimestamp])
					ELSE NULL
					END AS Pending_yearMonth
				,CASE 
					WHEN MLS_STATUS_STD = 'Sold'
						THEN SOLD_DATE_STD
					ELSE NULL
					END AS Sold_yearMonth
				,CASE 
					WHEN MLS_STATUS_STD = 'Fail'
						THEN convert(DATE, [UpdateTimestamp])
					ELSE NULL
					END AS Fail_yearMonth
				,CASE 
					WHEN MLS_STATUS_STD = 'Contingent'
						THEN convert(DATE, [UpdateTimestamp])
					ELSE NULL
					END AS Contingent_yearMonth
				,a.*
			FROM (
				SELECT *
				FROM [FA_Listing].[dbo].[vListingHistory] h with (Nolock)
				WHERE Listing_ID IN
					(
						SELECT DISTINCT Listing_ID
						FROM [FA_Listing].[dbo].[Listing] l with (Nolock)
						WHERE l.MLS_List_Date_STD >= '2019-08-01' --and fips = 06059
							AND l.listing_id not in (select Listing_id from #listingDeleted)
						)
				) a
			) b
		) c
	ORDER BY Listing_id
		,coalesce(Active_yearMonth_New, Active_yearMonth, Pending_yearMonth, Contingent_yearMonth, Sold_yearMonth, Fail_yearMonth)

	--select * from Minelson.dbo.ListingTrends_raw_temp1
	--- updating fips from address table 

	--create index idx_AddrId on Minelson.dbo.ListingTrends_raw_Finance (AddrId) include (fips)
	create  index idx_fips on [Minelson].[dbo].[ListingTrends_raw_Finance] (fips) include (AddrId)

	UPDATE [MiNelson].[dbo].[a]
	SET a.Fips = b.fips
	FROM [Minelson].[dbo].[ListingTrends_raw_Finance] a with(nolock,index(idx_fips))
	LEFT JOIN [FA_Listing].[dbo].[FA_MLS_Raw_Std_Address] b with(nolock,index(PK_IDX_FAMLS_Rowid_address)) ON a.AddrId = b.row_id
	WHERE a.fips IS NULL
		AND b.row_id IS NOT NULL
		AND b.fips <> 0
	OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

	--select *  from  Minelson.dbo.ListingTrends_raw_Finance 
	--- running time 2:03 minutes
	/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_F') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_F]

	SELECT *
		,(
			CASE 
				WHEN pending_yearmonth IS NOT NULL
					THEN row_number() OVER (
							PARTITION BY (
								CASE 
									WHEN pending_yearmonth IS NOT NULL
										THEN listing_id
									ELSE NULL
									END
								) ORDER BY pending_yearmonth DESC
							)
				END
			) AS [rn_Pending]
		,(
			CASE 
				WHEN Contingent_yearmonth IS NOT NULL
					THEN row_number() OVER (
							PARTITION BY (
								CASE 
									WHEN Contingent_yearmonth IS NOT NULL
										THEN listing_id
									ELSE NULL
									END
								) ORDER BY Contingent_yearmonth DESC
							)
				END
			) AS [rn_Contingent]
		,(
			CASE 
				WHEN sold_yearMonth IS NOT NULL
					THEN row_number() OVER (
							PARTITION BY (
								CASE 
									WHEN sold_yearMonth IS NOT NULL
										THEN listing_id
									ELSE NULL
									END
								) ORDER BY sold_yearMonth DESC
							)
				END
			) AS [rn_Sold]
		,(
			CASE 
				WHEN Fail_yearMonth IS NOT NULL
					THEN row_number() OVER (
							PARTITION BY (
								CASE 
									WHEN fail_yearmonth IS NOT NULL
										THEN listing_id
									ELSE NULL
									END
								) ORDER BY Fail_yearMonth
							)
				END
			) AS [rn_Fail]
	INTO [Minelson].[dbo].[ListingTrends_raw_F]
	FROM [Minelson].[dbo].[ListingTrends_raw_Finance] with (Nolock)
	ORDER BY listing_id

	create index idx_listing_id on [Minelson].[dbo].[ListingTrends_raw_F] (Listing_id)
	--create index idx_rn_pending on Minelson.dbo.ListingTrends_raw_F (rn_pending)
	--create index idx_rn_sold on Minelson.dbo.ListingTrends_raw_F (rn_sold)
	--create index idx_rn_Fail on Minelson.dbo.ListingTrends_raw_F (rn_Fail)
	--create index idx_rn_Contingent on Minelson.dbo.ListingTrends_raw_F (rn_Contingent)
	UPDATE [MiNelson].[dbo].[a]
	SET a.Pending_yearMonth = NULL
	FROM [Minelson].[dbo].[ListingTrends_raw_F] a
	WHERE rn_pending > 1
	OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));
	UPDATE [MiNelson].[dbo].[a]
	SET a.sold_yearMonth = NULL
	FROM [Minelson].[dbo].[ListingTrends_raw_F] a
	WHERE rn_sold > 1
	OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));
	UPDATE [MiNelson].[dbo].[a]
	SET a.Fail_yearMonth = NULL
	FROM [Minelson].[dbo].[ListingTrends_raw_F] a
	WHERE rn_Fail > 1
	OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));
	UPDATE [MiNelson].[dbo].[a]
	SET a.Contingent_yearMonth = NULL
	FROM [Minelson].[dbo].[ListingTrends_raw_F] a
	WHERE rn_Contingent > 1
	OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

	DELETE
	--select *
	FROM [Minelson].[dbo].[ListingTrends_raw_F]
	WHERE new IS NULL
		AND Active_yearMonth IS NULL
		AND Active_yearMonth_new IS NULL
		AND Pending_yearMonth IS NULL
		AND Sold_yearMonth IS NULL
		AND Fail_yearMonth IS NULL
		AND Contingent_yearMonth IS NULL
	--OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

	-------4/21/2022 adding logic to filter duplicates active listing
	----- remove non residential records (all status)
	/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_F_landuse') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_F_landuse]

	SELECT a.*
		,CASE 
			WHEN b.land_use IN (
					'100'
					,'102'
					,'109'
					,'111'
					,'112'
					,'115'
					,'116'
					,'117'
					,'135'
					,'137'
					,'138'
					,'148'
					,'151'
					,'160'
					,'163'
					,'165'
					,'199'
					)
				THEN 'Residential'
			ELSE 'Other'
			END AS landuse
	INTO [Minelson].[dbo].[ListingTrends_raw_F_landuse]
	FROM [Minelson].[dbo].[ListingTrends_raw_F] a
	LEFT JOIN [Fa_listing].[dbo].[listing] b with(nolock,index(PK__Listing__A91E6F4D32656725)) ON a.listing_id = b.listing_id


	create index idx_ref_id on [Minelson].[dbo].[ListingTrends_raw_F_landuse] (ref_id)
	----33 mil
	DELETE
	---select count (*)
	FROM [Minelson].[dbo].[ListingTrends_raw_F_landuse]
	WHERE landuse LIKE 'other' -- and new is null

	--- remove duplicates 1 active listing per ref_id per month
	/*IF OBJECT_ID('Minelson.dbo.ListingTrends_raw_F_Refid') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_F_Refid]

	SELECT *
	INTO [Minelson].[dbo].[ListingTrends_raw_F_Refid]
	FROM (
		SELECT --row_number() over(partition by Ref_id, fips, sort_month, new, active_yearMonth_new, Active_yearMonth, Pending_yearMonth, Fail_YearMonth, Contingent_YearMonth order by listing_id desc) as rn, 
			--case when (MLS_STATUS_STD = 'active' and new is null) then  row_number() over(partition by Ref_id, fips, MLS_STATUS_STD, left(MLS_LIST_Date_STD,7), new order by listing_id desc) else 1 end as rn,
			row_number() OVER (
				PARTITION BY Ref_id
				,fips
				,MLS_STATUS_STD
				,left(sort_month, 7)
				,new ORDER BY listing_id DESC
				) AS rn
			,*
		FROM [Minelson].[dbo].[ListingTrends_raw_F_landuse] with(nolock,index(idx_ref_id))
		WHERE ref_id IS NOT NULL --and MLS_STATUS_STD = 'active'
		) x
	WHERE rn = 1

	--delete 
	---- select count(*)
	----select *
	--from  Minelson.dbo.ListingTrends_raw_F_Refid
	--where rn > 1 and new is null 
	DELETE
	--- select count (*)
	FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid]
	WHERE MLS_STATUS_STD = 'active'
		AND MLS_LIST_PRICE_STD < 10000

	--and new is not null
	DELETE k
	--select *
	FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] k
	INNER JOIN [FA_Listing].[dbo].[ListingDelete] d ON d.Listing_ID = k.Listing_ID

	--- running time 54 minutes
	CREATE INDEX ix_Listing_id ON [Minelson].[dbo].[ListingTrends_raw_F_Refid] (Listing_id)

	/*IF object_id('Minelson.dbo.ListingTrends_raw_2_F') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ListingTrends_raw_2_F];

	SELECT r.*
		,r2.*
		,r3.*
		,r4.*
		,r5.*
	INTO [Minelson].[dbo].[ListingTrends_raw_2_F]
	FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] r with (Nolock)
	OUTER APPLY (
		SELECT TOP 1 Sold_yearMonth AS SoldMonth
		FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] r2 with (Nolock)
		WHERE r2.Listing_ID = r.Listing_ID
			AND Sold_yearMonth IS NOT NULL
		ORDER BY Sold_yearMonth
		) r2
	OUTER APPLY (
		SELECT TOP 1 Fail_yearMonth AS FailMonth
		FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] r2 with (Nolock)
		WHERE r2.Listing_ID = r.Listing_ID
			AND fail_yearMonth IS NOT NULL
		ORDER BY fail_yearMonth
		) r3
	OUTER APPLY (
		SELECT TOP 1 Pending_yearMonth AS PendingMonth
		FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] r2 with (Nolock)
		WHERE r2.Listing_ID = r.Listing_ID
			AND Pending_yearMonth IS NOT NULL
		ORDER BY pending_yearMonth
		) r4
	OUTER APPLY (
		SELECT TOP 1 Contingent_yearMonth AS ContingentMonth
		FROM [Minelson].[dbo].[ListingTrends_raw_F_Refid] r2 with (Nolock)
		WHERE r2.Listing_ID = r.Listing_ID
			AND Contingent_yearMonth IS NOT NULL
		ORDER BY Contingent_yearMonth
		) r5

	/*IF OBJECT_ID('Minelson.dbo.Calendar_Listing_f') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[Calendar_Listing_f]

	SELECT DISTINCT FirstDateOfWeek
	INTO [Minelson].[dbo].[Calendar_Listing_f]
	FROM [VerifiedRecord].[dbo].[Calendar] c
	WHERE c.CalendarDate BETWEEN '2019-06-01'
			AND getdate()
	ORDER BY 1

	
	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_1_f_new]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_1_f_new]

	SELECT c.STATE
		,b.FirstDateOfWeek AS Week
		,sum(CASE 
				WHEN (
						New = 'Yes'
						AND Active_yearMonth_New IS NOT NULL
						)
					THEN 1
				ELSE 0
				END) AS New_Listing_Count
	INTO [Minelson].[List].[Listing_trends_State_1_f_new]
	FROM [Minelson].[dbo].[ListingTrends_raw_F] r with (Nolock)
	LEFT JOIN [MiNelson].[dbo].[Calendar] b with (Nolock) ON r.sort_month = b.CalendarDate
	LEFT JOIN [Minelson].[Stats].[CountyCodes] c with (Nolock) ON r.Fips = c.Fips
	--where listing_id = 88355247
	GROUP BY c.STATE
		,b.FirstDateOfWeek

	UPDATE [MiNelson].[dbo].[a]
	SET a.STATE = 'na'
	--select *
	FROM [Minelson].[List].[Listing_trends_State_1_f_new] a
	WHERE STATE IS NULL


	CREATE INDEX idx_sort_month ON [Minelson].[dbo].[ListingTrends_raw_2_F] (sort_month) include (
		Pending_yearMonth
		,Contingent_yearMonth
		,Sold_yearMonth
		,Fail_yearMonth
		,fips
		)

	CREATE INDEX idx_fips ON [Minelson].[dbo].[ListingTrends_raw_2_F] (Fips)

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_1_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_1_f]

	SELECT c.STATE
		,b.FirstDateOfWeek AS Week
		,
		--sum (case when (New = 'Yes' and Active_yearMonth_New is not null ) then 1 else 0 end ) as New_Listing_Count,
		sum(CASE 
				WHEN Pending_yearMonth IS NOT NULL
					THEN 1
				ELSE 0
				END) AS Pending_Count
		,sum(CASE 
				WHEN Contingent_yearMonth IS NOT NULL
					THEN 1
				ELSE 0
				END) AS Contingent_Count
		,sum(CASE 
				WHEN Sold_yearMonth IS NOT NULL
					THEN 1
				ELSE 0
				END) AS Sold_Count
		,sum(CASE 
				WHEN Fail_yearMonth IS NOT NULL
					THEN 1
				ELSE 0
				END) AS Fail_Count
	INTO [Minelson].[List].[Listing_trends_State_1_f]
	FROM [Minelson].[dbo].[ListingTrends_raw_2_F] r with (Nolock)
	LEFT JOIN [MiNelson].[dbo].[Calendar] b with (Nolock) ON r.sort_month = b.CalendarDate
	LEFT JOIN [Minelson].[Stats].[CountyCodes] c with (Nolock) ON r.Fips = c.Fips
	--where listing_id = 88355247
	GROUP BY c.STATE
		,b.FirstDateOfWeek

	UPDATE [MiNelson].[dbo].[a]
	SET a.STATE = 'na'
	--select *
	FROM [Minelson].[List].[Listing_trends_State_1_f] a
	WHERE STATE IS NULL

	

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_f]

	SELECT a.*
		,b.Active_Listing_Count
		,c.New_Listing_Count
	INTO [Minelson].[List].[Listing_trends_State_f]
	FROM [Minelson].[List].[Listing_trends_State_1_f] a with (Nolock)
	LEFT JOIN [Minelson].[dbo].[Listing_trends_State_Platlabs_Active]  b with (Nolock) ON a.STATE = b.STATE ----- active platlabs
		AND a.Week = b.Week
	LEFT JOIN [Minelson].[List].[Listing_trends_State_1_f_new] c with (Nolock) ON a.STATE = c.STATE
		AND a.Week = c.Week

	--select * from  Minelson.[List].[Listing_trends_State_f]
	--where state = 'ca'
	--order by 2
	DELETE
	--select *
	FROM [Minelson].[List].[Listing_trends_state_f]
	WHERE week < '2019-01-01'

	DELETE
	--select *
	FROM [Minelson].[List].[Listing_trends_State_f]
	WHERE week > getdate()

	DELETE
	FROM [Minelson].[List].[Listing_trends_state_f]
	WHERE STATE IS NULL

	DELETE
	FROM [Minelson].[List].[Listing_trends_state_f]
	WHERE week IS NULL

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_Display_MLS_ListDate]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate]

	SELECT [State]
		,CASE 
			WHEN datepart(wk, week) < 10
				THEN CONCAT (
						'W0'
						,cast(datepart(wk, week) AS VARCHAR(2))
						,' - '
						,week
						)
			ELSE CONCAT (
					'W'
					,datepart(wk, week)
					,' - '
					,week
					)
			END AS [Week]
		,[New_Listing_Count]
		,[Active_Listing_Count]
		,[Pending_Count]
		,[Contingent_Count]
		,[Sold_Count]
		,[Fail_Count]
	INTO [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate]
	FROM [Minelson].[List].[Listing_trends_state_f] with (Nolock)
	WHERE week > = '2019-12-29'
	ORDER BY 1
		,2

	--- need to update
	UPDATE [MiNelson].[dbo].[a]
	SET a.Week = 'W01 - 2019-12-29'
	--select *
	FROM [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate] a
	WHERE week LIKE 'W53 - 2019-12-29%'

	UPDATE [MiNelson].[dbo].[a]
	SET a.Week = 'W01 - 2020-12-27'
	--select *
	FROM [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate] a
	WHERE week LIKE 'W53 - 2020-12-27%'

	UPDATE [MiNelson].[dbo].[a]
	SET a.Week = 'W01 - 2021-12-26'
	--select *
	FROM [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate] a
	WHERE week LIKE 'W53 - 2021-12-26%'

	--select * from Minelson.[List].[Listing_trends_State_Display_MLS_ListDate]
	--order by 1,2
	---- clean up
	/*IF OBJECT_ID('Minelson.[dbo].[Listing_trends_row_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[Listing_trends_row_f]

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_1_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_1_f]

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_2_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_2_f]

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_f]

	/*IF OBJECT_ID('Minelson.[dbo].[Listing_trends_perListing_f]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[Listing_trends_perListing_f]

	/*IF OBJECT_ID('Minelson.[List].[Listing_trends_State_1_f_new]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[Listing_trends_State_1_f_new]

	
		-----------------platlabs

		
  UPDATE [MiNelson].[dbo].[a]
	SET a.STATE = 'na'
	--select *
	FROM  [Minelson].[dbo].[Platlabs_newlisting_count_weekly] a
	WHERE STATE IS NULL or state in ('OS', 'US', 'OT', '0')

    /*IF OBJECT_ID('Minelson.dbo.Platlabs_newlisting_count_weekly_temp') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Platlabs_newlisting_count_weekly_temp]
		
	select CASE 
			WHEN datepart(wk, FirstDateOfWeek) < 10
				THEN CONCAT (
						'W0'
						,cast(datepart(wk, FirstDateOfWeek) AS VARCHAR(2))
						,' - '
						,FirstDateOfWeek
						)
			ELSE CONCAT (
					'W'
					,datepart(wk, FirstDateOfWeek)
					,' - '
					,FirstDateOfWeek
					)
			END AS [Week], * 
			into  [Minelson].[dbo].[Platlabs_newlisting_count_weekly_temp]
			from [Minelson].[dbo].[Platlabs_newlisting_count_weekly]
	where FirstDateOfWeek >='2024-01-01'
	
	order by 4,1



	--	select * from Minelson.[List].[Listing_trends_State_Display_MLS_ListDate] a
	--	inner join Minelson.dbo.Platlabs_newlisting_count_weekly_temp b
	--	on a.State = b.state and a.Week = b.Week 
	--where right(a.week, 10) > '2024-01-01'
	--order by 1,2


		update [MiNelson].[dbo].[a]
		set a.New_Listing_Count = b.New_Listing_Count
		
		from [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate] a
		inner join [Minelson].[dbo].[Platlabs_newlisting_count_weekly_temp] b
		on a.State = b.state and a.Week = b.Week 
	where right(a.week, 10) > '2024-01-01'
	

---- platlabs sold

	
  UPDATE [MiNelson].[dbo].[a]
	SET a.STATE = 'na'
	--select *
	FROM  [Minelson].[dbo].[Platlabs_listing_sold_state] a
	WHERE STATE IS NULL or state in ('OS', 'US', 'OT', '0')

    /*IF OBJECT_ID('Minelson.dbo.Platlabs_sold_count_weekly_temp') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[Platlabs_sold_count_weekly_temp]
		
	select CASE 
			WHEN datepart(wk, FirstDateOfWeek) < 10
				THEN CONCAT (
						'W0'
						,cast(datepart(wk, FirstDateOfWeek) AS VARCHAR(2))
						,' - '
						,FirstDateOfWeek
						)
			ELSE CONCAT (
					'W'
					,datepart(wk, FirstDateOfWeek)
					,' - '
					,FirstDateOfWeek
					)
			END AS [Week], * 
			into  [Minelson].[dbo].[Platlabs_sold_count_weekly_temp]
			from [Minelson].[dbo].[Platlabs_listing_sold_state]
	where FirstDateOfWeek >='2024-01-01'
	
	order by 4,1


	--select * from  Minelson.dbo.Platlabs_sold_count_weekly_temp


		update [MiNelson].[dbo].[a]
		set a.Sold_Count = b.Sold_Count
		--select *
		from [Minelson].[List].[Listing_trends_State_Display_MLS_ListDate] a
		inner join  [Minelson].[dbo].[Platlabs_sold_count_weekly_temp] b
		on a.State = b.state and a.Week = b.Week 
	where right(a.week, 10) > '2024-01-01'


	--	select * from  Minelson.[dbo].Listing_trends_State_Platlabs_Active 
	--	where week like '%2021-12-26'

	--	select *
	--	from Minelson.[List].[Listing_trends_State_Display_MLS_ListDate] a
	--	left join  Minelson.[dbo].Listing_trends_State_Platlabs_Active  b
	--	on a.State = b.state and a.Week = b.Week 
	--where b.week is null


END


