SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [zCust_NTC].[dbo].[usp_501_TESTING_INPUT] 
	
AS
BEGIN

	SET NOCOUNT ON;

		
		SET CONCAT_NULL_YIELDS_NULL OFF
		
		--Truncate table INPUT_IN

		INSERT INTO [zCust_NTC].[dbo].[INPUT_IN]([INPUTKey]
      ,[INPUTAddress]
      ,[INPUTCity]
      ,[INPUTState]
      ,[INPUTZip]
      ,[INPUT_Borrower Name]
      ,[INPUT_County Recording Juridiction]
      ,[INPUT_Release Doc Submitted Date]
      ,[INPUT_Orig Mtg Date]
      ,[INPUT_Orig Mtg Loan Amount]
      ,[INPUT_Orig Mtg Instrument #]
      ,[INPUT_Orig Mtg Book]
      ,[INPUT_Orig Mtg Page]
      ,[INPUT_Orig Mtg Recording Date]
      ,[INPUTBorrowerLastName]	)
		Select 
		[Unique ID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Borrower Name]
      ,[County Recording Juridiction]
      ,[Release Doc Submitted Date]
      ,Convert(date,[Orig Mtg Date])
      ,convert(money,[Orig Mtg Loan Amount])
      ,REPLACE([Orig Mtg Instrument #],',','')
      ,[Orig Mtg Book]
      ,[Orig Mtg Page]
      ,[Orig Mtg Recording Date]
      ,case when len([Borrower Name]) >= 1 then right(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM([Borrower Name])),' JR',''),' SR',''),' III','')
	  ,charindex(' ',REVERSE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM([Borrower Name])),' JR',''),' SR',''),' III','')))-1)
	else [Borrower Name] end
	  FROM [zCust_NTC].[dbo].[INPUT_RAW_CUST]
	  where len([UNIQUE ID])  > 1
	
	

END


