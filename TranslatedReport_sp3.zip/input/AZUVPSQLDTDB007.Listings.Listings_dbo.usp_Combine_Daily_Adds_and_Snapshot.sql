/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Combine_Daily_Adds_and_Snapshot | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Combine_Daily_Adds_and_Snapshot] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Combine_Daily_Adds_and_Snapshot'
		,N'Started'

	--DECLARE @snapshot_created DATETIME = (
	--		SELECT CONVERT(DATE, max(created), 121)
	--		FROM famls..fma_snapshot WITH (NOLOCK)
	--		)
	--DECLARE @daily_ads_created DATETIME = (
	--		SELECT CONVERT(DATE, max(created), 121)
	--		FROM famls..fma_daily_ads WITH (NOLOCK)
	--		)
	--Select @snapshot_created as N'@snapshot_created'
	--,@daily_ads_created as N'@daily_ads_created'
	--
	-- this code determine the max created date on snapshot and only retrieve them
	--
	--DROP TABLE
	--IF EXISTS Listings.Listings_tmp.hash_snapshot
	--	SELECT *
	--	INTO Listings.Listings_tmp.hash_snapshot
	--	FROM LISTINGS.Listings_dbo.FMA_Snapshot l WITH (
	--			NOLOCK
	--			,INDEX (IDX_Created)
	--			)
	--	WHERE CONVERT(DATE, l.created, 121) = (
	--			SELECT CONVERT(DATE, max(created), 121)
	--			FROM LISTINGS.Listings_dbo.FMA_Snapshot WITH (NOLOCK)
	--			)
	/* 
	select  format(count(*), '##,##0') as cnt from listings.listings_dbo.[FMA_Daily_Ads]

select top 100 * from Listings.Listings_tmp.hash_snapshot
listings.listings_dbo.[FMA_Daily_Ads]
use listings

		select top 100 * from Listings.Listings_tmp.hash_famls where id = 107068253
		
select top 100 *  FROM famls..fma_snapshot where id  = 107068253
select top 100 * from famls..fma_daily_ads where snapshot_id = 107068253

select top 100  * from  famls.dbo.fa_mls with(nolock,index(idx_poperty_id)) where property_id = 1107068253
*/
	--DROP TABLE
	--IF EXISTS Listings.Listings_tmp.hash_Daily_adds
	--	SELECT *
	--	INTO Listings.Listings_tmp.hash_Daily_adds
	--	FROM listings.listings_dbo.[FMA_Daily_Ads] d WITH (
	--			NOLOCK
	--			,INDEX (idx_created)
	--			)
	--	WHERE CONVERT(DATE, d.created, 121) = (
	--			SELECT CONVERT(DATE, max(created), 121)
	--			FROM listings.listings_dbo.[FMA_Daily_Ads] WITH (NOLOCK)
	--			)
	--SELECT format(count(*), '##,##0') AS cnt
	--FROM Listings.Listings_tmp.hash_snapshot --88,481
	--SELECT format(count(*), '##,##0') AS cnt
	--FROM Listings.Listings_tmp.hash_Daily_adds --94,227
	--CREATE CLUSTERED INDEX idx_id ON Listings.Listings_tmp.hash_snapshot (id)
	--CREATE CLUSTERED INDEX idx_snapshot_id ON Listings.Listings_tmp.hash_Daily_adds (snapshot_id)
	DROP TABLE

	IF EXISTS [Listings].[Listings_tmp].[hash_famls]
		SELECT l.id
			,l.property_id
			,l.current_market_status
			,l.date_first_advertised
			,l.date_last_advertised
			,l.asking_price_high
			,l.asking_price_high_on
			,l.asking_price_low
			,l.asking_price_low_on
			,l.asking_price_current
			,l.street_address
			,l.city
			,l.urbanization
			,l.county_name
			,l.STATE
			,l.postal_code
			,l.cass_street_address
			,l.cass_city
			,l.cass_urbanization
			,l.cass_county_name
			,l.cass_state
			,l.cass_postal_code
			,l.cass_dpbc
			,l.cass_unit_type
			,l.cass_unit_number
			,l.cass_dpv
			,l.cass_building_type
			,l.cass_return_code
			,l.cass_updated_on
			,l.gnis_feature_id
			,l.scf
			,l.fips
			,l.msa
			,l.latitude
			,l.longitude
			,l.property_type_description
			,l.subdivision
			,l.bedrooms_string
			,l.bedrooms_int
			,l.bathrooms_string
			,l.bathrooms_total
			,l.bathrooms_full
			,l.bathrooms_3_4
			,l.bathrooms_half
			,l.lot_size_string
			,l.lot_size_decimal
			,l.lot_size_unit
			,l.square_feet_string
			,l.square_feet_foundation
			,l.square_feet_total
			,l.square_feet_finished
			,l.square_feet_above_ground
			,l.square_feet_below_ground
			,l.garage_description
			,l.garage_stalls
			,l.year_built
			,l.stories
			,l.water_source
			,l.sewer_source
			,l.school_district
			,l.school_elementary
			,l.school_middle
			,l.school_senior_high
			,l.construction_description
			,l.floor_description
			,l.cooling_description
			,l.heating_description
			,l.basement_description
			,l.fireplace_description
			,l.interior_description
			,l.general_description
			,l.parking_description
			,l.exterior_description
			,l.roof_description
			,l.pool_description
			,l.lot_dimensions
			,l.zoning_description
			,l.land_description
			,l.green_energy_description
			,l.hoa_amenities
			,l.disabled_accessibility_description
			,l.design_features_description
			,l.legal_description
			,l.included_items
			,l.has_pool
			,l.has_water_front
			,l.body_of_water
			,l.water_front_type
			,l.agent_name
			,l.agent_telephone
			,l.agent_email
			,l.agent_website
			,l.brokerage_name
			,l.brokerage_street_address
			,l.brokerage_city
			,l.brokerage_state
			,l.brokerage_postal_code
			,l.brokerage_telephone
			,l.brokerage_website
			,l.is_fsbo
			,l.is_lender_owned
			,l.is_short_sale
			,l.has_notice_of_default
			,l.local_assessor_id
			,l.tax_year
			,l.tax_amount
			,l.assessments
			,l.association_fees
			,l.association_fees_frequency
			,l.is_active
			,l.created_at
			,l.last_price_change
			,l.last_price_change_on
			,l.inactive_on
			,d.sold_on
			,l.asking_price_original
			,d.asking_price
			,d.market_status
			,d.listing_number
		INTO [Listings].[Listings_tmp].[hash_famls]
		FROM [listings].[listings_tmp].[FMA_Snapshot_wrk] l WITH (
				NOLOCK
				,INDEX (idx_id)
				)
		INNER JOIN [listings].[listings_tmp].[FMA_Daily_Ads_wrk] d WITH (
				NOLOCK
				,INDEX (idx_snapshot_id)
				) ON d.snapshot_id = l.id

	/*	
DROP TABLE

IF EXISTS listings.tmp.[FA_MLS_Wrk_Prod]
	SELECT *
	INTO listings.tmp.[FA_MLS_Wrk_Prod]
	FROM [FAMLS].[dbo].[FA_MLS_Wrk]

DROP TABLE

IF EXISTS Listings.Listings_tmp.hash_famls
	SELECT *
	INTO Listings.Listings_tmp.hash_famls
	FROM Listings.Listings_tmp.hash_famls
	select  format(count(*), '##,##0') as cnt from listings.[Listings_dbo].[FA_MLS_Wrk]


*/
	--select  * into listings.tmp.[FA_MLS_Wrk_test_20250505] from [FAMLS].[dbo].[FA_MLS_Wrk]
	DECLARE @update_flag_date VARCHAR(10) = try_cast(getdate() AS DATE)

	SELECT @update_flag_date

	SET @update_flag_date = CONVERT(CHAR(10), GetDate(), 126) -- https://www.mssqltips.com/sqlservertip/1145/date-and-time-conversions-using-sql-server/

	SELECT @update_flag_date

	TRUNCATE TABLE [listings].[Listings_dbo].[FA_MLS_Wrk]

	INSERT INTO [listings].[Listings_dbo].[FA_MLS_Wrk] (
		[Property_ID]
		,[MLS_ID]
		,[APN]
		,[MLS_STATUS]
		,[MLS_LIST_DATE]
		,[SOLD_DATE]
		,[MLS_DAYS_ON_MARKET]
		,[HOUSE_NBR]
		,[STREET]
		,[CITY]
		,[STATE_1]
		,[ZIP]
		,[COUNTY_NAME]
		,[MLS_AREA]
		,[ZONING]
		,[PROPERTY_DETAILS]
		,[NBR_BEDRMS]
		,[NBR_BATH]
		,[HOME_SIZE]
		,[LOT_SIZE]
		,[LOT_FTRS]
		,[MLS_LIST_PRICE]
		,[SOLD_PRICE]
		,[PRICE_PER_SQFT]
		,[PROPERTY_TYPE]
		,[PROPERTY_SUB_TYPE]
		,[YEAR_BUILT]
		,[NEIGHBORHOOD]
		,[STYLE]
		,[NBR_STORIES]
		,[NBR_GRG]
		,[SCHOOL_DISTRICT]
		,[ELEMENTARY_SCHOOL]
		,[MIDDLE_SCHOOL]
		,[HIGH_SCHOOL]
		,[FIREPLACE_FTRS]
		,[HEATING_FTRS]
		,[EXTERIOR_CONSTRUCTION]
		,[ROOFING]
		,[INTERIOR_FTRS]
		,[EXTERIOR_FTRS]
		,[UTILITY_PRESENT]
		,[COOLING_FTRS]
		,[TOPOGRAPHY]
		,[PARCEL_ACCESS]
		,[MLS_INCLUSIONS]
		,[SUBDIVISION]
		,[RANGE_AIRCONDITIONERS]
		,[WATER_HEATERS]
		,[ENERGY_INFO]
		,[PARKING_FTRS]
		,[APX_LOT_DIMENSIONS]
		,[COMMUNITY_FTRS]
		,[POOL_FTRS]
		,[WATER_FRONT_FTRS]
		,[AIR_CONDITIONERS]
		,[VIEW_1]
		,[EXISTING_STRUCTURES]
		,[MASTER_BEDROOM]
		,[COMPLEX_FTRS]
		,[PRESENT_USE]
		,[APX_LOT_IS_L85]
		,[APPLIANCES]
		,[WATER]
		,[FARM_IMPROVEMENT]
		,[WATER_ACCESS]
		,[WATER_HEATER]
		,[SEWER]
		,[OTHER_FTRS]
		,[BSMT_FIN_SQFT]
		,[MLS_OFFICE_NAME]
		,[MLS_OFFICE_EMAIL]
		,[MLS_OFFICE_ADDRESS]
		,[MLS_OFFICE_PHONE]
		,[MLS_LISTING_AGENT_LICENSE_NBR]
		,[MLS_LISTING_AGENT_NAME]
		,[MLS_LISTING_AGENT_ADDRESS]
		,[MLS_LISTING_AGENT_PHONE]
		,[MLS_LISTING_AGENT_COMPANY]
		,[MLS_LISTING_AGENT_EMAIL]
		,[MLS_NAME]
		,[UPDATE_FLAG]
		,[UPDATE_FLAG_DATE]
		,[PROVIDER_TYPE]
		,[LISTING_AGENT_PHONE1]
		,[LISTING_AGENT_PHONE1_DESCRIPTION]
		,[LISTING_AGENT_PHONE2]
		,[LISTING_AGENT_PHONE2_DESCRIPTION]
		,[LISTING_AGENT_PHONE3]
		,[LISTING_AGENT_PHONE3_DESCRIPTION]
		,[LISTING_AGENT_PHONE4]
		,[LISTING_AGENT_PHONE4_DESCRIPTION]
		,[LISTING_AGENT_PHONE5]
		,[LISTING_AGENT_PHONE5_DESCRIPTION]
		,[LISTING_AGENT2_FULL_NAME]
		,[LISTING_AGENT2_LICENSE_NBR]
		,[LISTING_AGENT2_COMPANY]
		,[LISTING_AGENT2_ADDRESS]
		,[LISTING_AGENT2_PHONE1]
		,[LISTING_AGENT2_PHONE1_DESCRIPTION]
		,[LISTING_AGENT2_PHONE2]
		,[LISTING_AGENT2_PHONE2_DESCRIPTION]
		,[LISTING_AGENT2_PHONE3]
		,[LISTING_AGENT2_PHONE3_DESCRIPTION]
		,[LISTING_AGENT2_PHONE4]
		,[LISTING_AGENT2_PHONE4_DESCRIPTION]
		,[LISTING_AGENT2_PHONE5]
		,[LISTING_AGENT2_PHONE5_DESCRIPTION]
		,[LISTING_AGENT2_EMAIL]
		,[LISTING_OFFICE2_NAME]
		,[LISTING_OFFICE2_ADDRESS]
		,[LISTING_OFFICE2_PHONE]
		,[LISTING_OFFICE2_EMAIL]
		,[SEL_AGENT_FULL_NAME]
		,[SEL_AGENT_LICENSE_NBR]
		,[SEL_AGENT_COMPANY]
		,[SEL_AGENT_ADDRESS]
		,[SEL_AGENT_PHONE1]
		,[SEL_AGENT_PHONE1_DESCRIPTION]
		,[SEL_AGENT_PHONE2]
		,[SEL_AGENT_PHONE2_DESCRIPTION]
		,[SEL_AGENT_PHONE3]
		,[SEL_AGENT_PHONE3_DESCRIPTION]
		,[SEL_AGENT_PHONE4]
		,[SEL_AGENT_PHONE4_DESCRIPTION]
		,[SEL_AGENT_PHONE5]
		,[SEL_AGENT_PHONE5_DESCRIPTION]
		,[SEL_AGENT_EMAIL]
		,[SEL_OFFICE_NAME]
		,[SEL_OFFICE_ADDRESS]
		,[SEL_OFFICE_PHONE]
		,[SEL_OFFICE_EMAIL]
		,[SEL_AGENT2_FULL_NAME]
		,[SEL_AGENT2_LICENSE_NBR]
		,[SEL_AGENT2_COMPANY]
		,[SEL_AGENT2_ADDRESS]
		,[SEL_AGENT2_EMAIL]
		,[SEL_AGENT2_PHONE1]
		,[SEL_AGENT2_PHONE1_DESCRIPTION]
		,[SEL_AGENT2_PHONE2]
		,[SEL_AGENT2_PHONE2_DESCRIPTION]
		,[SEL_AGENT2_PHONE3]
		,[SEL_AGENT2_PHONE3_DESCRIPTION]
		,[SEL_AGENT2_PHONE4]
		,[SEL_AGENT2_PHONE4_DESCRIPTION]
		,[SEL_AGENT2_PHONE5]
		,[SEL_AGENT2_PHONE5_DESCRIPTION]
		,[SEL_OFFICE2_NAME]
		,[SEL_OFFICE2_ADDRESS]
		,[SEL_OFFICE2_PHONE]
		,[SEL_OFFICE2_EMAIL]
		,[Raw_Address]
		)
	--select  * from FAMLS.dbo.fa_mls_wrk where    property_id = 1110381796
	--select  bedrooms_string ,* from Listings.Listings_tmp.hash_famls where id = 110381796
	SELECT 1000000000 + a.id AS [Property_ID]
		,substring(nullif(a.listing_number, ' '), 1, 50) AS [MLS_ID]
		,nullif(substring(a.local_assessor_id, 1, 500), '') AS [APN]
		,nullif(substring(a.market_status, 1, 50), '') AS [MLS_STATUS]
		--		,nullif(try_cast(date_first_advertised AS VARCHAR(50)), '') AS [MLS_LIST_DATE] -- we commented this since sunil is updating fams.dbo.fa_mls with the created_at as the list date
		,nullif(try_cast(a.created_at AS VARCHAR(50)), '') AS [MLS_LIST_DATE]
		,nullif(try_cast(a.sold_on AS VARCHAR(50)), '') AS [SOLD_DATE]
		,nullif(substring('', 1, 50), '') AS [MLS_DAYS_ON_MARKET]
		,nullif(substring('', 1, 50), '') AS [HOUSE_NBR]
		,a3.[STREET]
		,a3.[CITY]
		,a3.[STATE_1]
		,a3.[ZIP]
		,a3.[COUNTY_NAME]
		,nullif(substring('', 1, 500), '') AS [MLS_AREA]
		,nullif(substring(a.zoning_description, 1, 100), '') AS [ZONING]
		,nullif(substring('', 1, 4000), '') AS [PROPERTY_DETAILS]
		,nullif(substring(a2.bedrooms_string, 1, 50), '') AS [NBR_BEDRMS]
		,nullif(a.bathrooms_total, 0) AS [NBR_BATH] -- 20250617 
		--,nullif(a.bathrooms_full, 0) AS [NBR_BATH] -- 20250617 after compre
		,nullif(a.square_feet_total, 0) AS [HOME_SIZE]
		--,nullif(lot_size_decimal, 0) AS [LOT_SIZE] -- 20250605
		--,nullif(try_cast(try_cast(a.lot_size_decimal AS FLOAT) AS VARCHAR(10)), '0') AS [LOT_SIZE]
		--,nullif(try_cast(try_cast(a.lot_size_decimal AS decimal(15,2)) AS VARCHAR(20)), '0') AS [LOT_SIZE]
		,nullif(try_cast(try_cast(CASE 
						WHEN lot_size_unit = 'ACRES'
							THEN a.lot_size_decimal * 43560
						ELSE a.lot_size_decimal
						END AS DECIMAL(15, 2)) AS VARCHAR(20)), '0') AS [LOT_SIZE]
		,nullif(substring(a.land_description, 1, 4000), '') AS [LOT_FTRS]
		,nullif(a.asking_price, 0) AS [MLS_LIST_PRICE]
		,nullif(substring('', 1, 50), '') AS [SOLD_PRICE]
		,nullif(substring('', 1, 50), '') AS [PRICE_PER_SQFT]
		,nullif(substring(a.property_type_description, 1, 500), '') AS [PROPERTY_TYPE]
		,nullif(substring('', 1, 500), '') AS [PROPERTY_SUB_TYPE]
		,nullif(a.year_built, 0) AS [YEAR_BUILT]
		,nullif(substring('', 1, 500), '') AS [NEIGHBORHOOD]
		,nullif(substring(a.design_features_description, 1, 1000), '') AS [STYLE]
		,nullif(a.stories, 0) AS [NBR_STORIES]
		,nullif(a.garage_stalls, 0) AS [NBR_GRG] -- 20250611 -- 20250619
		--,a.garage_stalls AS [NBR_GRG] -- 20250619
		,nullif(substring(a.school_district, 1, 1000), '') AS [SCHOOL_DISTRICT]
		,nullif(substring(a.school_elementary, 1, 1000), '') AS [ELEMENTARY_SCHOOL]
		,nullif(substring(a.school_middle, 1, 1000), '') AS [MIDDLE_SCHOOL]
		,nullif(substring(a.school_senior_high, 1, 1000), '') AS [HIGH_SCHOOL]
		,nullif(substring(a.fireplace_description, 1, 4000), '') AS [FIREPLACE_FTRS]
		,nullif(substring(a.heating_description, 1, 4000), '') AS [HEATING_FTRS]
		,nullif(substring(a.construction_description, 1, 4000), '') AS [EXTERIOR_CONSTRUCTION]
		,nullif(substring(a.roof_description, 1, 4000), '') AS [ROOFING]
		,nullif(substring(a.interior_description, 1, 4000), '') AS [INTERIOR_FTRS]
		,nullif(substring(a.exterior_description, 1, 4000), '') AS [EXTERIOR_FTRS]
		,nullif(substring('', 1, 4000), '') AS [UTILITY_PRESENT]
		,nullif(substring(a.cooling_description, 1, 4000), '') AS [COOLING_FTRS]
		,nullif(substring('', 1, 200), '') AS [TOPOGRAPHY]
		,nullif(substring('', 1, 200), '') AS [PARCEL_ACCESS]
		,nullif(substring('', 1, 4000), '') AS [MLS_INCLUSIONS]
		,substring(a.subdivision, 1, 500) AS [SUBDIVISION]
		,nullif(substring('', 1, 200), '') AS [RANGE_AIRCONDITIONERS]
		,nullif(substring('', 1, 200), '') AS [WATER_HEATERS]
		,nullif(substring(a.green_energy_description, 1, 4000), '') AS [ENERGY_INFO]
		,nullif(substring(a.parking_description, 1, 4000), '') AS [PARKING_FTRS]
		,nullif(substring(a.lot_dimensions, 1, 200), '') AS [APX_LOT_DIMENSIONS]
		,nullif(substring(a.hoa_amenities, 1, 500), '') AS [COMMUNITY_FTRS]
		,nullif(substring(a.pool_description, 1, 4000), '') AS [POOL_FTRS]
		,nullif(substring(CASE 
					WHEN a.water_front_type IN (
							'Y'
							,'1'
							)
						THEN 'Yes'
					WHEN nullif(a.water_front_type, '0') IS NOT NULL
						AND a.water_front_type NOT IN ('N')
						THEN a.water_front_type
					WHEN isnull(a.has_water_front, '') = '1'
						THEN 'Yes'
					ELSE NULL
					END, 1, 200), '') AS [WATER_FRONT_FTRS]
		,nullif(substring('', 1, 200), '') AS [AIR_CONDITIONERS]
		,nullif(substring('', 1, 4000), '') AS [VIEW_1]
		,nullif(substring('', 1, 4000), '') AS [EXISTING_STRUCTURES]
		,nullif(substring('', 1, 200), '') AS [MASTER_BEDROOM]
		,nullif(substring('', 1, 500), '') AS [COMPLEX_FTRS]
		,nullif(substring('', 1, 500), '') AS [PRESENT_USE]
		,nullif(substring('', 1, 200), '') AS [APX_LOT_IS_L85]
		,nullif(substring(a.included_items, 1, 4000), '') AS [APPLIANCES]
		,nullif(substring(a.water_source, 1, 4000), '') AS [WATER]
		,nullif(substring('', 1, 200), '') AS [FARM_IMPROVEMENT]
		,nullif(substring('', 1, 4000), '') AS [WATER_ACCESS]
		,nullif(substring('', 1, 200), '') AS [WATER_HEATER]
		,substring(a.sewer_source, 1, 4000) AS [SEWER]
		,nullif(substring('', 1, 4000), '') AS [OTHER_FTRS]
		,nullif(substring('', 1, 50), '') AS [BSMT_FIN_SQFT]
		,nullif(substring(a.brokerage_name, 1, 500), '') AS [MLS_OFFICE_NAME]
		,nullif(substring(a.agent_email, 1, 100), '') AS [MLS_OFFICE_EMAIL]
		,nullif(substring(CASE 
					WHEN isnull(a.brokerage_street_address, '') > ''
						THEN a.brokerage_street_address + ', '
					ELSE ''
					END + CASE 
					WHEN a.brokerage_city IS NOT NULL
						THEN a.brokerage_city + ', '
					ELSE ''
					END + CASE 
					WHEN a.brokerage_state IS NOT NULL
						THEN a.brokerage_state + ', '
					ELSE ''
					END + CASE 
					WHEN a.brokerage_postal_code IS NOT NULL
						THEN a.brokerage_postal_code
					ELSE ''
					END, 1, 1000), '') AS [MLS_OFFICE_ADDRESS]
		,nullif(substring(a.brokerage_telephone, 1, 100), '') AS [MLS_OFFICE_PHONE]
		,nullif(substring('', 1, 100), '') AS [MLS_LISTING_AGENT_LICENSE_NBR]
		,nullif(substring(a.agent_name, 1, 500), '') AS [MLS_LISTING_AGENT_NAME]
		,nullif(substring('', 1, 1000), '') AS [MLS_LISTING_AGENT_ADDRESS]
		,nullif(substring(a.agent_telephone, 1, 100), '') AS [MLS_LISTING_AGENT_PHONE]
		,nullif(substring(a.brokerage_name, 1, 100), '') AS [MLS_LISTING_AGENT_COMPANY]
		,nullif(substring(a.agent_email, 1, 100), '') AS [MLS_LISTING_AGENT_EMAIL]
		,nullif(substring('', 1, 100), '') AS [MLS_NAME]
		,nullif(substring('I', 1, 50), '') AS [UPDATE_FLAG]
		,substring(@update_flag_date, 1, 10) AS [UPDATE_FLAG_DATE]
		,nullif(substring('FMA', 1, 20), '') AS [PROVIDER_TYPE]
		,nullif(substring(a.agent_telephone, 1, 100), '') AS [LISTING_AGENT_PHONE1]
		,nullif(substring('', 1, 500), '') AS [LISTING_AGENT_PHONE1_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE2]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE2_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE3]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE3_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE4]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE4_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE5]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT_PHONE5_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_FULL_NAME]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_LICENSE_NBR]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_COMPANY]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE1]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE1_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE2]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE2_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE3]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE3_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE4]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE4_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE5]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_PHONE5_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [LISTING_AGENT2_EMAIL]
		,nullif(substring('', 1, 100), '') AS [LISTING_OFFICE2_NAME]
		,nullif(substring('', 1, 100), '') AS [LISTING_OFFICE2_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [LISTING_OFFICE2_PHONE]
		,nullif(substring('', 1, 100), '') AS [LISTING_OFFICE2_EMAIL]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_FULL_NAME]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_LICENSE_NBR]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_COMPANY]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE1]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE1_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE2]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE2_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE3]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE3_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE4]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE4_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE5]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_PHONE5_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT_EMAIL]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE_NAME]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE_PHONE]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE_EMAIL]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_FULL_NAME]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_LICENSE_NBR]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_COMPANY]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_EMAIL]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE1]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE1_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE2]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE2_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE3]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE3_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE4]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE4_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE5]
		,nullif(substring('', 1, 100), '') AS [SEL_AGENT2_PHONE5_DESCRIPTION]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE2_NAME]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE2_ADDRESS]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE2_PHONE]
		,nullif(substring('', 1, 100), '') AS [SEL_OFFICE2_EMAIL]
		,nullif(substring(isnull(a3.street, '') + ', ' + isnull(a3.city, '') + ', ' + isnull(a3.state_1, '') + ', ' + isnull(a3.zip, ''), 1, 200), '') AS [Raw_Address]
	--,nullif(substring(CASE 
	--	WHEN isnull(a.street_address, '') > ''
	--		THEN a.street_address + ', '
	--	ELSE ''
	--	END
	--	+ CASE 
	--	WHEN a.city IS NOT NULL
	--		THEN a.city + ', '
	--	ELSE ''
	--	END 
	--	+ CASE 
	--	WHEN a.state IS NOT NULL
	--		THEN a.state + ', '
	--	ELSE ''
	--	END 
	--	+ CASE 
	--	WHEN a.postal_code IS NOT NULL
	--		THEN a.postal_code
	--     					ELSE ''
	--		END, 1, 200), '') AS [Raw_Address_2]
	FROM [Listings].[Listings_tmp].[hash_famls] a --Listings.Listings_tmp.hash_famls a
	OUTER APPLY (
		SELECT replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ltrim(rtrim(bedrooms_string)), 'Beds', ''), 'Bed', ''), ' BEDS', ''), 'n/a', ''), 'Bedrooms', ''), 'Bedroom', ''), ' and ', ''), ' Full', ''), '--', ''), ' ', '') AS bedrooms_string
		) a1
	OUTER APPLY (
		SELECT CASE 
				WHEN a1.bedrooms_string IS NULL
					OR a1.bedrooms_string = '0'
					THEN NULL
				ELSE a1.bedrooms_string
				END AS bedrooms_string
		) a2
	OUTER APPLY (
		SELECT CASE 
				WHEN a.cass_street_address IS NOT NULL
					AND a.cass_city IS NOT NULL
					AND a.cass_state IS NOT NULL
					AND a.cass_postal_code IS NOT NULL
					--AND a.cass_county_name IS NOT NULL
					THEN nullif(substring(isnull(a.cass_street_address, ''), 1, 500), '')
				ELSE nullif(substring(isnull(a.street_address, ''), 1, 500), '')
				END AS [STREET]
			,CASE 
				WHEN a.cass_street_address IS NOT NULL
					AND a.cass_city IS NOT NULL
					AND a.cass_state IS NOT NULL
					AND a.cass_postal_code IS NOT NULL
					--AND a.cass_county_name IS NOT NULL
					THEN nullif(substring(isnull(a.cass_city, ''), 1, 500), '')
				ELSE nullif(substring(isnull(a.city, ''), 1, 500), '')
				END AS [CITY]
			,CASE 
				WHEN a.cass_street_address IS NOT NULL
					AND a.cass_city IS NOT NULL
					AND a.cass_state IS NOT NULL
					AND a.cass_postal_code IS NOT NULL
					--AND a.cass_county_name IS NOT NULL
					THEN nullif(substring(isnull(a.cass_state, ''), 1, 50), '')
				ELSE nullif(substring(isnull(a.STATE, ''), 1, 50), '')
				END AS [STATE_1]
			,CASE 
				WHEN a.cass_street_address IS NOT NULL
					AND a.cass_city IS NOT NULL
					AND a.cass_state IS NOT NULL
					AND a.cass_postal_code IS NOT NULL
					--AND a.cass_county_name IS NOT NULL
					THEN nullif(substring(isnull(a.cass_postal_code, ''), 1, 500), '')
				ELSE nullif(substring(isnull(a.postal_code, ''), 1, 50), '')
				END AS [ZIP]
			,CASE 
				WHEN a.cass_street_address IS NOT NULL
					AND a.cass_state IS NOT NULL
					AND a.cass_city IS NOT NULL
					AND a.cass_postal_code IS NOT NULL
					--AND a.cass_county_name IS NOT NULL
					THEN nullif(substring(isnull(a.cass_county_name, ''), 1, 50), '')
				ELSE nullif(substring(isnull(a.county_name, ''), 1, 500), '')
				END AS [COUNTY_NAME]
		) a3

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Combine_Daily_Adds_and_Snapshot'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

SELECT *
FROM [Listings].[Listings_tmp].[hash_famls]


