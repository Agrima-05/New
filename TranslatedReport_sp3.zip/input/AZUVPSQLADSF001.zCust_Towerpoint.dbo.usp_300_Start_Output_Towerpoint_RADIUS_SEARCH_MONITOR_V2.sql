SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_Towerpoint].[dbo].[usp_300_Start_Output_Towerpoint_RADIUS_SEARCH_MONITOR_V2]


AS
BEGIN
	
	SET NOCOUNT ON;


			------BACKUP monitor table----
		DECLARE @DATE varchar(250)
		Set @DATE =  (SELECT format(getdate(),'yyyyMMddHHmmssffff')) ----convert(varchar(14),Getdate(),115)
		EXEC('Select * into dbo.[INPUT_MONITOR_NEW_' + @DATE + '] From INPUT_MONITOR_NEW')
	


	----20220411 - Per CL:
	-----If we return 2 properties per Lat/Long radius search we are to ADD BOTH to the portfolio to MONITOR monthly going forward!!!

	----MONITORING FOR:
	-----1 - OWNER NAME CHANGE
	-----2 - CURRENTSALETRANSACTIONID change
	-----3 - TOTAL OPEN LINE NBR CHANGE

	------RADIUS search will be for initial match only & setting up the portfolio to monitor - will then need to change code to use portfolio only!!

	------20220609---
----	Hi Kristina,

----Here you are from the client;

----1.	Are moving forward with the 75,925 “matched” properties?  Yes.  
----2.	Do you want all records returned in each monthly extract – or only those where there has been a change in one of the monitored values(Ownership, CurrentSale or Total number of Open mortgages)?  Only those where that has been change in ownership/property sale.
----3.	How do you want to handle the scenario where ownership has changed – but we either do not have the new owner name – or perhaps the new mailing address or the new owner is Mail Opt Out? i.e.; Do we notify you of the change with the EVENT FOUND with fields blank (since we won’t have the details), do you want us not to return the record?  Yes I think it would still be beneficial to know that the property is no longer with the previous owner. 
----4.	Is there a specific Day of the month they want the monthly output sent?  Let’s go with the 15th of the month.
----5.	Is their plan to send Add/Change/Deletes to the portfolio at some point?   Yes.  We will be adding more, need to correct some errors, and delete some.  

----[6:18 PM] Kristina Lowe
----Hi Charysse - For Towerpoint - are we not also monitoring for a change in the number of Total Open Mortgages (I had that in my previous notes for this customer)?  Or are we only looking for Owner name or Current Sale change)?

----[6:49 PM] Charysse Le Beau
----Hi there - we are. 

----[6:49 PM] Charysse Le Beau
----We are looking for all the changes in the layout that I have outlined. 

----[6:54 PM] Kristina Lowe
----Ok - the customers comment on question 2 in the email only made reference to "change in ownership/property sale"  - so I just wanted to verify.  For the records where the new owner is a mail opt out or owner name/mail address is not fully populated - I will populate the property info (situs, prop char etc) - & just leave the owner name, mailing address & curr sale fields blank - that ok?

----[6:55 PM] Charysse Le Beau
----That will be perfect!

----[6:55 PM] Kristina Lowe
----& those will be marked as Event Found (so all records in their output will be Event Found records since we're only returning updated records)

----[6:55 PM] Kristina Lowe
----Coolio!

----[6:55 PM] Charysse Le Beau
----Thanks!



------20220621 - Per CL - Changing monitoring to ONLY monitor for Owner Name changes (of any kind)----


		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			

			-------INTERNAL-----
			[INPUTLAT][float]NULL,
			[INPUTLON][float]NULL,
			[FIPS][varchar](250)NULL,
			[MATCHTYPE][varchar](250)NULL,


			[Input Unique ID][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[RunDate][varchar](250)NULL,
			[Approxmate Distance][varchar](250)NULL,
			[PropertyID][varchar](250)NULL,
			[APN][varchar](250)NULL,
			[SitusFullStreetAddress][varchar](250)NULL,
			[SitusHouseNbr][varchar](250)NULL,
			[SitusHouseNbrSuffix][varchar](250)NULL,
			[SitusDirectionLeft][varchar](250)NULL,
			[SitusStreet][varchar](250)NULL,
			[SitusMode][varchar](250)NULL,
			[SitusDirectionRight][varchar](250)NULL,
			[SitusUnitType][varchar](250)NULL,
			[SitusUnitNbr][varchar](250)NULL,
			[SitusCity][varchar](250)NULL,
			[SitusState][varchar](250)NULL,
			[SitusZIP5][varchar](250)NULL,
			[SitusZIP4][varchar](250)NULL,
			[LandUseCode][varchar](250)NULL,
			[StateLandUseCode][varchar](250)NULL,
			[CountyLandUseCode][varchar](250)NULL,
			[Zoning][varchar](250)NULL,
			[SitusCensusTract][varchar](250)NULL,
			[SitusCensusBlock][varchar](250)NULL,
			[LotSizeAcres][varchar](250)NULL,
			[Owner1CorpInd][varchar](250)NULL,
			[Owner1LastName][varchar](250)NULL,
			[Owner1FirstName][varchar](250)NULL,
			[Owner1MiddleName][varchar](250)NULL,
			[Owner1Suffix][varchar](250)NULL,
			[Owner2CorpInd][varchar](250)NULL,
			[Owner2LastName][varchar](250)NULL,
			[Owner2FirstName][varchar](250)NULL,
			[Owner2MiddleName][varchar](250)NULL,
			[Owner2Suffix][varchar](250)NULL,
			[OwnerNAME1FULL][varchar](250)NULL,
			[OwnerNAME2FULL][varchar](250)NULL,
			[MailingFullStreetAddress][varchar](250)NULL,
			[MailingHouseNbr][varchar](250)NULL,
			[MailingHouseNbrSuffix][varchar](250)NULL,
			[MailingDirectionLeft][varchar](250)NULL,
			[MailingStreet][varchar](250)NULL,
			[MailingMode][varchar](250)NULL,
			[MailingDirectionRight][varchar](250)NULL,
			[MailingUnitType][varchar](250)NULL,
			[MailingUnitNbr][varchar](250)NULL,
			[MailingCity][varchar](250)NULL,
			[MailingState][varchar](250)NULL,
			[MailingZIP5][varchar](250)NULL,
			[MailingZIP4][varchar](250)NULL,
			[MailingCOName][varchar](250)NULL,
			[MailOptOut][varchar](250)NULL,
			[AssdTotalValue][varchar](250)NULL,
			[AssdLandValue][varchar](250)NULL,
			[AssdImprovementValue][varchar](250)NULL,
			[MarketTotalValue][varchar](250)NULL,
			[TaxAmt][varchar](250)NULL,
			[TaxYear][varchar](250)NULL,
			[TaxDeliquentYear][varchar](250)NULL,
			[AssdYear][varchar](250)NULL,
			[YearBuilt][varchar](250)NULL,
			[EffectiveYearBuilt][varchar](250)NULL,
			[BuildingConditionCode][varchar](250)NULL,
			[ConstructionTypeCode][varchar](250)NULL,
			[BuildingQualityCode][varchar](250)NULL,
			[RoofCoverCode][varchar](250)NULL,
			[RoofTypeCode][varchar](250)NULL,
			[StoriesNbrCode][varchar](250)NULL,
			[LandLot][varchar](250)NULL,
			[Block][varchar](250)NULL,
			[Section][varchar](250)NULL,
			[District][varchar](250)NULL,
			[Municipality][varchar](250)NULL,
			[SubdivisionName][varchar](250)NULL,
			[LegalDescription][varchar](2000)NULL,
			[CurrentSaleTransactionId][varchar](250)NULL,
			[CurrentSaleRecordingDate][varchar](250)NULL,
			[CurrentSaleDocumentType][varchar](250)NULL,
			[CurrentSalesPrice][varchar](250)NULL,
			[CurrentSaleBuyer1FullName][varchar](250)NULL,
			[CurrentSaleBuyer2FullName][varchar](250)NULL,
			[CurrentSaleSeller1FullName][varchar](250)NULL,
			[CurrentSaleSeller2FullName][varchar](250)NULL,
			[ConcurrentMtg1LoanAmt][varchar](250)NULL,
			[ConcurrentMtg1Lender][varchar](250)NULL,
			[ConcurrentMtg1LoanType][varchar](250)NULL,
			[ConcurrentMtg2LoanAmt][varchar](250)NULL,
			[ConcurrentMtg2Lender][varchar](250)NULL,
			[ConcurrentMtg2LoanType][varchar](250)NULL,
			[PrevSaleTransactionId][varchar](250)NULL,
			[PrevSaleRecordingDate][varchar](250)NULL,
			[PrevSalesPrice][varchar](250)NULL,
			[PrevSaleBuyer1FullName][varchar](250)NULL,
			[PrevSaleBuyer2FullName][varchar](250)NULL,
			[PrevSaleSeller1FullName][varchar](250)NULL,
			[PrevSaleSeller2FullName][varchar](250)NULL,
			[TotalOpenLienNbr][varchar](250)NULL
		   
		) ON [PRIMARY]

		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		-------Initial Extract----
		---------INSERT MATCHED------
		----Insert into x_Custom_OUTPUT ([Input Unique ID],
		----[INPUTLAT],
		----[INPUTLON]
		----,PropertyID)
		
		----Select DISTINCT
		----[Unique ID]
		----,cast([Latitude] as float)
		----,cast([Longitude] as float)
		----,A.PropertyID
		----FROM dbo.a_PropMatch_WORK_FLANK as A  with(NOLOCK)  join INPUT_RAW_20220505 as B on A.RAW_ID = B.[Unique ID]
		----where (ISNULL(PropertyID,'0') not like '0' and (MultiMatch is null or MultiMatch like 'LU')) 
		


		-------ONGOING MONITOR------
		Insert into [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT] (
		[Input Unique ID]
	  ,[INPUTLAT]
      ,[INPUTLON]
      ,[FIPS]
      ,[Property Status]
	  ,[MATCHTYPE]
      ,[PropertyID]
	  ,[Approxmate Distance])

	  Select A.INPUTKEY,A.INPUTLAT,A.INPUTLON,A.FIPS
	  --,case when MATCHTYPE like 'Property' then 'Property Found' else MATCHTYPE end
	  ,A.MATCHTYPE
	  ,A.MATCHTYPE
	  ,A.PropertyID
	  ,A.APPROX_RADIUS
	  From [zCust_Towerpoint].[dbo].[INPUT_MONITOR_NEW] A
	  --where DATE_ADDED = '2023-07-07'
	  --where PropertyID is not null
	  Order by INPUTKEY

	  --Select count(*) from INPUT_MONITOR_NEW
	  --Select count(*) from a_Propmatch_work_FLANK
	  --Select count(*) from a_asp_in_STD


		Select * From [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT]


		Update [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT]
		SET 
		RunDate = convert(date,Getdate())
		

		Update [zCust_Towerpoint].[dbo].[a]
		set [Coverage Status] = TaxrollActive
		--Select D_Flag 
		FROM [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT] a 
			JOIN [Global].[dbo].[COunty]  b  with(NOLOCK)
			ON a.FIPs = b.FIPsCode


		

		Update [zCust_Towerpoint].[dbo].[A]
		Set 
		A.[APN] = B.FormattedAPN
		,A.[SitusFullStreetAddress] = B.SitusStdFullStreetAddress
		,A.[SitusHouseNbr] = B.SitusStdHouseNbr
		,A.[SitusHouseNbrSuffix] = B.SitusStdHouseNbrSuffix
		,A.[SitusDirectionLeft] = B.SitusStdDirectionLeft
		,A.[SitusStreet] = B.SitusStdStreet
		,A.[SitusMode] = B.SitusStdMode
		,A.[SitusDirectionRight] = B.SitusStdDirectionRight
		,A.[SitusUnitType] = B.SitusStdUnitType
		,A.[SitusUnitNbr] = B.SitusStdUnitNbr


		,A.[SitusCity] = B.SitusStdCity
		,A.[SitusState] = B.SitusStdState
		,A.[SitusZIP5] = B.SitusStdZIP5
		,A.[SitusZIP4] = B.SitusStdZIP4
		--,A.[SitusCarrierCode] = B.SitusStdCarrierCode
		--,A.[SitusLatitude] = cast(B.SitusLatitude as float)
		--,A.[SitusLongitude] = cast(B.SitusLongitude as float)
		--,A.[SitusGeoStatusCode] = B.SitusGeoStatusCode
		,A.[LandUseCode] = B.StdLandUseCode
		,A.[StateLandUseCode] = B.StateLandUseCode
		,A.[CountyLandUseCode] = B.CountyLandUseCode
		,A.[Zoning] = B.Zoning
		,A.[SitusCensusTract] = B.SitusCensusTract
		,A.[SitusCensusBlock] = B.SitusCensusBlock
		,A.[LotSizeAcres] = B.LotSizeAcres


		,A.[Owner1CorpInd] = B.OwnerStd1CorpInd

		,A.[Owner1LastName] = B.OwnerStd1LastName
		,A.[Owner1FirstName] = B.OwnerStd1FirstName
		,A.[Owner1MiddleName] = B.OwnerStd1MiddleName
		,A.[Owner1Suffix] = B.OwnerStd1Suffix
		,A.[Owner2CorpInd] = B.OwnerStd2CorpInd
		,A.[Owner2LastName] = B.OwnerStd2LastName
		,A.[Owner2FirstName] = B.OwnerStd2FirstName
		,A.[Owner2MiddleName] = B.OwnerStd2MiddleName
		,A.[Owner2Suffix] = B.OwnerStd2Suffix


		,A.[OwnerNAME1FULL] = B.OwnerStdNAME1FULL
		,A.[OwnerNAME2FULL] = B.OwnerStdNAME2FULL
		--,A.[OwnerOccupied] = B.OwnerOccupied
		--,A.[Owner1OwnershipRights] = B.OwnerStd1OwnershipRights
		,A.[MailingFullStreetAddress] = B.MailingStdFullStreetAddress
		,A.[MailingHouseNbr] = B.MailingStdHouseNbr
		,A.[MailingHouseNbrSuffix] = B.MailingStdHouseNbrSuffix
		,A.[MailingDirectionLeft] = B.MailingStdDirectionLeft
		,A.[MailingStreet] = B.MailingStdStreet
		,A.[MailingMode] = B.MailingStdMode
		,A.[MailingDirectionRight] = B.MailingStdDirectionRight
		,A.[MailingUnitType] = B.MailingStdUnitType
		,A.[MailingUnitNbr] = B.MailingStdUnitNbr


		,A.[MailingCity] = B.MailingStdCity
		,A.[MailingState] = B.MailingStdState
		,A.[MailingZIP5] = B.MailingStdZIP5
		,A.[MailingZIP4] = B.MailingStdZIP4
		--,A.[MailingCarrierCode] = B.MailingStdCarrierCode
		,A.[MailOptOut] = B.MailingOptOut
		,A.[MailingCOName] = B.MailingCareOfName
		,A.[AssdTotalValue] = B.AssdTotalValue
		,A.[AssdLandValue] = B.AssdLandValue
		,A.[AssdImprovementValue] = B.AssdImprovementValue
		,A.[MarketTotalValue] = B.MarketTotalValue
		,A.[TaxAmt] = B.TaxAmount
		,A.[TaxYear] = B.TaxYear
		,A.[TaxDeliquentYear] = B.TaxDeliquentYear1
		,A.[AssdYear] = B.AssdYear
		,A.[YearBuilt] = B.YearBuilt
		,A.[EffectiveYearBuilt] = B.EffectiveYearBuilt
		,A.[BuildingConditionCode] = B.BuildingConditionCode
		,A.[ConstructionTypeCode] = B.ConstructionTypeCode
		,A.[BuildingQualityCode] = B.BuildingQualityCode
		,A.[RoofCoverCode] = B.RoofCoverCode
		,A.[RoofTypeCode] = B.RoofTypeCode
		,A.[StoriesNbrCode] = B.StoriesNbrCode
		,A.[LandLot] = B.LandLot
		,A.[Block] = B.Block
		,A.[Section] = B.Section
		,A.[District] = B.District
		,A.[Municipality] = B.Municipality
		,A.[SubdivisionName] = B.SubdivisionName
		,A.[LegalDescription] = B.LegalDescription
		,A.[CurrentSaleTransactionId] = B.CurrentSaleTransactionId
		,A.[CurrentSaleRecordingDate] = B.CurrSaleRecordingDate
		,A.[CurrentSaleDocumentType] = B.CurrSaleDocumentType
		,A.[CurrentSalesPrice] = B.CurrSalesPrice
		,A.[CurrentSaleBuyer1FullName] = B.CurrSaleBuyer1FullName
		,A.[CurrentSaleBuyer2FullName] = B.CurrSaleBuyer2FullName
		,A.[CurrentSaleSeller1FullName] = B.CurrSaleSeller1FullName
		,A.[CurrentSaleSeller2FullName] = B.CurrSaleSeller2FullName
		,A.[ConcurrentMtg1LoanAmt] = B.ConCurrMtg1LoanAmt
		,A.[ConcurrentMtg1Lender] = B.ConCurrMtg1Lender
		,A.[ConcurrentMtg1LoanType] = B.ConCurrMtg1LoanType
		,A.[ConcurrentMtg2LoanAmt] = B.ConCurrMtg2LoanAmt
		,A.[ConcurrentMtg2Lender] = B.ConCurrMtg2Lender
		,A.[ConcurrentMtg2LoanType] = B.ConCurrMtg2LoanType
		,A.[PrevSaleTransactionId] = B.PrevSaleTransactionId
		,A.[PrevSaleRecordingDate] = B.PrevSaleRecordingDate
		,A.[PrevSalesPrice] = B.PrevSalesPrice
		,A.[PrevSaleBuyer1FullName] = B.PrevSaleBuyer1FullName
		,A.[PrevSaleBuyer2FullName] = B.PrevSaleBuyer2FullName
		,A.[PrevSaleSeller1FullName] = B.PrevSaleSeller1FullName
		,A.[PrevSaleSeller2FullName] = B.PrevSaleSeller2FullName


		--,A.[MailingForeignAddressInd] = B.MailForeignAddrInd
		,A.[TotalOpenLienNbr] = B.TotalOpenLienNbr
		--,A.[TotalOpenLienAmt] = B.TotalOpenLienAmt
		--,A.[CurrentAVMValue] = convert(bigint,B.FirstAmericanCurrentAVM)
		--,A.[vValuationDate] = convert(date,B.VALUATIONDATE)
		--,A.[HOA1Name] = B.HOA_1_Name
		--,A.[PFCFlag] = B.PFCFlag
		--,A.[PFCIndicator] = B.PFCIndicator

		,A.[Event Status] = 'Event Found'
		

		--Select C.OwnerNAME1FULL, B.OwnerStdNAME1FULL,B.MailingSTDFullStreetAddress,B.MailingOptOut
		From  [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT] as A join [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) 
		on A.PropertyID = B.PropertyID
		join [zCust_Towerpoint].[dbo].[INPUT_MONITOR_NEW] as C with(NOLOCK) on A.[Input Unique ID] = C.INPUTKEY
		and A.PropertyID = C.PROPERTYID
		where A.PropertyID is not null
		----Added 20220608 for Monitor portion - PER CL:
			----MONITORING FOR:
			-----1 - OWNER NAME CHANGE
			-----2 - CURRENTSALETRANSACTIONID change
			-----3 - TOTAL OPEN LINE NBR CHANGE

			------20220621 - Per CL - Changing monitoring to ONLY monitor for Owner Name changes (of any kind)----

		AND 
		(ISNULL(B.OwnerStdNAME1FULL,'') <> ISNULL(C.OwnerNAME1FULL,'') 
		--OR
		--ISNULL(B.CurrentSaleTransactionId,'') <> ISNULL(C.CurrentSaleTransactionId,'') OR
		--ISNULL(B.TotalOpenLienNbr,'') <> ISNULL(C.TotalOpenLienNbr,'')
		)
		-------20230807 - Changed Criteria PER TRAVIS to:
		----ONLY OWNER NAME MUST BE POPULATED AND 
		----OWNER NAME MUST NOT BE 
		----    ISNULL(OwnerStdNAME1FULL,'') not like ''
		----	and ISNULL(OwnerStdNAME1FULL,'') not like 'NOT AVAIL%'
		----	and ISNULL(OwnerStdNAME1FULL,'') not like '***SUMMARY%'
		----	and ISNULL(OwnerStdNAME1FULL,'') not like 'NOT GIVEN'
		----	and ISNULL(OwnerStdNAME1FULL,'') not like 'OWNER RECORD'
		----	and ISNULL(OwnerStdNAME1FULL,'') not like 'NONE'


		--AND ISNULL(B.OwnerStdNAME1FULL,'') not like ''
		--AND ISNULL(B.MailingSTDFullStreetAddress,'') not like ''
		--AND ISNULL(B.MailingStdCity,'') not like ''
		--AND ISNULL(B.MailingStdState,'') not like ''
		--AND ISNULL(B.MailingStdZIP5,'') not like ''
		--AND B.MailingOptOut is null 


		    and ISNULL(B.OwnerStdNAME1FULL,'') not like ''
			and ISNULL(B.OwnerStdNAME1FULL,'') not like 'NOT AVAIL%'
			and ISNULL(B.OwnerStdNAME1FULL,'') not like '***SUMMARY%'
			and ISNULL(B.OwnerStdNAME1FULL,'') not like 'NOT GIVEN'
			and ISNULL(B.OwnerStdNAME1FULL,'') not like 'OWNER RECORD'
			and ISNULL(B.OwnerStdNAME1FULL,'') not like 'NONE'


	
		Delete from [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		where [Event Status] is null


		Select * From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]

	
		Update [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT]
		set [Coverage Status] = 'In Coverage'
		where PropertyID is not null and PropertyID not like '0' 
		and PropertyID not like ''
		and [Coverage Status] like 'Not In Coverage'

			


		Update  [zCust_Towerpoint].[dbo].[a]
		SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_Towerpoint].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ADS__S22_LienPosVerification].[dbo].[a_ASP_IN_STD] b
		on a.[Input Unique ID] = b.Raw_ID


		Select [AddressStandardization], count(*) From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [AddressStandardization]
		
		Select [Coverage Status], count(*) From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [Coverage Status]
		

		Select [Property Status], count(*) From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [Event Status]

		
	
		Select [Event Status],[Property Status],count(*)  From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [Event Status],[Property Status]

		Select [Event Status],[Property Status],[Coverage Status],count(*)  From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]
		Group by [Event Status],[Property Status],[Coverage Status]
		Order by [Event Status],[Property Status],[Coverage Status]



		Select count(*) From [zCust_Towerpoint].[dbo].[x_custom_OUTPUT]

		--Select A.[Input Unique ID] ,A.PropertyID,A.OwnerNAME1FULL,A.CurrentSaleRecordingDate,A.TotalOpenLienNbr,A.CurrentSaleTransactionId 
		--,B.OwnerNAME1FULL, B.CurrentSaleTransactionId, B.TotalOpenLienNbr
		--From x_custom_OUTPUT as A join INPUT_MONITOR_NEW_20220610 as B on A.[Input Unique ID] = B.INPUTKEY
		--and A.PropertyID = B.PropertyID
		--where A.TotalOpenLienNbr = B.TotalOpenLienNbr
		----and A.OwnerNAME1FULL = B.OwnerNAME1FULL
		--and ISNULL(A.CurrentSaleTransactionId,'') = ISNULL(B.CurrentSaleTransactionId,'') 
		--Order by A.CurrentSaleRecordingDate

		

		
	

END





