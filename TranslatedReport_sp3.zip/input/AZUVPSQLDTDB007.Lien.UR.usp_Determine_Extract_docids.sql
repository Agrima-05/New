/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Determine_Extract_docids | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:    <Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_Determine_Extract_docids] @ERROR VARCHAR(500) OUTPUT
AS
--
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Determine_Extract_docids'
		,N'Started'

	--
	--determine the last time the tracker ran
	--
	DECLARE @date DATETIME2 = (
			SELECT max(m_update_date)
			FROM [lien].[UR].[document_transaction_log_tracker]
			)

	--
	--find all the doc_id that had a change since the last update ran
	--
	DROP TABLE

	IF EXISTS #doc
		SELECT b.Doc_id
			,b.m_update_date
		INTO #doc
		FROM (
			SELECT a.doc_id
				,a.m_update_date
				,ROW_NUMBER() OVER (
					PARTITION BY a.doc_id ORDER BY a.m_update_date DESC
					) AS ROW4
			FROM (
				SELECT l.Doc_id
					,l.m_update_date
				FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
				WHERE l.m_update_date > isnull(@date, '19000101')
				
				UNION ALL
				
				SELECT n.Doc_id
					,l.m_update_date
				FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
				INNER JOIN [lien].[ur].[NAME] n ON n.name_id = l.name_id
				WHERE l.m_update_date > isnull(@date, '19000101')
					AND l.Name_id IS NOT NULL
				
				UNION ALL
				
				SELECT n.Doc_id
					,l.m_update_date
				FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
				INNER JOIN [lien].[ur].[Property] n ON n.Property_id = l.Property_id
				WHERE l.m_update_date > isnull(@date, '19000101')
					AND l.Property_id IS NOT NULL
				
				UNION ALL
				
				SELECT n.Doc_id
					,l.m_update_date
				FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
				INNER JOIN [lien].[ur].[Reference] n ON n.Reference_id = l.Reference_id
				WHERE l.m_update_date > isnull(@date, '19000101')
					AND l.Reference_id IS NOT NULL
				) a
			WHERE doc_id IS NOT NULL
			) b
		WHERE row4 = 1

	BEGIN TRANSACTION

	INSERT INTO [lien].[UR].[Lien_Extract_doc_id] (
		Doc_id
		,m_update_date
		)
	SELECT Doc_id
		,m_update_date
	FROM #doc

	--WHERE (
	--        SELECT count(1) AS cnt
	--        FROM lien.[UR].[Lien_Extract_doc_id] k
	--        WHERE k.doc_id = b.doc_id
	--            AND k.m_update_date = b.m_update_date
	--        ) = 0
	-- SELECT max(m_update_date) FROM [UR].[Lien_Extract_doc_id]
	--
	-- updat the tracker table with last update timestamp inserted in the Lien_Extract_doc_id table
	--
	INSERT INTO [lien].[UR].[document_transaction_log_tracker] (m_update_date)
	SELECT a.m_update_date
	FROM (
		SELECT max(m_update_date) AS m_update_date
		FROM [lien].[UR].[Lien_Extract_doc_id]
		) a
	WHERE (
			SELECT count(1) AS cnt
			FROM [lien].[UR].[document_transaction_log_tracker]
			WHERE m_update_date IN (
					SELECT max(m_update_date) AS m_update_date
					FROM [lien].[UR].[Lien_Extract_doc_id]
					)
			) = 0
		AND a.m_update_date IS NOT NULL

	COMMIT

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Determine_Extract_docids'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
END CATCH


