SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF





CREATE PROCEDURE [zCust_RenewFinancial].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 

		
	
AS
BEGIN

	SET NOCOUNT ON;


		Select count(*) as  'MatchPct'  From [zCust_RenewFinancial].[dbo].[INPUT_RAW_Taxsource]
		

		--------------------------------------------------
		--SET CONCAT_NULL_YIELDS_NULL off

		--Truncate table [INPUT_RAW_Taxsource]

		--Insert into [INPUT_RAW_Taxsource]([App ID]	,[ADDRESS],	[CITY]	,[STATE],	[ZIP],	[APN])
		--Select 
		--[App id]
		--,[address]
  --    ,[city]
  --    ,[state]
  --    ,[zip]
  --    ,convert(varchar(250),[apn])
	 ---- --Select * 
		------FROM [zCust_RenewFinancial].[dbo].INPUT_RAW_Taxsource
		----Select * 
		--From [INPUT_RAW_20251205]


		Select * From [zCust_RenewFinancial].[dbo].[INPUT_RAW_Taxsource]
		where APN like '%e%'
		



		Truncate table INPUT_IN

		INSERT INTO [zCust_RenewFinancial].[dbo].[INPUT_IN](INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZip,INPUTAPN
		)
		Select  DISTINCT
		LTRIM(RTRIM([App id]))
       ,REPLACE([Address],'  ',' ')
      ,REPLACE([City],'  ',' ')
      ,[State]
      ,[Zip]
      ,REPLACE([APN],',','')
	 	From [zCust_RenewFinancial].[dbo].[INPUT_RAW_Taxsource]
		where ISNULL([App id],'') not like ''

		--Select INPUTKEY,INPUTAPN, cast(INPUTAPN as float) From INPUT_IN
		--where INPUTAPN like '%e+%'

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where INPUTAPN like '%e+%'

		----Check for Dups--
		--Select A.*, B.*  From INPUT_RAW_CUST_Taxsource as A 
		--join INPUT_MONITOR as B on A.UniqueID = B.UniqueID

		Select top 100 * From [zCust_RenewFinancial].[dbo].[INPUT_IN]

		Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_IN]

		Select INPUTKEY,count(*) From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		Group by INPUTKEY
		Having count(*) >1

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where len(INPUTZip) > 10

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where InputAddress like '%  %'

		Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'


		UPDATE [zCust_RenewFinancial].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_RenewFinancial].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_RenewFinancial].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_RenewFinancial].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_RenewFinancial].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2

	
	
	---- INSERT DATA INTO ASP IN TABLE AND SET TRIGGER FOR PROCESS

	  EXEC [zCust_RenewFinancial].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]


	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_RenewFinancial].[dbo].[RenewFinancial]) = 0
				BEGIN
					RETURN;
				END
			ELSE
				BEGIN
					---- 2 min wait periods until ASP is complete
					DECLARE @CheckASP as int
				
						SET @CheckASP = 0

					WHILE @CheckASP = 0
						BEGIN
							WAITFOR DELAY '00:01'
							
						---- Checks for completion ** If not wait again
						SET @CheckASP = (Select COUNT(*) from [zCust_RenewFinancial].[dbo].[RenewFinancial_STD])
						END
				END

			

	---- APPENDS ASP DATA BACK TO DATABASE 

	
		EXEC [zCust_RenewFinancial].[dbo].[usp_100c_sp_ASP_Cust_STD]

		Update [zCust_RenewFinancial].[dbo].[a_ASP_IN_STD]
		set FIPS = RIGHT(('0' + convert(varchar(5),FIPS)),5)
		where FIPS not like '0'

	
		-----------------------------------------------------

		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_RenewFinancial'
		--EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_RenewFinancial'

		
			Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
			 from [zCust_RenewFinancial].[dbo].[a_PropMatch_WORK]
			group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END


		
			Select A.FIPS, B.State, B.[County Name] as COUNTY, A.*
			from [zCust_RenewFinancial].[dbo].[a_PropMatch_WORK] as A 
			join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
			where A.REF_ID is  null
			Order by A.FIPS


			Select A.FIPS, B.State, B.[County Name] as COUNTY, count(*) as TOTAL
			,sum(case when A.REF_ID is not null then 1 else 0 end) as MATCHED_REF_ID
			,sum(case when A.REF_ID is null then 1 else 0 end) as NOT_MATCHED
			from [zCust_RenewFinancial].[dbo].[a_PropMatch_WORK] as A 
			join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
			--where A.REF_ID is not null
			Group by  A.FIPS, B.State, B.[County Name]
			Order by  A.FIPS, B.State, B.[County Name]

			--Select * From INPUT_RAW_20231212
			--where [APP ID]  in ('FL-00205418','FL-00186812','FL-00204137')



				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Renew - Taxsource Batch Counts!!!  Send to Michael Clooten, Katherin Dieterich & FAHQ-DL-TaxSourceEscalations@firstam.com - ' + @Date 
				
				SET @body = '<html><body><H3>Renew Taxsource Batch Count - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> FIPS  </th> <th> STATE </th> <th> COUNTY  </th> <th> TOTAL  </th> <th> MATCHED_REF_ID  </th> <th> NOT_MATCHED  </th></tr>' 
				
			

				SET @xml = 
				CAST(( 
					Select FIPS as 'td','', State as 'td','', County as 'td','', Total as 'td','', Matched_REF_ID as 'td','', NOT_MATCHED as 'td',''
					from (
					Select A.FIPS , B.State, B.[County Name] as COUNTY, count(*) as TOTAL
					,sum(case when A.REF_ID is not null then 1 else 0 end) as MATCHED_REF_ID
					,sum(case when A.REF_ID is null then 1 else 0 end) as NOT_MATCHED
					from [zCust_RenewFinancial].[dbo].[a_PropMatch_WORK] as A 
					join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
					--where A.REF_ID is not null
					Group by  A.FIPS, B.State, B.[County Name])A
					Order by  FIPS, State, County, Total, Matched_REF_ID, NOT_MATCHED 
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))
			
			
		
				Set @body2 = @body + @XML +'</table></body></html> <BR/><BR/>
				'
				
				

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body2,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

		
		
		
END



