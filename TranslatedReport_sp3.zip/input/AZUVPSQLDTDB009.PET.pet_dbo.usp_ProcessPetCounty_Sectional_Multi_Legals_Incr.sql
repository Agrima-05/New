/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_Sectional_Multi_Legals_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================  
-- Author:        <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description:   <Description,,>  
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'  
-- =============================================  
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_Sectional_Multi_Legals_Incr] @fips INT
	,@FeatureName AS VARCHAR(50)
	,@ServiceName AS VARCHAR(50)
	,@FormatId AS VARCHAR(10)
	,@incremental_flag INT
AS
SET @incremental_flag = isnull(@incremental_flag, 0)

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_Sectional_Multi_Legals_Incr'
	,N'Started'

DECLARE @GetDynamicFormat tmpGetDynamicFormat

INSERT INTO @GetDynamicFormat (
	[FeatureName]
	,[ServiceName]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[OutputField]
	,[LongDesc]
	,[Label]
	,[MsgLabel]
	,[Partner]
	,[PartnerType]
	,[WildStart]
	,[DataType]
	,[Required]
	,[Enumeration]
	,[TabIndex]
	,[FromField]
	,[DataTreeIndexes]
	,[FormatChar]
	,[_overlay]
	,[ROW4]
	)
EXEC [pet].[dbo].[GetDynamicFormat] @FeatureName --'TITLE_SERVICES'  
	,@ServiceName --'SUBDIVIDED'  
	,@FormatId --@PPLNT_PLAT_ID_FRMT  

SELECT *
FROM @GetDynamicFormat

UPDATE [PET].[pet_dbo].[t1]
SET t1._overlay = (
		SELECT count(1)
		FROM @GetDynamicFormat t2
		WHERE t2.ROW4 < t1.ROW4
			AND t1.Offset BETWEEN t2.Offset
				AND (t2.Offset + t2.[Length])
		)
FROM @GetDynamicFormat t1

DECLARE @year_pos INT = (
		SELECT p.offset
		FROM @GetDynamicFormat p
		WHERE p.Field = 'Year'
		)
	,@Ref_id INT = NULL --13580129  

SELECT 'Sectional parms' AS aaaa
	,*
FROM @GetDynamicFormat

--IF object_id('Tempdb..pet.pet_tmp.Incr_Sectional_Multi_Legals_Incr_Temp2') IS NOT NULL
	DROP TABLE if exists [pet].[pet_tmp].[Incr_Sectional_Multi_Legals_Incr_Temp2];

SELECT distinct a.REF_ID
	,a.NEO_APN
	,a.NEO_LAND_TYPE
	,a.NEO_TITLE_LEGAL
	,CASE 
		WHEN ltrim(Rtrim(a._field)) = 'TorTeeName'
			THEN CASE 
					WHEN substring(a._value, len(a._value), 1) = '1'
						THEN 'GrantorName'
					WHEN substring(a._value, len(a._value), 1) = '2'
						THEN 'GranteeName'
					ELSE a._field
					END
		ELSE a._field
		END AS _field
	--,Replace(Replace(Replace(ltrim(a._value), 'T', ''), 'C', ''), 'M', '') AS _value  
	--,a._value  
	,CASE 
		WHEN ltrim(Rtrim(a._field)) = 'TorTeeName'
			THEN CASE 
					WHEN substring(a._value, len(a._value), 1) IN (
							'1'
							,'2'
							)
						THEN substring(a._value, 1, len(a._value) - 1)
					ELSE a._value
					END
		ELSE a._value
		END AS _value
	,a.Fips
	,a.ROW4
	,'' AS bookType
INTO [pet].[pet_tmp].[Incr_Sectional_Multi_Legals_Incr_Temp2]
FROM (
	SELECT --top 100    
		t.REF_ID
		,t.NEO_APN
		,t.NEO_LAND_TYPE
		,t.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL
		,t.fips
		,Field AS _field
		,substring(t.NEO_TITLE_LEGAL, Offset, [Length]) AS _value
		,p.ROW4
	
		FROM [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (
				NOLOCK
				,INDEX (idx_fips_neoAPN)
				)
		cross APPLY (
			SELECT *
			FROM [pet].[dbo].[PET_neo_legals] t WITH (
					NOLOCK
					,INDEX (ix_fipsNEO)
					)
			WHERE t.fips = incr.fips
				AND t.neo_apn = incr.neo_apn
				and t.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
				AND t.NEO_LAND_TYPE IN ('SC')
			) t

	OUTER APPLY (
		SELECT *
		FROM @GetDynamicFormat
		) p

	WHERE incr.fips = @fips
		AND incr.NEO_LAND_TYPE IN ('SC')
		--AND (  
		-- @incremental_flag = 0  
		-- OR (  
		--  @incremental_flag = 1  
		--  AND incr.neo_apn IS NOT NULL  
		--  )  
		-- )  
	) a
WHERE isnull(a._value, '') > ''

--select * from pet.pet_tmp.Incr_Sectional_Multi_Legals_Incr_Temp2  
--Select * from #temp  
CREATE UNIQUE INDEX ix_ref_id_field ON [pet].[pet_tmp].[Incr_Sectional_Multi_Legals_Incr_Temp2] (
	Fips
	,REF_ID
	,NEO_APN
	,NEO_TITLE_LEGAL
	,_field
	)

BEGIN TRANSACTION

INSERT INTO [PET].[dbo].[Pet_LabelColumns_Multi_Legals] (
	[REF_ID]
	,NEO_APN
	,[NEO_LAND_TYPE]
	,[NEO_TITLE_LEGAL]
	,[_field]
	,[_value]
	,fips
	,ROW4
	,bookType
	)
SELECT b.[REF_ID]
	,b.NEO_APN
	,b.[NEO_LAND_TYPE]
	,b.[NEO_TITLE_LEGAL]
	,b.[_field]
	,b.[_value]
	,b.fips
	,b.ROW4
	,b.bookType
FROM [pet].[pet_tmp].[Incr_Sectional_Multi_Legals_Incr_Temp2] b with(nolock,index(ix_ref_id_field))
LEFT JOIN [PET].[dbo].[Pet_LabelColumns_Multi_Legals] c with(nolock,index([ClusteredIndex-20170302-172737])) ON c.Fips = b.Fips
	AND c.REF_ID = b.REF_ID
	AND c.NEO_APN = b.NEO_APN
	AND c.NEO_TITLE_LEGAL = b.NEO_TITLE_LEGAL
	AND c._field = b._field
WHERE c.ref_id IS NULL
OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

COMMIT

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_Sectional_Multi_Legals_Incr'
	,N'Ended'


