SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_NOD_NOS]

AS
BEGIN

	SET NOCOUNT ON;

	
	

	------PULL ACTIVE HOA LIEN RECORDS-----IF multiple records per lien due to owners - pull only 1 owner per NH 20180322---
	 TRUNCATE TABLE  dbo.HOA_NOD_NOS

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[NOD_NOS_Recorded_Document_Number],
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],C.INPUTKEY ,NULL
	 --into dbo.HOA_NOD_NOS
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	 --on A.NEW_REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUTKEY
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
	 join  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DM_Data] as D on A.REF_ID = D.Property_ID   

	 -------20191114 - Added to use new doc type lookup table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as E with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(E.DocType))
	
	 where B.REF_ID is not null
	 AND  E.HOA_Data_Type like 'NOD/NOS/REO'
	 AND 
	 (convert(DATE,convert(varchar(10),A.NOD_NOS_Recording_Date)) > convert(date,D.[Date_Transfer]) OR
	  D.[Date_Transfer] is null)
	 --and 
	 --AND OWNSequence = 1
	 and 
	 --(convert(DATE,convert(varchar(10),A.RecordingDate)) >= convert(date,C.CurrSaleRecordingDate)
	 --OR C.CurrSaleRecordingDate is null)
	 (convert(DATE,convert(varchar(10),A.NOD_NOS_Recording_Date)) > convert(date,C.[MAX_NODDATE])
	 OR C.[MAX_NODDATE] is null)
	 and A.NOD_NOS_Recording_Date is not null

	 --AND A.[DocType] not like 'HOA'
	 ----------20180830 - Commented out name match per BR----------
	 --AND (case when C.InputBorrower is null or C.InputBorrower like '' then C.OwnerStdName1Full else C.InputBorrower end) like '%' + left(A.OWNLastName,4) + '%'
	 --AND A.OWNLastName is not null and A.OWNLastName not like ''



	 ------------------Added 20180912 to pull from LIEN fields as NOD/NOS fields are not consistently populated in HOA Lien table......--------

	  Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select  A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment]
,convert(date,convert(varchar(10),A.[RecordingDate]))
,A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[DocumentId],
A.[LienAmount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],C.INPUTKEY ,NULL
--	Select A.REF_ID, A.DocumentID, convert(date,convert(varchar(10),A.[RecordingDate]))
--,A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[DocumentId],D.[Date_Transfer], A.[RecordingDate], C.[MAX_NODDATE]
	 --into dbo.HOA_NOD_NOS
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	 --on A.NEW_REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUTKEY
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
	 join  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DM_Data] as D on A.REF_ID = D.Property_ID  

	  -------20191114 - Added to use new doc type lookup table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as E with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(E.DocType))
	
	 where B.REF_ID is not null
	  AND  E.HOA_Data_Type like 'NOD/NOS/REO'
	----Commented out 20191114--
	--AND A.DocType in (Select distinct HOA_Doc_Type  FROM [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705]
		--	where Full_Name like '%notice%'
		--	and Full_Name not like '%Release%'
		--	and Full_Name not like '%Rescission%'
		--	and Full_Name not like '%Cancella%')
	-----------------------REmoved 20180917 per Bill------------
	-----------------------UPDATE 20180917 per MS to return recording if more recent than 6 months prior to most recent conveyance----------------
	----Commented out 20191114--
	 --AND A.[DocType] not like 'HOA'
	 AND 
	 (convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,convert(datetime,D.[Date_Transfer])-183) OR
	  D.[Date_Transfer] is null)
	 --and 
	 --AND OWNSequence = 1
	 and 
	 --(convert(DATE,convert(varchar(10),A.RecordingDate)) >= convert(date,C.CurrSaleRecordingDate)
	 --OR C.CurrSaleRecordingDate is null)
	 (convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,C.[MAX_NODDATE])
	 OR C.[MAX_NODDATE] is null)
	 and A.[RecordingDate] is not null


	 --Select * From HOA_NOD_NOS

	  --   Insert into HOA_NOD_NOS([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
   --        ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		 --  ,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
	  --Select 
	  --PropertyID, FIPS, REF_ID, PropertyID, '2018.1005.563', '2018.1005.563','SLE','20181005','2018-10-05',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	  --,'1','NV4531',UPPER('Diamond Point Homeowners Association')
	  --,'2014.0224.1241'
	  --,'2018-10-05', '2018.1005.563'
	  --From INput_MONITOR
	  --where INPUTKEY = 'NV4531'


	

		--Select * From [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705]
		--where 
		----FULL_NAME like '%notice%def%'
		----OR 
		--FULL_NAME like '%notice%sal%'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1012.1282', '2018.1012.1282','SLE','20181012','2018-10-12',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('BARRINGTON MONTEROSSA OWNERS ASSOCIATION INC')
		,'2018.0108.2290'----Reference Number
		,'2018-10-12'
		,'2018.1012.1282' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV9966'



		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1022.416', '2018.1022.416','SLE','20181022','2018-10-22',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('ALEXIS HEIGHTS UNIT OWNERS ASSOCIATION')
		,'2018.0906.2020'----Reference Number
		,'2018-10-22'
		,'2018.1022.416' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV1866'


		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1022.426', '2018.1022.426','SLE','20181022','2018-10-22',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('FIFTH AND FARM COMMUNITY ASSOCIATION')
		,'2018.0906.2015'----Reference Number
		,'2018-10-22'
		,'2018.1022.426' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV12495'



		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1105.1373', '2018.1105.1373','SLE','20181105','2018-11-05',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('CANYON GATE HOMEOWNERS ASSOCIATION INC')
		,'2018.0926.2364'----Reference Number
		,'2018-11-05'
		,'2018.1105.1373' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV13403'


			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1106.2742', '2018.1106.2742','SLE','20181106','2018-11-06',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('GREEN VALLEY SOUTH OWNERS ASSOCIATION')
		,'2018.0426.821'----Reference Number
		,'2018-11-06'
		,'2018.1106.2742' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV13365'


		
			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.1109.2000', '2018.1109.2000','SLE','20181109','2018-11-09',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('ONE LAS VEGAS HOMEOWNERS ASSOCIATION')
		,'2018.0921.1511'----Reference Number
		,'2018-11-09'
		,'2018.1109.2000' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'NV14700'

		---------------------------------
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
		,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME
		,OAReference,NOD_NOS_Recording_Date,NOD_NOS_Recorded_Document_Number)
		Select 
		PropertyID, FIPS, REF_ID, PropertyID, '2018.113015', '2018.113015','SLE','20181113','2018-11-13',NULL,'1','1',convert(date,Getdate()),'1',convert(date,Getdate())
		,'1',INPUTKEY,UPPER('MCCLEAN GARDENS CONDO')
		--,'2018.0921.1511'----Reference Number
		,NULL----Reference Number
		,'2018-11-13'
		,'2018.113015' -----Repeat NOD doc number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INput_MONITOR]
		where INPUTKEY = 'DC418'


	

		


		--Select * From INput_MONITOR
		--where INPUTKEY  = 'NV5548'

	  


	 


	-- Select A.REF_ID, A.DocumentID, convert(date,convert(varchar(10),A.[RecordingDate]))
	--,A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],A.[DocumentId],D.[Date_Transfer], A.[RecordingDate], C.[MAX_NODDATE]
	-- FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	-- join a_PropMatch_WORK_FLANK as B with(NOLOCK)
	--  on A.REF_ID = B.REF_ID
	-- join x_custom_OUTPUT as C on B.RAW_ID = C.INPUTKEY
	-- join  [w_DM_Data] as D on A.REF_ID = D.Property_ID  
	-- where B.REF_ID is not null
	-- AND A.DocType in (Select distinct HOA_Doc_Type  FROM [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705]
	--		where Full_Name like '%notice%'
	--		and Full_Name not like '%Release%'
	--		and Full_Name not like '%Rescission%'
	--		and Full_Name not like '%Cancella%')
	-- AND 
	-- --(convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,D.[Date_Transfer]) OR
	-- -- D.[Date_Transfer] is null)
	-- --and 
	-- (convert(DATE,convert(varchar(10),A.[RecordingDate])) > convert(date,C.[MAX_NODDATE])
	-- OR C.[MAX_NODDATE] is null)
	-- and A.[RecordingDate] is not null
	-- and A.REF_ID = 83804612


	

	 --Select top 10 * From [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]
      ,[NOD_NOS_Recorded_Page]     ,[NOD_NOS_Recorded_Document_Number]      
	  ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
            ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
      ,[INPUTKEY]      ,[RecordNumber]
	  ,[SUP]
	  )
	 Select A.Lic_PropertyID    ,convert(int,[FipsCode])      ,F.REF_ID      ,[DetailDocumentType]      ,convert(varchar(10),[RecordingDt])      ,[LienAmount]      ,convert(varchar(10),[RecordingDt]) ,[NMD_document_Book]     
		   ,[NMD_document_Page]     
		   ,[Fmt_NMD_document_number]      
		   ,A.[Owner1LastName]      ,left([Owner1FirstName],60)     ,left([Owner1MiddleName],60)      ,left([Owner2FirstName] ,200)     ,left([Owner2MiddleName],10)      ,left([SitusStdFullStreetAddress],200)
      ,left([SitusStdCity],100)       ,left([SitusStdState],2)      ,left([SitusStdZIP5] ,15)     ,left([FormattedAPN] ,200)     
	  ,left([SitusStdFullStreetAddress],200)           ,left([SitusStdCity],100)      ,[SitusStdState],left([SitusStdZIP5] ,15)  
	 ,C.INPUTKEY ,NULL	 
	 ,'Y'
	 --FROM  [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 --Select * 
	  FROM  [Data].[dbo].[HOA_Lien_Default_Sup]  A with(NOLOCK)
	   join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PropertyID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
	   -------20191114 - Added to use new doc type lookup table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as DOCTYPE with(NOLOCK) on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(DOCTYPE.DocType))
	----Commented out 20191114---
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]

	  join  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DM_Data] as E on F.REF_ID = E.Property_ID  
	 where B.PropertyID is not null
	  AND  DOCTYPE.HOA_Data_Type like 'NOD/NOS/REO'
	  AND (convert(DATE,convert(varchar(10),A.RecordingDt)) > convert(date,E.[Date_Transfer]) OR
	  E.[Date_Transfer] is null)
	 and  (convert(DATE,convert(varchar(10),A.RecordingDt)) > convert(date,C.[MAX_NODDATE])
	 OR C.[MAX_NODDATE] is null)
	 and A.RecordingDt is not null
	 -----Commented out 20191114--
	 --AND D.HOA_Data_Type   in ('NDF','NOD/NOS/REO/Release','Partial Release','PRL','REL','REQ','SBT','SLE')
	  ----------20180830 - Commented out name match per BR----------
	  --AND (case when C.InputBorrower is null or C.InputBorrower like '' then C.OwnerStdName1Full else C.InputBorrower end) like '%' + left(A.Owner1LastName,4) + '%'
	  -- AND A.Owner1LastName is not null and A.Owner1LastName not like ''
	   and A.RELEASED is null

	  --Select top 10 * FRom [Data].[dbo].[HOA_Lien_sup]

	  ------------------------------20180917 - Added to exclude NOD/NOS's that have been released--------------------
	  Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	  --Select A.INPUTKEY, A.DocumentID, A.REcordingdate, A.DocType,C.Released, C.ReleaseDocNumber, C.FATimestamp , C.NMD_document_number_Raw
	  From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] as A join 
	  [Assr].[dbo].[Assr] as B with (NOLOCK) on A.REF_ID = B.REF_ID
	  join [data].[dbo].[HOA_Lien_Default_Sup] as C with(NOLOCK) on B.LIC_PropertyID = C.LIC_PropertyID
	  where Right(Fmt_NMD_document_number,4) = Right(DocumentID,4)
	  and C.Released = 'Y'



	  Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		--Select A.INPUTKEY, A.DocumentID, A.REcordingdate, A.DocType,C.DocumentID, C.DocType, C.REcordingDate,C.OAReference
		--,C.OAReferenceAlt
	  From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] as A  
	  join [HOA].[dbo].[HOA_Lien] as C with(NOLOCK) on A.REF_ID = C.REF_ID
	  where 
	  (Right(LTRIM(RTRIM(A.DocumentID)),4) = Right(LTRIM(RTRIM(C.OAReference)),4)
	  OR
	  Right(LTRIM(RTRIM(A.DocumentID)),4) = Right(LTRIM(RTRIM(C.OAReferenceAlt)),4)
	  )
	   -------20191114 - Added to use new doc type lookup table---
	   and C.DocType in ( Select DocType From [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]
	   where 
	   ((HOA_Data_Type like 'NOD/NOS/REO/Release' or HOA_Data_Type like 'Partial Release') 
		or HOA_Data_Type like 'release'))
		
		-------Commented out 20191114---
	 --  and C.DocType in ( Select HOA_DOC_TYPE From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
	 --  where 
	 --  ((Full_Name like '%rescission%' or Full_Name like '%release%') and FUll_Name like '%notice%'))



	  --Select A.INPUTKEY, A.DocumentID, A.REcordingdate, A.DocType,C.Released, C.ReleaseDocNumber, C.FATimestamp 
	  --From HOA_NOD_NOS as A join 
	  --Assr.dbo.Assr as B with (NOLOCK) on A.REF_ID = B.REF_ID
	  --join data.[dbo].[HOA_Lien_Default_Sup] as C with(NOLOCK) on B.LIC_PropertyID = C.LIC_PropertyID
	  --where A.INPUTKEY = 'NV18466'


	  --Select A.FIPS, A.WORK_REF_ID,A.INPUTKEY , A.MAX_LIENDATE, A.MAX_NODDATE, A.NbrofRecordings, A.NOD_NOS_RecordingDate, A.NOD_NOS_RecordedDocumentNumber, A.NOD_NOS_DocType
	  --,B.DATE_ADDED
	  --from x_Custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
	  --WHERE A.INPUTKEY = 'NV18466'

	  --Select * From HOA_NOD_NOS
	  -- WHERE INPUTKEY = 'NV18466'

	  -- --Select * From Assr.dbo.Assr with(NOLOCK)
	  -- --where REF_ID = '82938403'

	  -- Select * From data.[dbo].[HOA_Lien_Default_Sup]
	  -- where FIPS = '32003' and ReleaseDocNumber like '%4507%'


	  -- Select * From HOA.[dbo].[HOA_Lien] with(NOLOCK)
	  -- where  FIPS = '32003' and DocumentID like '%4507'

	  -- Select * From HOA_NOD_NOS
	  -- WHERE INPUTKEY = 'NV18466'


	  -- Select * From [HOA_LIEN_DOC_TYPES_20180705]
	  -- where HOA_DOC_TYPE like 'hadfrl'

	 --Select * From HOA_NOD_NOS



	 --ALTER TABLE dbo.HOA_NOD_NOS ADD [RecordNumber][int]NULL


	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY NOD_NOS_Recording_Date DESC)  AS RowNum
			FROM 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] t  ) r ON t.REF_ID = r.REF_ID and t.[ID] = r.[ID] and t.INPUTKEY = r.INPUTKEY


	--Select * From HOA_NOD_NOS
	--Order by REF_ID
			
			


END





