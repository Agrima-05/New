SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_RELEASE_SUP]

AS
BEGIN

	SET NOCOUNT ON;

	--Select top 10 * From HOA_NOD_NOS_RELEASE
	

	------PULL ACTIVE HOA LIEN RECORDS-----IF multiple records per lien due to owners - pull only 1 owner per NH 20180322---
	 TRUNCATE TABLE  dbo.[HOA_LIEN_RELEASE]

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]   ,LIEN_DOC_NUMBER   ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end,
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY,LIEN_DOC_NUMBER ,NULL
	 --,B.*
	 --Select A.*
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	   -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	 where ISNULL(B.REF_ID,'') not like ''
	 ----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	--AND  LTRIM(RTRIM(A.DocType)) not like 'HADFRL'
	AND (
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-','')
		OR
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-','')
	)
	
	AND B.RELEASED_YN is null



	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]   ,LIEN_DOC_NUMBER   ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end,
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY,LIEN_DOC_NUMBER ,NULL
	 --,B.*
	 --Select A.*
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	    -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	 where ISNULL(B.REF_ID,'') not like ''
	 AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	--AND  LTRIM(RTRIM(A.DocType)) not like 'HADFRL'
	AND (
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = left(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),4) + 
		Right(left(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),8),4) + 
		SUBSTRING((Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) ), PATINDEX('%[^0]%', (Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) )), 
		LEN((Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) )))
		OR
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = left(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),4) + 
		Right(left(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),8),4) + 
		SUBSTRING((Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) ), PATINDEX('%[^0]%', (Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) )), 
		LEN((Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) )))
		
		
	)
	
	AND B.RELEASED_YN is null


	


	--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
	--where HOA_DOC_TYPE in ('HALNRL','HADFRL')


	--Select A.*, D.*  FROM [HOA].[dbo].[HOA_Lien] A with(NOLOCK) 
	--join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	-- on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	-- where A.REF_ID = '82859652' 
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	
	--Select *  FROM NOD_TRACKING_HIST where REF_ID = '82859652'


	--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
	--where [HOA_Doc_Type] = 'hadfrl'


	 --Select top 10 * From [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
            ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
      ,[INPUTKEY]   ,LIEN_DOC_NUMBER   ,[RecordNumber]
	  ,[SUP]
	  )
	 Select A.Lic_PropertyID    ,convert(int,[FipsCode])      ,F.REF_ID      ,[DetailDocumentType]      ,convert(varchar(10),[RecordingDt])      ,[LienAmount]     
	  ,convert(varchar(10),[RecordingDt]) 
	  ,[NMD_document_Book]     
		   ,[NMD_document_Page]     
		   ,[Fmt_NMD_document_number]     
		--, [ReleaseDate]      ,A.[ReleaseBook]
  --    ,A.ReleasePage     ,A.ReleaseDocNumber 
		   ,[Owner1LastName]      ,left([Owner1FirstName],60)     ,left([Owner1MiddleName],60)      ,left([Owner2FirstName] ,200)     ,left([Owner2MiddleName],10)      ,left([SitusStdFullStreetAddress],200)
      ,left([SitusStdCity],100)       ,left([SitusStdState],2)      ,left([SitusStdZIP5] ,15)     ,left([FormattedAPN] ,200)     
	  ,left([SitusStdFullStreetAddress],200)           ,left([SitusStdCity],100)      ,[SitusStdState],left([SitusStdZIP5] ,15)  
	 ,C.INPUTKEY ,LIEN_DOC_NUMBER,NULL	 
	 ,'Y'
	 --FROM  [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 --Select B.RAW_ID, A.*, D.* 
	  FROM  [Data].[dbo].[HOA_Lien_Release_Sup]  A with(NOLOCK)
	   join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PropertyID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as C on B.RAW_ID = C.INPUTKEY
	    -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(D.DocType))
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]
	 where B.PropertyID is not null
	 and A.RecordingDt is not null
	  AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	 --AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	 AND 
	(
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(Org_Fmt_NMD_document_number,'.',''),' ',''),'-','')
		
	)
	AND C.RELEASED_YN is null


	


	-------Get Lien Releases-----

	  Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      
	  ,[NOD_NOS_Recorded_Document_Number]     
	   ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]  ,LIEN_DOC_NUMBER    ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
--,A.[NOD_NOS_Recorded_Document_Number]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end
,A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY,LIEN_DOC_NUMBER ,NULL
	 --,B.*
	 --Select B.*,
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	     -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	 where ISNULL(B.REF_ID,'') not like ''
	   AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	--AND  LTRIM(RTRIM(A.DocType)) not like 'HADFRL'
	AND 
	(
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-','')
		OR
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-','')
	)
	
	AND B.RELEASED_YN is null

	--Select A.*, D.*  FROM [HOA].[dbo].[HOA_Lien] A with(NOLOCK) 
	--join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	-- on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	-- where A.REF_ID = '82859652' 
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	
	--Select *  FROM NOD_TRACKING_HIST where REF_ID = '82859652'


	--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
	--where [HOA_Doc_Type] = 'hadfrl'


	 --Select top 10 * From [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
            ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
      ,[INPUTKEY]    ,LIEN_DOC_NUMBER  ,[RecordNumber]
	  ,[SUP]
	  )
	 Select A.Lic_PropertyID    ,convert(int,[FipsCode])      ,F.REF_ID      ,[DetailDocumentType]      ,convert(varchar(10),[RecordingDt])      ,[LienAmount]      ,convert(varchar(10),[RecordingDt]) ,[NMD_document_Book]     
		   ,[NMD_document_Page]     
		   ,[Fmt_NMD_document_number]      
		   ,[Owner1LastName]      ,left([Owner1FirstName],60)     ,left([Owner1MiddleName],60)      ,left([Owner2FirstName] ,200)     ,left([Owner2MiddleName],10)      ,left([SitusStdFullStreetAddress],200)
      ,left([SitusStdCity],100)       ,left([SitusStdState],2)      ,left([SitusStdZIP5] ,15)     ,left([FormattedAPN] ,200)     
	  ,left([SitusStdFullStreetAddress],200)           ,left([SitusStdCity],100)      ,[SitusStdState],left([SitusStdZIP5] ,15)  
	 ,C.INPUTKEY ,LIEN_DOC_NUMBER,NULL	 
	 ,'Y'
	 --FROM  [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 --Select * 
	  FROM  [Data].[dbo].[HOA_Lien_Release_Sup]  A with(NOLOCK)
	   join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PropertyID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as C on B.RAW_ID = C.INPUTKEY
	     -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(D.DocType))
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]
	 where B.PropertyID is not null
	 and A.RecordingDt is not null
	   AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	 --AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	 AND 
	(
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(Fmt_NMD_document_number,'.',''),' ',''),'-','')
		
	)
	AND C.RELEASED_YN is null




	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY NOD_NOS_Recording_Date DESC)  AS RowNum
			FROM 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE] t  ) r ON t.REF_ID = r.REF_ID and t.[ID] = r.[ID] and t.INPUTKEY = r.INPUTKEY


	--Select * From HOA_NOD_NOS
	--Order by REF_ID
			
			


END





