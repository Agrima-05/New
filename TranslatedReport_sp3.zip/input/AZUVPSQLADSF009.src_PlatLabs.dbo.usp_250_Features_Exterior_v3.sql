SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Exterior_v3]

AS
BEGIN

	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[ExteriorJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[ExteriorJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Exterior, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Exterior') AS j

			DROP TABLE IF EXISTS Table_A
			DROP TABLE IF EXISTS Table_B
			DROP TABLE IF EXISTS Table_C
			DROP TABLE IF EXISTS Table_D
			DROP TABLE IF EXISTS Table_ag

			SELECT MLSID,MLS_LISTING_ID,t.[value] as General INTO [src_PlatLabs].[dbo].[Table_a]
			FROM [src_Platlabs].[features].[ExteriorJSON] t1 with(NOLOCK)
			CROSS APPLY OPENJSON(t1.Exterior) AS t
			WHERE t.[key] = 'General' AND t1.[uid] IN(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_a(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_a(MLSID)

			SELECT MLSID,MLS_LISTING_ID,t.[value] as Style INTO [src_PlatLabs].[dbo].[Table_b]
			FROM [src_Platlabs].[features].[ExteriorJSON] t1 with(NOLOCK)
			CROSS APPLY OPENJSON(t1.Exterior) AS t
			WHERE t.[key] = 'Style' AND t1.[uid] IN(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_b(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_b(MLSID)

			SELECT MLSID,MLS_LISTING_ID,t.[value] as [Pool] INTO [src_PlatLabs].[dbo].[Table_c]
			FROM [src_Platlabs].[features].[ExteriorJSON] t1 with(NOLOCK)
			CROSS APPLY OPENJSON(t1.Exterior) AS t
			WHERE t.[key] = 'Pool' AND t1.[uid] IN(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_c(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_c(MLSID)

			SELECT MLSID, MLS_LISTING_ID, t.[value] as Parking INTO [src_PlatLabs].[dbo].[Table_d]
			FROM [src_Platlabs].[features].[ExteriorJSON] t1 with(NOLOCK)
			CROSS APPLY OPENJSON(t1.Exterior) AS t
			WHERE t.[key] = 'Parking' AND t1.[uid] IN(Select [uid] From [src_Platlabs].[listing].[ListingsRaw_Batch] with(NOLOCK))

						Create INDEX ix_MlsIDListingID on Table_d(MLSID,MLS_LISTING_ID)
						create INDEX ix_MLSID on Table_d(MLSID)

			Select MLSID,MLS_LISTING_ID,[Other Structures] INTO [src_PlatLabs].[dbo].[Table_ag]
					from [src_Platlabs].[features].[ExteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Exterior]) WITH([Other Structures] varchar(1000)) as Other_array
						WHERE Exterior like '%"[Other Structures":%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch])

						Create INDEX ix_MlsIDListingID on Table_ag(MLSID,MLS_LISTING_ID)
						create INDEX ix_MLSID on Table_ag(MLSID)

				Delete FROM [src_PlatLabs].[dbo].[Table_A] WHERE General is NULL
				Delete FROM [src_PlatLabs].[dbo].[Table_B] WHERE Style is NULL
				Delete FROM [src_PlatLabs].[dbo].[Table_C] WHERE [Pool] is NULL
				Delete FROM [src_PlatLabs].[dbo].[Table_D] WHERE Parking is NULL
				Delete FROM [src_PlatLabs].[dbo].[Table_ag] WHERE [Other Structures] is NULL

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END




