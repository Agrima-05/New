/* Source: AZUVNSQLDTDB003.datatree.local | lien_dtdb | INFC.usp_track_insert_rematch_doc_ids | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
CREATE PROCEDURE [lien_dtdb].[INFC].[usp_track_insert_rematch_doc_ids] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY
		TRUNCATE TABLE [trinitytest].[dbo].[Pet_Incr_Deed_Rematch_fips_list]

		--DROP TABLE  
		--IF EXISTS trinitytest.dbo.Pet_Incr_Deed_Rematch_fips_list  
		INSERT INTO [trinitytest].[dbo].[Pet_Incr_Deed_Rematch_fips_list]
		SELECT fips
			,count(1) AS cnt
		--INTO trinitytest.dbo.Pet_Incr_Deed_Rematch_fips_list  
		FROM [assr].[dbo].[Pet_Daily_INCR_Refids]
		GROUP BY fips
		ORDER BY cnt DESC

		--CREATE INDEX idx_fips ON trinitytest.dbo.Pet_Incr_Deed_Rematch_fips_list (fips)  
		--create clustered index idx_fips_apn on lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn (Fips, apn)  
		------SELECT fips
		------	,count(1) AS cnt
		------FROM Lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id
		------GROUP BY fips
		------ORDER BY cnt DESC
		TRUNCATE TABLE [Lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_deed_with_no_ref_id]

		--DROP TABLE  
		--IF EXISTS Lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id  
		INSERT INTO [Lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_deed_with_no_ref_id]
		SELECT d.fips
			,d.deedid
			,d.original_apn
			,d.ur_doc_id
		--INTO Lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id  
		FROM [deed].[dbo].[deed] AS d WITH (
				NOLOCK
				,INDEX (idx_recording_method)
				)
		INNER JOIN [trinitytest].[dbo].[Pet_Incr_Deed_Rematch_fips_list] AS l WITH (
				NOLOCK
				,INDEX (idx_fips)
				) ON l.fips = d.fips
		WHERE d.ref_id IS NULL
			AND d.original_apn IS NOT NULL
			AND d.source_type IN (
				'M'
				,'E'
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		--CREATE INDEX idx_fips ON Lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id (fips)  
		TRUNCATE TABLE [Lien_dtdb].[tmp].[usp_generate_pet_rematch_records_record_to_rematch]

		DROP TABLE

		IF EXISTS [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker]
			CREATE TABLE [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker] (
				[Fips] [int] NOT NULL
				,[DateStarted] [datetime] NULL
				,[DateEnded] [datetime] NULL
				)

		INSERT INTO [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker] (
			[Fips]
			,[DateStarted]
			,[DateEnded]
			)
		SELECT fips
			,NULL AS DateStarted
			,NULL AS DateEnded
		--FROM (Select distinct try_cast(fips as int) as Fips from Lien.ur.document) n  
		FROM (
			SELECT fips
			FROM [trinitytest].[dbo].[Pet_Incr_Deed_Rematch_fips_list]
			) AS n

		--where fips = 39049  
		DECLARE @fips INT = NULL
			,@fips_a CHAR(5) = NULL

		--SET @datefrom_a = Replace(cast(@datefrom AS NVARCHAR(24)), '-', '')  
		--SET @dateto_a = Replace(cast(@dateto AS NVARCHAR(24)), '-', '')  
		--select the starting fips  
		--  
		SELECT @fips = min(fips)
		FROM [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker]
		WHERE DateStarted IS NULL

		----select @fips  
		SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)

		--  
		--begin the loop for the Fips  
		DECLARE @return_value INT = 0
		DECLARE @rowcount INT = 0

		--SELECT *
		--FROM trinitytest.dbo.Pet_Incr_Deed_Rematch_fips_list
		--SELECT *
		--FROM lien_dtdb.tmp.usp_track_insert_rematch_doc_ids_tracker
		--  
		--declare @count int = 0;  
		WHILE @fips IS NOT NULL
			AND @fips > 0
			--and @count <= 1  
			--and @fips = 5007  
		BEGIN
			--set @count = @count + 1;  
			--select @fips  
			--  
			--Udpate the control trable to say you are workig on the fips  
			--  
			BEGIN
				UPDATE [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker]
				SET DateStarted = getdate()
				WHERE fips = @fips
			END

			RAISERROR (
					'%s Busy with Fips %s'
					,0
					,1
					,@fips_a
					,@fips_a
					)
			WITH NOWAIT

			--  
			-- here the logic start that you  wnat to run by fips  
			--  
			--Select @datefrom_a, @dateto_a  
			--create index idx_fips_ref_id_orig_apn_source on deed.dbo.deed (fips, ref_id, original_apn, source_type)  
			--CREATE INDEX idx_fips ON Lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id (fips)  
			--  
			INSERT INTO [Lien_dtdb].[tmp].[usp_generate_pet_rematch_records_record_to_rematch] (ur_doc_id)
			SELECT DISTINCT Ur_doc_id
			FROM [Lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_deed_with_no_ref_id] a WITH (
					NOLOCK
					,INDEX (idx_fips)
					)
			OUTER APPLY (
				SELECT TOP 1 *
				FROM [lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn] p WITH (
						NOLOCK
						,INDEX (idx_fips_apn)
						)
				WHERE p.fips = a.fips
					AND p.apn = a.original_apn
					AND p.Dup_ind = 0
				) p
			WHERE a.fips = @fips
				--  in (select fips  
				--from trinitytest.dbo.Pet_Incr_Deed_Rematch_fips_list) --1003  
				AND p.apn IS NOT NULL --  m.match_reason = 'ref_id found'  
			OPTION (
				RECOMPILE
				,MAXDOP 12
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

			--select * from  Lien_dtdb.tmp.usp_generate_pet_rematch_records_record_to_rematch  
			SET @rowcount = @@rowcount

			RAISERROR (
					'%s updated  %d'
					,0
					,1
					,@fips_a
					,@rowcount
					)

			--  
			--Update the control table to indicate you are done  
			BEGIN
				UPDATE [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker]
				SET DateEnded = getdate()
				WHERE fips = @fips
			END

			--  
			--Select the new fips to process - if non found then @fips would be null  
			--  
			SELECT @fips = min(fips)
			FROM [lien_dtdb].[tmp].[usp_track_insert_rematch_doc_ids_tracker]
			WHERE DateStarted IS NULL

			SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
		END

		BEGIN TRANSACTION A

		INSERT INTO [lien].[UR].[Fix_Request] (
			[doc_id]
			,[m_status_id]
			,[del_PROPERTY_APN_MATCH]
			,[del_PROPERTY_Std_Address]
			,[del_PROPERTYHeader]
			,[del_REFERENCE_Match]
			,[del_NAME_STD_ADDRESS]
			,[update_status]
			,[process_date]
			,[set_m_status_id_to]
			,[reprocess_flag]
			,[reprocess_reason]
			)
		SELECT d.[doc_id]
			,d.[m_status_id]
			,1 AS [del_PROPERTY_APN_MATCH]
			,1 AS [del_PROPERTY_Std_Address]
			,1 AS [del_PROPERTYHeader]
			,0 AS [del_REFERENCE_Match]
			,0 AS [del_NAME_STD_ADDRESS]
			,NULL AS [update_status]
			,getdate() AS [process_date]
			,d.[m_status_id] AS [set_m_status_id_to]
			,0 AS [reprocess_flag]
			,'Post Pet_incremental Deed apn Rematch SEAN' AS [reprocess_reason]
		FROM [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (pk_document)
				)
		WHERE doc_id IN (
				SELECT ur_doc_id
				FROM [Lien_dtdb].[tmp].[usp_generate_pet_rematch_records_record_to_rematch] --trinitytest.dbo.Paul_record_to_rematch  
				)

		INSERT INTO [Lien_dtdb].[tmp].[usp_generate_pet_rematch_records_record_to_rematch_total] (
			ur_doc_id
			,Insert_date
			)
		SELECT Ur_doc_id
			,getdate() AS Insert_date
		FROM [Lien_dtdb].[tmp].[usp_generate_pet_rematch_records_record_to_rematch]

		COMMIT TRANSACTION A
			--select @count  
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


