SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [src_PlatLabs].[dbo].[usp_900_Misc_Counts]
AS
BEGIN

declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

   DECLARE 
        @LogId        INT,
        @StartTime    DATETIME2(3) = GETDATE(),
        @EndTime      DATETIME2(3),
        @ErrorNumber  INT,
        @ErrorMessage NVARCHAR(4000);

    BEGIN TRY
        -- Insert "start" log
        INSERT INTO [Reports].[dbo].[ProcedureLog]
            (ProcedureName, StartTime, UserName, HostName, AppName, Success)
        VALUES
            (OBJECT_NAME(@@PROCID), @StartTime, SUSER_SNAME(), HOST_NAME(), APP_NAME(), 0);

        SET @LogId = SCOPE_IDENTITY()


		--Start the whole process over again
		update [Reports].[dbo].[Platlabs_update_times] set download_ready_to_start = 1
		--------------------------------------------------------


----- UPDATE Global with current Info

update [src_PlatLabs].[dbo].[a]
SET a.isActive = active
from [src_PlatLabs].[dbo].[Platlabs_Global] a JOIN [src_PlatLabs].[dbo].[platlabs_update_config] b with(NOLOCK) on mls_id = MLSId

update [src_PlatLabs].[dbo].[Platlabs_Global]
set isActive = 'Y'
where isActive = '1'

UPDATE [src_PlatLabs].[dbo].[a]
SET MinListDate = b.minListDate
,MaxListDate = b.maxListDate
,MinSoldDate = b.minCloseDate
,MaxSoldDate = b.maxCloseDate
,TotalActiveStatusTypes = b.ActiveListings
,TotalSoldStatusTypes = b.SoldListings
,TotalInActiveStatusTypes = b.OffMarketListings
,TotalListingCount = b.TotalListingCount
,MaxModifiedTimestamp = b.[MaxModifiedTimestamp]
,[LastSyncTimestamp] = b.[LastSyncTimestamp]
FROM [src_PlatLabs].[dbo].[Platlabs_Global] a JOIN (
Select MLS_ID
,min(Platlabs_Listdate) minListDate
,Max(CASE WHEN Platlabs_Listdate > GetDate() THEN '1968-06-17' ELSE Platlabs_Listdate END) maxListDate
,MIN([close_date]) minCloseDate
,max(close_date) as maxCloseDate 
,Count(*) as TotalListingCount
,SUM(CASE WHEN Status in('active','backup','pending','Contingent') then 1 Else 0 end) as ActiveListings
,SUM(CASE WHEN [status] in('expired','off_market','withdrawn','cancelled','deleted') THEN 1 ELSE 0 END) as OffMarketListings
,SUM(CASE WHEN [status] in('sold','rented') THEN 1 ELSE 0 END) as SoldListings
,MAX([mls_update_date]) as [MaxModifiedTimestamp]
,max([LoadDate]) as [LastSyncTimestamp]
from [src_PlatLabs].[listing].[listingFull] with(NOLOCK)
--where mls_id = 2782
group by MLS_ID) b
on a.MLSId = b.mls_id



  update [src_PlatLabs].[dbo].[a]
  SET a.PhotoCount = TotalPhotoCount
  ,a.PhotoSyncTimestamp = LastPhotoDate
  from [src_PlatLabs].[dbo].[Platlabs_Global] a JOIN 
(Select mls_id,count(*) as TotalPhotoCount,max(photo_date) as LastPhotoDate from [src_PlatLabs].[photos].[RawPhotoLinks] with(NOLOCK) group by mls_id) b
  on a.MLSId = b.mls_id


INSERT INTO [azuvpsqladsf001].[jobs].dbo.[MultipleListingService](MLSID)
SELECT [mls_id] 
FROM [src_Platlabs].[dbo].[platlabs_update_config] with(NOLOCK)
WHERE [active] = '1'
	AND [code] like '%_39'
		AND [mls_id] not in(Select MLSID from [azuvpsqladsf001].[jobs].dbo.[MultipleListingService])


EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

        -- If everything is OK, update log as success
        SET @EndTime = SYSUTCDATETIME();

        UPDATE [Reports].[dbo].[ProcedureLog]
        SET EndTime   = @EndTime,
            DurationMs = DATEDIFF(MILLISECOND, StartTime, @EndTime),
            Success    = 1
        WHERE ProcedureLogID = @LogId;
    END TRY
	    BEGIN CATCH
        SET @EndTime      = GETDATE();
        SET @ErrorNumber  = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();

        IF @LogId IS NOT NULL
        BEGIN
            UPDATE [Reports].[dbo].[ProcedureLog]
            SET EndTime      = @EndTime,
                DurationMs   = DATEDIFF(MILLISECOND, StartTime, @EndTime),
                Success      = 0,
                ErrorNumber  = @ErrorNumber,
                ErrorMessage = @ErrorMessage
            WHERE ProcedureLogID = @LogId;
        END
        ELSE
        BEGIN
            -- In case error occurs before initial log insert
            INSERT INTO [src_PlatLabs].[dbo].[ProcedureLog]
                (ProcedureName, StartTime, EndTime, DurationMs, UserName, HostName, AppName, Success, ErrorNumber, ErrorMessage)
            VALUES
                (OBJECT_NAME(@@PROCID), @StartTime, @EndTime, DATEDIFF(MILLISECOND, @StartTime, @EndTime),
                 SUSER_SNAME(), HOST_NAME(), APP_NAME(), 0, @ErrorNumber, @ErrorMessage);
        END

        ;THROW; -- rethrow error to caller
    END CATCH;


END


