/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_process_lien_fix | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

/* 
 =============================================
 Author: Sunwoo Park 
 Create date: 2026-01-14
 Description: Lien.UR.usp_process_lien_fix
 =============================================
*/
create PROCEDURE [Lien].[UR].[usp_process_lien_fix] (
	@m_status_id TINYINT
	,@set_m_status_id_to TINYINT
	)
AS
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_process_lien_fix'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien].[tmp].[usp_process_lien_fix_doc]
		SELECT a.*
		INTO [lien].[tmp].[usp_process_lien_fix_doc]
		FROM [Lien].[ur].[Fix_Request] a
		OUTER APPLY (
			SELECT m_status_id
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			WHERE d.doc_id = a.doc_id
			) d
		WHERE a.m_status_id = @m_status_id
			AND a.set_m_status_id_to = @set_m_status_id_to
			AND a.update_status IS NULL
			AND a.reprocess_flag = 0
			AND a.m_status_id = d.m_status_id

	---------------------------------------------------------------the above needs to change for every fix --------------------->>>>>>>>>>>
	CREATE INDEX idx_doc_id ON [lien].[tmp].[usp_process_lien_fix_doc] (doc_id)

	------ delete these if you need to rematch
	DELETE
	FROM [Lien].[UR].[PROPERTY_APN_MATCH]
	WHERE property_id IN (
			SELECT p.property_id
			FROM [Lien].[UR].[PROPERTY] p WITH (
					NOLOCK
					,INDEX (ix_Doc_idSeq)
					)
			WHERE p.doc_id IN (
					SELECT doc_id
					FROM [lien].[tmp].[usp_process_lien_fix_doc]
					WHERE del_PROPERTY_APN_MATCH = 1
					)
			)

	DELETE
	FROM [Lien].[UR].[PROPERTY_Std_Address]
	WHERE property_id IN (
			SELECT p.property_id
			FROM [Lien].[UR].[PROPERTY] p WITH (
					NOLOCK
					,INDEX (ix_Doc_idSeq)
					)
			WHERE p.doc_id IN (
					SELECT doc_id
					FROM [lien].[tmp].[usp_process_lien_fix_doc]
					WHERE del_PROPERTY_Std_Address = 1
					)
			)

	DELETE
	FROM [Lien].[UR].[PROPERTYHeader]
	WHERE doc_id IN (
			SELECT doc_id
			FROM [lien].[tmp].[usp_process_lien_fix_doc]
			WHERE del_PROPERTYHeader = 1
			)

	DELETE
	FROM [Lien].[UR].[REFERENCE_Match]
	WHERE REFERENCE_id IN (
			SELECT r.REFERENCE_id
			FROM [Lien].[UR].[reference] r WITH (
					NOLOCK
					,INDEX (ix_Doc_id)
					)
			WHERE r.doc_id IN (
					SELECT doc_id
					FROM [lien].[tmp].[usp_process_lien_fix_doc]
					WHERE del_REFERENCE_Match = 1
					)
			)

	DELETE
	FROM [Lien].[UR].[NAME_STD_ADDRESS]
	WHERE name_id IN (
			SELECT n.name_id
			FROM [Lien].[UR].[name] n WITH (
					NOLOCK
					,INDEX (doc_id)
					)
			WHERE n.doc_id IN (
					SELECT doc_id
					FROM [lien].[tmp].[usp_process_lien_fix_doc]
					WHERE del_NAME_STD_ADDRESS = 1
					)
			)

	--delete from Lien.UR.PROPERTY_APN_MATCH where property_id in (select property_id from Lien.UR.PROPERTY where doc_id in (select doc_id from lien.tmp.usp_process_lien_fix_doc))
	--delete from Lien.UR.PROPERTY_Std_Address where property_id in (select property_id from Lien.UR.PROPERTY where doc_id in (select doc_id from lien.tmp.usp_process_lien_fix_doc))
	--delete from Lien.UR.PROPERTYHeader where doc_id in (select doc_id from lien.tmp.usp_process_lien_fix_doc)
	--delete from Lien.UR.REFERENCE_Match where REFERENCE_id in (select REFERENCE_id from lien.ur.reference where doc_id in (select doc_id from lien.tmp.usp_process_lien_fix_doc))
	--delete from Lien.UR.NAME_STD_ADDRESS where name_id in (select name_id from lien.ur.name where doc_id in (select doc_id from lien.tmp.usp_process_lien_fix_doc))
	DROP TABLE

	IF EXISTS [lien].[tmp].[DocumentToChangeStatus]
		CREATE TABLE [lien].[tmp].[DocumentToChangeStatus] (
			[doc_id] [int] NOT NULL
			,[m_update_date] [datetime2](3) NULL
			,[fips_code] [varchar](200) NULL
			,[Fips] [int] NULL
			,[Instrument_nbr] [varchar](100) NULL
			,[recording_date_d] [date] NULL
			,[m_status_id] [tinyint] NOT NULL
			,[reprocess_flag] [char](1) NOT NULL
			,[ur_matrix] [varchar](200) NULL
			,[doc_type] [varchar](200) NULL
			)

	--
	--find all the doc_id that had a change since the last update ran
	--
	INSERT INTO [lien].[tmp].[DocumentToChangeStatus] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,doc_type
		)
	SELECT d.doc_id
		,D.m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.doc_type
	FROM [lien].[ur].[DOCUMENT] d
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM [lien].[tmp].[usp_process_lien_fix_doc]
			)

	CREATE INDEX idx ON [lien].[tmp].[DocumentToChangeStatus] (doc_id)

	CREATE INDEX id_matrix ON [lien].[tmp].[DocumentToChangeStatus] (ur_matrix) include (m_status_id)

	CREATE INDEX id_m_status ON [lien].[tmp].[DocumentToChangeStatus] (m_status_id) include (
		Instrument_nbr
		,reprocess_flag
		)

	CREATE INDEX idxa ON [lien].[tmp].[DocumentToChangeStatus] (
		fips_code
		,Instrument_nbr
		,recording_date_d
		) include (
		doc_id
		,reprocess_flag
		,m_status_id
		)

	DECLARE @ERROR VARCHAR(500)

	/*
	--
	call the routine usp_Fix_processing that will delete all records from 
					Deed
					Ras
					PFC
					dim_nova_document
					FCT_DOC_NAME
					DOC_XREF
	  and set the doc_ids select to the correct M_status_id

	  the m_status_id values are for
					1 -- Good record
					3 -- manually rejected
					4 -- reprocessed
					5 -- Duplicate
					6 -- Non dtdb UR_MAtrix
					7 -- Doctype 'DEDRES'

	note - keep in mind that when you set the status = 3 for a deed doc id , then then status for a mortgage
									merged into the deed is not set to 3 but kept what it was, 
	--
	*/
	EXEC [lien].[UR].[usp_Fix_processing] @m_status_id = @set_m_status_id_to -------------------->>>>>>>>>>> to change
		,@ERROR = @ERROR OUTPUT

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	UPDATE [Lien].[UR].[b]
	SET b.update_status = 'processed'
	--  select  format(count(*), '##,##0') as cnt
	FROM [lien].[tmp].[usp_process_lien_fix_doc] a WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			)
	INNER JOIN [Lien].[ur].[Fix_Request] b WITH (
			NOLOCK
			,INDEX (idx_doc_id_update_status)
			) ON b.doc_id = a.doc_id
	WHERE b.m_status_id = a.m_status_id
		AND b.set_m_status_id_to = a.set_m_status_id_to
		AND b.update_status IS NULL

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_process_lien_fix'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END
END CATCH


