SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_ValonMortgage].[dbo].[usp_300_Start_Output_ValonMortgage_S13]


AS
BEGIN
	
	SET NOCOUNT ON;

	------20250116 - Per workorder 
	----	S13 - Deed; S28 - INVL; S34 - HOA Lien
	----Valon_Test_Data 20250108
	----S13 - DEEDS ONLY per EC!!!
	----S28 - INVL, return all recordings after their input start date; S34 - HOA Lien, return ALL Open HOA Liens, regardless of input start date
	----Please alert SE when ready for QC

	-----S13 - Deed - return all recordings after their input start date


		DROP TABLE [dbo].[x_Custom_OUTPUT_S13]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S13](
		    [FIPS] [varchar](5) NULL,
			--[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT Key][varchar](250)NULL,
			--[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Through Date][varchar](250)NULL,
			--[Mortgage Coverage Status][varchar](250)NULL,
			--[Mortgage Through Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			--[Current Owner 1][varchar](250)NULL,
			--[Current Owner 2][varchar](250)NULL,
			--[Ownership Change Date][varchar](250)NULL,
			--[Current Owner Doc Type][varchar](250)NULL,
			[Nbr of Recordings][varchar](250)NULL,

			---------------Internal---------
			[INPUTSTARTDATE][varchar](250)NULL,
			[Max_Deed_RECDate][varchar](250)NULL
		) ON [PRIMARY]

		

		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13](
		[INPUT Key],
		--[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		[INPUTSTARTDATE],
		[Max_Deed_RECDate]
		,[FIPS]
		,[PROPERTYID])
	  
		SELECT 
		INPUTKEY
		--,[Loan_ID]
      ,ADDRESS
      ,[City]
      ,[State]
      ,[ZipCODE]
      ,convert(date,[Start Date])
	  ,[Max_Deed_RECDate]
	  	,[FIPS]
		,[PROPERTYID]
		
	  --Select * 
		FROM [zCust_ValonMortgage].[dbo].[INPUT_MONITOR]

		

	Select * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]



	
		--UPDATE a 
		--SET 
		---- A.WORK_REF_ID = C.REF_ID
		-- --,
		-- A.PropertyID = case when A.PropertyID is null then C.PropertyID else A.PropertyID end  
		--,a.Fips = CASE WHEN A.FIPS is null then case when LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END else A.FIPS end
		--,a.[Report Date] = convert(date,GetDate())
		----Select * 
		--FROM x_Custom_OUTPUT_S13 a JOIN [dbo].a_PropMatch_WORK_FLANK as c with(NOLOCK) on a.[INPUT Key] = c.RAW_ID

		UPdate [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		set [Report Date] = convert(date,GetDate())
				
	
		Update [zCust_ValonMortgage].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		--, a.[RunDate] = convert(varchar(10),GetDate(),120)
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--Select C.*  
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_ValonMortgage].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


	
		Update [zCust_ValonMortgage].[dbo].[A]
		Set 
		A.[Deed Coverage Status] = B.DeedActive
		,A.[Deed Through Date] = B.DeedMaxRecordDate
		--,A.[Mortgage Coverage Status] = B.SAMActive
		--,A.[Mortgage Through Date] = B.SAMMaxRecordDate
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] a JOIN 
		[Global].[dbo].[county] as B on A.FIPS = B.FIPSCODE


		--Update A
		--Set
		--A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		--,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		
		--FROM x_Custom_OUTPUT_S13 a 
		--JOIN data.dbo.Property as B with(NOLOCK) 
		--on A.FIPS = B.FIPS
		--and A.PropertyID = B.PropertyID

		------Run this first in case FAOwnershipUpdateDt is null
		--Update A
		--Set 
		--A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Current Owner Doc Type] = C.DocumentTypeCode
		--FROM x_Custom_OUTPUT_S13 a JOIN data.dbo.Property as B with(NOLOCK) 
		--on a.FIPS = b.FIPS 
		--and A.PropertyID = B.PropertyID
		--left outer join data.dbo.Deed as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		--and B.CurrentSaleTransactionId = C.Transactionid
		--where B.CurrentSaleTransactionId is not null
		--and A.PROPERTYID is not null
		

		-----Run this 2nd to pull most recent ownership change
		--Update A
		--Set 
		--A.[Ownership Change Date] = convert(date,C.recordingdt)
		--,A.[Current Owner Doc Type] = C.DocumentTypeCode
		--FROM x_Custom_OUTPUT_S13 a JOIN data.dbo.Property as B with(NOLOCK) 
		--on a.FIPS = b.FIPS 
		--and A.PropertyID = B.PropertyID
		--left outer join data.dbo.Deed as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPropertyID
		--and B.FAOwnerTransactionId = C.Transactionid
		--where B.FAOwnerTransactionId is not null
		--and A.PROPERTYID is not null


		--Update A
		--Set A.[Current Owner Doc Type] = B.CodeDesc
		----Select A.[Current Owner Doc Type] , B.CodeDesc
		--FROM x_Custom_OUTPUT_S13 a 
		--JOIN [Global].[dbo].[lkup_Doc_Type] as B with(NOLOCK) 
		--on A.[Current Owner Doc Type] = B.DocTypeID


		--Update x_Custom_OUTPUT_S13 
		--SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_ValonMortgage].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] a JOIN [zCust_ValonMortgage].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID



		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN 
		(PropertyID is  not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ValonMortgage].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] a join [zCust_ValonMortgage].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		Exec [zCust_ValonMortgage].[dbo].[usp_502_Pull_FLANK_DATA]


		Update [zCust_ValonMortgage].[dbo].[B]
		Set B.ToUse = 'Y'
		--Select A.InputStartDate, B.* 
		From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] as A join [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK] as B on A.[INPUT Key] = B.RAW_ID
		where B.Doc_Src_Ind in ('D')
		--where B.Doc_Src_Ind in ('D','M')
		and B.RecordingDate > A.INPUTSTARTDATE
		and (B.RecordingDate > A.[Max_Deed_RECDate]
		OR [Max_Deed_RECDate] is null)
		

		Truncate table w_TransHist_FLANK_II

		Insert into [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		Select * From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Order by RAW_ID, RecordingDate desc, Doc_Src_Ind, DocumentNbr


		Select RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr, count(*) From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK]
		where ToUse like 'Y'
		Group by RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr
		having count(*) > 1

		
		Select RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr, count(*) From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		where ToUse like 'Y'
		Group by RAW_ID, RecordingDate, Doc_Src_Ind, DocumentNbr
		having count(*) > 1

		
		--Select * From w_TransHist_FLANK_II
		--where RAW_ID in ('24-1009')
		--Order by DocumentNbr


		Update [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		set RecordNumber = NULL

			UPDATE [zCust_ValonMortgage].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC,  Doc_ID desc, DocumentNbr DESC) AS RowNum
				FROM 
			[zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID
			and t.DocumentNbr = R.DocumentNbr


		Select RAW_ID,RecordNumber,count(*) From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		WHERE ToUse = 'Y'
		Group by RAW_ID,RecordNumber
		having count(*) > 1



		Select * From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		Order by RAW_ID, RecordNumber asc

		Select * From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber = 1
		Order by DocumentNbr


		Select A.* From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II]
		WHERE ToUse = 'Y'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'Y'

	

			
		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Set [Nbr of Recordings] = NULL
		where convert(int,[Nbr of Recordings]) > 0


		UPDATE [zCust_ValonMortgage].[dbo].[a]
		SET a.[Nbr of Recordings] = b.NbrOfRecordings 
		FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] a JOIN 
		--(SELECT INPUTKEY,MAX(ROWNUM) NbrOfRecordings FROM DEEDS_TO_USE GROUP BY INPUTKEY) 
		(SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) 
		b
		on a.[INPUT Key] = b.RAW_ID

		Select MAX(convert(int,[Nbr of Recordings])) from [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]

		
		 
		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = MAX(convert(int,[Nbr of Recordings])) FROM [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Document Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Sale Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer1_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Buyer2_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller1_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Seller2_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S13 ADD [Title Company_' + @RecNbr + '] [varchar](250) NULL')



						EXEC('UPDATE a
						SET 
						A.[Record Number_' + @RecNbr + '] = ''' + @RecNbr + '''
						,A.[Recording Date_' + @RecNbr + '] = B.RecordingDate
						,A.[Document Number_' + @RecNbr + '] = B.DocumentNbr
						,A.[Sale Amount_' + @RecNbr + '] = B.Value
						,A.[Doc Type_' + @RecNbr + '] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
						,A.[Buyer1_' + @RecNbr + '] = B.BuyerBorrower1
						,A.[Buyer2_' + @RecNbr + '] = B.BuyerBorrower2
						,A.[Seller1_' + @RecNbr + '] = B.SellerLender1
						,A.[Seller2_' + @RecNbr + '] = B.SellerLender2
						--,A.[Title Company_' + @RecNbr + '] = B.TITLECONAME


						--Select B.* 
						FROM x_Custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
						on a.[INPUT Key] = b.RAW_ID
						WHERE B.[RecordNumber] = ' + @BeginNbrOfTrans + '
						')

						EXEC('UPDATE a
						SET 
						A.[Doc Type_' + @RecNbr + '] = B.[CodeDesc]
						--Select B.*
						FROM x_Custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
						on A.[Doc Type_' + @RecNbr + '] = b.DocTypeID
						WHERE A.[Record Number_' + @RecNbr + '] = ' + @BeginNbrOfTrans + '
						')

						
						


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 


		Select * From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Order by convert(int,[Nbr of Recordings]) desc


		--Update x_Custom_OUTPUT_S13
		--SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		
		--UPDATE a SET [Property Status] = 'Multiple Properties Found' 
		--FROM x_Custom_OUTPUT_S13 a join a_PropMatch_Work_FLANK b
		--on a.[INPUT Key] = b.RAW_ID
		--WHERE b.MultiMatch = 'M'


		---------------20240917 - Per EC Event Status = Has recording
		Update [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] 
		SET [Event Status] = CASE WHEN [Nbr of Recordings] > 0 
		THEN 'Event Found' ELSE 'Event Not Found' END


		--Select [Mortgage Coverage Status], count(*) From x_Custom_OUTPUT_S13
		--Group by [Mortgage Coverage Status]

		Select [Deed Coverage Status], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Deed Coverage Status]


		Select [Address Standardization], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Address Standardization]

		Select [Property Status], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Event Status]

	

	  Select A.[INPUT Key], A.PROPERTYID, A.[Nbr of Recordings]
	  ,*
	  From [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] as A 
	  where [Nbr of Recordings] > 0 
	  --and ISNULL([Document Number_001],'') like ''
	    Order by convert(int,[Nbr of Recordings]) desc


		Select A.RAW_ID, A.RecordNumber, B.PROPERTYID,  A.RecordingDate, A.DocumentNbr, A.BuyerBorrower, A.SellerLender, A.Value, A.DocumentTypeDesc
		From [zCust_ValonMortgage].[dbo].[w_TransHist_FLANK_II] as A 
		join [zCust_ValonMortgage].[dbo].[x_Custom_OUTPUT_S13] as B on A.RAW_ID = B.[INPUT Key]
		 Order by convert(int,[Nbr of Recordings]) desc, A.RAW_ID,A.RecordNumber desc

	
			

END






