/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | PET_MTC.usp_Copy_Apn_Match_Result_To_Source | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */


 CREATE   PROCEDURE [Pet_Match_service].[PET_MTC].[usp_Copy_Apn_Match_Result_To_Source] @Fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Copy_Apn_Match_Result_To_Source: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Started'

	-- select * from 	PET_Match_Service.PET_MTC.Match_Request
	-- DECLARE @Fileid INT = 8
	DECLARE @DbName VARCHAR(100) -- = 'Listings'
	DECLARE @SchemaName VARCHAR(100) --= 'Listings_tmp'
	DECLARE @Output_File VARCHAR(100) --= 'Pet_Apn_Match_Result'
	DECLARE @ServerName VARCHAR(100)

	SELECT @DbName = ltrim(rtrim(a.DbName))
		,@SchemaName = ltrim(rtrim(a.SchemaName))
		,@Output_File = ltrim(rtrim(a.Output_File))
		,@ServerName = ltrim(rtrim(a.ServerName))
	FROM [PET_Match_Service].[PET_MTC].[Match_Request] a
	WHERE fileid = @fileid

	DECLARE @Link VARCHAR(100) = (
			SELECT CASE 
					WHEN @ServerName = N'AZUVPSQLDTDB007' -- etl01
						THEN '[DWS-ETL01].'
					ELSE ''
					END
			)
	DECLARE @TableName VARCHAR(200) = @Link + @DbName + '.' + @SchemaName + '.' + @Output_File
	--SELECT @TableName
	DECLARE @SQL VARCHAR(max)

		--truncate table ' + @TableName + '

	SET @SQL = '
	
		
		INSERT INTO ' + @TableName + '
           (	Fileid
		,id
		,Fips
		,APN
		,Match_Fips
		,Ref_id
		,Match_code
		,Street_Number
		,Direction
		,Street_Name
		,Street_Type
		,Post_Direction
		,Unit_Type
		,Unit
		,City
		,STATE
		,Zip
		,Plus4
		,Created
		,Updated
		,Match_reason
		,Apn_type
		
		)
   
	SELECT 	Fileid
		,id
		,Fips
		,APN
		,Match_Fips
		,Ref_id
		,Match_code
		,Street_Number
		,Direction
		,Street_Name
		,Street_Type
		,Post_Direction
		,Unit_Type
		,Unit
		,City
		,STATE
		,Zip
		,Plus4
		,Created
		,Updated
		,Match_reason
		,Apn_type


	FROM [PET_Match_Service].[pet_mtc].[Apn_match_Result]
	WHERE fileid = ' + CAST(@Fileid AS VARCHAR)

	--print  @SQL
	EXEC (@SQL)

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

