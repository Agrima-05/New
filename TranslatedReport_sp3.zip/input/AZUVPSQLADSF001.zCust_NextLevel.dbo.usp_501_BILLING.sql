SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_NextLevel].[dbo].[usp_501_BILLING] 
		
	
AS
BEGIN

	SET NOCOUNT ON;

	   -------NEXT LEVEL------



	   ------Billing---Bill Once per Month for all records in portfolio that month--
	   Insert into [zCust_NextLevel].[dbo].[BILLING_REPORT]([Unique ID],[DATE_ADDED])
	   Select [Unique ID],[DATE_ADDED] From [zCust_NextLevel].[dbo].[INPUT_MONITOR]
	  


		
END



