/* Source: AZUVNSQLDTDB003.datatree.local | Lien | Lien_dbo.usp_Create_PEt_Legal_Match_input | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */



-- =============================================  
-- Author:  Sean Dang  
-- Create date: 08/12/2025  
-- Description:   
-- =============================================  
CREATE	 PROCEDURE [Lien].[Lien_dbo].[usp_Create_PEt_Legal_Match_input]
	-- Add the parameters for the stored procedure here  
	@FileId INT
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from  
		-- interfering with SELECT statements.  

--create index idx_property_id on Lien.UR.PROPERTY_Legal_MATCH(property_id)  -- must also go to pro



DROP TABLE

IF EXISTS [lien].[lien_tmp].[usp_Create_PEt_Legal_Match_input_table]
	SELECT   p.property_id
	INTO [lien].[lien_tmp].[usp_Create_PEt_Legal_Match_input_table]
	FROM [lien].[ur].[property] p with(nolock,index(PK_PROPERTY))
	LEFT JOIN [Lien].[UR].[PROPERTY_pet_Legal_MATCH] pa WITH (
			NOLOCK
			,INDEX (idx_prop_id)
			) ON pa.property_id = p.property_id
	WHERE pa.property_id IS NULL
OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));

create index idx_property_id on [lien].[lien_tmp].[usp_Create_PEt_Legal_Match_input_table] (Property_id)

	
	

		--TRUNCATE TABLE pet_match_service.pet_mtc.legal_match --Lien.tmp.Legal_match_BK
		TRUNCATE TABLE [lien].[lien_tmp].[legal_match] --Lien.tmp.Legal_match_BK  

		INSERT INTO [lien].[lien_tmp].[legal_match] (
		--INSERT INTO pet_match_service.pet_mtc.legal_match (	  
			[Fileid]
			,[id]
			,[id_seq]
			,[Fips]
			,[Input_Map_Block]
			,[Input_Map_Building]
			,[Input_Map_Lot_high]
			,[Input_Map_Lot_low]
			,[Input_Map_Lot_Type]
			,[Input_Map_Lot_Type_high]
			,[Input_Map_Lot_Type_low]
			,[Input_Map_Plat_Book]
			,[Input_Map_Plat_Condo_ID]
			,[Input_Map_Plat_Name]
			,[Input_Map_Plat_Number]
			,[Input_Map_Plat_Page]
			,[Input_Map_Plat_Subcode]
			,[Input_Map_Plat_Type_Indicator]
			,[Input_Map_Sublot]
			,[Input_Map_Unit_low]
			,[Input_Swiss_Code]
			,Input_Tax_Assessor_Section
			,Input_Tax_Assessor_Block
			,Input_Tax_Assessor_Lot
			,[LEGAL_DESC_MUNICIPALITY]
			,[LEGAL_DESC_QUALIFIER]
			,[Created]
			,[Updated]
			,[legal_ref_id]
			)
		SELECT --top(300000)
			@FileId AS Fileid
			--433 AS Fileid --null as fileid   
			--,d.doc_id AS id  
			,ph.Property_id AS id
			,ph.property_id_sequence_number AS id_seq
			,cast(d.fips_code AS INT) AS Fips
			,ph.legal_desc_map_block AS Input_Map_Block
			,ph.legal_desc_map_building AS [Input_Map_Building]
			,ph.legal_desc_map_lot_high AS [Input_Map_Lot_high]
			,ph.legal_desc_map_lot_low AS Input_Map_Lot_low
			,ph.legal_desc_map_lot_type AS [Input_Map_Lot_Type]
			,ph.legal_desc_map_lot_type_high AS [Input_Map_Lot_Type_high]
			,ph.legal_desc_map_lot_type_low AS [Input_Map_Lot_Type_low]
			,ph.legal_desc_map_plat_book AS [Input_Map_Plat_Book]
			,ph.legal_desc_map_plat_condo_id AS [Input_Map_Plat_Condo_ID]
			,ph.legal_desc_map_plat_name AS [Input_Map_Plat_Name]
			,ph.legal_desc_map_plat_number AS [Input_Map_Plat_Number]
			,ph.legal_desc_map_plat_page AS [Input_Map_Plat_Page]
			,ph.legal_desc_map_plat_subcode AS [Input_Map_Plat_Subcode]
			,ph.legal_desc_map_plat_type_indicator AS [Input_Map_Plat_Type_Indicator]
			,ph.legal_desc_map_sublot AS [Input_Map_Sublot]
			,ph.legal_desc_map_unit_low AS [Input_Map_Unit_low]
			,ph.legal_desc_swiss_code AS [Input_Swiss_Code]
			,ph.legal_desc_tax_assessor_section AS Input_Tax_Assessor_Section
			,ph.legal_desc_tax_assessor_block AS Input_Tax_Assessor_Block
			,ph.legal_desc_tax_assessor_lot AS Input_Tax_Assessor_Lot
			,ph.legal_desc_municipality AS [LEGAL_DESC_MUNICIPALITY]
			,ph.legal_desc_qualifier AS [LEGAL_DESC_QUALIFIER]
			,getdate() AS [Created]
			,getdate() AS [Updated]
			,NULL AS [legal_ref_id]

		from [lien].[lien_tmp].[usp_Create_PEt_Legal_Match_input_table] a with(nolock,index(idx_property_id))
		inner join [lien].[ur].[property] ph with(nolock,index(PK_PROPERTY)) on ph.property_id = a.Property_id
		outer apply (select fips_code from [lien].[ur].[document] d with(nolock,index(pk_document)) 
		where d.doc_id = ph.doc_id) d
		--where ph.property_id_sequence_number is not null
		OPTION (RECOMPILE,MAXDOP 12,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE'));
	

		--WHERE  d.fips_code IN (
		--		SELECT fips
		--		FROM pet.dbo.pet_counties
		--		WHERE Stage_SSIS_Connection IS NOT NULL
		--		)
			--and ph.property_id = 264544932
			--and ph.legal_desc_map_block is null   
			--and ph.legal_desc_map_unit_low is not null  
			--and ph.legal_desc_tax_assessor_block is not null
			--and ph.legal_desc_swiss_code is not null
			--and ph.legal_desc_tax_assessor_section is not null
			--and ph.legal_desc_tax_assessor_lot is not null
	END
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


