/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_Pet_QC_Counts | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =====================================================================================================================
-- Author:		<Marie Pretorius>
-- Create date: <07/25/2022>
-- Description:	<Create Pet QC Counts>
--
-- Marie - 3/28/2022
--         
-- =====================================================================================================================
CREATE PROCEDURE [PET].[dbo].[usp_Pet_QC_Counts] @Fips INT = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY
		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_PEt_QC_Counts'
			,N'Started'

		DECLARE @SQL VARCHAR(MAX)
			,@LinkSvr VARCHAR(100) = ''

		IF @@SERVERNAME NOT IN (
				'AZUVNSQLDTDB003'
				,'AZUVPSQLDTDB029'
				)
			SET @LinkSvr = '[DWS-ETL01].';

		BEGIN
			--DECLARE @InSert_DATE DATETIME = GETDATE()
			/*--------------------------------------------------------------
   Create record from Assr table 
   ------------------------------------------------------------*/
			SET @SQL = '
	DROP TABLE

	IF EXISTS pet.tmp.PETQC_assr
		SELECT a.FIPS
			,a.REF_ID
			,a.UNFORMATTED_APN
			,(
				CASE 
					WHEN a.OWN_NAME1_FULL IS NOT NULL
						THEN 1
					ELSE 0
					END + CASE 
					WHEN a.OWN_NAME2_FULL IS NOT NULL
						THEN 1
					ELSE 0
					END + CASE 
					WHEN a.OWN_NAME3_FULL IS NOT NULL
						THEN 1
					ELSE 0
					END + CASE 
					WHEN a.OWN_NAME4_FULL IS NOT NULL
						THEN 1
					ELSE 0
					END
				) AS owner_name_cnt
		INTO pet.tmp.PETQC_assr
		FROM ' + @LinkSvr + 'assr.dbo.assr a WITH (NOLOCK)
		WHERE fips = ' + Cast(@Fips AS CHAR) + ' 	CREATE INDEX ixa ON pet.tmp.PETQC_assr(Fips, ref_id)'

			--PRINT @SQL
			EXEC (@SQL)

			/*===============================
  Create Pet table
  ===============================*/
			SET @SQL = '
	DROP TABLE

	IF EXISTS pet.tmp.PETQC_Pet
		SELECT fips
			,ref_id
			,CASE 
				WHEN isnull(p.NEO_TITLE_LEGAL, '''') > ''''
					THEN 1
				ELSE 0
				END AS has_neo_on_Pet
			,U_Apn_Dup_Ind
			,F_Apn_Dup_Ind
			,Legal_Dup_Ind
			,Addr_Dup_Ind
			,Dup_Key
			,NEO_Legal_cnt
		INTO pet.tmp.PETQC_Pet
		FROM pet.dbo.pet p WITH (NOLOCK)
		WHERE p.fips = ' + Cast(@Fips AS CHAR) + 'CREATE INDEX ixa ON pet.tmp.PETQC_Pet (
		Fips
		,ref_id
		)'

			--PRINT @SQL
			EXEC (@SQL)

			/*===============================
  Create pet.tmp.PETQC_Pet_Apn
  ===============================*/
			SET @SQL = '
	DROP TABLE

	IF EXISTS pet.tmp.PETQC_Pet_Apn
		SELECT pa.fips
			,pa.ref_id
			,max(CASE 
					WHEN apn_type = ''NEO''
						THEN 1
					ELSE 0
					END) AS _HAs_neo_apn
			,sum(1) AS apn_cnt
		INTO pet.tmp.PETQC_Pet_Apn
		FROM pet.dbo.pet_apn pa WITH (NOLOCK)
		WHERE pa.fips = ' + Cast(@Fips AS CHAR) + '
		GROUP BY pa.fips
			,pa.ref_id

		CREATE INDEX ixa ON pet.tmp.PETQC_Pet_Apn (
		Fips
		,ref_id
		)
'

			--PRINT @SQL
			EXEC (@SQL)

			/*===============================
  Create pet.tmp.PETQC_Pet_Neo_Legals
  ===============================*/
			SET @SQL = '
DROP TABLE

	IF EXISTS pet.tmp.PETQC_Pet_Neo_Legals
		SELECT pa.fips
			,pa.ref_id
			,sum(1) AS neo_legals_cnt
		INTO pet.tmp.PETQC_Pet_Neo_Legals
		FROM pet.dbo.pet_neo_legals pa WITH (NOLOCK)
		WHERE pa.fips = ' + Cast(@Fips AS CHAR) + ' 
		GROUP BY pa.fips
			,pa.ref_id

		CREATE INDEX ixa ON pet.tmp.PETQC_Pet_Neo_Legals (
		Fips
		,ref_id
		)'

			--PRINT @SQL
			EXEC (@SQL)

			/*===============================
  Create pet.tmp.PETQC_Pet_Name
  ===============================*/
			SET @SQL = '
	DROP TABLE

	IF EXISTS pet.tmp.PETQC_Pet_Name
		SELECT pa.fips
			,pa.ref_id
			,sum(1) AS NAme_cnt
		INTO pet.tmp.PETQC_Pet_Name
		FROM pet.dbo.pet_name pa WITH (NOLOCK)
		WHERE pa.fips = ' + Cast(@Fips AS CHAR) + '
		GROUP BY pa.fips
			,pa.ref_id

	CREATE INDEX ixa ON pet.tmp.PETQC_Pet_Name (
		Fips
		,ref_id
		)
		'

			--PRINT @SQL
			EXEC (@SQL)

			/*===============================
  pet.tmp.PETQC_Pet_County
  ===============================*/
			SET @SQL = '
	DROP TABLE

	IF EXISTS pet.tmp.PETQC_Pet_County
		SELECT a.*
			,''p'' AS _p
			--,p.fips
			--,p.ref_id
			,p.has_neo_on_Pet
			,p.U_Apn_Dup_Ind
			,p.F_Apn_Dup_Ind
			,p.Legal_Dup_Ind
			,p.Addr_Dup_Ind
			,p.Dup_Key
			,p.NEO_Legal_cnt
			,''pa'' AS _pa
			--,pa.fips
			--,pa.ref_id
			,pa._HAs_neo_apn
			,pa.apn_cnt
			,''pl'' AS _pl
			--,pl.fips
			--,pl.ref_id
			,pl.neo_legals_cnt
			,''pn'' AS _pn
			--,pn.fips
			--,pn.ref_id
			,pn.NAme_cnt
		INTO pet.tmp.PETQC_Pet_County
		FROM pet.tmp.PETQC_assr a
		LEFT JOIN pet.tmp.PETQC_Pet p ON p.fips = a.fips
			AND p.ref_id = a.ref_id
		LEFT JOIN pet.tmp.PETQC_Pet_apn pa ON pa.fips = a.fips
			AND pa.ref_id = a.ref_id
		LEFT JOIN pet.tmp.PETQC_Pet_neo_legals pl ON pl.fips = a.fips
			AND pl.ref_id = a.ref_id
		LEFT JOIN pet.tmp.PETQC_Pet_Name pn ON pn.fips = a.fips
			AND pn.ref_id = a.ref_id
	'

			--PRINT @SQL
			EXEC (@SQL)

			/*---------------------------------------------
	Populate PET.dbo.PET_QC_Counts for a fips
  ---------------------------------------------*/
			DECLARE @Record_Cnt INT
				,@Old_Neo_Cnt INT
				,@NEW_Neo_Cnt INT
				,@Old_Neo_Perc DECIMAL(10, 2)
				,@NEW_Neo_Perc DECIMAL(10, 2)
				,@Name_Diff INT
				,@New_NEO_Not_On_PET INT
				,@NEO_Match_Improvement INT
				,@NEO_Match_Decrease INT
				,@NEO_LEGAL_CNT_Compare INT

			SET @Record_Cnt = (
					SELECT COUNT(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE FIPS = @Fips
					)
			SET @Old_Neo_Cnt = (
					SELECT sum(cast(has_neo_on_Pet AS DECIMAL(10, 2)))
					FROM [pet].[tmp].[PETQC_Pet_County]
					GROUP BY fips
					)
			SET @New_Neo_Cnt = (
					SELECT sum(CASE 
								WHEN NEO_Legal_cnt > 0
									THEN 1.00
								ELSE 0.00
								END)
					FROM [pet].[tmp].[PETQC_Pet_County]
					GROUP BY fips
					)
			SET @Old_Neo_Perc = (
					SELECT cast(((@Old_Neo_Cnt * 100.00) / (@Record_Cnt * 100.00)) * 100.00 AS DECIMAL(10, 2))
					)
			SET @New_Neo_Perc = (
					SELECT cast(((@New_Neo_Cnt * 100.00) / (@Record_Cnt * 100.00)) * 100.00 AS DECIMAL(10, 2))
					)
			SET @Name_Diff = (
					SELECT Count(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE owner_name_cnt <> NAme_cnt
					)
			SET @New_NEO_Not_On_PET = (
					SELECT Count(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE isnull(has_neo_on_Pet, 0) = 0
						AND isnull(neo_legals_cnt, 0) > 0
					)
			SET @NEO_Match_Improvement = (
					SELECT Count(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE isnull(has_neo_on_Pet, 0) = 0
						AND isnull(neo_legals_cnt, 0) > 0
						AND NEO_Legal_cnt = 1
					)
			SET @NEO_Match_Decrease = (
					SELECT Count(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE has_neo_on_Pet > 0
						AND isnull(neo_legals_cnt, 0) = 0
					)
			SET @NEO_LEGAL_CNT_Compare = (
					SELECT Count(*)
					FROM [pet].[tmp].[PETQC_Pet_County]
					WHERE isnull(NEO_Legal_cnt, 0) <> isnull(neo_legals_cnt, 0)
					)

			----DELETE c
			----FROM PET.dbo.PET_QC_Counts c
			----WHERE fips = @Fips
			INSERT INTO [PET].[dbo].[PET_QC_Counts] (
				FIPS
				,QCDate
				,Record_Cnt
				,Old_Neo_Cnt
				,NEW_Neo_Cnt
				,Old_Neo_Perc
				,NEW_Neo_Perc
				,Name_Diff
				,New_NEO_Not_On_PET
				,NEO_Match_Improvement
				,NEO_Match_Decrease
				,NEO_LEGAL_CNT_Compare
				)
			SELECT @Fips
				,Getdate() AS QCDdate
				,@Record_Cnt AS RecorCnt
				,@Old_Neo_Cnt AS Old_neo_cnt
				,@NEW_Neo_Cnt AS New_Neo_Cnt
				,@Old_Neo_Perc AS Old_Neo_perc
				,@NEW_Neo_Perc AS New_Neo_perc
				,@Name_Diff AS Name_Diff
				,@New_NEO_Not_On_PET AS New_NEO_Not_On_PET
				,@NEO_Match_Improvement AS NEO_Match_Improvement
				,@NEO_Match_Decrease AS NEO_Match_Decrease
				,@NEO_LEGAL_CNT_Compare AS NEO_LEGAL_CNT_Compare

			EXEC [PET].[dbo].[AddPetLog] @Fips
				,N'info'
				,N'usp_PEt_QC_Counts'
				,N'Ended'
		END
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		--ROLLBACK
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


