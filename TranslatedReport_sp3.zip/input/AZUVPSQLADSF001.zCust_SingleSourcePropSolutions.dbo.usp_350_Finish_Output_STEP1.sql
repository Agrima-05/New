SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_SingleSourcePropSolutions].[dbo].[usp_350_Finish_Output_STEP1]
		
AS
BEGIN
	
	SET NOCOUNT ON;


		ALTER Table w_PropertyToPullOut ADD RAW_ID varchar(50) NULL
		ALTER Table w_PropertyToPullOut ADD ToUse varchar(1) NULL
		ALTER Table w_PropertyToPullOut ADD RecordNbr int NULL



	

END




