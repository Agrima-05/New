/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_INFC_ETL_BEGIN | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

 
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_INFC_ETL_BEGIN]  @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_INFC_ETL_BEGIN'
	,N'Started'

	DECLARE @date_from DATETIME2 = NULL
		,@date_to DATETIME2 = NULL

	SELECT @date_from = to_date
	FROM [lien].[UR].[INFC_run_dates]

	TRUNCATE TABLE [lien].[UR].[INFC_run_dates_temp]

	INSERT INTO [Lien].[UR].[INFC_run_dates_temp] (
		[From_Date]
		,[To_Date]
		)
	EXEC [Lien].[UR].[usp_Create_INFC_DocIdExtract] @date_to = @date_to
		,@date_from = @date_from
		,@ERROR = @ERROR OUTPUT

EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_INFC_ETL_BEGIN'
	,N'Ended'


/****** Object:  StoredProcedure [UR].[usp_Set_INFC_RunDates_Success]    Script Date: 7/6/2023 2:35:12 PM ******/
SET ANSI_NULLS ON


END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	ROLLBACK
END CATCH

