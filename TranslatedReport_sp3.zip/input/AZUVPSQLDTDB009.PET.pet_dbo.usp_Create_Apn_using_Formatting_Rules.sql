/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Create_Apn_using_Formatting_Rules | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

--CREATE
--	OR
CREATE PROCEDURE [PET].[pet_dbo].[usp_Create_Apn_using_Formatting_Rules] @Refresh BIT
	,@ERROR VARCHAR(500) OUTPUT
	/*
DECLARE @ERROR varchar(500)
,@Refresh bit = 0 

EXEC [PET].[pet_dbo].[usp_Create_Apn_using_Formatting_Rules]
  @Refresh = @Refresh 
  ,@ERROR = @ERROR OUTPUT
*/
AS
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Create_Apn_using_Formatting_Rules'
		,N'Started'

	-- declare @Refresh BIT = 0 ,@ERROR VARCHAR(500) 
	IF @Refresh = 0
	BEGIN
		DROP TABLE

		IF EXISTS [Pet].[pet_tmp].[apn_formatting_rule_tracker]
			SELECT ROW_NUMBER() OVER (
					PARTITION BY 0 ORDER BY a.fips
						--(SELECT 0)
					) AS ROW4
				,a.fips
				,b.APN_Type
				,try_cast(NULL AS DATETIME) AS DateStarted
				,try_cast(NULL AS DATETIME) AS DateEnded
			INTO [Pet].[pet_tmp].[apn_formatting_rule_tracker]
			FROM (
				SELECT DISTINCT fips
				FROM [pet].[pet_tmp].[pet_apn_wrk]
				) a
			OUTER APPLY (
				SELECT *
				FROM [PEt].[dbo].[PET_APN_Additional_Formats] b
				WHERE b.fips = a.fips
				) b
			WHERE b.fips IS NOT NULL
			OPTION (
				RECOMPILE
				,MAXDOP 12
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

		DECLARE @fips INT = NULL
			,@fips_a CHAR(5) = NULL
			,@apn_type VARCHAR(10)
		--select the starting fips
		--
		DECLARE @row4 INT = 1

		SELECT @fips = a.fips
			,@apn_type = a.apn_type
		FROM [Pet].[pet_tmp].[apn_formatting_rule_tracker] a
		WHERE ROW4 = @row4

		--
		--begin the loop for the Fips
		DECLARE @return_value INT = 0
		DECLARE @rowcount INT = 0

		--
		WHILE /*@fips IS NOT NULL
			AND*/ @fips > 0
		BEGIN
			--
			--Udpate the control trable to say you are workig on the fips
			--
			BEGIN
				UPDATE [PET].[pet_dbo].[a]
				SET a.DateStarted = getdate()
				FROM [Pet].[pet_tmp].[apn_formatting_rule_tracker] a
				WHERE a.ROW4 = @row4
			END

			--select @fips as N'@fips'
			--
			-- here the logic start that you  wnat to run by fips
			--
			--Select @datefrom_a, @dateto_a
			--SELECT @fips AS N'@fips'
			--	,@APN_Type AS N'@APN_Type'
			EXEC [spdb].[dbo].[usp_PEt_Apn_Creation_1_incr] @fips = @fips
				,@Apn_type = @APN_Type
				,@list_Sql = 0
				,@Refresh = 0

			EXEC [SPDB].[dbo].[usp_PEt_Apn_Creation_2_incr] @fips = @fips
				,@Apn_type = @APN_Type
				,@list_Sql = 0
				,@Refresh = 0

			DROP TABLE

			IF EXISTS [pet].[pet_tmp].[usp_Create_Apn_using_Formatting_Rules_temp]
				SELECT DISTINCT fips
					,ref_id
				INTO [pet].[pet_tmp].[usp_Create_Apn_using_Formatting_Rules_temp]
				FROM [pet].[pet_tmp].[pet_apn_wrk] WITH (
						NOLOCK
						,INDEX (idx_fips_apn_type)
						)
				WHERE fips = @fips
				OPTION (
					RECOMPILE
					,MAXDOP 12
					,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
					);

			CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_Create_Apn_using_Formatting_Rules_temp] (
				fips
				,ref_id
				)

			INSERT INTO [pet].[pet_tmp].[pet_apn_wrk] (
				REF_ID
				,FIPS
				,APN_Type
				,APN
				,created
				)
			SELECT pa.REF_ID
				,pa.FIPS
				,pa.APN_Type
				,pa.APN
				,pa.created
			FROM [pet].[pet_tmp].[usp_Create_Apn_using_Formatting_Rules_temp] t WITH (
					NOLOCK
					,INDEX (idx_fips_ref_id)
					)
			INNER JOIN [pet].[dbo].[pet_apn] pa WITH (
					NOLOCK
					,INDEX (ixb_fips_ref_id)
					) ON pa.fips = t.fips
				AND pa.ref_id = t.ref_id
			OUTER APPLY (
				SELECT count(1) AS cnt
				FROM [pet].[pet_tmp].[pet_apn_wrk] pw WITH (
						NOLOCK
						,INDEX (fips_ref_id_apntype)
						)
				WHERE pw.fips = pa.fips
					AND pw.ref_id = pa.ref_id
					AND pw.apn_type = pa.apn_type
				) pw
			WHERE pw.cnt = 0
			OPTION (
				RECOMPILE
				,MAXDOP 12
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				);

			SET @rowcount = @@rowcount

			--
			--Update the control table to indicate you are done
			--
			--UPDATE [Pet].pet_tmp.[apn_formatting_rule_tracker]
			--SET DateEnded = getdate()
			--WHERE fips = @fips
			--	AND apn_type = @apn_type
			--
			--Select the new fips to process - if non found then @fips would be null
			--
			BEGIN
				UPDATE [PET].[pet_dbo].[a]
				SET a.DateEnded = getdate()
				FROM [Pet].[pet_tmp].[apn_formatting_rule_tracker] a
				WHERE a.ROW4 = @row4
			END

			SET @row4 = @row4 + 1
			SET @fips = 0

			SELECT @fips = a.fips
				,@apn_type = a.apn_type
			FROM [Pet].[pet_tmp].[apn_formatting_rule_tracker] a
			WHERE ROW4 = @row4
		END
	END

	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Create_Apn_using_Formatting_Rules'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


