/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.NewListing_Finance_Daily_Platlabs | type=P */









-- ===============================================================================================
-- Author:		My Phan
-- Create date: 7/18/2025
-- Description:	Create New Listing Trends for Finance
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[NewListing_Finance_Daily_Platlabs]
                
AS 


SET NOCOUNT ON

BEGIN
 
 --	select * FROM [MiNelson].[dbo].[Platlabs_NewListing_Count] r
	--order by 1

	/*IF OBJECT_ID('Minelson.List.NewListing_Nation_Day_platlabs') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[List].[NewListing_Nation_Day_platlabs]

	SELECT left(CONCAT (
				a.List_Date
				,'--'
				,b.DayOfWeekName
				), 15) AS Day
		,a.Total_New_Listing_Count
		,a.New_Listing_Count
		,a.New_RentalListing_Count
	INTO [Minelson].[List].[NewListing_Nation_Day_Platlabs]
--select * 	
FROM [MiNelson].[dbo].[Platlabs_NewListing_rental_Count] a
	LEFT JOIN [Minelson].[dbo].[Calendar] b ON a.List_Date = b.CalendarDate

	--select * from Minelson.List.NewListing_Nation_Day_Platlabs_1
	--where left(Day,10) >= '2024-01-01'
	--order by 1

--IF OBJECT_ID('Minelson.List.NewListing_Nation_Day_platlabs') IS NOT NULL
--		DROP TABLE Minelson.List.NewListing_Nation_Day_platlabs

--	select  * into Minelson.List.NewListing_Nation_Day_platlabs
--from Minelson.List.NewListing_Nation_Day
--where left(Day,10)  < '2024-01-01'
--union all
--	select * from Minelson.List.NewListing_Nation_Day_Platlabs_1
--	where left(Day,10) >= '2024-01-01'
--	order by 1

		--select * from Minelson.List.NewListing_Nation_Day_Platlabs
		--order by 1

END  




