SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_TaxSource_Amrock].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match_NEW] 
		
	
AS
BEGIN

	SET NOCOUNT ON;


		
		

		------------------------------------------
		SET CONCAT_NULL_YIELDS_NULL off

		
		
		Truncate table INPUT_IN

		INSERT INTO [zCust_TaxSource_Amrock].[dbo].[INPUT_IN](INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZip,INPUTAPN)
		Select  
		LTRIM(RTRIM([UniqueID]))
		,REPLACE([Address],'  ',' ')
      ,REPLACE([City],'  ',' ')
      ,[State]
      ,[Zip]
      ,REPLACE([APN],',','')
	
		From [zCust_TaxSource_Amrock].[dbo].[INPUT_RAW_CUST]

		
		Truncate table [INPUT_RAW_CUST]
		Insert into [zCust_TaxSource_Amrock].[dbo].[INPUT_RAW_CUST](UniqueID, [Reference ID], Address, City, State, Zip)

		Select INPUTKEY,INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZip
		From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]		where INPUTKEY in ('73049400','73049225','73049399','73049771','73049069','73049183','73048522',
'73048569','73048512','73048310','73049582','73049945','73048809','73051479','73049968','73052273','73048539','73049285',
'73052497','73052687','73048795','73050970','73049298','73048330','73049525','73050282','73048465','73048185','73050445',
'73051870','73049039','73051402','73050128','73051083','73048918','73050165','73049364','73049380','73048694','73048466',
'73048758','73048898','73048814','73060321','73060579','73050768','73050381','73055446','73048939','73049291','73049282','73049106',
'73050775','73049545')

Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_RAW_CUST]


		--Truncate table INPUT_IN

		--INSERT INTO INPUT_IN(INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZip)
		--Select 
	 -- [REFERENCE ID/LOAN NUMBER]	
	 -- ,[ADDRESS LINE 1]
	 -- ,CITY
	 -- ,STATE
	 -- ,[ZIP CODE]
	 --	FROM INPUT_RAW_20230328

		----Check for Dups--
		--Select A.*, B.*  From INPUT_RAW_CUST as A 
		--join INPUT_MONITOR as B on A.UniqueID = B.UniqueID

		
		SET CONCAT_NULL_YIELDS_NULL off

		
		--Truncate table [INPUT_RAW_CUST]

		--INSERT INTO [INPUT_RAW_CUST]([UniqueID],[Reference ID],[Address],[City],[State],[Zip],[APN])
		--Select  
		--convert(bigint,[Unique ID])
		--,convert(bigint,[Reference ID])
  --     ,REPLACE([Street Address],'  ',' ')
  --    ,REPLACE([City],'  ',' ')
  --    ,[State]
  --    ,[Zip]
  --    ,REPLACE([APN],',','')
	 --	--Select * 
		--FROM INPUT_RAW_20210510
		
		--Select * From [INPUT_RAW_CUST]



		--Select * from [zCust_TaxSource_Amrock].[dbo].[INPUT_RAW_20210305]


		Select top 100 * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]

		Select count(*) From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]

		Select INPUTKEY,count(*) From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		Group by INPUTKEY
		Having count(*) >1

		Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'

		Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		where len(INPUTZip) > 10

		Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		where InputAddress like '%  %'

		Update [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		Set InputAddress = REPLACE(InputAddress,'  ',' ')
		where InputAddress like '%  %'

		Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'


		UPDATE [zCust_TaxSource_Amrock].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_TaxSource_Amrock].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_TaxSource_Amrock].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_TaxSource_Amrock].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2

	
	
	---- INSERT DATA INTO ASP IN TABLE AND SET TRIGGER FOR PROCESS

	  EXEC [zCust_TaxSource_Amrock].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]


	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_TaxSource_Amrock].[dbo].[TaxSource_Amrock]) = 0
				BEGIN
					RETURN;
				END
			ELSE
				BEGIN
					---- 2 min wait periods until ASP is complete
					DECLARE @CheckASP as int
				
						SET @CheckASP = 0

					WHILE @CheckASP = 0
						BEGIN
							WAITFOR DELAY '00:01'
							
						---- Checks for completion ** If not wait again
						SET @CheckASP = (Select COUNT(*) from [zCust_TaxSource_Amrock].[dbo].[TaxSource_Amrock_STD])
						END
				END

			

	---- APPENDS ASP DATA BACK TO DATABASE 

	
		EXEC [zCust_TaxSource_Amrock].[dbo].[usp_100c_sp_ASP_Cust_STD]

	
		-----------------------------------------------------

		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_TaxSource_Amrock'
		--EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_TaxSource_Amrock'

		update [zCust_TaxSource_Amrock].[dbo].[a_PropMatch_WORK]
		Set FIPS = RIGHT('0' + (convert(varchar(5),FIPS)),5)
		
		
			Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
			 from [zCust_TaxSource_Amrock].[dbo].[a_PropMatch_WORK]
			group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END

			Select FIPS,RAW_ID, FullStreetAddress, City, State, Zip
			,CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as DTDB_AddrMatch, REF_ID
			 from [zCust_TaxSource_Amrock].[dbo].[a_PropMatch_WORK]
			 where RAW_ID in ('73049400','73049225','73049399','73049771','73049069','73049183','73048522','73048569','73048512','73048310',
'73049582','73049945','73048809','73051479','73049968','73052273','73048539','73049285','73052497','73052687','73048795','73050970','73049298',
'73048330','73049525','73050282','73048465','73048185','73050445','73051870','73049039','73051402','73050128','73051083','73048918','73050165',
'73049364','73049380','73048694','73048466','73048758','73048898','73048814','73060321','73060579','73050768','73050381','73055446','73048939',
'73049291','73049282','73049106','73050775','73049545')
			 Order by FIPS, RAW_ID

			 
			Select A.FIPS,B.State,B.[County Name],count(*) as TOTAL
			--,CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END as DTDB_AddrMatch
			 from [zCust_TaxSource_Amrock].[dbo].[a_PropMatch_WORK] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
			 Group by A.FIPS,B.State,B.[County Name]
			-- ,CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END 
			 Order by A.FIPS,B.State,B.[County Name]
			

			--Select CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
			-- from dbo.a_PropMatch_WORK_FLANK
			--group by CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END



			------------------Tax Source-----------
			DECLARE @CUSTOMER varchar(100)
			Set @CUSTOMER = 'Amrock'
			DECLARE @DATE varchar(30)
			--Set @DATE = (Select format(getdate(),'yyyyMMddHHmm'))
			Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			DECLARE @BATCH varchar(50)
			--SET @BATCH = (Select max(convert(int,ID)) + 1 from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK))
			--Set @DATE = '202104071524'
			
			Print @DATE

			--INsert into [TaxSourceAPI].[dbo].[Batch]([Name],[ImageFolderPath])
			--Select @CUSTOMER + '_' + @DATE,'\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Amrock\TaxSource\IMAGES\'+@DATE+'_'+@BATCH+'\Images'

			----Changed 20210413---
			--DECLARE @CUSTOMER varchar(100)
			--Set @CUSTOMER = 'Amrock'
			--DECLARE @DATE varchar(30)
			--DECLARE @BATCH varchar(50)
			--Set @DATE = (Select format(getdate(),'yyyyMMdd'))

			INsert into [TaxSourceAPI].[dbo].[Batch]([Name])
			Select @CUSTOMER + '_' + @DATE

			SET @BATCH = (Select ID from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			)

			Print @BATCH

			Update [TaxSourceAPI].[dbo].[Batch]
			Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Amrock\TaxSource\IMAGES\'+@DATE+'_'+@BATCH+'\Images'
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			and ID = @BATCH


			Select * From [TaxSourceAPI].[dbo].[Batch]
			Order by ID Desc

			--Update [TaxSourceAPI].[dbo].[Batch]
			--Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Amrock\TaxSource\IMAGES\20210413_12\Images'
			--where ID = 12

				

			
			----UPdate  [TaxSourceAPI].[dbo].[Batch]
			----Set 
			----Name = 'Amrock_202103051443'
			----,ImageFolderPath = '\\DTRESNA9SFIL01.datatree.local\CMAS$\Customers\Amrock\TaxSource\OUTPUT\4847_202103051443\Images'
			----where ID = 6

			--Truncate table [INPUT_MONITOR]

			--DECLARE @CUSTOMER varchar(100)
			--Set @CUSTOMER = 'Amrock'
			--DECLARE @DATE varchar(30)
			------Set @DATE = '202104071524'
			--Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			
			

			Insert into  [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]( [UniqueID]      ,[Reference ID]      ,[Address]      ,[City]      ,[State]
			,[Zip]      ,[APN]      ,[DATE_ADDED]      ,[FIPS]      ,[REF_ID]      ,[BATCHID])
			
			Select 	
			RAW_ID, B.[Reference ID]
			,REPLACE(B.ADDRESS,'  ',' ')
			,REPLACE(B.City,'  ',' '), B.State, B.Zip
			,REPLACE(B.APN,',','')
			,@DATE
			,RIGHT(('0' + A.FIPS),5)
			,A.REF_ID
			,(Select MAX([Id]) from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK) where [Name] like 
			@CUSTOMER + '_' + @DATE )
			
			From [zCust_TaxSource_Amrock].[dbo].[a_Propmatch_WORk] as A 
			join [zCust_TaxSource_Amrock].[dbo].[INPUT_RAW_CUST] as B on A.RAW_ID = B.[UniqueID]
			
			
			Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]

			Select BatchID, count(*) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
			Group by BatchID
			Order by BatchID

			Select distinct DATE_ADDED  From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
			where DATE_COMPLETED is null

			
			--Select * From [TaxSourceAPI].sys.tables as A join [TaxSourceAPI].sys.columns as B on A.object_id = B.object_id
			--where A.Name like 'Property'
			--Order by B.Name
			
			Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
			, City, State, Zip, RefId, APN, Fips
			, REFERENCEID)
			Select 
			A.RAW_ID
			,B.[BATCHID]
			,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
			, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
			----Added 20210326 so customer can pass through their secondary reference id
			--,ROW_NUMBER() OVER (order by RAW_ID)
			,B.[Reference ID]
			From [zCust_TaxSource_Amrock].[dbo].[a_Propmatch_WORk] as A 
			join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
			where B.BATCHID = 
			(Select MAX(convert(bigint,BATCHID)) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			--AND  UniqueID in ('69344666','69280094','69278648','69277576','69239611','69452770','69451418','69421823')

			

			--Update [TaxSourceAPI].[dbo].[Property]
			--Set ExternalKey = REPLACE(REPLACE(ExternalKey,'  ',''),' ','')
			--where BatchId = (Select MAX(convert(bigint,BATCHID)) From zCust_TaxSource_Amrock.dbo.[INPUT_MONITOR] with(NOLOCK)
			--where DATE_COMPLETED is null)
			--and ExternalKey like '% %'

			Update [TaxSourceAPI].[dbo].[Property]
			Set ExternalKey = LTRIM(RTRIM(ExternalKey))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ExternalKey like '% %'

			--Select * From [TaxSourceAPI].[dbo].[Property]
			--where (ExternalKey like '% %'
			--OR ReferenceId like '% %')
			--and BatchId = 12


			Update [TaxSourceAPI].[dbo].[Property]
			Set ReferenceId = LTRIM(RTRIM(ReferenceId))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ReferenceId like '% %'


			Select ReferenceId , ExternalKey From [TaxSourceAPI].[dbo].[Property]
			where  BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and (ReferenceId like '% %'
			OR ExternalKey like '% %')


			--Select * From a_Propmatch_WORk
			--where RAW_ID like '69167525%'

			--Select count(*) From [TaxSourceAPI].[dbo].[Property]
			--where BATCHID = 7


			Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]


			
		--Select BatchID, ExternalKey,ReportStatus, Errors   From  [TaxSourceAPI].[dbo].[OutputLayout2] as A with(NOLOCK)
		--where BatchID = 8

		--Select * From [TaxSourceAPI].[dbo].[Property]
		--where BatchId = 8


			--Delete from [TaxSourceAPI].[dbo].[Property]
			--where BatchID = 8

			--Update [TaxSourceAPI].[dbo].[Property]
			--Set SubmissionStatus = NULL
			--,Response = NULL
			--,Error = NULL
			--where BatchID = 8
		
END



