/* Source: AZUVNSQLDTDB003.datatree.local | Assr | pet_dbo.usp_Determine_Pet_Process_List | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [Assr].[pet_dbo].[usp_Determine_Pet_Process_List]
	--@fips INT
	--	,@Refresh BIT
	@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
BEGIN TRY
	--EXEC PET.Pet_dbo.Add_Petlog N'info'
	--	,N'usp_Determine_Pet_Process_List'
	--	,N'Started'
	--
	--
	-- select top 100 * from assr.pet_tmp.pet_daily_tracker

	DECLARE @SQL VARCHAR(MAX)
		,@LinkSvr VARCHAR(100) = ''

	SET @LinkSvr = CASE 
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB007' -- DWS-ETL01.DATATREE.LOCAL,1433
				THEN '[DWS-ETL02].'
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB029' --AZUVPSQLDTDB029.datatree.local
				THEN ''
			ELSE '' -- AZUVNSQLDTDB003
			END

	DROP TABLE

	IF EXISTS [assr].[pet_tmp].[pet_daily_tracker];
		CREATE TABLE [assr].[pet_tmp].[pet_daily_tracker] (
			Fips INT NOT NULL
			,Assr_fips INT NULL
			,refresh BIT NOT NULL
			,DateStarted DATETIME NULL
			,DateEnded DATETIME NULL
			)

	INSERT INTO [assr].[pet_tmp].[pet_daily_tracker] (
		Fips
		,Assr_Fips
		,refresh
		,DateStarted
		,DateEnded
		)
	SELECT DISTINCT a.*
	FROM (
		SELECT b.FIPS
			,b.Assr_Fips
			,b.refresh
			,NULL AS DateStarted
			,NULL AS DateEnded
		FROM (
			SELECT TOP 1 1 AS fips
				,1 AS Assr_Fips
				,0 AS refresh
			
			UNION ALL
			
			--SELECT FIPS
			--	,1 AS refresh
			--FROM NovaCL.dbo.FipsWrk
			
			--UNION ALL
			
			SELECT fips
				,fips as Assr_Fips
				,1 AS refresh
			FROM [Assr].[dbo].[Pet_Rebuild_fips] p
			WHERE p.process_status = 'P'
			) b
		) a

	--
	-- remove counties from incremental when their counts are to high so that we can run a pet_rebuild
	--
	DROP TABLE

	IF EXISTS [assr].[dbo].[Pet_Daily_INCR_Refids]
		SELECT DISTINCT a.fips
			,a.fips AS Assr_fips
			,a.ref_id
			,a.UNFORMATTED_APN
		INTO [assr].[dbo].[Pet_Daily_INCR_Refids]
		FROM (
			--SELECT b.fips
			--	,b.ref_id
			--	,b.UNFORMATTED_APN
			--FROM Assr.dbo.AssrWrkAll b
			
			--UNION ALL
			
			SELECT p.fips
				,p.ref_id
				,p.UNFORMATTED_APN
			FROM [Assr].[dbo].[Pet_Incremental_ref_ids] p WITH (NOLOCK,INDEX (idx_Process_status))
			WHERE process_status = 'P'
			
			UNION ALL
			
			SELECT a.fips
				,a.ref_id
				,ar.unformatted_apn
			FROM [Assr].[pet_tmp].[Missing_pet_ref_id] a -- this tables was created in assr.pet_dbo.usp_Determine_Missing_ref_id_Pet_Assr
			OUTER APPLY (
				SELECT unformatted_apn
				FROM [assr].[dbo].[assr] ar WITH (NOLOCK) -- WITH (NOLOCK,INDEX (IDX_Assr_Ref_ID))
				WHERE ar.ref_id = a.ref_id
				) ar
			) a
		OUTER APPLY (
			SELECT ref_id
				,UNFORMATTED_APN
			FROM [assr].[dbo].[assr] ar WITH (
					NOLOCK
					,INDEX (Idx_FipsRefId)
					)
			WHERE ar.fips = a.fips
				AND ar.ref_id = a.ref_id
			) ar
		WHERE ar.ref_id IS NOT NULL
			AND a.UNFORMATTED_APN = ar.UNFORMATTED_APN

	CREATE INDEX idx_fips ON [assr].[dbo].[Pet_Daily_INCR_Refids] (fips)

	CREATE INDEX idx_fips_ref_id ON [assr].[dbo].[Pet_Daily_INCR_Refids] (
		fips
		,ref_id
		)

--select * from assr.dbo.Pet_Daily_INCR_Refids

	
	--
	-- add records to assr.dbo.Pet_Daily_INCR_Refids when a dual fips county
	--
	SET @sql = N'
				insert into assr.dbo.Pet_Daily_INCR_Refids (fips, ref_id, UNFORMATTED_APN, Assr_fips)

				SELECT c.fips as fips
					,r.ref_id
					,r.UNFORMATTED_APN
					,c.assr_fips as Assr_fips
				FROM assr.dbo.Pet_Daily_INCR_Refids r
				INNER JOIN ' + @LinkSvr + 'pet.dbo.pet_counties c ON c.assr_fips = r.fips
				WHERE c.fips <> c.assr_fips

				INSERT INTO assr.pet_tmp.pet_daily_tracker (Fips, Assr_Fips, refresh, DateStarted, DateEnded)
				select c.Fips as Fips
					,c.Assr_Fips as Assr_fips
					,t.refresh
					,NULL as DateStarted
					,NULL as DateEnded
				from assr.pet_tmp.pet_daily_tracker t
			    INNER JOIN ' + @LinkSvr + 'pet.dbo.pet_counties c ON c.assr_fips = t.fips
				WHERE c.fips <> c.assr_fips
				'

		--PRINT @sql
		EXEC (@sql)

/*
select * from assr.dbo.Pet_Daily_INCR_Refids
select * from assr.pet_tmp.pet_daily_tracker
*/

	/*	

DROP TABLE

	IF EXISTS #Temp
		SELECT a.fips
			,Count(1) AS cnt
		INTO #temp
		FROM assr.dbo.Pet_Daily_INCR_Refids a
		GROUP BY a.fips
		HAVING count(1) > 10000 --000

	INSERT INTO assr.pet_tmp.pet_daily_tracker (
		Fips
		,refresh
		,DateStarted
		,DateEnded
		)
	SELECT fips
		,1
		,NULL
		,NULL
	FROM #temp
	WHERE fips NOT IN (
			SELECT fips
			FROM assr.pet_tmp.pet_daily_tracker
			)

	DELETE
	FROM assr.dbo.Pet_Daily_INCR_Refids
	WHERE fips IN (
			SELECT fips
			FROM #temp
			)
			
*/
	--
	--
	-- take backup of input ref_ids
	--DECLARE @SQL VARCHAR(MAX)
	--	,@LinkSvr VARCHAR(100) = ''

	--SET @LinkSvr = CASE 
	--		WHEN @@SERVERNAME = N'AZUVPSQLDTDB007' -- DWS-ETL01.DATATREE.LOCAL,1433
	--			THEN 'DWS-ETL02.'
	--		WHEN @@SERVERNAME = N'AZUVPSQLDTDB029' --AZUVPSQLDTDB029.datatree.local
	--			THEN ''
	--		ELSE '' -- AZUVNSQLDTDB003
	--		END

	DECLARE @date VARCHAR(20) = replace(replace(replace(replace(cast(getdate() AS DATETIME2), '-', ''), ' ', ''), ':', ''), '.', '')

	SET @sql = N'

SELECT *
INTO assr.dbo.Pet_Daily_INCR_Refids_' + @date + '
FROM assr.dbo.Pet_Daily_INCR_Refids



'

	--Select @sql as N'@sql'
	EXEC (@sql)
		--delete A from assr.dbo.Pet_Daily_INCR_Refids  a where a.fips not in (24039)
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


