/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_INFC_ETL_END | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_INFC_ETL_END] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'usp_INFC_ETL_END'
		,N'Started'

	DECLARE @date_from DATETIME2 = NULL
		,@date_to DATETIME2 = NULL

	SELECT @date_from = From_Date
		,@date_to = To_Date
	FROM [lien].[UR].[INFC_run_dates_temp]

	EXEC [Lien].[UR].[usp_Set_INFC_RunDates_Success] @date_from = @date_from
		,@date_to = @date_to
		,@ERROR = @ERROR OUTPUT

	TRUNCATE TABLE [lien].[UR].[INFC_run_dates]

	INSERT INTO [Lien].[UR].[INFC_run_dates] (
		[From_Date]
		,[To_Date]
		)
	SELECT [From_Date]
		,[To_Date]
	FROM [Lien].[UR].[INFC_run_dates_temp]

	truncate table [lien_dtdb].[dbo].[DTDB_DocIdExtract_fix]

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'usp_INFC_ETL_END'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	ROLLBACK
END CATCH


