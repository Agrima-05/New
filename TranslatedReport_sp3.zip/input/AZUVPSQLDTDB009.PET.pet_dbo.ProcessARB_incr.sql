/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.ProcessARB_incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
CREATE 
 PROCEDURE [PET].[pet_dbo].[ProcessARB_incr] @fips VARCHAR(5) = NULL  
 ,@ERROR VARCHAR(500) OUTPUT  
AS  
/******************************************************************************************************************  
CHANGE LOG:  
==========  
who  date  change  
Henk 4/14/2022 Initial version  
paul 7/31/22  add begin transaction logic  
  
DECLARE   
 @Fips INT = 26045  
  
 ,@ERROR VARCHAR(500)   
  
EXEC [PET].[pet_dbo].[ProcessARB_incr]  
 @Fips = @fips  
 ,@ERROR = @ERROR  OUTPUT  
  
  
  
  
******************************************************************************************************************/  
BEGIN  
 BEGIN TRY  
  --EXEC PET.[dbo].[AddPetLog] @Fips  
  -- ,N'info'  
  -- ,N'ProcessARB_incr'  
  -- ,N'Started'  
     



  --declare  @fips VARCHAR(5) = 56041  
  
  
  SET NOCOUNT ON;  
  
  DECLARE @sqlcmd VARCHAR(max)  
  
  SET @sqlcmd =   
   '  
DROP TABLE

IF EXISTS #fips_neo_apn
	SELECT DISTINCT fips
		,neo_apn
	INTO #fips_neo_apn
	FROM PET.pet_tmp.Pet_Incremental_Add

CREATE UNIQUE CLUSTERED INDEX idx_fips_neo_apn ON #fips_neo_apn (
	fips
	,neo_apn
	)



  begin transaction  
  UPDATE p  
  SET LEGAL_DESC_APN_ARB = a.legal_desc_apn_arb  
     
  FROM PET.dbo.PET_NEO_LEGALS p WITH (
		NOLOCK
		,INDEX (ix_fipsNEO)
		)
INNER JOIN #fips_neo_apn z ON z.fips = p.fips
	AND z.neo_apn = p.neo_apn
  OUTER APPLY (  
   SELECT label1  
    ,value1  
    ,label2  
    ,value2  
    ,label3  
    ,value3  
    ,label4  
    ,value4  
    ,label5  
    ,value5  
    ,label6  
    ,value6  
    ,label7  
    ,value7  
    ,label8  
    ,value8  
    ,label9  
    ,value9  
    ,label10  
    ,Value10  
    ,label11  
    ,value11  
    ,label12  
    ,value12  
    ,label13  
    ,value13  
    ,label14  
    ,value14  
    ,label15  
    ,value15  
    ,label16  
    ,value16  
    ,label17  
    ,value17  
    ,label18  
    ,value18  
    ,label19  
    ,value19  
    ,label20  
    ,value20  
    ,label21  
    ,value21  
    ,label22  
    ,value22  
    ,label23  
    ,value23  
  ) n  
  OUTER APPLY (
	SELECT p.NEO_APN AS legal_desc_apn
	) n2


  outer apply (  
   SELECT p.[NEO_LAND_TYPE] AS dl_land_type  
  ) b  
  OUTER APPLY (  
   SELECT iif(dl_land_type = ''SB'' AND isnull(n.Label1, '''') = ''Book'' AND substring(isnull(n.value1, ''''),1,1) = ''A'',substring(isnull(n.value1, ''''),2,10),n.value1) as _arb_book  
  ) arb  
  outer apply (  
   SELECT '   
   + [PET].[dbo].[fn_parseArb](@fips) + '  
   ) a  

   commit'  
  
  --SELECT @sqlcmd  
  EXEC (@sqlcmd)  
  
 
  
  --EXEC PET.[dbo].[AddPetLog] @Fips  
  -- ,N'info'  
  -- ,N'ProcessARB_incr'  
  -- ,N'Ended'  
 END TRY  
  
 BEGIN CATCH  
  SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())  
  
  --ROLLBACK  
  RAISERROR (  
    @ERROR  
    ,16  
    ,1  
    )  
 END CATCH  
END  
  

