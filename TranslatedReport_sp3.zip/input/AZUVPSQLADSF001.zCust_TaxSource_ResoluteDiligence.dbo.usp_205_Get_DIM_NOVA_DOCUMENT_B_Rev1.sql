SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF







/*Add document that are linked through the DocXRef*/

CREATE PROCEDURE [zCust_TaxSource_ResoluteDiligence].[dbo].[usp_205_Get_DIM_NOVA_DOCUMENT_B_Rev1] 
AS
BEGIN
	
	--Drop table dbo.t2

	select x.* into [zCust_TaxSource_ResoluteDiligence].[dbo].[t2] 
	from [AZUVPSQLDTDB029.datatree.local].NovaDimDoc.dbo.DIM_NOVA_DOCUMENT x  with(nolock) 
	JOIN (Select Distinct * FROM (
		SELECT FIPS,DOC_REF_ID as DOC_ID FROM  [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DOC_XREF] 
		UNION ALL
		SELECT FIPS,DOC_ID FROM  [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DOC_XREF]) DATA) d
	ON x.FIPS = d.FIPS
		and x.Doc_Id = d.DOC_ID

	INSERT INTO [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DIM_NOVA_DOCUMENT]
		( [Doc_Id]
		  ,[Fips]
		  ,[Doc_Number]
		  ,[Source_Doc_Number]
		  ,[Property_Id]
		  ,[Cmt_Id]
		  ,[Doc_Description]
		  ,[Doc_Type]
		  ,[Recording_Date]
		  ,[Filing_Date]
		  ,[Doc_Src_Ind]
		  ,[Loan_Amt]
		  ,[Transfer_Amt]
		  ,[Arms_Length]
		  ,[Lien_Position]
		  ,[Foreclosure_flag]
		  ,[Fraud_Flag]
		  ,[Assignment_Flag]
		  ,[Release_Flag]
		  ,[Subordination_Flag]
		  ,[Modification_Flag]
		  ,[ReoSale_Flag]
		  ,[Delinquency_Flag]
		  ,[Created_Date]
		  ,[Updated_Date]
		  ,[Sr_Unique_Id]
		  ,[Hist_Sr_Full_Part_Code]
		  ,[Hist_Sr_Int_Rate_Type]
		  ,[Hist_Sr_Mult_Port_Code]
		  ,[Sr_Ownership_Status_Code]
		  ,[Mtg_Term]
		  ,[Mtg_Term_TYPE]
		  ,[Loan_Type]
		  ,[Int_Rate]
		  ,[Short_Sale_Flag]
		  ,[Rate_Type]
		  ,[Raps_Doc_Ind]
		  ,[REF_ID]
		  ,[Source_Type]
		  ,[Doc_Nbr_Ind]
		  ,[confidence]
		  ,[lien_pos]
		  ,[IsVerified])

		SELECT 
			d.[Doc_Id]
			,d.[Fips]
			,d.[Doc_Number]
			,d.[Source_Doc_Number]
			,d.[Property_Id]
			,d.[Cmt_Id]
			,d.[Doc_Description]
			,d.[Doc_Type]
			,d.[Recording_Date]
			,d.[Filing_Date]
			,d.[Doc_Src_Ind]
			,d.[Loan_Amt]
			,d.[Transfer_Amt]
			,d.[Arms_Length]
			,d.[Lien_Position]
			,d.[Foreclosure_flag]
			,d.[Fraud_Flag]
			,d.[Assignment_Flag]
			,d.[Release_Flag]
			,d.[Subordination_Flag]
			,d.[Modification_Flag]
			,d.[ReoSale_Flag]
			,d.[Delinquency_Flag]
			,d.[Created_Date]
			,d.[Updated_Date]
			,d.[Sr_Unique_Id]
			,d.[Hist_Sr_Full_Part_Code]
			,d.[Hist_Sr_Int_Rate_Type]
			,d.[Hist_Sr_Mult_Port_Code]
			,d.[Sr_Ownership_Status_Code]
			,d.[Mtg_Term]
			,d.[Mtg_Term_TYPE]
			,d.[Loan_Type]
			,d.[Int_Rate]
			,d.[Short_Sale_Flag]
			,d.[Rate_Type]
			,d.[Raps_Doc_Ind]
			,d.[REF_ID]
			,d.[Source_Type]
			,d.[Doc_Nbr_Ind]
			,d.[confidence]
			,d.[lien_pos]
			,d.[IsVerified]		  
		FROM  [zCust_TaxSource_ResoluteDiligence].[dbo].[t2] d LEFT JOIN [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DIM_NOVA_DOCUMENT] e on d.Doc_Id = e.Doc_ID 
        WHERE e.Doc_ID is null  

		UPDATE [zCust_TaxSource_ResoluteDiligence].[dbo].[d] 
		SET d.REF_ID = x.REF_ID
		FROM [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DIM_NOVA_DOCUMENT] d inner join [zCust_TaxSource_ResoluteDiligence].[dbo].[w_DOC_XREF] x 
		ON (d.Doc_Id = x.DOC_ID or d.Doc_Id = x.DOC_REF_ID) and d.REF_ID = 0

		Drop table dbo.t2
END





