SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_NTC].[dbo].[usp_300_Start_Output_NTC_REL_STEP3]

AS
BEGIN
	
	SET NOCOUNT ON;


		-------20250624 per EC:
	----1.	If we don’t have the REL Image – we’re not returning the REL recording data – correct? 6/24: Correct
	----2.	Also – if we don’t have the REL Image – are we also NOT returning the Matched Mtg data? 6/24: Correct



		Select XosStatus, count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XosStatus


		Update [zCust_NTC].[dbo].[A]
		Set 
		A.[MTGRecording Date] = NULL
		,A.[MTGLoan Amount] = NULL	
		,A.[MTGInstrument #] = NULL
		,A.[MTGBookPage] = NULL	
		,A.[MTGDoc Type] = NULL	
		,A.[MTGBorrower Name] = NULL
		--Select * 
		From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] as A 
		
		left outer join (Select INPUTKEY, count(*) as T From [zCust_NTC].[dbo].[z_Images_To_Pull]
		where XOSStatus like 'Completed'
		Group by INPUTKEY) B on A.[Unique ID] = B.INPUTKEY
		where B.INPUTKEY is null




		-------------------------------------ADD BUILDOUT SECTIONS for those with images & set flag is there are recordings with no images!!!!!--------------------------------------------

		Truncate table [w_TransHist_II_NOIMAGE]
		
		Insert into [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE]
		Select A.*
		--, B.ImageName
		--Select * 
		From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join [zCust_NTC].[dbo].[z_Images_To_Pull] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.RAW_ID + '_' + 'REL' + '_' +  A.DocumentNbr
		 = B.ImageName
		 where 
		 (ISNULL(B.XosStatus,'') not like 'COmpleted')

	
	

		 Delete from [zCust_NTC].[dbo].[A]
		 --Select *
		 From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on 
		A.RAW_ID = B.RAW_ID
		and A.Doc_Id = B.DOC_ID
		and A.Doc_Src_Ind = B.Doc_Src_Ind
		and A.RecordingDate = B.RecordingDate


		Delete from [zCust_NTC].[dbo].[z_Images_To_Pull]
		where ISNULL(XosStatus,'') not like 'COmpleted'


		 Select count(*)  From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		 Select count(*)  From [zCust_NTC].[dbo].[z_Images_To_Pull] as A 
		 where XosStatus like 'Completed' 
		 and [DOCTYPE] in ('REL')


		 Select [DOCTYPE], count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull] as A 
		 where XosStatus like 'Completed' 
		 Group by [DOCTYPE]
		 Order by [DOCTYPE]


		 Select ToUse ,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		 Group by ToUse



		
	----------------------------------------------------REL----------------------------------------------------------------
		Select DocumentType,ToUse, count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		Group by DocumentType,ToUse
		Order by DocumentType,ToUse


		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[RELRecordingNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse Like 'R%'
		 
		

		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse Like 'R%' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'R%'
		Group by RAW_ID
		having count(*) > 1


		Select A.RAW_ID, A.REF_ID, A.RecordingDate, A.DocumentNbr, A.RecordNumber From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'R%'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse Like 'R%'
		Order by A.RAW_ID, A.RecordNumber 

		

		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse Like 'R%'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]
		where NbrofRecords > 0

		Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]

		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]) > 0
		BEGIN
		

		

		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans4 int
		Declare @EndNbrOfTrans4 int
		
		SET @BeginNbrOfTrans4 = 1
		Select @EndNbrOfTrans4 =  MAX(convert(int,NbrofRecords))   FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]

			WHILE (@BeginNbrOfTrans4 <= @EndNbrOfTrans4)
				BEGIN
				 
					DECLARE @RecNbr4 as varchar(5)
					SET @RecNbr4 = RIGHT('000' + convert(varchar(5),(@BeginNbrOfTrans4 )),3)
					
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELRecording Date_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELInstrument #_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELBookPage_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELDoc Type_' + @RecNbr4 + '] [varchar](250) NULL')


					
						EXEC('UPDATE A
						SET 
						A.[RELRecording Date_' + @RecNbr4 + '] = B.Recordingdate
						,A.[RELInstrument #_' + @RecNbr4 + '] = case when B.DocumentNbr = B.FMT_Book_Page then NULL else B.DocumentNbr end
						,A.[RELBookPage_' + @RecNbr4 + '] = case when ISNULL(B.FMT_Book_Page,'''') not like '''' then B.FMT_Book_Page else NULL END
						,A.[RELDoc Type_' + @RecNbr4 + '] = B.DocumentType



						--Select B.*
						FROM x_Custom_OUTPUT_REL A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse like ''R%''
						and 
						B.[RecordNumber] = ' + @BeginNbrOfTrans4 + '')


					
						EXEC('UPDATE a
						SET 
						 A.[RELDoc Type_' + @RecNbr4 + '] = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_REL as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[RELDoc Type_' + @RecNbr4 + '] = C.Value
						WHERE B.ToUse like ''R%''
						AND B.[RecordNumber] = ' + @BeginNbrOfTrans4 + '')
					

											
					SET @BeginNbrOfTrans4 = @BeginNbrOfTrans4 + 1
				
				END 

		END

		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]
		where NbrofRecords > 0
		Order by convert(int,NbrofRecords) desc


	


		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]) is null
		BEGIN
		-------Build 1 set even if no records to return 

				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELRecording Date] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELInstrument #] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELBookPage] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_REL ADD [RELDoc Type] [varchar](250) NULL')


		END


		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]



		
		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]
		where NbrofRecords > 0
		Order by convert(int,NbrofRecords) desc


	

		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL]


		
		Update [zCust_NTC].[dbo].[A]
		Set A.[Total Doc Image Count] = B.TOTAL
		From [zCust_NTC].[dbo].[x_Custom_OUTPUT_REL] as A join 
		(Select INPUTKEY, count(*) as TOTAL  From [zCust_NTC].[dbo].[z_Images_To_Pull]
		where xosstatus like 'Completed'
		Group by INPUTKEY)B
		on A.[Unique ID] = B.INPUTKEY



		Update [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL] 
		SET [In Coverage] = CASE WHEN [In Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		--Update  a
		--SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		--FROM X_CUSTOM_OUTPUT_REL a JOIN 
		--[dbo].a_ASP_IN_STD b
		--on a.[INPUTKEY] = b.Raw_ID

		Update [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_NTC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL] a join [zCust_NTC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		Select * From [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
	
		-----Per workorder - REL Image = Event Found
		Update  [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		SET [Event Status] = CASE WHEN [Total Doc Image Count] > 0 then 'Event Found' else 'Event Not Found' end
		

		Select [Property Status], count(*) From [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		Group by [Property Status]

		--Select [Address Standardization], count(*) From X_CUSTOM_OUTPUT_REL
		--Group by [Address Standardization]
		
		Select [Event Status], count(*) From [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		Group by [Event Status]

		Select [In Coverage], count(*) From [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		Group by [In Coverage]

		Select * From  [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL] as A 
		where 
		([Event Status] like 'Event Not Found'
		and [Total Doc Image Count] > 0)
		OR
		([Event Status] like 'Event Found'
		and [Total Doc Image Count] is null)


		Select * From  [zCust_NTC].[dbo].[X_CUSTOM_OUTPUT_REL]
		where [Total Doc Image Count] > 0



END






