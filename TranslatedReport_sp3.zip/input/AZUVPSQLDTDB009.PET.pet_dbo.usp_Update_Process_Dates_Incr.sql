/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Update_Process_Dates_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:		Sean Dang
-- Create date: 02/12/2025
-- Description:	Update Process Date For PET_Incremental
-- =============================================
CREATE PROCEDURE [PET].[pet_dbo].[usp_Update_Process_Dates_Incr]
	-- Add the parameters for the stored procedure here
	(
	 	 @Fips INT = 0,
		 @ERROR VARCHAR(500) OUTPUT
	 )
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Update_Process_Dates_Incr'
		,N'Started'

    -- Insert statements for procedure here
	UPDATE [PET].[pet_dbo].[c]
	SET c.Incremental_Process_Date = GETDATE()
	FROM [Pet].[Dbo].[Pet_Counties] c with(nolock, index(idxc_fips))
	WHERE c.fips =  @Fips

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Update_Process_Dates_Incr'
		,N'Ended'

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

