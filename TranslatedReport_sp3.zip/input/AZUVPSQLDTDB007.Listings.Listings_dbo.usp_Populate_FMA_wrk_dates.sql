/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Populate_FMA_wrk_dates | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Populate_FMA_wrk_dates] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Populate_FMA_wrk_dates'
		,N'Started'

	DECLARE @created DATETIME = (
			SELECT TOP 1 created
			FROM [LISTINGS].[Listings_dbo].[FMA_Daily_Ads_Sean] WITH (
					NOLOCK
					,INDEX (idx_created)
					)
			ORDER BY created DESC
			)

	DROP TABLE

	IF EXISTS [listings].[listings_tmp].[FMA_Daily_Ads_wrk]
		SELECT *
		INTO [listings].[listings_tmp].[FMA_Daily_Ads_wrk]
		FROM [LISTINGS].[Listings_dbo].[FMA_Daily_Ads_Sean] WITH (
				NOLOCK
				,INDEX (idx_created)
				)
		WHERE CREATEd = @created

	CREATE INDEX idx_created ON [listings].[listings_tmp].[FMA_Daily_Ads_wrk] (created)

	CREATE CLUSTERED INDEX idx_snapshot_id ON [listings].[listings_tmp].[FMA_Daily_Ads_wrk] (snapshot_id)

	SET @created = (
			SELECT TOP 1 created
			FROM [LISTINGS].[Listings_dbo].[FMA_Snapshot_Sean] WITH (
					NOLOCK
					,INDEX (idx_created)
					)
			ORDER BY created DESC
			)

	DROP TABLE

	IF EXISTS [listings].[listings_tmp].[FMA_Snapshot_wrk]
		SELECT *
		INTO [listings].[listings_tmp].[FMA_Snapshot_wrk]
		FROM [LISTINGS].[Listings_dbo].[FMA_Snapshot_Sean] WITH (
				NOLOCK
				,INDEX (idx_created)
				)
		WHERE CREATEd = @created

	CREATE INDEX idx_id ON [listings].[listings_tmp].[FMA_Snapshot_wrk] (id)

	--RETURN --- we need to remove this when we start running in parrallel - since we are still copying the snapshot load from famls
	--DECLARE @created DATETIME = getdate()
	--UPDATE a
	--SET a.created = @created
	--FROM Listings.Listings_tmp.FMA_Snapshot_wrk a
	--OPTION (
	--	RECOMPILE
	--	,MAXDOP 12
	--	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--	);
	--UPDATE a
	--SET a.created = @created
	--FROM LISTINGS.Listings_tmp.FMA_Daily_Ads_wrk a
	--OPTION (
	--	RECOMPILE
	--	,MAXDOP 12
	--	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--	);
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Populate_FMA_wrk_dates'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


