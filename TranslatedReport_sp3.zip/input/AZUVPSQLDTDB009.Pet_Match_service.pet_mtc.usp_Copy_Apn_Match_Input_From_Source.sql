/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.usp_Copy_Apn_Match_Input_From_Source | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

 create   PROCEDURE [Pet_Match_service].[pet_mtc].[usp_Copy_Apn_Match_Input_From_Source] @Fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Copy_Apn_Match_Input_From_Source: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Started'

	-- select * from 	PET_Match_Service.PET_MTC.Match_Request
	-- DECLARE @Fileid INT = 1
	DECLARE @DbName VARCHAR(100) -- = 'Listings'
	DECLARE @SchemaName VARCHAR(100) --= 'Listings_tmp'
	DECLARE @Input_file VARCHAR(100) --= 'Pet_Apn_Match_Result'
	DECLARE @ServerName VARCHAR(100)

	SELECT @DbName = ltrim(rtrim(a.DbName))
		,@SchemaName = ltrim(rtrim(a.SchemaName))
		,@Input_file = ltrim(rtrim(a.Input_file))
		,@ServerName = ltrim(rtrim(a.ServerName))
	FROM [PET_Match_Service].[PET_MTC].[Match_Request] a
	WHERE fileid = @fileid

	DECLARE @Link VARCHAR(100) = (
			SELECT CASE 
					WHEN @ServerName = N'AZUVPSQLDTDB007' -- etl01
						THEN '[DWS-ETL01].'
					ELSE ''
					END
			)
	DECLARE @TableName VARCHAR(200) = @Link + @DbName + '.' + @SchemaName + '.' + @Input_File
	--SELECT @TableName
	DECLARE @SQL VARCHAR(max)

	SET @SQL = '
		
		INSERT INTO  [PET_Match_Service].[PET_MTC].[Apn_match]
           ([Fileid]
           ,[id]
           ,[Fips]
           ,[Apn]
           ,[Apn_Seq]
           ,[_apn]
           ,[ca_apn1]
           ,[ca_apn2]
           ,[ca_apn3]
           ,[spaceAPN]
           ,[_add_apn_match]
           ,[Created]
           ,[Updated]
           ,[Use_Actual_Fips])
 
SELECT  ' + CAST(@Fileid AS VARCHAR) + ' as[Fileid]
      ,[Id]
      ,[Fips]
      ,[Apn]
      ,[Apn_Seq]
      ,[_apn]
      ,[ca_apn1]
      ,[ca_apn2]
      ,[ca_apn3]
      ,[spaceAPN]
      ,[_add_apn_match]
      ,[Created]
      ,[Updated]
      ,[Use_Actual_Fips]
  FROM ' + @TableName

	--	PRINT @SQL
	EXEC (@SQL)

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

