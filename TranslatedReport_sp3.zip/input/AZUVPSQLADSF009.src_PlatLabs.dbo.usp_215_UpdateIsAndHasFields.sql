SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [src_PlatLabs].[dbo].[usp_215_UpdateIsAndHasFields]
  --   @description varchar(max),
	 --@mls_property_type varchar(250),
	 --@mls_property_sub_type varchar(250),
	 --@property_type varchar(250)

As
Begin

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


/******** Populate has_horse_property *******/------------------

		   Update [src_PlatLabs].[listing].[ListingsRaw_Batch] 
              SET has_horse_property = 'true'
              Where [description] like '%horse%'
              and has_horse_property is NULL

/******** Populate has_mountain_view *******/------

			Update [src_PlatLabs].[listing].[ListingsRaw_Batch] 
              SET has_mountain_view = 'true'
              Where [description] like '%mountains%'
			  and [description] like '%mountain%'
			  and has_mountain_view is NULL

/******** Populate has_open_house *******/-------

		    --update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		    --  SET has_open_house = 'true'
		    --  where [description] like '%open house%'
		    --  and has_open_house is null

/******** has_pool *******/-------------------

		  update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		    set has_pool = case
		                   when [description] like '%pool%'
						        and [description] not like '%cesspool%'
						        and [description] not like '%whirlpool%'
						        and [description] not like '%pool table%'
								and [description] not like '%no pool%' then 'true'
						   when [description] like '% no pool %'
						        or [description] like 'no pool%'
								or [description] like '% no pool'
								or [description]  = 'no pool ' then 'false'
							else has_pool -------preserve current value for rows that do not match any condition
						  end
		where has_pool is null;

/******** has_price_reduced *******/----------------------------

		 update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		 SET has_price_reduced = 'true'
		 where ([description] like '%price reduced%'
			OR confidential_description like '%reduce%')
		 and has_price_reduced is null

/******** has_view *******/ ---------------------------
       
       update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	   set has_view = case
	                     when property_view_description is not null
						      and lower(property_view_description) != 'none' then 'true'
						
						 else has_view
					end;

/******** has_waterfront *******/------------------------

        update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	    set has_waterfront = case
	                            when waterfront_description is not null 
								     and lower(waterfront_description) != 'none' then 'true'
							    else cast(NULL as varchar(10))
						end;

/******** has_waterview *******/-----------------------

        --select has_waterview, [description] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK)
        --where [description] like '%waterview%';

		 update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		 SET has_waterview = 'true'
		 where ([description] like '%waterview%'
		 OR [description] like '%water view%')
		 and has_waterview is null

/******** Populate has_basement *******/
             update [src_PlatLabs].[listing].[ListingsRaw_Batch] 
              SET has_basement = 'true'
              where Basement_Description is not null 
			  and basement_description not in('None','No Basement','Not Included','NULL','on slab','None.')
              and basement_description not like '%slab%'
              and has_basement is NULL

/************ Populate has_electricity ***********************************/
			  Update [src_PlatLabs].[listing].[ListingsRaw_Batch]     
              SET has_electricity = 'true'
              Where (utilities like '%Electric%'
              AND utilities Not like '%Electricity Not Available %')
              and has_electricity is NULL

/***************Populate has_Sewer *******************************/ 
			  Update [src_PlatLabs].[listing].[ListingsRaw_Batch]    
              SET has_sewer = 'true'
              Where (utilities like '%sewer%' 
			  or utilities like '%septic%')
              and has_sewer is NULL

/****************** Populate has_water ************************/ 
			  Update [src_PlatLabs].[listing].[ListingsRaw_Batch]  
              SET has_water = 'true'
              Where (utilities like '%water%' 
			  and utilities Not like '%Haul water%')
              and has_water is NULL

 /******** Populate has_fireplace *******/ 

  UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
  SET has_fireplace = 'true' 
    Where fireplace_description like '%Gas%' 
	  OR fireplace_description like '%Electric%' 
	  OR fireplace_description like '%Wood%'
	  OR fireplace_description like '%Fire%'
	  OR fireplace_description like '%Propane%'
	  And fireplaces > 0 or fireplaces is not null
	  And has_fireplace is null

/******************** Populate has_garage ********************/

UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET has_garage = 'true'  ----- updated once with uppercase 'TRUE' -----
WHERE
   (garage_description LIKE '%garage%'
OR parking_description like '%garage%' ) 
And garage_spaces > 0 
AND (has_garage IS NULL OR 
     has_garage = 'FALSE')

/******************** Populate has_Hoa ********************/

UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
SET has_hoa = 'True'
WHERE
   description LIKE '%Hoa%'
   AND description Not like '%No Hoa%' 
   AND hoa_fee_includes not in ('no fees', 'None') 
   OR hoa_fee >0 
   AND hoa_fee is not null
   OR hoa_amenities is not null 
   AND (has_HOA IS NULL OR 
       has_HOA = 'FALSE')

----------------------------------------------------------------------------------------------------------------------------------------------------------------

/******** is_fields *******/

-------------------------------------------------------------------------------------------------------------------------------------------------------------------

/******** is_adult_community *******/

		 update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		 SET is_adult_community = 'true'
		 where [description] like '%adult community%'
		 and is_adult_community is null

/******** is_boat_slip *******/
       
	    update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		 SET is_boat_slip = 'true'
		 where [description] like '%boat slip%'
		 and is_boat_slip is null

/******** is_commercial *******/--------------------------

     update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	  set is_commercial = 'true'
	  where [mls_property_type] like '%commercial%'
	  and [mls_property_sub_type] like '%commercial%'
	  and is_commercial is null

/******** is_commercial_lease*******/

    update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	  set is_commercial_lease = 'true'
	  where [description] like '%commercial lease%'
   and [mls_property_sub_type] like '%commercial lease%'
	  and is_commercial_lease is null

/******** is_condo*******/-----------

      update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	  set is_condo = 'true'
	  where [mls_property_type] like '%condo%'
	  and [mls_property_sub_type] like '%condo%'
	  and is_condo is null

/******** is_condo_townhouse*******/-----------

      update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	  set is_condo_townhouse = 'true'
	  where [mls_property_type] like '%townhouse%'
     and [mls_property_sub_type] like '%townhouse%' 
	 and is_condo_townhouse is null


/******** is_coop***********************/--------

		  update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		  set is_coop = 'true'
		  where [mls_property_sub_type] like 'coop'
		  and [description] like 'coop'
		  and is_coop is null

/******** is_cul_de_sac***********************/

	   	 update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		 SET is_cul_de_sac = 'true'
		 where [description] like '%cul_de_sac%'
		 and is_cul_de_sac is null


/******** is_duplex***********************/

		   update [src_PlatLabs].[listing].[ListingsRaw_Batch]
		   set is_duplex = 'true'
			 where [mls_property_type] like '%duplex%'
		   and  [mls_property_sub_type] like '%duplex%';

/******** is_foreclosure***********************/
 
	 update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	 set is_foreclosure = case
	    when is_foreclosure is not null 
				and lower(is_foreclosure) != 'none' then 'true'
		else cast(NULL as varchar(10))
						end;

 /******** is_gated_community***********************/

  update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	   set is_gated_community = 'true'
	     where [description] like '%gated community%';

/******** is_golf_community***********************/

    update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	   set is_golf_community = 'true'
	     where [description] like '%golf community%';

/******** is_industrial***********************/
  
	   update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	   set is_industrial = 'true'
	     where [mls_property_sub_type] like '%industrial%';

/******** is_investment***********************/

	   update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	   set is_investment = 'true'
	     where [description] like '%investment%'
		 and [mls_property_sub_type] like '%investment%';

/*********************************Populate is_two_story ***********************************/ 
  UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
  SET  is_two_story = 'true' 
  Where stories_description = 'two story' 
  And is_two_story is null

  /*********************************Populate is_one_story ***********************************/ 
  UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
  SET  is_one_story = 'true' 
  Where stories_description = 'one story' 
  And is_one_story is null

 /*********************************Populate is_three_story ***********************************/ 
   UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
  SET  is_three_plus_story = 'true' 
  Where stories_description = 'one story' 
  And is_three_plus_story  is null

  /*********************************Populate is_mixed_use ***********************************/ 
     UPDATE [src_PlatLabs].[listing].[ListingsRaw_Batch] 
  SET  is_mixed_use = 'true' 
  Where description  like '%mixed use%' 
  And  is_mixed_use  is null

/*********************************Populate is_Loft ***********************************/ 
  --UPDATE listing.ListingsRaw_Batch 
  --SET  is_loft = 'true' 
  --Where description like '%loft%' 
  --And is_loft is null

 /*********************************Populate is_Lot ***********************************/ 
  Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
  SET is_lot = 'true'
  where property_type = 'land'
  and description  like '%vacant lot%'
  and is_lot is null 

 /*********************************Populate is_mobile_home ***********************************/ 
     Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
	 SET  is_loft = 'true' 
     where property_type = 'mobile'
	 and is_mobile_home is null 

/*************************************Populate is_rental****************************************/ 

Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
set is_rental = 'true'
where is_rental is null and price < 10000

/*************************************Populate is_multi_family****************************************/ 

Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
set is_multi_family = 'true'
where is_multi_family is null and property_type = 'multi'

/*************************************Populate is_single_family****************************************/ 

Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
set is_single_family = 'true'
where is_single_family is null and property_type = 'single'

/*************************************Populate is_townhouse****************************************/ 

Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
set is_townhouse = 'true'
where is_townhouse is null and property_type = 'townhouse'

/***************************************************** Populate is_single_family_detached***********************************/ 

Update [src_PlatLabs].[listing].[ListingsRaw_Batch]
set is_townhouse = 'true'
where property_type = 'single'
and (mls_property_sub_type = 'Single family attached'
or mls_property_sub_type = 'SF/attached'
or mls_property_sub_type ='attached'
or mls_property_sub_type like '% - attached%'
or mls_property_sub_type ='%House (attached)%')
    
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END

