/* Source: AZUVNSQLDTDB003.datatree.local | Listings | pet_mtc.usp_APN_Pet_MAtch_Input | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[pet_mtc].[usp_APN_Pet_MAtch_Input] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_APN_Pet_MAtch_Input :' + try_cast(@fileid AS VARCHAR(20))

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'


		

	--
	TRUNCATE TABLE [LISTINGS].[Listings_tmp].[Pet_Apn_Match]
	TRUNCATE TABLE [LISTINGS].[Listings_tmp].[Pet_Apn_Match_result]
	INSERT INTO [LISTINGS].[Listings_tmp].[Pet_Apn_Match] (
		[Id]
		,[Fips]
		,[Apn]
		,[Apn_Seq]
		,[_apn]
		,[ca_apn1]
		,[ca_apn2]
		,[ca_apn3]
		,[spaceAPN]
		,[_add_apn_match]
		,[Created]
		,[Updated]
		,[Use_Actual_Fips]
		)
	SELECT 
		-- select 
		a.Row_id AS Id
		,b.Fips
		,a.Apn
		,cast(1 AS VARCHAR(3)) AS Apn_Seq
		,cast(REplace(REplace(replace(replace(a.apn, ' ', ''), '-', ''), '.', ''), '/', '') AS VARCHAR(60)) AS _apn
		,a.apn + '-000' AS ca_apn1
		,a.apn + '-00' AS ca_apn2
		,a.apn + '-0' AS ca_apn3
		,replace(ltrim(rtrim(a.apn)), ' ', '') AS spaceAPN
		,CASE 
			WHEN b.fips IN (
					12097
					,12059
					,8069
					,41035
					,12005
					)
				AND substring(a.apn, 1, 1) = 'R'
				THEN substring(a.apn, 2, 59)
			WHEN b.fips IN (55025)
				AND substring(a.apn, 4, 1) IN (
					'/'
					,'-'
					)
				THEN substring(a.apn, 5, 60)
			WHEN b.fips IN (
					8001
					,53011
					)
				AND substring(a.apn, 1, 1) = '0'
				THEN substring(a.apn, 2, 59)
			WHEN b.fips IN (56039)
				AND substring(a.apn, 1, 2) = '22'
				THEN substring(a.apn, 3, 589)
			WHEN b.fips IN (26093)
				AND substring(a.apn, 1, 2) = '47'
				THEN substring(a.apn, 3, 589)
			WHEN b.fips IN (6001)
				AND len(ltrim(rtrim(a.apn))) IN (15)
				THEN substring(rtrim(ltrim(a.apn)), 1, 3) + ' ' + substring(ltrim(rtrim(a.Apn)), 4, 60)
			WHEN b.fips IN (6001)
				AND len(ltrim(rtrim(a.apn))) IN (12)
				THEN substring(ltrim(rtrim(a.apn)), 1, 3) + ' ' + substring(ltrim(rtrim(a.Apn)), 4, 60) + '-00'
			ELSE NULL
			END AS _add_apn_match
		,getdate() AS Created
		,getdate() AS Updated
		,0 AS Use_Actual_Fips
	FROM [listings].[Listings_dbo].[FA_MLS_Wrk] a WITH (
			NOLOCK
			,INDEX (IDX_address)
			)
	INNER JOIN [LISTINGS].[Listings_tmp].[Listings_Raw_Std_Address_wrk] b WITH (
			NOLOCK
			,INDEX (IDX_Listings_Rowid_address)
			) ON isnull(b.Raw_HOUSE_NBR, '') = isnull(a.HOUSE_NBR, '')
		AND b.Raw_STREET = a.STREET
		AND b.Raw_CITY = a.CITY
		AND b.Raw_STATE = a.STATE_1
		AND b.Raw_ZIP = a.ZIP
		AND b.Raw_Address = a.Raw_Address
	--WHERE a.Ref_id IS NULL
	-- AND a.Created > @date_from
	WHERE a.apn IS NOT NULL
		AND b.fips > 0
		AND isnull(b.ref_id, '') = ''

	--ORDER BY row_id DESC
	--
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


