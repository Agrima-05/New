/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.GetDynamicFormat | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- =============================================
CREATE PROCEDURE [PET].[dbo].[GetDynamicFormat] @FeatureName AS VARCHAR(50)
	,@ServiceName AS VARCHAR(50)
	,@FormatId AS VARCHAR(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @SQL NVARCHAR(4000)
		,@OrderSTR NVARCHAR(200)

	SET @OrderSTR = ' ORDER BY SubFormatId,Offset'

	IF (UPPER(@ServiceName) = 'ARB')
		SET @OrderSTR = ' ORDER BY SubFormatId,Offset,Field'
	SET @SQL = 
		' Select a.*
		,ROW_NUMBER( ) OVER ( PARTITION BY 0  ' +  @OrderSTR +' ) AS ROW4
		 from (
		SELECT F.[Name] AS FeatureName
		,S.[Name] AS ServiceName
		,df.[FormatId]
		,df.[SubFormatId]
		,df.[Field]
		,df.[Offset]
		,df.[Length]
		,df.[Justification]
		,df.[PadChar]
		,df.[FollowSuffixRule]
		,df.[IsThruField]
		,df.[OutputField]
		,df.[LongDesc]
		,df.[Label]
		,df.[MsgLabel]
		,df.[Partner]
		,df.[PartnerType]
		,df.[WildStart]
		,df.[DataType]
		,df.[Required]
		,df.[Enumeration]
		,df.[TabIndex]
		,df.[FromField]
		,df.[DataTreeIndexes]
		--,df.[TabIndex]
		,df.FormatChar
		,0 as _overlay

		
	FROM [Dynamic_Format] DF
	INNER JOIN [Feature] F
		ON DF.FeatureId = F.FeatureId
	INNER JOIN [Service] S
		ON DF.ServiceId = S.ServiceId
	WHERE df.[IsThruField] <> 1 and df.[Offset] > 0 and  F.NAME = '''+ @FeatureName + '''
		AND S.NAME = ''' + @ServiceName + '''
		AND DF.[FormatId] = ''' + @FormatId + '''

	 ) a
	
	'
	+ @OrderSTR

	EXEC SP_EXECUTESQL @SQL;


	--UPDATE t1
	--SET t1._overlay = (
	--		SELECT count(1)
	--		FROM @GetDynamicFormat t2
	--		WHERE t2.ROW4 < t1.ROW4
	--			AND t1.Offset BETWEEN t2.Offset
	--				AND (t2.Offset + t2.[Length])
	--		)
	--FROM @GetDynamicFormat t1



END


/*
		AND DF.[FormatId] = ''' + @FormatId + '''' + @OrderSTR +
*/


--declare @GetDynamicFormat tmpGetDynamicFormat

--INSERT INTO @GetDynamicFormat (
--	[FeatureName]
--	,[ServiceName]
--	,[FormatId]
--	,[SubFormatId]
--	,[Field]
--	,[Offset]
--	,[Length]
--	,[Justification]
--	,[PadChar]
--	,[FollowSuffixRule]
--	,[IsThruField]
--	,[OutputField]
--	,[LongDesc]
--	,[Label]
--	,[MsgLabel]
--	,[Partner]
--	,[PartnerType]

--	,[WildStart]
--	,[DataType]
--	,[Required]
--	,[Enumeration]
--	,[TabIndex]
--	,[FromField]
--	,[DataTreeIndexes]
--	,[FormatChar]
--	,[_overlay]
--	,[ROW4]
--	)
--EXEC pet.dbo.GetDynamicFormat @FeatureName --'TITLE_SERVICES'
--	,@ServiceName --'SUBDIVIDED'
--	,@FormatId --@PPLNT_PLAT_ID_FRMT

 
--UPDATE t1
--SET t1._overlay = (
--		SELECT count(1)
--		FROM @GetDynamicFormat t2
--		WHERE t2.ROW4 < t1.ROW4
--			AND t1.Offset BETWEEN t2.Offset
--				AND (t2.Offset + t2.[Length])
--		)
--FROM @GetDynamicFormat t1

