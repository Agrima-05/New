/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_Update_Pet_Legal_Information | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
-- =====================================================================================================================
-- Author:		<Marie Pretorius>
-- Create date: <02/09/2022>
-- Description:	<Create Pet Name Entries from NOVACL>
-- =====================================================================================================================
 Create PROCEDURE [PET].[dbo].[usp_Update_Pet_Legal_Information] @Fips INT = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	7/31/22		Add the begin transaction logic
******************************************************************************************************************/
	BEGIN TRY
		BEGIN TRANSACTION

		/*===========================
  Reset all Legal information
  ===========================*/
		UPDATE [PET].[dbo].[p]
		SET p.NEO_LAND_TYPE = NULL
			,p.NEO_TITLE_LEGAL = NULL
			,p.NEO_APN = NULL
			,p.Label1 = NULL
			,p.Value1 = NULL
			,p.Label2 = NULL
			,p.Value2 = NULL
			,p.Label3 = NULL
			,p.Value3 = NULL
			,p.Label4 = NULL
			,p.Value4 = NULL
			,p.Label5 = NULL
			,p.Value5 = NULL
			,p.Label6 = NULL
			,p.Value6 = NULL
			,p.Label7 = NULL
			,p.Value7 = NULL
			,p.Label8 = NULL
			,p.Value8 = NULL
			,p.Label9 = NULL
			,p.Value9 = NULL
			,p.Label10 = NULL
			,p.Value10 = NULL
			,p.Label11 = NULL
			,p.Value11 = NULL
			,p.Label12 = NULL
			,p.Value12 = NULL
			,p.Label13 = NULL
			,p.Value13 = NULL
			,p.Label14 = NULL
			,p.Value14 = NULL
			,p.Label15 = NULL
			,p.Value15 = NULL
			,p.Label16 = NULL
			,p.Value16 = NULL
			,p.Label17 = NULL
			,p.Value17 = NULL
			,p.Label18 = NULL
			,p.Value18 = NULL
			,p.Label19 = NULL
			,p.Value19 = NULL
			,p.Label20 = NULL
			,p.Value20 = NULL
			,p.Label21 = NULL
			,p.Value21 = NULL
			,p.Label22 = NULL
			,p.Value22 = NULL
			,p.Label23 = NULL
			,p.Value23 = NULL
			,p.BookType = NULL
			,p.updated = GETDATE()
		FROM [pet].[dbo].[Pet] p WITH (INDEX (ix_Fips))
		WHERE p.fips = @Fips
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		/*=================================================
  Populate Legal information when matched to Xref
  ================================================*/
		UPDATE [PET].[dbo].[p]
		SET p.NEO_LAND_TYPE = l.NEO_LAND_TYPE
			,p.NEO_TITLE_LEGAL = l.NEO_TITLE_LEGAL
			,p.NEO_APN = a.APN
			,p.Label1 = l.Label1
			,p.Value1 = l.Value1
			,p.Label2 = l.Label2
			,p.Value2 = l.Value2
			,p.Label3 = l.Label3
			,p.Value3 = l.Value3
			,p.Label4 = l.Label4
			,p.Value4 = l.Value4
			,p.Label5 = l.Label5
			,p.Value5 = l.Value5
			,p.Label6 = l.Label6
			,p.Value6 = l.Value6
			,p.Label7 = l.Label7
			,p.Value7 = l.Value7
			,p.Label8 = l.Label8
			,p.Value8 = l.Value8
			,p.Label9 = l.Label9
			,p.Value9 = l.Value9
			,p.Label10 = l.Label10
			,p.Value10 = l.Value10
			,p.Label11 = l.Label11
			,p.Value11 = l.Value11
			,p.Label12 = l.Label12
			,p.Value12 = l.Value12
			,p.Label13 = l.Label13
			,p.Value13 = l.Value13
			,p.Label14 = l.Label14
			,p.Value14 = l.Value14
			,p.Label15 = l.Label15
			,p.Value15 = l.Value15
			,p.Label16 = l.Label16
			,p.Value16 = l.Value16
			,p.Label17 = l.Label17
			,p.Value17 = l.Value17
			,p.Label18 = l.Label18
			,p.Value18 = l.Value18
			,p.Label19 = l.Label19
			,p.Value19 = l.Value19
			,p.Label20 = l.Label20
			,p.Value20 = l.Value20
			,p.Label21 = l.Label21
			,p.Value21 = l.Value21
			,p.Label22 = l.Label22
			,p.Value22 = l.Value22
			,p.Label23 = l.Label23
			,p.Value23 = l.Value23
			,p.BookType = l.BookType
			,p.Legal_Dup_Ind = l.Legal_Dup_Ind
			,p.updated = GETDATE()
		FROM [pet].[dbo].[Pet] p WITH (INDEX (IDX_FIPS_REF_ID))
		INNER JOIN [pet].[dbo].[pet_neo_legals] l WITH (INDEX (ix_fips_ref_id)) ON l.fips = p.fips
			AND l.ref_id = p.ref_id
		INNER JOIN [Pet].[dbo].[Pet_Apn] a WITH (INDEX (fips_ref_id_apntype)) ON a.Fips = p.Fips
			AND a.Ref_id = p.Ref_id
			AND a.Apn_Type = 'NEOF'
		WHERE p.fips = @Fips
			AND p.NEO_Legal_cnt = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		COMMIT
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		--ROLLBACK
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


