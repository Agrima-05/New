SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





-- =============================================
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_502_Pull_FLANK_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK
		UPDATE [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK]
		SET FIPS = '0' + FIPS
		WHERE LEN(FIPS)=4

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SaleDate,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,a.Loan1LenderName as NewLenderAssignee
		,A.[Loan1Amount]  ,A.[Loan2Amount]
		,[Loan1DocumentTypeCode],[Loan2DocumentTypeCode]
		,Buyer1LastName
		,[CMTIDInstNbr]
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_DEEDS]
		--Select * 
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.DeedTransactionType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES
		--ALTER TABLE w_TransHist_FLANK ADD Buyer1LastName[varchar](200)NULL
		--ALTER TABLE w_TransHist_FLANK_II ADD Buyer1LastName[varchar](200)NULL
		--ALTER TABLE [w_FLANK_DEEDS] ADD Buyer1LastName[varchar](200)NULL
		--ALTER TABLE [w_FLANK_MTG] ADD Buyer1LastName[varchar](200)NULL
		

		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower,LenderName AS SellerLender,LoanAmount,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.LenderName as NewLenderAssignee,ContractDate
		,NULL as Loan1DocumentTypeCode,NULL as Loan2DocumentTypeCode
		,Borrower1LastName as Buyer1LastName
		,Borrower1FirstName
		,LoanType
		,[CMTIDInstNbr] as LOANCMTDOC
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_MTG]
		--Select * 
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d  with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.LoanTransType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,TransactionID--case when Loan1TransactionID is null then TransactionID else Loan1TransactionID end
		,FAPropertyID,Loan1RecordingDt,Loan1Document,Loan1Book,Loan1Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan1LenderName AS SellerLender,Loan1Amount,Loan1DocumentTypeCode,d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.Loan1LenderName as NewLenderAssignee,NULL
		,Loan1DocumentTypeCode,Loan1DocumentTypeCode
		,Buyer1LastName
		,Buyer1FirstName
		,Loan1Type as LoanType
		,[Loan1CMTIDInstNbr] as LOANCMTDOC
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		and a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt 

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,TransactionID--case when Loan2TransactionID is null then TransactionID else Loan2TransactionID end
		,FAPropertyID,
		Case when Loan2RecordingDt is null then Loan1RecordingDt else Loan2RecordingDt end
		,Case when Loan2Document is null then Loan1Document else Loan2Document end
		,Case when Loan2Book is null then Loan1Book else Loan2Book end
		,Case when Loan2Page is null then Loan1Page else Loan2Page end
		,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower
		,Loan2LenderName  AS SellerLender
		,Loan2Amount
		,Loan2DocumentTypeCode,d.CodeDesc as DocType
		,Loan2TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.Loan2LenderName as NewLenderAssignee,NULL
		,Loan2DocumentTypeCode,Loan2DocumentTypeCode
		,Buyer1LastName
		,Buyer1FirstName
		,Loan2Type as LoanType
		,[Loan2CMTIDInstNbr] as LOANCMTDOC
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan2DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan2TransactionType Like t.TransType
		WHERE Loan2Amount > 0
		and a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt 

		----ASSIGN/REL

		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'A' as DocSrcInd,[ChronoKey],Assignee,AssignorName as Assignor,REF_ID
		,a.Assignee1CompanyName as NewLenderAssignee,AssignorName as OldLenderAssignor
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'R' as DocSrcInd,[ChronoKey],NULL,NULL,REF_ID
		,a.OrigLenderBen as NewLenderAssignee, NULL
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		UPDATE [zCust_SITUS_AMC].[dbo].[w_Flank_ASR]
		SET OrigDeedRecordingDt = NULL
		where isDATE(OrigDeedRecordingDt)=0

		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType,REF_ID
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentType = d.DocTypeID
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		---- CREATE TransHist 

	
	
	

		TRUNCATE TABLE w_TransHist_FLANK
			DROP INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate]
			  ,Loan1Amount
			  ,Loan2Amount
			  ,Loan1DocumentTypeCode
			  ,Loan2DocumentTypeCode
			  ,Buyer1LastName
			  ,LOANCMTDOC
			  )
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,SaleDate
			    ,Loan1Amount
			  ,Loan2Amount
			  ,Loan1DocumentTypeCode
			  ,Loan2DocumentTypeCode
			  ,Buyer1LastName
			  ,[CMTIDInstNbr]
			  
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_DEEDS]


		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate]
			  ,Buyer1LastName
			  ,Loan_Type
			  ,[LOANCMTDOC])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,ContractDate
			  ,Buyer1LastName
			  ,LoanType
			  ,[LOANCMTDOC]
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_MTG]

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			  ,left([BuyerBorrower],250)
			  ,NULL
			  ,NULL
			  ,OrigDeedRecordingDt
			  ,case When OrigDeedDocNbr is null then OrigDeedBook + '.' + OrigDeedPage ELSE  OrigDeedDocNbr END
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,left([NewLenderAssignee],250)
			  ,left([OldLenderAssignor],250)
			  ,[OrigLoanAmt]
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_ASR]

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct FIPS
			  ,FAPropertyID
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigNODDocumentNbr
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,OrigBeneficiaryLender
			  ,NULL
			  ,OrigLoanAmt
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_NOD]

		CREATE NONCLUSTERED INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]
		([Fips] ASC,
			[Doc_Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)



		UPDATE [zCust_SITUS_AMC].[dbo].[a]
		SET FA_DocNbrFmt = c.FA_DocNbrFmt
		,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		,FA_BookPageFmt = c.FA_BookPageFmt
		,FA_YearBookPageFmt = c.FA_YearBookPageFmt
        ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
        ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
        ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
        ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
        ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] a 
		JOIN (Select * from [global].[dbo].[Transaction_Master] with(NOLOCK)
		WHERE FIPS in(Select Distinct Right('0' + convert(varchar(5),FIPS),5)  as FIPS from [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK])) c
		on a.FIPS = c.FIPS
		and a.Doc_Id = c.TransactionID
		Where a.Doc_ID is not null and a.Doc_ID not like ''
		and a.Doc_ID not like 'unknown'
		and a.Doc_ID not like '0.0'

		--UPDATE a
		--SET FA_DocNbrFmt = c.FA_DocNbrFmt
		--,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		--,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		--,FA_BookPageFmt = c.FA_BookPageFmt
		--,FA_YearBookPageFmt = c.FA_YearBookPageFmt
  --      ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
  --      ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
  --      ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
  --      ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
  --      ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		--FROM w_TransHist_FLANK a 
		--JOIN global.dbo.Transaction_Master c with(NOLOCK)
		--on a.FIPS = c.FIPS
		--and a.Doc_Id = c.TransactionID
		--Where C.FIPS in(Select Distinct FIPS from w_TransHist_FLANK)
		--and A.Doc_ID is not null and A.Doc_ID not like ''
		--and A.Doc_ID not like 'unknown'
		--and A.Doc_ID not like '0.0'

		--UPDATE a 
		--set a.REF_ID = b.REF_ID
		--FROM w_transHist_Flank a JOIN a_PropMatch_Work_FLANK b
		--on convert(int,a.Fips) = convert(int,b.Fips)
		--and a.ref_id = b.propertyID

		  UPDATE [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
		  SET CmtID = case when FA_CMTID_YearDocNum is not null then FA_CMTID_YearDocNum
			WHEN FA_CMTID_BookPage is not null then FA_CMTID_BookPage
			WHEN FA_CMTID_YearDAteDocNum is not null then FA_CMTID_YearDAteDocNum
			WHEN FA_CMTID_DocNum is not null then FA_CMTID_DocNum
			WHEN FA_CMTID_YearBookPage is not null then FA_CMTID_YearBookPage
			END

		  UPDATE [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
		  SET CmtID = 1091
		  WHERE FIPS = 17031


		  --Select * From [w_TransHist_FLANK]

		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '1'
		  --Select A.DocumentNbr, B.*
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg1TransactionID and A.DOC_ID is not null
		  and A.Value = B.Mtg1LoanAmt
		  and A.DocumentNbr = B.Mtg1InputDocNbr
		  where B.Mtg1InputDocNbr is not null
		  --Order by A.DOC_ID

		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '2'
		  --Select A.*, B.Mtg2TransactionID, B.Mtg2Lender, B.Mtg2LoanAmt, B.Mtg2REcordingDt ,A.Loan1Amount,A.Loan2Amount
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg2TransactionID and A.DOC_ID is not null
		 and A.Value = B.Mtg2LoanAmt
		   and A.DocumentNbr = B.Mtg2InputDocNbr
		    where B.Mtg2InputDocNbr is not null
		  --Order by A.DOC_ID

		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '3'
		  --Select A.*, B.Mtg1TransactionID, B.Mtg1Lender, B.Mtg1LoanAmt, B.Mtg1REcordingDt 
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg3TransactionID and A.DOC_ID is not null
		   and A.Value = B.Mtg3LoanAmt
		     and A.DocumentNbr = B.Mtg3InputDocNbr
			  where B.Mtg3InputDocNbr is not null
		  --Order by A.DOC_ID


		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '4'
		  --Select A.*, B.Mtg1TransactionID, B.Mtg1Lender, B.Mtg1LoanAmt, B.Mtg1REcordingDt 
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg4TransactionID and A.DOC_ID is not null
		   and A.Value = B.Mtg4LoanAmt
		     and A.DocumentNbr = B.Mtg4InputDocNbr
			  where B.Mtg4InputDocNbr is not null
		  --Order by A.DOC_ID


		    Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '1'
		  --Select A.DocumentNbr, B.*
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg1TransactionID and A.DOC_ID is not null
		  and A.Value = B.Mtg1LoanAmt
		  where B.Mtg1InputDocNbr is null
		  --Order by A.DOC_ID

		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '2'
		  --Select A.*, B.Mtg2TransactionID, B.Mtg2Lender, B.Mtg2LoanAmt, B.Mtg2REcordingDt ,A.Loan1Amount,A.Loan2Amount
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg2TransactionID and A.DOC_ID is not null
		 and A.Value = B.Mtg2LoanAmt
		  where B.Mtg2InputDocNbr is null
		  --Order by A.DOC_ID

		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '3'
		  --Select A.*, B.Mtg1TransactionID, B.Mtg1Lender, B.Mtg1LoanAmt, B.Mtg1REcordingDt 
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg3TransactionID and A.DOC_ID is not null
		   and A.Value = B.Mtg3LoanAmt
		   where B.Mtg3InputDocNbr is null
		  --Order by A.DOC_ID


		  Update [zCust_SITUS_AMC].[dbo].[A]
		  Set A.[Lien_Pos] = '4'
		  --Select A.*, B.Mtg1TransactionID, B.Mtg1Lender, B.Mtg1LoanAmt, B.Mtg1REcordingDt 
		  From [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] as A join [data].[dbo].[Property] as B with(NOLOCK)
		  on A.FIPS = B.FIPS and A.REF_ID = B.PropertyID
		  AND A.DOC_ID = B.Mtg4TransactionID and A.DOC_ID is not null
		   and A.Value = B.Mtg4LoanAmt
		   where B.Mtg4InputDocNbr is null
		  --Order by A.DOC_ID



END





