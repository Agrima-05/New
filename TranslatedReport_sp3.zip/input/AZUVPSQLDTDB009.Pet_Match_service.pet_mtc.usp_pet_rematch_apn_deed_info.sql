/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_service | pet_mtc.usp_pet_rematch_apn_deed_info | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Pet_Match_service].[pet_mtc].[usp_pet_rematch_apn_deed_info]
	-- Add the parameters for the stored procedure here
	--<@Param1, sysname, @p1> <Datatype_For_Param1, , int> = <Default_Value_For_Param1, , 0>, 
	--<@Param2, sysname, @p2> <Datatype_For_Param2, , int> = <Default_Value_For_Param2, , 0>
	--@fips INT
	@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for procedure here
	--DECLARE @fips INT = 39151
	BEGIN TRY
		--DROP TABLE IF EXISTS PET_Match_Service.PET_MTC.Pet_Incr_Deed_Rematch_fips_list
		TRUNCATE TABLE 	[PET_Match_Service].[PET_MTC].[Pet_Incr_Deed_Rematch_fips_list]
			
		INSERT INTO [PET_Match_Service].[PET_MTC].[Pet_Incr_Deed_Rematch_fips_list]
		SELECT fips
			,count(1) AS cnt
		--INTO PET_Match_Service.PET_MTC.Pet_Incr_Deed_Rematch_fips_list
		FROM [pet].[dbo].[Pet_Incr_Deed_Rematch_day_ref_id]
		GROUP BY fips
		ORDER BY cnt DESC

		--create index idx_fips on PET_Match_Service.PET_MTC.Pet_Incr_Deed_Rematch_fips_list (fips)

		TRUNCATE TABLE [lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn]

		--DROP TABLE
		--IF EXISTS PET_MATCH_SERVICE.pet_mtc.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn
		INSERT INTO [lien_dtdb].[tmp].[usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn]
		SELECT a.*
		--INTO PET_MATCH_SERVICE.pet_mtc.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn 
		FROM [pet].[dbo].[pet_apn] as a WITH (
				NOLOCK
				,INDEX (ixb_fips_ref_id)
				)
		inner join [PET_Match_Service].[PET_MTC].[Pet_Incr_Deed_Rematch_fips_list] as l with(nolock, index(idx_fips)) on l.fips = a.fips
		WHERE a.ref_id IN (
				SELECT dr.ref_id
				--FROM assr.dbo.Pet_Daily_INCR_Refids as dr 
				FROM [pet].[dbo].[Pet_Incr_Deed_Rematch_day_ref_id] as dr
				WHERE dr.fips = a.fips
				)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		--select count(1)
		--from Lien_DTDB.tmp.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn
		--where fips = 42021

		--select *
		--from Lien_DTDB.tmp.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn
		--where fips = 42021

		--SELECT *
		--from lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn
		--CREATE CLUSTERED INDEX idxc_apn ON lien_dtdb.tmp.usp_pet_rematch_apn_deed_info_PEt_inct_rematch_apn (apn)
		----TRUNCATE TABLE Lien.lien_tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id
		--DROP TABLE

		--IF EXISTS Lien.lien_tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id
		--	--INSERT INTO Lien.lien_tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id
		--	SELECT d.fips
		--		  ,d.deedid
		--		  ,d.original_apn
		--		  ,d.ur_doc_id
		--	INTO Lien.lien_tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id
		--	FROM deed.dbo.deed as d
		--	inner join PET_Match_Service.PET_MTC.Pet_Incr_Deed_Rematch_fips_list as l with(nolock, index(idx_fips)) on l.fips = d.fips
		--	WHERE d.ref_id IS NULL
		--		AND d.original_apn IS NOT NULL
		--		AND d.source_type IN (
		--			'M'
		--			,'E'
		--			)
		--	OPTION (
		--		RECOMPILE
		--		,MAXDOP 12
		--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		--		);

		----create index idx_fips_ref_id_orig_apn_source on deed.dbo.deed (fips, ref_id, original_apn, source_type)
		--CREATE INDEX idx_original_apn ON Lien.lien_tmp.usp_pet_rematch_apn_deed_info_deed_with_no_ref_id (original_apn)
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


