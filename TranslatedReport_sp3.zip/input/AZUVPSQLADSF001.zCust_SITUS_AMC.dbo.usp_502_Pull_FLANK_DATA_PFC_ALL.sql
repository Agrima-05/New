SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





-- =============================================
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_502_Pull_FLANK_DATA_PFC_ALL] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK
		UPDATE [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK]
		SET FIPS = '0' + FIPS
		WHERE LEN(FIPS)=4

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SaleDate,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,a.Loan1LenderName as NewLenderAssignee
		,A.[Loan1Amount]  ,A.[Loan2Amount]
		,[Loan1DocumentTypeCode],[Loan2DocumentTypeCode]
		,Buyer1LastName
		,[CMTIDInstNbr]
		,REO
		,REOSale
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_DEEDS]
		--Select * 
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.DeedTransactionType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		and (A.Reo = 1 or A.REOSale = 1)
		ORDER BY RAW_ID,RecordingDt

		
		--Select * From [w_FLANK_DEEDS]

		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_SITUS_AMC].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType,REF_ID
		INTO [zCust_SITUS_AMC].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		JOIN [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_S11] as C on B.RAW_ID = C.[INPUT Unique RecordID]
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentType = d.DocTypeID
		WHERE a.FAUCIDFlag <> 'D'
		--AND C.PFCFLAG like 'Y'
		ORDER BY RAW_ID,RecordingDt


		---- CREATE TransHist 

	
	
	

		TRUNCATE TABLE w_TransHist_FLANK
			DROP INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]

		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,PROPERTYID
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate]
			  ,Loan1Amount
			  ,Loan2Amount
			  ,Loan1DocumentTypeCode
			  ,Loan2DocumentTypeCode
			  ,Buyer1LastName
			  ,LOANCMTDOC
			  )
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,SaleDate
			    ,Loan1Amount
			  ,Loan2Amount
			  ,Loan1DocumentTypeCode
			  ,Loan2DocumentTypeCode
			  ,Buyer1LastName
			  ,[CMTIDInstNbr]
			  
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_DEEDS]


	
		INSERT INTO [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			   ,[PROPERTYID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct FIPS
			  ,FAPropertyID
			  ,FAPropertyID
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigNODDocumentNbr
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,OrigBeneficiaryLender
			  ,NULL
			  ,OrigLoanAmt
		FROM [zCust_SITUS_AMC].[dbo].[w_FLANK_NOD]

		CREATE NONCLUSTERED INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]
		([Fips] ASC,
			[Doc_Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)



		UPDATE [zCust_SITUS_AMC].[dbo].[a]
		SET FA_DocNbrFmt = c.FA_DocNbrFmt
		,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		,FA_BookPageFmt = c.FA_BookPageFmt
		,FA_YearBookPageFmt = c.FA_YearBookPageFmt
        ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
        ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
        ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
        ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
        ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		FROM [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK] a 
		JOIN (Select * from [global].[dbo].[Transaction_Master] with(NOLOCK)
		WHERE FIPS in(Select Distinct Right('0' + convert(varchar(5),FIPS),5)  as FIPS from [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK])) c
		on a.FIPS = c.FIPS
		and a.Doc_Id = c.TransactionID
		Where a.Doc_ID is not null and a.Doc_ID not like ''
		and a.Doc_ID not like 'unknown'
		and a.Doc_ID not like '0.0'

		--UPDATE a
		--SET FA_DocNbrFmt = c.FA_DocNbrFmt
		--,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		--,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		--,FA_BookPageFmt = c.FA_BookPageFmt
		--,FA_YearBookPageFmt = c.FA_YearBookPageFmt
  --      ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
  --      ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
  --      ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
  --      ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
  --      ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		--FROM w_TransHist_FLANK a 
		--JOIN global.dbo.Transaction_Master c with(NOLOCK)
		--on a.FIPS = c.FIPS
		--and a.Doc_Id = c.TransactionID
		--Where C.FIPS in(Select Distinct FIPS from w_TransHist_FLANK)
		--and A.Doc_ID is not null and A.Doc_ID not like ''
		--and A.Doc_ID not like 'unknown'
		--and A.Doc_ID not like '0.0'

		--UPDATE a 
		--set a.REF_ID = b.REF_ID
		--FROM w_transHist_Flank a JOIN a_PropMatch_Work_FLANK b
		--on convert(int,a.Fips) = convert(int,b.Fips)
		--and a.ref_id = b.propertyID

		  UPDATE [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
		  SET CmtID = case when FA_CMTID_YearDocNum is not null then FA_CMTID_YearDocNum
			WHEN FA_CMTID_BookPage is not null then FA_CMTID_BookPage
			WHEN FA_CMTID_YearDAteDocNum is not null then FA_CMTID_YearDAteDocNum
			WHEN FA_CMTID_DocNum is not null then FA_CMTID_DocNum
			WHEN FA_CMTID_YearBookPage is not null then FA_CMTID_YearBookPage
			END

		  UPDATE [zCust_SITUS_AMC].[dbo].[w_TransHist_FLANK]
		  SET CmtID = 1091
		  WHERE FIPS = 17031


		


END





