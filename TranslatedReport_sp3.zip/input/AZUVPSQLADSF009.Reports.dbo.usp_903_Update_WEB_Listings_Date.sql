SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Update Date Sent Updates for CI Listings
-- =============================================
create PROCEDURE [Reports].[dbo].[usp_903_Update_WEB_Listings_Date]
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [Reports].[dbo].[SentToWEB_Listings] 
	SET DateSentUpdates = GetDate()

END

