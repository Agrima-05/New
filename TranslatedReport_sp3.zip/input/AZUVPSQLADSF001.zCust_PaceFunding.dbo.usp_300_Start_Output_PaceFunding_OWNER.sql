SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_PaceFunding].[dbo].[usp_300_Start_Output_PaceFunding_OWNER]


AS
BEGIN
	
	SET NOCOUNT ON;


		DROP TABLE [dbo].[x_Custom_OUTPUT_OWNER]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_OWNER](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[Input Unique ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[RunDate][varchar](250)NULL,
			[OwnerNAME1FULL][varchar](250)NULL,
			[OwnerNAME2FULL][varchar](250)NULL
	
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] ([Input Unique ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		,FIPS
		,PROPERTYID)
		

		Select 
		[INPUTKEY]
      ,[INPUTADDRESS]
      ,[INPUTCITY]
      ,[INPUTSTATE]
      ,[INPUTZIP]
	  ,FIPS
	  ,PROPERTYID
		
		From [zCust_PaceFunding].[dbo].[INPUT_MONITOR]


	
				
		
		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		SET 
		RunDate = convert(date,GetDate())
		


		Update [zCust_PaceFunding].[dbo].[A]
		set 
		[Coverage Status] = B.TaxrollActive
		From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] a 
		JOIN [Global].[dbo].[COunty] as B on 
		A.FIPS = B.FIPSCODE


		
		UPDATE [zCust_PaceFunding].[dbo].[a]
		SET 
		A.[OwnerNAME1FULL] = B.OwnerStdNAME1FULL
		,A.[OwnerNAME2FULL] = B.OwnerStdNAME2FULL
			--Select * 
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] a JOIN [data].[dbo].[Property] as B with(NOLOCK)
		on a.PROPERTYID = b.PROPERTYID
		where A.PROPERTYID is not null and A.PROPERTYID not like '' and A.PROPERTYID not like '0'
		
		

				
		Select top 100000 * From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]

		----------------------

		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_PaceFunding].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] a join [zCust_PaceFunding].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT UNIQUE ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		AND (A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		Update  [zCust_PaceFunding].[dbo].[a]
		SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER] a JOIN [zCust_PaceFunding].[dbo].[a_ASP_IN_STD] b
		on a.[Input Unique ID] = b.Raw_ID

			
		-------20220601 - Per layout in workorder:
		----Event Status	Y	Found; Not Found Based on OwnerName Found


		Update [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		SET [Event Status] = case when ISNULL([OwnerNAME1FULL],'') not like ''   THEN 'Event Found' ELSE 'Event Not Found' END

		
	
		Select [Property Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		Group by [Property Status]

		Select [Coverage Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		Group by [Coverage Status]

		Select [AddressStandardization], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		Group by [AddressStandardization]

		
		Select [Event Status], count(*) From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]
		Group by [Event Status]


		Select * From [zCust_PaceFunding].[dbo].[x_Custom_OUTPUT_OWNER]



END




