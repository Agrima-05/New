/* Source: AZUVNSQLDTDB003.datatree.local | HOA | Staging.SetContactMatchId | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */


CREATE PROCEDURE [HOA].[Staging].[SetContactMatchId]
AS

Select Id, MIN(EarliestRecording) as EarliestRecording, Max(LatestRecording) as LatestRecording
--, sum(records) as Records
--, count(Id) as Sources
--, (sum(records) + (3 * sum(records) * (count(Id) - 1))) * case when datediff(month, Max(LatestRecording), getdate()) > 192 THEN 0 ELSE (12 - cast (datediff(month, Max(LatestRecording), getdate()) as float) / 16)  END as SourceCount --multiplier bonus if multiple data sources agree on exact record 
, Case When sum(records) >= 3  or count(Id) - 1 > 1 THEN 1 ELSE 0 END * 100000 + case when datediff(month, Max(LatestRecording), getdate()) > 192 THEN 0 ELSE (12 - cast (datediff(month, Max(LatestRecording), getdate()) as float) / 16)  END * 5000 + sum(records) as SourceCount --new CurrencyEnhanced Score
--, ROUND(case when datediff(month, Max(LatestRecording), getdate()) > 192 THEN 0 ELSE (12 - cast (datediff(month, Max(LatestRecording), getdate()) as float) / 16)  END, 0)
--currency scaling score modifiers
INTO #TEMP
FROM (
	Select c.Id, MIN(OrdrClosForReprtDt) as EarliestRecording, MAX(OrdrClosForReprtDt) as LatestRecording, count(1) as Records
	from [HOA].[Staging].[FastData] f
	inner join [HOA].[Staging].[Contact] c on f.ContactId = c.Id
	GROUP by c.Id
	UNION ALL
	Select c.Id, min(convert(datetime, cast(d.RecordingDate as varchar(20)))) as EarliestRecording, max(convert(datetime, cast(d.RecordingDate as varchar(20)))) as LatestRecording, count(1) * 1.5 as Records
	from [HOA].[OA].[HoaLien] d
	inner join [HOA].[Staging].[Contact] c on d.HOAContactId = c.Id
	Group by c.Id
	UNION ALL
	Select c.Id, min(convert(datetime, cast(d.RecordingDate as varchar(20)))) as EarliestRecording, max(convert(datetime, cast(d.RecordingDate as varchar(20)))) as LatestRecording, count(1) * 1.5 as Records
	from [HOA].[OA].[HoaLien] d
	inner join [HOA].[Staging].[Contact] c on d.MAContactId = c.Id
	Group by c.Id
	UNION ALL
	Select c.Id, min(convert(datetime, cast(d.RecordingDate as varchar(20)))) as EarliestRecording, max(convert(datetime, cast(d.RecordingDate as varchar(20)))) as LatestRecording, count(1) * 1.5 as Records
	from [HOA].[OA].[HoaLien] d
	inner join [HOA].[Staging].[Contact] c on d.LAWContactId = c.Id
	Group by c.Id
	) R
	Group by Id

	Update [HOA].[Staging].[sc]
	SET sc.SourceCount = t.SourceCount
	,sc.EarliestRecordingDate = t.EarliestRecording
	,sc.LastRecordingDate = t.LatestRecording
	,sc.UpdateDate = getdate()
	FROM [HOA].[Staging].[Contact] sc 
	INNER JOIN #TEMP t on sc.Id = t.Id
	WHERE t.EarliestRecording <> sc.EarliestRecordingDate
	OR t.LatestRecording <> sc.LastRecordingDate
	OR sc.EarliestRecordingDate IS NULL and t.EarliestRecording IS NOT NULL
	OR sc.LastRecordingDate IS NULL and t.LatestRecording IS NOT NULL
	OR t.SourceCount <> sc.SourceCount
	OR sc.SourceCount IS NULL and t.SourceCount IS NOT NULL

	BEGIN TRANSACTION

	UPDATE [HOA].[Staging].[c]
	SET MatchId = Null
	From [HOA].[Staging].[Contact] c
	LEFT JOIN [HOA].[Staging].[Contact] c2 on c2.Id = c.MatchId
	WHERE c2.Id IS NULL and c.MatchId IS NOT NULL
	
	Update [HOA].[Staging].[Contact]
	Set MatchId = Id where MatchId > Id OR MatchId IS NULL

	CREATE TABLE #Match (
		Parent INT,
		Child INT,
		PRIMARY KEY (Parent, Child)
	)
	INSERT INTO #Match
	Select DISTINCT Parent, Child
	From (
	--SELECT a.Id as Parent, b.Id as Child
	--FROM Staging.Contact a
	--INNER JOIN Staging.Contact b ON a.Id <> b.Id AND a.Name = b.Name AND a.[Address] = b.[Address] AND a.[State] = b.[State]
	--WHERE a.MatchId IS NULL
	--UNION ALL
	--SELECT a.Id, b.Id
	--FROM Staging.Contact a
	--INNER JOIN Staging.Contact b ON a.Id <> b.Id AND a.Name = b.Name AND a.Email = b.Email
	--WHERE a.MatchId IS NULL
	--UNION ALL
	--SELECT a.Id, b.Id
	--FROM Staging.Contact a
	--INNER JOIN Staging.Contact b ON a.Id <> b.Id AND a.Name = b.Name AND (
	--	a.BusinessPhoneNbr = b.BusinessPhoneNbr
	--	OR a.CellPhoneNbr = b.CellPhoneNbr
	--)
	--WHERE a.MatchId IS NULL
	--UNION ALL
	SELECT a.Id as Parent, b.Id as Child
	FROM [HOA].[Staging].[Contact] a
	INNER JOIN [HOA].[Staging].[Contact] b ON a.Id <> b.Id AND a.[Address] = b.[Address] AND a.City = b.City AND a.[State] = b.[State]
	--WHERE a.MatchId IS NULL
	) R
	--Group by Parent

	DECLARE @RowCount INT = 1
	WHILE @RowCount > 0
	BEGIN
		UPDATE [HOA].[Staging].[a]
		SET MatchId = COALESCE(b.MatchId, m.Child)
		FROM [HOA].[Staging].[Contact] a
		INNER JOIN #Match m ON a.Id = m.Parent
		LEFT JOIN [HOA].[Staging].[Contact] b ON m.Child = b.Id AND b.MatchId < m.Child
		WHERE COALESCE(b.MatchId, m.Child) < a.MatchId or a.MatchId IS NULL

		SET @RowCount = @@ROWCOUNT
	END

		--UPDATE c
		--SET MatchId = Id
		--FROM Staging.Contact c
		--Where MatchId IS NULL

	COMMIT TRANSACTION

