SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [zCust_ReliantCapital].[dbo].[EMAIL_BAD_INPUT_TO_CUST]
as
Begin

		IF (Select sum([DUPS])   as 'DUPS'  From (
			Select count(*) as 'DUPS' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
			join [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] as B on A.UniqueID = B.INPUTKEY
			where A.[Record Indicator] like 'A'
	 
			UNION ALL 

	
			Select count(*) as 'DUPS' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
			left outer join [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] as B on A.UniqueID = B.INPUTKEY
			where A.[Record Indicator] like 'D'
			and B.INPUTKEY is null
	
			UNION ALL 

			Select count(*) as 'DUPS' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
			where ISNULL(A.[Record Indicator],'') like ''

			UNION ALL 
	
			Select count(*) as  'DUPS' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST]
			where UniqueID  in (
			Select UniqueID from (
			Select UniqueID, count(*) T From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST]
			where ISNULL(UniqueID,'') not like ''
			Group by UniqueID
			having count(*) > 1
			
			)A)

			)A ) > 0


			BEGIN



				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @body5 NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @xml3 NVARCHAR(MAX)
				DECLARE @xml4 NVARCHAR(MAX)
				DECLARE @xml5 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Reliant Capital - Bad Input Records - Check & then forward to zachary.hada@ascentds.com!!' + @Date 
								
			
				

				----------Adds already in the portfolio
			
				SET @xml2 = 
				CAST(( 
				Select A.UniqueID as 'td','',  A.Address as 'td','', A.City as 'td','', A.State as 'td','', A.Zip as 'td',''
				, B.DATE_RECEIVED as 'td','' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
				join [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] as B on A.UniqueID = B.INPUTKEY
				where A.[Record Indicator] like 'A'	
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				SET @body2 = '<html><body><H3>ADD Records that already exist - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> UniqueID  </th> <th> Address </th> <th> City </th> <th> State </th> <th> Zip </th> <th> DATE_RECEIVED </th></tr>'  
				+ @xml2

				------Deletes not in portfolio
				
				SET @xml3 = 
				CAST(( 
				Select A.UniqueID as 'td','',  A.Address as 'td','', A.City as 'td','', A.State as 'td','', A.Zip as 'td',''
				, B.DATE_RECEIVED as 'td','' From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
				left outer join [zCust_ReliantCapital].[dbo].[INPUT_MONITOR] as B on A.UniqueID = B.INPUTKEY
				where A.[Record Indicator] like 'D'
				and B.INPUTKEY is null
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

				SET @body3 = '<html><body><H3>DELETE Records that DO NOT exist - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> UniqueID  </th> <th> Address </th> <th> City </th> <th> State </th> <th> Zip </th> <th> DATE_RECEIVED </th></tr>'  
				+ @xml3

				----Records in input that do not have monitoring type
				
				SET @xml4 = 
				CAST(( 
				Select A.UniqueID as 'td','',  A.Address as 'td','', A.City as 'td','', A.State as 'td','', A.Zip as 'td',''
				From [zCust_ReliantCapital].[dbo].[INPUT_RAW_CUST] as A 
				where ISNULL(A.[Record Indicator],'') like ''
				and ISNULL(A.UniqueID,'') not like ''
				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

				SET @body4 = '<html><body><H3>Records in Input file that do not have Record Indicator - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> UniqueID  </th> <th> Address </th> <th> City </th> <th> State </th> <th> Zip  </th></tr>'  
				+ @xml4


				
			
				--Set @body2 = @body + @XML
				--Set @body8 = @body7 + @xml5 +'</table></body></html> <BR/><BR/>'
				Set @body5 = case 
				--when @body2 is null and @body3 is null and @body4 is null then NULL
				when @body2 is not null and @body3 is null and @body4 is null then @body2 + Char(13) + Char(10)
				when @body2 is not null and @body3 is not null and @body4 is null then @body2 + Char(13) + Char(10) + Char(13) + Char(10) + @body3 + Char(13) + Char(10) 
				when @body2 is not null and @body3 is not null and @body4 is not null then @body2 + Char(13) + Char(10) + Char(13) + Char(10) + @body3 + Char(13) + Char(10) + @body4 + Char(13) + Char(10) 

				when @body2 is null and @body3 is not null and @body4 is not null then  @body3 + Char(13) + Char(10) + @body4 + Char(13) + Char(10) 
				when @body2 is null and @body3 is null and @body4 is not null then   @body4 + Char(13) + Char(10) 
				when @body2 is null and @body3 is not null and @body4 is  null then  @body3 + Char(13) + Char(10) 
				else NULL end


				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body5,
				@body_format ='HTML',
				--@recipients = 'klowe@firstam.com;zachary.hada@ascentds.com;ecarnese@firstam.com',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = HIGH


		END



END

