SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_PalmettoSolar].[dbo].[usp_300_Start_Output_PalmettoSolar_S20]


AS
BEGIN
	
	SET NOCOUNT ON;
	-----20250529 - Per WO
----S20 - Custom Solution

-----RUNS TUE & THU at 11 AM ET - regardless if there is a new portfolio update file

----"Event found if:
----- IsListedFlag was NULL and is now ""Y""
----- IsListedFlag was ""Y"" and is now NULL"
----Full Refresh every Tuesday / Thursday
----Customer will provide input files Monday's before midnight
------****We are NOT using their Input Start Date*****-----


----Hi William – If we’re monitoring all details in the section below – then any change to any of those fields would results in Event Found – wouldn’t it?

----I thought we were just monitoring for on market listing changes?

----DATA OUTPUT DETAILS - Monitoring all details in this section
----Current Owner 1	Y	Current Owner of Record
----Current Owner 2	Y	Current Owner of Record
----MailingFullStreetAddress	 	Street Address: 123 S MAIN ST # 4
----MailingCity	 	The city for the mailing address.
----MailingState	 	Two letter state abbreviation for the mailing address.
----MailingZIP5	 	Five digit code assigned by the USPS: 90001-1000
----IsListedFlag	Y	Flag indicating that the house is listed for sale


		----Backup INPUT_IN_MONITOR in case need to roll back---
		DECLARE @DATE varchar(50)
		Set @DATE =  Format(GetDate(), N'yyyy-MM-dd-HHmm')
		EXEC('Select * into dbo.[INPUT_MONITOR_' + @DATE + '] From INPUT_MONITOR')



		DROP TABLE [dbo].[x_Custom_OUTPUT_S20]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S20](
			[FIPS][varchar](5)NULL,
			
			[PROPERTYID][varchar](250)NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Listing Event Status][varchar](250)NULL,
			----ADDED-20260109----
			[PropertyPFC Event Status][varchar](250)NULL,

			[Current Owner 1][varchar](250)NULL,
			[Current Owner 2][varchar](250)NULL,
			[MailingFullStreetAddress][varchar](250)NULL,
			[MailingCity][varchar](250)NULL,
			[MailingState][varchar](250)NULL,
			[MailingZIP5][varchar](250)NULL,
			[IsListedFlag][varchar](250)NULL,
			----ADDED-20260109----
			[PropertyPFCFlag][varchar](250)NULL,


			-----INTERNAL----
			[Start Date][varchar](250)NULL,
			[MAX_LISTDATE][varchar](250)NULL,
			[FAInitialListDate][varchar](250)NULL
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		

	   INSERT INTO [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] ([INPUT KEY],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		[Start Date],
		FIPS,
		PropertyID,
		[MAX_LISTDATE]
		)
	  SELECT 
		[INPUTKEY]
      ,ADDRESS
      ,[City]
      ,[State]
      ,[ZipCODE]
      ,convert(date,[Start Date])
	   ,FIPS
	   ,PROPERTYID,
	   convert(date,[MAX_LISTDATE])
	   
	   --Select * 
		FROM [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR]


		  
	  
	  Select * From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
	  
				

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S20 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUT Key] = c.RAW_ID

		

		Update [zCust_PalmettoSolar].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_PalmettoSolar].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


		
	


		Update [zCust_PalmettoSolar].[dbo].[A]
		Set
		A.[Current Owner 1] = B.[OwnerStdNAME1FULL]
		,A.[Current Owner 2] = B.[OwnerStdNAME2FULL]
		,A.[MailingFullStreetAddress] = B.MailingSTDFUllStreetAddress
		,A.[MailingCity] = B.MailingSTDCity
		,A.[MailingState] = B.MailingSTDState
		,A.[MailingZIP5] = B.MailingSTDZip5
		

		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID


		Update [zCust_PalmettoSolar].[dbo].[A]
		Set
		A.[IsListedFlag] = 'Y'		
		,A.[FAInitialListDate] = Convert(Date,B.[FAInitialListDate])
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] A 
		JOIN [data].[dbo].[vListings_Current_NEW_STD] as B with(NOLOCK) 
		on A.PropertyID = B.PM_PropertyID
		where 
		B.CurrentListingInd like 'Y'
		and 
		B.[Add,Change,DeleteIndicator] not like 'D'
		and B.Status in ('Active','Pending','Contingent')
		--and convert(date,B.FAInitialListDate) > convert(date,A.[Start Date])
		--and (convert(date,B.FAInitialListDate) > convert(date,A.[MAX_LISTDATE])
		--OR [MAX_LISTDATE] is null)
		AND ISNULL(A.PROPERTYID,'') not like ''
		

		Update [zCust_PalmettoSolar].[dbo].[A]
		Set
		A.[PropertyPFCFlag] = B.PFCFlag		
		--Select A.[PropertyPFCFlag] , B.PFCFlag	
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] A 
		JOIN [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) 
		on A.FIPS = B.FIPS and A.PROPERTYID = B.PropertyID


		------20260109 Per EC - ONLY Event Found when Property goes from NULL to Property PFCL Flag Populated
		Update [zCust_PalmettoSolar].[dbo].[A]
		Set
		A.[PropertyPFC Event Status] = case when ISNULL(A.[PropertyPFCFlag],'') like 'Y' and ISNULL(B.PFCFLAG,'') like ''
		then 'Event Found' else 'Event Not Found'  end
		--Select A.[PropertyPFC Event Status], A.[PropertyPFCFlag], case when ISNULL(A.[PropertyPFCFlag],'') like 'Y' and ISNULL(B.PFCFLAG,'') like ''
		--then 'Event Found' else 'Event Not Found'  end
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] A 
		JOIN [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR] as B with(NOLOCK) 
		on A.[INPUT KEY] = B.[INPUTKEY]



		----------------------


		Update  [zCust_PalmettoSolar].[dbo].[a]
		SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_PalmettoSolar].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID

		Update [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_PalmettoSolar].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] a join [zCust_PalmettoSolar].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

	
		------20250529 - Per WO  
		----"Event found if:
		----- IsListedFlag was NULL and is now ""Y""
		----- IsListedFlag was ""Y"" and is now NULL"


		-----20260108  Per EC - PFC flag will be monitored for when NULL & NOW Y (NOT when was Y & is now NULL). 
		------AND PFC Event FOund will ONLY be Event Found when flag was NULL & is now Y (even though we will monitor for flag updates anyway)
		-----BILLING - will NOT be $2500 monthly fee (no matter the number of records in portfolio) 
		-----PLUS $1.50 PER EVENT (which is Listing FLag change OR PFC was null and is now Y)
		----Portfolio Monitor Output File moving to Weekly on Tuesdays



		Update  [zCust_PalmettoSolar].[dbo].[A]
		Set A.[Listing Event Status] = case when  ISNULL(A.IsListedFlag,'') <> ISNULL(B.IsListedFlag,'')
		Then 'Event Found' else 'Event Not Found' END
		From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] as A join [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT Key] = B.[INPUTKey]
	


		
	

		Select [INPUT Key],PROPERTYID,[START DATE] , IsListedFlag,[Listing Event Status]
		,[MAX_LISTDATE]
		From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20] 
		where [Listing Event Status] = 'Event Not Found' 
		and 
		ISNULL(IsListedFlag,'') not like ''

		
	
		Select [Property Status], count(*) From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Property Status]

		Select [AddressStandardization], count(*) From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
		Group by [AddressStandardization]

		Select [Listing Event Status], count(*) From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Listing Event Status]

		
		Select * From [zCust_PalmettoSolar].[dbo].[x_Custom_OUTPUT_S20]
	
		
	

END





