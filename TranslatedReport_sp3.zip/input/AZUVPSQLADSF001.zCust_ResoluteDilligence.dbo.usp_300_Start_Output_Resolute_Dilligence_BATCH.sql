SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_ResoluteDilligence].[dbo].[usp_300_Start_Output_Resolute_Dilligence_BATCH]


AS
BEGIN
	
	SET NOCOUNT ON;


	------20220318 - Emily & I spoke with customer about issues with their input file 
	----& they agreed to run this as Batch instead of Monitor so they can better manage the input file they send to us
	-----Creating new SP for Batch processing

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[WORK_REF_ID] [bigint] NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Through Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Through Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[INPUT Vesting][varchar](500)NULL,
			-----Added 20210901---
			[INPUT Borrower][varchar](250)NULL,
			[INPUT Acquisition Date][varchar](250)NULL,
			[Current Owner][varchar](250)NULL,
			[Current Owner Change Date][varchar](250)NULL,
			
			----Remove - Internal----
			[NbrOfRecordings][varchar](250)NULL,
			[MAX_DEED_DATE][varchar](250)NULL,
			[MAX_MTG_DATE][varchar](250)NULL
			--,
						
			--[Record Number][varchar](250)NULL,
			--[Recording Date][varchar](250)NULL,
			--[Document Number][varchar](250)NULL,
			--[Amount][varchar](250)NULL,
			--[Doc Type][varchar](250)NULL,
			--[Buyer/Borrower][varchar](250)NULL,
			--[Seller/Lender][varchar](250)NULL

			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		,[INPUT Vesting]
		,[INPUT Acquisition Date]
		--,[INPUT Borrower]
		)

		Select  [Property ID]
		,propertyaddress,	[City],	[State],	[Zip]
       ,Vesting 
	   ,convert(date,[AcquisitionDate])
	   --,Input_BORROWER

	 --Select * 
	 FROM [zCust_ResoluteDilligence].[dbo].[INPUT_RAW_CUST_NEW]
	   where  [Property ID] is not null and [Property ID] not like ''
--	   and  [Property ID] in ('10005482','10010121','10087123','10087307','10171875','10182925','10206023','10273688','9696533','9757870','9789090','9877261',
--'9882284','9891928','9897199','9900229','9909516','9921107','9953746','9967472','9534765','9578534','9606720','9637760','9647676','9653914','9694388','86FMQV9P+RJP94XH',
--'86FMQVCQ+PJ2434C','86FMRV55+23WX4Q3','87G292HC+PV5J545','86CFJF5Q+J8CV9V3','86CFHFJ8+QV7X3QF','86CFJF24+9G3FGFC','86FQ6CF4+WFRHQ33','86FQ3JMW+MRQCQ45','86CFQC5C+8QRC5XC',
--'86GX8XG3+JPQG554','GA28455','11572','11574','11576','11577','atl01225','atl01358','atl01360','atl01361','atl01362','mem00259','11581','1-001043','1-055220','1-023090',
--'1-031380','1-036190','1-175070','1-198020','1006437','1006743','1028263','1006308','1006422','1006535','1006638','1006861','1007762','1007777','1007778','1010369',
--'1012123','1014311','PW000114','PW000273','PW001276','PW001953','PW002070','PW002287','PW002293','PW002643','PW002661','PW002799','PW002867','PW004761','PW004767','PW004770',
--'PW004889','PW004918','PW004919','PW004922','PW004929','PW004931','86CFJQ52+P4F8654','SC89082','TPA00191','DFW00192','ATL00211','ATL00069','TPA00292','PHX00233','PHX00234',
--'TPA00240','RES2653','RES1502','RES1027','RES1736','RES2672','RES2244','RES1735','RES1432','RES2699')
	 
	 
	 
	
	  Select * From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]

					

		UPDATE [zCust_ResoluteDilligence].[dbo].[a] 
		SET a.[PROPERTYID] = case when a.[PROPERTYID] is null then c.[PROPERTYID] else a.[PROPERTYID] end
		,a.WORK_REF_ID = case when a.WORK_REF_ID is null then c.REF_ID else a.WORK_REF_ID end 
			,a.Fips = CASE WHEN a.Fips is null then (case when LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END) else a.Fips end
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ResoluteDilligence].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT Key] = c.RAW_ID


		--Insert into Data.dbo.[DailyPropID_II](FIPS, PropertyID, FADateReceived, SRCID)
		--Select FIPS, PropertyID, FADatereceived, 'D'
		--From Data.dbo.Property with(NOLOCK)
		--where PropertyID in (Select distinct [PROPERTYID] from x_Custom_OUTPUT where PropertyID is not null and propertyid not like '' and propertyid not like '0')

		

		Update [zCust_ResoluteDilligence].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ResoluteDilligence].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID



	
		Update [zCust_ResoluteDilligence].[dbo].[A]
		set 
		[Deed Coverage Status] = B.DeedActive
		,[Deed Through Date] = B.DeedMaxRecordDate
		,[Mortgage Coverage Status] = B.SAMActive
		,[Mortgage Through Date] = B.SamMaxRecordDate
		From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a 
		JOIN [Global].[dbo].[COunty] as B on 
		A.FIPS = B.FIPSCODE
		


		
		UPDATE [zCust_ResoluteDilligence].[dbo].[a]
		SET 
		a.[Current Owner] = OwnerStdNAME1FULL		
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a JOIN [Data].[dbo].[Property] as B with(NOLOCK)
		on A.PROPERTYID = B.PropertyID
		where A.PROPERTYID is not null


		Select top 100 * FRom [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]


		--------20210120 - Per workorder - Y or Blank to indicate that the Input Borrower Name Matches or Doesn't Match the FA  Current Owner
		-------------------REMOVED FIELD PER EC 20210120
		----Update x_Custom_OUTPUT
		----Set [Borrower Name/Current Owner Match Indicator] = 
		----case when left([INPUT Borrower Name],4) = left([Current Owner],4) then 'Y'
		----else NULL END


		--------20210120 - Per workorder - 
		------2) If Input Borrower Name matches Current Owner Name, add to Monitoring Portfolio 
		----		--& Return Most Recent Arm's Length Ownership Transfer
		------3) If Input Borrower Name does NOT match Current Owner Name, do not return any further information than Current Owner
		------, Current Owner Change Date (Recording Date) & Borrower Name/Current Owner Match 

		-----CHANGED - PER EC 20210120:
		----Event Status
		----Any Recording Information past the Input Acquisition Date.

		-----CHANGED - Per EC 20210302 - Any recording >= the Input Acquisition Date

		------Changed 20200302 per EC - To >= Input Acquisition Date 
		
		----Initial Sweep Approach
		----1) Return Current Owner & Current Owner Change Date and any  Arm's Length Recording or Mortage after the Input Acquisition Date

		----Monitoring Approach
		----1) Return any Current Owner/Current Owner Change Date, Arm's Length Recording or Mortage since prior run

		
		
		--------------20210202 - Per EC ALWAYS return Current Owner & Current Owner Change Date - even if no changes!!!

		------Initial Sweep
		Update [zCust_ResoluteDilligence].[dbo].[A]
		Set A.[Current Owner Change Date] = convert(date,C.RecordingDt)
		--Select A.PROPERTYID, A.[Current Owner Change Date], B.CurrSaleRecordingDate, B.CurrentSaleTransactionId,B.FAOwnershipUpdateDt, B.FAOwnerTransactionId
		From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] as A 
		join [data].[dbo].[Property] as B with(NOLOCK) 
		on A.PROPERTYID = B.PropertyID
		join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS
		and B.PropertyID = C.FAPropertyId
		and B.FAOwnerTransactionId = C.TransactionId
		where A.PROPERTYID is not null
		and B.FAOwnerTransactionId is not null


		Update [zCust_ResoluteDilligence].[dbo].[A]
		Set A.[Current Owner Change Date] = convert(date,C.RecordingDt)
		--Select A.PROPERTYID, A.[Recording Date], B.CurrSaleRecordingDate, B.CurrentSaleTransactionId,B.FAOwnershipUpdateDt, B.FAOwnerTransactionId
		From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] as A 
		join [data].[dbo].[Property] as B with(NOLOCK) 
		on A.PROPERTYID = B.PropertyID
		join [data].[dbo].[Deed] as C with(NOLOCK) on B.FIPS = C.FIPS
		and B.PropertyID = C.FAPropertyId
		and B.CurrentSaleTransactionId = C.TransactionId
		where A.PROPERTYID is not null
		and B.FAOwnerTransactionId is null
		and B.CurrentSaleTransactionId is not null


				
	
		Select * From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		where [Current Owner Change Date] is not null


		--Select top 100 A.FAOwnershipUpdateDt, A.FAOwnerTransactionId, B.RecordingDt, A.CurrentSaleTransactionId, A.CurrSaleRecordingDate
		--From data.dbo.Property as A with(NOLOCK) 
		--join data.dbo.Deed as B with(NOLOCK) on A.FIPS = B.FIPS
		--and A.PropertyID = B.FAPropertyId
		--and A.FAOwnerTransactionId = B.TransactionId
		--where A.CurrSaleRecordingDate > B.RecordingDt


		----Initial Sweep Approach
		----1) Return All Arm's Length Recording or Mortage after the Input Acquisition Date

		----Monitoring Approach
		----1) Return All Arm's Length Recording or Mortage since prior run (using Max Tracked Date)

		----************NEED TO BUILD THIS PART****************------
	   ---------------Transactions------------------

		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist] SET toUse = NULL

		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')
		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'/','.')
		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK]
		Set DocumentNbr = REPLACE(DocumentNbr,'-','.')

		--Select * From w_TransHist
		--where  RAW_ID = 'MD01381' 
		--or  DocumentNbr like '44542/354'
		
		--Order by DocumentNbr

		--Delete from  w_TransHist
		--where DocumentNbr like '44542/354'
		--and RAW_ID = 'MD01381'
		


		--Select DocumentNbr,REPLACE(DocumentNbr,'/','.') From w_TransHist_FLANK
		--where DocumentNbr like '%/%'
			

		------20210227 - Per EC - Arms Length Deeds only & All mtgs recorded after input date & Max tracked dates
		UPDATE [zCust_ResoluteDilligence].[dbo].[w_TransHist]
		SET ToUse = 'Y'
		--Select A.DocumentType,DocumentTypeDesc,a.reCORDINGdATE,B.[INPUT Acquisition Date], A.Doc_Src_Ind
		FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist] a JOIN [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] b
		on A.RAW_ID = B.[INPUT KEY]
		WHERE CONVERT(DATE,a.reCORDINGdATE) >= Convert(date,B.[INPUT Acquisition Date])
		and A.Doc_SRC_IND in ('D','M')

		AND 
		(
			(A.Doc_SRC_IND like 'D' AND 
			(CONVERT(DATE,a.reCORDINGdATE) > Convert(date,B.MAX_DEED_DATE)
			OR B.MAX_DEED_DATE is null))
			OR
			(A.Doc_SRC_IND like 'M' AND 
			(CONVERT(DATE,a.reCORDINGdATE) > Convert(date,B.MAX_MTG_DATE)
			OR B.MAX_MTG_DATE is null))
		)


		Update [zCust_ResoluteDilligence].[dbo].[A]
		Set A.TOUSE = NULL
		--Select A.DocumentNbr, A.Doc_Id, B.Arms_Length
		From [zCust_ResoluteDilligence].[dbo].[w_TransHist] as A 
		join [zCust_ResoluteDilligence].[dbo].[w_DIM_NOVA_DOCUMENT] as B on A.REF_ID = B.REF_ID
		and A.Doc_Id = B.Doc_Id
		where  
		A.Doc_Src_Ind like 'D' and 
		(B.Arms_Length is null or B.Arms_Length = 0)
		and A.ToUse like 'Y'

		
		
					

		Truncate table w_TransHist_II

		INSERT INTO [zCust_ResoluteDilligence].[dbo].[w_TransHist_II]
		SELECT * 
		FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist]
		WHERE ToUSE = 'Y'


		Truncate table w_TransHist_III

		INSERT INTO [zCust_ResoluteDilligence].[dbo].[w_TransHist_III](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, TitleCompanyName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, 
					Raw_ID, DocDate, Assignor, Assignee, BuyerBorrower1, BuyerBorrower2)
		SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, TitleCompanyName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, 
					Raw_ID, DocDate, Assignor, Assignee, BuyerBorrower1, BuyerBorrower2
		FROM     [zCust_ResoluteDilligence].[dbo].[w_TransHist_II]
		WHERE  (ToUse = 'Y')

		

		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK] SET toUse = NULL

		--Select * From w_TransHist_FLANK
		--where [Doc_Src_Ind] like 'R'
		--and  [[Doc Type]Desc] not in ('RELEASE' , 'ASSIGNMENT')
					
		UPDATE [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK]
		SET ToUse = 'Y'
		--Select B.[INPUT Acquisition Date], a.reCORDINGdATE,Doc_SRC_IND
		FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK] a JOIN [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] b
		on A.RAW_ID = B.[INPUT KEY]
		WHERE CONVERT(DATE,a.reCORDINGdATE) >= Convert(date,B.[INPUT Acquisition Date])
		and A.Doc_SRC_IND in ('D','M')

		AND 
		(
			(A.Doc_SRC_IND like 'D' AND 
			(CONVERT(DATE,a.reCORDINGdATE) > Convert(date,B.MAX_DEED_DATE)
			OR B.MAX_DEED_DATE is null))
			OR
			(A.Doc_SRC_IND like 'M' AND 
			(CONVERT(DATE,a.reCORDINGdATE) > Convert(date,B.MAX_MTG_DATE)
			OR B.MAX_MTG_DATE is null))
		)

	
	

		Update [zCust_ResoluteDilligence].[dbo].[A]
		Set A.TOUSE = NULL
		--Select A.DocumentNbr, [CMTIDInstNbr],B.BkPgFrmt,DocNbrFrmt,A.Doc_Id, B.Armslength
		From [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK] as A 
		join [zCust_ResoluteDilligence].[dbo].[w_FLANK_DEEDS] as B on A.ChronoKey = B.ChronoKey
		and A.DocumentNbr = CASE WHEN [CMTIDInstNbr] is null and DocNbrFrmt is NULL THEN BkPgFrmt 
					when [CMTIDInstNbr] is null and DocNbrFrmt is not null then DocNbrFrmt
					when [CMTIDInstNbr] is not null then [CMTIDInstNbr] ELSE [CMTIDInstNbr] END
		where  
		A.Doc_Src_Ind like 'D' 
		and (B.Armslength  = 0 or B.Armslength is null)
		and A.ToUse like 'Y'



		Truncate table w_TransHist_FLANK_II

		INSERT INTO [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK_II]
		SELECT * 
		FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK]
		WHERE ToUSE = 'Y'

		
		INSERT INTO [zCust_ResoluteDilligence].[dbo].[w_TransHist_III]([Fips]
      ,[REF_ID]
      ,[RecordNumber]
      ,[RecordingDate]
      ,DocumentType
      ,[DocumentNbr]
      ,[BuyerBorrower]
      ,[SellerLender]
      ,[Value]
      ,[OrigTransRecDate]
      ,[OrigTransDocNumber]
      ,[Lien_Pos]
      ,[CmtId]
      ,[Source_Type]
      ,[Doc_Id]
      ,[Doc_Src_Ind]
      ,[OrigDoc_Id]
      ,DocumentTypeDesc
      ,[ToUse]
      
      ,[Loan_Type]
      
      ,[Raw_ID]
      ,[DocDate]
      ,[Assignor]
      ,[Assignee])
SELECT        
		A.[Fips]
      ,A.[REF_ID]
      ,A.[RecordNumber]
      ,A.[RecordingDate]
      ,A.DocumentType
      ,A.[DocumentNbr]
      ,A.[BuyerBorrower]
      ,A.[SellerLender]
      ,A.[Value]
      ,A.[OrigTransRecDate]
      ,A.[OrigTransDocNumber]
      ,A.[Lien_Pos]
      ,A.[CmtId]
      ,A.[Source_Type]
      ,A.[Doc_Id]
      ,A.[Doc_Src_Ind]
      ,A.[OrigDoc_Id]
      ,A.DocumentTypeDesc
      ,A.[ToUse]
    
          
      ,TRANSTYPE
     
      ,A.[Raw_ID]
      ,A.[DocDate]
      ,A.[OldLenderAssignor]
      ,A.[NewLenderAssignee]
	  --Select A.RAW_ID, A.DOcumentNbr, A.REcordingDate, B.DocumentNbr, B.REcordingDate
FROM            [zCust_ResoluteDilligence].[dbo].[w_TransHist_FLANK_II] as A
left outer join [zCust_ResoluteDilligence].[dbo].[w_TransHist_II] as B on 
A.RAW_ID = B.RAW_ID
and 
		(
		(Right(A.Documentnbr,len((case when CHARINDEX('.',B.DocumentNbr) > 0 then Right(B.DOcumentNbr,Charindex('.',REVERSE(B.DocumentNbr))-1) else B.DocumentNbr end)))
		 = (case when CHARINDEX('.',B.DocumentNbr) > 0 then Right(B.DOcumentNbr,Charindex('.',REVERSE(B.DocumentNbr))-1) else B.DocumentNbr end))
		 OR
		 (A.FA_BookPageFmt= B.DocumentNbr)
		 )
where B.DocumentNbr is null
and A.DocumentNbr is not null
and A.DocumentNbr not like ''





	Update [zCust_ResoluteDilligence].[dbo].[w_TransHist_III]
	Set DocumentType = 'T'
	where 
	(DocumentType is null or DocumentType like '')
	AND DocumentTypeDesc = 'TRUST DEED/MORTGAGE'


	


		Update [zCust_ResoluteDilligence].[dbo].[w_TransHist_III]
		Set RecordNumber = NULL

		UPDATE [zCust_ResoluteDilligence].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_III] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_ResoluteDilligence].[dbo].[w_TransHist_III] t WHERE ToUse = 'Y' ) r ON  t.DocumentNbr = r.DocumentNbr
				and r.RAW_ID = t.RAW_ID
		
		
		--Select * From [w_TransHist_III] where RAW_ID in (
		--Select RAW_ID from (
		--Select RAW_ID, RecordingDate, count(*) as TOTAL From [w_TransHist_III]
		--Group by RAW_ID, RecordingDate
		--Having count(*) > 1)A)
		--Order by RAW_ID, REcordNumber



		Update [zCust_ResoluteDilligence].[dbo].[x_custom_OUTPUT]
		Set NbrOfRecordings = NULL
		where convert(int,NbrOfRecordings) > 0

		SELECT Raw_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_III] 
		--where RecordNumber <= 30
		GROUP BY Raw_ID
		Order by max(RECORDNUMBER) desc

		Select * From [zCust_ResoluteDilligence].[dbo].[w_TransHist_III]
		where RAW_ID in (
		Select RAW_ID from (
		SELECT Raw_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_III] 
		GROUP BY Raw_ID ) A
		where NbrOfRecordings > 30)
		Order by RAW_ID, REcordNumber

		


		UPDATE [zCust_ResoluteDilligence].[dbo].[a]
		SET a.NbrOfRecordings =  b.NbrOfRecordings 
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_ResoluteDilligence].[dbo].[w_TransHist_III] GROUP BY RAW_ID) b
		on a.[INPUT KEY] = b.RAW_ID

		Select max(convert(int,NbrOfRecordings)) from [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]

		IF (Select max(convert(int,NbrOfRecordings)) from [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]) > 0

		BEGIN

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = MAX(convert(int,NbrofRecordings)) FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Document Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Buyer/Borrower_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Seller/Lender_' + @RecNbr + '] [varchar](250) NULL')


						EXEC('UPDATE a
						SET 
						A.[Record Number_' + @RecNbr + '] = ''' + @BeginNbrOfTrans + '''
						,a.[Recording Date_' + @RecNbr + '] = b.RecordingDate
						,a.[Doc Type_' + @RecNbr + '] = case when B.DocumentTypeDesc is null or B.DocumentTypeDesc like '''' then b.DocumentType
							 else b.DocumentTypeDesc end
						,a.[Document Number_' + @RecNbr + '] = b.DocumentNbr
						,a.[Buyer/Borrower_' + @RecNbr + '] = b.BuyerBorrower
						,a.[Seller/Lender_' + @RecNbr + '] = b.SellerLender
						,a.[Amount_' + @RecNbr + '] = b.Value
						
						FROM x_Custom_OUTPUT a JOIN (SELECT * FROM w_TransHist_III WHERE RecordNumber = ' + @BeginNbrOfTrans + ') b
						on a.[INPUT KEY] = b.RAW_ID')

						
						--	------------------Translate codes--------------------
							EXEC('Update a
							SET a.[Doc Type_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							from x_Custom_OUTPUT a join (SELECT distinct output_Code,Consolidated_Definition
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON a.[Doc Type_' + @RecNbr + '] = b.[output_Code]
							')

							EXEC('
							Update A
							SET A.[Doc Type_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							--Select * 
							from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON a.[Doc Type_' + @RecNbr + '] = b.[output_Code]
							and A.FIPS = B.FIPS
							join w_TransHist_III as C on A.[Document Number_' + @RecNbr + '] = C.DocumentNbr
							and B.Document_Type = C.Doc_Src_Ind
							where C.Source_Type  like ''T'' 
							and B.Document_Type is not null
							')

							EXEC('
							Update A
							SET A.[Doc Type_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							--Select * 
							from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON a.[Doc Type_' + @RecNbr + '] = b.[output_Code]
							and A.FIPS = B.FIPS
							join w_TransHist_III as C on A.[Document Number_' + @RecNbr + '] = C.DocumentNbr
							where C.Source_Type  like ''T'' 
							and B.Document_Type is  null
							')
			
							EXEC('
							Update A
							SET A.[Doc Type_' + @RecNbr + '] = Upper(b.[Consolidated_Definition])
							--Select * 
							from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
							FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
							) b
							ON A.[Doc Type_' + @RecNbr + '] = b.[output_Code]
							and A.FIPS = B.FIPS
							join w_TransHist_III as C on A.[Document Number_' + @RecNbr + '] = C.DocumentNbr
							where C.Source_Type  like ''T''
							')

							EXEC('
							Update A
							SET A.[Doc Type_' + @RecNbr + '] = Upper(b.[Code Description])
							--Select * 
							from x_Custom_OUTPUT a join 
							(
							Select * FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup]
							WHERE 
							Ltrim(Rtrim([Deed_Table_Column_name])) like ''DETAILED_DOC_TYPE''
							or [Deed_Table_Column_name] like ''DETAILED_DOC_TYPE ''
							) b
							ON A.[Doc Type_' + @RecNbr + '] = b.Value
							join w_TransHist_III as C on A.[Document Number_' + @RecNbr + '] = C.DocumentNbr
							where (C.Source_Type not like ''T'' or C.Source_Type is null)
							')

							EXEC('
							Update A
							SET A.[Doc Type_' + @RecNbr + '] = Upper(b.[CodeDesc])
							from x_Custom_OUTPUT a join [Global].[dbo].[lkup_Doc_Type] B
							ON A.[Doc Type_' + @RecNbr + '] = b.[DocTypeID]
							')
														
							
						

					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END
		
		--Select * From x_custom_OUTPUT
		--where DocumentNumber is null and REcordNum is not null
		--Order by INPUTKEY,convert(int,RecordNum)

		END



		------------------20190220 Per Victor -----------
		------The Doc_types table should only be used when the source_type from the DimNovaDoc table is ‘T’. 
		------All other sources you can use the DeedLookup table. 

		--	Update x_Custom_OUTPUT
		--	SET [Doc Type] = Upper(b.[Consolidated_Definition])
		--	--Select * 
		--	from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
		--	FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
		--	) b
		--	ON a.[Doc Type] = b.[output_Code]
		--	and A.FIPS = B.FIPS
		--	join w_TransHist_III as C on A.[Document Number] = C.DocumentNbr
		--	and B.Document_Type = C.Doc_Src_Ind
		--	where C.Source_Type  like 'T' 
		--	and B.Document_Type is not null


		--	Update x_Custom_OUTPUT
		--	SET [Doc Type] = Upper(b.[Consolidated_Definition])
		--	--Select * 
		--	from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
		--	FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
		--	) b
		--	ON a.[Doc Type] = b.[output_Code]
		--	and A.FIPS = B.FIPS
		--	join w_TransHist_III as C on A.[Document Number] = C.DocumentNbr
		--	where C.Source_Type  like 'T' 
		--	and B.Document_Type is  null

			
			
		--	Update x_Custom_OUTPUT
		--	SET [Doc Type] = Upper(b.[Consolidated_Definition])
		--	--Select * 
		--	from x_Custom_OUTPUT a join (SELECT distinct FIPS,output_Code,Consolidated_Definition,Document_Type
		--	FROM [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types
		--	) b
		--	ON a.[Doc Type] = b.[output_Code]
		--	and A.FIPS = B.FIPS
		--	join w_TransHist_III as C on A.[Document Number] = C.DocumentNbr
		--	where C.Source_Type  like 'T' 
			

		--	Update x_Custom_OUTPUT
		--	SET [Doc Type] = Upper(b.[Code Description])
		--	--Select * 
		--	from x_Custom_OUTPUT a join 
		--	(
		--	Select * FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup]
		--	WHERE 
		--	Ltrim(Rtrim([Deed_Table_Column_name])) like 'DETAILED_DOC_TYPE'
		--	or [Deed_Table_Column_name] like 'DETAILED_DOC_TYPE '
		--	) b
		--	ON a.[Doc Type] = b.Value
		--	join w_TransHist_III as C on A.[Document Number] = C.DocumentNbr
		--	where (C.Source_Type not like 'T' or C.Source_Type is null)




		--	Update x_Custom_OUTPUT
		--	SET [Doc Type] = Upper(b.[CodeDesc])
		--	from x_Custom_OUTPUT a join [Global].[dbo].[lkup_Doc_Type] B
		--	ON a.[Doc Type] = b.[DocTypeID]


			--Select [Doc Type], count(*) From x_Custom_OUTPUT
			--Group by [Doc Type]
			--Order by [Doc Type]

		
			

		----------------------

		Update [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] 
		SET [Deed Coverage Status] = CASE WHEN [Deed COverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_ResoluteDilligence].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ResoluteDilligence].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID


		Update [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN 
		(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ResoluteDilligence].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT] a join [zCust_ResoluteDilligence].[dbo].[a_PropMatch_WORK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 


		Select * From [zCust_ResoluteDilligence].[dbo].[x_custom_OUTPUT]
		where [Property Status] like 'Property Found'
		and ([Current Owner] like '' or [Current Owner] is null)
		Order by [Current Owner]



		Update [zCust_ResoluteDilligence].[dbo].[x_custom_OUTPUT]
		Set [Property Status] = 'Property Not Found'
		where [Property Status] like 'Property Found'
		and ([Current Owner] like '' or [Current Owner] is null)
		and PropertyID like '0'
		



		---Per workorder - Event Found = Any Recording Information past the Input Acquisition Date.
		Update [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		SET [Event Status] = case when nbrofrecordings > 0 THEN 'Event Found' ELSE 'Event Not Found' END
				


		Select [Property Status], count(*) From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		Group by [Address Standardization]

		Select [Deed Coverage Status], count(*) From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		Group by [Deed Coverage Status]

		Select [Mortgage Coverage Status], count(*) From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		Group by [Mortgage Coverage Status]

	
		Select [Event Status], count(*) From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		Group by [Event Status]

		Select * From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		where NbrOfRecordings > 0
		Order by NbrOfRecordings desc

		Select [INPUT KEY], WORK_REF_ID, PROPERTYID, [Current Owner Change Date], [INPUT Acquisition Date], MAX_DEED_DATE From [zCust_ResoluteDilligence].[dbo].[x_Custom_OUTPUT]
		where [Current Owner] is not null and [Current Owner Change Date] is not null
		and NbrOfRecordings is null
		and [Current Owner Change Date] > [INPUT Acquisition Date]
		and [Current Owner Change Date] > MAX_DEED_DATE
	

		Select FIPS, [INPUT KEY], WORK_REF_ID, PROPERTYID,[Input Vesting], [Current Owner], [INPUT Acquisition Date], [Deed Through Date] 
				--,*
		From [zCust_ResoluteDilligence].[dbo].[zzz_ResoluteDilligence_20220915_OUTPUT]
		where [Property Status] like 'Property Found'
		AND [Input Vesting] <> [Current Owner]
		AND [Input Vesting] not like '%' + left([Current Owner],4)  + '%'
		AND REPLACE([Input Vesting],'-',' ') not like '%' + left(REPLACE([Current Owner],'-',' '),4)  + '%'
		AND REPLACE([Current Owner],'-',' ') not like '%' + left(REPLACE([Input Vesting],'-',' '),4)  + '%'
		AND REPLACE([Input Vesting],'-',' ') not like '%' + right(REPLACE([Current Owner],'-',' '),7)  + '%'
		and convert(date,[INPUT Acquisition Date]) <= convert(date,convert(varchar(10),[Deed Through Date],112))

		Order by FIPS
	

	


END




