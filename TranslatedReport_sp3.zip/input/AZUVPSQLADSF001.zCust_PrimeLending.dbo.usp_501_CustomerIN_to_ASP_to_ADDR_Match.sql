SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [zCust_PrimeLending].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
	
AS
BEGIN

	SET NOCOUNT ON;



		-----------------Prime Lending---------
		--TRUNCATE TABLE INPUT_IN

		--INSERT INTO INPUT_IN([InputKey],INPUTDocSubmittedDate,[InputAddress],[InputCity],[InputState],[InputZip],INPUTBorrowerLastName)
		--Select [UniqueID]
		--,convert(date,[FundingDate])
		--,[PropertyAddress]
  --    ,[PropertyCity]
  --    ,[PropertyState]
  --    ,[PropertyZip]
  --    --,[Borrower1Name]
	 -- ,right(LTRIM(RTRIM([Borrower1Name])),charindex(' ',REVERSE(LTRIM(RTRIM([Borrower1Name]))))-1)
    
	 --FROM [dbo].[INPUT_RAW_PRIMELENDING_20201005]
	 --Order by [PropertyZip]

	 	TRUNCATE TABLE INPUT_IN

		INSERT INTO [zCust_PrimeLending].[dbo].[INPUT_IN]([InputKey],INPUTDocSubmittedDate,[InputAddress],[InputCity],[InputState],[InputZip],INPUTBorrowerLastName)
		Select [Unique ID]
		,convert(date,[Closing Date])
		,[Address]
      ,[City]
      ,[State]
      ,[Zip]
      --,[Borrower1Name]
	  ,case when LTRIM(RTRIM([Borrower Name 1 ])) like '% %' then 
	  right(LTRIM(RTRIM([Borrower Name 1 ])),CHarindex(' ',LTRIM(RTRIM(REVERSE([Borrower Name 1 ]))))-1)
	  else LTRIM(RTRIM([Borrower Name 1 ])) end
    
	 FROM [zCust_PrimeLending].[dbo].[Input_RAW_CUST]
	 


	 	 

		Select top 100 * From [zCust_PrimeLending].[dbo].[INPUT_IN] Order by Inputzip, INPUTKey

		Select INPUTKEY, count(*) From [zCust_PrimeLending].[dbo].[INPUT_IN]
		Group by INPUTKEY
		having count(*) > 1

		Select * From [zCust_PrimeLending].[dbo].[INPUT_IN]
		where len([InputState]) > 2
		or len([InputZip]) > 10

		Select * From [zCust_PrimeLending].[dbo].[INPUT_IN]
		where [InputCity] like '%  %'
		OR [InputAddress] like '%  %'



		EXEC [zCust_PrimeLending].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

			IF (SELECT COUNT(*) FROM [zCust_PrimeLending].[dbo].[PrimeLending_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_PrimeLending].[dbo].[PrimeLending_STD])
					END
			END
				
			EXEC [zCust_PrimeLending].[dbo].[usp_100c_sp_ASP_Cust_STD]

			
			EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_PrimeLending'
	
			EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_PrimeLending'


			Select CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
			from [zCust_PrimeLending].[dbo].[a_PropMatch_WORK]
			group by CASE WHEN REF_ID is NULL then 'N' ELSE 'Y' END 

			Select CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END as AddrMatch, COUNT(*) as RecCount
			from [zCust_PrimeLending].[dbo].[a_PropMatch_WORK_FLANK]
			group by CASE WHEN PropertyID is NULL then 'N' ELSE 'Y' END 

			Select * From [zCust_PrimeLending].[dbo].[a_PropMatch_WORK_FLANK]
			where PropertyID is null


			EXEC [zCust_PrimeLending].[dbo].[usp_502_Pull_DTDB_DATA_V2]

			EXEC [zCust_PrimeLending].[dbo].[usp_502_Pull_FLANK_DATA]

			--Insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.a_PropMatch_Work
			--Select * From a_PropMatch_Work


			
		
END



