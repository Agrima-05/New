SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [zCust_ProctorFinancial_HOA_LIEN].[dbo].[DROP_DTDB_TABLES_V2]
as
BEGIN

--/****** Object:  Table [dbo].[w_UniqueRefId]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_UniqueRefId]


--/****** Object:  Table [dbo].[w_RAS]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_RAS]


--/****** Object:  Table [dbo].[w_PropertyReference]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_PropertyReference]


--/****** Object:  Table [dbo].[w_PreForeclosure]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_PreForeclosure]


--/****** Object:  Table [dbo].[w_LastSaleDATA]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_LastSaleDATA]


--/****** Object:  Table [dbo].[w_FCT_DOC_NAME]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_FCT_DOC_NAME]


--/****** Object:  Table [dbo].[w_DOC_XREF]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DOC_XREF]


--/****** Object:  Table [dbo].[w_DM_Data]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DM_Data]


--/****** Object:  Table [dbo].[w_DIM_NOVA_DOCUMENT]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DIM_NOVA_DOCUMENT]


--/****** Object:  Table [dbo].[w_DIM_CLNAME]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DIM_CLNAME]


--/****** Object:  Table [dbo].[w_DEEDHIST]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DEEDHIST]


--/****** Object:  Table [dbo].[w_DEED]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_DEED]


--/****** Object:  Table [dbo].[w_AVM_Coverage]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_AVM_Coverage]


--/****** Object:  Table [dbo].[w_AVM]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_AVM]


--/****** Object:  Table [dbo].[w_Assr]    Script Date: 07/16/2019 5:20:35 AM ******/
--DROP TABLE [dbo].[w_Assr]


/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_UniqueRefId]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_UniqueRefId]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_RAS]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_RAS]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_PropertyReference]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_PropertyReference]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_PreForeclosure]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_PreForeclosure]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_LastSaleDATA]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_LastSaleDATA]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_FCT_DOC_NAME]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_FCT_DOC_NAME]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DOC_XREF]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DOC_XREF]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DM_Data]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DM_Data]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DIM_NOVA_DOCUMENT]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DIM_NOVA_DOCUMENT]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DIM_CLNAME]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DIM_CLNAME]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DEEDHIST]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DEEDHIST]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DEED]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_DEED]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_AVM_Coverage]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_AVM_Coverage]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_AVM]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_AVM]
/*IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Assr]') AND type in (N'U'))*/
DROP TABLE IF EXISTS [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Assr]




END

