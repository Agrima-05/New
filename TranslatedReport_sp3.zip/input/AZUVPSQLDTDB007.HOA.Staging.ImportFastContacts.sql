/* Source: AZUVNSQLDTDB003.datatree.local | HOA | Staging.ImportFastContacts | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [HOA].[Staging].[ImportFastContacts]
AS
-- =============================================
-- Original Author:		Ian Perez
-- Create date: 02/14/2016
-- Description:	Import Owner Association Contact Data from FAST data into Staging 
-- ChangeLog: 06/10/2016 TDao - Improved phone numbers
--			  06/28/2016 TDao - Filtered out City - Any City
--			  12/21/2016 TDao - Remove obsolete phones
-- =============================================
Declare @regex varchar(200) = '(?:\+?1)?-?\s*\(?(\d{3})?\)?(?:\.|-|\/)?\s*(?:\d-)?(\d{3})(?:\.|-|\s+)*(\d{4})(?:\s*[A-z]+\.?\s*(\d+))?'
       SELECT
              a.Id
              ,NULLIF(HomeOwnrsAsctnContctNm, '') AS Name
              ,NULLIF(LTRIM(RTRIM(sa.Street_Number) + ' ')
                     + LTRIM(RTRIM(sa.Direction) + ' ')
                     + LTRIM(RTRIM(sa.Street_Name) + ' ')
                     + LTRIM(RTRIM(sa.Street_Type) + ' ')
                     + LTRIM(RTRIM(sa.Post_Direction) + ' ')
                     + LTRIM(RTRIM(sa.Unit_Type) + ' ')
                     + LTRIM(RTRIM(sa.Unit) + ' '), '') AS [Address]
              ,NULLIF(City, '') As City
              ,NULLIF([State], '') As [State]
              ,NULLIF(Zip, '') As Zip
              ,NULLIF(Plus4, '') As Plus4
              ,NULLIF(HomeOwnrsAsctnEMailAddrs, '') AS Email
			  ,Case When [SPDB].[dbo].[RegexIsMatch](HomeOwnrsAsctnBusnsPhnNbr , @regex, 0) = 1 THEN Case When [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnBusnsPhnNbr, @regex, 1, 0) <> ''
					 THEN '(' +  [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnBusnsPhnNbr, @regex, 1, 0) + ') ' END +
								 + [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnBusnsPhnNbr, @regex, 2, 0) + '-'
							  + [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnBusnsPhnNbr, @regex, 3, 0)
							  + ISNULL(NULLIF(' x' + HomeOwnrsAsctnBusnsExtnsnNbr, ' x'), '')
					 END as BusinessPhoneNbr
			  ,Case When [SPDB].[dbo].[RegexIsMatch](HomeOwnrsAsctnCellPhnNbr , @regex, 0) = 1 THEN Case When [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnCellPhnNbr, @regex, 1, 0) <> ''
					 THEN '(' +  [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnCellPhnNbr, @regex, 1, 0) + ') ' END +
								 + [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnCellPhnNbr, @regex, 2, 0) + '-'
							  + [SPDB].[dbo].[RegexExtract](HomeOwnrsAsctnCellPhnNbr, @regex, 3, 0)
					 END as CellPhoneNbr
              ,NULL AS ContactId
       INTO #FastData
       FROM [HOA].[Staging].[FastData] a
       INNER JOIN [HOA].[Staging].[FastData_OA_Addr_STD] sa ON a.Id = sa.ID
	   WHERE sa.City <> 'Any City'
	   
       ALTER TABLE #FastData ADD PRIMARY KEY (Id)
 
       INSERT INTO [HOA].[Staging].[Contact] (
              Name
              ,[Address]
              ,City
              ,[State]
              ,Zip
              ,Plus4
              ,Email
              ,BusinessPhoneNbr
              ,CellPhoneNbr
              ,SourceCount
              ,InitialSourceId
              ,SourcePK
			  ,CreateDate
       )
       SELECT
              a.Name
              ,a.[Address]
              ,a.City
              ,a.[State]
              ,a.Zip
              ,a.Plus4
              ,a.Email
              ,a.BusinessPhoneNbr
              ,a.CellPhoneNbr
              ,NULL As SourceCount
              ,1 AS SourceId
              ,MIN(a.Id) AS SourcePK
			  ,getdate()
       FROM #FastData a
       LEFT JOIN [HOA].[Staging].[Contact] b ON
              (
                     a.Name = b.Name
                     OR (a.Name IS NULL AND b.Name IS NULL)
              )
              AND (
                     a.[Address] = b.[Address]
                     OR (a.[Address] IS NULL AND b.[Address] IS NULL)
              )
              AND (
                     a.City = b.City
                     OR (a.City IS NULL AND b.City IS NULL)
              )
              AND (
                     a.[State] = b.[State]
                     OR (a.[State] IS NULL AND b.[State] IS NULL)
              )
              AND (
                     a.Zip = b.Zip
                     OR (a.Zip IS NULL AND b.Zip IS NULL)
              )
              AND (
                     a.Plus4 = b.Plus4
                     OR (a.Plus4 IS NULL AND b.Plus4 IS NULL)
              )
              AND (
                     a.Email = b.Email
                     OR (a.Email IS NULL AND b.Email IS NULL)
              )
              AND (
                     a.BusinessPhoneNbr = b.BusinessPhoneNbr
                     OR (a.BusinessPhoneNbr IS NULL AND b.BusinessPhoneNbr IS NULL)
              )
              AND (
                     a.CellPhoneNbr = b.CellPhoneNbr
                     OR (a.CellPhoneNbr IS NULL AND b.CellPhoneNbr IS NULL)
              )
       WHERE b.Id IS NULL
       GROUP BY
              a.Name
              ,a.[Address]
              ,a.City
              ,a.[State]
              ,a.Zip
              ,a.Plus4
              ,a.Email
              ,a.BusinessPhoneNbr
              ,a.CellPhoneNbr
 
       UPDATE [HOA].[Staging].[a]
       SET ContactId = b.Id
       FROM #FastData a
       INNER JOIN [HOA].[Staging].[Contact] b ON
              (
                     a.Name = b.Name
                     OR (a.Name IS NULL AND b.Name IS NULL)
              )
              AND (
                     a.[Address] = b.[Address]
                     OR (a.[Address] IS NULL AND b.[Address] IS NULL)
              )
              AND (
                     a.City = b.City
                     OR (a.City IS NULL AND b.City IS NULL)
              )
              AND (
                     a.[State] = b.[State]
                     OR (a.[State] IS NULL AND b.[State] IS NULL)
              )
              AND (
                     a.Zip = b.Zip
                     OR (a.Zip IS NULL AND b.Zip IS NULL)
              )
              AND (
                     a.Plus4 = b.Plus4
                     OR (a.Plus4 IS NULL AND b.Plus4 IS NULL)
              )
              AND (
                     a.Email = b.Email
                     OR (a.Email IS NULL AND b.Email IS NULL)
              )
              AND (
                     a.BusinessPhoneNbr = b.BusinessPhoneNbr
                     OR (a.BusinessPhoneNbr IS NULL AND b.BusinessPhoneNbr IS NULL)
              )
              AND (
                     a.CellPhoneNbr = b.CellPhoneNbr
                     OR (a.CellPhoneNbr IS NULL AND b.CellPhoneNbr IS NULL)
              )

 
       UPDATE [HOA].[Staging].[a]
       SET ContactId = b.ContactId
       FROM [HOA].[Staging].[FastData] a
       INNER JOIN #FastData b ON a.Id = b.Id
       WHERE a.ContactId IS NULL OR a.ContactId <> b.ContactId

