SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Lot_v3]

AS
BEGIN


	SET NOCOUNT ON;

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[LotJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[LotJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], j.[value] as Lot, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Lot') AS j

			DROP TABLE IF EXISTS Table_W
			DROP TABLE IF EXISTS Table_X
			DROP TABLE IF EXISTS Table_Y
			DROP TABLE IF EXISTS Table_Z


			Select MLSID,MLS_LISTING_ID,[CurrentUse] INTO [src_PlatLabs].[dbo].[Table_w]
					from [src_Platlabs].[features].[LotJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(REPLACE([Lot],'Current Use','CurrentUse')) WITH([CurrentUse] varchar(1000)) as Use_array
						WHERE [Lot] like '%"Current Use"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_w(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_w(MLSID)

			Select MLSID,MLS_LISTING_ID,[Fencing] INTO [src_PlatLabs].[dbo].[Table_x]
					from [src_Platlabs].[features].[LotJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Lot]) WITH([Fencing] varchar(1000)) as Fencing_array
						WHERE [Lot] like '%"Fencing"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_x(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_x(MLSID)

			Select MLSID,MLS_LISTING_ID,[View] INTO [src_PlatLabs].[dbo].[Table_y]
					from [src_Platlabs].[features].[LotJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Lot]) WITH([View] varchar(1000)) as View_array
						WHERE [Lot] like '%"View"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_y(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_y(MLSID)

			Select MLSID,MLS_LISTING_ID,[Zoning] INTO [src_PlatLabs].[dbo].[Table_z]
					from [src_Platlabs].[features].[LotJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Lot]) WITH([Zoning] varchar(1000)) as Zoning_array
						WHERE [Lot] like '%"Zoning"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_z(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_z(MLSID)


			EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




