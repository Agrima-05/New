/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_import_FMA_Daily_Ads_wrk | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_import_FMA_Daily_Ads_wrk] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/
BEGIN TRY
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_import_FMA_Daily_Ads_wrk'
		,N'Started'

	BEGIN
		TRUNCATE TABLE [listings].[listings_tmp].[FMA_Daily_Ads_wrk2]
	END

	BEGIN
		INSERT INTO [listings].[listings_tmp].[FMA_Daily_Ads_wrk2]
		SELECT ROW_NUMBER() OVER (
				PARTITION BY snapshot_id
				,property_id
				,isnull(listing_number, '  ') ORDER BY updated_at DESC
					,created_at DESC
				) AS rownum
			,id
			,ad_source_id
			,property_id
			,snapshot_id
			,is_active
			,street_address
			,city
			,urbanization
			,county_name
			,STATE
			,postal_code
			,asking_price
			,advertised_on
			,market_status
			,agent_name
			,agent_telephone
			,agent_email
			,agent_website
			,brokerage_name
			,brokerage_street_address
			,brokerage_city
			,brokerage_state
			,brokerage_postal_code
			,brokerage_telephone
			,brokerage_website
			,is_fsbo
			,is_lender_owned
			,is_short_sale
			,has_notice_of_default
			,local_assessor_id
			,tax_year
			,tax_amount
			,assessments
			,association_fees
			,association_fees_frequency
			,property_type_description
			,subdivision
			,bedrooms_varchar
			,bedrooms_int
			,bathrooms_varchar
			,bathrooms_total
			,bathrooms_full
			,bathrooms_3_4
			,bathrooms_half
			,lot_dimensions
			,lot_size_string
			,lot_size_decimal
			,lot_size_unit
			,square_feet
			,square_feet_foundation
			,square_feet_total
			,square_feet_finished
			,square_feet_above_ground
			,square_feet_below_ground
			,garage_description
			,garage_stalls
			,year_built
			,stories
			,water_source
			,sewer_source
			,school_district
			,school_elementary
			,school_middle
			,school_senior_high
			,construction_description
			,floor_description
			,cooling_description
			,heating_description
			,basement_description
			,fireplace_description
			,interior_description
			,general_description
			,parking_description
			,exterior_description
			,roof_description
			,pool_description
			,zoning_description
			,land_description
			,green_energy_description
			,hoa_amenities
			,disabled_accessibility_description
			,design_features_description
			,legal_description
			,included_items
			,listing_number
			,has_pool
			,body_of_water
			,water_front_type
			,sold_on
			,created_at
			,updated_at
			,latitude
			,longitude
			,in_gated_community
			,checksum
			,created
			,updated
		FROM [listings].[listings_tmp].[FMA_Daily_Ads_wrk]
	END

	BEGIN
		DELETE
		FROM [listings].[listings_tmp].[FMA_Daily_Ads_wrk2]
		WHERE rownum > 1
	END

	BEGIN
		TRUNCATE TABLE [listings].[listings_tmp].[FMA_Daily_Ads_wrk]
	END

	BEGIN
		INSERT INTO [listings].[listings_tmp].[FMA_Daily_Ads_wrk] (
			[id]
			,[ad_source_id]
			,[property_id]
			,[snapshot_id]
			,[is_active]
			,[street_address]
			,[city]
			,[urbanization]
			,[county_name]
			,[STATE]
			,[postal_code]
			,[asking_price]
			,[advertised_on]
			,[market_status]
			,[agent_name]
			,[agent_telephone]
			,[agent_email]
			,[agent_website]
			,[brokerage_name]
			,[brokerage_street_address]
			,[brokerage_city]
			,[brokerage_state]
			,[brokerage_postal_code]
			,[brokerage_telephone]
			,[brokerage_website]
			,[is_fsbo]
			,[is_lender_owned]
			,[is_short_sale]
			,[has_notice_of_default]
			,[local_assessor_id]
			,[tax_year]
			,[tax_amount]
			,[assessments]
			,[association_fees]
			,[association_fees_frequency]
			,[property_type_description]
			,[subdivision]
			,[bedrooms_varchar]
			,[bedrooms_int]
			,[bathrooms_varchar]
			,[bathrooms_total]
			,[bathrooms_full]
			,[bathrooms_3_4]
			,[bathrooms_half]
			,[lot_dimensions]
			,[lot_size_string]
			,[lot_size_decimal]
			,[lot_size_unit]
			,[square_feet]
			,[square_feet_foundation]
			,[square_feet_total]
			,[square_feet_finished]
			,[square_feet_above_ground]
			,[square_feet_below_ground]
			,[garage_description]
			,[garage_stalls]
			,[year_built]
			,[stories]
			,[water_source]
			,[sewer_source]
			,[school_district]
			,[school_elementary]
			,[school_middle]
			,[school_senior_high]
			,[construction_description]
			,[floor_description]
			,[cooling_description]
			,[heating_description]
			,[basement_description]
			,[fireplace_description]
			,[interior_description]
			,[general_description]
			,[parking_description]
			,[exterior_description]
			,[roof_description]
			,[pool_description]
			,[zoning_description]
			,[land_description]
			,[green_energy_description]
			,[hoa_amenities]
			,[disabled_accessibility_description]
			,[design_features_description]
			,[legal_description]
			,[included_items]
			,[listing_number]
			,[has_pool]
			,[body_of_water]
			,[water_front_type]
			,[sold_on]
			,[created_at]
			,[updated_at]
			,[latitude]
			,[longitude]
			,[in_gated_community]
			,[checksum]
			,[created]
			,[updated]
			)
		SELECT b.[id]
			,b.[ad_source_id]
			,b.[property_id]
			,b.[snapshot_id]
			,b.[is_active]
			,b.[street_address]
			,b.[city]
			,b.[urbanization]
			,b.[county_name]
			,b.[STATE]
			,b.[postal_code]
			,b.[asking_price]
			,b.[advertised_on]
			,b.[market_status]
			,b.[agent_name]
			,b.[agent_telephone]
			,b.[agent_email]
			,b.[agent_website]
			,b.[brokerage_name]
			,b.[brokerage_street_address]
			,b.[brokerage_city]
			,b.[brokerage_state]
			,b.[brokerage_postal_code]
			,b.[brokerage_telephone]
			,b.[brokerage_website]
			,b.[is_fsbo]
			,b.[is_lender_owned]
			,b.[is_short_sale]
			,b.[has_notice_of_default]
			,b.[local_assessor_id]
			,b.[tax_year]
			,b.[tax_amount]
			,b.[assessments]
			,b.[association_fees]
			,b.[association_fees_frequency]
			,b.[property_type_description]
			,b.[subdivision]
			,b.[bedrooms_varchar]
			,b.[bedrooms_int]
			,b.[bathrooms_varchar]
			,b.[bathrooms_total]
			,b.[bathrooms_full]
			,b.[bathrooms_3_4]
			,b.[bathrooms_half]
			,b.[lot_dimensions]
			,b.[lot_size_string]
			,b.[lot_size_decimal]
			,b.[lot_size_unit]
			,b.[square_feet]
			,b.[square_feet_foundation]
			,b.[square_feet_total]
			,b.[square_feet_finished]
			,b.[square_feet_above_ground]
			,b.[square_feet_below_ground]
			,b.[garage_description]
			,b.[garage_stalls]
			,b.[year_built]
			,b.[stories]
			,b.[water_source]
			,b.[sewer_source]
			,b.[school_district]
			,b.[school_elementary]
			,b.[school_middle]
			,b.[school_senior_high]
			,b.[construction_description]
			,b.[floor_description]
			,b.[cooling_description]
			,b.[heating_description]
			,b.[basement_description]
			,b.[fireplace_description]
			,b.[interior_description]
			,b.[general_description]
			,b.[parking_description]
			,b.[exterior_description]
			,b.[roof_description]
			,b.[pool_description]
			,b.[zoning_description]
			,b.[land_description]
			,b.[green_energy_description]
			,b.[hoa_amenities]
			,b.[disabled_accessibility_description]
			,b.[design_features_description]
			,b.[legal_description]
			,b.[included_items]
			,b.[listing_number]
			,b.[has_pool]
			,b.[body_of_water]
			,b.[water_front_type]
			,b.[sold_on]
			,b.[created_at]
			,b.[updated_at]
			,b.[latitude]
			,b.[longitude]
			,b.[in_gated_community]
			,b.[checksum]
			,b.[created]
			,b.[updated]
		FROM [listings].[listings_tmp].[FMA_Snapshot_wrk] a WITH (NOLOCK)
		INNER JOIN [listings].[listings_tmp].[FMA_Daily_Ads_wrk2] b WITH (NOLOCK) ON b.snapshot_id = a.id
	END

	-- make sure that we only have records on _wrk table that are supposed to go to real table
	-- this can only run after the snapshort is loaded
	--truncate taBLE listings.listings_dbo.[FMA_Daily_Ads]  -- ?????????????????????????????????????????????????? THIS NEED STO BE REMOVED WHEN WE RUN MULTIPLE DAYS
	BEGIN
		INSERT INTO [listings].[listings_dbo].[FMA_Daily_Ads] (
			[id]
			,[ad_source_id]
			,[property_id]
			,[snapshot_id]
			,[is_active]
			,[street_address]
			,[city]
			,[urbanization]
			,[county_name]
			,[STATE]
			,[postal_code]
			,[asking_price]
			,[advertised_on]
			,[market_status]
			,[agent_name]
			,[agent_telephone]
			,[agent_email]
			,[agent_website]
			,[brokerage_name]
			,[brokerage_street_address]
			,[brokerage_city]
			,[brokerage_state]
			,[brokerage_postal_code]
			,[brokerage_telephone]
			,[brokerage_website]
			,[is_fsbo]
			,[is_lender_owned]
			,[is_short_sale]
			,[has_notice_of_default]
			,[local_assessor_id]
			,[tax_year]
			,[tax_amount]
			,[assessments]
			,[association_fees]
			,[association_fees_frequency]
			,[property_type_description]
			,[subdivision]
			,[bedrooms_varchar]
			,[bedrooms_int]
			,[bathrooms_varchar]
			,[bathrooms_total]
			,[bathrooms_full]
			,[bathrooms_3_4]
			,[bathrooms_half]
			,[lot_dimensions]
			,[lot_size_string]
			,[lot_size_decimal]
			,[lot_size_unit]
			,[square_feet]
			,[square_feet_foundation]
			,[square_feet_total]
			,[square_feet_finished]
			,[square_feet_above_ground]
			,[square_feet_below_ground]
			,[garage_description]
			,[garage_stalls]
			,[year_built]
			,[stories]
			,[water_source]
			,[sewer_source]
			,[school_district]
			,[school_elementary]
			,[school_middle]
			,[school_senior_high]
			,[construction_description]
			,[floor_description]
			,[cooling_description]
			,[heating_description]
			,[basement_description]
			,[fireplace_description]
			,[interior_description]
			,[general_description]
			,[parking_description]
			,[exterior_description]
			,[roof_description]
			,[pool_description]
			,[zoning_description]
			,[land_description]
			,[green_energy_description]
			,[hoa_amenities]
			,[disabled_accessibility_description]
			,[design_features_description]
			,[legal_description]
			,[included_items]
			,[listing_number]
			,[has_pool]
			,[body_of_water]
			,[water_front_type]
			,[sold_on]
			,[created_at]
			,[updated_at]
			,[latitude]
			,[longitude]
			,[in_gated_community]
			,[checksum]
			,[created]
			,[updated]
			)
		SELECT b.[id]
			,b.[ad_source_id]
			,b.[property_id]
			,b.[snapshot_id]
			,b.[is_active]
			,b.[street_address]
			,b.[city]
			,b.[urbanization]
			,b.[county_name]
			,b.[STATE]
			,b.[postal_code]
			,b.[asking_price]
			,b.[advertised_on]
			,b.[market_status]
			,b.[agent_name]
			,b.[agent_telephone]
			,b.[agent_email]
			,b.[agent_website]
			,b.[brokerage_name]
			,b.[brokerage_street_address]
			,b.[brokerage_city]
			,b.[brokerage_state]
			,b.[brokerage_postal_code]
			,b.[brokerage_telephone]
			,b.[brokerage_website]
			,b.[is_fsbo]
			,b.[is_lender_owned]
			,b.[is_short_sale]
			,b.[has_notice_of_default]
			,b.[local_assessor_id]
			,b.[tax_year]
			,b.[tax_amount]
			,b.[assessments]
			,b.[association_fees]
			,b.[association_fees_frequency]
			,b.[property_type_description]
			,b.[subdivision]
			,b.[bedrooms_varchar]
			,b.[bedrooms_int]
			,b.[bathrooms_varchar]
			,b.[bathrooms_total]
			,b.[bathrooms_full]
			,b.[bathrooms_3_4]
			,b.[bathrooms_half]
			,b.[lot_dimensions]
			,b.[lot_size_string]
			,b.[lot_size_decimal]
			,b.[lot_size_unit]
			,b.[square_feet]
			,b.[square_feet_foundation]
			,b.[square_feet_total]
			,b.[square_feet_finished]
			,b.[square_feet_above_ground]
			,b.[square_feet_below_ground]
			,b.[garage_description]
			,b.[garage_stalls]
			,b.[year_built]
			,b.[stories]
			,b.[water_source]
			,b.[sewer_source]
			,b.[school_district]
			,b.[school_elementary]
			,b.[school_middle]
			,b.[school_senior_high]
			,b.[construction_description]
			,b.[floor_description]
			,b.[cooling_description]
			,b.[heating_description]
			,b.[basement_description]
			,b.[fireplace_description]
			,b.[interior_description]
			,b.[general_description]
			,b.[parking_description]
			,b.[exterior_description]
			,b.[roof_description]
			,b.[pool_description]
			,b.[zoning_description]
			,b.[land_description]
			,b.[green_energy_description]
			,b.[hoa_amenities]
			,b.[disabled_accessibility_description]
			,b.[design_features_description]
			,b.[legal_description]
			,b.[included_items]
			,b.[listing_number]
			,b.[has_pool]
			,b.[body_of_water]
			,b.[water_front_type]
			,b.[sold_on]
			,b.[created_at]
			,b.[updated_at]
			,b.[latitude]
			,b.[longitude]
			,b.[in_gated_community]
			,b.[checksum]
			,b.[created]
			,b.[updated]
		FROM [listings].[listings_tmp].[FMA_Snapshot_wrk] a WITH (NOLOCK)
		INNER JOIN [listings].[listings_tmp].[FMA_Daily_Ads_wrk2] b WITH (NOLOCK) ON b.snapshot_id = a.id
	END

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_import_FMA_Daily_Ads_wrk'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


