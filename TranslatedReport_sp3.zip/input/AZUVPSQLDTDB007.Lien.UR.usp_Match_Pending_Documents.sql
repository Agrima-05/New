/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Match_Pending_Documents | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- ===================================================================================================================
-- Author:		Marie Pretorius
-- Create date: 2024-07-01
-- Description:	Match Pending Documents Using legal information in order to add re_id's to be used in the merge logic
--				to improve the merged Deed to Mortgage ratio
-- ====================================================================================================================
CREATE PROCEDURE [Lien].[UR].[usp_Match_Pending_Documents] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
we need to create a code table

Marie	2024-07-019	Initial Creation

 DECLARE @ERROR VARCHAR(500)
	EXEC Lien.[UR].[usp_Match_Pending_Documents] @ERROR = @ERROR OUTPUT
******************************************************************************************************************/
--declare @ERROR VARCHAR(500) 
BEGIN TRY
	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Match_Pending_Documents'
		,N'Started'

	--
	-- Get valid Buyer name Role Types
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Name_Types]
		SELECT a.*
		INTO [lien].[tmp].[Legal_Match_Name_Types]
		FROM (
			SELECT CodeValue AS Role_Type
			FROM [Lien].[dbo].[codetable] WITH (
					NOLOCK
					,INDEX (idx_Table_value)
					)
			WHERE TableShortName = 'Deed_Buy_Role_TP'
				AND CodeValue NOT IN (
					'Trustee'
					,'Personal Representative'
					,'ORIGINAL OWNER'
					)
			
			UNION ALL
			
			SELECT CodeValue AS Role_Type
			FROM [Lien].[dbo].[codetable] WITH (
					NOLOCK
					,INDEX (idx_Table_value)
					)
			WHERE TableShortName = 'Mtg_Buy_Role_TP'
				AND CodeValue NOT IN (
					'Trustee'
					,'Personal Representative'
					,'ORIGINAL OWNER'
					)
			) a
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_Role_Type ON [lien].[tmp].[Legal_Match_Name_Types] (Role_Type)

	--
	-- Get Records for the day That does not have a ref_id
	-- 
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Deed_Mtg]
		SELECT k.doc_id
			,k.fips_code
			,k.Fips
			,k.Instrument_nbr
			,k.recording_date_d
			,k.doc_title
			,k.doc_type
			,t.Deed_Type
		INTO [lien].[tmp].[Legal_Match_Deed_Mtg]
		FROM [lien].[tmp].[reprocess_records_to_be_processed] k WITH (
				NOLOCK
				,INDEX (id_m_status)
				)
		CROSS APPLY (
			SELECT max(ur_value) AS doc_type
				,max(deed_type) AS deed_type
			FROM [Lien_DTDB].[dbo].[UR_Document_Types] t
			WHERE t.ur_value = k.doc_type
				--AND t.Delete_Date IS NULL
				AND (
					t.Delete_date IS NULL
					OR t.Delete_date > k.Recording_Date_D
					)
				AND t.deed_type IN (
					'D'
					,'G'
					,'T'
					,'U'
					)
			) t
		WHERE k.m_status_id = 1
			AND t.Doc_Type IS NOT NULL
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx ON [lien].[tmp].[Legal_Match_Deed_Mtg] (doc_id)

	--
	-- Get Candidates to Match
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Candidates]
		SELECT dm.doc_id
			,dm.fips_code
			,dm.Fips
			,d.Instrument_nbr
			,d.recording_date_d
			,d.Fmt_Doc_Number
			,CASE 
				WHEN t.deed_type = 'T'
					THEN Try_Cast(dd.Fmt_Doc_Number_Range AS BIGINT) - 2
				ELSE Try_Cast(dd.Fmt_Doc_Number_Range AS BIGINT)
				END AS Fmt_Doc_Number_Range
			,CASE 
				WHEN t.deed_type = 'T'
					THEN try_Cast(dd.Fmt_Doc_Number_Range AS BIGINT)
				ELSE Try_Cast(dd.Fmt_Doc_Number_Range AS BIGINT) + 2
				END AS Fmt_Doc_Number_Range2
			,d.FMT_Book_Page
			,dm.doc_title
			,dm.doc_type
			,dm.Deed_Type
			,ph.Ph_doc_id
			,ph.ph_cnt
			,ph.pa_ref_id
			,ph.ps_ref_id
			,ph.pl_ref_id
			,n.name_cnt
		INTO [lien].[tmp].[Legal_Match_Candidates]
		FROM [lien].[tmp].[Legal_Match_Deed_Mtg] dm WITH (
				NOLOCK
				,INDEX (idx)
				)
		INNER JOIN [Lien].[ur].[Document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.Doc_id = dm.Doc_id
		INNER JOIN [Lien_DTDB].[dbo].[UR_Document_Types] t WITH (
				NOLOCK
				,INDEX (idx_doc_type)
				) ON t.UR_Value = dm.Doc_Type
			AND (
				t.Delete_date IS NULL
				OR t.Delete_date > dm.Recording_Date_D
				)
			AND t.deed_type IN (
				'D'
				,'G'
				,'T'
				,'U'
				)
		OUTER APPLY (
			SELECT max(doc_id) AS Ph_doc_id
				,sum(1) AS ph_cnt
				,max(ph.pa_ref_id) AS pa_ref_id
				,max(ps_ref_id) AS ps_ref_id
				,max(pl_ref_id) AS pl_ref_id
			FROM [lien].[ur].[propertyHeader] ph WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					)
			WHERE ph.doc_id = dm.doc_id
				AND isnull(pa_ref_id, 0) = 0
				AND isnull(ps_ref_id, 0) = 0
				AND isnull(pl_ref_id, 0) = 0
			) ph
		OUTER APPLY (
			SELECT sum(1) AS name_cnt
			FROM [lien].[ur].[name] n
			WHERE n.doc_id = dm.doc_id
			) n
		OUTER APPLY (
			SELECT TOP 1 value AS Fmt_Doc_Number_Range
			FROM (
				SELECT value
					,ROW_NUMBER() OVER (
						PARTITION BY 0 ORDER BY (
								SELECT 0
								)
						) AS ROW4
				FROM [Lien].[UR].[string_split](d.Fmt_Doc_Number, '.')
				) a
			ORDER BY row4 DESC
			) dd
		WHERE (
				(
					ISNULL(ph.pa_ref_id, 0) = 0
					AND ISNULL(ph.ps_Ref_id, 0) = 0
					AND ISNULL(ph.pl_Ref_id, 0) = 0
					)
				)
			AND ph.PH_doc_id > 0
			AND n.name_cnt > 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [lien].[tmp].[Legal_Match_Candidates] (doc_id)

	CREATE CLUSTERED INDEX idx_fips_code_recording_date ON [lien].[tmp].[Legal_Match_Candidates] (
		fips_code
		,recording_date_d
		)

	--
	-- Create Name file for Candidates
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Candidates_Names]
		SELECT DISTINCT n.doc_id
			,n.Name_id
			,n.sequence_number
			,n.name_identifier
			,try_cast(substring(n.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
			,n.first_name
			,n.middle_name
			,n.suffix
			,try_cast(substring(n.role_type, 1, 100) AS VARCHAR(100)) AS role_type
		INTO [lien].[tmp].[Legal_Match_Candidates_Names]
		FROM [lien].[tmp].[Legal_Match_Candidates] c WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		INNER JOIN [lien].[ur].[name] n WITH (
				NOLOCK
				,INDEX (doc_id)
				) ON n.doc_id = c.doc_id
		WHERE n.role_type IN (
				SELECT Role_type
				FROM [lien].[tmp].[Legal_Match_Name_Types] WITH (
						NOLOCK
						,INDEX (idx_Role_Type)
						)
				)
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX IDX_Doc_id ON [lien].[tmp].[Legal_Match_Candidates_Names] (Doc_id)

	--
	-- Create PropertyHeader file for Candidates
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Candidates_PropertyHeader]
		SELECT DISTINCT ph.doc_id
			,ph.property_id_sequence_number
			,ph.legal_desc_address
			,ph.legal_desc_address_city
			,ph.legal_desc_address_state
			,ph.legal_desc_address_zip
			,ph.legal_desc_apn
			,ph.legal_desc_map_unit_low
			,ph._unit
			,ph.legal_desc_map_unit_high
			,ph.legal_desc_map_lot_low
			,ph._lot
			,ph.legal_desc_map_lot_high
			,ph.legal_desc_map_block
			,ph.legal_desc_map_building
			,ph.legal_desc_map_sublot
			,ph.legal_desc_map_plat_subcode
			,ph.legal_desc_map_plat_name
			,ph.legal_desc_map_plat_number
			,ph.legal_desc_map_plat_condo_id
			,ph.legal_desc_map_plat_book
			,ph.legal_desc_map_plat_page
			,ph.legal_desc_str_section
			,ph.legal_desc_str_township
			,ph.legal_desc_str_range
			,ph.property_ref_id
			,ph.Multi_APN
		INTO [lien].[tmp].[Legal_Match_Candidates_PropertyHeader]
		FROM [lien].[tmp].[Legal_Match_Candidates] c WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		INNER JOIN [lien].[ur].[PropertyHeader] ph WITH (
				NOLOCK
				,INDEX (ix_doc_id)
				) ON ph.doc_id = c.doc_id
		WHERE ISNULL(ph.pa_ref_id, 0) = 0
			AND ISNULL(ph.ps_ref_id, 0) = 0
			AND ISNULL(ph.pl_ref_id, 0) = 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX IDX_Doc_id ON [lien].[tmp].[Legal_Match_Candidates_PropertyHeader] (Doc_id)

	--
	-- Get Potential Matches for candidates
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Potential_Matches]
		SELECT DISTINCT 'Candicate' AS _candidate
			,c.fips_code AS C_Fips_code
			,c.doc_id AS C_doc_id
			,c.recording_date_d AS C_recording_date_d
			,c.Fmt_Doc_Number AS C_Fmt_Doc_Number
			,c.Fmt_Doc_Number_Range
			,c.Fmt_Doc_Number_Range2
			,c.doc_type AS C_doc_type
			,c.Deed_Type AS C_Deed_Type
			,'Deed_Mtg' AS _Deed_Mtg
			,d.fips_code
			,d.doc_id
			,d.recording_date_d
			,d.Fmt_Doc_Number
			,Try_cast(dd.fmt_doc_number_Range AS BIGINT) AS fmt_doc_number_Range_mtg
			,d.doc_type
			,t.Deed_Type
		INTO [lien].[tmp].[Legal_Match_Potential_Matches]
		FROM [lien].[tmp].[Legal_Match_Candidates] c WITH (
				NOLOCK
				,INDEX (idx_fips_code_recording_date)
				)
		INNER JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (idx_fips_code_recording_date_d)
				) ON d.fips_code = c.fips_code
			AND d.recording_date_d = c.recording_date_d
		CROSS APPLY (
			SELECT max(ur_value) AS doc_type
				,max(deed_type) AS deed_type
			FROM [Lien_DTDB].[dbo].[UR_Document_Types] t WITH (
					NOLOCK
					,INDEX (idx_doc_type)
					)
			WHERE t.ur_value = d.doc_type
				AND t.Delete_Date IS NULL
				AND (
					t.Delete_date IS NULL
					OR t.Delete_date > d.Recording_Date_D
					)
				AND ISNULL(t.deed_type, '') NOT IN (
					'Q'
					,'Z'
					)
			) t
		OUTER APPLY (
			SELECT TOP 1 CASE 
					WHEN isnumeric(value) = 1
						THEN value
					ELSE NULL
					END AS Fmt_Doc_Number_Range
			FROM (
				SELECT value
					,ROW_NUMBER() OVER (
						PARTITION BY 0 ORDER BY (
								SELECT 0
								)
						) AS ROW4
				FROM [Lien].[UR].[string_split](d.Fmt_Doc_Number, '.')
				) a
			ORDER BY row4 DESC
			) dd
		WHERE c.doc_id <> d.Doc_id
			AND Try_cast(dd.fmt_doc_number_Range AS BIGINT) BETWEEN c.Fmt_Doc_Number_Range
				AND c.fmt_doc_number_Range2
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [lien].[tmp].[Legal_Match_Potential_Matches] (c_doc_id)

	--
	-- Confirm on Name
	--
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Match_Pending_Documents_Name]
		SELECT try_cast(substring(n.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
			,n.doc_id
			,try_cast(substring(n.Role_type, 1, 200) AS VARCHAR(200)) AS Role_type
		INTO [Lien].[tmp].[usp_Match_Pending_Documents_Name]
		FROM [lien].[ur].[name] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		WHERE n.doc_id IN (
				SELECT doc_id
				FROM [lien].[tmp].[Legal_Match_Potential_Matches]
				)

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien].[tmp].[usp_Match_Pending_Documents_Name] (doc_id)

	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Name_Matched]
		SELECT DISTINCT p.*
			,cn.*
		INTO [lien].[tmp].[Legal_Match_Name_Matched]
		FROM [lien].[tmp].[Legal_Match_Potential_Matches] p WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		CROSS APPLY (
			SELECT TOP 1 try_cast(substring(cn.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,cn.first_name
				,cn.middle_name
				,cn.suffix
			FROM [lien].[tmp].[Legal_Match_Candidates_Names] cn WITH (
					NOLOCK
					,INDEX (IDX_Doc_id)
					)
			CROSS APPLY (
				SELECT TOP 1 n.last_company_name
					,n.doc_id
				FROM [Lien].[tmp].[usp_Match_Pending_Documents_Name] n WITH (
						NOLOCK
						,INDEX (idx_doc_id)
						)
				WHERE n.doc_id = p.doc_id
					AND n.role_type IN (
						SELECT Role_type
						FROM [lien].[tmp].[Legal_Match_Name_Types] WITH (
								NOLOCK
								,INDEX (idx_Role_Type)
								)
						)
					AND Substring(cn.last_company_name, 1, 4) = Substring(n.last_company_name, 1, 4)
				) Nc
			WHERE p.C_doc_id = cn.doc_id
			) cn
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_doc_id ON [Lien].[tmp].[Legal_Match_Name_Matched] (doc_id)

	-- select * into lien_dtdb.bug.Legal_Match_Name_Matched_20241025 from lien.tmp.Legal_Match_Name_Matched
	-- select * into lien_dtdb.bug.Legal_Match_Candidates_PropertyHeader_20241025 from  lien.tmp.Legal_Match_Candidates_PropertyHeader
	-- select * into lien_Dtdb.bug.Legal_Match_Property_Match_20241025 from lien.tmp.Legal_Match_Property_Match
	--  
	--
	-- Confirm on Legal Elements
	--
	DROP TABLE

	IF EXISTS [lien].[tmp].[Legal_Match_Property_Match]
		SELECT DISTINCT m._candidate
			,m.C_Fips_code
			,m.C_doc_id
			,m.C_recording_date_d
			,m.C_Fmt_Doc_Number
			,m.C_doc_type
			,m.C_Deed_Type
			,m._Deed_Mtg
			,m.doc_id
			,m.Fmt_Doc_Number
			,m.doc_type
			,m.Deed_Type
			,m.last_company_name
			,'Match_Fields' AS _Match_Fields
			,cph.Prop_doc_id
			,cph.Prop_Property_id_sequence_number
			,'L1' AS _Grp1
			,cph.CPH_legal_desc_apn
			,cph.legal_desc_apn
			,'L2' AS _Grp2
			,cph.cph_legal_desc_address
			,cph.cph_legal_desc_address_city
			,cph.legal_desc_address
			,cph.legal_desc_address_city
			,'L3' AS _Grp3
			,cph.cph_legal_desc_map_plat_book
			,cph.cph_legal_desc_map_plat_page
			,cph.cph_legal_desc_map_lot_low
			,cph.cph_legal_desc_map_block
			,cph.legal_desc_map_plat_book
			,cph.legal_desc_map_plat_page
			,cph.legal_desc_map_block
			,cph.legal_desc_map_lot_low
			,'L4' AS _Grp4
			,cph.cph_legal_desc_map_plat_name
			,cph.legal_desc_map_plat_name
			,cph.cph_legal_desc_map_unit_low
			,cph.legal_desc_map_unit_low
			,'L5' AS _Grp5
			,cph.cph_legal_desc_map_plat_name AS cph_legal_desc_map_plat_name5
			,cph.legal_desc_map_plat_name AS legal_desc_map_plat_name5
			,'L6' AS _Grp6
			,cph.Ref_id
			,cph.property_ref_id
			,CASE 
				WHEN ISNULL(cph.legal_desc_apn, '') = ISNULL(cph.cph_legal_desc_apn, '')
					AND ISNULL(cph.legal_desc_apn, '') > ''
					THEN 'L001'
				WHEN ISNULL(cph.legal_desc_address, '') = ISNULL(cph.cph_legal_desc_address, '')
					AND isnull(cph.legal_desc_address_city, '') = isnull(cph.cph_legal_desc_address_city, '')
					AND ISNULL(cph.legal_desc_address, '') > ''
					AND ISNULL(cph.legal_desc_address_city, '') > ''
					THEN 'L002'
				WHEN m.c_fips_code = '42003'
					AND ISNULL(cph.legal_desc_address, '') = ISNULL(cph.cph_legal_desc_address, '')
					--AND isnull(cph.legal_desc_address_city, '') = isnull(cph.cph_legal_desc_address_city, '')
					AND ISNULL(cph.legal_desc_address, '') > ''
					--AND ISNULL(cph.legal_desc_address_city, '') > ''
					THEN 'L002'
				WHEN isnull(cph.legal_desc_map_plat_book, '') = isnull(cph.cph_legal_desc_map_plat_book, '')
					AND isnull(cph.legal_desc_map_plat_page, '') = isnull(cph.cph_legal_desc_map_plat_page, '')
					AND isnull(cph.legal_desc_map_lot_low, '') = isnull(cph.cph_legal_desc_map_lot_low, '')
					AND isnull(cph.legal_desc_map_block, '') = isnull(cph.cph_legal_desc_map_block, '')
					AND isnull(cph.legal_desc_map_plat_book, '') > ''
					AND isnull(cph.legal_desc_map_plat_page, '') > ''
					AND isnull(cph.legal_desc_map_lot_low, '') > ''
					AND isnull(cph.legal_desc_map_block, '') > ''
					--AND ISNULL(cph.legal_desc_apn, '') = ''
					AND ISNULL(cph.cph_legal_desc_apn, '') = ''
					--AND ISNULL(cph.legal_desc_address, '') = ''
					AND ISNULL(cph.cph_legal_desc_address, '') = ''
					--AND isnull(cph.legal_desc_address_city, '') = ''
					AND isnull(cph.cph_legal_desc_address_city, '') = ''
					THEN 'L003'
				WHEN isnull(cph.legal_desc_map_plat_name, '') = isnull(cph.cph_legal_desc_map_plat_name, '')
					AND isnull(cph.legal_desc_map_unit_low, '') = isnull(cph.cph_legal_desc_map_unit_low, '')
					AND isnull(cph.legal_desc_map_plat_name, '') > ''
					AND isnull(cph.legal_desc_map_unit_low, '') > ''
					--AND ISNULL(cph.legal_desc_apn, '') = ''
					AND ISNULL(cph.cph_legal_desc_apn, '') = ''
					--AND ISNULL(cph.legal_desc_address, '') = ''
					AND ISNULL(cph.cph_legal_desc_address, '') = ''
					--AND isnull(cph.legal_desc_address_city, '') = ''
					AND isnull(cph.cph_legal_desc_address_city, '') = ''
					THEN 'L004'
				WHEN isnull(cph.legal_desc_map_plat_name, '') = isnull(cph.cph_legal_desc_map_plat_name, '')
					AND isnull(cph.legal_desc_map_plat_name, '') > ''
					AND isnull(cph.legal_desc_map_unit_low, '') = ''
					--AND ISNULL(cph.legal_desc_apn, '') = ''
					AND ISNULL(cph.cph_legal_desc_apn, '') = ''
					--AND ISNULL(cph.legal_desc_address, '') = ''
					AND ISNULL(cph.cph_legal_desc_address, '') = ''
					AND isnull(cph.legal_desc_address_city, '') = ''
					AND isnull(cph.cph_legal_desc_address_city, '') = ''
					THEN 'L005'
						--WHEN ISNULL(cph.property_ref_id, 0) = ISNULL(cph.cph_property_Ref_id, 0)
						--	AND ISNULL(cph.property_ref_id, 0) > 0
						--	AND ISNULL(cph.legal_desc_apn, '') = ''
						--	AND ISNULL(cph.cph_legal_desc_apn, '') = ''
						--	AND ISNULL(cph.legal_desc_address, '') = ''
						--	AND ISNULL(cph.cph_legal_desc_address, '') = ''
						--	AND isnull(cph.legal_desc_address_city, '') = ''
						--	AND isnull(cph.cph_legal_desc_address_city, '') = ''
						--	THEN 'L006'
				END AS Match_Code
		INTO [lien].[tmp].[Legal_Match_Property_Match]
		-- select * 
		FROM [lien].[tmp].[Legal_Match_Name_Matched] m WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		CROSS APPLY (
			SELECT cph.Doc_id AS prop_doc_id
				,cph.Property_id_sequence_number AS Prop_Property_id_sequence_number
				,cph.legal_desc_address AS cph_legal_desc_address
				,cph.legal_desc_address_city AS cph_legal_desc_address_city
				,cph.legal_desc_apn AS cph_legal_desc_apn
				,cph.legal_desc_map_unit_low AS cph_legal_desc_map_unit_low
				,cph.legal_desc_map_lot_low AS cph_legal_desc_map_lot_low
				,cph.legal_desc_map_block AS cph_legal_desc_map_block
				,cph.legal_desc_map_plat_name AS cph_legal_desc_map_plat_name
				,cph.legal_desc_map_plat_book AS cph_legal_desc_map_plat_book
				,cph.legal_desc_map_plat_page AS cph_legal_desc_map_plat_page
				,cph.legal_desc_str_section AS cph_legal_desc_str_section
				,cph.legal_desc_str_township AS cph_legal_desc_str_township
				,cph.legal_desc_str_range AS cph_legal_desc_str_range
				,cph.property_ref_id AS cph_property_ref_id
				,'ph*' AS _phall
				,ph.*
			FROM [lien].[tmp].[Legal_Match_Candidates_PropertyHeader] cph WITH (
					NOLOCK
					,INDEX (IDX_Doc_id)
					)
			CROSS APPLY (
				SELECT ph.doc_id
					,ph.legal_desc_address
					,ph.legal_desc_address_city
					,ph.legal_desc_apn
					,ph.legal_desc_map_unit_low
					,ph.legal_desc_map_lot_low
					,ph.legal_desc_map_block
					,ph.legal_desc_map_plat_name
					,ph.legal_desc_map_plat_book
					,ph.legal_desc_map_plat_page
					,ph.legal_desc_str_section
					,ph.legal_desc_str_township
					,ph.legal_desc_str_range
					,ph.property_ref_id
					,CASE 
						WHEN isnull(ph.Pa_ref_id, 0) > 0
							THEN ph.Pa_ref_id
						WHEN ISNULL(ph.Ps_ref_id, 0) > 0
							THEN ph.Ps_ref_id
						WHEN ISNULL(ph.Property_ref_id, 0) > 0
							THEN ph.Property_ref_id
						ELSE ph.Pl_ref_id
						END AS Ref_id
				FROM [lien].[ur].[propertyheader] ph WITH (
						NOLOCK
						,INDEX (ix_doc_id)
						)
				WHERE ph.doc_id = m.doc_id
					AND (
						Isnull(ph.Pa_Ref_id, 0) > 0
						OR ISNULL(ph.Ps_Ref_id, 0) > 0
						OR ISNULL(ph.Property_ref_id, 0) > 0
						)
				) ph
			WHERE cph.doc_id = m.C_doc_id
				AND (
					(
						ISNULL(ph.legal_desc_apn, '') = ISNULL(cph.legal_desc_apn, '')
						AND ISNULL(ph.legal_desc_apn, '') > ''
						)
					OR (
						(
							ISNULL(ph.legal_desc_address, '') = ISNULL(cph.legal_desc_address, '')
							AND isnull(ph.legal_desc_address_city, '') = isnull(cph.legal_desc_address_city, '')
							AND ISNULL(ph.legal_desc_address, '') > ''
							AND ISNULL(ph.legal_desc_address_city, '') > ''
							)
						OR (
							C_Fips_code = '42003'
							AND ISNULL(ph.legal_desc_address, '') = ISNULL(cph.legal_desc_address, '')
							--AND isnull(ph.legal_desc_address_city, '') = isnull(cph.legal_desc_address_city, '')
							AND ISNULL(ph.legal_desc_address, '') > ''
							--AND ISNULL(ph.legal_desc_address_city, '') > '')
							)
						)
					OR (
						isnull(ph.legal_desc_map_plat_book, '') = isnull(cph.legal_desc_map_plat_book, '')
						AND isnull(ph.legal_desc_map_plat_page, '') = isnull(cph.legal_desc_map_plat_page, '')
						AND isnull(ph.legal_desc_map_lot_low, '') = isnull(cph.legal_desc_map_lot_low, '')
						AND isnull(ph.legal_desc_map_block, '') = isnull(cph.legal_desc_map_block, '')
						AND isnull(ph.legal_desc_map_plat_book, '') > ''
						AND isnull(ph.legal_desc_map_plat_page, '') > ''
						AND isnull(ph.legal_desc_map_lot_low, '') > ''
						AND isnull(ph.legal_desc_map_block, '') > ''
						--
						AND ISNULL(cph.legal_desc_apn, '') = ''
						AND ISNULL(cph.legal_desc_address, '') = ''
						AND isnull(cph.legal_desc_address_city, '') = ''
						)
					OR (
						isnull(ph.legal_desc_map_plat_name, '') = isnull(cph.legal_desc_map_plat_name, '')
						AND isnull(ph.legal_desc_map_unit_low, '') = isnull(cph.legal_desc_map_unit_low, '')
						AND isnull(ph.legal_desc_map_plat_name, '') > ''
						AND isnull(ph.legal_desc_map_unit_low, '') > ''
						--
						AND ISNULL(cph.legal_desc_apn, '') = ''
						AND ISNULL(cph.legal_desc_address, '') = ''
						AND isnull(cph.legal_desc_address_city, '') = ''
						)
					OR (
						isnull(ph.legal_desc_map_plat_name, '') = isnull(cph.legal_desc_map_plat_name, '')
						AND isnull(ph.legal_desc_map_plat_name, '') > ''
						AND isnull(ph.legal_desc_map_unit_low, '') = ''
						AND isnull(cph.legal_desc_map_plat_name, '') = ''
						--
						AND ISNULL(cph.legal_desc_apn, '') = ''
						AND ISNULL(cph.legal_desc_address, '') = ''
						AND isnull(cph.legal_desc_address_city, '') = ''
						)
					--OR (
					--	ISNULL(ph.property_ref_id, 0) = ISNULL(cph.property_ref_id, 0)
					--	AND ISNULL(ph.property_ref_id, 0) > 0
					--	--
					--	AND ISNULL(cph.legal_desc_apn, '') = ''
					--	AND ISNULL(cph.legal_desc_address, '') = ''
					--	AND isnull(cph.legal_desc_address_city, '') = ''
					--	)
					)
			) cph
		OUTER APPLY (
			SELECT count(1) AS assr_cnt
			FROM [assr].[dbo].[assr]
			WHERE ref_id = cph.Ref_id
			) ar
		WHERE ar.assr_cnt > 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [lien].[tmp].[Legal_Match_Property_Match] (C_doc_id)

	CREATE INDEX ix_doc_id_seq ON [lien].[tmp].[Legal_Match_Property_Match] (
		C_doc_id
		,Prop_Property_id_sequence_number
		)

	DECLARE @date VARCHAR(20) = replace(replace(replace(replace(cast(getdate() AS DATETIME2), '-', ''), ' ', ''), ':', ''), '.', '')
	DECLARE @sql VARCHAR(max) = N'
	SELECT *
	INTO lien.tmp.Legal_Match_Property_Match_' + @date + '
	FROM lien.tmp.Legal_Match_Property_Match
	'

	--Select @sql as N'@sql'
	EXEC (@sql)

	--SELECT  m.C_Fips_code
	--	,m.C_doc_id
	--	,m.C_recording_date_d
	--	,m.C_Fmt_Doc_Number
	--	,m.Ref_id
	--	--,m.Ps_ref_id
	--	,m.Match_code
	--	,'propertyheader' AS _propertyheader
	--	,ph.Doc_id
	--	,ph.Property_id_sequence_number
	--	,ph.Pa_ref_id
	--	,ph.Ps_ref_id
	--	,ph.pl_fips
	--	,ph.pl_ref_id
	--	,ph.pl_Match_code
	UPDATE [Lien].[UR].[ph]
	SET ph.pl_fips = Cast(m.C_Fips_code AS INT)
		,ph.pl_ref_id = nullif(m.Ref_id, 0)
		,ph.pl_Match_code = nullif(m.Match_code, '')
		,ph.updatedate = getdate()
	FROM [lien].[tmp].[Legal_Match_Property_Match] m WITH (
			NOLOCK
			,INDEX (ix_doc_id_seq)
			)
	INNER JOIN [lien].[ur].[propertyheader] ph WITH (
			NOLOCK
			,INDEX (ix_doc_id_seq)
			) ON ph.doc_id = m.c_doc_id
		AND ph.Property_id_sequence_number = m.Prop_Property_id_sequence_number
	OUTER APPLY (
		SELECT ref_id
		FROM [assr].[dbo].[assr] ar
		WHERE ar.ref_id = m.Ref_id
		) b
	WHERE b.ref_id IS NOT NULL

	-- select * from lien.tmp.Legal_Match_Property_Match
	/*============================================
  Special matching for Allegheny, PA 42003
  ===========================================*/
	--
	-- Get Candidates to Match - 42003
	--
	DROP TABLE

	IF EXISTS [Lien].[tmp].[Legal_Match_Candidates_42003]
		SELECT dm.doc_id
			,dm.fips_code
			,dm.Fips
			,d.Instrument_nbr
			,d.recording_date_d
			,dm.doc_title
			,dm.doc_type
			,dm.Deed_Type
			,ph.Ph_doc_id
			,ph.ph_cnt
			,ph.pa_ref_id
			,ph.ps_ref_id
			,ph.pl_ref_id
			,n.name_cnt
		INTO [Lien].[tmp].[Legal_Match_Candidates_42003]
		FROM [lien].[tmp].[Legal_Match_Deed_Mtg] dm WITH (
				NOLOCK
				,INDEX (idx)
				)
		INNER JOIN [Lien].[ur].[Document] d WITH (
				NOLOCK
				,INDEX (PK_DOCUMENT)
				) ON d.Doc_id = dm.Doc_id
		INNER JOIN [Lien_DTDB].[dbo].[UR_Document_Types] t WITH (
				NOLOCK
				,INDEX (idx_doc_type)
				) ON t.UR_Value = dm.Doc_Type
			AND (
				t.Delete_date IS NULL
				OR t.Delete_date > dm.Recording_Date_D
				)
			AND t.deed_type IN (
				'D'
				,'G'
				,'T'
				,'U'
				)
		OUTER APPLY (
			SELECT max(doc_id) AS Ph_doc_id
				,sum(1) AS ph_cnt
				,max(ph.pa_ref_id) AS pa_ref_id
				,max(ps_ref_id) AS ps_ref_id
				,max(pl_ref_id) AS pl_ref_id
			FROM [lien].[ur].[propertyHeader] ph WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					)
			WHERE ph.doc_id = dm.doc_id
				AND isnull(pa_ref_id, 0) = 0
				AND isnull(ps_ref_id, 0) = 0
				AND isnull(pl_ref_id, 0) = 0
			) ph
		OUTER APPLY (
			SELECT sum(1) AS name_cnt
			FROM [lien].[ur].[name] n
			WHERE n.doc_id = dm.doc_id
			) n
		WHERE (
				(
					ISNULL(ph.pa_ref_id, 0) = 0
					AND ISNULL(ph.ps_Ref_id, 0) = 0
					AND ISNULL(ph.pl_ref_id, 0) = 0
					)
				)
			AND ph.PH_doc_id > 0
			AND n.name_cnt > 0
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [lien].[tmp].[Legal_Match_Candidates_42003] (doc_id)

	-- select * from lien.tmp.Legal_Match_Candidates_42003 -- 103,650
	--
	-- Get Property header and Names for match Candidates
	--
	DROP TABLE

	IF EXISTS [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003]
		SELECT ph.doc_id
			,ph.property_id_sequence_number
			,c.recording_date_d
			,c.Deed_Type
			,ph.HouseNumber
			,ph.Street_Name
			,ph.Street_Type
			,ph.Post_Direction
			,ph.Unit_Type
			,ph.Unit
			,ph.City
			,ph.STATE
			,ph.Zip
			,ph.Plus4
			,n.name_id
			,n.sequence_number
			,n.last_company_name
			,n.first_name
			,n.middle_name
			,n.suffix
		---
		INTO [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003]
		FROM [Lien].[tmp].[Legal_Match_Candidates_42003] c WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		INNER JOIN [lien].[ur].[property] p WITH (
				NOLOCK
				,INDEX (ix_Doc_idSeq)
				) ON p.doc_id = c.doc_id
		INNER JOIN [lien].[ur].[PropertyHeader] ph WITH (
				NOLOCK
				,INDEX (ix_doc_id_seq)
				) ON ph.doc_id = p.doc_id
			AND ph.property_id_sequence_number = p.property_id_sequence_number
		CROSS APPLY (
			SELECT n.Name_id
				,n.sequence_number
				,n.name_identifier
				,try_cast(substring(n.last_company_name, 1, 200) AS VARCHAR(200)) AS last_company_name
				,n.first_name
				,n.middle_name
				,n.suffix
			FROM [lien].[ur].[name] n WITH (
					NOLOCK
					,INDEX (doc_id)
					)
			WHERE n.doc_id = c.doc_id
				AND n.role_type IN (
					SELECT Role_type
					FROM [Lien].[tmp].[Legal_Match_Name_Types] WITH (
							NOLOCK
							,INDEX (idx_Role_Type)
							)
					)
			) n
		WHERE ISNULL(ph.pa_ref_id, 0) = 0
			AND ISNULL(ph.ps_ref_id, 0) = 0
			AND ISNULL(ph.pl_ref_id, 0) = 0
			AND ph.Multi_Apn IS NULL
		OPTION (
			RECOMPILE
			,MAXDOP 8
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX IDX_Doc_id ON [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003] (Doc_id)

	CREATE INDEX idx_date_name ON [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003] (
		deed_type
		,recording_date_d
		,last_company_name
		,first_name
		,middle_name
		,suffix
		)

	--	select * from Lien.tmp.Legal_Match_Candidates_PropertyHeader_42003
	--
	-- extract all names for the county for doc_types
	--
	DROP TABLE

	IF EXISTS [Lien].[tmp].[Legal_Match_Dates_names_42003]
		SELECT n.doc_id
			,d.recording_date_d
			,d.doc_type
			,dt.*
			,cast(n.last_company_name AS VARCHAR(200)) AS last_company_name
			,n.first_name
			,n.middle_name
			,n.suffix
		INTO [Lien].[tmp].[Legal_Match_Dates_names_42003]
		FROM [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (ix_fips_doc)
				)
		INNER JOIN [lien].[ur].[name] n WITH (
				NOLOCK
				,INDEX (doc_id)
				) ON n.doc_id = d.doc_id
		CROSS APPLY (
			SELECT ur_value
				,deed_type
			FROM [Lien_DTDB].[dbo].[UR_Document_Types] t
			WHERE t.ur_value = d.Doc_type
				AND (
					t.Delete_date IS NULL
					OR t.Delete_date > d.Recording_Date_D
					)
				AND t.deed_type IN (
					'T'
					,'G'
					,'U'
					)
			) dt
		WHERE d.fips_code = '42003'
			AND n.doc_id = d.doc_id
			AND n.Role_type IN (
				SELECT role_type
				FROM [Lien].[tmp].[Legal_Match_Name_Types]
				)

	CREATE INDEX idx_date_name ON [Lien].[tmp].[Legal_Match_Dates_names_42003] (
		deed_type
		,recording_date_d
		,last_company_name
		,first_name
		,middle_name
		,suffix
		)

	-- select * from Lien.tmp.Legal_Match_Dates_names_42003
	--
	-- Do the Match on Recording Date and Name
	--
	DROP TABLE

	IF EXISTS [Lien].[tmp].[Legal_Match_Candidates_Matched_42003]
		SELECT DISTINCT a.c_doc_id
			,a.c_property_id_sequence_number
			,a.c_recording_date_d
			,a.c_Deed_Type
			--,a.Name_id
			--,a.sequence_number
			--,a.c_last_company_name
			--,a.c_first_name
			--,a.c_middle_name
			--,a.c_suffix
			,a._linked
			,a.Name_doc_id
			,a.recording_date_d
			--,a.doc_type
			,a.deed_type
			--,a.last_company_name
			--,a.first_name
			--,a.middle_name
			--,a.suffix
			,a.ph_doc_id
			,a.ph_property_id_sequence_number
			,a.Multi_apn
			,'Borrowed' AS _borrowed
			,Coalesce(a.pa_ref_id, a.ps_ref_id, a.pl_ref_id, a.property_ref_id) AS New_ref_id
			,'L010' AS Match_code
			,42003 AS pl_fips
		INTO [Lien].[tmp].[Legal_Match_Candidates_Matched_42003]
		FROM (
			SELECT m.doc_id AS c_doc_id
				,m.property_id_sequence_number AS c_property_id_sequence_number
				,m.recording_date_d AS c_recording_date_d
				,m.Deed_Type AS c_Deed_Type
				,m.Name_id
				,m.sequence_number
				,m.last_company_name AS c_last_company_name
				,m.first_name AS c_first_name
				,m.middle_name AS c_middle_name
				,m.suffix AS c_suffix
				,'linked' AS _linked
				,n.doc_id AS Name_doc_id
				,n.recording_date_d
				,n.doc_type
				,n.deed_type
				,n.last_company_name
				,n.first_name
				,n.middle_name
				,n.suffix
				,ph.doc_id AS ph_doc_id
				,ph.property_id_sequence_number AS ph_property_id_sequence_number
				,ph.Multi_apn
				,ph.pa_ref_id
				,ph.ps_ref_id
				,ph.pl_ref_id
				,ph.property_ref_id
			FROM [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003] m WITH (
					NOLOCK
					,INDEX (idx_date_name)
					)
			CROSS APPLY (
				SELECT TOP 1 n.doc_id
					,n.recording_date_d
					,n.doc_type
					,n.deed_type
					,n.last_company_name
					,n.first_name
					,n.middle_name
					,n.suffix
				FROM [Lien].[tmp].[Legal_Match_Dates_names_42003] n WITH (
						NOLOCK
						,INDEX (idx_date_name)
						)
				WHERE n.deed_type = 'T'
					AND n.recording_date_d = m.Recording_date_d
					AND ISNULL(n.last_company_name, '') = ISNULL(m.last_company_name, '')
					AND ISNULL(n.first_name, '') = ISNULL(m.first_name, '')
					AND ISNULL(n.middle_name, '') = ISNULL(m.middle_name, '')
					AND ISNULL(n.suffix, '') = ISNULL(m.suffix, '')
				) n
			INNER JOIN [lien].[ur].[PropertyHeader] ph WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					) ON ph.doc_id = n.doc_id
				AND multi_apn IS NULL
			WHERE m.deed_type IN (
					'G'
					,'U'
					)
			
			UNION ALL
			
			SELECT m.doc_id
				,m.property_id_sequence_number
				,m.recording_date_d AS c_recording_date_d
				,m.Deed_Type AS c_Deed_Type
				,m.Name_id
				,m.sequence_number
				,m.last_company_name AS c_last_company_name
				,m.first_name AS c_first_name
				,m.middle_name AS c_middle_name
				,m.suffix AS c_suffix
				,'linked' AS _linked
				,n.doc_id AS Name_doc_id
				,n.recording_date_d
				,n.doc_type
				,n.deed_type
				,n.last_company_name
				,n.first_name
				,n.middle_name
				,n.suffix
				,ph.doc_id AS ph_doc_id
				,ph.property_id_sequence_number AS ph_property_id_sequence_number
				,ph.Multi_apn
				,ph.pa_ref_id
				,ph.ps_ref_id
				,ph.pl_ref_id
				,ph.property_ref_id
			FROM [Lien].[tmp].[Legal_Match_Candidates_PropertyHeader_42003] m WITH (
					NOLOCK
					,INDEX (idx_date_name)
					)
			CROSS APPLY (
				SELECT TOP 1 n.doc_id
					,n.recording_date_d
					,n.doc_type
					,n.deed_type
					,n.last_company_name
					,n.first_name
					,n.middle_name
					,n.suffix
				FROM [Lien].[tmp].[Legal_Match_Dates_names_42003] n WITH (
						NOLOCK
						,INDEX (idx_date_name)
						)
				WHERE n.deed_type IN (
						'G'
						,'U'
						)
					AND n.recording_date_d = m.Recording_date_d
					AND isnull(n.last_company_name, '') = isnull(m.last_company_name, '')
					AND isnull(n.first_name, '') = isnull(m.first_name, '')
					AND isnull(n.middle_name, '') = isnull(m.middle_name, '')
					AND isnull(n.suffix, '') = isnull(m.suffix, '')
				) n
			INNER JOIN [lien].[ur].[PropertyHeader] ph WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					) ON ph.doc_id = n.doc_id
				AND multi_apn IS NULL
			WHERE m.deed_type IN ('t')
			) a
		WHERE isnull(a.pa_ref_id, 0) > 0
			OR isnull(a.ps_ref_id, 0) > 0
			OR isnull(a.pl_ref_id, 0) > 0
			OR isnull(a.property_ref_id, 0) > 0

	CREATE INDEX idx_doc_id ON [Lien].[tmp].[Legal_Match_Candidates_Matched_42003] (c_doc_id)

	-- select * from Lien.tmp.Legal_Match_Candidates_Matched_42003 order by c_doc_id
	BEGIN TRANSACTION

	--select a.c_doc_id, a.c_property_id_sequence_number
	--,ph.doc_id, ph.property_id_sequence_number
	--,ph.property_ref_id
	--,ph.pa_ref_id, ph.Pa_match_code, ph.pa_fips
	--,ph.ps_ref_id, ph.Ps_match_code, ph.ps_fips
	--,ph.pl_ref_id, ph.Pl_match_code, ph.pl_fips
	--,a.New_ref_id, a.Match_code, a.pl_fips
	UPDATE [Lien].[UR].[ph]
	SET ph.pl_ref_id = a.New_ref_id
		,ph.Pl_Match_code = a.Match_code
		,ph.Pl_fips = a.pl_fips
	-- select a.* , ph.Pa_ref_id, ph.pa_match_code, ph.Ps_ref_id, ph.ps_match_code ,ph.Pl_ref_id, ph.pl_match_code
	FROM [Lien].[tmp].[Legal_Match_Candidates_Matched_42003] a
	INNER JOIN [lien].[ur].[PropertyHeader] ph WITH (
			NOLOCK
			,INDEX (ix_doc_id_seq)
			) ON ph.doc_id = a.c_doc_id
		AND ph.property_id_sequence_number = a.c_property_id_sequence_number
	OUTER APPLY (
		SELECT ref_id
		FROM [assr].[dbo].[assr] ar
		WHERE ar.ref_id = a.New_ref_id
		) b
	WHERE isnull(a.New_ref_id, 0) > 0
		AND b.ref_id IS NOT NULL

	COMMIT

	------------------------------------------------------------------------
	/*------------------------------------------------------------------------------------------------------------
	  Lien_fix--
	  Run the Lien fix to delete the records where we assigned the ref-Id's on the property header from the db
	  and re-process it
	--------------------------------------------------------------------------------------------------------------*/
	DROP TABLE

	IF EXISTS [Lien].[tmp].[usp_Match_Pending_Documents_doc]
		SELECT doc_id
		INTO [Lien].[tmp].[usp_Match_Pending_Documents_doc]
		FROM [lien].[ur].[document](NOLOCK)
		WHERE doc_id IN (
				SELECT c_doc_id
				FROM [lien].[tmp].[Legal_Match_Property_Match]
				
				UNION ALL
				
				SELECT c_Doc_id
				FROM [Lien].[tmp].[Legal_Match_Candidates_Matched_42003] a
				WHERE isnull(a.New_ref_id, 0) > 0
				)
			AND m_status_id = 1

	INSERT INTO [lien].[UR].[Fix_Request] (
		[doc_id]
		,[m_status_id]
		,[del_PROPERTY_APN_MATCH]
		,[del_PROPERTY_Std_Address]
		,[del_PROPERTYHeader]
		,[del_REFERENCE_Match]
		,[del_NAME_STD_ADDRESS]
		,[update_status]
		,[process_date]
		,[set_m_status_id_to]
		,[reprocess_flag]
		,[reprocess_reason]
		)
	--,[action]
	SELECT d.[doc_id]
		,d.[m_status_id]
		,0 AS [del_PROPERTY_APN_MATCH]
		,0 AS [del_PROPERTY_Std_Address]
		,0 AS [del_PROPERTYHeader]
		,0 AS [del_REFERENCE_Match]
		,0 AS [del_NAME_STD_ADDRESS]
		,NULL AS [update_status]
		,getdate() AS [process_date]
		,d.[m_status_id] AS [set_m_status_id_to]
		,0 AS [reprocess_flag]
		,'Post Production Legal Match' AS [reprocess_reason]
	--,NULL AS [action]
	FROM [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			)
	WHERE doc_id IN (
			SELECT doc_id
			FROM [Lien].[tmp].[usp_Match_Pending_Documents_doc]
			)

	--EXEC lien.[UR].[usp_process_lien_fix_starter]
	---------------------------------------------------------------the above needs to change for every fix --------------------->>>>>>>>>>>
	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	EXEC [Lien].[LEAP].[AddLeapLog] N'info'
		,N'usp_Match_Pending_Documents'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
		--ROLLBACK
END CATCH


