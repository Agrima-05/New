/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Create_Pet_Work | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
CREATE   PROCEDURE [PET].[pet_dbo].[usp_Create_Pet_Work] @Assr_Fips int, @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Create_Pet_Work'
		,N'Started'

	TRUNCATE TABLE [PET].[pet_tmp].[PET_WRK]

	INSERT INTO [PET].[pet_tmp].[PET_WRK] (
		[REF_ID]
		,[FIPS]
		,[UNFORMATTED_APN]
		,[APN_SEQUENCE_NBR]
		,[SOURCE]
		,[DQ_PROP_ID]
		,[DQ_APN]
		,[BK_PROP_ID]
		,[BK_APN]
		,[RT_PROP_ID]
		,[RT_APN]
		,[NEO_APN]
		,[NEO_LAND_TYPE]
		,[NEO_TITLE_LEGAL]
		,[StreetNumber]
		,[Pre_Direction]
		,[StreetName]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[State]
		,[Zip]
		,[Plus4]
		,[Label1]
		,[Value1]
		,[Label2]
		,[Value2]
		,[Label3]
		,[Value3]
		,[Label4]
		,[Value4]
		,[Label5]
		,[Value5]
		,[Label6]
		,[Value6]
		,[Label7]
		,[Value7]
		,[Label8]
		,[Value8]
		,[Label9]
		,[Value9]
		,[Label10]
		,[Value10]
		,[Label11]
		,[Value11]
		,[Label12]
		,[Value12]
		,[Label13]
		,[Value13]
		,[Label14]
		,[Value14]
		,[Label15]
		,[Value15]
		,[Label16]
		,[Value16]
		,[Label17]
		,[Value17]
		,[Label18]
		,[Value18]
		,[Label19]
		,[Value19]
		,[Label20]
		,[Value20]
		,[Label21]
		,[Value21]
		,[Label22]
		,[Value22]
		,[Label23]
		,[Value23]
		,[BookType]
		,[Full_Address]
		,[Check_Sum]
		--,[Rec_Type]
		,[Addr_CNT]
		,[Addr_change_status]
		,[FORMATTED_APN]
		--,[U_Apn_Dup_Ind]
		--,[F_Apn_Dup_Ind]
		--,[Legal_Dup_Ind]
		--,[Addr_Dup_Ind]
		--,[Dup_Key]
		--,[U_Apn_CNT]
		--,[U_Apn_change_status]
		--,[F_Apn_CNT]
		--,[F_Apn_change_status]
		,AddressMatchResults
		)
	SELECT ar.[REF_ID] AS [REF_ID]
		,ar.[FIPS] AS [FIPS]
		,ar.UNFORMATTED_APN AS [UNFORMATTED_APN]
		,ar.APN_SEQUENCE_NBR AS [APN_SEQUENCE_NBR]
		,isnull(ar.[SOURCE], '') AS [SOURCE]
		,ar.DQ_PROP_ID AS [DQ_PROP_ID]
		,dq.SA_PARCEL_NBR_PRIMARY AS [DQ_APN]
		,ar.BK_PROP_ID AS [BK_PROP_ID]
		,bk.APN AS [BK_APN]
		,Rt.SA_PROPERTY_ID AS [RT_PROP_ID]
		,Rt.SA_PARCEL_NBR_PRIMARY AS [RT_APN]
		,NULL AS [NEO_APN]
		,NULL AS [NEO_LAND_TYPE]
		,NULL AS [NEO_TITLE_LEGAL]
		,addr.[StreetNumber]
		,addr.[Pre_Direction]
		,addr.[StreetName]
		,addr.[Street_Type]
		,addr.[Post_Direction]
		,addr.[Unit_Type]
		,addr.[Unit]
		,addr.[City]
		,addr.[State]
		,addr.[Zip]
		,addr.[Plus4]
		,NULL AS [Label1]
		,NULL AS [Value1]
		,NULL AS [Label2]
		,NULL AS [Value2]
		,NULL AS [Label3]
		,NULL AS [Value3]
		,NULL AS [Label4]
		,NULL AS [Value4]
		,NULL AS [Label5]
		,NULL AS [Value5]
		,NULL AS [Label6]
		,NULL AS [Value6]
		,NULL AS [Label7]
		,NULL AS [Value7]
		,NULL AS [Label8]
		,NULL AS [Value8]
		,NULL AS [Label9]
		,NULL AS [Value9]
		,NULL AS [Label10]
		,NULL AS [Value10]
		,NULL AS [Label11]
		,NULL AS [Value11]
		,NULL AS [Label12]
		,NULL AS [Value12]
		,NULL AS [Label13]
		,NULL AS [Value13]
		,NULL AS [Label14]
		,NULL AS [Value14]
		,NULL AS [Label15]
		,NULL AS [Value15]
		,NULL AS [Label16]
		,NULL AS [Value16]
		,NULL AS [Label17]
		,NULL AS [Value17]
		,NULL AS [Label18]
		,NULL AS [Value18]
		,NULL AS [Label19]
		,NULL AS [Value19]
		,NULL AS [Label20]
		,NULL AS [Value20]
		,NULL AS [Label21]
		,NULL AS [Value21]
		,NULL AS [Label22]
		,NULL AS [Value22]
		,NULL AS [Label23]
		,NULL AS [Value23]
		,NULL AS [BookType]
		,addr.[Full_Address]
		,CASE 
			WHEN addr.[Full_Address] IS NOT NULL
				THEN CONVERT(NVARCHAR(32), HashBytes('MD5', addr.[Full_Address]), 2)
			ELSE NULL
			END AS [Check_Sum]
		--,NULL AS [Rec_Type]
		,NULL AS [Addr_CNT]
		,NULL AS [Addr_change_status]
		,ar.FORMATTED_APN AS [FORMATTED_APN]
		,addr.AddressMatchResults
	FROM [Pet].[Pet_tmp].[Assr] ar WITH (
			NOLOCK
			,INDEX (Idx_Fips_Ref_Id)
			)
	OUTER APPLY (
		SELECT Fips
			,SA_PROPERTY_ID
			,SA_PARCEL_NBR_PRIMARY
		FROM [Pet].[Pet_tmp].[Assessor] dq WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		WHERE dq.fips = ar.fips
			AND dq.ref_id = ar.ref_id
		) dq
	OUTER APPLY (
		SELECT DISTINCT Fips
			,BK_PROP_ID
			,APN
		FROM [Pet].[Pet_tmp].[MD_Assessment] bk WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		WHERE bk.Fips = ar.fips
			AND bk.ref_id = ar.ref_id
		) bk
	OUTER APPLY (
		SELECT C.[StreetNumber]
			,C.[Pre_Direction]
			,C.[StreetName]
			,C.[Street_Type]
			,C.[Post_Direction]
			,C.[Unit_Type]
			,C.[Unit]
			,C.[City]
			,C.[State]
			,C.[Zip]
			,C.[Plus4]
			,C.FIPS AS FIPS
			,C.REF_ID AS REF_ID
			,C.[Full_Address]
			,c.AddressMatchResults
		FROM [Pet].[Pet_tmp].[CL_Address_Base] C WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		WHERE C.fips = ar.fips
			AND C.ref_id = ar.ref_id
		) addr
	OUTER APPLY (
		SELECT TOP 1 r.SA_PROPERTY_ID
			,r.SA_PARCEL_NBR_PRIMARY
		FROM [ART].[dbo].[RT_Assessor] R WITH (
				NOLOCK
				,INDEX (IDX_Fips_SA)
				)
		WHERE R.FIPS = @Assr_Fips
			--AND R.SA_PARCEL_NBR_PRIMARY = ar.UNFORMATTED_APN
			AND r.SA_PROPERTY_ID = ar.DQ_PROP_ID
		) rt
	WHERE ar.ref_id IS NOT NULL
	
	OPTION (
		RECOMPILE
		,MAXDOP 32
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--SELECT * FROM pet.pet_tmp.PET_WRK
	--
	-- update sf columns on pet_wrk
	--
	UPDATE [PET].[pet_dbo].[a]
	SET a.[SF_Address] = d._Address
		,a.[SF_City] = d._City
		,a.[SF_Unit] = d._Unit
		,a.[SF_Address_5] = d._Address_5
		,a.[AddressCity] = d.addressCity
		,a.[Unit_Ind] = d.Unit_ind
		,a.[SF_Address_10] = d.[SF_Address_10]
	FROM [pet].[pet_tmp].[PET_WRK] a
	OUTER APPLY (
		SELECT cast(ltrim(Rtrim(a.StreetNumber)) AS VARCHAR) + ' ' + cast(ltrim(Rtrim(a.Pre_Direction)) AS VARCHAR) + ' ' + cast(ltrim(Rtrim(a.StreetName)) AS VARCHAR) + ' ' + cast(ltrim(Rtrim(a.Street_Type)) AS VARCHAR) + ' ' + cast(ltrim(Rtrim(a.Post_Direction)) AS VARCHAR) AS _Address
			,cast(ltrim(rtrim(a.[City])) AS VARCHAR) AS _City
		) b
	OUTER APPLY (
		SELECT Cast(Replace(Replace(b._Address, '  ', ' '), ' Trail', ' trl') AS VARCHAR(200)) AS _Address
			,cast(Replace(b._City, '  ', ' ') AS VARCHAR(200)) AS _City
			,isnull(a.Unit, '') AS _Unit
		) c
	OUTER APPLY (
		SELECT nullif(c._Address, '') AS _Address
			,nullif(c._City, '') AS _City
			,isnull(c._Unit, '') AS _Unit
			,nullif(substring(c._Address, 1, 5), '') AS _Address_5
			,CASE 
				WHEN c._Address > ''
					AND c._City > ''
					THEN rtrim(c._Address) + ', ' + ltrim(c._City)
				WHEN c._Address > ''
					THEN c._Address
				WHEN c._City > ''
					THEN c._City
				ELSE NULL
				END AS addressCity
			,0 AS Unit_ind
			,substring(c._Address, 1, 10) AS SF_Address_10
		) d
	OPTION (
		RECOMPILE
		,MAXDOP 32
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Create_Pet_Work'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

