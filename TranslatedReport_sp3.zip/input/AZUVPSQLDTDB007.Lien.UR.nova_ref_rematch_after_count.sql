/* Source: DWS-ETL01.DATATREE.LOCAL | lien | UR.nova_ref_rematch_after_count | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Sunwoo Park>
-- Create date: <2026-04-22>
-- Description:	<Nova ref rematch after count>
-- =============================================
create PROCEDURE [Lien].[UR].[nova_ref_rematch_after_count]
AS

DROP TABLE if exists [LIEN].[dbo].[nova_ref_rematch_after_count_tracker]

	CREATE TABLE [LIEN].[dbo].[nova_ref_rematch_after_count_tracker] (
		[Fips] [int] NOT NULL
		,[DateStarted] [datetime] NULL
		,[DateEnded] [datetime] NULL
		)

	INSERT INTO [LIEN].[dbo].[nova_ref_rematch_after_count_tracker] (
		[Fips]
		,[DateStarted]
		,[DateEnded]
		)
	SELECT fips
		,NULL AS DateStarted
		,NULL AS DateEnded
	FROM (
		SELECT fips
		FROM [lien].[dbo].[lien_rematch]
		WHERE Ref_Status = 'Completed'
			AND datediff(hour, Ref_Modified_Date, Getdate()) >= 48
			AND cnt_ref_rematch_after IS NULL
		) n


DECLARE @fips INT = NULL
	,@fips_a CHAR(5) = NULL

--select the starting fips
--
SELECT @fips = min(fips)
FROM [LIEN].[dbo].[nova_ref_rematch_after_count_tracker]
WHERE DateStarted IS NULL

SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)

--begin the loop for the Fips
DECLARE @return_value INT = 0
DECLARE @rowcount INT = 0

WHILE @fips IS NOT NULL
	AND @fips > 0
BEGIN
	--
	--Update the control table to say you are workig on the fips
	--
	BEGIN
		UPDATE [LIEN].[dbo].[nova_ref_rematch_after_count_tracker]
		SET DateStarted = getdate()
		WHERE fips = @fips
	END

	RAISERROR (
			'%s Busy with Fips %s'
			,0
			,1
			,@fips_a
			,@fips_a
			)
	WITH NOWAIT

	--
	--here the logic start that you want to run by fips
	--
	DECLARE @fips_code CHAR(5) = NULL

	SET @fips_code = right('00' + cast(@fips AS VARCHAR(5)), 5)

	UPDATE [Lien].[UR].[r]
	SET r.cnt_ref_rematch_after = isnull(c.ref_match_cnt,0)
		,r.cnt_nova_doc_found_after = isnull(c.nova_doc_found,0)
		,r.cnt_nova_ref_found_after = isnull(c.nova_ref_found,0)
	FROM [lien].[dbo].[lien_rematch] r
	LEFT JOIN (
		SELECT rm.fips
			,COUNT(*) AS ref_match_cnt
			,COUNT(rm.nova_doc_id) AS nova_doc_found
			,COUNT(rm.nova_ref_id) AS nova_ref_found
		FROM [lien].[ur].[DOCUMENT] d WITH (
				NOLOCK
				,INDEX (idx_fips_inst_rcdt_cmt_dt_seq)
				)
		INNER JOIN [lien].[ur].[REFERENCE_match] rm WITH (
				NOLOCK
				,INDEX (id_doc_id)
				) ON rm.doc_id = d.doc_id
		WHERE d.fips_code = @fips_code
		GROUP BY rm.fips
		) c ON r.fips = c.fips
	WHERE r.Ref_Status = 'Completed'
		AND r.fips = @fips

	SET @rowcount = @@rowcount

	RAISERROR (
			'%s updated  %d'
			,0
			,1
			,@fips_a
			,@rowcount
			)

	--
	--Update the control table to indicate you are done
	--
	BEGIN
		UPDATE [LIEN].[dbo].[nova_ref_rematch_after_count_tracker]
		SET DateEnded = getdate()
		WHERE fips = @fips
	END

	--
	--Select the new fips to process - if non found then @fips would be null
	--
	SELECT @fips = min(fips)
	FROM [LIEN].[dbo].[nova_ref_rematch_after_count_tracker]
	WHERE DateStarted IS NULL

	SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
END


