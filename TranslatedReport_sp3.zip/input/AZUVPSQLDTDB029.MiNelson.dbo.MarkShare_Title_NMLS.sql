/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_NMLS | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 7/10/2019
-- Description:	Create MarkShareTitle_NMLS
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_NMLS]
                
AS 


SET NOCOUNT ON

BEGIN


----- step 1

--select * from  [MiNelson].[mktshr].[TitleMarketShare_Expansion] b
--where deedid in 
--(select deedid from  [MiNelson].[mktshr].[TitleMarketShare] b
--where rundate in ('20251126','20251224','20251231','20260107')
--)


/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] ;

select [DeedID], [DeedSequence],[FIPS], [Date],[MTG1_PRIVATE_PARTY_LENDER], Rundate
into   [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
from  [Minelson].[mktshr].[TitleMarketShare] 
where rundate =  convert (varchar(10),GETDATE(), 112)
-- or  rundate in ('20251126','20251224','20251231','20260107')

alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Deed_DeedID int
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add [FMT_MTG1_DOC_NBR] varchar(20)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add [FMT_MTG2_DOC_NBR] varchar(20)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add FMT_MTG1_Book_Page varchar(20)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add FMT_MTG2_Book_Page varchar(20)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Ref_ID decimal (12,0)
--alter table Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 
--add sr_unique_id decimal (12,0)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add SR_PROPERTY_ID decimal (12,0)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Officer_NMLS_ID nvarchar(64)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Officer_Name nvarchar(254)

alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_NMLS_ID nvarchar(64)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_Name nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_Street nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_Street2 nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_City nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Lender_State nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  
add Lender_PostalCode nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  
add Lender_Country nvarchar(254)

alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Broker_NMLS_ID nvarchar(64)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Broker_Name nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Broker_Street nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  
add Broker_Street2 nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  
add Broker_City nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  
add Broker_State nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Broker_PostalCode nvarchar(254)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Broker_Country nvarchar(254)

alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add CBSA_Code nvarchar(255)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Owner_Occupied varchar(1)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Latitude numeric(10,6)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Longitude numeric(10,6)

alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add [Loan Type] varchar(12)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add [Match_Flag] varchar(1)
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add [Update_Flag] varchar(1)

-----adding new fields
alter table  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Mtg_DeedID int
alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add UpdateDate varchar(8)


----Bk Data

--- adding index fips and deedid next time

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] (fips,deedid)


--- step 2




update  [MiNelson].[dbo].[f]
set f.Deed_DeedID = DeedID
from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  f
where deedid < 1000000000

update [MiNelson].[dbo].[a]
set a.Ref_ID = d.Ref_ID,
a.[FMT_MTG1_DOC_NBR] = d.[FMT_MTG1_DOC_NBR],
a.[FMT_MTG2_DOC_NBR] = d.[FMT_MTG2_DOC_NBR],
a.FMT_MTG1_Book_Page = d.FMT_MTG1_Book_Page,
a. FMT_MTG2_Book_Page =d. FMT_MTG2_Book_Page

from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  a
left join [Deed].[dbo].[Deed] d
on a.fips = d.fips and a.Deedid = d.Deedid 
where a.deedid < 1000000000 
 

 ----RT Data




--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 
--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] (deedid)

--- getting sr_unique_id/SR_PROPERTY_ID from RT_Recorder

--update a
--set a.SR_PROPERTY_ID = b.SR_PROPERTY_ID
----select *
--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a
--inner join [MiNelson].[dbo].[Title_marketshare_RT] b-- ART.dbo.RT_Recorder b
--on a.deedid = (1000000000 + RECORDER_ID)
--where a.deedid > 1000000000

----- get Ref_id from Bill's table

--update a
--set a.ref_id = b.ref_ID
--from  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a
--inner join [MiNelson].[dbo].[RT_Recorder_Match_Archive] b
--on a.fips = b.fipscode and a.SR_UNIQUE_ID = b.SR_UNIQUE_ID 
--where a.deedid > 1000000000 

--update a
--set a.ref_id = b.ref_ID
--from  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a
--inner join [MiNelson].[dbo].[RT_Recorder_Match] b
--on a.fips = b.fipscode and a.SR_UNIQUE_ID = b.SR_UNIQUE_ID 
--where a.deedid > 1000000000 

---- get ref_id from Pet


--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 

--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] (fips,SR_PROPERTY_ID)


--UPDATE a
--SET a.REF_ID = b.REF_ID
--FROM Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a
--INNER JOIN PET.dbo.PET b  WITH (NOLOCK) ON b.FIPS = a.FIPS
--       AND b.RT_PROP_ID = a.SR_PROPERTY_ID
-- WHERE a.REF_ID IS NULL 




--- Getting Deed_id from Deed for RT records


--update a
--set a.Deed_DeedID = d.DeedID,
--a.[FMT_MTG1_DOC_NBR] = d.[FMT_MTG1_DOC_NBR],
--a.[FMT_MTG2_DOC_NBR] = d.[FMT_MTG2_DOC_NBR],
--a.FMT_MTG1_Book_Page = d.FMT_MTG1_Book_Page,
--a. FMT_MTG2_Book_Page =d. FMT_MTG2_Book_Page
--from  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a 
--inner join Deed.dbo.Deed d
--on a.fips = d.fips and a.ref_id = d.ref_id and a.date = d.recording_date
--where a.deedid > 1000000000 


---- connecting with NMLS_OCR table

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Match_Flag = 'Y'
--FROM [MiNelson].[nmls].[NMLS_OCR_Results_p_Matched_Roles] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.deedid = b.Deed_DeedID and a.MtgPos = b.Deedsequence
--where a.MtgPos in (1,2) 


----- change ---> fips and document 

--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 

--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] (fips,FMT_MTG1_DOC_NBR)



----- matching firts mtg doc

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '1'
----b.rundate = '20181130'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.documentnumber = b.FMT_MTG1_DOC_NBR
--where b.FMT_MTG1_DOC_NBR <> '' and match_flag is null


----- match 2nd mtg


--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '2'
----b.rundate = '20181130'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.documentnumber = b.FMT_MTG2_DOC_NBR
--where b.Match_flag is null and b.FMT_MTG2_DOC_NBR <> ''


------ Book ana Page 1

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '3'
----b.rundate = '20181130'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.documentnumber = b.FMT_MTG1_Book_Page and a.deedid = b.deedid
--where  b.Match_flag is null and b.FMT_MTG1_Book_Page <> ''
 



------ Book and Page 2

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '4'
----b.rundate = '20181130'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.documentnumber = b.FMT_MTG2_Book_Page and a.deedid = b.deedid
--where b.Match_flag is null and b.FMT_MTG2_Book_Page <> ''


---------using altdocumentnumber

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '5'--,
----b.rundate = '20190213'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.altdocumentnumber =  b.FMT_MTG1_DOC_NBR and a.deedid = b.deedid
--where b.Match_flag is null and b.FMT_MTG1_DOC_NBR <> ''


--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '6'--,
----b.rundate = '20190213'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.altdocumentnumber  = b.FMT_MTG2_DOC_NBR
--where b.Match_flag is null and b.FMT_MTG2_DOC_NBR <> ''



--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '7'--,
----b.rundate = '20190213'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] b
--on a.fips = b.fips and a.altdocumentnumber = b.FMT_MTG1_Book_Page and a.deedid = b.deedid
--where b.Match_flag is null and b.FMT_MTG1_Book_Page <> ''



------ Book and Page 2

--update b
--set b.Officer_NMLS_ID = a_NMLSID,
--b.Officer_Name = a.a_Name,
--b.Lender_NMLS_ID = a.l_NMLSID,
--b.Lender_Name = a.l_name,
--b.Broker_NMLS_ID = a.b_NMLSID,
--b.Broker_Name = a.b_Name,
--b.Match_Flag = '8'--,
----b.rundate = '20190213'
----select *
--FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
--inner join Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  b
--on a.fips = b.fips and a.altdocumentnumber = b.FMT_MTG2_Book_Page and a.deedid = b.deedid
--where b.Match_flag is null and b.FMT_MTG2_Book_Page <> '' 


------ Run Paul Rematch

--DECLARE @sample INT = 12
--	,@datefrom DATE = '2015-01-01'
--	,@dateto DATE = '2015-01-31'
--	,@fips_from INT = 00000
--	,@fips_to INT = 60000
--	,@datefrom_a NVARCHAR(24) = NULL
--	,@dateto_a NVARCHAR(24) = NULL

--/*IF object_id('MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]') IS NOT NULL	*/
DROP TABLE IF EXISTS MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]

--truncate table [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch]
	
--/* First time
--DROP TABLE MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]
--truncate table [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch]
--*/
--/*
----SELECT Fips
----	,DateStarted
----	,DateEnded
---- --	begin transaction update a set a.DateStarted = null
----FROM MiNelson.[dbo].[Nmls_ResultsFix] a
----where DateEnded is null
----and DateStarted is not null
---- commit
----ORDER BY fips
--*/
--IF object_id('MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]') IS NULL
--BEGIN
--	CREATE TABLE MiNelson.[dbo].[TitleMarketShare_Expansion_tracker] (
--		[Fips] [int] NOT NULL
--		,
--		--[Rows] [int] NOT NULL,
--		--[SPID] [int] NOT NULL,
--		[DateStarted] [datetime] NULL
--		,[DateEnded] [datetime] NULL
--		)

--	INSERT INTO [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker] (
--		[Fips]
--		,[DateStarted]
--		,[DateEnded]
--		)
--	SELECT fips
--		,NULL AS DateStarted
--		,NULL AS DateEnded
--	FROM NovaDimDoc.dbo.Doc_type_Min_Max_Date n
--	where fips in (select distinct fips from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]) 
--END

----Select * from MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]
--DECLARE @fips INT = NULL
--	,@fips_a CHAR(5) = NULL

--SET @datefrom_a = Replace(cast(@datefrom AS NVARCHAR(24)), '-', '')
--SET @dateto_a = Replace(cast(@dateto AS NVARCHAR(24)), '-', '')

----select the starting fips
----
--SELECT @fips = min(fips)
--FROM [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker]
--WHERE DateStarted IS NULL

--SET @fips_a = @fips

----
----begin the loop for the Fips
--DECLARE @return_value INT = 0
--DECLARE @rowcount INT = 0

----
--WHILE @fips IS NOT NULL
--	AND @fips > 0
--BEGIN
--	--
--	--Udpate the control trable to say you are workig on the fips
--	--
--	BEGIN
--		UPDATE [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker]
--		SET DateStarted = getdate()
--		WHERE fips = @fips
--	END

--	RAISERROR (
--			'%s Busy with Fips %s'
--			,0
--			,1
--			,@fips_a
--			,@fips_a
--			)
--	WITH NOWAIT

--	--
--	-- here the logic start that you  wnat to run by fips
--	--
--	--Select @datefrom_a, @dateto_a



----
---- 
----create index ix_fips on [MiNelson].[mktshr].[TitleMarketShare_Expansion] (Fips)
----create unique index ix_deedid_seq on [MiNelson].[mktshr].[TitleMarketShare_Expansion] (DeedID, DeedSequence)
----
--IF object_id('Tempdb..#input') IS NOT NULL
--	DROP TABLE #input;

--SELECT b.*
--INTO #input
--FROM (
--	SELECT DeedID
--		,DeedSequence
--		,max(FIPS) AS FIPS
--		,max(DATE) AS DATE
--		,max(Deed_DeedID) AS Deed_DeedID
--		,max(CASE 
--				WHEN DeedSequence = 1
--					THEN FMT_MTG1_DOC_NBR
--				ELSE FMT_MTG2_DOC_NBR
--				END) AS FMT_MTG_DOC_NBR
--		,max(CASE 
--				WHEN deedsequence = 1
--					THEN FMT_MTG1_Book_Page
--				ELSE FMT_MTG2_Book_Page
--				END) AS FMT_MTG_Book_Page
--		,max(Ref_ID) AS Ref_ID
--		,max(SR_PROPERTY_ID) AS SR_PROPERTY_ID
--	--FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion]
--	from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 
--	WHERE fips = @fips
--	GROUP BY DeedID
--		,DeedSequence
--	) b
----WHERE NOT (
----		isnull(FMT_MTG_DOC_NBR, '') > ''
----		AND isnull(FMT_MTG_Book_Page, '') > ''
----		)
--ORDER BY DeedID
--	,DeedSequence


--	--		AND NOT (
--	--			substring(b1.FMT_MTG_DOC_NBR, 5, 1) = '.'
--	--			AND substring(b1.FMT_MTG_DOC_NBR, 10, 2) = '.-'
--	--			and isnull(b1.FMT_MTG_DOC_NBR,'') > ''
--	--			)
--	--	) c
--	--WHERE (
--	--		isnull(FMT_MTG_Book_Page, '') > ''
--	--		OR isnull(FMT_MTG_DOC_NBR, '') > ''
--	--		)
--/*
--select top 100 * FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion] where /*Match_Flag is not null and fips = 53053*/ DeedID in (1376701791, 115660822, 115189107)

--select top 100 * from #input where  DeedID in (1376701791, 115660822, 115189107)
--*/
--IF object_id('Tempdb..#Temp2') IS NOT NULL
--	DROP TABLE #Temp2;

--SELECT d.*
--	,h.*
--INTO #temp2
--FROM #INput d
--OUTER APPLY (
--	SELECT max(CASE 
--				WHEN ROW4 = 1
--					THEN Item
--				END) AS Item1
--		,max(CASE 
--				WHEN ROW4 = 1
--					THEN ItemNumber
--				END) AS ItemNumber1
--		,max(CASE 
--				WHEN ROW4 = 2
--					THEN Item
--				END) AS Item2
--		,max(CASE 
--				WHEN ROW4 = 2
--					THEN ItemNumber
--				END) AS ItemNumber2
--		,max(CASE 
--				WHEN ROW4 = 3
--					THEN Item
--				END) AS Item3
--		,max(CASE 
--				WHEN ROW4 = 3
--					THEN ItemNumber
--				END) AS ItemNumber3
--		,max(CASE 
--				WHEN ROW4 = 4
--					THEN Item
--				END) AS Item4
--		,max(CASE 
--				WHEN ROW4 = 4
--					THEN ItemNumber
--				END) AS ItemNumber4
--	FROM (
--		SELECT ItemNumber
--			,Item
--			,ROW_NUMBER() OVER (
--				PARTITION BY 0 ORDER BY ItemNumber
--				) AS ROW4
--		FROM spdb.[dbo].[DelimitedSplit8K](d.FMT_MTG_Book_Page, '.')
--		WHERE Item > ''
--		) c
--	) b
--OUTER APPLY (
--	SELECT max(CASE 
--				WHEN ROW4 = 1
--					THEN Item
--				END) AS Item1
--		,max(CASE 
--				WHEN ROW4 = 1
--					THEN ItemNumber
--				END) AS ItemNumber1
--		,max(CASE 
--				WHEN ROW4 = 2
--					THEN Item
--				END) AS Item2
--		,max(CASE 
--				WHEN ROW4 = 2
--					THEN ItemNumber
--				END) AS ItemNumber2
--		,max(CASE 
--				WHEN ROW4 = 3
--					THEN Item
--				END) AS Item3
--		,max(CASE 
--				WHEN ROW4 = 3
--					THEN ItemNumber
--				END) AS ItemNumber3
--		,max(CASE 
--				WHEN ROW4 = 4
--					THEN Item
--				END) AS Item4
--		,max(CASE 
--				WHEN ROW4 = 4
--					THEN ItemNumber
--				END) AS ItemNumber4
--	FROM (
--		SELECT ItemNumber
--			,Item
--			,ROW_NUMBER() OVER (
--				PARTITION BY 0 ORDER BY ItemNumber
--				) AS ROW4
--		FROM spdb.[dbo].[DelimitedSplit8K](d.FMT_MTG_DOC_NBR, '.')
--		WHERE Item > ''
--		) c
--	) e
--OUTER APPLY (
--	SELECT 	b.Item1 AS d_node1
--		,CASE 
--			WHEN b.Item2 IS NOT NULL
--				THEN b.Item2 + isnull(b.Item3, '') + isnull(b.Item4, '')
--			ELSE NULL
--			END AS d_node2
--		,e.item1 AS ad_node1
--		,CASE 
--			WHEN e.Item2 IS NOT NULL
--				THEN e.Item2 + isnull(e.Item3, '') + isnull(e.Item4, '')
--			ELSE NULL
--			END AS ad_node2
--	) f
--OUTER APPLY (
--	SELECT f.d_node1
--		,SUBSTRING(f.d_node2, PATINDEX('%[^0]%', f.d_node2), LEN(f.d_node2)) AS d_node2
--		,f.d_node2 AS d_node2_old
--		,f.ad_node1
--		,SUBSTRING(f.ad_node2, PATINDEX('%[^0]%', f.ad_node2), LEN(f.ad_node2)) AS ad_node2
--		,f.ad_node2 AS ad_node2_old
--	) g
--OUTER APPLY (
--	SELECT CASE 
--			WHEN g.d_node2 IS NULL
--				THEN g.d_node1
--			ELSE g.d_node1 + '.' + g.d_node2
--			END AS _Fmt_doc
--		,CASE 
--			WHEN g.ad_node2 IS NULL
--				THEN g.ad_node1
--			ELSE g.ad_node1 + '.' + g.ad_node2
--			END AS _Fmt_Alt_doc
--		--where d.[altdocumentnumber] like '%.%'
--	) h

--/*
--  select top 100 * FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion] where DeedID in (1376701791, 115660822, 115189107)

--  select top 100 * from #input where DeedID in (1376701791, 115660822, 115189107)
--  select * from #temp2 where deedid in (1376701791, 115660822, 115189107)

--*/

--	--BEGIN TRANSACTION

--	--DELETE
--	--FROM [MiNelson].[dbo].[NMLS_Rematch]
--	--WHERE fips =  @fips

--	--create index ix_fips on [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch] (Fips)

--Delete from  [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch] where Fips = @fips

--INSERT INTO [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch]
--           ([DeedID]
--           ,[DeedSequence]
--           ,[FIPS]
--           ,[DATE]
--           ,[Deed_DeedID]
--           ,[FMT_MTG_DOC_NBR]
--           ,[FMT_MTG_Book_Page]
--           ,[Ref_ID]
--           ,[SR_PROPERTY_ID]
--           ,[_Fmt_doc]
--           ,[_Fmt_Alt_doc]
--           ,[_src]
--           ,[documentnumber]
--           ,[RoleID])
 
--	--IF object_id('Tempdb..#output') IS NOT NULL
--	--DROP TABLE #output;

--	SELECT c.*
--		,r.*
--	--INTO #output
--	FROM #temp2 c
--	OUTER APPLY (
--		SELECT TOP 1 *
--		FROM (
--			SELECT 'd1' AS _src
--				,nullif(documentnumber, '') AS documentnumber
--				,RoleID
--			FROM MiNelson.nmls.NMLS_Roles_Combined r
--			WHERE r.fips = c.fips
--				AND r.documentnumber_Conv = isnull(c._Fmt_doc, '')
--				AND isnull(c._Fmt_doc, '') > ''
		
--			UNION ALL
		
--			SELECT 'b1' AS _src
--				,nullif(documentnumber, '') AS documentnumber
--				,RoleID
--			FROM MiNelson.nmls.NMLS_Roles_Combined r2
--			WHERE r2.fips = c.fips
--				AND r2.documentnumber_Conv = isnull(c._Fmt_Alt_doc, '')
--				AND isnull(c._Fmt_Alt_doc, '') > ''
		
--			UNION ALL
		
--			SELECT 'd2' AS _src
--				,nullif(altdocumentnumber, '') AS documentnumber
--				,RoleID
--			FROM MiNelson.nmls.NMLS_Roles_Combined r
--			WHERE r.fips = c.fips
--				AND r.altdocumentnumber_Conv = isnull(c._Fmt_doc, '')
--				AND isnull(c._Fmt_doc, '') > ''
		
--			UNION ALL
		
--			SELECT 'b2' AS _src
--				,nullif(altdocumentnumber, '') AS documentnumber
--				,RoleID
--			FROM MiNelson.nmls.NMLS_Roles_Combined r2
--			WHERE r2.fips = c.fips
--				AND r2.altdocumentnumber_Conv = isnull(c._Fmt_Alt_doc, '')
--				AND isnull(c._Fmt_Alt_doc, '') > ''
--			) r1
--		) r

--	SET @rowcount = @@rowcount

--	RAISERROR (
--			'%s updated  %d'
--			,0
--			,1
--			,@fips_a
--			,@rowcount
--			)

--	--EXEC @return_value = [dbo].[usp_CreatePhotoIndexForFips] @Fips
--	--
--	--Update the control table to indicate you are done
--	--
--	BEGIN
--		UPDATE [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker]
--		SET DateEnded = getdate()
--		WHERE fips = @fips
--	END

--	--
--	--Select the new fips to process - if non found then @fips would be null
--	--
--	SELECT @fips = min(fips)
--	FROM [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker]
--	WHERE DateStarted IS NULL

--	SET @fips_a = @fips
--End

--	--- check count

--	select count (*) from  [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch]
--	select count (*) from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] 


-----------------------------rematch-----------------------------------------

alter table  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add RoleID int


------ step 3



drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]
create index ix_a on   [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] (deedid, deedsequence)
--create index ix_a on  [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch] (deedid, deedsequence)


--update a
--set a.RoleID = b.RoleID
--from  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]  a
--inner join [MiNelson].[mktshr].[TitleMarketShare_Expansion_Rematch] b
--on a.deedid = b.deedid and a.deedsequence = b.deedsequence

--select count(*) from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]
--where roleid is not null

drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] (roleid)

--------------------------------------extra matching------------------------------------


-----updating roleid using Deed_Deedid

--SELECT *
--  FROM Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] a
--  left join [MiNelson].[dbo].[NMLS_Rematch] b
--on a.Deed_DeedID = b.deedid and a.deedsequence = b._seq
--where a.RoleID is null and b.roleid is not null

update [MiNelson].[dbo].[a]
set a.roleID = b.RoleId
  FROM [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
  left join [MiNelson].[dbo].[NMLS_Rematch] b
on a.Deed_DeedID = b.deedid and a.deedsequence = b._seq
where a.RoleID is null and b.roleid is not null




----updating roleid using link process

--	select a.*

--from  [MiNelson].[mktshr].[TitleMarketShare] a
--left join [MiNelson].[dbo].[NMLS_Rematch] b
--on a.deedid = b.deedid and a.deedsequence = b._seq
--where b.RoleId is null and  a.[MGT Document number] = ''
--and [Loan Amount] <> 0

--	Select m.DeedID as MarketShare_DeedID,m.FIPS,m.[Sale Document Number],m.[MGT Document Number],m.[Book/Page],m.Date
--,d.DeedID as MTG_DeedID,d.DOC_NBR as MTG_DOC_NBR,d.RECORDING_BOOK+d.RECORDING_PAGE as [MTG_BOOK/PAGE],d.RECORDING_DATE
--from [MiNelson].[mktshr].[TitleMarketShare] m
--left join [MiNelson].[dbo].[NMLS_Rematch] b
--on m.deedid = b.deedid and m.deedsequence = b._seq
--inner join Deed.dbo.Deed d on d.FIPS=m.FIPS and d.RECORDING_DATE=m.Date and d.DOC_NBR=m.[MGT Document Number] and d.MTG1_MTG_AMOUNT=m.[Loan Amount]
--inner join Deed.dbo.Deed dd on dd.FIPS=m.FIPS and dd.DeedID=m.DeedID
--where b.RoleId is null and  m.[MGT Document number] = ''
--and m.[Loan Amount] <> 0
--and m.DeedID <> d.deedid

--	select * from [MiNelson].[dbo].[NMLS_Rematch]
--	where deedid = 188968889


	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_temp1]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1] ;



select  a.*
into [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1]
from [MiNelson].[mktshr].[TitleMarketShare] a
left join [MiNelson].[dbo].[NMLS_Rematch] b
on a.deedid = b.deedid and a.deedsequence = b._seq
where b.RoleId is null and b.RoleIdNodata is null and b.deedid is  null and  a.[MGT Document number] = ''
and a.[Loan Amount] <> 0

			alter table  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1]
				add Mtg_DeedID int


/*if object_id('minelson.dbo.Deedid_merg') is not null
    */
DROP TABLE IF EXISTS [minelson].[dbo].[Deedid_merg] ;


  select deedid , FIPS, Source_Type, RECORDING_DATE, BYR1_OWN_NAME,  SALE_AMOUNT, MTG1_MTG_AMOUNT,
   DOC_NBR, MTG1_DOC_NBR,FMT_MTG1_Book_Page, 
    recording_book,RECORDING_PAGE , MTG2_MTG_AMOUNT, MTG2_DOC_NBR,  REF_ID, CLGX_UNIQUE_ID
  into [minelson].[dbo].[Deedid_merg]
 from [deed].[dbo].[deed]
 where deedid in 
(select DeedID  
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1])



alter table  [minelson].[dbo].[Deedid_merg]	add  MTG1_MTG_AMOUNT_new numeric (13,2)
	alter table  [minelson].[dbo].[Deedid_merg]		add MTG1_DOC_NBR_new varchar (12)
		alter table  [minelson].[dbo].[Deedid_merg]		add Mtg_DeedID int

--- step 4
/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_temp2]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp2] ;

select 
     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
 x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
 x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S,
  x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,
  x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
 x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
 x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S

 into [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp2] 
from 

(  SELECT  *
FROM [minelson].[dbo].[Deedid_merg]
												 
)x
inner join
   
( SELECT  
 deedid , MTG1_MTG_AMOUNT, MTG1_DOC_NBR,FMT_MTG1_Book_Page, FIPS, Source_Type, RECORDING_DATE, BYR1_OWN_NAME, 
  REF_ID, CLGX_UNIQUE_ID ,  DOC_NBR, recording_book, MTG2_MTG_AMOUNT, MTG2_DOC_NBR, SALE_AMOUNT, RECORDING_PAGE
 
FROM [Deed].[dbo].[Deed]
where
Source_Type = 'B' and SRC_TBL = 'BKS' 
and DETAILED_DOC_TYPE not in ('CD','RD','MO')
)y
on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
and x.Source_Type = y.Source_Type 
and (y.RECORDING_DATE between x.RECORDING_DATE and Dateadd( day,45,x.RECORDING_DATE))
and left(x.BYR1_OWN_NAME, 4) = left(y.BYR1_OWN_NAME,4)


--select * from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_temp2]
--where rn= 1

 update [MiNelson].[dbo].[a]
   set 
    a.Mtg1_mtg_amount_New = b.Mtg1_mtg_amount_S
   ,a.Mtg1_Doc_NBR_New = b.Mtg1_Doc_Nbr_S
    , a.Mtg_DeedID = DeedID_S
	from  [minelson].[dbo].[Deedid_merg] a
    inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp2]  b
    on a.fips = b.fips and a.deedid = b.DeedID_D
	where b.rn = 1

	--select * from minelson.dbo.Deedid_merg 
	


	update [MiNelson].[dbo].[a]
	set a.Mtg_deedID = b.Mtg_DeedID
	from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1] a
	inner join [minelson].[dbo].[Deedid_merg] b
	on a.deedid = b.deedid and a.DeedSequence = a.DeedSequence

	update [MiNelson].[dbo].[c]
set c.mtg_DeedID = a.Mtg_DeedID
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]   c
 inner join [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1] a
  on a.deedid = c.DeedID and a.DeedSequence = c.DeedSequence


	update [MiNelson].[dbo].[a]
set a.RoleID = b.RoleID

 from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
 inner join [MiNelson].[dbo].[NMLS_Rematch] b
on a.Mtg_DeedID = b.deedid and a.deedsequence = b._seq
where  b.RoleId is not null
	



--- updating nmls infor



--------------------------------------------------------------------------------------


update [MiNelson].[dbo].[b]
set b.Officer_NMLS_ID = a_NMLSID,
b.Officer_Name = a.a_Name,
b.Lender_NMLS_ID = a.l_NMLSID,
b.Lender_Name = a.l_name,
b.Broker_NMLS_ID = a.b_NMLSID,
b.Broker_Name = a.b_Name,
b.Match_Flag = 'P'

FROM [MiNelson].[nmls].[NMLS_Roles_Combined] a
inner join  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  b
on a.RoleID = B.RoleID

------------------Adding NMLS data from Deed table 7/9/2024

-- update b
--  set b.Officer_NMLS_ID = isnull (a.[NMLSAgentId_1],b.Officer_NMLS_ID  ),
--b.Officer_Name = isnull(a.[NMLSAgentName_1],b.Officer_Name  ),
--b.Lender_NMLS_ID =isnull (a.[NMLSLenderId_1],b.Lender_NMLS_ID  ),
--b.Lender_Name =isnull (a.[NMLSLenderName_1],b.Lender_Name  ),
--b.Broker_NMLS_ID = isnull (a.[NMLSBrokerId_1],b.Broker_NMLS_ID ),
--b.Broker_Name = isnull(a.[NMLSBrokerName_1],b.Broker_Name ),
--b.Match_Flag = 'D'
--from 
-- Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] b
-- inner join Deed.dbo.deed a
-- on a.deedid = b.deedid 
-- where b.Lender_NMLS_ID is null and  a.NMLSLenderId_1 is not null
--  and b.DeedSequence = 1

--    update b
--	set  b.Officer_NMLS_ID = isnull (a.[NMLSAgentId_2],b.Officer_NMLS_ID  ),
--b.Officer_Name = isnull(a.[NMLSAgentName_2],b.Officer_Name  ),
--b.Lender_NMLS_ID =isnull (a.[NMLSLenderId_2],b.Lender_NMLS_ID  ),
--b.Lender_Name =isnull (a.[NMLSLenderName_2],b.Lender_Name  ),
--b.Broker_NMLS_ID = isnull (a.[NMLSBrokerId_2],b.Broker_NMLS_ID ),
--b.Broker_Name = isnull(a.[NMLSBrokerName_2],b.Broker_Name ),
--b.Match_Flag = 'D'

--  FROM Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] b
--  inner join deed.dbo.deed a
--  on a.deedid = b.deedid
--  where b.Lender_NMLS_ID is null and a.NMLSLenderId_2 is not null
--  and b.DeedSequence = 2


 update [MiNelson].[dbo].[b]
  set b.Officer_NMLS_ID = a.[NMLSAgentId_1],
b.Officer_Name = a.[NMLSAgentName_1],
b.Lender_NMLS_ID = a.[NMLSLenderId_1],
b.Lender_Name = a.[NMLSLenderName_1],
b.Broker_NMLS_ID = a.[NMLSBrokerId_1],
b.Broker_Name = a.[NMLSBrokerName_1],
b.Match_Flag = 'D'
from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] b
 inner join [Deed].[dbo].[deed] a
 on a.deedid = b.deedid 
 where --b.Lender_NMLS_ID is null and  a.NMLSLenderId_1 is not null  and 
  b.DeedSequence = 1

    update [MiNelson].[dbo].[b]
	set  b.Officer_NMLS_ID = a.[NMLSAgentId_2],
b.Officer_Name = a.[NMLSAgentName_2],
b.Lender_NMLS_ID =a.[NMLSLenderId_2],
b.Lender_Name = a.[NMLSLenderName_2],
b.Broker_NMLS_ID = a.[NMLSBrokerId_2],
b.Broker_Name = a.[NMLSBrokerName_2],
b.Match_Flag = 'D'

  FROM [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] b
  inner join [deed].[dbo].[deed] a
  on a.deedid = b.deedid
  where --b.Lender_NMLS_ID is null and a.NMLSLenderId_2 is not null  and
  b.DeedSequence = 2




------ Adding Lender and broker addresses

				--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]

				--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] (Lender_NMLS_ID)

				--update a
				-- set a.Lender_Street = b.[Street]
				--	  ,a.Lender_Street2 = b.[Street2]
				--	  ,a.Lender_City = b.[City]
				--	  ,a.Lender_State = b.[State]
				--	  ,a.Lender_PostalCode = b.[PostalCode]
				--	  ,a.Lender_Country =b.[Country]
				--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] a
				--inner join [MiNelson].[nmls].[NMLS_Src_Company] b
				--on a.Lender_NMLS_ID = b.[NMLSID]


				--drop index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]

				--create index ix_a on  Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] (Broker_NMLS_ID)

				--update a
				-- set   a.Broker_Street = b.[Street]
				--	  ,a.Broker_Street2 = b.[Street2]
				--	  ,a.Broker_City = b.[City]
				--	  ,a.Broker_State = b.[State]
				--	  ,a.Broker_PostalCode = b.[PostalCode]
				--	  ,a.Broker_Country =b.[Country]
				--from Minelson.[dbo].[TitleMarketShare_NMLS_Incremental] a
				--inner join [MiNelson].[nmls].[NMLS_Src_Company] b
				--on a.Broker_NMLS_ID = b.[NMLSID]





 ---- update lender_name 

 
 select Lender_NMLS_ID, count (*)
  from 
  (select distinct  Lender_NMLS_ID, Lender_Name
   from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]
   )x
   group by     Lender_NMLS_ID
	having count (*) > 1


 Update [MiNelson].[dbo].[a]
 set a.Lender_Name = b.Name
 from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
 on a.Lender_NMLS_ID = b.[NMLSID]
 where (a.Lender_Name <> b.Name) or (a.Lender_Name is null and b.Name is not null)

 --- update broker_name

 	 select [Broker_NMLS_ID], count (*)
  from 
  (select distinct  [Broker_NMLS_ID], [Broker_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]
   )x
   group by     [Broker_NMLS_ID]
	having count (*) > 1


update [MiNelson].[dbo].[a]
set a.[Broker_Name] = b.Name

from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
inner join [MiNelson].[nmls].[NMLS_Src_Company_P] b
 on a.[Broker_NMLS_ID] = b.[NMLSID]
 where (a.[Broker_Name] <> b.Name) or (a.[Broker_Name] is null and b.Name is not null)


 ----- update officer name
 

	 select [Officer_NMLS_ID], count (*)
  from 
  (select distinct  [Officer_NMLS_ID], [Officer_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]
 --  where  [Officer_NMLS_ID] =1018455
   )x
   group by     [Officer_NMLS_ID]
	having count (*) > 1


	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp] ;

		 select [Officer_NMLS_ID], count (*) as count
		 into  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp]
  from 
  (select distinct  [Officer_NMLS_ID], [Officer_Name]
   from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]
 --  where  [Officer_NMLS_ID] =1018455
   )x
   group by     [Officer_NMLS_ID]
	having count (*) > 1


	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp1]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] ;

			  
select  [Officer_NMLS_ID],  [Officer_Name], count (*) as cnt 
into  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1]
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
where  [Officer_NMLS_ID] in

(select [Officer_NMLS_ID] from  [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp]
where [Officer_NMLS_ID] is not null
)
group by [Officer_NMLS_ID],  [Officer_Name]
order by 1

/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp2]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] ;

select [Officer_NMLS_ID],  [Officer_Name], cnt,
 row_number() over(partition by [Officer_NMLS_ID]  order by cnt desc) as [rn]
into [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] 
 from [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] 

 select  a.[Officer_NMLS_ID],  b.[Officer_NMLS_ID], a.[Officer_Name] , b.[Officer_Name] ,b.*  from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
 inner join [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2]  b
 on a.[Officer_NMLS_ID] = b.[Officer_NMLS_ID] and b.rn = 1
 and a.[Officer_Name] <> b.[Officer_Name]

 
 update [MiNelson].[dbo].[a]
 set  a.[Officer_Name] = b.[Officer_Name]   
 from 
 [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
 inner join [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] b
 on a.[Officer_NMLS_ID] = b.[Officer_NMLS_ID] and b.rn = 1
 and a.[Officer_Name] <> b.[Officer_Name]

 	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp] ;
		/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp1]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp1] ;
	/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_officer_temp2]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_officer_temp2] ;


 -----

drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] (fips)

update [MiNelson].[dbo].[t]
set t.CBSA_code =  c.CBSA_Code
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  t
left join [Minelson].[Stats].[CBSA_Codes] c on t.FIPS = c.fips



drop index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 

create index ix_a on  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] (fips,REF_ID )

update [MiNelson].[dbo].[t]
set t.Owner_occupied = p.Absentee_Own_Status 
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  t
left join [Assr].[dbo].[assr] p with (Nolock) on
t.Fips = p.Fips and   t.REF_ID = p.REF_ID 
 

 

update [MiNelson].[dbo].[t]
set t.Latitude = b.Latitude, 
t.Longitude = b.Longitude
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  t
inner join  [Addr].[dbo].[CL_Address_Base] b with (nolock) on t.fips = b.fips and t.ref_id = b.ref_id and b.Address_Type = 'S'




---- Adding USDA loan type  -----> 26,125

update [MiNelson].[dbo].[a]
set a.[Loan type] = 'USDA'
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
inner join [Minelson].[mktshr].[TitleMarketShare] b
on a.deedid = b.Deedid and a.DeedSequence = b.DeedSequence
where  (b.lender like 'USDA%' 
    or b.lender like '%DEP%AGRIC%'
    or b.lender like 'FARM SE%'  
    or b.lender like 'FARM SV%'  
    or b.lender like '% FSA%'  
    or b.lender like 'RURAL H%' 
    or b.lender like 'USA%RHS%')
	and b.[loan type] not in ( 'VA', 'FHA')


------ Adding Listing Incremental


alter table [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] 
add Listing_ID int


----- step 4



update [MiNelson].[dbo].[a]
set a.Listing_ID = l.listing_ID
from  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  a
inner join [FA_Listing].[dbo].[Listing] l  on a.ref_id = l.Ref_id and a.date = l.sold_date_std and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
where l.MLS_STATUS_STD = 'sold'

update [MiNelson].[dbo].[a]
set a.Listing_ID = l.listing_ID
--select *
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  a
inner join [FA_Listing].[dbo].[Listing] l on a.ref_id = l.Ref_id and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
inner join [MiNelson].[dbo].[Title_marketshare_RT] r on RECORDER_ID+1000000000=a.DeedID and r.FIPS=a.FIPS and isdate(SR_DATE_FILING)=1
where l.MLS_STATUS_STD = 'sold'
and a.Date=cast(SR_DATE_FILING as Date)
and a.DeedID>1000000000
and a.Listing_Id is null

update [MiNelson].[dbo].[a]
set a.Listing_ID = l.listing_ID
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental]  a
inner join [FA_Listing].[dbo].[Listing] l on a.ref_id = l.Ref_id and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
inner join [Deed].[dbo].[Deed] d on d.DeedID=a.DeedID and d.FIPS=a.FIPS and SALE_DATE is not null
where l.MLS_STATUS_STD = 'sold'
and a.Date=SALE_DATE
and a.DeedID<1000000000
and a.Listing_Id is null

----- adding match by saledate 11/16/2022

update [MiNelson].[dbo].[a]
set a.Listing_ID = l.listing_ID
from [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a
inner join [FA_Listing].[dbo].[Listing] l on a.ref_id = l.Ref_id 
and Original_UPDATE_FLAG_DATE_STD>='2015-04-01' and isnull(PROVIDER_TYPE,'')<>'Altos'
inner join [Deed].[dbo].[Deed] d on d.DeedID=a.DeedID and d.FIPS=a.FIPS and SALE_DATE is not null
where l.MLS_STATUS_STD = 'sold'
and d.SALE_DATE =l.sold_date_std
and a.DeedID<1000000000
and a.Listing_Id is null
and d.TRANSACTION_TYPE in  ('1', '3')

--create index ix_a on  Minelson.[dbo].[TitleMarketShare_Listing_temp]  (Deedid, Deedsequence,listing_id)


/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Listing_Incremental]') is not null
    */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] ;


SELECT 
a.*,
RTRIM(ISNULL(LTRIM(Substring(addr.HouseNumber, 1, LEN(addr.HouseNumber)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Direction, 1, LEN(addr.Direction)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Name, 1, LEN(addr.Street_Name)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Type, 1, LEN(addr.Street_Type)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Post_Direction, 1, LEN(addr.Post_Direction)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Unit, 1, LEN(addr.Unit)) + ' '), '')) AS [Property Address]
       ,RTRIM(ISNULL(addr.City, '')) AS [Property City]
       ,RTRIM(ISNULL(addr.STD_State, '')) AS [Property State]
       ,RTRIM(ISNULL(addr.Zip, '')) AS [Property Zip]
       ,RTRIM(ISNULL(addr.Plus4, '')) AS [Property Zip + 4] 
,MLS_STATUS_STD
,MLS_LIST_DATE_STD
,MLS_Listing_Number
,agentstd.MLS_LISTING_AGENT_NAME
,agentstd.MLS_LISTING_AGENT_EMAIL
,agentstd.AGENT_PHONE
,officestd.MLS_OFFICE_NAME
,officestd.MLS_OFFICE_EMAIL
,officestd.MLS_OFFICE_ADDRESS
,officestd.MLS_OFFICE_PHONE
,Concurrent_Listed_Ind
,SOLD_DATE_STD
,Rental_Ind
,MLS_LIST_PRICE_STD
,SOLD_PRICE_STD
,(Select [SUM_OF_GROSS_SQUARE_FEET] from [Assr].[dbo].[Assr] a where a.Fips=lh.Fips and a.REF_ID=lh.REF_ID) as [Gross Living Area (GLA)]
,HOME_SIZE_STD
,LOT_SIZE_STD
,PRICE_PER_SQFT_STD
,YEAR_BUILT_STD
,SHORT_SALE_IND
,HOUSE_NBR
,MLS_DAYS_ON_MARKET_STD
into [Minelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental]
FROM  [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] a  
left join [FA_Listing].[dbo].[Listing] lh with(NOLOCK) ON a.listing_id = lh.listing_id
LEFT JOIN [FA_Listing].[dbo].[FA_MLS_Raw_Std_Address] addr with(NOLOCK) ON addr.Row_Id = lh.AddrId AND addr.Addr_type = 'S'
LEFT JOIN [FA_Listing].[dbo].[MLS_Listing_Agent] agent with(NOLOCK) ON agent.MLS_Listing_Agent_CODE = lh.MLS_Listing_Agent_CODE
LEFT JOIN [FA_Listing].[dbo].[MLS_Listing_Agent_Std] agentstd with(NOLOCK) ON agentstd.MLS_Listing_Agent_CODE_STD = agent.MLS_Listing_Agent_CODE_STD
LEFT JOIN [FA_Listing].[dbo].[MLS_Office] office with(NOLOCK) ON office.MLS_OFFICE_CODE = lh.MLS_OFFICE_CODE
LEFT JOIN [FA_Listing].[dbo].[MLS_Office_Std] officestd with(NOLOCK) ON officestd.MLS_OFFICE_CODE_STD = office.MLS_OFFICE_CODE_STD

---------------------Check updatd records--------------------------------

--SELECT count(*)
--  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Incremental]
--  SELECT count(*)
--  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental]


--  SELECT count(*)
--  FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion]
--  SELECT count(*)
--  FROM [MiNelson].[mktshr].[TitleMarketShare]


----- Checking ID length-----------------9-17-2020


update [MiNelson].[dbo].[a]
set Officer_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where len(Officer_NMLS_ID) > 8

   update [MiNelson].[dbo].[a]
set Lender_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where len(Lender_NMLS_ID) > 8

 update [MiNelson].[dbo].[a]
set Broker_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where len(Broker_NMLS_ID) > 8

  update [MiNelson].[dbo].[a]
set Officer_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where Officer_NMLS_ID like ''

   update [MiNelson].[dbo].[a]
set Lender_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where Lender_NMLS_ID like ''

 update [MiNelson].[dbo].[a]
set Broker_NMLS_ID = null
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental] a
  where Broker_NMLS_ID like ''




-------------Adding incremental to production----------------

insert into [MiNelson].[mktshr].[TitleMarketShare_Expansion]
(  [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Deed_DeedID]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[SR_PROPERTY_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RunDate]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
	  ,[RoleID]
	  ,[Mtg_DeedID]  
	  ,[UpdateDate]
	  )
 
(SELECT  [DeedID]
      ,[DeedSequence]
      ,[FIPS]
      ,[Date]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[Deed_DeedID]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      ,[Ref_ID]
      ,[SR_PROPERTY_ID]
      ,[Officer_NMLS_ID]
      ,[Officer_Name]
      ,[Lender_NMLS_ID]
      ,[Lender_Name]
      ,[Lender_Street]
      ,[Lender_Street2]
      ,[Lender_City]
      ,[Lender_State]
      ,[Lender_PostalCode]
      ,[Lender_Country]
      ,[Broker_NMLS_ID]
      ,[Broker_Name]
      ,[Broker_Street]
      ,[Broker_Street2]
      ,[Broker_City]
      ,[Broker_State]
      ,[Broker_PostalCode]
      ,[Broker_Country]
      ,[CBSA_Code]
      ,[Owner_Occupied]
      ,[Latitude]
      ,[Longitude]
      ,[Loan Type]
      ,[Match_Flag]
      ,[Update_Flag]
      ,[RunDate]
      ,[Listing_ID]
      ,[Property Address]
      ,[Property City]
      ,[Property State]
      ,[Property Zip]
      ,[Property Zip + 4]
      ,[MLS_STATUS_STD]
      ,[MLS_LIST_DATE_STD]
      ,[MLS_Listing_Number]
      ,[MLS_LISTING_AGENT_NAME]
      ,[MLS_LISTING_AGENT_EMAIL]
      ,[AGENT_PHONE]
      ,[MLS_OFFICE_NAME]
      ,[MLS_OFFICE_EMAIL]
      ,[MLS_OFFICE_ADDRESS]
      ,[MLS_OFFICE_PHONE]
      ,[Concurrent_Listed_Ind]
      ,[SOLD_DATE_STD]
      ,[Rental_Ind]
      ,[MLS_LIST_PRICE_STD]
      ,[SOLD_PRICE_STD]
      ,[Gross Living Area (GLA)]
      ,[HOME_SIZE_STD]
      ,[LOT_SIZE_STD]
      ,[PRICE_PER_SQFT_STD]
      ,[YEAR_BUILT_STD]
      ,[SHORT_SALE_IND]
      ,[HOUSE_NBR]
      ,[MLS_DAYS_ON_MARKET_STD]
	  ,[RoleID] ,[Mtg_DeedID]  ,[UpdateDate]
	  from [MiNelson].[dbo].[TitleMarketShare_NMLS_Listing_Incremental])


	  
------ Check count with production Marketshare table

-- SELECT count(*)
--  FROM [MiNelson].[mktshr].[TitleMarketShare_Expansion]

--  SELECT count(*)
--  FROM [MiNelson].[mktshr].[TitleMarketShare]


---- Clean up

/*IF object_id('MiNelson.[dbo].[TitleMarketShare_Expansion_tracker]') IS NOT NULL	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_Expansion_tracker]
/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_temp1]') is not null     */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp1] ;
/*if object_id('minelson.dbo.Deedid_merg') is not null    */
DROP TABLE IF EXISTS [minelson].[dbo].[Deedid_merg] ;
/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental_temp2]') is not null     */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental_temp2] ;
/*if object_id('Minelson.[dbo].[TitleMarketShare_NMLS_Incremental]') is not null     */
DROP TABLE IF EXISTS [Minelson].[dbo].[TitleMarketShare_NMLS_Incremental] ;


 
END  




