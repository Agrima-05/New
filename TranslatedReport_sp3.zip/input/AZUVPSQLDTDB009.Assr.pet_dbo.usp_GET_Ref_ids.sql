/* Source: AZUVNSQLDTDB003.datatree.local | assr | pet_dbo.usp_GET_Ref_ids | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

--CREATE
--	OR
CREATE PROCEDURE [Assr].[pet_dbo].[usp_GET_Ref_ids] @fips INT
	,@Assr_Fips INT
	,@Refresh BIT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
/*
DECLARE	@ERROR varchar(500)
		,@fips int = 12109
		,@Refresh bit = 1
					 
			 

EXEC	[assr].[pet_dbo].[usp_GET_Ref_ids]
		@fips = @fips 
		,@Refresh = @Refresh 
		,@ERROR = @ERROR OUTPUT
 
 select  format(count(*), '##,##0') as cnt from assr.Pet_tmp.Pet_ref_ids
 select  * from assr.Pet_tmp.Pet_ref_ids


*/
BEGIN TRY
	--EXEC PET.Pet_dbo.Add_Petlog N'info'
	--	,N'usp_GET_Ref_ids'
	--	,N'Started'
	TRUNCATE TABLE [assr].[Pet_tmp].[Pet_ref_ids]

 
 
	IF @Refresh = 1
	BEGIN
		INSERT INTO [assr].[Pet_tmp].[Pet_ref_ids] (
			fips
			,assr_fips
			,ref_id
			,UNFORMATTED_APN
			)

		--	declare @fips int = 32901, @Assr_fips int = 32003
		SELECT @fips as fips 
			,@assr_fips as assr_fips
			,ref_id
			,UNFORMATTED_APN
		FROM [assr].[dbo].[assr] a
		--WHERE fips = @fips
		WHERE a.fips = @Assr_fips
		   --and  ref_id in (37895860, 34458577, 36873769, 36007042, 36807053, 37101053, 205133143, 36864301, 37726580, 35543587, 34913232, 37783616, 35042602, 227372808, 37278538, 35911110, 36278248, 37150174, 35133053, 36176391)

	END
	ELSE
	BEGIN
		--
		--Incremental 
		--
		INSERT INTO [assr].[Pet_tmp].[Pet_ref_ids] (
			fips
			,assr_fips
			,ref_id
			,UNFORMATTED_APN
			)
		SELECT DISTINCT  fips
			,assr_fips
			,ref_id
			,UNFORMATTED_APN
		FROM [assr].[dbo].[Pet_Daily_INCR_Refids] a 

	 
			--FROM (
			--	SELECT fips
			--		,ref_id
			--		,UNFORMATTED_APN
			--	FROM Assr.dbo.AssrWrkAll
			--	UNION ALL
			--	SELECT a.fips
			--		,a.ref_id
			--		,ar.unformatted_apn
			--	FROM Assr.pet_tmp.Missing_pet_ref_id a -- this tables was created in assr.pet_dbo.usp_Determine_Missing_ref_id_Pet_Assr
			--	OUTER APPLY (
			--		SELECT unformatted_apn
			--		FROM assr.dbo.assr ar WITH (NOLOCK) -- WITH (NOLOCK,INDEX (IDX_Assr_Ref_ID))
			--		WHERE ar.ref_id = a.ref_id
			--		) ar
			--	) a




	END
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH



