/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Determine_Neo_Counties_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Determine_Neo_Counties_Incr] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
 
******************************************************************************************************************/
BEGIN TRY
	SET NOCOUNT ON

	DECLARE @FIPS INT = 99999

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Determine_Neo_Counties_Incr'
		,N'Started'

	--DECLARE @test bit;
	--Determine id all neo counties ran with previous job
	-- If all Incremental_Process_Date has values - Reset the column Incremental_Process_Date
	--SET @test = 
	--	(
	--		SELECT 
	--			CASE WHEN COUNT(*) = COUNT(PetCounties.Incremental_Process_Date)
	--				THEN 1 --have to reset
	--				ELSE 0 --there was at least 1 null
	--			END
	--		FROM 
	--			(
	--				SELECT * 
	--				FROM pet.dbo.pet_counties 
	--				WHERE Stage_SSIS_connection is not null or Prod_SSIS_connection is not null
	--			) as PetCounties
	--	)
	--PRINT(@test)
	--IF @test = 1
	UPDATE [PET].[dbo].[Pet_Counties] --#PetNeoCounties
	SET Incremental_Process_date = NULL
	WHERE Stage_SSIS_connection IS NOT NULL
		OR Prod_SSIS_connection IS NOT NULL

	UPDATE [PET].[pet_dbo].[a]
	SET a.Incremental_Process_Date = getdate()
	FROM [PET].[dbo].[Pet_Counties] a
	WHERE fips IN (
			SELECT Fips
			FROM [pet].[dbo].[pet_enhanced_process_list] a(NOLOCK)
			WHERE Process_Flag = 1
			)

	DROP TABLE

	IF EXISTS [pet].[Pet_tmp].[Pet_Incremental_Counties]
		SELECT c.Fips
			,c.Neo_counties
			,c.Land_Id_Ind
			,CASE 
				WHEN @@SERVERNAME = 'AZUVNSQLDTDB003'
					THEN '[' + rtrim(c.Stage_SSIS_connection) + ']'
				ELSE '[' + rtrim(c.Prod_SSIS_connection) + ']'
				END AS Neo_server
			,c.Incremental_Process_Date
			,try_cast(NULL AS DATETIME) AS Max_NEO_Update_date
		INTO [pet].[Pet_tmp].[Pet_Incremental_Counties]
		FROM [pet].[dbo].[pet_counties] c
		WHERE (
				c.Stage_SSIS_connection IS NOT NULL
				OR c.Prod_SSIS_connection IS NOT NULL
				)
			AND c.Incremental_Process_Date IS NULL
		ORDER BY fips

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'usp_Determine_Neo_Counties_Incr'
		,N'Ended'

		--	SELECT * FROM pet.Pet_tmp.Pet_Incremental_Counties
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH
	--SELECT Fips
	--	,Neo_counties
	--	,Land_Id_Ind
	--	,Neo_server
	--FROM pet.Pet_tmp.Pet_Incremental_Counties
	--order by fips


