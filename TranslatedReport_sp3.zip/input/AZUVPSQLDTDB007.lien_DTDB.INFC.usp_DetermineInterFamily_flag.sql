/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_DetermineInterFamily_flag | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[usp_DetermineInterFamily_flag] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who				date		change
paul and Marie  20230614	SP
Marie			2023-11-07	Remove logic for Party-type-code of FBO

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) 
BEGIN TRY
	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_DetermineInterFamily_flag'
		,N'Started'

	--create clustered index idx_doc_id on #docs (doc_id)
	DROP TABLE

	IF EXISTS #Set_interfamily_flag
		SELECT d.doc_id
			,CASE 
				WHEN (
						----------------2
						d.doc_title LIKE '%interspousal%'
						OR d.doc_title LIKE '%inter-spousal%'
						OR d.doc_title LIKE '%husband and wife%'
						OR d.doc_title LIKE '%DOMESTIC PARTNER%'
						OR d.doc_title LIKE '%OWELTY'
						OR d.doc_title LIKE '%interfamily%'
						OR d.doc_title LIKE '%Parent to Children%'
						OR d.doc_title LIKE '%Lady Bird%'
						)
					OR dd.owelty_flag = 'y'
					OR d.Doc_Type IN (
						'DEDLFE'
						,'DEDFAM'
						,'QCDFAM'
						,'DEDGFT'
						)
					THEN 'YES'
				ELSE b._match
				END AS _match
		INTO #Set_interfamily_flag
		FROM [Lien_dtdb].[tmp].[reprocess_records_to_be_processed] d
		INNER JOIN [lien].[ur].[document] dd ON dd.doc_id = d.doc_id
		OUTER APPLY (
			SELECT TOP 1 _match
			FROM (
				SELECT s._match
			
				
				FROM [Lien_dtdb].[infc].[deed_buyer_names] b
				OUTER APPLY (
					SELECT CASE 
							WHEN (
									(
										(
											substring(b.last_company_name, 1, 4) = substring(ss.Last_company_name, 1, 4)
											AND len(b.last_company_name) > 4
											)
										OR (
											len(b.last_company_name) < 5
											AND b.last_company_name = ss.Last_company_name
											)
										)
									OR (
										ss.Last_company_name LIKE '%' + b.last_company_name + '%'
										AND len(b.last_company_name) > 3
										)
									OR (
										b.last_company_name LIKE '%' + ss.Last_company_name + '%'
										AND len(ss.Last_company_name) > 3
										)
									--OR SPDB.dbo.Similarity(ss.Last_company_name, b.last_company_name, 3, 0, .5) > .85
									)
								THEN 'yes'
							ELSE NULL
							END AS _match
					FROM [Lien_dtdb].[infc].[deed_seller_names] s WITH (INDEX (idx_doc_id))
					OUTER APPLY (
						SELECT replace(Replace(Replace(Replace(s.Last_company_name, 'FAMILY', ''), 'TRUST', ''), 'Revocable', ''), 'LIVING', '') AS last_company_name
							--last_company_name
						) ss
					WHERE s.doc_id = b.doc_id
						AND ss.Last_company_name NOT IN (
							'NAME NOT AVAILABLE'
							,'RECORD OWNER'
							)
						AND len(ss.Last_company_name) > 1
						AND len(b.last_company_name) > 1
						--and s.party_type_code not in ('FBO')  -- Removed 2023/11/07
					) s
				WHERE b.doc_id = d.doc_id
					--and b.party_type_code not in ('FBO') -- Removed 2023/11/07
					--AND s._match = 'yes'
				) l
			WHERE l._match = 'YES'
			) b
		WHERE d.Doc_type IN (
				SELECT UR_Value
				FROM [Deed].[dbo].[UR_Document_Types]
				WHERE deed_type NOT IN (
						'Z'
						,'T'
						,'U'
						)
				)
		--WHERE d.doc_id IN (
		--		SELECT DISTINCT doc_id
		--		FROM #names
		--		)
		--	--and a.doc_id = 217465022
		--	AND b._match = 'yes'
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON #Set_interfamily_flag (doc_id) include (_match)

	BEGIN TRANSACTION

	UPDATE [lien_DTDB].[INFC].[d]
	SET d.interfamily_flag = CASE 
			WHEN d.interfamily_flag = 'Y'
				THEN d.interfamily_flag
			ELSE CASE 
					WHEN a._match IS NOT NULL
						THEN 'X'
					ELSE NULL
					END
			END
	FROM [lien].[ur].[document] d
	INNER JOIN #Set_interfamily_flag a ON a.doc_id = d.doc_id

	COMMIT

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'usp_DetermineInterFamily_flag'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
END CATCH




