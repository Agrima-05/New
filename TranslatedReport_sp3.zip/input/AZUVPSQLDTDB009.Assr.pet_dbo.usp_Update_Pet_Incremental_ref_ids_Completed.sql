/* Source: AZUVNSQLDTDB003.datatree.local | Assr | pet_dbo.usp_Update_Pet_Incremental_ref_ids_Completed | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [Assr].[pet_dbo].[usp_Update_Pet_Incremental_ref_ids_Completed] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG: 
==========
who		date		change

******************************************************************************************************************/
-- declare @fips INT = 1 ,@ERROR VARCHAR(500) ,@Refresh BIT = 0, @fips INT = null
BEGIN TRY
	--select * 
	UPDATE [Assr].[pet_dbo].[p]
	SET p.process_status = 'C'
	FROM [Assr].[dbo].[Pet_Incremental_ref_ids] p WITH (
			NOLOCK
			,INDEX (idx_Process_status)
			)
	CROSS APPLY (
		SELECT *
		FROM [assr].[dbo].[Pet_Daily_INCR_Refids] d WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		WHERE d.fips = p.fips
			AND d.ref_id = p.ref_id
		) d
	WHERE p.process_status = 'P'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH




