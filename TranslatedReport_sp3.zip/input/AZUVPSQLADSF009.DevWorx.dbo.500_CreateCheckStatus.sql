SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [DevWorx].[dbo].[500_CreateCheckStatus]
AS
BEGIN

		drop table dbo.CheckStatus

		Select Fipscode,PropertyID,StandardStatus,ListingContractDate,ListPrice,CloseDate,ClosePrice
		INTO [DevWorx].[dbo].[CheckStatus]
		 from [DevWorx].[dbo].[Devworx_ALL] with(NOLOCK)
		WHERE isNULL(FIPSCode,'') not like ''
		and PropertyID is not null
		and isNULL(StandardStatus,'') Not like ''
		group by Fipscode,PropertyID,StandardStatus,ListingContractDate,ListPrice,CloseDate,ClosePrice

		--Select * from dbo.CheckStatus a JOIN [AZUVPSQLADSF001].Data.dbo.Property b with(NOLOCK)
		--on FIPSCode = b.fips
		--and a.PropertyID = b.PropertyID

		Create index [ix_FipsPropID] on dbo.CheckStatus(Fipscode,PropertyID)




END


