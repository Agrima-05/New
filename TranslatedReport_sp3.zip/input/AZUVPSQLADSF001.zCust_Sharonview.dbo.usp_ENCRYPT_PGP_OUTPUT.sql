SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [zCust_Sharonview].[dbo].[usp_ENCRYPT_PGP_OUTPUT] 
	
AS
BEGIN

	EXEC msdb.dbo.sp_start_job N'Sharonview_Encrypt_Output' ; 

			
		
END




