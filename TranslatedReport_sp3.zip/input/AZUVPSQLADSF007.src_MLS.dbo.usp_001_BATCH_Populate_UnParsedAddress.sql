SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Populate UnParsedAddress from Parsed Fields
-- ================================================================================

CREATE procedure [src_MLS].[dbo].[usp_001_BATCH_Populate_UnParsedAddress] @Board varchar(50)
	
AS
BEGIN

	SET NOCOUNT ON;

		EXEC('UPDATE ' + @Board + '_Listings_Batch
		SET [UnparsedAddress] = UPPER(LTRIM(RTRIM(
										RTRIM(
									RTRIM(
								RTRIM(
							RTRIM(
						LTRIM(
					LTRIM(RTRIM(CASE WHEN isNULL([StreetNumber],'''') LIKE '''' THEN isNULL([StreetNumberNumeric],'''') ELSE isNULL([StreetNumber],'''') END + '' '' + isNULL([StreetDirPrefix],'''')))
						+ '' '' + isNULL([StreetName],'''')) 
							+ '' '' + isNULL([StreetSuffix],'''')) 
								+ '' '' + isNULL([StreetSuffixModifier],'''')) 
									+ '' '' + isNULL([StreetDirSuffix],'''')) 
										+ '' '' + isNULL([StreetAdditionalInfo],'''')) 
											+ CASE WHEN ISNULL([UnitNumber],'''') Like '''' THEN '''' ELSE '' UNIT '' + [UnitNumber] END
											)))
		WHERE IsNULL([UnparsedAddress],'''') LIKE ''''
			AND isNULL([StreetName],'''') NOT LIKE ''''
		')

				EXEC('Update ' + @Board + '_Listings_Batch
				SET MlsStatus = [StandardStatus]
				WHERE isNULL(MlsStatus,'''') LIKE ''''
				and isNULL([StandardStatus],'''') NOT LIKE ''''
				')				
				
				EXEC('Update a
				SET a.StandardStatus = b.[StandardStatus]
				from ' + @Board + '_Listings_Batch a JOIN [src_MLS_Global].[dbo].[lkup_MLSStatus] b
				on a.MlsStatus = b.[MlsStatus]')

				EXEC('update [src_MLS].dbo.' + @Board + '_Listings_Batch set [UnparsedAddress] = left([UnparsedAddress],50) where len([UnparsedAddress]) > 50')--20220805 AF can't parse if over 50
				
END




