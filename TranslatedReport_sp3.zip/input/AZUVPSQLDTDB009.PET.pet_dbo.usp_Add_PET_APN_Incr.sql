/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Add_PET_APN_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 

-- =============================================  
-- Author:  Sean Dang  
-- Create date: 02/28/2025  
-- Description: Adding PetAPN  
-- =============================================  
CREATE PROCEDURE [PET].[pet_dbo].[usp_Add_PET_APN_Incr]
	-- Add the parameters for the stored procedure here  
	@Fips INT,
	@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from  
	-- interfering with SELECT statements.  
	SET NOCOUNT ON;

	/*======================================================  
   Add NEOF entry when not exist - Added 10/21/2022 - MP  
   =====================================================*/
	--DECLARE @NEOF_Cnt INT = 0  
	--SET @NEOF_Cnt = (  
	--  SELECT count(*)  
	--  FROM pet.tmp.Pet_Fips_Apn_type_Inserts  
	--  WHERE apn_type = 'NEOF'  
	--  )  
	--IF @NEOF_Cnt = 0  
	--BEGIN  
	-- INSERT INTO pet.tmp.Pet_Fips_Apn_type_Inserts (  
	--  [FIPS]  
	--  ,[APN_Type]  
	--  ,[NEO_PET]  
	--  ,[UNQ_Match]  
	--  ,[created]  
	--  )  
	-- SELECT @Fips AS Fips  
	--  ,'NEOF' AS Apn_Type  
	--  ,1 AS NEO_PET  
	--  ,0 AS UNQ_Match  
	--  ,GETDATE() AS [created]  
	--END  
	/*=========================================  
  Identify All Apns in From Neo for a county    
   =========================================*/
	BEGIN TRY	
		EXEC [PET].[dbo].[AddPetLog] @Fips
		  ,N'info'
		  ,N'usp_Add_PET_APN_Incr'
		  ,N'Started'

		DROP TABLE

		IF EXISTS #dist_apn
			CREATE TABLE #dist_apn (
				fips INT
				,NEO_APN VARCHAR(65)
				,strippedAPN VARCHAR(65)
				,spaceAPN VARCHAR(65)
				)

		INSERT INTO #dist_apn
		SELECT a.fips
			,a.NEO_APN
			,cast([SPDB].[dbo].[RegexReplace](a.NEO_APN, '(\/| |-|\.)', '', 0) AS VARCHAR(100)) AS strippedAPN
			,cast([SPDB].[dbo].[RegexReplace](a.NEO_APN, '( )', '', 0) AS VARCHAR(100)) AS spaceAPN
		FROM (
			SELECT fips
				,NEO_APN
				,NEO_TITLE_LEGAL
				,NEO_LAND_TYPE
				,count(1) AS cnt

			FROM [pet].[pet_tmp].[Pet_Incremental_Add]
			GROUP BY fips
				,NEO_APN
				,NEO_TITLE_LEGAL
				,NEO_LAND_TYPE
			) a
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		DROP TABLE

		IF EXISTS #apn_match_1
			CREATE TABLE #apn_match_1 (
				REF_ID INT
				,FIPS INT
				,apn_type VARCHAR(50)
				,APN_ID NUMERIC(12, 0)
				,APN VARCHAR(100)
				,created DATETIME
				,updated DATETIME
				,ROW4 INT
				)

		INSERT INTO #apn_match_1
		SELECT k.REF_ID
			,k.FIPS
			,k.apn_type
			,k.APN_ID
			,k.APN
			,k.created
			,k.updated
			,ROW_NUMBER() OVER (
				PARTITION BY ref_id
				,apn_type ORDER BY (
						SELECT 0
						)
				) AS ROW4
		FROM (
			SELECT DISTINCT p.[REF_ID]
				,a.[FIPS] AS FIPS
				,'NEOF' AS apn_type
				,0 AS [APN_ID]
				,LTRIM(RTRIM(a.NEO_APN)) AS [APN]
				,getdate() AS [created]
				,NULL AS [updated]
			FROM #dist_apn a
			OUTER APPLY (
				SELECT *
				FROM [PET].[dbo].[PET_APN] p WITH (NOLOCK,INDEX (ixa_Fips_Apn))
				outer apply (Select NEO_PET from [pet].[dbo].[pet_fips_apn_type] pp where pp.fips = a.fips and pp.apn_type = p.apn_type) pt
				WHERE p.FIPS = a.Fips
					AND p.Apn IN (
						a.NEO_APN
						,a.strippedAPN
						,a.spaceAPN
						)
					and pt.NEO_PET = 1
				) p
			WHERE p.ref_id IS NOT NULL
				--and p.apn_type = 'NEOF' --maybe edit later
			) k
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		--dynamic sql that finds all records that share apns and since they share apn the procedure will only add one instance of the apn 
		--DECLARE 
		--	@sql VARCHAR(MAX),
		--	@FipsToChar VARCHAR(MAX) = CAST(@Fips as VARCHAR);
		--SET @sql = 
		--	(
		--		'
		--			drop table if exists pet.pet_tmp.pet_incremental_FindRecordsNotInAPNMatch_' + @FipsToChar + '
		--			select *
		--			into pet.pet_tmp.pet_incremental_FindRecordsNotInAPNMatch_' + @FipsToChar + '
		--			from pet.pet_tmp.pet_incremental_Add as addPet
		--			where NEO_APN in
		--				(
		--					select neo_apn
		--					from pet.pet_tmp.Pet_Incremental_Add
		--					group by NEO_APN
		--					having COUNT(neo_apn) > 1
		--				)
		--		'
		--	)
		--print(@sql)
		--exec(@sql)
		--not part dynamic sql code above
		----get the number of rows returns
		--select neo_apn, COUNT(neo_apn) as cnt
		--from pet.pet_tmp.Pet_Incremental_Add
		--group by NEO_APN
		--having COUNT(neo_apn) > 1
		----get the total sum of all repeating neo_apns, then take totalRepeatingAPNS - numRowsReturned = how many are repeated AND not accounted for
		--select SUM(c.cnt)
		--from 
		--	(
		--		select neo_apn, COUNT(neo_apn) as cnt
		--		from pet.pet_tmp.Pet_Incremental_Add
		--		group by NEO_APN
		--		having COUNT(neo_apn) > 1
		--	) c
		CREATE INDEX ixa ON #apn_match_1 (row4)

		CREATE INDEX ixb ON #apn_match_1 (APN)

		--catches duplicates in temp table that might occur  
		DELETE
		FROM #apn_match_1
		WHERE apn IN (
				SELECT apn
				FROM #apn_match_1
				WHERE row4 > 1
				)

		TRUNCATE TABLE [PET].[pet_tmp].[PET_APN_Inserts_Incremental]

		INSERT INTO [PET].[pet_tmp].[PET_APN_Inserts_Incremental] (
			[REF_ID]
			,[FIPS]
			,[APN_Type]
			,[APN_ID]
			,[APN]
			,[created]
			,[updated]
			)
		SELECT [REF_ID]
			,[FIPS]
			,[APN_Type]
			,[APN_ID]
			,[APN]
			,[created]
			,[updated]
		FROM #apn_match_1
	
		UNION
	
		SELECT [REF_ID]
			,[FIPS]
			,'NEO' AS [APN_Type]
			,[APN_ID]
			,[APN]
			,[created]
			,[updated]
		FROM #apn_match_1

		SELECT fips
			,apn
			,count(1) AS cnt
		INTO #dups
		FROM (
			SELECT DISTINCT Fips
				,ref_id
				,apn
			FROM [PET].[dbo].[PET_APN]
			WHERE fips = @fips
			) a
		GROUP BY fips
			,apn
		HAVING count(1) > 1

		CREATE INDEX ixa ON #dups (
			fips
			,apn
			)

		UPDATE [PET].[pet_dbo].[p]
		SET p.Dup_ind = 1
		FROM [PET].[dbo].[PET_APN] p WITH (
				NOLOCK
				,INDEX (ixa_Fips_Apn)
				)
		INNER JOIN #dups d WITH (
				NOLOCK
				,INDEX (ixa)
				) ON d.FIPS = p.fips
			AND d.apn = p.apn

		EXEC [PET].[dbo].[AddPetLog] @Fips
		  ,N'info'
		  ,N'usp_Add_PET_APN_Incr'
		  ,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


