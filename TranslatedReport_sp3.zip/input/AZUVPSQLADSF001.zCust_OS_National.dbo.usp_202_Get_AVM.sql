SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF





CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_202_Get_AVM] 
AS
BEGIN

TRUNCATE TABLE dbo.w_AVM

INSERT INTO [zCust_OS_National].[dbo].[w_AVM]([fips]
      ,[ref_id]
      ,[final_value]
      ,[VALUATION_DATE]
      ,[LAST_SALE]
      ,[LAST_SALE_DATE]
      ,[score]
      ,[high]
      ,[low]
      ,[stdev]
      ,[land_use]
      ,[sqft]
      ,[latitude]
      ,[longitude]
      ,[yb]
      ,[charSource])
SELECT d.[fips]
      ,d.[ref_id]
      ,d.[final_value]
      ,d.[VALUATION_DATE]
      ,d.[LAST_SALE]
      ,d.[LAST_SALE_DATE]
      ,d.[score]
      ,d.[high]
      ,d.[low]
      ,d.[stdev]
      ,d.[land_use]
      ,d.[sqft]
      ,d.[latitude]
      ,d.[longitude]
      ,d.[yb]
      ,d.[charSource]
  FROM  [AZUVPSQLDTDB029.datatree.local].[Property_EVAL_OUTPUT].[dbo].[valuationOut] d with(nolock) INNER JOIN [zCust_OS_National].[dbo].[w_UniqueRefId] p
  ON d.Fips = p.FIPS AND d.REF_ID = p.REF_ID

  DROP TABLE w_AVM_Coverage

  Select FIPS
  INTO [zCust_OS_National].[dbo].[w_AVM_Coverage]
 FROM  [AZUVPSQLDTDB029.datatree.local].[Property_EVAL_OUTPUT].[dbo].[valuationOut] d with(nolock) 
 WHERE Final_Value is not null and Final_Value > 0
 GROUP BY FIPS
 ORDER BY FIPS


END



