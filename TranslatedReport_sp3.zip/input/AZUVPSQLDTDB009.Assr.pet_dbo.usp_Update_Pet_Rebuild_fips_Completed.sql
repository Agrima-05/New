/* Source: AZUVNSQLDTDB003.datatree.local | assr | pet_dbo.usp_Update_Pet_Rebuild_fips_Completed | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

--CREATE
--	OR
CREATE PROCEDURE [Assr].[pet_dbo].[usp_Update_Pet_Rebuild_fips_Completed] @fips INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
BEGIN TRY
	UPDATE [Assr].[pet_dbo].[p]
	SET p.process_status = 'C'
	FROM [Assr].[dbo].[Pet_Rebuild_fips] p
	WHERE p.fips = @fips
		AND p.process_status = 'P'

	--
	-- added this to eliminate processing the same records every day - 2025/10/17
	--
	UPDATE [Assr].[pet_dbo].[a]
	SET a.process_status = 'C'
	FROM [Assr].[dbo].[Pet_Incremental_ref_ids] a
	WHERE a.fips = @fips
		AND a.process_status = 'P'

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


