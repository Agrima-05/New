SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_WesternAlliance].[dbo].[usp_300_Start_Output_WESTERN_ALLIANCE_S12]

AS
BEGIN
	
	SET NOCOUNT ON;

	

		DROP TABLE [dbo].[x_Custom_OUTPUT_S12]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S12](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID]  [varchar](250) NULL,
		
			[INPUT Property ID][varchar](250)NULL,
			[INPUT Loan ID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Owner1CorpInd][varchar](250)NULL,
			[OwnerNAME1FULL][varchar](250)NULL,
			[Owner2CorpInd][varchar](250)NULL,
			[OwnerNAME2FULL][varchar](250)NULL,
			[MailingFullStreetAddress][varchar](250)NULL,
			[MailingCity][varchar](250)NULL,
			[MailingState][varchar](250)NULL,
			[MailingZIP5][varchar](250)NULL,
			[LotSizeSqFt][varchar](250)NULL,
			[LegalDescription][varchar](250)NULL,
			[TotalOpenLienNbr][varchar](250)NULL,
			[TotalOpenLienAmt][varchar](250)NULL,
			[Mtg1TransactionId][varchar](250)NULL,
			[Mtg1RecordingDate][varchar](250)NULL,
			[Mtg1LoanAmt][varchar](250)NULL,
			[Mtg1Lender][varchar](250)NULL,
			[Mtg1PrivateLender][varchar](250)NULL,
			[Mtg1Term][varchar](250)NULL,
			[Mtg1LoanDueDate][varchar](250)NULL,
			[Mtg1AdjRider][varchar](250)NULL,
			[Mtg1LoanType][varchar](250)NULL,
			[Mtg1TypeFinancing][varchar](250)NULL,
			[Mtg1LienPosition][varchar](250)NULL,
			[Mtg2TransactionId][varchar](250)NULL,
			[Mtg2RecordingDate][varchar](250)NULL,
			[Mtg2LoanAmt][varchar](250)NULL,
			[Mtg2Lender][varchar](250)NULL,
			[Mtg2PrivateLender][varchar](250)NULL,
			[Mtg2Term][varchar](250)NULL,
			[Mtg2LoanDueDate][varchar](250)NULL,
			[Mtg2AdjRider][varchar](250)NULL,
			[Mtg2LoanType][varchar](250)NULL,
			[Mtg2TypeFinancing][varchar](250)NULL,
			[Mtg2LienPosition][varchar](250)NULL,
			[Mtg3TransactionId][varchar](250)NULL,
			[Mtg3RecordingDate][varchar](250)NULL,
			[Mtg3LoanAmt][varchar](250)NULL,
			[Mtg3Lender][varchar](250)NULL,
			[Mtg3PrivateLender][varchar](250)NULL,
			[Mtg3Term][varchar](250)NULL,
			[Mtg3LoanDueDate][varchar](250)NULL,
			[Mtg3AdjRider][varchar](250)NULL,
			[Mtg3LoanType][varchar](250)NULL,
			[Mtg3TypeFinancing][varchar](250)NULL,
			[Mtg3LienPosition][varchar](250)NULL,
			[Mtg4TransactionId][varchar](250)NULL,
			[Mtg4RecordingDate][varchar](250)NULL,
			[Mtg4LoanAmt][varchar](250)NULL,
			[Mtg4Lender][varchar](250)NULL,
			[Mtg4PrivateLender][varchar](250)NULL,
			[Mtg4Term][varchar](250)NULL,
			[Mtg4LoanDueDate][varchar](250)NULL,
			[Mtg4AdjRider][varchar](250)NULL,
			[Mtg4LoanType][varchar](250)NULL,
			[Mtg4TypeFinancing][varchar](250)NULL,
			[Mtg4LienPosition][varchar](250)NULL,
			[IsListedFlag][varchar](250)NULL,
			[IsListedFlagDate][varchar](250)NULL,
			[flCommunityName][varchar](250)NULL,
			[flCommunityNbr][varchar](250)NULL,
			[flFemaMapNbr][varchar](250)NULL,
			[flFIRMID][varchar](250)NULL,
			[flPanelNbr][varchar](250)NULL,
			[flInsideSFHA][varchar](250)NULL,
			[flFemaFloodZone][varchar](250)NULL,
			[flFemaMapDate][varchar](250)NULL,
			[HOA1Name][varchar](250)NULL,
			[HOA1PropertyManagementName][varchar](250)NULL,
			[HOA2Name][varchar](250)NULL,
			[HOA2PropertyManagementName][varchar](250)NULL,
			[PFCFlag][varchar](250)NULL,
			[FinalValue][varchar](250)NULL,
			[HighValue][varchar](250)NULL,
			[LowValue][varchar](250)NULL,
			[ConfidenceScore][varchar](250)NULL,
			[StandardDeviation][varchar](250)NULL,
			[ValuationDate][varchar](250)NULL



		) ON [PRIMARY]

	
	SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] (
		[INPUT Property ID],
		[INPUT Loan ID],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip]
		)
		
		--Select 
		--[Property ID]
		--,[Loan ID] 
		--,left([Street] ,250)
		--,[City] 
		--,[State]
		--,[ZIP] 
		----,convert(DAte,[Start Date] )

		Select 
		[PropertyID]
		,[LoanID] 
		,left([PropertyStreet] ,250)
		,[PropertyCity] 
		,[PropertyState]
		,[PropertyZIPCode] 
		
		
		From [zCust_WesternAlliance].[dbo].[INPUT_RAW_CUST]

		--SET CONCAT_NULL_YIELDS_NULL OFF
		--INSERT INTO x_Custom_OUTPUT_S12 (
		--[INPUT Property ID])
		--Select 
		--[PROPERTY_ID]
		--From [dbo].[INPUT_RAW_BUILDER_20260422] as A 
	
		

	






	   Select  * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
	   Order by convert(bigint,[INPUT Property ID])

	   

		UPDATE [zCust_WesternAlliance].[dbo].[a] 
		SET 
		a.WORK_REF_ID = c.REF_ID
		,A.PropertyID = C.PropertyID
			,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a JOIN 
		[zCust_WesternAlliance].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT Property ID] = c.RAW_ID
		
		
		
		Update [zCust_WesternAlliance].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Property ID] = c.RAW_ID



		Select * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]

	


	

		--Update a
		--set 
		----A.[Deed Coverage Status] = B.DeedActive
		----,A.[Deed Start Date] = case when B.DeedMinRecordDate like '' then NULL else convert(date,B.DeedMinRecordDate) end
		----,A.[Deed Thru Date] = case when B.DeedMAXRECORDDATE like '' then NULL else convert(date,B.DeedMAXRECORDDATE) end
		
		----,
		--A.[Mortgage Coverage Status] = B.SamActive
		----,A.[Mortgage Start Date] = case when B.SAMMinRecordDate like '' then NULL else convert(date,B.SAMMinRecordDate) end
		--,A.[Mortgage Thru Date] = case when B.SAMMAXRECORDDATE like '' then NULL else convert(date,B.SAMMAXRECORDDATE) end

		
		--FROM x_Custom_OUTPUT_S12 a 
		--	JOIN global.dbo.county b  with(NOLOCK)
		--	ON convert(int,a.FIPs) = b.FIPsCode


		--Update x_Custom_OUTPUT_S12
		--Set [Mortgage Coverage Status] = 1

		----Select FIPS, PROPERTYID, [Mortgage Coverage Status], [Mortgage Thru Date] from x_Custom_OUTPUT_S12
		--where [Mortgage Coverage Status] = 0
		--and ISNULL([Mortgage Thru Date],'') not like ''
		----Order by FIPS


		--Select  [Mortgage Coverage Status], Count(*) from x_Custom_OUTPUT_S12
		----where [Mortgage Coverage Status] = 0
		--WHERE ISNULL([Mortgage Thru Date],'') not like ''
		--Group by [Mortgage Coverage Status]

		

	

		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.[Owner1CorpInd] = B.OwnerStd1CorpInd
		,A.[OwnerNAME1FULL] = B.OwnerStdNAME1FULL
		,A.[Owner2CorpInd] = B.OwnerStd2CorpInd
		,A.[OwnerNAME2FULL] = B.OwnerStdNAME2FULL
		,A.[MailingFullStreetAddress] = B.MailingStdFullStreetAddress
		,A.[MailingCity] = B.MailingStdCity
		,A.[MailingState] = B.MailingStdState
		,A.[MailingZIP5] = B.MailingStdZIP5
		,A.[LotSizeSqFt] = B.LotSizeSqFt
		,A.[LegalDescription] = left(B.LegalDescription,250)

		
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID
	
	
		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.TotalOpenLienAmt = B.TotalOpenLienAmt
		,A.TotalOpenLienNbr = B.TotalOpenLienNbr
		,A.[Mtg1TransactionId] = B.[Mtg1TransactionId]
		,A.[Mtg1RecordingDate] = B.[Mtg1RecordingDt]
		,A.[Mtg1LoanAmt] = B.[Mtg1LoanAmt]
		,A.[Mtg1Lender] = B.[Mtg1Lender]
		,A.[Mtg1PrivateLender] = B.[Mtg1PrivateLender]
		,A.[Mtg1Term] = B.[Mtg1Term]
		,A.[Mtg1LoanDueDate] = B.Mtg1LoanDueDt
		,A.[Mtg1AdjRider] = B.[Mtg1AdjRider]
		,A.[Mtg1LoanType] = B.[Mtg1LoanType]
		,A.[Mtg1TypeFinancing] = B.[Mtg1TypeFinancing]
		,A.[Mtg1LienPosition] = B.[Mtg1LienPosition]
		,A.[Mtg2TransactionId] = B.[Mtg2TransactionId]
		,A.[Mtg2RecordingDate] = B.Mtg2RecordingDt
		,A.[Mtg2LoanAmt] = B.[Mtg2LoanAmt]
		,A.[Mtg2Lender] = B.[Mtg2Lender]
		,A.[Mtg2PrivateLender] = B.[Mtg2PrivateLender]
		,A.[Mtg2Term] = B.[Mtg2Term]
		,A.[Mtg2LoanDueDate] = B.Mtg2LoanDueDt
		,A.[Mtg2AdjRider] = B.[Mtg2AdjRider]
		,A.[Mtg2LoanType] = B.[Mtg2LoanType]
		,A.[Mtg2TypeFinancing] = B.[Mtg2TypeFinancing]
		,A.[Mtg2LienPosition] = B.[Mtg2LienPosition]
		,A.[Mtg3TransactionId] = B.[Mtg3TransactionId]
		,A.[Mtg3RecordingDate] = B.Mtg3RecordingDt
		,A.[Mtg3LoanAmt] = B.[Mtg3LoanAmt]
		,A.[Mtg3Lender] = B.[Mtg3Lender]
		,A.[Mtg3PrivateLender] = B.[Mtg3PrivateLender]
		,A.[Mtg3Term] = B.[Mtg3Term]
		,A.[Mtg3LoanDueDate] = B.Mtg3LoanDueDt
		,A.[Mtg3AdjRider] = B.[Mtg3AdjRider]
		,A.[Mtg3LoanType] = B.[Mtg3LoanType]
		,A.[Mtg3TypeFinancing] = B.[Mtg3TypeFinancing]
		,A.[Mtg3LienPosition] = B.[Mtg3LienPosition]
		,A.[Mtg4TransactionId] = B.[Mtg4TransactionId]
		,A.[Mtg4RecordingDate] = B.Mtg4RecordingDt
		,A.[Mtg4LoanAmt] = B.[Mtg4LoanAmt]
		,A.[Mtg4Lender] = B.[Mtg4Lender]
		,A.[Mtg4PrivateLender] = B.[Mtg4PrivateLender]
		,A.[Mtg4Term] = B.[Mtg4Term]
		,A.[Mtg4LoanDueDate] = B.Mtg4LoanDueDt
		,A.[Mtg4AdjRider] = B.[Mtg4AdjRider]
		,A.[Mtg4LoanType] = B.[Mtg4LoanType]
		,A.[Mtg4TypeFinancing] = B.[Mtg4TypeFinancing]
		,A.[Mtg4LienPosition] = B.[Mtg4LienPosition]
		,A.[IsListedFlag] = B.FAIsListedFlag
		,A.[IsListedFlagDate] = B.FAIsListedFlagDt
		,A.[flCommunityName] = B.CommunityName
		,A.[flCommunityNbr] = B.CommunityNumber
		,A.[flFemaMapNbr] = B.FemaMapNumber
		,A.[flFIRMID] = B.FIRMID
		,A.[flPanelNbr] = B.PanelNumber
		,A.[flInsideSFHA] = B.InsideSFHA
		,A.[flFemaFloodZone] = B.FemaFloodZone
		,A.[flFemaMapDate] = B.FemaMapDate
		,A.[HOA1Name] = B.HOA_1_Name
		--,A.[HOA1PropertyManagementName] = B.hoa
		,A.[HOA2Name] = B.HOA_2_Name
		--,A.[HOA2PropertyManagementName] = B.[HOA2PropertyManagementName]
		,A.[PFCFlag] = B.[PFCFlag]
		,A.[FinalValue] = B.DIRECT_FINAL_VALUE
		,A.[HighValue] = B.DIRECT_HIGH_VALUE
		,A.[LowValue] = B.DIRECT_LOW_VALUE
		,A.[ConfidenceScore] = B.DIRECT_CONFIDENCE_SCORE
		,A.[StandardDeviation] = B.DIRECT_FORECAST_STANDARD_DEVIATION
		,A.[ValuationDate] = B.Procision_ValuationDate


		--Select A.[INPUT Property ID], A.[Input Origination Date], A.[Input Origination Amount], A.[INPUT Mortgage Lien Position]
		--,A.[Recording Date], A.[Amount ], A.[FA Lien Position]
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID


		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.[HOA1PropertyManagementName] = B.HOA1CompanyName
		,A.[HOA2PropertyManagementName] = B.HOA2CompanyName
		
		--Select B.*
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a 
		JOIN [data].[dbo].[v_HOA_Fulfillment_NEW] as B with(NOLOCK) 
		on A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID
		

	



		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.Mtg1LoanType = B.CodeDesc
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] as A 
		join [global].[dbo].[lkup_Loan_Type] as B on 
		A.Mtg1LoanType = B.LoanTypeID

		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.Mtg2LoanType = B.CodeDesc
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] as A 
		join [global].[dbo].[lkup_Loan_Type] as B on 
		A.Mtg2LoanType = B.LoanTypeID

		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.Mtg3LoanType = B.CodeDesc
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] as A 
		join [global].[dbo].[lkup_Loan_Type] as B on 
		A.Mtg3LoanType = B.LoanTypeID

		Update [zCust_WesternAlliance].[dbo].[A]
		Set
		A.Mtg4LoanType = B.CodeDesc
		From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] as A 
		join [global].[dbo].[lkup_Loan_Type] as B on 
		A.Mtg4LoanType = B.LoanTypeID



		Select * from [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]

		


		--Update x_Custom_OUTPUT_S12 
		--SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		--Update x_Custom_OUTPUT_S12 
		--SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

	

		Update  [zCust_WesternAlliance].[dbo].[a]
		SET a.[AddressStandardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a JOIN [zCust_WesternAlliance].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Property ID] = b.Raw_ID

		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
		SET [Property Status] = CASE WHEN PROPERTYID is not null and PROPERTYID not like '0' THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_WesternAlliance].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12] a join [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Property ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		----20251114 - Per workorder - Event Found = Matched Input Property
	

		Update [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
		Set [Event Status] = case when [Property Status] like 'Property Found'  then 'Event Found' 
		else 'Event Not Found'  end
	


		

		Select [Property Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
		Group by [Property Status]
		
		Select [Event Status], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
		Group by [Event Status]

		
		
		
		--Select [Deed Coverage Status], count(*) From x_Custom_OUTPUT_S12
		--Group by [Deed Coverage Status]

		--Select [Mortgage Coverage Status], count(*) From x_Custom_OUTPUT_S12
		--Group by [Mortgage Coverage Status]
				
		
		Select [AddressStandardization], count(*) From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]
		Group by [AddressStandardization]

	


		Select top 1000 * From [zCust_WesternAlliance].[dbo].[x_Custom_OUTPUT_S12]


END



