/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | LEAP.LoadLeapNew | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[LEAP].[LoadLeapNew] 

AS

/*
Truncate table [Lien].[UR].[NAME_STD_ADDRESS]
if you need to re-de all
*/
EXEC [Lien].[LEAP].[AddLeapLog] N'info', N'LoadLeapNew', N'Started'

--
-- Reload Capture corrections
--
Declare @return_value int
EXEC	@return_value = [LEAP].[usp_Recapture_Rejects]

--
-- Load new data
--

/*IF object_id('Tempdb..#Date') IS NOT NULL
	*/
DROP TABLE IF EXISTS #Date;

SELECT a.*
	,ROW_NUMBER() OVER (
		PARTITION BY 0 ORDER BY  Created_Date
		) AS ROW4
INTO #date
FROM (
	SELECT DISTINCT Created_Date
	FROM [Lien].[LEAP].[LEAP] a
	) a
WHERE a.created_date NOT IN (
		SELECT Created_date
		FROM [Lien].[LEAP].[LeapImportDate]
		)

DECLARE @Created_Date DATETIME = NULL
DECLARE @i INT = 1
DECLARE @e INT = (
		SELECT TOP 1 ROW4
		FROM #date
		ORDER BY row4 DESC
		)

WHILE @i <= @e
BEGIN
	SET @Created_Date = (
			SELECT Created_Date
			FROM #Date
			WHERE row4 = @i
			)

	SELECT @Created_Date AS N'@Created_Date'

	SET @i = @i + 1

	EXEC @return_value = [LEAP].[usp_LeapDailyLoad] @Created_Date
END

EXEC [Lien].[LEAP].[AddLeapLog] N'info', N'LoadLeapNew', N'Ended'

