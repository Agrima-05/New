/* Source: AZUVNSQLDTDB003.datatree.local | assr | pet_dbo.usp_GET_DTDB_Tables | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

--CREATE
--	OR

CREATE PROCEDURE [Assr].[pet_dbo].[usp_GET_DTDB_Tables] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
[Execute SQL Task] Error: Executing the query "
DECLARE	@ERROR varchar(500)

EXEC	[assr].[pet_dbo..." failed with the following error: "Index 'idx_ref_id' on table 'ASSR.Pet_tmp.Pet_Ref_Ids' (specified in the FROM clause) does not exist.". Possible failure reasons: Problems with the query, "ResultSet" property not set correctly, parameters not set correctly, or connection not established correctly.

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	--EXEC PET.Pet_dbo.Add_Petlog N'info'
	--	,N'usp_GET_DTDB_Tables'
	--	,N'Started'
	--DECLARE @SQL VARCHAR(MAX)
	--	,@LinkSvr VARCHAR(100) = ''
	--SET @LinkSvr = CASE 
	--		WHEN @@SERVERNAME = N'AZUVPSQLDTDB007'
	--			THEN '[DWS-ETL02].'
	--		WHEN @@SERVERNAME = N'AZUVPSQLDTDB009'
	--			THEN '[DWS-ETL01].'
	--		WHEN @@SERVERNAME = N'AZUVPSQLDTDB029'
	--			THEN '[DWS-ETL01.DATATREE.LOCAL].'
	--		ELSE ''
	--		END
	--SELECT @LinkSvr
	DROP TABLE

	IF EXISTS [ASSR].[pet_tmp].[assr]
		SELECT r.fips
			,ar.ref_id
			,ar.UNFORMATTED_APN
			,ar.APN_SEQUENCE_NBR
			,ar.FORMATTED_APN AS [FORMATTED_APN]
			,ar.BLOCK_NBR
			,ar.LOT_NBR_1
			,ar.LOT_NBR_2
			,ar.LOT_NBR_3
			,ar.SUBDIV_TRACT_NBR
			,ar.SUBDIV_PLAT_BOOK
			,ar.SUBDIV_PLAT_PAGE
			,ar.SUBDIV_NAME
			,ar.EXTENDED_LEGAL_DESCRIPTION
			,ar.RANGE
			,ar.TOWNSHIP
			,ar.SECTION
			,ar.QUARTER_SECTION
			,ar.MUNICIPALITY_NAME
			,ar.MUNICIPALITY_CODE
			,ar.MAP_REFERENCE_1
			,ar.MAP_REFERENCE_2
			,ar.COUNTY_USE_CODE
			,ar.ORIGINAL_APN
			,ar.PREVIOUS_PARCEL_NBR
			,ar.P_ID_IRIS_FRMTD
			,ar.ALTERNATE_APN
			,ar.ACCOUNT_NBR
			,ar.Vendor_Original_Apn
			,ar.[SOURCE_type] AS [SOURCE]
			,a.SA_PROPERTY_ID AS [DQ_PROP_ID]
			,a.BK_PROP_ID AS [BK_PROP_ID]
		INTO [ASSR].[pet_tmp].[Assr]
		FROM [ASSR].[Pet_tmp].[Pet_Ref_Ids] r WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		LEFT JOIN [assr].[dbo].[assr] ar WITH (
				NOLOCK
				,INDEX (IDX_Assr_Ref_ID)
				) ON ar.ref_id = r.ref_id
		LEFT JOIN [Assr].[dbo].[PropertyReference] a WITH (
				NOLOCK
				,INDEX (PK_PropertyReference)
				) ON a.ref_id = ar.ref_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--select top 100 * from assr.dbo.assr
	CREATE CLUSTERED INDEX idx_fips_ref_id ON [ASSR].[pet_tmp].[Assr] (
		fips
		,ref_id
		)


	

		

	----DROP TABLE

	----IF EXISTS ASSR.pet_tmp.RT_Assessor
	----	SELECT R.SA_PROPERTY_ID
	----		,R.SA_PARCEL_NBR_PRIMARY
	----		,a.Fips
	----		,a.ref_id
	----		,a.UNFORMATTED_APN
	----	INTO ASSR.pet_tmp.RT_Assessor
	----	FROM ASSR.Pet_tmp.Pet_Ref_Ids a
	----	OUTER APPLY (
	----		SELECT /*a.fips
	----			,a.ref_id
	----			,a.UNFORMATTED_APN
	----			,*/ r.SA_PROPERTY_ID
	----			,r.SA_PARCEL_NBR_PRIMARY
	----		FROM /**/ ART.dbo.RT_Assessor R WITH (
	----				NOLOCK
	----				,INDEX (idx_fips_SA_PARCEL_NBR_PRIMARY)
	----				)
	----		WHERE R.FIPS = a.fips
	----			AND R.SA_PARCEL_NBR_PRIMARY = a.UNFORMATTED_APN
	----		) r
	----	OPTION (
	----		RECOMPILE
	----		,MAXDOP 12
	----		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	----		);

	------where a.ref_id = 34380861
	------create index idx_fips_SA_PARCEL_NBR_PRIMARY on ART.dbo.RT_Assessor (fips,SA_PARCEL_NBR_PRIMARY)
	----CREATE CLUSTERED INDEX idx_fips_ref_id ON ASSR.pet_tmp.RT_Assessor (
	----	FIPS
	----	,ref_id
	----	)

	DROP TABLE

	IF EXISTS [ASSR].[pet_tmp].[Assessor]
		SELECT DISTINCT ar.Fips
			,ar.ref_id
			,r.SA_PROPERTY_ID
			,r.SA_PARCEL_NBR_PRIMARY
		INTO [ASSR].[pet_tmp].[Assessor]
		FROM [ASSR].[Pet_tmp].[Pet_Ref_Ids] ar WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		INNER JOIN [Assr].[dbo].[PropertyReference] a WITH (
				NOLOCK
				,INDEX (PK_PropertyReference)
				) ON a.ref_id = ar.ref_id
		OUTER APPLY (
			SELECT /*a.fips
				,a.ref_id
				,*/ r.SA_PROPERTY_ID
				,SA_PARCEL_NBR_PRIMARY
			FROM [Assessor].[dbo].[Assessor] R WITH (
					NOLOCK
					,INDEX (Idx_Assessor_Clustered)
					)
			WHERE R.FIPS = a.fips
				AND R.SA_PROPERTY_ID = a.SA_PROPERTY_ID
			) r
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_fips_ref_id ON [ASSR].[pet_tmp].[Assessor] (
		fips
		,ref_id
		)

	DROP TABLE

	IF EXISTS [ASSR].[pet_tmp].[MD_Assessment]
		SELECT DISTINCT ar.Fips
			,a.REF_ID
			,bk.BK_PROP_ID
			,bk.APN
		INTO [ASSR].[pet_tmp].[MD_Assessment]
		FROM [ASSR].[Pet_tmp].[Pet_Ref_Ids] ar WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		INNER JOIN [Assr].[dbo].[PropertyReference] a WITH (
				NOLOCK
				,INDEX (PK_PropertyReference)
				) ON a.ref_id = ar.ref_id
		OUTER APPLY (
			SELECT bk.apn
				,bk.bk_prop_id
			/*,a.ref_id
				,a.fips*/
			FROM [ADB].[dbo].[MD_Assessment] bk WITH (
					NOLOCK
					,INDEX (IDX_BK_PROP_ID)
					)
			WHERE bk.CountyFips = a.fips
				AND bk.BK_PROP_ID = a.BK_PROP_ID
			) bk
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_fips_ref_id ON [ASSR].[pet_tmp].[MD_Assessment] (
		fips
		,ref_id
		)



	DROP TABLE

	IF EXISTS [ASSR].[pet_tmp].[CL_Address_Base]
		SELECT C.STD_StreetNumber AS [StreetNumber]
			,C.STD_PreDirection AS [Pre_Direction]
			,C.STD_StreetName AS [StreetName]
			,C.STD_Suffix AS [Street_Type]
			,C.STD_PostDirection AS [Post_Direction]
			,C.STD_UnitType AS [Unit_Type]
			,C.STD_Unit AS [Unit]
			,C.STD_City AS [City]
			,C.STD_State AS [State]
			,C.STD_Zip AS [Zip]
			,C.STD_Plus4 AS [Plus4]
			,a.FIPS AS FIPS
			,C.REF_ID AS REF_ID
			,c.AddressMatchResults
			,CASE 
				WHEN isnull(STD_StreetNumber, '') > ''
					THEN LTRIM(RTRIM(STD_StreetNumber)) + '~' + LTRIM(RTRIM(STD_PreDirection)) + '~' + LTRIM(RTRIM(STD_StreetName)) + '~' + LTRIM(RTRIM(STD_Suffix)) + '~' + LTRIM(RTRIM(STD_PostDirection)) + '~' + LTRIM(RTRIM(STD_UnitType)) + '~' + LTRIM(RTRIM(STD_Unit)) + '~' + LTRIM(RTRIM(STD_City)) + '~' + LTRIM(RTRIM(STD_State)) + '~' + LTRIM(RTRIM(STD_Zip)) + '~' + LTRIM(RTRIM(STD_Plus4))
				ELSE NULL
				END AS [Full_Address]
		INTO [ASSR].[pet_tmp].[CL_Address_Base]
		FROM [ASSR].[Pet_tmp].[Pet_Ref_Ids] a
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [Addr].[dbo].[CL_Address_Base] c WITH (
					NOLOCK
					,INDEX (Idx_FipsRefId)
					)
			WHERE c.fips = a.assr_fips
				AND c.ref_id = a.ref_id
				AND C.Address_Type = 'S'
			) c
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_fips_ref_id ON [ASSR].[pet_tmp].[CL_Address_Base] (
		Fips
		,ref_id
		)

	DROP TABLE

	IF EXISTS [assr].[tmp].[NOVACL_XREF_Name_Assr_incr]
		SELECT pr.ref_id
	,dn.Name_Id
	,dn.Last_Name
	,dn.First_Name
	,dn.Middle_Name
	,dn.Full_Name
	,dn.Name_Type
	,pr.fips
	,dn.Load_Date
	,dn.Suffix
	,dn.Raw_Name
	,dn.TranslatedFips


		INTO [assr].[tmp].[NOVACL_XREF_Name_Assr_incr]
		FROM [ASSR].[Pet_tmp].[Pet_Ref_Ids] pr WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		INNER JOIN [Novacl].[dbo].[NOVACL_XREF] nx WITH (
				NOLOCK
				,INDEX (Idx_RefID)
				) ON nx.ref_id = pr.ref_id
		OUTER APPLY (
			SELECT top 10 *
			FROM [Novacl].[dbo].[DIM_CLNAME] dn WITH (
					NOLOCK
					,INDEX (PK_NameId1)
					)
			WHERE dn.name_id = nx.name_id
			) dn
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);
			--	select * from Pet.[pet_tmp].[pet_daily_tracker]
			--EXEC PET.Pet_dbo.Add_Petlog N'info'
			--	,N'usp_GET_DTDB_Tables'
			--	,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

