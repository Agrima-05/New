/* Source: AZUVNSQLDTDB003.datatree.local | HOA | OA.MasterOAFees | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE Procedure [HOA].[OA].[MasterOAFees] AS
-- =============================================
-- Original Author:		Tim Dao
-- Create date: 02/14/2016
-- Description:	Calculate Best OA Fee, and reputable Min/Max Fee range per owner association and fee type
-- ChangeLog: 06/10/2016 - Improved Fee Mastering to include frequencies and better ranges
--			  07/13/2016 - Fee match fix on NULL frequency or type
--		      08/14/2017 - Fixing Fee logic
--			   2/26/2019 - Query Optimization
--			   8/19/2019 - HOA Fees should not link to Shell/NA
--			   9/11/2019 - HOA Fee occurence score will be counted by *source* records instead of ref_ids + Major outlier fee filter
--             10/4/2019 - HOA fee analysis will propertly ignore soft deleted/orphaned properties
--            10/15/2019 - HOA Fee hotfix
--		      01/25/2023 - Global Fee Outlier Enhancement
-- =============================================
Truncate Table OA.OwnerAssociationFee


/*IF OBJECT_ID('tempdb..#FeeOutlierGlobal') IS NOT NULL
	*/
DROP TABLE IF EXISTS #FeeOutlierGlobal;
With Amount_Calc_g AS (
Select SourceId, SourcePK, Amount, Amount_Calc, FeeTypeId, FeeFrequencyId From (
SELECT 
	 oaf.SourceId
	, oaf.sourcePK
	, oaf.FeeTypeId
	, oaf.FeeFrequencyId
	, oaf.Amount
	, Case When FeeFrequencyId = 1 THEN Amount When (ISNULL(FeeFrequencyId, 2) = 2) THEN AMOUNT * 12 WHEN FeeFrequencyId = 3 THEN AMOUNT * 4 WHEN FeeFrequencyId = 4 THEN Amount * 2 END as Amount_Calc
	, ROW_NUMBER() over (partition by SourceId, SourcePK order by oaf.Id) rownum
FROM [HOA].[Staging].[OwnerAssociationFee] oaf
) G 
Where rownum = 1 
),
Amount_Calc AS (
Select OwnerAssociationId, SourceId, SourcePK, Amount, Amount_Calc, FeeTypeId, FeeFrequencyId From (
SELECT oap.OwnerAssociationId
	, oaf.SourceId
	, oaf.sourcePK
	, oaf.FeeTypeId
	, oaf.FeeFrequencyId
	, oaf.Amount
	, Case When FeeFrequencyId = 1 THEN Amount When (ISNULL(FeeFrequencyId, 2) = 2) THEN AMOUNT * 12 WHEN FeeFrequencyId = 3 THEN AMOUNT * 4 WHEN FeeFrequencyId = 4 THEN Amount * 2 END as Amount_Calc
	, ROW_NUMBER() over (partition by oap.OwnerAssociationId, SourceId, SourcePK order by oaf.Id) rownum
FROM [HOA].[Staging].[OwnerAssociationFee] oaf
INNER JOIN [HOA].[OA].[OwnerAssociationProperty] oap ON oaf.REF_ID = oap.REF_ID and oap.StatusId NOT IN (3, 6)
INNER JOIN [HOA].[OA].[OwnerAssociation] oa ON oa.Id = oap.OwnerAssociationId and (oaf.OwnerAssociationId = oa.StagingId or oaf.OwnerAssociationId IS NULL)--and oa.Id = 707980
	
WHERE oa.StatusId NOT IN (
		3
		,6
		)
	AND oa.Name <> 'SHELL|N/A'
	AND (oa.OwnerAssociationTypeId IS NULL OR oa.OwnerAssociationTypeId IN (1, 2, 3))--Only calculate fee if valid and not a doc or managing agency
) G 
Where rownum = 1 
)

Select f.SourceId, f.SourcePK 
INTO #FeeOutlierGlobal
from Amount_Calc_g f INNER JOIN (
Select * from (
       SELECT
              FeeTypeId,
			  (max(ThirdQuartile) - max(FirstQuartile)) * 3.0 + max(ThirdQuartile) as UpperOutlierPoint, 
			  max(FirstQuartile) - ((max(ThirdQuartile) - max(FirstQuartile)) * 3.0) as LowerOutlierPoint
       FROM
              (
              SELECT FeeTypeId,
                     percentile_disc(0.75) within group (order by Amount_Calc) over(Partition By FeeTypeId) as ThirdQuartile,
                     percentile_disc(0.25) within group (order by Amount_Calc) over(Partition By FeeTypeId) as FirstQuartile
              FROM Amount_Calc	
			  Group by FeeTypeId, Amount_Calc
       ) quartiles
	   Group by FeeTypeId
	  ) x where UpperOutlierPoint <> LowerOutlierPoint
) G on f.FeeTypeId = g.FeeTypeId 
and f.Amount_Calc not between LowerOutlierPoint and UpperOutlierPoint
UNION 
Select DISTINCT f.SourceId, f.SourcePK 
from Amount_Calc f INNER JOIN (
Select * from (
       SELECT
              OwnerAssociationId, FeeTypeId,
			  (max(ThirdQuartile) - max(FirstQuartile)) * 3.0 + max(ThirdQuartile) as UpperOutlierPoint, 
			  max(FirstQuartile) - ((max(ThirdQuartile) - max(FirstQuartile)) * 3.0) as LowerOutlierPoint
       FROM
              (
              SELECT OwnerAssociationId, FeeTypeId,
                     percentile_disc(0.75) within group (order by Amount_Calc) over(Partition By OwnerAssociationId, FeeTypeId) as ThirdQuartile,
                     percentile_disc(0.25) within group (order by Amount_Calc) over(Partition By OwnerAssociationId, FeeTypeId) as FirstQuartile
              FROM Amount_Calc	
			  Group by OwnerAssociationId, FeeTypeId, Amount_Calc
       ) quartiles
	   Group by OwnerAssociationId, FeeTypeId
	  ) x where UpperOutlierPoint <> LowerOutlierPoint
) G on f.OwnerAssociationId = g.OwnerAssociationId and f.FeeTypeId = g.FeeTypeId 
and f.Amount_Calc not between LowerOutlierPoint and UpperOutlierPoint

/*IF OBJECT_ID('tempdb..#TEMP2') IS NOT NULL
	*/
DROP TABLE IF EXISTS #TEMP2

SELECT oap.OwnerAssociationId
	,ISNULL(oaf.FeeTypeId, 5) as FeeTypeId
	,oaf.FeeFrequencyId
	,MIN(oaf.SourceId) AS SourceId
	,(count(DISTINCT oaf.SourcePK) * 4 * (Case When oaf.SourceId = 11 THEN 2 ELSE 1 END) - ISNULL(DateDiff(month, ISNULL(RecordingDate, ProcessDate - 1825), getdate()+ Case When oaf.FeeFrequencyId IS NULL THEN 720 ELSE 0 END), 60)) AS CurrencyOccurScore
	,DENSE_RANK() OVER (
		PARTITION BY oap.OwnerAssociationId
		,ISNULL(FeeTypeId, 5) ORDER BY CASE 
				WHEN oaf.SourceId = 11
					THEN 0
				WHEN oaf.SourceId = 5
					THEN 1
				WHEN oaf.SourceId = 6
					THEN 2
				END
		) AS DenseRank
INTO #TEMP2
FROM [HOA].[Staging].[OwnerAssociationFee] oaf
INNER JOIN [HOA].[OA].[OwnerAssociationProperty] oap ON oaf.REF_ID = oap.REF_ID and oap.StatusId NOT IN (3, 6)
INNER JOIN [HOA].[OA].[OwnerAssociation] oa ON oa.Id = oap.OwnerAssociationId and (oaf.OwnerAssociationId = oa.StagingId or oaf.OwnerAssociationId IS NULL)--and oa.Id = 707980
LEFT JOIN #FeeOutlierGlobal fx on fx.SourceId = oaf.SourceId and fx.SourcePK = oaf.SourcePK
WHERE oa.StatusId NOT IN (
		3
		,6
		)
	AND oa.Name <> 'SHELL|N/A'
	AND (oa.OwnerAssociationTypeId IS NULL OR oa.OwnerAssociationTypeId IN (1, 2, 3))--Only calculate fee if valid and not a doc or managing agency
	and fx.SourcePK IS NULL
GROUP BY oap.OwnerAssociationId
	,oaf.SourceId
	,oaf.FeeTypeId
	,oaf.FeeFrequencyId
	,DateDiff(month, ISNULL(RecordingDate, ProcessDate - 1825), getdate()+ Case When oaf.FeeFrequencyId IS NULL THEN 720 ELSE 0 END)

/*IF OBJECT_ID('tempdb..#TEMP3') IS NOT NULL
*/
DROP TABLE IF EXISTS #TEMP3

SELECT OwnerAssociationId
		,FeeTypeId
		,FeeFrequencyId
		,SourceId
		,ROW_NUMBER() OVER (
			PARTITION BY OwnerAssociationId
			,FeeTypeId ORDER BY MAX(CurrencyOccurScore) DESC, Case When FeeFrequencyId = 2 THEN 0 ELSE FeeFrequencyId END 
			) AS Ranking
	INTO #TEMP3
	FROM #TEMP2 R
	WHERE DenseRank = 1
	--And FeeFrequencyId <> 2
	GROUP BY R.OwnerAssociationId
		,R.FeeTypeId
		,R.FeeFrequencyId
		,R.SourceId

/*IF OBJECT_ID('tempdb..#TEMP2') IS NOT NULL
	*/
DROP TABLE IF EXISTS #TEMP2

/*IF OBJECT_ID('tempdb..#TEMP') IS NOT NULL
	*/
DROP TABLE IF EXISTS #TEMP

Create Table #TEMP
(
	Id int not null,
	Amount numeric(16,2) not null,
	SourceId tinyint not null,
	FeeTypeId tinyint not null,
	FeeFrequencyId tinyint null,
	CurrencyOccurScore int not null,
	LastRecordingDate datetime2(3) not null,
	Ranking int not null,
	PRIMARY KEY(Id, FeeTypeId, Ranking)
)

Insert Into #TEMP
Select *, ROW_NUMBER() OVER (PARTITION By Id, FeeTypeId Order by CurrencyOccurScore DESC, LastRecordingDate DESC, Case When FeeFrequencyId = 2 THEN 0 ELSE FeeFrequencyId END) as Ranking
From (
SELECT oa.Id, CASE 
              WHEN oaf.SourceId = 6 --ROUND ACI values
                     THEN CASE WHEN ROUND(oaf.Amount, - 2) = 0 THEN 50 ELSE ROUND(oaf.Amount, - 2) END 
					 ELSE oaf.Amount END as Amount
					 ,oaf.SourceId, ISNULL(oaf.FeeTypeId, 5) as FeeTypeId, oaf.FeeFrequencyId
,(count(DISTINCT oaf.SourcePK) * 4 * (Case When oaf.SourceId = 11 THEN 2 When oaf.FeeFrequencyId IS NULL THEN 0.5 ELSE 1 END) - ISNULL(DateDiff(month, ISNULL(RecordingDate, ProcessDate - 1825), getdate() + Case When oaf.FeeFrequencyId IS NULL THEN 720 ELSE 0 END), 60)) AS CurrencyOccurScore
, max(oaf.RecordingDate) as LastRecordingDate
FROM [HOA].[Staging].[OwnerAssociationFee] oaf
INNER JOIN [HOA].[OA].[OwnerAssociationProperty] oap ON oaf.REF_ID = oap.REF_ID and oap.StatusId NOT IN (3, 6)
INNER JOIN [HOA].[OA].[OwnerAssociation] oa ON oa.Id = oap.OwnerAssociationId and (oaf.OwnerAssociationId = oa.StagingId or oaf.OwnerAssociationId IS NULL)--and oa.Id = 707980
INNER JOIN #TEMP3 X ON x.Ranking = 1
	AND x.OwnerAssociationId = oap.OwnerAssociationId
	AND oa.Name <> 'SHELL|N/A'
	AND (
		(x.FeeFrequencyId = oaf.FeeFrequencyId OR (x.FeeFrequencyId IS NULL AND oaf.FeeFrequencyId IS NULL))
		AND x.FeeTypeId = ISNULL(oaf.FeeTypeId, 5)
		)
	AND x.SourceId = oaf.SourceId
LEFT JOIN #FeeOutlierGlobal fx on fx.SourceId = oaf.SourceId and fx.SourcePK = oaf.SourcePK
Where fx.SourcePK IS NULL
GROUP BY  oa.Id, oaf.Amount, oaf.SourceId, oaf.FeeTypeId, oaf.FeeFrequencyId,DateDiff(month, ISNULL(RecordingDate, ProcessDate - 1825), getdate()+ Case When oaf.FeeFrequencyId IS NULL THEN 720 ELSE 0 END)
) R2 

/*IF OBJECT_ID('tempdb..#TEMP3') IS NOT NULL
	*/
DROP TABLE IF EXISTS #TEMP3

Insert Into [HOA].[OA].[OwnerAssociationFee]
Select OwnerAssociationId, Amount
, NullIf(MinAmount, MaxAmount) as MinAmount
, NullIf(MaxAmount, MinAmount) as MaxAmount
, ISNULL(FeeTypeId, 5) as FeeTypeId
, FeeFrequencyId 
, CurrencyOccurScore
, LastRecordingDate
from (
select t.Id as OwnerAssociationId, SUM(Case When t.Ranking = 1 THEN t.Amount END) as Amount, MIN(t.Amount) as MinAmount, Max(t.Amount) As MaxAmount, t.FeeTypeId, t.FeeFrequencyId, MAX(CurrencyOccurScore) as CurrencyOccurScore, MAX(LastRecordingDate) as LastRecordingDate
from #TEMP t 
WHERE EXISTS (Select 1 From #TEMP t2 where t.Amount between t2.Amount / 2 and t2.Amount * 2.5
and t.CurrencyOccurScore >= t2.CurrencyOccurScore - 15
and t2.Ranking = 1 and t.Id = t2.Id and t.FeeTypeId = t2.FeeTypeId)
Group by t.Id, t.FeeTypeId, t.FeeFrequencyId
)
R

