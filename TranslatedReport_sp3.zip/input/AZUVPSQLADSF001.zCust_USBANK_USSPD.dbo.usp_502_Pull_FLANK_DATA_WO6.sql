SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








-- =============================================
-- Create date: 20151215
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_USBANK_USSPD].[dbo].[usp_502_Pull_FLANK_DATA_WO6] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_USBANK_USSPD].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,[TitleCompanyName]
		,[CMTIDInstNbr]
		,CMTID

		INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_DEEDS]
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.DeedTransactionType = t.TransType
		where A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES

		IF  EXISTS (SELECT * FROM [zCust_USBANK_USSPD].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower,LenderName AS SellerLender,LoanAmount
		,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] 
		,[CMTIDInstNbr]
		,CMTID
		,case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as Borrower1FullName
		,case when Borrower2FullName is null then Borrower2CompanyName else Borrower2FullName end as Borrower2FullName
		INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_MTG]
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.LoanTransType = t.TransType
		where A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,Loan1RecordingDt,Loan1Document,Loan1Book,Loan1Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan1LenderName AS SellerLender,Loan1Amount
		,'MG'--Loan1DocumentTypeCode
		,'MG'--d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] 
		,[Loan1CMTIDInstNbr]
		,Loan1CMTID 
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as Borrower1FullName
		,CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END as Borrower2FullName
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		AND A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt 


		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,Loan2RecordingDt,Loan2Document,Loan2Book,Loan2Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan2LenderName AS SellerLender,Loan2Amount
		--,Loan2DocumentTypeCode,d.CodeDesc as DocType
		,'MG'--Loan1DocumentTypeCode
		,'MG'--d.CodeDesc as DocType
		,Loan2TransactionType,t.CodeDesc as TransType 
		, 'M' as DocSrcInd,[ChronoKey] 
		,[Loan2CMTIDInstNbr]
		,Loan2CMTID
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as Borrower1FullName
		,CASE WHEN Buyer2FullName is NULL THEN Buyer2CompanyName ELSE Buyer2FullName END as Borrower2FullName
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.Loan2DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.Loan2TransactionType Like t.TransType
		WHERE Loan2RecordingDt is not null
		AND A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt 

		----ASSIGN/REL

		IF  EXISTS (SELECT * FROM [zCust_USBANK_USSPD].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt, 'A' as DocSrcInd,[ChronoKey] 
		,[CMTIDInstNbr]
		,CMTID
		,OrigLoanCMTIDInstNbr
		,left((Replace(Replace((case when charindex(':',assignee) >0 then Substring([Assignee],1,(Charindex(':',[Assignee])-1)) when charindex(';',assignee) >0 then Substring([Assignee],1,(Charindex(';',[Assignee])-1)) when charindex(',',assignee) >0 then Substring([Assignee],1,(Charindex(',',[Assignee])-1)) else assignee end),',',' '),'.','')),60) as NewLenderName
		,left((Replace(Replace((case when charindex(':',[AssignorName]) >0 then Substring([AssignorName],1,(Charindex(':',[AssignorName])-1)) when charindex(';',[AssignorName]) >0 then Substring([AssignorName],1,(Charindex(';',[AssignorName])-1)) when charindex(',',[AssignorName]) >0 then Substring([AssignorName],1,(Charindex(',',[AssignorName])-1)) else [AssignorName] end),',',' '),'.','')),60) as OriginalLenderName
		,case when Borrower1FullNameSTd is null then  BorrowerFullName else Borrower1FullNameSTd end as Borrower1FullName
		,case when Borrower2FullNameSTd is null then  NULL else Borrower2FullNameSTd end as Borrower2FullName
		INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		WHERE A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt

		

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt, 'R' as DocSrcInd,[ChronoKey] 
		,[CMTIDInstNbr]
		,CMTID
		,OrigLoanCMTIDInstNbr
		,NULL as NewLenderName
		,left(Replace(Replace([OrigLenderBen],',',''),'.',''),60) as OriginalLenderName
		,case when Borrower1FullNameSTd is null then  BorrowerFullName else Borrower1FullNameSTd end as Borrower1FullName
		,case when Borrower2FullNameSTd is null then  NULL else Borrower2FullNameSTd end as Borrower2FullName
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		WHERE A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt


		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_USBANK_USSPD].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType
		INTO [zCust_USBANK_USSPD].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_USBANK_USSPD].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		WHERE A.FAUCIDFLAG not like 'D'
		ORDER BY RAW_ID,RecordingDt


		---- CREATE TransHist 

		TRUNCATE TABLE w_TransHist_FLANK

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			   ,OrigLoanAmount
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,FA_BookPageFmt
			  ,FA_DocNbrFmt)
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentTypeCode]
			  ,CASE WHEN [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is not null THEN BkPgFrmt 
					when [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is null and DocNbrSrce is not null then DocNbrSrce
					when [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is null and DocNbrSrce is null and BookSrce is not null 
								then SUBSTRING(BookSrce, PATINDEX('%[^0]%', BookSrce+'.'), LEN(BookSrce)) + '.' + 
								 SUBSTRING(BookSrce, PATINDEX('%[^0]%', PageSrce+'.'), LEN(PageSrce))
					when [CMTIDInstNbr] is null and DocNbrFrmt is not null then DocNbrFrmt
					when [CMTIDInstNbr] is not null then [CMTIDInstNbr] ELSE [CMTIDInstNbr] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,CMTID
			  ,NULL
			  ,TransactionID
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  --,BookSrce + '.' + PageSrce
			  ,BkPgFrmt
			  ,DocNbrFrmt
		FROM [zCust_USBANK_USSPD].[dbo].[w_FLANK_DEEDS]

		

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			   ,OrigLoanAmount
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey] 
			  ,FA_BookPageFmt
			  ,FA_DocNbrFmt
			  ,Borrower1FullName
			  ,Borrower2FullName)
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,case when ISNULL([DocumentTypeCode],'') like '' then 'MORTGAGE' else  [DocumentTypeCode] end 
			   --,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,CASE WHEN [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is not null THEN BkPgFrmt 
					when [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is null and DocNbrSrce is not null then DocNbrSrce
					when [CMTIDInstNbr] is null and DocNbrFrmt is null and BkPgFrmt is null and DocNbrSrce is null and BookSrce is not null 
								then SUBSTRING(BookSrce, PATINDEX('%[^0]%', BookSrce+'.'), LEN(BookSrce)) + '.' + 
								 SUBSTRING(BookSrce, PATINDEX('%[^0]%', PageSrce+'.'), LEN(PageSrce))
					when [CMTIDInstNbr] is null and DocNbrFrmt is not null then DocNbrFrmt
					when [CMTIDInstNbr] is not null then [CMTIDInstNbr] ELSE [CMTIDInstNbr] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,CMTID
			  ,NULL
			  ,TransactionID
			  ,[DocSrcInd]
			  ,NULL
			  ,case when ISNULL([DocType],'') like '' then 'MORTGAGE' else  [DocType] end
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  --,BookSrce + '.' + PageSrce
			  ,BkPgFrmt
			   ,DocNbrFrmt
			   ,Borrower1FullName
			   ,Borrower2FullName
		     FROM [zCust_USBANK_USSPD].[dbo].[w_FLANK_MTG]


		
		

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			   ,OrigLoanAmount
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			   ,FA_BookPageFmt
			   ,FA_DocNbrFmt
			   ,OldLenderAssignor
			   ,NewLenderAssignee
			   ,Borrower1FullName
			  ,Borrower2FullName)
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentType]
			  --,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			   ,LEFT(CASE WHEN [CMTIDInstNbr] is null and DocNbrFrmt is NULL THEN BkPgFrmt 
					when [CMTIDInstNbr] is null and DocNbrFrmt is not null then DocNbrFrmt
					when [CMTIDInstNbr] is not null then [CMTIDInstNbr] ELSE [CMTIDInstNbr] END,250)
			   ,left([BuyerBorrower],250)
			  ,NULL
			  ,NULL
			  ,OrigDeedRecordingDt
			  ,OrigLoanAmt
			  ,case 
				when ISNULL(OrigLoanCMTIDInstNbr,'') like '' and  OrigDeedDocNbr is null then OrigDeedBook + '.' + OrigDeedPage 
				When ISNULL(OrigLoanCMTIDInstNbr,'') like '' and ISNULL(OrigDeedDocNbr,'') not like '' then OrigDeedDocNbr
			  else OrigLoanCMTIDInstNbr end
			  ,NULL
			  ,CMTID
			  ,NULL
			  ,TransactionID
			  ,'R'
			  ,NULL
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			   --,BookSrce + '.' + PageSrce
			  ,BkPgFrmt
			   ,DocNbrFrmt
			   ,left(OriginalLenderName,250)
			   ,left(NewLenderName,250)
			   ,left(Borrower1FullName,250)
			  ,left(Borrower2FullName,250)
		FROM [zCust_USBANK_USSPD].[dbo].[w_FLANK_ASR]

		

		INSERT INTO [zCust_USBANK_USSPD].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,OrigLoanAmount
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			   ,FA_BookPageFmt
			   ,FA_DocNbrFmt)
		SELECT FIPS
			  ,FAPropertyID
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentType]
			   --,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			   ,CASE WHEN [CMTIDInstNbr] is null and DocNbrFrmt is NULL THEN BkPgFrmt 
					when [CMTIDInstNbr] is null and DocNbrFrmt is not null then DocNbrFrmt
					when [CMTIDInstNbr] is not null then [CMTIDInstNbr] ELSE [CMTIDInstNbr] END
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigLoanAmt
			   --, OrigLoanCMTIDInstNbr 
			    ,case 
				when ISNULL(OrigLoanCMTIDInstNbr,'') like '' and  Loan_FA_DocNbrFmt is null then LoanDocumentNbr
				When ISNULL(OrigLoanCMTIDInstNbr,'') like '' and ISNULL(Loan_FA_DocNbrFmt,'') not like '' then Loan_FA_DocNbrFmt
			  else OrigLoanCMTIDInstNbr end
			  ,NULL
			  ,CMTID
			  ,NULL
			  ,TransactionID
			  ,'P'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  --,BookSrce + '.' + PageSrce
			  ,BkPgFrmt
			   ,DocNbrFrmt
			FROM [zCust_USBANK_USSPD].[dbo].[w_FLANK_NOD]

		
		


		UPDATE [zCust_USBANK_USSPD].[dbo].[a] 
		set a.propertyID = b.propertyID
		FROM [zCust_USBANK_USSPD].[dbo].[w_transHist_Flank] a JOIN [zCust_USBANK_USSPD].[dbo].[a_propMatch_work] b
		on convert(int,a.Fips) = convert(int,b.Fips)
		and a.RAW_ID = b.RAW_ID

		
		UPDATE [zCust_USBANK_USSPD].[dbo].[a] 
		set a.REF_ID = b.REF_ID
		FROM [zCust_USBANK_USSPD].[dbo].[w_transHist_Flank] a JOIN [zCust_USBANK_USSPD].[dbo].[a_propMatch_work] b
		on convert(int,a.Fips) = convert(int,b.Fips)
		and a.RAW_ID = b.RAW_ID



END




