/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.Add_match_Log | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

 create   PROCEDURE [Pet_Match_service].[pet_mtc].[Add_match_Log] @Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [pet_Match_Service].[pet_mtc].[Match_log] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

