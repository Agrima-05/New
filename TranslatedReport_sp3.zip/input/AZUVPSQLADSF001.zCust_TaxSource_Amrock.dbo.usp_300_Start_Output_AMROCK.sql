SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_TaxSource_Amrock].[dbo].[usp_300_Start_Output_AMROCK]


AS
BEGIN
	
	SET NOCOUNT ON;

	

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
		[Id][int]NULL,
		[BatchId][int]NULL,
		[ExternalKey][varchar](10)NULL,
		[PropertyId][varchar](4000)NULL,
		[ReportName][varchar](4000)NULL,
		[ReportStatus][varchar](4000)NULL,
		[ReferenceId][varchar](4000)NULL,
		[OrderItemId][varchar](4000)NULL,
		[StreetAddress][varchar](4000)NULL,
		[City][varchar](4000)NULL,
		[State][varchar](4000)NULL,
		[Zip9][varchar](4000)NULL,
		[County][varchar](4000)NULL,
		[APN][varchar](4000)NULL,
		[StateFips][varchar](4000)NULL,
		[CountyFips][varchar](4000)NULL,
		[ReportAsOfDate][varchar](30)NULL,
		[AssessorsAlternateParcelIdentifier][varchar](4000)NULL,
		[ExtendedLegalDescription][varchar](4000)NULL,
		[LandUse][varchar](4000)NULL,
		[TraCode][varchar](4000)NULL,
		[TraName][varchar](4000)NULL,
		[OwnerNames][varchar](4000)NULL,
		[Errors][varchar](2000)NULL,
		[Message][varchar](4000)NULL,
		[Agency1_MismoAgencyCode][varchar](4000)NULL,
		[Agency1_Name][varchar](4000)NULL,
		[Agency1_AgencyType][varchar](4000)NULL,
		[Agency1_TaxCollectorUrl][varchar](4000)NULL,
		[Agency1_PhoneNumber][varchar](4000)NULL,
		[Agency1_FaxNumber][varchar](4000)NULL,
		[Agency1_Email][varchar](4000)NULL,
		[Agency1_MakePayableTo][varchar](4000)NULL,
		[Agency1_StreetAddress][varchar](4000)NULL,
		[Agency1_CityStateZip][varchar](4000)NULL,
		[Agency1_MailingStreet][varchar](4000)NULL,
		[Agency1_MailingCityStateZip][varchar](4000)NULL,
		[Agency1_TaxYearType][varchar](4000)NULL,
		[Agency1_TaxYearDates][varchar](4000)NULL,
		[Agency1_CurrentTaxYear][varchar](4000)NULL,
		[Agency1_CollectsInArrears][varchar](4000)NULL,
		[Agency1_DiscountAgency][varchar](4000)NULL,
		[Agency1_DuplicateBillRequired][varchar](4000)NULL,
		[Agency1_DuplicateBillFee][varchar](4000)NULL,
		[Agency1_ExternalAgencyNotes][varchar](4000)NULL,
		[TaxDetails_AsOfDate][varchar](30)NULL,
		[TaxDetails_SchoolDistrict][varchar](4000)NULL,
		[TaxDetails_TaxId][varchar](4000)NULL,
		[TaxDetails_DelinquentTaxes][varchar](4000)NULL,
		[TaxDetails_TaxReportStatus][varchar](4000)NULL,
		[TaxDetails_DelinquencyTaxSaleYear][varchar](4000)NULL,
		[TaxYear][varchar](4000)NULL,
		[TaxType][varchar](4000)NULL,
		[TaxSupplementalAPN][varchar](4000)NULL,
		[TotalTax][varchar](4000)NULL,
		[ImprovementValue][varchar](4000)NULL,
		[LandVal][varchar](4000)NULL,
		[AssessedTotalValue][varchar](4000)NULL,
		[AssessedYear][varchar](4000)NULL,
		[ExemptionType][varchar](4000)NULL,
		[ExemptionAmount][varchar](4000)NULL,
		[NetVal][varchar](4000)NULL,
		[CertificateOfPurchase][varchar](4000)NULL,
		[TaxInstallmentsMessage][varchar](4000)NULL,
		[TaxBillNumber][varchar](4000)NULL,
		[InstallmentDetail1_SequenceId][varchar](4000)NULL,
		[InstallmentDetail1_Amount][varchar](4000)NULL,
		[InstallmentDetail1_Status][varchar](4000)NULL,
		[InstallmentDetail1_PaymentDate][varchar](30)NULL,
		[InstallmentDetail1_AmountDue][varchar](4000)NULL,
		[InstallmentDetail1_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail1_DueDate][varchar](30)NULL,
		[InstallmentDetail1_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail1_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail1_DiscountDate][varchar](30)NULL,
		[InstallmentDetail1_Penalty][varchar](4000)NULL,
		[InstallmentDetail1_Interest][varchar](4000)NULL,
		[InstallmentDetail2_SequenceId][varchar](4000)NULL,
		[InstallmentDetail2_Amount][varchar](4000)NULL,
		[InstallmentDetail2_Status][varchar](4000)NULL,
		[InstallmentDetail2_PaymentDate][varchar](30)NULL,
		[InstallmentDetail2_AmountDue][varchar](4000)NULL,
		[InstallmentDetail2_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail2_DueDate][varchar](30)NULL,
		[InstallmentDetail2_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail2_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail2_DiscountDate][varchar](30)NULL,
		[InstallmentDetail2_Penalty][varchar](4000)NULL,
		[InstallmentDetail2_Interest][varchar](4000)NULL,
		[InstallmentDetail3_SequenceId][varchar](4000)NULL,
		[InstallmentDetail3_Amount][varchar](4000)NULL,
		[InstallmentDetail3_Status][varchar](4000)NULL,
		[InstallmentDetail3_PaymentDate][varchar](30)NULL,
		[InstallmentDetail3_AmountDue][varchar](4000)NULL,
		[InstallmentDetail3_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail3_DueDate][varchar](30)NULL,
		[InstallmentDetail3_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail3_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail3_DiscountDate][varchar](30)NULL,
		[InstallmentDetail3_Penalty][varchar](4000)NULL,
		[InstallmentDetail3_Interest][varchar](4000)NULL,
		[InstallmentDetail4_SequenceId][varchar](4000)NULL,
		[InstallmentDetail4_Amount][varchar](4000)NULL,
		[InstallmentDetail4_Status][varchar](4000)NULL,
		[InstallmentDetail4_PaymentDate][varchar](30)NULL,
		[InstallmentDetail4_AmountDue][varchar](4000)NULL,
		[InstallmentDetail4_PartialPayAmt][varchar](4000)NULL,
		[InstallmentDetail4_DueDate][varchar](30)NULL,
		[InstallmentDetail4_DelinquentDate][varchar](30)NULL,
		[InstallmentDetail4_EstimatedAmountGoodThrough][varchar](30)NULL,
		[InstallmentDetail4_DiscountDate][varchar](30)NULL,
		[InstallmentDetail4_Penalty][varchar](4000)NULL,
		[InstallmentDetail4_Interest][varchar](4000)NULL,
		[OtherTaxDetails1_TaxYear][varchar](4000)NULL,
		[OtherTaxDetails1_TaxType][varchar](4000)NULL,
		[OtherTaxDetails1_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails1_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails1_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails1_TaxBillNumber][varchar](4000)NULL,
		[OtherTaxDetails2_TaxYear][varchar](4000)NULL,
		[OtherTaxDetails2_TaxType][varchar](4000)NULL,
		[OtherTaxDetails2_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails2_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails2_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails2_TaxBillNumber][varchar](4000)NULL,
		[OtherTaxDetails3_TaxYear][varchar](4000)NULL,
		[OtherTaxDetails3_TaxType][varchar](4000)NULL,
		[OtherTaxDetails3_TaxSupplementalAPN][varchar](4000)NULL,
		[OtherTaxDetails3_TotalTax][varchar](4000)NULL,
		[OtherTaxDetails3_CertificateOfPurchase][varchar](4000)NULL,
		[OtherTaxDetails3_TaxBillNumber][varchar](4000)NULL,
		[AdditionalOtherTaxDetails][varchar](1)NULL,
		[RedemptionDetails1_Amount][varchar](4000)NULL,
		[RedemptionDetails1_RedemptionDate][varchar](30)NULL,
		[RedemptionDetails1_PaymentGoodThrough][varchar](30)NULL,
		[RedemptionDetails2_Amount][varchar](4000)NULL,
		[RedemptionDetails2_RedemptionDate][varchar](30)NULL,
		[RedemptionDetails2_PaymentGoodThrough][varchar](30)NULL,
		[RedemptionDetails3_Amount][varchar](4000)NULL,
		[RedemptionDetails3_RedemptionDate][varchar](30)NULL,
		[RedemptionDetails3_PaymentGoodThrough][varchar](30)NULL

			
			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		

	   INSERT INTO [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	   SELECT 
		A.ID,
		A.BatchId,
		ExternalKey,
		PropertyId,
		ReportName,
		ReportStatus,
		ReferenceId,
		OrderItemId,
		StreetAddress,
		A.City,
		A.State,
		A.Zip9,
		A.County,
		A.APN,
		StateFips,
		CountyFips,
		ReportAsOfDate,
		AssessorsAlternateParcelIdentifier,
		ExtendedLegalDescription,
		LandUse,
		TraCode,
		TraName,
		OwnerNames,
		convert(varchar(2000),Errors) as Errors,
		Message,
		Agency1_MismoAgencyCode,
		Agency1_Name,
		Agency1_AgencyType,
		Agency1_TaxCollectorUrl,
		Agency1_PhoneNumber,
		Agency1_FaxNumber,
		Agency1_Email,
		Agency1_MakePayableTo,
		Agency1_StreetAddress,
		Agency1_CityStateZip,
		Agency1_MailingStreet,
		Agency1_MailingCityStateZip,
		Agency1_TaxYearType,
		Agency1_TaxYearDates,
		Agency1_CurrentTaxYear,
		Agency1_CollectsInArrears,
		Agency1_DiscountAgency,
		Agency1_DuplicateBillRequired,
		Agency1_DuplicateBillFee,
		Agency1_ExternalAgencyNotes,
		TaxDetails_AsOfDate,
		TaxDetails_SchoolDistrict,
		TaxDetails_TaxId,
		TaxDetails_DelinquentTaxes,
		TaxDetails_TaxReportStatus,
		TaxDetails_DelinquencyTaxSaleYear,
		TaxYear,
		TaxType,
		TaxSupplementalAPN,
		TotalTax,
		ImprovementValue,
		LandVal,
		AssessedTotalValue,
		AssessedYear,
		ExemptionType,
		ExemptionAmount,
		NetVal,
		CertificateOfPurchase,
		TaxInstallmentsMessage,
		TaxBillNumber,
		InstallmentDetail1_SequenceId,
		InstallmentDetail1_Amount,
		InstallmentDetail1_Status,
		InstallmentDetail1_PaymentDate,
		InstallmentDetail1_AmountDue,
		InstallmentDetail1_PartialPayAmt,
		InstallmentDetail1_DueDate,
		InstallmentDetail1_DelinquentDate,
		InstallmentDetail1_EstimatedAmountGoodThrough,
		InstallmentDetail1_DiscountDate,
		InstallmentDetail1_Penalty,
		InstallmentDetail1_Interest,
		InstallmentDetail2_SequenceId,
		InstallmentDetail2_Amount,
		InstallmentDetail2_Status,
		InstallmentDetail2_PaymentDate,
		InstallmentDetail2_AmountDue,
		InstallmentDetail2_PartialPayAmt,
		InstallmentDetail2_DueDate,
		InstallmentDetail2_DelinquentDate,
		InstallmentDetail2_EstimatedAmountGoodThrough,
		InstallmentDetail2_DiscountDate,
		InstallmentDetail2_Penalty,
		InstallmentDetail2_Interest,
		InstallmentDetail3_SequenceId,
		InstallmentDetail3_Amount,
		InstallmentDetail3_Status,
		InstallmentDetail3_PaymentDate,
		InstallmentDetail3_AmountDue,
		InstallmentDetail3_PartialPayAmt,
		InstallmentDetail3_DueDate,
		InstallmentDetail3_DelinquentDate,
		InstallmentDetail3_EstimatedAmountGoodThrough,
		InstallmentDetail3_DiscountDate,
		InstallmentDetail3_Penalty,
		InstallmentDetail3_Interest,
		InstallmentDetail4_SequenceId,
		InstallmentDetail4_Amount,
		InstallmentDetail4_Status,
		InstallmentDetail4_PaymentDate,
		InstallmentDetail4_AmountDue,
		InstallmentDetail4_PartialPayAmt,
		InstallmentDetail4_DueDate,
		InstallmentDetail4_DelinquentDate,
		InstallmentDetail4_EstimatedAmountGoodThrough,
		InstallmentDetail4_DiscountDate,
		InstallmentDetail4_Penalty,
		InstallmentDetail4_Interest,
		OtherTaxDetails1_TaxYear,
		OtherTaxDetails1_TaxType,
		OtherTaxDetails1_TaxSupplementalAPN,
		OtherTaxDetails1_TotalTax,
		OtherTaxDetails1_CertificateOfPurchase,
		OtherTaxDetails1_TaxBillNumber,
		OtherTaxDetails2_TaxYear,
		OtherTaxDetails2_TaxType,
		OtherTaxDetails2_TaxSupplementalAPN,
		OtherTaxDetails2_TotalTax,
		OtherTaxDetails2_CertificateOfPurchase,
		OtherTaxDetails2_TaxBillNumber,
		OtherTaxDetails3_TaxYear,
		OtherTaxDetails3_TaxType,
		OtherTaxDetails3_TaxSupplementalAPN,
		OtherTaxDetails3_TotalTax,
		OtherTaxDetails3_CertificateOfPurchase,
		OtherTaxDetails3_TaxBillNumber,
		AdditionalOtherTaxDetails,
		RedemptionDetails1_Amount,
		RedemptionDetails1_RedemptionDate,
		RedemptionDetails1_PaymentGoodThrough,
		RedemptionDetails2_Amount,
		RedemptionDetails2_RedemptionDate,
		RedemptionDetails2_PaymentGoodThrough,
		RedemptionDetails3_Amount,
		RedemptionDetails3_RedemptionDate,
		RedemptionDetails3_PaymentGoodThrough
		--Select * 
		FROM [TaxSourceAPI].[dbo].[OutputLayout1] as A with(NOLOCK)
		join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
		and A.ExternalKey = B.UniqueID
		where B.DATE_COMPLETED is null
	

		Select BATCHID,count(*) as TOTAL From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
		Group by BATCHID

		Select count(*) as TOTAL From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
		

	  
	  Select * From [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT]
	  

	  UPdate [zCust_TaxSource_Amrock].[dbo].[A]
	  Set A.DATE_COMPLETED = (Select format(getdate(),'yyyyMMddHHmm'))
	  From  [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[x_Custom_OUTPUT] as B on 
	  A.UniqueID = B.[ExternalKey]


	  Insert into [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED]
	  Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
	  where DATE_COMPLETED is not null

	  Select * From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED]


	  Delete from [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR]
	  --Select * 
	  From [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR] as A 
	  join [zCust_TaxSource_Amrock].[dbo].[INPUT_MONITOR_COMPLETED] as B on 
	  A.UniqueID = B.UniqueID
	  and A.BatchID = B.BatchID

	 	
		
		

END





