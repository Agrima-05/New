SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_FIND_MONTHLY_RUN] 
	
AS
BEGIN
		
		
		Truncate table dbo.FIND_MONTHLY_RUN_DATE

		Insert into [zCust_OS_National].[dbo].[FIND_MONTHLY_RUN_DATE]
		Select top 1  convert(varchar(10),[CalendarDate],112) as 'FIFTHOFMONTH' 
		--into dbo.FIND_MONTHLY_RUN_DATE
		FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc


		Select * From [zCust_OS_National].[dbo].[FIND_MONTHLY_RUN_DATE]

		



END


