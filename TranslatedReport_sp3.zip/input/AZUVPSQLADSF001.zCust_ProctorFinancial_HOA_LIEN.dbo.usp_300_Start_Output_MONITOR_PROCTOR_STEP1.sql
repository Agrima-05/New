SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_300_Start_Output_MONITOR_PROCTOR_STEP1]

AS
BEGIN
	
	SET NOCOUNT ON;

	
		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [varchar](250) NULL,
			[INPUTCustomerID] [varchar](250) NULL,
			[INPUTKey] [varchar](250) NULL,
			[INPUTAddress] [varchar](250) NULL,
			[INPUTCity] [varchar](250) NULL,
			[INPUTState] [varchar](250) NULL,
			[INPUTZip] [varchar](250) NULL,
			[INPUTAPN] [varchar](250) NULL,
			[INPUTBORROWER] [varchar](250) NULL,
			
			[PropertyAddress] [varchar](250) NULL,
			[City] [varchar](250) NULL,
			[State] [varchar](250) NULL,
			[ZipCode] [varchar](250) NULL,

			------20190221 - Added per NH-NOTE - THIS IS REF_ID - NOT PROPERTYID--
			
			[PROPERTYID] [bigint] NULL,
			[FREEBIE] [varchar](1) NULL,

			
			---------VERIFY-----
			--[InCoverage] [varchar](250) NULL,
			---------------------

			[AddressStandardization] [varchar](250) NULL,
			[PropertyStatus] [varchar](250) NULL,

			[AddressMatch] [varchar](250) NULL,

			[CountyName] [varchar](250) NULL,

			-----Verify----
			[Prioritization] [varchar](250) NULL,
			[SuperLienState] [varchar](250) NULL,
			[LastDocTypeRecorded] [varchar](250) NULL,
			[DaysSinceRecording] [varchar](250) NULL,



			[RunDate] [varchar](250) NULL,
			[MonitorBeginDate] [varchar](250) NULL,

			------------------REMOVE FROM CLIENT OUTPUT------
			[MAX_LIENDATE] [varchar](250) NULL,
			[MAX_NODDATE] [varchar](250) NULL,
			--[OWNERSTDNAME1FULL] [varchar](250) NULL,
			[PROPERTYID_INT] [bigint] NULL,

			--------------------------------------------------

			[CoverageStatus_HOA_LIEN] [varchar](250) NULL,
			[CoverageStatus_PREFC] [varchar](250) NULL,
			[CoverageStatus_PREFCBeginDate] [varchar](250) NULL,
			[CoverageStatus_PREFCEndDate] [varchar](250) NULL,
			[CoverageStatus_HOALienBeginDate] [varchar](250) NULL,
			[CoverageStatus_HOALienEndDate] [varchar](250) NULL,
			------20190221 - Added per NH---
		

			[HAS_HOA_RECORD] [varchar](2) NULL,

			
			[EventStatus] [varchar](250) NULL,
			[OWNERSTDNAME1FULL] [varchar](250) NULL,

			[Owner Borrower Match][varchar](1) NULL,

			------------PER NH 20180604 - Providing HOA 1 Contact 1 info ONLY-----
			[HOA_Name] [varchar](250) NULL,
			[HOA_Type] [varchar](250) NULL,
			[HOA_Contact_Name] [varchar](250) NULL,
			[HOA_Address_Mailing] [varchar](250) NULL,
			[HOA_City_Mailing] [varchar](250) NULL,
			[HOA_State_Mailing] [varchar](250) NULL,
			[HOA_Zip_Mailing] [varchar](250) NULL,
			[HOA_Contact_Phone] [varchar](250) NULL,
			[HOA_Contact_Email] [varchar](255) NULL,
			[HOA_Fee_Value][varchar](255) NULL,
			[HOA_Fee_Minimum_Value][varchar](255) NULL,
			[HOA_Fee_Maximum_Value][varchar](255) NULL,
			[HOA_Fee_Type][varchar](255) NULL,
			[HOA_Fee_Frequency][varchar](255) NULL,

			
			[Number_of_HOA_Liens] [int] NULL,
			[Number_of_HOA_Liens_RELEASED] [int] NULL,
			[NbrofRecordings][int] NULL,
			[NbrofRecordings_NOD_NOS][int] NULL,
			[NbrofRecordings_RELEASED][int] NULL


		) ON [PRIMARY]


		
		/****** Object:  Index [NonClusteredIndex-20200131-124816]    Script Date: 1/31/2020 12:48:39 PM ******/
		CREATE NONCLUSTERED INDEX [NonClusteredIndex-20200131-124816] ON [dbo].[x_Custom_OUTPUT]
		(
			[FIPS] ASC,
			[WORK_REF_ID] ASC,
			[PROPERTYID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		


		

		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] ([FIPS],WORK_REF_ID,[INPUTCustomerID],[INPUTKEY],INPUTAddress,INPUTCity,INPUTState,INPUTzip,[INPUTAPN],[INPUTBORROWER],[MonitorBeginDate]
		,[MAX_LIENDATE],[MAX_NODDATE],[OWNERSTDNAME1FULL],[PROPERTYID_INT],[PROPERTYID])
		Select [FIPS],[REF_ID],[CUSTOMERID],[INPUTKEY]   ,[INPUTADDRESS]   ,[INPUTCITY]   ,[INPUTSTATE]   ,[INPUTZIP] ,[INPUTAPN],[INPUTBORROWERNAME],DATE_ADDED
		,[MAX_LIENDATE],[MAX_NODDATE],[OWNERSTDNAME1FULL],[PROPERTYID],REF_ID
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as A 
		
		Select DATE_ADDED, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR]
		Group by DATE_ADDED
		Order by DATE_ADDED
		--Update x_Custom_OUTPUT
		--Set PROPERTYID = WORK_REF_ID


		--Select  count(*) FROm x_Custom_OUTPUT
		--where [INPUTCustomerID] is null or [INPUTCustomerID] like ''
		

		--Select  PropertyStatus, count(*) FROm x_Custom_OUTPUT
		--where [PROPERTYID] is null or [PROPERTYID] like '' or [PROPERTYID] like '0'
		--Group by PropertyStatus

		
		--Select COUNT(*) From x_Custom_OUTPUT
		--where 
		--[INPUTCITY] like '%  %' 

		--Select COUNT(*) From x_Custom_OUTPUT
		--where 
		--[INPUTADDRESS] like '%  %' 
		
		
		
		--Select * From x_Custom_OUTPUT
	
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.PropertyAddress = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.ZipCode = c.Zip + c.Zip4
		, a.RunDate = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKey] = c.RAW_ID

		--------Persist Original matches---
		--Update a
		--SET a.PropertyAddress = c.PropertyAddress
		--, a.City = c.City
		--, a.[State] = c.[State]
		--, a.ZipCode = c.ZipCode
		--, a.RunDate = convert(date,GetDate())
		----, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		----Select *
		--FROM x_Custom_OUTPUT a JOIN zzz_Proctor_20190213_OUTPUT c
		--			ON a.[INPUTKey] = c.[INPUTKey]
		--where C.PropertyAddress is not null and C.PropertyAddress not like ''
		--and A.PropertyAddress is null


		--Select count(*) From x_Custom_OUTPUT
		--where PropertyAddress is null or PropertyAddress like ''

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.FIPS = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] c
					ON a.[INPUTKey] = c.RAW_ID
		where A.FIPS IS NULL
		and c.FIPS not like '0'

		
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.FIPS = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--Select A.FIPS, A.INPUTKEY, A.INPUTSTATE,C.* 
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKey] = c.RAW_ID
		where A.FIPS IS NULL
		and c.FIPS not like '0'
		

		IF (Select count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where FIPS is null or FIPS like '0' or FIPS like '') > 0

			BEGIN
			Select count(*) as NO_FIPS From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
			where FIPS is null or FIPS like '0' or FIPS like ''
			END

			Select *  From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
			where FIPS is null or FIPS like '0' or FIPS like ''



		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set 
		A.[PROPERTYID_INT] = B.[PROPERTYID]
		,A.[OWNERSTDNAME1FULL] = B.[OWNERSTDNAME1FULL]
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.[INPUTKey] = B.[INPUTKey]
		where B.[PROPERTYID] is not null


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[SuperLienState] = 'Y'
		--Select * 
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A 
		join 
		(Select distinct left(FIPSCODE,2) as FIPS FROM [HOALIEN].[dbo].[SuperLienStates]
		Group by left(FIPSCODE,2))
		as B on 
		LEFT(A.FIPS,2) = B.FIPS

		


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		Set [CoverageStatus_PREFC] = NULL

		
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[CoverageStatus_PREFC] = B.P_Flag
		,A.[CoverageStatus_PREFCBeginDate] = convert(date,B.P_Min_date)
		,A.[CoverageStatus_PREFCEndDate] = convert(date,B.P_Max_Date)
		--Select * 
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a 
		JOIN [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] b  with(NOLOCK)
			ON convert(int,a.FIPs) = b.FIPs


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[CoverageStatus_PREFC] = case when A.[CoverageStatus_PREFC] is null and B.ForeclosureActive = 1 then B.ForeclosureActive else  A.[CoverageStatus_PREFC] end 
		,A.[CoverageStatus_PREFCBeginDate] = case when convert(date,A.[CoverageStatus_PREFCBeginDate]) > convert(date,B.ForeclosureMinREcordDate) then convert(date,B.ForeclosureMinREcordDate)
		else convert(date,A.[CoverageStatus_PREFCBeginDate]) end
		,A.[CoverageStatus_PREFCEndDate] = case when convert(date,A.[CoverageStatus_PREFCEndDate]) < convert(date,B.ForeclosureMaxREcordDate) then convert(date,B.ForeclosureMaxREcordDate)
		else convert(date,A.[CoverageStatus_PREFCEndDate]) end
		,A.[CountyName] = REPLACE(B.[County Name],' County','')
		--Select B.* 
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a 
		JOIN [Global].[dbo].[COunty] as B on 
		A.FIPS = B.FIPSCODE
		

		--Select * From x_Custom_OUTPUT
		--where 
		--FIPS is null or FIPS like '0' or FIPS like ''

		--Select B.DATE_ADDED, A.* From x_Custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKey = B.INPUTKEY
		--where 
		--WORK_REF_ID is null or WORK_REF_ID like '0' or WORK_REF_ID like ''

		

		-------------Coverage is HOA Lien Per NH 20180320--
		------------------Per NH - 20180403 - Use Doc Image Coverage report where restriction is NOT "No images-live acquisition "----
		------------Per NH 20180504 - Yes for the 1333. We need to determine where we can & cannot collect data. We collect data in doc image counties. 
		------Update a
		------set [CoverageStatus_HOA_LIEN] = 'Y'
		--------Select * 
		------FROM x_Custom_OUTPUT a 
		--------where a.FIPs IN
		--------(
		--------Select [Fips] from 
		--------	(SELECT [Fips], count(*) as TOTAL
		--------	FROM [HOA].[dbo].[HOA_Lien] with(NOLOCK)
		--------	Group by FIPS) as A
		--------)
		------join [xKLowe].[dbo].[DOC_IMAGE_COVERAGE_20180403] as B on A.FIPS = B.FIPS
		------where B.[Restrictions]  not like 'No images-live acquisition'



		--------------------20181218 - KL - Per NH - USE ACTUAL DATA TO SET COVERAGE-----------------
		
		--Update a
		--set [CoverageStatus_HOA_LIEN] = 'Y'
		----Select * 
		--FROM x_Custom_OUTPUT a 
		--where a.FIPs IN
		--(
		--Select [Fips] from 
		--	(SELECT [Fips], count(*) as TOTAL
		--	FROM [HOA].[dbo].[HOA_Lien] with(NOLOCK)
		--	Group by FIPS) as A
		--)

		------------------20190321 - Per NH - Use FirstAm_HOA Lien Coverage_190220.xlsx report to set In Coverage for HOA Lien!!!----------
		-------Imported report as [HOA_LIEN_COVERAGE_20190321]
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		set [CoverageStatus_HOA_LIEN] = 'Y'
		--Select * 
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_COVERAGE_PER_NH_20190321] as B on 
		A.FIPS = B.FIPS
		

		

		----Added 20180629 - Using Min Max REcording date from HOA Lien data---
		-------20190322 - Per NH - Ignore future recording dates----
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		set 
		A.[CoverageStatus_HOALienBeginDate] = convert(date,B.MIN_DATE)
		,A.[CoverageStatus_HOALienEndDate] = convert(date,B.MAX_DATE)
		--Select * 
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a 
		join (Select FIPS, convert(date,convert(varchar(10),MIN(REcordingDate))) as MIN_DATE
		,convert(date,convert(varchar(10),MAX(REcordingDate))) as MAX_DATE
		 From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
		 where convert(date,convert(varchar(10),(REcordingDate))) < Getdate()
		Group by FIPS)
		 as B on A.FIPS = B.FIPS
		 ------added 20180703 per NH - do not populate begin & end dates when no doc images---
		 AND [CoverageStatus_HOA_LIEN] like 'Y'




		------------------OVERWRITE ASP address with SITUS ADDRESS PER NH--20180604---------
		Set CONCAT_NULL_YIELDS_NULL OFF
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.PropertyAddress = rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim(substring(SITUS_HOUSE_NBR, patindex('%[^0]%',SITUS_HOUSE_NBR), 10)))
		+' '+ltrim(rtrim(SITUS_HOUSE_NBR_SUFFIX)))
		+' '+ltrim(rtrim(SITUS_DIRECTION)))
			+' '+ltrim(rtrim(substring(SITUS_STREET_NAME, patindex('%[^0]%',SITUS_STREET_NAME), 50)))
				+' '+ltrim(rtrim(SITUS_MODE)))
					+' '+ltrim(rtrim(SITUS_QUADRANT)))
						+' '+ltrim(rtrim(substring(SITUS_UNIT_NBR, patindex('%[^0]%',SITUS_UNIT_NBR), 10))))
		, a.City = SITUS_CITY
		, a.[State] = SITUS_STATE
		, a.ZipCode = SITUS_ZIP_CODE
		--Select *
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Assr] c
					ON a.WORK_REF_ID = c.REF_ID
		WHERE a.WORK_REF_ID is NOT NULL
		


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		Set [Owner Borrower Match] = 

		--Select INputborrower
		--,case when charindex(' ',REverse(INputborrower)) = 0 then INputborrower else  right(INputborrower,charindex(' ',REverse(INputborrower))-1)
		--end
		--,OwnerStdName1Full,
		case when OwnerStdName1Full like '%' + left(INputborrower,3) + '%' OR
		INputborrower like '%' + left(OwnerStdName1Full,3) + '%' then 'Y' else 'N' end
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		--Order by case when OwnerStdName1Full like '%' + left(INputborrower,3) + '%' OR
		--INputborrower like '%' + left(OwnerStdName1Full,3) + '%' then 'Y' else NULL end
		
		
	


		--------------------------Populate HOA Data -----------------
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set 
		[HOA_Name]= [HOA 1- Name]
      ,[HOA_Type]= [HOA 1 - Type]
      ,[HOA_Contact_Name] = [HOA 1- Contact Name 1]
      ,[HOA_Address_Mailing]= [HOA 1- Address (Mailing)  1]
      ,[HOA_City_Mailing]= [HOA 1- City (Mailing) 1]
      ,[HOA_State_Mailing] = [HOA 1- State (Mailing) 1]
      ,[HOA_Zip_Mailing]= [HOA 1- Zip (Mailing)  1]
      ,[HOA_Contact_Phone] = HOA1_Contact_Business_Phone_1
      ,[HOA_Contact_Email] = [HOA 1- Contact Email 1]
      ,[HOA_Fee_Value]= [HOA 1- Fee Value]
      ,[HOA_Fee_Minimum_Value]= [HOA 1- Fee Minimum Value]
      ,[HOA_Fee_Maximum_Value] = [HOA 1- Fee Maximum Value]
      ,[HOA_Fee_Type] = [HOA 1- Fee Type]
      ,[HOA_Fee_Frequency]= [HOA 1 - Fee Frequency]
	 --Select * 
	  FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [DATA].[dbo].[HOA_Fulfillment] as B with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.Work_REF_ID = b.REF_ID 
		where A.Work_REF_ID is not null 
		AND (A.[HAS_HOA_RECORD] is null or A.[HAS_HOA_RECORD]  like '')

		


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set HAS_HOA_RECORD = 'Y'
		where 
		(
			(HOA_Name is not null and  HOA_Name not like '')
			OR
			(HOA_Type is not null and  HOA_Type not like '')
			OR
			(HOA_Contact_Name is not null and  HOA_Contact_Name not like '')
			OR
			(HOA_Address_Mailing is not null and  HOA_Address_Mailing not like '')
			OR
			(HOA_City_Mailing is not null and  HOA_City_Mailing not like '')
			OR
			(HOA_State_Mailing is not null and  HOA_State_Mailing not like '')
			OR
			(HOA_Zip_Mailing is not null and  HOA_Zip_Mailing not like '')
		)
		AND (HAS_HOA_RECORD is null or HAS_HOA_RECORD like '')



		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set 
		[HOA_Name]= [HOA 1- Name]
      ,[HOA_Type]= [HOA 1 - Type]
      ,[HOA_Contact_Name] = [HOA 1- Contact Name 1]
      ,[HOA_Address_Mailing]= [HOA 1- Address (Mailing)  1]
      ,[HOA_City_Mailing]= [HOA 1- City (Mailing) 1]
      ,[HOA_State_Mailing] = [HOA 1- State (Mailing) 1]
      ,[HOA_Zip_Mailing]= [HOA 1- Zip (Mailing)  1]
      ,[HOA_Contact_Phone] = HOA1_Contact_Business_Phone_1
      ,[HOA_Contact_Email] = [HOA 1- Contact Email 1]
      ,[HOA_Fee_Value]= [HOA 1- Fee Value]
      ,[HOA_Fee_Minimum_Value]= [HOA 1- Fee Minimum Value]
      ,[HOA_Fee_Maximum_Value] = [HOA 1- Fee Maximum Value]
      ,[HOA_Fee_Type] = [HOA 1- Fee Type]
      ,[HOA_Fee_Frequency]= [HOA 1 - Fee Frequency]
	 --Select * 
	  FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [DATA].[dbo].[HOA_Fulfillment] as B with(NOLOCK)
		on a.FIPS = b.FIPS
		and  A.PropertyID = B.PropertyID
		where  A.PropertyID is not null
		AND (A.[HAS_HOA_RECORD] is null or A.[HAS_HOA_RECORD]  like '')


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set HAS_HOA_RECORD = 'Y'
		where 
		(
			(HOA_Name is not null and  HOA_Name not like '')
			OR
			(HOA_Type is not null and  HOA_Type not like '')
			OR
			(HOA_Contact_Name is not null and  HOA_Contact_Name not like '')
			OR
			(HOA_Address_Mailing is not null and  HOA_Address_Mailing not like '')
			OR
			(HOA_City_Mailing is not null and  HOA_City_Mailing not like '')
			OR
			(HOA_State_Mailing is not null and  HOA_State_Mailing not like '')
			OR
			(HOA_Zip_Mailing is not null and  HOA_Zip_Mailing not like '')
		)
		AND (HAS_HOA_RECORD is null or HAS_HOA_RECORD like '')


	Select HAS_HOA_RECORD, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
	Group by HAS_HOA_RECORD
	
	
		-------20200131 - One time
		--Update A
		--Set 
		--A.[HOA_Name] = B.[HOA_Name]
		--,A.   [HOA_Type] = B.   [HOA_Type]
		--,A.   [HOA_Contact_Name]  = B.   [HOA_Contact_Name] 
		--,A.   [HOA_Address_Mailing] = B.   [HOA_Address_Mailing]
		--,A.   [HOA_City_Mailing] = B.   [HOA_City_Mailing]
		--,A.   [HOA_State_Mailing]  = B.   [HOA_State_Mailing] 
		--,A.   [HOA_Zip_Mailing] = B.   [HOA_Zip_Mailing]
		--,A.   [HOA_Contact_Phone]  = B.   [HOA_Contact_Phone] 
		--,A.   [HOA_Contact_Email]  = B.   [HOA_Contact_Email] 
		--,A.   [HOA_Fee_Value] = B.   [HOA_Fee_Value]
		--,A.   [HOA_Fee_Minimum_Value] = B.   [HOA_Fee_Minimum_Value]
		--,A.   [HOA_Fee_Maximum_Value]  = B.   [HOA_Fee_Maximum_Value] 
		--,A.   [HOA_Fee_Type]  = B.   [HOA_Fee_Type] 
		--,A.   [HOA_Fee_Frequency] = B.   [HOA_Fee_Frequency]

	 ----Select * 
	 -- FROM x_Custom_OUTPUT a JOIN dbo.USE_20200131 as B with(NOLOCK)
		--on a.FIPS = b.FIPS
		--and A.INPUTKEY = B.INPUTKEY



		

		


	
		--Select * From x_custom_OUTPUT


		--Select A.HAS_HOA_RECORD, B.HAS_HOA_RECORD From dbo.USE_20200131 as A 
		--join x_custom_OUTPUT as B  on A.INPUTKEY = B.INPUTKEY
		--where A.HAS_HOA_RECORD <> B.HAS_HOA_RECORD

	

		Update [HOA].[dbo].[HOA_LIEN]
		Set DocType = 'HASLRL'
		where DocumentID = '557640' 

		Update [HOA].[dbo].[HOA_LIEN]
		Set DocType = 'HASL'
		where DocumentID = '4839064' 

		Update [HOA].[dbo].[HOA_LIEN]
		Set DocType = 'HALNRL'
		where DocumentID = '2018.0927.2267'

		Update [HOA].[dbo].[HOA_LIEN]
		Set DocType = 'SLE'
		where DocumentID = '2018.1001.3935'


		Update [HOA].[dbo].[HOA_LIEN]
		Set OAREference = '2017.0623.101'
		where DocumentID = '2018.1003.1565'


		Update [HOA].[dbo].[HOA_LIEN]
		Set OAREference = '2008.1112.1129'
		where DocumentID = '2018.1003.1677'


		Update [HOA].[dbo].[HOA_LIEN]
		Set OAREference = '2016.1005.1464'
		where DocumentID = '2017.1208.304'


		---------------------------------GET HOA LIENS---------------------------------

		EXEC [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN]
		EXEC [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_SUP]

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA]
		where REF_ID = '29309903'
		OR INPUTKEY = '0580380017 7274510'


		Select A.REF_ID,A.DocumentID, A.IsHOALienActive, A.DocType
		,C.INPUTKEY, C.WORK_REF_ID ,C.InputAddress ,B.FullStreetAddress, B.REF_ID, B.PROPERTYID
	
		FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
		on A.REF_ID = B.REF_ID
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
		where 
		--A.REF_ID = '29309903'
		--OR 
		INPUTKEY = '0580380017 7274510'

		Select INPUTKEY, INPUTADDRESS, PROPERTYID, REF_ID From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = '0580380017 7274510'
		Select FIPS, WORK_REF_ID,  PROPERTYID_INT From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] where INPUTKEY = '0580380017 7274510'
		--Select FIPS, PropertyID, DTDB_Ref_ID, SitusStdFullStreetAddress From data.dbo.Property with(NOLOCK) 
		--where PropertyID in ('28080295','28080322')
		--OR DTDB_Ref_ID in ('26679431','29309903')

		Select RAW_ID, FullStreetAddress, REF_ID, PropertyID From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK]
		where RAW_ID = '0580380017 7274510'


		Select IsHoaLienActive, * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK)
		where REF_ID = '29309903'
		and IsHoaLienActive = 1 and OWNSequence = 1
		Order by REcordingDate 

		Select FIPS, REF_ID, Lic_PropertyID, SITUS_HOUSE_NBR, SITUS_STREET_NAME, SITUS_UNIT_NBR From [Assr].[dbo].[Assr]
		where REF_ID in ('29309903','26679431')

		Select FIPS, PropertyID, DTDB_Ref_ID, SitusStdFullStreetAddress From [data].[dbo].[Property] with(NOLOCK)
		where PropertyID = '28080295'
		OR DTDB_REF_ID in ('29309903','26679431')

		Select FIPS, WORK_REF_ID, PROPERTYID_INT, INPUTAddress, INPUTKey From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where PropertyID = '28080295'
		OR WORK_REF_ID in ('29309903','26679431')

		Select FIPS, REF_ID, INPUTKEY From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
		where REF_ID = '29309903'
		OR INPUTKEY = '0580380017 7274510'

		Select INPUTKEY, INPUTADDRESS, REF_ID, PROPERTYID, DATE_ADDED, MAX_LIENDATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR]
		where INPUTKEY = '0580380017 7274510'

		
		Select A.*, C.State, C.[County Name] From [Data].[dbo].[HOA_Lien_Sup] as A with(NOLOCK)
		 join [Assr].[dbo].[Assr] as B with(NOLOCK) on A.LIC_PRopertyID = B.LIC_PRopertyID
		 join [global].[dbo].[county] as C with(NOLOCK) on A.FipsCode = C.FIPSCode
		where B.REF_ID = '29309903'
		Order by REcordingDt 
	

		Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA]
		where DocumentID = '2016.1128.1634'

		Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
		where Fmt_NMD_document_number = '2018.745006'

		Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
		where Fmt_NMD_document_number = '2018.4865806'
		
	

		Truncate table HOA_LIEN_DATA_II

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
		Select DISTINCT A.[ID],A.[Fips],A.[REF_ID]--A.[NEW_REF_ID]
		,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],
A.[RecordingYear],A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],
A.[NOD_NOS_Recorded_Document_Number],A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],
A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],
A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],
A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],
A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],
A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],
A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],
A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],
A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],
A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],
A.[LAW_Std_State],A.[LAW_Std_Zip],A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],A.[INPUTKEY],A.[RecordNumber],A.SUP

		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA] as A join 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on 
		a.INPUTKEY = b.INPUTKEY
		where (convert(date,convert(varchar(10),A.RecordingDate)) > convert(date,B.[MAX_LIENDATE])
		OR B.[MAX_LIENDATE] is null)
		--and DocumentId not like '2018.09.25.1112'


		--Select * From HOA_LIEN_DATA where REF_ID = '19601048'
		--Select * From HOA_LIEN_SUP as A  
		-- join Assr.dbo.Assr as B with(NOLOCK) on A.LIC_PRopertyID = B.LIC_PRopertyID
		--where B.REF_ID = '19601048'
		--Order by REcordingDt Desc
		--Select * From HOA_LIEN_DATA_II where REF_ID = '19601048'
		

		--Select * From HOA_LIEN_DATA_II
		--Select * From HOA_LIEN_SUP


		--ALTER TABLE HOA_LIEN_DATA_II ADD [SUP][varchar](1)NULL

		--Select * From HOA_LIEN_DATA_II


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[DocumentId]      ,[DocType]     
      ,[RecordingDate]      ,[LienAmount]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      
       ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState],INPUTKEY,RECORDNUMBER,[SUP],HOANAME)
		Select DISTINCT LIC_PROPERTYID      ,convert(int,[FipsCode])       ,A.[REF_ID]		,LIC_PROPERTYID		,LIC_PROPERTYID      ,[Fmt_NMD_document_number]      ,[DetailDocumentType]
      , convert(varchar(10),[RecordingDt])           ,A.[LienAmount]      ,[Owner1LastName]      ,[Owner1FirstName]      ,[Owner1MiddleName]      ,[Owner2FirstName]      ,[Owner2MiddleName]   
	     ,[SitusStdFullStreetAddress]      ,[SitusStdZIP5]      ,[SitusStdCity]      ,[SitusStdState]      ,[FormattedAPN]      ,[SitusStdFullStreetAddress]      ,[SitusStdZIP5]      ,[SitusStdCity]
      ,[SitusStdState]	  ,A.INPUTKEY,A.RECORDNUMBER
	  ,'Y'
	  ,Assn1NameFull

	  --Select A.*
	 -- charindex('.',REVERSE([Fmt_NMD_document_number])),[Fmt_NMD_document_number]
	 -- ,(case when charindex('.',REVERSE([Fmt_NMD_document_number])) > 0 then right([Fmt_NMD_document_number],charindex('.',REVERSE([Fmt_NMD_document_number]))-1)
		--else [Fmt_NMD_document_number] end)
		--From HOA_LIEN_SUP as A join 
		--x_Custom_OUTPUT as B on 
		--a.INPUTKEY = b.INPUTKEY
		--right outer join HOA_LIEN_DATA_II as C on  convert(varchar(10),A.[RecordingDt]) = C.REcordingDate 
		--AND C.[DocumentId] like '%' + (case when charindex('.',REVERSE(A.[Fmt_NMD_document_number])) > 0 then right(A.[Fmt_NMD_document_number],charindex('.',REVERSE(A.[Fmt_NMD_document_number]))-1)
		--else A.[Fmt_NMD_document_number] end) + '%' 
		--where 
		--(convert(date,convert(varchar(10),A.[RecordingDt])) > convert(date,B.[MAX_LIENDATE])
		--OR B.[MAX_LIENDATE] is null)
		--AND A.[Fmt_NMD_document_number] is null

		
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A join 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on 
		a.INPUTKEY = b.INPUTKEY
		left outer join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] as C on  A.REF_ID = C.REF_ID AND convert(varchar(10),A.[RecordingDt]) = C.REcordingDate 
		AND 
		right(REPLACE(REPLACE(A.[Fmt_NMD_document_number],'.',''),'0',''),4) = Right(REPLACE(REPLACE(C.[DocumentId],'.',''),'0','') ,4)
		--C.[DocumentId] like '%' + (case when charindex('.',REVERSE(A.[Fmt_NMD_document_number])) > 0 then right(A.[Fmt_NMD_document_number],charindex('.',REVERSE(A.[Fmt_NMD_document_number]))-1)
		--else A.[Fmt_NMD_document_number] end) + '%' 
		where 
		(convert(date,convert(varchar(10),A.[RecordingDt])) > convert(date,B.[MAX_LIENDATE])
		OR B.[MAX_LIENDATE] is null)
		AND REPLACE(REPLACE(C.[DocumentId],'.',''),'0','')  is null



		---------------ADDED 20190416 per NH to send FULL RECORDS FOR PREVIOUSLY SENT SUP RECORDS---------------------------------------------------

		Exec [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_FULL_TO_REPLACE_SUP]

			
		--Select INPUTKEY, count(*) as TOTAL From dbo.[HOA_LIEN_DATA_REPLACE_SUP]
		--Group by INPUTKEY
		--having count(*) > 1

		--Select * From [HOA_LIEN_DATA_REPLACE_SUP]
		--where INPUTKEY = '0578522625 4144792'



		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] ([ID],[Fips],[REF_ID]--[NEW_REF_ID]
		,[PKID],[Identifier],[CmtId],[DocumentId],[Sequence],[BatchDate],[DocType],[State],[County],[RecordingDate],
[RecordingYear],[DocumentDate],[HeaderSequence],[LienDate],[LienAmount],[DateofFirstMissedPayment],[NOD_NOS_Recording_Date],[NOD_NOS_Recorded_Book],[NOD_NOS_Recorded_Page],
[NOD_NOS_Recorded_Document_Number],[NOD_NOS_Default_Amount],[HOA_Auction_Date],[CaseNumber],[CourtType],[MAName],[MAAddress],[MAZip],[MACity],[MAState],[MAEmail],[MAPhone],
[MAContact],[MASequence],[HOA_Trustee_Attorney Name],[HOA_Trustee_Attorney_Phone_Number],[LAWName],[LAWAddress],[LAWZip],[LAWCity],[LAWState],[LAWEmail],[LAWPhone],[LAWLastName],
[LAWFirstName],[LAWMI],[LAWSfx],[OWNLastName],[OWNFirstName],[OWNMI],[OWNSfx],[OWNSpouseFirst],[OWNSpouseMiddle],[OWNSpouseFlag],[OWNSameAsProperty],[OWNAddress],[OWNZip],
[OWNCity],[OWNState],[OWNSequence],[PropAPN],[PropAddress],[PropZip],[PropCity],[PropState],[PropSequence],[OAReference],[OAReferenceAlt],[ReferenceBook],[ReferencePage],
[ReferenceYear],[ReferenceDocNo],[ReferenceRecordingDate],[SourceId],[SourcePK],[SourceCreatedDate],[SourceTruncationOccur],[MULTI_APN],[HOAName],[HOAAddress],[HOAZip],
[HOACity],[HOAState],[HOAEmail],[HOAPhone],[HOAContact],[SSCC],[TAXAPN],[Created],[updated],[FMT_ReferenceDocNo],[FMT_ReferenceBookPage],[IsHoaLienActive],[HOA_Std_FIPS],
[HOA_Std_Street_Number],[HOA_Std_Direction],[HOA_Std_Street_Name],[HOA_Std_Street_Type],[HOA_Std_Post_Direction],[HOA_Std_Unit_Type],[HOA_Std_Unit],[HOA_Std_City],[HOA_Std_State],
[HOA_Std_Zip],[HOA_Std_Plus4],[HOA_Std_PlaceCode],[HOA_Std_PlaceName],[HOA_Std_Verified],[HOA_Std_AddressMatchResults],[MA_Std_FIPS],[MA_Std_Street_Number],[MA_Std_Direction],[MA_Std_Street_Name],
[MA_Std_Street_Type],[MA_Std_Post_Direction],[MA_Std_Unit_Type],[MA_Std_Unit],[MA_Std_City],[MA_Std_State],[MA_Std_Zip],[MA_Std_Plus4],[MA_Std_PlaceCode],[MA_Std_PlaceName],[MA_Std_Verified],
[MA_Std_AddressMatchResults],[LAW_Std_FIPS],[LAW_Std_Street_Number],[LAW_Std_Direction],[LAW_Std_Street_Name],[LAW_Std_Street_Type],[LAW_Std_Post_Direction],[LAW_Std_Unit_Type],[LAW_Std_Unit],[LAW_Std_City],
[LAW_Std_State],[LAW_Std_Zip],[LAW_Std_Plus4],[LAW_Std_PlaceCode],[LAW_Std_PlaceName],[LAW_Std_Verified],[LAW_Std_AddressMatchResults],[INPUTKEY],[RecordNumber],[SUP])
		
	   Select DISTINCT A.[ID],A.[Fips],A.[REF_ID]--A.[NEW_REF_ID]
		,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],
A.[RecordingYear],A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page],
A.[NOD_NOS_Recorded_Document_Number],A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],
A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],
A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],
A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],
A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],
A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],
A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],
A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],
A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],
A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],
A.[LAW_Std_State],A.[LAW_Std_Zip],A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],A.[INPUTKEY],A.[RecordNumber],'F'

		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] as A join 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on 
		a.INPUTKEY = b.INPUTKEY
		Order by A.INPUTKEY


---------------------20200115 - MOVING LIS PENDENS TO NOD?NOS SECTION PER MS - KL---------------------------------
----------20191114 - Adding in Lis Pendens type 2 records from DTDB ONLY (per MS - will look at a way to determine HOA LIS from FLANK in the future-------------------------------
--		Update w_TransHist
--		Set toUSE = NULL

--		UPDATE a
--		SET toUSE = 'Y'
--		--Select A.RAW_ID, B.DATE_ADDED, B.MAX_LIENDATE, B.MAX_NODDATE, A.DocumentType, A.DocumentNbr, A.RecordingDate
--		--,A.BuyerBorrower,  B.OwnerStdName1Full,B.InputBorrowerName , C.Recording_Instrument_Nbr, C.Fmt_Inst_Nbr,C.Recording_Book, C.Recording_Page
--		--, C.Lis_Pendens_Type, C.Document_Type, G.State, G.[County Name]
--		from w_TransHist a JOIN [INPUT_MONITOR] b
--		on a.Raw_ID = b.INPUTKey
--		join w_preforeclosure as C on A.FIPS = C.FIPS
--		and A.REF_ID = C.REF_ID
--		and A.DocumentNbr = C.Fmt_Inst_Nbr
--		join global.dbo.county as G with(NOLOCK) on A.FIPS = G.FIPSCODE
--		WHERE 
--			----------------------Including Lis Pendens type 2 as LIENS per MS 20191115------------
--			-------20200115 - Changed from using Max Lien Date to tracking LIS separately & using Max LIS date -----
--			(Lis_Pendens_Type like '2' and A.DocumentType like 'LIS%' )
--			AND 
--			(
--					(convert(date,a.RecordingDate) > convert(date,b.[MAX_LIS_DATE])
--					or convert(date,a.DocDate) > convert(date,b.[MAX_LIS_DATE]))
--				OR 
--					(B.[MAX_LIS_DATE] is null
--					AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
--					like '%' + left(A.BuyerBorrower,4) + '%'
--					AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
--			)

--		------------------To remove released LIS records-----------
--		UPDATE a
--		SET toUSE = NULL
--		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, B.*
--		from w_TransHist a JOIN 
--		(Select * From w_transhist
--		WHERE DocumentTypeDesc like '%Release%' or DocumentTypeDesc like '%Rescission%' 
--		or DocumentType like '%REL%' or DocumentType like '%REC%'
--		 ) as B on 
--		A.RAW_ID = B.RAW_ID
--		and A.DocumentNbr = B.OrigTransDocNumber
--		--and A.REcordingDate = B.OrigTransRecDate
--		where A.ToUse = 'Y'


--		UPDATE a
--		SET toUSE = NULL
--		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, C.Fmt_Inst_Nbr, C.Recording_Date,C.Fmt_Ori_Inst_Nbr,C.Document_Type 
--		from w_TransHist a JOIN [INPUT_MONITOR] b
--		on a.Raw_ID = b.INPUTKey
--		join w_preforeclosure as C on A.FIPS = C.FIPS
--		and A.REF_ID = C.REF_ID
--		and A.DocumentNbr = C.Fmt_Ori_Inst_Nbr
--		where A.ToUse = 'Y'
--		AND  (C.Document_Type like '%REL%' or C.Document_Type like '%REC%')


--		--	-------TEsting----
--		--Select A.FIPS, A.REF_ID, A.DocumentNbr, A.RecordingDate, A.DocumentType, C.Lis_Pendens_Type, C.Recording_Instrument_Nbr
--		--from w_TransHist a JOIN [INPUT_MONITOR] b
--		--on a.Raw_ID = b.INPUTKey
--		--join w_preforeclosure as C on A.FIPS = C.FIPS
--		--and A.REF_ID = C.REF_ID
--		--and A.DocumentNbr = C.Fmt_Inst_Nbr
--		--join global.dbo.county as G with(NOLOCK) on A.FIPS = G.FIPSCODE
--		--WHERE 
--		--	----------------------Changed 20181217 to include JUDGEMENTS as they contain the Auction Date info------------
--		--	(Lis_Pendens_Type like '2'  and A.DocumentType like 'LIS%')
--		--	AND 
--		--	(
--		--			(convert(date,a.RecordingDate) > convert(date,b.[MAX_LIENDATE])
--		--			or convert(date,a.DocDate) > convert(date,b.[MAX_LIENDATE]))
--		--		OR 
--		--			(B.[MAX_LIENDATE] is null
--		--			AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
--		--			like '%' + left(A.BuyerBorrower,4) + '%'
--		--			AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
--		--	)
--		--	Order by A.REF_ID

--		--Select * From HOA.dbo.HOA_LIEN with(NOLOCK)
--		--where REF_ID = '22380674'
--		-------------------------------------------------------------------------------------------------------------------


--			Insert into HOA_LIEN_DATA_II ([Fips],[REF_ID],[CmtId],[DocumentId],[DocType],[RecordingDate]
--			,[DocumentDate],[LienDate],[LienAmount]
--			,[DateofFirstMissedPayment],[NOD_NOS_Recording_Date],[NOD_NOS_Recorded_Book],[NOD_NOS_Recorded_Page],
--			--[NOD_NOS_Recorded_Document_Number],
--			[NOD_NOS_Default_Amount],[HOA_Auction_Date]
--			,[INPUTKEY],[RecordNumber],[SUP])
		
--			Select DISTINCT A.[Fips],A.[REF_ID],A.[CmtId],A.DocumentNbr,A.DocumentType,convert(int,convert(varchar(10),A.[RecordingDate],112))
--			,convert(int,convert(varchar(10),D.[Document_Date],112))
--			,A.[RecordingDate],A.Value
--			,D.Default_Date	,A.[RecordingDate],D.REcording_Book,D.Recording_Page,
--			--A.DocumentNbr,
--			D.Default_AMount,D.Auction_Date,A.RAW_ID,A.[RecordNumber],'F'
--			--,C.DATE_ADDED, C.MAX_LIENDATE
--			--Select A.*, D.*
--			from w_TransHist as A 
--			join x_Custom_OUTPUT as B on 
--			a.RAW_ID = b.INPUTKEY
--			JOIN [INPUT_MONITOR] as C 
--			on a.Raw_ID = C.INPUTKey
--			join w_preforeclosure as D on A.FIPS = D.FIPS
--			and A.REF_ID = D.REF_ID
--			and A.DocumentNbr = D.Fmt_Inst_Nbr
--			where A.ToUse = 'Y'
--			--Order by a.RAW_ID

		
--			---------------------How we we know if a FLANK Lis Pendens is HOA related??  There is no Lis Pendens Type---
--			--Select * From w_FLANK_NOD


			-----Check for dups-----
			Select A.INPUTKEY, A.FIPS,A.REF_ID,A.RecordingDate, A.DocumentId, A.DocType, A.LienAMount
			,C.DATE_ADDED
			From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] as A join (
			Select INPUTKEY, RecordingDate, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
			Group by INPUTKEY, RecordingDate
			having count(*) > 1)B on A.INPUTKEY = B.INPUTKEY and A.RecordingDate = B.RecordingDate
			join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
			order by A.INPUTKEY, A.RecordingDate

			Select FIPS, REF_ID, Identifier, DocumentId, DocType, RecordingDate, OAReference, SourceCreatedDate, * 
			From [HOA].[dbo].[HOA_LIEN] A with(NOLOCK)
			where --FIPS like '12031'
			REF_ID in ('32406956')
			and OWNSequence = 1
			order by A.REF_ID,A.RecordingDate desc
					--25545123	
			Select A.* From [DATA].[dbo].[HOA_Lien_Sup] as A with(NOLOCK)join [ASSR].[dbo].[ASSR] as B with(NOLOCK) on A.Lic_PropertyID = B.Lic_PropertyID
			where B.REF_ID = '87423410'

			--Select * From HOA_LIEN_DATA_II
			--where FIPS = '53033'

			
			--Select INPUTKEY, RecordingDate, DocumentId ,count(*) as TOTAL From HOA_LIEN_DATA_II
			--Group by INPUTKEY, RecordingDate,DocumentId 
			--having count(*) > 1
			

			--Select * From HOA.dbo.HOA_LIEN where REF_ID = '35547293'


			--Select * From w_TransHist where REF_ID = '28636250'

			--Select * From HOA_LIEN_DATA_II
			--where INPUTKEY = '0079129585 757445'


						
--------------------------Added 20191105 per NH - Need to add REO Deeds with recording date in the last 60 days 
-----------------------AND more recent than most recent HOA Lien recording date if one is populated----
-----------------Per NH - REO is now to go in the NOD section - NOT HOA Lien---AARGH!!!!!!-------
		

--		Update w_Transhist
--		Set ToUse = NULL
--		where ToUSe is not null

--		Update A
--		Set A.ToUse = 'Y'
--		--Select B.MAX_LIENDATE,A.*
--		From w_Transhist as A join x_Custom_OUTPUT as B on 
--		A.RAW_ID = B.INPUTKEY
--		where A.DOc_SRc_Ind like 'D'
--		--and (A.RecordingDate > B.MAX_LIENDATE
--		--or B.MAX_LIENDATE is null)
--		AND A.RecordingDate >= Getdate()-60
--		AND A.Foreclosure_Flag like '1'


--		Update A
--		Set A.DocumentTypeDesc = B.Document_Name
--		--Select A.DocumentType, A.DocumentTypeDesc, B.*
--		From w_Transhist as A join 
--		[AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types as B on
--		Convert(int,A.FIPS) = B.FIPS
--		AND A.DocumentType = B.Output_Code
--		where A.ToUSe = 'Y'
--		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.Document_Name,'')


--		Update A
--		Set A.DocumentTypeDesc = B.[Code Description]
--		--Select A.DocumentType, A.DocumentTypeDesc, B.*
--		From w_Transhist as A join 
--		[AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B on
--		A.DocumentType = b.Value
--		where A.ToUSe = 'Y'
--		AND (Ltrim(Rtrim([Deed_Table_Column_name])) like 'DETAILED_DOC_TYPE'
--				or [Deed_Table_Column_name] like 'DETAILED_DOC_TYPE ')
--		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.[Code Description],'')
		

--		Select DocumentType,DocumentTypeDesc, count(*) From w_Transhist
--		where ToUse = 'Y'
--		Group by DocumentType,DocumentTypeDesc
--		Order by DocumentType,DocumentTypeDesc

		


--		Update w_Transhist_FLANK
--		Set ToUse = NULL
--		where ToUSe is not null


--		Update A
--		Set A.ToUse = 'Y'
--		Select B.MAX_LIENDATE,A.*
--		From w_Transhist_FLANK as A join x_Custom_OUTPUT as B on 
--		A.RAW_ID = B.INPUTKEY
--		where A.DOc_SRc_Ind like 'D'
--		--and (A.RecordingDate > B.MAX_LIENDATE
--		--or B.MAX_LIENDATE is null)
--		AND A.RecordingDate >= Getdate()-60
--		AND A.REO like '1'
--		--Order by B.MAX_LIENDATE desc

--		Update A
--		Set A.DocumentTypeDesc = B.CodeDesc
--		--Select A.DocumentType, A.DocumentTypeDesc, B.*
--		From w_Transhist_FLANK as A join 
--		Global.dbo.lkup_Doc_Type as B on
--		A.DocumentType = B.DocTypeID
--		where A.ToUSe = 'Y'
--		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.CodeDesc,'')


--		Insert into HOA_LIEN_DATA_II ([INPUTKEY],[Fips],[REF_ID],[DocumentId],[DocType],[RecordingDate],[LienAmount],HeaderSequence)
		
--	   Select DISTINCT A.RAW_ID
--	   ,cast(A.[Fips] as int)
--	   ,A.[REF_ID]
--	   ,DocumentNbr
--	   ,A.DocumentTypeDesc 
--	   ,convert(varchar(10),A.RecordingDate,112)
--	   ,A.Value
--	   ,'9999'
--		From w_Transhist_FLANK as A --join x_custom_OUTPUT as B on 
--		--A.RAW_ID = B.INPUTKEY
--		where A.ToUse = 'Y'

		

--		-----Backfill with DTDB-----
--		Insert into HOA_LIEN_DATA_II ([INPUTKEY],[Fips],[REF_ID],[DocumentId],[DocType],[RecordingDate],[LienAmount],HeaderSequence)
		
--	   Select DISTINCT A.RAW_ID,A.[Fips],A.[REF_ID]
--	   ,DocumentNbr
--	   ,A.DocumentTypeDesc 
--	   ,convert(varchar(10),A.RecordingDate,112)
--	   ,A.Value
--	   ,'9999'
--		From w_Transhist as A --join x_custom_OUTPUT as B on 
--		--A.RAW_ID = B.INPUTKEY
--		where A.ToUse = 'Y'
--		and A.RAW_ID not in (Select Distinct INPUTKey from HOA_LIEN_DATA_II with(NOLOCK)
--		where HeaderSequence like '9999')

		
--		Select * From HOA_LIEN_DATA_II
--		where HeaderSequence like '9999'
		
		
		------------Testing to make sure SUP data included---------------
		
		--Select A.REF_ID,A.[Fmt_NMD_document_number],A.[RecordingDt] ,REPLACE(REPLACE(A.[Fmt_NMD_document_number],'.',''),'0','')
		--From HOA_LIEN_SUP as A join 
		--x_Custom_OUTPUT as B on 
		--a.INPUTKEY = b.INPUTKEY
		--where 
		--(convert(date,convert(varchar(10),A.[RecordingDt])) > convert(date,B.[MAX_LIENDATE])
		--OR B.[MAX_LIENDATE] is null)
		--Order by A.[Fmt_NMD_document_number]


		--Select A.REF_ID,A.[DocumentId],A.[RecordingDate] ,REPLACE(REPLACE(A.[DocumentId],'.',''),'0','') From HOA_LIEN_DATA_II A
		--where REF_ID in (  Select A.REF_ID
		--From HOA_LIEN_SUP as A join 
		--x_Custom_OUTPUT as B on 
		--a.INPUTKEY = b.INPUTKEY
		--where 
		--(convert(date,convert(varchar(10),A.[RecordingDt])) > convert(date,B.[MAX_LIENDATE])
		--OR B.[MAX_LIENDATE] is null))
		--Order by [DocumentId]

		

		--Select * From x_custom_OUTPUT where INPUTKEY = '1548405'

		--Select * From HOA_LIEN_DATA_II  where INPUTKEY = '1548405'


		--Select * From HOA.dbo.HOA_LIEN where REF_ID = '83205017'

		--Select * From HOA_LIEN_DATA_II
		--where REF_ID in (
		--Select REF_ID from (
		--Select REF_ID, count(*) as TOTAL From HOA_LIEN_DATA_II 
		--Group by REF_ID
		--having count(*) > 1)A)
		--Order by REF_ID


		--Select * From HOA.dbo.HOA_LIEN where REF_ID = '143551439'

		--Select * From HOA_LIEN_SUP where REF_ID = '143551439'


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] SET REcordNumber = NULL

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET REcordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY convert(date,convert(varchar(10),RecordingDate)) DESC, Identifier DESC, DocumentID desc) AS RowNum
			FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] t ) r ON t.INPUTKEY = r.INPUTKEY and t.RecordingDate = r.RecordingDate 
			and ISNULL(t.Identifier,'0') = ISNULL(r.Identifier,'0')
			and r.DocumentID = t.DocumentID


		Select REcordNumber, count(*) FRom [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
		Group by REcordNumber
		Order by REcordNumber

		--Select * From HOA_LIEN_DATA_II

		--Select REF_ID, INPUTKEY, RecordingDate, Identifier, DocumentId From HOA_LIEN_DATA_II
		--where REF_ID = '63913184'

		--Select * From HOA_LIEN_DATA_II
		--where INPUTKEY = 60

		----Select * From x_custom_OUTPUT
		----where INPUTKEY = 60

		--Select * From  [Data].[dbo].[HOA_Lien_Sup]
		--where LIC_PropertyID = '83240769'
		

		--Select * From HOA.dbo.HOA_Lien where REF_ID = '83496304'


		--Select INPUTKEY, REcordNumber From HOA_LIEN_DATA_II
		--where INPUTKEY in 
		--(Select INPUTKEY from 
		--(Select INPUTKEY, count(*) as TOTAL from HOA_LIEN_DATA_II
		--Group by INPUTKEY
		--Having count(*) > 1)A)
		--Order by INPUTKEY,REcordNumber

		--Select *, convert(date,convert(varchar(10),RecordingDate)) 
		--,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY convert(date,convert(varchar(10),RecordingDate)) DESC) AS RowNum
		--From HOA_LIEN_DATA_II
		--where INPUTKEY = 'NV13485'

		Select INPUTKEY, * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] A where INPUTKEY in (
		Select INPUTKEY from (
		Select INPUTKEY, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
		Group by INPUTKEY
		Having count(*) > 1)A)
		Order by A.INPUTKEY 

		Select A.REF_ID, A.PropAddress, B.PropertyAddress, B.INPUTAddress
		 From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on A.REF_ID = B.WORK_REF_ID


		Select IsHoaLienActive, * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK)
		where REF_ID = '35236245'

		Select A.Released, A.* From [data].[dbo].[HOA_Lien_Sup] as A with(NOLOCK)
		join [Assr].[dbo].[Assr] as B with(NOLOCK) on A.Lic_PropertyID = B.Lic_PropertyID and A.FipsCode = B.FIPS
		where B.REF_ID = '35236245'


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		Set [Number_of_HOA_Liens] = 0

		--Select * From INPUT_MONITOR
		

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[Number_of_HOA_Liens] = B.TOTAL
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN 
		(Select INPUTKEY, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II] 
		Group by INPUTKEY) B
		on a.INPUTKEY = b.INPUTKEY

		Select max([Number_of_HOA_Liens]) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]

		--Select INPUTKey,max([Number_of_HOA_Liens]) From x_Custom_OUTPUT
		--Group by INPUTKey
		--Order by max([Number_of_HOA_Liens])  desc

		--Select INPUTKEY, DocumentId, RecordingDate, DocType, IsHoaLienActive, OAReference From HOA_LIEN_DATA_II
		--where INPUTKEY in ('0580287325 7086509','0580372509 7300991','0580474834 7334340')
		--Order by INPUTKEY,RecordingDate

			---- FILL IN LIENS 
		SET CONCAT_NULL_YIELDS_NULL OFF

		DECLARE @BeginNbrOfTrans int
		DECLARE @EndNbrOfTrans int
		DECLARE @RecNbr as varchar(5)

		IF(Select max([Number_of_HOA_Liens]) FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]) > 0 
		BEGIN

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans =   MAX(convert(int,REcordNumber)) FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienRecordNbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienDocType_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienDocType_INTERNAL_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienRecordingDate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienRecordedDocumentNumber_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienAmount_' + @RecNbr + '] [varchar](250) NULL')

					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienAgency_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienContactCompany_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienContactName_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienAddressMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienCityMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienStateMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienZipMailing_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_LienContactPhone_' + @RecNbr + '] [varchar](250) NULL')

					-----------------20181217 - Update - REmoved as orig fields already in NOD/NOS section--------------
					----------------Per NH - fields must be populated with original info - if NOS then NOD - if NOD then Lien - if Release then NOD/NOR or LIEN----
					------added 20181218 -however not populated as all release/NOD/NOS etc go in NOD fields-------
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_OrigRecordingDate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_OrigDocNumber_' + @RecNbr + '] [varchar](250) NULL')

					------added 20190329 to track SUPPLEMENTAL (SKINNY) records sent -------
					EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_SUP_' + @RecNbr + '] [varchar](1) NULL')
					

									
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_RecordingDate_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_RecordedDocumentNumber_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_DefaultAmount_' + @RecNbr + '] [varchar](250) NULL')
										
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_TrusteeAttorneyName_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_TrusteeAttorneyPhoneNumber_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_AuctionDate_' + @RecNbr + '] [varchar](250) NULL')
				

				-----------20180827 - Added code PER NH to backfill the HOA Contact fields from the MA fields if the LAW fields are not populated-----
						
						SET CONCAT_NULL_YIELDS_NULL OFF 

						EXEC('UPDATE a
						SET 
						--a.HOA_LienRecordNbr_' + @RecNbr + ' = ' + @RecNbr + '
						--,
						A.HOA_LienDocType_' + @RecNbr + ' = B.DocType
						--,A.HOA_LienDocType_INTERNAL_' + @RecNbr + ' = Case when B.HeaderSequence like ''9999'' then ''REO'' else NULL End
						,a.HOA_LienRecordingDate_' + @RecNbr + ' = convert(varchar(10),convert(datetime,convert(varchar(8),RecordingDate)),120)
						,a.HOA_LienRecordedDocumentNumber_' + @RecNbr + ' = DocumentID
						,a.HOA_LienAmount_' + @RecNbr + ' = LienAmount

						,a.HOA_LienName_' + @RecNbr + ' = B.HOANAME
						,a.HOA_LienAgency_' + @RecNbr + ' = B.MAName
						,a.HOA_LienContactCompany_' + @RecNbr + ' = B.lawname 
						,a.HOA_LienContactName_' + @RecNbr + ' = Case when (B.lawfirstname is null or B.lawfirstname like '''') and (B.lawlastname is null or B.lawlastname like '''') then B.MAContact 
						else REPLACE((B.lawfirstname + '' '' + B.lawmi + '' '' + B.lawlastname + '' '' + B.lawsfx),''  '','''') end
						,a.HOA_LienAddressMailing_' + @RecNbr + ' = case when B.[LAWAddress] is null or B.[LAWAddress] like '''' then B.MAAddress else B.[LAWAddress] end
						,a.HOA_LienCityMailing_' + @RecNbr + ' = case when B.[LAWCity] is null or B.[LAWCity] like '''' then B.MACity else B.[LAWCity] end
						,a.HOA_LienStateMailing_' + @RecNbr + ' = case when B.[LAWState] is null or B.[LAWState] like '''' then B.MAState else B.[LAWState] end 
						,a.HOA_LienZipMailing_' + @RecNbr + ' = case when B.[LAWZip] is null or B.[LAWZip] like '''' then B.MAZip else B.[LAWZip] end 
						,a.HOA_LienContactPhone_' + @RecNbr + ' = case when B.[LAWPHONE] is null or B.[LAWPHONE] like '''' then B.MAPhone else B.[LAWPHONE] end


						
						--,a.NOD_NOS_RecordingDate_' + @RecNbr + ' = convert(date,NOD_NOS_Recording_Date)
						--,a.NOD_NOS_RecordedDocumentNumber_' + @RecNbr + ' = NOD_NOS_Recorded_Document_Number
						--,a.NOD_NOS_DefaultAmount_' + @RecNbr + ' = NOD_NOS_Default_Amount
						--,a.HOA_TrusteeAttorneyName_' + @RecNbr + ' = LawName
						--,a.HOA_TrusteeAttorneyPhoneNumber_' + @RecNbr + ' = LawPhone
						--,a.HOA_AuctionDate_' + @RecNbr + ' = HOA_Auction_Date


						,A.[HOA_SUP_' + @RecNbr + '] = B.[sup]
						
						--SET CONCAT_NULL_YIELDS_NULL OFF 
						--Select REPLACE((B.lawfirstname + '' '' + B.lawmi + '' '' + B.lawlastname + '' '' + B.lawsfx),''  '','''') 
						--Select * 
						FROM x_Custom_OUTPUT a JOIN HOA_LIEN_DATA_II as B on 
						a.INPUTKEY = b.INPUTKEY
						WHERE B.REcordNumber = ' + @BeginNbrOfTrans + '') 

						
						EXEC('
						Update A
						Set 
						A.HOA_LienDocType_' + @RecNbr + ' = B.FULL_NAME
						FROM x_Custom_OUTPUT a JOIN
						zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as B with(NOLOCK) on 
						A.HOA_LienDocType_' + @RecNbr + '  = B.HOA_DOC_TYPE
						')

						-----Added to use new doc type table----
						EXEC('
						Update A
						Set 
						A.HOA_LienDocType_' + @RecNbr + ' = B.FULL_NAME
						FROM x_Custom_OUTPUT a JOIN
						[HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as B with(NOLOCK) on 
						A.HOA_LienDocType_' + @RecNbr + '  = B.DOCTYPE
						')

						--Select A.HOA_LienDocType_001, B.*
						--FROM x_Custom_OUTPUT a JOIN
						--[HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as B with(NOLOCK) on 
						--A.HOA_LienDocType_001  = B.DOCTYPE
						


										
					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 
		END

		

		
	




		--Select top 10 * From x_Custom_OUTPUT

		-------------Uncomment & Run----
		Select  A.FIPS, B.State, B.[County Name],WORK_REF_ID,A.PROPERTYID_INT, A.INPUTKey,A.InputAddress,A.INputAPN,A.OwnerStdName1Full,A.MAX_LIENDATE, C.DATE_ADDED
		,HAS_HOA_RECORD, CoverageStatus_HOA_LIEN, CoverageStatus_PREFC
		,Number_of_HOA_Liens
		--,HOA_LienRecordingDate_001 ,HOA_LienRecordedDocumentNumber_001      ,HOA_LienAmount_001       ,HOA_LienName_001, HOA_LienDocType_001,[HOA_SUP_001]
		--,HOA_LienRecordingDate_002 ,HOA_LienRecordedDocumentNumber_002      ,HOA_LienAmount_002       ,HOA_LienName_002, HOA_LienDocType_002,[HOA_SUP_002]
		--,HOA_LienRecordingDate_003 ,HOA_LienRecordedDocumentNumber_003      ,HOA_LienAmount_003       ,HOA_LienName_003, HOA_LienDocType_003,[HOA_SUP_003]
		--,HOA_LienRecordingDate_004 ,HOA_LienRecordedDocumentNumber_004      ,HOA_LienAmount_004       ,HOA_LienName_004, HOA_LienDocType_004
		--,HOA_LienRecordingDate_005 ,HOA_LienRecordedDocumentNumber_005      ,HOA_LienAmount_005       ,HOA_LienName_005, HOA_LienDocType_005
		--,HOA_LienRecordingDate_006 ,HOA_LienRecordedDocumentNumber_006      ,HOA_LienAmount_006       ,HOA_LienName_006, HOA_LienDocType_006
		--,HOA_LienRecordingDate_007 ,HOA_LienRecordedDocumentNumber_007      ,HOA_LienAmount_007       ,HOA_LienName_007, HOA_LienDocType_007
		--,HOA_LienRecordingDate_008 ,HOA_LienRecordedDocumentNumber_008      ,HOA_LienAmount_008       ,HOA_LienName_008, HOA_LienDocType_008
		--,HOA_LienRecordingDate_009 ,HOA_LienRecordedDocumentNumber_009      ,HOA_LienAmount_009       ,HOA_LienName_009, HOA_LienDocType_009
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[Input_MONITOR] as C on A.INputkey = C.Inputkey
		where Number_of_HOA_Liens > 0
		--and HOA_LienDocType_001 is null
		Order by A.Number_of_HOA_Liens desc

	


		--Select IsHoaLienActive, * From HOA.dbo.HOA_LIEN with(NOLOCK)
		--where REF_ID = '29309903'
		--and IsHoaLienActive = 1 and OWNSequence = 1
		--Order by REcordingDate 

		--Select FIPS, REF_ID, Lic_PropertyID, SITUS_HOUSE_NBR, SITUS_STREET_NAME, SITUS_UNIT_NBR From Assr.dbo.Assr
		--where REF_ID in ('29309903','26679431')

		--Select FIPS, PropertyID, DTDB_Ref_ID, SitusStdFullStreetAddress From data.dbo.Property with(NOLOCK)
		--where PropertyID = '28080295'
		--OR DTDB_REF_ID in ('29309903','26679431')

		--Select FIPS, WORK_REF_ID, PROPERTYID_INT, INPUTAddress, INPUTKey From x_Custom_OUTPUT
		--where PropertyID = '28080295'
		--OR WORK_REF_ID in ('29309903','26679431')

		--Select FIPS, REF_ID, INPUTKEY From HOA_LIEN_DATA_II
		--where REF_ID = '29309903'
		--OR INPUTKEY = '0580380017 7274510'

		--Select INPUTKEY, INPUTADDRESS, REF_ID, PROPERTYID, DATE_ADDED, MAX_LIENDATE From INPUT_MONITOR
		--where INPUTKEY = '0580380017 7274510'

		
		--Select A.*, C.State, C.[County Name] From [Data].[dbo].[HOA_Lien_Sup] as A with(NOLOCK)
		-- join Assr.dbo.Assr as B with(NOLOCK) on A.LIC_PRopertyID = B.LIC_PRopertyID
		-- join global.dbo.county as C with(NOLOCK) on A.FipsCode = C.FIPSCode
		--where B.REF_ID = '29309903'
		--Order by REcordingDt 

		--Select * From HOA_LIEN_DATA_II A JOIN
		--zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as B with(NOLOCK) on 
		--A.DocType = B.HOA_DOC_TYPE
		--where REF_ID = '29309903'

		--Select A.* From [Data].[dbo].[HOA_Lien_Release_Sup] as A with(NOLOCK)
		--where A.LIC_PRopertyID = '22510639'

		--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] 
		--Order by HOA_DOC_TYPE
		--where HOA_Data_Type in ( 'Lien','len','LEN')

		--Select * From Assr.dbo.Assr
		--where REF_ID = '22434416'

		



		--Select HOA_LIEN_DOC, sum(TOTAL) from (
		--Select HOA_LienDocType_001 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--Group by HOA_LienDocType_001
		--UNION ALL
		--Select HOA_LienDocType_002 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_002 is not null
		--Group by HOA_LienDocType_002
		--UNION ALL
		--Select HOA_LienDocType_003 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_003 is not null
		--Group by HOA_LienDocType_003
		--UNION ALL
		--Select HOA_LienDocType_004 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_004 is not null
		--Group by HOA_LienDocType_004
		--UNION ALL
		--Select HOA_LienDocType_005 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_005 is not null
		--Group by HOA_LienDocType_005
		--UNION ALL
		--Select HOA_LienDocType_006 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_006 is not null
		--Group by HOA_LienDocType_006
		--UNION ALL
		--Select HOA_LienDocType_007 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_007 is not null
		--Group by HOA_LienDocType_007
		--UNION ALL
		--Select HOA_LienDocType_008 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_008 is not null
		--Group by HOA_LienDocType_008
		--UNION ALL
		--Select HOA_LienDocType_009 as HOA_LIEN_DOC, count(*) as TOTAL from x_Custom_OUTPUT
		--where Number_of_HOA_Liens > 0
		--and HOA_LienRecordingDate_009 is not null
		--Group by HOA_LienDocType_009
		--)A
		--Group by HOA_LIEN_DOC


		--Select * From [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]
		--where full_name like 'Notice of Default%'
		--and DocType not like 'NDF'

		--Select * From HOA.[dbo].[HOA_DOC_TYPE]
		--where full_name like 'Notice of Default'
		--OR HOA_DOC_TYPE like 'NDF'

		--Select A.FIPS,B.State, B.[County NAme], WORK_REF_ID, HOA_LienDocType_001 , HOA_LienRecordingDate_001, HOA_LienRecordedDocumentNumber_001
		--from x_Custom_OUTPUT as A join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		--where Number_of_HOA_Liens > 0
		--and HOA_LienDocType_001 like 'Notice of Default%'
		--Order by A.FIPS

		--Select * From HOA.dbo.HOA_LIEN with(NOLOCK)
		--where REF_ID = '83532545'

		--Select * From w_TransHist
		--where REF_ID = '83532545'

		--Select FIPS, REF_ID From w_PreForeclosure
		--where REF_ID = '83532545'

		----Update [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]
		----Set HOA_Data_Type = 'NOD/NOS/REO'
		----where DocType like 'FCLSLEHLN'
		----and HOA_Data_Type like 'Lien'


		--Select * From zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
		--where full_name like 'FORECLOSURE SALE UNDER HOMEOWNERS ASSOCIATION'



		Select DocType, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_II]
		Group by DocType


		--Select HOA_Data_Type,DocType, FULL_NAME,count(*) From HOA.dbo.HOA_LIEN as A with(NOLOCK)
		--join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D on A.DocType = D.[HOA_Doc_Type]
		--where IsHoaLienActive = 1
		--and OWNSequence = 1
		--Group by HOA_Data_Type,DocType,FULL_NAME
		--Order by HOA_Data_Type,DocType,FULL_NAME


		Select * From [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705]
		where  HOA_DOC_TYPE in ( 'halv','HLN','f7','HALNAM','HLNVIO','HALNAMD')

		Select B.DATE_ADDED, A.INPUTKEY,A.PropertyID, A.Number_of_HOA_Liens
		 From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.INPUTKEY = B.INPUTKEY
		 Order by A.Number_of_HOA_Liens desc,B.DATE_ADDED desc


		----------------------------------------------GET NOD----------------------------------------
		truncate table HOA_NOD

		------------------------*****************START HERE - Should LIS from DTDB & FLANK be forced in HOA Lien Data Pull????-----------------
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist]
		Set toUSE = NULL

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = 'Y'
		--Select A.RAW_ID, B.DATE_ADDED, B.MAX_LIENDATE, B.MAX_NODDATE, A.DocumentType, A.DocumentNbr, A.RecordingDate, A.Value
		--,C.*
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] b
		on a.Raw_ID = b.INPUTKey
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Inst_Nbr
		And A.DocumentType = C.Document_Type
		WHERE 
			----------------------Changed 20181217 to include JUDGEMENTS as they contain the Auction Date info------------
			(
				(Lis_Pendens_Type like '2' and Document_Type not like 'LIS%') 
				or 
			
			------Changed 20200131 per NH to only return Judgements not in the HOA Lien table where Default Amount is populated & Below 50K (no 0's or NULLS)
				(Document_Type like 'JDG'  AND ((C.Default_Amount > 0 and C.Default_Amount < 50000) or (C.Judgment_Amount > 0 and  C.Judgment_Amount < 50000)))
			)
			AND 
			(
					(convert(date,a.RecordingDate) > convert(date,b.[MAX_NODDATE])
					or convert(date,a.DocDate) > convert(date,b.[MAX_NODDATE])
					--OR B.[MAX_NODDATE] is null
					)
					--AND A.REF_ID =  '26810023'
				OR 
					(B.[MAX_NODDATE] is null
					AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
					like '%' + left(A.BuyerBorrower,4) + '%'
					AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
			)
			--Order by A.DocumentType
			And A.REF_ID not like '196878235'



		


		--	--------------------Testing-------------
		--Select A.RAW_ID, B.DATE_ADDED, B.MAX_LIENDATE, B.MAX_NODDATE, A.DocumentType, A.DocumentNbr, A.RecordingDate
		--,A.BuyerBorrower,  B.OwnerStdName1Full,B.InputBorrowerName , C.Lis_Pendens_Type, C.Document_Type, C.Fmt_Inst_Nbr
		--,Glob.FIPSCODE,Glob.state, Glob.[County Name]
		--from w_TransHist a JOIN [INPUT_MONITOR] b
		--on a.Raw_ID = b.INPUTKey
		--join w_preforeclosure as C on A.FIPS = C.FIPS
		--and A.REF_ID = C.REF_ID
		--and A.DocumentNbr = C.Fmt_Inst_Nbr
		--And A.DocumentType = C.Document_Type
		--join global.dbo.county as GLOB on A.FIPS = GLOB.FIPSCODE
		--WHERE 
		--	----------------------Changed 20181217 to include JUDGEMENTS as they contain the Auction Date info------------
		--	((Lis_Pendens_Type like '2' and Document_Type not like 'LIS%') or Document_Type like 'JDG'
		--	)
		--	AND 
		--	(
		--			(convert(date,a.RecordingDate) > convert(date,b.[MAX_NODDATE])
		--			or convert(date,a.DocDate) > convert(date,b.[MAX_NODDATE])
		--			--OR B.[MAX_NODDATE] is null
		--			)
		--			--AND A.REF_ID =  '26810023'
		--		OR 
		--			(B.[MAX_NODDATE] is null
		--			AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
		--			like '%' + left(A.BuyerBorrower,4) + '%'
		--			AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
		--	)
		--	And A.REF_ID = '34113007'


			--Select FIPS, REF_ID, Document_Type, Fmt_Inst_Nbr,Recording_Date, Created, UPdated 
			--From [AZUVPSQLDTDB029.datatree.local].Pre_Foreclosure.dbo.PreForeclosure d with(nolock)
			--where FIPS = 12057
			--and REF_ID = '34113007'


			--Select * From w_preforeclosure
			--where Document_Type like 'JDG' and Lis_Pendens_Type like '2'

			--Select * From HOA_LIEN_DATA_II
			--where INPUTKEY = '0079129585 757445'


	--Select * From w_preforeclosure
	--where REF_ID = '27378045'


		-------------------------REMOVE any that are NOT currently in PreFC (Status 1 or 6)
		-----Removed 20191113---
		--UPDATE a
		--SET toUSE = NULL
		----Select * 
		--from w_TransHist a JOIN w_DM_DATA b
		--on a.REF_ID = b.PROPERTY_ID
		--where B.STATUS not in ('1','6')
		--and A.TOUSE = 'Y'


	
		------------------To remove released NOD/NOS records-----------
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, B.*
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN 
		(Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_transhist]
		WHERE DocumentTypeDesc like '%Release%' or DocumentTypeDesc like '%Rescission%' 
		or DocumentType like '%REL%' or DocumentType like '%REC%'
		 ) as B on 
		A.RAW_ID = B.RAW_ID
		and A.DocumentNbr = B.OrigTransDocNumber
		--and A.REcordingDate = B.OrigTransRecDate
		where A.ToUse = 'Y'
		


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, C.Fmt_Ori_Inst_Nbr,C.Document_Type 
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] b
		on a.Raw_ID = b.INPUTKey
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Ori_Inst_Nbr
		where A.ToUse = 'Y'
		AND C.Document_Type    like 'REC'

		--Select REF_ID, ToUse, DocumentNbr, RecordingDate, DocumentType From w_TransHist
		--where REF_ID = '34113007'
		--and ToUse like 'Y'


----------------------------20191114 - Start Here!!!------------------------------------



			-----------------Added  to pull NOD/NOS from HOA Lien table where HOA Lien is not active & NOD/NOS not in DTDB-----------
		EXEC [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_NOD_NOS]

	

		---- GET NOD/NOS from HOA_LIEN

		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKey],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
		,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		SELECT distinct a.FIPS,a.REF_ID,b.INPUTKey
		,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
		,convert(varchar(8),a.RecordingDate,112),UPPER(DocumentTypeDesc),Value,HOAName,MAName,LawName,LawPhone,HOA_Auction_Date,ltrim(rtrim(OrigTransRecDate)),ltrim(rtrim(OrigTransDocNumber)),0
		 --Select * 
		 --,OWNLASTNAME,BuyerBorrower
		 FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA] b
		ON a.REF_ID = b.REF_ID 
		WHERE toUSE = 'Y' and a.OrigTransRecDate = convert(varchar(10),convert(datetime,convert(varchar(8),b.RecordingDate)),120)
		--and b.Released like '' and a.Released is null 
		--and a.REF_ID not in(Select Match_REF_ID from HOA_NOD)

		AND A.BuyerBorrower like '%' + B.OWNLastName + '%'
		AND B.OWNLastName is not null AND B.OWNLastName not like ''
		And A.REF_ID not like '196878235'

		

		
		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKey],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
		,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr],[SUP])
		
		SELECT distinct B.FIPS,B.REF_ID,B.INPUTKey
		,CASE WHEN B.[DocumentID] is null then 
		case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		WHEN B.[DocumentID] is NOT null then 
		case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		END
		,convert(varchar(8),B.NOD_NOS_Recording_Date,112)
		--,UPPER(DocumentTypeDesc)
		,UPPER(LTRIM(RTRIM(REPLACE(D.Full_Name,char(160),''))))
		-----20180720 - Per Bill - Lien Amount is Default Sup table is Default Amount---
		,B.LienAmount--,Value
		,B.HOAName,B.MAName,B.LawName,B.LawPhone,HOA_Auction_Date
		,NULL--,ltrim(rtrim(OrigTransRecDate))
		,NULL--,ltrim(rtrim(OrigTransDocNumber))
		,0
		,B.[SUP]
		 --Select * 
		 --,C.InputBorrowerName,B.OWNLastName,C.OwnerStdName1Full
		 FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS] b
		

		
		-----Changed 20191114 to use new doc type table---
		 left outer join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
		 on B.DocType = D.DocType
		 Left outer join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as H on 
		B.INPUTKEY = H.INPUTKey AND 
		B.RecordingDate = H.RecordingDate AND 
		Right((CASE WHEN B.[DocumentID] is null then 
		case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		WHEN B.[DocumentID] is NOT null then 
		case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		END),4) = Right(H.DocumentID,4)
		-----Commented out 20191114---
		-- join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
		-- on B.DocType = D.[HOA_Doc_Type]
		-- join INPUT_MONITOR as C on B.INPUTKEY = C.INPUTKEY
		
		 where H.DocumentID is null AND 
		 D.HOA_Data_Type in ('NOD/NOS/REO')
		 And B.REF_ID not like '196878235'
		 AND B.DocumentId not in ('2019.12.23.2167','2020.1.3.902','2019.12.27.1324','2019.12.10.1971')
		-----Commented out 20191114---
		--(D.HOA_Data_Type   in ('NDF','NOD/NOS/REO/Release','Partial Release','PRL','REL','REQ','SBT','SLE')
		-- OR 
		-- (
		--	D.Full_Name like  '%notice%' 
		--	--OR
		--	--Full_Name like '%Release%' OR
		--	--Full_Name like '%Rescission%' OR
		--	--Full_Name like '%Cancella%' 
		--	))
		----AND (case when C.InputBorrowerName is null or C.InputBorrowerName like '' then C.OwnerStdName1Full else C.InputBorrowerName end) like '%' + B.OWNLastName + '%'
		----AND B.OWNLastName is not null AND B.OWNLastName not like ''
	
		
		 
		
		-----------------------------HERE----------------
			  
	

		---- GET NOD/NOS from TRANSHIST

	--Select * From w_PreForeclosure where REF_ID = '24109878'

		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKey],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
			,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		SELECT distinct a.FIPS,a.REF_ID,a.Raw_ID as RAW_ID
			,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
			,convert(varchar(8),a.RecordingDate,112)
			,case when A.DocumentType like 'JDG' and ISNULL(DocumentTypeDesc,'') like '' then 'JUDGMENT' else UPPER(DocumentTypeDesc) end
			,case when B.Judgment_Amount is null or B.Judgment_Amount like '' or B.Judgment_Amount = 0 then   isNULL(B.Default_Amount,0) 
			else isNULL(B.Judgment_Amount,0) end
			,NULL as HOAName,NULL as MAName,NULL as LawName,Null as LawPhone,B.Auction_Date
			,ltrim(rtrim(OrigTransRecDate))
			,case when OrigTransDocNumber like 'Invalid%' then NULL else ltrim(rtrim(OrigTransDocNumber)) end
			,0
		--,A.DocumentType, A.DocumentTypeDesc,B.Judgment_Amount,B.Default_Amount, A.Value
		--,case when B.Judgment_Amount is null or B.Judgment_Amount like '' or B.Judgment_Amount = 0 then   isNULL(B.Default_Amount,0) 
		--	else isNULL(B.Judgment_Amount,0) end
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Preforeclosure] b
		ON a.REF_ID = b.REF_ID and a.RecordingDate = b.Recording_Date
		and A.DocumentNbr = B.Fmt_Inst_Nbr
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.RAW_ID = C.INPUTKEY
	
		Left outer join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as H on 
		A.RAW_ID = H.INPUTKey AND 
		A.RecordingDate = H.RecordingDate AND 
		Right((CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END),4)
		= Right(H.DocumentID,4)

			WHERE H.DocumentID is null AND 
			toUSE = 'Y' 
			And A.REF_ID not like '196878235'
		--	-------Commented out 20191115---
		----	and ([Lis_Pendens_Type] = 2 or [Trustee_Attorney_Plaintiff_Full1] like '%HOA%' or [Trustee_Attorney_Plaintiff_Full1] like '%HOMEO%') and Doc_Src_Ind = 'R' 
		------and Released is null
		----		and (DocumentTypeDesc like '%NOTICE%' --or DocumentTypeDesc Like 'Release'
		----		)
		----AND (Case when C.INPUTBORROWERNAME is not null and C.INPUTBORROWERNAME not like '' then C.INPUTBORROWERNAME else C.OWNERSTDNAME1FULL end) like '%' + left(A.BuyerBorrower,4) + '%'
		----AND A.BuyerBorrower is not null and A.BuyerBorrower not like ''


	

		
-------------------20200115 - MOVING LIS PENDENS TO NOD?NOS SECTION PER MS - KL---------------------------------
--------20191114 - Adding in Lis Pendens type 2 records from DTDB ONLY (per MS - will look at a way to determine HOA LIS from FLANK in the future-------------------------------
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist]
		Set toUSE = NULL

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = 'Y'
		--Select A.RAW_ID, B.DATE_ADDED, B.MAX_LIENDATE, B.MAX_NODDATE, A.DocumentType, A.DocumentNbr, A.RecordingDate
		--,A.BuyerBorrower,  B.OwnerStdName1Full,B.InputBorrowerName , C.Recording_Instrument_Nbr, C.Fmt_Inst_Nbr,C.Recording_Book, C.Recording_Page
		--, C.Lis_Pendens_Type, C.Document_Type, G.State, G.[County Name]
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] b
		on a.Raw_ID = b.INPUTKey
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Inst_Nbr
		join [global].[dbo].[county] as G with(NOLOCK) on A.FIPS = G.FIPSCODE
		WHERE 
			----------------------Including Lis Pendens type 2 as LIENS per MS 20191115------------
			-------20200115 - Changed from using Max Lien Date to tracking LIS separately & using Max LIS date -----
			(Lis_Pendens_Type like '2' and A.DocumentType like 'LIS%' )
			AND 
			(
					(convert(date,a.RecordingDate) > convert(date,b.[MAX_LIS_DATE])
					or convert(date,a.DocDate) > convert(date,b.[MAX_LIS_DATE]))
				OR 
					(B.[MAX_LIS_DATE] is null
					AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
					like '%' + left(A.BuyerBorrower,4) + '%'
					AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
			)

		------------------To remove released LIS records-----------
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, B.*
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN 
		(Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_transhist]
		WHERE DocumentTypeDesc like '%Release%' or DocumentTypeDesc like '%Rescission%' 
		or DocumentType like '%REL%' or DocumentType like '%REC%'
		 ) as B on 
		A.RAW_ID = B.RAW_ID
		and A.DocumentNbr = B.OrigTransDocNumber
		--and A.REcordingDate = B.OrigTransRecDate
		where A.ToUse = 'Y'


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = NULL
		--Select A.RAW_ID, A.REcordingDate, A.DocumentType, A.DocumentTypeDesc, A.DocumentNbr, C.Fmt_Inst_Nbr, C.Recording_Date,C.Fmt_Ori_Inst_Nbr,C.Document_Type 
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] b
		on a.Raw_ID = b.INPUTKey
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_preforeclosure] as C on A.FIPS = C.FIPS
		and A.REF_ID = C.REF_ID
		and A.DocumentNbr = C.Fmt_Ori_Inst_Nbr
		where A.ToUse = 'Y'
		AND  (C.Document_Type like '%REL%' or C.Document_Type like '%REC%')


		
		-------------------------------------------------------------------------------------------------------------------
		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]([FIPS],[Match_REF_ID],[INPUTKey],[DocumentID],[RecordingDate],[Document_Title_Text],[LienAmount],[HOAName],[MAName]
			,[LawName],[LawPhone],[Auction_Date],[OrigRecDate],[OrigDocNbr],[RowNbr])
		SELECT distinct a.FIPS,a.REF_ID,a.Raw_ID as RAW_ID
			,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
			,convert(varchar(8),a.RecordingDate,112)
			,case when A.DocumentType like 'JDG' and ISNULL(DocumentTypeDesc,'') like '' then 'JUDGMENT'
				  when A.DocumentType like 'LIS' and ISNULL(DocumentTypeDesc,'') like '' then 'LIS PENDENS'
				  else UPPER(DocumentTypeDesc) end
			,case when B.Judgment_Amount is null or B.Judgment_Amount like '' or B.Judgment_Amount = 0 then   isNULL(B.Default_Amount,0) 
			else isNULL(B.Judgment_Amount,0) end
			,NULL as HOAName,NULL as MAName,NULL as LawName,Null as LawPhone,B.Auction_Date
			,ltrim(rtrim(OrigTransRecDate))
			,case when OrigTransDocNumber like 'Invalid%' then NULL else ltrim(rtrim(OrigTransDocNumber)) end
			,0
			--,A.DocumentType
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Preforeclosure] b
		ON a.REF_ID = b.REF_ID and a.RecordingDate = b.Recording_Date
		and A.DocumentNbr = B.Fmt_Inst_Nbr
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.RAW_ID = C.INPUTKEY

		--from w_TransHist as A 
		--	join x_Custom_OUTPUT as B on 
		--	a.RAW_ID = b.INPUTKEY
		--	JOIN [INPUT_MONITOR] as C 
		--	on a.Raw_ID = C.INPUTKey
		--	join w_preforeclosure as D on A.FIPS = D.FIPS
		--	and A.REF_ID = D.REF_ID
		--	and A.DocumentNbr = D.Fmt_Inst_Nbr
		--	where A.ToUse = 'Y'
	
		Left outer join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as H on 
		A.RAW_ID = H.INPUTKey AND 
		A.RecordingDate = H.RecordingDate AND 
		Right((CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END),4)
		= Right(H.DocumentID,4)

			WHERE H.DocumentID is null AND 
			toUSE = 'Y' 
			
		
			--Select DISTINCT A.[Fips],A.[REF_ID],A.[CmtId],A.DocumentNbr,A.DocumentType,convert(int,convert(varchar(10),A.[RecordingDate],112))
			--,convert(int,convert(varchar(10),D.[Document_Date],112))
			--,A.[RecordingDate],A.Value
			--,D.Default_Date	,A.[RecordingDate],D.REcording_Book,D.Recording_Page,
			----A.DocumentNbr,
			--D.Default_AMount,D.Auction_Date,A.RAW_ID,A.[RecordNumber],'F'
			----,C.DATE_ADDED, C.MAX_LIENDATE
			----Select A.*, D.*
			--from w_TransHist as A 
			--join x_Custom_OUTPUT as B on 
			--a.RAW_ID = b.INPUTKEY
			--JOIN [INPUT_MONITOR] as C 
			--on a.Raw_ID = C.INPUTKey
			--join w_preforeclosure as D on A.FIPS = D.FIPS
			--and A.REF_ID = D.REF_ID
			--and A.DocumentNbr = D.Fmt_Inst_Nbr
			--where A.ToUse = 'Y'
			----Order by a.RAW_ID

		
			---------------------How we we know if a FLANK Lis Pendens is HOA related??  There is no Lis Pendens Type---
			--Select * From w_FLANK_NOD


----------------------------------------------------------------------------------------------------------------------------------

	  Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	  --Select A.INPUTKEY, A.RecordingDate, A.DocumentID, B.MAX_NODDATE
	  From  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.INPUTKEY = B.INPUTKEY
	  where convert(Date,B.MAX_NODDATE) >= convert(Date,A.RecordingDate)


	--------------------------STARTHERE20200131--------------------------------
	  --Select * From HOA_NOD
	  Select *  from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
	  where Document_Title_Text = 'NOTICE OF HOMEOWNERS ASSOCIATION'


	  Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
	  where Document_Title_Text = 'NOTICE OF HOMEOWNERS ASSOCIATION'

	  Select Document_Title_Text, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
	  Group by Document_Title_Text
	 

	  	-----Check for dups-----
			Select A.INPUTKEY, A.FIPS,A.Match_REF_ID,A.RecordingDate, A.DocumentId, A.Document_Title_Text From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as A join (
			Select INPUTKEY, RecordingDate, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
			Group by INPUTKEY, RecordingDate
			having count(*) > 1)B on A.INPUTKEY = B.INPUTKEY and A.RecordingDate = B.RecordingDate
			order by A.INPUTKEY, A.RecordingDate

			Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] where Match_REF_ID = '196878235'

			Select * FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Preforeclosure] b
			ON a.REF_ID = b.REF_ID and a.RecordingDate = b.Recording_Date
			and A.DocumentNbr = B.Fmt_Inst_Nbr
			join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.RAW_ID = C.INPUTKEY
			WHERE toUSE = 'Y' 
			AND A.REF_ID = '43528499'

		--SELECT distinct B.FIPS,B.REF_ID,B.INPUTKey
		--,CASE WHEN B.[DocumentID] is null then 
		--case when B.NOD_NOS_Recorded_Document_Number like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.NOD_NOS_Recorded_Document_Number,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.NOD_NOS_Recorded_Document_Number)) end
		--WHEN B.[DocumentID] is NOT null then 
		--case when B.[DocumentID] is not null and B.[DocumentID] like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(B.[DocumentID],'.00','.'),'.0','.'))) ELSE ltrim(rtrim(B.[DocumentID])) END
		--END
		--,convert(varchar(8),B.NOD_NOS_Recording_Date,112)
		----,UPPER(DocumentTypeDesc)
		--,UPPER(LTRIM(RTRIM(REPLACE(D.Full_Name,char(160),''))))
		-------20180720 - Per Bill - Lien Amount is Default Sup table is Default Amount---
		--,LienAmount--,Value
		--,HOAName,MAName,LawName,LawPhone,HOA_Auction_Date
		--,NULL--,ltrim(rtrim(OrigTransRecDate))
		--,NULL--,ltrim(rtrim(OrigTransDocNumber))
		--,0
		--,[SUP]
		-- FROM HOA_NOD_NOS b
		-- left outer join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
		-- on B.DocType = D.DocType
		-- where 
		-- D.HOA_Data_Type in ('NOD/NOS/REO')
		-- AND B.REF_ID = '43528499'





			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
			Set ROwNbr = 0

		
			UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET ROwNbr = RowNum
			FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY INPUTKEY,MATCH_REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] t ) r ON t.MATCH_REF_ID = r.MATCH_REF_ID AND t.DocumentID = r.DocumentID
			and t.INPUTKEY = r.INPUTKEY

	
		Select ROwNbr, count(*) from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD]
		Group by ROwNbr
		Order by ROwNbr

		--Select * From HOA_NOD
		--where MATCH_REF_ID in ('35679608','35294290')

		--Select * From HOA_NOD_NOS
		--where REF_ID in ('35679608','35294290')


	

END






