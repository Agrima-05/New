/* Source: DWS-ETL02.DATATREE.LOCAL | spdb | dbo.usp_PEt_Report | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [SPDB].[dbo].[usp_PEt_Report] 
	@Email_To		varchar(800) = Null,
	@Email_CC		varchar(800) = Null,
	@Email_Bcc		varchar(800) = Null



AS
BEGIN
	Drop Table If Exists  #temp

SELECT   a.FIPS	
			,a.APN_Type
			,a.Source_Apn
			,a.Rule_Description
			,a.[Rule]
			,a.[Status]
			,a.Example_before
			,a.Example_After
			,a.node_delimeter
			,isnull(a.Promote,' ') as Promote
			,cast(b.pet_apn_cnt as char(5)) as pet_apn_cnt
	into  #temp
	FROM [Pet].[dbo].[PET_APN_Additional_Formats] a
	OUTER APPLY (SELECT count(1) AS pet_apn_cnt
				FROM [pet].[dbo].[pet_apn]
				WHERE fips = a.fips
					AND APN_Type = a.APN_Type
				) b
	where pet_apn_cnt = 0
	and a.fips not in (2240)
	order by fips

 
declare 
	@Subject	varchar(200) = 'Daily PET Report',
	@Body		varchar(MAX),
	@Format		varchar(200) = 'html'

declare @BodyContent varchar(max),
		@TableHeader varchar(max),
		@TableFooter varchar(max)

Set @TableFooter = '</table></body></html>';
Set @TableHeader = '<html><head>' +
                  '<style>' +
                  'td {padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;font-family: Arial, Helvetica, sans-serif; font-size: 10pt;} ' +
                  '</style>' +
                  '</head>' +
                  '<body><table cellpadding="5" cellspacing="0" border="1" bordercolor="#000000" style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; border-collapse:collapse;border-bottom-style:solid black;">' +
                  '<tr bgcolor=#FFEFD8>
				   <td align=center style="background-color: #359AFF; color: black"><b>Fips</b></td>' +
                  '<td align=center style="background-color: #359AFF; color: black"><b>APN_Type</b></td>' +
                  '<td align=center style="background-color: #359AFF; color: black"><b>Source_APN</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Rule_Description</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Rule</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Status</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Example_Before</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Example_After</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>node_delimeter</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>Promote</b></td>' +
				  '<td align=center style="background-color: #359AFF; color: black"><b>pet_apn_cnt</b></td>' ;
Select @BodyContent = (
SELECT   FIPS	As [TD]
		,APN_Type As [TD]
		,Source_Apn As [TD] 
		,Rule_Description As [TD]
		,[Rule] As [TD]
		,[Status] As [TD]
		,Example_before As [TD]
		,Example_After As [TD]
		,node_delimeter As [TD]
		,Promote As [TD]
		,pet_apn_cnt  As [TD]
	FROM #Temp
	order by fips
	      For XML raw('tr'), Elements)
	
Set @BodyContent = Replace(@BodyContent, '_x0020_', space(1))
Set @BodyContent = Replace(@BodyContent, '_x003D_', '=')
Set @BodyContent = Replace(@BodyContent, '<tr><ALTCOLOR>1</ALTCOLOR>', '<tr bgcolor=#DFFFDF>')
Set @BodyContent = Replace(@BodyContent, '<ALTCOLOR>0</ALTCOLOR>', '')


Select @BodyContent = @TableHeader + @BodyContent + @TableFooter

exec  msdb.dbo.sp_send_dbmail
   @recipients				= @Email_To
   ,@copy_recipients		= @Email_Cc
   ,@blind_copy_recipients	= @Email_Bcc
   ,@subject				= @Subject
   ,@body					= @BodyContent
   ,@body_format			= @Format

END



