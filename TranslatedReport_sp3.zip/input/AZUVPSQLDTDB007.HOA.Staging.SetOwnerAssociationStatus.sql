/* Source: AZUVNSQLDTDB003.datatree.local | HOA | Staging.SetOwnerAssociationStatus | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */


       CREATE Procedure [HOA].[Staging].[SetOwnerAssociationStatus]
       AS
       --Update oa2
       --Set oa2.StatusId = f.StatusId
       --From Staging.OwnerAssociation oa
       --inner join Staging.OwnerAssociation oa2 on oa2.MatchId = oa.MatchId 
       --inner join Staging.Filter f on oa.Name like f.Filter
       --WHERE oa2.StatusId IN (1)

