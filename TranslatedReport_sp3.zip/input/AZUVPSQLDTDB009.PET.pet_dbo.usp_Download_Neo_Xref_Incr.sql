/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Download_Neo_Xref_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Download_Neo_Xref_Incr] @Fips INT
	,@Neo_Counties VARCHAR(5)
	,@Neo_server VARCHAR(100) 
	,@Land_Id_Ind VARCHAR(6)
	,@Max_Neo_Date DATETIME
	,@Neo_DB VARCHAR(10)
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************          
CHANGE LOG:          
==========          
who  date  change          
           
******************************************************************************************************************/
BEGIN TRY
	SET NOCOUNT ON

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'Download Neo Xref Data'
		,N'Started'

	-- SELECT * FROM pet.Pet_tmp.Pet_Incremental_Counties          
	--DECLARE @Fips INT = 2020          
	-- ,@Neo_Counties VARCHAR(5) = 'AK03'          
	-- ,@Land_Id_Ind VARCHAR(6) = 'FLNS'          
	-- ,@Neo_server VARCHAR(100) = '[AZUVNSQLDTLM008.DATATRACE.LOCAL]'          
	DECLARE @SQL NVARCHAR(max)

	TRUNCATE TABLE pet_tmp.Pet_NEO_Xreff_Full_Fips

	IF @Land_Id_Ind = 'FLNS'
	BEGIN
		SET @SQL = '    
 INSERT INTO         

 
  [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips] (FIPS, NEO_APN, NEO_LAND_TYPE, NEO_TITLE_LEGAL, PORTION_IND)          
 SELECT a.Fips     ,a.NEO_APN     ,a.NEO_LAND_TYPE     ,a.NEO_TITLE_LEGAL     ,CASE WHEN b.pt_cnt > 0 THEN 1 ELSE 0 END AS PORTION_IND           
 FROM (           
   SELECT  Distinct ' + cast(@Fips AS VARCHAR) + ' as Fips        ,LTRIM(RTRIM(b.[dl_land_info])) as NEO_APN        ,c.[LLL_child_dl_land_type]  as NEO_LAND_TYPE        ,d.[dl_land_info] as NEO_TITLE_LEGAL                  
   FROM      ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_name_situs] a             
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[LVL_LAND_LINKS] c on a.flns_dl_land_id = c.LLL_parent_dl_land_id and c.LLL_link_type = ''XR''         
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] b on a.flns_dl_land_id = b.dl_land_id            
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + 
			QUOTENAME(@Neo_Counties) + '.[DIM_land] d on c.LLL_child_dl_land_id = d.dl_land_id           
   where c.lll_Update_Date > ''' + CONVERT(VARCHAR, @Max_Neo_Date, 13) + '''    
   group by a.[FLNS_dl_land_id]           ,c.[LLL_parent_dl_land_id]         ,b.[dl_land_info]         ,c.[LLL_parent_dl_land_type]         ,c.[LLL_link_type]         ,c.[LLL_child_dl_land_id]         ,c.[LLL_child_dl_land_type]         ,d.[dl_land_info]        
  ) a          
 OUTER APPLY (    
  SELECT count(1) AS pt_cnt             
  FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + '[' + @Neo_Counties + ']' + '.[FCT_land_document] g            
  WHERE FLD_dl_land_id IN (    
    SELECT DL_land_id                   
    FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + 
			'.[DIM_land] d         
    WHERE d.[dl_land_info] = a.NEO_TITLE_LEGAL                   
    )              
   AND g.FLD_portion > ''''            
  ) b          
 OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));'

		--PRINT(@SQL)          
		EXEC (@SQL)
	END
			--IF Land_Id_Ind - 'Flnf'          
			--BEGIN          
			--END          
	ELSE IF @Land_Id_Ind = 'FLNF'
	BEGIN
		SET @SQL = (
				N'         
 INSERT INTO           
  [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips] (FIPS, NEO_APN, NEO_LAND_TYPE, NEO_TITLE_LEGAL, PORTION_IND)          
 SELECT      a.Fips      ,a.NEO_APN      ,a.NEO_LAND_TYPE      ,a.NEO_TITLE_LEGAL      ,CASE WHEN b.pt_cnt > 0 THEN 1 ELSE 0 END AS PORTION_IND           
 FROM (          
   SELECT  Distinct ' + cast(@Fips AS VARCHAR) + ' as Fips         ,LTRIM(RTRIM(b.[dl_land_info])) as NEO_APN         ,c.[LLL_child_dl_land_type]as NEO_LAND_TYPE         ,d.[dl_land_info] as NEO_TITLE_LEGAL    
   FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_name_situs_full] a              
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[LVL_LAND_LINKS] c on a.flnf_dl_land_id = c.LLL_parent_dl_land_id and c.LLL_link_type = ''XR''            
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] b on a.flnf_dl_land_id = b.dl_land_id            
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + 
				'].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] d on c.LLL_child_dl_land_id = d.dl_land_id             
   where c.lll_Update_Date > ''' + CONVERT(VARCHAR, @Max_Neo_Date, 13) + '''    
   group by a.[FLNF_dl_land_id]       ,c.[LLL_parent_dl_land_id]          ,b.[dl_land_info]          ,c.[LLL_parent_dl_land_type]          ,c.[LLL_link_type]          ,c.[LLL_child_dl_land_id]          ,c.[LLL_child_dl_land_type]          ,d.[dl_land_info]                  
  ) a    
  OUTER APPLY (    
   SELECT count(1) AS pt_cnt             
   FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_document] g             
   WHERE FLD_dl_land_id IN (    
     SELECT DL_land_id                   
     FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + 
				'.[DIM_land] d                   
     WHERE d.[dl_land_info] = a.NEO_TITLE_LEGAL               )          AND g.FLD_portion > ''''            
    ) b       
  OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));'
				)

		--PRINT(@SQL)          
		EXEC (@SQL)
	END
			--IF Land_Id_Ind - 'FLOF'          
			--BEGIN          
	ELSE IF @Land_Id_Ind = 'FLOF'
	BEGIN
		SET @SQL = (
				'    
 INSERT INTO           
  [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips]  (FIPS, NEO_APN, NEO_LAND_TYPE, NEO_TITLE_LEGAL, PORTION_IND)         
 SELECT a.Fips      ,a.NEO_APN      ,a.NEO_LAND_TYPE      ,a.NEO_TITLE_LEGAL      ,CASE WHEN b.pt_cnt > 0 THEN 1 ELSE 0 END AS PORTION_IND           
 FROM (          
   SELECT  Distinct ' + cast(@Fips AS VARCHAR) + ' as Fips         ,LTRIM(RTRIM(b.[dl_land_info])) as NEO_APN         ,c.[LLL_child_dl_land_type] as NEO_LAND_TYPE         ,d.[dl_land_info] as NEO_TITLE_LEGAL             
   FROM      ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_owner_situs_full] a              
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[LVL_LAND_LINKS] c on a.flof_dl_land_id = c.LLL_parent_dl_land_id and c.LLL_link_type = ''XR''            
   left join ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] b on a.flof_dl_land_id = b.dl_land_id             
   left join ' + QUOTENAME(@Neo_server) + '.[' + 
				@Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] d on c.LLL_child_dl_land_id = d.dl_land_id             
   where c.lll_Update_Date > ''' + CONVERT(VARCHAR, @Max_Neo_Date, 13) + '''    
   group by a.[FLOF_dl_land_id]            ,c.[LLL_parent_dl_land_id]          ,b.[dl_land_info]          ,c.[LLL_parent_dl_land_type]          ,c.[LLL_link_type]          ,c.[LLL_child_dl_land_id]          ,c.[LLL_child_dl_land_type]          ,d.[dl_land_info]        
  ) a          
 OUTER APPLY (    
  SELECT count(1) AS pt_cnt             
  FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_document] g             
  WHERE FLD_dl_land_id IN (    
    SELECT DL_land_id                   
    FROM ' + QUOTENAME(@Neo_server) + '.[' + @Neo_DB + '].' + QUOTENAME(@Neo_Counties) + 
				'.[DIM_land] d                   
    WHERE d.[dl_land_info] = a.NEO_TITLE_LEGAL                   
   )    
   AND g.FLD_portion > ''''            
  ) b           
 OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));    
'
				)

		--PRINT(@SQL)          
		EXEC (@SQL)
	END
			--END          
			--IF Land_Id_Ind - 'FLOFHI'          
			--BEGIN          
			--END          
			--did not make the neo database portion dynamic unlike the other queries because none of the HI counties seem to be apart of the Neo_WA counties  
	ELSE IF @Land_Id_Ind = 'FLOFHI'
	BEGIN
		SET @SQL = (
				'    
 INSERT INTO           
  [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips]  (FIPS, NEO_APN, NEO_LAND_TYPE, NEO_TITLE_LEGAL, PORTION_IND)           
 SELECT a.Fips       ,a.NEO_APN       ,a.NEO_LAND_TYPE       ,a.NEO_TITLE_LEGAL       ,CASE WHEN b.pt_cnt > 0 THEN 1 ELSE 0 END AS PORTION_IND            
 FROM (           
  SELECT  Distinct ' + cast(@Fips AS VARCHAR) + ' as Fips          ,LTRIM(RTRIM(b.[dl_land_info])) as NEO_APN          ,c.[LLL_child_dl_land_type] as NEO_LAND_TYPE          ,d.[dl_land_info] as NEO_TITLE_LEGAL    
  FROM      ' + QUOTENAME(@Neo_server) + '.[NEO].' + QUOTENAME(@Neo_Counties) + '.[FCT_land_owner_situs_full] a               
  left join ' + QUOTENAME(@Neo_server) + '.[NEO].' + QUOTENAME(@Neo_Counties) + '.[LVL_LAND_LINKS] c on a.flof_dl_land_id = c.LLL_parent_dl_land_id and c.LLL_link_type = ''XR''            
  left join ' + QUOTENAME(@Neo_server) + '.[NEO].' + QUOTENAME(@Neo_Counties) + '.[DIM_land] b on a.flof_dl_land_id = b.dl_land_id            
  left join ' + QUOTENAME(@Neo_server) + 
				'.[NEO].[HIHI].[DIM_land] d on c.LLL_child_dl_land_id = d.dl_land_id         
  where c.lll_Update_Date > ''' + CONVERT(VARCHAR, @Max_Neo_Date, 13) + '''    
  group by a.[FLOF_dl_land_id]      ,c.[LLL_parent_dl_land_id]           ,b.[dl_land_info]           ,c.[LLL_parent_dl_land_type]           ,c.[LLL_link_type]           ,c.[LLL_child_dl_land_id]           ,c.[LLL_child_dl_land_type]           ,d.[dl_land_info]             
  ) a          
 OUTER APPLY (    
  SELECT count(1) AS pt_cnt              
  FROM ' + QUOTENAME(@Neo_server) + '.[NEO].[HIHI].[FCT_land_document] g              
  WHERE FLD_dl_land_id IN (    
    SELECT DL_land_id                    
    FROM ' + QUOTENAME(@Neo_server) + 
				'.[NEO].[HIHI].[DIM_land] d                    
    WHERE d.[dl_land_info] = a.NEO_TITLE_LEGAL                    
   )               
   AND g.FLD_portion > ''''             
  ) b             
 OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''))        '
				)

		--PRINT(@SQL)          
		EXEC (@SQL)
	END

	INSERT INTO [pet].[pet_tmp].[Pet_NEO_Xreff_Full_Fips_detail] (
		[FIPS]
		,[NEO_APN]
		,[NEO_LAND_TYPE]
		,[NEO_TITLE_LEGAL]
		,[PORTION_IND]
		,[Created]
		)
	SELECT [FIPS]
		,[NEO_APN]
		,[NEO_LAND_TYPE]
		,[NEO_TITLE_LEGAL]
		,[PORTION_IND]
		,getdate() as Created
	FROM [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips]

	EXEC [PET].[dbo].[AddPetLog] @Fips
		,N'info'
		,N'Download Neo Xref Data'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


