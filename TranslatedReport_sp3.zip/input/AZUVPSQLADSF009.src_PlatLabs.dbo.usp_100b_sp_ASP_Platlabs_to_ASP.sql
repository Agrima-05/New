SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [src_PlatLabs].[dbo].[usp_100b_sp_ASP_Platlabs_to_ASP]
AS
BEGIN

declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


truncate table [dbo].[a_ASP_IN]
truncate table [dbo].[a_ASP_IN_STD]

truncate table [dbo].[Platlabs]
truncate table [dbo].[Platlabs_STD]

INSERT INTO [src_PlatLabs].[dbo].[a_ASP_IN]([RAW_ID]
		,[FullStreetAddress]
		,[City]
		,[State]
		,[ZIP5])
SELECT [uid]
		,LTRIM(RTRIM(UPPER(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(isNULL([street_number],'') + ' ' + isNULL([RawPreDir],''))) + ' ' + isNULL([street_name],''))) + ' ' + isNULL([street_suffix],''))) + ' ' + isNULL([RawPostDir],''))) + ' ' + isNULL([secondary_number],''))))))
		,LEFT(ltrim(rtrim([RawCity])),255)
		,LEFT(ltrim(rtrim([RawState])),2)
		,LEFT(ltrim(rtrim([RawZip])),5)
FROM [src_PlatLabs].[addr].[RawAddress_Batch]
WHERE [uid] is not null 
and LTRIM(RTRIM(UPPER(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(isNULL([RawStreetNbr],'') + ' ' + isNULL([RawPreDir],''))) + ' ' + isNULL([RawStreet],''))) + ' ' + isNULL([RawMode],''))) + ' ' + isNULL([RawPostDir],''))) + ' ' + isNULL([unit_number],'')))))) Not like ''


		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN]
		SET FullStreetAddress = REPLACE(FullStreetAddress,'  ',' ')
		WHERE FullStreetAddress like '%  %'

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN]
		SET FullStreetAddress = ltrim(rtrim([global].[dbo].[BeforeLastCharacter](FullStreetAddress, ' ')))
		where [global].[dbo].[AfterLastCharacter]([global].[dbo].[Before2ndCharacter]([FullStreetAddress],' ') ,' ') = [global].[dbo].[AfterLastCharacter]([FullStreetAddress],' ')
		and Ltrim(RTrim(FullStreetAddress)) like '% [A-Z]% %'

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
		SET FullStreetAddress = ltrim(rtrim(replace(replace(replace(FullStreetAddress,[Zip5],''),[STATE],''),[CITY],'')))
		WHERE FullStreetAddress LIKE '%' + [City] + '%' + [State] + '%' + [Zip5]
		and [Zip5] not like '' and isNULL([State],'') not like '' and isNULL([City],'') not like ''

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
		SET FullStreetAddress = ltrim(rtrim(replace(replace(FullStreetAddress,[STATE],''),[CITY],'')))
		WHERE FullStreetAddress LIKE '%' + [City] + '%' + [State] 
		and [Zip5] like '' and isNULL([State],'') not like '' and isNULL([City],'') not like ''

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
		SET FullStreetAddress = ltrim(rtrim(replace(replace([Global].[dbo].[BeforeLastSpace](FullStreetAddress),[STATE],''),[CITY],'')))
		 From [src_PlatLabs].[dbo].[a_ASP_IN]
		where FullStreetAddress like '% [0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]'
		or FullStreetAddress like '% [0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9]'
		or FullStreetAddress like '% [0-9][0-9][0-9][0-9][0-9]-[0-9][0-9]'
		or FullStreetAddress like '% [0-9][0-9][0-9][0-9][0-9]-[0-9]'

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
		SET FullStreetAddress = ltrim(rtrim(replace(replace(FullStreetAddress,[STATE],''),[CITY],'')))
		WHERE FullStreetAddress LIKE '%' + [City] + '%' + [State] 
		and [Zip5] NOT like '' and [State] not like '' and [City] not like ''

		UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
		SET FullStreetAddress = substring(FullStreetAddress,1, CharIndex('@',FullStreetAddress)-1)
		WHERE Ltrim(rtrim(FullStreetAddress)) LIKE '%@%'

		update [src_PlatLabs].[dbo].[a_ASP_IN] SET ZIP5 = NULL Where ZIP5 like '%[a-z]%'

		update [src_PlatLabs].[dbo].[a_ASP_IN] SET State = NULL Where len(STATE)>2

			update [src_PlatLabs].[dbo].[a_ASP_IN] set FullStreetAddress = '' where FullStreetAddress like '-'
			update [src_PlatLabs].[dbo].[a_ASP_IN] set FullStreetAddress = '' where FullStreetAddress like '.'
			update [src_PlatLabs].[dbo].[a_ASP_IN] set FullStreetAddress = '' where FullStreetAddress like 'TBD%'
			update [src_PlatLabs].[dbo].[a_ASP_IN] set FullStreetAddress = '' where LEN(FullStreetAddress) = 1
		
		Delete from [src_PlatLabs].[dbo].[a_ASP_IN] where FullStreetAddress like ''

		--Select * from a_ASP_IN where RAW_ID is null

IF (Select COUNT(*) FROM [src_PlatLabs].[dbo].[a_ASP_IN] with(NOLOCK) WHERE Processed = 'N') > 0 
	BEGIN

		WHILE (Select COUNT(*) FROM [src_PlatLabs].[dbo].[a_ASP_IN] with(NOLOCK) WHERE Processed = 'N') > 0
			BEGIN
				
				truncate table [dbo].[Platlabs]
				truncate table [dbo].[Platlabs_STD]

				INSERT INTO [src_PlatLabs].[dbo].[Platlabs](RecordId,[FullStreetAddress],[City],[State],[Zip],[raw_id])
				SELECT TOP 200000 ASP_ID
				,replace(replace(replace(LEFT([FullStreetAddress],255),'.',''),'$',''),',','')
				,replace(replace(replace(LEFT([City],55),'.',''),'$',''),',','')
				,[State]
				,CASE WHEN Right('00000' + [ZIP5],5) = '00000' THEN NULL ELSE Right('00000' + [ZIP5],5) END,[RAW_ID]
				FROM [src_PlatLabs].[dbo].[a_ASP_IN] 
				WHERE PROCESSED = 'N'
				AND isNULL(FullStreetAddress,'') NOT IN('',',','.','-')
				and (replace(replace(replace(LEFT([City],55),'.',''),'$',''),',','') is NOT NULL OR CASE WHEN Right('00000' + [ZIP5],5) = '00000' THEN NULL ELSE Right('00000' + [ZIP5],5) END is NOT NULL)
				ORDER BY RAW_ID --and STATE Not like 'PR'


				EXEC('INSERT INTO  [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
				 (''Platlabs'',''Platlabs'',''B'',''R'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
				 ')

			---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

					IF (SELECT COUNT(*) FROM [src_PlatLabs].[dbo].[Platlabs] with(NOLOCK)) = 0
						BEGIN
							RETURN;
						END
					ELSE
						BEGIN
							---- 1 min wait periods until ASP is complete
							DECLARE @CheckASP as int
				
								SET @CheckASP = 0

							WHILE @CheckASP = 0
								BEGIN
									WAITFOR DELAY '00:00:30'
							
								---- Checks for completion ** If not wait again
								SET @CheckASP = (Select COUNT(*) from [src_PlatLabs].[dbo].[Platlabs_STD] with(NOLOCK))
								END
						END

				EXEC [src_PlatLabs].[dbo].[usp_100c_sp_ASP_Platlabs_STD]

				UPDATE [src_PlatLabs].[dbo].[a_ASP_IN] 
				SET Processed = 'Y'
				WHERE ASP_ID in(Select ASP_ID from [src_PlatLabs].[dbo].[a_ASP_IN_STD])

			END
	END

	update [src_PlatLabs].[dbo].[a_ASP_IN_STD] set FIPS = '0' + FIPS where LEN(FIPS)=4

	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END



