SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- Description:	Address Match to up Property
-- =============================================
CREATE PROCEDURE [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V9_FLANK_PreMatch_PlatLabs] 
	@SrcDB as varchar(50)
AS
BEGIN
	
	SET NOCOUNT ON;

	/*******************************************************************************
	---INPUT_IN Table MUST CONTAIN INPUTBorrowerLastName and INPUTAPN Fields----
	********************************************************************************/

	EXEC('truncate table ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]')

			EXEC('INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]([ASP_ID]
				  ,[FullStreetAddress]
				  ,[HouseNbr]
				  ,[LeftDirection]
				  ,[Street]
				  ,[Mode]
				  ,[RightDirection]
				  ,[UnitNumber]
				  ,[City]
				  ,[State]
				  ,[Zip]
				  ,[Zip4]
				  ,[Zip9]
				  ,[FIPS]
				  ,[CountyName]
 				  ,[BorrowerLastName]
				 ,[RAW_ID]
				 ,[INPUTAPN])
				Select distinct [ASP_ID]
				  ,[FullStreetAddress]
				  ,[HouseNbr]
				  ,[LeftDirection]
				  ,[Street]
				  ,[Mode]
				  ,[RightDirection]
				  ,[UnitNumber]
				  ,a.[City]
				  ,a.[State]
				  ,a.[Zip]
				  ,a.[Zip4]
				  ,RIGHT((''0'' + a.[zip]),5) + isNULL(a.[zip4],'''') as [Zip9]
				  ,A.[FIPS]
				  ,[CountyName]
				  ,NULL
				  ,[RAW_ID]
				  ,NULL
				  from ' + @SrcDB + '.dbo.[a_ASP_IN_STD] a JOIN ' + @SrcDB + '.[listing].[ListingsRaw_Batch] b
				  on a.[RAW_ID] = b.[uid]')


-- Post append clean up
	BEGIN TRANSACTION PostAppendCleanUP

		EXEC('UPDATE a 
		SET a.PropertyID = b.PropertyID
		,MatchQuery = ''00''
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[w_PreMatch] b
		ON a.[RAW_ID] = b.[RAW_ID]
		Where isNULL(b.Propertyid,0) <> 0
		')

		EXEC('UPDATE ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]
		SET Street = left([Global].[dbo].[BeforeLastSpace](substring(street,1,LEN(Street)-(LEN(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex(''%[a-z]%'', REVERSE(street)) - 1)))))),55)
		,UnitNumber = left(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex(''%[a-z]%'', REVERSE(street)) - 1)),15)
		WHERE REF_ID is null 
			AND Street like ''% %[a-z][0-9]%[0-9]'' or street like ''% %[a-z][0-9]''
		')

		EXEC('UPDATE ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]
		SET HouseNbr = left(REPLACE(HouseNbr,LeftDirection,''''),30)
		WHERE isNULL(LeftDirection,'''') not like '''' AND HouseNbr like ''%'' + LeftDirection
		')

		EXEC('UPDATE ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]
		SET INPUTAPN = NULL
		WHERE INPUTAPN = ''0'' or INPUTAPN = ''''')

	COMMIT TRANSACTION PostAppendCleanUP

	BEGIN TRANSACTION APNMatch

	EXEC('TRUNCATE TABLE ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]')
	
	EXEC('IF (Select COUNT(*) from ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] where isNULL(INPUTAPN,'''') NOT LIKE '''') >1
		BEGIN
			-- Match 0 on FIPS AND APN
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND r.INPUTAPN = d.FormattedAPN
						where r.PropertyID is NULL
						and r.INPUTAPN is not null AND  r.INPUTAPN not like ''''
					
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery = CASE WHEN MatchQuery is null then 0 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL


				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND replace(replace(replace(r.INPUTAPN,''-'',''''),''.'',''''),'':'','''') = d.FORMATTEDAPN
			WHERE r.PropertyID is NULL  
			AND  r.INPUTAPN is not null AND  r.INPUTAPN not like ''''
							
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery = CASE WHEN MatchQuery is null then 0 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND r.INPUTAPN = d.TaxAccountNumber
			WHERE r.PropertyID is NULL  
			AND  r.INPUTAPN is not null AND  r.INPUTAPN not like ''''
							
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery = CASE WHEN MatchQuery is null then 0 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

		INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
			  ,[FIPS]
			  ,[REF_ID]
			  ,[UNFORMATTED_APN]
			  ,[APN_SEQUENCE_NBR]
			  ,[FORMATTED_APN]
			  ,[ORIGINAL_APN]
			  ,[PREVIOUS_PARCEL_NBR]
			  ,[P_ID_IRIS_FRMTD]
			  ,[ALTERNATE_APN]
			  ,[ACCOUNT_NBR]
			  ,[SITUS_HOUSE_NBR]
			  ,[SITUS_HOUSE_NBR_#2]
			  ,[SITUS_HOUSE_NBR_SUFFIX]
			  ,[SITUS_DIRECTION]
			  ,[SITUS_STREET_NAME]
			  ,[SITUS_MODE]
			  ,[SITUS_QUADRANT]
			  ,[SITUS_UNIT_NBR]
			  ,[SITUS_CITY]
			  ,[SITUS_STATE]
			  ,[SITUS_ZIP_CODE]
			  ,[PropHseNbr]
			  ,[PropStName]
			  ,[PropUnit]
			  ,[MatchFlg]
			  ,[OWN1_LAST_NAME]
			  ,[RAW_ID])
		SELECT d.[PropertyID]
			  ,d.[FIPS]
			  ,d.[PropertyID]
			  ,[UnformattedAPN]
			  ,[APNSeqNbr]
			  ,[FormattedAPN]
			  ,NULL
			  ,[OldAPN]
			  ,NULL
			  ,NULL
			  ,[TaxAccountNumber]
			  ,[SitusStdHouseNbr]
			  ,[SitusStdHouseNbr2]
			  ,[SitusStdHouseNbrSuffix]
			  ,[SitusStdDirectionLeft]
			  ,[SitusStdStreet]
			  ,[SitusStdMode]
			  ,[SitusStdDirectionRight]
			  ,[SitusStdUnitNbr]
			  ,[SitusStdCity]
			  ,[SitusStdState]
			  ,[SitusStdZIP5]
			  ,[SitusStdHouseNbr]
			  ,[SitusStdStreet]
			  ,[SitusStdUnitNbr]
			  ,NULL
			  ,[OwnerStd1LastName]
			  ,[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON r.[FIPS] = d.[FIPS]
				and replace(replace(replace(r.INPUTAPN,''-'',''''),''.'',''''),'' '','''') = replace(replace(replace(d.FORMATTEDAPN,''-'',''''),''.'',''''),'' '','''')
				WHERE r.PropertyID is null
				AND  r.INPUTAPN is not null AND  r.INPUTAPN not like ''''

					
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery = CASE WHEN MatchQuery is null then 0 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL


		END
	')


	COMMIT TRANSACTION APNMatch

	BEGIN TRANSACTION LastNameWork

	EXEC('IF(Select COUNT(*) FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] WHERE isNULL(BorrowerLastName,'''') NOT LIKE '''')>0
		BEGIN

		-- Match 00 on FIPS, FullStreetAddress, Zip9, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND r.[FullStreetAddress] = d.[SitusStdFullStreetAddress]
								AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.FullStreetAddress,'''') not like '''' 
				AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then ''00'' ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL


		-- Match 00 on FIPS, FullStreetAddress, Zip9, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND r.[FullStreetAddress] = d.[SitusStdFullStreetAddress]
								AND r.Zip = [SitusStdZip5]
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.FullStreetAddress,'''') not like '''' 
				AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then ''00'' ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL


			
		-- Match 1 on FIPS, StNbr, StNbr2, StName, Unit, Zip9, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
									AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))-- OR replace(d.[SitusStdUnitNbr],''-'','''') like ''%'' + replace(r.UnitNumber,''-'','''') + ''%'')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
					AND isNULL(r.UnitNumber,'''') not like '''' 
						AND isNULL(r.Street,'''') not like '''' 
							AND r.HouseNbr like ''%-%''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 1 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 2 on FIPS, StNbr, StName, Unit, Zip9, NAME
		
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
				AND r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street Like d.[SitusStdStreet] + ''%''
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
							AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))-- OR replace(d.[SitusStdUnitNbr],''-'','''') like ''%'' + replace(r.UnitNumber,''-'','''') + ''%'')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 2 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 3 on FIPS, StNbr, StNbr2, StName, Unit, Zip5, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
									AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))
										AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND r.HouseNbr like ''%-%''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 3 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 4 on FIPS, StNbr, StNbr2, StName, Zip9, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND r.HouseNbr like ''%-%''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 4 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 5 on FIPS, StNbr, StNbr2, StName, Zip5, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip = [SitusStdZip5]
									AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND r.HouseNbr like ''%-%''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 5 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 5a on FIPS, StNbr, StNbr2, StName, Zip5, NAME
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.[City] = d.[SitusStdCity]
									AND r.[State] = d.[SitusStdState]
										AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND r.HouseNbr like ''%-%''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then ''5a'' ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 6 on FIPS, StNbr, StName, Zip9, NAME
			
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]		
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
				AND r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.Street ,'''') not like '''' 
				AND isNULL(r.HouseNbr,'''') not like ''''
					AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 6 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 7 on FIPS, StNbr, StName, Unit, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
				AND r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
							AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''') OR replace(d.[SitusStdUnitNbr],''-'','''') like ''%'' + replace(r.UnitNumber,''-'','''') + ''%'')
								AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 7 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 8 on FIPS, StNbr, StName, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
				AND r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.Street ,'''') not like '''' 
				AND isNULL(r.HouseNbr,'''') not like ''''
					AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 8 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 9 on  StNbr+StNbrSuffix, StName, Unit, Zip9, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 9 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 10 on  StNbr+StNbrSuffix, StName+Mode, Unit, Zip9, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND ltrim(rtrim(r.Street + '' '' + r.Mode))=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 10 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 11 on  StNbr+StNbrSuffix, StName, Zip9, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
						AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.Street ,'''') not like '''' 
				AND isNULL(r.HouseNbr,'''') not like ''''
					AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 11 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 12 on  StNbr+StNbrSuffix, StName+Mode, Zip9, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND ltrim(rtrim(r.Street + '' '' + r.Mode))=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
						AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.Street ,'''') not like '''' 
				AND isNULL(r.HouseNbr,'''') not like ''''
					AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 12 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 13 on  StNbr+StNbrSuffix, StName, Unit, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 13 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 14 on  StNbr+StNbrSuffix, StName+Mode, Unit, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL  
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 14 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 15 on  StNbr+StNbrSuffix, StName, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 15 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 16 on  StNbr+StNbrSuffix, StName+Mode, Zip5, NAME

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			 AND r.HouseNbr = right( d.[SitusStdHouseNbr] + CASE WHEN d.[SitusStdHouseNbrSuffix] is NULL THEN '''' ELSE d.[SitusStdHouseNbrSuffix] END,10)
				AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
						AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 16 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 17 on  StNbr, StName, Unit, Zip9, NAME --NO FIPS
					
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON r.HouseNbr = d.[SitusStdHouseNbr]
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 17 ELSE MatchQuery END
		,a.FIPS = b.FIPS
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 18 on StNbr, StName, Zip9, NAME --NO FIPS
			
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON r.HouseNbr = d.[SitusStdHouseNbr]
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
			WHERE r.PropertyID is NULL  
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 18 ELSE MatchQuery END
		,a.FIPS = b.FIPS
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL
	
		-- Match 19 on StNbr, StName, Unit, Zip5, NAME --NO FIPS

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON r.HouseNbr = d.[SitusStdHouseNbr]
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
						AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL 
			AND isNULL(r.UnitNumber,'''') not like '''' 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 19 ELSE MatchQuery END
		,a.FIPS = b.FIPS
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 20 on StNbr, StName, Zip5, NAME --NO FIPS

			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON r.HouseNbr = d.[SitusStdHouseNbr]
				AND r.Street=  d.[SitusStdStreet]
					AND r.Zip = ltrim(rtrim(isNull(LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5),'''')))
							AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL 
			AND isNULL(r.Street ,'''') not like '''' 
				AND isNULL(r.HouseNbr,'''') not like ''''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''

		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 20 ELSE MatchQuery END
		,a.FIPS = b.FIPS
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 21 FIPS, StreetNumber, First Part of Street Name, Zip, LastName 
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			AND r.HouseNbr = d.[SitusStdHouseNbr]
				AND LEFT(d.[SitusStdStreet],5)= LEFT(Ltrim(Rtrim(replace(r.[FullStreetAddress],[SitusStdHouseNbr],''''))),5)
					AND LEFT(d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],''''),5) = LEFT([Zip],5)
						AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL 
			AND isNULL(r.Street ,'''') not like '''' 
				AND BorrowerLastName not like ''''
					AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
						AND isNULL(r.BorrowerLastName,'''') not like ''''
				 
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 21 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 22 FIPS, Street Number, Street Name, LastName 
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]		
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
			ON convert(int,r.FIPS) = convert(int,d.FIPS)
			AND r.HouseNbr = d.[SitusStdHouseNbr]
				AND d.[SitusStdStreet] = r.[Street]
					AND Left(d.OwnerStd1LastName,4) = Left(r.BorrowerLastName,4)
		WHERE r.PropertyID is NULL 
			AND isNULL(r.Street ,'''') not like '''' 
				AND BorrowerLastName not like ''''
						AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
							AND isNULL(r.BorrowerLastName,'''') not like ''''
				 
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then 22 ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		END

	')
		---- NO NAMES


	COMMIT TRANSACTION LastNameWork

		-- Match 23 on FIPS, StNbr, StName+Mode, Unit, Zip9
	BEGIN TRANSACTION MandA
		
			EXEC('
				BEGIN

				-- Match 00 on FIPS, FullStreetAddress, Zip9, NAME
					INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
						  ,[FIPS]
						  ,[REF_ID]
						  ,[UNFORMATTED_APN]
						  ,[APN_SEQUENCE_NBR]
						  ,[FORMATTED_APN]
						  ,[ORIGINAL_APN]
						  ,[PREVIOUS_PARCEL_NBR]
						  ,[P_ID_IRIS_FRMTD]
						  ,[ALTERNATE_APN]
						  ,[ACCOUNT_NBR]
						  ,[SITUS_HOUSE_NBR]
						  ,[SITUS_HOUSE_NBR_#2]
						  ,[SITUS_HOUSE_NBR_SUFFIX]
						  ,[SITUS_DIRECTION]
						  ,[SITUS_STREET_NAME]
						  ,[SITUS_MODE]
						  ,[SITUS_QUADRANT]
						  ,[SITUS_UNIT_NBR]
						  ,[SITUS_CITY]
						  ,[SITUS_STATE]
						  ,[SITUS_ZIP_CODE]
						  ,[PropHseNbr]
						  ,[PropStName]
						  ,[PropUnit]
						  ,[MatchFlg]
						  ,[OWN1_LAST_NAME]
						  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
					FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
						 on  convert(int,r.FIPS) = convert(int,d.FIPS)
							AND r.[FullStreetAddress] = d.[SitusStdFullStreetAddress]
								AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
					WHERE r.PropertyID is NULL  
						AND isNULL(r.FullStreetAddress,'''') not like '''' 
							AND isNULL([SitusStdZip4],'''') not like ''''

				UPDATE a 
				SET a.[PropertyID] = b.[REF_ID]
				,a.MatchQuery =  CASE WHEN MatchQuery is null then ''00'' ELSE MatchQuery END
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
				ON a.RAW_ID = b.RAW_ID
				WHERE a.PropertyID is NULL


				-- Match 00 on FIPS, FullStreetAddress, Zip9, NAME
					INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
						  ,[FIPS]
						  ,[REF_ID]
						  ,[UNFORMATTED_APN]
						  ,[APN_SEQUENCE_NBR]
						  ,[FORMATTED_APN]
						  ,[ORIGINAL_APN]
						  ,[PREVIOUS_PARCEL_NBR]
						  ,[P_ID_IRIS_FRMTD]
						  ,[ALTERNATE_APN]
						  ,[ACCOUNT_NBR]
						  ,[SITUS_HOUSE_NBR]
						  ,[SITUS_HOUSE_NBR_#2]
						  ,[SITUS_HOUSE_NBR_SUFFIX]
						  ,[SITUS_DIRECTION]
						  ,[SITUS_STREET_NAME]
						  ,[SITUS_MODE]
						  ,[SITUS_QUADRANT]
						  ,[SITUS_UNIT_NBR]
						  ,[SITUS_CITY]
						  ,[SITUS_STATE]
						  ,[SITUS_ZIP_CODE]
						  ,[PropHseNbr]
						  ,[PropStName]
						  ,[PropUnit]
						  ,[MatchFlg]
						  ,[OWN1_LAST_NAME]
						  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
					FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
						 on  convert(int,r.FIPS) = convert(int,d.FIPS)
							 AND r.[FullStreetAddress] = d.[SitusStdFullStreetAddress]
								AND r.Zip = [SitusStdZip5]
					WHERE r.PropertyID is NULL  
						AND isNULL(r.FullStreetAddress,'''') not like '''' 

				UPDATE a 
				SET a.[PropertyID] = b.[REF_ID]
				,a.MatchQuery =  CASE WHEN MatchQuery is null then ''00'' ELSE MatchQuery END
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
				ON a.RAW_ID = b.RAW_ID
				WHERE a.PropertyID is NULL




					INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
							AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
								AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''') 
								--OR replace(d.[SitusStdUnitNbr],''-'','''') like ''%'' + replace(r.UnitNumber,''-'','''') + ''%''
								)
				WHERE r.PropertyID is NULL 
					AND isNULL(r.UnitNumber,'''') not like '''' 
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 23 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 24 on FIPS, StNbr, StName, Unit, Zip9
		
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.Street=  d.[SitusStdStreet]
							AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
								AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))
				WHERE r.PropertyID is NULL 
					AND isNULL(r.UnitNumber,'''') not like '''' 
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 24 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 25 on FIPS, StNbr, StName+Mode, Unit, Zip5

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
							AND r.Zip = d.[SitusStdZip5]
								AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 25 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 26 on FIPS, StNbr, StName, Unit, Zip5

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.Street=  d.[SitusStdStreet]
							AND r.Zip = d.[SitusStdZip5]
								AND (replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'',''''))
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 26 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 27 on FIPS, StNbr, StName, Zip9
		
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.Street=  d.[SitusStdStreet]
							AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
			WHERE r.PropertyID is NULL 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 27 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 28 on FIPS, StNbr, StName+Mode, Zip9
		
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
							AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
			WHERE r.PropertyID is NULL 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 28 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL


		-- Match 28a on FIPS, StNbr, StNbr2, StName, Zip5
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip = [SitusStdZip5]
			WHERE r.PropertyID is NULL  
					AND isNULL(r.Street ,'''') not like '''' 
						AND r.HouseNbr like ''%-%''
							AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then ''28a'' ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL

		-- Match 28b on FIPS, StNbr, StNbr2, StName, City, State
			INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
				  ,[FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[SITUS_HOUSE_NBR]
				  ,[SITUS_HOUSE_NBR_#2]
				  ,[SITUS_HOUSE_NBR_SUFFIX]
				  ,[SITUS_DIRECTION]
				  ,[SITUS_STREET_NAME]
				  ,[SITUS_MODE]
				  ,[SITUS_QUADRANT]
				  ,[SITUS_UNIT_NBR]
				  ,[SITUS_CITY]
				  ,[SITUS_STATE]
				  ,[SITUS_ZIP_CODE]
				  ,[PropHseNbr]
				  ,[PropStName]
				  ,[PropUnit]
				  ,[MatchFlg]
				  ,[OWN1_LAST_NAME]
				  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				 on  convert(int,r.FIPS) = convert(int,d.FIPS)
					 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
						AND SUBSTRING(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)), PATINDEX(''%[^0 ]%'',SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)) + '' ''), LEN(SubString(r.HouseNbr,Charindex(''-'',r.HouseNbr)+1,LEN(r.HouseNbr)))) = SUBSTRING([SitusStdHouseNbr2], PATINDEX(''%[^0 ]%'', [SitusStdHouseNbr2] + '' ''), LEN([SitusStdHouseNbr2]))
							AND r.Street= d.[SitusStdStreet]
								AND r.[City] = d.[SitusStdCity]
									AND r.[State] = d.[SitusStdState]
			WHERE r.PropertyID is NULL  
					AND isNULL(r.Street ,'''') not like '''' 
						AND r.HouseNbr like ''%-%''
							AND isNULL(d.[SitusStdUnitNbr],'''')  like ''''
			
		UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,a.MatchQuery =  CASE WHEN MatchQuery is null then ''28b'' ELSE MatchQuery END
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID
		WHERE a.PropertyID is NULL




			-- Match 29 on FIPS, StNbr, StName, Zip5

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.Street=  d.[SitusStdStreet]
							AND r.Zip = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 29 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 30 on FIPS, StNbr, StName+Mode, Zip5

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
							AND r.Zip = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 30 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL



			-- Match 31 on  StNbr, StName, Unit, Zip9 --NO FIPS
					
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
							AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 31 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 32 on  StNbr, StName+Mode, Unit, Zip9 --NO FIPS
					
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND ltrim(rtrim(r.Street + '' '' + r.Mode)) = d.[SitusStdStreet]
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
							AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 32 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 33 on StNbr, StName, Zip9 --NO FIPS
			
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 33 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL
	
			-- Match 34 on StNbr, StName+Mode, Zip9 --NO FIPS
			
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
						AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 34 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL
	
			-- Match 35 on StNbr, StName, Unit, Zip5 --NO FIPS

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip = d.[SitusStdZip5]
							AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 35 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 36 on StNbr, StName+Mode, Unit, Zip5 --NO FIPS

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
						AND r.Zip = d.[SitusStdZip5]
							AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
			WHERE r.PropertyID is NULL 
				AND isNULL(r.UnitNumber,'''') not like '''' 
					AND isNULL(r.Street ,'''') not like '''' 
						AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 36 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 37 on StNbr, StName, Zip5 --NO FIPS

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND r.Street=  d.[SitusStdStreet]
						AND r.Zip = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 37 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 38 on StNbr, StName+Mode, Zip5 --NO FIPS

				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON r.HouseNbr = d.[SitusStdHouseNbr]
					AND ltrim(rtrim(r.Street + '' '' + r.Mode)) =  d.[SitusStdStreet]
						AND r.Zip = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL 
				AND isNULL(r.Street ,'''') not like '''' 
					AND isNULL(r.HouseNbr,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 38 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 39 on FIPS, First Part of StNbr with DASH, StName, Unit, Zip5
			
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 on  convert(int,r.FIPS) = convert(int,d.FIPS)
						 AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
							AND r.Street= d.[SitusStdStreet]
								AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
									AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
				WHERE r.PropertyID is NULL  
						AND isNULL(r.UnitNumber,'''') not like '''' 
							AND isNULL(r.Street ,'''') not like '''' 
								AND r.HouseNbr like ''%-%''
			
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 39 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 40 on FIPS, First Part of StName, StNumber, Unit, Zip9 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 ON convert(int,r.FIPS) = convert(int,d.FIPS)
						 AND SubString(r.Street,1,5) = SubString(d.[SitusStdStreet],1,5)
							AND r.HouseNbr = d.[SitusStdHouseNbr]
								AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
									AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
				WHERE r.PropertyID is NULL  
						AND isNULL(r.UnitNumber,'''') not like '''' 
							AND isNULL(r.Street ,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 40 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 41 on FIPS, First Part of StName, StNumber, Zip9 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 ON convert(int,r.FIPS) = convert(int,d.FIPS)
						 AND SubString(r.Street,1,5) = SubString(d.[SitusStdStreet],1,5)
							AND r.HouseNbr = d.[SitusStdHouseNbr]
									AND r.Zip9 = [SitusStdZip5] + isNULL([SitusStdZip4],'''')
				WHERE r.PropertyID is NULL  
						AND isNULL(r.Street ,'''') not like ''''

			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 41 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 42 on FIPS, First Part of StNbr with DASH, StName, Zip5 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND SubString(r.HouseNbr,1,Charindex(''-'',r.HouseNbr)-1) = d.[SitusStdHouseNbr]
							AND r.Street= d.[SitusStdStreet]
								AND d.[SitusStdZip5] = LEFT([Zip],5)
				WHERE r.PropertyID is NULL  
						AND isNULL(r.Street ,'''') not like '''' 
							AND  r.HouseNbr like ''%-%''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 42 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 43 FIPS, StreetNumber, First Part of Street Name, Zip, UNIT 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND r.HouseNbr = d.[SitusStdHouseNbr]
							AND LEFT(r.Street,5)= LEFT(d.[SitusStdStreet],5)
								AND d.[SitusStdZip5] = LEFT([Zip],5)
									AND replace(r.UnitNumber,''-'','''') = replace(d.[SitusStdUnitNbr],''-'','''')
				WHERE r.PropertyID is NULL  
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL([SitusStdUnitNbr],'''') not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 43 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 44 FIPS, StreetNumber, First Part of Street Name, Zip 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
					 ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND r.HouseNbr = d.[SitusStdHouseNbr]
							AND LEFT(r.Street,5)= LEFT(d.[SitusStdStreet],5)
								AND d.[SitusStdZip5] = LEFT([Zip],5)
				WHERE r.PropertyID is NULL  
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL([SitusStdUnitNbr],'''') not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 44 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL


			-- Match 45 FIPS, Street Number Suffix, Street Name (Change COUNTY HWY to COUNTY HIGHWAY), ZIP5 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
						AND r.Street=  CASE WHEN d.[SitusStdStreet] LIKE ''COUNTY HWY%'' THEN REPLACE(d.[SitusStdStreet],''COUNTY HWY'',''COUNTY HIGHWAY'') ELSE d.[SitusStdStreet] END
							AND LEFT(r.Zip,5) = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL  and r.STreet like ''%COUNTY HIGHWAY%''
					AND d.[SitusStdHouseNbr] is NULL 
							AND isNULL(r.Street ,'''') not like '''' 
								AND r.Zip not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 45 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 46 FIPS, Street Number Suffix, Street Name (change COUNTY HWY to COUNTY ROAD), ZIP5 
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.Street = CASE WHEN d.[SitusStdStreet] LIKE ''COUNTY HWY%'' THEN REPLACE(d.[SitusStdStreet],''COUNTY HWY'',''COUNTY ROAD'') ELSE d.[SitusStdStreet] END
							AND LEFT(r.Zip,5) = d.[SitusStdZip5]
			WHERE r.PropertyID is NULL
			    and r.STreet like ''%COUNTY ROAD%''
						AND isNULL(r.Street ,'''') not like '''' 
							AND r.Zip not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 46 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 47 FIPS, Street Number, Wild Carded Street Name , ZIP9
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.FullStreetAddress Like d.[SitusStdHouseNbr] + '' %'' + d.[SitusStdStreet] + ''%''
							AND r.Zip9 = d.[SitusStdZip5] + isNULL(d.[SitusStdZip4],'''')
				WHERE r.PropertyID is NULL
					AND LEN(d.[SitusStdStreet])>1  
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL(d.[SitusStdHouseNbr],'''') Not like ''''
								AND r.Zip9 not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 46 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

			-- Match 48 FIPS, Street Number, Wild Carded Street Name , ZIP5, UNIT
				INSERT INTO ' + @SrcDB + '.dbo.[a_PropMatches_FLANK]([AssrID]
					  ,[FIPS]
					  ,[REF_ID]
					  ,[UNFORMATTED_APN]
					  ,[APN_SEQUENCE_NBR]
					  ,[FORMATTED_APN]
					  ,[ORIGINAL_APN]
					  ,[PREVIOUS_PARCEL_NBR]
					  ,[P_ID_IRIS_FRMTD]
					  ,[ALTERNATE_APN]
					  ,[ACCOUNT_NBR]
					  ,[SITUS_HOUSE_NBR]
					  ,[SITUS_HOUSE_NBR_#2]
					  ,[SITUS_HOUSE_NBR_SUFFIX]
					  ,[SITUS_DIRECTION]
					  ,[SITUS_STREET_NAME]
					  ,[SITUS_MODE]
					  ,[SITUS_QUADRANT]
					  ,[SITUS_UNIT_NBR]
					  ,[SITUS_CITY]
					  ,[SITUS_STATE]
					  ,[SITUS_ZIP_CODE]
					  ,[PropHseNbr]
					  ,[PropStName]
					  ,[PropUnit]
					  ,[MatchFlg]
					  ,[OWN1_LAST_NAME]
					  ,[RAW_ID])
				SELECT d.[PropertyID]
					  ,d.[FIPS]
					  ,d.[PropertyID]
					  ,d.[FORMATTEDAPN]
					  ,NULL
					  ,NULL
					  ,d.[OldAPN]
					  ,NULL
					  ,NULL
					  ,NULL
					  ,d.[TaxAccountNumber]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdHouseNbr2]
					  ,d.[SitusStdHouseNbrSuffix]
					  ,d.[SitusStdDirectionLeft]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdMode]
					  ,d.[SitusStdDirectionRight]
					  ,d.[SitusStdUnitNbr]
					  ,d.[SitusStdCity]
					  ,d.[SitusStdState]
					  ,d.[SitusStdZIP5]
					  ,d.[SitusStdHouseNbr]
					  ,d.[SitusStdStreet]
					  ,d.[SitusStdUnitNbr]
					  ,NULL
					  ,d.[OwnerStd1LastName]
					  ,r.[RAW_ID]	
				FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] r JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
				ON convert(int,r.FIPS) = convert(int,d.FIPS)
					AND r.HouseNbr = d.[SitusStdHouseNbr]
						AND r.FullStreetAddress Like d.[SitusStdHouseNbr] + '' %'' + d.[SitusStdStreet] + ''%''
							AND LEFT(r.Zip9,5) = d.[SitusStdZip5]
								and UnitNumber = d.[SitusStdUnitNbr]
				WHERE r.PropertyID is NULL  
					AND LEN(d.[SitusStdStreet])>1  
						AND isNULL(r.Street ,'''') not like '''' 
							AND isNULL( d.[SitusStdHouseNbr],'''') Not like ''''
								AND r.Zip9 not like ''''
									AND isNULL([SitusStdUnitNbr],'''') not like ''''
				 
			UPDATE a 
			SET a.[PropertyID] = b.[REF_ID]
			,a.MatchQuery =  CASE WHEN MatchQuery is null then 48 ELSE MatchQuery END
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
			ON a.RAW_ID = b.RAW_ID
			WHERE a.PropertyID is NULL

		END
	')

	COMMIT TRANSACTION MandA

	BEGIN TRANSACTION PostMatchWork

	---- FIX WRONG FIPS

		EXEC('UPDATE a 
		SET a.FIPS = b.FIPS
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		on a.PropertyID = b.REF_ID
		WHERE a.FIPS <> b.FIPS
		')

	---- FILL LANDUSE

		EXEC('UPDATE a
		SET a.Land_Use = d.StdLandUseCode
		FROM ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] a JOIN [zCust_ADS__00_SharedProcs].dbo.Property d with(NOLOCK)
		on a.REF_ID = d.PropertyID
		')

	----  GET Multiple Property Matches

		EXEC('UPDATE ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK]
		SET REF_ID = NULL,PropertyID = NULL, MultiMatch = ''M''
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN (
			Select RAW_ID FROM ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] 
			group by RAW_ID 
			having Count(*) >1) b
		ON a.RAW_ID = b.RAW_ID
		')

		EXEC('UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,MultiMatch = NULL
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] b
		ON a.RAW_ID = b.RAW_ID 
			AND [BorrowerLastName] Like ''%'' + OWN1_LAST_NAME + ''%''
		WHERE MultiMatch = ''M'' AND OWN1_LAST_NAME not like ''''
		')

			EXEC('UPDATE a
			SET REF_ID = NULL,PropertyID = NULL, MultiMatch = ''M''
			FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN (
				Select a.RAW_ID,OWN1_LAST_NAME FROM ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] b 
				on a.Raw_id = b.Raw_id and a.OWN1_LAST_NAME = b.BorrowerLastName
				Where OWN1_LAST_NAME is NOT NULL
				group by a.RAW_ID,OWN1_LAST_NAME 
				having Count(*) >1) b 
			ON a.RAW_ID = b.RAW_ID
			WHERE MultiMatch is NULL
			')


		EXEC('UPDATE a 
		SET a.[PropertyID] = b.[REF_ID]
		,MultiMatch = ''LU''
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN (Select p.* from ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] p JOIN (
			Select Raw_ID,Land_USE
			from ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] 
			Where Land_Use in(''1999'',''1000'',''1001'')
			group by RAW_ID,Land_USE 
			Having COUNT(*) = 1) d on p.RAW_ID = d.RAW_ID and p.Land_Use = d.Land_Use) b
		ON a.RAW_ID = b.RAW_ID 
		WHERE MultiMatch = ''M'' and b.Land_Use in(''1999'',''1000'',''1001'')
		')

		EXEC('UPDATE F
		SET F.PropertyID = D.REF_ID
		,F.MultiMatch = NULL
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] F JOIN (
			Select RAW_ID,REF_ID from (
				Select b.FullStreetAddress,a.* from ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatch_Work_Flank] b
				on a.[Raw_ID] = b.[Raw_ID]
				where a.[RAW_ID] IN(Select [RAW_ID] from ' + @SrcDB + '.dbo.[a_PropMatches_Flank]
				group by [RAW_ID]
				having COUNT(*) = 2)
				and (isNULL(a.[SITUS_DIRECTION],'''') not like '''' or isNULL(a.[SITUS_QUADRANT],'''') Not like '''')
				and [FullStreetAddress] like [PropHseNbr] + ''%'' + [SITUS_DIRECTION] + ''%'' + [PropStName] + ''%'' + [SITUS_QUADRANT] + ''%'' 
				and (APN_SEQUENCE_NBR is NULL or APN_SEQUENCE_NBR = ''01'')
				) DIRECTION_WORK
				WHERE RAW_ID in(
					Select RAW_ID FROM (
					Select b.FullStreetAddress,a.* from ' + @SrcDB + '.dbo.[a_PropMatches_FLANK] a JOIN ' + @SrcDB + '.dbo.[a_PropMatch_Work_Flank] b
					on a.[Raw_ID] = b.[Raw_ID]
					where a.[RAW_ID] IN(Select [RAW_ID] from ' + @SrcDB + '.dbo.[a_PropMatches_Flank]
					group by [RAW_ID]
					having COUNT(*) = 2)
					and (isNULL(a.[SITUS_DIRECTION],'''') not like '''' or isNULL(a.[SITUS_QUADRANT],'''') Not like '''')
					and [FullStreetAddress] like [PropHseNbr] + ''%'' + [SITUS_DIRECTION] + ''%'' + [PropStName] + ''%'' + [SITUS_QUADRANT] + ''%'' 
					and (APN_SEQUENCE_NBR is NULL or APN_SEQUENCE_NBR = ''01'')
					) DIRECTION_WORK
					GROUP BY RAW_ID
					HAVING COUNT(*) = 1
					)
			)  D
		ON F.RAW_ID = D.RAW_ID
		')

		EXEC('UPDATE a
		SET a.REF_ID = b.DTDB_Ref_ID
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN zCust_ADS__00_SharedProcs.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID
		')

		EXEC('UPDATE a
		SET a.REF_ID = b.Ref_ID
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN zCust_ADS__00_SharedProcs.dbo.Assr b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.Lic_PropertyId
		WHERE a.REF_ID is NULL
		')

		EXEC('UPDATE a
		SET a.INPUTAPN = b.FORMATTEDAPN
		FROM ' + @SrcDB + '.dbo.[a_PropMatch_Work_FLANK] a JOIN zCust_ADS__00_SharedProcs.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID
		where A.PropertyID is not null
		')


	COMMIT TRANSACTION PostMatchWork


END








