/* Source: AZUVNSQLDTDB003.datatree.local | assr | pet_dbo.usp_Determine_Missing_ref_id_Pet_Assr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE  PROCEDURE [Assr].[pet_dbo].[usp_Determine_Missing_ref_id_Pet_Assr] @ERROR VARCHAR(500) OUTPUT
AS
-- declare @ERROR VARCHAR(500) 

--
--
--
TRUNCATE TABLE [Assr].[pet_tmp].[Missing_pet_ref_id]

TRUNCATE TABLE [Assr].[pet_tmp].[Missing_assr_ref_id]

--/****** Object:  Table [pet_tmp].[Missing_assr_ref_id]    Script Date: 8/18/2025 11:35:04 AM ******/
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pet_tmp].[Missing_assr_ref_id]') AND type in (N'U'))
--DROP TABLE [pet_tmp].[Missing_assr_ref_id]


--create TABLE [pet_tmp].[Missing_assr_ref_id](
--	[fips] [int] NOT NULL,
--	[ref_id] [numeric](12, 0) NOT NULL
--) ON [PRIMARY]




--/****** Object:  Index [idx_fips_ref_id]    Script Date: 8/18/2025 11:35:21 AM ******/
--CREATE CLUSTERED INDEX [idx_fips_ref_id] ON [pet_tmp].[Missing_assr_ref_id]
--(
--	[fips] ASC,
--	[ref_id] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


--/****** Object:  Table [pet_tmp].[Missing_pet_ref_id]    Script Date: 8/18/2025 11:35:49 AM ******/
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pet_tmp].[Missing_pet_ref_id]') AND type in (N'U'))
--DROP TABLE [pet_tmp].[Missing_pet_ref_id]


--/****** Object:  Table [pet_tmp].[Missing_pet_ref_id]    Script Date: 8/18/2025 11:35:49 AM ******/

--CREATE TABLE [pet_tmp].[Missing_pet_ref_id](
--	[fips] [int] NOT NULL,
--	[ref_id] [numeric](12, 0) NOT NULL
--) ON [PRIMARY]




--/****** Object:  Index [idx_fips_ref_id]    Script Date: 8/18/2025 11:36:11 AM ******/
--CREATE CLUSTERED INDEX [idx_fips_ref_id] ON [pet_tmp].[Missing_pet_ref_id]
--(
--	[fips] ASC,
--	[ref_id] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


DECLARE @SQL VARCHAR(MAX)
		,@LinkSvr VARCHAR(100) = ''

	SET @LinkSvr = CASE 
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB007' -- DWS-ETL01.DATATREE.LOCAL,1433
				THEN '[DWS-ETL02].'
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB029' --AZUVPSQLDTDB029.datatree.local
				THEN ''
			ELSE ''  -- AZUVNSQLDTDB003
			END


--
--get count differences between assr and pet  ref_ids
--


	SET @SQL = N'
DROP TABLE

IF EXISTS Assr.pet_tmp.Assr_pet_differences
	SELECT a.Fips
		,a.Assr_fips
		,a.Process_Date
		,ar.*
		,p.*
		,d.*
	INTO Assr.pet_tmp.Assr_pet_differences
	FROM ' + @LinkSvr + 'pet.dbo.pet_counties a
	OUTER APPLY (
		SELECT count(1) AS assr_cnt
		FROM assr.dbo.assr
		WHERE fips = a.assr_fips
		) ar
	OUTER APPLY (
		SELECT count(1) AS pet_cnt
		FROM ' + @LinkSvr + 'pet.dbo.pet 
		WHERE fips = a.fips
		) p
	OUTER APPLY (
		SELECT ar.assr_cnt - p.pet_cnt AS diff
		) d
	--WHERE a.fips NOT IN (6904)

	'
	--Print @SQL
	EXEC (@SQL)

--
--determine which counties run annual for 
--
DROP TABLE

IF EXISTS #incremental
	SELECT *
	INTO #incremental

	FROM [Assr].[pet_tmp].[Assr_pet_differences]
where diff <> 0


-- DROP TABLE Assr.dbo.Missing_ref_id_tracker
/*
--SELECT Fips
--	,DateStarted
--	,DateEnded
-- --	begin transaction update a set a.DateStarted = null
--FROM Assr.dbo.Missing_ref_id_tracker a
--where DateEnded is null
--and DateStarted is not null
-- commit
--ORDER BY fips
*/
DROP TABLE

IF EXISTS [Assr].[dbo].[Missing_ref_id_tracker]
	CREATE TABLE [Assr].[dbo].[Missing_ref_id_tracker] (
		Fips INT NOT NULL
		,Assr_Fips INT NOT NULL
		,DateStarted DATETIME NULL
		,DateEnded DATETIME NULL
		)

INSERT INTO [Assr].[dbo].[Missing_ref_id_tracker] (
	Fips
	,Assr_Fips
	,DateStarted
	,DateEnded
	)
SELECT n.fips
	,n.Assr_Fips
	,NULL AS DateStarted
	,NULL AS DateEnded
FROM #incremental n

 
select * from [Assr].[dbo].[Missing_ref_id_tracker]

DECLARE @fips INT = NULL
	,@fips_a CHAR(5) = NULL

DECLARE @Assr_fips INT = NULL
	,@Assr_fips_a CHAR(5) = NULL



--select the starting fips
--
SELECT @fips = min(fips)
	,@Assr_fips = min(assr_fips)
 FROM [Assr].[dbo].[Missing_ref_id_tracker]
WHERE DateStarted IS NULL

SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
SET @Assr_fips_a = right('00' + cast(@Assr_fips AS VARCHAR(5)), 5)

select @fips_a, @Assr_fips_a

--
--begin the loop for the Fips
DECLARE @return_value INT = 0
DECLARE @rowcount INT = 0

--
WHILE @fips IS NOT NULL
	AND @fips > 0
BEGIN
	--
	--Udpate the control trable to say you are workig on the fips
	--
	
	--SELECT @LinkSvr
	--SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)

	BEGIN
		UPDATE [Assr].[dbo].[Missing_ref_id_tracker]
		SET DateStarted = getdate()
		WHERE fips = @fips
	END

	RAISERROR (
			'%s Busy with Fips %s'
			,0
			,1
			,@fips_a
			,@fips_a
			)
	WITH NOWAIT

	--
	-- here the logic start that you  wnat to run by fips
	--
	SET @SQL = N'
	INSERT INTO Assr.pet_tmp.Missing_pet_ref_id (
		ref_id
		)
	SELECT a.*
	FROM (
		SELECT ref_id
		FROM assr.dbo.assr a
		WHERE fips = ' + @Assr_Fips_a + '
		
		EXCEPT
		
		SELECT ref_id
		FROM  ' + @LinkSvr + 'pet.dbo.pet
		WHERE fips = ' + @Fips_a + '
		) a

Update a
		set a.fips = ' + @Fips_a + '
			,a.Assr_fips = ' + @Assr_Fips_a + '
		from Assr.pet_tmp.Missing_Pet_ref_id a
		Where fips is null


	INSERT INTO Assr.pet_tmp.Missing_assr_ref_id (
		ref_id
		)
	SELECT a.*
	FROM (
		SELECT 	ref_id
		FROM  ' + @LinkSvr + 'pet.dbo.pet
		WHERE fips = ' + @Fips_a + '
		
		EXCEPT
		
		SELECT ref_id
		FROM assr.dbo.assr
		WHERE fips = ' + @Assr_Fips_a + '
		) a


		Update a
		set a.fips = ' + @Fips_a + '
			,a.Assr_fips = ' + @Assr_Fips_a + '
		from Assr.pet_tmp.Missing_assr_ref_id a
		Where fips is null
	'

	--Print @SQL
	EXEC (@SQL)

	SET @rowcount = @@rowcount

	RAISERROR (
			'%s updated  %d'
			,0
			,1
			,@fips_a
			,@rowcount
			)

	--
	--Update the control table to indicate you are done
	--
	BEGIN
		UPDATE [Assr].[dbo].[Missing_ref_id_tracker]
		SET DateEnded = getdate()
		WHERE fips = @fips
	END

	--
	--Select the new fips to process - if non found then @fips would be null
	--
	SELECT @fips = min(fips)
		,@Assr_fips = min(Assr_fips)
	FROM [Assr].[dbo].[Missing_ref_id_tracker]
	WHERE DateStarted IS NULL

	SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
	SET @Assr_fips_a = right('00' + cast(@Assr_fips AS VARCHAR(5)), 5)
END




