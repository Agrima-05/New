/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Create_INFC_DocIdExtract | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_Create_INFC_DocIdExtract] (
	@date_to DATETIME2 = NULL
	,@date_from DATETIME2 = NULL
	,@ERROR VARCHAR(500) OUTPUT
	)
AS
BEGIN TRY
EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_Create_INFC_DocIdExtract'
	,N'Started'

/*
This SP is called by the application that extract the doc_id's - UR to INFC process.
The table lien.dbo.INFC_DocIdExtract is created every time this routine is called.
The purpose of this routine is to identify all the docid's that were changed within a time period
This SP is called with a date from and to to - this will allow to get doc_ids that were missed before. On a regular day it wil call it from the the last timestamp it extratced
The caller of this module needs to keep track of the last time that it requested doc_ids so that it can ask for additional ids next time
from the place left of before


USE [Lien]
GO

DECLARE	@return_value int

EXEC	@return_value = [UR].[usp_Create_INFC_DocIdExtract]

SELECT	'Return Value' = @return_value

GO


*/
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	2022/06.08	create inital program
paul	20230203	Remove the null check in the date to calculation
******************************************************************************************************************/
-- DECLARE 	@date_to DATETIME = NULL 	,@date_from DATETIME = null --'20221217 04:57:44.663'
--SELECT @date_from AS N'@date_from'
--	,@date_to AS N'@date_to'
--
-- if date from and to is not provided then we retrieve the data between the last 2 extracts
--
IF @date_from IS NULL
BEGIN
	SELECT @date_from = (
			SELECT a.m_update_date
			FROM (
				SELECT TOP 1 m_update_date
				--,ROW_NUMBER() OVER (
				--	PARTITION BY 0 ORDER BY m_update_date DESC
				--	) AS ROW4
				FROM [lien].[UR].[document_transaction_log_tracker](NOLOCK)
				WHERE INFC_Extract_date IS NOT NULL
				ORDER BY m_update_date DESC
				) a
				--WHERE row4 = 2
			)
END

IF @date_to IS NULL
BEGIN
	SELECT @date_to = (
			SELECT TOP 1 m_update_date
			FROM [lien].[UR].[document_transaction_log_tracker](NOLOCK)
			--WHERE INFC_Extract_date IS not NULL
			ORDER BY m_update_date DESC
			)
END

SELECT @date_from AS N'@date_from'
	,@date_to AS N'@date_to'

TRUNCATE TABLE [lien].[dbo].[INFC_DocIdExtract]

INSERT INTO [lien].[dbo].[INFC_DocIdExtract] (doc_id)
SELECT a.doc_id
--into #temp
FROM [lien].[UR].[Lien_Extract_doc_id] a
INNER JOIN [lien].[ur].[document] d ON d.doc_id = a.doc_id
WHERE a.m_update_date > @date_from
	AND a.m_update_date <= @date_to
	AND d.m_status_id < 3
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
	,N'usp_Create_INFC_DocIdExtract'
	,N'Ended'


/****** Object:  StoredProcedure [UR].[usp_INFC_INFCL_BEGIN]    Script Date: 7/6/2023 2:36:01 PM ******/
SET ANSI_NULLS ON


END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	ROLLBACK
END CATCH

