SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [Src_PropMix].[dbo].[usp_100_Get_ListingVerify]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	TRUNCATE TABLE dbo.zListingVerify

	INSERT INTO [Src_PropMix].[dbo].[zListingVerify]([PropertyID]
			  ,[FAPropertyRefId]
			  ,[APN]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[OffMarketTimestamp]
			  ,[SoldDate]
			  ,[OffMarketValue]
			  ,[SoldValue]
			  ,[PVD]
			  ,[FACalc1]
			  ,[FACalc2]
			  ,[CurrSalesPrice]
			  ,[ConCurrMtg1LoanAmt]
			  ,[CurrSaleRecordingDate]
			  ,[CurrSaleContractDate]
			  ,[Status]
			  ,[PMXDOM]
			  ,[FIPS]
			  ,[DateInserted])
		SELECT m.[PropertyID]
			  ,[FAPropertyRefId]
			  ,[APN]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[OffMarketTimestamp]
			  ,[SoldDate]
			  ,[OffMarketValue]
			  ,[SoldValue]
			  ,[PVD]
			  ,round(convert(money,coalesce([SoldValue],[OffMarketValue])) * (1 - convert(float,[PVD])/100),-2) as FACalc1
			  ,round(convert(money,[SoldValue]) * (1 - convert(float,[PVD])/100),-3) as FACalc2
			  ,p.CurrSalesPrice
			  ,p.ConCurrMtg1LoanAmt
			  ,p.CurrSaleRecordingDate
			  ,p.CurrSaleContractDate
			  ,[Status]
			  ,[PMXDOM]
			  ,p.[FIPS]
			  ,[DateInserted]
		  FROM [Src_PropMix].[dbo].[MLSLite_data] m
		  join [adsf1.datatree.local].data.dbo.property p with(nolock)
		  on convert(int,p.fips) = m.fips
		  and p.propertyid = m.[FAPropertyRefId]
		  and status = 'sold'
		  order by [OffMarketTimestamp] desc


		 INSERT INTO [Src_PropMix].[dbo].[zListingVerify_ALL]([PropertyID]
			  ,[FAPropertyRefId]
			  ,[APN]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[OffMarketTimestamp]
			  ,[SoldDate]
			  ,[OffMarketValue]
			  ,[SoldValue]
			  ,[PVD]
			  ,[FACalc1]
			  ,[FACalc2]
			  ,[CurrSalesPrice]
			  ,[ConCurrMtg1LoanAmt]
			  ,[CurrSaleRecordingDate]
			  ,[CurrSaleContractDate]
			  ,[Status]
			  ,[PMXDOM]
			  ,[FIPS]
			  ,[DateInserted])
		SELECT m.[PropertyID]
			  ,[FAPropertyRefId]
			  ,[APN]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[OffMarketTimestamp]
			  ,[SoldDate]
			  ,[OffMarketValue]
			  ,[SoldValue]
			  ,[PVD]
			  ,round(convert(money,coalesce([SoldValue],[OffMarketValue])) * (1 - convert(float,[PVD])/100),-2) as FACalc1
			  ,round(convert(money,[SoldValue]) * (1 - convert(float,[PVD])/100),-3) as FACalc2
			  ,p.CurrSalesPrice
			  ,p.ConCurrMtg1LoanAmt
			  ,p.CurrSaleRecordingDate
			  ,p.CurrSaleContractDate
			  ,[Status]
			  ,[PMXDOM]
			  ,p.[FIPS]
			  ,[DateInserted]
		  FROM [Src_PropMix].[dbo].[MLSLite_data] m
		  join [adsf1.datatree.local].data.dbo.property p with(nolock)
		  on convert(int,p.fips) = m.fips
		  and p.propertyid = m.[FAPropertyRefId]
		  and status = 'sold'
		  ----Added 20200212 to prevent invalid values per MS - KL--
		  AND round(convert(money,[SoldValue]) * (1 - convert(float,[PVD])/100),-3) < 50000000
		  order by [OffMarketTimestamp] desc

		INSERT INTO [Src_PropMix].[dbo].[MLSLite_historydata]
		Select *,CONVERT(VARCHAR(4),GETDATE(),112),NULL From [Src_PropMix].[dbo].[MLSLite_data]


		UPDATE [Src_PropMix].[dbo].[a]
			  SET a.[FAPropertyRefId] = b.PropertyID
			  --,a.[FAUserID] = 'Apply PropertyID ' + Convert(varchar(8),GETDATE(),112)
			  FROM [Src_PropMix].[dbo].[zListingVerify_ALL] a with(NOLOCK) JOIN [adsf1.datatree.local].[DATA].dbo.Property b with(NOLOCK)
			  on convert(int,b.fips) = convert(int,a.fips)
			  and a.APN = b.FormattedAPN
			  where FAPropertyRefId like ''

		TRUNCATE TABLE [dbo].[MLSLite_data]

		INSERT INTO [Src_PropMix].[dbo].[zListingVerify_ALL_BADSold]
		Select * 
		FROM [Src_PropMix].[dbo].[zListingVerify_ALL]
		WHERE (convert(money,SoldValue) > convert(money,OffMarketValue)*5 
			and convert(money,SoldValue) > convert(money,CurrSalesPrice)*2)

		DELETE 
		--SELECT COUNT(*) 
		FROM [Src_PropMix].[dbo].[zListingVerify_ALL]
		WHERE (convert(money,SoldValue) > convert(money,OffMarketValue)*5 
			and convert(money,SoldValue) > convert(money,CurrSalesPrice)*2)


		--  INSERT INTO dbo.zListingVerify_ALL([PropertyID]
		--	  ,[FAPropertyRefId]
		--	  ,[APN]
		--	  ,[UnparsedAddress]
		--	  ,[City]
		--	  ,[StateOrProvince]
		--	  ,[PostalCode]
		--	  ,[OffMarketTimestamp]
		--	  ,[SoldDate]
		--	  ,[OffMarketValue]
		--	  ,[SoldValue]
		--	  ,[PVD]
		--	  ,[FACalc1]
		--	  ,[FACalc2]
		--	  ,[CurrSalesPrice]
		--	  ,[ConCurrMtg1LoanAmt]
		--	  ,[CurrSaleRecordingDate]
		--	  ,[CurrSaleContractDate]
		--	  ,[Status]
		--	  ,[PMXDOM]
		--	  ,[FIPS]
		--	  ,[DateInserted])
		--SELECT m.[PropertyID]
		--	  ,[FAPropertyRefId]
		--	  ,[APN]
		--	  ,[UnparsedAddress]
		--	  ,[City]
		--	  ,[StateOrProvince]
		--	  ,[PostalCode]
		--	  ,[OffMarketTimestamp]
		--	  ,[SoldDate]
		--	  ,[OffMarketValue]
		--	  ,[SoldValue]
		--	  ,[PVD]
		--	  ,round(convert(money,coalesce([SoldValue],[OffMarketValue])) * (1 - convert(float,[PVD])/100),-2) as FACalc1
		--	  ,round(convert(money,[SoldValue]) * (1 - convert(float,[PVD])/100),-3) as FACalc2
		--	  ,p.CurrSalesPrice
		--	  ,p.ConCurrMtg1LoanAmt
		--	  ,p.CurrSaleRecordingDate
		--	  ,p.CurrSaleContractDate
		--	  ,[Status]
		--	  ,[PMXDOM]
		--	  ,p.[FIPS]
		--	  ,'2019-09-05'
		--  FROM [Src_PropMix].[dbo].[MLSLite_historydata_2018] m
		--  join data.dbo.property p with(nolock)
		--  on p.fips = m.fips
		--  and p.propertyid = m.[FAPropertyRefId]
		--  and status = 'sold'
		--  order by [OffMarketTimestamp] desc
END

