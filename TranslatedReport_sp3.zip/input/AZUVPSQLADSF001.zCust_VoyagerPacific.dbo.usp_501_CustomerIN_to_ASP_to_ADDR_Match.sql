SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF




CREATE PROCEDURE [zCust_VoyagerPacific].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
		
	
AS
BEGIN

	SET NOCOUNT ON;


		
		

		------------------------------------------
		SET CONCAT_NULL_YIELDS_NULL off

		--Truncate table [INPUT_RAW_CUST]

		--Insert into [INPUT_RAW_CUST]([UniqueID]
  --    ,[Reference ID]
  --    ,[Address]
  --    ,[City]
  --    ,[State]
  --    ,[Zip]
  --    ,[APN])
		--Select 
		--[id]
		--,[id]
  --    ,[address]
  --    ,[city]
  --    ,[state]
  --    ,[zip]
  --    ,convert(varchar(250),[apn])
		--FROM [zCust_VoyagerPacific].[dbo].[INPUT_RAW_20210514]


		
		--Select [Reference ID],APN, cast(APN as float) From [INPUT_RAW_CUST]
		--where APN like '%e+%'

--Update [INPUT_RAW_CUST]	Set APN = '6180000000000000'	where [Reference ID] = '224'
--Update [INPUT_RAW_CUST]	Set APN = '6180000000000000'	where [Reference ID] = '226'
--Update [INPUT_RAW_CUST]	Set APN = '5170000000000000'	where [Reference ID] = '228'
--Update [INPUT_RAW_CUST]	Set APN = '2160000000000000'	where [Reference ID] = '229'
--Update [INPUT_RAW_CUST]	Set APN = '2160000000000000'	where [Reference ID] = '230'
--Update [INPUT_RAW_CUST]	Set APN = '6170000000000000'	where [Reference ID] = '231'
--Update [INPUT_RAW_CUST]	Set APN = '4180000000000000'	where [Reference ID] = '53'
--Update [INPUT_RAW_CUST]	Set APN = '22800000000000'	where [Reference ID] = '190'
--Update [INPUT_RAW_CUST]	Set APN = '362000000000000'	where [Reference ID] = '136'
--Update [INPUT_RAW_CUST]	Set APN = '351000000000000'	where [Reference ID] = '295'
--Update [INPUT_RAW_CUST]	Set APN = '481000000000'	where [Reference ID] = '764'
--Update [INPUT_RAW_CUST]	Set APN = '242000000000'	where [Reference ID] = '1456'


	



		Truncate table INPUT_IN

		INSERT INTO [zCust_VoyagerPacific].[dbo].[INPUT_IN](INPUTKEY,INPUTAddress,INPUTCity,INPUTState,INPUTZip--,INPUTAPN
		)
		Select  
		LTRIM(RTRIM([UniqueID]))
       ,REPLACE([Address],'  ',' ')
      ,REPLACE([City],'  ',' ')
      ,[State]
      ,[Zip]
      --,REPLACE([APN],',','')
	 	From [zCust_VoyagerPacific].[dbo].[INPUT_RAW_CUST]

		Select INPUTKEY,INPUTAPN, cast(INPUTAPN as float) From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where INPUTAPN like '%e+%'


		----Check for Dups--
		--Select A.*, B.*  From INPUT_RAW_CUST as A 
		--join INPUT_MONITOR as B on A.UniqueID = B.UniqueID


		--Select * From [INPUT_RAW_CUST]
		--Truncate table [INPUT_RAW_CUST]

		--INSERT INTO [INPUT_RAW_CUST]([UniqueID],[Reference ID],[Address],[City],[State],[Zip],[APN])
		--Select  
		--LTRIM(RTRIM([UniqueID]))
		--,LTRIM(RTRIM([Reference ID]))
  --     ,REPLACE([Address],'  ',' ')
  --    ,REPLACE([City],'  ',' ')
  --    ,[State]
  --    ,[Zip]
  --    ,REPLACE([APN],',','')
	 --	FROM Amrock_TaxSource_20210407
		



		--Select * from [zCust_VoyagerPacific].[dbo].[INPUT_RAW_20210305]


		Select top 100 * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]

		Select count(*) From [zCust_VoyagerPacific].[dbo].[INPUT_IN]

		Select INPUTKEY,count(*) From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		Group by INPUTKEY
		Having count(*) >1

		Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where INPUTKEY like '%e%'

		Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where len(INPUTZip) > 10

		Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where len(INPUTState) > 2

		Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where InputAddress like '%  %'

		Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
		where INPUTCity like '%  %'


		UPDATE [zCust_VoyagerPacific].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_VoyagerPacific].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_VoyagerPacific].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_VoyagerPacific].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_VoyagerPacific].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2

	
	
	---- INSERT DATA INTO ASP IN TABLE AND SET TRIGGER FOR PROCESS

	  EXEC [zCust_VoyagerPacific].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]


	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

			IF (SELECT COUNT(*) FROM [zCust_VoyagerPacific].[dbo].[VoyagerPacific]) = 0
				BEGIN
					RETURN;
				END
			ELSE
				BEGIN
					---- 2 min wait periods until ASP is complete
					DECLARE @CheckASP as int
				
						SET @CheckASP = 0

					WHILE @CheckASP = 0
						BEGIN
							WAITFOR DELAY '00:01'
							
						---- Checks for completion ** If not wait again
						SET @CheckASP = (Select COUNT(*) from [zCust_VoyagerPacific].[dbo].[VoyagerPacific_STD])
						END
				END

			

	---- APPENDS ASP DATA BACK TO DATABASE 

	
		EXEC [zCust_VoyagerPacific].[dbo].[usp_100c_sp_ASP_Cust_STD]

	
		-----------------------------------------------------

		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_VoyagerPacific'
		--EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_VoyagerPacific'

			
		
		
			Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
			 from [zCust_VoyagerPacific].[dbo].[a_PropMatch_WORK]
			group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END

			--Select A.*, B.REF_ID From INPUT_IN as A join a_PropMatch_Work as B on A.INPUTKey = B.RAW_ID
			--where B.REF_ID in (
			--Select REF_ID from (
			--Select REF_ID, count(*) as TOTAL From a_PropMatch_WORK as A 
			--join INPUT_IN
			-- as B on A.RAW_ID = B.INPUTKey

			--Group by REF_ID
			--having count(*) > 1)A)
			--and B.REF_ID is not null
			--Order by REF_ID

			--Select CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
			-- from dbo.a_PropMatch_WORK_FLANK
			--group by CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END



			------------------Tax Source-----------
			DECLARE @CUSTOMER varchar(100)
			Set @CUSTOMER = 'VoyagerPacific'
			DECLARE @DATE varchar(30)
			--Set @DATE = (Select format(getdate(),'yyyyMMddHHmm'))
			Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			DECLARE @BATCH varchar(50)
			--SET @BATCH = (Select max(convert(int,ID)) + 1 from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK))
			--Set @DATE = '202104071524'
			
			Print @DATE

			
			INsert into [TaxSourceAPI].[dbo].[Batch]([Name])
			Select @CUSTOMER + '_' + @DATE

			SET @BATCH = (Select ID from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			)

			Print @BATCH

			Update [TaxSourceAPI].[dbo].[Batch]
			Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Voyager_Pac_Cap_Mgmnt\Taxsource\IMAGES\'+@DATE+'_'+@BATCH+'\Images'
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			and ID = @BATCH

			

			Select * From [TaxSourceAPI].[dbo].[Batch]
			Order by ID Desc

	

			Insert into  [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]( [UniqueID]      ,[Reference ID]      ,[Address]      ,[City]      ,[State]
			,[Zip]      ,[APN]      ,[DATE_ADDED]      ,[FIPS]      ,[REF_ID]      ,[BATCHID])
			
			Select 	
			RAW_ID, B.[Reference ID]
			,REPLACE(B.ADDRESS,'  ',' ')
			,REPLACE(B.City,'  ',' '), B.State, B.Zip
			,REPLACE(B.APN,',','')
			,@DATE
			,RIGHT(('0' + A.FIPS),5)
			,A.REF_ID
			,(Select MAX([Id]) from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK) where [Name] like 
			@CUSTOMER + '_' + @DATE )
			--Select * 
			From [zCust_VoyagerPacific].[dbo].[a_Propmatch_WORk] as A 
			join [zCust_VoyagerPacific].[dbo].[INPUT_RAW_CUST] as B on A.RAW_ID = B.[UniqueID]
			
			
			Select * From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]

			Select BatchID, count(*) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]
			Group by BatchID
			Order by BatchID

			Select distinct DATE_ADDED  From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]
			where DATE_COMPLETED is null

			
			--Select * From [TaxSourceAPI].sys.tables as A join [TaxSourceAPI].sys.columns as B on A.object_id = B.object_id
			--where A.Name like 'Property'
			--Order by B.Name
			
			Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
			, City, State, Zip, RefId, APN, Fips
			, REFERENCEID)
			Select 
			A.RAW_ID
			,B.[BATCHID]
			,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
			, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
			----Added 20210326 so customer can pass through their secondary reference id
			--,ROW_NUMBER() OVER (order by RAW_ID)
			,B.[Reference ID]
			From [zCust_VoyagerPacific].[dbo].[a_Propmatch_WORk] as A 
			join [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
			where B.BATCHID = 
			(Select MAX(convert(bigint,BATCHID)) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			AND  UniqueID NOT in ('271','366','1884','1631','1359','1017','1750')


			Select count(*) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]

			Select RAW_ID, * From [zCust_VoyagerPacific].[dbo].[a_PRopmatch_WORK] where REF_ID in (
			Select REF_ID from (
			Select REF_ID, count(*) as TOTAL From [zCust_VoyagerPacific].[dbo].[a_PRopmatch_WORK]
			Group by REF_ID
			having count(*) > 1)A)
			Order by REF_ID


			
			Select * From [TaxSourceAPI].[dbo].[Property] as A 
			join [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
			and A.ExternalKey = B.UniqueID

		
			Update [TaxSourceAPI].[dbo].[Property]
			Set ExternalKey = LTRIM(RTRIM(ExternalKey))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ExternalKey like '% %'

			--Select * From [TaxSourceAPI].[dbo].[Property]
			--where (ExternalKey like '% %'
			--OR ReferenceId like '% %')
			--and BatchId = 12


			Update [TaxSourceAPI].[dbo].[Property]
			Set ReferenceId = LTRIM(RTRIM(ReferenceId))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ReferenceId like '% %'


			Select ReferenceId , ExternalKey From [TaxSourceAPI].[dbo].[Property]
			where  BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and (ReferenceId like '% %'
			OR ExternalKey like '% %')


			Select * From [zCust_VoyagerPacific].[dbo].[INPUT_MONITOR]


		
		
END



