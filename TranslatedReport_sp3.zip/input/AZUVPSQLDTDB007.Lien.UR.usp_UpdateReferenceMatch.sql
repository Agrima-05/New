/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_UpdateReferenceMatch | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,> 
-- Description:	<Description,,> 
-- =============================================
CREATE PROCEDURE [Lien].[UR].[usp_UpdateReferenceMatch]
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	1/5/22		Retain the fips from DTDB match when refid is found, regardless if it is diff than document fips_code
******************************************************************************************************************/
--
-- First make sure all reference records have a formatted  number
--
EXEC [Lien].[UR].[usp_UpdateFormattedReference]

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'UpdateReferenceMatch'
	,N'Started'

--declare @annual BIT = 0
DROP TABLE

IF EXISTS [Lien].[tmp].[usp_UpdateReferenceMatch_ref]
	--IF @annual = 0
	--BEGIN
	SELECT r.REFERENCE_id
	INTO [lien].[tmp].[usp_UpdateReferenceMatch_ref]
	FROM [Lien].[UR].[REFERENCE] r WITH (
			NOLOCK
			,INDEX (PK_REFERENCE)
			)
	LEFT JOIN [Lien].[UR].[REFERENCE_Match] rm WITH (
			NOLOCK
			,INDEX (ix_ref)
			) ON rm.REFERENCE_id = r.REFERENCE_id
	WHERE rm.REFERENCE_id IS NULL
	OPTION (
		RECOMPILE
		,MAXDOP 16
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

--END
--ELSE
--BEGIN
--	SELECT r.reference_id
--	INTO lien.tmp.usp_UpdateReferenceMatch_ref
--	FROM lien.ur.reference r
--	WHERE r.doc_id IN (
--			SELECT doc_id
--			FROM lien.tmp.nova_ref_rematch_tbl2
--			)
--END
--	END
CREATE INDEX id_id ON [lien].[tmp].[usp_UpdateReferenceMatch_ref] (REFERENCE_id)

DROP TABLE

IF EXISTS [Lien].[tmp].[usp_UpdateReferenceMatch_Match]
	DROP TABLE

IF EXISTS [Lien].[tmp].[usp_UpdateReferenceMatch_Match]
	SELECT a.REFERENCE_id
		,d.fips_code
		,d.doc_id
		,CASE 
			WHEN pfc.PRE_FORECLOSURE_CODE IS NOT NULL
				THEN 'PFC'
			WHEN ras.DTDB_DETAILED_DOCUMENT_TYPE IS NOT NULL
				THEN 'RAS'
			WHEN deed.DETAILED_DOCUMENT_TYPE IS NOT NULL
				THEN 'DEED'
			ELSE 'NONE'
			END AS UR_Doc_Type
	INTO [Lien].[tmp].[usp_UpdateReferenceMatch_Match]
	FROM [lien].[tmp].[usp_UpdateReferenceMatch_ref] a
	LEFT JOIN [Lien].[UR].[REFERENCE] r WITH (
			NOLOCK
			,INDEX (PK_REFERENCE)
			) ON r.reference_id = a.reference_id
	LEFT JOIN [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (pk_document)
			) ON d.doc_id = r.doc_id
	LEFT JOIN [Lien_DTDB].[dbo].[UR_PFC_Doc_Types] pfc WITH (
			NOLOCK
			,INDEX (idx_doc_type)
			) ON d.doc_type = pfc.doc_type
		AND pfc.delete_date IS NULL
	LEFT JOIN [Lien_DTDB].[dbo].[UR_RAS_Doc_Types] ras WITH (
			NOLOCK
			,INDEX (idx_ur_doc_type)
			) ON d.doc_type = ras.ur_doc_type
		AND ras.delete_date IS NULL
	LEFT JOIN [Lien_DTDB].[dbo].[UR_Document_Types] deed WITH (
			NOLOCK
			,INDEX (idx_doc_type)
			) ON d.doc_type = deed.ur_value
		AND deed.delete_date IS NULL

CREATE INDEX idx_fips ON [Lien].[tmp].[usp_UpdateReferenceMatch_Match] (fips_code)

CREATE INDEX ix_ref_id ON [Lien].[tmp].[usp_UpdateReferenceMatch_Match] (REFERENCE_id)

--declare @fips_a varchar(5) = '06059'
DECLARE @sample INT = 12
	,@datefrom DATE = '2015-01-01'
	,@dateto DATE = '2015-01-31'
	,@fips_from INT = 00000
	,@fips_to INT = 60000
	,@datefrom_a NVARCHAR(24) = NULL
	,@dateto_a NVARCHAR(24) = NULL
--DROP TABLE Lien.[dbo].[UR_REf_MAtch_Tracke r]
-- select * from Lien.[dbo].[UR_REf_MAtch_Tracker] order by Fips
DECLARE @date DATETIME2 = dateadd(day, - 2, getdate())

/*
--SELECT Fips
--	,DateStarted
--	,DateEnded
-- --	begin transaction update a set a.DateStarted = null
--FROM Lien.[dbo].[UR_REf_MAtch_Tracker] a
--where DateEnded is null
--and DateStarted is not null
-- commit
--ORDER BY fips
*/
/*IF object_id('Lien.[dbo].[UR_REf_MAtch_Tracker]') IS NOT NULL
	*/
DROP TABLE IF EXISTS [Lien].[dbo].[UR_REf_MAtch_Tracker];

IF object_id('Lien.[dbo].[UR_REf_MAtch_Tracker]') IS NULL
BEGIN
	CREATE TABLE [Lien].[dbo].[UR_REf_MAtch_Tracker] (
		[Fips] [int] NOT NULL
		,
		--[Rows] [int] NOT NULL,
		--[SPID] [int] NOT NULL,
		[DateStarted] [datetime] NULL
		,[DateEnded] [datetime] NULL
		)

	INSERT INTO [Lien].[dbo].[UR_REf_MAtch_Tracker] (
		[Fips]
		,[DateStarted]
		,[DateEnded]
		)
	SELECT fips
		,NULL AS DateStarted
		,NULL AS DateEnded
	FROM (
		SELECT DISTINCT cast(fips_code AS INT) AS fips
		FROM [Lien].[tmp].[usp_UpdateReferenceMatch_Match]
		) a
END

--Select * from Lien.[dbo].[UR_REf_MAtch_Tracker]
DECLARE @ERROR VARCHAR(500)
DECLARE @fips INT = NULL
	,@fips_a CHAR(5) = NULL

SET @datefrom_a = Replace(cast(@datefrom AS NVARCHAR(24)), '-', '')
SET @dateto_a = Replace(cast(@dateto AS NVARCHAR(24)), '-', '')

--select the starting fips
--
SELECT @fips = min(fips)
FROM [Lien].[dbo].[UR_REf_MAtch_Tracker]
WHERE DateStarted IS NULL

SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)

--
--begin the loop for the Fips
DECLARE @return_value INT = 0
DECLARE @rowcount INT = 0

--
WHILE @fips IS NOT NULL
	AND @fips > 0
BEGIN
	--
	--Udpate the control trable to say you are workig on the fips
	--
	BEGIN
		UPDATE [Lien].[dbo].[UR_REf_MAtch_Tracker]
		SET DateStarted = getdate()
		WHERE fips = @fips
	END

	RAISERROR (
			'%s Busy with Fips %s'
			,0
			,1
			,@fips_a
			,@fips_a
			)
	WITH NOWAIT

	--
	-- procide the doc_ids for the fips in the loop
	--
	TRUNCATE TABLE [lien].[tmp].[usp_UpdateReferenceMatch_fips_rematch_input]

	INSERT INTO [lien].[tmp].[usp_UpdateReferenceMatch_fips_rematch_input] (doc_id)
	SELECT doc_id
	FROM [Lien].[tmp].[usp_UpdateReferenceMatch_Match]
	WHERE fips_code = @fips_a

	EXEC [lien].[UR].[usp_UpdateReferenceMatch_fips] @fips = @fips
		,@annual = 0
		,@ERROR = @ERROR

	IF @ERROR IS NOT NULL
	BEGIN
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END

	SET @rowcount = @@rowcount

	RAISERROR (
			'%s updated  %d'
			,0
			,1
			,@fips_a
			,@rowcount
			)

	--
	--Update the control table to indicate you are done
	--
	BEGIN
		UPDATE [Lien].[dbo].[UR_REf_MAtch_Tracker]
		SET DateEnded = getdate()
		WHERE fips = @fips
	END

	--
	--Select the new fips to process - if non found then @fips would be null
	--
	SELECT @fips = min(fips)
	FROM [Lien].[dbo].[UR_REf_MAtch_Tracker]
	WHERE DateStarted IS NULL

	SET @fips_a = right('00' + cast(@fips AS VARCHAR(5)), 5)
END

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'UpdateReferenceMatch'
	,N'Ended'


