SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE procedure [zCust_TX_TAX].[dbo].[Drop_DTDB_Tables]
as
BEGIN

IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_UniqueRefId]') AND type in (N'U'))
		DROP TABLE [dbo].[w_UniqueRefId]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_RAS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_RAS]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_PropertyReference]') AND type in (N'U'))
		DROP TABLE [dbo].[w_PropertyReference]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_PreForeclosure]') AND type in (N'U'))
		DROP TABLE [dbo].[w_PreForeclosure]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_LastSaleDATA]') AND type in (N'U'))
		DROP TABLE [dbo].[w_LastSaleDATA]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FCT_DOC_NAME]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FCT_DOC_NAME]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DOC_XREF]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DOC_XREF]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DM_Data]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DM_Data]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DIM_NOVA_DOCUMENT]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DIM_NOVA_DOCUMENT]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DIM_CLNAME]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DIM_CLNAME]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DEEDHIST]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DEEDHIST]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_DEED]') AND type in (N'U'))
		DROP TABLE [dbo].[w_DEED]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_AVM_Coverage]') AND type in (N'U'))
		DROP TABLE [dbo].[w_AVM_Coverage]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_AVM]') AND type in (N'U'))
		DROP TABLE [dbo].[w_AVM]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_Assr]') AND type in (N'U'))
		DROP TABLE [dbo].[w_Assr]
IF  EXISTS (SELECT * FROM [zCust_TX_TAX].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_HistDeed]') AND type in (N'U'))
		DROP TABLE [dbo].[w_HistDeed]

		



END

