SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_FULL_TO_REPLACE_SUP]

AS
BEGIN

	SET NOCOUNT ON;

	
	--Select * From dbo.[HOA_LIEN_DATA_REPLACE_SUP]

	
	 DROP TABLE dbo.[HOA_LIEN_DATA_REPLACE_SUP]

	 Select A.*,C.INPUTKEY ,NULL as [SUP]
	 into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP]
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 --on A.NEW_REF_ID = B.REF_ID
	  on A.REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUTKEY
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
	   --------20191113 - Changed to look at new HOA Lien Doc Type Table per MS---
	  --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D on A.DocType = D.[HOA_Doc_Type]
	 join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	  join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as T on A.DocumentID = T.LIEN_DOC_NUMBER
	  and A.REF_ID = T.REF_ID
	 where B.REF_ID is not null
	 AND D.HOA_Data_Type in ( 'Lien','len')
	 ---------Added 20181217 to remove notice of Lis Pendens...--------
	 ------20191113 - REMOVED-----
	 --AND D.HOA_DOC_TYPE not in ( 'HALP','f7')
	 and A.[IsHoaLienActive] = 1
	 AND OWNSequence = 1
	 and T.SUP like 'Y'
	 and T.SUP_FULL_SENT_DATE is null
	



	 -----------------Added 20180713 to REMOVE RELEASED LIENS still marked as ACTIVE in the HOA Lien table----------
	Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select * 
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] as A join 
	(Select REF_ID,DocumentId,OAReference,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] with(NOLOCK))
	----Changed 20191113 to use new doc type table---
	---and DocType like 'halnrl')
	And DocType in (Select DocType from [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] with(NOLOCK)  where  HOA_Data_Type in ( 'release')))
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReference,'.',''),' ',''),'-','')


	Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select * 
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] as A join 
	(Select REF_ID,DocumentId,OAReferencealt,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] with(NOLOCK))
	----Changed 20191113 to use new doc type table---
	---and DocType like 'halnrl')
	And DocType in (Select DocType from [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] with(NOLOCK)  where  HOA_Data_Type in ( 'release')))
	B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReferencealt,'.',''),' ',''),'-','')
	--where B.DocType like 'halnrl'

	--Select top 10 * From  [HOA].[dbo].[HOA_Lien] with(NOLOCK)

	-------ADded 20180727 to look for decoded string in doc type----
	Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select * 
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] as A join 
	(Select REF_ID,DocumentId,OAReference,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] with(NOLOCK))
	and 
		(
		(DocType like '%Release%' and DocType like '%Association%') OR 
		(DocType like '%Recission%' and DocType like '%Association%')
		)
		)
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReference,'.',''),' ',''),'-','')


	Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select * 
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] as A join 
	(Select REF_ID,DocumentId,OAReferencealt,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] with(NOLOCK))
	and 
		(
		(DocType like '%Release%' and DocType like '%Association%') OR 
		(DocType like '%Recission%' and DocType like '%Association%')
		)
		)
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReferencealt,'.',''),' ',''),'-','')
	
	
	-------------Per MS - 20181206 - Any Lien anounts > 100K - divide by 100--------
	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP]
	Set LienAmount = convert(numeric(20,2),LienAmount/100)
	--Select LienAmount , convert(numeric(20,2),LienAmount/100)
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP]
	where  convert(bigint,LienAmount) > 100000



	 ALTER TABLE dbo.[HOA_LIEN_DATA_REPLACE_SUP] ADD [RecordNumber][int]NULL


	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY RecordingDate DESC)  AS RowNum
			FROM 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_DATA_REPLACE_SUP] t  ) r ON t.REF_ID = r.REF_ID and t.PKID = r.PKID and t.INPUTKEY = r.INPUTKEY


			
			


END





