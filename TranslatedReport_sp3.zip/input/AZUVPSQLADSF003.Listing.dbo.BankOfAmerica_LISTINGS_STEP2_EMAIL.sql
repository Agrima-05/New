SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [Listing].[dbo].[BankOfAmerica_LISTINGS_STEP2_EMAIL]
as
BEGIN

DECLARE @STARTDATE3 datetime
SET @STARTDATE3 = (Select MAX_UPDATETIMESTAMP+.0001 from [AZUVPSQLADSF001.datatree.local].Listing.dbo.[LISTING_TRACKING] 
with(NOLOCK) where CUSTOMER = 'BankOfAmerica' and DATA_TYPE = 'Listing')


				DECLARE @STARTDATE2 NVARCHAR(MAX)
				Set @STARTDATE2 = (Select case when @STARTDATE3 is null or @STARTDATE3 like '' then NULL else  convert(varchar(50),convert(datetime,@STARTDATE3),21) end)
				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @importance2 NVARCHAR(MAX)
				DECLARE @body12 NVARCHAR(MAX)
				--DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				
				
				Set @importance2 = 'High' --(Select case when @STARTDATE2 is null then 'High' else 'Normal' end)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'BofA Listing Extract Complete - ' + @Date  + ' - ' + case when @STARTDATE2 is null or @STARTDATE2 like '' then 'START DATE IS NULL!!!' else @STARTDATE2 end
				 + ' - Check the below!!!'
				SET @body = 'Select [Listing Tracking ID], [FA Unique Listing Identifier - REF ID],[DATE_SENT]
 From [Listing].[dbo].[BankOfAmerica_OUT_DEDUP_CHECK] with(NOLOCK)
Order by [Listing Tracking ID], [FA Unique Listing Identifier - REF ID],[DATE_SENT] desc'
		

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = @importance2
						;



END
