/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | infc.UR_set_flags_on_Deed | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
CREATE PROCEDURE [lien_DTDB].[infc].[UR_set_flags_on_Deed] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY 
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_set_flags_on_Deed'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[UR_set_flags_on_Deed_REO_Updates]
		SELECT CurrD.deedid
			,nr3._new_REO_SALE AS nr3_new_REO_SALE
			,nr._new_REO_SALE AS nr_new_REO_SALE
			,nr2.REO_SALE as currd_reo_sale
			,nr2.GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG 
			,nr3._GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG
		INTO [lien_dtdb].[tmp].[UR_set_flags_on_Deed_REO_Updates]
		FROM [lien_dtdb].[infc].[deed_work] dw WITH (NOLOCK,INDEX (idx_ur_doc_id))
		--from deed.dbo.deed dw with(nolock,index(PK__Deed__ADD9BF987F60ED59)) --with(nolock,index(Idx_Fips_RecordDate_Include))


		
		INNER JOIN [deed].[dbo].[deed] CurrD WITH (
		NOLOCK
				,INDEX (IDX_Deed_FIPS_CLGX_UNIQUE_ID)
				) ON currd.fips = dw.fips
			AND currd.clgx_unique_id = dw.clgx_unique_id
		OUTER APPLY (
			SELECT grantee_is_foreclosing_beneficiary
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			WHERE d.doc_id = currd.ur_doc_id
			) d
		OUTER APPLY (
			SELECT CASE 
					WHEN /*CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
					AND*/ (
							CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%LIVING TRUST%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FAMILY TRUST%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%REVOCABLE TRUST'
							)
						THEN ''
					WHEN /*CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
					AND*/ (
							CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%SECRETARY OF HOUSING%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% HUD %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%SECRETARY OF URBAN%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FANNIE MAE%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%WELLS FARGO%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%BANK%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FINANCE%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LOAN%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%MORTGAGE%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%BANK %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% BANK %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% BK %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% CREDIT UNION%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% CU %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LOAN %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%LOANDEPOT%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%NEWREZ%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LOANS %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LN %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LNS %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% SAVINGS %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% SVGS %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% SVCNG %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% FSB %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% MORTGAGE %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%MORTGAGE %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%MTG %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%TD %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%LN SVCS %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%LN SVCG %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%BANK OF %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%BANC OF %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%TITLE%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% LENDER %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% DEFAULT %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '% RECON %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%SERIES 2%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%RECONVEYANCE %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FORECLOSURE %'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FUNDING%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%FINANCIAL%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%ASSESTS%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%VETERANS AFFAIRS%'
							OR CurrD.SELLER_NAME_PLAINTIFF_1 LIKE '%AFFAIRS VETERANS%'
							)
						THEN 'Y'
					ELSE ''
					END AS REO_SALE_Name
				,CASE 
					WHEN /*CurrD.BYR1_CORP_IND = 'Y'
					AND */ (
							CurrD.BYR1_OWN_NAME LIKE '%LIVING TRUST%'
							OR CurrD.BYR1_OWN_NAME LIKE '%FAMILY TRUST%'
							OR CurrD.BYR1_OWN_NAME LIKE '%REVOCABLE TRUST'
							)
						THEN ''
					WHEN /*CurrD.BYR1_CORP_IND = 'Y'
					AND*/ (
							CurrD.BYR1_OWN_NAME LIKE '%SECRETARY OF HOUSING%'
							OR CurrD.BYR1_OWN_NAME LIKE '% HUD %'
							OR CurrD.BYR1_OWN_NAME LIKE '%SECRETARY OF URBAN%'
							OR CurrD.BYR1_OWN_NAME LIKE '%FANNIE MAE%'
							OR CurrD.BYR1_OWN_NAME LIKE '%WELLS FARGO%'
							OR CurrD.BYR1_OWN_NAME LIKE '%BANK%'
							OR CurrD.BYR1_OWN_NAME LIKE '%FINANCE%'
							OR CurrD.BYR1_OWN_NAME LIKE '% LOAN%'
							OR CurrD.BYR1_OWN_NAME LIKE '%MORTGAGE%'
							OR CurrD.BYR1_OWN_NAME LIKE '%BANK %'
							OR CurrD.BYR1_OWN_NAME LIKE '% BANK %'
							OR CurrD.BYR1_OWN_NAME LIKE '% BK %'
							OR CurrD.BYR1_OWN_NAME LIKE '% CREDIT UNION%'
							OR CurrD.BYR1_OWN_NAME LIKE '% CU %'
							OR CurrD.BYR1_OWN_NAME LIKE '% LOAN %'
							OR CurrD.BYR1_OWN_NAME LIKE '% LOAN %'
							OR CurrD.BYR1_OWN_NAME LIKE '%LOANDEPOT%'
							OR CurrD.BYR1_OWN_NAME LIKE '%NEWREZ%'
							OR CurrD.BYR1_OWN_NAME LIKE '% LN %'
							OR CurrD.BYR1_OWN_NAME LIKE '% LNS %'
							OR CurrD.BYR1_OWN_NAME LIKE '% SAVINGS %'
							OR CurrD.BYR1_OWN_NAME LIKE '% SVGS %'
							OR CurrD.BYR1_OWN_NAME LIKE '% SVCNG %'
							OR CurrD.BYR1_OWN_NAME LIKE '% FSB %'
							OR CurrD.BYR1_OWN_NAME LIKE '% MORTGAGE %'
							OR CurrD.BYR1_OWN_NAME LIKE '%MORTGAGE %'
							OR CurrD.BYR1_OWN_NAME LIKE '%MTG %'
							OR CurrD.BYR1_OWN_NAME LIKE '%TD %'
							OR CurrD.BYR1_OWN_NAME LIKE '%LN SVCS %'
							OR CurrD.BYR1_OWN_NAME LIKE '%LN SVCG %'
							OR CurrD.BYR1_OWN_NAME LIKE '%BANK OF %'
							OR CurrD.BYR1_OWN_NAME LIKE '%BANC OF %'
							OR CurrD.BYR1_OWN_NAME LIKE '%TITLE%'
							OR CurrD.BYR1_OWN_NAME LIKE '% LENDER %'
							OR CurrD.BYR1_OWN_NAME LIKE '% DEFAULT %'
							OR CurrD.BYR1_OWN_NAME LIKE '% RECON %'
							OR CurrD.BYR1_OWN_NAME LIKE '%SERIES 2%'
							OR CurrD.BYR1_OWN_NAME LIKE '%RECONVEYANCE %'
							OR CurrD.BYR1_OWN_NAME LIKE '%FORECLOSURE %'
							OR CurrD.BYR1_OWN_NAME LIKE '%FUNDING%'
							OR CurrD.BYR1_OWN_NAME LIKE '%FINANCIAL%'
							OR CurrD.BYR1_OWN_NAME LIKE '%ASSESTS%'
							OR CurrD.BYR1_OWN_NAME LIKE '%VETERANS AFFAIRS%'
							OR CurrD.BYR1_OWN_NAME LIKE '%AFFAIRS VETERANS%'
							)
						THEN 'Y'
					ELSE ''
					END AS Buyer_Name_Is_REO
			) CurrD_name
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [deed].[dbo].[deed] PriorD
			WHERE PriorD.fips = CurrD.fips
				AND PriorD.ref_id = CurrD.ref_id
				AND PriorD.recording_date < CurrD.recording_date
				AND PriorD.deed_type NOT IN ('T')
				AND PriorD.detailed_doc_type NOT IN (
					'CD'
					,'RD'
					)
			ORDER BY PriorD.recording_date DESC
			) PriorD
		OUTER APPLY (
			SELECT TOP 1 *
			FROM [deed].[dbo].[deed] priort
			WHERE priort.fips = CurrD.fips
				AND priort.ref_id = CurrD.ref_id
				AND priort.recording_date < CurrD.recording_date
				--and priort.recording_date >= priord.recording_date
				AND priort.deed_type IN ('T')
				AND priort.detailed_doc_type NOT IN (
					'CD'
					,'RD'
					)
			ORDER BY priort.recording_date DESC
			) Priort
		OUTER APPLY (
			SELECT CASE 
					WHEN /*PriorD.BYR1_CORP_IND = 'Y'
					AND */ (
							PriorD.BYR1_OWN_NAME LIKE '%LIVING TRUST%'
							OR PriorD.BYR1_OWN_NAME LIKE '%FAMILY TRUST%'
							OR PriorD.BYR1_OWN_NAME LIKE '%REVOCABLE TRUST'
							)
						THEN ''
					WHEN /*PriorD.BYR1_CORP_IND = 'Y'
					AND*/ (
							PriorD.BYR1_OWN_NAME LIKE '%SECRETARY OF HOUSING%'
							OR PriorD.BYR1_OWN_NAME LIKE '% HUD %'
							OR PriorD.BYR1_OWN_NAME LIKE '%SECRETARY OF URBAN%'
							OR PriorD.BYR1_OWN_NAME LIKE '%FANNIE MAE%'
							OR PriorD.BYR1_OWN_NAME LIKE '%WELLS FARGO%'
							OR PriorD.BYR1_OWN_NAME LIKE '%BANK%'
							OR PriorD.BYR1_OWN_NAME LIKE '%FINANCE%'
							OR PriorD.BYR1_OWN_NAME LIKE '% LOAN%'
							OR PriorD.BYR1_OWN_NAME LIKE '%MORTGAGE%'
							OR PriorD.BYR1_OWN_NAME LIKE '%BANK %'
							OR PriorD.BYR1_OWN_NAME LIKE '% BANK %'
							OR PriorD.BYR1_OWN_NAME LIKE '% BK %'
							OR PriorD.BYR1_OWN_NAME LIKE '% CREDIT UNION%'
							OR PriorD.BYR1_OWN_NAME LIKE '% CU %'
							OR PriorD.BYR1_OWN_NAME LIKE '% LOAN %'
							OR PriorD.BYR1_OWN_NAME LIKE '% LOAN %'
							OR PriorD.BYR1_OWN_NAME LIKE '%LOANDEPOT%'
							OR PriorD.BYR1_OWN_NAME LIKE '%NEWREZ%'
							OR PriorD.BYR1_OWN_NAME LIKE '% LN %'
							OR PriorD.BYR1_OWN_NAME LIKE '% LNS %'
							OR PriorD.BYR1_OWN_NAME LIKE '% SAVINGS %'
							OR PriorD.BYR1_OWN_NAME LIKE '% SVGS %'
							OR PriorD.BYR1_OWN_NAME LIKE '% SVCNG %'
							OR PriorD.BYR1_OWN_NAME LIKE '% FSB %'
							OR PriorD.BYR1_OWN_NAME LIKE '% MORTGAGE %'
							OR PriorD.BYR1_OWN_NAME LIKE '%MORTGAGE %'
							OR PriorD.BYR1_OWN_NAME LIKE '%MTG %'
							OR PriorD.BYR1_OWN_NAME LIKE '%TD %'
							OR PriorD.BYR1_OWN_NAME LIKE '%LN SVCS %'
							OR PriorD.BYR1_OWN_NAME LIKE '%LN SVCG %'
							OR PriorD.BYR1_OWN_NAME LIKE '%BANK OF %'
							OR PriorD.BYR1_OWN_NAME LIKE '%BANC OF %'
							OR PriorD.BYR1_OWN_NAME LIKE '%TITLE%'
							OR PriorD.BYR1_OWN_NAME LIKE '% LENDER %'
							OR PriorD.BYR1_OWN_NAME LIKE '% DEFAULT %'
							OR PriorD.BYR1_OWN_NAME LIKE '% RECON %'
							OR PriorD.BYR1_OWN_NAME LIKE '%SERIES 2%'
							OR PriorD.BYR1_OWN_NAME LIKE '%RECONVEYANCE %'
							OR PriorD.BYR1_OWN_NAME LIKE '%FORECLOSURE %'
							OR PriorD.BYR1_OWN_NAME LIKE '%FUNDING%'
							OR PriorD.BYR1_OWN_NAME LIKE '%FINANCIAL%'
							OR PriorD.BYR1_OWN_NAME LIKE '%ASSESTS%'
							OR PriorD.BYR1_OWN_NAME LIKE '%VETERANS AFFAIRS%'
							OR PriorD.BYR1_OWN_NAME LIKE '%AFFAIRS VETERANS%'
							)
						THEN 'Y'
					ELSE ''
					END AS REO_buyer_Name
			) PriorD_name
		OUTER APPLY (
			SELECT count(1) AS cnt 
			FROM [Pre_Foreclosure].[dbo].[preforeclosure] pf WITH (
					NOLOCK
					,INDEX (Idx_FipsRefIdDocType)
					)
			WHERE pf.fips = currd.fips
				AND pf.ref_id = currd.ref_id
				AND substring(Currd.BYR1_OWN_NAME, 1, 5) = substring(pf.Lender_Beneficiary_Name, 1, 5)
				AND currd.deed_type = 'U'
			) U_pfc
		OUTER APPLY (
			SELECT CASE 
					WHEN u_pfc.cnt > 0
						--AND currd.fips = 6037
						THEN 'y8'
					WHEN d.grantee_is_foreclosing_beneficiary = 'Y'
						--AND currd.fips = 6037
						THEN 'Y7'
					WHEN CurrD.deed_type = 'U'
						--AND currd.fips = 6037
						AND (
							substring(Currd.BYR1_OWN_NAME, 1, 5) = substring(Priort.MTG1_LENDER_LAST_NAME, 1, 5)
							OR substring(Currd.BYR1_OWN_NAME, 1, 5) = substring(Priord.MTG1_LENDER_LAST_NAME, 1, 5)
							)
						THEN 'y6'
					else ''
					end as _GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG

				,case 
					WHEN CurrD.deed_type = 'U'
						THEN 'N1'
					WHEN CurrD.detailed_doc_type = 'QC'
						AND CurrD.sale_amount IS NULL
						THEN 'N2'
							--WHEN CurrD.detailed_doc_type = 'QC'
							--	AND CurrD.sale_amount > 0
							--	AND CurrD_name.REO_SALE_Name = 'Y'
							--	AND substring(CurrD.SELLER_NAME_PLAINTIFF_1, 1, 5) = substring(PriorD.BYR1_OWN_NAME, 1, 5)
							--	AND (
							--		PriorD.BYR1_CORP_IND = 'Y'
							--		OR CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
							--		)
							--	AND PriorD.deed_type = 'U'
							--	--AND PriorD.detailed_doc_type IN (
							--	--	'DL'
							--	--	,'FD'
							--	--	,'TE'
							--	--	,'SD'
							--	--	)
							--	THEN 'Y3'
					WHEN CurrD_name.REO_SALE_Name = 'Y'
						AND currd_name.Buyer_Name_Is_REO = ''
						AND (
							PriorD.BYR1_CORP_IND = 'Y'
							OR CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
							)
						AND substring(CurrD.SELLER_NAME_PLAINTIFF_1, 1, 5) = substring(PriorD.BYR1_OWN_NAME, 1, 5)
						AND PriorD.deed_type = 'u'
						--AND PriorD.detailed_doc_type IN (
						--	'DL'
						--	,'FD'
						--	,'TE'
						--	,'SD'
						--	)
						--and not (d.SALE_AMOUNT is null and d.detailed_doc_type ='QC')
						THEN 'Y1'
					WHEN CurrD_name.REO_SALE_Name = 'Y'
						AND currd_name.Buyer_Name_Is_REO = ''
						AND (
							PriorD.BYR1_CORP_IND = 'Y'
							OR CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
							)
						AND substring(CurrD.SELLER_NAME_PLAINTIFF_1, 1, 5) = substring(PriorD.BYR1_OWN_NAME, 1, 5)
						AND PriorD.deed_type = 'u'
						--AND PriorD.detailed_doc_type IN (
						--	'DL'
						--	,'FD'
						--	,'TE'
						--	,'SD'
						--	)
						--and not (d.SALE_AMOUNT is null and d.detailed_doc_type ='QC')
						THEN 'Y2'
					WHEN CurrD_name.REO_SALE_Name = 'Y'
						AND currd_name.Buyer_Name_Is_REO = ''
						AND PriorD_name.REO_buyer_Name = 'Y'
						AND (
							PriorD.BYR1_CORP_IND = 'Y'
							OR CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
							)
						AND PriorD.deed_type = 'U'
						--AND PriorD.detailed_doc_type IN (
						--	'DL'
						--	,'FD'
						--	,'TE'
						--	,'SD'
						--	)
						THEN 'Y4'
					WHEN CurrD.SELLER_NAME_PLAINTIFF1_CORP_IND = 'Y'
						AND CurrD_name.REO_SALE_Name = 'Y'
						AND currd_name.Buyer_Name_Is_REO = ''
						AND priord.deed_type = 'U'
						--AND priord.detailed_doc_type IN (
						--	'DL'
						--	,'FD'
						--	,'SD'
						--	,'TE'
						--	)
						THEN 'Y5'
							--not REO Sale)
							--else REO sale = 'Y'
					ELSE ''
					END AS _new_REO_SALE
			) Nr
		OUTER APPLY (
			SELECT isnull(substring(nr._new_REO_SALE, 1, 1), '') AS _new_REO_SALE
				,isnull(CurrD.REO_SALE, '') AS REO_SALE
				,isnull(currd.GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG,'') as GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG
			) nr2
		OUTER APPLY (
			SELECT CASE 
					WHEN substring(nr2._new_REO_SALE, 1, 1) = 'N'
						THEN ''
					ELSE substring(nr2._new_REO_SALE, 1, 1)
					END AS _new_REO_SALE
				,substring(nr._GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG,1,1) as _GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG
			) nr3
		WHERE CurrD.deed_type NOT IN ('T') 	AND (nr3._new_REO_SALE > '' or nr._GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG > '')
		and dw.RECORDING_DATE > '2021-01-01'
		--WHERE dw.deedid = 542757514 -- dw.fips = 6037 
		--	and dw.ur_doc_id = 305313496
	

		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE UNIQUE CLUSTERED INDEX idx_deedid ON [lien_dtdb].[tmp].[UR_set_flags_on_Deed_REO_Updates] (deedid)


	--select * from lien_dtdb.tmp.UR_set_flags_on_Deed_REO_Updates
	--where _GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG <> 'n'
	
	BEGIN TRANSACTION

	UPDATE [lien_DTDB].[infc].[d]
	SET d.reo_sale = case when nr3_new_REO_SALE = 'Y' then 'Y' else null end 
		,d.GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG = case when t._GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG > '' then 'Y' else null end 
		,d.UPDATED = getdate()
		,d.REO_SALE_FLAG = case when isnull(nr3_new_REO_SALE,'') = 'Y' then 1 else null end 
	FROM [deed].[dbo].[deed] d WITH (
			NOLOCK
			,INDEX (PK__Deed__ADD9BF987F60ED59)
			)
	INNER JOIN [lien_dtdb].[tmp].[UR_set_flags_on_Deed_REO_Updates] t WITH (
			NOLOCK
			,INDEX (idx_deedid)
			) ON t.DeedID = d.deedid

	where isnull(d.reo_sale ,'') <> isnull(nr3_new_REO_SALE,'')
	or isnull(d.GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG, '') <> isnull(t._GRANTEE_IS_FORECLOSING_BENEFICIARY_FLAG,'')


	COMMIT

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_set_flags_on_Deed'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


