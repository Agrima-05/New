SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Update Date Sent Updates for CI Listings
-- =============================================
CREATE PROCEDURE [Reports].[dbo].[usp_901_Update_HW_Listings_Date]
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [Reports].[dbo].[SentToHW_Listings] 
	SET DateSentUpdates = GetDate()

END

