SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF





CREATE PROCEDURE [zCust_RenewFinancial].[dbo].[usp_501_STEP2_Taxsource_Submission] 
		
	
AS
BEGIN

	SET NOCOUNT ON;


		----------------20250113 - Per Leslie this customer is contracted for both automated & manual
		-------------******However per their contract we run only as Automated & the CUSTOMER will request which to rerun as Manual - DO NOT DEFAULT to Manual****
		
		

			Select A.FIPS, B.State, B.[County Name], count(*) as TOTAL
			,sum(case when A.REF_ID is not null then 1 else 0 end) as MATCHED_REF_ID
			,sum(case when A.REF_ID is null then 1 else 0 end) as NOT_MATCHED
			from [zCust_RenewFinancial].[dbo].[a_PropMatch_WORK] as A 
			join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
			--where A.REF_ID is not null
			Group by  A.FIPS, B.State, B.[County Name]
			Order by  A.FIPS, B.State, B.[County Name]

		


			----DTAPI Production credentials for the Renew Account:

			----Account Number:
			----	2016111
			----Username:
			----	DTAPI_Renew-ADS_Prod
			----Password:
			----	RenewDTAPI1@Prod
			----Products Enabled:
			----	TaxSourceAutomated   
			---- OR Taxsource (for Manual fulfillment)

			----D:\SupportTools\TaxSourceApiExe
			----TaxSourcePuller.exe BATCHID USERNAME PSWD TaxSourceAutomated
			
			----TaxSourcePuller.exe 300 DTAPI_Renew-ADS_Prod RenewDTAPI1@Prod TaxSourceAutomated

		
	 

			------------------Tax Source-----------
			DECLARE @CUSTOMER varchar(100)
			Set @CUSTOMER = 'RenewFinancial'
			DECLARE @DATE varchar(30)
			--Set @DATE = (Select format(getdate(),'yyyyMMddHHmm'))
			Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			DECLARE @BATCH varchar(50)
			--SET @BATCH = (Select max(convert(int,ID)) + 1 from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK))
			--Set @DATE = '202104071524'
			
			Print @DATE

			--Select * From [TaxSourceAPI].[dbo].[Batch]
			--Order by ID desc

			
			INsert into [TaxSourceAPI].[dbo].[Batch]([Name])
			Select @CUSTOMER + '_' + @DATE

			SET @BATCH = (Select ID from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			)

			Print @BATCH

			Update [TaxSourceAPI].[dbo].[Batch]
			Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Renew_Financial\TaxSource\IMAGES\'+@DATE+'_'+@BATCH+'\Images'
			where [Name] = @CUSTOMER + '_' + @DATE
			AND [ImageFolderPath] is null
			and ID = @BATCH

			

			Select * From [TaxSourceAPI].[dbo].[Batch]
			Order by ID Desc


			--Truncate table [INPUT_MONITOR]
			--Select * From [INPUT_MONITOR]

			
			--DECLARE @CUSTOMER varchar(100)
			--Set @CUSTOMER = 'RenewFinancial'
			--DECLARE @DATE varchar(30)
			----Set @DATE = (Select format(getdate(),'yyyyMMddHHmm'))
			--Set @DATE = (Select format(getdate(),'yyyyMMdd'))
			--DECLARE @BATCH varchar(50)

			Insert into  [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]( [UniqueID]      ,[Reference ID]      ,[Address]      ,[City]      ,[State]
			,[Zip]      ,[APN]      ,[DATE_ADDED]      ,[FIPS]      ,[REF_ID]      ,[BATCHID])
			
			Select 	
			RAW_ID, RAW_ID
			,REPLACE(FULLSTREETADDRESS,'  ',' ')
			,REPLACE(A.CITY,'  ',' '), A.STATE, A.ZIP9
			,REPLACE(INPUTAPN,',','')
			,@DATE
			--,(Select format(getdate(),'yyyyMMdd'))
			,RIGHT(('0' + A.FIPS),5)
			,A.REF_ID
			,(Select MAX([Id]) from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK) where [Name] like 
			@CUSTOMER + '_' + @DATE )
			--,(Select MAX([Id]) from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK) where [Name] like 
			--'RenewFinancial' + '_' + '20230407' )
			--Select * 
			From [zCust_RenewFinancial].[dbo].[a_Propmatch_WORk] as A 
			--join (		Select * from x_Custom_OUTPUT
			--where ReportStatus in ('NotAvailable','Errored','Error')) B on A.RAW_ID = B.ExternalKey

			--join INPUT_RAW_TAXSOURCE as B on A.RAW_ID = B.[App ID]
			--left outer join [INPUT_MONITOR] as C on A.RAW_ID = C.UniqueID
			--where  C.UniqueID is null


			--Select * from INPUT_IN

			--Select * From dbo.INPUT_RAW_TAXSOURCE

			------One time manual push----
			--Insert into  [INPUT_MONITOR]( [UniqueID]      ,[Reference ID]      ,[Address]      ,[City]      ,[State]
			--,[Zip]      ,[APN]      ,[DATE_ADDED]      ,[FIPS]      ,[REF_ID]      ,[BATCHID])
			
		
			--Select[UniqueID]      ,[Reference ID]      ,[Address]      ,A.[City]      ,A.[State]
			--,A.[Zip]      ,[APN]      ,[DATE_ADDED]      ,A.[FIPS]      ,B.[REF_ID]      
			--,(Select MAX([Id]) from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK) where [Name] like 
			--@CUSTOMER + '_' + @DATE )
			--From INPUT_MONITOR_COMPLETED as A 
			--join a_PRopmatch_WORk as B on A.UniqueID = B.RAW_ID
			--where A.REF_ID is null
			--and B.REF_ID is not null
			
			--Update [INPUT_MONITOR]
			--Set BatchID = '54'
			--where DATE_COMPLETED is null
	
			Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]

			Select FIPS, count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
			Group by FIPS
			Order by FIPS

			Select BatchID, count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
			Group by BatchID
			Order by BatchID

			Select distinct DATE_ADDED  From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
			where DATE_COMPLETED is null

			
			--Select * From [TaxSourceAPI].sys.tables as A join [TaxSourceAPI].sys.columns as B on A.object_id = B.object_id
			--where A.Name like 'Property'
			--Order by B.Name
			
			--Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
			--, City, State, Zip, RefId, APN, Fips
			--, REFERENCEID)
			--Select 
			--A.RAW_ID
			--,B.[BATCHID]
			--,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
			--, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
			------Added 20210326 so customer can pass through their secondary reference id
			----,ROW_NUMBER() OVER (order by RAW_ID)
			--,B.[Reference ID]
			--From dbo.a_Propmatch_WORk as A 
			--join [INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
			--where B.BATCHID = 
			--(Select MAX(convert(bigint,BATCHID)) From zCust_RenewFinancial.dbo.[INPUT_MONITOR] with(NOLOCK)
			--where DATE_COMPLETED is null)


				Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId
				-----Changed 20220406 to populate FULL address rather than parsed so the executable submits the SearchType of FULLADDRESS rather than ADDRESS
				-----per GT & MC
				--, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
				,AddressLine
				, City, State, Zip, RefId, APN, Fips
				, REFERENCEID)
				
				Select 
				A.RAW_ID
				,B.[BATCHID]
				--,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
				,FullStreetAddress
				, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
				----Added 20210326 so customer can pass through their secondary reference id
				--,ROW_NUMBER() OVER (order by RAW_ID)
				,B.[Reference ID]
				From [zCust_RenewFinancial].[dbo].[a_Propmatch_WORk] as A 
				join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
				where B.BATCHID = 
				(Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
				where DATE_COMPLETED is null)
				
					


			Select count(*) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]

			Select RAW_ID, * From [zCust_RenewFinancial].[dbo].[a_PRopmatch_WORK] where REF_ID in (
			Select REF_ID from (
			Select REF_ID, count(*) as TOTAL From [zCust_RenewFinancial].[dbo].[a_PRopmatch_WORK]
			Group by REF_ID
			having count(*) > 1)A)
			Order by REF_ID


			
			Select * From [TaxSourceAPI].[dbo].[Property] as A 
			join [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] as B on A.BatchID = B.BatchID
			and A.ExternalKey = B.UniqueID
			--and A.ExternalKey = 'FL-00157878' 


			--IF((
			--Select TOTAL - NOT_SUBMITTED  as 'ASP_COUNT' from (
			--Select count(*) as TOTAL 
			--,sum(case when SubmissionStatus is null then 1 else 0 end) as NOT_SUBMITTED
			--From [TaxSourceAPI].[dbo].[Property] as A with(NOLOCK)
			--join zCust_RenewFinancial.dbo.INPUT_MONITOR as B  with(NOLOCK) on A.BatchID = B.BatchID
			--and A.ExternalKey = B.UniqueID
			--Group by SubmissionStatus)A
			--where TOTAL > 0) = 0)
			
			--BEGIN
			--PRINT 'NOT_SUBMITTED'

			--END


		
			Update [TaxSourceAPI].[dbo].[Property]
			Set ExternalKey = LTRIM(RTRIM(ExternalKey))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ExternalKey like '% %'

			--Select * From [TaxSourceAPI].[dbo].[Property]
			--where (ExternalKey like '% %'
			--OR ReferenceId like '% %')
			--and BatchId = 17


			Update [TaxSourceAPI].[dbo].[Property]
			Set ReferenceId = LTRIM(RTRIM(ReferenceId))
			where BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and ReferenceId like '% %'


			Select ReferenceId , ExternalKey From [TaxSourceAPI].[dbo].[Property]
			where  BatchId = (Select MAX(convert(bigint,BATCHID)) From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR] with(NOLOCK)
			where DATE_COMPLETED is null)
			and (ReferenceId like '% %'
			OR ExternalKey like '% %')


			Select * From [zCust_RenewFinancial].[dbo].[INPUT_MONITOR]
			

			


			Select * From [TaxSourceAPI].[dbo].[Batch]
			Order by ID desc


		------	-------RESEND-------

		----	Select * From [INPUT_MONITOR]

		--	DECLARE @CUSTOMER2 varchar(100)
		--	Set @CUSTOMER2 = 'RenewFinancial'
		--	DECLARE @DATE2 varchar(30)
		--	Set @DATE2 = (Select format(getdate(),'yyyyMMdd'))
		--	DECLARE @BATCH2 varchar(50)
		--	Print @DATE2

		--	INsert into [TaxSourceAPI].[dbo].[Batch]([Name])
		--	Select @CUSTOMER2 + '_' + @DATE2

		--	--Select * From [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
		--	--where [Name] like 'Renew%'
		--	--Order by [Name] desc

		--	SET @BATCH2 = (Select ID from [TaxSourceAPI].[dbo].[Batch] with(NOLOCK)
		--	where [Name] = @CUSTOMER2 + '_' + @DATE2
		--	AND [ImageFolderPath] is null
		--	)

		--	Print @BATCH2

		--	Update [TaxSourceAPI].[dbo].[Batch]
		--	Set [ImageFolderPath] = '\\AZUVPAPPDFTP002.datatree.local\CMAS$\Customers\Renew_Financial\TaxSource\IMAGES\'+@DATE2+'_'+@BATCH2+'\Images'
		--	where [Name] = @CUSTOMER2 + '_' + @DATE2
		--	AND [ImageFolderPath] is null
		--	and ID = @BATCH2

			

		--	Select * From [TaxSourceAPI].[dbo].[Batch]
		--	Order by ID Desc


		--	Update [INPUT_MONITOR]
		--	Set BATCHID = '70'
		--	WHERE FIPS in ('12097','12015','12071','12017','12021','12085','12117','12001','12087','12127','12115','12053','12081',
		--	'12105','12061','12069')
			

	
		--	Insert into [TaxSourceAPI].[dbo].[Property](ExternalKey, BatchId
		--	-----Changed 20220406 to populate FULL address rather than parsed so the executable submits the SearchType of FULLADDRESS rather than ADDRESS
		--	-----per GT & MC
		--	--, StreetNumber, PreDirection, StreetName, StreetType, PostDirection, UnitNumber
		--	,AddressLine
		--	, City, State, Zip, RefId, APN, Fips
		--	, REFERENCEID)
		--	Select 
		--	A.RAW_ID
		--	,B.[BATCHID]
		--	--,A.HouseNbr, A.LeftDirection, A.Street, A.Mode, A.RightDirection, A.UnitNumber
		--	,FullStreetAddress
		--	, A.City, A.State, A.Zip9, A.REF_ID, A.INPUTAPN, RIGHT(('0' + A.FIPS),5)
		--	----Added 20210326 so customer can pass through their secondary reference id
		--	--,ROW_NUMBER() OVER (order by RAW_ID)
		--	,B.[Reference ID]
		--	From dbo.a_Propmatch_WORk as A 
		--	join [INPUT_MONITOR] as B on A.RAW_ID = B.UNIQUEID
		--	where B.BATCHID = 
		--	(Select MAX(convert(bigint,BATCHID)) From zCust_RenewFinancial.dbo.[INPUT_MONITOR] with(NOLOCK)
		--	where DATE_COMPLETED is null)
		----	--AND B.FIPS in ('12097','12015','12071','12017','12021','12085','12117','12001','12087','12127','12115','12053','12081',
		----	--'12105','12061','12069')
		



		--Select BatchID, count(*) From INPUT_MONITOR
		--Group by BATCHID


		----	Select * From [TaxSourceAPI].[dbo].[Property] with(NOLOCK)
		----	where BatchId = (Select MAX(convert(bigint,BATCHID)) From zCust_RenewFinancial.dbo.[INPUT_MONITOR] with(NOLOCK)
		----	where DATE_COMPLETED is null)


		--	--Delete From [TaxSourceAPI].[dbo].[Property] 
		--	--where BatchID = 40
		
		
END



