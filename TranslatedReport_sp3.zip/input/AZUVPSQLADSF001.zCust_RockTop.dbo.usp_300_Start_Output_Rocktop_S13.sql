SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_RockTop].[dbo].[usp_300_Start_Output_Rocktop_S13]


AS
BEGIN
	
	SET NOCOUNT ON;

	------20260731 - Include FARecordType = I, C & U - So running on FATimestamp just not incuding D records per EC

		DROP TABLE [dbo].[x_Custom_OUTPUT_S13]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S13](
		   [InputUniqueID][varchar](250)NULL,
			[ReportDate][varchar](250)NULL,
			[AddressStandardization][varchar](250)NULL,
			[Deed Coverage][varchar](250)NULL,
			[Mortgage Coverage][varchar](250)NULL,
			[PropertyStatus][varchar](250)NULL,
			[EventStatus][varchar](250)NULL,
			[FIPS][varchar](250)NULL,
			[PropertyID][varchar](250)NULL,
			[APN][varchar](250)NULL,
			[APNSeqNbr][varchar](250)NULL,
			[OldAPN][varchar](250)NULL,
			[TaxAccountNumber][varchar](250)NULL,
			[MatchedFlag][varchar](250)NULL,
			[SitusHouseNbr][varchar](250)NULL,
			[SitusHouseNbrSuffix][varchar](250)NULL,
			[SitusDirectionLeft][varchar](250)NULL,
			[SitusStreet][varchar](250)NULL,
			[SitusMode][varchar](250)NULL,
			[SitusDirectionRight][varchar](250)NULL,
			[SitusUnitType][varchar](250)NULL,
			[SitusUnitNbr][varchar](250)NULL,
			[SitusCity][varchar](250)NULL,
			[SitusState][varchar](250)NULL,
			[SitusZIP5][varchar](250)NULL,
			[SitusZIP4][varchar](250)NULL,
			[SitusCarrierCode][varchar](250)NULL,
			[BuyerBorrower1CorpInd][varchar](250)NULL,
			[BuyerBorrower1Name][varchar](250)NULL,
			[BuyerBorrower1EtalInd][varchar](250)NULL,
			[BuyerBorrower1CareOfName][varchar](250)NULL,
			[BuyerBorrower1OwnershipRightsCode][varchar](250)NULL,
			[BuyerBorrower1RelationshipType][varchar](250)NULL,
			[BuyerBorrower2CorpInd][varchar](250)NULL,
			[BuyerBorrower2Name][varchar](250)NULL,
			[BuyerBorrower2OwnershipRightsCode][varchar](250)NULL,
			[BuyerBorrower2RelationshipType][varchar](250)NULL,
			[BuyerBorrower1LastName][varchar](250)NULL,
			[BuyerBorrower1FirstName][varchar](250)NULL,
			[BuyerBorrower1MiddleInitial][varchar](250)NULL,
			[BuyerBorrower1NameSuffix][varchar](250)NULL,
			[BuyerBorrower2LastName][varchar](250)NULL,
			[BuyerBorrower2FirstName][varchar](250)NULL,
			[BuyerBorrower2MiddleInitial][varchar](250)NULL,
			[BuyerBorrower2NameSuffix][varchar](250)NULL,
			[MailingHouseNbr][varchar](250)NULL,
			[MailingHouseNbrSuffix][varchar](250)NULL,
			[MailingDirectionLeft][varchar](250)NULL,
			[MailingStreet][varchar](250)NULL,
			[MailingMode][varchar](250)NULL,
			[MailingDirectionRight][varchar](250)NULL,
			[MailingUnitType][varchar](250)NULL,
			[MailingUnitNbr][varchar](250)NULL,
			[MailingCity][varchar](250)NULL,
			[MailingState][varchar](250)NULL,
			[MailingZIP5][varchar](250)NULL,
			[MailingZIP4][varchar](250)NULL,
			[MailingCarrierCode][varchar](250)NULL,
			[MailingCountyFipsCode][varchar](250)NULL,
			[MailingForeignAddressInd][varchar](250)NULL,
			[FATransactionID][varchar](250)NULL,
			[RecordingDate][varchar](250)NULL,
			[SaleDate][varchar](250)NULL,
			[DocumentNbr][varchar](250)NULL,
			[RecordingBook][varchar](250)NULL,
			[RecordingPage][varchar](250)NULL,
			[HawaiiLandCourtDocumentNbr][varchar](250)NULL,
			[HawaiiCertificateNbr][varchar](250)NULL,
			[WAExiceNbr][varchar](250)NULL,
			[DocumentType][varchar](250)NULL,
			[TransactionType][varchar](250)NULL,
			[Seller1Name][varchar](250)NULL,
			[Seller1CorpInd][varchar](250)NULL,
			[Seller2Name][varchar](250)NULL,
			[Seller2CorpInd][varchar](250)NULL,
			[SaleAmt][varchar](250)NULL,
			[SalesPriceCode][varchar](250)NULL,
			[TransferTax][varchar](250)NULL,
			[PartialInterestFlag][varchar](250)NULL,
			[ResaleFlag][varchar](250)NULL,
			[NewConstructionFlag][varchar](250)NULL,
			[InterFamilyFlag][varchar](250)NULL,
			[ForeclosureFlag][varchar](250)NULL,
			[REOSaleFlag][varchar](250)NULL,
			[FirstMtgRecordingDate][varchar](250)NULL,
			[FirstMtgDocumentDate][varchar](250)NULL,
			[FirstMtgDocumentNbr][varchar](250)NULL,
			[FirstMtgBook][varchar](250)NULL,
			[FirstMtgPage][varchar](250)NULL,
			[FirstMtgDocumentType][varchar](250)NULL,
			[FirstMtgAmt][varchar](250)NULL,
			[FirstMtgLenderName][varchar](250)NULL,
			[FirstMtgLoanTransType][varchar](250)NULL,
			[FirstMtgLoanType][varchar](250)NULL,
			[FirstMtgTermCode][varchar](250)NULL,
			[FirstMtgTerm][varchar](250)NULL,
			[FirstMtgDueDate][varchar](250)NULL,
			[FirstMtgInterestRateType][varchar](250)NULL,
			[FirstMtgInterestRate][varchar](250)NULL,
			[FirstMtgEstimatedInterestRateInd][varchar](250)NULL,
			[FirstMtgSellerCarryBackFlag][varchar](250)NULL,
			[FirstMtgPrivatePartyLender][varchar](250)NULL,
			[FirstMtgConstructionLoan][varchar](250)NULL,
			[FirstMtgRefiFlag][varchar](250)NULL,
			[FirstMtgEquityFlag][varchar](250)NULL,
			[FirstMtgHelocFlag][varchar](250)NULL,
			[FirstMtgOtherSubordinateLoanFlag][varchar](250)NULL,
			[FirstMtgSecondHomeRider][varchar](250)NULL,
			[FirstMtgCondominiumRider][varchar](250)NULL,
			[FirstMtgMultiFamily4Rider][varchar](250)NULL,
			[FirstMtgPlannedUnitDevelopmentRider][varchar](250)NULL,
			[FirstMtgAssumabilityRider][varchar](250)NULL,
			[FirstMtgBalloonRider][varchar](250)NULL,
			[FirstMtgBiweeklyPaymentRider][varchar](250)NULL,
			[FirstMtgFixedStepRateRider][varchar](250)NULL,
			[FirstMtgGraduatedPaymentRider][varchar](250)NULL,
			[FirstMtgPrepaymentRider][varchar](250)NULL,
			[FirstMtgRateImprovementRider][varchar](250)NULL,
			[FirstMtgAdjustableRateRider][varchar](250)NULL,
			[FirstMtgAdjustableRateIndex][varchar](250)NULL,
			[FirstMtgChangeIndex][varchar](250)NULL,
			[FirstMtgFirstChangeDateMonthDay][varchar](250)NULL,
			[FirstMtgFirstChangeDateYear][varchar](250)NULL,
			[FirstMtgInterestOnlyPeriod][varchar](250)NULL,
			[FirstMtgMaximumInterestRate][varchar](250)NULL,
			[FirstMtgMinimumInterestRate][varchar](250)NULL,
			[FirstMtgRateChangeFrequency][varchar](250)NULL,
			[SecondMtgRecordingDate][varchar](250)NULL,
			[SecondMtgDocumentDate][varchar](250)NULL,
			[SecondMtgDocumentNbr][varchar](250)NULL,
			[SecondMtgBook][varchar](250)NULL,
			[SecondMtgPage][varchar](250)NULL,
			[SecondMtgDocumentType][varchar](250)NULL,
			[SecondMtgAmt][varchar](250)NULL,
			[SecondMtgLenderName][varchar](250)NULL,
			[SecondMtgLoanTransType][varchar](250)NULL,
			[SecondMtgLoanType][varchar](250)NULL,
			[SecondMtgTermCode][varchar](250)NULL,
			[SecondMtgTerm][varchar](250)NULL,
			[SecondMtgDueDate][varchar](250)NULL,
			[SecondMtgInterestRateType][varchar](250)NULL,
			[SecondMtgInterestRate][varchar](250)NULL,
			[SecondMtgEstimatedInterestRateInd][varchar](250)NULL,
			[SecondMtgSellerCarryBackFlag][varchar](250)NULL,
			[SecondMtgPrivatePartyLender][varchar](250)NULL,
			[SecondMtgConstructionLoan][varchar](250)NULL,
			[SecondMtgRefiFlag][varchar](250)NULL,
			[SecondMtgEquityFlag][varchar](250)NULL,
			[SecondMtgHelocFlag][varchar](250)NULL,
			[SecondMtgOtherSubordinateLoanFlag][varchar](250)NULL,
			[SecondMtgSecondHomeRider][varchar](250)NULL,
			[SecondMtgCondominiumRider][varchar](250)NULL,
			[SecondMtgMultiFamily4Rider][varchar](250)NULL,
			[SecondMtgPlannedUnitDevelopmentRider][varchar](250)NULL,
			[SecondMtgAssumabilityRider][varchar](250)NULL,
			[SecondMtgBalloonRider][varchar](250)NULL,
			[SecondMtgBiweeklyPaymentRider][varchar](250)NULL,
			[SecondMtgFixedStepRateRider][varchar](250)NULL,
			[SecondMtgGraduatedPaymentRider][varchar](250)NULL,
			[SecondMtgPrepaymentRider][varchar](250)NULL,
			[SecondMtgRateImprovementRider][varchar](250)NULL,
			[SecondMtgAdjustableRateRider][varchar](250)NULL,
			[SecondMtgAdjustableRateIndex][varchar](250)NULL,
			[SecondMtgChangeIndex][varchar](250)NULL,
			[SecondMtgFirstChangeDateMonthDay][varchar](250)NULL,
			[SecondMtgFirstChangeDateYear][varchar](250)NULL,
			[SecondMtgInterestOnlyPeriod][varchar](250)NULL,
			[SecondMtgMaximumInterestRate][varchar](250)NULL,
			[SecondMtgMinimumInterestRate][varchar](250)NULL,
			[SecondMtgRateChangeFrequency][varchar](250)NULL,
			[LotCode][varchar](250)NULL,
			[LotNbr][varchar](250)NULL,
			[LandLot][varchar](250)NULL,
			[Block][varchar](250)NULL,
			[Section][varchar](250)NULL,
			[District][varchar](250)NULL,
			[LegalUnit][varchar](250)NULL,
			[Municipality][varchar](250)NULL,
			[SubdivisionName][varchar](250)NULL,
			[SubdivisionPhaseNbr][varchar](250)NULL,
			[SubdivisionTractNbr][varchar](250)NULL,
			[Meridian][varchar](250)NULL,
			[AssessorsMapRef][varchar](250)NULL,
			[LegalDescription][varchar](250)NULL,
			[TitleCompanyName][varchar](250)NULL,
			[MultiAPN][varchar](250)NULL,
			[FATimeStamp][varchar](250)NULL,
			[FARecordType][varchar](250)NULL,
			----INTERNAL---
			[MAX_FATimeStamp][varchar](250)NULL

		) ON [PRIMARY]

		

		
		--SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13](
		[InputUniqueID],
		[ReportDate],
		[AddressStandardization],
		--[Deed Coverage],
		--[Mortgage Coverage],
		[PropertyStatus],
		[EventStatus],
		[FIPS],
		[PropertyID],
		[APN],
		[APNSeqNbr],
		[OldAPN],
		[TaxAccountNumber],
		[MatchedFlag],
		[SitusHouseNbr],
		[SitusHouseNbrSuffix],
		[SitusDirectionLeft],
		[SitusStreet],
		[SitusMode],
		[SitusDirectionRight],
		[SitusUnitType],
		[SitusUnitNbr],
		[SitusCity],
		[SitusState],
		[SitusZIP5],
		[SitusZIP4],
		[SitusCarrierCode],
		[BuyerBorrower1CorpInd],
		[BuyerBorrower1Name],
		[BuyerBorrower1EtalInd],
		[BuyerBorrower1CareOfName],
		[BuyerBorrower1OwnershipRightsCode],
		[BuyerBorrower1RelationshipType],
		[BuyerBorrower2CorpInd],
		[BuyerBorrower2Name],
		[BuyerBorrower2OwnershipRightsCode],
		[BuyerBorrower2RelationshipType],
		[BuyerBorrower1LastName],
		[BuyerBorrower1FirstName],
		[BuyerBorrower1MiddleInitial],
		[BuyerBorrower1NameSuffix],
		[BuyerBorrower2LastName],
		[BuyerBorrower2FirstName],
		[BuyerBorrower2MiddleInitial],
		[BuyerBorrower2NameSuffix],
		[MailingHouseNbr],
		[MailingHouseNbrSuffix],
		[MailingDirectionLeft],
		[MailingStreet],
		[MailingMode],
		[MailingDirectionRight],
		[MailingUnitType],
		[MailingUnitNbr],
		[MailingCity],
		[MailingState],
		[MailingZIP5],
		[MailingZIP4],
		[MailingCarrierCode],
		[MailingCountyFipsCode],
		[MailingForeignAddressInd],
		[FATransactionID],
		[RecordingDate],
		[SaleDate],
		[DocumentNbr],
		[RecordingBook],
		[RecordingPage],
		[HawaiiLandCourtDocumentNbr],
		[HawaiiCertificateNbr],
		[WAExiceNbr],
		[DocumentType],
		[TransactionType],
		[Seller1Name],
		[Seller1CorpInd],
		[Seller2Name],
		[Seller2CorpInd],
		[SaleAmt],
		[SalesPriceCode],
		[TransferTax],
		[PartialInterestFlag],
		[ResaleFlag],
		[NewConstructionFlag],
		[InterFamilyFlag],
		[ForeclosureFlag],
		[REOSaleFlag],
		[FirstMtgRecordingDate],
		[FirstMtgDocumentDate],
		[FirstMtgDocumentNbr],
		[FirstMtgBook],
		[FirstMtgPage],
		[FirstMtgDocumentType],
		[FirstMtgAmt],
		[FirstMtgLenderName],
		[FirstMtgLoanTransType],
		[FirstMtgLoanType],
		[FirstMtgTermCode],
		[FirstMtgTerm],
		[FirstMtgDueDate],
		[FirstMtgInterestRateType],
		[FirstMtgInterestRate],
		[FirstMtgEstimatedInterestRateInd],
		[FirstMtgSellerCarryBackFlag],
		[FirstMtgPrivatePartyLender],
		[FirstMtgConstructionLoan],
		[FirstMtgRefiFlag],
		[FirstMtgEquityFlag],
		[FirstMtgHelocFlag],
		[FirstMtgOtherSubordinateLoanFlag],
		[FirstMtgSecondHomeRider],
		[FirstMtgCondominiumRider],
		[FirstMtgMultiFamily4Rider],
		[FirstMtgPlannedUnitDevelopmentRider],
		[FirstMtgAssumabilityRider],
		[FirstMtgBalloonRider],
		[FirstMtgBiweeklyPaymentRider],
		[FirstMtgFixedStepRateRider],
		[FirstMtgGraduatedPaymentRider],
		[FirstMtgPrepaymentRider],
		[FirstMtgRateImprovementRider],
		[FirstMtgAdjustableRateRider],
		[FirstMtgAdjustableRateIndex],
		[FirstMtgChangeIndex],
		[FirstMtgFirstChangeDateMonthDay],
		[FirstMtgFirstChangeDateYear],
		[FirstMtgInterestOnlyPeriod],
		[FirstMtgMaximumInterestRate],
		[FirstMtgMinimumInterestRate],
		[FirstMtgRateChangeFrequency],
		[SecondMtgRecordingDate],
		[SecondMtgDocumentDate],
		[SecondMtgDocumentNbr],
		[SecondMtgBook],
		[SecondMtgPage],
		[SecondMtgDocumentType],
		[SecondMtgAmt],
		[SecondMtgLenderName],
		[SecondMtgLoanTransType],
		[SecondMtgLoanType],
		[SecondMtgTermCode],
		[SecondMtgTerm],
		[SecondMtgDueDate],
		[SecondMtgInterestRateType],
		[SecondMtgInterestRate],
		[SecondMtgEstimatedInterestRateInd],
		[SecondMtgSellerCarryBackFlag],
		[SecondMtgPrivatePartyLender],
		[SecondMtgConstructionLoan],
		[SecondMtgRefiFlag],
		[SecondMtgEquityFlag],
		[SecondMtgHelocFlag],
		[SecondMtgOtherSubordinateLoanFlag],
		[SecondMtgSecondHomeRider],
		[SecondMtgCondominiumRider],
		[SecondMtgMultiFamily4Rider],
		[SecondMtgPlannedUnitDevelopmentRider],
		[SecondMtgAssumabilityRider],
		[SecondMtgBalloonRider],
		[SecondMtgBiweeklyPaymentRider],
		[SecondMtgFixedStepRateRider],
		[SecondMtgGraduatedPaymentRider],
		[SecondMtgPrepaymentRider],
		[SecondMtgRateImprovementRider],
		[SecondMtgAdjustableRateRider],
		[SecondMtgAdjustableRateIndex],
		[SecondMtgChangeIndex],
		[SecondMtgFirstChangeDateMonthDay],
		[SecondMtgFirstChangeDateYear],
		[SecondMtgInterestOnlyPeriod],
		[SecondMtgMaximumInterestRate],
		[SecondMtgMinimumInterestRate],
		[SecondMtgRateChangeFrequency],
		[LotCode],
		[LotNbr],
		[LandLot],
		[Block],
		[Section],
		[District],
		[LegalUnit],
		[Municipality],
		[SubdivisionName],
		[SubdivisionPhaseNbr],
		[SubdivisionTractNbr],
		[Meridian],
		[AssessorsMapRef],
		[LegalDescription],
		[TitleCompanyName],
		[MultiAPN],
		[FATimeStamp],
		[FARecordType],
		[MAX_FATimeStamp])
	  
		Select 
		A.INPUTKEY
		,convert(date,getdate())
		,A.[AddressStandardization]
		--,A.[Deed Coverage]
		--,A.[Mortgage Coverage]
		,A.[PropertyStatus]
		,'Event Found'
		,B.FIPS
		,B.PROPERTYUNIQUEID
		,B.APN
		,B.APNSEQUENCENBR
		,B.PREVIOUSPARCELNUMBER
		,B.TAXACCOUNTNUMBER
		,B.MatchedFlag
		,B.HOUSENUMBER
		,B.HOUSENUMBERSUFFIX
		,B.DIRECTIONLEFT
		,B.STREETNAME
		,B.Suffix
		,B.DIRECTIONRIGHT
		,B.UNITTYPE
		,B.UNITNUMBER
		,B.CITY
		,B.STATE
		,B.ZIPCODE
		,B.ZIPPLUS4
		,B.CARRIERCODE
		,B.CORPORATEINDICATOR
		,B.BUYERNAMEBORROWERNAME1
		,B.OWNERETALIND
		,B.OwnerCAREOfNAME
		,B.OWNERSHIPRIGHTSCODE1
		,B.OWNERRELATIONSHIPTYPE1
		,B.CORPORATEINDICATOR2
		,B.BUYERNAMEBORROWERNAME2
		,B.OWNERSHIPRIGHTSCODE2
		,B.OWNERRELATIONSHIPTYPE2
		,B.BUYER1LASTNAME
		,B.BUYER1FIRSTNAME
		,B.BUYER1MIDDLEName
		,B.BUYER1SUFFIX
		,B.BUYER2LASTNAME
		,B.BUYER2FIRSTNAME
		,B.BUYER2MIDDLEName
		,B.BUYER2SUFFIX
		,B.MAILHOUSENUMBER
		,B.MAILHOUSENUMBERSUFFIX
		,B.MAILDIRECTIONLEFT
		,B.MAILSTREETNAME
		,B.MAILMODE
		,B.MAILDIRECTIONRIGHT
		,B.MAILUNITTYPE
		,B.MAILUNITNUMBER
		,B.MAILCITY
		,B.MAILSTATE
		,B.MAILZIPCODE
		,B.MAILZIPPlus4
		,B.MAILCARRIERCODE
		,B.MailingCountyFipsCode
		,B.MailingForeignAddressInd
		,B.FirstAmericanUniqueTransactionID
		,B.RECORDINGDATE
		,B.SALEDATE
		,B.DOCUMENTNUMBER
		,B.RECORDINGBOOK
		,B.RECORDINGPAGE
		,B.HAWAIILANDCOURTDOCUMENTNUMBER
		,B.HAWAIITCTCERTIFICATENUMBER
		,B.WAEXCISENUMBER
		,B.DOCUMENTTYPE
		,B.TRANSACTIONTYPE
		,B.SELLERNAME
		,B.SELLERNAMECORPINDICATOR
		,B.SELLERNAME2
		,B.SELLERNAME2CORPINDICATOR
		,B.SALEAMOUNT
		,B.SalesPriceCode
		,B.TRANSFERTAX
		,B.PARTIALINTERESTINDICATORFLAG
		,B.RESALEFLAG
		,B.NEWCONSTRUCTIONFLAG
		,B.INTERFAMILYFLAG
		,B.FORCLOSUREFLAG
		,B.REOSALEFLAG
		,B.FIRSTMORTGAGERECORDINGDATE
		,B.FIRSTMORTGAGEDOCDATE
		,B.FIRSTMORTGAGEDOCUMENTNUMBER
		,B.FIRSTMORTGAGERECORDINGBOOK
		,B.FIRSTMORTGAGERECORDINGPAGE
		,B.FIRSTMORTGAGEDETAILEDDOCUMENTTYPE
		,B.FIRSTMORTGAGEMORTGAGEAMOUNT
		,B.FIRSTMORTGAGELENDERNAME
		,B.FIRSTMORTGAGELOANTYPECODE
		,B.FIRSTMORTGAGEDETAILEDLOANTYPE
		,B.FIRSTMORTGAGETERMCODE
		,B.FIRSTMORTGAGETERM
		,B.FIRSTMORTGAGEDUEDATE
		,B.FIRSTMORTGAGEINTERESTRATETYPE
		,B.FIRSTMORTGAGEINTERESTRATE
		,B.Loan1InterestRateSrce
		,B.FIRSTMORTGAGESELLERCARRYBACKFLAG
		,B.FIRSTMORTGAGEPRIVATEPARTYLENDER
		,B.FIRSTMORTGAGECONSTRUCTIONLOAN
		,B.FIRSTMORTGAGEREFIFLAG
		,B.FIRSTMORTGAGEEQUITYFLAG
		,B.FIRSTMORTGAGEHELOCFLAG
		,B.FIRSTMORTGAGEOTHERSUBORDINATELOANFlag
		,B.FIRSTMORTGAGESecondHomeRider
		,B.FIRSTMORTGAGECondominiumRider
		,B.FIRSTMORTGAGEMultiFamily4Rider
		,B.FIRSTMORTGAGEPlannedUnitDevelopmentRider
		,B.FIRSTMORTGAGEAssumabilityRider
		,B.FIRSTMORTGAGEBalloonRider
		,B.FIRSTMORTGAGEBiweeklyPaymentRider
		,B.FIRSTMORTGAGEFixedStepRateRider
		,B.FIRSTMORTGAGEGraduatedPaymentRider
		,B.FIRSTMORTGAGEPrepaymentRider
		,B.FIRSTMORTGAGERateImprovementRider
		,B.FIRSTMORTGAGEAdjustableRateRider
		,B.FIRSTMORTGAGEAdjustableRateIndex
		,B.FIRSTMORTGAGEChangeIndex
		,B.FIRSTMORTGAGEFirstChangeDateMonthDay
		,B.FIRSTMORTGAGEFirstChangeDateYear
		,B.FIRSTMORTGAGEInterestOnlyPeriod
		,B.FIRSTMORTGAGEMaximumInterestRate
		,B.FIRSTMORTGAGEMinimumInterestRate
		,B.FIRSTMORTGAGERateChangeFrequency
		,B.SECONDMORTGAGERECORDINGDATE
		,B.SECONDMORTGAGEDOCDATE
		,B.SECONDMORTGAGEDOCUMENTNUMBER
		,B.SECONDMORTGAGERECORDINGBOOK
		,B.SECONDMORTGAGERECORDINGPAGE
		,B.SECONDMORTGAGEDETAILEDDOCUMENTTYPE
		,B.SECONDMORTGAGEAMOUNT
		,B.SECONDMORTGAGELENDERNAME
		,B.SECONDMORTGAGELOANTYPECODE
		,B.SECONDMORTGAGEDETAILEDLOANTYPE
		,B.SECONDMORTGAGETERMCODE
		,B.SECONDMORTGAGETERM
		,B.SECONDMORTGAGEDUEDATE
		,B.SECONDMORTGAGEINTERESTRATETYPE
		,B.SECONDMORTGAGEINTERESTRATE
		,B.Loan2InterestRateSrce
		,B.SECONDMORTGAGESELLERCARRYBACK
		,B.SECONDMORTGAGEPRIVATEPARTYLENDER
		,B.SECONDMORTGAGECONSTRUCTIONLOAN
		,B.SECONDMORTGAGEREFIFLAG
		,B.SECONDMORTGAGEEQUITYFLAG
		,B.SECONDMORTGAGEHELOCFLAG
		,B.SECONDMORTGAGEOTHERSUBORDINATELOANFlag
		,B.SECONDMORTGAGESecondHomeRider
		,B.SECONDMORTGAGECondominiumRider
		,B.SECONDMORTGAGEMultiFamily4Rider
		,B.SECONDMORTGAGEPlannedUnitDevelopmentRider
		,B.SECONDMORTGAGEAssumabilityRider
		,B.SECONDMORTGAGEBalloonRider
		,B.SECONDMORTGAGEBiweeklyPaymentRider
		,B.SECONDMORTGAGEFixedStepRateRider
		,B.SECONDMORTGAGEGraduatedPaymentRider
		,B.SECONDMORTGAGEPrepaymentRider
		,B.SECONDMORTGAGERateImprovementRider
		,B.SECONDMORTGAGEAdjustableRateRider
		,B.SECONDMORTGAGEAdjustableRateIndex
		,B.SECONDMORTGAGEChangeIndex
		,B.SECONDMORTGAGEFirstChangeDateMonthDay
		,B.SECONDMORTGAGEFirstChangeDateYear
		,B.SECONDMORTGAGEInterestOnlyPeriod
		,B.SECONDMORTGAGEMaximumInterestRate
		,B.SECONDMORTGAGEMinimumInterestRate
		,B.SECONDMORTGAGERateChangeFrequency
		,B.LotCode
		,B.LotNumber
		,B.LandLot
		,B.[Block]
		,B.Section
		,B.District
		,B.Unit
		,B.CityMunicipalityTownship
		,B.SubdivisionName
		,B.PhaseNo
		,B.TractNo
		,B.SecTwnRngMer
		,B.AssessorsMapRef
		,B.LEGALDESCRIPTION
		,B.TITLECOMPANYNAME
		,B.MULTIAPN
		,B.UPDATETIMESTAMP
		,B.UCID
		,convert(datetime2,A.MAX_FATIMESTAMP)
		--Select  convert(datetime2,A.MAX_FATIMESTAMP)
		FROM [zCust_RockTop].[dbo].[INPUT_MONITOR] as A 
		join [data].[dbo].[vDeedMortgageSTD2] as B with(NOLOCK) on 
		A.FIPS = B.FIPS
		and A.PropertyID = B.PROPERTYUNIQUEID
		where 
		A.PropertyID is not null and A.PropertyID not like '' and A.PropertyID not like '0'
		AND (convert(datetime2,B.FATimeStamp) > convert(datetime2,A.MAX_FATIMESTAMP)
		OR A.MAX_FATIMESTAMP is null)
		and B.UCID not like 'D'

		

		------Insert Non Matched & records with no new transactions

		INSERT INTO [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13](
		[InputUniqueID],
		[ReportDate],
		[AddressStandardization],
		[PropertyStatus],
		[EventStatus])
		Select 
		A.INPUTKEY
		,convert(date,getdate())
		,A.[AddressStandardization]
		,A.[PropertyStatus]
		,'Event Not Found'
		FROM [zCust_RockTop].[dbo].[INPUT_MONITOR] as A 
		left outer join [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13] as B with(NOLOCK) 
		on A.INPUTKEY = B.[InputUniqueID]
		where B.[InputUniqueID] is null


		Update [zCust_RockTop].[dbo].[A]
		Set
		A.[Mortgage Coverage] = C.SAMActive
		,A.[Deed Coverage] = C.DeedActive
		From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13] as A join 
		[zCust_RockTop].[dbo].[INPUT_MONITOR] as B with(NOLOCK) on  A.[InputUniqueID] = B.INPUTKEY
		join [global].[dbo].[county] as C with(NOLOCK) on B.FIPS = C.FIPSCode


		Update [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		set
		[Mortgage Coverage] = case when [Mortgage Coverage] like '1' then 'In Coverage' else 'Not In Coverage' end

		Update [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		set
		[Deed Coverage] = case when [Deed Coverage] like '1' then 'In Coverage' else 'Not In Coverage' end




		Select top 1000 * From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]


		Update  [zCust_RockTop].[dbo].[A]
		SET A.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		--Select * 
		FROM [zCust_RockTop].[dbo].[INPUT_MONITOR] a JOIN [zCust_RockTop].[dbo].[a_ASP_IN_STD] b
		on a.INPUTKEY = b.Raw_ID



		Update [zCust_RockTop].[dbo].[INPUT_MONITOR]
		SET PropertyStatus = CASE WHEN 
		(PropertyID is  not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_RockTop].[dbo].[a] 
		SET PropertyStatus = 'Multiple Properties Found' 
		FROM [zCust_RockTop].[dbo].[INPUT_MONITOR] a join [zCust_RockTop].[dbo].[a_PropMatch_WORK_FLANK] B
		on a.INPUTKEY = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		
		Select [Deed Coverage], count(*) From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Deed Coverage]
				
		Select [Mortgage Coverage], count(*) From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		Group by [Mortgage Coverage]

		Select AddressStandardization, count(*) From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		Group by AddressStandardization

		Select PropertyStatus, count(*) From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		Group by PropertyStatus

		Select EventStatus, count(*) From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
		Group by EventStatus

	

		Select top 1000 *  From [zCust_RockTop].[dbo].[x_Custom_OUTPUT_S13]
			

END






