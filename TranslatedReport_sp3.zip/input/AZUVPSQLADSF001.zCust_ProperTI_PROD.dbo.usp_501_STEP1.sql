SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_ProperTI_PROD].[dbo].[usp_501_STEP1] 
	
AS
BEGIN

	SET NOCOUNT ON;

		-----------20240328 - SAMPLE ONLY----
		--Truncate table INPUT_RAW_CUST
		--Insert into INPUT_RAW_CUST
		--Select top 50 PROPERTYID, SitusSTDFullSTreetAddress,SitusSTDCity,SitusSTDState,SitusSTDzip5,
		--'MARICOPA'
		--,DATEADD("DD",-10,convert(datetime,currsalerecordingdate))
		--,'A'
		----,B.FA_Initial_List_Date
		--From data.dbo.Property as A with(NOLOCK)
		--join Listing.dbo._LISTINGS_ALL_CURRENT as B With(NOLOCK)
		--on A.FIPS = B.County_FIPS
		--and A.PROPERTYID = B.PM_PROPERTYID
		--where A.currsalerecordingdate < B.FA_Initial_List_Date
		--and B.Current_Listing_Ind = 1
		--and A.faucidflag not like 'D'
		----and B.FA_Initial_List_Date > getdate()-120
		--and A.currsalerecordingdate > getdate()-365
		--and ISNULL(SitusSTDFullSTreetAddress,'') not like ''
		--and A.FIPS like '04013'

		--Insert into INPUT_RAW_CUST
		--Select top 50 PROPERTYID, SitusSTDFullSTreetAddress,SitusSTDCity,SitusSTDState,SitusSTDzip5,
		--'MARICOPA'
		--,DATEADD("DD",-10,convert(datetime,currsalerecordingdate))
		--,'A'
		----,B.FA_Initial_List_Date
		--From data.dbo.Property as A with(NOLOCK)
		--where A.currsalerecordingdate < A.Mtg1RecordingDt
		--and A.faucidflag not like 'D'
		--and A.currsalerecordingdate > getdate()-365
		--and ISNULL(SitusSTDFullSTreetAddress,'') not like ''
		--and A.FIPS like '04013'
		
		--Select reference_id, count(*) From INPUT_RAW_CUST
		--Group by reference_id
		--having count(*) > 1

	


		

		

		----Backup INPUT_IN_MONITOR in case need to roll back---
		DECLARE @DATE varchar(50)
		Set @DATE =  Format(GetDate(), N'yyyy-MM-dd-HHmmss')
		--Print @DATE
		EXEC('Select * into dbo.[INPUT_MONITOR_' + @DATE + '] From INPUT_MONITOR')

	
		--Truncate table INPUT_MONITOR
	
		Select count(*) From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] with(NOLOCK)


			
		Select * From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST]


		Select top 10000 * From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		
		Select DATE_RECEIVED, count(*) From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		Group by DATE_RECEIVED
		ORder by DATE_RECEIVED
	
		
	

		-----Verify Missing Deletes in portfolio---
		Select A.*, B.DATE_RECEIVED
		From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.REFERENCE_ID = B.INPUTKEY
		where A.REFERENCE_ID is not null 
		and A.[Monitoring_Type] like 'D%'
		And B.INPUTKEY is null


		Select [Monitoring_Type], count(*) FROm [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST]
		Group by [Monitoring_Type]


		Update [zCust_ProperTI_PROD].[dbo].[A]
		Set 
		A.DATE_DELETED = convert(date,Getdate())
		,A.[Monitoring Type] = 'D'
		--Select * 
		From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as A 
		join [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as B on 
		A.INPUTKEY = B.REFERENCE_ID
		where A.INPUTKEY is not null 
		and B.[Monitoring_Type] like 'D%'


		

		Insert into [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR_DELETED]
		Select * From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] like 'D'


		Delete From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] like 'D' 

		Select [Monitoring_Type], count(*) From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST]
		Group by [Monitoring_Type]

		
		----------------Change Records---------------
		-----Verify MISSING CHANGES portfolio---
		Select A.*, B.DATE_RECEIVED
		From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.REFERENCE_ID = B.INPUTKEY
		where A.REFERENCE_ID is not null and A.[Monitoring_Type] like 'C%'
		and B.INPUTKEY is null

		

		Update [zCust_ProperTI_PROD].[dbo].[A]
		Set 
		A.DATE_DELETED = convert(date,Getdate())
		,A.[Monitoring Type] = 'D'
		--Select * 
		From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as A 
		join [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as B on 
		A.INPUTKEY = B.REFERENCE_ID
		where B.REFERENCE_ID is not null 
		and B.[Monitoring_Type] like 'C%'


		Insert into [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR_DELETED]
		Select * From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		where  [Monitoring Type] like 'D'



		Delete From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] like 'D'


		---Add Changed Records---
		Insert into [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] ([INPUTKEY]
      ,[ADDRESS]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[Start Date]
      ,[Monitoring Type]
      ,[DATE_RECEIVED])
		Select A.[REFERENCE_ID]
		
		,A.[STREET_Address]  ,A.[City] ,A.[State]  ,A.[ZIP_CODE]  ,convert(date,A.[Start_Date])
		,A.[Monitoring_Type]
		,Convert(date,Getdate())
		--Select * 
		from [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.[REFERENCE_ID] = B.INPUTKEY
		where B.INPUTKEY is null 
		And A.[Monitoring_Type] like 'C%'




		-----Verify Add record is NOT already in portfolio---
		Select A.*, B.DATE_RECEIVED
		From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.[REFERENCE_ID] = B.INPUTKEY
		where A.[REFERENCE_ID] is not null and A.[Monitoring_Type] like 'A%'

		Select [Monitoring_Type], count(*) From [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST]
		Group by [Monitoring_Type]


		--Truncate table INPUT_MONITOR

		---Add New---
		Insert into [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] ( [INPUTKEY]
      ,[ADDRESS]
      ,[CITY]
      ,[STATE]
      ,[ZIPCODE]
      ,[Start Date]
      ,[Monitoring Type]
      ,[DATE_RECEIVED])
		Select A.[REFERENCE_ID]
		
		,A.[STREET_Address]  ,A.[City] ,A.[State]  ,A.[ZIP_CODE]  ,convert(date,A.[Start_Date])
		,A.[Monitoring_Type]
		,Convert(date,Getdate())
		--Select * 
		from [zCust_ProperTI_PROD].[dbo].[INPUT_RAW_CUST] as A 
		left outer join [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as B on 
		A.[REFERENCE_ID] = B.INPUTKEY
		where B.INPUTKEY is null 
		And A.[Monitoring_Type] like 'A%'

		
		Select DATE_RECEIVED, count(*)  FROM [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR]
		Group by DATE_RECEIVED
		Order by DATE_RECEIVED desc


		---------20250722 - MOVED to 501 STEP 2 to accomodate multiple input files
	----Select * From INPUT_MONITOR

	--	TRUNCATE TABLE INPUT_IN

	--	INSERT INTO INPUT_IN([INPUTKEY],[INPUTAddress],[INPUTCity],[INPUTState],[INPUTZip])
	--	SELECT [INPUTKEY]      
	--	,REPLACE(REPLACE(REPLACE(LTRIM(RTRIM([Address])),'    ',' '),'   ',' '),'  ',' ')
	--	,REPLACE(REPLACE(REPLACE(LTRIM(RTRIM([City])),'    ',' '),'   ',' '),'  ',' ')
	--	,[State]      ,[ZIPCODE]        
	--	FROM INPUT_MONITOR
	--	WHERE [INPUTKEY] is not null and [INPUTKEY] not like ''
	--	and [Monitoring Type] not like 'D'

	--	Select * From INPUT_IN
	--	where INPUTKEY like '%e%'

	--	 --Select top 100 * From INPUT_IN

	--	 Select Inputkey, count(*) From INPUT_IN
	--	 Group by Inputkey
	--	 Having count(*) > 1

	--	  Select * From INPUT_IN
	--	  where [INPUTAddress] like '%  %'

	--	  Select * From INPUT_IN
	--	  where [INPUTCity] like '%  %'

		 
	--	  Select * From INPUT_IN
	--	  where len(InputState) > 2

	--	  Select * From INPUT_IN
	--	  where len([INPUTZip]) > 10


	--	UPDATE a 
	--	SET a.[InputState] = b.[State]
	--	FROM INPUT_IN a JOIN Global.dbo.StateNames b
	--	on a.[InputState] = b.[StateName]
	--	where len(a.[InputState])>2 

	--		Select * From INPUT_IN
	--		where len([InputState])>2
	--		and len([InputState])<4

	--		Update INPUT_IN
	--		Set [InputState] = left(REPLACE([InputState],' ',''),2)
	--		where len([InputState])>2
	--		and len([InputState])<4

	--		Select * From INPUT_IN where 
	--		len([InputState])>2

	--	UPDATE INPUT_IN 
	--	SET [InputState] = NULL
	--	where len([InputState])>2




	-- EXEC [dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	-------- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

		
	--		IF (SELECT COUNT(*) FROM dbo.ProperTI_PROD_STD) = 0
	--		BEGIN
	--			---- Subsequent 2 min wait periods until ASP is complete
	--			DECLARE @CheckASP as int
				
	--				SET @CheckASP = 0

	--			WHILE @CheckASP = 0
	--				BEGIN
	--					WAITFOR DELAY '00:01'
	--					--Checks for completion ** If not Wait again

	--				SET @CheckASP = (Select COUNT(*) from dbo.ProperTI_PROD_STD)
	--				END
	--		END

				



 --   EXEC dbo.usp_100c_sp_ASP_Cust_STD

	
	--	Update a_ASP_IN_STD
	--	Set FIPS = RIGHT(('0' + convert(varchar(5),FIPS)),5)
	--	where FIPS not like '0'

	

	--	Select FIPS, count(*) From a_ASP_IN_STD
	--	Group by FIPS
	--	Order by FIPS
	  
	--    ------New Process 20210203 to Prematch FLANK-----
			  
			 
	--		  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[w_PreMatch]') AND type in (N'U'))
	--		  DROP TABLE [dbo].[w_PreMatch]

			  
 --             SELECT Right('0' + FIPS,5) as FIPS, FullStreetAddress, City, State, Zip, ZIP4, convert(bigint,0) as PropertyID,'' as MulitMatch
	--		  ,RAW_ID
	--		  ,B.INPUTBorrowerLastName
 --             INTO [dbo].w_PreMatch
 --             FROM [dbo].[a_ASP_IN_STD] as A 
	--		  join INPUT_IN as B on A.RAW_ID = B.INPUTKey

			  

 --             Create index [ix_Addr] on [dbo].w_PreMatch(FIPS,FullStreetAddress,Zip,Zip4)

 --             DECLARE @FipsCode varchar(5)

 --             DECLARE Prematch CURSOR FOR  
 --                    SELECT Distinct [FIPS] 
 --                    FROM [dbo].w_PreMatch
 --                    WHERE LEN(FIPS)=5
 --                    ORDER BY [FIPS]


 --             OPEN Prematch   
 --             FETCH NEXT FROM Prematch INTO @FipsCode

 --             WHILE @@FETCH_STATUS = 0   
 --             BEGIN   
  
 --                    PRINT @FipsCode

 --                    EXEC('UPDATE a
 --                                 SET a.PropertyID = b.Propertyid
 --                                 FROM [dbo].[w_PreMatch] a JOIN zCust_ADS__00_SharedProcs.dbo.Property b with(NOLOCK)
 --                                 on a.FIPS = b.FIPS
 --                                 and a.FullStreetAddress = b.SitusStdFullStreetAddress
 --                                 and a.Zip = b.SitusStdZIP5
 --                                 and a.ZIP4 = b.SitusStdZIP4
 --                                 WHERE a.FIPS = ''' + @FipsCode + '''
 --                                 and b.FIPS = ''' + @Fipscode + '''
 --                          ')

	--					   	EXEC('UPDATE a
 --                                 SET a.PropertyID = NULL
 --                                 FROM [dbo].[w_PreMatch] a 
	--							  JOIN zCust_ADS__00_SharedProcs.dbo.Property_DUPS b with(NOLOCK)
 --                                 on a.FIPS = b.FIPS
 --                                 and a.FullStreetAddress = b.SitusStdFullStreetAddress
 --                                 and a.Zip = b.SitusStdZIP5
 --                                 and a.ZIP4 = b.SitusStdZIP4
 --                                 WHERE a.FIPS = ''' + @FipsCode + '''
 --                                 and b.FIPS = ''' + @Fipscode + '''
 --                          ')
                     
 --                    FETCH NEXT FROM Prematch INTO @FipsCode   
 --             END   

 --             CLOSE Prematch   
 --             DEALLOCATE Prematch 


 --             Select count(*) from [dbo].[w_PreMatch]
 --             Select count(*) from [dbo].[w_PreMatch] where propertyid = 0


	--		   IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INPUT_IN_PREMATCH]') AND type in (N'U'))
	--		  DROP TABLE [dbo].[INPUT_IN_PREMATCH]


	--		 Select * into dbo.[INPUT_IN_PREMATCH]
	--		 From INPUT_IN

	--		 Truncate table INPUT_IN

	--			INSERT INTO INPUT_IN(INPUTKey, INPUTAddress, INPUTCity, INPUTState, INPUTZip,   INPUTStartDate,   INPUTBorrowerLastName, 
	--									 INPUTAPN)
	--			SELECT        A.INPUTKey, A.INPUTAddress, A.INPUTCity, A.INPUTState, A.INPUTZip,  A.INPUTStartDate,  A.INPUTBorrowerLastName, 
	--									 A.INPUTAPN
	--			FROM            INPUT_IN_PREMATCH AS A INNER JOIN
	--									 w_PreMatch AS B ON A.INPUTKey = B.RAW_ID INNER JOIN
	--									 a_ASP_IN_STD AS C ON A.INPUTKey = C.RAW_ID
	--			WHERE        (B.PropertyID LIKE '0') AND (A.INPUTAddress NOT LIKE 'P%') AND (C.FIPS NOT LIKE '0')


	--		Select count(*) From INPUT_IN
	--		Select count(*) From [INPUT_IN_PREMATCH]

	 

	----EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_ProperTI_PROD'
	--EXEC [zCust_ADS__00_SharedProcs].dbo.[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_ProperTI_PROD'


	
		
	--	---Append Prematch records---
	--INSERT INTO dbo.[a_PropMatch_Work_FLANK]([ASP_ID]
	--			  ,[FullStreetAddress]
	--			  ,[HouseNbr]
	--			  ,[LeftDirection]
	--			  ,[Street]
	--			  ,[Mode]
	--			  ,[RightDirection]
	--			  ,[UnitNumber]
	--			  ,[City]
	--			  ,[State]
	--			  ,[Zip]
	--			  ,[Zip4]
	--			  ,[Zip9]
	--			  ,[FIPS]
	--			  ,[CountyName]
 --				  ,[BorrowerLastName]
	--			 ,[RAW_ID]
	--			 ,[INPUTAPN]
	--			 ,PropertyID)
	--			Select distinct A.[ASP_ID]
	--			  ,A.[FullStreetAddress]
	--			  ,A.[HouseNbr]
	--			  ,A.[LeftDirection]
	--			  ,A.[Street]
	--			  ,A.[Mode]
	--			  ,A.[RightDirection]
	--			  ,A.[UnitNumber]
	--			  ,a.[City]
	--			  ,a.[State]
	--			  ,a.[Zip]
	--			  ,a.[Zip4]
	--			  --,a.[zip]+isNULL(a.[zip4],'''') as [Zip9]
	--			  ,RIGHT(('0' + a.[zip]),5) + isNULL(a.[zip4],'') as [Zip9]
	--			  ,A.[FIPS]
	--			  ,A.[CountyName]
	--			  ,C.[INPUTBorrowerLastName]
	--			  ,A.[RAW_ID]
	--			  ,LEFT([InputAPN],50)
	--			  ,C.PropertyID
	--			   from dbo.[a_ASP_IN_STD] a 
	--			   left outer join w_PreMatch as C on A.RAW_ID = C.RAW_ID
	--			  LEFT OUTER JOIN [a_PropMatch_Work_FLANK] as B  
	--			  on a.[RAW_ID] = b.[RAW_ID]
	--			  where B.[RAW_ID] is null



	--			   Select count(*) From [a_PropMatch_Work_FLANK]
	--			 Select count(*) From [a_ASP_IN_STD]



	--	-- Post append clean up

	--	UPDATE dbo.[a_PropMatch_Work_FLANK]
	--	SET Street = left([xMSmith].[dbo].[BeforeLastSpace](substring(street,1,LEN(Street)-(LEN(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%'
	--	, REVERSE(street)) - 1)))))),55)
	--	,UnitNumber = left(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%', REVERSE(street)) - 1)),15)
	--	WHERE REF_ID is null 
	--	AND Street like '% %[a-z][0-9]%[0-9]' or street like '% %[a-z][0-9]'
		

	--	UPDATE dbo.[a_PropMatch_Work_FLANK]
	--	SET HouseNbr = left(REPLACE(HouseNbr,LeftDirection,''),30)
	--	WHERE isNULL(LeftDirection,'') not like '' AND HouseNbr like '%' + LeftDirection
		

	--	UPDATE dbo.[a_PropMatch_Work_FLANK]
	--	SET INPUTAPN = NULL
	--	WHERE INPUTAPN = '0' or INPUTAPN = ''
	

	
	--	Update A
	--	Set 
	--	A.REF_ID = B.DTDB_Ref_ID
	--	--Select A.RAW_ID, A.REF_ID, B.DTDB_Ref_ID, A.FullStreetAddress, B.SitusStdFullStreetAddress
	--	From [a_PropMatch_Work_FLANK] as A 
	--	join data.dbo.Property as B with(NOLOCK) on 
	--	A.PropertyID = B.PropertyID
	--	where A.PropertyID is not null
	--	and (A.REF_ID is null or A.REF_ID <> B.DTDB_Ref_ID)
	--	and B.DTDB_Ref_ID is not null
		


	--	Select count(*) FRom [a_PropMatch_Work_FLANK] where REF_ID is null

	

	--Truncate table a_PropMatch_WORK
	--Insert into a_PropMatch_WORK
	--Select * From a_PropMatch_WORK_FLANK


	--Truncate table INPUT_IN

	--Insert into INPUT_IN
	--Select * From [INPUT_IN_PREMATCH]


	--		Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
	--		 from dbo.a_PropMatch_WORK_FLANK
	--		group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END

	--		Select CASE WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
	--		 from dbo.a_PropMatch_WORK_FLANK
	--		group by CASE WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END


	--		Select A.*,CASE WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END as FLANK_AddrMatch
	--		,B.State, B.[County Name]
	--		 from dbo.a_PropMatch_WORK_FLANK as A 
	--		 left outer join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
	--		 where ISNULL(PropertyID,'0')  like '0'
	--		Order by CASE WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch is NULL) then 'Not Matched' 
	--		WHEN (ISNULL(PropertyID,'0') like '0' and MultiMatch = 'M') then 'Multi Matched'
	--		ELSE 'Matched' END



	---------Update Monitor table-----
	--Update A
	--Set A.PROPERTYID = B.PropertyID
	--,MultiMatch = NULL
	----Select A.RAW_ID,A.PROPERTYID, B.PropertyID
	--From a_PropMatch_Work_FLANK as A 
	--join INPUT_MONITOR as B on A.RAW_ID = B.INPUTKEY
	--where 
	--((A.PROPERTYID is null or A.PROPERTYID like '')
	--and B.PropertyID is not null )
	




	--Update A
	--Set A.REF_ID = B.REF_ID
	--,MultiMatch = NULL
	----Select A.RAW_ID,A.PROPERTYID, B.PropertyID, B.FinalValue, A.REF_ID, B.REF_ID
	--From a_PropMatch_Work as A 
	--join INPUT_MONITOR as B on A.RAW_ID = B.INPUTKEY
	--where 
	--((A.REF_ID is null or A.REF_ID like '')
	--and B.REF_ID is not null )

	----Update A
	----Set A.REF_ID = B.REF_ID
	----,A.PropertyID = B.PROPERTYID
	------Select A.RAW_ID, A.PropertyID, A.REF_ID, B.INPUTKEY
	----From a_PropMatch_Work_FLANK as A join  INPUT_MONITOR as B on A.RAW_ID = B.INPUTKEY
	----where A.REF_ID is null



	


	--Select * From INPUT_MONITOR
	--where PROPERTYID is null
	--Order by DATE_RECEIVED DESC

	
	
	
	--Update A
	--Set 
	--A.PROPERTYID = B.PropertyID
	--,A.REF_ID = B.REF_ID
	----Select A.UniqueId,A.PROPERTYID, B.PropertyID, A.*
	--From INPUT_MONITOR as A 
	--join a_PropMatch_Work_FLANK as B on A.INPUTKEY = B.RAW_ID
	--where (A.PROPERTYID is null or A.PROPERTYID like '')
	--and B.PropertyID is not null 


	--Update A
	--Set 
	--A.PROPERTYID = B.PropertyID
	--,A.REF_ID = B.REF_ID
	----Select A.UniqueId,A.PROPERTYID, B.PropertyID, A.FinalValue
	--From INPUT_MONITOR as A 
	--join a_PropMatch_Work_FLANK as B on A.INPUTKEY = B.RAW_ID
	--where (A.PROPERTYID is not null and  A.PROPERTYID not like '')
	--and B.PropertyID is not null 
	--AND A.PROPERTYID <> B.PropertyID

	


	--Update A
	--Set A.REF_ID = B.DTDB_Ref_ID
	----Select A.UniqueId,A.REF_ID, B.DTDB_Ref_ID
	--From INPUT_MONITOR as A 
	--join data.dbo.Property as B with(NOLOCK) on A.PROPERTYID = B.PROPERTYID
	--where (A.PROPERTYID is not null and  A.PROPERTYID not like '')
	--and B.DTDB_Ref_ID is not null 
	--AND A.REF_ID <> B.DTDB_Ref_ID



	--Update A
	--Set A.FIPS = B.FIPS
	----Select A.UniqueId,A.FIPS, B.FIPS
	--From INPUT_MONITOR as A 
	--join a_PropMatch_Work_FLANK as B on A.INPUTKEY = B.RAW_ID
	--where B.FIPS is not null and B.FIPS not like '' and B.FIPS not like '0'


	--Select count(*) From INPUT_MONITOR
	--Select count(*) From INPUT_IN

	----Select * From INPUT_MONITOR
	----where INPUTKEY <> PROPERTYID


	--Select count(*)
	--,Sum(case when REF_ID is null then 1 else 0 end) as NULL_REF
	-- From   INPUT_MONITOR


	-- Select DATE_RECEIVED, count(*) 
	-- ,Sum(case when REF_ID is null then 1 else 0 end) as NULL_REF
	-- From   INPUT_MONITOR
	-- Group by DATE_RECEIVED
	-- Order by DATE_RECEIVED desc


	-- --EXEC dbo.usp_502_Pull_DTDB_DATA_V2
	-- --EXEC dbo.usp_502_Pull_FLANK_DATA

	-- --Select * From global.dbo.county where FIPSCODE = '04013'

	-- --Select * From INPUT_MONITOR
	-- --where INPUTKEY <> PROPERTYID


END


