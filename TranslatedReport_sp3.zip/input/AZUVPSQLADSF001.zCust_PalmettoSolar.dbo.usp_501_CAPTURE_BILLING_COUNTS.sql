SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_PalmettoSolar].[dbo].[usp_501_CAPTURE_BILLING_COUNTS] 
	
AS
BEGIN

	SET NOCOUNT ON;


	 -----------------BILLING COUNTS-------------

	 ----20250529 - Per WO = Charge Per input record standardized & matched:
	 ----1-20K = $0.10 per 
	 ----20,001-60K = $0.075 per 
	 ----60,001-120K = $0.067 per 
	 ----120,001 - 250K  = $0.06 per 
	 ----No more than 250K
	 
	 ------$2000 Monthly Min per SOW
	  ---PLUS $3.00 PER EVENT


	  ----Ticket 7739 is S20 For Event Counts
	  ----Ticket 7741 is for S60 - Portfolio Monitor Counts


	  

		INSERT INTO [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING](INPUTKEY, ADDRESS, CITY, STATE, ZIPCODE, [Start Date], [Monitoring Type], DATE_RECEIVED, DATE_DELETED, PROPERTYID,  MAX_LISTDATE,  FIPS)
		SELECT INPUTKEY, ADDRESS, CITY, STATE, ZIPCODE, [Start Date], [Monitoring Type], DATE_RECEIVED, DATE_DELETED, PROPERTYID,  MAX_LISTDATE,  FIPS
		FROM     [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR]
		where PropertyID is not null and propertyID not like '' and propertyID not like '0'


		


END


