/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_get_Related_Docids | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
 
/*
This query text was retrieved from showplan XML, and may be truncated.
*/
CREATE PROCEDURE [lien_DTDB].[INFC].[usp_get_Related_Docids] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddinfcLog] N'info'
		,N'usp_get_Related_Docids'
		,N'Started'

	--use Doc_Id from novadimdoc..Dim_Nova_Document
	--to get the values on doc_xref
	--	fct_doc_name
	--select top 100 * from novadimdoc..Dim_Nova_Document rollback
	--- begin finding related ref_ids to be moved 
	DROP TABLE

	IF EXISTS #doc_id
		SELECT DISTINCT a.doc_id
		INTO #doc_id
		FROM (
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg1_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg1_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg2_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg2_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg3_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg3_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg4_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg4_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			) a

	INSERT INTO [lien_dtdb].[tmp].[reprocess_records_to_be_processed] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,[previous_doc_unique_id]
		,[update_type]
		,[doc_title]
		,[doc_type]
		)
	SELECT d.doc_id
		,d.m_update_date AS m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.[previous_doc_unique_id]
		,d.[update_type]
		,d.[doc_title]
		,d.[doc_type]
	FROM [lien].[ur].[DOCUMENT] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	LEFT JOIN [lien_dtdb].[tmp].[reprocess_records_to_be_processed] b WITH (
			NOLOCK
			,INDEX (idx)
			) ON b.doc_id = d.doc_id
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM #doc_id
			)
		AND b.doc_id IS NULL
		AND d.m_status_id = 1
	AND d.source IN (
			'EPR'
			,'REDX'
			)


	DROP TABLE

	IF EXISTS [Lien_dtdb].[dbo].[lien_fix_doc_ids]
		SELECT DISTINCT a.doc_id
		INTO [Lien_dtdb].[dbo].[lien_fix_doc_ids]
		FROM [Lien].[UR].[Merge_ref_ids] a WITH (
				NOLOCK
				,INDEX (idx_ref_id)
				)
		OUTER APPLY (
			SELECT d.doc_id
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					)
			WHERE d.doc_id = a.doc_id
				AND d.doc_type IN (
					SELECT ur_value
					FROM [Lien_Dtdb].[dbo].[UR_Document_Types] DT
					WHERE DEED_TYPE NOT IN ('Z')
							and (dt.Delete_date IS NULL or dt.Delete_date > D.Recording_Date_D)
					)
			) d
		WHERE a.ref_id IN (
				SELECT DISTINCT ref_id
				FROM [Lien].[UR].[Merge_ref_ids] d WITH (
						NOLOCK
						,INDEX (id_doc_id)
						)
				WHERE d.doc_id IN (
						SELECT doc_id
						FROM [LIEN_DTDB].[tmp].[reprocess_records_to_be_processed] g
						WHERE g.doc_type IN (
								SELECT ur_value
								FROM [Lien_Dtdb].[dbo].[UR_Document_Types] DT
								WHERE DEED_TYPE NOT IN ('Z')
									and (dt.Delete_date IS NULL or dt.Delete_date > G.Recording_Date_D)
								)
						)
					AND ref_id > 0
				)
			AND d.doc_id IS NOT NULL
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[dbo].[lien_fix_doc_ids] (doc_id)

	--select * from Lien_dtdb.dbo.lien_fix_doc_ids
	--DROP TABLE
	--IF EXISTS Lien_dtdb.dbo.lien_fix_name
	--	SELECT b.doc_id
	--		,try_cast(substring(last_company_name, 1, 4) AS VARCHAR(4)) AS buyr_nm
	--	INTO Lien_dtdb.dbo.lien_fix_name
	--	FROM lien.ur.NAME n WITH (INDEX (doc_id))
	--	INNER JOIN Lien_dtdb.dbo.lien_fix_doc_ids b WITH (
	--			NOLOCK
	--			,INDEX (idx_doc_id)
	--			) ON b.doc_id = n.doc_id
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);
	DROP TABLE

	IF EXISTS [Lien_dtdb].[dbo].[lien_fix_name]
		SELECT b.doc_id
			,n.buyr_nm
		INTO [Lien_dtdb].[dbo].[lien_fix_name]
		FROM [Lien_dtdb].[dbo].[lien_fix_doc_ids] b WITH (
				NOLOCK
				,INDEX (idx_doc_id)
				)
		OUTER APPLY (
			SELECT try_cast(substring(last_company_name, 1, 4) AS VARCHAR(4)) AS buyr_nm
			FROM [lien].[ur].[NAME] n WITH (INDEX (doc_id))
			WHERE n.doc_id = b.doc_id
			) n
		WHERE n.buyr_nm IS NOT NULL
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[dbo].[lien_fix_name] (doc_id)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix]
		CREATE TABLE [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] (
			ROW4 BIGINT NULL
			,doc_id INT NOT NULL
			,ur_matrix VARCHAR(200) NULL
			,m_status_id TINYINT NULL
			,fips_code VARCHAR(200) NULL
			,recording_date_d DATE NULL
			,doc_type VARCHAR(200) NULL
			,ref_id INT NULL
			,buyr_nm VARCHAR(4) NULL
			,property_id_sequence_number INT NULL
			,reprocess_flag CHAR(1) NULL
			,Instrument_nbr VARCHAR(100) NULL
			,_target VARCHAR(20) NULL
			)

	--ALTER TABLE lien_dtdb.tmp.S6_Merge_ref_ids_name_fix ADD property_id_sequence_number int ;
	INSERT INTO [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] (
		ROW4
		,doc_id
		,ur_matrix
		,m_status_id
		,fips_code
		,recording_date_d
		,doc_type
		,ref_id
		,buyr_nm
		,property_id_sequence_number
		,reprocess_flag
		,Instrument_nbr
		)
	SELECT ROW_NUMBER() OVER (
			PARTITION BY 0 ORDER BY (
					SELECT 0
					)
			) AS ROW4
		,a.doc_id
		,a.ur_matrix
		,a.m_status_id
		,a.fips_code
		,a.recording_date_d
		,a.doc_type
		,a.ref_id
		,a.buyr_nm
		,a.property_id_sequence_number
		,a.reprocess_flag
		,a.Instrument_nbr
	FROM (
		SELECT DISTINCT a.doc_id
			,a.ur_matrix
			,a.m_status_id
			,a.fips_code
			,a.recording_date_d
			,a.doc_type
			,a.ref_id
			,n.buyr_nm
			,a.property_id_sequence_number
			,a.reprocess_flag
			,a.Instrument_nbr
		FROM [Lien].[UR].[Merge_ref_ids] a WITH (INDEX (id_doc_id))
		INNER JOIN [Lien_dtdb].[dbo].[lien_fix_doc_ids] b WITH (INDEX (idx_doc_id)) ON b.doc_id = a.doc_id
		INNER JOIN [Lien_dtdb].[dbo].[lien_fix_name] n WITH (INDEX (idx_doc_id)) ON n.doc_id = b.doc_id
			--OUTER APPLY (
			--	SELECT substring(try_cast(last_company_name AS VARCHAR), 1, 4) AS buyr_nm
			--	FROM lien.ur.NAME n WITH (INDEX (doc_id))
			--	WHERE n.doc_id IN (/*209200972, 209129021, 209200972, 209129021, 209129021, 209129021, 209200972, 209200972, 209200972) --*/ a.doc_id)
			--	) n
			--where a.ref_id in (select ref_id from  Lien.UR.Merge_ref_ids where doc_id = 209200972)
		) a
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--create index idx_ref_id on Lien.UR.Merge_ref_ids (ref_id) include (doc_id )
	CREATE NONCLUSTERED INDEX ida ON [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] (fips_code ASC) INCLUDE (
		doc_id
		,ROW4
		,ur_matrix
		,m_status_id
		,recording_date_d
		,doc_type
		,ref_id
		,buyr_nm
		,property_id_sequence_number
		,reprocess_flag
		,Instrument_nbr
		)

	CREATE NONCLUSTERED INDEX idx ON [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] (
		fips_code ASC
		,ref_id ASC
		,recording_date_d ASC
		,buyr_nm ASC
		) INCLUDE (
		ROW4
		,doc_id
		,m_status_id
		,doc_type
		,ur_matrix
		)

	CREATE INDEX idx_doc_id ON [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] (doc_id) include (
		ROW4
		,ur_matrix
		,m_status_id
		,fips_code
		,recording_date_d
		,doc_type
		,ref_id
		,buyr_nm
		,property_id_sequence_number
		,reprocess_flag
		,Instrument_nbr
		,_target
		)

	--select * from lien_dtdb.tmp.S6_Merge_ref_ids_name_fix order by buyr_nm
	-- select top 100 * from lien_dtdb.tmp.S6_Merge_ref_ids_name_fix
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[S6_Merge_ref_ids_merge_results_fix]
		CREATE TABLE [lien_dtdb].[tmp].[S6_Merge_ref_ids_merge_results_fix] (
			_merge BIGINT NULL
			,
			--ROW4 bigint NULL,
			doc_id INT NOT NULL
			,ur_matrix VARCHAR(200) NULL
			,m_status_id TINYINT NULL
			,ref_id INT NULL
			,a_doc_id INT NULL
			,
			)

	--,
	--fips_code varchar(200) NULL,
	--recording_date_d date NULL,
	--doc_type varchar(200) NULL,
	--ref_id int NULL,
	--buyr_nm varchar(4) NULL,
	--b_doc_type varchar(200) NULL,
	--property_id_sequence_number int NULL,
	--reprocess_flag char(1) NULL,
	--Instrument_nbr varchar(100) NULL,
	--_target varchar(20) NULLuse lien
	INSERT INTO [lien_dtdb].[tmp].[S6_Merge_ref_ids_merge_results_fix] (
		_merge
		,
		--,ROW4
		--,
		doc_id
		,ur_matrix
		,m_status_id
		,ref_id
		,a_doc_id
		)
	--,fips_code
	--,recording_date_d
	--,doc_type
	--,buyr_nm
	--,b_doc_type
	--,property_id_sequence_number
	--,reprocess_flag
	--,Instrument_nbr
	SELECT c._merge
		,
		--,c.ROW4
		--,
		c.doc_id
		,c.ur_matrix
		,c.m_status_id
		--,c.fips_code
		--,c.recording_date_d
		--,c.doc_type
		,c.ref_id
		--,c.buyr_nm
		,c.a_doc_id
	--,c.b_doc_type
	--,c.property_id_sequence_number
	--,c.reprocess_flag
	--,c.Instrument_nbr
	FROM (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY a.doc_id
				,b.doc_id ORDER BY a.buyr_nm
				) AS _merge --
			,b.ROW4 --
			,b.doc_id --
			,b.ur_matrix --
			,b.m_status_id --
			,b.fips_code --
			,b.recording_date_d
			,b.doc_type
			,b.ref_id --
			,b.buyr_nm
			,a.doc_id AS a_doc_id
			,a.doc_type AS a_doc_type
			,b.property_id_sequence_number
			,b.reprocess_flag
			,b.Instrument_nbr
		-- select  format(count(*), '##,##0') as cnt
		FROM [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] a WITH (INDEX (idx_doc_id))
		INNER JOIN [LIEN_DTDB].[tmp].[reprocess_records_to_be_processed] k WITH (
				NOLOCK
				,INDEX (idx)
				) ON k.doc_id = a.doc_id
		OUTER APPLY (
			SELECT *
			FROM [lien_dtdb].[tmp].[S6_Merge_ref_ids_name_fix] b WITH (INDEX (idx))
			WHERE b.fips_code = a.fips_code
				AND b.ref_id = a.ref_id
				AND (
					(
						b.recording_date_d BETWEEN a.recording_date_d
							AND Dateadd(day, 5, a.recording_date_d)
						)
					OR (
						a.recording_date_d BETWEEN b.recording_date_d
							AND Dateadd(day, 5, b.recording_date_d)
						)
					)
				AND b.buyr_nm = a.buyr_nm
				AND b.doc_id <> a.doc_id
			) b
		WHERE b.doc_id IS NOT NULL
		) c
	WHERE c._merge = 1

	CREATE INDEX idx_doc_id ON [lien_dtdb].[tmp].[S6_Merge_ref_ids_merge_results_fix] (doc_id)

	INSERT INTO [lien_dtdb].[tmp].[reprocess_records_to_be_processed] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,[previous_doc_unique_id]
		,[update_type]
		,[doc_title]
		,[doc_type]
		)
	SELECT d.doc_id
		,d.m_update_date AS m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.[previous_doc_unique_id]
		,d.[update_type]
		,d.[doc_title]
		,d.[doc_type]
	FROM [lien].[ur].[document] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	LEFT JOIN [lien_dtdb].[tmp].[reprocess_records_to_be_processed] a WITH (
			NOLOCK
			,INDEX (idx)
			) ON a.doc_id = d.doc_id
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM [lien_dtdb].[tmp].[S6_Merge_ref_ids_merge_results_fix]
			)
		AND d.m_status_id < 3
		AND a.doc_id IS NULL
	AND d.source IN (
			'EPR'
			,'REDX'
			)

	DROP TABLE

	IF EXISTS #doc_id2
		SELECT DISTINCT a.doc_id
		INTO #doc_id2
		FROM (
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg1_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg1_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg2_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg2_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg3_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg3_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			
			UNION ALL
			
			SELECT d1.*
			FROM [deed].[dbo].[deed] d WITH (
					NOLOCK
					,INDEX (idx_mtg4_ur_doc_id)
					)
			OUTER APPLY (
				SELECT ur_doc_id AS doc_id
				
				UNION ALL
				
				SELECT mtg1_ur_doc_id AS mtg1_ur_doc_id
				
				UNION ALL
				
				SELECT mtg2_ur_doc_id AS mtg2_ur_doc_id
				
				UNION ALL
				
				SELECT mtg3_ur_doc_id AS mtg3_ur_doc_id
				
				UNION ALL
				
				SELECT mtg4_ur_doc_id AS mtg4_ur_doc_id
				) d1
			WHERE d.mtg4_ur_doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed]
					)
				AND d1.doc_id IS NOT NULL
			) a

	INSERT INTO [lien_dtdb].[tmp].[reprocess_records_to_be_processed] (
		[doc_id]
		,[m_update_date]
		,[fips_code]
		,[Fips]
		,[Instrument_nbr]
		,[recording_date_d]
		,[m_status_id]
		,[reprocess_flag]
		,[ur_matrix]
		,[previous_doc_unique_id]
		,[update_type]
		,[doc_title]
		,[doc_type]
		)
	SELECT d.doc_id
		,d.m_update_date AS m_update_date
		,d.fips_code
		,try_cast(d.Fips_code AS INT) AS Fips
		,d.Instrument_nbr
		,d.recording_date_d
		,d.m_status_id
		,isnull(d.reprocess_flag, '') AS reprocess_flag
		,d.[ur_matrix]
		,d.[previous_doc_unique_id]
		,d.[update_type]
		,d.[doc_title]
		,d.[doc_type]
	FROM [lien].[ur].[DOCUMENT] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			)
	LEFT JOIN [lien_dtdb].[tmp].[reprocess_records_to_be_processed] b WITH (
			NOLOCK
			,INDEX (idx)
			) ON b.doc_id = d.doc_id
	WHERE d.doc_id IN (
			SELECT doc_id
			FROM #doc_id2
			)
		AND b.doc_id IS NULL
		AND d.m_status_id = 1
	AND d.source IN (
			'EPR'
			,'REDX'
			)

	EXEC [lien_DTDB].[INFC].[AddinfcLog] N'info'
		,N'usp_get_Related_Docids'
		,N'Ended'
END TRY

BEGIN CATCH
	--SET @ERROR = ERROR_MESSAGE() + CHAR(10) + 'in Paul_2 - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--SELECT @ERROR AS N'@ERROR'
	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


