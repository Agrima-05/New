SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_100A_GET_HOA_LIEN]

AS
BEGIN

	SET NOCOUNT ON;

	Update [HOA].[dbo].[HOA_LIEN]
	Set Identifier = DocumentId
	where REF_ID = '63913184'
	and IDentifier is null
	
	--Select * From dbo.HOA_LIEN_DATA

	------PULL ACTIVE HOA LIEN RECORDS-----IF multiple records per lien due to owners - pull only 1 owner per NH 20180322---
	 DROP TABLE dbo.HOA_LIEN_DATA

	 Select A.*,C.INPUTKEY ,NULL as [SUP]
	 into [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA]
	 --,C.[LOOKBACKDATE],(convert(DATE,convert(varchar(10),A.RecordingDate))),convert(date,C.[LOOKBACKDATE])
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ServiceMac].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 --on A.NEW_REF_ID = B.REF_ID
	  on A.REF_ID = B.REF_ID
	 --join INPUT_IN as C on B.RAW_ID = C.INPUTKEY
	 join [zCust_ServiceMac].[dbo].[x_custom_OUTPUT_S33] as C on B.RAW_ID = C.INPUTKEY

	 --------20191113 - Changed to look at new HOA Lien Doc Type Table per MS---
	  --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D on A.DocType = D.[HOA_Doc_Type]
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D with(NOLOCK) on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 where B.REF_ID is not null
	 AND D.HOA_Data_Type in ( 'Lien','len')
	 ---------Added 20181217 to remove notice of Lis Pendens...--------
	 -----20191113 - Lis Pendens are to be included for Proctor per NH / MS----
	 --AND D.HOA_DOC_TYPE not in ( 'HALP','f7')
	 and A.[IsHoaLienActive] = 1
	 AND OWNSequence = 1
	 and 
	 --(convert(DATE,convert(varchar(10),A.RecordingDate)) >= convert(date,C.CurrSaleRecordingDate)
	 --OR C.CurrSaleRecordingDate is null)
	 (convert(DATE,convert(varchar(10),A.RecordingDate)) > convert(date,C.[MAX_LIENDATE])
	 OR C.[MAX_LIENDATE] is null)
	--------------------ADDED 20180713 per Nicole - do not want liens for prior owners - even if they are marked as Active in the LIEN table-------------

	----------------------REMOVED 20180810 Per Annette..shouldn't be doing name matching----------------------------------------- 

	 --AND (Case when C.INPUTBORROWER is not null and C.INPUTBORROWER not like '' then C.INPUTBORROWER else C.OWNERSTDNAME1FULL end) like '%' + A.OWNLastName + '%'
	 --and A.OWNLastName is not null and A.OWNLastName not like ''
	 

	 --Select top 10 * From [HOA].[dbo].[HOA_Lien] with(NOLOCK)

	 --Select * From x_custom_OUTPUT_S33

	 --Select DocType, count(*) From HOA_LIEN_DATA
	 --Group by DocType
	 --Order by DocType



	 --Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.088999', '2018.088999','CDLN','20180905','2018-09-05','4898.46','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1','DC1123',UPPER('Belton at Deanwood Condominium')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC1123'


	 --  Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.112552', '2018.112552','CDLN','20181109','2018-11-09','3841.26','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('McLean Gardens Condominium')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC418'


	 --  Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.90899', '2018.90899','CDLN','20180910','2018-09-05','8209.09','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1','DC143',UPPER('Parkside Townhomes, A Condominium')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC143'


	 --    Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1005.2232', '2018.1005.2232','HALN','20181005','2018-10-05','8726.51','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1','NV12495',UPPER('Fifth and Farm Community Association')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV12495'


	 --    Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1003.1807', '2018.1003.1807','HALN','20181003','2018-10-03','1448.98','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('West Sahara Community Association')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV2951'


	    
	 --    Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.103902', '2018.103902','CDLN','20181016','2018-10-16','8120.28','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('The Renaissance Condominium')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC522'


	 --      Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1012.108', '2018.1012.108','HALN','20181012','2018-10-12','2652.49','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('STONE CANYON WEST HOMEOWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV6625'


	 --       Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1012.1256', '2018.1012.1256','HALN','20181012','2018-10-12','4916.98','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('CALABRIA HOMEOWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV6711'


	   
	 --    Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.105736', '2018.105736','CDLN','20181022','2018-10-22','13765.39','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('BROOKLAND CONDOMINIUM ASSOCIATION INC')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC1017'

	 --   Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.103902', '2018.103902','CDLN','20181016','2018-10-16','8120.28','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('THE RENAISSANCE CONDOMINIUM')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'DC522'


	 --       Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --         ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1018.394', '2018.1018.394','HALN','20181018','2018-10-18','882.00','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('MOUNTAINS EDGE MASTER ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV7627'


	 -- Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --    ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1023.1350', '2018.1023.1350','HALN','20181023','2018-10-23','1186.56','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('ELAN OWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV18437'


	 --   Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --    ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1023.1305', '2018.1023.1305','HALN','20181023','2018-10-23','1360.88','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('VILLAS AT HUNTINGTON HOMEOWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV4929'


	 -- Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --    ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1023.1128', '2018.1023.1128','HALN','20181023','2018-10-23','1136.96','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('CAMBRIDGE HOMEOWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV4613'


	 --   Insert into HOA_LIEN_DATA([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]        ,[DocumentId]       ,[DocType]      ,[RecordingDate]     
  --    ,[LienDate]      ,[LienAmount],CMTID,Sequence,BatchDate,OWNSequence,SourceCreatedDate,IsHoaLienActive,Inputkey,HOANAME)
	 -- Select 
	 -- PropertyID, FIPS, REF_ID, PropertyID, '2018.1109.1397', '2018.1109.1397','HALN','20181109','2018-11-09','1847.41','1','1',convert(date,Getdate()),'1',convert(date,Getdate())
	 -- ,'1',INPUTKEY,UPPER('PALM HILLS HOMEOWNERS ASSOCIATION')
	 -- From INput_MONITOR
	 -- where INPUTKEY = 'NV1305'



	  --Select * From INput_MONITOR
	  --where INPUTKEY = 'NV7627'

	  -- Select * From INput_MONITOR
	  -- where INPUTADDRESS like '2125%Suit%'

	  -- Select * From Assr.dbo.Assr with(NOLOCK)
	  -- where REF_ID = '24479239'
	  -- OR LIC_PropertyID = '26734724'

	  -- Select FIPS, PropertyID, SItusSTDFullSTreetAddress From data.dbo.Property with(NOLOCK)
	  -- where PropertyID = '26734724'


	      

	  --Select * From HOA_LIEN_DATA

	  --Select * From [HOA_LIEN_DOC_TYPES_20180705]
	  --where Full_Name like '%sale%'



	 -----------------Added 20180713 to REMOVE RELEASED LIENS still marked as ACTIVE in the HOA Lien table----------
	Delete from [zCust_ServiceMac].[dbo].[A]
	--Select A.DocType, A.DocumentId,A.IsHoaLienActive, B.* 
	From [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] as A join 
	(Select REF_ID,DocumentId,OAReference,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] with(NOLOCK))
	----Changed 20191113 to use new doc type table---
	---and DocType like 'halnrl')
	And DocType in (Select DocType from [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] with(NOLOCK)  where  HOA_Data_Type in ( 'release')))
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReference,'.',''),' ',''),'-','')







	Delete from [zCust_ServiceMac].[dbo].[A]
	--Select A.DocType, A.DocumentId,A.IsHoaLienActive, B.* 
	From [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] as A join 
	(Select REF_ID,DocumentId,OAReferencealt,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] with(NOLOCK))
	----Changed 20191113 to use new doc type table---
	---and DocType like 'halnrl')
	And DocType in (Select DocType from [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] with(NOLOCK)  where  HOA_Data_Type in ( 'release')))
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReferencealt,'.',''),' ',''),'-','')
	--where B.DocType like 'halnrl'

	--Select top 10 * From  [HOA].[dbo].[HOA_Lien] with(NOLOCK)

	-------ADded 20180727 to look for decoded string in doc type----
	Delete from [zCust_ServiceMac].[dbo].[A]
	--Select * 
	From [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] as A join 
	(Select REF_ID,DocumentId,OAReference,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] with(NOLOCK))
	and 
		(
		(DocType like '%Release%' and DocType like '%Association%') OR 
		(DocType like '%Recission%' and DocType like '%Association%')
		)
		)
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReference,'.',''),' ',''),'-','')


	Delete from [zCust_ServiceMac].[dbo].[A]
	--Select * 
	From [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] as A join 
	(Select REF_ID,DocumentId,OAReferencealt,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	where REF_ID in (Select distinct REF_ID from [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] with(NOLOCK))
	and 
		(
		(DocType like '%Release%' and DocType like '%Association%') OR 
		(DocType like '%Recission%' and DocType like '%Association%')
		)
		)
	 B  on A.REF_ID = B.REF_ID
	AND REPLACE(REPLACE(REPLACE(A.DocumentId,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReferencealt,'.',''),' ',''),'-','')
	

	--Select * From x_custom_OUTPUT_S33 where WORK_REF_ID = '83136954'
	--Select FIPS, REF_ID, DocumentID,OAReferencealt,OAReference,DocType From HOA_LIEN_DATA
	--where REF_ID = '83136954'
	--Select FIPS, REF_ID, DocumentID,OAReferencealt,OAReference,DocType, * From HOA.dbo.HOA_LIEN
	--where REF_ID = '83136954'

	--Select DocType, count(*) From HOA.dbo.HOA_LIEN
	--Group by DocType

	--Select * From HOA_LIEN_DATA
	--Select REF_ID,DocumentId,OAReference,DocType From [HOA].[dbo].[HOA_Lien] with(NOLOCK)
	--where REF_ID in (Select distinct REF_ID from dbo.HOA_LIEN_DATA with(NOLOCK))
	--and DocType like 'halnrl'


	--Select * From HOA_LIEN_DATA
	--where REF_ID = '83286324'

	--Select * From [HOA].[dbo].[HOA_Lien]  B with(NOLOCK)
	--where REF_ID = '83286324'

	--Select * From x_custom_OUTPUT_S33
	--where WORK_REF_ID = '83286324'


	--Select top 10 * From HOA_LIEN_DATA
	--Select top 10 * From [HOA].[dbo].[HOA_Lien]
	--where REF_ID is not null


	--Select top 10 * From dbo.HOA_LIEN_DATA
	--where REF_ID = '26433136'


	--Insert into dbo.HOA_LIEN_DATA( ID
	--,[Fips]
 --     ,[REF_ID]
 --     ,[PKID]
 --     ,[Identifier]
 --     ,[CmtId]
 --     ,[DocumentId]
 --     ,[Sequence]
    
 --     ,[DocType]
 --     ,[State]
 --     ,[County]
 --     ,[RecordingDate]
    
     
     
 --     ,[LienAmount]
    
    
     
 --     ,[HOA_Trustee_Attorney Name]
 --     ,[HOA_Trustee_Attorney_Phone_Number]
 --     ,[LAWName]
 --     ,[LAWAddress]
 --     ,[LAWZip]
 --     ,[LAWCity]
 --     ,[LAWState]
 --     ,[LAWEmail]
 --     ,[LAWPhone]
 --     ,[LAWLastName]
 --     ,[LAWFirstName]
 --     ,[LAWMI]
 --     ,[LAWSfx]
 --     ,[OWNLastName]
 --     ,[OWNFirstName]
 --     ,[OWNMI]
 --     ,[OWNSfx]
 --     ,[OWNSpouseFirst]
 --     ,[OWNSpouseMiddle]
 --     ,[OWNSpouseFlag]
 --     ,[OWNSameAsProperty]
 --     ,[OWNAddress]
 --     ,[OWNZip]
 --     ,[OWNCity]
 --     ,[OWNState]
 --     ,[OWNSequence]
 --     ,[PropAPN]
 --     ,[PropAddress]
 --     ,[PropZip]
 --     ,[PropCity]
 --     ,[PropState]
 --     ,[PropSequence]
 --     ,[OAReference]
 --     ,[OAReferenceAlt]
 --     ,[ReferenceBook]
 --     ,[ReferencePage]
 --     ,[ReferenceYear]
 --     ,[ReferenceDocNo]
 --     ,[ReferenceRecordingDate]
     
 --     ,[HOAName]
 --     ,[HOAAddress]
 --     ,[HOAZip]
 --     ,[HOACity]
 --     ,[HOAState]
 --     ,[HOAEmail]
 --     ,[HOAPhone]
 --     ,[HOAContact]
     
    
 --     ,[IsHoaLienActive]
     
 --     ,[INPUTKEY]
	--  ,BatchDate
	--  ,SourceCreatedDate)
	--  Select  
	--  ID + 10
	--  , [Fips]
 --     ,[REF_ID]
 --     ,[PKID]
 --     ,'2018.78360'
 --     ,[CmtId]
 --     ,'2018.78360'
 --     ,[Sequence]
    
 --     ,[DocType]
 --     ,[State]
 --     ,[County]
 --     ,'20180807' as [RecordingDate]
     
    
 --     ,'3879.00' as [LienAmount]
  
    
 --     ,[HOA_Trustee_Attorney Name]
 --     ,[HOA_Trustee_Attorney_Phone_Number]
 --     ,[LAWName]
 --     ,[LAWAddress]
 --     ,[LAWZip]
 --     ,[LAWCity]
 --     ,[LAWState]
 --     ,[LAWEmail]
 --     ,[LAWPhone]
 --     ,[LAWLastName]
 --     ,[LAWFirstName]
 --     ,[LAWMI]
 --     ,[LAWSfx]
 --     ,[OWNLastName]
 --     ,[OWNFirstName]
 --     ,[OWNMI]
 --     ,[OWNSfx]
 --     ,[OWNSpouseFirst]
 --     ,[OWNSpouseMiddle]
 --     ,[OWNSpouseFlag]
 --     ,[OWNSameAsProperty]
 --     ,[OWNAddress]
 --     ,[OWNZip]
 --     ,[OWNCity]
 --     ,[OWNState]
 --     ,[OWNSequence]
 --     ,[PropAPN]
 --     ,[PropAddress]
 --     ,[PropZip]
 --     ,[PropCity]
 --     ,[PropState]
 --     ,[PropSequence]
 --     ,[OAReference]
 --     ,[OAReferenceAlt]
 --     ,[ReferenceBook]
 --     ,[ReferencePage]
 --     ,[ReferenceYear]
 --     ,[ReferenceDocNo]
 --     ,[ReferenceRecordingDate]
     
 --     ,[HOAName]
 --     ,[HOAAddress]
 --     ,[HOAZip]
 --     ,[HOACity]
 --     ,[HOAState]
 --     ,[HOAEmail]
 --     ,[HOAPhone]
 --     ,[HOAContact]
    
    
 --     ,[IsHoaLienActive]
    
 --     ,[INPUTKEY]
 --    ,convert(date,Getdate())
	--   ,convert(date,Getdate())
	-- From HOA_LIEN_DATA
	-- where INPUTKEY = 'DC1009'


	-------------Per MS - 20181206 - Any Lien anounts > 100K - divide by 100--------
	Update [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA]
	Set LienAmount = convert(numeric(20,2),LienAmount/100)
	--Select LienAmount , convert(numeric(20,2),LienAmount/100)
	From [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA]
	where  convert(bigint,LienAmount) > 100000



	 ALTER TABLE dbo.HOA_LIEN_DATA ADD [RecordNumber][int]NULL


	 UPDATE [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_ServiceMac].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY RecordingDate DESC)  AS RowNum
			FROM 
		[zCust_ServiceMac].[dbo].[HOA_LIEN_DATA] t  ) r ON t.REF_ID = r.REF_ID and t.PKID = r.PKID and t.INPUTKEY = r.INPUTKEY


	--Select REF_ID, PKID, RecordNumber From dbo.HOA_LIEN_DATA
	--Order by REF_ID,RecordNumber


	 --Select sum(case when REF_ID is not null then 1 else 0 end) as REF_ID_POP
	 --,sum(case when REF_ID is  null then 1 else 0 end) as REF_ID_NOT_POP
	 -- From a_PropMatch_WORK_FLANK

	 --Select * From HOA_LIEN_DATA

			
			


END





