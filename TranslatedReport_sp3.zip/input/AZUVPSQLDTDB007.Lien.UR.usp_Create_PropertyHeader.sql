/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.usp_Create_PropertyHeader | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- ================================= ============ 
-- Author:        <Author,,Name>
-- Create date: <Create Date,,> 
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- ============================================= 
CREATE PROCEDURE [Lien].[UR].[usp_Create_PropertyHeader]
AS
/******************************************************************************************************************
CHANGE LOG: 
==========
who		date		change
paul	2022-03-11  Update County name on Document when fips changed
Marie	2023-02-13	Add call to Lien.UR.usp_Lien_Post_Capture_Processing in order to populate the ORIG_MTG_LENDER_NAME
                    in the Lien.UR.Name table 
Marie	2023-04-11  Add call to Lien.UR.usp_Lien_Post_Capture_NMLS To Standardize NMLS information


******************************************************************************************************************/
--
-- Populate ORIG_MTG_LENDER_NAME on the Lien.UR.Name for the daily doc_id's
--
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_Create_PropertyHeader'
	,N'Started'

DECLARE @ERROR VARCHAR(500)
DECLARE @date_1 DATETIME2 = (
		SELECT max(m_update_date)
		FROM [lien].[UR].[document_transaction_log_tracker]
		WHERE INFC_Extract_date IS NOT NULL
		)
DECLARE @m_create_date DATETIME2

SET @m_create_date = dateadd(hour, - 1, (
			SELECT TOP 1 m_create_date
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (IX_CREATED_DATE)
					)
			ORDER BY m_create_date DESC
			))

--SELECT @date
--
--find all the doc_id that had a change since the last update ran
--
DROP TABLE

IF EXISTS [lien].[tmp].[usp_Create_PropertyHeader_doc_ids]
	SELECT DISTINCT doc_id
	INTO [lien].[tmp].[usp_Create_PropertyHeader_doc_ids]
	FROM (
		SELECT a.doc_id
		FROM (
			SELECT l.Doc_id
			FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
			--where l.doc_id in (147093623,207319327) 
			WHERE l.m_update_date > isnull(@date_1, '19000101')
			
			UNION ALL
			
			SELECT n.Doc_id
			FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
			INNER JOIN [lien].[ur].[NAME] n WITH (INDEX (PK_NAME)) ON n.name_id = l.name_id
			--where l.doc_id in (147093623,207319327) 
			WHERE l.m_update_date > isnull(@date_1, '19000101')
				AND l.Name_id IS NOT NULL
			
			UNION ALL
			
			SELECT n.Doc_id
			FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
			INNER JOIN [lien].[ur].[Property] n WITH (INDEX (PK_PROPERTY)) ON n.Property_id = l.Property_id
			WHERE l.m_update_date > isnull(@date_1, '19000101')
				AND l.Property_id IS NOT NULL
			
			UNION ALL
			
			SELECT n.Doc_id
			FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
			INNER JOIN [lien].[ur].[Reference] n WITH (INDEX (PK_REFERENCE)) ON n.Reference_id = l.Reference_id
			WHERE l.m_update_date > isnull(@date_1, '19000101')
				AND l.Reference_id IS NOT NULL
			
			UNION ALL
			
			SELECT doc_id
			FROM [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (IX_CREATED_DATE)
					)
			WHERE d.m_create_date > @m_create_date
			) a
		WHERE doc_id IS NOT NULL
		) b
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_doc_id]
	SELECT DISTINCT doc_id
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_doc_id]
	FROM [Lien].[UR].[PROPERTY] p WITH (
			NOLOCK
			,INDEX (ix_Doc_idSeq) --(idx_Easement_portion)
			)
	WHERE p.doc_id IN (
			SELECT doc_id
			FROM [lien].[tmp].[usp_Create_PropertyHeader_doc_ids]
			)
		AND p.legal_desc_easement_flag IS NULL
		AND isnull(p.legal_desc_apn_portion, '') NOT IN (
			'Y'
			,'PT'
			)
		AND isnull(p.legal_desc_property_questionable_indicator, '') = ''

CREATE INDEX idx_doc_id ON [Lien].[tmp].[usp_Create_PropertyHeader_doc_id] (doc_id)

-- select  format(count(*), '##,##0') as cnt from Lien.tmp.usp_Create_PropertyHeader_doc_id
-- for the doc_ids identified above, determine which doc_id dont have a PropertyHeader
--   since we only create propertyheaders when not present
--
DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_temp]
	SELECT p.doc_id
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_temp]
	FROM [Lien].[tmp].[usp_Create_PropertyHeader_doc_id] p WITH (
			NOLOCK
			,INDEX (idx_doc_id)
			)
	OUTER APPLY (
		SELECT count(1) AS cnt
		FROM [Lien].[UR].[PROPERTYHeader] h WITH (
				NOLOCK
				,INDEX (ix_doc_id)
				)
		WHERE h.doc_id = p.doc_id
		) h
	WHERE h.cnt = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		)

CREATE INDEX idx ON [Lien].[tmp].[usp_Create_PropertyHeader_temp] (doc_id)

DECLARE @create_date DATETIME = getdate()

DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_prop1];
	SELECT a.[doc_id]
		,ROW_NUMBER() OVER (
			PARTITION BY a.[doc_id] ORDER BY (
					SELECT 0
					)
			) AS [property_id_sequence_number]
		,[legal_desc_abstract_portion]
		,[legal_desc_abstract_acreage]
		,[legal_desc_abstract_name]
		,[legal_desc_abstract_number]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[legal_desc_address_zip]
		,[legal_desc_apn_portion]
		,[legal_desc_apn]
		,[legal_desc_apn_split]
		,[legal_desc_apn_arb]
		,[legal_desc_apn_alternate]
		,[legal_desc_map_portion]
		,[legal_desc_map_unit_low]
		,_unit
		,[legal_desc_map_unit_high]
		,[legal_desc_map_lot_type]
		,[legal_desc_map_lot_type_low]
		,[legal_desc_map_lot_type_high]
		,[legal_desc_map_lot_low]
		,_lot
		,[legal_desc_map_lot_high]
		,[legal_desc_map_block]
		,[legal_desc_map_building]
		,[legal_desc_map_sublot]
		,[legal_desc_map_plat_subcode]
		,[legal_desc_map_plat_name]
		,[legal_desc_map_plat_number]
		,[legal_desc_map_plat_condo_id]
		,[legal_desc_map_plat_type_indicator]
		,[legal_desc_map_plat_book]
		,[legal_desc_map_plat_page]
		,[legal_desc_mine_mining_claim_lode]
		,[legal_desc_mine_mining_district]
		,[legal_desc_mine_mining_survey]
		,[legal_desc_rancho_portion]
		,[legal_desc_rancho_name_number]
		,[legal_desc_str_portion]
		,[legal_desc_str_government_lot]
		,[legal_desc_str_quarter]
		,[legal_desc_str_section]
		,[legal_desc_str_township]
		,[legal_desc_str_range]
		,[legal_desc_tct]
		,[legal_desc_timeshare_name]
		,[legal_desc_timeshare_inventory_control_number]
		,[legal_desc_timeshare_unit]
		,[legal_desc_timeshare_week]
		,[legal_desc_timeshare_season]
		,[legal_desc_timeshare_type]
		,[legal_desc_timeshare_map_plat_lot]
		,[legal_desc_timeshare_map_plat_block]
		,[legal_desc_timeshare_map_plat_id]
		,[legal_desc_timeshare_map_plat_type_indicator]
		,[legal_desc_timeshare_map_plat_book]
		,[legal_desc_timeshare_map_plat_page]
		,[legal_desc_district]
		,[legal_desc_municipality]
		,[legal_desc_swiss_code]
		,[legal_desc_project_name]
		,[legal_desc_easement_flag]
		,[legal_desc_easement_type]
		,[legal_desc_unincorporated_property_flag]
		,[legal_desc_property_questionable_indicator]
		,[legal_desc_timeshare_year_type]
		,[legal_desc_arb_portion]
		,[batch]
		,[bucket]
		--
		,[pa_fips]
		,[pa_ref_id]
		,[pa_Match_code]
		,[ps_Fips]
		,[ps_Ref_id]
		,[ps_Match_code]
		,[ps_Apn]
		,[HouseNumber]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STATE]
		,[Zip]
		,[Plus4]
		,[CRRT]
		,[CountyName]
		,[PMB]
		,[PMSA]
		,[MSA]
		,[ZipType]
		,[Urbanization]
		,[CongressionalDistrict]
		,[CountryCode]
		,[CityAbbreviation]
		,[AddressTypeCode]
		,[AddressTypeString]
		,[DPV_Count]
		,[DPV_Footnotes]
		,[CMRA]
		,[ELOT_Number]
		,[ELOT_Order]
		,[LACS]
		,[LACS_LinkIndicator]
		,[EWS_Flag]
		,[RBDI]
		,[SuiteLinkReturnCode]
		,[DeliveryPointCheckDigit]
		,[DeliveryPointCode]
		,[CensusBlock]
		,[CensusTract]
		,[PlaceCode]
		,[PlaceName]
		,[CBSACode]
		,[CBSALevel]
		,[CBSATitle]
		,[CBSADivisionCode]
		,[CBSADivisionLevel]
		,[CBSADivisionTitle]
		,[Latitude]
		,[Longitude]
		,[AddressMatchResults]
		,[GeoErrorCode]
		,[GeoStatusCode]
		,[AddressType]
		,NULL AS [UpdateDate]
		,legal_desc_qualifier
		,legal_desc_timeshare_phase
		,legal_desc_map_city_block
		,legal_desc_application_number
		,legal_desc_tax_assessor_portion
		,legal_desc_tax_assessor_lot
		,legal_desc_tax_assessor_block
		,legal_desc_tax_assessor_section
		,legal_desc_arb_alternate
		,@create_date AS m_create_date
		,[property_ref_id]
		,[legal_desc_timeshare_unit_high]
		,[legal_desc_timeshare_points]
		,[property_sequence_id]
		,[plat_name_lookup]
		,[property_ref_id_source]
		,[legal_desc_map_plat_year]
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_prop1]
	FROM (
		SELECT p.doc_id
			,p.legal_desc_address
			,p.legal_desc_apn
			--,_Legal_type 
			--,_Legal_Type_Sequence
			,max(p.legal_desc_abstract_portion) AS legal_desc_abstract_portion
			,max(p.legal_desc_abstract_acreage) AS legal_desc_abstract_acreage
			,max(p.legal_desc_abstract_name) AS legal_desc_abstract_name
			,max(p.legal_desc_abstract_number) AS legal_desc_abstract_number
			--,max(p.legal_desc_address) AS legal_desc_address
			,max(p.legal_desc_address_city) AS legal_desc_address_city
			,max(p.legal_desc_address_state) AS legal_desc_address_state
			,max(p.legal_desc_address_zip) AS legal_desc_address_zip
			,max(p.legal_desc_apn_portion) AS legal_desc_apn_portion
			--,max(p.legal_desc_apn) AS legal_desc_apn
			,max(p.legal_desc_apn_split) AS legal_desc_apn_split
			,max(p.legal_desc_apn_arb) AS legal_desc_apn_arb
			,max(p.legal_desc_apn_alternate) AS legal_desc_apn_alternate
			,max(p.legal_desc_map_portion) AS legal_desc_map_portion
			,max(p.legal_desc_map_unit_low) AS legal_desc_map_unit_low
			,max(substring(ll._new_u, 1, 200)) AS _unit
			,max(p.legal_desc_map_unit_high) AS legal_desc_map_unit_high
			,max(p.legal_desc_map_lot_type) AS legal_desc_map_lot_type
			,max(p.legal_desc_map_lot_type_low) AS legal_desc_map_lot_type_low
			,max(p.legal_desc_map_lot_type_high) AS legal_desc_map_lot_type_high
			,max(p.legal_desc_map_lot_low) AS legal_desc_map_lot_low
			,max(substring(ll._new_l, 1, 200)) AS _lot
			,max(p.legal_desc_map_lot_high) AS legal_desc_map_lot_high
			,max(p.legal_desc_map_block) AS legal_desc_map_block
			,max(p.legal_desc_map_building) AS legal_desc_map_building
			,max(p.legal_desc_map_sublot) AS legal_desc_map_sublot
			,max(p.legal_desc_map_plat_subcode) AS legal_desc_map_plat_subcode
			,max(p.legal_desc_map_plat_name) AS legal_desc_map_plat_name
			,max(p.legal_desc_map_plat_number) AS legal_desc_map_plat_number
			,max(p.legal_desc_map_plat_condo_id) AS legal_desc_map_plat_condo_id
			,max(p.legal_desc_map_plat_type_indicator) AS legal_desc_map_plat_type_indicator
			,max(p.legal_desc_map_plat_book) AS legal_desc_map_plat_book
			,max(p.legal_desc_map_plat_page) AS legal_desc_map_plat_page
			,max(p.legal_desc_mine_mining_claim_lode) AS legal_desc_mine_mining_claim_lode
			,max(p.legal_desc_mine_mining_district) AS legal_desc_mine_mining_district
			,max(p.legal_desc_mine_mining_survey) AS legal_desc_mine_mining_survey
			,max(p.legal_desc_rancho_portion) AS legal_desc_rancho_portion
			,max(p.legal_desc_rancho_name_number) AS legal_desc_rancho_name_number
			,max(p.legal_desc_str_portion) AS legal_desc_str_portion
			,max(p.legal_desc_str_government_lot) AS legal_desc_str_government_lot
			,max(p.legal_desc_str_quarter) AS legal_desc_str_quarter
			,max(p.legal_desc_str_section) AS legal_desc_str_section
			,max(p.legal_desc_str_township) AS legal_desc_str_township
			,max(p.legal_desc_str_range) AS legal_desc_str_range
			,max(p.legal_desc_tct) AS legal_desc_tct
			,max(p.legal_desc_timeshare_name) AS legal_desc_timeshare_name
			,max(p.legal_desc_timeshare_inventory_control_number) AS legal_desc_timeshare_inventory_control_number
			,max(p.legal_desc_timeshare_unit) AS legal_desc_timeshare_unit
			,max(p.legal_desc_timeshare_week) AS legal_desc_timeshare_week
			,max(p.legal_desc_timeshare_season) AS legal_desc_timeshare_season
			,max(p.legal_desc_timeshare_type) AS legal_desc_timeshare_type
			,max(p.legal_desc_timeshare_map_plat_lot) AS legal_desc_timeshare_map_plat_lot
			,max(p.legal_desc_timeshare_map_plat_block) AS legal_desc_timeshare_map_plat_block
			,max(p.legal_desc_timeshare_map_plat_id) AS legal_desc_timeshare_map_plat_id
			,max(p.legal_desc_timeshare_map_plat_type_indicator) AS legal_desc_timeshare_map_plat_type_indicator
			,max(p.legal_desc_timeshare_map_plat_book) AS legal_desc_timeshare_map_plat_book
			,max(p.legal_desc_timeshare_map_plat_page) AS legal_desc_timeshare_map_plat_page
			,max(p.legal_desc_district) AS legal_desc_district
			,max(p.legal_desc_municipality) AS legal_desc_municipality
			,max(p.legal_desc_swiss_code) AS legal_desc_swiss_code
			,max(p.legal_desc_project_name) AS legal_desc_project_name
			,max(p.legal_desc_easement_flag) AS legal_desc_easement_flag
			,max(p.legal_desc_easement_type) AS legal_desc_easement_type
			,max(p.legal_desc_unincorporated_property_flag) AS legal_desc_unincorporated_property_flag
			,max(p.legal_desc_property_questionable_indicator) AS legal_desc_property_questionable_indicator
			,max(p.legal_desc_timeshare_year_type) AS legal_desc_timeshare_year_type
			,max(p.legal_desc_arb_portion) AS legal_desc_arb_portion
			,max(p.batch) AS batch
			,max(p.bucket) AS bucket
			,max(pa.Fips) AS pa_fips
			,max(pa.Ref_id) AS pa_ref_id
			,max(pa.Match_code) AS pa_Match_code
			,max(ps.Fips) AS ps_Fips
			,max(ps.Ref_id) AS ps_Ref_id
			,max(ps.Match_code) AS ps_Match_code
			,max(ps.Apn) AS ps_Apn
			,max(ps.HouseNumber) AS HouseNumber
			,max(ps.Street_Number) AS Street_Number
			,max(ps.Direction) AS Direction
			,max(ps.Street_Name) AS Street_Name
			,max(ps.Street_Type) AS Street_Type
			,max(ps.Post_Direction) AS Post_Direction
			,max(ps.Unit_Type) AS Unit_Type
			,max(ps.Unit) AS Unit
			,max(ps.City) AS City
			,max(ps.STATE) AS STATE
			,max(ps.Zip) AS Zip
			,max(ps.Plus4) AS Plus4
			,max(ps.CRRT) AS CRRT
			,max(ps.CountyName) AS CountyName
			,max(ps.PMB) AS PMB
			,max(ps.PMSA) AS PMSA
			,max(ps.MSA) AS MSA
			,max(ps.ZipType) AS ZipType
			,max(ps.Urbanization) AS Urbanization
			,max(ps.CongressionalDistrict) AS CongressionalDistrict
			,max(ps.CountryCode) AS CountryCode
			,max(ps.CityAbbreviation) AS CityAbbreviation
			,max(ps.AddressTypeCode) AS AddressTypeCode
			,max(ps.AddressTypeString) AS AddressTypeString
			,max(ps.DPV_Count) AS DPV_Count
			,max(ps.DPV_Footnotes) AS DPV_Footnotes
			,max(ps.CMRA) AS CMRA
			,max(ps.ELOT_Number) AS ELOT_Number
			,max(ps.ELOT_Order) AS ELOT_Order
			,max(ps.LACS) AS LACS
			,max(ps.LACS_LinkIndicator) AS LACS_LinkIndicator
			,max(ps.EWS_Flag) AS EWS_Flag
			,max(ps.RBDI) AS RBDI
			,max(ps.SuiteLinkReturnCode) AS SuiteLinkReturnCode
			,max(ps.DeliveryPointCheckDigit) AS DeliveryPointCheckDigit
			,max(ps.DeliveryPointCode) AS DeliveryPointCode
			,max(ps.CensusBlock) AS CensusBlock
			,max(ps.CensusTract) AS CensusTract
			,max(ps.PlaceCode) AS PlaceCode
			,max(ps.PlaceName) AS PlaceName
			,max(ps.CBSACode) AS CBSACode
			,max(ps.CBSALevel) AS CBSALevel
			,max(ps.CBSATitle) AS CBSATitle
			,max(ps.CBSADivisionCode) AS CBSADivisionCode
			,max(ps.CBSADivisionLevel) AS CBSADivisionLevel
			,max(ps.CBSADivisionTitle) AS CBSADivisionTitle
			,max(ps.Latitude) AS Latitude
			,max(ps.Longitude) AS Longitude
			--,max(caseps.Verified) AS Verified
			--,max(ps.Geocoded) AS Geocoded
			,max(ps.AddressMatchResults) AS AddressMatchResults
			,max(ps.GeoErrorCode) AS GeoErrorCode
			,max(ps.GeoStatusCode) AS GeoStatusCode
			,max(ps.AddressType) AS AddressType
			--,max(ps.UpdateDate) AS UpdateDate
			--,max(CASE 
			--		WHEN ps.UpdateDate  > pA.Updated
			--			THEN ps.UpdateDate
			--		ELSE pA.Updated
			--		END) AS UpdateDate
			,max(property_sequence) AS property_sequence
			,max(legal_desc_qualifier) AS legal_desc_qualifier
			,max(legal_desc_timeshare_phase) AS legal_desc_timeshare_phase
			,max(legal_desc_map_city_block) AS legal_desc_map_city_block
			,max(legal_desc_application_number) AS legal_desc_application_number
			,max(legal_desc_tax_assessor_portion) AS legal_desc_tax_assessor_portion
			,max(legal_desc_tax_assessor_lot) AS legal_desc_tax_assessor_lot
			,max(legal_desc_tax_assessor_block) AS legal_desc_tax_assessor_block
			,max(legal_desc_tax_assessor_section) AS legal_desc_tax_assessor_section
			,max(legal_desc_arb_alternate) AS legal_desc_arb_alternate
			,max(property_ref_id) AS property_ref_id
			,max(legal_desc_timeshare_unit_high) AS legal_desc_timeshare_unit_high
			,max(legal_desc_timeshare_points) AS legal_desc_timeshare_points
			,max(property_sequence_id) AS property_sequence_id
			,max(plat_name_lookup) AS plat_name_lookup
			,max(property_ref_id_source) AS property_ref_id_source
			,max(legal_desc_map_plat_year) AS legal_desc_map_plat_year
		FROM [Lien].[tmp].[usp_Create_PropertyHeader_temp] t
		INNER JOIN [Lien].[UR].[PROPERTY] p WITH (
				NOLOCK
				,INDEX (ix_Doc_idSeq)
				) ON p.doc_id = t.doc_id
		LEFT JOIN [Lien].[UR].[PROPERTY_APN_MATCH] pa WITH (
				NOLOCK
				,INDEX (ix_propid_Ref_Code_apn)
				) ON pa.property_id = p.property_id
		LEFT JOIN [Lien].[UR].[PROPERTY_Std_Address] ps WITH (
				NOLOCK
				,INDEX (ix_PropIDREfidMatchCode)
				) ON ps.property_id = p.property_id
		OUTER APPLY (
			SELECT stuff((
						SELECT ',' + cast(CASE 
									WHEN pp.legal_desc_map_lot_high IS NOT NULL
										THEN pp.legal_desc_map_lot_low + '-' + pp.legal_desc_map_lot_high
									ELSE pp.legal_desc_map_lot_low
									END AS VARCHAR)
						FROM (
							SELECT DISTINCT legal_desc_map_lot_low
								,pp.legal_desc_map_lot_high
							FROM [Lien].[UR].[PROPERTY] pp WITH (
									NOLOCK
									,INDEX (ix_Doc_idSeq)
									)
							WHERE pp.doc_id = p.doc_id
								AND pp.property_id_sequence_number = p.property_id_sequence_number
							) pp
						ORDER BY pp.legal_desc_map_lot_low
						FOR XML PATH('')
						), 1, 1, '') AS _Lot
				,stuff((
						SELECT ',' + cast(CASE 
									WHEN pp.legal_desc_map_unit_high IS NOT NULL
										THEN pp.legal_desc_map_unit_low + '-' + pp.legal_desc_map_unit_high
									ELSE pp.legal_desc_map_unit_low
									END AS VARCHAR)
						FROM (
							SELECT DISTINCT pp.legal_desc_map_unit_low
								,pp.legal_desc_map_unit_high
							FROM [Lien].[UR].[PROPERTY] pp WITH (
									NOLOCK
									,INDEX (ix_Doc_idSeq)
									)
							WHERE pp.doc_id = p.doc_id
								AND pp.property_id_sequence_number = p.property_id_sequence_number
							) pp
						ORDER BY pp.legal_desc_map_unit_low
						FOR XML PATH('')
						), 1, 1, '') AS _UNit
			) AS stufff
		OUTER APPLY (
			SELECT [Lien].[dbo].[fn_FitLotUnit](stufff._Lot, 6) AS _new_l
				,[Lien].[dbo].[fn_FitLotUnit](stufff._unit, 8) AS _new_u
			) ll
		--AND p.legal_desc_apn = a.legal_desc_apn
		WHERE (
				p.legal_desc_address IS NOT NULL
				OR p.legal_desc_apn IS NOT NULL
				)
			AND p.legal_desc_easement_flag IS NULL
			AND isnull(p.legal_desc_apn_portion, '') NOT IN (
				'Y'
				,'PT'
				)
			AND isnull(p.legal_desc_property_questionable_indicator, '') = ''
		GROUP BY p.doc_id
			,p.legal_desc_address
			,p.legal_desc_apn
		) a
	ORDER BY a.doc_id

DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_prop2]
	SELECT a.[doc_id]
		--,[property_id_sequence_number]
		,ROW_NUMBER() OVER (
			PARTITION BY a.[doc_id] ORDER BY (
					SELECT 0
					)
			) AS [property_id_sequence_number]
		,[legal_desc_abstract_portion]
		,[legal_desc_abstract_acreage]
		,[legal_desc_abstract_name]
		,[legal_desc_abstract_number]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[legal_desc_address_zip]
		,[legal_desc_apn_portion]
		,[legal_desc_apn]
		,[legal_desc_apn_split]
		,[legal_desc_apn_arb]
		,[legal_desc_apn_alternate]
		,[legal_desc_map_portion]
		,[legal_desc_map_unit_low]
		,_unit
		,[legal_desc_map_unit_high]
		,[legal_desc_map_lot_type]
		,[legal_desc_map_lot_type_low]
		,[legal_desc_map_lot_type_high]
		,[legal_desc_map_lot_low]
		,_lot
		,[legal_desc_map_lot_high]
		,[legal_desc_map_block]
		,[legal_desc_map_building]
		,[legal_desc_map_sublot]
		,[legal_desc_map_plat_subcode]
		,[legal_desc_map_plat_name]
		,[legal_desc_map_plat_number]
		,[legal_desc_map_plat_condo_id]
		,[legal_desc_map_plat_type_indicator]
		,[legal_desc_map_plat_book]
		,[legal_desc_map_plat_page]
		,[legal_desc_mine_mining_claim_lode]
		,[legal_desc_mine_mining_district]
		,[legal_desc_mine_mining_survey]
		,[legal_desc_rancho_portion]
		,[legal_desc_rancho_name_number]
		,[legal_desc_str_portion]
		,[legal_desc_str_government_lot]
		,[legal_desc_str_quarter]
		,[legal_desc_str_section]
		,[legal_desc_str_township]
		,[legal_desc_str_range]
		,[legal_desc_tct]
		,[legal_desc_timeshare_name]
		,[legal_desc_timeshare_inventory_control_number]
		,[legal_desc_timeshare_unit]
		,[legal_desc_timeshare_week]
		,[legal_desc_timeshare_season]
		,[legal_desc_timeshare_type]
		,[legal_desc_timeshare_map_plat_lot]
		,[legal_desc_timeshare_map_plat_block]
		,[legal_desc_timeshare_map_plat_id]
		,[legal_desc_timeshare_map_plat_type_indicator]
		,[legal_desc_timeshare_map_plat_book]
		,[legal_desc_timeshare_map_plat_page]
		,[legal_desc_district]
		,[legal_desc_municipality]
		,[legal_desc_swiss_code]
		,[legal_desc_project_name]
		,[legal_desc_easement_flag]
		,[legal_desc_easement_type]
		,[legal_desc_unincorporated_property_flag]
		,[legal_desc_property_questionable_indicator]
		,[legal_desc_timeshare_year_type]
		,[legal_desc_arb_portion]
		,[batch]
		,[bucket]
		,[pa_fips]
		,[pa_ref_id]
		,[pa_Match_code]
		,[ps_Fips]
		,[ps_Ref_id]
		,[ps_Match_code]
		,[ps_Apn]
		,[HouseNumber]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STATE]
		,[Zip]
		,[Plus4]
		,[CRRT]
		,[CountyName]
		,[PMB]
		,[PMSA]
		,[MSA]
		,[ZipType]
		,[Urbanization]
		,[CongressionalDistrict]
		,[CountryCode]
		,[CityAbbreviation]
		,[AddressTypeCode]
		,[AddressTypeString]
		,[DPV_Count]
		,[DPV_Footnotes]
		,[CMRA]
		,[ELOT_Number]
		,[ELOT_Order]
		,[LACS]
		,[LACS_LinkIndicator]
		,[EWS_Flag]
		,[RBDI]
		,[SuiteLinkReturnCode]
		,[DeliveryPointCheckDigit]
		,[DeliveryPointCode]
		,[CensusBlock]
		,[CensusTract]
		,[PlaceCode]
		,[PlaceName]
		,[CBSACode]
		,[CBSALevel]
		,[CBSATitle]
		,[CBSADivisionCode]
		,[CBSADivisionLevel]
		,[CBSADivisionTitle]
		,[Latitude]
		,[Longitude]
		,[AddressMatchResults]
		,[GeoErrorCode]
		,[GeoStatusCode]
		,[AddressType]
		,NULL AS [UpdateDate]
		,legal_desc_qualifier
		,legal_desc_timeshare_phase
		,legal_desc_map_city_block
		,legal_desc_application_number
		,legal_desc_tax_assessor_portion
		,legal_desc_tax_assessor_lot
		,legal_desc_tax_assessor_block
		,legal_desc_tax_assessor_section
		,legal_desc_arb_alternate
		,@create_date AS [m_create_date]
		,[property_ref_id]
		,[legal_desc_timeshare_unit_high]
		,[legal_desc_timeshare_points]
		,[property_sequence_id]
		,[plat_name_lookup]
		,[property_ref_id_source]
		,[legal_desc_map_plat_year]
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_prop2]
	FROM (
		SELECT p.doc_id
			,cast(NULL AS VARCHAR(200)) AS legal_desc_address
			,cast(NULL AS VARCHAR(200)) AS legal_desc_apn
			,max(p.legal_desc_abstract_portion) AS legal_desc_abstract_portion
			,max(p.legal_desc_abstract_acreage) AS legal_desc_abstract_acreage
			,max(p.legal_desc_abstract_name) AS legal_desc_abstract_name
			,max(p.legal_desc_abstract_number) AS legal_desc_abstract_number
			,max(p.legal_desc_address_city) AS legal_desc_address_city
			,max(p.legal_desc_address_state) AS legal_desc_address_state
			,max(p.legal_desc_address_zip) AS legal_desc_address_zip
			,max(p.legal_desc_apn_portion) AS legal_desc_apn_portion
			,max(p.legal_desc_apn_split) AS legal_desc_apn_split
			,max(p.legal_desc_apn_arb) AS legal_desc_apn_arb
			,max(p.legal_desc_apn_alternate) AS legal_desc_apn_alternate
			,max(p.legal_desc_map_portion) AS legal_desc_map_portion
			,max(p.legal_desc_map_unit_low) AS legal_desc_map_unit_low
			,max(substring(ll._new_u, 1, 200)) AS _unit
			,max(p.legal_desc_map_unit_high) AS legal_desc_map_unit_high
			,max(p.legal_desc_map_lot_type) AS legal_desc_map_lot_type
			,max(p.legal_desc_map_lot_type_low) AS legal_desc_map_lot_type_low
			,max(p.legal_desc_map_lot_type_high) AS legal_desc_map_lot_type_high
			,max(p.legal_desc_map_lot_low) AS legal_desc_map_lot_low
			,max(substring(ll._new_l, 1, 200)) AS _lot
			,max(p.legal_desc_map_lot_high) AS legal_desc_map_lot_high
			,max(p.legal_desc_map_block) AS legal_desc_map_block
			,max(p.legal_desc_map_building) AS legal_desc_map_building
			,max(p.legal_desc_map_sublot) AS legal_desc_map_sublot
			,max(p.legal_desc_map_plat_subcode) AS legal_desc_map_plat_subcode
			,max(p.legal_desc_map_plat_name) AS legal_desc_map_plat_name
			,max(p.legal_desc_map_plat_number) AS legal_desc_map_plat_number
			,max(p.legal_desc_map_plat_condo_id) AS legal_desc_map_plat_condo_id
			,max(p.legal_desc_map_plat_type_indicator) AS legal_desc_map_plat_type_indicator
			,max(p.legal_desc_map_plat_book) AS legal_desc_map_plat_book
			,max(p.legal_desc_map_plat_page) AS legal_desc_map_plat_page
			,max(p.legal_desc_mine_mining_claim_lode) AS legal_desc_mine_mining_claim_lode
			,max(p.legal_desc_mine_mining_district) AS legal_desc_mine_mining_district
			,max(p.legal_desc_mine_mining_survey) AS legal_desc_mine_mining_survey
			,max(p.legal_desc_rancho_portion) AS legal_desc_rancho_portion
			,max(p.legal_desc_rancho_name_number) AS legal_desc_rancho_name_number
			,max(p.legal_desc_str_portion) AS legal_desc_str_portion
			,max(p.legal_desc_str_government_lot) AS legal_desc_str_government_lot
			,max(p.legal_desc_str_quarter) AS legal_desc_str_quarter
			,max(p.legal_desc_str_section) AS legal_desc_str_section
			,max(p.legal_desc_str_township) AS legal_desc_str_township
			,max(p.legal_desc_str_range) AS legal_desc_str_range
			,max(p.legal_desc_tct) AS legal_desc_tct
			,max(p.legal_desc_timeshare_name) AS legal_desc_timeshare_name
			,max(p.legal_desc_timeshare_inventory_control_number) AS legal_desc_timeshare_inventory_control_number
			,max(p.legal_desc_timeshare_unit) AS legal_desc_timeshare_unit
			,max(p.legal_desc_timeshare_week) AS legal_desc_timeshare_week
			,max(p.legal_desc_timeshare_season) AS legal_desc_timeshare_season
			,max(p.legal_desc_timeshare_type) AS legal_desc_timeshare_type
			,max(p.legal_desc_timeshare_map_plat_lot) AS legal_desc_timeshare_map_plat_lot
			,max(p.legal_desc_timeshare_map_plat_block) AS legal_desc_timeshare_map_plat_block
			,max(p.legal_desc_timeshare_map_plat_id) AS legal_desc_timeshare_map_plat_id
			,max(p.legal_desc_timeshare_map_plat_type_indicator) AS legal_desc_timeshare_map_plat_type_indicator
			,max(p.legal_desc_timeshare_map_plat_book) AS legal_desc_timeshare_map_plat_book
			,max(p.legal_desc_timeshare_map_plat_page) AS legal_desc_timeshare_map_plat_page
			,max(p.legal_desc_district) AS legal_desc_district
			,max(p.legal_desc_municipality) AS legal_desc_municipality
			,max(p.legal_desc_swiss_code) AS legal_desc_swiss_code
			,max(p.legal_desc_project_name) AS legal_desc_project_name
			,max(p.legal_desc_easement_flag) AS legal_desc_easement_flag
			,max(p.legal_desc_easement_type) AS legal_desc_easement_type
			,max(p.legal_desc_unincorporated_property_flag) AS legal_desc_unincorporated_property_flag
			,max(p.legal_desc_property_questionable_indicator) AS legal_desc_property_questionable_indicator
			,max(p.legal_desc_timeshare_year_type) AS legal_desc_timeshare_year_type
			,max(p.legal_desc_arb_portion) AS legal_desc_arb_portion
			,max(p.batch) AS batch
			,max(p.bucket) AS bucket
			,max(pa.Fips) AS pa_fips
			,max(pa.Ref_id) AS pa_ref_id
			,max(pa.Match_code) AS pa_Match_code
			,max(ps.Fips) AS ps_Fips
			,max(ps.Ref_id) AS ps_Ref_id
			,max(ps.Match_code) AS ps_Match_code
			,max(ps.Apn) AS ps_Apn
			,max(ps.HouseNumber) AS HouseNumber
			,max(ps.Street_Number) AS Street_Number
			,max(ps.Direction) AS Direction
			,max(ps.Street_Name) AS Street_Name
			,max(ps.Street_Type) AS Street_Type
			,max(ps.Post_Direction) AS Post_Direction
			,max(ps.Unit_Type) AS Unit_Type
			,max(ps.Unit) AS Unit
			,max(ps.City) AS City
			,max(ps.STATE) AS STATE
			,max(ps.Zip) AS Zip
			,max(ps.Plus4) AS Plus4
			,max(ps.CRRT) AS CRRT
			,max(ps.CountyName) AS CountyName
			,max(ps.PMB) AS PMB
			,max(ps.PMSA) AS PMSA
			,max(ps.MSA) AS MSA
			,max(ps.ZipType) AS ZipType
			,max(ps.Urbanization) AS Urbanization
			,max(ps.CongressionalDistrict) AS CongressionalDistrict
			,max(ps.CountryCode) AS CountryCode
			,max(ps.CityAbbreviation) AS CityAbbreviation
			,max(ps.AddressTypeCode) AS AddressTypeCode
			,max(ps.AddressTypeString) AS AddressTypeString
			,max(ps.DPV_Count) AS DPV_Count
			,max(ps.DPV_Footnotes) AS DPV_Footnotes
			,max(ps.CMRA) AS CMRA
			,max(ps.ELOT_Number) AS ELOT_Number
			,max(ps.ELOT_Order) AS ELOT_Order
			,max(ps.LACS) AS LACS
			,max(ps.LACS_LinkIndicator) AS LACS_LinkIndicator
			,max(ps.EWS_Flag) AS EWS_Flag
			,max(ps.RBDI) AS RBDI
			,max(ps.SuiteLinkReturnCode) AS SuiteLinkReturnCode
			,max(ps.DeliveryPointCheckDigit) AS DeliveryPointCheckDigit
			,max(ps.DeliveryPointCode) AS DeliveryPointCode
			,max(ps.CensusBlock) AS CensusBlock
			,max(ps.CensusTract) AS CensusTract
			,max(ps.PlaceCode) AS PlaceCode
			,max(ps.PlaceName) AS PlaceName
			,max(ps.CBSACode) AS CBSACode
			,max(ps.CBSALevel) AS CBSALevel
			,max(ps.CBSATitle) AS CBSATitle
			,max(ps.CBSADivisionCode) AS CBSADivisionCode
			,max(ps.CBSADivisionLevel) AS CBSADivisionLevel
			,max(ps.CBSADivisionTitle) AS CBSADivisionTitle
			,max(ps.Latitude) AS Latitude
			,max(ps.Longitude) AS Longitude
			,max(ps.AddressMatchResults) AS AddressMatchResults
			,max(ps.GeoErrorCode) AS GeoErrorCode
			,max(ps.GeoStatusCode) AS GeoStatusCode
			,max(ps.AddressType) AS AddressType
			,max(legal_desc_qualifier) AS legal_desc_qualifier
			,max(legal_desc_timeshare_phase) AS legal_desc_timeshare_phase
			,max(legal_desc_map_city_block) AS legal_desc_map_city_block
			,max(legal_desc_application_number) AS legal_desc_application_number
			,max(legal_desc_tax_assessor_portion) AS legal_desc_tax_assessor_portion
			,max(legal_desc_tax_assessor_lot) AS legal_desc_tax_assessor_lot
			,max(legal_desc_tax_assessor_block) AS legal_desc_tax_assessor_block
			,max(legal_desc_tax_assessor_section) AS legal_desc_tax_assessor_section
			,max(legal_desc_arb_alternate) AS legal_desc_arb_alternate
			,max(property_ref_id) AS property_ref_id
			,max(legal_desc_timeshare_unit_high) AS legal_desc_timeshare_unit_high
			,max(legal_desc_timeshare_points) AS legal_desc_timeshare_points
			,max(property_sequence_id) AS property_sequence_id
			,max(plat_name_lookup) AS plat_name_lookup
			,max(property_ref_id_source) AS property_ref_id_source
			,max(legal_desc_map_plat_year) AS legal_desc_map_plat_year
		FROM [Lien].[tmp].[usp_Create_PropertyHeader_temp] t
		INNER JOIN [Lien].[UR].[PROPERTY] p WITH (
				NOLOCK
				,INDEX (ix_Doc_idSeq)
				) ON p.doc_id = t.doc_id
		LEFT JOIN [Lien].[UR].[PROPERTY_APN_MATCH] pa WITH (
				NOLOCK
				,INDEX (ix_propid_Ref_Code_apn)
				) ON pa.property_id = p.property_id
		LEFT JOIN [Lien].[UR].[PROPERTY_Std_Address] ps WITH (
				NOLOCK
				,INDEX (ix_PropIDREfidMatchCode)
				) ON ps.property_id = p.property_id
		OUTER APPLY (
			SELECT stuff((
						SELECT ',' + cast(CASE 
									WHEN pp.legal_desc_map_lot_high IS NOT NULL
										THEN pp.legal_desc_map_lot_low + '-' + pp.legal_desc_map_lot_high
									ELSE pp.legal_desc_map_lot_low
									END AS VARCHAR)
						FROM (
							SELECT DISTINCT legal_desc_map_lot_low
								,pp.legal_desc_map_lot_high
							FROM [Lien].[UR].[PROPERTY] pp WITH (
									NOLOCK
									,INDEX (ix_Doc_idSeq)
									)
							WHERE pp.doc_id = p.doc_id
								AND pp.property_id_sequence_number = p.property_id_sequence_number
							) pp
						ORDER BY pp.legal_desc_map_lot_low
						FOR XML PATH('')
						), 1, 1, '') AS _Lot
				,stuff((
						SELECT ',' + cast(CASE 
									WHEN pp.legal_desc_map_unit_high IS NOT NULL
										THEN pp.legal_desc_map_unit_low + '-' + pp.legal_desc_map_unit_high
									ELSE pp.legal_desc_map_unit_low
									END AS VARCHAR)
						FROM (
							SELECT DISTINCT pp.legal_desc_map_unit_low
								,pp.legal_desc_map_unit_high
							FROM [Lien].[UR].[PROPERTY] pp WITH (
									NOLOCK
									,INDEX (ix_Doc_idSeq)
									)
							WHERE pp.doc_id = p.doc_id
								AND pp.property_id_sequence_number = p.property_id_sequence_number
							) pp
						ORDER BY pp.legal_desc_map_unit_low
						FOR XML PATH('')
						), 1, 1, '') AS _UNit
			) AS stufff
		OUTER APPLY (
			SELECT [Lien].[dbo].[fn_FitLotUnit](stufff._Lot, 6) AS _new_l
				,[Lien].[dbo].[fn_FitLotUnit](stufff._unit, 8) AS _new_u
			) ll
		WHERE (
				p.legal_desc_address IS NULL
				AND p.legal_desc_apn IS NULL
				)
			AND NOT (
				p.[legal_desc_abstract_portion] IS NULL
				AND p.[legal_desc_abstract_acreage] IS NULL
				AND p.[legal_desc_abstract_name] IS NULL
				AND p.[legal_desc_abstract_number] IS NULL
				AND p.[legal_desc_address] IS NULL
				AND p.[legal_desc_address_city] IS NULL
				AND p.[legal_desc_address_state] IS NULL
				AND p.[legal_desc_address_zip] IS NULL
				AND p.[legal_desc_apn_portion] IS NULL
				AND p.[legal_desc_apn] IS NULL
				AND p.[legal_desc_apn_split] IS NULL
				AND p.[legal_desc_apn_arb] IS NULL
				AND p.[legal_desc_apn_alternate] IS NULL
				AND p.[legal_desc_map_portion] IS NULL
				AND p.[legal_desc_map_unit_low] IS NULL
				AND p.[legal_desc_map_unit_high] IS NULL
				AND p.[legal_desc_map_lot_type] IS NULL
				AND p.[legal_desc_map_lot_type_low] IS NULL
				AND p.[legal_desc_map_lot_type_high] IS NULL
				AND p.[legal_desc_map_lot_low] IS NULL
				AND p.[legal_desc_map_lot_high] IS NULL
				AND p.[legal_desc_map_block] IS NULL
				AND p.[legal_desc_map_building] IS NULL
				AND p.[legal_desc_map_sublot] IS NULL
				AND p.[legal_desc_map_plat_subcode] IS NULL
				AND p.[legal_desc_map_plat_name] IS NULL
				AND p.[legal_desc_map_plat_number] IS NULL
				AND p.[legal_desc_map_plat_condo_id] IS NULL
				AND p.[legal_desc_map_plat_type_indicator] IS NULL
				AND p.[legal_desc_map_plat_book] IS NULL
				AND p.[legal_desc_map_plat_page] IS NULL
				AND p.[legal_desc_mine_mining_claim_lode] IS NULL
				AND p.[legal_desc_mine_mining_district] IS NULL
				AND p.[legal_desc_mine_mining_survey] IS NULL
				AND p.[legal_desc_rancho_portion] IS NULL
				AND p.[legal_desc_rancho_name_number] IS NULL
				AND p.[legal_desc_str_portion] IS NULL
				AND p.[legal_desc_str_government_lot] IS NULL
				AND p.[legal_desc_str_quarter] IS NULL
				AND p.[legal_desc_str_section] IS NULL
				AND p.[legal_desc_str_township] IS NULL
				AND p.[legal_desc_str_range] IS NULL
				AND p.[legal_desc_tct] IS NULL
				AND p.[legal_desc_timeshare_name] IS NULL
				AND p.[legal_desc_timeshare_inventory_control_number] IS NULL
				AND p.[legal_desc_timeshare_unit] IS NULL
				AND p.[legal_desc_timeshare_week] IS NULL
				AND p.[legal_desc_timeshare_season] IS NULL
				AND p.[legal_desc_timeshare_type] IS NULL
				AND p.[legal_desc_timeshare_map_plat_lot] IS NULL
				AND p.[legal_desc_timeshare_map_plat_block] IS NULL
				AND p.[legal_desc_timeshare_map_plat_id] IS NULL
				AND p.[legal_desc_timeshare_map_plat_type_indicator] IS NULL
				AND p.[legal_desc_timeshare_map_plat_book] IS NULL
				AND p.[legal_desc_timeshare_map_plat_page] IS NULL
				AND p.[legal_desc_district] IS NULL
				AND p.[legal_desc_municipality] IS NULL
				AND p.[legal_desc_swiss_code] IS NULL
				AND p.[legal_desc_project_name] IS NULL
				AND p.[legal_desc_easement_flag] IS NULL
				AND p.[legal_desc_easement_type] IS NULL
				AND p.[legal_desc_unincorporated_property_flag] IS NULL
				AND p.[legal_desc_property_questionable_indicator] IS NULL
				AND p.[legal_desc_timeshare_year_type] IS NULL
				AND p.[legal_desc_arb_portion] IS NULL
				AND p.[batch] IS NULL
				AND p.[bucket] IS NULL
				)
			AND legal_desc_easement_flag IS NULL
			AND isnull(legal_desc_apn_portion, '') NOT IN (
				'Y'
				,'PT'
				)
			AND isnull(p.legal_desc_property_questionable_indicator, '') = ''
		GROUP BY p.doc_id
		) a
	ORDER BY a.doc_id --,a.property_id_sequence_number

INSERT INTO [Lien].[UR].[PROPERTYHeader] (
	[doc_id]
	,[property_id_sequence_number]
	,[legal_desc_abstract_portion]
	,[legal_desc_abstract_acreage]
	,[legal_desc_abstract_name]
	,[legal_desc_abstract_number]
	,[legal_desc_address]
	,[legal_desc_address_city]
	,[legal_desc_address_state]
	,[legal_desc_address_zip]
	,[legal_desc_apn_portion]
	,[legal_desc_apn]
	,[legal_desc_apn_split]
	,[legal_desc_apn_arb]
	,[legal_desc_apn_alternate]
	,[legal_desc_map_portion]
	,[legal_desc_map_unit_low]
	,[_unit]
	,[legal_desc_map_unit_high]
	,[legal_desc_map_lot_type]
	,[legal_desc_map_lot_type_low]
	,[legal_desc_map_lot_type_high]
	,[legal_desc_map_lot_low]
	,[_lot]
	,[legal_desc_map_lot_high]
	,[legal_desc_map_block]
	,[legal_desc_map_building]
	,[legal_desc_map_sublot]
	,[legal_desc_map_plat_subcode]
	,[legal_desc_map_plat_name]
	,[legal_desc_map_plat_number]
	,[legal_desc_map_plat_condo_id]
	,[legal_desc_map_plat_type_indicator]
	,[legal_desc_map_plat_book]
	,[legal_desc_map_plat_page]
	,[legal_desc_mine_mining_claim_lode]
	,[legal_desc_mine_mining_district]
	,[legal_desc_mine_mining_survey]
	,[legal_desc_rancho_portion]
	,[legal_desc_rancho_name_number]
	,[legal_desc_str_portion]
	,[legal_desc_str_government_lot]
	,[legal_desc_str_quarter]
	,[legal_desc_str_section]
	,[legal_desc_str_township]
	,[legal_desc_str_range]
	,[legal_desc_tct]
	,[legal_desc_timeshare_name]
	,[legal_desc_timeshare_inventory_control_number]
	,[legal_desc_timeshare_unit]
	,[legal_desc_timeshare_week]
	,[legal_desc_timeshare_season]
	,[legal_desc_timeshare_type]
	,[legal_desc_timeshare_map_plat_lot]
	,[legal_desc_timeshare_map_plat_block]
	,[legal_desc_timeshare_map_plat_id]
	,[legal_desc_timeshare_map_plat_type_indicator]
	,[legal_desc_timeshare_map_plat_book]
	,[legal_desc_timeshare_map_plat_page]
	,[legal_desc_district]
	,[legal_desc_municipality]
	,[legal_desc_swiss_code]
	,[legal_desc_project_name]
	,[legal_desc_easement_flag]
	,[legal_desc_easement_type]
	,[legal_desc_unincorporated_property_flag]
	,[legal_desc_property_questionable_indicator]
	,[legal_desc_timeshare_year_type]
	,[legal_desc_arb_portion]
	,[batch]
	,[bucket]
	,[pa_fips]
	,[pa_ref_id]
	,[pa_Match_code]
	,[ps_Fips]
	,[ps_Ref_id]
	,[ps_Match_code]
	,[ps_Apn]
	,[HouseNumber]
	,[Street_Number]
	,[Direction]
	,[Street_Name]
	,[Street_Type]
	,[Post_Direction]
	,[Unit_Type]
	,[Unit]
	,[City]
	,[STATE]
	,[Zip]
	,[Plus4]
	,[CRRT]
	,[CountyName]
	,[PMB]
	,[PMSA]
	,[MSA]
	,[ZipType]
	,[Urbanization]
	,[CongressionalDistrict]
	,[CountryCode]
	,[CityAbbreviation]
	,[AddressTypeCode]
	,[AddressTypeString]
	,[DPV_Count]
	,[DPV_Footnotes]
	,[CMRA]
	,[ELOT_Number]
	,[ELOT_Order]
	,[LACS]
	,[LACS_LinkIndicator]
	,[EWS_Flag]
	,[RBDI]
	,[SuiteLinkReturnCode]
	,[DeliveryPointCheckDigit]
	,[DeliveryPointCode]
	,[CensusBlock]
	,[CensusTract]
	,[PlaceCode]
	,[PlaceName]
	,[CBSACode]
	,[CBSALevel]
	,[CBSATitle]
	,[CBSADivisionCode]
	,[CBSADivisionLevel]
	,[CBSADivisionTitle]
	,[Latitude]
	,[Longitude]
	,[AddressMatchResults]
	,[GeoErrorCode]
	,[GeoStatusCode]
	,[AddressType]
	,[UpdateDate]
	,[legal_desc_qualifier]
	,[legal_desc_timeshare_phase]
	,[legal_desc_map_city_block]
	,[legal_desc_application_number]
	,[legal_desc_tax_assessor_portion]
	,[legal_desc_tax_assessor_lot]
	,[legal_desc_tax_assessor_block]
	,[legal_desc_tax_assessor_section]
	,[legal_desc_arb_alternate]
	,[m_create_date]
	,[property_ref_id]
	,[legal_desc_timeshare_unit_high]
	,[legal_desc_timeshare_points]
	,[property_sequence_id]
	,[plat_name_lookup]
	,[property_ref_id_source]
	,[legal_desc_map_plat_year]
	)
OUTPUT inserted.Doc_id
	,NULL AS Name_id
	,NULL AS property_id
	,NULL AS reference_id
	,inserted.m_create_date
	,'usp_Create_PropertyHeader_1' AS Process_name
INTO [lien].[ur].[document_transaction_log]
SELECT p.doc_id
	,p.property_id_sequence_number
	,max(p.legal_desc_abstract_portion) AS legal_desc_abstract_portion
	,max(p.legal_desc_abstract_acreage) AS legal_desc_abstract_acreage
	,max(p.legal_desc_abstract_name) AS legal_desc_abstract_name
	,max(p.legal_desc_abstract_number) AS legal_desc_abstract_number
	,max(p.legal_desc_address) AS legal_desc_address
	,max(p.legal_desc_address_city) AS legal_desc_address_city
	,max(p.legal_desc_address_state) AS legal_desc_address_state
	,max(p.legal_desc_address_zip) AS legal_desc_address_zip
	,max(p.legal_desc_apn_portion) AS legal_desc_apn_portion
	,max(p.legal_desc_apn) AS legal_desc_apn
	,max(p.legal_desc_apn_split) AS legal_desc_apn_split
	,max(p.legal_desc_apn_arb) AS legal_desc_apn_arb
	,max(p.legal_desc_apn_alternate) AS legal_desc_apn_alternate
	,max(p.legal_desc_map_portion) AS legal_desc_map_portion
	,max(p.legal_desc_map_unit_low) AS legal_desc_map_unit_low
	,max(_unit) AS _unit
	,max(p.legal_desc_map_unit_high) AS legal_desc_map_unit_high
	,max(p.legal_desc_map_lot_type) AS legal_desc_map_lot_type
	,max(p.legal_desc_map_lot_type_low) AS legal_desc_map_lot_type_low
	,max(p.legal_desc_map_lot_type_high) AS legal_desc_map_lot_type_high
	,max(p.legal_desc_map_lot_low) AS legal_desc_map_lot_low
	,max(_lot) AS _lot
	,max(p.legal_desc_map_lot_high) AS legal_desc_map_lot_high
	,max(p.legal_desc_map_block) AS legal_desc_map_block
	,max(p.legal_desc_map_building) AS legal_desc_map_building
	,max(p.legal_desc_map_sublot) AS legal_desc_map_sublot
	,max(p.legal_desc_map_plat_subcode) AS legal_desc_map_plat_subcode
	,max(p.legal_desc_map_plat_name) AS legal_desc_map_plat_name
	,max(p.legal_desc_map_plat_number) AS legal_desc_map_plat_number
	,max(p.legal_desc_map_plat_condo_id) AS legal_desc_map_plat_condo_id
	,max(p.legal_desc_map_plat_type_indicator) AS legal_desc_map_plat_type_indicator
	,max(p.legal_desc_map_plat_book) AS legal_desc_map_plat_book
	,max(p.legal_desc_map_plat_page) AS legal_desc_map_plat_page
	,max(p.legal_desc_mine_mining_claim_lode) AS legal_desc_mine_mining_claim_lode
	,max(p.legal_desc_mine_mining_district) AS legal_desc_mine_mining_district
	,max(p.legal_desc_mine_mining_survey) AS legal_desc_mine_mining_survey
	,max(p.legal_desc_rancho_portion) AS legal_desc_rancho_portion
	,max(p.legal_desc_rancho_name_number) AS legal_desc_rancho_name_number
	,max(p.legal_desc_str_portion) AS legal_desc_str_portion
	,max(p.legal_desc_str_government_lot) AS legal_desc_str_government_lot
	,max(p.legal_desc_str_quarter) AS legal_desc_str_quarter
	,max(p.legal_desc_str_section) AS legal_desc_str_section
	,max(p.legal_desc_str_township) AS legal_desc_str_township
	,max(p.legal_desc_str_range) AS legal_desc_str_range
	,max(p.legal_desc_tct) AS legal_desc_tct
	,max(p.legal_desc_timeshare_name) AS legal_desc_timeshare_name
	,max(p.legal_desc_timeshare_inventory_control_number) AS legal_desc_timeshare_inventory_control_number
	,max(p.legal_desc_timeshare_unit) AS legal_desc_timeshare_unit
	,max(p.legal_desc_timeshare_week) AS legal_desc_timeshare_week
	,max(p.legal_desc_timeshare_season) AS legal_desc_timeshare_season
	,max(p.legal_desc_timeshare_type) AS legal_desc_timeshare_type
	,max(p.legal_desc_timeshare_map_plat_lot) AS legal_desc_timeshare_map_plat_lot
	,max(p.legal_desc_timeshare_map_plat_block) AS legal_desc_timeshare_map_plat_block
	,max(p.legal_desc_timeshare_map_plat_id) AS legal_desc_timeshare_map_plat_id
	,max(p.legal_desc_timeshare_map_plat_type_indicator) AS legal_desc_timeshare_map_plat_type_indicator
	,max(p.legal_desc_timeshare_map_plat_book) AS legal_desc_timeshare_map_plat_book
	,max(p.legal_desc_timeshare_map_plat_page) AS legal_desc_timeshare_map_plat_page
	,max(p.legal_desc_district) AS legal_desc_district
	,max(p.legal_desc_municipality) AS legal_desc_municipality
	,max(p.legal_desc_swiss_code) AS legal_desc_swiss_code
	,max(p.legal_desc_project_name) AS legal_desc_project_name
	,max(p.legal_desc_easement_flag) AS legal_desc_easement_flag
	,max(p.legal_desc_easement_type) AS legal_desc_easement_type
	,max(p.legal_desc_unincorporated_property_flag) AS legal_desc_unincorporated_property_flag
	,max(p.legal_desc_property_questionable_indicator) AS legal_desc_property_questionable_indicator
	,max(p.legal_desc_timeshare_year_type) AS legal_desc_timeshare_year_type
	,max(p.legal_desc_arb_portion) AS legal_desc_arb_portion
	,max(p.batch) AS batch
	,max(p.bucket) AS bucket
	,max(pa_fips) AS pa_fips
	,max(pa_ref_id) AS pa_ref_id
	,max(pa_Match_code) AS pa_Match_code
	,max(ps_Fips) AS ps_Fips
	,max(ps_Ref_id) AS ps_Ref_id
	,max(ps_Match_code) AS ps_Match_code
	,max(ps_Apn) AS ps_Apn
	,max(HouseNumber) AS HouseNumber
	,max(Street_Number) AS Street_Number
	,max(Direction) AS Direction
	,max(Street_Name) AS Street_Name
	,max(Street_Type) AS Street_Type
	,max(Post_Direction) AS Post_Direction
	,max(Unit_Type) AS Unit_Type
	,max(Unit) AS Unit
	,max(City) AS City
	,max(STATE) AS STATE
	,max(Zip) AS Zip
	,max(Plus4) AS Plus4
	,max(CRRT) AS CRRT
	,max(CountyName) AS CountyName
	,max(PMB) AS PMB
	,max(PMSA) AS PMSA
	,max(MSA) AS MSA
	,max(ZipType) AS ZipType
	,max(Urbanization) AS Urbanization
	,max(CongressionalDistrict) AS CongressionalDistrict
	,max(CountryCode) AS CountryCode
	,max(CityAbbreviation) AS CityAbbreviation
	,max(AddressTypeCode) AS AddressTypeCode
	,max(AddressTypeString) AS AddressTypeString
	,max(DPV_Count) AS DPV_Count
	,max(DPV_Footnotes) AS DPV_Footnotes
	,max(CMRA) AS CMRA
	,max(ELOT_Number) AS ELOT_Number
	,max(ELOT_Order) AS ELOT_Order
	,max(LACS) AS LACS
	,max(LACS_LinkIndicator) AS LACS_LinkIndicator
	,max(EWS_Flag) AS EWS_Flag
	,max(RBDI) AS RBDI
	,max(SuiteLinkReturnCode) AS SuiteLinkReturnCode
	,max(DeliveryPointCheckDigit) AS DeliveryPointCheckDigit
	,max(DeliveryPointCode) AS DeliveryPointCode
	,max(CensusBlock) AS CensusBlock
	,max(CensusTract) AS CensusTract
	,max(PlaceCode) AS PlaceCode
	,max(PlaceName) AS PlaceName
	,max(CBSACode) AS CBSACode
	,max(CBSALevel) AS CBSALevel
	,max(CBSATitle) AS CBSATitle
	,max(CBSADivisionCode) AS CBSADivisionCode
	,max(CBSADivisionLevel) AS CBSADivisionLevel
	,max(CBSADivisionTitle) AS CBSADivisionTitle
	,max(Latitude) AS Latitude
	,max(Longitude) AS Longitude
	,max(AddressMatchResults) AS AddressMatchResults
	,max(GeoErrorCode) AS GeoErrorCode
	,max(GeoStatusCode) AS GeoStatusCode
	,max(AddressType) AS AddressType
	,max(UpdateDate) AS UpdateDate
	,max(legal_desc_qualifier) AS legal_desc_qualifier
	,max(legal_desc_timeshare_phase) AS legal_desc_timeshare_phase
	,max(legal_desc_map_city_block) AS legal_desc_map_city_block
	,max(legal_desc_application_number) AS legal_desc_application_number
	,max(legal_desc_tax_assessor_portion) AS legal_desc_tax_assessor_portion
	,max(legal_desc_tax_assessor_lot) AS legal_desc_tax_assessor_lot
	,max(legal_desc_tax_assessor_block) AS legal_desc_tax_assessor_block
	,max(legal_desc_tax_assessor_section) AS legal_desc_tax_assessor_section
	,max(legal_desc_arb_alternate) AS legal_desc_arb_alternate
	,max(m_create_date) AS m_create_date
	,max(property_ref_id) AS property_ref_id
	,max(legal_desc_timeshare_unit_high) AS legal_desc_timeshare_unit_high
	,max(legal_desc_timeshare_points) AS legal_desc_timeshare_points
	,max(property_sequence_id) AS property_sequence_id
	,max(plat_name_lookup) AS plat_name_lookup
	,max(property_ref_id_source) AS property_ref_id_source
	,max(legal_desc_map_plat_year) AS legal_desc_map_plat_year
FROM (
	SELECT *
	FROM [Lien].[tmp].[usp_Create_PropertyHeader_prop1]
	
	UNION ALL
	
	SELECT *
	FROM [Lien].[tmp].[usp_Create_PropertyHeader_prop2]
	) p
GROUP BY doc_id
	,property_id_sequence_number
ORDER BY doc_id
	,property_id_sequence_number

--
-- Update 4 character fipscode to 5 character
--
DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_4fips]
	SELECT DISTINCT [fips_code]
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_4fips]
	FROM [Lien].[UR].[DOCUMENT]
	WHERE len(fips_code) = 4

DROP TABLE

IF EXISTS [Lien].[tmp].[usp_Create_PropertyHeader_detail]
	SELECT a.doc_id
		,a.fips_code
		,'0' + a.fips_code AS new_fips_code
	INTO [Lien].[tmp].[usp_Create_PropertyHeader_detail]
	FROM [Lien].[UR].[DOCUMENT] a
	WHERE a.fips_code IN (
			SELECT Fips_code
			FROM [Lien].[tmp].[usp_Create_PropertyHeader_4fips]
			)

CREATE INDEX ixa ON [Lien].[tmp].[usp_Create_PropertyHeader_detail] (doc_id) --

UPDATE [Lien].[UR].[d]
SET d.fips_code = b.new_fips_code
	,d.m_update_date = getdate()
OUTPUT inserted.Doc_id
	,NULL AS Name_id
	,NULL AS property_id
	,NULL AS reference_id
	,inserted.m_update_date
	,'usp_Create_PropertyHeader_3' AS Process_name
INTO [lien].[ur].[document_transaction_log]
FROM [lien].[ur].[document] d WITH (
		NOLOCK
		,INDEX (pk_document)
		)
INNER JOIN [Lien].[tmp].[usp_Create_PropertyHeader_detail] b ON b.doc_id = d.doc_id

--
--post processing started
--
--
--Make sure the Instrument number indexes are upated on Document
--
UPDATE [Lien].[UR].[a]
SET a.Instrument_nbr = CASE 
		WHEN isnull(a.cmt_docnumber, '') > ''
			THEN cmt_docnumber
		WHEN isnull(a.Fmt_Doc_Number, '') > ''
			THEN Fmt_Doc_Number
		WHEN isnull(a.FMT_Book_Page, '') > ''
			THEN a.FMT_Book_Page
		ELSE 'none'
		END
	,recording_date_d = [spdb].[eprvdb].[fn_DTOCR_RecordingDate](a.recording_date)
FROM [lien].[ur].[document] a WITH (
		NOLOCK
		,INDEX (idx_instr_fips_RecDt)
		)
WHERE a.Instrument_nbr IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

-- 
--Find records part of todays lien Run
--
TRUNCATE TABLE [lien].[tmp].[reprocess_records_to_be_processed]

--
--determine the last time the tracker ran
--
DECLARE @date DATETIME2 = (
		SELECT max(m_update_date)
		FROM [lien].[UR].[document_transaction_log_tracker]
		WHERE INFC_Extract_date IS NOT NULL
		)

--SELECT @date
--
--find all the doc_id that had a change since the last update ran
--
INSERT INTO [lien].[tmp].[reprocess_records_to_be_processed] (
	[doc_id]
	,[m_update_date]
	,[fips_code]
	,[Fips]
	,[Instrument_nbr]
	,[recording_date_d]
	,[m_status_id]
	,[reprocess_flag]
	,[ur_matrix]
	,[previous_doc_unique_id]
	,[update_type]
	,[doc_title]
	,[doc_type]
	)
SELECT d.doc_id
	,b.m_update_date AS m_update_date
	,d.fips_code
	,try_cast(d.Fips_code AS INT) AS Fips
	,d.Instrument_nbr
	,d.recording_date_d
	,d.m_status_id
	,isnull(d.reprocess_flag, '') AS reprocess_flag
	,d.[ur_matrix]
	,d.[previous_doc_unique_id]
	,d.[update_type]
	,d.[doc_title]
	,d.[doc_type]
FROM (
	SELECT a.doc_id
		,a.m_update_date
		,ROW_NUMBER() OVER (
			PARTITION BY a.doc_id ORDER BY a.m_update_date DESC
			) AS ROW4
	FROM (
		SELECT l.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		--where l.doc_id in (147093623,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[NAME] n WITH (INDEX (PK_NAME)) ON n.name_id = l.name_id
		--where l.doc_id in (147093623,207319327) 
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Name_id IS NOT NULL
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[Property] n WITH (INDEX (PK_PROPERTY)) ON n.Property_id = l.Property_id
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Property_id IS NOT NULL
		
		UNION ALL
		
		SELECT n.Doc_id
			,l.m_update_date
		FROM [lien].[ur].[document_transaction_log] l WITH (INDEX (ixc_update_date))
		INNER JOIN [lien].[ur].[Reference] n WITH (INDEX (PK_REFERENCE)) ON n.Reference_id = l.Reference_id
		WHERE l.m_update_date > isnull(@date, '19000101')
			AND l.Reference_id IS NOT NULL
		) a
	WHERE doc_id IS NOT NULL
	) b
INNER JOIN [lien].[ur].[DOCUMENT] d WITH (
		NOLOCK
		,INDEX (pk_document)
		) ON d.doc_id = b.Doc_id
WHERE row4 = 1
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

--
--Make sure the Instrument number indexes are upated on Document
--
UPDATE [Lien].[UR].[a]
SET a.Instrument_nbr = CASE 
		WHEN isnull(a.cmt_docnumber, '') > ''
			THEN cmt_docnumber
		WHEN isnull(a.Fmt_Doc_Number, '') > ''
			THEN Fmt_Doc_Number
		WHEN isnull(a.FMT_Book_Page, '') > ''
			THEN a.FMT_Book_Page
		ELSE 'none'
		END
	,recording_date_d = [spdb].[eprvdb].[fn_DTOCR_RecordingDate](a.recording_date)
FROM [lien].[ur].[document] a WITH (
		NOLOCK
		,INDEX (idx_instr_fips_RecDt)
		)
WHERE a.Instrument_nbr IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

UPDATE [Lien].[UR].[a]
SET a.Instrument_nbr = c.Instrument_nbr
	,recording_date_d = [spdb].[eprvdb].[fn_DTOCR_RecordingDate](a.recording_date)
FROM [lien].[ur].[document] a WITH (
		NOLOCK
		,INDEX (pk_document)
		)
INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] b WITH (
		NOLOCK
		,INDEX (idx)
		) ON b.doc_id = a.doc_id
OUTER APPLY (
	SELECT CASE 
			WHEN isnull(a.cmt_docnumber, '') > ''
				THEN cmt_docnumber
			WHEN isnull(a.Fmt_Doc_Number, '') > ''
				THEN Fmt_Doc_Number
			WHEN isnull(a.FMT_Book_Page, '') > ''
				THEN a.FMT_Book_Page
			ELSE 'none'
			END AS Instrument_nbr
	) c
WHERE a.Instrument_nbr <> c.Instrument_nbr
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

UPDATE [Lien].[UR].[b]
SET b.Instrument_nbr = a.Instrument_nbr
	,b.recording_date_d = a.recording_date_d
FROM [lien].[ur].[document] a WITH (
		NOLOCK
		,INDEX (pk_document)
		)
INNER JOIN [lien].[tmp].[reprocess_records_to_be_processed] b WITH (
		NOLOCK
		,INDEX (idx)
		) ON b.doc_id = a.doc_id
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

EXEC [Lien].[UR].[usp_Match_Pending_Documents] @ERROR = @ERROR OUTPUT

IF @ERROR IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END

--
--
--
EXEC [Lien].[UR].[usp_Lien_Post_Capture_Processing] @ERROR = @ERROR OUTPUT

IF @ERROR IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END

--
-- Added 4/11/2023 - Standardize NMLS Information
--
EXEC [Lien].[UR].[usp_Lien_Post_Capture_NMLS] @ERROR = @ERROR OUTPUT

IF @ERROR IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END

--
-- Calculate Washington DC sales price - Implemented 7/18/2023
--
--EXEC Lien.UR.USP_Sales_Price_Calculation @ERROR = @ERROR OUTPUT
--IF @ERROR IS NOT NULL
--BEGIN
--	RAISERROR (
--			@ERROR
--			,16
--			,1
--			)
--END
--
EXEC [Lien].[UR].[usp_Set_Status_for_reprossess_Flag] @ERROR = @ERROR OUTPUT

--Select @ERROR as N'@ERROR'
IF @ERROR IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END

--
-- set multi apn after m_status flags are set
--
--declare @ERROR VARCHAR(500) 
--EXEC Lien.UR.USP_Multi_apn_calculation @ERROR = @ERROR OUTPUT
--Select @ERROR as N'@ERROR'
IF @ERROR IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_Create_PropertyHeader'
	,N'Ended'


