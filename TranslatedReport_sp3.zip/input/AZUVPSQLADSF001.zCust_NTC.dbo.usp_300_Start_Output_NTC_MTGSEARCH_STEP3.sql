SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_NTC].[dbo].[usp_300_Start_Output_NTC_MTGSEARCH_STEP3]

AS
BEGIN
	
	SET NOCOUNT ON;

	--------EXEC dbo.[usp_300_Start_Output_NTC_BASIC_STEP1]
	--------EXEC dbo.[usp_300_Start_Output_NTC_BASIC_STEP2]
	--------EXEC dbo.[usp_300_Start_Output_NTC_BASIC_STEP3]

		Select XosStatus, count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XosStatus


		-------------------------------------ADD BUILDOUT SECTIONS for those with images & set flag is there are recordings with no images!!!!!--------------------------------------------

		Truncate table [w_TransHist_II_NOIMAGE]
		
		Insert into [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE]
		Select A.*
		--Select * 
		From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join [zCust_NTC].[dbo].[z_Images_To_Pull] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.RAW_ID + '_' + 'SMAR' + '_' +  case when A.DocumentType like 'MO%' then 'MOD' 
		when A.DocumentType like 'U' then 'FCD'
		else A.DocumentType end + '_' +  A.DocumentNbr
		 = B.ImageName
		 and case when A.DocumentType like 'MO%' then 'MOD'
		 when A.DocumentType like 'U' then 'FCD'
		 else A.DocumentType end = B.[DOCTYPE]
		 where 
		 (ISNULL(B.XosStatus,'') not like 'COmpleted')

	
	

		 Delete from [zCust_NTC].[dbo].[A]
		 --Select *
		 From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on 
		A.RAW_ID = B.RAW_ID
		and A.Doc_Id = B.DOC_ID
		and A.Doc_Src_Ind = B.Doc_Src_Ind
		and A.RecordingDate = B.RecordingDate


		Delete from [zCust_NTC].[dbo].[z_Images_To_Pull]
		where ISNULL(XosStatus,'') not like 'COmpleted'


		 Select count(*)  From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		 Select count(*)  From [zCust_NTC].[dbo].[z_Images_To_Pull] as A 
		 where XosStatus like 'Completed' 
		 and [DOCTYPE] in ('ASN','MOD','REL','FCD')


		 Select [DOCTYPE], count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull] as A 
		 where XosStatus like 'Completed' 
		 Group by [DOCTYPE]
		 Order by [DOCTYPE]


		 Select ToUse ,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		 Group by ToUse



		 -----------------------SUB-MTG-------------------------

		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[SubseqMTGRecNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse like 'MG'
		 


		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse like 'MG' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse = 'MG'
		Group by RAW_ID
		having count(*) > 1


		Select A.* From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse = 'MG'
		Group by RAW_ID
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'MG'


		 Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]


		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse = 'MG'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0

		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) > 0
		BEGIN
		

		

		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int
		
		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans =  MAX(convert(int,NbrofRecords))   FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),(@BeginNbrOfTrans )),3)
					
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGRecording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGLoan Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGInstrument #_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGBookPage_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGDoc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGBorrower Name_' + @RecNbr + '] [varchar](250) NULL')


					
						EXEC('UPDATE A
						SET 
						A.[SUB_MTGRecording Date_' + @RecNbr + '] = B.Recordingdate
						,A.[SUB_MTGLoan Amount_' + @RecNbr + '] = B.Value
						,A.[SUB_MTGInstrument #_' + @RecNbr + '] = B.DocumentNbr
						,A.[SUB_MTGBookPage_' + @RecNbr + '] = B.BookSrce
						,A.[SUB_MTGDoc Type_' + @RecNbr + '] = B.PageSrce
						,A.[SUB_MTGBorrower Name_' + @RecNbr + '] = B.BuyerBorrower

						--Select B.*
						FROM x_Custom_OUTPUT_MTGSEARCH A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse = ''MG''
						and 
						B.[RecordNumber] = ' + @BeginNbrOfTrans + '')

					
						EXEC('UPDATE a
						SET 
						 A.[SUB_MTGDoc Type_' + @RecNbr + '] = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_MTGSEARCH as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[SUB_MTGDoc Type_' + @RecNbr + '] = C.Value
						WHERE B.ToUse = ''MG''
						AND B.[RecordNumber] = ' + @BeginNbrOfTrans + '')
					

											
					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 

		END



		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) is null
		BEGIN
		-------Build 1 set even if no records to return 

					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGRecording Date] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGLoan Amount] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGInstrument #] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGBookPage] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGDoc Type] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [SUB_MTGBorrower Name] [varchar](250) NULL')

		END


		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

	
		
		


	----------------------------------------------------MOD----------------------------------------------------------------

		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[MODRecordingNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse like 'MO%'
		 


		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse like 'MO%' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse like 'MO%'
		Group by RAW_ID
		having count(*) > 1


		Select A.* From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse like 'MO%'
		Group by RAW_ID
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse like 'MO%'


		

		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse like 'MO%'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0

		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) > 0
		BEGIN
		

		

		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans2 int
		Declare @EndNbrOfTrans2 int
		
		SET @BeginNbrOfTrans2 = 1
		Select @EndNbrOfTrans2 =  MAX(convert(int,NbrofRecords))   FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

			WHILE (@BeginNbrOfTrans2 <= @EndNbrOfTrans2)
				BEGIN
				 
					DECLARE @RecNbr2 as varchar(5)
					SET @RecNbr2 = RIGHT('000' + convert(varchar(5),(@BeginNbrOfTrans2 )),3)
					
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODRecording Date_' + @RecNbr2 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODInstrument #_' + @RecNbr2 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODBookPage_' + @RecNbr2 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODDoc Type_' + @RecNbr2 + '] [varchar](250) NULL')


					
						EXEC('UPDATE A
						SET 
						A.[MODRecording Date_' + @RecNbr2 + '] = B.Recordingdate
						,A.[MODInstrument #_' + @RecNbr2 + '] = case when B.DocumentNbr = B.FMT_Book_Page then NULL else B.DocumentNbr end
						,A.[MODBookPage_' + @RecNbr2 + '] = case when ISNULL(B.FMT_Book_Page,'''') not like '''' then B.FMT_Book_Page else NULL END
						,A.[MODDoc Type_' + @RecNbr2 + '] = B.DocumentType

						--Select B.*
						FROM x_Custom_OUTPUT_MTGSEARCH A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse like ''MO%''
						and 
						B.[RecordNumber] = ' + @BeginNbrOfTrans2 + '')

					
						EXEC('UPDATE a
						SET 
						 A.[MODDoc Type_' + @RecNbr2 + '] = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_MTGSEARCH as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[MODDoc Type_' + @RecNbr2 + '] = C.Value
						WHERE B.ToUse like ''MO%''
						AND B.[RecordNumber] = ' + @BeginNbrOfTrans2 + '')
					

											
					SET @BeginNbrOfTrans2 = @BeginNbrOfTrans2 + 1
				
				END 

		END

		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0




		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) is null
		BEGIN
		-------Build 1 set even if no records to return 

					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODRecording Date] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODInstrument #] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODBookPage] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [MODDoc Type] [varchar](250) NULL')


		END


		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]


			



	----------------------------------------------------ASN----------------------------------------------------------------

		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[ASNRecordingNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse Like 'A%'
		 
		

		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse Like 'A%' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'A%'
		Group by RAW_ID
		having count(*) > 1


		Select A.RAW_ID, A.REF_ID, A.RecordingDate, A.DocumentNbr, A.RecordNumber From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'A%'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse Like 'A%'
		Order by A.RAW_ID, A.RecordNumber 

		

		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse Like 'A%'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0

		Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) > 0
		BEGIN
		

		

		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans3 int
		Declare @EndNbrOfTrans3 int
		
		SET @BeginNbrOfTrans3 = 1
		Select @EndNbrOfTrans3 =  MAX(convert(int,NbrofRecords))   FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

			WHILE (@BeginNbrOfTrans3 <= @EndNbrOfTrans3)
				BEGIN
				 
					DECLARE @RecNbr3 as varchar(5)
					SET @RecNbr3 = RIGHT('000' + convert(varchar(5),(@BeginNbrOfTrans3 )),3)
					
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNRecording Date_' + @RecNbr3 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNInstrument#_' + @RecNbr3 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNBookPage_' + @RecNbr3 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNDocType_' + @RecNbr3 + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNNewLenderName_' + @RecNbr3 + '] [varchar](250) NULL')


					
						EXEC('UPDATE A
						SET 
						A.[ASNRecording Date_' + @RecNbr3 + '] = B.Recordingdate
						,A.[ASNInstrument#_' + @RecNbr3 + '] = case when B.DocumentNbr = B.FMT_Book_Page then NULL else B.DocumentNbr end
						,A.[ASNBookPage_' + @RecNbr3 + '] = case when ISNULL(B.FMT_Book_Page,'''') not like '''' then B.FMT_Book_Page else NULL END
						,A.[ASNDocType_' + @RecNbr3 + '] = B.DocumentType
						,A.[ASNNewLenderName_' + @RecNbr3 + '] = B.SellerLender

						--Select B.*
						FROM x_Custom_OUTPUT_MTGSEARCH A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse like ''A%''
						and 
						B.[RecordNumber] = ' + @BeginNbrOfTrans3 + '')


					
						EXEC('UPDATE a
						SET 
						 A.[ASNDocType_' + @RecNbr3 + '] = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_MTGSEARCH as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[ASNDocType_' + @RecNbr3 + '] = C.Value
						WHERE B.ToUse like ''A%''
						AND B.[RecordNumber] = ' + @BeginNbrOfTrans3 + '')
					

											
					SET @BeginNbrOfTrans3 = @BeginNbrOfTrans3 + 1
				
				END 

		END

		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0
		Order by convert(int,NbrofRecords) desc


	


		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) is null
		BEGIN
		-------Build 1 set even if no records to return 

					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNRecording Date] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNInstrument#] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNBookPage] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNDocType] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [ASNNewLenderName] [varchar](250) NULL')


		END


		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]


		
	----------------------------------------------------REL----------------------------------------------------------------
		Select DocumentType,ToUse, count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		Group by DocumentType,ToUse
		Order by DocumentType,ToUse


		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[RELRecordingNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse Like 'R%'
		 
		

		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse Like 'R%' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'R%'
		Group by RAW_ID
		having count(*) > 1


		Select A.RAW_ID, A.REF_ID, A.RecordingDate, A.DocumentNbr, A.RecordNumber From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'R%'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse Like 'R%'
		Order by A.RAW_ID, A.RecordNumber 

		

		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse Like 'R%'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0

		Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) > 0
		BEGIN
		

		

		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans4 int
		Declare @EndNbrOfTrans4 int
		
		SET @BeginNbrOfTrans4 = 1
		Select @EndNbrOfTrans4 =  MAX(convert(int,NbrofRecords))   FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]

			WHILE (@BeginNbrOfTrans4 <= @EndNbrOfTrans4)
				BEGIN
				 
					DECLARE @RecNbr4 as varchar(5)
					SET @RecNbr4 = RIGHT('000' + convert(varchar(5),(@BeginNbrOfTrans4 )),3)
					
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELRecording Date_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELInstrument #_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELBookPage_' + @RecNbr4 + '] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELDoc Type_' + @RecNbr4 + '] [varchar](250) NULL')


					
						EXEC('UPDATE A
						SET 
						A.[RELRecording Date_' + @RecNbr4 + '] = B.Recordingdate
						,A.[RELInstrument #_' + @RecNbr4 + '] = case when B.DocumentNbr = B.FMT_Book_Page then NULL else B.DocumentNbr end
						,A.[RELBookPage_' + @RecNbr4 + '] = case when ISNULL(B.FMT_Book_Page,'''') not like '''' then B.FMT_Book_Page else NULL END
						,A.[RELDoc Type_' + @RecNbr4 + '] = B.DocumentType



						--Select B.*
						FROM x_Custom_OUTPUT_MTGSEARCH A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse like ''R%''
						and 
						B.[RecordNumber] = ' + @BeginNbrOfTrans4 + '')


					
						EXEC('UPDATE a
						SET 
						 A.[RELDoc Type_' + @RecNbr4 + '] = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_MTGSEARCH as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[RELDoc Type_' + @RecNbr4 + '] = C.Value
						WHERE B.ToUse like ''R%''
						AND B.[RecordNumber] = ' + @BeginNbrOfTrans4 + '')
					

											
					SET @BeginNbrOfTrans4 = @BeginNbrOfTrans4 + 1
				
				END 

		END

		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0
		Order by convert(int,NbrofRecords) desc


	


		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) is null
		BEGIN
		-------Build 1 set even if no records to return 

				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELRecording Date] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELInstrument #] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELBookPage] [varchar](250) NULL')
				EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [RELDoc Type] [varchar](250) NULL')


		END


		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]



		----------------------------------------------------FC DEED----------------------------------------------------------------
		Select DocumentType,ToUse, count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		Group by DocumentType,ToUse
		Order by DocumentType,ToUse


		 Update [zCust_NTC].[dbo].[A]
		 set
		 A.[FCLRecordingNoImage] = 'Y'
		 From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		 [zCust_NTC].[dbo].[w_TransHist_II_NOIMAGE] as B on A.[Unique ID] = B.RAW_ID
		 where B.ToUse Like 'U%'
		 
		

		 Update [zCust_NTC].[dbo].[w_TransHist_II]
		 set RecordNumber = NULL

		 	UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist_II] t WHERE ToUse Like 'U%' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID



		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'U%'
		Group by RAW_ID
		having count(*) > 1


		Select A.RAW_ID, A.REF_ID, A.RecordingDate, A.DocumentNbr, A.RecordNumber From [zCust_NTC].[dbo].[w_TransHist_II] as A 
		join (Select RAW_ID,RecordNumber,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist_II]
		WHERE ToUse Like 'U%'
		Group by RAW_ID,RecordNumber
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse Like 'U%'
		Order by A.RAW_ID, A.RecordNumber 

		

		UPDATE [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET NbrofRecords = NULL

		UPDATE [zCust_NTC].[dbo].[a]
		SET a.NbrofRecords = b.NbrOfRecordings
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings FROM [zCust_NTC].[dbo].[w_TransHist_II] 
		where ToUse Like 'U%'
		GROUP BY RAW_ID) b
		on a.[Unique ID] = b.RAW_ID

				
		
		Select count(*) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0

		Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]


			-------Build 1 set even if no records to return 

			EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [FCLRecording Date] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [FCLInstrument #] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [FCBookPage] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [FCLDoc Type] [varchar](250) NULL')
			EXEC('ALTER Table x_Custom_OUTPUT_MTGSEARCH ADD [FCLBuyer/Borrower] [varchar](250) NULL')




		IF (Select max(convert(int,NbrofRecords)) from [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]) > 0
		BEGIN
		
					
						EXEC('UPDATE A
						SET 
						A.[FCLRecording Date = B.Recordingdate
						,A.[FCLInstrument # =  case when B.DocumentNbr = B.FMT_Book_Page then NULL else B.DocumentNbr end
						,A.[FCBookPage = B.case when ISNULL(B.FMT_Book_Page,'''') not like '''' then B.FMT_Book_Page else NULL END
						,A.[FCLDoc Type = B.DocumentType
						,A.[FCLBuyer/Borrower = B.BuyerBorrower


						--Select B.*
						FROM x_Custom_OUTPUT_MTGSEARCH A JOIN 
						w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						WHERE B.ToUse like ''U%''
						')


					
						EXEC('UPDATE a
						SET 
						 A.[FCLDoc Type = C.[Code Description]
						--Select A.[Doc Type], B.*
						From x_Custom_OUTPUT_MTGSEARCH as A 
						join  w_TransHist_II as B on A.[Unique ID] = B.RAW_ID
						JOIN 
							(Select Value, [Code Description]  FROM [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B with(NOLOCK)
							where Deed_Table_Column_Name like ''DETAILED_DOC_TYPE%'')C
						on A.[FCLDoc Type = C.Value
						WHERE B.ToUse like ''U%''
						')
					

				
				END 

		
		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where NbrofRecords > 0
		Order by convert(int,NbrofRecords) desc


	

		Select * From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]


		
		Update [zCust_NTC].[dbo].[A]
		Set A.[Total Doc Image Count] = B.TOTAL
		From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A join 
		(Select INPUTKEY, count(*) as TOTAL  From [zCust_NTC].[dbo].[z_Images_To_Pull]
		where xosstatus like 'Completed'
		Group by INPUTKEY)B
		on A.[Unique ID] = B.INPUTKEY



		Update [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] 
		SET [In Coverage] = CASE WHEN [In Coverage] = '2' THEN 'In Coverage' ELSE 'Not In Coverage' END

		--Update  a
		--SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		--FROM x_Custom_OUTPUT_MTGSEARCH a JOIN 
		--[dbo].a_ASP_IN_STD b
		--on a.[INPUTKEY] = b.Raw_ID

		Update [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_NTC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] a join [zCust_NTC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[Unique ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		Update  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		SET [Event Status] = CASE WHEN ISNULL([MTGRecording Date],'') not like '' then 'Event Found' else 'Event Not Found' end
		

		Select [Property Status], count(*) From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		Group by [Property Status]

		--Select [Address Standardization], count(*) From x_Custom_OUTPUT_MTGSEARCH
		--Group by [Address Standardization]
		
		Select [Event Status], count(*) From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		Group by [Event Status]

		Select [In Coverage], count(*) From [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		Group by [In Coverage]

		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH] as A 
		where 
		([Event Status] like 'Event Not Found'
		and [Total Doc Image Count] > 0)
		OR
		([Event Status] like 'Event Found'
		and [Total Doc Image Count] is null)


		Select * From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_MTGSEARCH]
		where [Total Doc Image Count] > 0



END






