/* Source: DWS-ETL02.DATATREE.LOCAL | spdb | EPRVDB.AddTorteeLog | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

create PROCEDURE [SPDB].[EPRVDB].[AddTorteeLog]
	@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [EPR_VDB_TORTEE].[dbo].[LoadLog] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

