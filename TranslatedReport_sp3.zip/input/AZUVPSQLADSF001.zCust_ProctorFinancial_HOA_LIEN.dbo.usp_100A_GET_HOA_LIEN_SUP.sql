SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_SUP]

AS
BEGIN

	SET NOCOUNT ON;

	
	

	 DROP TABLE  dbo.HOA_LIEN_SUP

	 Select A.*,F.REF_ID, C.INPUTKEY 
	 into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	 --,C.INPUTBORROWER, C.OWNERSTDNAME1FULL, A.Owner1LastName
	 --FROM [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 FROM [Data].[dbo].[HOA_Lien_Sup]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PROPERTYID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as C on B.RAW_ID = C.INPUTKEY
	  --------20191113 - Changed to look at new HOA Lien Doc Type Table per MS---
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]
	 join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D with(NOLOCK) on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(D.DocType))
	 where B.PROPERTYID is not null
	 and 
	 (convert(DATE,convert(varchar(10),A.[RecordingDt])) > convert(date,C.[MAX_LIENDATE])
	 OR C.[MAX_LIENDATE] is null)
	 AND D.HOA_Data_Type   in ('LIEN','LEN')
	 --------------------ADDED 20180713 per Nicole - do not want liens for prior owners - even if they are marked as Active in the LIEN table-------------
	 AND (Case when C.INPUTBORROWER is not null and C.INPUTBORROWER not like '' then C.INPUTBORROWER else C.OWNERSTDNAME1FULL end) like '%' + A.Owner1LastName + '%'
	 and A.Owner1LastName is not null and A.Owner1LastName not like ''
	 AND A.Released is NULL

	 --Select top 1000 * From [Data].[dbo].[HOA_Lien_sup]
	 --where Owner1LastName is null

	 --Select * From dbo.HOA_LIEN_SUP
	

	 Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select A.DetailDocumentType,A.Fmt_NMD_document_number ,A.[RecordingDt],B.OAReference, B.DocType, B.DocumentID, B.REcordingDate
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A  
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on A.LIC_PRopertyID = F.LIC_PRopertyID
	 join [HOA].[dbo].[HOA_Lien]  B with(NOLOCK) on F.REF_ID = B.REF_ID
	where 
	REPLACE(REPLACE(REPLACE(A.Fmt_NMD_document_number,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.OAReference,'.',''),' ',''),'-','')
	----Changed 20191113 to use new doc type table---
	---AND B.DocType like 'halnrl'
	And DocType in (Select DocType from [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] with(NOLOCK)  where  HOA_Data_Type in ( 'release'))


	---------------Added 20190306 to remove all active HOA Liens in SUP that are also in HOA_LIEN but are NOT active----
	
	 Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select A.REF_ID, A.REcordingDt, A.Fmt_NMD_document_number, A.LienAmount,A.DetailDocumentType,
	--B.DocumentID, B.REcordingDate, B.DocType,B.LienAmount, B.IsHoaLienActive
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A  
	 --join Assr.dbo.Assr as F with(NOLOCK) on A.LIC_PRopertyID = F.LIC_PRopertyID
	 join [HOA].[dbo].[HOA_Lien]  B with(NOLOCK) on A.REF_ID = B.REF_ID
	where 
	REPLACE(REPLACE(REPLACE(A.Fmt_NMD_document_number,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.DocumentID,'.',''),' ',''),'-','')
	AND B.IsHoaLienActive = 0


	 Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select A.REF_ID, A.REcordingDt, A.Fmt_NMD_document_number, A.LienAmount,A.DetailDocumentType,
	--B.DocumentID, B.REcordingDate, B.DocType,B.LienAmount, B.IsHoaLienActive
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A  
	 --join Assr.dbo.Assr as F with(NOLOCK) on A.LIC_PRopertyID = F.LIC_PRopertyID
	 join [HOA].[dbo].[HOA_Lien]  B with(NOLOCK) on A.REF_ID = B.REF_ID
	where 
	REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(A.NMD_document_number_Raw)),'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(B.Identifier)),'.',''),' ',''),'-','')
	AND B.IsHoaLienActive = 0

	--Select * From HOA_LIEN_SUP
		
	 Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select A.REF_ID, A.REcordingDt, A.Fmt_NMD_document_number, A.LienAmount,A.DetailDocumentType,
	--B.DocumentID, B.REcordingDate, B.DocType,B.LienAmount, B.IsHoaLienActive, B.Identifier
	--,A.NMD_document_number_Raw
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A  
	 --join Assr.dbo.Assr as F with(NOLOCK) on A.LIC_PRopertyID = F.LIC_PRopertyID
	 join [HOA].[dbo].[HOA_Lien]  B with(NOLOCK) on A.REF_ID = B.REF_ID
	where 
	REPLACE(REPLACE(REPLACE(A.NMD_document_number_Raw,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(B.Identifier,'.',''),' ',''),'-','')
	AND B.IsHoaLienActive = 1


	

	 ALTER TABLE dbo.HOA_LIEN_SUP ADD [RecordNumber][int]NULL


	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] SET RecordNumber = NULL

	 --Select * From  dbo.HOA_LIEN_SUP
	  
	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY [RecordingDt] DESC)  AS RowNum
			FROM 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] t  ) r ON t.REF_ID = r.REF_ID and t.Fmt_NMD_document_number = r.Fmt_NMD_document_number and t.INPUTKEY = r.INPUTKEY


		--Select * From HOA_LIEN_SUP


	--Select * From [Data].[dbo].[HOA_Lien_Sup]
	--where LIC_PropertyID = '83548681'

	ALTER TABLE HOA_LIEN_SUP ALTER COLUMN LIENAMOUNT [decimal](13,2)NULL

	UPdate [Data].[dbo].[HOA_Lien_Sup]
	Set LienAmount = '3604.32'
	,Fmt_NMD_document_number = '4850495'
	where LIC_PropertyID = '83548681'
	and Fmt_NMD_document_number = '2018.4850495'

	
	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set Fmt_NMD_document_number = REPLACE((left(NMD_document_number_Raw,4) + '.' + right(left(NMD_document_number_Raw,8),4) + '.' + right(NMD_document_number_Raw,4)),' ','')
	where Fmt_NMD_document_number not like '%.%.%'
	and FIPSCODE = '32003'


	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set Fmt_NMD_document_number = case when left(Fmt_NMD_document_number,5) = left(recordingDt,4) + '.'
	then Right(Fmt_NMD_document_number,len(Fmt_NMD_document_number)-5)
	else Fmt_NMD_document_number end
	where FIPSCODE = '32031'

	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set Fmt_NMD_document_number = REPLACE((left(NMD_document_number_Raw,4) + '.' + right(left(NMD_document_number_Raw,8),4) + '.' + right(NMD_document_number_Raw,4)),' ','')
	where Fmt_NMD_document_number not like '%.%.%'
	and FIPSCODE = '53053'



	Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
	--Select A.*, B.*
	From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP] as A 
	join [HOA].[dbo].[HOA_Lien] as B with(NOLOCK) 
	on A.REF_ID = B.REF_ID
	and A.REcordingDt = B.RecordingDate
	and (case when left(A.Fmt_NMD_document_number,5) like left(A.REcordingDt,4) + '.' 
	then Right(A.Fmt_NMD_document_number,Len(A.Fmt_NMD_document_number)-5) else A.Fmt_NMD_document_number end)
	 = B.DocumentId


	--Select * From dbo.HOA_LIEN_SUP
	--where convert(bigint,LienAmount) > 100000

	-------------Per MS - 20181206 - Any Lien anounts > 100K - divide by 100--------
	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set LienAmount = convert(money,LienAmount/100)
	--Select LienAmount , convert(money,LienAmount/100)
	--From HOA_LIEN_SUP
	--where  convert(bigint,LienAmount) > 100000
	-----20190306 - Changed to 50K per MS
		where  convert(bigint,LienAmount) > 50000

	--Select NMD_document_number_Raw,Fmt_NMD_document_number,
	--REPLACE((left(NMD_document_number_Raw,4) + '.' + right(left(NMD_document_number_Raw,8),4) + '.' + right(NMD_document_number_Raw,4)),' ','')
	--from HOA_LIEN_SUP



	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set 
	Fmt_NMD_document_number = REPLACE(Fmt_NMD_document_number,'D','')
	,NMD_document_number_Raw = REPLACE(NMD_document_number_Raw,'D','')
	where FIPSCode like '%8005'


	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set 
	Fmt_NMD_document_number = case when left(Fmt_NMD_document_number,5) like left(REcordingDt,4) + '.' and len(Fmt_NMD_document_number) > 11
	and right(left(Fmt_NMD_document_number,6),1) = right(left(REcordingDt,4),1) then left(REcordingDt,4) + '.' + right(Fmt_NMD_document_number,len(Fmt_NMD_document_number)-6)
	else Fmt_NMD_document_number end
	,NMD_document_number_Raw =  case when left(NMD_document_number_Raw,1) like right(left(REcordingDt,4),1) and len(NMD_document_number_Raw) > 6
	 then  right(NMD_document_number_Raw,len(NMD_document_number_Raw)-1)
	else NMD_document_number_Raw end
	where FIPSCode like '%8005'


	Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_SUP]
	Set LienAmount = convert(money,LienAmount/100)
	where  FIPSCode like '%8005'

	

	--Select  convert(money,LienAmount/100),LienAmount
	--From dbo.HOA_LIEN_SUP
	--where  FIPSCode like '%8005'
			
		


END





