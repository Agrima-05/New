SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF






CREATE PROCEDURE [zCust_WesternAlliance].[dbo].[usp_211_Create_TransHist_Rev5] 
AS
BEGIN

	TRUNCATE TABLE dbo.[w_TransHist]

	--Add transaction linked by ref_id - CL
	INSERT INTO [zCust_WesternAlliance].[dbo].[w_TransHist]
	( [Fips]
		,[REF_ID]      
		,[RecordingDate]
		,[DocumentType]
		,[DocumentNbr]
		,[Lien_Pos]
		,[CmtId]
		,[Source_Type]
		,[Doc_Id]
		,[Doc_Src_Ind]
		,[Updated_Date]
		,[MTG_Term]
		,[MTG_TermType]
		,[Loan_Type]
		,[Int_Rate]
		,[Rate_Type]
		,[DocDate]
		,[RAW_ID]

	)
	SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind,d.Updated_Date
	,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date],RAW_ID
 
		FROM [zCust_WesternAlliance].[dbo].[w_UniqueRefId] s with(nolock)
		INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d with(nolock) ON d.Fips = s.Fips AND d.REF_ID = s.REF_ID 
		JOIN [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
--	WHERE Source_Type = 'C' 



	---- REMOVED DUE TO ONLY PULLING THE CONTROL TABLE VERSION OF DIM_NOVA_DOCUMENT -- MS 20170726

	----Add transaction linked by ref_id - CL
	--INSERT INTO [dbo].[w_TransHist]
	--( 
	--	[Fips]
	--	,[REF_ID]      
	--	,[RecordingDate]
	--	,[DocumentType]
	--	,[DocumentNbr]
	--	,[Lien_Pos]
	--	,[CmtId]
	--	,[Source_Type]
	--	,[Doc_Id]
	--	,[Doc_Src_Ind]
	--	,[Updated_Date]
	--	,[MTG_Term]
	--	,[MTG_TermType]
	--	,[Loan_Type]
	--	,[Int_Rate]
	--	,[Rate_Type]
	--	,[DocDate]
	--	,[RAW_ID]

	--)
	--SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	--, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind, d.[Updated_Date]
	--,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date], RAW_ID
	--FROM dbo.w_UniqueRefId s with(nolock) 
	--	INNER JOIN dbo.w_DIM_NOVA_DOCUMENT d with(nolock) ON d.Fips = s.Fips AND d.REF_ID = s.REF_ID 
	--	JOIN a_PropMatch_WORK c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
	--WHERE d.Recording_Date < '06/01/2012'  AND Source_Type = 'D'


	----Add transaction linked by ref_id - CL
	--INSERT INTO [dbo].[w_TransHist]
	--( 
	--	[Fips]
	--	,[REF_ID]      
	--	,[RecordingDate]
	--	,[DocumentType]
	--	,[DocumentNbr]
	--	,[Lien_Pos]
	--	,[CmtId]
	--	,[Source_Type]
	--	,[Doc_Id]
	--	,[Doc_Src_Ind]
	--	,[Updated_Date]
	--	,[MTG_Term]
	--	,[MTG_TermType]
	--	,[Loan_Type]
	--	,[Int_Rate]
	--	,[Rate_Type]
	--	,[DocDate]
	--	,[RAW_ID]

	--)
	--SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	--, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind, d.[Updated_Date]
	--,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date],RAW_ID
	--FROM dbo.w_UniqueRefId s with(nolock) 
	--	INNER JOIN dbo.w_DIM_NOVA_DOCUMENT d with(nolock) ON d.Fips = s.Fips AND d.REF_ID = s.REF_ID 
	--	JOIN a_PropMatch_WORK c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
	--WHERE d.Recording_Date < '06/01/2012'  AND Source_Type not in('C','D')

	------ added for BKFS data

	--INSERT INTO [dbo].[w_TransHist]
	--( 
	--	[Fips]
	--	,[REF_ID]      
	--	,[RecordingDate]
	--	,[DocumentType]
	--	,[DocumentNbr]
	--	,[Lien_Pos]
	--	,[CmtId]
	--	,[Source_Type]
	--	,[Doc_Id]
	--	,[Doc_Src_Ind]
	--	,[Updated_Date]
	--	,[MTG_Term]
	--	,[MTG_TermType]
	--	,[Loan_Type]
	--	,[Int_Rate]
	--	,[Rate_Type]
	--	,[DocDate]
	--	,[RAW_ID]

	--)
	--SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	--, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind, d.[Updated_Date]
	--,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date],RAW_ID
	--FROM dbo.w_UniqueRefId s with(nolock) 
	--	INNER JOIN dbo.w_DIM_NOVA_DOCUMENT d with(nolock) ON d.Fips = s.Fips AND d.REF_ID = s.REF_ID 
	--	JOIN a_PropMatch_WORK c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
	--WHERE d.created_date > '06/01/2017' AND Source_Type in('B')

	--Add referenced transaction that is being linked by doc_ref_id 
	INSERT INTO [zCust_WesternAlliance].[dbo].[w_TransHist]
	( [Fips]
		,[REF_ID]      
		,[RecordingDate]
		,[DocumentType]
		,[DocumentNbr]
		,[Lien_Pos]
		,[CmtId]
		,[Source_Type]
		,[Doc_Id]
		,[Doc_Src_Ind]
		,[Updated_Date]
		,[MTG_Term]
		,[MTG_TermType]
		,[Loan_Type]
		,[Int_Rate]
		,[Rate_Type]
		,[DocDate]
		,[RAW_ID]

	)
	SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind, d.[Updated_Date]
	,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date],RAW_ID
	FROM [zCust_WesternAlliance].[dbo].[w_DOC_XREF] s with(nolock) 
		INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d with(nolock)  ON d.Fips = s.Fips AND d.Doc_Id = s.DOC_REF_ID 
		JOIN [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
	ORDER BY d.REF_ID, d.Recording_Date DESC, d.Doc_Number,  s.DOC_REF_ID DESC

	--Add referencing transaction might not be in NDD 
	INSERT INTO [zCust_WesternAlliance].[dbo].[w_TransHist]
	( [Fips]
		,[REF_ID]      
		,[RecordingDate]
		,[DocumentType]
		,[DocumentNbr]
		,[Lien_Pos]
		,[CmtId]
		,[Source_Type]
		,[Doc_Id]
		,[Doc_Src_Ind]
		,[Updated_Date]
		,[MTG_Term]
		,[MTG_TermType]
		,[Loan_Type]
		,[Int_Rate]
		,[Rate_Type]
		,[DocDate]
		,[RAW_ID]

	)
	SELECT s.Fips,s.REF_ID, d.Recording_Date, d.Doc_Type, d.Doc_Number, d.lien_pos, d.Cmt_Id
	, d.Source_Type, d.Doc_Id, d.Doc_Src_Ind, d.[Updated_Date] 
	,d.[MTG_Term],d.[Mtg_Term_TYPE],d.[Loan_Type],d.[Int_Rate],d.[Rate_Type],d.[Filing_Date],RAW_ID
	FROM [zCust_WesternAlliance].[dbo].[w_DOC_XREF] s with(nolock) 
		INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d with(nolock)  ON d.Fips = s.Fips AND d.Doc_Id = s.DOC_REF_ID 
		JOIN [zCust_WesternAlliance].[dbo].[a_PropMatch_WORK] c on s.FIPS = c.FIPS and s.REF_ID = c.REF_ID
	ORDER BY d.REF_ID, d.Recording_Date DESC, d.Doc_Number,  s.DOC_ID DESC


	--Remove Aliases
	DELETE FROM
		[zCust_WesternAlliance].[dbo].[w_TransHist] 
	WHERE 
		Doc_id in
		(SELECT Doc_id FROM 
			(
				SELECT t.*, 
				ROW_NUMBER() OVER(PARTITION BY T.RAW_ID,d.REF_ID, d.Sr_Unique_Id, REPLACE(d.Raps_Doc_Ind, 'A', '') ORDER BY d.Raps_Doc_Ind ASC) AS RowNum,
				d.Raps_Doc_Ind FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d ON t.Doc_Id = d.Doc_Id
				WHERE d.Raps_Doc_Ind <> ''	
			) Potential WHERE Potential.RowNum > 1
		)


	--Assign Record Number
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET RecordNumber = RowNum
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t LEFT JOIN
	(SELECT * 
		,ROW_NUMBER() OVER(PARTITION BY REF_ID ORDER BY RecordingDate DESC, DocumentNbr DESC) AS RowNum
		FROM 
	[zCust_WesternAlliance].[dbo].[w_TransHist] t ) r ON t.REF_ID = r.REF_ID AND t.DOC_ID = r.Doc_ID


	--Get Original Doc number
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET t.OrigDoc_Id = tRef.Doc_id, t.OrigTransDocNumber = tRef.DocumentNbr, t.OrigTransRecDate = tRef.RecordingDate
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t 
	LEFT JOIN [zCust_WesternAlliance].[dbo].[w_DOC_XREF] r ON t.Doc_Id = r.DOC_ID 
	LEFT JOIN [zCust_WesternAlliance].[dbo].[w_TransHist] tRef ON r.DOC_REF_ID = tRef.DOC_ID 



	--Get Original Doc number from Prefore Closure
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET  t.OrigTransDocNumber = p.Fmt_Loan_Inst_Nbr, t.OrigTransRecDate = p.Original_Loan_Date
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d ON t.Doc_Id = d.Doc_Id
		INNER JOIN [zCust_WesternAlliance].[dbo].[w_PreForeclosure] p ON d.Sr_Unique_Id = p.CLGX_Unique_ID 
			AND d.Fips = p.FIPS
				AND d.REF_ID = p.REF_ID
	WHERE t.OrigTransRecDate IS NULL AND t.OrigTransDocNumber IS null



	--Get Buyer/Borrower/Defendant
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET t.BuyerBorrower = RTRIM(LTRIM(n.Raw_Name))
	
		,t.BuyerBorrowerLastName = RTRIM(LTRIM(n.Last_Name))
		,t.BuyerBorrowerFirstName = RTRIM(LTRIM(n.First_Name))
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t
	INNER JOIN 
		(
			SELECT n.Raw_Name,n.Last_Name,n.First_Name, f.Doc_Id,
			ROW_NUMBER() OVER(PARTITION BY f.DOC_ID ORDER BY ROLE) AS RowNum
			--Select * 
			FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist] t 
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_FCT_DOC_NAME] f ON t.Doc_id = f.Doc_Id AND 
				(
					f.ROLE LIKE 'BUYER%'
					OR f.ROLE LIKE 'BORROWER%'
					OR f.ROLE LIKE 'DEFENDANT%'				
				)
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_CLNAME] n ON f.Name_Id = n.Name_Id
		)n
		ON t.Doc_Id = n.DOC_ID AND n.RowNum = 1


		--Get Buyer/Borrower/Defendant
	UPDATE [zCust_WesternAlliance].[dbo].[T]
	Set
	t.[BuyerBorrower1] = RTRIM(LTRIM(n.FULL_Name))
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t
	INNER JOIN 
		(
			SELECT n.FULL_Name,n.Last_Name,n.First_Name, f.Doc_Id,
			ROW_NUMBER() OVER(PARTITION BY f.DOC_ID ORDER BY ROLE) AS RowNum
			--Select * 
			FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist] t 
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_FCT_DOC_NAME] f ON t.Doc_id = f.Doc_Id AND 
				(
					f.ROLE LIKE 'BUYER%'
					OR f.ROLE LIKE 'BORROWER%'
					OR f.ROLE LIKE 'DEFENDANT%'				
				)
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_CLNAME] n ON f.Name_Id = n.Name_Id
		)n
		ON t.Doc_Id = n.DOC_ID AND n.RowNum = 1

	
	UPDATE [zCust_WesternAlliance].[dbo].[T]
	Set
	t.[BuyerBorrower2] = RTRIM(LTRIM(n.FULL_Name))
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t
	INNER JOIN 
		(
			SELECT n.FULL_Name,n.Last_Name,n.First_Name, f.Doc_Id,
			ROW_NUMBER() OVER(PARTITION BY f.DOC_ID ORDER BY ROLE) AS RowNum
			--Select * 
			FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist] t 
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_FCT_DOC_NAME] f ON t.Doc_id = f.Doc_Id AND 
				(
					f.ROLE LIKE 'BUYER%'
					OR f.ROLE LIKE 'BORROWER%'
					OR f.ROLE LIKE 'DEFENDANT%'				
				)
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_CLNAME] n ON f.Name_Id = n.Name_Id
		)n
		ON t.Doc_Id = n.DOC_ID AND n.RowNum = 2





	--Get Lender/Plaintiff
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET t.SellerLender = RTRIM(LTRIM(n.Raw_Name))
		,t.SellerLenderLastName = RTRIM(LTRIM(n.Last_Name))
		,t.SellerLenderFirstName = RTRIM(LTRIM(n.First_Name))
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t
	INNER JOIN 
		(
			SELECT n.Raw_Name,n.Last_Name,n.First_Name, f.Doc_Id,
			ROW_NUMBER() OVER(PARTITION BY f.DOC_ID ORDER BY ROLE) AS RowNum
			 FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist] t 
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_FCT_DOC_NAME] f ON t.Doc_id = f.Doc_Id AND 
				(
					f.ROLE LIKE 'LENDER%'
					--OR f.ROLE LIKE 'SELLER%'
					OR f.ROLE LIKE 'PLAINTIFF%'				
				)
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_CLNAME] n ON f.Name_Id = n.Name_Id
		)n
		ON t.Doc_Id = n.DOC_ID AND n.RowNum = 1
		WHERE t.Doc_Src_Ind != 'D'

	--Get SELLER
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET t.SellerLender = RTRIM(LTRIM(n.Raw_Name))
		,t.SellerLenderLastName = RTRIM(LTRIM(n.Last_Name))
		,t.SellerLenderFirstName = RTRIM(LTRIM(n.First_Name))
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t
	INNER JOIN 
		(
			SELECT n.Raw_Name,n.Last_Name,n.First_Name, f.Doc_Id,
			ROW_NUMBER() OVER(PARTITION BY f.DOC_ID ORDER BY ROLE) AS RowNum
			 FROM 
			[zCust_WesternAlliance].[dbo].[w_TransHist] t 
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_FCT_DOC_NAME] f ON t.Doc_id = f.Doc_Id AND 
				(
					f.ROLE LIKE 'SELLER%'				
				)
			INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_CLNAME] n ON f.Name_Id = n.Name_Id
		
		)n
		ON t.Doc_Id = n.DOC_ID AND n.RowNum = 1
		WHERE t.Doc_Src_Ind = 'D'


	--Update Value for Mortgage and Deed
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET 
	t.Value = 
		CASE WHEN d.Doc_Src_Ind = 'M' THEN d.Loan_Amt
		WHEN d.Doc_Src_Ind = 'D' THEN d.Transfer_Amt
		ELSE
		NULL
	END 
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d ON t.Doc_Id = d.Doc_Id


	--Update Default Amount for PreforeClosure
	UPDATE [zCust_WesternAlliance].[dbo].[t] SET 
	t.Value = Default_Amount
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [zCust_WesternAlliance].[dbo].[w_DIM_NOVA_DOCUMENT] d ON t.Doc_Id = d.Doc_Id
	INNER JOIN [zCust_WesternAlliance].[dbo].[w_PreForeclosure] p ON d.Sr_Unique_Id = p.CLGX_Unique_ID AND d.Fips = p.FIPS
	AND d.REF_ID = p.REF_ID
	AND t.Value IS null


	--Update Document Type

	UPDATE [zCust_WesternAlliance].[dbo].[t] SET DocumentTypeDesc = 'DEED TRANSFER'
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t WHERE Doc_Src_Ind = 'D'

	UPDATE [zCust_WesternAlliance].[dbo].[t] SET DocumentTypeDesc = 'TRUST DEED/MORTGAGE'
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t WHERE Doc_Src_Ind = 'M'

	UPDATE [zCust_WesternAlliance].[dbo].[t] SET DocumentTypeDesc = 'MODIFICATION'
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t WHERE DocumentType like 'MO'



	UPDATE [zCust_WesternAlliance].[dbo].[t] SET DocumentTypeDesc = d.[Code Description]
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] d 
	ON t.DocumentType = d.Value  and d.Deed_Table_Column_name = 'DETAILED_DOC_TYPE' AND t.Source_Type = 'C' AND Doc_Src_Ind = 'R'


	UPDATE [zCust_WesternAlliance].[dbo].[t] SET DocumentTypeDesc = d.Consolidated_Definition
	FROM [zCust_WesternAlliance].[dbo].[w_TransHist] t INNER JOIN [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].[Doc_Types] d 
	ON t.DocumentType = d.Output_Code AND t.Source_Type = 'T' AND d.FIPS = t.Fips AND t.DocumentType = d.Output_Code AND Doc_Src_Ind = 'R'

	UPDATE [zCust_WesternAlliance].[dbo].[a]
	SET [MTG_Term] = CASE WHEN isNULL([MTG_Term],'') like '' then MTG1_MTG_TERM_ ELSE [MTG_Term] END
		,[MTG_TermType] = CASE WHEN isNULL([MTG_TermType],'') like '' then MTG1_MTG_TERM_CODE ELSE [MTG_TermType] END
		,[Loan_Type] = CASE WHEN isNULL([Loan_Type],'') like '' then MTG1_MTG_LOAN_TYPE_CODE ELSE [Loan_Type] END
		,[Int_Rate] = CASE WHEN isNULL([Int_Rate],'') like '' then MTG1_MTG_INTEREST_RATE ELSE [Int_Rate] END
		,[Rate_Type] = CASE WHEN isNULL([Rate_Type],'') like '' then MTG1_MTG_INTEREST_RATE_TYPE ELSE [Rate_Type] END
		,[DocDate] = CASE WHEN [DocDate] is NULL then MTG1_DOC_DATE ELSE [DocDate] END
	  FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_DEED] b
	  on a.FIPS = b.FIPS
	  and a.REF_ID = b.REF_ID 
	  and a.RecordingDate = b.MTG1_RECORDING_DATE
	  and a.DocumentNbr = CASE WHEN FMT_MTG1_DOC_NBR is NULL THEN FMT_MTG1_Book_Page ELSE FMT_MTG1_DOC_NBR END
	WHERE Doc_Src_Ind = 'M'

	UPDATE [zCust_WesternAlliance].[dbo].[a]
	SET [MTG_Term] = CASE WHEN isNULL([MTG_Term],'') like '' then MTG2_MTG_TERM ELSE [MTG_Term] END
		,[MTG_TermType] = CASE WHEN isNULL([MTG_TermType],'') like '' then MTG2_MTG_TERM_CODE ELSE [MTG_TermType] END
		,[Loan_Type] = CASE WHEN isNULL([Loan_Type],'') like '' then MTG2_MTG_LOAN_TYPE_CODE ELSE [Loan_Type] END
		,[Int_Rate] = CASE WHEN isNULL([Int_Rate],'') like '' then MTG2_MTG_INTEREST_RATE ELSE [Int_Rate] END
		,[Rate_Type] = CASE WHEN isNULL([Rate_Type],'') like '' then MTG2_MTG_INTEREST_RATE_TYPE ELSE [Rate_Type] END
		,[DocDate] = CASE WHEN [DocDate] is NULL then MTG2_DOC_DATE ELSE [DocDate] END
	  FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_DEED] b
	  on a.FIPS = b.FIPS
	  and a.REF_ID = b.REF_ID 
	  and a.RecordingDate = b.MTG2_RECORDING_DATE
	  and a.DocumentNbr = CASE WHEN FMT_MTG2_DOC_NBR is NULL THEN FMT_MTG2_Book_Page ELSE FMT_MTG2_DOC_NBR END
	WHERE Doc_Src_Ind = 'M'

	UPDATE [zCust_WesternAlliance].[dbo].[a]
	SET [MTG_Term] = CASE WHEN isNULL([MTG_Term],'') like '' then MTG3_MTG_TERM ELSE [MTG_Term] END
		,[MTG_TermType] = CASE WHEN isNULL([MTG_TermType],'') like '' then MTG3_MTG_TERM_CODE ELSE [MTG_TermType] END
		,[Loan_Type] = CASE WHEN isNULL([Loan_Type],'') like '' then MTG3_MTG_LOAN_TYPE_CODE ELSE [Loan_Type] END
		,[Int_Rate] = CASE WHEN isNULL([Int_Rate],'') like '' then MTG3_MTG_INTEREST_RATE ELSE [Int_Rate] END
		,[Rate_Type] = CASE WHEN isNULL([Rate_Type],'') like '' then MTG3_MTG_INTEREST_RATE_TYPE ELSE [Rate_Type] END
		,[DocDate] = CASE WHEN [DocDate] is NULL then MTG3_DOC_DATE ELSE [DocDate] END
	  FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_DEED] b
	  on a.FIPS = b.FIPS
	  and a.REF_ID = b.REF_ID 
	  and a.RecordingDate = b.MTG3_RECORDING_DATE
	  and a.DocumentNbr = CASE WHEN FMT_MTG3_DOC_NBR is NULL THEN FMT_MTG3_Book_Page ELSE FMT_MTG3_DOC_NBR END
	WHERE Doc_Src_Ind = 'M'

	UPDATE [zCust_WesternAlliance].[dbo].[a]
	SET [MTG_Term] = CASE WHEN isNULL([MTG_Term],'') like '' then MTG4_MTG_TERM ELSE [MTG_Term] END
		,[MTG_TermType] = CASE WHEN isNULL([MTG_TermType],'') like '' then MTG4_MTG_TERM_CODE ELSE [MTG_TermType] END
		,[Loan_Type] = CASE WHEN isNULL([Loan_Type],'') like '' then MTG4_MTG_LOAN_TYPE_CODE ELSE [Loan_Type] END
		,[Int_Rate] = CASE WHEN isNULL([Int_Rate],'') like '' then MTG4_MTG_INTEREST_RATE ELSE [Int_Rate] END
		,[Rate_Type] = CASE WHEN isNULL([Rate_Type],'') like '' then MTG4_MTG_INTEREST_RATE_TYPE ELSE [Rate_Type] END
		,[DocDate] = CASE WHEN [DocDate] is NULL then MTG4_DOC_DATE ELSE [DocDate] END
	  FROM [zCust_WesternAlliance].[dbo].[w_TransHist] a JOIN [zCust_WesternAlliance].[dbo].[w_DEED] b
	  on a.FIPS = b.FIPS
	  and a.REF_ID = b.REF_ID 
	  and a.RecordingDate = b.MTG4_RECORDING_DATE
	  and a.DocumentNbr = CASE WHEN FMT_MTG4_DOC_NBR is NULL THEN FMT_MTG4_Book_Page ELSE FMT_MTG4_DOC_NBR END
	WHERE Doc_Src_Ind = 'M'

		UPDATE [zCust_WesternAlliance].[dbo].[w_TransHist] 
		SET Mtg_TermType = null where Mtg_Term = 0

		UPDATE [zCust_WesternAlliance].[dbo].[w_TransHist] 
		SET Mtg_Term = null where Mtg_Term = 0

		UPDATE [zCust_WesternAlliance].[dbo].[w_TransHist] 
		SET Int_Rate = null where Int_Rate = '0'


END












