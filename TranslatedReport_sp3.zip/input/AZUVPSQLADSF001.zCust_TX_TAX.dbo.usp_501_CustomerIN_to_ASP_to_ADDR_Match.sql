SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [zCust_TX_TAX].[dbo].[usp_501_CustomerIN_to_ASP_to_ADDR_Match] 
	
AS
BEGIN

		

		-----TX_TAX-----------
		SET CONCAT_NULL_YIELDS_NULL OFF
		TRUNCATE TABLE INPUT_IN
		INSERT INTO [zCust_TX_TAX].[dbo].[INPUT_IN]([INPUTKey],[INPUTAddress],[INPUTCity],[INPUTState],[INPUTZip],INPUTAPN,INPUTFIPS,INPUTSTARTDATE)
	
		Select 
		A.unique_id
		,left(A.ADDRESS,255)
		,A.[CITY]
		,A.[STATE]
		,A.[ZIP]
		,A.APN
		,A.FIPS
		,convert(Date,[monitoring start date])
		--Select top 100 * 
		FROM [zCust_TX_TAX].[dbo].[INPUT_RAW_CUST] as A 
		--From [dbo].[INPUT_RAW_20260430] as A 
		join [global].[dbo].[county] as B With(NOLOCK) on A.FIPS = B.FIPSCODE
		where ISNULL(unique_id,'') NOT like ''

	Select top 100 * From [zCust_TX_TAX].[dbo].[INPUT_RAW_CUST]
		

		Select top 1000 * From [zCust_TX_TAX].[dbo].[INPUT_IN]

		Select [INPUTKey], count(*) From [zCust_TX_TAX].[dbo].[INPUT_IN]
		Group by [INPUTKey]
		having count(*) > 1


		UPdate [zCust_TX_TAX].[dbo].[INPUT_IN]
		SET [INPUTAddress] = REPLACE([INPUTAddress],'  ',' ')
		where [INPUTAddress] like '%  %'

		UPdate [zCust_TX_TAX].[dbo].[INPUT_IN]
		SET [INPUTAddress] = REPLACE([INPUTAddress],'  ',' ')
		where [INPUTAddress] like '%  %'

		Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
		where [INPUTAddress] like '%  %'

		UPdate [zCust_TX_TAX].[dbo].[INPUT_IN]
		SET [INPUTCity] = REPLACE([INPUTCity],'  ',' ')
		where [INPUTCity] like '%  %'

		Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
		where [INPUTCity] like '%  %'

		Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
		where len([INPUTState]) > 2

	
		Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
		where len([INPUTState]) < 2


		Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
		where len([INPUTZip]) > 10
		
		UPDATE [zCust_TX_TAX].[dbo].[a] 
		SET a.[InputState] = b.[State]
		FROM [zCust_TX_TAX].[dbo].[INPUT_IN] a JOIN [Global].[dbo].[StateNames] b
		on a.[InputState] = b.[StateName]
		where len(a.[InputState])>2 

			Select * From [zCust_TX_TAX].[dbo].[INPUT_IN]
			where len([InputState])>2
			and len([InputState])<4

			Update [zCust_TX_TAX].[dbo].[INPUT_IN]
			Set [InputState] = left(REPLACE([InputState],' ',''),2)
			where len([InputState])>2
			and len([InputState])<4

			Select * From [zCust_TX_TAX].[dbo].[INPUT_IN] where 
			len([InputState])>2

		UPDATE [zCust_TX_TAX].[dbo].[INPUT_IN] 
		SET [InputState] = NULL
		where len([InputState])>2




      EXEC [zCust_TX_TAX].[dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

			
		
			IF (SELECT COUNT(*) FROM [zCust_TX_TAX].[dbo].[TX_TAX_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_TX_TAX].[dbo].[TX_TAX_STD])
					END
			END


    EXEC [zCust_TX_TAX].[dbo].[usp_100c_sp_ASP_Cust_STD]

	Select FIPS, count(*) From [zCust_TX_TAX].[dbo].[a_ASP_IN_STD]
	Group by FIPS
	Order by FIPS

	Update [zCust_TX_TAX].[dbo].[A]
	set 
	A.FIPS = B.INPUTFIPS
	from [zCust_TX_TAX].[dbo].[a_ASP_IN_STD] as A 
	join [zCust_TX_TAX].[dbo].[INPUT_IN] as B on A.RAW_ID = B.INPUTKEY


	Update [zCust_TX_TAX].[dbo].[a_ASP_IN_STD]
	Set FIPS = RIGHT(('0' + convert(varchar(5),FIPS)),5)
	where FIPS not like '0'

	Select count(*) From [zCust_TX_TAX].[dbo].[a_ASP_IN_STD]
	Select count(*) From [zCust_TX_TAX].[dbo].[INPUT_IN]

			
		 -- ------New Process 20210203 to Prematch FLANK-----
			  
			 
			--  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[w_PreMatch]') AND type in (N'U'))
			--  DROP TABLE [dbo].[w_PreMatch]

			  
   --           SELECT Right('0' + FIPS,5) as FIPS, FullStreetAddress, City, State, Zip, ZIP4, convert(bigint,0) as PropertyID,'' as MulitMatch
			--  ,RAW_ID
			--  ,B.INPUTBorrowerLastName
   --           INTO [dbo].w_PreMatch
   --           --Select * 
			--  FROM [dbo].[a_ASP_IN_STD] as A 
			--  join INPUT_IN as B on A.RAW_ID = B.INPUTKey

			  

   --           Create index [ix_Addr] on [dbo].w_PreMatch(FIPS,FullStreetAddress,Zip,Zip4)

   --           DECLARE @FipsCode varchar(5)

   --           DECLARE Prematch CURSOR FOR  
   --                  SELECT Distinct [FIPS] 
   --                  FROM [dbo].w_PreMatch
   --                  WHERE LEN(FIPS)=5
   --                  ORDER BY [FIPS]


   --           OPEN Prematch   
   --           FETCH NEXT FROM Prematch INTO @FipsCode

   --           WHILE @@FETCH_STATUS = 0   
   --           BEGIN   
  
   --                  PRINT @FipsCode

   --                  EXEC('UPDATE a
   --                               SET a.PropertyID = b.Propertyid
   --                               FROM [dbo].[w_PreMatch] a JOIN zCust_ADS__00_SharedProcs.dbo.Property b with(NOLOCK)
   --                               on a.FIPS = b.FIPS
   --                               and a.FullStreetAddress = b.SitusStdFullStreetAddress
   --                               and a.Zip = b.SitusStdZIP5
   --                               and a.ZIP4 = b.SitusStdZIP4
   --                               WHERE a.FIPS = ''' + @FipsCode + '''
   --                               and b.FIPS = ''' + @Fipscode + '''
			--					  AND ISNULL(a.FullStreetAddress,'''') not like ''''
			--					  AND ISNULL(a.Zip,'''') not like ''''
   --                        ')


			--			   	EXEC('UPDATE a
   --                               SET a.PropertyID = NULL
   --                               FROM [dbo].[w_PreMatch] a 
			--					  JOIN zCust_ADS__00_SharedProcs.dbo.Property_DUPS b with(NOLOCK)
   --                               on a.FIPS = b.FIPS
   --                               and a.FullStreetAddress = b.SitusStdFullStreetAddress
   --                               and a.Zip = b.SitusStdZIP5
   --                               and a.ZIP4 = b.SitusStdZIP4
   --                               WHERE a.FIPS = ''' + @FipsCode + '''
   --                               and b.FIPS = ''' + @Fipscode + '''
   --                        ')
                     
   --                  FETCH NEXT FROM Prematch INTO @FipsCode   
   --           END   

   --           CLOSE Prematch   
   --           DEALLOCATE Prematch 


   --           Select count(*) from [dbo].[w_PreMatch]
   --           Select count(*) from [dbo].[w_PreMatch] where propertyid = 0

			--  Select * From [w_PreMatch]

			--  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INPUT_IN_PREMATCH]') AND type in (N'U'))
			--  DROP TABLE [dbo].[INPUT_IN_PREMATCH]


			-- Select * into dbo.[INPUT_IN_PREMATCH]
			-- From INPUT_IN

			-- Truncate table INPUT_IN

			-- Insert into INPUT_IN
			-- Select A.* From [INPUT_IN_PREMATCH] as A 
			-- join [w_PreMatch] as B on A.INPUTKey = B.RAW_ID
			-- join a_ASP_IN_STD as C on A.InputKey = C.RAW_ID
			-- where ISNULL(B.PropertyID,'0') like '0'
			-- and A.InputAddress not like 'P%'
			-- and C.FIPS not like '0'


			--Select count(*) From INPUT_IN
			--Select count(*) From [INPUT_IN_PREMATCH]
			
			


		-----------------------------------------------------

		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V6_DTDB] 'zCust_TX_TAX'
		EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK] 'zCust_TX_TAX'

			
	--				---Append Prematch records---
	--INSERT INTO dbo.[a_PropMatch_Work_FLANK]([ASP_ID]
	--			  ,[FullStreetAddress]
	--			  ,[HouseNbr]
	--			  ,[LeftDirection]
	--			  ,[Street]
	--			  ,[Mode]
	--			  ,[RightDirection]
	--			  ,[UnitNumber]
	--			  ,[City]
	--			  ,[State]
	--			  ,[Zip]
	--			  ,[Zip4]
	--			  ,[Zip9]
	--			  ,[FIPS]
	--			  ,[CountyName]
 --				  ,[BorrowerLastName]
	--			 ,[RAW_ID]
	--			 ,[INPUTAPN]
	--			 ,PropertyID)
	--			Select distinct A.[ASP_ID]
	--			  ,A.[FullStreetAddress]
	--			  ,A.[HouseNbr]
	--			  ,A.[LeftDirection]
	--			  ,A.[Street]
	--			  ,A.[Mode]
	--			  ,A.[RightDirection]
	--			  ,A.[UnitNumber]
	--			  ,a.[City]
	--			  ,a.[State]
	--			  ,a.[Zip]
	--			  ,a.[Zip4]
	--			  --,a.[zip]+isNULL(a.[zip4],'''') as [Zip9]
	--			  ,RIGHT(('0' + a.[zip]),5) + isNULL(a.[zip4],'') as [Zip9]
	--			  ,A.[FIPS]
	--			  ,A.[CountyName]
	--			  ,C.[INPUTBorrowerLastName]
	--			  ,A.[RAW_ID]
	--			  ,LEFT([InputAPN],50)
	--			  ,C.PropertyID
	--			   from dbo.[a_ASP_IN_STD] a 
	--			   left outer join w_PreMatch as C on A.RAW_ID = C.RAW_ID
	--			  LEFT OUTER JOIN [a_PropMatch_Work_FLANK] as B  
	--			  on a.[RAW_ID] = b.[RAW_ID]
	--			  where B.[RAW_ID] is null



	--			   Select count(*) From [a_PropMatch_Work_FLANK]
	--			 Select count(*) From [a_ASP_IN_STD]



		-- Post append clean up

		UPDATE [zCust_TX_TAX].[dbo].[a_PropMatch_Work_FLANK]
		Set PropertyID = NULL
		where PropertyID like '0'

		UPDATE [zCust_TX_TAX].[dbo].[a_PropMatch_Work_FLANK]
		SET Street = left([xMSmith].[dbo].[BeforeLastSpace](substring(street,1,LEN(Street)-(LEN(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%'
		, REVERSE(street)) - 1)))))),55)
		,UnitNumber = left(REVERSE(SUBSTRING(REVERSE(street), 1, PatIndex('%[a-z]%', REVERSE(street)) - 1)),15)
		WHERE REF_ID is null 
		AND Street like '% %[a-z][0-9]%[0-9]' or street like '% %[a-z][0-9]'
		

		UPDATE [zCust_TX_TAX].[dbo].[a_PropMatch_Work_FLANK]
		SET HouseNbr = left(REPLACE(HouseNbr,LeftDirection,''),30)
		WHERE isNULL(LeftDirection,'') not like '' AND HouseNbr like '%' + LeftDirection
		

		UPDATE [zCust_TX_TAX].[dbo].[a_PropMatch_Work_FLANK]
		SET INPUTAPN = NULL
		WHERE INPUTAPN = '0' or INPUTAPN = ''
	

	
		Update [zCust_TX_TAX].[dbo].[A]
		Set 
		A.REF_ID = B.DTDB_Ref_ID
		--Select A.RAW_ID, A.REF_ID, B.DTDB_Ref_ID, A.FullStreetAddress, B.SitusStdFullStreetAddress
		From [zCust_TX_TAX].[dbo].[a_PropMatch_Work_FLANK] as A 
		join [data].[dbo].[Property] as B with(NOLOCK) on 
		A.PropertyID = B.PropertyID
		where A.PropertyID is not null
		and (A.REF_ID is null or A.REF_ID <> B.DTDB_Ref_ID)
		and B.DTDB_Ref_ID is not null
		


	--	Select count(*) FRom [a_PropMatch_Work_FLANK] where REF_ID is null

	--Truncate table a_PropMatch_WORK
	--Insert into a_PropMatch_WORK
	--Select * From a_PropMatch_WORK_FLANK

	--Truncate table INPUT_IN
	--Insert into INPUT_IN
	--Select * From [INPUT_IN_PREMATCH]

		
	--	Select count(*) From INPUT_IN
	--	Select count(*) From a_PropMatch_WORK_FLANK
		
			--Select CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END as DTDB_AddrMatch, COUNT(*) as RecCount
			-- from dbo.a_PropMatch_WORK
			--group by CASE WHEN (REF_ID is NULL and MultiMatch is NULL) then 'Not Matched' 
			--WHEN (REF_ID is NULL and MultiMatch = 'M') then 'Multi Matched'
			--ELSE 'Matched' END

		--Truncate table a_PropMatch_WORK_FLANK
		--Insert into a_PropMatch_WORK_FLANK
		--Select * From a_PropMatch_WORK


		Select A.FIPS,A.RAW_ID, A.FullStreetAddress, A.PropertyID, B.PropertyID, A.INPUTAPN, A.MatchQuery, B.MatchQuery
		From [zCust_TX_TAX].[dbo].[a_PropMatch_WORK] as A 
		join [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as B on A.RAW_ID = B.RAW_ID
		where 
		ISNULL(A.Propertyid,'0') not like '0'
		and ISNULL(B.Propertyid,'0') like '0'

		Update [zCust_TX_TAX].[dbo].[B]
		set
		B.PropertyID = A.PropertyID
		,B.REF_ID = A.REF_ID
		From [zCust_TX_TAX].[dbo].[a_PropMatch_WORK] as A 
		join [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as B on A.RAW_ID = B.RAW_ID
		join [data].[dbo].[Property] as C with(NOLOCK) on A.PropertyID = C.PropertyID
		where 
		ISNULL(A.Propertyid,'0') not like '0'
		and ISNULL(B.Propertyid,'0') like '0'

	
		Select A.FIPS,A.RAW_ID, A.FullStreetAddress, A.PropertyID, B.PropertyID, A.INPUTAPN, A.MatchQuery, B.MatchQuery
		From [zCust_TX_TAX].[dbo].[a_PropMatch_WORK] as A 
		join [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as B on A.RAW_ID = B.RAW_ID
		where 
		ISNULL(B.Propertyid,'0') not like '0'
		and ISNULL(A.Propertyid,'0') like '0'



			Select CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as FLANK_AddrMatch, COUNT(*) as RecCount
			 from [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK]
			group by CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END


						
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.FIPS = B.INPUTFIPS
		--Select * 
		from [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A join [zCust_TX_TAX].[dbo].[INPUT_IN] as B on A.RAW_ID = B.INPUTKey
		where A.FIPS <> B.INPUTFIPS

			
		--/****** Object:  Index [NonClst_RefId_RecDt_DocNum]    Script Date: 9/11/2022 9:35:31 AM ******/
		--CREATE  NONCLUSTERED INDEX [IDX_FIPS_APN] ON a_PropMatch_WORK_FLANK
		--(
		--	FIPS ASC,
		--	INPUTAPN ASC
		--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	




		----FormattedAPN---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FIPS,D.[County Name],A.RAW_ID,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = REPLACE(C.FormattedAPN,'-','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		AND C.FAUCIDFlag not like 'D'

		
		

		----ADDING R---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN	,C.FormattedAPN,C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = 'R' + C.FormattedAPN
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'


		----REMOVING R---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN, REPLACE(C.FormattedAPN,'R','')
		--,C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = REPLACE(C.FormattedAPN,'R','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'



		----ADDING M---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN	,C.FormattedAPN,C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = 'M' + REPLACE(C.FormattedAPN,'-','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'

		
		----ADDING R0---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN	,C.FormattedAPN,C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and 'R0' + A.INPUTAPN = REPLACE(C.FormattedAPN,'-','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and 'R0' + A.INPUTAPN = REPLACE(C.FormattedAPN,'-','')
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			Group by A.RAW_ID
			having count(*) = 1)A)



		----REMOVING LAST CHAR if ALPHA---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN, LEFT(A.INPUTAPN,len(A.INPUTAPN)-1)
		--,C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and LEFT(A.INPUTAPN,len(A.INPUTAPN)-1) = REPLACE(C.FormattedAPN,'-','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and right(A.INPUTAPN,1) like '[a-Z]'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and LEFT(A.INPUTAPN,len(A.INPUTAPN)-1) = REPLACE(C.FormattedAPN,'-','')
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			and right(A.INPUTAPN,1) like '[a-Z]'
			Group by A.RAW_ID
			having count(*) = 1)A)


		----REMOVING LAST CHAR if ALPHA---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.FullStreetAddress, A.INPUTAPN, LEFT(A.INPUTAPN,len(A.INPUTAPN)-1)
		--,C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and LEFT(A.INPUTAPN,len(A.INPUTAPN)-1) = C.FormattedAPN
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and right(A.INPUTAPN,1) like '[a-Z]'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and LEFT(A.INPUTAPN,len(A.INPUTAPN)-1) = C.FormattedAPN
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			and right(A.INPUTAPN,1) like '[a-Z]'
			Group by A.RAW_ID
			having count(*) = 1)A)


		----REMOVING LEADING 0---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN))  = C.FormattedAPN
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		--Order by A.RAW_ID

		----REMOVING LEADING 0---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN))  = REPLACE(C.FormattedAPN,'-','')
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		--Order by A.RAW_ID


		----REMOVING LEADING 0 AND TRAILING ALPHA---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and LEFT(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)),len(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)))-1)
		= C.FormattedAPN
		join [global].[dbo].[county] as D with(NOLOCK) on A.FIPS = D.FIPSCODE
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and right(A.INPUTAPN,1) like '[a-Z]'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and LEFT(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)),len(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)))-1)
			= C.FormattedAPN
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			and right(A.INPUTAPN,1) like '[a-Z]'
			Group by A.RAW_ID
			having count(*) = 1)A)


		----------------------Variations of Tax Account number ONLY when there is 1 match!!-----------
		

		----TaxAccountNumber---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID, A.INPUTAPN, A.FullStreetAddress, C.FormattedAPN, C.TaxAccountNumber, C.SitusStdFullStreetAddress
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = REPLACE(C.TaxAccountNumber,'-','')
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and A.INPUTAPN = REPLACE(C.TaxAccountNumber,'-','')
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			Group by A.RAW_ID
			having count(*) = 1)A)

		-----Tax account num
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID, A.INPUTAPN, A.FullStreetAddress, C.FormattedAPN, C.TaxAccountNumber, C.SitusStdFullStreetAddress
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and A.INPUTAPN = C.TaxAccountNumber
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and A.INPUTAPN = C.TaxAccountNumber
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			Group by A.RAW_ID
			having count(*) = 1)A)
		


		----FIPS Remove leading R Use Tax Account Number---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN, C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and RIGHT(A.INPUTAPN,len(A.INPUTAPN)-1)	= C.TaxAccountNumber
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and left(A.INPUTAPN,1) like 'R'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and RIGHT(A.INPUTAPN,len(A.INPUTAPN)-1)	= C.TaxAccountNumber
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			and left(A.INPUTAPN,1) like 'R'
			Group by A.RAW_ID
			having count(*) = 1)A)



		----FIPS Remove leading 0 Use Tax Account Number---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FIPS,D.[County Name],A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN, C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
		and SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN))  = C.TaxAccountNumber
		where 
		ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [data].[dbo].[Property] as C with(NOLOCK) on A.FIPS = C.FIPS
			and SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN))  = C.TaxAccountNumber
			where 
			ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			Group by A.RAW_ID
			having count(*) = 1)A)
		
		
		
		----FIPS Remove leading 0 Use DTDB  ALTERNATE APN---
		Update [zCust_TX_TAX].[dbo].[A]
		set
		A.PropertyID = C.PropertyID
		,A.REF_ID = C.DTDB_REF_ID
		,A.MultiMatch = NULL
		--Select A.RAW_ID,A.FIPS,A.FullStreetAddress, A.INPUTAPN, C.FormattedAPN, C.TaxAccountNumber
		--, C.SitusStdFullStreetAddress,C.FAUCIDFlag, C.PropertyID, C.FATimestamp
		
		FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
		join [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] as D with(NOLOCK) on A.FIPS = D.FIPS
		and REPLACE(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)),'-','')  = REPLACE(D.ALTERNATE_APN,'-','')
		join [data].[dbo].[Property] as C with(NOLOCK) on D.FIPS = C.FIPS and D.REF_ID = C.DTDB_REF_ID
		where 
		D.FIPS like '48%'
		AND ISNULL(A.Propertyid,'0')  like '0'
		and C.FAUCIDFlag not like 'D'
		and A.RAW_ID in 
			(Select RAW_ID from (
			Select A.RAW_ID, count(*) as T
			FROM [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A 
			join [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] as D with(NOLOCK) on A.FIPS = D.FIPS
			and REPLACE(SUBSTRING(A.INPUTAPN, PATINDEX('%[^0]%', A.INPUTAPN), LEN(A.INPUTAPN)),'-','')  = REPLACE(D.ALTERNATE_APN,'-','')
			join [data].[dbo].[Property] as C with(NOLOCK) on D.FIPS = C.FIPS and D.REF_ID = C.DTDB_REF_ID
			where 
			D.FIPS like '48%'
			AND ISNULL(A.Propertyid,'0')  like '0'
			and C.FAUCIDFlag not like 'D'
			Group by A.RAW_ID
			having count(*) = 1)A)

		--Select A.FullStreetAddress, A.INPUTAPN, LEFT(A.INPUTAPN,len(A.INPUTAPN)-1) FROM a_PropMatch_WORK_FLANK as A
		--where INPUTAPN = '2775-077-115-000A'

		--Select * From data.dbo.Property as C with(NOLOCK)
		--where FIPS = '48491'
		--and 
		--(DTDB_REF_ID = 246242401
		----or situsstdfullstreetaddress like '7748 Wins%'
		--)

		--Select FIPSCODE, State, [County Name], SrcProperty From global.dbo.county where FIPSCODE = '48491'

		--Select * From  [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] A with(NOLOCK)
		--where FIPS = 48491
		--and FORMATTED_APN in ('R664525')

		--Select FIPS, PropertyID, FormattedAPN, DTDB_Ref_ID, FADateReceived, FATimestamp, FAUCIDFlag
		-- From data.dbo.Property with(NOLOCK)
		--where  FIPS = '48491'
		--and DTDB_Ref_ID in (246242401)

		--Select FIPS, PropertyID, FormattedAPN, DTDB_Ref_ID, FADateReceived, FATimestamp, FAUCIDFlag
		-- From data.dbo.Property with(NOLOCK)
		--where  FIPS = '48327'
		--and
		--( DTDB_Ref_ID in (132567309) or SitusStdFullStreetAddress like '7748%'
		--or FormattedAPN like '01794%')

		--Select * 
		--FROM [AZUVPSQLDTDB029.datatree.local].[ADB].[dbo].[md_assessment] a with(NOLOCK) 
		--WHERE CountyFIPS = 48491
		--and APN = '01794-0046-100-00'

			

			Select A.FIPS, C.[County Name],C.SrcProperty,A.FULLSTREETADDRESS, A.STATE, A.INPUTAPN,CASE WHEN (PropertyID is NULL and MultiMatch is NULL) then 'Not Matched' 
			WHEN (PropertyID is NULL and MultiMatch = 'M') then 'Multi Matched'
			ELSE 'Matched' END as FLANK_AddrMatch
			,B.INPUTFIPS, A.PropertyID, A.MatchQuery
			 from [zCust_TX_TAX].[dbo].[a_PropMatch_WORK_FLANK] as A join [zCust_TX_TAX].[dbo].[INPUT_IN] as B on A.RAW_ID = B.INPUTKey
			 join [global].[dbo].[county] as C with(NOLOCK) on A.FIPS = C.FIPSCODE
			where PropertyID is NULL
			--and A.FullStreetaddress like '714%'
			Order by FIPS


			 --Select A.*
			 --from dbo.INPUT_RAW_20260420_2 as A 
			 --left outer join a_PropMatch_WORK_FLANK as B on A.unique_id = B.RAW_ID
			 --where B.PropertyID is null
			 --and ISNULL(A.unique_id,'') not like ''


	
	--Select count(*) from a_PropMatch_Work_FLANK
		
	--Insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.[a_PropMatch_Work](ASP_ID,FullStreetAddress,HouseNbr,LeftDirection,Street,Mode,
	--RightDirection,UnitNumber,City,State,Zip,Zip4,Zip9,FIPS,CountyName,BorrowerLastName,RAW_ID,REF_ID,MultiMatch,INPUTAPN,PropertyID,MatchQuery)
	
	--Select  ASP_ID,FullStreetAddress,HouseNbr,LeftDirection,Street,Mode,RightDirection,UnitNumber,City,State,Zip,Zip4,Zip9,FIPS,CountyName,
	--BorrowerLastName,RAW_ID,REF_ID,MultiMatch,INPUTAPN,PropertyID,MatchQuery From a_PropMatch_Work_FLANK with(NOLOCK)
	--where REF_ID is not null



	--EXEC dbo.usp_502_Pull_FLANK_DATA

	--EXEC dbo.usp_502_Pull_DTDB_DATA_V2

	




END



