/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.Marketshare_Attorney | type=P */

-- =============================================
-- Author:		My Phan
-- Create date: 2025-04-08
-- Description:	Attorney fields for title marketshare
-- =============================================

CREATE PROCEDURE [MiNelson].[dbo].[Marketshare_Attorney]

AS
BEGIN

-------First time
-- 	IF OBJECT_ID('[MiNelson].[mktshr].Attorney') IS NOT NULL
--		DROP TABLE [MiNelson].[mktshr].Attorney;

-- SELECT a.Deedid, a.DeedSequence, a.Attorney
----,[Attorney_Full_Name]
--       ,[Attorney_Address]
--      ,[Attorney_Address_City]
--      ,[Attorney_Address_State]
--      ,[Attorney_Address_Zip]
--      ,[Attorney_Phone]
      
--	  ,[Attorney_Email]
--	  , CONVERT(varchar(10), GETDATE(),112) as [Rundate]
--	  Into [MiNelson].[mktshr].Attorney
--from  [MiNelson].[mktshr].[TitleMarketShare] a
--left join Deed.dbo.deed b
--on a.Deedid = b.deedid
-- where rundate=(select max(rundate) from MiNelson.mktshr.TitleMarketShare)

-- select * from [MiNelson].[mktshr].[Attorney]

 --and a.attorney <> 'unknown'
 --and a.attorney = [Attorney_Full_Name]


 
 -------------------Incremental -----------------------------------------

 	/*IF OBJECT_ID('[MiNelson].[mktshr].Attorney_incremental') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[mktshr].[Attorney_incremental];

CREATE TABLE [Minelson].[mktshr].[Attorney_incremental](
	[Deedid] [int] NULL,
	[DeedSequence] [int] NULL,
	[Attorney] [varchar](60) NULL,
	[Attorney_Firm] [varchar](60)  NULL,
	[Attorney_Address] [varchar](60) NULL,
	[Attorney_Address_City] [varchar](30) NULL,
	[Attorney_Address_State] [varchar](4) NULL,
	[Attorney_Address_Zip] [varchar](9) NULL,
	[Attorney_Phone] [varchar](15) NULL,
	[Attorney_Email] [varchar](100) NULL,
	[Rundate] [varchar](10) NULL
) ON [PRIMARY]


insert into [MiNelson].[mktshr].[Attorney_incremental]
(Deedid, DeedSequence, Attorney
,[Attorney_Firm]
  , [Attorney_Address]
      ,[Attorney_Address_City]
      , [Attorney_Address_State]
      ,[Attorney_Address_Zip]
      , [Attorney_Phone]
      
	  , [Attorney_Email]
	  , Rundate
	  )
(
 SELECT a.Deedid, a.DeedSequence, a.Attorney
, null [Attorney_Firm]
       ,null [Attorney_Address]
      ,null [Attorney_Address_City]
      ,null [Attorney_Address_State]
      ,null [Attorney_Address_Zip]
      ,null [Attorney_Phone]
      
	  ,null [Attorney_Email]
	 ,CONVERT(varchar(10), GETDATE(),112) as [Rundate]
from  [MiNelson].[mktshr].[TitleMarketShare] a
 where rundate=(select max(rundate) from [MiNelson].[mktshr].[TitleMarketShare])
)


update [MiNelson].[dbo].[a]
set a.Attorney_address = b.Attorney_address,
a.Attorney_Address_City = b.Attorney_Address_City,
a.Attorney_Address_State = b.Attorney_Address_State,
a.Attorney_Address_Zip = b.Attorney_Address_Zip,
a.Attorney_Email = b.Attorney_Email,
a.Attorney_Phone = b.Attorney_Phone
from [MiNelson].[mktshr].[Attorney_incremental] a
inner join [Deed].[dbo].[deed] b
on a.Deedid = b.deedid
where attorney <> 'Unknown' and Attorney = [Attorney_Full_Name]


update [MiNelson].[dbo].[a]
set a.Attorney_Firm = b.Attorney_Firm_Name,
 a.Attorney_address = b.Attorney_address,
a.Attorney_Address_City = b.Attorney_Address_City,
a.Attorney_Address_State = b.Attorney_Address_State,
a.Attorney_Address_Zip = b.Attorney_Address_Zip,
a.Attorney_Email = b.Attorney_Email,
a.Attorney_Phone = b.Attorney_Phone
-- select * 
from [MiNelson].[mktshr].[Attorney_incremental] a
inner join [Deed].[dbo].[deed] b
on a.Deedid = b.deedid
where a.Attorney_Firm is null and b.Attorney_Firm_Name is not null


--select * 
--from [MiNelson].[mktshr].Attorney_incremental a
--where attorney <> 'Unknown'
--and Attorney_Address_State not in ( 'IL', 'Ny', 'NJ')


--- Insert into main table

  Delete t
  --select *
   from  [MiNelson].[mktshr].[Attorney_incremental] f
   inner join  [MiNelson].[mktshr].[Attorney] t
on f.DeedID = t.DeedID and f.DeedSequence = t.DeedSequence

insert into [MiNelson].[mktshr].[Attorney]
( [Deedid]
      ,[DeedSequence]
      ,[Attorney]
      ,[Attorney_Firm]
      ,[Attorney_Address]
      ,[Attorney_Address_City]
      ,[Attorney_Address_State]
      ,[Attorney_Address_Zip]
      ,[Attorney_Phone]
      ,[Attorney_Email]
      ,[Rundate])
(SELECT  [Deedid]
      ,[DeedSequence]
      ,[Attorney]
      ,[Attorney_Firm]
      ,[Attorney_Address]
      ,[Attorney_Address_City]
      ,[Attorney_Address_State]
      ,[Attorney_Address_Zip]
      ,[Attorney_Phone]
      ,[Attorney_Email]
      ,[Rundate]
  FROM [MiNelson].[mktshr].[Attorney_incremental]
  )

  --- select * from [MiNelson].[mktshr].[Attorney]
  --- select * from [MiNelson].[mktshr].Attorney_incremental

END


