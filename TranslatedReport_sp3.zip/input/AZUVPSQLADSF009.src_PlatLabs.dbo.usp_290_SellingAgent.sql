SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	parse CoAgent data
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_290_SellingAgent]

AS
BEGIN

	SET NOCOUNT ON;

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		TRUNCATE TABLE [agent].[SellingAgents_Batch]

		INSERT INTO [src_platlabs].[agent].[SellingAgents_Batch]
		Select agentid
		,agentUID
		,[mls_id]
		,[mls_listing_id]
		,agentName [name]
		,agentFirstName
		,agentLastName
		,agentEmail
		,agentPhone
		,agentLicenseNumber
		,office
		,officeID
		,officeName
		,officePhone
		,officeUID
		,GetDate() as LoadDate
		,[state] as PropertyState
		 from (Select mls_id,mls_listing_id,[state],[agents_selling_agent],a.id agentid,a.[uid] agentUID,a.[name] agentName,first_name agentFirstName
		 ,last_name agentLastName,email agentEmail,a.phone agentPhone,license_number agentLicenseNumber,office office,office_array.id officeID,office_array.name officeName,office_array.phone officePhone,office_array.uid officeUID
		FROM (Select mls_id,mls_listing_id,[state],[agents_selling_agent],id,Agent_Array.[uid],[name],first_name,last_name,email,phone,license_number,office
		from [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK)
				CROSS APPLY OPENJSON([agents_selling_agent]) WITH(
					id varchar(100)
					  ,uid varchar(100)
					  ,name varchar(100)
					  ,first_name varchar(50)
					  ,last_name varchar(50)
					  ,email varchar(200)
					  ,phone varchar(25)
					  ,license_number varchar(50)
					  ,office nvarchar(max) AS JSON
					 ) as Agent_Array) a
						CROSS APPLY OPENJSON([office]) WITH(
						[id] varchar(100)
						,[name] varchar(100)
						,[phone] varchar(25)
						,[uid] varchar(100)
						) as office_array) agentdata

		Delete from [src_PlatLabs].[agent].[SellingAgents_Batch] where [agent_id] is NULL

		Delete from [src_PlatLabs].[dbo].[a]
			FROM [src_PlatLabs].[agent].[SellingAgents] a 
				JOIN [src_PlatLabs].[agent].[SellingAgents_Batch] b
			ON a.mls_id = b.mls_id
			and a.mls_listing_id = b.mls_listing_id

		insert into [src_PlatLabs].[agent].[SellingAgents]
		Select * from [src_PlatLabs].[agent].[SellingAgents_Batch] WITH(NOLOCK)
		
			Select distinct mls_id,agent_id,agent_Email,agent_Phone into #p from [src_PlatLabs].[agent].[ListAgents] with(NOLOCK)

			create index ix on #p(mls_id,agent_id)

			UPDATE [src_PlatLabs].[dbo].[a]
			SET a.preferred_phone_number = b.agent_Phone
			,a.standardized_preferred_phone_number = b.agent_Phone
			,a.LoadDate = GETDATE()
			from [src_PlatLabs].[agent].[Platlabs_agents] a JOIN #p b 
			on a.mls_id = b.mls_id
			and a.dp_member_id = b.agent_id
			where a.preferred_phone_number is NULL 
			and b.agent_Phone is not null

			UPDATE [src_PlatLabs].[dbo].[a]
			SET a.email = b.agent_Email
			,a.LoadDate = GETDATE()
			from [src_PlatLabs].[agent].[Platlabs_agents] a JOIN #p b 
			on a.mls_id = b.mls_id
			and a.dp_member_id = b.agent_id
			where a.email is NULL 
			and b.agent_Email is not null

			DROP TABLE IF exists #p
 
				---- ADDED 20251001 to try to link more Agent IDs
				 UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.full_name
				and a.agent_Email = b.email
				where isNULL(agent_ListAgentFullName,'') not like ''
				and isNULL(agent_id,'') like ''


				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.full_name
				and replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ','') = replace(replace(replace(replace(b.cellphone_number,'-',''),')',''),'(',''),' ','')
				where isNULL(agent_ListAgentFullName,'') not like ''
				and isNULL(agent_id,'') like ''
				and LEN(replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ',''))=10


				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.full_name
				and replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ','') = replace(replace(replace(replace(b.preferred_phone_number,'-',''),')',''),'(',''),' ','')
				where isNULL(agent_ListAgentFullName,'') not like ''
				and isNULL(agent_id,'') like ''
				and LEN(replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ',''))=10


				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_LastName = b.last_name
				and a.agent_LicenseNumber = b.license_number
				where isNULL(agent_LastName,'') not like ''
				and isNULL(agent_id,'') like ''
				and isNULL(a.agent_LicenseNumber,'') not like ''

				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				--Select agent_Email,email
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.full_name
				where isNULL(agent_ListAgentFullName,'') not like ''
				and b.email LIKE agent_Email + '%'
				and isNULL(agent_id,'') like ''
				and isNULL(agent_Email,'') not like ''

				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.dp_member_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN [src_Platlabs].[agent].[Platlabs_agents] b
				on a.mls_id = b.mls_id
				and a.agent_FirstName = b.first_name
				and replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ','') = replace(replace(replace(replace(b.preferred_phone_number,'-',''),')',''),'(',''),' ','')
				where isNULL(agent_id,'') like ''
				and isNULL(agent_Email,'') not like ''
				and isNULL(a.agent_Phone,'') not like ''
				and b.email LIKE a.agent_Email + '%'


				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.agent_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN (Select agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone from [src_Platlabs].[agent].[ListAgents] group by agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone) b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.agent_ListAgentFullName
				and replace(replace(replace(replace(a.agent_Phone,'-',''),')',''),'(',''),' ','') = replace(replace(replace(replace(b.agent_Phone,'-',''),')',''),'(',''),' ','')
				where isNULL(a.agent_ListAgentFullName,'') not like ''
				and isNULL(a.agent_id,'') like ''
				and isNULL(b.agent_id,'') NOT like ''
				and b.agent_Email LIKE a.agent_Email + '%'
				and isNULL(a.agent_Email,'') not like ''

				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.agent_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN (Select agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone from [src_Platlabs].[agent].[ListAgents] group by agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone) b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.agent_ListAgentFullName
				and a.agent_LicenseNumber = b.agent_LicenseNumber
				where isNULL(a.agent_ListAgentFullName,'') not like ''
				and isNULL(a.agent_id,'') like ''
				and isNULL(b.agent_id,'') NOT like ''
				and isNULL(a.agent_LicenseNumber,'') not like ''

				UPDATE [src_PlatLabs].[dbo].[a]
				SET a.agent_id = b.agent_id
				from [src_Platlabs].[agent].[SellingAgents] a JOIN (Select agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone from [src_Platlabs].[agent].[ListAgents] group by agent_id,mls_id,agent_ListAgentFullName,agent_LicenseNumber,agent_Email,agent_Phone) b
				on a.mls_id = b.mls_id
				and a.agent_ListAgentFullName = b.agent_ListAgentFullName
				and a.agent_Email = b.agent_Email
				where isNULL(a.agent_ListAgentFullName,'') not like ''
				and isNULL(a.agent_id,'') like ''
				and isNULL(b.agent_id,'') NOT like ''
				and isNULL(a.agent_Email,'') not like ''


		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




