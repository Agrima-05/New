SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE procedure [src_PlatLabs].[dbo].[usp_100c_sp_ASP_Platlabs_STD]
as  

-- Trim all fields, make some fields uppdercase, rebuild FullStreetAddress and CensusTractBlock fields
	   INSERT INTO [src_PlatLabs].[dbo].[a_ASP_IN_STD](ASP_ID
	   ,RAW_ID
	   ,[FullStreetAddress]
       ,[HouseNbr]
       ,[LeftDirection]
       ,[Street]
       ,[Mode]
       ,[RightDirection]
       ,[UnitNumber]
       ,[City]
       ,[State]
       ,[Zip]
       ,[ZIP4]
       ,[Latitude]
       ,[Longitude]
       ,[CarrierCode]
	   ,[CensusTract]
       ,[CensusTractBlock]
       ,[UnitType]
       ,[MatchCode]
       ,[DPVCount]
       ,[DPVFootnote]
       ,[LACS]
       ,[LACSLinkInd]
       ,[DPCheckDigit]
       ,[DPCheckCode]
       ,[CensusBlock]
       ,[GeoErrorCode]
       ,[GeoStatusCode]
       ,[GeoCoded]
	   ,[FIPS]
	   ,[AddressMatchResults]
	   ,[CountyName])
	   SELECT recordid
	   ,b.Raw_id
	   ,LEFT(Rtrim(Rtrim(Rtrim(Rtrim(Rtrim(Rtrim(Ltrim(Rtrim([StreetNumber])) + ' ' + Ltrim(Rtrim([PreDir]))) + ' ' + Ltrim(Rtrim([StreetName]))) + ' ' + Ltrim(Rtrim([StreetType]))) + ' ' + Ltrim(Rtrim([PostDir])))  + ' ' + Ltrim(Rtrim([SuiteType]))) + ' ' + Ltrim(Rtrim([Suite]))),116)
	   ,ltrim(rtrim([StreetNumber]))
       ,UPPER(ltrim(rtrim([PreDir])))
       ,LEFT(UPPER(ltrim(rtrim([StreetName]))),55)
       ,UPPER(ltrim(rtrim([StreetType])))
       ,UPPER(ltrim(rtrim([PostDir])))
       ,UPPER(ltrim(rtrim([Suite])))
       ,UPPER(ltrim(rtrim(a.[City])))
       ,UPPER(ltrim(rtrim(a.[State])))
       ,ltrim(rtrim([Zip]))
       ,ltrim(rtrim([Plus4]))
       ,ltrim(rtrim([Latitude]))
       ,ltrim(rtrim([Longitude]))
       ,ltrim(rtrim([CarrierRoute]))
	   ,ltrim(rtrim([CensusTract]))
       ,ltrim(rtrim([CensusTract])) + ltrim(rtrim([CensusBlock]))
       ,UPPER(ltrim(rtrim([SuiteType])))
       ,ltrim(rtrim([AddressTypeCode]))
       ,ltrim(rtrim([DPVCount]))
       ,ltrim(rtrim([DPVFootnotes]))
       ,ltrim(rtrim([LACS]))
       ,ltrim(rtrim([LACSLinkIndicator]))
       ,ltrim(rtrim([DeliveryPointCheckDigit]))
       ,ltrim(rtrim([DeliveryPointCode]))
       ,ltrim(rtrim([CensusBlock]))
       ,ltrim(rtrim([GeoErrorCode]))
       ,ltrim(rtrim([GeoStatusCode]))
       ,ltrim(rtrim([GeoCoded]))
	   ,ltrim(rtrim([CountyFips]))
	   ,ltrim(rtrim([AddressMatchResults])) 
	   ,ltrim(rtrim([CountyName]))
     From [src_PlatLabs].[dbo].[Platlabs_STD] a with(NOLOCK) JOIN [src_PlatLabs].[dbo].[a_ASP_IN] b with(NOLOCK)
	 on a.RecordID = b.ASP_ID

	 


