SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_PrimeLending].[dbo].[usp_502_Pull_FLANK_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK
		UPDATE [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK]
		SET FIPS = '0' + FIPS
		WHERE LEN(FIPS)=4

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_PrimeLending].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SaleDate,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		,a.Loan1LenderName as NewLenderAssignee
		,A.CMTIDInstNbr, A.Loan1CMTIDInstNbr, A.Loan2CMTIDInstNbr
		INTO [zCust_PrimeLending].[dbo].[w_FLANK_DEEDS]
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.DeedTransactionType = t.TransType
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES

		IF  EXISTS (SELECT * FROM [zCust_PrimeLending].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower,LenderName AS SellerLender,LoanAmount,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.LenderName as NewLenderAssignee,ContractDate
		,CMTIDInstNbr
		INTO [zCust_PrimeLending].[dbo].[w_FLANK_MTG]
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d  with(NOLOCK)
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.LoanTransType = t.TransType
		WHERE a.FAUCIDFlag not like 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_PrimeLending].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,Loan1TransactionID,FAPropertyID,Loan1RecordingDt,Loan1Document,Loan1Book,Loan1Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan1LenderName AS SellerLender,Loan1Amount,Loan1DocumentTypeCode,d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.Loan1LenderName as NewLenderAssignee,NULL
		,Loan1CMTIDInstNbr as CMTIDInstNbr
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan1TransactionType Like t.TransType
		WHERE a.FAUCIDFlag not like  'D' and Loan1RecordingDt is not null
		--and A.TransactionId not like '1140874887'
		ORDER BY RAW_ID,RecordingDt 

		INSERT INTO [zCust_PrimeLending].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,Loan2TransactionID,FAPropertyID,Loan2RecordingDt,Loan2Document,Loan2Book,Loan2Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan2LenderName AS SellerLender,Loan2Amount,Loan2DocumentTypeCode,d.CodeDesc as DocType
		,Loan2TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] ,REF_ID
		,a.Loan2LenderName as NewLenderAssignee,NULL
		,Loan2CMTIDInstNbr as CMTIDInstNbr
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.Loan2DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t  with(NOLOCK)
		on a.Loan2TransactionType Like t.TransType
		WHERE a.FAUCIDFlag not like  'D' and Loan2RecordingDt is not null
		--and A.TransactionId not like '1140874887'
		ORDER BY RAW_ID,RecordingDt 

		----ASSIGN/REL

		IF  EXISTS (SELECT * FROM [zCust_PrimeLending].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'A' as DocSrcInd,[ChronoKey],Assignee,AssignorName as Assignor,REF_ID
		,a.Assignee1CompanyName as NewLenderAssignee,AssignorName as OldLenderAssignor
		INTO [zCust_PrimeLending].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_PrimeLending].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt
		, 'R' as DocSrcInd,[ChronoKey],NULL,NULL,REF_ID
		,a.OrigLenderBen as NewLenderAssignee, NULL
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		--LEFT OUTER JOIN [Global].dbo.[Lkup_Doc_Type] d with(NOLOCK)
		--	on a.DocumentType = d.DocTypeID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on convert(varchar(200),a.DocumentType) = 
			case 
			when ISNUMERIC(a.DocumentType) = 1 then convert(varchar(200),d.DocTypeID)
			when ISNUMERIC(a.DocumentType) = 0 then convert(varchar(200),d.FACode)
			END
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt


		UPDATE [zCust_PrimeLending].[dbo].[w_Flank_ASR]
		SET OrigDeedRecordingDt = NULL
		where isDATE(OrigDeedRecordingDt)=0

		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_PrimeLending].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType,REF_ID
		INTO [zCust_PrimeLending].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_PrimeLending].[dbo].[a_PropMatch_Work_FLANK] b
		on a.FIPS = b.FIPS
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d with(NOLOCK)
			on a.DocumentType = d.DocTypeID
		WHERE a.FAUCIDFlag <> 'D'
		ORDER BY RAW_ID,RecordingDt

		

		---- CREATE TransHist 
		SET CONCAT_NULL_YIELDS_NULL OFF
		TRUNCATE TABLE w_TransHist_FLANK
			DROP INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]

		INSERT INTO [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN  CMTIDInstNbr is null and  [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce 
					WHen CMTIDInstNbr is null and  [DocNbrSrce] is not null then [DocNbrSrce] ELSE CMTIDInstNbr END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,SaleDate
			FROM [zCust_PrimeLending].[dbo].[w_FLANK_DEEDS]


		INSERT INTO [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[DocDate])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentTypeCode]
			  ,CASE WHEN  CMTIDInstNbr is null and  [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce 
					WHen CMTIDInstNbr is null and  [DocNbrSrce] is not null then [DocNbrSrce] ELSE CMTIDInstNbr END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,NewLenderAssignee
			  ,NULL
			  ,ContractDate
		FROM [zCust_PrimeLending].[dbo].[w_FLANK_MTG]

		INSERT INTO [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			  ,left([BuyerBorrower],250)
			  ,NULL
			  ,NULL
			  ,OrigDeedRecordingDt
			  ,case When OrigDeedDocNbr is null then OrigDeedBook + '.' + OrigDeedPage ELSE  OrigDeedDocNbr END
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,left([NewLenderAssignee],250)
			  ,left([OldLenderAssignor],250)
			  ,[OrigLoanAmt]
		FROM [zCust_PrimeLending].[dbo].[w_FLANK_ASR]

		INSERT INTO [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey]
			  ,[NewLenderAssignee]
			  ,[OldLenderAssignor]
			  ,[OrigLoanAmount])
		SELECT Distinct FIPS
			  ,FAPropertyID
			  ,NULL
			  ,convert(varchar(10),convert(date,[RecordingDt]),101)
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigNODDocumentNbr
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[TransactionID]
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
			  ,OrigBeneficiaryLender
			  ,NULL
			  ,OrigLoanAmt
		FROM [zCust_PrimeLending].[dbo].[w_FLANK_NOD]

		CREATE NONCLUSTERED INDEX [ix_FipsDocID] ON [dbo].[w_TransHist_FLANK]
		([Fips] ASC,
			[Doc_Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)



		UPDATE [zCust_PrimeLending].[dbo].[a]
		SET FA_DocNbrFmt = c.FA_DocNbrFmt
		,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		,FA_BookPageFmt = c.FA_BookPageFmt
		,FA_YearBookPageFmt = c.FA_YearBookPageFmt
        ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
        ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
        ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
        ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
        ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		FROM [zCust_PrimeLending].[dbo].[w_TransHist_FLANK] a 
		JOIN (Select * from [global].[dbo].[Transaction_Master] with(NOLOCK)
		WHERE FIPS in(Select Distinct FIPS from [zCust_PrimeLending].[dbo].[w_TransHist_FLANK])) c
		on a.FIPS = c.FIPS
		and a.Doc_Id = c.TransactionID
		Where a.Doc_ID is not null and a.Doc_ID not like ''
		and a.Doc_ID not like 'unknown'
		and a.Doc_ID not like '0.0'

		--UPDATE a
		--SET FA_DocNbrFmt = c.FA_DocNbrFmt
		--,FA_YearDocNbrFmt = c.FA_YearDocNbrFmt
		--,FA_YearDayDocNumFmt = c.FA_YearDayDocNumFmt
		--,FA_BookPageFmt = c.FA_BookPageFmt
		--,FA_YearBookPageFmt = c.FA_YearBookPageFmt
  --      ,[FA_CMTID_DocNum] = c.[FA_CMTID_DocNum]
  --      ,[FA_CMTID_YearDocNum] = c.[FA_CMTID_YearDocNum]
  --      ,[FA_CMTID_YearDateDocNum] = c.[FA_CMTID_YearDateDocNum]
  --      ,[FA_CMTID_BookPage] = c.[FA_CMTID_BookPage]
  --      ,[FA_CMTID_YearBookPage] = c.[FA_CMTID_YearBookPage]
		--FROM w_TransHist_FLANK a 
		--JOIN global.dbo.Transaction_Master c with(NOLOCK)
		--on a.FIPS = c.FIPS
		--and a.Doc_Id = c.TransactionID
		--Where C.FIPS in(Select Distinct FIPS from w_TransHist_FLANK)
		--and A.Doc_ID is not null and A.Doc_ID not like ''
		--and A.Doc_ID not like 'unknown'
		--and A.Doc_ID not like '0.0'

		--UPDATE a 
		--set a.REF_ID = b.REF_ID
		--FROM w_transHist_Flank a JOIN a_PropMatch_Work_FLANK b
		--on convert(int,a.Fips) = convert(int,b.Fips)
		--and a.ref_id = b.propertyID

		  UPDATE [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]
		  SET CmtID = case when FA_CMTID_YearDocNum is not null then FA_CMTID_YearDocNum
			WHEN FA_CMTID_BookPage is not null then FA_CMTID_BookPage
			WHEN FA_CMTID_YearDAteDocNum is not null then FA_CMTID_YearDAteDocNum
			WHEN FA_CMTID_DocNum is not null then FA_CMTID_DocNum
			WHEN FA_CMTID_YearBookPage is not null then FA_CMTID_YearBookPage
			END

		  UPDATE [zCust_PrimeLending].[dbo].[w_TransHist_FLANK]
		  SET CmtID = 1091
		  WHERE FIPS = 17031

		  UPDATE [zCust_PrimeLending].[dbo].[a]
		  Set A.WORK_REF_ID = B.DTDB_Ref_ID
		  FROM [zCust_PrimeLending].[dbo].[w_TransHist_FLANK] a 
			JOIN [data].[dbo].[Property] as B With(NOLOCK)
			on A.REF_ID = B.PropertyID
			where A.REF_ID is not null
END





