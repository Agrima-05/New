/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | UR.lienMailingAddrStd | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE
	

 PROCEDURE [Lien].[UR].[lienMailingAddrStd]
AS
-- lienMailingAddrStd
-- Situs match
--
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'lienMailingAddrStd'
	,N'Started'

--CREATE INDEX idx_address_Name_id ON Lien.UR.NAME ([address]) include (name_id)

--
-- Identify all Names with addresses that we dont have a Nmae_Std_AAddress for
--
DROP TABLE

IF EXISTS #addr
	SELECT a.name_id
	INTO #addr
	FROM [Lien].[UR].[NAME] a WITH (
			NOLOCK
			,INDEX (idx_address_Name_id)
			)
	LEFT JOIN [Lien].[UR].[NAME_Std_Address] p WITH (
			NOLOCK
			,INDEX (PK_Name_Std_Address)
			) ON p.Name_id = a.Name_id
	WHERE a.[address] IS NOT NULL
		AND p.Name_id IS NULL

CREATE INDEX idx_name_id ON #addr (name_id)

BEGIN TRANSACTION

INSERT INTO [Lien].[UR].[NAME_STD_ADDRESS] (
	[Name_id]
	,[Fips]
	,[Ref_id]
	,[Match_code]
	,[Apn]
	,[HouseNumber]
	,[Street_Number]
	,[Direction]
	,[Street_Name]
	,[Street_Type]
	,[Post_Direction]
	,[Unit_Type]
	,[Unit]
	,[City]
	,[STATE]
	,[Zip]
	,[Plus4]
	,[CRRT]
	,[CountyName]
	,[PMB]
	,[PMSA]
	,[MSA]
	,[ZipType]
	,[Urbanization]
	,[CongressionalDistrict]
	,[CountryCode]
	,[CityAbbreviation]
	,[AddressTypeCode]
	,[AddressTypeString]
	,[DPV_Count]
	,[DPV_Footnotes]
	,[CMRA]
	,[ELOT_Number]
	,[ELOT_Order]
	,[LACS]
	,[LACS_LinkIndicator]
	,[EWS_Flag]
	,[RBDI]
	,[SuiteLinkReturnCode]
	,[DeliveryPointCheckDigit]
	,[DeliveryPointCode]
	,[CensusBlock]
	,[CensusTract]
	,[PlaceCode]
	,[PlaceName]
	,[CBSACode]
	,[CBSALevel]
	,[CBSATitle]
	,[CBSADivisionCode]
	,[CBSADivisionLevel]
	,[CBSADivisionTitle]
	,[Latitude]
	,[Longitude]
	,[Verified]
	,[Geocoded]
	,[AddressMatchResults]
	,[GeoErrorCode]
	,[GeoStatusCode]
	,[AddressType]
	--,[UpdateDate]
	,[m_create_date]
	)
OUTPUT NULL AS Doc_id
	,inserted.Name_id AS Name_id
	,NULL AS property_id
	,NULL AS reference_id
	,inserted.m_create_date
	,'usp_UpdateMailingAddrAssrMatchPET' AS Process_name
INTO [lien].[ur].[document_transaction_log]
SELECT a.Name_id
	,a.Fips
	,NULL AS Ref_id
	--,substring(a.Match_code,1,4) as Match_code
	,NULL AS Match_code
	--,substring(' ',1,60) as Apn    
	,NULL AS Apn
	,substring(a.Street_Number, 1, 30) AS HouseNumber
	,substring(a.Street_Number, 1, 50) AS Street_Number
	,substring(a.Direction, 1, 2) AS Direction
	,substring(a.Street_Name, 1, 60) AS Street_Name
	,substring(a.Street_Type, 1, 4) AS Street_Type
	,substring(a.Post_Direction, 1, 2) AS Post_Direction
	,substring(a.Unit_Type, 1, 50) AS Unit_Type
	,substring(a.Unit, 1, 50) AS Unit
	,substring(a.City, 1, 55) AS City
	,substring(a.STATE, 1, 2) AS STATE
	,substring(a.Zip, 1, 50) AS Zip
	,substring(a.Plus4, 1, 4) AS Plus4
	,substring(a.CRRT, 1, 4) AS CRRT
	,substring(a.CountyName, 1, 50) AS CountyName
	,substring(a.PMB, 1, 30) AS PMB
	,substring(a.PMSA, 1, 2) AS PMSA
	,substring(a.MSA, 1, 70) AS MSA
	,substring(a.ZipType, 1, 2) AS ZipType
	,substring(a.Urbanization, 1, 6) AS Urbanization
	,substring(a.CongressionalDistrict, 1, 2) AS CongressionalDistrict
	,substring(a.CountryCode, 1, 50) AS CountryCode
	,substring(a.CityAbbreviation, 1, 50) AS CityAbbreviation
	,substring(a.AddressTypeCode, 1, 1) AS AddressTypeCode
	,substring(a.AddressTypeString, 1, 60) AS AddressTypeString
	,substring(a.DPV_Count, 1, 5) AS DPV_Count
	,substring(a.DPV_Footnotes, 1, 4) AS DPV_Footnotes
	,substring(a.CMRA, 1, 1) AS CMRA
	,substring(a.ELOT_Number, 1, 5) AS ELOT_Number
	,substring(a.ELOT_Order, 1, 2) AS ELOT_Order
	,substring(a.LACS, 1, 1) AS LACS
	,substring(a.LACS_LinkIndicator, 1, 1) AS LACS_LinkIndicator
	,substring(a.EWS_Flag, 1, 1) AS EWS_Flag
	,substring(a.RBDI, 1, 1) AS RBDI
	,substring(a.SuiteLinkReturnCode, 1, 1) AS SuiteLinkReturnCode
	,substring(a.DeliveryPointCheckDigit, 1, 1) AS DeliveryPointCheckDigit
	,substring(a.DeliveryPointCode, 1, 2) AS DeliveryPointCode
	,substring(a.CensusBlock, 1, 4) AS CensusBlock
	,substring(a.CensusTract, 1, 6) AS CensusTract
	,substring(a.PlaceCode, 1, 7) AS PlaceCode
	,substring(a.PlaceName, 1, 60) AS PlaceName
	,substring(a.CBSACode, 1, 5) AS CBSACode
	,substring(a.CBSALevel, 1, 50) AS CBSALevel
	,substring(a.CBSATitle, 1, 50) AS CBSATitle
	,substring(a.CBSADivisionCode, 1, 5) AS CBSADivisionCode
	,substring(a.CBSADivisionLevel, 1, 50) AS CBSADivisionLevel
	,substring(a.CBSADivisionTitle, 1, 50) AS CBSADivisionTitle
	,a.Latitude
	,a.Longitude
	,a.Verified
	,a.Geocoded
	,substring(a.AddressMatchResults, 1, 50) AS AddressMatchResults
	,substring(a.GeoErrorCode, 1, 1) AS GeoErrorCode
	,substring(a.GeoStatusCode, 1, 1) AS GeoStatusCode
	,substring(a.AddressType, 1, 1) AS AddressType
	,Getdate() AS [m_create_date]
FROM (
	SELECT a.Name_id
		,a.[address]
		,a.[address_city_name]
		,a.[address_state_name]
		,a.[address_zip_code]
		,d.[fips_code] AS Fips
		,cast(0 AS INT) AS Ref_id
		,'    ' AS Match_code
		,substring(replace(Replace(ltrim(rtrim(a.address)) + ' ,' + isnull(ltrim(rtrim(a.address_city_name)), '') + ' ,' + isnull(ltrim(rtrim(a.address_state_name)), '') + ' ,' + isnull(ltrim(rtrim(a.address_zip_code)), ''), 'NUll', ''), '  ', ''), 1, 60) AS Raw_Address
		,s.*
	FROM #addr aa WITH (
			NOLOCK
			,INDEX (idx_name_id)
			)
	INNER JOIN [Lien].[UR].[NAME] a ON a.name_id = aa.Name_id
	LEFT JOIN [Lien].[UR].[DOCUMENT] d WITH (
			NOLOCK
			,INDEX (PK_DOCUMENT)
			) ON d.doc_id = a.doc_id
	--LEFT JOIN Lien.UR.NAME_Std_Address p with(nolock,index(PK_Name_Std_Address)) ON p.Name_id = a.Name_id
	OUTER APPLY (
		SELECT PreDir AS Direction
			,StreetNumber AS Street_Number
			,StreetName AS Street_Name
			,PostDir AS Post_Direction
			,StreetType AS Street_Type
			,s1.SuiteType AS Unit_Type
			,s1.Suite AS Unit
			,City
			,STATE
			,Zip
			,Plus4
			,PrivateMailbox AS PMB
			,Pmsa
			,Msa
			,ZipType
			,Urbanization
			,TimeZoneCode
			,TimeZone
			,CongressionalDistrict
			,CountryCode
			,CountyFips
			,CountyName
			,CityAbbreviation
			,AddressTypeString
			,AddressTypeCode AS AddressTypeCode
			,'' AS AddressType
			,DPVFootNotes AS DPV_Footnotes
			,'' AS DPV_Count
			,CarrierRoute AS CRRT
			,ELotOrder AS ELOT_Order
			,ELotNumber AS ELOT_Number
			,Lacs
			,LACSLinkIndicator AS LACS_LinkIndicator
			,LACSLinkReturnCode
			,EWSFlag AS EWS_Flag
			,RBDI
			,SuiteLinkReturnCode
			,AddressMatchResults
			,AddressMatchResultString
			,DeliveryPointCheckDigit
			,DeliveryPointCode
			,Latitude
			,Longitude
			,GeoErrorCode
			,GeoStatusCode
			,GeoCodeResults
			,CensusTract
			,CensusBlock
			,PlaceCode
			,PlaceName
			,CBSACode
			,CBSALevel
			,CBSATitle
			,CBSADivisionCode
			,CBSADivisionTitle
			,CBSADivisionLevel
			,CMRA
			,Verified
			,Geocoded
			,LoadDate
			,DsfNoStats
			,DsfVacant
			,DsfDNA
			,AddressKey
			,Company
			,MelissaAddressKey
			,MelissaAddressKeyBase
			,SuiteStatus
			,GeoDbLoadDate
			,AddrBuildNumber
			,GeoBuildNumber
			,FaAddrBuildDate
		FROM [spdb].[dbo].[StandardizeAddress](0, 1, a.[address], a.[address_city_name], a.[address_state_name], a.[address_zip_code])
		OUTER APPLY (
			SELECT CASE 
					WHEN isnull(Suite, '') = ''
						AND isnull(PrivateMailbox, '') > ''
						AND AddressMatchResults LIKE '%AS10%'
						and len(ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''),'#','')))) <= 6
						--THEN ltrim(replace(PrivateMailbox, 'PMB', ''))
						then ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''),'#','')))
					ELSE Suite
					END AS Suite
				,CASE 
					WHEN isnull(Suite, '') = ''
						AND isnull(PrivateMailbox, '') > ''
						AND AddressMatchResults LIKE '%AS10%'
						and len(ltrim(rtrim(replace(Replace(PrivateMailbox, 'PMB', ''),'#','')))) <= 6
						THEN 'PMB'
					ELSE SuiteType
					END AS SuiteType
			) s1
		) s
		--WHERE aa.name_id = 789390097
		--WHERE p.Name_id IS NULL
		--	a.name_id = 426127994
		--AND a.[address] > ''
	) a
OUTER APPLY (
	SELECT *
	FROM [Lien].[UR].[Name_Std_Address] c WITH (
			NOLOCK
			,INDEX (PK_Name_Std_Address)
			)
	WHERE c.Name_id = a.Name_id
	) c
WHERE c.Name_id IS NULL

COMMIT

----rollback
-- DELETE FROM lien.ur.Name_std_address WHERE name_id = 426127994 789390097
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'lienMailingAddrStd'
	,N'Ended'


