SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- ============================================
-- Description:	Process OUTPUT
-- =============================================
CREATE PROCEDURE [zCust_SingleSourcePropSolutions].[dbo].[usp_300_Start_Output_SINGLE_SOURCE_PROPERTY_SOLUTIONS]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[In Coverage][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Mortgage Start Date][varchar](250)NULL,
			[Mortgage Thru Date][varchar](250)NULL,
			[Foreclosure Start Date][varchar](250)NULL,
			[Foreclosure Thru Date][varchar](250)NULL,
			[Invol Lien Start Date][varchar](250)NULL,
			[Invol Lien Tax Thru Date][varchar](250)NULL,
			[Current Owner][varchar](250)NULL,
			[Grade][varchar](250)NULL,
			[Foreclosure Flag][varchar](250)NULL,
			[Tax Status Flag][varchar](250)NULL,
			[Involuntary Liens ][varchar](250)NULL,
			[# Open Mortgages][varchar](250)NULL

		) ON [PRIMARY]

	---- POPULATE OUTPUT with Customer Provided Data
		INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] ([INPUT KEY],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip])
		Select 
		InputKey
      ,[ADDRESS]
      ,[CITY]
      ,[STATE]
        ,[ZIP]
		FROM [zCust_SingleSourcePropSolutions].[dbo].[INPUT_IN]

	
		Select * From [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT]

		

	---- Fill in REF_ID
		UPDATE [zCust_SingleSourcePropSolutions].[dbo].[a] 
		SET a.WORK_REF_ID = c.REF_ID
			,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_SingleSourcePropSolutions].[dbo].[a_PropMatch_WORK] c on a.[INPUT Key] = c.RAW_ID

		
	---- Populates the Standardized address data in OUTPUT
		Update [zCust_SingleSourcePropSolutions].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(Date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_SingleSourcePropSolutions].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID

		
		Update [zCust_SingleSourcePropSolutions].[dbo].[a]
		set 
		A.[Mortgage Start Date] = B.M_Min_Date
		,A.[Mortgage Thru Date] = B.M_MAX_DATE
		,A.[Foreclosure Start Date] = B.P_MIN_DATE
		,A.[Foreclosure Thru Date] = B.P_MAX_DATE
		--,A.[Invol Lien Start Date] = B.
		--,A.[Invol Lien Tax Thru Date] = B.
 		--Select *
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
			JOIN [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] b  with(NOLOCK)
			ON convert(int,a.FIPs) = b.FIPs


		Update [zCust_SingleSourcePropSolutions].[dbo].[a]
		set 
		A.[In Coverage] = B.M_FLAG
		,A.[Mortgage Start Date] = B.M_Min_Date
		,A.[Mortgage Thru Date] = B.M_MAX_DATE
		,A.[Foreclosure Start Date] = B.P_MIN_DATE
		,A.[Foreclosure Thru Date] = B.P_MAX_DATE
		--,A.[Invol Lien Start Date] = B.
		--,A.[Invol Lien Tax Thru Date] = B.
 		--Select *
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
			JOIN [AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].[Doc_type_Min_Max_Date] b  with(NOLOCK)
			ON convert(int,a.FIPs) = b.FIPs


		-----20200429 - Per Kiran Pandya - use this table
		-----20200429 - Per NH - use this field as Through Date "Use this one - Plant Thru Full Date"



		Update [zCust_SingleSourcePropSolutions].[dbo].[a]
		set 
		A.[Invol Lien Start Date] = case when ISNULL(B.PPLNT_PLNT_FROM_DT,'') not like '' and B.PPLNT_PLNT_FROM_DT not like '0' 
			then  convert(date,convert(varchar(10),B.PPLNT_PLNT_FROM_DT))
			else NULL ENd
		,A.[Invol Lien Tax Thru Date] = case when ISNULL(B.PPLNT_THRU_FULL_DT,'') not like '' and B.PPLNT_THRU_FULL_DT not like '0' 
			then convert(date,convert(varchar(10),B.PPLNT_THRU_FULL_DT))
			else NULL ENd
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
			JOIN 
		(Select * From 
		(
		SELECT c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS AS FIPSCODE
		,PPLNT_PLNT_FROM_DT, PPLNT_THRU_FULL_DT
		FROM [zCust_ADS__S28_InvoluntaryLien].[DBO].[PL_PLANT_PARAM] p 
		INNER JOIN [zCust_ADS__S28_InvoluntaryLien].[DBO].[COUNTY] c 
		ON p.PPLNT_ST = c.TCNTY_ST 
		AND p.PPLNT_CTY = c.TCNTY_CTY
		where c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS not in ( '00000','48021')
		
		UNION ALL

		SELECT c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS AS FIPSCODE
		,PPLNT_PLNT_FROM_DT, PPLNT_THRU_FULL_DT
		--,PPLNT_ST,PPLNT_CTY
		FROM [zCust_ADS__S28_InvoluntaryLien].[DBO].[PL_PLANT_PARAM] p 
		INNER JOIN [zCust_ADS__S28_InvoluntaryLien].[DBO].[COUNTY] c 
		ON p.PPLNT_ST = c.TCNTY_ST 
		AND p.PPLNT_CTY = c.TCNTY_CTY
		where c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS  like '48021'
		and PPLNT_CTY like '11'
		)A
		--Order by FIPSCODE
		)B on A.FIPS = B.FIPSCODE


		

		------Need to know WHICH ONE TO USE!!!!----

		--SELECT c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS AS FIPSCODE
		--,PPLNT_PLNT_FROM_DT, PPLNT_THRU_FULL_DT
		--,PPLNT_ST,PPLNT_CTY
		--FROM zCust_ADS__S28_InvoluntaryLien.[DBO].PL_PLANT_PARAM p 
		--INNER JOIN zCust_ADS__S28_InvoluntaryLien.[DBO].[COUNTY] c 
		--ON p.PPLNT_ST = c.TCNTY_ST 
		--AND p.PPLNT_CTY = c.TCNTY_CTY
		--where c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS  like '48021'
		--and PPLNT_CTY like '11'
		--Order by c.TCNTY_ST_FIPS + c.TCNTY_CTY_FIPS
	
	

		---------------------------------------------
		SET CONCAT_NULL_YIELDS_NULL OFF
		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set 
		A.[Current Owner] = case when ISNULL(B.Owner1LastName,'') like '' then LTRIM(RTRIM(B.OwnerName1Full)) else 
		REPLACE(LTRIM(RTRIM(B.Owner1FirstNameMiddleInitial + ' ' + B.Owner1LastName + ' ' + Owner1Suffix)),'  ',' ') end
		+ 
		case when ISNULL(B.OwnerName2Full,'') not like '' or ISNULL(B.Owner2LastName,'') not like '' then ' / ' else null end
		+
		case when ISNULL(B.Owner2LastName,'') like '' then LTRIM(RTRIM(B.OwnerName2Full)) else 
		REPLACE(LTRIM(RTRIM(B.Owner2FirstNameMiddleInitial + ' ' + B.Owner2LastName + ' ' + Owner2Suffix)),'  ',' ') end
				
		--Select A.WORK_REF_ID
		----, LTRIM(RTRIM(B.Owners))
		--, OwnerName1Full,OwnerName2Full
		--,B.Owner1FirstNameMiddleInitial,B.Owner1LastName
		--,B.Owner2FirstNameMiddleInitial,B.Owner2LastName
		--, case when ISNULL(B.Owner1LastName,'') like '' then LTRIM(RTRIM(B.OwnerName1Full)) else 
		--REPLACE(LTRIM(RTRIM(B.Owner1FirstNameMiddleInitial + ' ' + B.Owner1LastName + ' ' + Owner1Suffix)),'  ',' ') end
		--+ 
		--case when ISNULL(B.OwnerName2Full,'') not like '' or ISNULL(B.Owner2LastName,'') not like '' then ' / ' else null end
		--+
		--case when ISNULL(B.Owner2LastName,'') like '' then LTRIM(RTRIM(B.OwnerName2Full)) else 
		--REPLACE(LTRIM(RTRIM(B.Owner2FirstNameMiddleInitial + ' ' + B.Owner2LastName + ' ' + Owner2Suffix)),'  ',' ') end

		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
		join [zCust_SingleSourcePropSolutions].[dbo].[w_DM_Data] as B on A.WORK_REF_ID = B.PROPERTY_ID
		--where A.WORK_REF_ID = '212626964'



		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set 
		A.[Foreclosure Flag] = 'Y'
		--Select A.WORK_REF_ID, B.Status
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
		join [zCust_SingleSourcePropSolutions].[dbo].[w_DM_Data] as B on A.WORK_REF_ID = B.PROPERTY_ID
		where B.Status in ('1','6')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set 
		A.[Foreclosure Flag] = 'Y'
		--Select A.WORK_REF_ID, A.[Foreclosure Flag],B.[PFCIndicator]
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a 
		join [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK)
		on A.FIPS = B.FIPS and A.WORK_REF_ID = B.DTDB_REFID
		where B.[PFCIndicator] in ('1','2','3')
		
		
		

		-------20200417 - Per NH - if there are DBS tax records for the property - but the TOTALDELINQAMOUNT is null or 0 - then populate P for Paid
		Update [zCust_SingleSourcePropSolutions].[dbo].[A]

		Set A.[Tax Status Flag] = case 
			when B.TOTAL > 0 and B.NOTPAID = 0 then 'P' 
			when B.TOTAL > 0 and B.NOTPAID > 0 then 'Y' 
		else NULL end 
		From [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT] as A join 
		(
		Select B.FIPS, B.REF_ID, count(*) as TOTAL
		,SUm(case when A.TOTALDELINQAMOUNT > 0 THEN 1 ELSE 0 END) AS NOTPAID
		from [data].[dbo].[vDBS_TAX] as A with(NOLOCK) 
		join [Assr].[dbo].[Assr] as B with(NOLOCK) on A.FIPS = B.FIPS and A.FAPropertyID = B.LIC_PropertyID
		join [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT] as C on B.FIPS = C.FIPS and B.REF_ID = C.WORK_REF_ID
		where isnull(C.WORK_REF_ID,'') not like '' and C.WORK_REF_ID not like '0'
		Group by B.FIPS, B.REF_ID
		) B on A.FIPS = B.FIPS
		and A.WORK_REF_ID = B.REF_ID


		

		
		Select * From [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT]
		Order by [Tax Status Flag]


		---------------------------------------------------------------------------------
		Update [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] SET toUse = NULL

	---- PULL ALL OPEN LIENS
		Update [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] 
		SET ToUSE = 'Y' 
		Where Lien_Pos is not null


	---- Recreates the w_TransHist to only include transactions that match above 
		Truncate table w_TransHist_II

		INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist_II]
		SELECT * 
		FROM [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist]
		WHERE ToUSE = 'Y'


			UPDATE [zCust_SingleSourcePropSolutions].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist_II] t LEFT JOIN
			(SELECT top 100 percent* 
				,ROW_NUMBER() OVER(PARTITION BY REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_SingleSourcePropSolutions].[dbo].[w_TransHist_II] t WHERE ToUse = 'Y' ORDER BY Lien_POS ) r ON t.REF_ID = r.REF_ID AND t.DOC_ID = r.Doc_ID


		---- LOAD OPEN LIENS INTO w_OpenLien table
		BEGIN

			SET CONCAT_NULL_YIELDS_NULL OFF

			TRUNCATE TABLE w_OpenLiens

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)

			where b.lien_pos = 1 and MTG1_MTG_AMOUNT <> '1.00'
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT 

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 1
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT 

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
							and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 2 and MTG1_MTG_AMOUNT <> '1.00'
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 2
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 3
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 4
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 5
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 6
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 7
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 8
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 9
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS,a.REF_ID,b.lien_pos as [1stLienPosition]
			,CASE WHEN a.BYR1_LAST_NAME is null THEN a.BYR1_OWN_NAME ELSE a.BYR1_LAST_NAME + ' ' + a.BYR1_FIRST_NAME + ' ' + a.BYR1_MIDDLE_INITIAL END as [1stBorrowerName1]
			,CASE WHEN a.BYR2_LAST_NAME is null THEN a.BYR2_OWN_NAME ELSE a.BYR2_LAST_NAME + ' ' + a.BYR2_FIRST_NAME + ' ' + a.BYR2_MIDDLE_INITIAL END as [1stBorrowerName2]
			,a.BYR3_LAST_NAME + ' ' + a.BYR3_FIRST_NAME + ' ' + a.BYR3_MIDDLE_INITIAL as [1stBorrowerName3]
			,a.BYR4_LAST_NAME + ' ' + a.BYR4_FIRST_NAME + ' ' + a.BYR4_MIDDLE_INITIAL as [1stBorrowerName4]
			,a.MTG1_LENDER_LAST_NAME + ' ' + a.MTG1_LENDER_FIRST_NAME as [1stLender]
			,MTG1_DOC_DATE as [1stMortgageDate]
			,MTG1_RECORDING_DATE as [1stRecordingDate]
			,MTG1_MTG_AMOUNT as [1stMortgageAmount]
			,CASE WHEN [FMT_MTG1_DOC_NBR] is NULL THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [1stDocNumber]
			,MTG1_MTG_LOAN_TYPE_CODE as [1stLoanType]
			,MTG1_MTG_INTEREST_RATE as [1stInterestRate]
			,MTG1_MTG_INTEREST_RATE_TYPE as [1stRateType]
			,MTG1_MTG_TERM_ as [1stMortgageTerm]
			,TRANSACTION_TYPE as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_Deed] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.Recording_Date = b.Recording_Date
						and convert(Money,a.MTG1_MTG_AMOUNT) = convert(Money,b.Loan_Amt)
			where b.lien_pos = 10
			order by a.fips,a.REF_ID,a.MTG1_RECORDING_DATE,a.MTG1_MTG_AMOUNT DESC

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 1 and b.lien_pos = 1
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 2 and b.lien_pos = 2
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 3 and b.lien_pos = 3
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 4 and b.lien_pos = 4
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 5 and b.lien_pos = 5
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 6 and b.lien_pos = 6
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 7 and b.lien_pos = 7
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 8 and b.lien_pos = 8
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 9 and b.lien_pos = 9
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value

			INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens]
			Select distinct 
			a.FIPS
			,a.REF_ID
			,b.Lien_Pos as [1stLienPosition]
			,BuyerBorrower as [1stBorrowerName1]
			,NULL
			,NULL
			,NULL
			,SellerLender as [1stLender]
			,Filing_Date
			,RecordingDate as [1stRecordingDate]
			,Value as [1stMortgageAmount]
			,DocumentNbr as [1stDocNumber]
			,A.Loan_Type as [1stLoanType]
			,A.Int_Rate as [1stInterestRate]
			,A.Rate_Type as [1stRateType]
			,A.Mtg_Term as [1stMortgageTerm]
			,NULL as TransactionType    ---TransType as TransactionType 
			 from [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] a join [zCust_SingleSourcePropSolutions].[dbo].[w_DIM_NOVA_DOCUMENT] b
			on a.FIPS = b.FIPS
				and a.REF_ID = b.REF_ID 
					and a.RecordingDate = b.Recording_Date
			where a.lien_pos = 10 and b.lien_pos = 10
			order by a.fips,a.REF_ID,a.RecordingDate,a.Value


			SET CONCAT_NULL_YIELDS_NULL ON
		END



		Truncate table w_OpenLiens_II

		Insert into [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II]
		Select A.* From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as A 
		join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and B.Lien_Pos is not null

		Update [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II]
		Set 
		 [1stBorrowerName1] = REPLACE(LTRIM(RTRIM([1stBorrowerName1])),'  ',' ')
        ,[1stBorrowerName2] = REPLACE(LTRIM(RTRIM([1stBorrowerName2])),'  ',' ')

		--Select * From w_OpenLiens_II
		--where REF_ID = '81804579'

		--UPdate w_OpenLiens_II
		--Set 1stLienPosition = NULL
		--where REF_ID = '81804579'
		--and DocumentNbr in ('2013.2643','2013.6888','2014.5207')

		--UPdate w_OpenLiens_II
		--Set [1stLienPosition] = 1
		--where REF_ID = '81804579'
		--and [1stDocNumber] = '2015.373'

		--UPdate w_OpenLiens_II
		--Set [1stLienPosition] = 2
		--where REF_ID = '81804579'
		--and [1stDocNumber] = '2020.2020-02236'


		----------------------------------------------------------------------------
		--------Update from Transhist------

		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stLender] = B.SellerLender
		--Select A.REF_ID
		
  --    ,[1stLender]
 	 -- ,B.SellerLender
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stLender],'') not like ISNULL(B.SellerLender,'')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stMortgageDate] = B.DocDate
		--Select A.REF_ID
		--,[1stMortgageDate]
  --    ,B.DocDate
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stMortgageDate],'') not like ISNULL(B.DocDate,'')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stLoanType] = case when B.Loan_Type like 'F' then 'FHA'
		when B.Loan_Type like 'V' then 'VA' else B.Loan_Type end
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,[1stLoanType]
  --    ,B.Loan_Type
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stLoanType],'') not like ISNULL(B.Loan_Type,'')
		and (ISNULL(A.[1stLoanType],'')  like '' OR A.[1stLoanType] like 'CNV')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stInterestRate] = B.Int_Rate
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,[1stInterestRate]
  --    ,B.Int_Rate
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stInterestRate],'') not like ISNULL(B.Int_Rate,'')
		and A.[1stInterestRate] not like '0.0000 '


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stRateType] = B.Rate_Type
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,[1stRateType]
  --    ,B.Rate_Type
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stRateType],'') not like ISNULL(B.Rate_Type,'')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stMortgageTerm] = B.MTG_Term
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,[1stMortgageTerm]
  --    ,B.MTG_Term
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_TransHist] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.RecordingDate
		and A.[1stMortgageAmount] = B.Value
		and A.[1stDocNumber] = B.DocumentNbr
		where B.Doc_Src_Ind like 'M'
		and ISNULL(A.[1stMortgageTerm],'') like '' 
		and ISNULL(B.MTG_Term,'') not like '' 

		--------Update from Open Lien---------

	
	
		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stLoanType] = case when B.[1stLoanType] like 'F' then 'FHA'
		when B.[1stLoanType] like 'V' then 'VA' else B.[1stLoanType] end
		--	Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,A.[1stLoanType]
  --    ,B.[1stLoanType]
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		and right(A.[1stDocNumber],4) = right(B.[1stDocNumber],4)
		
		and ISNULL(A.[1stLoanType],'') not like ISNULL(B.[1stLoanType],'')
		and 
		(
			(ISNULL(A.[1stLoanType],'')  like '' AND ISNULL(B.[1stLoanType],'')  not like '') 
			OR
			 (ISNULL(A.[1stLoanType],'') in ('V','F') AND ISNULL(B.[1stLoanType],'') not like 'CNV' )
		)


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stInterestRate] = B.[1stInterestRate]
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,A.[1stInterestRate]
  --    ,B.[1stInterestRate]
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		and right(A.[1stDocNumber],4) = right(B.[1stDocNumber],4)
		
		and ISNULL(A.[1stInterestRate],'') not like ISNULL(B.[1stInterestRate],'')
		and B.[1stInterestRate] not like '0.0000 '


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stRateType] = B.[1stRateType]
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,A.[1stRateType]
  --    ,B.[1stRateType]
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		and right(A.[1stDocNumber],4) = right(B.[1stDocNumber],4)
		and ISNULL(A.[1stRateType],'') not like ISNULL(B.[1stRateType],'')


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[1stMortgageTerm] = B.[1stMortgageTerm]
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,A.[1stMortgageTerm]
  --    ,B.[1stMortgageTerm]
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		and right(A.[1stDocNumber],4) = right(B.[1stDocNumber],4)
		and ISNULL(A.[1stMortgageTerm],'') not like ISNULL(B.[1stMortgageTerm],'')

		--------------------------Add-------------------- 


		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set A.[TransactionType] = B.[TransactionType]
		--Select A.REF_ID, A.[1stRecordingDate], A.[1stDocNumber]
		--,A.[TransactionType]
		--,B.[TransactionType]
			From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as A join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		and right(A.[1stDocNumber],4) = right(B.[1stDocNumber],4)
		and ISNULL(A.[TransactionType],'') not like ISNULL(B.[TransactionType],'')
		

		Select A.REF_ID, A.[1stDocNumber],A.[1stRecordingDate],A.[1stMortgageAmount]  
		,B.[1stDocNumber]
		From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens] as A 
		left outer join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as B on 
		A.REF_ID = B.REF_ID
		and A.[1stRecordingDate] = B.[1stRecordingDate]
		and A.[1stMortgageAmount] = B.[1stMortgageAmount]
		--and right(ISNULL(A.[1stDocNumber],''),4) = right(ISNULL(B.[1stDocNumber],''),4)
		--and REPLACE(right(ISNULL(A.[1stDocNumber],''),4),'','Unknown') = REPLACE(right(ISNULL(B.[1stDocNumber],''),4),'','Unknown')
		where 
		--B.[1stDocNumber] is null
		B.[1stMortgageAmount] is null




		--Select * From w_OpenLiens_II where REF_ID = '81804579'
		--Select * From w_OpenLiens where REF_ID = '81804579'
		--Select * From w_TransHist where REF_ID = '81804579' and Doc_Src_Ind like 'M'

		Select REF_ID, [1stLienPosition], count(*)  From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II]
		Group by  REF_ID, [1stLienPosition]
		Having count(*) > 1
		

	-----------------------------------------------------------------------------

		
		Update [zCust_SingleSourcePropSolutions].[dbo].[A]
		Set 
		A.[# Open Mortgages] = B.TOTAL
		From [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT] as A join 
		(Select REF_ID, count(*) as TOTAL From [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] 
		Group by REF_ID)
		as B on 
		A.WORK_REF_ID = B.REF_ID

		Select WORK_REF_ID,[# Open Mortgages], B.* From [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT] AS A
		join [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II] as B on A.WORK_REF_ID = B.REF_ID
		Order by [# Open Mortgages] desc

		
		--Select REF_ID, Recording_Date, Doc_Number,lien_pos,Doc_Src_Ind,Raps_Doc_Ind From w_DIM_NOVA_DOCUMENT
		--where 
		--REF_ID = '81804579'	and 
		--lien_pos > 0 and Doc_Src_Ind like 'M'
		--Order by REF_ID,lien_pos
		

		--Select REF_ID, Lien_POs, count(*) as TOTAL from (
		--Select B.REF_ID, Recording_Date, Doc_Number,B.lien_pos,B.Doc_Src_Ind From w_TransHist as A join w_DIM_NOVA_DOCUMENT as B on 
		--A.REF_ID = B.REF_ID
		--and A.DocumentNbr = B.Doc_Number
		--where 
		----A.REF_ID = '81804579'
		--A.Doc_Src_Ind like 'M'
		--and ISNULL(A.Lien_Pos,'0') > 0 and B.Lien_Pos is not null)A
		--Group by REF_ID, Lien_POs
		--having count(*) > 1

		--Select REF_ID, RecordingDate, DocumentNbr, Value, Lien_Pos From w_TransHist
		--where REF_ID = '81804579'
		--ORder by Lien_Pos
		

		---- ADD LIEN FIELDS TO OUTPUT TABLE

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans =    MAX([1stLienPosition]) FROM [zCust_SingleSourcePropSolutions].[dbo].[w_OpenLiens_II]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT ADD [Lien Position_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Borrower Name 1_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Borrower Name 2_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Mortgage Purpose_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Lender_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Mortgage Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Mortgage Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Doc Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Loan Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Interest Rate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Rate Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT ADD [Mortgage Term_' + @RecNbr + '] [varchar](250) NULL')


					EXEC('UPDATE a
					SET 
					 [Lien Position_' + @RecNbr + '] = b.[1stLienPosition]
					,[Borrower Name 1_' + @RecNbr + '] = b.[1stBorrowerName1]
					,[Borrower Name 2_' + @RecNbr + '] = b.[1stBorrowerName2]
					,[Mortgage Purpose_' + @RecNbr + '] = b.[TransactionType]
					,[Lender_' + @RecNbr + '] = b.[1stLender]
					,[Mortgage Date_' + @RecNbr + '] = b.[1stMortgageDate]
					,[Recording Date_' + @RecNbr + '] = b.[1stRecordingDate]
					,[Mortgage Amount_' + @RecNbr + '] = Convert(varchar(15),convert(int,convert(money,b.[1stMortgageAmount])))
					,[Doc Number_' + @RecNbr + '] = b.[1stDocNumber]
					,[Loan Type_' + @RecNbr + '] = b.[1stLoanType]
					,[Interest Rate_' + @RecNbr + '] = b.[1stInterestRate]
					,[Rate Type_' + @RecNbr + '] = b.[1stRateType]
					,[Mortgage Term_' + @RecNbr + '] = b.[1stMortgageTerm]
					
					FROM x_Custom_OUTPUT a JOIN w_OpenLiens_II as B 
					on a.WORK_REF_ID = b.REF_ID
					WHERE B.[1stLienPosition] =  ' + @BeginNbrOfTrans + '
					')

					EXEC('UPDATE A 
					SET 
					A.[Loan Type_' + @RecNbr + '] = UPPER(b.[Desc])
					from x_Custom_OUTPUT a JOIN (
					Select Distinct Value,[Code Description] as [Desc] 
						from [AZUVPSQLDTDB029.datatree.local].[DEED].dbo.DeedLookup 
						WHERE [Deed_Table_Column_Name] Like ''MTG%_MTG_LOAN_TYPE_CODE''
						) b
					on A.[Loan Type_' + @RecNbr + '] = b.value')

					EXEC('UPDATE A 
					SET A.[Rate Type_' + @RecNbr + '] = UPPER(b.[Desc])
					from x_Custom_OUTPUT a JOIN (
						Select Distinct Value,[Code Description] as [Desc] 
							from [AZUVPSQLDTDB029.datatree.local].[DEED].dbo.DeedLookup 
							WHERE [Deed_Table_Column_Name] Like ''MTG%_MTG_INTEREST_RATE_TYPE''
							) b
					on A.[Rate Type_' + @RecNbr + '] = b.value')


					EXEC('UPDATE A 
					SET A.[Mortgage Purpose_' + @RecNbr + '] = UPPER(b.[Desc])
					from x_Custom_OUTPUT a JOIN (
					Select Distinct Value,[Code Description] as [Desc] 
						from [AZUVPSQLDTDB029.datatree.local].[DEED].dbo.DeedLookup 
						WHERE [Deed_Table_Column_Name] Like ''TRANSACTION_TYPE''
						) b
					on A.[Mortgage Purpose_' + @RecNbr + '] = b.value')


					EXEC('UPDATE x_Custom_OUTPUT 
					SET [Mortgage Term_' + @RecNbr + '] = convert(varchar(10),convert(int,[Mortgage Term_' + @RecNbr + '])) 
					WHERE [Mortgage Term_' + @RecNbr + '] not like ''''
					')

					EXEC('UPDATE x_Custom_OUTPUT 
					SET [Mortgage Term_' + @RecNbr + '] = '''' 
					WHERE [Mortgage Term_' + @RecNbr + '] = ''0''
					')

					EXEC('UPDATE x_Custom_OUTPUT 
					SET [Interest Rate_' + @RecNbr + ']  = cast([Interest Rate_' + @RecNbr + '] as Numeric(10,4))
					WHERE [Interest Rate_' + @RecNbr + '] not like '''' 
					and [Interest Rate_' + @RecNbr + '] not like ''0.0000 ''
					')

					EXEC('UPDATE x_Custom_OUTPUT 
					SET 
					[Interest Rate_' + @RecNbr + '] = ''''
					WHERE ltrim(rtrim([Interest Rate_' + @RecNbr + '])) like ''0.0000''
					')

					EXEC('UPDATE x_Custom_OUTPUT 
					SET [Mortgage Amount_' + @RecNbr + '] = convert(varchar(10),convert(int,convert(money,[Mortgage Amount_' + @RecNbr + ']))) 
					WHERE [Mortgage Amount_' + @RecNbr + '] not like ''''
					')

					

					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END


		

			Select * From [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT]
			Order by [# Open Mortgages] desc
						
	---- POPULATES STANDARD STATUS FIELDS
		Update [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] 
		SET [In Coverage] = CASE WHEN [In Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		
		Update  [zCust_SingleSourcePropSolutions].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_SingleSourcePropSolutions].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID


		Update [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN WORK_REF_ID is not null THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_SingleSourcePropSolutions].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT] a join [zCust_SingleSourcePropSolutions].[dbo].[a_PropMatch_WORK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		------Per SOW - Event Found is Any record that has Mortgage Data Coverage & is Property Found!!!
		Update [zCust_SingleSourcePropSolutions].[dbo].[x_Custom_OUTPUT]
		SET [Event Status] = CASE WHEN [In Coverage] like 'In Coverage' and [Property Status] like 'Property Found' 
		THEN 'Event Found' ELSE 'Event Not Found' END


		DROP TABLE [dbo].[w_PropertyToPull]
		DROP TABLE [dbo].[w_PropertyToPullOut]

		CREATE TABLE [dbo].[w_PropertyToPull](
			[Id] [int] IDENTITY(1,1) NOT NULL,
			[RAW_ID] [varchar](50) NULL,
			[Fips] [int] NOT NULL,
			[SitusNumber] [varchar](20) NULL,
			[SitusDirection] [varchar](2) NULL,
			[SitusStreet] [varchar](65) NULL,
			[SitusType] [varchar](10) NULL,
			[SitusUnit] [varchar](15) NULL,
			[Apn] [varchar](45) NULL,
			[LastName] [varchar](130) NULL,
			[Processed] [datetime] NULL,
			[RequestXml] [varchar](max) NULL,
			[ResponseXml] [varchar](max) NULL,
		 CONSTRAINT [PK_PropertyToPull] PRIMARY KEY CLUSTERED 
		(
			[Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		CREATE TABLE [dbo].[w_PropertyToPullOut](
			[Id] [int] IDENTITY(1,1) NOT NULL,
			[InputRecordId] [int] NULL,
			[RecordType] [varchar](10) NULL,
			[DocType] [varchar](50) NULL,
			[DocNumber] [varchar](50) NULL,
			[Year] [varchar](50) NULL,
			[Book] [varchar](50) NULL,
			[Reel] [varchar](50) NULL,
			[Volume] [varchar](50) NULL,
			[Page] [varchar](50) NULL,
			[Recorded] [datetime] NULL,
			[Filed] [datetime] NULL,
			[Posted] [datetime] NULL,
			[Amount] [varchar](50) NULL,
			[Party1LastName] [varchar](50) NULL,
			[Party1FirstName] [varchar](50) NULL,
			[Party1MiddleName] [varchar](50) NULL,
			[Party1Role1] [varchar](50) NULL,
			[Party1Role2] [varchar](50) NULL,
			[Party1SSN] [varchar](50) NULL,
			[Party1Source] [varchar](50) NULL,
			[Party2LastName] [varchar](50) NULL,
			[Party2FirstName] [varchar](50) NULL,
			[Party2MiddleName] [varchar](50) NULL,
			[Party2Role1] [varchar](50) NULL,
			[Party2Role2] [varchar](50) NULL,
			[Party2SSN] [varchar](50) NULL,
			[Party2Source] [varchar](50) NULL,
			[AdditionalParties] [varchar](5000) NULL,
			[ParentId] [int] NULL,
		 CONSTRAINT [PK_PropertyToPullOut] PRIMARY KEY CLUSTERED 
		(
			[Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	

		INSERT INTO [zCust_SingleSourcePropSolutions].[dbo].[w_PropertyToPull]([RAW_ID],[Fips],[SitusNumber],[SitusDirection],[SitusStreet],[SitusType],[SitusUnit],[Apn],[LastName])
		Select a.RAW_ID,a.FIPS
		,case when A.RAW_ID = '410387341-OT' then '15-17' 
		when RAW_ID = '410367869-OT' then '1430'
		else  a.HouseNbr end
		,CASE WHEN a.LeftDirection IS NULL THEN a.RightDirection ELSE a.LeftDirection END
		,case when RAW_ID = '410367869-OT' then 'BROADMOORE'	else  a.Street end  
		,case when RAW_ID = '410367869-OT' then 'DR'	else  a.Mode end  
		--,a.Street
		--,a.Mode
		,a.UnitNumber
		--,b.INPUTAPN
		,NULL
		,[GLOBAL].[dbo].[NameFMLRemoveSuffixGetLast](b.[Current Owner])
		FROM [zCust_SingleSourcePropSolutions].[dbo].[a_PropMatch_WORK] a JOIN [zCust_SingleSourcePropSolutions].[dbo].[x_custom_OUTPUT] b
		on a.Raw_ID = b.[INPUT Key]
		--where A.RAW_ID in ('410387341-OT','410367869-OT')

		

		Delete from [zCust_SingleSourcePropSolutions].[dbo].[a]
		FROM [zCust_SingleSourcePropSolutions].[dbo].[w_PropertyToPull] a JOIN [zCust_ADS__S28_InvoluntaryLien].[dbo].[TitlePlantCoverage_20161128] b
		on convert(int,a.FIPS) = convert(int,b.[FIPS Code])
		where B.[Restricted] = 'Y'

		--Select * From [x_Custom_OUTPUT]
		--where [INPUT KEY] like '410460249-OT'

		--Select * From w_TransHist
		--where REF_ID = '82430789'
		--and Doc_Src_Ind like 'M'
		--and Lien_Pos is not null

		--Select * From w_OpenLiens 
		--where REF_ID = '82430789'

		--Select FIPS, REF_ID, MTG1_RECORDING_DATE, FMT_MTG1_DOC_NBR, TRANSACTION_TYPE
		--From [AZUVPSQLDTDB029.datatree.local].Deed.dbo.Deed with(NOLOCK)
		--where FIPS = 31109
		--and REF_ID = '82430789'
		--and FMT_MTG1_DOC_NBR like '2019.15096'
		

		--Select * From  [AZUVPSQLDTDB029.datatree.local].[DEED].dbo.DeedLookup 
		--WHERE [Deed_Table_Column_Name] Like 'TRANSACTION_TYPE'
		--and Value like 'H%'
			
		
		----------------PULL TITLE RECORDS-----------

		------20200730 - Manual fix per NH!!---
		--Select REF_ID, Lien_Pos, RecordingDate, DocumentNbr From w_TransHist 
		--where REF_ID = '81804579'

		--UPdate w_TransHist
		--Set Lien_POS = NULL
		--where REF_ID = '81804579'
		--and DocumentNbr in ('2013.2643','2013.6888','2014.5207')

		--UPdate w_TransHist
		--Set Lien_POS = 1
		--where REF_ID = '81804579'
		--and DocumentNbr = '2015.373'

		--UPdate w_TransHist
		--Set Lien_POS = 2
		--where REF_ID = '81804579'
		--and DocumentNbr = '2020.2020-02236'


END



