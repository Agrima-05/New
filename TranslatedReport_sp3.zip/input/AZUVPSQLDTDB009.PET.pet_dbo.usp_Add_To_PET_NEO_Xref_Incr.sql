/* Source: AZUVNSQLDTDB003.datatree.local | Pet | pet_dbo.usp_Add_To_PET_NEO_Xref_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */


-- =============================================
-- Author:		Sean Dang
-- Create date: 02/19/2025
-- Description:	Add rows to appropriate PET tables for PET_Incremental SSIS package
-- =============================================
CREATE PROCEDURE [PET].[pet_dbo].[usp_Add_To_PET_NEO_Xref_Incr]
	-- Add the parameters for the stored procedure here
	@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	BEGIN TRY
		SET NOCOUNT ON;

		--add to NEO_Xref_Full
		INSERT INTO [PET].[dbo].[PET_NEO_Xref_Full] (
			Fips
			,NEO_APN
			,NEO_LAND_TYPE
			,NEO_TITLE_LEGAL
			,PORTION_IND
			)
		SELECT a.FIPS
			,a.NEO_APN
			,a.NEO_LAND_TYPE
			,a.NEO_TITLE_LEGAL
			,a.PORTION_IND
		FROM [PET].[pet_tmp].[Pet_Incremental_Add] AS a
			--add into pet apn is its own stored procedure?
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


