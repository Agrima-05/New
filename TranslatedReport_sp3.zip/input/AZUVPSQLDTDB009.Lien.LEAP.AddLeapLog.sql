/* Source: AZUVNSQLDTDB003.datatree.local | Lien | LEAP.AddLeapLog | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
CREATE PROCEDURE [Lien].[LEAP].[AddLeapLog]
	@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [Lien].[LEAP].[LeapLog] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

