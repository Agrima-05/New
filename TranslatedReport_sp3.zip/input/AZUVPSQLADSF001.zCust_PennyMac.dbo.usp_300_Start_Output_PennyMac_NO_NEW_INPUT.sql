SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_PennyMac].[dbo].[usp_300_Start_Output_PennyMac_NO_NEW_INPUT]

AS
BEGIN
	
	SET NOCOUNT OFF;

	

	---- Create the custom OUTPUT table
	DROP TABLE [dbo].[x_Custom_OUTPUT] 

	CREATE TABLE [dbo].[x_Custom_OUTPUT](
	[FIPS] [varchar](5) NULL,
	[COUNTYNAME] [varchar](250) NULL,
	[WORK_REF_ID] [bigint] NULL,
	[PropertyID] [bigint] NULL,
	--[DeedID] [bigint] NULL,
	--[TransactionID] [bigint] NULL,
	[INPUTKEY] [varchar](250) NULL,
	[INPUTAddress] [varchar](150) NULL,
	[INPUTCity] [varchar](150) NULL,
	[INPUTState] [varchar](150) NULL,
	[INPUTZip] [varchar](150) NULL,
	[PropertyAddress] [varchar](116) NULL,
	[City] [varchar](55) NULL,
	[State] [varchar](2) NULL,
	[ZipCode] [varchar](9) NULL,
	[ReportDate] [date] NULL,
	[AddressStandardization] [varchar](25)  NULL,
	[PropertyStatus] [varchar](25)  NULL,
	[MortgageCoverageStatus] [varchar](20)  NULL,
	[MortgageThroughDate] [varchar](10) NULL,
	[Mortgage Event Status] [varchar](20)  NULL,
	[Legal Event Status] [varchar](20)  NULL,
	[Required Title Fields Event Status] [varchar](20)  NULL,
	
	[INPUTOriginationDate] [varchar](10) NULL,
	[INPUTOriginationAmount] [varchar](150) NULL,
	[INPUTBorrowerName] [varchar](150) NULL,

	-------INTERNAL _ REMOVE----
	[INPUTBorrowerLASTName] [varchar](150) NULL,
	[EXCEPTION] [varchar](150) NULL,
	[SEND_TO_TIER_II] [varchar](150) NULL,

	
	-----PNMAC fields required---
	[LoanId][varchar](250)NULL,
	--[assessors_parcel_id_number][varchar](50)NULL,
	[assessors_parcel_id_number][varchar](250)NULL,
	[land_records_type][varchar](250)NULL,
	[legal_description][varchar](max)NULL,
	[mortgage_tax_paid][varchar](250)NULL,
	[original_borrower][varchar](250)NULL,
	[original_deed_date][varchar](250)NULL,
	[original_grantee_vesting][varchar](250)NULL,
	[original_grantor_vesting][varchar](250)NULL,
	[original_loan_date][varchar](250)NULL,
	[original_mortgage_loan_amount][varchar](250)NULL,
	[original_mortgagee][varchar](250)NULL,
	[original_mtg_recorded_date][varchar](250)NULL,
	[original_source_book][varchar](250)NULL,
	[original_source_instrument_number][varchar](250)NULL,
	[original_source_page][varchar](250)NULL,
	[re_recording_book][varchar](250)NULL,
	[re_recording_date][varchar](250)NULL,
	[re_recording_instrument_number][varchar](250)NULL,
	[re_recording_page][varchar](250)NULL,
	[recording_source_book][varchar](250)NULL,
	[recording_source_date][varchar](250)NULL,
	[recording_source_instrument_number][varchar](250)NULL,
	[recording_source_page][varchar](250)NULL,
	[section_block_lot][varchar](250)NULL,
	[short_legal][varchar](250)NULL,
	[transfer_cert_title_number][varchar](250)NULL,


	-----Added for EXCEPTION REPORT----
	[MortgageStartDate] [varchar](10) NULL,

	----Internal----
	[RECEIVED_FROM_TIER_II] [varchar](50) NULL

) ON [PRIMARY] 





			-------------------IMPORT RECORDS FROM TPS--------
		IF (Select count(*) From [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]) > 0

		BEGIN

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = REPLACE(REPLACE(REPLACE(legal_description,char(10),''),char(13),''),char(9),'')
			where  
			legal_description like '%' + char(10) + '%' or
			legal_description like '%' + char(13) + '%' or
			legal_description like '%' + char(9) + '%' 

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = Right(legal_description,len(legal_description)-2)
			where  
			legal_description like '""%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = Right(legal_description,len(legal_description)-1)
			where  
			legal_description like '"%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = left(legal_description,len(legal_description)-2)
			where  
			legal_description like '%""'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = left(legal_description,len(legal_description)-1)
			where  
			legal_description like '%"'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = REPLACE(legal_description,'”','')
			where legal_description like '%”%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = REPLACE(legal_description,'“','')
			where legal_description like '%“%'

			
			------20201118  Added for APN-------------------
			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = REPLACE(REPLACE(REPLACE(assessors_parcel_id_number,char(10),''),char(13),''),char(9),'')
			where  
			assessors_parcel_id_number like '%' + char(10) + '%' or
			assessors_parcel_id_number like '%' + char(13) + '%' or
			assessors_parcel_id_number like '%' + char(9) + '%' 

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = Right(assessors_parcel_id_number,len(assessors_parcel_id_number)-2)
			where  
			assessors_parcel_id_number like '""%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = Right(assessors_parcel_id_number,len(assessors_parcel_id_number)-1)
			where  
			assessors_parcel_id_number like '"%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = left(assessors_parcel_id_number,len(assessors_parcel_id_number)-2)
			where  
			assessors_parcel_id_number like '%""'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = left(assessors_parcel_id_number,len(assessors_parcel_id_number)-1)
			where  
			assessors_parcel_id_number like '%"'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = REPLACE(assessors_parcel_id_number,'”','')
			where assessors_parcel_id_number like '%”%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = REPLACE(assessors_parcel_id_number,'“','')
			where assessors_parcel_id_number like '%“%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = REPLACE(assessors_parcel_id_number,'''','')
			where assessors_parcel_id_number like '%''%'

			
		

			------20201118  Added for SHORT LEGAL-------------------
			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = REPLACE(REPLACE(REPLACE(short_legal,char(10),''),char(13),''),char(9),'')
			where  
			short_legal like '%' + char(10) + '%' or
			short_legal like '%' + char(13) + '%' or
			short_legal like '%' + char(9) + '%' 

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = Right(short_legal,len(short_legal)-2)
			where  
			short_legal like '""%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = Right(short_legal,len(short_legal)-1)
			where  
			short_legal like '"%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = left(short_legal,len(short_legal)-2)
			where  
			short_legal like '%""'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = left(short_legal,len(short_legal)-1)
			where  
			short_legal like '%"'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = REPLACE(short_legal,'”','')
			where short_legal like '%”%'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = REPLACE(short_legal,'“','')
			where short_legal like '%“%'


			-------------------------------------Clean No Found-----------------------


			Select legal_description From [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			where  
			legal_description like '%"%' 

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = ''
			where legal_description like 'NO FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set legal_description = ''
			where legal_description like 'NOT FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = ''
			where assessors_parcel_id_number like 'NO FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set assessors_parcel_id_number = ''
			where assessors_parcel_id_number like 'NOT FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = ''
			where short_legal like 'NO FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set short_legal = ''
			where short_legal like 'NOT FOUND'

			Update [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
			Set FIPS = Right(('0' + convert(varchar(5),FIPS)),5)

		

		INSERT INTO [zCust_PennyMac].[dbo].[x_Custom_OUTPUT](FIPS, COUNTYNAME,WORK_REF_ID, PropertyID, INPUTKEY, INPUTAddress, INPUTCity, INPUTState, INPUTZip, PropertyAddress, City, State, ZipCode, ReportDate, AddressStandardization, PropertyStatus, MortgageCoverageStatus, 
				MortgageThroughDate, [Mortgage Event Status], [Legal Event Status], [Required Title Fields Event Status], INPUTOriginationDate, INPUTOriginationAmount, INPUTBorrowerName, INPUTBorrowerLASTName, EXCEPTION, 
				SEND_TO_TIER_II, LoanId, assessors_parcel_id_number, land_records_type, legal_description, mortgage_tax_paid, original_borrower, original_deed_date, original_grantee_vesting, original_grantor_vesting, original_loan_date, 
				original_mortgage_loan_amount, original_mortgagee, original_mtg_recorded_date, original_source_book, original_source_instrument_number, original_source_page, re_recording_book, re_recording_date, 
				re_recording_instrument_number, re_recording_page, recording_source_book, recording_source_date, recording_source_instrument_number, recording_source_page, section_block_lot, short_legal, transfer_cert_title_number, 
				MortgageStartDate, [RECEIVED_FROM_TIER_II])
		--SELECT 
		--FIPS, COUNTYNAME,WORK_REF_ID, PropertyID, INPUTKEY, INPUTAddress, INPUTCity, INPUTState, INPUTZip, PropertyAddress, City, State, ZipCode, convert(date,Getdate()), AddressStandardization, PropertyStatus, MortgageCoverageStatus
		--		,case when ISNULL(MortgageThroughDate,'') like '' then '' else convert(date,MortgageThroughDate) end
		--		, [Mortgage Event Status], [Legal Event Status], [Required Title Fields Event Status]
		--		,convert(date,INPUTOriginationDate)
		--		,INPUTOriginationAmount, INPUTBorrowerName, INPUTBorrowerLASTName, EXCEPTION, 
		--		SEND_TO_TIER_II, LoanId, assessors_parcel_id_number, land_records_type, legal_description, mortgage_tax_paid, original_borrower, original_deed_date, original_grantee_vesting, original_grantor_vesting, original_loan_date, 
		--		original_mortgage_loan_amount, original_mortgagee, original_mtg_recorded_date, original_source_book, original_source_instrument_number, original_source_page, re_recording_book, re_recording_date, 
		--		re_recording_instrument_number, re_recording_page, recording_source_book, recording_source_date, recording_source_instrument_number, recording_source_page, section_block_lot, short_legal, transfer_cert_title_number
		--		,case when ISNULL(MortgageStartDate,'') like '' then '' else convert(date,MortgageStartDate) end
		--		, CONVERT(varchar(50), GETDATE(), 20) 
		--FROM     INPUT_RAW_INTERNAL_TPS
		--where isnull([LoanID],'') not like ''

		SELECT FIPS, COUNTYNAME,WORK_REF_ID, PropertyID, INPUTKEY, INPUTAddress, INPUTCity, INPUTState, INPUTZip, PropertyAddress, City, State, ZipCode, convert(date,Getdate()), AddressStandardization
	
	-------20201118  Changed to force Property Status when Tier II finds & populates the APN
		--, PropertyStatus
		, case when ISNULL(assessors_parcel_id_number,'') not like '' then 'Property Found' else PropertyStatus end
		, MortgageCoverageStatus
		--,case when ISDATE(MortgageThroughDate) = 0 and ISNULL(MortgageThroughDate,'') not like '' then 
		--convert(date,CAST(convert(bigint,MortgageThroughDate) -2  as DateTime))
		--when ISNULL(MortgageThroughDate,'')  like '' then NULL 
		--else convert(date,MortgageThroughDate) end
		--		--,case when ISNULL(MortgageThroughDate,'') like '' then '' else convert(date,MortgageThroughDate) end
		
		,case 
		when ISDATE(MortgageThroughDate) = 1 then convert(date,MortgageThroughDate)
		when ISDATE(MortgageThroughDate) = 0 and ISNULL(MortgageThroughDate,'') not like '' 
		and MortgageThroughDate not like '%/%' then 
		convert(date,CAST(convert(bigint,MortgageThroughDate) -2  as DateTime))
		when ISNULL(MortgageThroughDate,'')  like '' then NULL 
		
		when ISDATE(MortgageThroughDate) = 0 and ISNULL(MortgageThroughDate,'') not like '' 
		and MortgageThroughDate like '%/%' then 
		CONVERT(CHAR(10),CONVERT(DATETIME,LEFT(MortgageThroughDate,10),105),101)
		
		else  MortgageThroughDate end

		
		, [Mortgage Event Status], [Legal Event Status], [Required Title Fields Event Status]
		
		--,case when ISDATE(INPUTOriginationDate) = 0 and ISNULL(INPUTOriginationDate,'') not like '' then 
		--convert(date,CAST(convert(bigint,INPUTOriginationDate) -2  as DateTime))
		--when ISNULL(INPUTOriginationDate,'')  like '' then NULL 
		--else convert(date,INPUTOriginationDate) end

		,case 
		when ISDATE(INPUTOriginationDate) = 1 then convert(date,INPUTOriginationDate)
		when ISDATE(INPUTOriginationDate) = 0 and ISNULL(INPUTOriginationDate,'') not like '' 
		and INPUTOriginationDate not like '%/%' then 
		convert(date,CAST(convert(bigint,MortgageStartDate) -2  as DateTime))
		when ISNULL(INPUTOriginationDate,'')  like '' then NULL 
		
		when ISDATE(INPUTOriginationDate) = 0 and ISNULL(INPUTOriginationDate,'') not like '' 
		and INPUTOriginationDate like '%/%' then 
		CONVERT(CHAR(10),CONVERT(DATETIME,LEFT(INPUTOriginationDate,10),105),101)
		
		else  INPUTOriginationDate end

				--,convert(date,INPUTOriginationDate)
				,INPUTOriginationAmount, INPUTBorrowerName, INPUTBorrowerLASTName
				,EXCEPTION ---,NULL --as EXCEPTION to reset Exception Status
				, SEND_TO_TIER_II, LoanId, assessors_parcel_id_number, land_records_type, legal_description, mortgage_tax_paid, original_borrower, original_deed_date, original_grantee_vesting, original_grantor_vesting, original_loan_date, 
				original_mortgage_loan_amount, original_mortgagee, original_mtg_recorded_date, original_source_book, original_source_instrument_number, original_source_page, re_recording_book, re_recording_date, 
				re_recording_instrument_number, re_recording_page, recording_source_book, recording_source_date, recording_source_instrument_number, recording_source_page, section_block_lot, short_legal, transfer_cert_title_number
		
		--,case when ISDATE(MortgageStartDate) = 0 and ISNULL(MortgageStartDate,'') not like '' then 
		--convert(date,CAST(convert(bigint,MortgageStartDate) -2  as DateTime))
		--when ISNULL(MortgageStartDate,'')  like '' then NULL 
		--else convert(date,MortgageStartDate) end

		,case 
		when ISDATE(MortgageStartDate) = 1 then convert(date,MortgageStartDate)
		when ISDATE(MortgageStartDate) = 0 and ISNULL(MortgageStartDate,'') not like '' 
		and MortgageStartDate not like '%/%' then 
		convert(date,CAST(convert(bigint,MortgageStartDate) -2  as DateTime))
		when ISNULL(MortgageStartDate,'')  like '' then NULL 
		
		when ISDATE(MortgageStartDate) = 0 and ISNULL(MortgageStartDate,'') not like '' 
		and MortgageStartDate like '%/%' then 
		CONVERT(CHAR(10),CONVERT(DATETIME,LEFT(MortgageStartDate,10),105),101)
		
		else  MortgageStartDate end


				--,case when ISNULL(MortgageStartDate,'') like '' then '' else convert(date,MortgageStartDate) end
				, CONVERT(varchar(50), GETDATE(), 20) 
		FROM     [zCust_PennyMac].[dbo].[INPUT_RAW_INTERNAL_TPS]
		where isnull([LoanID],'') not like ''

		
		--Select FIPS, LoanId,INPUTOriginationDate,ISDATE(INPUTOriginationDate)
		--,case 
		--when ISDATE(INPUTOriginationDate) = 1 then convert(date,INPUTOriginationDate)
		--when ISDATE(INPUTOriginationDate) = 0 and ISNULL(INPUTOriginationDate,'') not like '' 
		--and INPUTOriginationDate not like '%/%' then 
		--convert(date,CAST(convert(bigint,MortgageStartDate) -2  as DateTime))
		--when ISNULL(INPUTOriginationDate,'')  like '' then NULL 
		
		--when ISDATE(INPUTOriginationDate) = 0 and ISNULL(INPUTOriginationDate,'') not like '' 
		--and INPUTOriginationDate like '%/%' then 
		--CONVERT(CHAR(10),CONVERT(DATETIME,LEFT(INPUTOriginationDate,10),105),101)
		
		--else  INPUTOriginationDate end
		--From INPUT_RAW_INTERNAL_TPS


							   
			
		END

		UPDATE [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		SET [legal event status] = CASE WHEN isNULL(legal_description,'') Like '' THEN 'Not Found' ELSE 'Found' END


		-----Reset Exceptions for records Tier II was able to match--
		UPDATE [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		SET EXCEPTION = ''
		where EXCEPTION like 'Y'  
		and
		ISNULL(assessors_parcel_id_number,'') not like '' 
		AND ISNULL(legal_description,'') NOT like ''

		Update [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Set section_block_lot  = assessors_parcel_id_number
		where FIPS like '36%'


			--------------INITIAL EXCEPTIONS-----------------------------------------------------
		-----KY, SC, TN or MA
		-----Changed 20201203 to add LA, VA & NY  per EC & Zach
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select A.FIPS, B.State
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('KY','SC','TN','MA','LA','VA','NY')
		--and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''
		
		----------PROPERTY NOT FOUND
		Update [zCust_PennyMac].[dbo].[x_custom_OUTPUT]
		Set Exception = 'Y'
		where PropertyStatus not like 'Property Found'
		--and ISNULL([RECEIVED_FROM_TIER_II],'') like ''

		----------HI or MN - LEGAL FOUND BUT MORTGAGE NOT FOUND
		-----20201022 - Per EC - Even if we don't have Land Record Type in MN doesn't cause it to be an Exception
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select * 
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where 
		(B.State in ('HI') and [Mortgage Event Status] not like 'Found')
		--(B.State in ('HI','MN') and [Mortgage Event Status] not like 'Found')
		AND ISNULL(A.legal_description,'') NOT like ''
		--and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''



		---------APN REQUIRED STATES (22) - LEGAL FOUND BUT NO APN
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select A.INPUTKEY,A.State,A.assessors_parcel_id_number, A.legal_description
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('AL','AZ','CA','DE','FL','HI','IL','IN','MD','MI','MS','NV','NC','OH','OK','OR','PA','RI','UT','VA','WA','WI')
		and
		ISNULL(A.assessors_parcel_id_number,'') like '' 
		AND ISNULL(A.legal_description,'') NOT like ''
		--and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''

		-----HI---   LEGAL FOUND BUT NO TRANSFER CERT TITLE NUMBER OR NO LAND RECORD TYPE
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select * 
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('HI')
		and
		(ISNULL(A.land_records_type,'') like '' OR ISNULL(transfer_cert_title_number,'') like '')
		AND ISNULL(A.legal_description,'') NOT like ''
		--and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''

		-----MN Land Records Type NOT an exception per notes from EC --  LEGAL FOUND BUT NO TRANSFER CERT TITLE NUMBER
		----20201022 - Per EC -No Longer need Transfer Cert Title Number in MN for Success - Just Legal (NO APN either)
		--Update A
		--Set A.Exception = 'Y'
		----Select A.FIPS, B.STATE, A.transfer_cert_title_number, A.legal_description
		--From x_custom_OUTPUT as A 
		--join global.dbo.county as B with(NOLOCK)
		--on A.FIPS = B.FIPSCODE
		--where B.State in ('MN')
		--and
		--ISNULL(transfer_cert_title_number,'') like ''
		--AND ISNULL(A.legal_description,'') NOT like ''
		----and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''


		-------Added 20201111 per PNMAC - Short legal must be populated in WA or this is an exception - even if Long legal is populated---
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select * 
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('WA')
		and ISNULL(A.short_legal,'') like ''



		----RECEIVED FROM TPS------
		----EXCEPTION - NO LEGAL-----
		Update [zCust_PennyMac].[dbo].[A]
		Set A.Exception = 'Y'
		--Select A.FIPS, A.INPUTKEY, A.legal_description, A.[Legal Event Status], A.EXCEPTION, A.RECEIVED_FROM_TIER_II 
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where 
		ISNULL(A.legal_description,'') like ''
		and ISNULL(A.[RECEIVED_FROM_TIER_II],'') not like ''



			-------------------REQUIRED TITLE FIELDS---TIER 1 (can change if Tier II is able to find the Legal----
		Update [zCust_PennyMac].[dbo].[A]
		Set A.[Required Title Fields Event Status] = 'Found'
		--Select A.INPUTKEY,A.State, A.assessors_parcel_id_number, A.legal_description, A.PropertyStatus, A.[Mortgage Event Status]
		--,A.EXCEPTION, A.SEND_TO_TIER_II, A.[Required Title Fields Event Status]
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('AL','AZ','CA','DE','FL','IL','IN','MD','MI','MS','NV','NC','OH','OK','OR','PA','RI','UT','VA','WA','WI')
		and
		ISNULL(A.assessors_parcel_id_number,'') NOT like '' 
		AND ISNULL(A.legal_description,'') NOT like ''

		Update [zCust_PennyMac].[dbo].[A]
		Set A.[Required Title Fields Event Status] = 'Found'
		--Select A.INPUTKEY, A.assessors_parcel_id_number, A.legal_description, A.PropertyStatus, A.[Mortgage Event Status], A.land_records_type, A.transfer_cert_title_number
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('HI')
		and
		ISNULL(A.assessors_parcel_id_number,'') NOT like '' 
		AND ISNULL(A.legal_description,'') NOT like ''
		AND ISNULL(land_records_type,'') not like ''
		AND ISNULL(transfer_cert_title_number,'') not like ''

		Update [zCust_PennyMac].[dbo].[A]
		Set A.[Required Title Fields Event Status] = 'Found'
		--Select A.INPUTKEY, A.section_block_lot, A.legal_description, A.PropertyStatus, A.[Mortgage Event Status], A.land_records_type, A.transfer_cert_title_number
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('NY')
		and
		ISNULL(A.section_block_lot,'') NOT like '' 
		AND ISNULL(A.legal_description,'') NOT like ''

		Update [zCust_PennyMac].[dbo].[A]
		Set A.[Required Title Fields Event Status] = 'Found'
		--Select A.INPUTKEY, A.section_block_lot, A.legal_description, A.PropertyStatus, A.[Mortgage Event Status], A.land_records_type, A.transfer_cert_title_number
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('MN')
		and
		ISNULL(A.legal_description,'') NOT like ''
		AND ISNULL(transfer_cert_title_number,'') not like ''

		Update [zCust_PennyMac].[dbo].[A]
		Set A.[Required Title Fields Event Status] = 'Found'
		--Select A.INPUTKEY, A.assessors_parcel_id_number, A.legal_description, A.PropertyStatus, A.[Mortgage Event Status]
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State in ('AK','AR','CO','CT','GA','ID','IA','KS','LA','ME','MO','MT','NE','NH','NJ','NM','ND','SD','TX','VT','WV','WY','DC')
		AND ISNULL(A.legal_description,'') NOT like ''
		

		Update [zCust_PennyMac].[dbo].[x_custom_OUTPUT]
		Set [Required Title Fields Event Status] = 'Not Found'
		where ISNULL([Required Title Fields Event Status],'') like ''







			------Send to Tier II - Matched Property but no Legal--
		Update [zCust_PennyMac].[dbo].[A]
		Set A.SEND_TO_TIER_II = 'Y'
		--Select A.INPUTKEY, A.State, A.PropertyStatus, A.legal_description,A.[RECEIVED_FROM_TIER_II],A.SEND_TO_TIER_II
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		join [global].[dbo].[county] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		where B.State NOT in ('KY','SC','TN','MA')
		AND PropertyStatus like 'Property Found'
		and ISNULL(legal_description,'') like ''
		and ISNULL(A.[RECEIVED_FROM_TIER_II],'') like ''
		AND ISNULL(A.SEND_TO_TIER_II,'') like ''
		
		
		Select INPUTKEY,STATE,WORK_REF_ID, PropertyID,PropertyStatus, assessors_parcel_id_number,Exception 
		,[Required Title Fields Event Status],[Mortgage Event Status],legal_description, SEND_TO_TIER_II
		From [zCust_PennyMac].[dbo].[x_custom_OUTPUT] as A 
		--where  legal_description is null
		Order by SEND_TO_TIER_II,STATE
		


		Select * From [zCust_PennyMac].[dbo].[x_custom_OUTPUT]


		-----------------------------------------------------------------------

		Select * from [zCust_PennyMac].[dbo].[x_Custom_OUTPUT] order by FIPS

		Select [PropertyStatus], count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by [PropertyStatus]

		Select MortgageCoverageStatus, count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by MortgageCoverageStatus

		Select * From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		where MortgageCoverageStatus is null

		Select * From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		where [PropertyStatus]  not like 'Property Found'

		Select AddressStandardization, count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by AddressStandardization

		Select [Legal Event Status], count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by [Legal Event Status]

		Select [Mortgage Event Status], count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by [Mortgage Event Status]

		Select [Required Title Fields Event Status], count(*) From [zCust_PennyMac].[dbo].[x_Custom_OUTPUT]
		Group by [Required Title Fields Event Status]


END





