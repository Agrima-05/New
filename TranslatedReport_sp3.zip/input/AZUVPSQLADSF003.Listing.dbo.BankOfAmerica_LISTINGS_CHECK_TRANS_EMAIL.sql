SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [Listing].[dbo].[BankOfAmerica_LISTINGS_CHECK_TRANS_EMAIL]
as
BEGIN


				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'BOFA LISTINGS TRANS ISSUES - SEE BELOW!! - ' + @Date 
				
				SET @body1 = '<html><body><H3>BOFA LISTINGS TRANS ISSUES!! - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> Listing Tracking ID  </th> <th> UpdateSeq  </th> <th>FA Unique Listing Identifier - Ref ID  </th> <th> STATUS  </th></tr>' 
			

				SET @xml = 
				CAST(( 
					
					Select top 20 [Listing Tracking ID] as 'td','',  ISNULL(UpdateSeq,'NULL')  as 'td','',   [FA Unique Listing Identifier - Ref ID] as 'td','',   STATUS  as 'td',''
					From [Listing].[dbo].[BankOfAmerica_OUT_BATCH]
					where len([FA Unique Listing Identifier - Ref ID]) - len([Listing Tracking ID]) > 3


				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body2 = '
				<BR/><BR/>
				Select [Listing Tracking ID], UpdateSeq, [FA Unique Listing Identifier - Ref ID], STATUS Listing.dbo.From BankOfAmerica_OUT_BATCH
				where len([FA Unique Listing Identifier - Ref ID]) - len([Listing Tracking ID]) > 3
				<BR/><BR/>
				Select [Listing Tracking ID], [FA Unique Listing Identifier - Ref ID], STATUS From Listing.dbo.BankOfAmerica_OUT
				where len([FA Unique Listing Identifier - Ref ID]) - len([Listing Tracking ID]) > 3

				<BR/><BR/>' + 
				
				
				@body1 + @XML +'</table></body></html> <BR/><BR/>
				'
				

				

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body2 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;


END
