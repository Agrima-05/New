SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_Regrid].[dbo].[usp_300_Start_Output_REGRID]
	

AS
BEGIN
	
	SET NOCOUNT ON;


	
		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			
			[INPUT UNIQUE ID][varchar](250)NULL,
			[INPUT APN][varchar](250)NULL,
			[INPUT County][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[PropertyID][varchar](250)NULL,
			[APN][varchar](250)NULL,
			[Current Owner Name 1][varchar](250)NULL,
			[Current Owner Name 2][varchar](250)NULL,
			[Mail Address][varchar](250)NULL,
			[Mail City][varchar](250)NULL,
			[Mail Sate][varchar](250)NULL,
			[Mail Zip][varchar](250)NULL

		) ON [PRIMARY]

		
		

		SET CONCAT_NULL_YIELDS_NULL OFF  

		Insert into [zCust_Regrid].[dbo].[x_Custom_OUTPUT] ([INPUT UNIQUE ID],
		[INPUT APN],
		[INPUT County],
		[INPUT State] 
		,FIPS)
			
		Select  
		INPUTKEY
		,INPUTAPN
		,INPUTCOUNTY
		,INPUTSTATE
		,B.FIPS
		FROM [zCust_Regrid].[dbo].[INPUT_IN] as A join [zCust_Regrid].[dbo].[a_ASP_IN_STD] as B on 
		A.INPUTKEY = B.RAW_ID
	
		
		UPDATE [zCust_Regrid].[dbo].[a] 
		SET 
		a.[PropertyID] = C.PropertyID
		,a.[Report Date] = convert(date,GetDate())
		--Select * 
		FROM [zCust_Regrid].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Regrid].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT UNIQUE ID] = c.RAW_ID
		
		
	
		Update [zCust_Regrid].[dbo].[a]
		SET a.[Property Address] = c.SitusSTDFullStreetAddress
		, a.City = c.SitusSTDCity
		, a.[State] = c.SitusSTDState
		, a.[Zip Code] = C.SitusSTDZip5
		,A.APN = C.FormattedAPN
		,A.[Current Owner Name 1] = C.OwnerStdName1Full
		,A.[Current Owner Name 2] = C.OwnerStdName2Full
		,A.[Mail Address] = C.MailingSTDFullStreetAddress
		,A.[Mail City] = C.MailingSTDCity
		,A.[Mail Sate] = C.MailingSTDState
		,A.[Mail Zip] = C.MailingSTDZip5

		FROM [zCust_Regrid].[dbo].[x_Custom_OUTPUT] a JOIN [data].[dbo].[Property] as c with(NOLOCK)
					ON 
					A.FIPS = C.FIPS and 
					a.PropertyID = c.PropertyID
					where A.PropertyID is not null and A.PropertyID not like ''
					and A.PropertyID not like '0'
	
		
	
		Update [zCust_Regrid].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN PropertyID is not null and PropertyID not like ''
					and PropertyID not like '0'  THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_Regrid].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_Regrid].[dbo].[x_Custom_OUTPUT] a join [zCust_Regrid].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT UNIQUE ID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		
		
	
		Select [Property Status],count(*) From [zCust_Regrid].[dbo].[x_custom_OUTPUT]
		Group by [Property Status]

		Select top 10000 * From [zCust_Regrid].[dbo].[x_custom_OUTPUT]

		Select count(*) From [zCust_Regrid].[dbo].[x_custom_OUTPUT]



END





