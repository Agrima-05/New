SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_PropertyOnion].[dbo].[usp_350_Finish_Output_PROPERTY_ONION]
		
AS
BEGIN
	
	SET NOCOUNT ON;


	

	--DECLARE @FIELDNAME varchar(200)
	--	DECLARE CLEAN_cursor CURSOR FOR  
	--	Select '[' + NAME + ']' From sys.columns
	--	where Object_ID = 
	--	(Select OBJECT_ID FROM sys.tables
	--	where NAME = 'x_Custom_OUTPUT')
	--	order by NAME

	--		OPEN CLEAN_cursor   
	--		FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME

	--		WHILE @@FETCH_STATUS = 0   
	--			BEGIN   
	--					EXEC('
	--					UPDATE [x_Custom_OUTPUT] 
	--					SET
	--					' + @FIELDNAME + '  = isNULL(' + @FIELDNAME + ','''')
	--					')
			

	--				FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME   
	--			END   

	--	CLOSE CLEAN_cursor   
	--	DEALLOCATE CLEAN_cursor


	Drop table x_Custom_OUT
	Select * into [zCust_PropertyOnion].[dbo].[x_Custom_OUT]
	From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT]

	
	--EXEC('ALTER TABLE dbo.x_Custom_OUT DROP COLUMN FIPS')
	--EXEC('ALTER TABLE dbo.x_Custom_OUT DROP COLUMN WORK_REF_ID')
	--EXEC('ALTER TABLE dbo.x_Custom_OUT DROP COLUMN PROPERTYID')


	


	----Select * From x_custom_OUTPUT
	
	DECLARE @yyyymmdd varchar(250) = (SELECT format(getdate(),'yyyyMMddHHmmssffff'))
	DECLARE @Customer varchar(50)
	Set @Customer = 'ProprtyOnion'
	
	
	EXEC('IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[zzz_' + @Customer + '_' + @yyyymmdd + '_OUTPUT]'') AND type in (N''U''))
	DROP TABLE [dbo].[zzz_' + @Customer + '_' + @yyyymmdd + '_OUTPUT]
	Select * INTO dbo.[zzz_' + @Customer + '_' + @yyyymmdd + '_OUTPUT] from x_Custom_OUTPUT')



	EXEC('IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[zzz_' + @Customer + '_' + @yyyymmdd + '_Out]'') AND type in (N''U''))
	DROP TABLE [dbo].[zzz_' + @Customer + '_' + @yyyymmdd + '_Out]
	Select * INTO dbo.[zzz_' + @Customer + '_' + @yyyymmdd + '_Out] from x_Custom_OUT')

	

		DECLARE @SharepointNbr varchar(20)
		Set @SharepointNbr = '4932'

		Update [zCust_PropertyOnion].[dbo].[ADS_DATA]
		Set IsActive = 'NO'
		where IsActive = 'YES'

		Insert into [zCust_PropertyOnion].[dbo].[ADS_DATA](SharePtNbr,Type,IsActive,IsBillable)
		Values(@SharepointNbr,'BATCH','YES','YES')

		
	--Select * From ADS_COUNTS
		

		INSERT INTO [zCust_PropertyOnion].[dbo].[ADS_COUNTS](AppSource
		,IsBillable
		,TicketNumber
		,CustomerName
		,CMASProductCode
		,BillingOption
		,AccountNumber
		,BatchType)
		 SELECT 'SQL ADS'
		 ,CASE WHEN Billing_x0020_Type NOT LIKE '%Non-billable%' THEN 'YES' ELSE 'NO' END
		 ,a.ID
		 ,left(Client_X0020_Name,255)
		 ,LEFT(Replace(Product,';#',''),100)
		 , Billing_x0020_Type
		 ,Billing_x0020_Number
		 ,b.[Type]
		 FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] a  With(NOLOCK )
		 JOIN [zCust_PropertyOnion].[dbo].[ADS_DATA] b
		 on a.ID = b.SharePtNbr
		 WHERE b.IsActive = 'YES'

	
		update [zCust_PropertyOnion].[dbo].[ADS_COUNTS] 
		SET CreateDate = GETDATE()
		,TotalRecords = (Select COUNT(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT])
		,TotalMatched = (Select COUNT(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT] where PropertyID is not null)
		,TotalUnMatched = (Select COUNT(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT] where PropertyID is null)
		--,TotalDuplicate = 0
		--,TotalExpired = 0
		--,TotalInCoverage = (Select COUNT(*) from x_Custom_OUTPUT where CoverageStatus = 'In Coverage')
		--,TotalNotInCoverage = (Select COUNT(*) from x_Custom_OUTPUT where CoverageStatus = 'Not In Coverage')
		--,TotalPropertiesFound = (Select COUNT(*) from x_Custom_OUTPUT where [Property Status] = 'Property Found')
		--,TotalPropertiesNotFound = (Select COUNT(*) from x_Custom_OUTPUT where [Property Status] = 'Property Not Found')
		--,TotalMultiplePropertiesFound = (Select COUNT(*) from x_Custom_OUTPUT where [Property Status] = 'Multiple Properties Found')
		--,TotalAddressStandardized = (Select COUNT(*) from x_Custom_OUTPUT where AddressStandardization = 'Standardized')
		--,TotalAddressNotStandardized = (Select COUNT(*) from x_Custom_OUTPUT where AddressStandardization = 'Not Standardized')
		,TotalWithEventsFound = (Select COUNT(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT] where PropertyID is not null)
		,TotalWithoutEventsFound = (Select COUNT(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT] where PropertyID is null)
		--,DocImageCounts = (SELECT COUNT(*) as ImageLinkCounts FROM z_Images_To_Pull with(NOLOCK) WHERE ImageLink is not null)
		WHERE CreateDate is NULL

	

	---- GENERATE STATS
	Select TotalRecords as Total_Records_Monitored
		,TotalMatched as PropertiesMatched
		,TotalUnMatched as PropertiesNotMatched
		,TotalMultiplePropertiesFound as MultiplePropertiesMatched
		,TotalInCoverage as InCoverage
		,TotalNotInCoverage as NotInCoverage
		,TotalAddressStandardized as AddressStandardized
		,TotalAddressNotStandardized as AddressNotStandardized
		,TotalWithEventsFound as EventsFound
		,TotalWithoutEventsFound as EventsNotFound
		,DocImageCounts
		FROM [zCust_PropertyOnion].[dbo].[ADS_COUNTS] 
		WHERE CreateDate = (Select MAX(CreateDate) from [zCust_PropertyOnion].[dbo].[ADS_COUNTS])


		

		
		Insert into [JOBS].[dbo].[_Counts] (Customer,JobType,FIPS,STATE,COUNTY,Count,Rundate)
		Select 'PropertyOnion','Batch_RECORDS',A.FIPS,B.STATE,B.[County Name],count(*) ,(Select max([CreateDate]) from [zCust_PropertyOnion].[dbo].[ADS_COUNTS]) 
		From [zCust_PropertyOnion].[dbo].[a_PropMatch_Work_FLANK] as A join [Global].[dbo].[County] as B with(NOLOCK)
		on A.FIPS = B.FIPSCODE
		Group by A.FIPS,B.STATE,B.[County Name]
		Order by A.FIPS,B.STATE,B.[County Name]

		Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
		where Ticketnumber = '4932'

		--Delete from [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
		--where ID = 235132


		-------Added 20210830 to track-----
		--Truncate table [x_Custom_OUTPUT_ALL]

		

		

		Insert into [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT_ALL]
		Select *, convert(date,Getdate()) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT]

		--Truncate table [x_Custom_OUTPUT_ALL]

		--DECLARE @FIELDNAME varchar(500)
		--DECLARE CLEAN_cursor CURSOR FOR  
		--Select '[' + NAME + ']' From sys.tables
		--where NAME like 'zzz%OUTPUT'
		--and NAME > 'zzz_ProprtyOnion_202106042321167100_OUTPUT'
		--order by NAME

		--	OPEN CLEAN_cursor   
		--	FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME

		--	WHILE @@FETCH_STATUS = 0   
		--		BEGIN   
		--				EXEC('
		--				Insert into [x_Custom_OUTPUT_ALL]
		--				Select * From ' + @FIELDNAME + ' 
		--				')
			

		--			FETCH NEXT FROM CLEAN_cursor INTO @FIELDNAME   
		--		END   

		--CLOSE CLEAN_cursor   
		--DEALLOCATE CLEAN_cursor

		
		


			INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			--INSERT INTO DATA.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			SELECT [AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,LEFT(LTRIM(RTRIM([CMASProductCode])),3)
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate]
		FROM [zCust_PropertyOnion].[dbo].[ADS_COUNTS]
		WHERE [SentToBilling] is NULL

		UPDATE [zCust_PropertyOnion].[dbo].[ADS_COUNTS]
		SET [SentToBilling] = 'Y'
		WHERE [SentToBilling] is NULL


		

END





