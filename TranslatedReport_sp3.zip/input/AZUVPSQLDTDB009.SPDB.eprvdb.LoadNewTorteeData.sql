/* Source: DWS-ETL02.DATATREE.LOCAL | spdb | eprvdb.LoadNewTorteeData | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

/* =================================================================================================
	Author:			?
	Create date:	08/14/2020
	Description:	This procedure will load the data from the tortee text files that are loaded in the
					xxx_table for processing 
					(xxx = Document, Name, Property and Reference)

	CHANGE LOG:    
	==========    
	WHO		DATE		CHANGE  
	+-------+-----------+---------------------------------------------------------------------------
	Henk	01/23/2025	Added recording document page count column
						Change logic to update page count if the record already exists
	Henk	05/15/2025	Add check on recording year
	Henk	08/25/2025	Change CountyCodes to synchronized table on EPR_VDB_TORTEE ftom VerifiedRecord
	Henk	09/05/2025	Add Legal_Desc_District to property table
	Henk	11/19/2025	Add Easement, Property_Type, Air_Rights, Subterranean_Rights, Street_Number, 
						Street_Name, Addr_Unit to property table
==================================================================================================== */
CREATE PROCEDURE [SPDB].[eprvdb].[LoadNewTorteeData]
AS
EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info'
	,N'LoadNewTorteeData'
	,N'Started'

SET XACT_ABORT ON

BEGIN TRANSACTION

UPDATE [SPDB].[eprvdb].[t]
SET t.[cmt_docnumber] = ltrim(t.[cmt_docnumber])
	,t.Doc_Type = ltrim(t.Doc_Type)
FROM [EPR_VDB_TORTEE].[dbo].[Document_table] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id IS NULL
	AND isnumeric(t.fips_code) = 1
	AND isnumeric(t.cmt_id) = 1
	AND (
		t.[cmt_docnumber] <> ltrim(t.[cmt_docnumber])
		OR t.Doc_Type <> ltrim(t.Doc_Type)
		)

UPDATE [SPDB].[eprvdb].[t]
SET t.[cmt_docnumber] = ltrim(t.[cmt_docnumber])
	,t.Doc_Type = ltrim(Doc_Type)
FROM [EPR_VDB_TORTEE].[dbo].[Property_table] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id IS NULL
	AND isnumeric(t.fips_code) = 1
	AND isnumeric(t.cmt_id) = 1
	AND (
		t.[cmt_docnumber] <> ltrim(t.[cmt_docnumber])
		OR t.Doc_Type <> ltrim(t.Doc_Type)
		)

UPDATE [SPDB].[eprvdb].[t]
SET t.[cmt_docnumber] = ltrim(t.[cmt_docnumber])
	,t.Doc_Type = ltrim(Doc_Type)
FROM [EPR_VDB_TORTEE].[dbo].[NAme_table] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id IS NULL
	AND isnumeric(t.fips_code) = 1
	AND isnumeric(t.cmt_id) = 1
	AND (
		t.[cmt_docnumber] <> ltrim(t.[cmt_docnumber])
		OR t.Doc_Type <> ltrim(t.Doc_Type)
		)

UPDATE [SPDB].[eprvdb].[t]
SET t.[cmt_docnumber] = ltrim(t.[cmt_docnumber])
	,t.Doc_Type = ltrim(Doc_Type)
FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id IS NULL
	AND isnumeric(t.fips_code) = 1
	AND isnumeric(t.cmt_id) = 1
	AND (
		t.[cmt_docnumber] <> ltrim(t.[cmt_docnumber])
		OR t.Doc_Type <> ltrim(t.Doc_Type)
		)

DECLARE @DocumentInserted TABLE (Doc_Id INT NOT NULL PRIMARY KEY)

INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] with(tablock) (
	[doc_unique_id]
	,[source_PK]
	,[fips_code]
	,[cmt_docnumber]
	,[cmt_id]
	,[source]
	,[county]
	,[state]
	,[recording_date]
	,[recording_time]
	,[recording_book]
	,[recording_page]
	,[recording_year]
	,[recording_doc_number]
	,[recording_doc_number_alternate]
	,[recording_doc_sequence_number]
	,[doc_title]
	,[doc_type]
	,[doc_date]
	,[doc_filing_date]
	,[case_number]
	,[ordinance_number]
	,[resolution_number]
	,[tax_account_serial_warrant_number]
	,[water_rights_number]
	,[loan_financed_amount]
	,[recording_fee_1]
	,[transfer_sale_purchase_price]
	,[remarks]
	,[alt_cmt_docnumber]
	,[alt_cmt_id]
	,[Return_To_Name_Identifier]
	,[Return_To_Last_Company_Name]
	,[Return_To_First_Name]
	,[Return_To_Suffix]
	,[Return_to_Address]
	,[Return_to_City]
	,[Return_to_State]
	,[Return_to_Zip]
	,[Return_to_Middle_Name]
	,[Transfer_Tax_county]
	,[MERS_Flag]
	,[m_status_id]
	,[m_create_date]
	,[Amount_Due]
	,[Transfer_Tax]
	,[Transfer_Tax_State]
	,[Transfer_Tax_City]
	,recording_page_count
	)
OUTPUT inserted.source_PK
INTO @DocumentInserted(Doc_Id)
SELECT NULL AS doc_unique_id
	,t.doc_id AS source_PK
	,try_cast(t.fips_code AS INT) AS fips_code
	,substring(ltrim(rtrim(t.[cmt_docnumber])), 1, 200) AS cmt_docnumber
	,try_cast(t.[cmt_id] AS INT) AS cmt_id
	,'FAI' AS source
	,substring(c.CountyName, 1, 200) AS county
	,substring(c.STATE, 1, 200) AS STATE
	,substring(ltrim(Rtrim(t.[recording_date])), 5, 4) + substring(ltrim(Rtrim(t.[recording_date])), 1, 4)
	,try_cast(ltrim(rtrim(t.[recording_time])) AS VARCHAR(200)) AS [recording_time]
	,substring(ltrim(rtrim(t.[recording_book])), 1, 200) AS [recording_book]
	,substring(ltrim(rtrim(t.[recording_page])), 1, 200) AS [recording_page]
	,substring(ltrim(rtrim(t.[recording_year])), 1, 200) AS [recording_year]
	,substring(ltrim(rtrim(t.[recording_doc_number])), 1, 200) AS [recording_doc_number]
	,substring(ltrim(rtrim(t.[recording_doc_number_alternate])), 1, 200) AS [recording_doc_number_alternate]
	,1 AS [recording_doc_sequence_number]
	,substring(ltrim(rtrim(t.[doc_title])), 1, 200) AS [doc_title]
	,substring(ltrim(rtrim(t.[doc_type])), 1, 250) AS [doc_type]
	,substring(ltrim(Rtrim(t.[doc_date])), 5, 4) + substring(ltrim(Rtrim(t.[doc_date])), 1, 4) AS [doc_date]
	,substring(ltrim(rtrim(t.[doc_filing_date])), 1, 200) AS [doc_filing_date]
	,substring(ltrim(rtrim(t.[case_number])), 1, 200) AS [case_number]
	,substring(ltrim(rtrim(t.[ordinance_number])), 1, 200) AS [ordinance_number]
	,substring(ltrim(rtrim(t.[resolution_number])), 1, 200) AS [resolution_number]
	,substring(ltrim(rtrim(t.[tax_account_serial_warrant_number])), 1, 200) AS [tax_account_serial_warrant_number]
	,substring(ltrim(rtrim(t.[water_rights_number])), 1, 200) AS [water_rights_number]
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[loan_financed_amount], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS loan_financed_amount
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[recording_fee_1], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS recording_fee_1
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[transfer_sale_purchase_price], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS transfer_sale_purchase_price
	,ltrim(rtrim(t.[remarks])) AS [remarks]
	,ltrim(rtrim(t.[alt_cmt_docnumber])) AS alt_cmt_docnumber
	--,ltrim(rtrim(replace(t.[alt_cmt_id],'"',''))) AS alt_cmt_id
	,CASE 
		WHEN isnumeric(ltrim(rtrim(t.[alt_cmt_id]))) = 1
			THEN ltrim(rtrim(t.[alt_cmt_id]))
		ELSE NULL
		END AS alt_cmt_id
	,substring(ltrim(rtrim(t.[Return_To_Name_Identifier])), 1, 200) AS Return_To_Name_Identifier
	,substring(ltrim(rtrim(t.[Return_To_Last_Company_Name])), 1, 200) AS Return_To_Last_Company_Name
	,substring(ltrim(rtrim(t.[Return_To_First_Name])), 1, 200) AS Return_To_First_Name
	,substring(ltrim(rtrim(t.[Return_To_Suffix])), 1, 200) AS Return_To_Suffix
	,substring(ltrim(rtrim(t.[Return_to_Address])), 1, 200) AS Return_to_Address
	,substring(ltrim(rtrim(t.[Return_to_City])), 1, 200) AS Return_to_City
	,substring(ltrim(rtrim(t.[Return_to_State])), 1, 200) AS Return_to_State
	,substring(ltrim(rtrim(t.[Return_to_Zip])), 1, 200) AS Return_to_Zip
	,substring(ltrim(rtrim(t.[Return_to_Middle_Name])), 1, 200) AS Return_to_Middle_Name
	,substring(ltrim(rtrim(t.[Transfer_Tax_county])), 1, 200) AS Transfer_Tax_county
	,substring(ltrim(rtrim(t.[MERS_Flag])), 1, 200) AS MERS_Flag
	,1 AS [m_status_id]
	,getdate() AS [m_create_date]
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[Amount_Due], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS [Amount_Due]
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[Transfer_Tax], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS [Transfer_Tax]
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[Transfer_Tax_State], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS [Transfer_Tax_State]
	,try_cast(nullif(REplace(rtrim(ltrim(replace(t.[Transfer_Tax_City], ' ', ''))), ',', ''), '') AS DECIMAL(15, 2)) AS [Transfer_Tax_City]
	,recording_page_count
FROM [EPR_VDB_TORTEE].[dbo].[Document_table] t with(nolock, index(idx_m_status_id_nc))
LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c with(nolock) ON c.Fips_Code = t.fips_code -- cast(t.fips_code AS INT)
OUTER APPLY (
	SELECT substring(ltrim(rtrim(t.[recording_year])), 1, 200) AS recYear
) ry
OUTER APPLY (
	SELECT CASE 
		WHEN PATINDEX('%[^0-9]%', ry.recYear)=0 AND ry.recYear >= 1900 AND ry.recYear <= YEAR(GETDATE())
			THEN ry.recYear
		WHEN ISDATE(substring(ltrim(Rtrim(t.[recording_date])), 5, 4) + substring(ltrim(Rtrim(t.[recording_date])), 1, 4))=1
			THEN substring(ltrim(Rtrim(t.[recording_date])), 1, 4)
		ELSE NULL
	END AS recording_year
) a
WHERE t.m_status_id IS NULL
	AND isnumeric(t.fips_code) = 1
	AND isnumeric(t.cmt_id) = 1
	AND (
		SELECT count(1)
		FROM [epr_vdb_tortee].[ur_tortee].[Document] pn with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
		WHERE pn.fips_code = try_cast(t.fips_code AS INT)
			AND pn.cmt_docnumber = ltrim(t.cmt_docnumber)
			AND pn.cmt_id = t.cmt_id
			AND pn.Doc_Type = t.Doc_Type
		) = 0

/*******************************************************************************************************
	For the documents that were not inserted as they already exists, update their corresponding document
	page count from the source table if it has a zero page count
*******************************************************************************************************/
UPDATE [SPDB].[eprvdb].[urd]
SET urd.recording_page_count = ddt.recording_page_count
FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] urd
INNER JOIN [EPR_VDB_TORTEE].[dbo].[Document_table] ddt with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc)) ON try_cast(urd.fips_code AS INT) = try_cast(ddt.fips_code AS INT)
	AND ltrim(urd.cmt_docnumber) = ltrim(ddt.cmt_docnumber)
	AND urd.cmt_id = ddt.cmt_id
	AND urd.Doc_Type = ddt.Doc_Type
WHERE ddt.doc_id NOT IN (
		SELECT doc_id
		FROM @DocumentInserted
		)
	AND ISNULL(urd.recording_page_count, 0) = 0
	AND ISNULL(ddt.recording_page_count,0) > 0

/*******************************************************************************************************
--
--Property
--
*******************************************************************************************************/
DECLARE @PropertyInserted TABLE (
	Id INT NOT NULL PRIMARY KEY
	,Doc_Id INT NOT NULL
	)

INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[PROPERTY] with(tablock) (
	[doc_id]
	,[FIPS]
	,[State]
	,[County]
	,[SSCC]
	,[doc_unique_id]
	,[cmt_docnumber]
	,[cmt_id]
	,[alt_cmt_docnumber]
	,[alt_cmt_id]
	,[doc_type]
	,[property_id_sequence_number]
	,[legal_type]
	,[legal_type_sequence]
	,[legal_desc_abstract_portion]
	,[legal_desc_abstract_acreage]
	,[legal_desc_abstract_name]
	,[legal_desc_abstract_number]
	,[legal_desc_address]
	,[legal_desc_address_city]
	,[legal_desc_address_state]
	,[legal_desc_address_zip]
	,[legal_desc_apn]
	,[legal_desc_map_portion]
	,[legal_desc_map_lot_low]
	,[legal_desc_map_block]
	,[legal_desc_map_plat_name]
	,[legal_desc_map_plat_number]
	,[legal_desc_map_plat_type_indicator]
	,[legal_desc_map_plat_book]
	,[legal_desc_map_plat_page]
	,[legal_desc_str_portion]
	,[legal_desc_str_quarter]
	,[legal_desc_str_section]
	,[legal_desc_str_township]
	,[legal_desc_str_range]
	,[property_sequence]
	,[Legal_Desc_Map_Lot_High]
	,[Legal_Desc_Map_Unit_low]
	,[Legal_Desc_STR_Government_Lot]
	,[m_status_id]
	,[m_create_date]
	,[Legal_Desc_Tax_Assessor_Block]
	,[Legal_Desc_Tax_Assessor_Lot]
	,[Legal_Desc_APN_Portion]
	,[Source_PK]
	,[Legal_Desc_District]
	,Easement
	,Property_Type
	,Air_Rights
	,Subterranean_Rights
	,Street_Number
	,Street_Name
	,Addr_Unit
)
OUTPUT inserted.Source_PK
	,inserted.doc_id
INTO @PropertyInserted(Id, Doc_Id)
SELECT d.doc_id AS doc_id
	,x.fips
	,c.[State]
	,c.CountyName
	,c.[SSCC]
	,NULL AS doc_unique_id
	,substring(ltrim(rtrim(p.[cmt_docnumber])), 1, 200) AS cmt_docnumber
	,try_cast(p.[cmt_id] AS INT) AS cmt_id
	,substring(Ltrim(rtrim(p.[alt_cmt_docnumber])), 1, 200) AS alt_cmt_docnumber
	,CASE 
		WHEN isnumeric(ltrim(rtrim(p.[alt_cmt_id]))) = 1
			THEN ltrim(rtrim(p.[alt_cmt_id]))
		ELSE NULL
		END AS alt_cmt_id
	,substring(Ltrim(rtrim(p.[doc_type])), 1, 250) AS [doc_type]
	,p.Sequence_Number AS [property_id_sequence_number]
	,NULL AS legal_type
	,NULL AS legal_type_sequence
	,substring(Ltrim(rtrim(p.[legal_desc_abstract_portion])), 1, 200) AS [legal_desc_abstract_portion]
	,substring(Ltrim(rtrim(p.[legal_desc_abstract_acreage])), 1, 200) AS [legal_desc_abstract_acreage]
	,substring(Ltrim(rtrim(p.[legal_desc_abstract_name])), 1, 200) AS [legal_desc_abstract_name]
	,substring(Ltrim(rtrim(p.[legal_desc_abstract_number])), 1, 200) AS [legal_desc_abstract_number]
	,substring(Ltrim(rtrim(p.[legal_desc_address])), 1, 200) AS [legal_desc_address]
	,substring(Ltrim(rtrim(p.[legal_desc_address_city])), 1, 200) AS [legal_desc_address_city]
	,substring(Ltrim(rtrim(p.[legal_desc_address_state])), 1, 200) AS [legal_desc_address_state]
	,substring(Ltrim(rtrim(p.[legal_desc_address_zip])), 1, 200) AS [legal_desc_address_zip]
	,substring(Ltrim(rtrim(p.[legal_desc_apn])), 1, 200) AS [legal_desc_apn]
	,substring(Ltrim(rtrim(p.[legal_desc_map_portion])), 1, 200) AS [legal_desc_map_portion]
	,substring(Ltrim(rtrim(p.[legal_desc_map_lot_low])), 1, 200) AS [legal_desc_map_lot_low]
	,substring(Ltrim(rtrim(p.[legal_desc_map_block])), 1, 200) AS [legal_desc_map_block]
	,substring(Ltrim(rtrim(p.[legal_desc_map_plat_name])), 1, 200) AS [legal_desc_map_plat_name]
	,substring(Ltrim(rtrim(p.[legal_desc_map_plat_number])), 1, 200) AS [legal_desc_map_plat_number]
	,substring(Ltrim(rtrim(p.[legal_desc_map_plat_type_indicator])), 1, 200) AS [legal_desc_map_plat_type_indicator]
	,substring(Ltrim(rtrim(p.[legal_desc_map_plat_book])), 1, 200) AS [legal_desc_map_plat_book]
	,substring(Ltrim(rtrim(p.[legal_desc_map_plat_page])), 1, 200) AS [legal_desc_map_plat_page]
	,substring(Ltrim(rtrim(p.[legal_desc_str_portion])), 1, 200) AS [legal_desc_str_portion]
	,substring(Ltrim(rtrim(p.[legal_desc_str_quarter])), 1, 200) AS [legal_desc_str_quarter]
	,substring(Ltrim(rtrim(p.[legal_desc_str_section])), 1, 200) AS [legal_desc_str_section]
	,substring(Ltrim(rtrim(p.[legal_desc_str_township])), 1, 200) AS [legal_desc_str_township]
	,substring(Ltrim(rtrim(p.[legal_desc_str_range])), 1, 200) AS [legal_desc_str_range]
	,NULL AS [property_sequence]
	,substring(Ltrim(rtrim([Legal_Desc_Map_Lot_High])), 1, 200) AS Legal_Desc_Map_Lot_High
	,substring(Ltrim(rtrim([Legal_Desc_Map_Unit_low])), 1, 200) AS Legal_Desc_Map_Unit_low
	,substring(Ltrim(rtrim([Legal_Desc_STR_Government_Lot])), 1, 200) AS Legal_Desc_STR_Government_Lot
	,1 AS [m_status_id]
	,getdate() AS [m_create_date]
	,substring(Ltrim(rtrim(p.[Legal_Desc_Tax_Assessor_Block])), 1, 200) AS [Legal_Desc_Tax_Assessor_Block]
	,substring(Ltrim(rtrim(p.[Legal_Desc_Tax_Assessor_Lot])), 1, 200) AS [Legal_Desc_Tax_Assessor_Lot]
	,substring(Ltrim(rtrim(p.[Legal_Desc_APN_Portion])), 1, 200) AS [Legal_Desc_APN_Portion]
	,p.Id AS Source_PK
	,p.Legal_Desc_District
	,p.Easement
	,p.Property_Type
	,p.Air_Rights
	,p.Subterranean_Rights
	,p.Street_Number
	,p.Street_Name
	,p.Addr_Unit
FROM [EPR_VDB_TORTEE].[dbo].[Property_table] p  with(nolock, index(idx_m_status_id_nc))
CROSS APPLY (
	SELECT TOP 1 *
	FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d  with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
	WHERE d.fips_code = try_cast(p.fips_code AS INT)
		AND d.cmt_docnumber = ltrim(p.cmt_docnumber)
		AND d.cmt_id = p.cmt_id
		AND d.Doc_Type = p.Doc_Type
	ORDER BY doc_id DESC
) d
LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c with(nolock) ON c.Fips_Code = D.Fips_code
OUTER APPLY (
	SELECT CASE 
		WHEN c.Fips_Code IS NULL
			THEN RIGHT('000' + try_cast(D.Fips_code AS VARCHAR),5)
		ELSE c.Fips_Code
		END AS fips
) x
WHERE p.m_status_id IS NULL
	AND isnumeric(p.fips_code) = 1
	AND isnumeric(p.cmt_id) = 1
	AND (
		SELECT count(1)
		FROM [epr_vdb_tortee].[ur_tortee].[Property] pn with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
		WHERE pn.fips = p.FIPS_Code
			AND pn.cmt_docnumber = ltrim(p.cmt_docnumber)
			AND pn.cmt_id = p.cmt_id
			AND pn.Doc_Type = p.Doc_Type
		) = 0

/*******************************************************************************************************
--
--Name
--
*******************************************************************************************************/
DECLARE @NameInserted TABLE (
	Id INT NOT NULL PRIMARY KEY
	,Doc_Id INT NOT NULL
	)

INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[NAME] with(tablock) (
	[doc_id]
	,[FIPS]
	,[State]
	,[County]
	,[SSCC]
	,[cmt_docnumber]
	,[cmt_id]
	,[alt_cmt_docnumber]
	,[alt_cmt_id]
	,[doc_type]
	,[doc_unique_id]
	,[sequence_number]
	,[name_identifier]
	,[name_code]
	,[role_type]
	,[COUNTY_party_name]
	,[last_company_name]
	,[first_name]
	,[middle_name]
	,[suffix]
	,[m_status_id]
	,[m_create_date]
	,[Source_PK]
	)
--,[m_update_date]
OUTPUT inserted.Source_PK
	,inserted.doc_id
INTO @NameInserted(Id, Doc_Id)
SELECT d.[doc_id]
	,x.fips
	,c.[State]
	,c.CountyName
	,c.[SSCC]
	,substring(ltrim(rtrim(n.[cmt_docnumber])), 1, 200) AS cmt_docnumber
	,CASE 
		WHEN isnumeric(ltrim(rtrim(n.[cmt_id]))) = 1
			THEN ltrim(rtrim(n.[cmt_id]))
		ELSE NULL
		END AS cmt_id
	,substring(ltrim(rtrim(n.[alt_cmt_docnumber])), 1, 200) AS alt_cmt_docnumber
	,CASE 
		WHEN isnumeric(ltrim(rtrim(n.[alt_cmt_id]))) = 1
			THEN ltrim(rtrim(n.[alt_cmt_id]))
		ELSE NULL
		END AS alt_cmt_id
	,substring(ltrim(rtrim(n.[doc_type])), 1, 250) AS [doc_type]
	,NULL AS [doc_unique_id]
	,substring(Ltrim(rtrim(n.[sequence_number])), 1, 200) sequence_number
	,substring(Ltrim(rtrim(n.[name_identifier])), 1, 1) AS name_identifier
	,substring(Ltrim(rtrim(substring(n.[name_code], 1, 200))), 1, 200) AS name_code
	,substring(Ltrim(rtrim(substring(n.[role_type], 1, 200))), 1, 200) AS role_type
	,substring(Ltrim(rtrim(n.[COUNTY_party_name])), 1, 200) AS COUNTY_party_name
	,substring(Ltrim(rtrim(n.[last_company_name])), 1, 200) AS last_company_name
	,substring(Ltrim(rtrim(substring(n.[first_name], 1, 200))), 1, 200) AS first_name
	,substring(Ltrim(rtrim(substring(n.[middle_name], 1, 200))), 1, 200) AS middle_name
	,substring(Ltrim(rtrim(substring(n.[suffix], 1, 200))), 1, 200) AS suffix
	,1 AS [m_status_id]
	,getdate() AS [m_create_date]
	,n.Id AS Source_PK
FROM [EPR_VDB_TORTEE].[dbo].[Name_Table] n with(nolock, index(idx_m_status_id_nc))
CROSS APPLY (
	SELECT TOP 1 *
	FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
	WHERE d.fips_code = try_cast(n.fips_code AS INT)
		AND d.cmt_docnumber = ltrim(rtrim(n.cmt_docnumber))
		AND d.cmt_id = n.cmt_id
		AND d.Doc_Type = n.Doc_Type
	ORDER BY doc_id DESC
	) d
LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c with(nolock) ON c.Fips_Code = D.Fips_code
OUTER APPLY (
	SELECT CASE 
		WHEN c.Fips_Code IS NULL
			THEN RIGHT('000' + try_cast(D.Fips_code AS VARCHAR),5)
		ELSE c.Fips_Code
		END AS fips
) x
--AND d.m_create_date = getdate()
WHERE n.m_status_id IS NULL
	AND isnumeric(n.fips_code) = 1
	AND isnumeric(n.cmt_id) = 1
	AND (
		SELECT count(1)
		FROM [epr_vdb_tortee].[ur_tortee].[NAME] pn with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
		WHERE pn.fips = n.fips_code
			AND pn.cmt_docnumber = ltrim(n.cmt_docnumber)
			AND pn.cmt_id = n.cmt_id
			AND pn.Doc_Type = n.Doc_Type
		) = 0

/*******************************************************************************************************
--
-- References
--
*******************************************************************************************************/
DECLARE @ReferenceInserted TABLE (
	Id INT NOT NULL PRIMARY KEY
	,Doc_Id INT NOT NULL
	)

INSERT INTO [EPR_VDB_TORTEE].[ur_tortee].[REFERENCE] with(tablock) (
	[doc_id]
	,[FIPS]
	,[State]
	,[County]
	,[SSCC]
	,[doc_unique_id]
	,[cmt_docnumber]
	,[cmt_id]
	,[alt_cmt_docnumber]
	,[alt_cmt_id]
	,[doc_type]
	,[reference_id_sequence_number]
	,[reference_type_code]
	,[reference_book]
	,[reference_page]
	,[reference_recording_year]
	,[reference_doc_number]
	,[reference_recording_date]
	,CMT_reference_doc_number
	,cmt_Reference_Book_Page
	,[m_status_id]
	,[m_create_date]
	,[Source_PK]
	)
OUTPUT inserted.Source_PK
	,inserted.doc_id
INTO @ReferenceInserted(Id, Doc_Id)
SELECT d.[doc_id]
	,x.fips
	,c.[State]
	,c.[CountyName]
	,c.[SSCC]
	,NULL AS [doc_unique_id]
	,ltrim(rtrim(r.[cmt_docnumber])) AS [cmt_docnumber]
	,CASE 
		WHEN isnumeric(ltrim(rtrim(r.[cmt_id]))) = 1
			THEN ltrim(rtrim(r.[cmt_id]))
		ELSE NULL
		END AS cmt_id
	,substring(ltrim(rtrim(r.[alt_cmt_docnumber])), 1, 200) AS alt_cmt_docnumber
	,CASE 
		WHEN isnumeric(ltrim(rtrim(r.[alt_cmt_id]))) = 1
			THEN ltrim(rtrim(r.[alt_cmt_id]))
		ELSE NULL
		END AS alt_cmt_id
	,substring(ltrim(rtrim(r.[doc_type])), 1, 250) AS [doc_type]
	,NULL AS [reference_id_sequence_number]
	,NULL AS [reference_type_code]
	,substring(Ltrim(rtrim(r.[reference_book])), 1, 200) AS [reference_book]
	,substring(Ltrim(rtrim(r.[reference_page])), 1, 200) AS [reference_page]
	,substring(Ltrim(rtrim(r.[reference_recording_year])), 1, 200) AS [reference_recording_year]
	,substring(Ltrim(rtrim(r.[reference_doc_number])), 1, 200) AS [reference_doc_number]
	,substring(Ltrim(rtrim(r.[reference_recording_date])), 1, 200) AS [reference_recording_date]
	,substring(Ltrim(rtrim(r.CMT_reference_doc_number)), 1, 200) AS CMT_reference_doc_number
	,substring(Ltrim(rtrim(r.cmt_Reference_Book_Page)), 1, 200) AS cmt_Reference_Book_Page
	,1 AS [m_status_id]
	,getdate() AS [m_create_date]
	,r.Id AS Source_PK
FROM [EPR_VDB_TORTEE].[dbo].[Reference_table] r with(nolock, index(idx_m_status_id_nc))
CROSS APPLY (
	SELECT TOP 1 *
	FROM [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
	WHERE d.fips_code = try_cast(r.fips_code AS INT)
		AND d.cmt_docnumber = r.cmt_docnumber
		AND d.cmt_id = r.cmt_id
		AND d.Doc_Type = r.Doc_Type
	ORDER BY doc_id DESC
	) d
LEFT JOIN [EPR_VDB_TORTEE].[dbo].[CountyCodes] c with(nolock) ON c.Fips_Code = D.Fips_code
OUTER APPLY (
	SELECT CASE 
		WHEN c.Fips_Code IS NULL
			THEN RIGHT('000' + try_cast(D.Fips_code AS VARCHAR),5)
		ELSE c.Fips_Code
		END AS fips
) x
WHERE r.m_status_id IS NULL
	AND isnumeric(r.fips_code) = 1
	AND isnumeric(r.cmt_id) = 1
	AND (
		SELECT count(1)
		FROM [epr_vdb_tortee].[ur_tortee].[Reference] pn with(nolock, index(idx_FIPS_Code_cmt_docnumber_cmt_id_doc_type_nc))
		WHERE pn.fips = R.fips_code
			AND pn.cmt_docnumber = R.cmt_docnumber
			AND pn.cmt_id = R.cmt_id
			AND pn.Doc_Type = R.Doc_Type
		) = 0

/*******************************************************************************************************
--
--Update the documents inserted as successful
--
*******************************************************************************************************/
UPDATE [SPDB].[eprvdb].[p]
SET p.doc_id = d.source_PK
	,p.[m_status_id] = 2
FROM [EPR_VDB_TORTEE].[dbo].[PROPERTY_table] p with(tablock,index(PK_Property_table))
INNER JOIN @PropertyInserted i ON p.Id = i.Id
INNER JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d with(nolock,index(PK_DOCUMENT)) ON i.Doc_Id = d.doc_id

UPDATE [SPDB].[eprvdb].[n]
SET n.Doc_id = d.source_PK
	,n.[m_status_id] = 2
FROM [EPR_VDB_TORTEE].[dbo].[Name_Table] n with(tablock,index(PK_Name_table))
INNER JOIN @NameInserted i ON n.Id = i.Id
INNER JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d with(nolock,index(PK_DOCUMENT)) ON i.Doc_Id = d.doc_id

UPDATE [SPDB].[eprvdb].[r]
SET r.Doc_id = d.source_PK
	,r.[m_status_id] = 2
FROM [EPR_VDB_TORTEE].[dbo].[REFERENCE_table] r with(tablock,index(PK_Reference_table))
INNER JOIN @ReferenceInserted i ON r.Id = i.Id
INNER JOIN [EPR_VDB_TORTEE].[ur_tortee].[DOCUMENT] d with(nolock,index(PK_DOCUMENT)) ON i.Doc_Id = d.doc_id

UPDATE [SPDB].[eprvdb].[d]
SET d.[m_status_id] = 2
FROM [EPR_VDB_TORTEE].[dbo].[DOCUMENT_table] d with(tablock,index(PK_Document_table))
INNER JOIN @DocumentInserted i ON d.doc_id = i.Doc_Id

UPDATE [SPDB].[eprvdb].[t]
SET t.m_status_id = 2
FROM [EPR_VDB_TORTEE].[Ur_tortee].[Document] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id = 1

UPDATE [SPDB].[eprvdb].[t]
SET t.m_status_id = 2
FROM [EPR_VDB_TORTEE].[Ur_tortee].[NAME] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id = 1

UPDATE [SPDB].[eprvdb].[t]
SET t.m_status_id = 2
FROM [EPR_VDB_TORTEE].[Ur_tortee].[PROPERTY] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id = 1

UPDATE [SPDB].[eprvdb].[t]
SET t.m_status_id = 2
FROM [EPR_VDB_TORTEE].[Ur_tortee].[Reference] t with(tablock,index(idx_m_status_id_nc))
WHERE t.m_status_id = 1

COMMIT

DECLARE @cnt INT = (
		SELECT count(1)
		FROM @DocumentInserted
		) + (
		SELECT count(1)
		FROM @PropertyInserted
		) + (
		SELECT count(1)
		FROM @NameInserted
		) + (
		SELECT count(1)
		FROM @ReferenceInserted
		)
DECLARE @msg VARCHAR(100) = 'Ended - document Loaded: ' + try_cast(@cnt AS VARCHAR)

EXEC [SPDB].[EPRVDB].[AddTorteeLog] N'info'
	,N'LoadNewTorteeData'
	,@msg


