/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Sale_Amount_Calc_NDS | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Sale_Amount_Calc_NDS] @ERROR VARCHAR(500) OUTPUT
AS
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc_NDS'
		,N'Started'

	BEGIN
		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 1.01)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE ltrim(rtrim(d.US_STATE)) IN (
				SELECT codevalue
				FROM [lien].[dbo].[CodeTable]
				WHERE TableShortName = 'nondisc'
				)
			AND ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) IN (
				'FHA'
				,'FRA'
				)
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				
				)
			AND isnull(Deed_type, '') <> 'T'

		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = Floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 0.98)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE ltrim(rtrim(d.US_STATE)) IN (
				SELECT codevalue
				FROM [lien].[dbo].[CodeTable]
				WHERE TableShortName = 'nondisc'
				)
			AND ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) = 'VA'
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				)
			AND isnull(Deed_type, '') <> 'T'

		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = Floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 1.33)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE ltrim(rtrim(d.US_STATE)) IN (
				SELECT codevalue
				FROM [lien].[dbo].[CodeTable]
				WHERE TableShortName = 'nondisc'
				)
			AND (
				ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) NOT IN (
					'FHA'
					,'FRA'
					,'VA'
					)
				OR d.MTG1_MTG_LOAN_TYPE_CODE IS NULL
				OR len(ltrim(d.MTG1_MTG_LOAN_TYPE_CODE)) = 0
				)
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				)
			AND isnull(Deed_type, '') <> 'T'
	END

	-- B31690 - Removed below calculation on 2025/11/17 for 4005 and 4007
	
	BEGIN
		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = Floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 1.01)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE d.fips IN (
				--4005
				--,4007
				17117
				)
			AND ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) IN (
				'FHA'
				,'FRA'
				)
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				)
			AND isnull(Deed_type, '') <> 'T'

		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = Floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 0.98)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE d.fips IN (
				--4005
				--,4007
				17117
				)
			AND ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) = 'VA'
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				)
			AND isnull(Deed_type, '') <> 'T'

		UPDATE [lien_DTDB].[INFC].[d]
		SET d.SALE_AMOUNT = Floor(convert(BIGINT, d.MTG1_MTG_AMOUNT) * 1.33)
			,d.SALE_CODE = 'E'
		FROM [lien_DTDB].[infc].[deed_work] d
		WHERE d.fips IN (
				--4005
				--,4007
				17117
				)
			AND (
				ltrim(rtrim(d.MTG1_MTG_LOAN_TYPE_CODE)) NOT IN (
					'FHA'
					,'FRA'
					,'VA'
					)
				OR d.MTG1_MTG_LOAN_TYPE_CODE IS NULL
				OR len(ltrim(d.MTG1_MTG_LOAN_TYPE_CODE)) = 0
				)
			AND (
				isnull(d.SALE_AMOUNT, 0) = 0
				--OR len(ltrim(d.SALE_AMOUNT)) = 0
				)
			AND (
				isnull(d.MTG1_MTG_AMOUNT,0) > 0
				)
			AND isnull(Deed_type, '') <> 'T'
	END

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Sale_Amount_Calc_NDS'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

