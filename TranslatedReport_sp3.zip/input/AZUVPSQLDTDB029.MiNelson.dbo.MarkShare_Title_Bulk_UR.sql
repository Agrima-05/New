/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_Bulk_UR | type=P */

-- ===============================================================================================
-- Author:		My Phan
-- Create date: 8/8/2018
-- Description:	Create MarkShareTitle_Bulk
-- ================================================================================================
CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_Bulk_UR]
AS
SET NOCOUNT ON

BEGIN
	------ Incremental Run ----------------------------------
	---------------New MartketShare for MLS------------------------------------------------------
	----- step 1
	---------------------------
	/*IF OBJECT_ID('Minelson.mktshr.Marketshare_Deed_BK_Final') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[mktshr].[Marketshare_Deed_BK_Final]

	---------------------------BK Data ---------------------------------
	/*IF OBJECT_ID('Minelson.mktshr.Marketshare_Deed_BK') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[mktshr].[Marketshare_Deed_BK]

	SELECT MTG1_CONSTRUCTION_LOAN
		,REO_SALE_FLAG
		,REO_SALE
		,TRANSACTION_TYPE
		,MTG1_MTG_AMOUNT
		,Fips
		,MTG1_EQUITY_FLAG
		,MTG1_OTHER_SUBORDINATE_LOANS
		,MTG1_LENDER_LAST_NAME
		,TITLE_COMPANY_NAME
		,MULTI_APN
		,RECORDING_DATE
		,SALE_DATE
		,  case when (us_state = 'IN' and source_type = 'M' and Doc_nbr is null) then left(UR_REMARKS,20) else doc_nbr end  as DOC_NBR
		,Recording_Book
		,Recording_Page
		,DeedId
		,MTG1_DOC_NBR
		,DETAILED_DOC_TYPE
		,SALE_AMOUNT
		,MTG1_MTG_INTEREST_RATE_TYPE
		,MTG1_MTG_LOAN_TYPE_CODE
		,SELLER_NAME_PLAINTIFF_1
		,BYR1_OWN_NAME
		,BYR1_CORP_IND
		,SITUS_CITY
		,US_COUNTY
		,US_STATE
		,SITUS_ZIP_CODE
		,TITLE_COMPANY_CODE
		,DEED_TYPE
		,UPDATED
		,FORCLOSURE
		,RESALE_NEW_CONSTRUCTION
		,MTG1_PRIVATE_PARTY_LENDER
		,SELLER_NAME_PLAINTIFF1_CORP_IND
		,Sales_Source_Ind
		,---------------------change 2/4/2016 to filter AZ affidavits
		REF_ID
		,---------------------Added for update Attorney names 3/14/2016
		source_type
		,SRC_TBL
		,CLGX_UNIQUE_ID
		,MTG2_DOC_NBR
		,MTG2_MTG_AMOUNT
		,MTG2_CONSTRUCTION_LOAN
		,MTG2_EQUITY_FLAG
		,MTG2_LENDER_LAST_NAME
		,MTG2_MTG_INTEREST_RATE_TYPE
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_REFI_FLAG]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIp]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_REFI_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[FMT_DOC_NBR]
		,[FMT_Book_Page]
		,[FMT_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[FMT_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
	INTO [Minelson].[mktshr].[Marketshare_Deed_BK]
	FROM [Deed].[dbo].[Deed] t
	WHERE (
			isnull(Recording_Date, Sale_Date) >= '2022-01-01'
			AND (
				source_type = 'E'
				
				)
			AND (
				fips IN (
					SELECT fips
					FROM [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver_Bulk]
					WHERE source = 'E'
						AND fips NOT IN (
							SELECT fips
							FROM [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver]
							WHERE source = 'E'
							)
					)
				)
			)

	--OR --- adding new county 20211202
	--(isnull(Recording_Date,Sale_Date) >= '2013-01-01' 
	--and source_type = 'B'
	--and fips  = 48185
	--)
	

	----- change transaction type---
	UPDATE [MiNelson].[dbo].[a]
	SET a.transaction_type = '9'
		,sale_amount = NULL
	--select b.INTER_FAMILY, b.TRANSACTION_TYPE, DOC_TRANSFER_TAX, b.DETAILED_DOC_TYPE, b.sale_amount,*
	FROM [Minelson].[mktshr].[Marketshare_Deed_BK] a
	LEFT JOIN [deed].[dbo].[deed] b ON a.deedid = b.deedid
	WHERE a.fips --in (41005,41067,41051) --
		BETWEEN '41003'
			AND '41071'
		AND b.Source_type = 'e'
		AND b.deed_type = 'g'
		AND b.Sale_code IS NULL
		AND b.Sale_amount = (b.doc_transfer_tax) * 1000 / 1.00

	UPDATE [MiNelson].[dbo].[a]
	SET a.transaction_type = '9'
		,a.sale_amount = NULL
	--	select b.fips,b.US_COUNTY, b.APN_unformatted,b.DOC_NBR, b.INTER_FAMILY, b.TRANSACTION_TYPE, DOC_TRANSFER_TAX, 
	--b.DETAILED_DOC_TYPE, b.sale_amount, b.MTG1_MTG_AMOUNT,a.* , b.*
	FROM [Minelson].[mktshr].[Marketshare_Deed_BK] a
	LEFT JOIN [deed].[dbo].[deed] b ON a.deedid = b.deedid
	WHERE a.us_state = 'WA'
		AND left(a.recording_date, 7) >= '2022-01'
		AND b.[TRANSACTION_TYPE] IN ('1')
		AND DOC_TRANSFER_TAX IS NOT NULL
		AND DOC_TRANSFER_TAX < 300
		AND (
			(
				b.DETAILED_DOC_TYPE = 'WD'
				AND b.inter_family = 'y'
				)
			OR (b.DETAILED_DOC_TYPE <> 'WD')
			)

	
	-------------------------update original fields_---------------
	/*IF OBJECT_ID('Minelson.mktshr.Marketshare_Deed_BK_Final') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[mktshr].[Marketshare_Deed_BK_Final]

	SELECT *
	INTO [Minelson].[mktshr].[Marketshare_Deed_BK_Final]
	FROM [Minelson].[mktshr].[Marketshare_Deed_BK]

	
	--- step 3
	--------------------------------create Bk mtg1 and mtg2 report
	/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp1]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp1]

	SELECT DeedSequence
		,[Transaction Type]
		,[Lender]
		,[Title Company]
		,TITLE_COMPANY_CODE
		,[Attorney]
		,[Sale Document number]
		,[MGT Document number]
		,[Book/Page]
		,[Sales Price]
		,[Loan Amount]
		,[Loan To Value]
		,[Date]
		,[Adjustable Rate]
		,[Loan Type]
		,[Reverse Mortgage]
		,[Conforming]
		,[Builder]
		,[Seller Name]
		,[Buyer]
		,[Residential]
		,[Corporate]
		,[City]
		,[County]
		,[State]
		,[Zip Code]
		,[FIPS]
		,[Census Tract #]
		,[Property Type]
		,MTG1_CONSTRUCTION_LOAN
		,REO_SALE_FLAG
		,MTG1_EQUITY_FLAG
		,MTG1_OTHER_SUBORDINATE_LOANS
		,TRANSACTION_TYPE
		,DETAILED_DOC_TYPE
		,DEED_TYPE
		,FORCLOSURE
		,RESALE_NEW_CONSTRUCTION
		,MULTI_APN
		,DeedID
		,BYR1_CORP_IND
		,[CHECK] AS NBR_OF_RES_UNITS
		,MTG1_PRIVATE_PARTY_LENDER
		,SELLER_NAME_PLAINTIFF1_CORP_IND
		,Sales_Source_Ind
		,REF_ID
		,RECORDING_DATE
		,SALE_DATe
		,UPDATED
		,Ass_ZipCode
		,Year_Built
		,[FMT_DOC_NBR]
		,[FMT_Book_Page]
		,[FMT_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[FMT_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
	INTO [MiNelson].[dbo].[MarketShareTitle_Temp1]
	FROM (
		SELECT 1 AS DeedSequence
			,CASE 
				WHEN MTG1_CONSTRUCTION_LOAN = 'Y'
					THEN 'Construction Loan' -- Added 4/01/2015 
				WHEN (
						REO_SALE_FLAG = 1
						OR REO_SALE = 'Y'
						)
					AND deed.TRANSACTION_TYPE != 4
					THEN -- Added "Cash Sale" split 2/27/2015 -- Added REO_Sale ='Y' 4/13/15
						CASE 
							WHEN (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)
								AND mc.Fips IS NOT NULL
								THEN 'REO - Cash Sale'
							ELSE 'REO'
							END
				WHEN MTG1_EQUITY_FLAG = 'Y'
					THEN 'Home Equity'
				WHEN MTG1_OTHER_SUBORDINATE_LOANS = 'Y'
					THEN 'Other Subordinate Loan' -- Added 2/19/2015
				ELSE CASE deed.TRANSACTION_TYPE
						WHEN '1'
							THEN CASE 
									WHEN (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)
										AND mc.Fips IS NOT NULL
										THEN 'Resale - Cash Sale'
									ELSE 'Resale'
									END
						WHEN '2'
							THEN 'Refinance'
						WHEN '3'
							THEN CASE 
									WHEN (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)
										AND mc.Fips IS NOT NULL
										THEN 'Subdivision/Newhome - Cash Sale'
									ELSE 'Subdivision/Newhome'
									END
						WHEN '4'
							THEN CASE 
									WHEN (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)
										AND mc.Fips IS NOT NULL
										THEN 'Timeshare - Cash Sale'
									ELSE 'Timeshare'
									END
						WHEN '6'
							THEN 'Construction Loan'
						WHEN '7'
							THEN CASE 
									WHEN (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)
										AND mc.Fips IS NOT NULL
										THEN 'Resale - Cash Sale'
									ELSE 'Resale'
									END
						WHEN '9'
							THEN 'Refinance'
						ELSE ''
						END
				END AS [Transaction Type]
			,
			--isnull(deed.MTG1_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
			--isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			CASE 
				WHEN (
						deed.MTG1_LENDER_LAST_NAME IS NULL
						OR deed.MTG1_LENDER_LAST_NAME = ''
						)
					THEN 'UNKNOWN'
				ELSE deed.MTG1_LENDER_LAST_NAME
				END AS [Lender]
			,CASE 
				WHEN (
						deed.TITLE_COMPANY_NAME IS NULL
						OR deed.TITLE_COMPANY_NAME = ''
						)
					THEN 'UNKNOWN'
				ELSE deed.TITLE_COMPANY_NAME
				END AS [Title Company]
			,'UNKNOWN' AS [Attorney]
			,MTG1_EQUITY_FLAG
			,deed.MULTI_APN
			,--
			--row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
			row_number() OVER (
				PARTITION BY deed.FIPS
				,isnull(deed.RECORDING_DATE, deed.SALE_DATE)
				,CASE 
					WHEN isnull(deed.DOC_NBR, '') <> ''
						THEN deed.DOC_NBR
					ELSE (deed.Recording_Book + '/' + deed.Recording_Page)
					END ORDER BY deed.MULTI_APN Desc
					,deed.DeedId
				) AS [rn]
			,-- Corrected problem with row_number 3/09/15----- 4/14 Add DeedID
			deed.DOC_NBR AS [Sale Document number]
			,deed.MTG1_DOC_NBR AS [MGT Document number]
			,deed.DETAILED_DOC_TYPE AS [Detailed Doc Type]
			,
			--     (deed.MTG1_RECORDING_BOOK + '/' + deed.MTG1_RECORDING_PAGE) as 'Book/Page', -- change 7/6/2015 make unique keys
			(deed.Recording_Book + '/' + deed.Recording_Page) AS 'Book/Page'
			,-- change 7/6/2015 make unique keys
			isnull(deed.SALE_AMOUNT, 0) AS [Sales Price]
			,-- Reformatted as currency 2/27/2015
			--'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
			isnull(deed.MTG1_MTG_AMOUNT, 0) AS [Loan Amount]
			,-- Reformatted as currency 2/27/2015
			--'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
			CASE 
				WHEN deed.MTG1_MTG_AMOUNT IS NOT NULL
					AND deed.SALE_AMOUNT IS NOT NULL
					AND deed.SALE_AMOUNT != 0
					THEN convert(VARCHAR(15), round(convert(FLOAT, deed.MTG1_MTG_AMOUNT / deed.SALE_AMOUNT * 100), 2)) + '%'
				ELSE 'No Data'
				END AS [Loan To Value]
			,isnull(deed.RECORDING_DATE, deed.SALE_DATE) AS [Date]
			,
			-- case when deed.US_STATE = 'KS' ---------adding 4/29/15 ----------take out 5/4/15
			--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
			--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
			CASE 
				WHEN deed.MTG1_MTG_INTEREST_RATE_TYPE = 'ADJ'
					THEN 'YES'
				ELSE 'NO'
				END AS [Adjustable Rate]
			,
			--deed.MTG1_MTG_LOAN_TYPE_CODE,
			CASE deed.MTG1_MTG_LOAN_TYPE_CODE
				WHEN 'CNV'
					THEN 'Conventional'
				WHEN 'FHA'
					THEN 'FHA'
				WHEN 'VA'
					THEN 'VA'
				ELSE 'none'
				END AS [Loan Type]
			,
			--case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
			CASE 
				WHEN rm.Fips IS NOT NULL
					OR deed.MTG1_DETAILED_DOC_TYPE = 'VR'
					THEN 'YES' -- Added 2/20/2015; Added VR check 20180815
				ELSE 'NO'
				END AS [Reverse Mortgage]
			,
			--'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
			NBR_OF_RES_UNITS AS [check]
			,CASE 
				WHEN deed.MTG1_MTG_LOAN_TYPE_CODE = 'CNV'
					THEN CASE 
							WHEN NBR_OF_RES_UNITS = 1
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 2
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 3
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 4
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4]
								THEN 'YES'
							WHEN (
									NBR_OF_RES_UNITS = 0
									OR NBR_OF_RES_UNITS IS NULL
									)
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							ELSE 'NO'
							END
				ELSE 'NO'
				END AS [Conforming]
			,CASE 
				WHEN TRANSACTION_TYPE = '3'
					THEN deed.SELLER_NAME_PLAINTIFF_1
				ELSE 'UNKNOWN'
				END AS [Builder]
			,CASE 
				WHEN deed.TRANSACTION_TYPE = '9'
					THEN ''
				ELSE isnull(deed.SELLER_NAME_PLAINTIFF_1, '')
				END AS [Seller Name]
			,isnull(deed.BYR1_OWN_NAME, '') AS [Buyer]
			,CASE 
				WHEN assr.PROPERTY_INDICATOR IN (
						'10'
						,'11'
						,'21'
						)
					THEN 'YES'
				ELSE 'NO'
				END AS [Residential]
			,CASE 
				WHEN deed.BYR1_CORP_IND = 'Y'
					THEN 'YES'
				ELSE 'NO'
				END AS [Corporate]
			 --   isnull(deed.SITUS_CITY,'') as [City],
			,case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code]
			,deed.FIPS AS [FIPS]
			,isnull(left(assr.CENSUS_TRACT, 4), '') AS [Census Tract #]
			,CASE assr.PROPERTY_INDICATOR
				WHEN '10'
					THEN 'Single Family Residence'
				WHEN '11'
					THEN 'Condominium'
				WHEN '20'
					THEN 'Commercial'
				WHEN '21'
					THEN 'Duplex (Triplex, Quadplex)'
				WHEN '22'
					THEN 'Apartment'
				WHEN '23'
					THEN 'Hotel, Motel'
				WHEN '24'
					THEN 'Commercial Condominium'
				WHEN '25'
					THEN 'Retail'
				WHEN '26'
					THEN 'Service'
				WHEN '27'
					THEN 'Office Building'
				WHEN '28'
					THEN 'Warehouse'
				WHEN '29'
					THEN 'Financial Institution'
				WHEN '30'
					THEN 'Hospital (Medical Complex)'
				WHEN '31'
					THEN 'Parking'
				WHEN '32'
					THEN 'Amusement Recreation'
				WHEN '50'
					THEN 'Industrial'
				WHEN '51'
					THEN 'Industrial Light'
				WHEN '52'
					THEN 'Industrial Heavy'
				WHEN '53'
					THEN 'Transport'
				WHEN '54'
					THEN 'Utilities'
				WHEN '70'
					THEN 'Agricultural'
				WHEN '80'
					THEN 'Vacant'
				WHEN '90'
					THEN 'Exempt'
				ELSE 'Unknown'
				END AS [Property Type]
			,MTG1_CONSTRUCTION_LOAN
			,REO_SALE_FLAG
			,deed.TITLE_COMPANY_CODE
			,
			--MTG1_EQUITY_FLAG,
			MTG1_OTHER_SUBORDINATE_LOANS
			,TRANSACTION_TYPE
			,DETAILED_DOC_TYPE
			,deed.DEED_TYPE
			,Deed.FORCLOSURE
			,Deed.RESALE_NEW_CONSTRUCTION
			,Deed.DeedID
			,Deed.BYR1_CORP_IND
			,Deed.MTG1_PRIVATE_PARTY_LENDER
			,Deed.SELLER_NAME_PLAINTIFF1_CORP_IND
			,Deed.Sales_Source_Ind
			,---------------------change 2/4/2016 to filter AZ affidavits
			Deed.REF_ID
			,---------------------Added for update Attorney names 3/14/2016
			deed.RECORDING_DATE
			,deed.SALE_DATe
			,deed.UPDATED
			,assr.SITUS_ZIP_CODE AS Ass_ZipCode
			,-----------Added for checking wrong zipcode
			assr.Year_Built -----------------------------Added YearBuilt for HI fix
			,[FMT_DOC_NBR]
			,[FMT_Book_Page]
			,[FMT_MTG1_DOC_NBR]
			,[FMT_MTG2_DOC_NBR]
			,[FMT_MTG1_Book_Page]
			,[FMT_MTG2_Book_Page]
		FROM [Minelson].[mktshr].[Marketshare_Deed_BK_Final] deed WITH (NOLOCK)
		LEFT OUTER JOIN [Assr].[dbo].[Assr] assr WITH (NOLOCK) ON deed.FIPS = assr.FIPS
			AND
			--  deed.ORIGINAL_APN = assr.ORIGINAL_APN  -----------9/8/15 change to use ref_id to join
			deed.REF_ID = assr.REF_ID
		--INNER JOIN [MiNelson].[mktshr].[ConformingLimits] cnf WITH (NOLOCK) ON deed.FIPS = cnf.fips
		  left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
		LEFT OUTER JOIN [MiNelson].[mktshr].[ReverseMortgage] rm WITH (NOLOCK) ON deed.Fips = rm.Fips
			AND deed.Ref_Id = rm.Ref_Id
			AND deed.DeedId = rm.DeedId
		LEFT OUTER JOIN [MiNelson].[mktshr].[MtgCoverage] mc WITH (NOLOCK) ON deed.Fips = mc.Fips
		WHERE deed.DETAILED_DOC_TYPE NOT IN (
				'MO'
				,'RD'
				,'DT'
				) --, 'TE') -- Added back the 'TE' records on 4/06/15
			--  and (deed.FIPS  between 56001 and 56999)
			--      and deed.US_STATE = 'ME'
			--and isnull(deed.RECORDING_DATE,deed.SALE_DATE) >= '2013-01-01'
			AND (
				deed.MTG1_MTG_AMOUNT != 1
				OR deed.MTG1_MTG_AMOUNT IS NULL
				) -- Exclude HUD Reverse Mortgages
			--AND (
			--	MULTI_APN != 'D'
			--	OR MULTI_APN IS NULL
			--	)
			AND NOT (
				deed.MTG1_MTG_AMOUNT IS NULL
				AND deed.SALE_AMOUNT IS NULL
				AND deed.TRANSACTION_TYPE = '9'
				) -- Added TransType=9 on 4/07/15
			--   and not (Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null) -- Added Title_Company_Code is Null on 4/06/15 --4/17/15 take out take make filter for AZ
			--and (Deed.DeedID >  (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
			--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16
			-- and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- take out BK data 8/20/2015  
			-- or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131	)) --- Add BK data 3/10/16 
			--	  )   
			--and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 --- remove 6/9
		) x
	WHERE rn = 1


	update [MiNelson].[dbo].[a]
set a.[Transaction Type] = 'Resale' 
 from [MiNelson].[dbo].[MarketShareTitle_Temp1] a
 where a.transaction_type = 1
 and ( MTG1_CONSTRUCTION_LOAN = 'Y' or MTG1_EQUITY_FLAG = 'Y' or MTG1_OTHER_SUBORDINATE_LOANS = 'Y'or MTG1_EQUITY_FLAG = 'Y')
  and a.[loan amount] <> 0 and a.[Sales Price] <> 0

	--order by
	--      [Sale Document number]
	------------------
	/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp2]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp2]

	-------------------------
	-- Create 2nd mgt table
	SELECT DeedSequence
		,[Transaction Type]
		,[Lender]
		,[Title Company]
		,TITLE_COMPANY_CODE
		,[Attorney]
		,[Sale Document number]
		,[MGT Document number]
		,[Book/Page]
		,[Sales Price]
		,[Loan Amount]
		,[Loan To Value]
		,[Date]
		,[Adjustable Rate]
		,[Loan Type]
		,[Reverse Mortgage]
		,[Conforming]
		,[Builder]
		,[Seller Name]
		,[Buyer]
		,[Residential]
		,[Corporate]
		,[City]
		,[County]
		,[State]
		,[Zip Code]
		,[FIPS]
		,[Census Tract #]
		,[Property Type]
		,MTG1_CONSTRUCTION_LOAN
		,REO_SALE_FLAG
		,MTG1_EQUITY_FLAG
		,MTG1_OTHER_SUBORDINATE_LOANS
		,TRANSACTION_TYPE
		,DETAILED_DOC_TYPE
		,DEED_TYPE
		,FORCLOSURE
		,RESALE_NEW_CONSTRUCTION
		,MULTI_APN
		,DeedID
		,BYR1_CORP_IND
		,[CHECK] AS NBR_OF_RES_UNITS
		,MTG1_PRIVATE_PARTY_LENDER
		,SELLER_NAME_PLAINTIFF1_CORP_IND
		,sales_source_ind
		,REF_ID
		,RECORDING_DATE
		,SALE_DATe
		,UPDATED
		,Ass_ZipCode
		,Year_Built
		,[FMT_DOC_NBR]
		,[FMT_Book_Page]
		,[FMT_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[FMT_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
	INTO [MiNelson].[dbo].[MarketShareTitle_Temp2]
	FROM (
		SELECT 2 AS DeedSequence
			,
			--case 
			----when REO_SALE_FLAG = 1 then    -- Added "Cash Sale" split 2/27/2015
			----                        case when deed.MTG1_MTG_AMOUNT is Null and mc.Fips is not Null then 'REO - Cash Sale'
			----                        else 'REO'
			----                        end
			--      when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity'
			--      when MTG2_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
			--      else
			--            case deed.TRANSACTION_TYPE 
			--                  when 1 then 'Resale'
			--                  when 2 then 'Refinance'
			--                  when 3 then 'Subdivision/Newhome'
			--                  when 4 then 'Timeshare'
			--                  when 6 then 'Construction Loan'
			--                  when 7 then 'Resale'
			--                  when 9 then 'Refinance'
			--                  else ''
			--            end
			--      end as [Transaction Type],
			CASE 
				WHEN MTG2_CONSTRUCTION_LOAN = 'Y'
					THEN 'Construction Loan' --- Added 4/1/2015
				WHEN MTG1_CONSTRUCTION_LOAN = 'Y'
					THEN 'Construction Loan' --- Added 4/1/2015
				WHEN MTG2_EQUITY_FLAG = 'Y'
					THEN 'Home Equity' ---------Added 4/23/15
				ELSE 'Other Subordinate Loan'
				END AS [Transaction Type]
			,--- changed 4/1/2015
			--isnull(deed.MTG2_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
			--isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			CASE 
				WHEN (
						deed.MTG2_LENDER_LAST_NAME IS NULL
						OR deed.MTG2_LENDER_LAST_NAME = ''
						)
					THEN 'UNKNOWN'
				ELSE deed.MTG2_LENDER_LAST_NAME
				END AS [Lender]
			,CASE 
				WHEN (
						deed.TITLE_COMPANY_NAME IS NULL
						OR deed.TITLE_COMPANY_NAME = ''
						)
					THEN 'UNKNOWN'
				ELSE deed.TITLE_COMPANY_NAME
				END AS [Title Company]
			,
			--and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null)
			deed.TITLE_COMPANY_CODE
			,'UNKNOWN' AS [Attorney]
			,MTG2_EQUITY_FLAG
			,deed.MULTI_APN
			,--
			--row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
			row_number() OVER (
				PARTITION BY deed.FIPS
				,isnull(deed.RECORDING_DATE, deed.SALE_DATE)
				,CASE 
					WHEN isnull(deed.DOC_NBR, '') <> ''
						THEN deed.DOC_NBR
					ELSE (deed.Recording_Book + '/' + deed.Recording_Page)
					END ORDER BY deed.MULTI_APN Desc
					,deed.DeedId
				) AS [rn]
			,-- Corrected problem with row_number 3/09/15--- 4/14 add DeedID
			deed.DOC_NBR AS [Sale Document number]
			,deed.MTG2_DOC_NBR AS [MGT Document number]
			,deed.DETAILED_DOC_TYPE AS [Detailed Doc Type]
			,
			--   (deed.MTG2_RECORDING_BOOK + '/' + deed.MTG2_RECORDING_PAGE) as 'Book/Page', --change to make uique keys 7/06/2015
			(deed.Recording_Book + '/' + deed.Recording_Page) AS 'Book/Page'
			,-- change to make unique keys 7/6/2015
			isnull(deed.SALE_AMOUNT, 0) AS [Sales Price]
			,-- Reformatted as currency 2/27/2015
			--'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
			isnull(deed.MTG2_MTG_AMOUNT, 0) AS [Loan Amount]
			,-- Reformatted as currency 2/27/2015
			--'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
			CASE 
				WHEN deed.MTG2_MTG_AMOUNT IS NOT NULL
					AND deed.SALE_AMOUNT IS NOT NULL
					AND deed.SALE_AMOUNT != 0
					THEN convert(VARCHAR(15), round(convert(FLOAT, deed.MTG2_MTG_AMOUNT / deed.SALE_AMOUNT * 100), 2)) + '%'
				ELSE 'No Data'
				END AS [Loan To Value]
			,isnull(deed.RECORDING_DATE, deed.SALE_DATE) AS [Date]
			,
			--      case when deed.US_STATE = 'KS' 
			--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
			--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
			CASE 
				WHEN deed.MTG2_MTG_INTEREST_RATE_TYPE = 'ADJ'
					THEN 'YES'
				ELSE 'NO'
				END AS [Adjustable Rate]
			,
			--deed.MTG1_MTG_LOAN_TYPE_CODE,
			CASE deed.MTG2_MTG_LOAN_TYPE_CODE
				WHEN 'CNV'
					THEN 'Conventional'
				WHEN 'FHA'
					THEN 'FHA'
				WHEN 'VA'
					THEN 'VA'
				ELSE 'none'
				END AS [Loan Type]
			,
			--case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
			CASE 
				WHEN rm.Fips IS NOT NULL
					THEN 'YES' -- Added 2/20/2015
				ELSE 'NO'
				END AS [Reverse Mortgage]
			,
			--'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
			NBR_OF_RES_UNITS AS [check]
			,CASE 
				WHEN deed.MTG2_MTG_LOAN_TYPE_CODE = 'CNV'
					THEN CASE 
							WHEN NBR_OF_RES_UNITS = 1
								AND deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 2
								AND deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 3
								AND deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3]
								THEN 'YES'
							WHEN NBR_OF_RES_UNITS = 4
								AND deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4]
								THEN 'YES'
							WHEN (
									NBR_OF_RES_UNITS = 0
									OR NBR_OF_RES_UNITS IS NULL
									)
								AND deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							ELSE 'NO'
							END
				ELSE 'NO'
				END AS [Conforming]
			,CASE 
				WHEN TRANSACTION_TYPE = 3
					THEN deed.SELLER_NAME_PLAINTIFF_1
				ELSE 'UNKNOWN'
				END AS [Builder]
			,CASE 
				WHEN deed.TRANSACTION_TYPE = 9
					THEN ''
				ELSE isnull(deed.SELLER_NAME_PLAINTIFF_1, '')
				END AS [Seller Name]
			,isnull(deed.BYR1_OWN_NAME, '') AS [Buyer]
			,CASE 
				WHEN assr.PROPERTY_INDICATOR IN (
						'10'
						,'11'
						,'21'
						)
					THEN 'YES'
				ELSE 'NO'
				END AS [Residential]
			,CASE 
				WHEN deed.BYR1_CORP_IND = 'Y'
					THEN 'YES'
				ELSE 'NO'
				END AS [Corporate]
			,case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code]
			,deed.FIPS AS [FIPS]
			,isnull(left(assr.CENSUS_TRACT, 4), '') AS [Census Tract #]
			,CASE assr.PROPERTY_INDICATOR
				WHEN '10'
					THEN 'Single Family Residence'
				WHEN '11'
					THEN 'Condominium'
				WHEN '20'
					THEN 'Commercial'
				WHEN '21'
					THEN 'Duplex (Triplex, Quadplex)'
				WHEN '22'
					THEN 'Apartment'
				WHEN '23'
					THEN 'Hotel, Motel'
				WHEN '24'
					THEN 'Commercial Condominium'
				WHEN '25'
					THEN 'Retail'
				WHEN '26'
					THEN 'Service'
				WHEN '27'
					THEN 'Office Building'
				WHEN '28'
					THEN 'Warehouse'
				WHEN '29'
					THEN 'Financial Institution'
				WHEN '30'
					THEN 'Hospital (Medical Complex)'
				WHEN '31'
					THEN 'Parking'
				WHEN '32'
					THEN 'Amusement Recreation'
				WHEN '50'
					THEN 'Industrial'
				WHEN '51'
					THEN 'Industrial Light'
				WHEN '52'
					THEN 'Industrial Heavy'
				WHEN '53'
					THEN 'Transport'
				WHEN '54'
					THEN 'Utilities'
				WHEN '70'
					THEN 'Agricultural'
				WHEN '80'
					THEN 'Vacant'
				WHEN '90'
					THEN 'Exempt'
				ELSE 'Unknown'
				END AS [Property Type]
			,MTG1_CONSTRUCTION_LOAN
			,REO_SALE_FLAG
			,MTG1_EQUITY_FLAG
			,MTG1_OTHER_SUBORDINATE_LOANS
			,TRANSACTION_TYPE
			,DETAILED_DOC_TYPE
			,deed.DEED_TYPE
			,Deed.FORCLOSURE
			,Deed.RESALE_NEW_CONSTRUCTION
			,Deed.DeedID
			,Deed.BYR1_CORP_IND
			,Deed.MTG1_PRIVATE_PARTY_LENDER
			,Deed.SELLER_NAME_PLAINTIFF1_CORP_IND
			,Deed.Sales_Source_ind
			,Deed.REF_ID
			,deed.RECORDING_DATE
			,deed.SALE_DATe
			,deed.UPDATED
			,assr.SITUS_ZIP_CODE AS Ass_ZipCode
			,-----------Added for checking wrong zipcode
			assr.Year_Built ------------------------------Added yearBuilt for HI Fix
			,[FMT_DOC_NBR]
			,[FMT_Book_Page]
			,[FMT_MTG1_DOC_NBR]
			,[FMT_MTG2_DOC_NBR]
			,[FMT_MTG1_Book_Page]
			,[FMT_MTG2_Book_Page]
		FROM [Minelson].[mktshr].[Marketshare_Deed_BK_Final] deed WITH (NOLOCK)
		LEFT OUTER JOIN [Assr].[dbo].[Assr] assr WITH (NOLOCK) ON deed.FIPS = assr.FIPS
			AND
			--  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
			deed.REF_ID = assr.REF_ID
		--INNER JOIN [MiNelson].[mktshr].[ConformingLimits] cnf WITH (NOLOCK) ON deed.FIPS = cnf.fips
		  left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
		LEFT OUTER JOIN [MiNelson].[mktshr].[ReverseMortgage] rm WITH (NOLOCK) ON deed.Fips = rm.Fips
			AND deed.Ref_Id = rm.Ref_Id
			AND deed.DeedId = rm.DeedId
		LEFT OUTER JOIN [MiNelson].[mktshr].[MtgCoverage] mc WITH (NOLOCK) ON deed.Fips = mc.Fips
		WHERE deed.DETAILED_DOC_TYPE NOT IN (
				'MO'
				,'RD'
				,'DT'
				) --, 'TE') 
			--    and (deed.FIPS  between 56001 and 56999)
			--  and deed.US_STATE = 'ME'
			-- and isnull(deed.RECORDING_DATE,deed.SALE_DATE)  >= '2013-01-01'
			AND (
				deed.MTG1_MTG_AMOUNT != 1
				OR deed.MTG1_MTG_AMOUNT IS NULL
				) -- Exclude HUD Reverse Mortgages
			--AND (
			--	MULTI_APN != 'D'
			--	OR MULTI_APN IS NULL
			--	)
			AND NOT (
				deed.MTG1_MTG_AMOUNT IS NULL
				AND deed.SALE_AMOUNT IS NULL
				AND deed.TRANSACTION_TYPE = '9'
				)
			-- and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and deed.MTG2_LENDER_LAST_NAME is null)--4/17/15 take out take make filter for AZ
			AND deed.MTG2_MTG_AMOUNT IS NOT NULL
			--  and (Deed.DeedID >   (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
			--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16
			--         and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- 8/20/215 take out BK data
			--or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131
			--												))  -----add BK data 3/10/2016
			-- --- BK data
			--)
			--	and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 -- remove 6/9
		) y
	WHERE rn = 1

	--order by
	--       [Sale Document number]
	------
	----------------------------------------------------------
	---Union Results -----------------------------------------
	/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable]

	SELECT *
	INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	FROM (
		SELECT *
		FROM [MiNelson].[dbo].[MarketShareTitle_Temp1]
		
		UNION
		
		SELECT *
		FROM [MiNelson].[dbo].[MarketShareTitle_Temp2]
		) x
	ORDER BY [County]
		,[Sale Document number]

	DELETE
	-- select *
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE TRANSACTION_TYPE = '9' ---------------------- by MyPhan 10/11/2022
		AND isnull([Sales Price], 0) = 0
		AND isnull([Loan Amount], 0) = 0

	-----------------
	-------HI Fix--------------------changed to all states 20171130
	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Subdivision/Newhome'
		,t.Builder = t.[Seller Name]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE [Transaction Type] = 'Resale'
		AND [Seller Name] IN (
			SELECT *
			FROM [Minelson].[mktshr].[Title_MarketShare_BuilderNames]
			)

	--where State = 'HI' and [Transaction Type] = 'Resale' 
	--and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
	--and [Seller Name] in (select * from Minelson.mktshr.Title_MarketShare_HI_BuilerNames)
	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
		,t.Builder = t.[Seller Name]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE [Transaction Type] = 'Resale - Cash Sale'
		AND [Seller Name] IN (
			SELECT *
			FROM [Minelson].[mktshr].[Title_MarketShare_BuilderNames]
			)

	--where State = 'HI' and [Transaction Type] = 'Resale - Cash Sale' 
	--and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
	--and [Seller Name] in (select * from Minelson.mktshr.Title_MarketShare_HI_BuilerNames)
	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Subdivision/Newhome'
		,t.Builder = t.[Seller Name]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE --State = 'HI' and 
		[Transaction Type] = 'Resale'
		AND [Seller Name] IN (
			SELECT Builder
			FROM [MiNelson].[mktshr].[GlobalBuilderTbl]
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
		,t.Builder = t.[Seller Name]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE --State = 'HI' and 
		[Transaction Type] = 'Resale - Cash Sale'
		AND [Seller Name] IN (
			SELECT Builder
			FROM [MiNelson].[mktshr].[GlobalBuilderTbl]
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.Builder = t.[Seller Name]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE [Transaction Type] LIKE 'Subdivision/Newhome%'
		AND t.Builder = 'UNKNOWN'

	update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])


  update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])
  

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Resale'
		,t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE t.[Transaction Type] = 'Subdivision/Newhome'
		AND t.Builder IN (
			SELECT Builder
			FROM [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder]
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Resale - Cash Sale'
		,t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
		AND t.Builder IN (
			SELECT Builder
			FROM [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder]
			)

	--Castiglione, Caroline Thursday, February 7, 2019 2:56 PM Market Share Report issues email
	--Castiglione, Caroline Tuesday, February 26, 2019 8:15 AM NV- Frontier Estates email
	--Alan Ratner <alan@zelmanassociates.com>, May 14, 2019 2:05 PM [External] RE: First American DataTree - Builder Sample email
	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Resale'
		,t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE t.[Transaction Type] = 'Subdivision/Newhome'
		AND (
			t.Builder LIKE 'OPEN DOOR%'
			OR t.Builder LIKE 'OPENDOOR%'
			OR t.Builder IN (
				'OENDOOR HOMES PHOENIX 2 LLC'
				,'OOENDOOR HOMES PHOENIX 2 L'
				,'OPEADOOR HOMES PHOENIX 2 LLC'
				,'OPNDOOR HOMES PHOENIX 2 LLC'
				,'OPNDOOR PROERW6 LLC'
				,'QPENDOOR HOMES PHOENIX 2 L'
				,'FRONTIER ESTATES LLC'
				)
			OR left(t.Builder, 12) = 'COLONY RIDGE'
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Transaction Type] = 'Resale - Cash Sale'
		,t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
		AND (
			t.Builder LIKE 'OPEN DOOR%'
			OR t.Builder LIKE 'OPENDOOR%'
			OR t.Builder IN (
				'OENDOOR HOMES PHOENIX 2 LLC'
				,'OOENDOOR HOMES PHOENIX 2 L'
				,'OPEADOOR HOMES PHOENIX 2 LLC'
				,'OPNDOOR HOMES PHOENIX 2 LLC'
				,'OPNDOOR PROERW6 LLC'
				,'QPENDOOR HOMES PHOENIX 2 L'
				,'FRONTIER ESTATES LLC'
				)
			OR left(t.Builder, 12) = 'COLONY RIDGE'
			)

	-----
	-----
	-------------------------------------------------------------
	---- Filter records Resale_CashSale where it is REO
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE [Transaction Type] = 'Resale - Cash Sale'
		AND (
			FORCLOSURE = 'Y'
			OR DEED_TYPE = 'U'
			)

	-------------------------------------
	-----------------------------------------------------------
	------Filter cashsale records with no sale price in disclosure states
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE [Transaction Type] IN (
			'REO - Cash Sale'
			,'Resale - Cash Sale'
			,'Subdivision/Newhome - Cash Sale'
			,'Timeshare - Cash Sale'
			)
		AND [Sales Price] = 0
		AND STATE NOT IN (
			'AZ'
			,'AK'
			,'ID'
			,'IN'
			,'KS'
			,'LA'
			,'ME'
			,'MS'
			,'MO'
			,'MT'
			,'NM'
			,'ND'
			,'TX'
			,'UT'
			,'WY'
			,'HI'
			)

	-----------------------------------------------------
	------------------------------------------------------------------
	----------------Update Transaction_Type = ''---------------------
	--select * from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	--where [Transaction Type] = '' 
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Transaction Type] = (
			CASE 
				WHEN [Transaction Type] = ''
					AND [Sales Price] = 0
					AND [Loan Amount] <> 0
					THEN 'Refinance'
				WHEN [Transaction Type] = ''
					AND RESALE_NEW_CONSTRUCTION = 'M'
					THEN CASE 
							WHEN [Sales Price] <> 0
								AND [Loan Amount] = 0
								THEN 'Resale - Cash Sale'
							ELSE 'Resale'
							END
				WHEN [Transaction Type] = ''
					AND RESALE_NEW_CONSTRUCTION = 'N'
					THEN CASE 
							WHEN [Sales Price] <> 0
								AND [Loan Amount] = 0
								THEN 'Subdivision/Newhome - Cash Sale'
							ELSE 'Subdivision/Newhome'
							END
				ELSE [Transaction Type]
				END
			)

	----------------------------------------
	-----------------------------------------------------------------
	-----------------Filter Title_company_code 400 for IL------------
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE TRANSACTION_TYPE = 4
		AND (
			TITLE_COMPANY_CODE <> '00400'
			OR TITLE_COMPANY_CODE IS NULL
			)
		AND STATE = 'IL'

	--  -----------------------------------------------------------------------------
	----Filter unknown title, lender records for Non_AZ counties ------------------
	---- add change for Indiana
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = l.title_company_name
	FROM [Minelson].[dbo].[TitleMarketShare_BaseTable] a
	LEFT JOIN [Deed].[dbo].[deed] d ON a.deedid = d.deedid
	LEFT JOIN [Lien].[UR].[DOCUMENT] l ON d.ur_doc_id = l.doc_id
	WHERE (
			a.[Title Company] = 'unknown'
			AND a.TITLE_COMPANY_CODE IS NULL
			AND Lender = 'unknown'
			)
		AND a.STATE IN ('IN')
		AND left(DATE, 7) > '2022-08'
		AND l.title_company_name = 'NONE LISTED ON DOCUMENT'

	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE (
			[Title Company] = 'unknown'
			AND TITLE_COMPANY_CODE IS NULL
			AND Lender = 'unknown'
			)
		AND STATE NOT IN (
			'AZ'
			,'HI'
			)

	--Delete
	--  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	--  where [Transaction Type] not in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
	--  and   ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')        
	--  and State = 'NV'
	--Delete 
	--FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	--where  
	--          ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
	--          and State <> 'AZ'
	--Filter unknown title, lender records for AZ counties------------- --------- 
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE (
			[Title Company] = 'unknown'
			AND TITLE_COMPANY_CODE IS NULL
			AND Lender = 'unknown'
			)
		AND detailed_doc_type <> 'SW'
		AND [Sales Price] = 0
		AND STATE = 'AZ'

	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE [Transaction Type] = 'Resale'
		AND detailed_doc_type <> 'SW'
		AND [Sales Price] = 0
		AND STATE = 'AZ'

	----------------------------------------------------------------------------------
	--Filter Timeshare when unknown Title for Timshare records in TX and AZ counties
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	-- where [Title Company] = 'unknown' and [transaction type]  = 'Timeshare' --- changed 4/23
	--            and (state = 'TX' or State = 'AZ')
	WHERE [Title Company] = 'unknown'
		AND (
			[transaction type] = 'Timeshare'
			OR [Transaction Type] = 'Timeshare - Cash Sale'
			)
		AND (
			STATE = 'TX'
			OR STATE = 'AZ'
			)

	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE TRANSACTION_TYPE = '9'
		AND NOT (
			[Sales Price] = 0
			AND [Loan Amount] IS NOT NULL
			)

	ALTER TABLE [MiNelson].[dbo].[TitleMarketShare_BaseTable]

	ALTER COLUMN [Attorney] VARCHAR(60)

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Attorney = [Title Company]
	WHERE TITLE_COMPANY_CODE = '00400'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Title Company] = 'ATTORNEY ONLY'
	WHERE TITLE_COMPANY_CODE = '00400'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [Property type] = 'unknown'
		AND Corporate != 'YES'
		AND STATE != 'NM' ----- 10/16 take out NM state

	----- Change Residential Indicator If LOAN_TYPE is FHA or VA and Residential indicator is NO and property type = vacant 
	------then change the Residential indicator to YES  ---- 9/22/15
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [loan Type] IN (
			'FHA'
			,'VA'
			)
		AND Residential = 'NO'
		AND [property type] = 'vacant'

	-----------------------
	----Change  When the Transaction type is Subdivision/Newhome or Subdivision/Newhome-Cash Sale ---> change Residential to Yes  --- 9/22/15
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [Transaction Type] IN (
			'Subdivision/Newhome'
			,'Subdivision/Newhome - Cash Sale'
			)
		AND Residential = 'NO'
		AND [Property Type] = 'vacant'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
		,[Property Type] = 'Unknown'
	WHERE [Transaction Type] IN (
			'Subdivision/Newhome'
			,'Subdivision/Newhome - Cash Sale'
			)
		AND Residential = 'NO'
		AND [Property Type] != 'vacant'

	---------------------------
	----Change If the Reverse Mortgage Indicator is ‘Y’ and Residential is NO --> change Residential to Y regardless of Property Type --- 9/22/15
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [Reverse Mortgage] = 'YES'
		AND Residential = 'NO'
		AND [Property Type] = 'vacant'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
		,[Property Type] = 'Unknown'
	WHERE [Reverse Mortgage] = 'YES'
		AND Residential = 'NO'
		AND [Property Type] != 'vacant'

	----------------------
	--  ---For these FIPS lets bypass the changes we put in on Friday:
	--Dallas- 48113
	--Hennepin-27053
	--Philadelphia-42101
	--Kern-6029
	--Anchorage-2020
	--Marion OH-39101
	--St Clair IL-17163
	--Shasta CA-6089
	--Yakima WA-53077
	--Erie OH-39043
	--Spokane-53063
	--Ramsey mn-27123
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [Property type] IN (
			'vacant'
			,'agricultural'
			)
		AND Corporate != 'YES'
		AND residential = 'No'
		AND [loan to value] != 'No data'
		AND round(convert(FLOAT, [loan Amount] / [SALEs price] * 100), 2) > 20
		AND STATE NOT IN (
			'TX'
			,'UT'
			)

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE [Loan type] IN (
			'Conventional'
			,'VA'
			,'FHA'
			)
		AND [Property type] IN (
			'vacant'
			,'agricultural'
			)
		AND residential = 'No'
		AND (
			STATE NOT IN (
				'TX'
				,'UT'
				)
			OR fips = 48113
			)
		AND fips NOT IN (
			27053
			,42101
			,6029
			,2020
			,39101
			,17163
			,6089
			,53077
			,39043
			)

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'NO'
	WHERE STATE NOT IN (
			'TX'
			,'UT'
			)
		AND residential = 'Yes'
		AND corporate = 'Yes'
		AND [Sales price] = 0
		AND [transaction type] = 'Construction Loan'
		AND fips NOT IN (
			48113
			,27053
			,42101
			,6029
			,2020
			,39101
			,17163
			,6089
			,53077
			,39043
			,53063
			,27123
			)

	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	WHERE STATE NOT IN (
			'TX'
			,'UT'
			)
		AND [transaction type] IN (
			'Subdivision/NewHome'
			,'Subdivision/NewHome - Cash Sale'
			,'REO'
			,'REO-CASH SALE'
			)
		AND [sales price] = 0
		AND [loan Amount] = 0
		AND fips NOT IN (
			48113
			,27053
			,42101
			,6029
			,2020
			,39101
			,17163
			,6089
			,53077
			,39043
			,53063
			,27123
			)

	--------------------
	----------------------
	---- Change If the Transaction Type is TimeShare or TimeShare - Cash -> change Residential Indicator to NO  --- 9/22/15
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'NO'
	WHERE [Transaction Type] IN (
			'Timeshare'
			,'Timeshare - Cash Sale'
			)
		AND Residential = 'YES'
		AND fips NOT IN (
			48113
			,27053
			,42101
			,6029
			,2020
			,39101
			,17163
			,6089
			,53077
			,39043
			,53063
			,27123
			)

	---------------------------
	---, If the Transaction Type is Construction Loan and the Detailed Doc type is CL and Corp Indicator is Y then make Residential =NO 
	---This will take the builders and Construction companies out of the Residential bucket
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'NO'
	WHERE [Transaction Type] = 'Construction Loan'
		AND DETAILED_DOC_TYPE = 'CL'
		AND Corporate = 'YES'
		AND Residential = 'YES'
		AND fips NOT IN (
			48113
			,27053
			,42101
			,6029
			,2020
			,39101
			,17163
			,6089
			,53077
			,39043
			,53063
			,27123
			)

	--------------------------------
	----I do have two changes to suggest, 1) for TX if Property type is Vacant and Buyer is corp change residential to NO 
	--select * from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	--where [property type] = 'vacant' and Corporate = 'YES' and Residential = 'YES' and State = 'TX'
	----and in IL if Property types is Apartment and number of residentiail units is less than 2 change to Condo
	---- 10/15 add logic for IL
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Property Type] = 'Condominium'
		,Residential = 'YES'
	WHERE [Property Type] = 'Apartment'
		AND nbr_of_res_units < 2
		AND STATE = 'IL'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Property Type] = 'Condominium'
		,Residential = 'YES'
	WHERE [Property Type] = 'Apartment'
		AND [Sales Price] < 300000
		AND [Transaction Type] IN (
			'Resale'
			,'Resale - Cash Sale'
			)
		AND STATE = 'IL'

	---  If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’ and property type to single family
	--- For CA --- 10/20/2015
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Property Type] = 'Single Family Residence'
		,Residential = 'YES'
	WHERE [Property Type] = 'vacant'
		AND Residential = 'NO'
		AND MTG1_CONSTRUCTION_LOAN IS NULL
		AND STATE = 'CA'

	--These changes are for Oregon: ----------10/20/2015
	--1) If Property type is Agricultural and Corporate is ‘NO’ and MTG1_COMSTRUCTION_LOAN is null  change RESIDENTIAL to YES
	--2) If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’
	--3) If Property type is Agricultural and NBR_OF_RES_UNITS is more than 0 change PROPERTY type to Single Family Residence and Residential =”YES’
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE STATE = 'OR'
		AND [Property Type] = 'Agricultural'
		AND Residential = 'NO'
		AND Corporate = 'NO'
		AND MTG1_CONSTRUCTION_LOAN IS NULL

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE STATE = 'OR'
		AND [Property Type] = 'vacant'
		AND Residential = 'NO'
		AND MTG1_CONSTRUCTION_LOAN IS NULL
		AND Corporate = 'NO'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Property Type] = 'Single Family Residence'
		,Residential = 'YES'
	WHERE STATE = 'OR'
		AND [Property Type] = 'Agricultural'
		AND Residential = 'NO'
		AND nbr_of_res_units > 0

	--Here is one for PA  --- 10/21/15
	--If Property type is “vacant’ and if sale price is greater than 10,000 change property type to ‘Single Family Residence’ change Residential to Yes
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET [Property Type] = 'Single Family Residence'
		,Residential = 'YES'
	WHERE STATE = 'PA'
		AND [Property Type] = 'vacant'
		AND Residential = 'NO'
		AND [Sales Price] > 10000

	--- Change for TX --- 10/22/2015
	--  If NBR_OF_RES_UNITS are null and Corporate Indicator is YES change and Residential is YES, change Residential to NO
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'NO'
	WHERE STATE = 'TX'
		AND Corporate = 'YES'
		AND Residential = 'YES'
		AND nbr_of_res_units IS NULL

	--for 48113, If NBR_OF_RES_UNITS = 0 and Corporate Indicator is YES  and Residential is YES, change Residential to NO   --- 10/22/2015
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'NO'
	WHERE fips = 48113
		AND Corporate = 'YES'
		AND Residential = 'YES'
		AND nbr_of_res_units = 0

	----Change for MI -- 10/27/2015
	--- if Property type is vacant and Corp indicator is NO change Residential to YES
	---- if Property type is Amusement Recreation change residentail to Yes
	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE STATE = 'MI'
		AND [Property Type] = 'vacant'
		AND Residential = 'NO'
		AND Corporate = 'NO'

	UPDATE [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	SET Residential = 'YES'
	WHERE STATE = 'MI'
		AND [Property Type] = 'Amusement Recreation'
		AND Residential = 'NO'

	------------------------"Contruction loan" with Builder name is not unknown----------------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE DeedID NOT IN (
			SELECT DISTINCT deedid
			FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
			WHERE DeedID IN (
					SELECT DISTINCT deedid
					FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
					WHERE Builder != 'UNKNOWN'
						AND [Transaction Type] = 'Construction Loan'
					)
				AND [transaction type] = 'Subdivision/Newhome'
			)
		AND Builder != 'UNKNOWN'
		AND [Transaction Type] = 'Construction Loan'

	------------------------"Home Equity" with Builder name is not unknown----------------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.Builder = 'UNKNOWN'
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	WHERE DeedID NOT IN (
			SELECT DISTINCT deedid
			FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
			WHERE DeedID IN (
					SELECT DISTINCT deedid
					FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
					WHERE Builder != 'UNKNOWN'
						AND [Transaction Type] = 'Home Equity'
					)
				AND [transaction type] = 'Subdivision/Newhome'
			)
		AND Builder != 'UNKNOWN'
		AND [Transaction Type] = 'Home Equity'

	--------------check duplicates-----------------------------
	/*IF OBJECT_ID('Minelson.dbo.titlemarketshare_dup') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[titlemarketshare_dup]

	SELECT DeedId
		,[MGT Document number]
		,[Loan Amount]
		,Lender
		,[Transaction Type]
		,[Loan Type]
		,[Adjustable Rate]
		,COUNT(*) count
	INTO [Minelson].[dbo].[titlemarketshare_dup]
	FROM [MiNelson].[dbo].[TitleMarketShare_Basetable]
	GROUP BY DeedId
		,[MGT Document number]
		,[Loan Amount]
		,Lender
		,[Transaction Type]
		,[Loan Type]
		,[Adjustable Rate]
	HAVING COUNT(*) > 1

	------------------Delete duplciates---------------------------
	DELETE
	FROM [MiNelson].[dbo].[TitleMarketShare_Basetable]
	WHERE DeedID IN (
			SELECT deedid
			FROM [Minelson].[dbo].[titlemarketshare_dup]
			)
		AND deedsequence = 2

	-----------------------------------------------------------
	--------------------------------------------------------------------------
	------updating Zipcode and city------------------------------------------
	---------------------------------------------------------------------------
	/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]

	SELECT *
	INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]
	FROM [Minelson].[dbo].[TitleMarketShare_BaseTable]

	----- add new column for title zipcode-------------------
	ALTER TABLE [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] ADD Title_ZipCode VARCHAR(5)

	ALTER TABLE [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] ADD Title_city VARCHAR(40)

	----- when Deedid match then populate deed_zip to title_zip----------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.Title_ZipCode = t.[zip code]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	INNER JOIN [MiNelson].[dbo].[ZipFipsCityAll] z ON t.FIPS = z.Fips
		AND t.[Zip Code] = z.ZIPCode

	----When Deedid dont match update assr_zip to title_zip if it match---------------------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.Title_ZipCode = left(t.ass_Zipcode, 5)
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	LEFT JOIN [MiNelson].[dbo].[ZipFipsCityAll] z ON t.FIPS = z.Fips
		AND left(t.ass_Zipcode, 5) = z.ZIPCode
	WHERE z.ZIPCode IS NOT NULL
		AND t.[Zip Code] <> ''
		AND t.ass_zipCode IS NOT NULL
		AND t.Title_ZipCode IS NULL
		AND z.ZIPCode IS NOT NULL

	-----------------------------------------------------------
	---update Preferred city name
	/*IF OBJECT_ID('Minelson.dbo.ZIPPreferredCity') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ZIPPreferredCity]

	SELECT DISTINCT ZIPCode
		,Fips
		,PreferredCity
	INTO [Minelson].[dbo].[ZIPPreferredCity]
	FROM [Minelson].[dbo].[ZipFipsCityAll]
	GROUP BY ZIPCode
		,Fips
		,PreferredCity

	------------Update preferred city name--------------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.title_city = z.PreferredCity
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	INNER JOIN [Minelson].[dbo].[ZIPPreferredCity] z ON t.FIPS = z.Fips
		AND t.title_zipcode = z.ZIPCode

	-------------------------------------------------------------
	---Update Deed Zip in update table-----------------------
	/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]

	-----152,279 with city name or zip different
	SELECT *
	INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	WHERE t.Title_city <> t.City
		OR t.Title_ZipCode <> t.[Zip Code]
	
	UNION
	
	SELECT *
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	WHERE t.Title_ZipCode IS NULL
		AND (
			t.[Zip Code] IS NOT NULL
			AND t.[Zip Code] <> ''
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Zip Code] = t.title_ZipCode
		,t.city = t.title_city
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
	WHERE t.title_zipcode IS NOT NULL

	UPDATE [MiNelson].[dbo].[t]
	SET t.[Zip Code] = ''
		,t.city = ''
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
	WHERE t.title_zipcode IS NULL

	--- update Zip and city in orginal table------------------
	--update t
	--set t.[Zip Code] = u.[Zip Code] , t.City = u.City
	--from  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
	--inner join [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u
	--on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
	----update base table ---------------------------------
	UPDATE [MiNelson].[dbo].[t]
	SET t.[Zip Code] = u.[Zip Code]
		,t.City = u.City
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
	INNER JOIN [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u ON t.DeedID = u.DeedID
		AND t.DeedSequence = u.DeedSequence

	/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]

	/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]

	/*IF OBJECT_ID('Minelson.dbo.ZIPPreferredCity') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[ZIPPreferredCity]

	---------------Add Attorney name from RT--------------------------------------------------------
	----------------------------------------------------------------------------------------
	-----------------------------------------------------------------------
	----- create RT table with only the columns that we need--------------------    
	--      /*IF OBJECT_ID('[MiNelson].[dbo].[Title_marketshare_RT]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Title_marketshare_RT]
	--SELECT[RECORDER_ID]
	--      ,[FIPS]
	--     ,SR_PROPERTY_ID,SR_UNIQUE_ID
	--      ,[SR_DOC_NBR_FMT]
	--      ,[SR_DOC_NBR_RAW]
	--      , case when [SR_DOC_NBR_FMT] is null then null
	--		 when ([SR_DOC_NBR_FMT] <> '' and len([SR_DOC_NBR_FMT]) >  2) then RIGHT(Rtrim([SR_DOC_NBR_FMT]), len([SR_DOC_NBR_FMT]) -2) else null end as RT_Doc_Nbr
	--  ,SR_LAWYER_NAME,SR_LAWYER_CODE,SR_TITLE_CO_NAME,SR_TITLE_CO_CODE,SR_DATE_TRANSFER,SR_VAL_TRANSFER,SR_DATE_FILING
	-- into  Minelson.dbo.Title_marketshare_RT
	-- FROM [ART].[dbo].[RT_Recorder]
	-- where SR_DATE_TRANSFER >= '20130101'
	-----------------------------------------------------
	-------------------------------------------------- 
	--           /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID
	--       select r.SA_PROPERTY_ID, r.CLGX_UNIQUE_ID, c.* ,
	--       case when c.[Book/Page] IS not null then RIGHT(c.[Book/Page], 4)
	--       when c.[Sale Document number] IS null then null
	--       when len(c.[Sale Document number])<4 then null
	--       else RIGHT(Rtrim(c.[Sale Document number]), len(c.[Sale Document number]) -4) end as Deed_Doc_Nbr
	--       into  Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID from [MiNelson].[dbo].[TitleMarketShare_BaseTable] c
	--      left join Assr.dbo.PropertyReference r 
	--       on c.FIPS = r.FIPS and c.REF_ID =r.REF_ID 
	--           /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney
	--       select r.[RECORDER_ID]
	--      ,r.[FIPS] as RT_Fips
	--      ,r.[SR_PROPERTY_ID]
	--      ,r.[SR_DOC_NBR_FMT]
	--      ,r.[SR_DOC_NBR_RAW]
	--      ,r.[RT_Doc_Nbr]
	--      ,r.[SR_LAWYER_NAME]
	--      ,r.[SR_LAWYER_CODE]
	--      ,r.[SR_TITLE_CO_NAME]
	--      ,r.[SR_TITLE_CO_CODE]
	--      ,r.[SR_DATE_TRANSFER]
	--      ,r.[SR_VAL_TRANSFER]
	--      ,r.[SR_DATE_FILING], I.* 
	--     into Minelson.dbo.TitleMarketShare_BaseTable_Attorney 
	--     from Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID I
	--     left outer join Minelson.dbo.Title_marketshare_RT r
	--     on I.FIPS = r.Fips and I.SA_PROPERTY_ID = r.SR_PROPERTY_ID and right(I.Deed_Doc_Nbr,4) = right(r.RT_Doc_Nbr,4)  and  LEFT(CONVERT(varchar,I.RECORDING_DATE,112),8) =r.SR_DATE_TRANSFER
	--  /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final
	--select * 
	--  into Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final
	--  from 
	--(
	--SELECT  
	--DeedId, 
	--[MGT Document number] ,
	--[Loan Amount] ,
	--Lender ,
	--[Transaction Type] ,
	--[Loan Type] ,
	--[Adjustable Rate]
	--,[SR_LAWYER_NAME]
	--, row_number() over(partition by DeedId, [MGT Document number] ,[Loan Amount] ,Lender ,[Transaction Type] ,[Loan Type] ,[Adjustable Rate]
	--      order by sr_lawyer_name desc) as [rn]
	--from Minelson.dbo.TitleMarketShare_BaseTable_Attorney
	--)x
	--where rn =1
	-- ------------update attorney name--------------------
	--update t1
	--set  t1.Attorney =  t2.sr_lawyer_name
	--From [MiNelson].[dbo].[TitleMarketShare_BaseTable] t1
	--left outer join Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final t2
	--on t1.DeedID = t2.DeedID and  isnull (t1.[MGT Document number],'') = isnull(t2.[MGT Document number],'') and
	--t1.[Loan Amount] = t2.[Loan Amount] and t1.Lender = t2.Lender and t1.[Transaction Type] = t2.[Transaction Type]
	--and t1.[Loan Type] = t2.[Loan Type] and t1.[Adjustable Rate] = t2.[Adjustable Rate]
	--where 
	-- t1.attorney = 'UNKNOWN' and t2.sr_lawyer_name is not null 
	--  and t2.sr_lawyer_name <> ''
	--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
	--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
	--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
	--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
	--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
	--  and  t2.SR_LAWYER_NAME not like '%FCU%'
	--  and  t2.SR_LAWYER_NAME not like '%S&L%'
	--   --/*IF OBJECT_ID('[MiNelson].[dbo].[Title_marketshare_RT]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Title_marketshare_RT]
	--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID
	--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney
	--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final
	/*IF OBJECT_ID('Minelson.dbo.titlemarketshare_dup') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[dbo].[titlemarketshare_dup]

	/*IF OBJECT_ID('Minelson.mktshr.Marketshare_Deed_BK_Final') IS NOT NULL
		*/
DROP TABLE IF EXISTS [Minelson].[mktshr].[Marketshare_Deed_BK_Final]

	--- step 4
	------------------------------------------------------------------
	/*IF OBJECT_ID('[MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1]

	SELECT *
	INTO [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1]
	FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]

	--select count(*) from  [MiNelson].[mktshr].[TitleMarketShare_Bulk_Incremental_noFMTDoc]
	---------------step 5
	/*IF OBJECT_ID('[MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_Bulk]') IS NOT NULL
		*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_Bulk]

	SELECT a.*
	INTO [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_Bulk]
	FROM [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1] a
	LEFT JOIN [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver_Bulk] b ON a.FIPS = b.fips
	WHERE b.source = 'E'
		AND CutOver = 'Y'
		AND (
			DeedID > (
				SELECT Max([Max_DeedId])
				FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID]
				WHERE rundate != CONVERT(VARCHAR(10), GETDATE(), 112)
				)
			OR CONVERT(VARCHAR(10), a.updated, 112) >= (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
			--convert(VARCHAR(10), DATEADD(day, - 7, GETDATE()), 112)
			--(select MAX(rundate) from mktshr.TitleMarketShare )
			)
		AND DATE >= b.StartDate_UR
	----------------------new cut over------------------------------
	
	UNION ALL
	
	(
		SELECT a.*
		FROM [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1] a
		INNER JOIN [Minelson].[mktshr].[TitleMarketShare_County_Source_CutOver_Bulk] b ON a.FIPS = b.fips
		WHERE b.source = 'E'
			AND CutOver = 'N'
			AND DATE >= b.StartDate_UR
		)

	UPDATE [MiNelson].[dbo].[A]
	SET A.[Title company] = b.[Title Company Edited]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_Bulk] a
	INNER JOIN [MiNelson].[mktshr].[TitleMarketShare_TitleCompanyName_Edit] b ON a.STATE = b.STATE
		AND a.[Title Company] = b.[Title Company]

	UPDATE [MiNelson].[dbo].[A]
	SET A.[Title company] = b.[Title Company Edited]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_Bulk] a
	INNER JOIN [MiNelson].[mktshr].[TitleMarketShare_TitleCompanyName_Edit] b ON b.STATE = 'NN'
		AND a.[Title Company] = b.[Title Company]
		AND a.DATE >= b.[Transfer Date]

	UPDATE [MiNelson].[dbo].[A]
	SET A.[Title Company] = 'FIRST AMERICAN TITLE'
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	WHERE a.STATE = 'UT'
		AND a.[Title Company] IN (
			'FIRST AMERICAN LENDERS ADVANTA'
			,'FIRST AMERICAN LNDRS ABSTRACT'
			,'FIRST AMERICAN MORTGAGE SOLUTIONS LLC'
			,'FIRST AMERICAN MTG SVCS'
			,'FIRST AMERICAN-BOUNTIFUL'
			)
		AND [transaction type] IN (
			'Resale'
			,'Resale - Cash Sale'
			)

	UPDATE [MiNelson].[dbo].[t]
	SET t.County = n.marketshare_county_name
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] t
	INNER JOIN [MiNelson].[mktshr].[TitleMarketShare_Fips_CountyName] n ON t.fips = n.fips
	WHERE t.county <> n.marketshare_county_name

	DELETE a
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	LEFT JOIN [MiNelson].[mktshr].[Market_Share_Coverage_ZipCode] b ON a.[zip code] = isnull(b.[Zip Code], '')
	WHERE b.[zip code] IS NULL
		AND a.[zip code] <> ''

	--select * from [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	--where a.[Title Company] IN (
	--             'NEW TITLE COMPANY NAME'
	--             ,'NONE LISTED ON DOCUMENT'
	--             )
	-- update a
	--  set a.[Title Company] = b.title_recommended_value
	-- FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	--OUTER APPLY (
	--       SELECT top 1 *
	--       FROM [MiNelson].[dbo].[UR_Raw_Title_Recording] b
	--       WHERE b.Fips = a.Fips
	--             AND b.document_number IN (
	--                    a.FMT_DOC_NBR
	--                    ,a.FMT_Book_Page
	--                    ,a.FMT_MTG1_DOC_NBR
	--                    ,a.FMT_MTG1_Book_Page
	--                    )
	--       ) b
	--WHERE a.[Title Company] IN (
	--             'NEW TITLE COMPANY NAME'
	--             ,'NONE LISTED ON DOCUMENT'
	--             )
	--       AND len(b.title_recommended_value) < 40
	--       AND b.title_recommended_value NOT IN (
	--             'NEW TITLE COMPANY NAME'
	--             ,'NONE LISTED ON DOCUMENT'
	--             )
	--       AND b.title_recommended_value IS NOT NULL
	---------------updating using keyed Ne_titlecompanyName field
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(r.[new_title_company_name], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Lien].[UR].[DOCUMENT] r ON a.fips = r.fips_code
		AND a.FMT_DOC_NBR = r.cmt_docnumber
	WHERE a.[Title Company] IN ('NEW TITLE COMPANY NAME')
		AND isnull(r.[new_title_company_name], '') <> ''

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(r.[new_title_company_name], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Lien].[UR].[DOCUMENT] r ON a.fips = r.fips_code
		AND a.FMT_Book_Page = r.cmt_docnumber
	WHERE a.[Title Company] IN ('NEW TITLE COMPANY NAME')
		AND isnull(r.[new_title_company_name], '') <> ''

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.title_recommended_value
	-- select *
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording] b ON a.Fips = b.Fips
		AND a.FMT_DOC_NBR = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND len(b.title_recommended_value) < 40
		AND b.title_recommended_value NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.title_recommended_value IS NOT NULL
		   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.title_recommended_value
	--  select * 
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording] b ON a.Fips = b.Fips
		AND a.FMT_Book_Page = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND len(b.title_recommended_value) < 40
		AND b.title_recommended_value NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.title_recommended_value IS NOT NULL
		   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.title_recommended_value
	--  select * 
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording] b ON a.Fips = b.Fips
		AND a.FMT_MTG1_DOC_NBR = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND len(b.title_recommended_value) < 40
		AND b.title_recommended_value NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.title_recommended_value IS NOT NULL
		   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.title_recommended_value
	--  select * 
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording] b ON a.Fips = b.Fips
		AND a.FMT_MTG1_Book_Page = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND len(b.title_recommended_value) < 40
		AND b.title_recommended_value NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.title_recommended_value IS NOT NULL
		   and not(b.title_recommended_value  like '%ESCROW%' and	b.title_recommended_value not like '%TITLE%')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.[Title Company], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b ON a.Fips = b.Fips
		AND a.FMT_DOC_NBR = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		-- and  len(b.title_recommended_value) >= 40
		AND b.[Title Company] NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.[Title Company] IS NOT NULL
	

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.[Title Company], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b ON a.Fips = b.Fips
		AND a.FMT_Book_Page = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		-- and  len(b.title_recommended_value) >= 40
		AND b.[Title Company] NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.[Title Company] IS NOT NULL
		

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.[Title Company], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b ON a.Fips = b.Fips
		AND a.FMT_MTG1_DOC_NBR = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		-- and  len(b.title_recommended_value) >= 40
		AND b.[Title Company] NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.[Title Company] IS NOT NULL
		

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.[Title Company], 60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[dbo].[UR_Raw_Title_Recording_LongTitle] b ON a.Fips = b.Fips
		AND a.FMT_MTG1_Book_Page = b.document_number
		AND a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		-- and  len(b.title_recommended_value) >= 40
		AND b.[Title Company] NOT IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.[Title Company] IS NOT NULL
		

	----- Update from Deed BK
	--select count (*)
	--			 from Minelson.[dbo].[TitleMarketShare_BaseTable_FMTDoc] a
	--where a.[Title Company] IN (
	--             'NEW TITLE COMPANY NAME'
	--            ,'NONE LISTED ON DOCUMENT'
	--             )
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.[TITLE_COMPANY_NAME]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.fips = b.fips
		AND a.fmt_doc_nbr = b.FMT_DOC_NBR
		AND b.Source_Type = 'B'
	WHERE a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'
		

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.[TITLE_COMPANY_NAME]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.fips = b.fips
		AND a.FMT_Book_Page = b.FMT_Book_Page
		AND b.Source_Type = 'B'
	WHERE a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'
		

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.[TITLE_COMPANY_NAME]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.fips = b.fips
		AND a.FMT_MTG1_DOC_NBR = b.FMT_MTG1_DOC_NBR
		AND b.Source_Type = 'B'
	WHERE a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = b.[TITLE_COMPANY_NAME]
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.fips = b.fips
		AND a.FMT_MTG1_Book_Page = b.FMT_MTG1_Book_Page
		AND b.Source_Type = 'B'
	WHERE a.[Title Company] IN (
			'NEW TITLE COMPANY NAME'
			,'NONE LISTED ON DOCUMENT'
			)
		AND b.TITLE_COMPANY_NAME <> 'NONE AVAILABLE'

	--------using Trustee names
	--update a
	--  set a.[Title Company] = left(b.Trustee_name, 60)
	--  --select *
	-- FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	--OUTER APPLY (
	--       SELECT top 1 *
	--       FROM  Minelson.dbo.TC_Trustee b
	--       WHERE b.Fips_code = a.Fips
	--             AND b.cmt_docnumber IN (
	--                    a.FMT_DOC_NBR
	--                    ,a.FMT_Book_Page
	--                    ,a.FMT_MTG1_DOC_NBR
	--                    ,a.FMT_MTG1_Book_Page
	--                    )
	--       ) b
	--WHERE a.[Title Company] IN ( 'NONE LISTED ON DOCUMENT', 'SIMPLIFILE'  )
	--      -- AND len(b.Trustee_name) < 40
	--       AND  b.name_identifier = 'C' 
	-- and (b.Trustee_name  like '%title%'
	--              or  b.Trustee_name   like '%ABSTRACT%'
	--             or  b.Trustee_name  like '%SETTLEMENT%'
	--             or b.Trustee_name  like '%closing%'
	--              or b.Trustee_name  like '%escrow%' 
	--              or b.Trustee_name  like '% ttl %' 
	--              or b.Trustee_name  like '% t&E %'
	--              or  b.Trustee_name    like '%ABS%'
	--			  )
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.Trustee_name, 60)
	-- select *
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Minelson].[dbo].[TC_Trustee] b ON b.Fips_code = a.Fips
		AND a.FMT_DOC_NBR = b.cmt_docnumber
		AND a.[Title Company] IN (
			'SIMPLIFILE'
			,'NONE LISTED ON DOCUMENT'
			)
		--and  len(b.Trustee_name ) < 40
		AND (
			b.Trustee_name LIKE '%title%'
			OR b.Trustee_name LIKE '%ABSTRACT%'
			OR b.Trustee_name LIKE '%SETTLEMENT%'
			OR b.Trustee_name LIKE '%closing%'
		--	OR b.Trustee_name LIKE '%escrow%'
			OR b.Trustee_name LIKE '% ttl %'
			OR b.Trustee_name LIKE '% t&E %'
			OR b.Trustee_name LIKE '%ABS%'
			)
			and a.state not in ('WA', 'OR')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.Trustee_name, 60)
	-- select *
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Minelson].[dbo].[TC_Trustee] b ON b.Fips_code = a.Fips
		AND a.FMT_Book_Page = b.cmt_docnumber
		AND a.[Title Company] IN (
			'SIMPLIFILE'
			,'NONE LISTED ON DOCUMENT'
			)
		--and  len(b.Trustee_name ) < 40
		AND (
			b.Trustee_name LIKE '%title%'
			OR b.Trustee_name LIKE '%ABSTRACT%'
			OR b.Trustee_name LIKE '%SETTLEMENT%'
			OR b.Trustee_name LIKE '%closing%'
		--	OR b.Trustee_name LIKE '%escrow%'
			OR b.Trustee_name LIKE '% ttl %'
			OR b.Trustee_name LIKE '% t&E %'
			OR b.Trustee_name LIKE '%ABS%'
			)
		and a.state not in ('WA', 'OR')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.Trustee_name, 60)
	-- select *
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Minelson].[dbo].[TC_Trustee] b ON b.Fips_code = a.Fips
		AND a.FMT_MTG1_DOC_NBR = b.cmt_docnumber
		AND a.[Title Company] IN (
			'SIMPLIFILE'
			,'NONE LISTED ON DOCUMENT'
			)
		--and  len(b.Trustee_name ) < 40
		AND (
			b.Trustee_name LIKE '%title%'
			OR b.Trustee_name LIKE '%ABSTRACT%'
			OR b.Trustee_name LIKE '%SETTLEMENT%'
			OR b.Trustee_name LIKE '%closing%'
		--	OR b.Trustee_name LIKE '%escrow%'
			OR b.Trustee_name LIKE '% ttl %'
			OR b.Trustee_name LIKE '% t&E %'
			OR b.Trustee_name LIKE '%ABS%'
			)
			and a.state not in ('WA', 'OR')

	UPDATE [MiNelson].[dbo].[a]
	SET a.[Title Company] = left(b.Trustee_name, 60)
	-- select *
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Minelson].[dbo].[TC_Trustee] b ON b.Fips_code = a.Fips
		AND a.FMT_MTG1_Book_Page = b.cmt_docnumber
		AND a.[Title Company] IN (
			'SIMPLIFILE'
			,'NONE LISTED ON DOCUMENT'
			)
		--and  len(b.Trustee_name ) < 40
		AND (
			b.Trustee_name LIKE '%title%'
			OR b.Trustee_name LIKE '%ABSTRACT%'
			OR b.Trustee_name LIKE '%SETTLEMENT%'
			OR b.Trustee_name LIKE '%closing%'
		--	OR b.Trustee_name LIKE '%escrow%'
			OR b.Trustee_name LIKE '% ttl %'
			OR b.Trustee_name LIKE '% t&E %'
			OR b.Trustee_name LIKE '%ABS%'
			)
			and a.state not in ('WA', 'OR')


	------------------------------------
	--- update attorney from attorney field from Deed 7/12/2022
	UPDATE [MiNelson].[dbo].[a]
	SET a.Attorney = deed.Attorney_Full_Name
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	LEFT JOIN [deed].[dbo].[deed] deed ON a.deedid = deed.deedid
	WHERE a.Attorney = 'UNKNOWN'
		AND (
			deed.Attorney_Full_Name IS NOT NULL
			AND deed.Attorney_Full_Name NOT LIKE 'ERECORDING%'
			AND deed.Attorney_Full_Name NOT LIKE 'SIMPLIFILE%'
			AND deed.Attorney_Full_Name NOT LIKE 'INDECOMM%'
			)

    update [MiNelson].[dbo].[a]
set a.Attorney = deed.Attorney_Firm_Name
--select *
FROM   [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
  left join [deed].[dbo].[deed] deed
  on a.deedid = deed.deedid		
  where a.Attorney = 'UNKNOWN' 
     and (deed.Attorney_Full_Name is null and deed.Attorney_Firm_Name is not null)


	--  and left(a.[title company],10) <>  left(deed.Attorney_Full_Name,10)
	UPDATE [MiNelson].[dbo].[a]
	SET a.Attorney = substring((
			CASE 
				WHEN c.requested_prepared_by_attorney_middle_initial IS NOT NULL
					THEN CONCAT (
							requested_prepared_by_attorney_first_name
							,' '
							,requested_prepared_by_attorney_middle_initial
							,' '
							,requested_prepared_by_attorney_last_company_name
							)
				WHEN (
						c.requested_prepared_by_attorney_first_name IS NOT NULL
						AND c.requested_prepared_by_attorney_middle_initial IS NULL
						)
					THEN CONCAT (
							requested_prepared_by_attorney_first_name
							,' '
							,requested_prepared_by_attorney_last_company_name
							)
				ELSE c.requested_prepared_by_attorney_last_company_name
				END
			),1,60)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.deedid = b.deedid
	LEFT JOIN [Lien].[UR].[DOCUMENT] c ON b.ur_doc_id = c.doc_id
	WHERE a.attorney LIKE 'UNKNOWN'
		AND a.DATE >= '2021-01-01'
		--and b.Attorney_Full_Name is  null
		AND c.[requested_prepared_by_attorney_last_company_name] IS NOT NULL
		AND c.[requested_prepared_by_attorney_last_company_name] <> ''

	UPDATE [MiNelson].[dbo].[a]
	SET a.Attorney = a.[Title company]
		,a.[Title company] = 'ATTORNEY ONLY'
	--select * 
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	WHERE (
			[title company] LIKE '% PLLC'
			OR [title company] LIKE '% PLC'
			OR [Title Company] LIKE 'LAW OFFICES OF %'
			OR (
				[Title Company] LIKE '% PA'
				AND [Title Company] NOT LIKE '% of PA'
				)
			OR [Title Company] LIKE '% ESQ'
			OR [Title Company] LIKE '% LLP'
			OR [Title Company] LIKE '% PC'
			OR [Title Company] LIKE '% LPA'
			OR [Title Company] LIKE '% PL'
			OR [Title Company] LIKE '% PS'
			OR [Title Company] LIKE '% PSC'
			OR [Title Company] LIKE '% SC'
			OR [Title Company] LIKE '% LAW'
			OR [Title Company] LIKE '% LAW GROUP'
			OR [Title Company] LIKE '% LAW FIRM'
			OR [Title Company] LIKE '% LAW OFFICE'
			OR [Title Company] LIKE '% FIRM %'
			OR [Title Company] LIKE '% FIRM'
			OR [Title Company] LIKE '% LEGAL SERVICES %'
			OR [Title Company] LIKE '% LEGAL SERVICES'
			OR [Title Company] LIKE '% LEGAL SVCS %'
			OR [Title Company] LIKE '% LEGAL SVCS'
			OR [Title Company] LIKE '% PARALEGAL SERVICES %'
			OR [Title Company] LIKE '% PARALEGAL SERVICES'
			OR [Title Company] LIKE '% PARALEGAL SVCS %'
			OR [Title Company] LIKE '% PARALEGAL SVCS'
			OR [Title Company] LIKE '% LICENSED ATTORNEY %'
			OR [Title Company] LIKE '% LICENSED ATTORNEY'
			OR [Title Company] LIKE '% ATTORNEY %'
			OR [Title Company] LIKE '% ATTORNEY'
			OR [Title Company] LIKE '% ATTORNEY AT LAW %'
			OR [Title Company] LIKE '% ATTORNEY AT LAW'
			OR [Title Company] LIKE '% ATTORNEYS AT LAW %'
			OR [Title Company] LIKE '% ATTORNEYS AT LAW'
			OR [Title Company] LIKE '% ATTORNEY-AT-LAW %'
			OR [Title Company] LIKE '% ATTORNEY-AT-LAW'
			OR [Title Company] LIKE '% ATTORNEYS-AT-LAW %'
			OR [Title Company] LIKE '% ATTORNEYS-AT-LAW'
			OR [Title Company] LIKE '% COUNSELLOR AT LAW %'
			OR [Title Company] LIKE '% COUNSELLOR AT LAW'
			OR [Title Company] LIKE '% ESQUIRE %'
			OR [Title Company] LIKE '% ESQUIRE'
			OR [Title Company] LIKE '% ESQ.'
			)
		AND (
			[Title Company] NOT LIKE '%title%'
			AND [Title Company] NOT LIKE '%ABSTRACT%'
			AND [Title Company] NOT LIKE '%SETTLEMENT%'
			AND [Title Company] NOT LIKE '%closing%'
			AND [Title Company] NOT LIKE '%escrow%'
			--and [Title Company] not like '%services%'
			AND [Title Company] NOT LIKE '% ttl %'
			AND [Title Company] NOT LIKE '% t&E %'
			AND [Title Company] NOT LIKE '%ABS%'
			AND [Title Company] NOT LIKE '%#NAME%'
			AND [Title Company] NOT LIKE '%CORPORATION%'
			AND [Title Company] NOT LIKE '%DOCUMENT%'
			AND [Title Company] NOT LIKE '%ENGINEER%'
			AND [Title Company] NOT LIKE '%MORTGAGE%'
			AND [Title Company] NOT LIKE '%PARTNERSHIP%'
			AND [Title Company] NOT LIKE '%RECORDER%'
			AND [Title Company] NOT LIKE '%SURVEY%'
			AND [Title Company] NOT LIKE '%TITLE%'
			AND [Title Company] NOT LIKE '%TOWNSHIP%'
			AND [Title Company] NOT LIKE '%STATE OF%'
			AND [Title Company] NOT LIKE '%OF PA%'
			AND [Title Company] NOT LIKE '%PHILADELPHIA PA%'
			AND [Title Company] NOT LIKE '%IRWIN PA%'
			AND [Title Company] NOT LIKE '%CORAPOLIS PA%'
			)

	---- change high loan value to 04/27/2022
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Loan Amount] = 0
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.deedid = b.deedid
	INNER JOIN [Assr].[dbo].[Assr] c ON b.Ref_Id = c.Ref_Id
		AND b.Fips = c.Fips
	WHERE a.[Transaction Type] IN ('Refinance')
		AND a.[Loan Amount] > 10000000
		AND a.[Loan Amount] > (
			CASE 
				WHEN c.Total_Value_Calculated IS NOT NULL
					THEN c.Total_Value_Calculated
				ELSE 0
				END
			) * 10
		AND (
			CASE 
				WHEN (
						a.[loan amount] IS NOT NULL
						AND c.Total_Value_Calculated IS NOT NULL
						)
					THEN cast((100 * a.[Loan Amount] / (c.Total_Value_Calculated + 1)) AS FLOAT)
				ELSE NULL
				END
			) > 1000
		AND a.Residential = 'YES'

	-- ----- Update title company from RT 5/4/2022 ---- take out 2/6/23 since we dont have RT data anymore
	-- --select *  FROM  [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	--	  update m
	--	  set m.[Title Company] = r.SR_TITLE_CO_NAME
	-- FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] m 
	--inner join 
	--Deed.dbo.Deed ur
	--on m.deedid = ur.deedid
	--inner join
	--[MiNelson].[dbo].[My_rt_doc_formats] r
	--on ur.fips = r.fips and ur.FMT_DOC_NBR = r.FMT_DOC_NBR
	--and ur.recording_date = (left(r.[SR_DATE_TRANSFER],4) + '-' + left(right(r.[SR_DATE_TRANSFER],4),2) + '-' + right(r.[SR_DATE_TRANSFER],2))
	--where ur.source_type = 'E'
	--and  m.[title company] in ('NONE LISTED ON DOCUMENT', 'NEW TITLE COMPANY NAME')
	--and (sr_title_co_name  not like '@%'
	--and sr_title_co_name  not like 'INDECOMM%' 
	--and sr_title_co_name not like 'ATTORNEY ONLY'
	--and sr_title_co_name not like  'Texas Recording Service%'
	--and sr_title_co_name  not like  'DATA SEARCH%'
	--and sr_title_co_name not like  'LENDER RECORDING%'
	--and sr_title_co_name not like  'CCS RECORDING TEAM%'
	--and sr_title_co_name not like  'Ameristar Info Network Llc%'
	--and sr_title_co_name not like  'AMERISTAR INFORMATION NETWORK%'
	--and sr_title_co_name not like 'ISGN RECORDING DEPT%'
	--and sr_title_co_name not like 'LSI-LPS E RECORDING SOLUTIONS%'
	--and sr_title_co_name not like 'CSC DOCUMENT RECORDING%'
	--and sr_title_co_name not like 'CUSTOM RECORDING SOLUTIONS%'
	--and sr_title_co_name not like 'US RECORDINGS INC%'
	--and sr_title_co_name not like 'LSI E RECORDING SOLUTIONS%')
	-- update m
	--	  set m.[Title Company] = r.SR_TITLE_CO_NAME
	--FROM  [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] m 
	--inner join 
	--Deed.dbo.Deed ur
	--on m.deedid = ur.deedid
	--inner join
	--[MiNelson].[dbo].[My_rt_doc_formats] r
	--on ur.fips = r.fips and ur.[FMT_Book_Page] = r.[FMT_Book_Page] and ur.recording_date = (left(r.[SR_DATE_TRANSFER],4) + '-' + left(right(r.[SR_DATE_TRANSFER],4),2) + '-' + right(r.[SR_DATE_TRANSFER],2))
	--where m.[sale document number] is null and ur.source_type = 'E'
	--and  m.[title company] in ('NONE LISTED ON DOCUMENT', 'NEW TITLE COMPANY NAME')
	--and (sr_title_co_name  not like '@%'
	--and sr_title_co_name  not like 'INDECOMM%' 
	--and sr_title_co_name not like 'ATTORNEY ONLY'
	--and sr_title_co_name not like  'Texas Recording Service%'
	--and sr_title_co_name  not like  'DATA SEARCH%'
	--and sr_title_co_name not like  'LENDER RECORDING%'
	--and sr_title_co_name not like  'CCS RECORDING TEAM%'
	--and sr_title_co_name not like  'Ameristar Info Network Llc%'
	--and sr_title_co_name not like  'AMERISTAR INFORMATION NETWORK%'
	--and sr_title_co_name not like 'ISGN RECORDING DEPT%'
	--and sr_title_co_name not like 'LSI-LPS E RECORDING SOLUTIONS%'
	--and sr_title_co_name not like 'CSC DOCUMENT RECORDING%'
	--and sr_title_co_name not like 'CUSTOM RECORDING SOLUTIONS%'
	--and sr_title_co_name not like 'US RECORDINGS INC%'
	--and sr_title_co_name not like 'LSI E RECORDING SOLUTIONS%')
	-------- Delete Covid Partial Claim HUD 6/29/2022
	DELETE a
	--select a.* 
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [MiNelson].[mktshr].[LenderClean_BK] l ON a.Lender = l.Lender
	WHERE --fips in  (41005,41067,41051) and 
		left(DATE, 7) >= '2022-01'
		AND [Loan Amount] < 50000
		AND [Lender Clean] != 'UNKNOWN'
		AND (
			[Lender Clean] = 'HUD'
			OR [Lender Clean] LIKE 'SECRETARY OF HOUSING%'
			OR [Lender Clean] LIKE 'FEDERAL HOUSING COMMISSIONER%'
			OR [Lender Clean] LIKE 'US DEPARTMENT OF HOUSING%'
			OR [lender clean] LIKE 'COMMISSIONER OF HOUSING%'
			OR [lender clean] LIKE 'SECRETARY OF THE US DEPARTMENT%'
			OR [lender clean] LIKE 'SECRETARY OF VETERANS AFFAIRS%'
			OR [lender clean] LIKE 'UNITED STATES OF AMERICA%'
			OR a.[Lender] LIKE 'SECRETARY OF HOUSING%'
			OR a.[Lender] LIKE 'FEDERAL HOUSING COMMISSIONER%'
			OR a.[Lender] LIKE 'US DEPARTMENT OF HOUSING%'
			OR a.[lender] LIKE 'COMMISSIONER OF HOUSING%'
			OR a.[lender] LIKE 'SECRETARY OF THE US DEPARTMENT%'
			OR a.[lender] LIKE 'SECRETARY OF VETERANS AFFAIRS%'
			OR a.[lender] LIKE 'UNITED STATES OF AMERICA%'
			)
		AND a.[Lender] IS NOT NULL
		AND [Transaction Type] NOT LIKE 'Timeshare%'

	---- Update loan type 6/29/2022
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Loan Type] = 'Conventional'
	--select a.*
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Deed].[dbo].[deed] b ON a.deedid = b.deedid
	WHERE [loan amount] <> 0
		AND [Loan Type] = 'none'
		AND b.MTG1_DETAILED_DOC_TYPE IN (
			'TR'
			,'MG'
			)
		AND b.mtg1_construction_loan IS NULL
		AND DATE > '2022-01-01'
		AND Residential = 'Yes'

	----- update conforming 7/6/2022
	UPDATE [MiNelson].[dbo].[a]
	SET a.[Conforming] = (
			CASE 
				WHEN a.[LOAN TYPE] = 'Conventional'
					THEN CASE 
							WHEN a.NBR_OF_RES_UNITS = 1
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							WHEN a.NBR_OF_RES_UNITS = 2
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2]
								THEN 'YES'
							WHEN a.NBR_OF_RES_UNITS = 3
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3]
								THEN 'YES'
							WHEN a.NBR_OF_RES_UNITS = 4
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4]
								THEN 'YES'
							WHEN (
									a.NBR_OF_RES_UNITS = 0
									OR a.NBR_OF_RES_UNITS IS NULL
									)
								AND deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ]
								THEN 'YES'
							ELSE 'NO'
							END
				ELSE 'NO'
				END
			)
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	LEFT JOIN [deed].[dbo].[deed] deed ON a.deedid = deed.deedid
	LEFT JOIN [Assr].[dbo].[Assr] assr WITH (NOLOCK) ON deed.FIPS = assr.FIPS
		AND
		--  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
		deed.REF_ID = assr.REF_ID
	LEFT JOIN [MiNelson].[mktshr].[ConformingLimits] cnf WITH (NOLOCK) ON deed.FIPS = cnf.fips

	--- update upper case title company name 7/12/2022
	UPDATE [MiNelson].[dbo].[a]
	SET [Title Company] = Upper([Title Company])
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a

	---update FMT_DOC_NBR 11/16/2022
	UPDATE [MiNelson].[dbo].[a]
	SET a.FMT_MTG1_DOC_NBR = b.FMT_MTG1_DOC_NBR
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [Deed].[dbo].[deed] b ON a.ref_id = b.ref_id
		AND a.[Mgt document number] = b.mtg1_doc_nbr
		AND a.DATE = b.Recording_Date
	WHERE a.FMT_MTG1_DOC_NBR IS NULL
		AND (
			b.FMT_MTG1_DOC_NBR IS NOT NULL
			AND b.FMT_MTG1_DOC_NBR <> ''
			)
		AND a.fmt_doc_nbr <> b.fmt_doc_nbr

	----- remove cashsale in non disclosure state
	DELETE a
	FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
	INNER JOIN [deed].[dbo].[deed] b ON a.deedid = b.deedid
	WHERE DATE >= '2017-01-01'
		AND [Transaction Type] IN ('Resale - Cash Sale')
		AND residential = 'Yes'
		AND (
			left([seller name], 5) = left(buyer, 5)
			OR b.DETAILED_DOC_TYPE IN (
				'DI'
				,'CD'
				,'EX'
				,'AF'
				,'VL'
				,'AD'
				,'AN'
				,'ID'
				,'QC'
				,'GF'
				)
			)
		AND [Sales Price] = 0
		AND STATE IN (
			'AK'
			,'ID'
			,'IN'
			,'KS'
			,'LA'
			,'ME'
			,'MS'
			,'MO'
			,'MT'
			,'NM'
			,'ND'
			,'TX'
			,'UT'
			,'WY'
			)

 ----- change to unknown for FAMS with City Lending 9/25/2024 per Janice Letcher and Tracy Wayland
   
update [MiNelson].[dbo].[a]
set [title company] =   'UNKNOWN'
-- select *
from [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
where  ( [title company] like 'FIRST AMERICAN MORTGAGE%'or [title company] like 'FAMS%')
and lender like 'City Lending %' 

--- update lender account 2026/07/22

update [MiNelson].[dbo].[a]
set lender  =   'UNKNOWN'
-- select *
from [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
where  
                lender like '%Account%'

                and lender not like '%Accounting%'

                and lender not like '%Accountan%'

                and lender not like '%Account'

                and lender not like '%Account llc%'

--- Change to Venture Title & Escrow for ID per Coreln 2024-12-18

update [MiNelson].[dbo].[a]
set [title company] =   'VENTURE TITLE & ESCROW'
-- select * 
from [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a
  where [title company] like 'VENTURE TITLE%'
  and state = 'ID'


    update [MiNelson].[dbo].[a] 
	  set a.[Title Company] = replace([Title Company],'-','')
FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a with(nolock)
where [Title Company] like '-%'

--- update upper case title company name 7/12/2022
update [MiNelson].[dbo].[a]
		set [Title Company] = Upper([Title Company])
		FROM [MiNelson].[dbo].[UR_TitleMarketShare_BaseTable_bulk] a

END


