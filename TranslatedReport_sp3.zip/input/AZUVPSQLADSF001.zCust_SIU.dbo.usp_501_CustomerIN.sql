SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- Create date: 20151215
-- Description:	Step 1 of Process, Address Standardization and Matching
-- =============================================
CREATE PROCEDURE [zCust_SIU].[dbo].[usp_501_CustomerIN] 
	--@InputFILE varchar(50)
	
AS
BEGIN

	SET NOCOUNT ON;

	--Truncate table INPUT_RAW
	--Insert into  INPUT_RAW ([EntityID]
 --     ,[Monitoring Type]
 --     ,[LastName]
 --     ,[FirstName]
 --     ,[MiddleName]
 --     ,[State]
 --     ,[BankruptcyThruDate]
 --     ,[TypeOfEntity]
 --     ,[ParentAgentID]
 --     ,[TerritoryID])
	--Select 
	--[Entity ID]
 --     ,[Monitoring Type]
 --     ,[Last Name]
 --     ,[First Name]
 --     ,[Middle Name]
 --     ,[State]
 --     ,[BankruptcyThruDate]
 --     ,[Type Of Entity]
 --     ,[ParentAgentID]
 --     ,[TerritoryID]
	--  --Select * 
 --    FROM [zCust_SIU].[dbo].INPUT_RAW_20220715
	

	--Select [Entity ID]
 --     ,[Monitoring Type]
 --     ,[Last Name]
 --     ,[First Name]
 --     ,[Middle Name]
 --     ,[State]
 --     ,[BankruptcyThruDate]
 --     ,[Type of Entity]
 --     ,[ParentAgentID]
 --     ,[TerritoryID]
 -- FROM [zCust_SIU].[dbo].[INPUT_RAW_20190502]
 -- where [Entity ID] not like ''


	--TRUNCATE TABLE INPUT_IN

	--	INSERT INTO INPUT_IN(
	--	[EntityID1]
 --     ,[Monitoring Type]
 --     ,[Last Name]
 --     ,[First Name]
 --     ,[Middle Name]
 --     ,[State]
 --     ,[Bankruptcy Thru Date]
 --     ,[TypeOfEntity]
 --     ,[ParentAgentID]
 --     ,[TerritoryID]
	--  ,[INPUTKEY]
	--  )
	--Select 
	--[Entity ID]
 --     ,[Monitoring Type]
 --     ,[Last Name]
 --     ,[First Name]
 --     ,[Middle Name]
 --     ,[State]
 --     ,[BankruptcyThruDate]
 --     ,[Type Of Entity]
 --     ,[ParentAgentID]
 --     ,[TerritoryID]
	--  ,[Entity ID]
	--  --Select * 
 --    FROM [zCust_SIU].[dbo].INPUT_RAW_20220715



	--Select EntityID, count(*)   from INPUT_RAW
	--Group by EntityID
	--having count(*) > 1

--     ------Update Monitoring table - Deletes & Changes
	  Update [zCust_SIU].[dbo].[INPUT_IN_MONITOR]
	  Set DATE_DELETED =  convert(date,Getdate())
	   ,[Monitoring Type] = 'D'
	 --Select * 
	  From [zCust_SIU].[dbo].[INPUT_IN_MONITOR] as A join 
	  [zCust_SIU].[dbo].[INPUT_RAW] as B on 
	  A.[EntityID1]  = B.[EntityID]
	  where B.[Monitoring Type] = 'D'

	
	Update [zCust_SIU].[dbo].[INPUT_IN_MONITOR]
	  Set DATE_DELETED =  convert(varchar(10),Getdate(),112)
	   ,[Monitoring Type] = 'C'
	 --Select * 
	 From [zCust_SIU].[dbo].[INPUT_IN_MONITOR] as A join 
	  [zCust_SIU].[dbo].[INPUT_RAW] as B on 
	  A.[EntityID1]  = B.[EntityID]
	  where B.[Monitoring Type] = 'C'


	  Insert into [zCust_SIU].[dbo].[INPUT_IN_MONITOR_DELETE]
	 SELECT        EntityID1, [Monitoring Type], [Last Name], [First Name], [Middle Name], State, [Bankruptcy Thru Date], TypeOfEntity, ParentAgentID, TerritoryID, DATE_ADDED, 
                         DATE_DELETED, MAX_DATE
FROM            [zCust_SIU].[dbo].[INPUT_IN_MONITOR]
WHERE        ([Monitoring Type] IN ('C', 'D'))


	  Delete from [zCust_SIU].[dbo].[INPUT_IN_MONITOR]
	  where [Monitoring Type] in ('C','D')

	  Select * From [zCust_SIU].[dbo].[INPUT_IN_MONITOR]

	  --Truncate table [INPUT_IN_MONITOR]

	  --ALTER TABLE [INPUT_IN_MONITOR] ADD [INPUTKEY][varchar](250)NULL

	  


	  Insert into [zCust_SIU].[dbo].[INPUT_IN_MONITOR]([EntityID1]
      ,[Monitoring Type]
      ,[Last Name]
      ,[First Name]
      ,[Middle Name]
      ,[State]
      ,[Bankruptcy Thru Date]
      ,[TypeOfEntity]
      ,[ParentAgentID]
      ,[TerritoryID]
      ,[DATE_ADDED]
	  ,MAX_DATE
	  ,[FullName]
	  ,[INPUTKEY]
     )
	  Select 
	   A.[EntityID]
      ,A.[Monitoring Type]
      ,A.[LastName]
      ,A.[FirstName]
      ,A.[MiddleName]
      ,A.[State]
      ,A.[BankruptcyThruDate]
      ,A.[TypeOfEntity]
      ,A.[ParentAgentID]
      ,A.[TerritoryID]
	  ,convert(varchar(10),Getdate(),112)
	  ,A.[BankruptcyThruDate]
	  ,ltrim(rtrim([Global].[dbo].[Before1stCharacter](A.[LastName],'('))) + ',' 
		+ isNULL(ltrim(rtrim(A.[FirstName])),'') 
		+ CASE WHEN ltrim(rtrim(A.[MiddleName])) is NOT NULL THEN ' ' + LEFT(ltrim(rtrim(A.[MiddleName])),1) ELSE '' END 
		,A.[EntityID]
      From [zCust_SIU].[dbo].[INPUT_RAW] AS A left outer join 
	  [zCust_SIU].[dbo].[INPUT_IN_MONITOR] as B on  
	  A.[EntityID]  = B.[INPUTKEY]
	  where   B.[INPUTKEY] is null
	  and A.[Monitoring Type] in ('A','C')


	  TRUNCATE TABLE INPUT_IN

		INSERT INTO [zCust_SIU].[dbo].[INPUT_IN](
		[EntityID1]
      ,[Monitoring Type]
      ,[Last Name]
      ,[First Name]
      ,[Middle Name]
      ,[State]
      ,[Bankruptcy Thru Date]
      ,[TypeOfEntity]
      ,[ParentAgentID]
      ,[TerritoryID]
	  ,[INPUTKEY]
	  )
		SELECT   
	  INPUTKEY
      ,[Monitoring Type]
      ,[Last Name]
      ,[First Name]
      ,[Middle Name]
      ,[State]
      ,[Bankruptcy Thru Date]
      ,[TypeOfEntity]
       ,[ParentAgentID]
	   ,[TerritoryID]
	   ,INPUTKEY
	   --,ROW_NUMBER() OVER(ORder by A.INPUTKEY, A.[Last Name], A.[First Name], A.[State])

	  FROM [zCust_SIU].[dbo].[INPUT_IN_MONITOR] A
	   where  A.[Monitoring Type] not like 'D'

	
	

END




