/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_Bulk_DataTree_ClosedCounties | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 1/14/2020
-- Description:	Create MarkShareTitle_DATATree
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_Bulk_DataTree_ClosedCounties]
                
AS 


SET NOCOUNT ON

BEGIN
 
 


 --Bk and TWG Counties
----------------------------------------------------------
----------------------------------------------------------
/*IF OBJECT_ID('tempdb..#Muni_Closed1') IS NOT NULL */
DROP TABLE IF EXISTS #Muni_Closed1
/*IF OBJECT_ID('tempdb..#ClosedCounty1') IS NOT NULL */
DROP TABLE IF EXISTS #ClosedCounty1
----------------------------------------------------------
-- Get latest closed counties from Muni table
----------------------------------------------------------
SELECT distinct
          f.Fips
      ,[MM_STATE_CODE] as [State]
      ,[CENSUS_MUNI_NAME] as [County]
      --,[MM_MUNI_NAME] as [Munc]
      ,[MM_DATA_AVAIL_FLAG]
      ,[MM_NON_DISCLOSURE_FLAG]
       ,left(convert(varchar,MM_LAST_CLOSE_DATE,112),6) as [RecMonth]
      --,[MM_LAST_CLOSE_DATE]
      ,[MORTGAGES_MISSING_FLAG]
into
       #Muni_Closed1
FROM 
       [ART].[dbo].[RT_Muni_Master] mm left outer join
       [MiNelson].[mktshr].[FipsCodes] f on
              mm.MM_STATE_CODE = f.State and
              mm.CENSUS_MUNI_NAME = f.County --and mm.FIPS = 26005
where
       MM_DATA_AVAIL_FLAG = 'B' 
----------------------------------------------------------
-- Get the rest from the Deed table
----------------------------------------------------------
select
       x.Fips,
       x.Month,
       x.Volume,
       avg(x.Volume) over(partition by x.Fips) as [AvgVol],
       x.MaxDate,
       x.MaxBatch,
       case when isdate(x.MaxBatch) = 1 then datediff(day,x.MaxBatch,getdate()) else Null end as [DaysSince],
       m.RecMonth as [MuniMonth],
       case when x.Month <= m.RecMonth or x.Rn < max(Rn) over(partition by x.Fips) - 1 then 'Closed' 
              when m.RecMonth is not Null then 'Open'
              when x.Rn = max(Rn) over(partition by x.Fips) then 'Curr'
              else 'TBD' end as [Status]
       --,max(Rn) over(partition by x.Fips) as [MaxRn]
into
       #ClosedCounty1
from (
select
       deed.Fips,
       left(isnull(deed.RECORDING_DATE,deed.SALE_DATE),4) + substring(convert(varchar(25),isnull(deed.RECORDING_DATE,deed.SALE_DATE),120),6,2) as [Month],
       row_number() over(partition by deed.Fips 
                           order by left(isnull(deed.RECORDING_DATE,deed.SALE_DATE),4) + substring(convert(varchar(25),isnull(deed.RECORDING_DATE,deed.SALE_DATE),120),6,2)) as [Rn],
       count(*) as [Volume],
       max(isnull(deed.RECORDING_DATE,deed.SALE_DATE)) as [MaxDate],
       max(left(deed.CLGX_Unique_Id,8)) as [MaxBatch]
FROM 
       [Deed].[dbo].[Deed] deed 
where
      ( deed.FIPS  in (SELECT distinct fips
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk]) or deed.fips = 1125) 
  and  isnull(deed.RECORDING_DATE,deed.SALE_DATE) > '2014-01-01'
       and Pri_Cat_Code = 'A'                                               ----  Arms-length only
       and (MULTI_APN != 'D' or MULTI_APN is Null)            ----  No Multi's
group by
       deed.Fips,
       left(isnull(deed.RECORDING_DATE,deed.SALE_DATE),4) + substring(convert(varchar(25),isnull(deed.RECORDING_DATE,deed.SALE_DATE),120),6,2)
       ) x left outer join #Muni_Closed1 m on
              x.Fips = m.Fips
order by
       x.Fips,
       x.Month
       


/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_temp') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_temp]



select
       n.Fips,
       n.Month,
       n.Volume,
       convert(varchar, n.MaxDate, 112) as [MaxDate],
       n.MaxBatch,
       case when n.MuniMonth is Null then 'N' else 'Y' end as [Muni],
       convert(varchar, getdate(), 112) as [CloseDate]
       ,n.Status
	 ,  n.MuniMonth 
    into [MiNelson].[mktshr].[DT_ClosedCounties_temp]
from
       #ClosedCounty1 n
where
        n.Status = 'Closed'
     
order by
       n.Fips,
       n.Month

/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_lastupdated') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated]

    
	select distinct fips,  convert(varchar, max(recording_date) , 112) as LastUpdated 
	into [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated]
	from [Deed].[dbo].[Deed]
	group by fips   
  

--  -------------------------------------------------------
---- First Time
---------------------------------------------------------

--/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties') IS NOT NULL */
DROP TABLE IF EXISTS MiNelson.mktshr.DT_ClosedCounties

		
--		 select b.* 
--		   ,a.[Month]
--      ,a.[Volume]
--      ,a.[MaxDate]
--      ,a.[MaxBatch]
--      ,a.[Muni]
--      ,a.[CloseDate]  
--	  ,c.LastUpdated 
--	  into MiNelson.mktshr.DT_ClosedCounties
--	  from MiNelson.mktshr.DT_ClosedCounties_temp a
--		 left join [MiNelson].[mktshr].[DT_StateCountyFips] b
--		 on a.fips = b.fips
--		  left join  MiNelson.mktshr.DT_ClosedCounties_lastupdated c
--		  on b.fips = c.fips



	    

		  
-------------------------------------------------------
--Incremental --- Update ClosedCounty table with newly closed counties
-------------------------------------------------------

/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_temp2') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_temp2]

		
		 select b.* 
		   ,a.[Month]
      ,a.[Volume]
      ,a.[MaxDate]
      ,a.[MaxBatch]
      ,a.[Muni]
      ,a.[CloseDate] 
	     ,a.Status
	 ,  a.MuniMonth  
	  ,c.LastUpdated 
	  into [MiNelson].[mktshr].[DT_ClosedCounties_temp2]
	  from [MiNelson].[mktshr].[DT_ClosedCounties_temp] a
		 left join [MiNelson].[mktshr].[DT_StateCountyFips] b
		 on a.fips = b.fips
		  left join  [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated] c
		  on b.fips = c.fips


		    update [MiNelson].[dbo].[a] 
			set NewClosed = 'N',CloseDate = convert(varchar, getdate(), 112)
			from [MiNelson].[mktshr].[DT_ClosedCounties] a
				 where Newclosed = 'Y'

--			select * from MiNelson.mktshr.DT_ClosedCounties
--				 where Newclosed = 'Y'

--select * from MiNelson.mktshr.DT_ClosedCounties
--				 where CloseDate ='20220526'


insert into  [MiNelson].[mktshr].[DT_ClosedCounties]
     
	   ( [STATE]
      ,[COUNTY]
      ,[FIPS]
      ,[STATE_FIPS]
      ,[Month]
      ,[Volume]
      ,[MaxDate]
      ,[MaxBatch]
      ,[Muni]
      ,[CloseDate]
      ,[LastUpdated]
	  ,NewClosed)
select
	distinct n.state, n.county, n.Fips,n.STATE_FIPS,
      
       n.Month,
       n.Volume,
       convert(varchar, n.MaxDate, 112) as [MaxDate],
       n.MaxBatch,
       case when n.MuniMonth is Null then 'N' else 'Y' end as [Muni],
       convert(varchar, getdate(), 112) as [CloseDate]
	   ,n.LastUpdated
	   ,'Y' as NewClosed
       --,n.Status
   -- into #temp4
from
       [MiNelson].[mktshr].[DT_ClosedCounties_temp2] n left outer join [MiNelson].[mktshr].[DT_ClosedCounties] o on
              n.Fips = o.Fips and
              n.Month = o.Month
where
       o.Fips is Null
       and n.Status = 'Closed'
       and (n.FIPS     in (SELECT distinct fips
  FROM [MiNelson].[mktshr].[DT_TitleMarketShare_Bulk])  or n.fips = 1125) 
order by
       n.Fips,
       n.Month
   
  ---- update lastupdate date 05/07/2021 all rows with the same lastupdated 

update [MiNelson].[dbo].[a] 
set a.lastupdated = b.lastupdated
--select *
from 
  [MiNelson].[mktshr].[DT_ClosedCounties] a
  left join   [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated] b
		  on a.fips = b.fips

--select * from 
--  MiNelson.mktshr.DT_ClosedCounties a
-- where fips = 04013
-- order by month

       
/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_temp') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_temp]
/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_temp2') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_temp2]
/*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_lastupdated') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated]


---check duplicates
select state, county, fips, state_fips, month, Volume, maxdate, maxbatch, muni, closedate, lastupdated, count (*)
 from [MiNelson].[mktshr].[DT_ClosedCounties]
 group by state, county, fips, state_fips, month, Volume, maxdate, maxbatch, muni, closedate, lastupdated
 having count (*) > 1

 select *
 from [MiNelson].[mktshr].[DT_ClosedCounties]
 where Newclosed = 'Y'

 ----adding Tony update 1/5/2023

 
  ----- delete tony counties already closed

  delete a
 -- select *
  from 
  [Minelson].[dbo].[Closed_Date_Tony] a
inner join  [MiNelson].[mktshr].[DT_ClosedCounties] b 
on a.fips = b.fips 
and b.month = concat(left(closed_confidence,4), right(closed_confidence,2))


  /*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_lastupdated') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated]

    
	select distinct fips,  convert(varchar, max(recording_date) , 112) as LastUpdated 
	into [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated]
	from [Deed].[dbo].[Deed]
	group by fips   


  /*IF OBJECT_ID('MiNelson.mktshr.DT_ClosedCounties_save') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[DT_ClosedCounties_save]
	
	  select * into [MiNelson].[mktshr].[DT_ClosedCounties_save]
	  from 
  [MiNelson].[mktshr].[DT_ClosedCounties] a

   select *from 
  [MiNelson].[mktshr].[DT_ClosedCounties] a
  where newclosed = 'Y'
  
 insert into [MiNelson].[mktshr].[DT_ClosedCounties]
 ([STATE]
      ,[COUNTY]
      ,[FIPS]
      ,[STATE_FIPS]
      ,[Month]
      ,[Volume]
      ,[MaxDate]
      ,[MaxBatch]
      ,[Muni]
      ,[CloseDate]
      ,[LastUpdated]
      ,[NewClosed])
(		
		select b.* 
		   ,concat(left(closed_confidence,4), right(closed_confidence,2)) as  [Month]
      ,a.[Volume]
      ,CONVERT(varchar(10), Max_Recording_Date,112) as [MaxDate]
      ,a.[MaxBatch]
      ,'N' as [Muni]
      ,CONVERT(varchar(10), GETDATE(),112) as [CloseDate]
	 
	  ,c.LastUpdated 
	  ,'Y' as NewClosed
	 -- into MiNelson.mktshr.DT_ClosedCounties_temp2
	  from [Minelson].[dbo].[Closed_Date_Tony] a
		 left join [MiNelson].[mktshr].[DT_StateCountyFips] b
		 on a.fips = b.fips
		 left join  [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated] c
		  on b.fips = c.fips
		  )

		    --check duplicates
  select fips, month, count (*)
  from -- MiNelson.mktshr.DT_ClosedCounties_save
  [MiNelson].[mktshr].[DT_ClosedCounties]
group by fips, month
having count (*) > 1

----------------8/8/2024----------------------------------------
  --------------From NEO-----------------

  /*IF object_id('Minelson.dbo.Mytemp1_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp1_NEO];
  
 select Fips,  Max(recording_Date) Max_Recording_Date, 
  Max(created) Last_Date_Received
  into [Minelson].[dbo].[Mytemp1_NEO]
  from [Deed].[dbo].[vDeed]
  group by Fips

     /*IF object_id('Minelson.dbo.Mytemp2_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp2_NEO];
   
  select Fips, left(recording_date,7) as Month, 
  --Max(recording_Date) Max_Recording_Date, 
 -- Max(created) Last_Date_Received,
  count(*) as [Volume],
           max(left(CLGX_Unique_Id,8)) as [MaxBatch]
  into [Minelson].[dbo].[Mytemp2_NEO]
  from [Deed].[dbo].[vDeed]
  group by Fips, left(recording_date,7)


  /*IF object_id('Minelson.dbo.Mytemp3_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp3_NEO];

select x.Fips, x.Current_ClosedMonth, y.NEO_ClosedMonth
 
		into	[Minelson].[dbo].[Mytemp3_NEO]
from 
 (select Fips, max(Month) as Current_ClosedMonth
from -- [MiNelson].[mktshr].[ClosedCounties]  
	[MiNelson].[mktshr].[DT_ClosedCounties]
 group by Fips
)x
inner join  [Minelson].[mktshr].[NEO_Closed_Counties] y
on x.Fips = Y.Fips
where (NEO_CLosedMonth > Current_ClosedMonth) and NEO_ClosedMonth is not null
--and  datediff(month, convert(date,concat(left(Current_ClosedMonth,4),'-',right(Current_ClosedMonth,2),'-', '01'),126), 
--			convert(datetime,concat(left(NEO_ClosedMonth,4),'-',right(NEO_ClosedMonth,2),'-', '01'),126)) = 1
order by 1


  /*IF object_id('Minelson.dbo.Mytemp_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp_NEO];
	  (SELECT distinct a.[Fips]
	 -- , b.Current_ClosedMonth,  NEO_ClosedMonth ,
    ,left (convert(varchar,DATEADD(month, 1,convert ( date, convert (varchar (10), concat(left(Current_ClosedMonth,4),right(Current_ClosedMonth,2), '01')),112) ),112),6) as  [Month]
           ,[Volume]
      ,CONVERT(varchar(10), Max_Recording_Date,112) as [MaxDate]
      ,[MaxBatch]
      ,'N' as [Muni]
      ,CONVERT(varchar(10), GETDATE(),112) as [CloseDate]
	  into [Minelson].[dbo].[Mytemp_NEO]
  FROM [Minelson].[dbo].[Mytemp1_NEO] a
  inner join [Minelson].[dbo].[Mytemp3_NEO] b
  on a.fips = b.fips
  inner join  [Minelson].[dbo].[Mytemp2_NEO] c
  on a.fips = c.fips and --b.NEO_ClosedMonth = concat(left(c.Month,4),right(c.Month,2))
   left (convert(varchar,DATEADD(month, 1,convert ( date, convert (varchar (10), concat(left(Current_ClosedMonth,4),right(Current_ClosedMonth,2), '01')),112) ),112),6) = concat(left(c.Month,4),right(c.Month,2))
  )
  union all
   (SELECT distinct a.[Fips]
	--  , b.Current_ClosedMonth,  NEO_ClosedMonth ,
    ,left (convert(varchar,DATEADD(month, 2,convert ( date, convert (varchar (10), concat(left(Current_ClosedMonth,4),right(Current_ClosedMonth,2), '01')),112) ),112),6) as  [Month]
           ,[Volume]
      ,CONVERT(varchar(10), Max_Recording_Date,112) as [MaxDate]
      ,[MaxBatch]
      ,'N' as [Muni]
      ,CONVERT(varchar(10), GETDATE(),112) as [CloseDate]
  FROM [Minelson].[dbo].[Mytemp1_NEO] a
  inner join [Minelson].[dbo].[Mytemp3_NEO] b
  on a.fips = b.fips
  inner join  [Minelson].[dbo].[Mytemp2_NEO] c
  on a.fips = c.fips and b.NEO_ClosedMonth = concat(left(c.Month,4),right(c.Month,2))
 where datediff(month, convert(date,concat(left(b.Current_ClosedMonth,4),'-',right(b.Current_ClosedMonth,2),'-', '01'),126), 
			convert(datetime,concat(left(b.NEO_ClosedMonth,4),'-',right(b.NEO_ClosedMonth,2),'-', '01'),126)) = 2
  )

  select * from [MiNelson].[mktshr].[DT_ClosedCounties]
  
 insert into [MiNelson].[mktshr].[DT_ClosedCounties]
 ([STATE]
      ,[COUNTY]
      ,[FIPS]
      ,[STATE_FIPS]
      ,[Month]
      ,[Volume]
      ,[MaxDate]
      ,[MaxBatch]
      ,[Muni]
      ,[CloseDate]
      ,[LastUpdated]
      ,[NewClosed])

	
(		
		  select b.*
      ,a.[Month]
      ,a.[Volume]
      ,a.[MaxDate]
      ,a.[MaxBatch]
      ,a.[Muni]
      ,a.[CloseDate]
      ,c.[LastUpdated]
      ,'Y' as [NewClosed]
	  from [Minelson].[dbo].[Mytemp_NEO] a
	   left join [MiNelson].[mktshr].[DT_StateCountyFips] b
		 on a.fips = b.fips
		 left join  [MiNelson].[mktshr].[DT_ClosedCounties_lastupdated] c
		  on b.fips = c.fips
		  )
		    --check duplicates
  select fips, month, count (*)
  from -- MiNelson.mktshr.DT_ClosedCounties_save
  [MiNelson].[mktshr].[DT_ClosedCounties]
group by fips, month
having count (*) > 1

 

 /*IF object_id('Minelson.dbo.Mytemp1_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp1_NEO];
	      /*IF object_id('Minelson.dbo.Mytemp2_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp2_NEO];

	     /*IF object_id('Minelson.dbo.Mytemp3_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp3_NEO];

	     /*IF object_id('Minelson.dbo.Mytemp_NEO') IS NOT NULL
       */
DROP TABLE IF EXISTS [Minelson].[dbo].[Mytemp_NEO];


END  

