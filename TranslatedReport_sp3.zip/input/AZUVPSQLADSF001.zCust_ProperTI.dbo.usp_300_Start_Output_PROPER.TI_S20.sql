SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_ProperTI].[dbo].[usp_300_Start_Output_PROPER.TI_S20]


AS
BEGIN
	
	SET NOCOUNT ON;

	-----This is the Ownership Change Solution---

	----20231129 -  We’re not using their Start Date for this solution.  
	----We’re returning the Current Owner on the property for each extract & setting the 
	----Transaction Status field to Event Found when the current owner name doesn’t match the owner name we sent 
	----on that property on the last extract.

	----20240321 - Change per Nicole---
	----Ownership Change - Return change in ownership AFTER the start date

	----IF the owner name changes but there's no new deed - look at the "The date that the new Assessor data is brought into the db." per NH

		DROP TABLE [dbo].[x_Custom_OUTPUT_S20]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S20](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[INPUT Key][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			[INPUT_Reference ID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			------Added 20240730 per NH-----
			[DTDB RefID][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,

			[Start Date][varchar](250)NULL,

			[Current Owner][varchar](250)NULL,
			[Recording Date][varchar](250)NULL,
			[Document Type][varchar](250)NULL,
			[Document #][varchar](250)NULL,
			[CMTID][varchar](250)NULL,

			-------INTERNAL-----
			[TRACKED_OWNERNAME][varchar](250)NULL,
			[FALastRefreshDate][varchar](250)NULL,
			[CurrSaleRecordingDt][varchar](250)NULL,
			[FAOwnershipTransID][varchar](250)NULL,
			[FAOwnershipRecDate][varchar](250)NULL,
			[MAX_DEEDDATE][varchar](250)NULL
			
		) ON [PRIMARY]

		


		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] (
		[INPUT Key],
		[INPUT_Reference ID],
			[INPUT_ADDRESS],
			[INPUT_CITY],
			[INPUT_STATE],
			[INPUT_ZIPCODE],
			[TRACKED_OWNERNAME],
			[FIPS],
			[PROPERTYID],
			[Start Date],
			[DTDB RefID],
			[MAX_DEEDDATE]
	   )
	
		Select 	INPUTKEY
		,[INPUTKEY]
         ,[Address]
      ,[City]
      ,[State]
      ,[ZipCODE]
	  ,[TRACKED_OWNERNAME]
	  ,FIPS
	  ,[PROPERTYID]
	  ,convert(date,[Start Date])
	  ,REF_ID
     ,[MAX_DEEDDATE]
       --Select * 
	   
	   FROM [zCust_ProperTI].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null


	

	  
	  
	  Select top 100 * From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S20 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S20 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUT Key] = c.RAW_ID

		

		Update [zCust_ProperTI].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[RUN Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_ProperTI].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


		
		Update [zCust_ProperTI].[dbo].[a]
		set 
		A.[Coverage Status] = B.TaxrollActive
		,A.[FALastRefreshDate] = B.[FALastRefreshDate]
		--,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE

	
		------------------------------------------------------------------------

		Update [zCust_ProperTI].[dbo].[A]
		Set 
		A.[Current Owner] = B.OwnerStdNAME1FULL
		,A.[CurrSaleRecordingDt] = B.CurrSaleRecordingDate
		,A.FAOwnershipTransID = B.FAOwnerTransactionId
		From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A join [data].[dbo].[Property] as B with(NOLOCK)
		on A.FIPS = B.FIPS 
		and A.PROPERTYID = B.PropertyID


		Update [zCust_ProperTI].[dbo].[A]
		Set 
		A.FAOwnershipRecDate = B.RecordingDt
		From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A join [data].[dbo].[Deed] as B with(NOLOCK)
		on A.FIPS = B.FIPS 
		and A.PROPERTYID = B.FAPropertyID
		and A.FAOwnershipTransID = B.TransactionId


		-------Ownership Deed---
		   Update [zCust_ProperTI].[dbo].[w_TransHist_FLANK] 
		   SET toUse = NULL
		   where toUse is not null

		 

			--UPDATE A
			--SET ToUse = 'Y' 
			----Select B.[INPUTKey], B.[INPUT Start Date], A.PropertyID,A.Doc_Id,DocumentTypeDesc--, C.*
			--FROM [dbo].w_TransHist_FLANK a JOIN x_Custom_OUTPUT_S20 as B on 
			--A.RAW_ID = B.[INPUT Key]  
			--where Doc_Src_Ind like 'D'
		
			UPDATE [zCust_ProperTI].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[INPUT Key], B.[Start Date],B.[MAX_DEEDDATE], A.PropertyID,A.Doc_Id,DocumentTypeDesc--, C.*
			FROM [zCust_ProperTI].[dbo].[w_TransHist_FLANK] a JOIN [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as B on 
			A.RAW_ID = B.[INPUT Key]  
			where Doc_Src_Ind like 'D'
			-----ADDED 20250516----
			AND 
			A.RecordingDate > convert(Date,B.[Start Date])
			AND 
			(A.RecordingDate > convert(Date,B.[MAX_DEEDDATE])
			or B.[MAX_DEEDDATE] is null
			)


			

		

	Truncate table [dbo].w_TransHist_FLANK_II

	INSERT INTO [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate,[PROPERTYID]--,REO,REOSALE
				   )
SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate ,[PROPERTYID]--,REO,REOSALE
FROM     [zCust_ProperTI].[dbo].[w_TransHist_FLANK]
WHERE  (ToUse = 'Y')


			UPDATE [zCust_ProperTI].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC, Documentnbr desc) AS RowNum
				FROM 
			[zCust_ProperTI].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II]
		--where PROPERTYID like '38080973'
		Order by RAW_ID, RecordingDate
		

		Select * From [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_ProperTI].[dbo].[A]
		Set 
		A.[Recording Date] = B.RecordingDate
		,A.[Document Type] = B.DocumentType
		--,A.[Document #] = case when ISNULL(B.FA_YearDocNbrFmt,'') like '' then B.FA_BookPageFmt else B.FA_YearDocNbrFmt end
		----Select B.DocumentType 
		,A.[Document #] = --20250516 -Changed --
		case 
		when ISNULL(B.FA_YearDocNbrFmt,'') not like '' then B.FA_YearDocNbrFmt
		when ISNULL(B.FA_YearDocNbrFmt,'')  like '' and ISNULL(B.FA_BookPageFmt,'') not like '' then FA_BookPageFmt
		ELSE  DocumentNbr END
		,A.CMTID = B.[CMTID]
		--Select A.CMTID , B.[CMTID]
		From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A join [zCust_ProperTI].[dbo].[w_TransHist_FLANK_II] as B with(NOLOCK)
		on A.[INPUT Key] = B.RAW_ID
		WHERE B.RecordNumber = 1


		--Update A
		--Set 
		--A.[Recording Date] = B.CurrSaleRecordingDate
		--,A.[Document Type] = B.CurrSaleDocumentType
		--,A.[Document #] = case when ISNULL(B.CurrSaleFormatDocNbr,'') like '' then B.CurrSaleFormatBook + '.' + B.CurrSaleFormatPage
		--else B.CurrSaleFormatDocNbr end

		--From x_Custom_OUTPUT_S20 as A join data.dbo.Property as B with(NOLOCK)
		--on A.FIPS = B.FIPS 
		--and A.PROPERTYID = B.PropertyID
		--WHERE ISNULL(B.CurrentSaleTransactionID,'') not like ''

		



	
		--Update A
		--Set 
		--A.[Recording Date] = C.RecordingDt
		--,A.[Document Type] = C.DocumentTypeCode
		--,A.[Document #] = case when ISNULL(C.YearDocNbrFrmt,'') like '' then C.BkPgFrmt
		--else C.YearDocNbrFrmt end

		--From x_Custom_OUTPUT_S20 as A join data.dbo.Property as B with(NOLOCK)
		--on A.FIPS = B.FIPS 
		--and A.PROPERTYID = B.PropertyID
		--join data.dbo.Deed as C with(NOLOCK) on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
		--AND B.FAOwnerTransactionId = C.TransactionID
		--AND ISNULL(B.FAOwnerTransactionId,'') not like ''
		--AND (C.RecordingDt > A.[Recording Date] or isnull(A.[Recording Date],'') like '')

	
		Update [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		set [Recording Date] = convert(date,[Recording Date])
		where [Recording Date] is not null and [Recording Date] not like ''

		--Select [Recording Date] from x_Custom_OUTPUT_S20

		Update [zCust_ProperTI].[dbo].[A]
		Set A.[Document Type] = B.CodeDesc
		From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A
		join [global].[dbo].[lkup_Doc_Type] as B on 
		A.[Document Type] = B.DocTypeID

		Select [Document Type], count(*) From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Document Type]
		ORder by [Document Type]

		----------------------

		Update [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_ProperTI].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] a JOIN [zCust_ProperTI].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID

		Update [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_ProperTI].[dbo].[a] SET [Property Status] = 'Multiple ProperTI_PRODes Found' 
		FROM [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] a join [zCust_ProperTI].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

		
		------------------20240321 - Per NH - USE INPUT START DATE & IF NO DEEDS _ USE FALASTREFRESHDATE ("The date that the new Assessor data is brought into the db.
		------Certification date could be months before we load and make it available to customers."

		-----20250529 - Changed per Nicole
		----	Requested Change:
		----•	Day 1 logic will NOT compare a NULL Owner Name to the Assessor Owner Name because that is not a valid comparison.
		----•	The record will not be returned if the only change is based on Owner Name comparison. 
		----•	Only return the record if there is a deed after the Start Date.


		--Update  A
		--Set A.[Transaction Status] = 
		--case when ISNULL([Current Owner],'') <> ISNULL(TRACKED_OWNERNAME,'') 
		--AND
		--convert(date,B.MAXDATE)   > convert(date,[Start Date])
		--then 'Event Found'
		--else 'Event Not Found' end
		
		----Select A.[INPUT Key], A.[Start Date], B.MAXDATE,[Current Owner],TRACKED_OWNERNAME
		----,	case when ISNULL([Current Owner],'') <> ISNULL(TRACKED_OWNERNAME,'') 
		----AND
		----convert(date,B.MAXDATE)   > convert(date,[Start Date])
		----then 'Event Found'
		----else 'Event Not Found' end
		--From x_Custom_OUTPUT_S20 as A join 
		--(
		--	Select [INPUT Key], MAX(MAXDATE) as MAXDATE from 
		--		(Select   [INPUT Key], max([CurrSaleRecordingDt]) as MAXDATE 
		--		From x_Custom_OUTPUT_S20 with(NOLOCK)
		--		Group by [INPUT Key]

		--		UNION ALL 

		--		Select   [INPUT Key], max(FALastRefreshDate) as MAXDATE 
		--		From x_Custom_OUTPUT_S20 with(NOLOCK)
		--		Group by [INPUT Key]

		--		UNION ALL 

		--		Select   [INPUT Key], max([FAOwnershipRecDate]) as MAXDATE 
		--		From x_Custom_OUTPUT_S20 with(NOLOCK)
		--		Group by [INPUT Key])A
		--	Group by [INPUT Key]
		--)B on A.[INPUT Key] = B.[INPUT Key]
	


		
		Update  [zCust_ProperTI].[dbo].[A]
		Set A.[Transaction Status] = 
		case when (ISNULL(A.[Current Owner],'') <> ISNULL(A.TRACKED_OWNERNAME,'') 
		AND convert(date,getdate()) > convert(date,B.DATE_RECEIVED)  )
		OR ISNULL([Recording Date],'') not like ''
		then 'Event Found'
		else 'Event Not Found' end

		--Select * 
		From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20] as A 
		join [zCust_ProperTI].[dbo].[INPUT_MONITOR] as B on 
		A.[INPUT KEY] = B.INPUTKEY
		--where B.DATE_RECEIVED = convert(date,getdate())


		Select * From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]


		Select [Property Status], count(*) From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Address Standardization]

		Select [Transaction Status], count(*) From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Transaction Status]

		Select [Coverage Status], count(*) From [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		Group by [Coverage Status]

		Select * from [zCust_ProperTI].[dbo].[x_Custom_OUTPUT_S20]
		where [Property Status] like 'Property Not Found'


			IF (Select count(*)  from (
					
					Select PROPERTYID ,[Recording Date]	,[Document Type]	,[Document #]
					From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S20] with(NOLOCK)
					where ISNULL([Recording Date] ,'') not like ''
					and ISNULL([Document #],'') like '')A) > 0

			BEGIN

		
				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @body1 NVARCHAR(MAX)
				DECLARE @body2 NVARCHAR(MAX)
				DECLARE @body3 NVARCHAR(MAX)
				DECLARE @body4 NVARCHAR(MAX)
				DECLARE @importance NVARCHAR(MAX)
				DECLARE @xml NVARCHAR(MAX)
				DECLARE @xml2 NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Propert.TI S20 ***MISSING DOC NUMBER*** - ' + @Date 
				
				SET @body1 = '<html><body><H3>PROPER.TI S20 MISSING DOC NUM - ' + @Date + '</H3>
				<table border = 1> 
				<tr><th> PROPERTYID  </th> <th> Recording Date </th> <th> Document Type </th> <th> Document #     </th></tr>' 
				
			

				SET @xml = 
				CAST(( 
					Select PROPERTYID as 'td','', [Recording Date] as 'td','', [Document Type] as 'td','', [Document #]  'td',''
					from (
					
					Select PROPERTYID ,[Recording Date]	,[Document Type]	,[Document #]
					From [zCust_ProperTI].[dbo].[X_CUSTOM_OUTPUT_S20] with(NOLOCK)
					where ISNULL([Recording Date] ,'') not like ''
					and ISNULL([Document #],'') like '')A

				FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


				Set @body2 = @body1 + @XML +'</table></body></html> <BR/><BR/>
				'
				

				--Set @body4 = @body3 + @XML2 +'</table></body></html> <BR/><BR/>
				--' + @body2 + '</table></body></html> <BR/><BR/>
				--'

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body2 ,
				@body_format ='HTML',
				@recipients = 'klowe@firstam.com',
				--@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1,
				@importance = High
						;

		
			END

END





