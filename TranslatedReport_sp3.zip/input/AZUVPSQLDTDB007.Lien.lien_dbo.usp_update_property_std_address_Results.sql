/* Source: DWS-ETL01.DATATREE.LOCAL | Lien | lien_dbo.usp_update_property_std_address_Results | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

-- ==========================================================================================
-- Author:		Marie Pretorius
-- Create date: 2024-03-20
-- Description:	Insert Records into Lien.UR.PROPERTY_Std_Address that was matched against Pet
-- ============================================================================================
CREATE PROCEDURE [Lien].[lien_dbo].[usp_update_property_std_address_Results] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	12/6/21		Change translated Fips routine call to table value function call
paul	200220721   add commentss on zip in match logic
******************************************************************************************************************/
--
-- Situs match
--
EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_update_property_std_address_Results'
	,N'Started'

BEGIN TRANSACTION

--DECLARE @fileid INT
INSERT INTO [Lien].[UR].[PROPERTY_Std_Address] (
	[Property_id]
	,[Fips]
	,[Ref_id]
	,[Match_code]
	,[Apn]
	,[HouseNumber]
	,[Street_Number]
	,[Direction]
	,[Street_Name]
	,[Street_Type]
	,[Post_Direction]
	,[Unit_Type]
	,[Unit]
	,[City]
	,[STATE]
	,[Zip]
	,[Plus4]
	,[CRRT]
	,[CountyName]
	,[PMB]
	,[PMSA]
	,[MSA]
	,[ZipType]
	,[Urbanization]
	,[CongressionalDistrict]
	,[CountryCode]
	,[CityAbbreviation]
	,[AddressTypeCode]
	,[AddressTypeString]
	,[DPV_Count]
	,[DPV_Footnotes]
	,[CMRA]
	,[ELOT_Number]
	,[ELOT_Order]
	,[LACS]
	,[LACS_LinkIndicator]
	,[EWS_Flag]
	,[RBDI]
	,[SuiteLinkReturnCode]
	,[DeliveryPointCheckDigit]
	,[DeliveryPointCode]
	,[CensusBlock]
	,[CensusTract]
	,[PlaceCode]
	,[PlaceName]
	,[CBSACode]
	,[CBSALevel]
	,[CBSATitle]
	,[CBSADivisionCode]
	,[CBSADivisionLevel]
	,[CBSADivisionTitle]
	,[Latitude]
	,[Longitude]
	,[Verified]
	,[Geocoded]
	,[AddressMatchResults]
	,[GeoErrorCode]
	,[GeoStatusCode]
	,[AddressType]
	,[UpdateDate]
	,[m_create_date]
	)
OUTPUT NULL AS Doc_id
	,NULL AS Name_id
	,inserted.property_id AS property_id
	,NULL AS reference_id
	,inserted.m_create_date
	,'usp_update_property_std_address_Results' AS Process_name
INTO [lien].[ur].[document_transaction_log]
SELECT a.ID AS Property_id
	,coalesce(a.match_fips, a.Fips) AS fips
	,Nullif(ar.Ref_id, 0) AS ref_id
	,Nullif(a.Match_code, '') AS Match_code
	,b.Apn
	,b.HouseNumber
	,b.Street_Number
	,b.Direction
	,b.Street_Name
	,b.Street_Type
	,b.Post_Direction
	,b.Unit_Type
	,b.Unit
	,b.City
	,b.STATE
	,b.Zip
	,b.Plus4
	,b.CRRT
	,b.CountyName
	,b.PMB
	,b.PMSA
	,b.MSA
	,b.ZipType
	,b.Urbanization
	,b.CongressionalDistrict
	,b.CountryCode
	,b.CityAbbreviation
	,b.AddressTypeCode
	,b.AddressTypeString
	,b.DPV_Count
	,b.DPV_Footnotes
	,b.CMRA
	,b.ELOT_Number
	,b.ELOT_Order
	,b.LACS
	,b.LACS_LinkIndicator
	,b.EWS_Flag
	,b.RBDI
	,b.SuiteLinkReturnCode
	,b.DeliveryPointCheckDigit
	,b.DeliveryPointCode
	,b.CensusBlock
	,b.CensusTract
	,b.PlaceCode
	,b.PlaceName
	,b.CBSACode
	,b.CBSALevel
	,b.CBSATitle
	,b.CBSADivisionCode
	,b.CBSADivisionLevel
	,b.CBSADivisionTitle
	,b.Latitude
	,b.Longitude
	,b.Verified
	,b.Geocoded
	,b.AddressMatchResults
	,b.GeoErrorCode
	,b.GeoStatusCode
	,b.AddressType
	,getdate() AS UpdateDate
	,getdate() AS m_create_date
FROM [lien].[tmp].[Situs_Std_Address_Result] a WITH (
		NOLOCK
		,INDEX (idx_file_id_id)
		)
INNER JOIN [lien].[tmp].[Situs_Std_Address] b WITH (
		NOLOCK
		,INDEX (idx_file_id_id)
		) ON b.fileid = a.fileid
	AND b.id = a.id
LEFT JOIN [Lien].[UR].[PROPERTY_Std_Address] c WITH (
		NOLOCK
		,INDEX (ix_PropIDREfidMatchCode)
		) ON c.Property_id = a.id
OUTER APPLY (
	SELECT assrid
		,ref_id
		,fips
	FROM [assr].[dbo].[assr] ar WITH (
			NOLOCK
			,INDEX (IDX_Assr_Ref_ID)
			)
	WHERE ar.ref_id = a.ref_id
	) ar
WHERE a.fileid = @fileid
	AND c.Property_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 8
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

COMMIT

EXEC [Lien].[LEAP].[AddLeapLog] N'info'
	,N'usp_update_property_std_address_Results'
	,N'Ended'


