SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_StateBankIndia_CA].[dbo].[usp_300_Start_Output_StateBankofIndia_CA_S13]


AS
BEGIN
	
	SET NOCOUNT ON;

	------20240619 - Per EC - return all Deeds & Mortgages with recording date > their input start date

	----4.	Deed & Mortgages
	----a.	Per call 20250903
		----i.	DEEDS only!
		----ii.	Use Input Start Date?? – YES per customer !!!




		DROP TABLE [dbo].[x_custom_OUTPUT_S13]

		CREATE TABLE [dbo].[x_custom_OUTPUT_S13](
		    [FIPS] [varchar](5) NULL,
			--[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,
			
			[INPUT KEY][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Deed Coverage Status][varchar](250)NULL,
			[Deed Through Date][varchar](250)NULL,
			[Mortgage Coverage Status][varchar](250)NULL,
			[Mortgage Through Date][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
			[Input Start Date][varchar](250)NULL,
			--[INPUT Borrower Name1][varchar](250)NULL,
			--[INPUT Borrower Name2][varchar](250)NULL,
			[Nbr of Recordings][varchar](250)NULL,
			-----------------Internal---------
			[InputStartDate][varchar](250)NULL,
			[MAX_DEED_DATE][varchar](250)NULL
		) ON [PRIMARY]

		

		
		SET CONCAT_NULL_YIELDS_NULL OFF  

		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13](
		[INPUT KEY],
		[INPUT Address],
		[INPUT City],
		[INPUT State],
		[INPUT Zip],
		[InputStartDate],
		[Input Start Date],
		[MAX_DEED_DATE],
		FIPS,
		PROPERTYID)
	  
		Select 
		INPUTKEY,
		ADDRESS,
		CITY,
		STATE,
		ZIPCODE,
		convert(Date,[Start Date]),
		convert(Date,[Start Date]),
		convert(Date,MAX_DEED_RECDATE),
		FIPS,
		PROPERTYID
		From [zCust_StateBankIndia_CA].[dbo].[INPUT_MONITOR]


		Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		set [Report Date] = convert(date,GetDate())

	
		--UPDATE a 
		--SET 
		---- A.WORK_REF_ID = C.REF_ID
		-- --,
		-- A.PropertyID = case when A.PropertyID is null then C.PropertyID else A.PropertyID end  
		--,a.Fips = CASE WHEN A.FIPS is null then case when LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END else A.FIPS end
		--,a.[Report Date] = convert(date,GetDate())
		----Select * 
		--FROM x_custom_OUTPUT_S13 a JOIN [dbo].a_PropMatch_WORK_FLANK as c with(NOLOCK) on a.[INPUT Key] = c.RAW_ID


				
	
		Update [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		--Select C.*  
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT Key] = c.RAW_ID


	
		Update [zCust_StateBankIndia_CA].[dbo].[A]
		Set 
		A.[Deed Coverage Status] = B.DeedActive
		,A.[Deed Through Date] = B.DeedMaxRecordDate
		,A.[Mortgage Coverage Status] = B.SAMActive
		,A.[Mortgage Through Date] = B.SAMMaxRecordDate
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a JOIN 
		[Global].[dbo].[county] as B on A.FIPS = B.FIPSCODE


		


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] 
		SET [Mortgage Coverage Status] = CASE WHEN [Mortgage Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] 
		SET [Deed Coverage Status] = CASE WHEN [Deed Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END


		Update  [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a JOIN [zCust_StateBankIndia_CA].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Key] = b.Raw_ID



		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN 
		(PropertyID is  not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_StateBankIndia_CA].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a join [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT Key] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		EXEC [zCust_StateBankIndia_CA].[dbo].[usp_502_Pull_FLANK_DATA]
		

		Update [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK]
		set ToUse = NULL
		where ToUse is not null

		


		------Find Deeds  After INPUT START DATE & Max Deed Date----
		Update [zCust_StateBankIndia_CA].[dbo].[B]
		Set B.ToUse = 'Y'
		--Select  B.* 
		From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] as A join [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK] as B on A.[INPUT KEY] = B.RAW_ID
		where B.Doc_Src_Ind like 'D'
		and B.RecordingDate > A.[Input Start Date]
		AND (B.RecordingDate > A.MAX_DEED_DATE
		or A.MAX_DEED_DATE is null)


		

		
		INSERT INTO [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II]
		SELECT *
		FROM     [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK]
		WHERE  (ToUse LIKE 'Y')

		
		Update [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II]
		set RecordNumber = NULL

			UPDATE [zCust_StateBankIndia_CA].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC,  Doc_ID desc, DocumentNbr DESC) AS RowNum
				FROM 
			[zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID
			and t.DocumentNbr = R.DocumentNbr



		Select * From  [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null

		Select RAW_ID, RecordNumber, count(*) T From [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, RecordNumber
		having count(*) > 1


	
	
			
		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Set [Nbr of Recordings] = NULL
		where convert(int,[Nbr of Recordings]) > 0


		UPDATE [zCust_StateBankIndia_CA].[dbo].[a]
		SET a.[Nbr of Recordings] = case when convert(int,b.NbrOfRecordings) > 30 then '30' else b.NbrOfRecordings end
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a JOIN 
		(SELECT RAW_ID,MAX(convert(int,RecordNumber)) NbrOfRecordings FROM [zCust_StateBankIndia_CA].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) 
		b
		on a.[INPUT KEY] = b.RAW_ID

		Select max(convert(int,[Nbr of Recordings])) from [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]

		
		 
		---- ADD TRANSACTION FIELDS ACCORDING TO THE MAX NUMBER OF TRANSACTIONS THAT OCCUR

		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = MAX(convert(int,[Nbr of Recordings])) FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Record Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Document Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Doc Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Buyer 1 Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Buyer 2 Name_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Seller Name_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_custom_OUTPUT_S13 ADD [Title Company_' + @RecNbr + '] [varchar](250) NULL')



						EXEC('UPDATE a
						SET 
						A.[Record Number_' + @RecNbr + '] = ''' + @RecNbr + '''
						,A.[Recording Date_' + @RecNbr + '] = B.RecordingDate
						,A.[Document Number_' + @RecNbr + '] = B.DocumentNbr
						,A.[Amount_' + @RecNbr + '] = B.Value
						,A.[Doc Type_' + @RecNbr + '] = case when B.DocumentType is null and B.Doc_Src_Ind like ''M'' then ''Mortgage'' else B.DocumentType end
						,A.[Buyer 1 Name_' + @RecNbr + '] = B.BuyerBorrower1
						,A.[Buyer 2 Name_' + @RecNbr + '] = B.BuyerBorrower2
						,A.[Seller Name_' + @RecNbr + '] = B.SellerLender
						--,A.[Title Company_' + @RecNbr + '] = B.TITLECONAME

						
						--Select B.* 
						FROM x_custom_OUTPUT_S13 a JOIN w_TransHist_FLANK_II B 
						on a.[INPUT Key] = b.RAW_ID
						WHERE B.[RecordNumber] = ' + @BeginNbrOfTrans + '
						')

						EXEC('UPDATE a
						SET 
						A.[Doc Type_' + @RecNbr + '] = B.[CodeDesc]
						--Select B.*
						FROM x_custom_OUTPUT_S13 a JOIN Global.dbo.lkup_doc_Type B 
						on A.[Doc Type_' + @RecNbr + '] = b.DocTypeID
						WHERE A.[Record Number_' + @RecNbr + '] = ' + @BeginNbrOfTrans + '
						')

						
						


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END 


		Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Order by convert(int,[Nbr of Recordings])  desc


		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END

		
		UPDATE [zCust_StateBankIndia_CA].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] a join [zCust_StateBankIndia_CA].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT KEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


		
		Update [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13] 
		SET [Event Status] = CASE WHEN [Nbr of Recordings] > 0 THEN 'Event Found' ELSE 'Event Not Found' END


		Select [Mortgage Coverage Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Group by [Mortgage Coverage Status]

		Select [Deed Coverage Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Group by [Deed Coverage Status]


		Select [Address Standardization], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Group by [Address Standardization]

		Select [Property Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
		Group by [Event Status]

	

	  Select * From [zCust_StateBankIndia_CA].[dbo].[x_custom_OUTPUT_S13]
	  Order by convert(int,[Nbr of Recordings]) desc

	

			

END






