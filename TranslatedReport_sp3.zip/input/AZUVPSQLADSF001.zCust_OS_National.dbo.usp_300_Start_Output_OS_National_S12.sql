SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_300_Start_Output_OS_National_S12]

AS
BEGIN
	
	-----20231030 - Per Nicole:
	----Only REturn OPEN Mortgages Recorded after original lien
	----This is NOT an S12 / Open Lien - this is a NEW OPEN LIEN only
	-----Populate Mortgage Purpose using Loan Transaction Type

		DROP TABLE [dbo].[X_CUSTOM_OUTPUT_S12]

		CREATE TABLE [dbo].[X_CUSTOM_OUTPUT_S12](
			[INPUTKEY][varchar](250)NULL,
			
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			
			[INPUT_Customer ID][varchar](250)NULL,
			[INPUT_UniqueID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[INPUT_CURRENTOWNER][varchar](250)NULL,

			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
			[START DATE][varchar](250)NULL,
			[# of Liens][varchar](250)NULL,
			
			------INTERNAL------
			
			[MAX_MTGDATE][varchar](250)NULL,
			[MTG1TRANSACTIONID][varchar](250)NULL,
			[MTG2TRANSACTIONID][varchar](250)NULL,
			[MTG3TRANSACTIONID][varchar](250)NULL,
			[MTG4TRANSACTIONID][varchar](250)NULL
		) ON [PRIMARY]

		



		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] (
		INPUTKEY,
		FIPS,
		PROPERTYID,
		[START DATE],
		[INPUT_Customer ID],
		[INPUT_UniqueID],
		[INPUT_ADDRESS],
		[INPUT_CITY],
		[INPUT_STATE],
		[INPUT_ZIPCODE],
		[MAX_MTGDATE],
		[INPUT_CURRENTOWNER])

		Select 	
		INPUTKEY,FIPS, PROPERTYID,
		convert(date,[START DATE]),
		CustomerID,
		[UniqueId],
		[Address],
		[City],
		[State],
		[ZipCODE],
		[MAX_MTGDATE],
		[INPUT_OWNER]
		--Select * 
	   
		FROM [zCust_OS_National].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and INPUTKEY is not null



			
		------********ONLY RUN FULL PORTFOLIO on 5th of month or next bus day****-------
		DECLARE @TODAY date = convert(date,getdate())
		DECLARE @5th date = (Select top 1  [CalendarDate] FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc) 

		Print @TODAY
		Print @5th
		
		IF @TODAY <> @5th
		BEGIN
		
		Delete from [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		--Select B.*
		From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as A join [zCust_OS_National].[dbo].[INPUT_MONITOR] as B on 
		A.INPUTKEY = B.INPUTKEY
		where B.DATE_RECEIVED < convert(Date,getdate())



		END

	

		
		--UPdate INPUT_MONITOR
		--set MAX_MTGDATE = NULL
		
		Select count(*) From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]

	
		Select top 100 * From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]

	

		--UPDATE a 
		--SET a.PROPERTYID = c.PROPERTYID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM X_CUSTOM_OUTPUT_S12 a JOIN 
		--[dbo].a_PropMatch_Work_FLANK c on a.[INPUTKEY] = c.RAW_ID


		Update [zCust_OS_National].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN 
		[zCust_OS_National].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKEY] = c.RAW_ID

			-----

		Update [zCust_OS_National].[dbo].[a]
		set [Coverage Status] = B.SAMActive
		--,A.[Mortgage Start Date] = case when ISNULL(B.SamMinRecordDate,'') like '' then NULL else convert(date,B.SamMinRecordDate) end
		--,A.[Coverage Status] = case when ISNULL(B.SamMaxRecordDate,'') like '' then NULL else convert(date,B.SamMaxRecordDate) end 
		--Select D_Flag 
		FROM [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE


		Update [zCust_OS_National].[dbo].[A]
		Set
		A.MTG1TRANSACTIONID = B.Mtg1TransactionId
		,A.MTG2TRANSACTIONID = B.Mtg2TransactionId
		,A.MTG3TRANSACTIONID = B.Mtg3TransactionId
		,A.MTG4TRANSACTIONID = B.Mtg4TransactionId
		From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as A 
		join [data].[dbo].[Property] as B With(NOLOCK) on 
		A.FIPS = B.FIPS
		and A.PROPERTYID = B.PropertyID



		Update [zCust_OS_National].[dbo].[w_TransHist_FLANK]
		Set ToUse = NULL
		where ToUse is not null

		Truncate table [dbo].w_TransHist_FLANK_II

		--Select top 10 * From w_TransHist_FLANK
	

		------20231211 - Per EC - They may not alway have an input start date.  If they DON'T - use the CurrSaleRecordingDt.
		-----If we dont have CurrSaleRecDate - return any open mortgages in the 1-4 positions
		
		INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]([Fips],
			[REF_ID],
			[RecordNumber],
			[RecordingDate],
			[DocumentType],
			[DocumentNbr],
			[BookSrce],
			[PageSrce],
			[BuyerBorrower],
			[SellerLender],
			[Value],
			[OrigTransRecDate],
			[OrigTransDocNumber],
			[OrigLoanFAYearFmtDocNumber],
			[OrigLoanAmount],
			[Lien_Pos],
			[CmtId],
			[Source_Type],
			[Doc_Id],
			[Doc_Src_Ind],
			[OrigDoc_Id],
			[DocumentTypeDesc],
			[TransType],
			[ToUse],
			[RAW_ID],
			[ChronoKey],
			[NewLenderAssignee],
			[OldLenderAssignor],
			[FA_DocNbrFmt],
			[FA_YearDocNbrFmt],
			[FA_YearDayDocNumFmt],
			[FA_BookPageFmt],
			[FA_YearBookPageFmt],
			[FA_CMTID_DocNum],
			[FA_CMTID_YearDocNum],
			[FA_CMTID_YearDateDocNum],
			[FA_CMTID_BookPage],
			[FA_CMTID_YearBookPage],
			[DocDate],
			[BuyerBorrowerFirstNameMI],
			[BuyerBorrowerLastNameMI],
			[LOANTYPE],
			[BuyerBorrower1],
			[BuyerBorrower2],
			[BuyerBorrower3],
			[BuyerBorrower4],
			[PURCHASE],
			[RateType],
			[Rate],
			[OrigTransBookPage],
			[ARMSLENGTH],
			[PROPERTYID],
			[LOANTERM],
			[REO],
			[REOSALE])
					SELECT A.[Fips],
			A.[REF_ID],
			A.[RecordNumber],
			A.[RecordingDate],
			A.[DocumentType],
			A.[DocumentNbr],
			A.[BookSrce],
			A.[PageSrce],
			A.[BuyerBorrower],
			A.[SellerLender],
			A.[Value],
			A.[OrigTransRecDate],
			A.[OrigTransDocNumber],
			A.[OrigLoanFAYearFmtDocNumber],
			A.[OrigLoanAmount],
			'1',
			A.[CmtId],
			A.[Source_Type],
			A.[Doc_Id],
			A.[Doc_Src_Ind],
			A.[OrigDoc_Id],
			A.[DocumentTypeDesc],
			A.[TransType],
			A.[ToUse],
			A.[RAW_ID],
			A.[ChronoKey],
			A.[NewLenderAssignee],
			A.[OldLenderAssignor],
			A.[FA_DocNbrFmt],
			A.[FA_YearDocNbrFmt],
			A.[FA_YearDayDocNumFmt],
			A.[FA_BookPageFmt],
			A.[FA_YearBookPageFmt],
			A.[FA_CMTID_DocNum],
			A.[FA_CMTID_YearDocNum],
			A.[FA_CMTID_YearDateDocNum],
			A.[FA_CMTID_BookPage],
			A.[FA_CMTID_YearBookPage],
			A.[DocDate],
			A.[BuyerBorrowerFirstNameMI],
			A.[BuyerBorrowerLastNameMI],
			A.[LOANTYPE],
			A.[BuyerBorrower1],
			A.[BuyerBorrower2],
			A.[BuyerBorrower3],
			A.[BuyerBorrower4],
			A.[PURCHASE],
			A.[RateType],
			A.[Rate],
			A.[OrigTransBookPage],
			A.[ARMSLENGTH],
			A.[PROPERTYID],
			A.[LOANTERM],
			A.[REO],
			A.[REOSALE]

		--Update A
		--Set
		--A.ToUse = 'Y'
		--,A.Lien_Pos = '1'
		--Select A.RAW_ID, B.[START DATE], B.MAX_MTGDATE, A.RecordingDate, A.DocDate
		From [zCust_OS_National].[dbo].[w_TransHist_FLANK] as A 
		join [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.Doc_Id = B.MTG1TRANSACTIONID
		join [data].[dbo].[Property] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PROPERTYID = C.PropertyID
		where A.Doc_Src_Ind like 'M'
		and 
		(
			(convert(date,A.RecordingDate) > case 
			when B.[START DATE] is NOT null then convert(date,B.[START DATE])
			when B.[START DATE] is  null and ISNULL(C.CurrSaleRecordingDate,'') not like ''  then convert(date,C.CurrSaleRecordingDate)
			else convert(date,'1990-01-01')END

			AND (A.RecordingDate > B.MAX_MTGDATE
			or ISNULL(B.MAX_MTGDATE,'') like ''))
		OR
		(A.DocDate > B.[START DATE]
		AND (A.DocDate > B.MAX_MTGDATE
		or ISNULL(B.MAX_MTGDATE,'') like ''))
		)

		
	INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]([Fips],
			[REF_ID],
			[RecordNumber],
			[RecordingDate],
			[DocumentType],
			[DocumentNbr],
			[BookSrce],
			[PageSrce],
			[BuyerBorrower],
			[SellerLender],
			[Value],
			[OrigTransRecDate],
			[OrigTransDocNumber],
			[OrigLoanFAYearFmtDocNumber],
			[OrigLoanAmount],
			[Lien_Pos],
			[CmtId],
			[Source_Type],
			[Doc_Id],
			[Doc_Src_Ind],
			[OrigDoc_Id],
			[DocumentTypeDesc],
			[TransType],
			[ToUse],
			[RAW_ID],
			[ChronoKey],
			[NewLenderAssignee],
			[OldLenderAssignor],
			[FA_DocNbrFmt],
			[FA_YearDocNbrFmt],
			[FA_YearDayDocNumFmt],
			[FA_BookPageFmt],
			[FA_YearBookPageFmt],
			[FA_CMTID_DocNum],
			[FA_CMTID_YearDocNum],
			[FA_CMTID_YearDateDocNum],
			[FA_CMTID_BookPage],
			[FA_CMTID_YearBookPage],
			[DocDate],
			[BuyerBorrowerFirstNameMI],
			[BuyerBorrowerLastNameMI],
			[LOANTYPE],
			[BuyerBorrower1],
			[BuyerBorrower2],
			[BuyerBorrower3],
			[BuyerBorrower4],
			[PURCHASE],
			[RateType],
			[Rate],
			[OrigTransBookPage],
			[ARMSLENGTH],
			[PROPERTYID],
			[LOANTERM],
			[REO],
			[REOSALE])
					SELECT A.[Fips],
			A.[REF_ID],
			A.[RecordNumber],
			A.[RecordingDate],
			A.[DocumentType],
			A.[DocumentNbr],
			A.[BookSrce],
			A.[PageSrce],
			A.[BuyerBorrower],
			A.[SellerLender],
			A.[Value],
			A.[OrigTransRecDate],
			A.[OrigTransDocNumber],
			A.[OrigLoanFAYearFmtDocNumber],
			A.[OrigLoanAmount],
			'2',
			A.[CmtId],
			A.[Source_Type],
			A.[Doc_Id],
			A.[Doc_Src_Ind],
			A.[OrigDoc_Id],
			A.[DocumentTypeDesc],
			A.[TransType],
			A.[ToUse],
			A.[RAW_ID],
			A.[ChronoKey],
			A.[NewLenderAssignee],
			A.[OldLenderAssignor],
			A.[FA_DocNbrFmt],
			A.[FA_YearDocNbrFmt],
			A.[FA_YearDayDocNumFmt],
			A.[FA_BookPageFmt],
			A.[FA_YearBookPageFmt],
			A.[FA_CMTID_DocNum],
			A.[FA_CMTID_YearDocNum],
			A.[FA_CMTID_YearDateDocNum],
			A.[FA_CMTID_BookPage],
			A.[FA_CMTID_YearBookPage],
			A.[DocDate],
			A.[BuyerBorrowerFirstNameMI],
			A.[BuyerBorrowerLastNameMI],
			A.[LOANTYPE],
			A.[BuyerBorrower1],
			A.[BuyerBorrower2],
			A.[BuyerBorrower3],
			A.[BuyerBorrower4],
			A.[PURCHASE],
			A.[RateType],
			A.[Rate],
			A.[OrigTransBookPage],
			A.[ARMSLENGTH],
			A.[PROPERTYID],
			A.[LOANTERM],
			A.[REO],
			A.[REOSALE]
		--Update A
		--Set
		--A.ToUse = 'Y'
		--,A.Lien_Pos = '2'
		----Select A.RAW_ID, B.[START DATE], B.MAX_MTGDATE, A.RecordingDate, A.DocDate
		From [zCust_OS_National].[dbo].[w_TransHist_FLANK] as A 
		join [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.Doc_Id = B.MTG2TRANSACTIONID
		join [data].[dbo].[Property] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PROPERTYID = C.PropertyID
		where A.Doc_Src_Ind like 'M'
		and 
		(
			(convert(date,A.RecordingDate) > case 
			when B.[START DATE] is NOT null then convert(date,B.[START DATE])
			when B.[START DATE] is  null and ISNULL(C.CurrSaleRecordingDate,'') not like ''  then convert(date,C.CurrSaleRecordingDate)
			else convert(date,'1990-01-01')END

			AND (A.RecordingDate > B.MAX_MTGDATE
			or ISNULL(B.MAX_MTGDATE,'') like ''))
		OR
		(A.DocDate > B.[START DATE]
		AND (A.DocDate > B.MAX_MTGDATE
		or ISNULL(B.MAX_MTGDATE,'') like ''))
		)

		
			INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]([Fips],
			[REF_ID],
			[RecordNumber],
			[RecordingDate],
			[DocumentType],
			[DocumentNbr],
			[BookSrce],
			[PageSrce],
			[BuyerBorrower],
			[SellerLender],
			[Value],
			[OrigTransRecDate],
			[OrigTransDocNumber],
			[OrigLoanFAYearFmtDocNumber],
			[OrigLoanAmount],
			[Lien_Pos],
			[CmtId],
			[Source_Type],
			[Doc_Id],
			[Doc_Src_Ind],
			[OrigDoc_Id],
			[DocumentTypeDesc],
			[TransType],
			[ToUse],
			[RAW_ID],
			[ChronoKey],
			[NewLenderAssignee],
			[OldLenderAssignor],
			[FA_DocNbrFmt],
			[FA_YearDocNbrFmt],
			[FA_YearDayDocNumFmt],
			[FA_BookPageFmt],
			[FA_YearBookPageFmt],
			[FA_CMTID_DocNum],
			[FA_CMTID_YearDocNum],
			[FA_CMTID_YearDateDocNum],
			[FA_CMTID_BookPage],
			[FA_CMTID_YearBookPage],
			[DocDate],
			[BuyerBorrowerFirstNameMI],
			[BuyerBorrowerLastNameMI],
			[LOANTYPE],
			[BuyerBorrower1],
			[BuyerBorrower2],
			[BuyerBorrower3],
			[BuyerBorrower4],
			[PURCHASE],
			[RateType],
			[Rate],
			[OrigTransBookPage],
			[ARMSLENGTH],
			[PROPERTYID],
			[LOANTERM],
			[REO],
			[REOSALE])
					SELECT A.[Fips],
			A.[REF_ID],
			A.[RecordNumber],
			A.[RecordingDate],
			A.[DocumentType],
			A.[DocumentNbr],
			A.[BookSrce],
			A.[PageSrce],
			A.[BuyerBorrower],
			A.[SellerLender],
			A.[Value],
			A.[OrigTransRecDate],
			A.[OrigTransDocNumber],
			A.[OrigLoanFAYearFmtDocNumber],
			A.[OrigLoanAmount],
			'3',
			A.[CmtId],
			A.[Source_Type],
			A.[Doc_Id],
			A.[Doc_Src_Ind],
			A.[OrigDoc_Id],
			A.[DocumentTypeDesc],
			A.[TransType],
			A.[ToUse],
			A.[RAW_ID],
			A.[ChronoKey],
			A.[NewLenderAssignee],
			A.[OldLenderAssignor],
			A.[FA_DocNbrFmt],
			A.[FA_YearDocNbrFmt],
			A.[FA_YearDayDocNumFmt],
			A.[FA_BookPageFmt],
			A.[FA_YearBookPageFmt],
			A.[FA_CMTID_DocNum],
			A.[FA_CMTID_YearDocNum],
			A.[FA_CMTID_YearDateDocNum],
			A.[FA_CMTID_BookPage],
			A.[FA_CMTID_YearBookPage],
			A.[DocDate],
			A.[BuyerBorrowerFirstNameMI],
			A.[BuyerBorrowerLastNameMI],
			A.[LOANTYPE],
			A.[BuyerBorrower1],
			A.[BuyerBorrower2],
			A.[BuyerBorrower3],
			A.[BuyerBorrower4],
			A.[PURCHASE],
			A.[RateType],
			A.[Rate],
			A.[OrigTransBookPage],
			A.[ARMSLENGTH],
			A.[PROPERTYID],
			A.[LOANTERM],
			A.[REO],
			A.[REOSALE]
		--Update A
		--Set
		--A.ToUse = 'Y'
		--,A.Lien_Pos = '3'
		----Select A.RAW_ID, B.[START DATE], B.MAX_MTGDATE, A.RecordingDate, A.DocDate
		From [zCust_OS_National].[dbo].[w_TransHist_FLANK] as A 
		join [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.Doc_Id = B.MTG3TRANSACTIONID
		join [data].[dbo].[Property] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PROPERTYID = C.PropertyID
		where A.Doc_Src_Ind like 'M'
		and 
		(
			(convert(date,A.RecordingDate) > case 
			when B.[START DATE] is NOT null then convert(date,B.[START DATE])
			when B.[START DATE] is  null and ISNULL(C.CurrSaleRecordingDate,'') not like ''  then convert(date,C.CurrSaleRecordingDate)
			else convert(date,'1990-01-01')END

			AND (A.RecordingDate > B.MAX_MTGDATE
			or ISNULL(B.MAX_MTGDATE,'') like ''))
		OR
		(A.DocDate > B.[START DATE]
		AND (A.DocDate > B.MAX_MTGDATE
		or ISNULL(B.MAX_MTGDATE,'') like ''))
		)


			INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]([Fips],
			[REF_ID],
			[RecordNumber],
			[RecordingDate],
			[DocumentType],
			[DocumentNbr],
			[BookSrce],
			[PageSrce],
			[BuyerBorrower],
			[SellerLender],
			[Value],
			[OrigTransRecDate],
			[OrigTransDocNumber],
			[OrigLoanFAYearFmtDocNumber],
			[OrigLoanAmount],
			[Lien_Pos],
			[CmtId],
			[Source_Type],
			[Doc_Id],
			[Doc_Src_Ind],
			[OrigDoc_Id],
			[DocumentTypeDesc],
			[TransType],
			[ToUse],
			[RAW_ID],
			[ChronoKey],
			[NewLenderAssignee],
			[OldLenderAssignor],
			[FA_DocNbrFmt],
			[FA_YearDocNbrFmt],
			[FA_YearDayDocNumFmt],
			[FA_BookPageFmt],
			[FA_YearBookPageFmt],
			[FA_CMTID_DocNum],
			[FA_CMTID_YearDocNum],
			[FA_CMTID_YearDateDocNum],
			[FA_CMTID_BookPage],
			[FA_CMTID_YearBookPage],
			[DocDate],
			[BuyerBorrowerFirstNameMI],
			[BuyerBorrowerLastNameMI],
			[LOANTYPE],
			[BuyerBorrower1],
			[BuyerBorrower2],
			[BuyerBorrower3],
			[BuyerBorrower4],
			[PURCHASE],
			[RateType],
			[Rate],
			[OrigTransBookPage],
			[ARMSLENGTH],
			[PROPERTYID],
			[LOANTERM],
			[REO],
			[REOSALE])
					SELECT A.[Fips],
			A.[REF_ID],
			A.[RecordNumber],
			A.[RecordingDate],
			A.[DocumentType],
			A.[DocumentNbr],
			A.[BookSrce],
			A.[PageSrce],
			A.[BuyerBorrower],
			A.[SellerLender],
			A.[Value],
			A.[OrigTransRecDate],
			A.[OrigTransDocNumber],
			A.[OrigLoanFAYearFmtDocNumber],
			A.[OrigLoanAmount],
			'4',
			A.[CmtId],
			A.[Source_Type],
			A.[Doc_Id],
			A.[Doc_Src_Ind],
			A.[OrigDoc_Id],
			A.[DocumentTypeDesc],
			A.[TransType],
			A.[ToUse],
			A.[RAW_ID],
			A.[ChronoKey],
			A.[NewLenderAssignee],
			A.[OldLenderAssignor],
			A.[FA_DocNbrFmt],
			A.[FA_YearDocNbrFmt],
			A.[FA_YearDayDocNumFmt],
			A.[FA_BookPageFmt],
			A.[FA_YearBookPageFmt],
			A.[FA_CMTID_DocNum],
			A.[FA_CMTID_YearDocNum],
			A.[FA_CMTID_YearDateDocNum],
			A.[FA_CMTID_BookPage],
			A.[FA_CMTID_YearBookPage],
			A.[DocDate],
			A.[BuyerBorrowerFirstNameMI],
			A.[BuyerBorrowerLastNameMI],
			A.[LOANTYPE],
			A.[BuyerBorrower1],
			A.[BuyerBorrower2],
			A.[BuyerBorrower3],
			A.[BuyerBorrower4],
			A.[PURCHASE],
			A.[RateType],
			A.[Rate],
			A.[OrigTransBookPage],
			A.[ARMSLENGTH],
			A.[PROPERTYID],
			A.[LOANTERM],
			A.[REO],
			A.[REOSALE]
		--Update A
		--Set
		--A.ToUse = 'Y'
		--,A.Lien_Pos = '4'
		----Select A.RAW_ID, B.[START DATE], B.MAX_MTGDATE, A.RecordingDate, A.DocDate
		From [zCust_OS_National].[dbo].[w_TransHist_FLANK] as A 
		join [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as B on 
		A.RAW_ID = B.INPUTKEY
		and A.Doc_Id = B.MTG4TRANSACTIONID
		join [data].[dbo].[Property] as C with(NOLOCK) on B.FIPS = C.FIPS and B.PROPERTYID = C.PropertyID
		where A.Doc_Src_Ind like 'M'
		and 
		(
			(convert(date,A.RecordingDate) > case 
			when B.[START DATE] is NOT null then convert(date,B.[START DATE])
			when B.[START DATE] is  null and ISNULL(C.CurrSaleRecordingDate,'') not like ''  then convert(date,C.CurrSaleRecordingDate)
			else convert(date,'1990-01-01')END

			AND (A.RecordingDate > B.MAX_MTGDATE
			or ISNULL(B.MAX_MTGDATE,'') like ''))
		OR
		(A.DocDate > B.[START DATE]
		AND (A.DocDate > B.MAX_MTGDATE
		or ISNULL(B.MAX_MTGDATE,'') like ''))
		)

		----TESTING---
		--Select INPUTKEY,PROPERTYID, FIPS, [START DATE], MTG1TRANSACTIONID, * From X_CUSTOM_OUTPUT_S12
		--where INPUTKEY in ('IH_600261-1')

		--Select FIPS, PropertyID, FAUCIDFlag, Mtg1TransactionId,Mtg2TransactionId,Mtg1RecordingDt,CurrSaleRecordingDate From data.dbo.Property with(NOLOCK)
		--where PropertyID in (97858814)
		--Order by PropertyID

		--Select FIPS, FAPropertyId, TransactionId, FAUCIDFlag, FATimestamp From data.dbo.Mortgage with(NOLOCK)
		--where Transactionid in (21140222786)
		--Order by FAPropertyId


		--Select * From w_TransHist_FLANK
		--where RAW_ID in ('IH_600261-1')
		--and Doc_Src_Ind like 'M'
		--and Doc_Id in (21140222786)


		--Select A.RAW_ID, B.[START DATE], C.CurrSaleRecordingDate, A.RecordingDate 
		--From w_TransHist_FLANK as A 
		--join X_CUSTOM_OUTPUT_S12 as B on 
		--A.RAW_ID = B.INPUTKEY
		--and A.Doc_Id = B.MTG4TRANSACTIONID
		--join data.dbo.Property as C with(NOLOCK) on B.FIPS = C.FIPS and B.PROPERTYID = C.PropertyID
		--where A.Doc_Src_Ind like 'M'
		--and  RAW_ID in ('IH_600261-1')
		--and 
		--(
		--	(convert(date,A.RecordingDate) > case 
		--	when B.[START DATE] is NOT null then convert(date,B.[START DATE])
		--	when B.[START DATE] is  null and ISNULL(C.CurrSaleRecordingDate,'') not like ''  then convert(date,C.CurrSaleRecordingDate)
		--	else convert(date,'1990-01-01')END

		--	AND (A.RecordingDate > B.MAX_MTGDATE
		--	or ISNULL(B.MAX_MTGDATE,'') like ''))
		--OR
		--(A.DocDate > B.[START DATE]
		--AND (A.DocDate > B.MAX_MTGDATE
		--or ISNULL(B.MAX_MTGDATE,'') like ''))
		--)
	
		

		--Truncate table [dbo].w_TransHist_FLANK_II

		--INSERT INTO w_TransHist_FLANK_II
		--SELECT *
		--FROM     w_TransHist_FLANK
		--WHERE  (ToUse = 'Y')


		--Select * From w_TransHist_FLANK
		--where RAW_ID in  ('IH_600261-1')



		Update [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		SET RecordNumber = Lien_Pos


		

			--UPDATE t SET RecordNumber = RowNum
			--FROM [dbo].w_TransHist_FLANK_II t LEFT JOIN
			--(SELECT * 
			--	,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC) AS RowNum
			--	FROM 
			--[dbo].w_TransHist_FLANK_II t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			--AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		Order by RAW_ID, RecordingDate

		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S12]
		Set [# of Liens] = NULL

		UPDATE [zCust_OS_National].[dbo].[a]
		SET a.[# of Liens] = b.NbrOfRecordings
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S12] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings 
		FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) b
		on a.[INPUTKEY] = b.RAW_ID

		Select max(convert(int,[# of Liens])) from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S12]


		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = case when max(convert(int,[# of Liens])) is null then 1 else  
		max(convert(int,[# of Liens])) end FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S12]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Record Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [DOCID_' + @RecNbr + '] [varchar](250) NULL')

					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Lien Position_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Borrower Name 1_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Borrower Name 2_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Borrower Name 3_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Borrower Name 4_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Mortgage Purpose_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Lender_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Mortgage Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Mortgage Amount_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Doc Number_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Loan Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Interest Rate_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Rate Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S12 ADD [Mortgage Term_' + @RecNbr + '] [varchar](250) NULL')



				
					EXEC('UPDATE a
					SET 
					A.[Record Nbr_' + @RecNbr + '] = b.RecordNumber
					,A.[DOCID_' + @RecNbr + '] = b.DOC_ID
					,A.[Lien Position_' + @RecNbr + '] = B.REcordNumber
					,A.[Borrower Name 1_' + @RecNbr + '] = b.BuyerBorrower1
					,A.[Borrower Name 2_' + @RecNbr + '] = b.BuyerBorrower2
					,A.[Borrower Name 3_' + @RecNbr + '] = b.BuyerBorrower3
					,A.[Borrower Name 4_' + @RecNbr + '] = b.BuyerBorrower4
					,A.[Mortgage Purpose_' + @RecNbr + '] = b.TransType
					,A.[Lender_' + @RecNbr + '] = b.SellerLender
					,A.[Mortgage Date_' + @RecNbr + '] = b.DocDate
					,A.[Recording Date_' + @RecNbr + '] = b.RecordingDate
					,A.[Mortgage Amount_' + @RecNbr + '] = b.Value
					,A.[Doc Number_' + @RecNbr + '] = case when ISNULL(B.FA_YearDocNbrFmt,'''') like '''' then B.FA_BookPageFmt
							else B.FA_YearDocNbrFmt end
					,A.[Loan Type_' + @RecNbr + '] = b.LOANTYPE
					,A.[Interest Rate_' + @RecNbr + '] = b.RATE
					,A.[Rate Type_' + @RecNbr + '] = b.RATETYPE
					,A.[Mortgage Term_' + @RecNbr + '] = b.LOANTERM

				
					--Select b.TransType
					FROM x_Custom_OUTPUT_S12 a JOIN 
					w_TransHist_FLANK_II as B on 
					a.[INPUTKEY] = b.RAW_ID
					WHERE B.Doc_Src_Ind like ''M''
					AND B.REcordNumber = ' + @BeginNbrOfTrans + '') 


					--EXEC('UPDATE a
					--SET 
					--A.[Lien Position_' + @RecNbr + '] = ''1''								
					----Select B.* 
					--FROM x_Custom_OUTPUT_S12 a JOIN 
					--DATA.dbo.Property as B with(NOLOCK)
					--on A.FIPS = B.FIPS and A.PROPERTYID = B.PROPERTYID
					--and A.[DOCID_' + @RecNbr + '] = B.MTG1TransactionID
					--')

					
					--EXEC('UPDATE a
					--SET 
					--A.[Lien Position_' + @RecNbr + '] = ''2''								
					----Select B.* 
					--FROM x_Custom_OUTPUT_S12 a JOIN 
					--DATA.dbo.Property as B with(NOLOCK)
					--on A.FIPS = B.FIPS and A.PROPERTYID = B.PROPERTYID
					--and A.[DOCID_' + @RecNbr + '] = B.MTG2TransactionID
					--')

					--EXEC('UPDATE a
					--SET 
					--A.[Lien Position_' + @RecNbr + '] = ''3''								
					----Select B.* 
					--FROM x_Custom_OUTPUT_S12 a JOIN 
					--DATA.dbo.Property as B with(NOLOCK)
					--on A.FIPS = B.FIPS and A.PROPERTYID = B.PROPERTYID
					--and A.[DOCID_' + @RecNbr + '] = B.MTG3TransactionID
					--')

					--EXEC('UPDATE a
					--SET 
					--A.[Lien Position_' + @RecNbr + '] = ''43''								
					----Select B.* 
					--FROM x_Custom_OUTPUT_S12 a JOIN 
					--DATA.dbo.Property as B with(NOLOCK)
					--on A.FIPS = B.FIPS and A.PROPERTYID = B.PROPERTYID
					--and A.[DOCID_' + @RecNbr + '] = B.MTG4TransactionID
					--')

									

					EXEC('
					Update A
					SET A.[Loan Type_' + @RecNbr + ']  = b.[Codedesc]
					from x_Custom_OUTPUT_S12 A 
					join [Global].[dbo].[lkup_Loan_Type] as B on 
					 A.[Loan Type_' + @RecNbr + ']  = B.LoanTypeID
					')

					
					EXEC('
					Update A
					SET A.[Rate Type_' + @RecNbr + ']  = b.[Codedesc]
					from x_Custom_OUTPUT_S12 A 
					join [Global].[dbo].[lkup_Type_Fin] as B on 
					 A.[Rate Type_' + @RecNbr + ']  = B.[TypeFinId]
					')


							


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END

		

		

			

		----------------------

		Update [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		Update  [zCust_OS_National].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] a JOIN 
		[zCust_OS_National].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKEY] = b.Raw_ID

		Update [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_OS_National].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] a join [zCust_OS_National].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUTKEY] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 



		--------------------------------------------------
	
		------MONITORING FOR OPEN LIEN CHANGES
		--Update  A
		--SET A.[Event Status] = CASE WHEN 
		--ISNULL(A.Mtg1TransactionID,'') <> ISNULL(B.Mtg1TransactionID,'') OR
		--ISNULL(A.Mtg2TransactionID,'') <> ISNULL(B.Mtg2TransactionID,'') OR
		--ISNULL(A.Mtg3TransactionID,'') <> ISNULL(B.Mtg3TransactionID,'') OR
		--ISNULL(A.Mtg4TransactionID,'') <> ISNULL(B.Mtg4TransactionID,'') 
		--then 'Event Found' else 'Event Not Found' end
		----Select A.[INPUTKEY] 
		----,ISNULL(A.Mtg1TransactionID,'') , ISNULL(B.Mtg1TransactionID,'') ,
		----ISNULL(A.Mtg2TransactionID,'') , ISNULL(B.Mtg2TransactionID,'') ,
		----ISNULL(A.Mtg3TransactionID,'') , ISNULL(B.Mtg3TransactionID,'') ,
		----ISNULL(A.Mtg4TransactionID,'') , ISNULL(B.Mtg4TransactionID,'') 
		--From X_CUSTOM_OUTPUT_S12 as A join INPUT_MONITOR as B on 
		--A.[INPUTKEY] = B.UniqueId


		Update  [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		SET [Transaction Status] = CASE WHEN [# of Liens] > 0 then 'Event Found' else 'Event Not Found' end
		

		Select [Property Status], count(*) From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Address Standardization]
		
		Select [Transaction Status], count(*) From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Transaction Status]

		Select [Coverage Status], count(*) From [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12]
		Group by [Coverage Status]

		Select * From  [zCust_OS_National].[dbo].[X_CUSTOM_OUTPUT_S12] as A 
		where [Property Status] like 'Property Not Found'


		--------Looking for open mortgages where rec date > Input start date
		--Select A.FIPS, A.PROPERTYID, [START DATE], [# of Liens],MAX_MTGDATE
		--,B.Mtg1RecordingDt,B.Mtg2RecordingDt, B.Mtg3RecordingDt, B.Mtg4RecordingDt
		--,A.MTG1TRANSACTIONID,A.MTG2TRANSACTIONID,A.MTG3TRANSACTIONID,A.MTG4TRANSACTIONID
		----,
		--From  X_CUSTOM_OUTPUT_S12 as A join data.dbo.Property as B With(NOLOCK) on A.PROPERTYID = B.PropertyID
		--where ISNULL([Recording Date_001] ,'') like ''
		--and 
		--([# of Liens] > 0 or A.MTG1TRANSACTIONID is not null)
		--Order by [# of Liens] desc


		--Select * From w_TransHist_FLANK 
		--where RAW_ID = 'IH_p0002475-1-18.1'


		

END


