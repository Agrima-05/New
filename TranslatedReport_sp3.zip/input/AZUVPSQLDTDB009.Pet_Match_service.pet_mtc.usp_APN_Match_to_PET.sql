/* Source: AZUVNSQLDTDB003.datatree.local | Pet_Match_Service | pet_mtc.usp_APN_Match_to_PET | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */


CREATE PROCEDURE [Pet_Match_service].[pet_mtc].[usp_APN_Match_to_PET] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************

  

CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation

******************************************************************************************************************/
--declare @fileid INT = 1 ,@ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_APN_Match_to_PET - fileid: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Started'

	-- declare @fileid INT = 7
	--
	-- here the logic start that you  want to run by fips
	--
	DROP TABLE

	IF EXISTS #Match_Results
		SELECT d.ID
				,d.Multi_refID
				,d.b_fips
				,d.ref_id
				,d.b_apn
			,try_cast('fmt' AS VARCHAR(20)) AS apn_type
		INTO #Match_Results
		FROM (
			SELECT c.ID
				,max(Multi_refID) AS Multi_refID
				,max(b_fips) AS b_fips
				,max(b_ref_id) AS ref_id
				,max(b_apn) AS b_apn
			FROM (
				SELECT b.ID
					,Fips
					,Apn
					,Apn_Seq
					,_apn
					,ca_apn1
					,ca_apn2
					,ca_apn3
					,_add_apn_match
					,b_fips
					,b_ref_id
					,b_apn
					,REf_id_Occur
					,ROW_NUMBER() OVER (
						PARTITION BY ID ORDER BY (
								SELECT 0
								)
						) AS Multi_refID
				FROM (
					SELECT a.*
						,ROW_NUMBER() OVER (
							PARTITION BY ID
							,b_fips
							,b_ref_id ORDER BY (
									SELECT 0
									)
							) AS REf_id_Occur
					FROM (
						SELECT DISTINCT t.*
							,'pa' AS _pa
							,D.fips AS b_fips
							,d.ref_id AS b_ref_id
							,d.apn AS b_apn
						FROM [PET_Match_Service].[pet_mtc].[Apn_match] t WITH (
								NOLOCK
								,INDEX (idx_file_ID)
								)
						INNER JOIN [PET].[dbo].[Translate_Fips] tf WITH (INDEX (ixc_fips)) ON tf.fips = t.Fips
							AND (
								isnull(Use_Actual_Fips, 0) = 0
								OR (
									isnull(Use_Actual_Fips, 0) = 1
									AND tf.TranslatedFips = t.fips
									)
								)
						INNER JOIN [Pet].[dbo].[pet_apn] D WITH (INDEX (ixa_Fips_Apn)) ON d.fips = tf.TranslatedFips
							AND d.Apn IN (t.Apn)
						INNER JOIN [PET].[dbo].[Pet_Fips_APN_Type] f WITH (INDEX (fips_apn_type_unq)) ON f.Fips = d.Fips
							AND f.Apn_type = d.Apn_type
							AND f.UNQ_Match = 1
							AND f.apn_type = 'FMT'
						WHERE t.Fileid = @Fileid
						) a
					) b
				WHERE REf_id_Occur = 1
					AND b.b_ref_id > 0
				) c
			GROUP BY c.ID
			) d
		WHERE Multi_refID = 1

	CREATE UNIQUE CLUSTERED INDEX idx_id ON #Match_Results (ID)

	INSERT INTO #Match_Results (
		ID
		,Multi_refID
		,b_fips
		,ref_id
		,b_apn
		,apn_type
		)
	SELECT d.*
		,'unf' AS apn_type
	FROM (
		SELECT c.ID
			,max(Multi_refID) AS Multi_refID
			,max(b_fips) AS b_fips
			,max(b_ref_id) AS ref_id
			,max(b_apn) AS b_apn
		FROM (
			SELECT b.ID
				,Fips
				,Apn
				,Apn_Seq
				,_apn
				,ca_apn1
				,ca_apn2
				,ca_apn3
				,_add_apn_match
				,b_fips
				,b_ref_id
				,b_apn
				,REf_id_Occur
				,ROW_NUMBER() OVER (
					PARTITION BY ID ORDER BY (
							SELECT 0
							)
					) AS Multi_refID
			FROM (
				SELECT a.*
					,ROW_NUMBER() OVER (
						PARTITION BY ID
						,b_fips
						,b_ref_id ORDER BY (
								SELECT 0
								)
						) AS REf_id_Occur
				FROM (
					SELECT DISTINCT t.*
						,'pa' AS _pa
						,D.fips AS b_fips
						,d.ref_id AS b_ref_id
						,d.apn AS b_apn
					FROM [PET_Match_Service].[pet_mtc].[Apn_match] t WITH (
							NOLOCK
							,INDEX (idx_file_ID)
							)
					INNER JOIN [PET].[dbo].[Translate_Fips] tf WITH (INDEX (ixc_fips)) ON tf.fips = t.Fips
						AND (
							isnull(Use_Actual_Fips, 0) = 0
							OR (
								isnull(Use_Actual_Fips, 0) = 1
								AND tf.TranslatedFips = t.fips
								)
							)
					INNER JOIN [Pet].[dbo].[pet_apn] D WITH (INDEX (ixa_Fips_Apn)) ON d.fips = tf.TranslatedFips
						AND d.Apn IN (t.Apn)
					INNER JOIN [PET].[dbo].[Pet_Fips_APN_Type] f WITH (INDEX (fips_apn_type_unq)) ON f.Fips = d.Fips
						AND f.Apn_type = d.Apn_type
						AND f.UNQ_Match = 1
						AND f.apn_type = 'UNF'
					OUTER APPLY (
						SELECT id
						FROM #match_results mr
						WHERE mr.id = t.id
						) mr
					WHERE t.Fileid = @Fileid
						AND mr.id IS NULL
					) a
				) b
			WHERE REf_id_Occur = 1
				AND b.b_ref_id > 0
			) c
		GROUP BY c.ID
		) d
	WHERE Multi_refID = 1

	-- select top 100 * from #Match_Results where apn_type not in ('FMT')
	INSERT INTO #Match_Results (
		ID
		,Multi_refID
		,b_fips
		,ref_id
		,b_apn
		,apn_type
		)
	SELECT d.*
	FROM (
		SELECT c.ID
			,max(Multi_refID) AS Multi_refID
			,max(b_fips) AS b_fips
			,max(b_ref_id) AS ref_id
			,max(b_apn) AS b_apn
			,max(apn_type) AS apn_type
		FROM (
			SELECT b.ID
				,Fips
				,Apn
				,Apn_Seq
				,_apn
				,ca_apn1
				,ca_apn2
				,ca_apn3
				,_add_apn_match
				,b_fips
				,b_ref_id
				,b_apn
				,REf_id_Occur
				,apn_type
				,ROW_NUMBER() OVER (
					PARTITION BY ID ORDER BY (
							SELECT 0
							)
					) AS Multi_refID
			FROM (
				SELECT a.*
					,ROW_NUMBER() OVER (
						PARTITION BY ID
						,b_fips
						,b_ref_id ORDER BY (
								SELECT 0
								)
						) AS REf_id_Occur
				FROM (
					SELECT DISTINCT t.*
						,'pa' AS _pa
						,D.fips AS b_fips
						,d.ref_id AS b_ref_id
						,d.apn AS b_apn
						,d.apn_type
					FROM [PET_Match_Service].[pet_mtc].[Apn_match] t WITH (
							NOLOCK
							,INDEX (idx_file_ID)
							)
					INNER JOIN [PET].[dbo].[Translate_Fips] tf WITH (INDEX (ixc_fips)) ON tf.fips = t.Fips
						AND (
							isnull(Use_Actual_Fips, 0) = 0
							OR (
								isnull(Use_Actual_Fips, 0) = 1
								AND tf.TranslatedFips = t.fips
								)
							)
					INNER JOIN [Pet].[dbo].[pet_apn] D WITH (INDEX (ixa_Fips_Apn)) ON d.fips = tf.TranslatedFips
						AND d.Apn IN (t.Apn)
					INNER JOIN [PET].[dbo].[Pet_Fips_APN_Type] f WITH (INDEX (fips_apn_type_unq)) ON f.Fips = d.Fips
						AND f.Apn_type = d.Apn_type
						AND f.UNQ_Match = 1
						AND f.apn_type NOT IN (
							'UNF'
							,'FMT'
							)
					OUTER APPLY (
						SELECT id
						FROM #match_results mr
						WHERE mr.id = t.id
						) mr
					WHERE t.Fileid = @Fileid
						AND mr.id IS NULL
					) a
				) b
			WHERE REf_id_Occur = 1
				AND b.b_ref_id > 0
			) c
		GROUP BY c.ID
		) d
	WHERE Multi_refID = 1

	--select top 100 * from #Match_Results where apn_type not in('UNF','FMT')
	DROP TABLE

	IF EXISTS [pet_Match_service].[pet_tmp].[usp_APN_Match_to_PET_Apn_changed_apn_match]
		CREATE TABLE [pet_Match_service].[pet_tmp].[usp_APN_Match_to_PET_Apn_changed_apn_match] (
			[id] [bigint] NOT NULL
			,[Fips] [int] NULL
			,[Ref_id] [int] NOT NULL
			,[Apn] [varchar](100) NULL
			,apn_type VARCHAR(20) NULL
			)

	INSERT INTO [pet_Match_service].[pet_tmp].[usp_APN_Match_to_PET_Apn_changed_apn_match] (
		id
		,Fips
		,ref_id
		,apn
		,apn_type
		)
	SELECT t.id
		,t.Fips
		,0 AS ref_id
		,substring(b.apn,1,100) as APn
		,substring(b.apn_type,1,20) as apn_type
	
	FROM [PET_Match_Service].[pet_mtc].[Apn_match] t WITH (
			NOLOCK
			,INDEX (idx_file_ID)
			)
	OUTER APPLY (
		SELECT id
		FROM #match_results mr
		WHERE mr.id = t.id
		) mr
	OUTER APPLY (
		SELECT t._apn AS apn
			,'_apn' AS apn_type
		
		UNION ALL
		
		SELECT t.ca_apn1 AS apn
			,'ca_apn1' AS apn_type
		
		UNION ALL
		
		SELECT t.ca_apn2 AS apn
			,'ca_apn2' AS apn_type
		
		UNION ALL
		
		SELECT t.ca_apn3 AS apn
			,'ca_apn3' AS apn_type
		
		UNION ALL
		
		SELECT t.spaceAPN AS apn
			,'spaceAPN' AS apn_type
		
		UNION ALL
		
		SELECT t._add_apn_match AS apn
			,'_add_apn_match' AS apn_type
		) b
	WHERE t.Fileid = @fileid
		AND mr.id IS NULL





	CREATE INDEX idx_id ON [pet_Match_service].[pet_tmp].[usp_APN_Match_to_PET_Apn_changed_apn_match] (id)

	INSERT INTO #Match_results (
		[id]
		,[Multi_refID]
		,[b_fips]
		,[ref_id]
		,apn_type
		)
	SELECT d.*
	FROM (
		SELECT c.id
			,max(Multi_refID) AS Multi_refID
			,max(b_fips) AS b_fips
			,max(b_ref_id) AS ref_id
			,max(apn_type) AS apn_type
		FROM (
			SELECT b.id
				--,t.Fips  
				--,t.Ref_id  
				--,t.Apn  
				--,_n  
				,b_fips
				,b_ref_id
				,apn_type
				--,b_match_code  
				,REf_id_Occur
				,ROW_NUMBER() OVER (
					PARTITION BY id ORDER BY (
							SELECT 0
							)
					) AS Multi_refID
			FROM (
				SELECT a.*
					,ROW_NUMBER() OVER (
						PARTITION BY id
						,b_fips
						,b_ref_id ORDER BY (
								SELECT 0
								)
						) AS REf_id_Occur
				FROM (
					SELECT DISTINCT t.*
						,'pa' AS _pa
						,d.fips AS b_fips
						,d.ref_id AS b_ref_id
					FROM [pet_Match_service].[pet_tmp].[usp_APN_Match_to_PET_Apn_changed_apn_match] t WITH (
							NOLOCK
							,INDEX (idx_id)
							)
					OUTER APPLY (
						SELECT *
						FROM [pet].[dbo].[Translate_Fips] tf WITH (
								NOLOCK
								,INDEX (ixc_Fips)
								)
						WHERE tf.fips = t.fips
						) tf
					INNER JOIN [pet].[dbo].[pet_apn] d WITH (
							NOLOCK
							,INDEX (ixa_Fips_Apn)
							) ON d.Fips = tf.TranslatedFips
						AND d.Apn IN (t.apn)
					INNER JOIN [pet].[dbo].[Pet_Fips_APN_Type] f WITH (
							NOLOCK
							,INDEX (fips_apn_type_unq)
							) ON f.Fips = tf.TranslatedFips
						AND f.Apn_type = d.Apn_type
						AND f.UNQ_Match = 1
					) a
				) b
			WHERE REf_id_Occur = 1
				AND b.b_ref_id > 0
			) c
		GROUP BY c.id
		) d

	-- select top 100 * from #Match_results where apn_type not in ('unf','fmt','prev')
	--	SELECT id , count(1) as cnt FROM PET_Match_Service.[pet_mtc].[Apn_match_Result] group by id having count(1) > 1
	--     truncate table PET_Match_Service.[pet_mtc].[Apn_match_Result]
	INSERT INTO [PET_Match_Service].[pet_mtc].[Apn_match_Result] (
		Fileid
		,id
		,Fips
		,APN
		,Match_Fips
		,Ref_id
		,Match_code
		,Street_Number
		,Direction
		,Street_Name
		,Street_Type
		,Post_Direction
		,Unit_Type
		,Unit
		,City
		,STATE
		,Zip
		,Plus4
		,Created
		,Updated
		,Match_reason
		,Apn_type
		)
	SELECT a.Fileid
		,a.id
		,a.Fips
		,a.apn AS APN
		,b.b_fips AS [Match_Fips]
		,CASE 
			WHEN b.Multi_refID = 1
				THEN b.[Ref_id]
			ELSE 0
			END AS ref_id
		,'' AS [Match_code]
		,p.StreetNumber AS Street_Number
		,p.Pre_Direction AS Direction
		,p.StreetName AS Street_Name
		,p.Street_Type
		,p.Post_Direction
		,p.Unit_Type
		,p.Unit
		,p.City
		,p.STATE
		,p.Zip
		,p.Plus4
		,getdate() AS [Created]
		,getdate() AS [Updated]
		,Match_reason = CASE 
			WHEN b.Multi_refID = 1
				THEN 'ref_id found'
					--WHEN @Match_results_cnt = 0  
					-- THEN 'ref_id not found'  
			WHEN b.Multi_refID > 1
				THEN 'multi_ref_id found'
			END
		,b.apn_type


	FROM [PET_Match_Service].[pet_mtc].[Apn_match] a WITH (
			NOLOCK
			,INDEX (idx_file_id)
			)
	LEFT JOIN #Match_Results b WITH (
			NOLOCK
			,INDEX (idx_id)
			) ON b.ID = a.ID
	LEFT JOIN [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			) ON p.fips = b.b_fips
		AND p.REF_ID = b.[Ref_id]
	WHERE a.fileid = @fileid

	--select a.Match_reason, a.Apn_type,a.* from PET_Match_Service.[pet_mtc].[Apn_match_Result] a
	--where a.Match_reason is not null
	--and a.match_reason not in ('ref_id found')
	--UPDATE a 
	--SET a.Ref_id = isnull(b.Ref_id, 0)
	--	,a.Fips = isnull(b.b_fips, a.Fips)
	--	,a.Match_code = ''
	--	,a.updated = getdate() --@UpdateDate
	--FROM PET.pet_mtc.Apn_match a
	--LEFT JOIN #Match_Results b with(nolock,index(idx_ID)) ON b.ID = a.ID
	--WHERE a.fileid = @fileid
	EXEC [PET_Match_Service].[pet_mtc].[Add_match_Log] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


