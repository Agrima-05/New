SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE procedure [zCust_ReliantCapital].[dbo].[NO_FILE_EMAIL]
as
BEGIN

-----Only runs on MONDAY--------

If(Select datepart("DW",Getdate())) = 2

		BEGIN

		--------Email COunts------


						DECLARE @query NVARCHAR(MAX)
						DECLARE @body NVARCHAR(MAX)
						DECLARE @body1 NVARCHAR(MAX)
						DECLARE @body2 NVARCHAR(MAX)
						DECLARE @body3 NVARCHAR(MAX)
						DECLARE @body4 NVARCHAR(MAX)
						DECLARE @importance NVARCHAR(MAX)
						DECLARE @xml NVARCHAR(MAX)
						DECLARE @xml2 NVARCHAR(MAX)
						DECLARE @Subject NVARCHAR(MAX)
						DECLARE @DATE VARCHAR(10)
						DECLARE @tab char(1) = CHAR(9)
						DECLARE @query_attachment_filename NVARCHAR(MAX)
						Set @Date = Convert(varchar(10),Getdate(),112)
						Set @Subject = 'Reliant Capital - No New Input File - ' + @Date 
				
						SET @body1 = 'Hello - We did not receive a new input file' 
			
	

						-----------sp_send_dbmail example-------------
						EXEC msdb.dbo.sp_send_dbmail
						@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
						@query =  NULL,
						@body = @body1 ,
						@body_format ='HTML',
						@recipients = 'makesh.loganathan@reliantcap.com;srini.raju@ascentds.com;klowe@firstam.com;ECarnese@firstam.com;WLucas@firstam.com',
						--@recipients = 'klowe@firstam.com',
						@subject = @subject,
						@attach_query_result_as_file = 0,
						@query_attachment_filename = @query_attachment_filename,
						@query_result_separator=@tab,
						@query_result_no_padding=1,
						@importance = High
								;

			END

END
