SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_300_Start_Output_MONITOR_PROCTOR_STEP2]

AS
BEGIN
	
	SET NOCOUNT ON;

	
			---------------------BUILD DOWN----------


		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_RecordNbr] [int]NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_RecordingDate] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_RecordedDocumentNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_DocType] [varchar](250) NULL')

		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_DefaultAmount] [varchar](250) NULL')
										
		EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_TrusteeAttorneyName] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_TrusteeAttorneyPhoneNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [HOA_AuctionDate] [varchar](250) NULL')

		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_OrigRecDate] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_OrigDocNbr] [varchar](250) NULL')
		
		--------------Added 20190329 to track SUP records--------
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_SUP] [varchar](1) NULL')

			--------------Added 20191105 to track REO records--------
		EXEC('ALTER Table x_Custom_OUTPUT ADD [NOD_NOS_REO] [varchar](3) NULL')


END






