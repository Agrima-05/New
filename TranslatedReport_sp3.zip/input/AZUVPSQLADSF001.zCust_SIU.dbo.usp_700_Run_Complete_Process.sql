SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF




-- =============================================
-- Create date: 20160107
-- Description:	Run Complete Process
-- =============================================
CREATE PROCEDURE [zCust_SIU].[dbo].[usp_700_Run_Complete_Process] 
		
AS
BEGIN

	SET NOCOUNT ON;

	--DECLARE @CustomerName varchar(200)
	--Set @CustomerName = 'FA_SIU'
	
	DECLARE @SharePtNbr int
	Set @SharePtNbr = '1275'

	Update [zCust_SIU].[dbo].[ADS_DATA]
	Set IsActive = 'NO'

	Insert into [zCust_SIU].[dbo].[ADS_DATA](SharePtNbr,Type,IsACtive,IsBillable)
	Select @SharePtNbr,'BATCH','YES','NO'



	-----Change Input table if new input table provided & run below to update deletes & add new---
	----No new inputs---
	--EXEC [dbo].[usp_501_CustomerIN] 

	-----Run to pull BKY data
	EXEC [zCust_SIU].[dbo].[usp_100_GET_BankruptcyDATA]

	----Create output----

	 IF(Select count(*) from [zCust_SIU].[dbo].[MatchWork_I] t WHERE BKY_VALID_FLAG = 1 and RowNbr > 0) > 0

		BEGIN
			EXEC [zCust_SIU].[dbo].[usp_300_Start_Output_PreDocImage_Pull_V3]
		

				-----Update Max Date for next run----
				Update [zCust_SIU].[dbo].[A]
				Set MAX_DATE = MAXDATE
				--Select *
				From [zCust_SIU].[dbo].[INPUT_IN_MONITOR] as A
				join 
				(Select INPUTKEY,max(convert(datetime,BKY_RECORD_DATE)) as MAXDATE from [zCust_SIU].[dbo].[MatchWork_I]
				WHERE ltrim(rtrim(BKY_VALID_FLAG)) = 1
				Group by INPUTKEY) B
				on A.INPUTKEY = B.INPUTKEY

	



			---- FILL ADS_COUNTS For Monitor JOB based on Active Monitor SharePoint Ticket


				INSERT INTO [zCust_SIU].[dbo].[ADS_COUNTS](AppSource
				,IsBillable
				,TicketNumber
				,CustomerName
				,CMASProductCode
				,BillingOption
				,AccountNumber
				,BatchType)
				 SELECT 'SQL ADS'
				 ,CASE WHEN Billing_x0020_Type NOT LIKE '%Non-billable%' THEN 'YES' ELSE 'NO' END
				 ,a.ID
				 ,left(Client_X0020_Name,255)
				 ,LEFT(Replace(Product,';#',''),100)
				 , Billing_x0020_Type
				 ,Billing_x0020_Number
				 ,b.[Type]
				 FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] a  With(NOLOCK )
				 JOIN [zCust_SIU].[dbo].[ADS_DATA] b
				 on a.ID = b.SharePtNbr
				 WHERE b.IsActive = 'YES'

				update [zCust_SIU].[dbo].[ADS_COUNTS] 
				SET CreateDate = GETDATE()
				,TotalRecords = (Select COUNT(*) from [zCust_SIU].[dbo].[x_Custom_OUTPUT])
				--,TotalMatched = (Select COUNT(*) from x_Custom_OUTPUT where PropertyStatus = 'Property Found')
				--,TotalUnMatched = (Select COUNT(*) from x_Custom_OUTPUT where PropertyStatus = 'Property Not Found')
				,TotalDuplicate = 0
				,TotalExpired = 0
				,TotalInCoverage = (Select COUNT(*) from [zCust_SIU].[dbo].[x_Custom_OUTPUT] where CoverageStatus = 'In Coverage')
				,TotalNotInCoverage = (Select COUNT(*) from [zCust_SIU].[dbo].[x_Custom_OUTPUT] where CoverageStatus = 'Not In Coverage')
				--,TotalPropertiesFound = (Select COUNT(*) from x_Custom_OUTPUT where PropertyStatus = 'Property Found')
				--,TotalPropertiesNotFound = (Select COUNT(*) from x_Custom_OUTPUT where PropertyStatus = 'Property Not Found')
				--,TotalMultiplePropertiesFound = (Select COUNT(*) from x_Custom_OUTPUT where PropertyStatus = 'Multiple Properties Found')
				--,TotalAddressStandardized = (Select COUNT(*) from x_Custom_OUTPUT where AddressStandardization = 'Standardized')
				--,TotalAddressNotStandardized = (Select COUNT(*) from x_Custom_OUTPUT where AddressStandardization = 'Not Standardized')
				,TotalWithEventsFound = (Select COUNT(*) from [zCust_SIU].[dbo].[x_Custom_OUTPUT] where DATAStatus = 'Event Found')
				,TotalWithoutEventsFound = (Select COUNT(*) from [zCust_SIU].[dbo].[x_Custom_OUTPUT] where DATAStatus = 'Event NOT Found')
				--,DocImageCounts = (SELECT COUNT(*) as ImageLinkCounts FROM (Select distinct imagelink from z_Images_To_Pull with(NOLOCK) WHERE ImageLink is not null)A)
				WHERE CreateDate is NULL

				--Select TotalRecords as Total_Records_Monitored
				--,TotalMatched as PropertiesMatched
				--,TotalUnMatched as PropertiesNotMatched
				--,TotalMultiplePropertiesFound as MultiplePropertiesMatched
				--,TotalInCoverage as InCoverage
				--,TotalNotInCoverage as NotInCoverage
				--,TotalAddressStandardized as AddressStandardized
				--,TotalAddressNotStandardized as AddressNotStandardized
				--,TotalWithEventsFound as EventsFound
				--,TotalWithoutEventsFound as EventsNotFound
				--,DocImageCounts
				--FROM ADS_COUNTS 
				--WHERE CreateDate = (Select MAX(CreateDate) from ADS_COUNTS)


		Insert into [JOBS].[dbo].[_Counts] (Customer,JobType,FIPS,STATE,COUNTY,Count,Rundate)
		Select 'FA_SIU','Batch_RECORDS',NULL,left(STATE,2),NULL,
		--A.FIPS,B.STATE,B.[County Name],
		count(*) ,(Select max([CreateDate]) from [zCust_SIU].[dbo].[ADS_COUNTS]) 
		From [zCust_SIU].[dbo].[x_custom_OUTPUT] as A 
		--join Global.dbo.County as B with(NOLOCK)
		--on A.FIPS = B.FIPSCODE
		Group by left(STATE,2)
		Order by left(STATE,2)


		--Select * From [ADS_COUNTS]

	


				  INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
				--INSERT INTO DATA.dbo.AutomatedBilling([AppSource]
					  ,[BatchId]
					  ,[BatchType]
					  ,[CreateDate]
					  ,[ImportDate]
					  ,[TotalRecords]
					  ,[TotalMatched]
					  ,[TotalUnMatched]
					  ,[TotalDuplicate]
					  ,[TotalExpired]
					  ,[TotalInCoverage]
					  ,[TotalNotInCoverage]
					  ,[TotalPropertiesFound]
					  ,[TotalPropertiesNotFound]
					  ,[IsBillable]
					  ,[TotalMultiplePropertiesFound]
					  ,[TotalAddressStandardized]
					  ,[TotalAddressNotStandardized]
					  ,[TotalWithEventsFound]
					  ,[TotalWithoutEventsFound]
					  ,[TicketNumber]
					  ,[BillingDate]
					  ,[ExtractionDate]
					  ,[BillingOption]
					  ,[AccountNumber]
					  ,[DaysToMonitor]
					  ,[CustomerName]
					  ,[ClientName]
					  ,[CMASProductCode]
					  ,[CMASProductName]
					  ,[OracleProductCode]
					  ,[OracleProductName]
					  ,[Title]
					  ,[DocImageCounts]
					  ,[MonitorEndDate])
					SELECT [AppSource]
					  ,[BatchId]
					  ,[BatchType]
					  ,[CreateDate]
					  ,[ImportDate]
					  ,[TotalRecords]
					  ,[TotalMatched]
					  ,[TotalUnMatched]
					  ,[TotalDuplicate]
					  ,[TotalExpired]
					  ,[TotalInCoverage]
					  ,[TotalNotInCoverage]
					  ,[TotalPropertiesFound]
					  ,[TotalPropertiesNotFound]
					  ,[IsBillable]
					  ,[TotalMultiplePropertiesFound]
					  ,[TotalAddressStandardized]
					  ,[TotalAddressNotStandardized]
					  ,[TotalWithEventsFound]
					  ,[TotalWithoutEventsFound]
					  ,[TicketNumber]
					  ,[BillingDate]
					  ,[ExtractionDate]
					  ,[BillingOption]
					  ,[AccountNumber]
					  ,[DaysToMonitor]
					  ,[CustomerName]
					  ,[ClientName]
					  ,LEFT(LTRIM(RTRIM([CMASProductCode])),3)
					  ,[CMASProductName]
					  ,[OracleProductCode]
					  ,[OracleProductName]
					  ,[Title]
					  ,[DocImageCounts]
					  ,[MonitorEndDate]
				FROM [zCust_SIU].[dbo].[ADS_COUNTS]
				WHERE [SentToBilling] is NULL

				UPDATE [zCust_SIU].[dbo].[ADS_COUNTS]
				SET [SentToBilling] = 'Y'
				WHERE [SentToBilling] is NULL


			DECLARE @yyyymmdd varchar(10) = (SELECT convert(varchar(10),Getdate(),112))
			DECLARE @CustomerName varchar(200)
			Set @CustomerName = 'FA_SIU'
	


			EXEC('
			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[zzz_'+ @CustomerName +'_' + @yyyymmdd + '_OUTPUT]'') AND type in (N''U''))
				DROP TABLE [dbo].[zzz_'+ @CustomerName +'_' + @yyyymmdd + '_OUTPUT]

				Select * INTO dbo.zzz_'+ @CustomerName +'_' + @yyyymmdd + '_OUTPUT from x_Custom_OUTPUT
				')

			EXEC('
			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[zzz_'+ @CustomerName +'_' + @yyyymmdd + '_INPUT_IN_MONITOR]'') AND type in (N''U''))
				DROP TABLE [dbo].[zzz_'+ @CustomerName +'_' + @yyyymmdd +  '_INPUT_IN_MONITOR]

				Select * INTO dbo.zzz_'+ @CustomerName +'_' + @yyyymmdd + '_INPUT_IN_MONITOR from INPUT_IN_MONITOR
				')

	

	END



		


END




