/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Determine_Duplicate_Indicators_And_Names | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Determine_Duplicate_Indicators_And_Names] @Refresh BIT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG: 
==========
who		date		change

******************************************************************************************************************/
-- declare @fips INT = 1 ,@ERROR VARCHAR(500) ,@Refresh BIT = 0, @fips INT = null
BEGIN TRY
	DECLARE @msg_fips INT = 55555
	DECLARE @wrk_fips INT = (
			SELECT TOP 1 fips
			FROM [pet].[pet_tmp].[pet_wrk]
			)

	SET @msg_fips = CASE 
			WHEN @Refresh = 1
				THEN @wrk_fips
			ELSE @msg_fips
			END

	EXEC [PET].[dbo].[AddPetlog] @msg_fips
		,N'info'
		,N'usp_Determine_Duplicate_Indicators_And_Names'
		,N'Started'

	--
	-- othe rpgm logic
	TRUNCATE TABLE [PET].[pet_tmp].[Fips_apn]

	IF @refresh = 0
	BEGIN
		INSERT INTO [PET].[pet_tmp].[Fips_apn] (
			Fips
			,apn
			)
		SELECT DISTINCT fips
			,apn
		FROM (
			SELECT fips
				,apn
			FROM [pet].[Pet_tmp].[Pet_ref_ids_Apns_before]
			
			UNION ALL
			
			SELECT fips
				,apn
			FROM [pet].[Pet_tmp].[Pet_ref_ids_Apns_after]
			) a
	END
	ELSE
	BEGIN
		INSERT INTO [PET].[pet_tmp].[Fips_apn] (
			Fips
			,apn
			)
		SELECT DISTINCT fips
			,apn
		FROM [pet].[dbo].[pet_apn] p WITH (
				NOLOCK
				,INDEX (ixa_Fips_Apn)
				)
		WHERE fips IN (
				SELECT DISTINCT fips
				FROM [pet].[pet_tmp].[pet_wrk]
				)
	END

	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Dup_ind]
		SELECT b.fips
			,apn
			,try_cast(CASE 
					WHEN cnt > 1
						THEN 1
					ELSE 0
					END AS BIT) AS dup_ind
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Dup_ind]
		FROM (
			SELECT a.fips
				,a.apn
				,count(1) AS cnt
			FROM (
				SELECT DISTINCT p.Fips
					,p.ref_id
					,p.apn
				FROM [PET].[dbo].[PET_APN] p WITH (
						NOLOCK
						,INDEX (ixa_Fips_Apn)
						)
				INNER JOIN [PET].[pet_tmp].[Fips_apn] a WITH (
						NOLOCK
						,INDEX (ixa_Fips_Apn)
						) ON a.fips = p.fips
					AND a.apn = p.apn
				) a
			GROUP BY a.fips
				,a.apn
			) b
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			)

	CREATE CLUSTERED INDEX ixa_Fips_Apn ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Dup_ind] (
		fips
		,apn
		)

	UPDATE [PET].[pet_dbo].[p]
	SET p.Dup_ind = d.Dup_ind
	--SELECT TOP 100 p.*
	--	,d.*
	FROM [PET].[dbo].[PET_APN] p WITH (
			NOLOCK
			,INDEX (ixa_Fips_Apn)
			)
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Dup_ind] d WITH (
			NOLOCK
			,INDEX (ixa_Fips_Apn)
			) ON d.FIPS = p.fips
		AND d.apn = p.apn

	--
	-- determine legal duplicates duplicates
	--
	IF @refresh = 0
	BEGIN

	    truncate table  [pet].[pet_tmp].[Fips_NEO_TITLE_LEGAL]

		INSERT INTO [pet].[pet_tmp].[Fips_NEO_TITLE_LEGAL] (
			fips
			,NEO_TITLE_LEGAL
			)
		SELECT DISTINCT a.fips
			,a.NEO_TITLE_LEGAL
		FROM (
			SELECT fips
				,NEO_TITLE_LEGAL
			FROM [pet].[Pet_tmp].[Pet_ref_ids_Legal_before]
			
			UNION ALL
			
			SELECT fips
				,NEO_TITLE_LEGAL
			FROM [pet].[Pet_tmp].[Pet_ref_ids_Legal_after]
			) a

		DROP TABLE

		IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Legal_dup_ind]
			SELECT b.fips
				,NEO_TITLE_LEGAL
				,try_cast(CASE 
						WHEN cnt > 1
							THEN 1
						ELSE 0
						END AS BIT) AS legal_dup_ind
			INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Legal_dup_ind]
			FROM (
				SELECT a.fips
					,a.NEO_TITLE_LEGAL
					,count(1) AS cnt
				FROM (
					SELECT DISTINCT p.Fips
						,p.ref_id
						,p.NEO_TITLE_LEGAL
					FROM [PET].[dbo].[PET_NEO_LEGALs] p WITH (
							NOLOCK
							,INDEX (a)
							)
					INNER JOIN [pet].[pet_tmp].[Fips_NEO_TITLE_LEGAL] a WITH (
							NOLOCK
							,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
							) ON a.fips = p.fips
						AND a.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL
					) a
				GROUP BY a.fips
					,a.NEO_TITLE_LEGAL
				) b
			OPTION (
				RECOMPILE
				,MAXDOP 12
				,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
				)

		CREATE CLUSTERED INDEX ixa_Fips_NEO_TITLE_LEGAL ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Legal_dup_ind] (
			fips
			,NEO_TITLE_LEGAL
			)

		--
		-- Update pet_neo_legal 
		--
		UPDATE [PET].[pet_dbo].[p]
		SET p.legal_dup_ind = d.legal_dup_ind
		FROM [PET].[dbo].[PET_NEO_LEGALs] p WITH (
				NOLOCK
				,INDEX (a)
				)
		INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Legal_dup_ind] d WITH (
				NOLOCK
				,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
				) ON d.FIPS = p.fips
			AND d.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL

		--
		-- update pet.dbo.pet with Legal_Dup_Ind
		--
		DROP TABLE

		IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_pet_legal_dup]
			SELECT p.fips
				,p.ref_id
				,max(CASE 
						WHEN p.legal_dup_ind = 1
							THEN 1
						ELSE 0
						END) AS legal_dup_ind
			INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_pet_legal_dup]
			FROM [PET].[dbo].[PET_NEO_LEGALS] p WITH (
					NOLOCK
					,INDEX (a)
					)
			INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Legal_dup_ind] d WITH (
					NOLOCK
					,INDEX (ixa_Fips_NEO_TITLE_LEGAL)
					) ON d.FIPS = p.fips
				AND d.NEO_TITLE_LEGAL = p.NEO_TITLE_LEGAL
			GROUP BY p.fips
				,p.ref_id

		CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_pet_legal_dup] (
			Fips
			,ref_id
			)

		UPDATE [PET].[pet_dbo].[p]
		SET p.legal_dup_ind = a.legal_dup_ind
		FROM [pet].[dbo].[pet] p
		INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_pet_legal_dup] a WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON a.fips = p.fips
			AND a.ref_id = p.ref_id
	END -- legal_dup_ind

	--
	--  end other
	TRUNCATE TABLE [pet].[pet_tmp].[Pet_incr_ref_ids]

	IF @refresh = 0
	BEGIN
		INSERT INTO [pet].[pet_tmp].[Pet_incr_ref_ids] (
			fips
			,ref_id
			,Check_Sum
			,unformatted_apn
			,FORMATTED_APN
			)
		SELECT p.fips
			,p.ref_id
			,p.Check_Sum
			,p.unformatted_apn
			,p.FORMATTED_APN
		FROM [pet].[dbo].[pet] p WITH (
				NOLOCK
				,INDEX (IDX_FIPS_REF_ID)
				)
		INNER JOIN [Pet].[Pet_tmp].[Assr] pt WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON pt.fips = p.fips
			AND pt.ref_id = p.REF_ID
	END
	ELSE
	BEGIN
		INSERT INTO [pet].[pet_tmp].[Pet_incr_ref_ids] (
			fips
			,ref_id
			,Check_Sum
			,unformatted_apn
			,FORMATTED_APN
			)
		SELECT p.fips
			,p.ref_id
			,p.Check_Sum
			,p.unformatted_apn
			,p.FORMATTED_APN
		FROM [pet].[dbo].[pet] p WITH (
				NOLOCK
				,INDEX (ix_Fips)
				)
		WHERE p.fips IN (
				SELECT DISTINCT fips
				FROM [pet].[pet_tmp].[pet_wrk]
				)
	END

	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Check_Sum]
		SELECT a.fips
			,a.check_sum
			,count(1) AS cnt
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Check_Sum]
		FROM (
			SELECT p.fips
				,p.ref_id
				,p.Check_Sum
			--INTO pet.pet_tmp.usp_Determine_Duplicate_Indicators_And_Names_Check_Sum
			FROM [pet].[pet_tmp].[Pet_incr_ref_ids] pr WITH (
					NOLOCK
					,INDEX (IDX_Fips_CHECKSUM)
					)
			INNER JOIN [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_CHECKSUM)
					) ON p.fips = pr.fips
				AND p.Check_Sum = pr.Check_Sum
			) a
		GROUP BY a.fips
			,a.check_sum

	CREATE INDEX IDX_Fips_CHECKSUM ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Check_Sum] (
		FIPS
		,Check_Sum
		)

	UPDATE [PET].[pet_dbo].[p]
	SET p.Addr_Dup_Ind = CASE 
			WHEN c.cnt > 1
				THEN 1
			ELSE 0
			END
	FROM [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_Fips_CHECKSUM)
			)
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Check_Sum] c WITH (
			NOLOCK
			,INDEX (IDX_Fips_CHECKSUM)
			) ON c.FIPS = p.FIPS
		AND c.Check_Sum = p.Check_Sum

	--
	--update unit_id on pet_wrk
	--
	UPDATE [PET].[pet_dbo].[p]
	SET p.Unit_Ind = 1
	FROM [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID_X)
			)
	INNER JOIN [pet].[pet_tmp].[PET_WRK] a WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			) ON a.FIPS = p.fips
		AND a.ref_id = p.ref_id
	WHERE (
			SELECT count(1)
			FROM [pet].[dbo].[PET] pp WITH (
					NOLOCK
					,INDEX (ix_fips_addr_city)
					) -- FIPS, SF_Address_10, Addr_Dup_Ind, Unit_Ind
			WHERE pp.fips = a.fips
				AND pp.SF_Address = a.SF_Address
				AND pp.SF_City = a.SF_City
				AND isnull(pp.SF_Unit, '') > ''
			) > 0

	--
	--unformatted apn
	--
	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_unformatted_apn]
		SELECT a.fips
			,a.unformatted_apn
			,count(1) AS cnt
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_unformatted_apn]
		FROM (
			SELECT p.fips
				,p.ref_id
				,p.unformatted_apn
			--INTO pet.pet_tmp.usp_Determine_Duplicate_Indicators_And_Names_Check_Sum
			FROM [pet].[pet_tmp].[Pet_incr_ref_ids] pr WITH (
					NOLOCK
					,INDEX (IDX_Fips_UAPN)
					)
			INNER JOIN [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_UAPN)
					) ON p.fips = pr.fips
				AND p.unformatted_apn = pr.unformatted_apn
			) a
		GROUP BY a.fips
			,a.unformatted_apn

	CREATE INDEX IDX_Fips_UAPN ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_unformatted_apn] (
		FIPS
		,unformatted_apn
		)

	UPDATE [PET].[pet_dbo].[p]
	SET p.U_Apn_Dup_Ind = CASE 
			WHEN c.cnt > 1
				THEN 1
			ELSE 0
			END
	FROM [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_Fips_UAPN)
			)
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_unformatted_apn] c WITH (
			NOLOCK
			,INDEX (IDX_Fips_UAPN)
			) ON c.FIPS = p.FIPS
		AND c.unformatted_apn = p.unformatted_apn

	--
	-- Formatted_apn
	--
	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_formatted_apn]
		SELECT a.fips
			,a.formatted_apn
			,count(1) AS cnt
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_formatted_apn]
		FROM (
			SELECT p.fips
				,p.ref_id
				,p.formatted_apn
			--INTO pet.pet_tmp.usp_Determine_Duplicate_Indicators_And_Names_Check_Sum
			FROM [pet].[pet_tmp].[Pet_incr_ref_ids] pr WITH (
					NOLOCK
					,INDEX (IDX_Fips_FAPN)
					)
			INNER JOIN [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_FAPN)
					) ON p.fips = pr.fips
				AND p.formatted_apn = pr.formatted_apn
			) a
		GROUP BY a.fips
			,a.formatted_apn

	CREATE INDEX IDX_Fips_FAPN ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_formatted_apn] (
		FIPS
		,formatted_apn
		)

	UPDATE [PET].[pet_dbo].[p]
	SET p.F_Apn_Dup_Ind = CASE 
			WHEN c.cnt > 1
				THEN 1
			ELSE 0
			END
	FROM [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_Fips_FAPN)
			)
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_formatted_apn] c WITH (
			NOLOCK
			,INDEX (IDX_Fips_FAPN)
			) ON c.FIPS = p.FIPS
		AND c.formatted_apn = p.formatted_apn

	--
	-- all ref_ids that were captured today and those set to duplicated because of hte record changes today
	--
	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_ref_id_affected]
		SELECT DISTINCT a.fips
			,a.ref_id
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_ref_id_affected]
		FROM (
			SELECT fips
				,ref_id
			FROM [Pet].[Pet_tmp].[Assr]
			
			UNION ALL
			
			SELECT p.fips
				,p.ref_id
			FROM [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_FAPN)
					)
			INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_formatted_apn] c WITH (
					NOLOCK
					,INDEX (IDX_Fips_FAPN)
					) ON c.FIPS = p.FIPS
				AND c.formatted_apn = p.formatted_apn
			
			UNION ALL
			
			SELECT p.fips
				,p.ref_id
			FROM [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_UAPN)
					)
			INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_unformatted_apn] c WITH (
					NOLOCK
					,INDEX (IDX_Fips_UAPN)
					) ON c.FIPS = p.FIPS
				AND c.unformatted_apn = p.unformatted_apn
			
			UNION ALL
			
			SELECT p.fips
				,p.ref_id
			FROM [pet].[dbo].[pet] p WITH (
					NOLOCK
					,INDEX (IDX_Fips_CHECKSUM)
					)
			INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Check_Sum] c WITH (
					NOLOCK
					,INDEX (IDX_Fips_CHECKSUM)
					) ON c.FIPS = p.FIPS
				AND c.Check_Sum = p.Check_Sum
			) a

	CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_ref_id_affected] (
		Fips
		,ref_id
		)

	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Temp]
		SELECT p.fips
			,p.ref_id
			,p.UNFORMATTED_APN
			,p.Check_Sum
			,p.FORMATTED_APN
			,p.U_Apn_Dup_Ind
			,p.F_Apn_Dup_Ind
			,p.Addr_Dup_Ind
			,p.Legal_Dup_Ind
			,p.Dup_Key
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Temp]
		FROM [pet].[dbo].[pet] p WITH (
				NOLOCK
				,INDEX (IDX_FIPS_REF_ID)
				)
		INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_ref_id_affected] r WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				) ON r.fips = p.fips
			AND r.ref_id = p.ref_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Temp] (
		fips
		,ref_id
		)

	UPDATE [PET].[pet_dbo].[p]
	SET p.Dup_Key = e.Dup_Key_u
	FROM [pet].[dbo].[pet] p WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			)
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Temp] t WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON t.fips = p.fips
		AND t.ref_id = p.ref_id
	OUTER APPLY (
		SELECT CASE 
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 0
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 1
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 2
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 3
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 4
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 5
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 6
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 7
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 8
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 9
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 10
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 11
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 12
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 1
						)
					THEN 13
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.Legal_dup_ind, 0) = 1
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 14
				WHEN (
						ISNULL(t.u_Apn_Dup_Ind, 0) = 0
						AND ISNULL(t.f_Apn_Dup_Ind, 0) = 1
						AND ISNULL(t.Legal_dup_ind, 0) = 0
						AND ISNULL(t.addr_Dup_Ind, 0) = 0
						)
					THEN 15
				ELSE 0
				END AS Dup_Key_u
		) e

	--
	-- rebuild pet_name for incremental
	--
	DROP TABLE

	IF EXISTS [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Name]
		SELECT a.*
		INTO [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Name]
		FROM (
			SELECT n.Fips
				,n.Ref_ID
				,n1.Last_Name
				,n1.First_Name
				,n1.Middle_Name
				,n1.Name_Type
				,n1.Suffix
				,ROW_NUMBER() OVER (
					PARTITION BY n.Fips
					,n.Ref_ID
					,n1.Last_Name
					,n1.First_Name
					,n1.Middle_Name
					,n1.Name_Type
					,n1.Suffix ORDER BY (
							SELECT 0
							)
					) AS ROW4
				,n1.Full_Name
				,n1.Raw_name
			FROM [pet].[tmp].[NOVACL_XREF_Name_Assr_incr] n
			OUTER APPLY (
				SELECT nullif(n.Last_Name, '') AS Last_Name
					,nullif(n.First_Name, '') AS First_Name
					,nullif(n.Middle_Name, '') AS Middle_Name
					,nullif(n.Name_Type, '') AS Name_Type
					,nullif(n.Suffix, '') AS Suffix
					,nullif(n.Full_Name, '') AS Full_Name
					,nullif(n.Raw_name, '') AS Raw_name
				) n1
			) a
		WHERE row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_fips_ref_id ON [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Name] (
		fips
		,ref_id
		)

	/*
			select top 100 * from PEt.pet_tmp.NOVACL_XREF
			select top 100 * from pet.pet_tmp.usp_Determine_Duplicate_Indicators_And_Names_Name

			*/
	BEGIN TRANSACTION

	DELETE n
	FROM [pet].[dbo].[pet_name] n
	INNER JOIN [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Name] x WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON x.fips = n.fips
		AND x.ref_id = n.ref_id

	INSERT INTO [PET].[dbo].[PET_NAME] (
		Fips
		,REF_ID
		,Last_Name
		,First_Name
		,Middle_Name
		,Full_Name
		,Name_Type
		,created
		,updated
		,Suffix
		,Raw_Name
		)
	SELECT n.Fips
		,n.Ref_ID
		,n.Last_Name
		,n.First_Name
		,n.Middle_Name
		,n.Full_Name
		,n.Name_Type
		,getdate() AS created
		,getdate() AS updated
		,n.Suffix
		,n.Raw_Name
	FROM [pet].[pet_tmp].[usp_Determine_Duplicate_Indicators_And_Names_Name] n
	WHERE fips IS NOT NULL

	COMMIT

	EXEC [PET].[dbo].[AddPetlog] @msg_fips
		,N'info'
		,N'usp_Determine_Duplicate_Indicators_And_Names'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


