/* Source: DWS-ETL02.DATATREE.LOCAL | SPDB | dbo.usp_PEt_Apn_Creation_1_incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- =============================================
--create
--or 
CREATE   PROCEDURE [SPDB].[dbo].[usp_PEt_Apn_Creation_1_incr] @fips INT = NULL
	,@Apn_type VARCHAR(10) = NULL
	,@list_Sql INT = 0
	,@Refresh BIT = 1
AS
begin try
declare @ERROR VARCHAR(500)

	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'[usp_PEt_Apn_Creation_1_incr]'
		,N'Started'

-- declare @fips INT = 45079 ,@Apn_type VARCHAR(5) = 'FMT1' ,@list_Sql INT = 1 ,@Refresh BIT = 0
		DECLARE @SQL VARCHAR(MAX)
			,@LinkSvr VARCHAR(100) = ''





		--IF @@SERVERNAME <> 'AZUVNSQLDTDB003'
SET @LinkSvr = CASE 
		WHEN @@SERVERNAME = N'AZUVPSQLDTDB009'
			THEN '[DWS-ETL01].'
		WHEN @@SERVERNAME = N'AZUVPSQLDTDB029'
			THEN ''
		ELSE ''
		END




DECLARE @sql_cmd VARCHAR(max)
DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
	,@Rule VARCHAR(max) = NULL --
	--'			
	--when SUBSTRING(a.APN,1,2) = ''1-'' then ''DC'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''2-'' then ''ED'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''3-'' then ''kh'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''4-'' then ''LC'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''5-'' then ''MD'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''6-'' then ''MN'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''7-'' then ''NM'' + substring(a.apn, 2,60)			
	--when SUBSTRING(a.APN,1,2) = ''8-'' then ''SM'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''9-'' then ''WD'' + substring(a.apn, 2,60)
	--'
	,@Status VARCHAR(20) = NULL --'To_Be_Processed'
	,@node_delimeter VARCHAR(10) = NULL --'-'
	-- select top 100 * from Lien.dbo.PET_APN_Additional_Formats a
DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type

--EXEC ntp.Stage.[AddNtpLog] N'info'
--	,N'usp_PEt_Apn_Creation_1 begin'
--	,@mess
-- Select top 100 * from ntp.Stage.ntp_log where logger = 'Paul_ssis_TEST'
--update a set a.Status = 'To_Be_Processed'
--from Lien.dbo.PET_APN_Additional_Formats a
--where a.fips =  @fips and a.apn_type =  @apn_type
SELECT @Source_Apn = a.Source_Apn
	,@Rule = a.[Rule]
	,@node_delimeter = a.node_delimeter
-- select top 10 * 
FROM [PEt].[dbo].[PET_APN_Additional_Formats] a
WHERE a.fips = @fips
	AND a.APN_Type = @apn_type

SET @node_delimeter = CASE 
		WHEN @node_delimeter IS NULL
			THEN ' '
		ELSE @node_delimeter
		END
-- and (@Refresh  = 1 or ( @refresh = 0 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk) ))
SET @sql_cmd = cast(N'
DROP TABLE if exists pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source1

SELECT  A.[FIPS]
	,a.[REF_ID]
	,a.' + @Source_apn + ' as apn
	,a.Unformatted_apn
	,a.original_apn
	,a.Alternate_apn
	,a.MUNICIPALITY_CODE
	,a.MUNICIPALITY_NAME


into pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source1
FROM ' + @LinkSvr + '[Assr].[dbo].[Assr] a with (nolock) 

WHERE fips = ' + try_cast(@fips AS VARCHAR) AS NVARCHAR(max))

IF @refresh = 0
BEGIN
	SET @sql_cmd = @sql_cmd + cast(N'
 and a.ref_id in (select distinct ref_id from pet.pet_tmp.pet_apn_wrk)
' AS NVARCHAR(max))
END

SET @sql_cmd = @sql_cmd + cast(N'


DROP TABLE if exists pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source


SELECT  a.*
	,ROW_NUMBER( ) OVER ( PARTITION BY a.apn  ORDER BY ( SELECT 0 ) ) AS ROW4
	,aa.*

into pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source
FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source1 a
outer apply (SELECT node1,node2,node3,node4,node5,node6,node7,node8,node9,node10  FROM  spdb.[dbo].[fn_get_apn_nodes] (a.apn,''' + @node_delimeter + 
		''')
) aa

OPTION (RECOMPILE,MAXDOP 12,USE HINT(''ENABLE_PARALLEL_PLAN_PREFERENCE''));

create clustered index ixa on pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source (REf_id)

DELETE
FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source
WHERE ref_id IN (
		SELECT DISTINCT Ref_id
		FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source
		WHERE row4 > 1
		)



DROP TABLE if exists pet.dbo.Pet_apn_additions

CREATE TABLE [PET].[dbo].[Pet_apn_additions](
	[REF_ID] [numeric](12, 0) NOT NULL,
	[FIPS] [int] NOT NULL,
	[APN_Type] [varchar](10) NULL,
	[APN_ID] [numeric](12, 0) NULL,
	[APN] [varchar](60) NULL,
	[created] [datetime] NULL,
	[updated] [datetime] NULL
) ON [PRIMARY]


create index ixa on pet.dbo.Pet_apn_additions (APN)



INSERT INTO pet.dbo.Pet_apn_additions
           ([REF_ID]
           ,[FIPS]
           ,[APN_Type]
           ,[APN_ID]
           ,[APN]
           ,[created]
           ,[updated]
           )
SELECT a.[REF_ID]
      ,a.[FIPS]
      ,''' + @APN_Type + 
		''' as [APN_Type]
      ,0 as [APN_ID]
      ,b._new_apn as [APN]
      ,getdate() as [created]
      ,getdate() as [updated]
  FROM pet.pet_tmp.usp_PEt_Apn_Creation_1_incr_source a
  OUTER APPLY (
	SELECT CASE 
			' + @Rule + '
			ELSE NULL
			END AS _new_apn
	) b
  where b._new_apn is not null



' AS NVARCHAR(max))

IF @list_Sql = 1
BEGIN
	SELECT @sql_cmd
END

IF @list_Sql = 0
BEGIN
	EXEC (@sql_cmd)
END
		--EXEC ntp.Stage.[AddNtpLog] N'info'
		--	,N'usp_PEt_Apn_Creation_1 END'
		--	,@mess
	EXEC [PET].[dbo].[AddPetlog] @fips, N'info'
		,N'[usp_PEt_Apn_Creation_1_incr]'
		,N'Started'

END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH

