/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Insert_Listings_Raw_Std_Address | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Insert_Listings_Raw_Std_Address] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation


Notes 
1. the where clause need to limit the data to the daily input

DECLARE @Error_Msg varchar(500),
		@ERROR varchar(500)

EXEC	Listings.Listings_dbo.usp_Combine_Daily_Adds_and_Snapshot
		@ERROR = @ERROR OUTPUT

 SET  @Error_Msg = @ERROR

--SELECT ? = @Error_Msg 


******************************************************************************************************************/
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Insert_Listings_Raw_Std_Address'

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'

	UPDATE [Listings].[Listings_dbo].[a]
	SET a.Raw_HOUSE_NBR = isnull(a.Raw_HOUSE_NBR, '')
		,a.Raw_STREET = isnull(a.Raw_STREET, '')
		,a.Raw_CITY = isnull(a.Raw_CITY, '')
		,a.Raw_STATE = isnull(a.Raw_STATE, '')
		,a.Raw_ZIP = isnull(a.Raw_ZIP, '')
		,a.Raw_Address = isnull(a.Raw_Address, '')
	FROM [LISTINGS].[Listings_tmp].[Listings_Raw_Std_Address_wrk] a

	INSERT INTO [LISTINGS].[Listings_dbo].[Listings_Raw_Std_Address] (
		[Raw_HOUSE_NBR]
		,[Raw_STREET]
		,[Raw_CITY]
		,[Raw_STATE]
		,[Raw_ZIP]
		,[Addr_type]
		,[FIPS]
		,[REF_ID]
		,[Match_code]
		,[HouseNumber]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[STD_State]
		,[Zip]
		,[Plus4]
		,[CRRT]
		,[CountyName]
		,[PMB]
		,[PMSA]
		,[MSA]
		,[ZipType]
		,[Urbanization]
		,[CongressionalDistrict]
		,[CountryCode]
		,[CityAbbreviation]
		,[AddressTypeCode]
		,[AddressTypeString]
		,[DPV_Count]
		,[DPV_Footnotes]
		,[CMRA]
		,[ELOT_Number]
		,[ELOT_Order]
		,[LACS]
		,[LACS_LinkIndicator]
		,[EWS_Flag]
		,[RBDI]
		,[SuiteLinkReturnCode]
		,[DeliveryPointCheckDigit]
		,[DeliveryPointCode]
		,[CensusBlock]
		,[CensusTract]
		,[PlaceCode]
		,[PlaceName]
		,[CBSACode]
		,[CBSALevel]
		,[CBSATitle]
		,[CBSADivisionCode]
		,[CBSADivisionLevel]
		,[CBSADivisionTitle]
		,[Latitude]
		,[Longitude]
		,[Verified]
		,[Geocoded]
		,[AddressMatchResults]
		,[GeoErrorCode]
		,[GeoStatusCode]
		,[Created]
		,[Updated]
		,[Raw_Address]
		)
	SELECT a.[Raw_HOUSE_NBR]
		,a.[Raw_STREET]
		,a.[Raw_CITY]
		,a.[Raw_STATE]
		,a.[Raw_ZIP]
		,a.[Addr_type]
		,coalesce(a.Match_fips, a.FIPS) AS Fips
		,a.[REF_ID]
		,a.[Match_code]
		,a.[HouseNumber]
		,a.[Street_Number]
		,a.[Direction]
		,a.[Street_Name]
		,a.[Street_Type]
		,a.[Post_Direction]
		,a.[Unit_Type]
		,a.[Unit]
		,a.[City]
		,a.[STD_State]
		,a.[Zip]
		,a.[Plus4]
		,a.[CRRT]
		,a.[CountyName]
		,a.[PMB]
		,a.[PMSA]
		,a.[MSA]
		,a.[ZipType]
		,a.[Urbanization]
		,a.[CongressionalDistrict]
		,a.[CountryCode]
		,a.[CityAbbreviation]
		,a.[AddressTypeCode]
		,a.[AddressTypeString]
		,a.[DPV_Count]
		,a.[DPV_Footnotes]
		,a.[CMRA]
		,a.[ELOT_Number]
		,a.[ELOT_Order]
		,a.[LACS]
		,a.[LACS_LinkIndicator]
		,a.[EWS_Flag]
		,a.[RBDI]
		,a.[SuiteLinkReturnCode]
		,a.[DeliveryPointCheckDigit]
		,a.[DeliveryPointCode]
		,a.[CensusBlock]
		,a.[CensusTract]
		,a.[PlaceCode]
		,a.[PlaceName]
		,a.[CBSACode]
		,a.[CBSALevel]
		,a.[CBSATitle]
		,a.[CBSADivisionCode]
		,a.[CBSADivisionLevel]
		,a.[CBSADivisionTitle]
		,a.[Latitude]
		,a.[Longitude]
		,a.[Verified]
		,a.[Geocoded]
		,a.[AddressMatchResults]
		,a.[GeoErrorCode]
		,a.[GeoStatusCode]
		,a.[Created]
		,a.[Updated]
		,a.[Raw_Address]
	FROM [LISTINGS].[Listings_tmp].[Listings_Raw_Std_Address_wrk] a WITH (
			NOLOCK
			,INDEX (IDX_Listings_Rowid_address)
			)
	OUTER APPLY (
		SELECT count(1) AS cnt
		FROM [listings].[Listings_dbo].[Listings_Raw_Std_Address] b WITH (
				NOLOCK
				,INDEX (IDX_Listings_Rowid_address)
				)
		WHERE b.Raw_HOUSE_NBR = a.Raw_HOUSE_NBR
			AND b.Raw_STREET = a.Raw_STREET
			AND b.Raw_CITY = a.Raw_CITY
			AND b.Raw_STATE = a.Raw_STATE
			AND b.Raw_ZIP = a.Raw_ZIP
			AND b.Raw_Address = a.Raw_Address
		) b
	WHERE b.cnt = 0
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


