/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.usp_DailyExtractNames | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[usp_DailyExtractNames] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who				date		change
paul and Marie  20230614	SP
Marie			2025/04/14	B29686 - Special Processing for Transfer on Death transactions Hardcoding Instructions
Marie			2025/09/29	B30782 - Buyer_Ownership_Percentage population

******************************************************************************************************************/
/*
USE Lien_dtdb
GO

DECLARE	@return_value int,
		@ERROR varchar(500)

EXEC	INFC.usp_DailyExtractNames
		@ERROR = @ERROR OUTPUT

SELECT	@ERROR as N'@ERROR'

SELECT	'Return Value' = @return_value

GO
*/
--declare @ERROR VARCHAR(500) 
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddinfcLog] N'info'
		,N'usp_DailyExtractNames'
		,N'Started'

	DROP TABLE

	IF EXISTS #doc_type
		SELECT a.*
		INTO #doc_type
		FROM (
			SELECT 'deed' AS _deed
				,UR_VALUE
				,DESCRIPTION
				,Delete_date
			FROM [Lien_dtdb].[dbo].[UR_Document_Types] dt
			WHERE isnull(dt.deed_type, '') <> 'Z'
			--			WHERE Delete_date IS NULL
			
			UNION ALL
			
			SELECT 'ras' AS _ras
				,UR_DOC_TYPE
				,REPRESENTATIVE_DOC_TITLE
				,Delete_date
			FROM [Lien_dtdb].[dbo].[UR_RAS_Doc_Types]
			--WHERE Delete_date IS NULL
			
			UNION ALL
			
			SELECT 'pfc' AS _pfc
				,Doc_type
				,Description
				,Delete_date
			FROM [Lien_dtdb].[dbo].[UR_PFC_Doc_Types]
			WHERE PRE_FORECLOSURE_CODE <> 'SBT'
				--AND Delete_date IS NULL
			) a

	CREATE INDEX idx_UR_VALUE ON #doc_type (UR_VALUE)

	--
	-- B30782 - Ownership Ownership Percentage
	--
	DROP TABLE

	IF EXISTS [Lien_dtdb].[tmp].[B30782_Buyer_Ownership_Percent]
		SELECT DISTINCT n.doc_id
			,n.name_id
			,n.percent_transferred
			,CASE 
				WHEN substring(c.c_percent_transferred, 1, 1) = '.'
					THEN '0' + c.c_percent_transferred
				ELSE c.c_percent_transferred
				END AS c_percent_transferred
			,p.position_Slash
			,p.position_Dot
			,a.Whole
			,a.fraction
			,d.convert_to_percentage
			,h.percent_transferred_whole_number
			,f.percent_transferred_f
		INTO [Lien_dtdb].[tmp].[B30782_Buyer_Ownership_Percent]
		FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed] r
		INNER JOIN [lien].[ur].[name] n WITH (
				NOLOCK
				,INDEX (doc_id)
				) ON n.doc_id = r.doc_id
		OUTER APPLY (
			SELECT try_cast(convert_to_percentage AS VARCHAR(3)) AS convert_to_percentage
			FROM [Deed].[dbo].[UR_Buyer_Percentage] pt WITH (
					NOLOCK
					,INDEX (idx_percent_transferred)
					)
			WHERE pt.percent_transferred = (
					SELECT [SPDB].[dbo].[RegexReplace](upper(N.percent_transferred), '([A-Z]+)', '', 0)
					)
				AND pt.percent_transferred <> 'null'
			) d
		OUTER APPLY (
			SELECT [SPDB].[dbo].[RegexReplace](n.percent_transferred, '[^0-9/.]', '', 0) AS C_percent_Transferred
			) c
		OUTER APPLY (
			SELECT charindex('/', c.c_percent_transferred) AS position_Slash
				,charindex('.', c.c_percent_transferred) AS position_Dot
			) p
		OUTER APPLY (
			SELECT max(CASE 
						WHEN ItemNumber = 1
							THEN try_cast(item AS DECIMAL(10, 2))
						ELSE NULL
						END) AS whole
				,max(CASE 
						WHEN ItemNumber = 2
							THEN try_cast(item AS DECIMAL(10, 2))
						ELSE NULL
						END) AS fraction
			FROM (
				SELECT ROW_NUMBER() OVER (
						PARTITION BY 0 ORDER BY (
								SELECT 0
								)
						) AS ItemNumber
					,value AS Item
				FROM [lien_DTDB].[INFC].[STRING_SPLIT](c.c_percent_transferred, '/')
				WHERE RTRIM(value) <> ''
					AND p.position_Slash > 0
				) ff
			WHERE p.position_Slash > 0
			) a
		OUTER APPLY (
			SELECT try_cast(CASE 
						WHEN p.position_Slash > 0
							AND a.Whole <= 99
							AND a.Fraction IS NOT NULL
							AND p.Position_Dot = 0
							AND c_percent_transferred <> ''
							THEN CASE 
									WHEN (a.Whole / a.fraction) * 100 - floor((a.Whole / a.fraction) * 100) > = 0.5
										THEN FLOOR((a.Whole / a.fraction) * 100) + 1
									WHEN (a.Whole / a.fraction) * 100 - floor((a.Whole / a.fraction) * 100) < 0.5
										THEN FLOOR((a.Whole / a.fraction) * 100)
									WHEN (a.Whole / a.fraction) * 100 - floor((a.Whole / a.fraction) * 100) = 0
										THEN NULL -- FLOOR((a.Whole / a.fraction) * 100)
									END
						WHEN isnumeric(c.c_percent_transferred) = 1
							AND position_Dot = 0
							THEN c.c_percent_transferred
						WHEN c_percent_transferred <> ''
							AND position_Dot <> 0
							AND isnumeric(Substring(c.c_percent_transferred, position_dot + 1, 1)) = 1
							AND Substring(c.c_percent_transferred, position_dot + 1, 1) NOT IN (
								'.'
								,'/'
								)
							THEN CASE 
									WHEN TRY_CAST(Substring(c.c_percent_transferred, position_dot + 1, 1) AS INT) >= 5
										THEN try_cast(Substring(c.c_percent_transferred, 1, position_dot - 1) AS INT) + 1
									WHEN TRY_CAST(Substring(c.c_percent_transferred, position_dot + 1, 1) AS INT) <= 5
										THEN try_cast(Substring(c.c_percent_transferred, 1, position_dot - 1) AS INT)
									END
						END AS VARCHAR(3)) AS percent_transferred_whole_number
			) h
		OUTER APPLY (
			SELECT coalesce(d.convert_to_percentage, h.percent_transferred_whole_number) AS percent_transferred_f
			) f
		WHERE n.percent_transferred IS NOT NULL
			AND try_cast(f.percent_transferred_f AS INT) BETWEEN 1
				AND 99

	--AND r.doc_id = 353286131
	CREATE INDEX idx_docid_nameId ON [Lien_dtdb].[tmp].[B30782_Buyer_Ownership_Percent] (
		doc_id
		,name_id
		)

	DROP TABLE

	IF EXISTS [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames]
		SELECT k.*
			,ROW_NUMBER() OVER (
				PARTITION BY k.doc_id
				,k._Name_type
				,k.last_company_name
				,k.first_name
				,k.middle_name
				,k.suffix
				,k.vesting_code -- Marie
				ORDER BY k.RoleType_single_sort_seq
				) AS dedupe_delete
		INTO [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames]
		FROM (
			SELECT N.Doc_id
				,N.Name_id
				,ltrim(rtrim(isnull(dd._Name_type, ''))) AS _Name_type
				,ltrim(rtrim(isnull(N.doc_unique_id, ''))) AS doc_unique_id
				,ltrim(rtrim(isnull(N.sequence_number, ''))) AS sequence_number
				,CASE 
					WHEN isnull(N.name_identifier, '') = 'T'
						THEN 'T'
					WHEN LEN(LTRIM(NN.last_company_name)) > 0
						AND LEN(LTRIM(N.first_name)) = 0
						THEN 'C'
					WHEN LEN(LTRIM(NN.last_company_name)) > 0
						AND LEN(LTRIM(N.first_name)) > 0
						THEN 'I'
					ELSE ltrim(rtrim(isnull(N.name_identifier, '')))
					END AS name_identifier
				,CASE 
					WHEN ltrim(rtrim(isnull(NN.last_company_name, ''))) IN (
							'NOT GIVEN'
							,'RECORD OWNER'
							)
						THEN 'NAME NOT AVAILABLE'
					ELSE ltrim(rtrim(isnull(NN.last_company_name, '')))
					END AS last_company_name
				,ltrim(rtrim(isnull(N.first_name, ''))) AS first_name
				,ltrim(rtrim(isnull(N.middle_name, ''))) AS middle_name
				,ltrim(rtrim(isnull(N.suffix, ''))) AS suffix
				,ltrim(rtrim(isnull(N.party_type_code, ''))) AS party_type_code
				,ltrim(rtrim(isnull(try_cast(n.role_type AS VARCHAR(200)), ''))) AS role_type
				,ltrim(rtrim(isnull(rt._relationship_code, ''))) AS relationship_code
				,ltrim(rtrim(isnull(vc._vesting_code, ''))) AS vesting_code
				,ltrim(rtrim(isnull(pt.percent_transferred, ''))) AS percent_transferred
				,ltrim(rtrim(isnull(N.address_same_as_property_address_flag, ''))) AS address_same_as_property_address_flag
				,ltrim(rtrim(isnull(N.address, ''))) AS address
				,ltrim(rtrim(isnull(CASE 
								WHEN dd._Name_type = 'Lender'
									THEN CASE 
											WHEN n.orig_Mtg_Lender_Name IS NULL
												THEN try_cast(substring(n.last_company_name, 1, 200) AS VARCHAR(200))
											ELSE try_cast(substring(n.orig_Mtg_Lender_Name, 1, 200) AS VARCHAR(200))
											END
								ELSE NULL
								END, ''))) AS orig_Mtg_Lender_Name
				,DENSE_RANK() OVER (
					PARTITION BY n.doc_unique_id
					,n.sequence_number
					,n.name_identifier ORDER BY Name_id
					) AS RN
				,ltrim(rtrim(isnull(n.address_city_name, ''))) AS address_city_name
				,ltrim(rtrim(isnull(n.address_state_name, ''))) AS address_state_name
				,ltrim(rtrim(isnull(n.address_zip_code, ''))) AS address_zip_code
				,ROW_NUMBER() OVER (
					PARTITION BY a.doc_id
					,dd._Name_type ORDER BY CASE 
							WHEN n.party_type_code IN (
									'DBA'
									,'AKA'
									)
								AND N.name_identifier = 'C' --'I'
								THEN 1
							ELSE 0
							END
					) AS dba_aka_sort_seq
				,ROW_NUMBER() OVER (
					PARTITION BY a.doc_id
					,dd._Name_type ORDER BY CASE 
							WHEN n.role_type = 'Party Receiving Life Estate'
								THEN 1
							WHEN n.party_type_code IN (
									'LFE'
									,'LFR'
									)
								THEN 2
							WHEN vc._Vesting_code = 'LE'
								THEN 3
									--WHEN vc._Vesting_code = 'LE'
									--OR n.role_type = 'Party Receiving Life Estate'
									--OR n.party_type_code in('LFE','LFR')
									--	THEN 1
							ELSE 0
							END --DESC
						,CASE 
							WHEN n.role_type IN (
									'Executor'
									,'Executor/Administrator'
									,'Administrator'
									,'Guardian'
									)
								THEN 1
							ELSE 0
							END
						,n.sequence_number
					) AS RoleType_single_sort_seq
				,s.*
			/*
		if DBA or AKA and Name_Indicator = C then this name must be in forst position
		*/
			FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed] a
			CROSS APPLY (
				SELECT ur_value
				FROM #doc_type dt
				WHERE dt.ur_value = a.doc_type
					AND (
						dt.Delete_date IS NULL
						OR dt.Delete_date > A.Recording_Date_D
						)
				) dt
			INNER JOIN [Lien].[UR].[NAME] N WITH (INDEX (doc_id)) ON a.doc_id = n.doc_id
			OUTER APPLY (
				SELECT s.AddressMatchResults
				FROM [Lien].[dbo].[Lien_Mail_Std_Address] s
				WHERE s.Id = N.Name_id
				) s
			OUTER APPLY (
				SELECT percent_transferred_f AS percent_transferred
				FROM [Lien_dtdb].[tmp].[B30782_Buyer_Ownership_Percent] pt
				WHERE pt.doc_id = a.doc_id
					AND pt.name_id = n.name_id
				) pt
			OUTER APPLY (
				SELECT try_cast(N.last_company_name AS VARCHAR(200)) AS last_company_name
					,try_cast(N.role_type AS VARCHAR(200)) AS role_type
					,try_cast(N.orig_Mtg_Lender_Name AS VARCHAR(200)) AS orig_Mtg_Lender_Name
				) nn
			OUTER APPLY (
				SELECT CASE 
						WHEN UPPER(LTRIM(RTRIM(N.party_type_code))) IN (
								SELECT CodeValue
								FROM [Lien].[dbo].[codetable]
								WHERE TableShortName = 'inval_partytypecode'
									AND codevalue NOT IN (
										'AKA'
										,'DBA'
										)
								)
							THEN 'invalid_partyType'
						WHEN UPPER(nn.role_type) IN (
								SELECT CodeValue
								FROM [Lien].[dbo].[codetable]
								WHERE TableShortName = 'Deed_Buy_Role_TP'
									AND CodeValue NOT IN (
										'Trustee'
										,'Personal Representative'
										,'ORIGINAL OWNER'
										)
								)
							--'PARTY RECEIVING LIFE ESTATE' should always be in the first position
							AND a.doc_type IN (
								SELECT UR_VALUE  
								FROM [Lien_Dtdb].[dbo].[UR_Document_Types] dt
								WHERE DEED_TYPE <> 'T'
									AND (dt.Delete_date IS NULL or dt.Delete_date > a.Recording_Date_D)
									 
								)
							THEN 'deed_buyer'
						WHEN UPPER(nn.role_type) IN (
								SELECT CodeValue
								FROM [Lien].[dbo].[codetable]
								WHERE TableShortName = 'Mtg_Buy_Role_TP'
									AND CodeValue NOT IN (
										'Trustee'
										,'Personal Representative'
										,'ORIGINAL OWNER'
										)
								)
							AND a.doc_type IN (
								SELECT UR_VALUE
								FROM [Lien_Dtdb].[dbo].[UR_Document_Types] dt
								WHERE DEED_TYPE = 'T'
									AND (dt.Delete_date IS NULL or dt.Delete_date > a.Recording_Date_D)
									 
								)
							THEN 'deed_buyer'
						WHEN UPPER(nn.role_type) IN (
								SELECT CodeValue
								FROM [Lien].[dbo].[codetable]
								WHERE TableShortName = 'Sel_Role_TP'
								)
							THEN 'Seller'
						WHEN UPPER(nn.role_type) IN (
								SELECT CodeValue
								FROM [Lien].[dbo].[codetable]
								WHERE TableShortName = 'Lndr_Role_TP'
								)
							THEN 'Lender'
						ELSE ''
						END AS _Name_type
				) dd
			OUTER APPLY (
				SELECT RELATIONSHIP_Type AS _relationship_code
				FROM [Deed].[dbo].[UR_Relationship_Codes]
				WHERE UR_VALUE = n.relationship_code
				) rt
			OUTER APPLY (
				SELECT OWNERSHIP_RIGHTS_CODE AS Vesting_code
				FROM [Deed].[dbo].[UR_Vesting_Codes] V
				--WHERE UR_VALUE = Substring(n.vesting_code, 1, 2)
				WHERE UR_VALUE = n.vesting_code -- B33124 - Chetan vesting codes longer than 2 characters
					AND ur_value <> 'TR'
				) VS
			OUTER APPLY (
				SELECT CASE 
						WHEN vs.Vesting_code IS NOT NULL
							THEN vs.Vesting_code
						WHEN n.role_type = 'Party Receiving Life Estate'
							OR n.party_type_code IN (
								'LFE'
								,'LFR'
								)
							THEN 'LE'
						WHEN n.Last_company_name LIKE '%FAMILY IRREVOCABLE TRUST%'
							THEN 'FI'
						WHEN n.Last_company_name LIKE '%FAMILY %IRREVOCABLE TRUST%'
							THEN 'FI' --B33124 - Chetan Vesting codes
						WHEN n.Last_company_name LIKE '%FAMILY %IRREVOCABLE %TRUST%'
							THEN 'FI' --B33124 - Chetan Vesting codes
						WHEN n.Last_company_name LIKE '%FAMILY IRREVOCABLE %TRUST%'
							THEN 'FI'
								-------------------------------------------------------------------------------------------------------------------------------
								--WHEN n.Last_company_name LIKE '%FAMILY%IRREVOCABLE TRUST%'  THEN 'FI' --B33124 - Chetan Vesting codes
						WHEN n.Last_company_name LIKE '%FAMILY REVOCABLE TRUST%'
							THEN 'FR'
						WHEN n.Last_company_name LIKE '%FAMILY %REVOCABLE TRUST%'
							THEN 'FR'
						WHEN n.Last_company_name LIKE '%FAMILY %REVOCABLE %TRUST%'
							THEN 'FR'
						WHEN n.Last_company_name LIKE '%FAMILY REVOCABLE %TRUST%'
							THEN 'FR'
								----------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%FAMILY LIVING TRUST%'
							THEN 'FL'
						WHEN n.Last_company_name LIKE '%FAMILY %LIVING TRUST%'
							THEN 'FL'
						WHEN n.Last_company_name LIKE '%FAMILY %LIVING %TRUST%'
							THEN 'FL'
						WHEN n.Last_company_name LIKE '%FAMILY LIVING %TRUST%'
							THEN 'FL'
								-------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%FAMILY TRUST%'
							THEN 'FM'
						WHEN n.Last_company_name LIKE '%FAMILY %TRUST%'
							THEN 'FM' --B33124 - Chetan Vesting codes
								-------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%PERSONAL TRUST%'
							THEN 'PT'
						WHEN n.Last_company_name LIKE '%PERSONAL %TRUST%'
							THEN 'PT' --B33124 - Chetan Vesting codes
								-------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%IRREVOCABLE LIVING TRUST%'
							THEN 'IL'
						WHEN n.Last_company_name LIKE '%IRREVOCABLE %LIVING TRUST%'
							THEN 'IL'
						WHEN n.Last_company_name LIKE '%IRREVOCABLE %LIVING %TRUST%'
							THEN 'IL'
						WHEN n.Last_company_name LIKE '%IRREVOCABLE LIVING %TRUST%'
							THEN 'IL'
								---------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%IRREVOCABLE TRUST%'
							THEN 'IR'
						WHEN n.Last_company_name LIKE '%IRREVOCABLE %TRUST%'
							THEN 'IR' --B33124 - Chetan Vesting Codes
								----------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%REVOCABLE LIVING TRUST%'
							THEN 'RL'
						WHEN n.Last_company_name LIKE '%REVOCABLE %LIVING TRUST%'
							THEN 'RL'
						WHEN n.Last_company_name LIKE '%REVOCABLE %LIVING %TRUST%'
							THEN 'RL'
						WHEN n.Last_company_name LIKE '%REVOCABLE LIVING %TRUST%'
							THEN 'RL'
								----------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%REVOCABLE TRUST%'
							THEN 'RT'
						WHEN n.Last_company_name LIKE '%REVOCABLE %TRUST%'
							THEN 'RT'
								----------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%LIVING TRUST%'
							THEN 'LT'
						WHEN n.Last_company_name LIKE '%LIVING %TRUST%'
							THEN 'LT'
								-------------------------------------------------------------------------------------------------------------------------------------------
						WHEN n.Last_company_name LIKE '%TRUST%'
							AND n.Last_company_name NOT LIKE '%Bank%'
							AND n.Last_company_name NOT LIKE '%Loan%'
							AND n.Last_company_name NOT LIKE '%Finance%'
							AND n.Last_company_name NOT LIKE '%Savings%'
							THEN 'TR'
								--ELSE (
								--		SELECT OWNERSHIP_RIGHTS_CODE AS Vesting_code
								--		FROM Deed.dbo.UR_Vesting_Codes V
								--		--WHERE UR_VALUE = Substring(n.vesting_code, 1, 2)
								--		WHERE UR_VALUE = n.vesting_code    -- B33124 - Chetan vesting codes longer than 2 characters
								--		)
						END AS _Vesting_code
				) vc
			WHERE a.m_status_id < 3
				AND n.Last_company_name IS NOT NULL -- B32162 2026-02-5
			) k
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	/*
SELECT dba_aka_sort_seq
	,RoleType_single_sort_seq
	,dedupe_delete
	,*
FROM lien_dtdb.lien_dtdb_tmp.usp_DailyExtractNames_hashNames n
WHERE doc_id = 48931512
	AND _Name_type = 'deed_buyer'
ORDER BY n.RoleType_single_sort_seq
*/
	DELETE
	FROM [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames]
	WHERE party_type_code IN (
			'AKA'
			,'DBA'
			)
		AND dba_aka_sort_seq > 1
		AND _Name_type = 'deed_buyer'
		AND name_identifier = 'I'

	DELETE
	FROM [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames]
	WHERE dedupe_delete <> 1

	/*
select RoleType_single_sort_seq, dedupe_delete, * from lien_dtdb.lien_dtdb_tmp.usp_DailyExtractNames_hashNames a where  doc_id = 48931512 and _Name_type = 'deed_buyer' order by a.RoleType_single_sort_seq
*/
	/*	
	select a.RoleType_single_sort_seq, sequence_number, * from Lien_dtdb.infc.deed_buyer_names a  WHERE doc_id = 351856009
	 select * from lien_dtdb.infc.deed_buyer_names_pivot  WHERE doc_id = 351856009
	*/
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_buyer_names]
		SELECT a.*
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id
				,_Name_type ORDER BY Role_Type
					,sequence_number
				) AS ROW4
			,cast('' AS VARCHAR(60)) AS Combine_NAME
			,try_cast(0 AS INT) AS aditional_name_id
			,ROW_NUMBER() OVER (
				PARTITION BY a.doc_id ORDER BY CASE 
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'I'
								)
							THEN 1
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'C'
								)
							THEN 2
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'T'
								)
							THEN 3
						WHEN a.name_identifier = 'T'
							THEN 4
						WHEN a.name_identifier = 'I'
							AND isnull(party_type_code, '') IN (
								'TRS'
								,'FBO'
								)
							THEN 5
						WHEN a.name_identifier = 'C'
							AND ISNULL(party_type_code, '') <> 'CO'
							THEN 6
						ELSE 99
						END --desc-----------------------------------20240109
					,a.sequence_number
					,Role_Type
				) AS _Parse_seq
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY (
						CASE 
							WHEN party_type_code IN (
									'aka'
									,'dba'
									)
								AND a.name_identifier = 'C'
								THEN 1
							ELSE 0
							END
						)
				) AS ROW_aka
		INTO [Lien_dtdb].[infc].[deed_buyer_names]
		FROM [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames] a
		WHERE _Name_type = 'deed_buyer'
			AND (
				(
					role_type IN (
						'Executor/Administrator'
						,'Administrator'
						,'Executor'
						,'Guardian'
						)
					AND RoleType_single_sort_seq = 1
					)
				OR (
					role_type NOT IN (
						'Executor/Administrator'
						,'Administrator'
						,'Executor'
						,'Guardian'
						)
					)
				)

	CREATE INDEX idx_row ON [Lien_dtdb].[infc].[deed_buyer_names] (
		doc_id
		,row4
		)

	CREATE CLUSTERED INDEX idx_doc_id_Seq ON [Lien_dtdb].[infc].[deed_buyer_names] (
		doc_id
		,_Parse_seq
		)

	/*
select RoleType_single_sort_seq, _Parse_seq, rn, * from Lien_dtdb.infc.deed_buyer_names where doc_id =  351856009
*/
	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_seller_names]
		SELECT a.*
			,CASE 
				WHEN name_identifier IN (
						'C'
						--,'T'
						)
					THEN 'Y'
				ELSE ''
				END AS CORP_IND
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id
				,_Name_type ORDER BY sequence_number
				) AS ROW4
			,cast('' AS VARCHAR(60)) AS Combine_NAME
			,ROW_NUMBER() OVER (
				PARTITION BY a.doc_id ORDER BY CASE 
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'I'
								)
							THEN 1
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'C'
								)
							THEN 2
						WHEN role_type = 'PARTY RECEIVING LIFE ESTATE'
							OR (
								isnull(party_type_code, '') IN (
									'LFE'
									,'LFR'
									)
								AND a.name_identifier = 'T'
								)
							THEN 3
						WHEN a.name_identifier = 'T'
							THEN 4
						WHEN a.name_identifier = 'I'
							AND isnull(party_type_code, '') IN (
								'TRS'
								,'FBO'
								)
							THEN 5
						WHEN a.name_identifier = 'C'
							AND ISNULL(party_type_code, '') <> 'CO'
							THEN 6
						ELSE 99
						END --desc-----------------------------------20240109
					,a.sequence_number
					,Role_Type
				) AS _Parse_seq
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY (
						CASE 
							WHEN party_type_code IN (
									'aka'
									,'dba'
									)
								AND a.name_identifier = 'C'
								THEN 0
							ELSE 1
							END
						)
				) AS ROW_aka
		INTO [Lien_dtdb].[infc].[deed_seller_names]
		FROM [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames] a
		WHERE _Name_type = 'Seller'
			AND (
				(
					role_type IN (
						'Executor/Administrator'
						,'Administrator'
						,'Executor'
						,'Guardian'
						)
					AND RoleType_single_sort_seq = 1
					)
				OR (
					role_type NOT IN (
						'Executor/Administrator'
						,'Administrator'
						,'Executor'
						,'Guardian'
						)
					)
				)

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[infc].[deed_buyer_names] (doc_id)

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[infc].[deed_seller_names] (doc_id) include (
		_Name_type
		,sequence_number
		,ROW4
		,name_identifier
		,last_company_name
		,first_name
		,middle_name
		,party_type_code
		,role_type
		,dba_aka_sort_seq
		)

	--
	-- Special Logic for Transfer on Death Documents - B29686
	--
  
  /*

  select 'hashNames' as _hashNames, * from lien_dtdb.lien_dtdb_tmp.usp_DailyExtractNames_hashNames where doc_id = 197174068
  select 'deed_TOF_names' as _deed_TOF_names ,* from Lien_dtdb.infc.deed_TOF_names where doc_id = 197174068
  select 'deed_seller_names' as _deed_seller_names ,* from Lien_dtdb.infc.deed_seller_names  where doc_id = 197174068
  select 'deed_buyer_names' as _deed_buyer_names ,* from  Lien_dtdb.infc.deed_buyer_names where doc_id = 197174068

  */

	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_TOF_names]
		SELECT a.*
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,sequence_number
				) AS _new_sequence_number
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,dba_aka_sort_seq
				) AS _new_dba_aka_sort_seq
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,RoleType_single_sort_seq
				) AS _New_RoleType_single_sort_seq
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,ROW4
				) AS _New_ROW4
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,_Parse_seq
				) AS _new_Parse_seq
			,ROW_NUMBER() OVER (
				PARTITION BY doc_id ORDER BY doc_id
					,role_Type DESC
					,ROW_aka
				) AS _new_ROW_aka
		INTO [Lien_dtdb].[infc].[deed_TOF_names]
		FROM (
			SELECT Doc_id
				,Name_id
				--,'deed_buyer' AS _Name_type
				,_Name_type
				,doc_unique_id
				,try_cast(sequence_number AS INT) AS sequence_number
				,name_identifier
				,last_company_name
				,first_name
				,middle_name
				,suffix
				,party_type_code
				,role_type
				,relationship_code
				,vesting_code
				,percent_transferred
				,address_same_as_property_address_flag
				,address
				,orig_Mtg_Lender_Name
				,RN
				,address_city_name
				,address_state_name
				,address_zip_code
				,dba_aka_sort_seq
				,RoleType_single_sort_seq
				,dedupe_delete
				,CORP_IND
				,ROW4
				,Combine_NAME
				,0 AS aditional_name_id
				,_Parse_seq
				,ROW_aka
				,s.AddressMatchResults
			FROM [Lien_dtdb].[infc].[deed_seller_names] s
			WHERE doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed] a
					WHERE a.doc_type IN (
							'DEDTOD'
							,'QCDTOD'
							--,'AFFTOD'
							)
					)
			
			UNION ALL
			
			SELECT Doc_id
				,Name_id
				,_Name_type
				,doc_unique_id
				--,sequence_number
				,try_cast(sequence_number AS INT) + 10 AS sequence_number
				,name_identifier
				,last_company_name
				,first_name
				,middle_name
				,suffix
				,party_type_code
				,role_type
				,relationship_code
				,'BE' AS vesting_code
				,percent_transferred
				,address_same_as_property_address_flag
				,address
				,orig_Mtg_Lender_Name
				,RN
				,address_city_name
				,address_state_name
				,address_zip_code
				,dba_aka_sort_seq
				,RoleType_single_sort_seq
				,dedupe_delete
				,NULL AS CORP_IND
				,ROW4
				,Combine_NAME
				,aditional_name_id
				,_Parse_seq
				,ROW_aka
				,AddressMatchResults
			FROM [Lien_dtdb].[infc].[deed_buyer_names] s
			WHERE doc_id IN (
					SELECT doc_id
					FROM [lien_dtdb].[tmp].[reprocess_records_to_be_processed] a
					WHERE a.doc_type IN (
							'DEDTOD'
							,'QCDTOD'
							--,'AFFTOD'
							)
					)
			) a

	CREATE INDEX idx_doc_id ON [Lien_dtdb].[infc].[deed_tof_names] (Doc_id)

	/*
	select * from  Lien_dtdb.infc.deed_TOF_names where doc_id = 351856009
	select * from Lien_dtdb.infc.deed_buyer_names where doc_id = 351856009
	*/
	DELETE b
	-- select * 
	FROM [Lien_dtdb].[infc].[deed_buyer_names] b
	WHERE b.doc_id IN (
			SELECT doc_id
			FROM [Lien_dtdb].[infc].[deed_tof_names]
			)

	INSERT INTO [Lien_DTDB].[INFC].[deed_buyer_names] (
		[Doc_id]
		,[Name_id]
		,[_Name_type]
		,[doc_unique_id]
		,[sequence_number]
		,[name_identifier]
		,[last_company_name]
		,[first_name]
		,[middle_name]
		,[suffix]
		,[party_type_code]
		,[role_type]
		,[relationship_code]
		,[vesting_code]
		,[percent_transferred]
		,[address_same_as_property_address_flag]
		,[address]
		,[orig_Mtg_Lender_Name]
		,[RN]
		,[address_city_name]
		,[address_state_name]
		,[address_zip_code]
		,[dba_aka_sort_seq]
		,[RoleType_single_sort_seq]
		,[dedupe_delete]
		,[ROW4]
		,[Combine_NAME]
		,[aditional_name_id]
		,[_Parse_seq]
		,[ROW_aka]
		,AddressMatchResults
		)
	SELECT b.[Doc_id]
		,b.[Name_id]
		,b.[_Name_type]
		,b.[doc_unique_id]
		--,b.[sequence_number]
		,right('0000' + cast(b.[sequence_number] AS VARCHAR), 4)
		,b.[name_identifier]
		,b.[last_company_name]
		,b.[first_name]
		,b.[middle_name]
		,b.[suffix]
		,b.[party_type_code]
		,'GRANTEE' AS [role_type]
		,b.[relationship_code]
		,b.[vesting_code]
		,b.[percent_transferred]
		,b.[address_same_as_property_address_flag]
		,b.[address]
		,b.[orig_Mtg_Lender_Name]
		,b.[RN]
		,b.[address_city_name]
		,b.[address_state_name]
		,b.[address_zip_code]
		,b.[dba_aka_sort_seq]
		,b.[RoleType_single_sort_seq]
		,b.[dedupe_delete]
		,b.[ROW4]
		,b.[Combine_NAME]
		,b.[aditional_name_id]
		,b.[_Parse_seq]
		,b.[ROW_aka]
		,b.AddressMatchResults
	FROM (
		SELECT --dedupe_names,role_type 
			a.[Doc_id]
			,a.[Name_id]
			,a.[_Name_type]
			,a.[doc_unique_id]
			--,a.[sequence_number]
			,ROW_NUMBER() OVER (
				PARTITION BY 0 ORDER BY role_type DESC
					,sequence_number
				) AS sequence_number
			,a.[name_identifier]
			,a.[last_company_name]
			,a.[first_name]
			,a.[middle_name]
			,a.[suffix]
			,a.[party_type_code]
			,a.[role_type]
			,a.[relationship_code]
			,a.[vesting_code]
			,a.[percent_transferred]
			,a.[address_same_as_property_address_flag]
			,a.[address]
			,a.[orig_Mtg_Lender_Name]
			,a.[RN]
			,a.[address_city_name]
			,a.[address_state_name]
			,a.[address_zip_code]
			,a.[dba_aka_sort_seq]
			,a.[RoleType_single_sort_seq]
			,a.[dedupe_delete]
			,a.[ROW4]
			,a.[Combine_NAME]
			,a.[aditional_name_id]
			,a.[_Parse_seq]
			,a.[ROW_aka]
			,a.AddressMatchResults
		FROM (
			SELECT [Doc_id]
				,[Name_id]
				,[_Name_type]
				,[doc_unique_id]
				,right('0000' + cast(_new_sequence_number AS VARCHAR), 4) AS sequence_number
				,[name_identifier]
				,[last_company_name]
				,[first_name]
				,[middle_name]
				,[suffix]
				,[party_type_code]
				,[role_type]
				,[relationship_code]
				,[vesting_code]
				,[percent_transferred]
				,[address_same_as_property_address_flag]
				,[address]
				,[orig_Mtg_Lender_Name]
				,[RN]
				,[address_city_name]
				,[address_state_name]
				,[address_zip_code]
				,_new_dba_aka_sort_seq AS dba_aka_sort_seq
				,_New_RoleType_single_sort_seq AS RoleType_single_sort_seq
				,[dedupe_delete]
				,_New_ROW4 AS [ROW4]
				,[Combine_NAME]
				,[aditional_name_id]
				,_new_Parse_seq AS _Parse_seq
				,_new_ROW_aka AS [ROW_aka]
				,AddressMatchResults
				,ROW_NUMBER() OVER (
					PARTITION BY doc_id
					,last_company_name
					,first_name
					,middle_name
					,suffix ORDER BY CASE 
							WHEN role_type = 'GRANTOR' -- seller
								THEN 1
							WHEN role_type = 'GRANTEE' -- buyer
								THEN 2
							ELSE 3
							END
					) AS dedupe_names
			FROM [Lien_dtdb].[infc].[deed_TOF_names]
			) a
		WHERE a.dedupe_names = 1
		--and a._Name_type = 'deed_buyer'
		) b

	DROP TABLE

	IF EXISTS [Lien_dtdb].[infc].[deed_Lender_names]
		SELECT a.Doc_id
			,Name_id
			,_Name_type
			,doc_unique_id
			,sequence_number
			,CASE 
				WHEN last_company_name LIKE '%bank%'
					AND name_identifier = 'T'
					THEN 'C'
				ELSE name_identifier
				END AS name_identifier
			,last_company_name
			,first_name
			,middle_name
			,suffix
			,party_type_code
			,role_type
			,relationship_code
			,vesting_code
			,percent_transferred
			,address_same_as_property_address_flag
			,address
			,orig_Mtg_Lender_Name
			,RN
			,address_city_name
			,address_state_name
			,address_zip_code
			,dba_aka_sort_seq
			,RoleType_single_sort_seq
			,ROW_NUMBER() OVER (
				PARTITION BY Doc_id
				,_Name_type ORDER BY sequence_number
				) AS ROW4
			,cast('' AS VARCHAR(60)) AS Combine_NAME
			,a.AddressMatchResults
		INTO [Lien_dtdb].[infc].[deed_Lender_names]
		FROM [lien_dtdb].[lien_dtdb_tmp].[usp_DailyExtractNames_hashNames] a
		WHERE _Name_type = 'Lender'

	EXEC [Lien_dtdb].[INFC].[AddInfcLog] N'info'
		,N'usp_DailyExtractNames'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


