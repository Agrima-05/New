/* Source: DWS-ETL01.DATATREE.LOCAL | lien | UR.nova_ref_rematch_before_count | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
 
-- =============================================
-- Author:		<Sunwoo Park>
-- Create date: <2026-04-29>
-- Description:	<Nova ref rematch before count>
-- =============================================
create PROCEDURE [Lien].[UR].[nova_ref_rematch_before_count] (@fips int)
AS

DECLARE @fips_code CHAR(5) = right('00' + cast(@fips AS VARCHAR(5)), 5)
DECLARE @rowcount INT = 0

BEGIN
	BEGIN TRY
		-- Update counts
		UPDATE [Lien].[UR].[r]
		SET r.cnt_ref_rematch_before = isnull(c.ref_match_cnt,0)
			,r.cnt_nova_doc_found_before = isnull(c.nova_doc_found,0)
			,r.cnt_nova_ref_found_before = isnull(c.nova_ref_found,0)
			,r.cnt_ref_rematch_after = NULL
			,r.cnt_nova_doc_found_after = NULL
			,r.cnt_nova_ref_found_after = NULL
		FROM [lien].[dbo].[lien_rematch] r
		LEFT JOIN (
			SELECT rm.fips
				,COUNT(*) AS ref_match_cnt
				,COUNT(rm.nova_doc_id) AS nova_doc_found
				,COUNT(rm.nova_ref_id) AS nova_ref_found
			FROM [lien].[ur].[DOCUMENT] d WITH (
					NOLOCK
					,INDEX (idx_fips_inst_rcdt_cmt_dt_seq)
					)
			INNER JOIN [lien].[ur].[REFERENCE_match] rm WITH (
					NOLOCK
					,INDEX (id_doc_id)
					) ON rm.doc_id = d.doc_id
			WHERE d.fips_code = @fips_code
			GROUP BY rm.fips
			) c ON r.fips = c.fips
		WHERE r.Ref_Status = 'To_Be_Run'
			and r.fips = @fips

		SET @rowcount = @@rowcount

		RAISERROR (
				'%s updated %d'
				,0
				,1
				,@fips_code
				,@rowcount
				)
	END TRY

	BEGIN CATCH
		-- Print error details then Rollback
		SELECT 
			ERROR_LINE() AS ErrorLine,
            ERROR_MESSAGE() AS ErrorMessage;

		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;
	END CATCH

	-- Commit if no error
	IF @@TRANCOUNT > 0
		COMMIT TRANSACTION;
END

