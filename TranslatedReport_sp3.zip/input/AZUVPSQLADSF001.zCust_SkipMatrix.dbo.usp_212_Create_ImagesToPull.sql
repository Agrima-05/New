SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE PROCEDURE [zCust_SkipMatrix].[dbo].[usp_212_Create_ImagesToPull] 
AS
BEGIN

  TRUNCATE TABLE [dbo].[z_Images_To_Pull]

  INSERT INTO [zCust_SkipMatrix].[dbo].[z_Images_To_Pull]
  ([Fips]
      ,[DocumentNbr]
      ,[CmtId]
      ,[RecordingDate]
      ,[ImageName]
  )
  SELECT [Fips]
      ,[DocumentNbr]
      ,[CmtId]
      ,[RecordingDate]
      ,[DocumentNbr]
  FROM [zCust_SkipMatrix].[dbo].[w_TransHist] 
  WHERE [DocumentNbr] <> '' AND [DocumentNbr] <> 'Unknown' AND CmtId > 0

END






