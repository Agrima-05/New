SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF






CREATE PROCEDURE [zCust_NJ_Redact].[dbo].[usp_203_Get_DIM_NOVA_DOCUMENT_A] 
AS
BEGIN

TRUNCATE TABLE dbo.w_DIM_NOVA_DOCUMENT

	INSERT INTO [zCust_NJ_Redact].[dbo].[w_DIM_NOVA_DOCUMENT]
	( [Doc_Id]
      ,[Fips]
      ,[Doc_Number]
      ,[Source_Doc_Number]
      ,[Property_Id]
      ,[Cmt_Id]
      ,[Doc_Description]
      ,[Doc_Type]
      ,[Recording_Date]
      ,[Filing_Date]
      ,[Doc_Src_Ind]
      ,[Loan_Amt]
      ,[Transfer_Amt]
      ,[Arms_Length]
      ,[Lien_Position]
      ,[Foreclosure_flag]
      ,[Fraud_Flag]
      ,[Assignment_Flag]
      ,[Release_Flag]
      ,[Subordination_Flag]
      ,[Modification_Flag]
      ,[ReoSale_Flag]
      ,[Delinquency_Flag]
      ,[Created_Date]
      ,[Updated_Date]
      ,[Sr_Unique_Id]
      ,[Hist_Sr_Full_Part_Code]
      ,[Hist_Sr_Int_Rate_Type]
      ,[Hist_Sr_Mult_Port_Code]
      ,[Sr_Ownership_Status_Code]
      ,[Mtg_Term]
      ,[Mtg_Term_TYPE]
      ,[Loan_Type]
      ,[Int_Rate]
      ,[Short_Sale_Flag]
      ,[Rate_Type]
      ,[Raps_Doc_Ind]
      ,[REF_ID]
      ,[Source_Type]
      ,[Doc_Nbr_Ind]
      ,[confidence]
      ,[lien_pos]
      ,[IsVerified])

	SELECT 
		d.[Doc_Id]
		,d.[Fips]
		,d.[Doc_Number]
		,d.[Source_Doc_Number]
		,d.[Property_Id]
		,d.[Cmt_Id]
		,d.[Doc_Description]
		,d.[Doc_Type]
		,d.[Recording_Date]
		,d.[Filing_Date]
		,d.[Doc_Src_Ind]
		,d.[Loan_Amt]
		,d.[Transfer_Amt]
		,d.[Arms_Length]
		,d.[Lien_Position]
		,d.[Foreclosure_flag]
		,d.[Fraud_Flag]
		,d.[Assignment_Flag]
		,d.[Release_Flag]
		,d.[Subordination_Flag]
		,d.[Modification_Flag]
		,d.[ReoSale_Flag]
		,d.[Delinquency_Flag]
		,d.[Created_Date]
		,d.[Updated_Date]
		,d.[Sr_Unique_Id]
		,d.[Hist_Sr_Full_Part_Code]
		,d.[Hist_Sr_Int_Rate_Type]
		,d.[Hist_Sr_Mult_Port_Code]
		,d.[Sr_Ownership_Status_Code]
		,d.[Mtg_Term]
		,d.[Mtg_Term_TYPE]
		,d.[Loan_Type]
		,d.[Int_Rate]
		,d.[Short_Sale_Flag]
		,d.[Rate_Type]
		,d.[Raps_Doc_Ind]
		,d.[REF_ID]
		,d.[Source_Type]
		,d.[Doc_Nbr_Ind]
		,d.[confidence]
		,d.[lien_pos]
		,d.[IsVerified]		  
	FROM  [AZUVPSQLDTDB029.datatree.local].NovaDimDoc.dbo.DIM_NOVA_DOCUMENT d with(nolock)  
		INNER JOIN [zCust_NJ_Redact].[dbo].[w_PropertyReference] p with(nolock)  ON d.Fips = p.FIPS
	AND (d.REF_ID = p.REF_ID)

	PRINT('Finish compared by ref_id')
	

END



