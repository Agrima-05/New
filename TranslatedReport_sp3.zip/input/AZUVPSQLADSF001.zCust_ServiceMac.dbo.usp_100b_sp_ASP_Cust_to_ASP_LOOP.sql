SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_100b_sp_ASP_Cust_to_ASP_LOOP]
AS
BEGIN





truncate table [dbo].[a_ASP_IN]
truncate table [dbo].[a_ASP_IN_STD]



Declare @TOTALTOPROCESS bigint
SET @TOTALTOPROCESS = (Select count(*) From [zCust_ServiceMac].[dbo].[INPUT_IN] with(NOLOCK) where [Processed] is null)
PRINT @TOTALTOPROCESS

	WHILE (@TOTALTOPROCESS > 0)
		BEGIN

DECLARE	@limit int = 250000
truncate table [dbo].ServiceMac
truncate table [dbo].[ServiceMac_STD]
truncate table [dbo].[a_ASP_IN]


EXEC('INSERT INTO [dbo].[a_ASP_IN]
(
       [RAW_ID]
	  ,[FullStreetAddress]
      ,[City]
      ,[State]
      ,[ZIP5]
)
SELECT top ('+@limit+')
       [InputKey]
	  ,replace(replace(replace(replace([INPUTAddress],''.'',''''),''"'',''''),''[#]'',''''),'','','''')
      ,[INPUTCity]
      ,[INPUTState]
      ,left([INPUTZip],5)

FROM [dbo].[INPUT_IN] where [Processed] is null')

IF (Select COUNT(*) FROM [zCust_ServiceMac].[dbo].[a_ASP_IN]) > 0 
	BEGIN

			 
		EXEC('INSERT INTO dbo.[ServiceMac](RecordId,[FullStreetAddress],[City],[State],[Zip],[raw_id])
			Select ASP_ID,[FullStreetAddress],[City],LEFT([State],2),[ZIP5],[RAW_ID]
			FROM a_ASP_IN')


		EXEC('INSERT INTO [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
			 (''ServiceMac'',''ServiceMac'',''B'',''R'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
			 ')

	END

	IF (SELECT COUNT(*) FROM [zCust_ServiceMac].[dbo].[ServiceMac_STD]) = 0
			BEGIN
				---- Subsequent 2 min wait periods until ASP is complete
				DECLARE @CheckASP as int
				
					SET @CheckASP = 0

				WHILE @CheckASP = 0
					BEGIN
						WAITFOR DELAY '00:01'
						--Checks for completion ** If not Wait again

					SET @CheckASP = (Select COUNT(*) from [zCust_ServiceMac].[dbo].[ServiceMac_STD])
					END
			END

	WAITFOR DELAY '00:01'

    EXEC [zCust_ServiceMac].[dbo].[usp_100c_sp_ASP_Cust_STD]


	UPdate [zCust_ServiceMac].[dbo].[A]
	Set A.Processed = 'Y'
	From [zCust_ServiceMac].[dbo].[INPUT_IN] as A 
	join [zCust_ServiceMac].[dbo].[a_ASP_IN_STD] as B on A.INPUTKey = B.RAW_ID
	where A.Processed is null


	WAITFOR DELAY '00:01'

		SET @TOTALTOPROCESS = (Select count(*) From [zCust_ServiceMac].[dbo].[INPUT_IN] with(NOLOCK) where [Processed] is null)
				
	END


	


	--Select * From [Addr].[dbo].[STDTrigger] with(NOLOCK)
	--where AppName like 'ServiceMac'
	--Order by CreatedDateTime desc


END



