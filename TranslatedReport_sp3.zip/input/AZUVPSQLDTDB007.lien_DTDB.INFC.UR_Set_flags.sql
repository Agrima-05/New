/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Set_flags | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Set_flags] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2024/06/11	Populate Arms_lenght_id with '0' when not and Arms Lenght transacion
Marie	2024/06/28	Resale_new_construction  - remove ref_id check and add M to source type
Marie	2024/10/14	New Requirements for Pri_cat_Code BUG665022
Marie	2025/10/24	Set transaction Flag to 9 for doctypess AF and TO - B31561

DECLARE @ERROR VARCHAR(500)
	,@Error_Msg VARCHAR(500)

EXEC Lien_dtdb.INFC.UR_Set_flags @ERROR = @ERROR OUTPUT

SET @Error_Msg = @ERROR

IF @Error_Msg IS NOT NULL
BEGIN
	RAISERROR (
			@ERROR
			,16
			,1
			)
END




******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Set_flags'
		,N'Started'

	--BEGIN TRANSACTION
	--
	--			MTG_SELLER_CARRY_BACK
	--
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.MTG1_SELLER_CARRY_BACK = CASE 
			WHEN (
					d.SELLER_NAME_PLAINTIFF_1 = d.MTG1_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_1 = RTRIM(LTRIM((d.MTG1_LENDER_LAST_NAME + ' ' + d.MTG1_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s.last_company_name + ' ' + s.first_name))) = RTRIM(LTRIM((d.MTG1_LENDER_LAST_NAME + ' ' + d.MTG1_LENDER_FIRST_NAME)))
					OR d.SELLER_NAME_PLAINTIFF_2 = d.MTG1_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_2 = RTRIM(LTRIM((d.MTG1_LENDER_LAST_NAME + ' ' + d.MTG1_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s2.last_company_name + ' ' + s2.first_name))) = RTRIM(LTRIM((d.MTG1_LENDER_LAST_NAME + ' ' + d.MTG1_LENDER_FIRST_NAME)))
					)
				--AND ISNULL(d.MTG1_PRIVATE_PARTY_LENDER, '') = 'Y'
				THEN 'Y'
			ELSE NULL
			END
		,d.MTG2_SELLER_CARRY_BACK = CASE 
			WHEN (
					d.SELLER_NAME_PLAINTIFF_1 = d.MTG2_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_1 = RTRIM(LTRIM((d.MTG2_LENDER_LAST_NAME + ' ' + d.MTG2_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s.last_company_name + ' ' + s.first_name))) = RTRIM(LTRIM((d.MTG2_LENDER_LAST_NAME + ' ' + d.MTG2_LENDER_FIRST_NAME)))
					OR d.SELLER_NAME_PLAINTIFF_2 = d.mtg2_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_2 = RTRIM(LTRIM((d.mtg2_LENDER_LAST_NAME + ' ' + d.mtg2_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s2.last_company_name + ' ' + s2.first_name))) = RTRIM(LTRIM((d.mtg2_LENDER_LAST_NAME + ' ' + d.mtg2_LENDER_FIRST_NAME)))
					)
				--AND ISNULL(d.MTG2_PRIVATE_PARTY_LENDER, '') = 'Y'
				THEN 'Y'
			ELSE NULL
			END
		,d.MTG3_SELLER_CARRY_BACK = CASE 
			WHEN (
					d.SELLER_NAME_PLAINTIFF_1 = d.MTG3_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_1 = RTRIM(LTRIM((d.MTG3_LENDER_LAST_NAME + ' ' + d.MTG3_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s.last_company_name + ' ' + s.first_name))) = RTRIM(LTRIM((d.MTG3_LENDER_LAST_NAME + ' ' + d.MTG3_LENDER_FIRST_NAME)))
					OR d.SELLER_NAME_PLAINTIFF_2 = d.mtg3_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_2 = RTRIM(LTRIM((d.mtg3_LENDER_LAST_NAME + ' ' + d.mtg3_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s2.last_company_name + ' ' + s2.first_name))) = RTRIM(LTRIM((d.mtg3_LENDER_LAST_NAME + ' ' + d.mtg3_LENDER_FIRST_NAME)))
					)
				----AND ISNULL(d.MTG3_PRIVATE_PARTY_LENDER, '') = 'Y'
				THEN 'Y'
			ELSE NULL
			END
		,d.MTG4_SELLER_CARRY_BACK = CASE 
			WHEN (
					d.SELLER_NAME_PLAINTIFF_1 = d.MTG4_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_1 = RTRIM(LTRIM((d.MTG4_LENDER_LAST_NAME + ' ' + d.MTG4_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s.last_company_name + ' ' + s.first_name))) = RTRIM(LTRIM((d.MTG4_LENDER_LAST_NAME + ' ' + d.MTG4_LENDER_FIRST_NAME)))
					OR d.SELLER_NAME_PLAINTIFF_2 = d.mtg4_LENDER_LAST_NAME
					OR d.SELLER_NAME_PLAINTIFF_2 = RTRIM(LTRIM((d.mtg4_LENDER_LAST_NAME + ' ' + d.mtg4_LENDER_FIRST_NAME)))
					OR RTRIM(LTRIM((s2.last_company_name + ' ' + s2.first_name))) = RTRIM(LTRIM((d.mtg4_LENDER_LAST_NAME + ' ' + d.mtg4_LENDER_FIRST_NAME)))
					)
				--AND ISNULL(d.MTG4_PRIVATE_PARTY_LENDER, '') = 'Y'
				THEN 'Y'
			ELSE NULL
			END
	FROM [lien_DTDB].[infc].[deed_work] d
	INNER JOIN [lien_dtdb].[infc].[deed_Seller_names] s ON s.doc_id = d.ur_doc_id
		AND s.Combine_NAME = d.SELLER_NAME_PLAINTIFF_1
	LEFT JOIN [lien_dtdb].[infc].[deed_Seller_names] s2 ON s2.doc_id = d.ur_doc_id
		AND s2.Combine_NAME = d.SELLER_NAME_PLAINTIFF_2
	WHERE d.SELLER_NAME_PLAINTIFF_1 IS NOT NULL

	--
	--             RESALE_NEW_CONSTRUCTION
	--
	DROP TABLE

	IF EXISTS #builder -- 146303
		SELECT DISTINCT builder
		INTO #builder
		FROM [Lien].[dbo].[Builder_Standard]
		WHERE Deleted IS NULL

	CREATE INDEX idx_builder ON #builder (builder)

	DELETE -- (1650 rows affected)
	FROM #builder
	WHERE builder IN (
			SELECT Builder
			FROM [Lien_dtdb].[dbo].[GlobalBuilderTbl_nonBuilder]
			)

	DROP TABLE

	IF EXISTS #Name
		SELECT n.doc_id
			,try_cast(substring(n.last_company_name, 1, 60) AS VARCHAR(60)) AS last_company_name
			,try_cast(substring(n.ORIG_MTG_Lender_Name, 1, 60) AS VARCHAR(60)) AS ORIG_MTG_Lender_Name
			,d.rider_construction_loan_flag
		INTO #name
		FROM [lien].[ur].[name] n WITH (
				NOLOCK
				,INDEX (doc_id)
				)
		LEFT JOIN [lien].[ur].[document] d WITH (
				NOLOCK
				,INDEX (pk_document)
				) ON d.doc_id = n.doc_id
		WHERE n.doc_id IN (
				SELECT ur_doc_id
				FROM [lien_DTDB].[INFC].[Deed_work] a WITH (
						NOLOCK
						,INDEX (idx_ur_doc_id)
						)
				WHERE a.deed_type NOT IN ('T')
				)

	CREATE CLUSTERED INDEX idx_doc_id ON #name (doc_id)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.RESALE_NEW_CONSTRUCTION = a1.RESALE_NEW_CONSTRUCTION
	FROM [lien_DTDB].[INFC].[Deed_work] a
	OUTER APPLY (
		SELECT n.doc_id
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.SELLER_NAME_PLAINTIFF_1, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.SELLER_NAME_PLAINTIFF_1
					END) AS SELLER_NAME_PLAINTIFF_1_orig
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.SELLER_NAME_PLAINTIFF_2, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.SELLER_NAME_PLAINTIFF_2
					END) AS SELLER_NAME_PLAINTIFF_2_orig
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.BYR1_OWN_NAME, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.BYR1_OWN_NAME
					END) AS BYR1_OWN_NAME_orig
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.BYR2_OWN_NAME, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.BYR2_OWN_NAME
					END) AS BYR2_OWN_NAME_orig
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.BYR3_OWN_NAME, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.BYR3_OWN_NAME
					END) AS BYR3_OWN_NAME_orig
			,max(CASE 
					WHEN substring(n.last_company_name, 1, 60) = isnull(nn.BYR4_OWN_NAME, '')
						THEN isnull(n.ORIG_MTG_Lender_Name, '')
							--ELSE nn.BYR4_OWN_NAME
					END) AS BYR4_OWN_NAME_orig
			,max(CASE 
					WHEN n.rider_construction_loan_flag = 'Y'
						THEN 'N'
					ELSE NULL
					END) AS RESALE_NEW_CONSTRUCTION
		FROM #name n
		OUTER APPLY (
			SELECT a.SELLER_NAME_PLAINTIFF_1 AS SELLER_NAME_PLAINTIFF_1
				,a.SELLER_NAME_PLAINTIFF_2 AS SELLER_NAME_PLAINTIFF_2
				,a.BYR1_OWN_NAME AS BYR1_OWN_NAME
				,a.BYR2_OWN_NAME AS BYR2_OWN_NAME
				,a.BYR3_OWN_NAME AS BYR3_OWN_NAME
				,a.BYR4_OWN_NAME AS BYR4_OWN_NAME
			) nn
		WHERE n.doc_id IN (a.ur_doc_id)
		GROUP BY n.doc_id
		) n
	OUTER APPLY (
		SELECT CASE 
				WHEN ISNULL(YEAR_built, '') < '1901'
					THEN NULL
				ELSE YEAR_built
				END AS YEAR_built
		FROM [assr].[dbo].[assr] ar WITH (
				NOLOCK
				,INDEX (Idx_FipsRefId)
				)
		WHERE ar.fips = a.fips
			AND ar.ref_id = a.ref_id
		) ar
	--LEFT JOIN assr.dbo.assr ar WITH (
	--		NOLOCK
	--		,INDEX (Idx_FipsRefId)
	--		) ON ar.fips = a.fips
	--	AND ar.ref_id = a.ref_id
	OUTER APPLY (
		SELECT a.SELLER_NAME_PLAINTIFF_1 AS SELLER_NAME_PLAINTIFF_1
			,a.SELLER_NAME_PLAINTIFF_2 AS SELLER_NAME_PLAINTIFF_2
			,n.SELLER_NAME_PLAINTIFF_1_orig AS SELLER_NAME_PLAINTIFF_1_orig
			,n.SELLER_NAME_PLAINTIFF_2_orig AS SELLER_NAME_PLAINTIFF_2_orig
		) b4
	LEFT JOIN #builder b1 WITH (
			NOLOCK
			,INDEX (idx_builder)
			) ON b1.Builder IN (
			b4.SELLER_NAME_PLAINTIFF_1
			,b4.SELLER_NAME_PLAINTIFF_1_orig
			)
	LEFT JOIN #builder b2 WITH (
			NOLOCK
			,INDEX (idx_builder)
			) ON b2.Builder IN (
			b4.SELLER_NAME_PLAINTIFF_2
			,b4.SELLER_NAME_PLAINTIFF_2_orig
			)
	OUTER APPLY (
		SELECT TOP 1 builder
		FROM #builder
		WHERE builder IN (
				coalesce(n.BYR1_OWN_NAME_orig, a.BYR1_OWN_NAME)
				,coalesce(n.BYR2_OWN_NAME_orig, a.BYR2_OWN_NAME)
				,coalesce(n.BYR3_OWN_NAME_orig, a.BYR3_OWN_NAME)
				,coalesce(n.BYR4_OWN_NAME_orig, a.BYR4_OWN_NAME)
				)
		) b3
	OUTER APPLY (
		SELECT CASE 
				WHEN ISNULL(n.RESALE_NEW_CONSTRUCTION, '') = 'N' --- keyed d.rider_construction_loan_flag = 'Y'
					THEN n.RESALE_NEW_CONSTRUCTION
				WHEN (
						-- seller is on the builder table
						isnull(b1.Builder, '') > '' -- IS NOT NULL
						OR isnull(b2.Builder, '') > '' -- IS NOT NULL
						)
					AND (
						ISNULL(n.RESALE_NEW_CONSTRUCTION, '') = 'N' --- may not be needed or redundent
						OR ISNULL(a.MTG1_CONSTRUCTION_LOAN, '') = 'Y' -- DETAILED_DOC_TYPE = 'CL' OR datediff(month, d.recording_date_d, a1.date_of_loan_maturity) < 19
						OR ISNULL(a.SALE_AMOUNT, 0) > 0
						)
					AND isnull(b3.builder, '') = '' -- buyer is not on the builder table
					AND (isnull(a.BYR1_CORP_IND, '') = '')
					AND (
						datepart(year, a.recording_date) - ar.YEAR_built <= 3
						--ar.YEAR_built - datepart(year, a.recording_date) <= 3
						OR (ar.YEAR_BUILT IS NULL)
						)
					THEN 'N'
				WHEN a.Source_Type IN (
						'E'
						,'M'
						)
					AND (
						datepart(year, a.recording_date) - ar.YEAR_built <= 3
						--ar.YEAR_built - datepart(year, a.recording_date) <= 3
						OR (ar.YEAR_BUILT IS NULL)
						)
					AND (
						isnull(a.seller_NAME_PLAINTIFF1_CORP_IND, '') = 'Y'
						OR isnull(a.seller_NAME_PLAINTIFF_2_CORP_IND, '') = 'Y'
						)
					AND (isnull(a.BYR1_CORP_IND, '') = '')
					AND ISNULL(n.RESALE_NEW_CONSTRUCTION, '') <> 'N' --- redundent
					AND isnull(b3.builder, '') = '' -- buyer is not on the builder table
					AND (
						isnull(b1.Builder, '') > '' -- seller1 is a builder
						OR isnull(b2.Builder, '') > '' -- selelr2 is a builder
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%CONST %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%CONST %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%CUSTOM %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%CUSTOM %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%CONSTR%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%CONSTR%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%BLDG%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%BLDG%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%BLDRS%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%BLDRS%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%DEV%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%DEV%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%BUILD%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%BUILD%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%BLRS%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%BLRS%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%CONTR%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%CONTR%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1, '') LIKE '%HOME%'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_1_orig, '') LIKE '%HOME%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%CONST %'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%CONST %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_2, '') LIKE '%CUSTOM %'
						OR isnull(b4.SELLER_NAME_PLAINTIFF_2_orig, '') LIKE '%CUSTOM %'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%CONSTR%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%CONSTR%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%BLDG%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%BLDG%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%BLDRS%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%BLDRS%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%DEV%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%DEV%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%BUILD%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%BUILD%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%BLRS%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%BLRS%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%CONTR%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%CONTR%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2, '') LIKE '%HOME%'
						OR isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') LIKE '%HOME%'
						)
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%Mobile home%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%Mobile home%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%Mobile home%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%Mobile home%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%Urban dev%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%Urban dev%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%Urban dev%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%Urban dev%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%Open%door%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%Open%door%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%Open%door%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%Open%door%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%Constable%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%Constable%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%Constable%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%Constable%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%federal home loan%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%federal home loan%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%federal home loan%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%federal home loan%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%home loans%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%home loans%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%home loans%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%home loans%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%ECONOMIC DEVELOPMENT CORP%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%ECONOMIC DEVELOPMENT CORP%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%ECONOMIC DEVELOPMENT CORP%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%ECONOMIC DEVELOPMENT CORP%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%REDEVELOPMENT%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%REDEVELOPMENT%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%REDEVELOPMENT%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%REDEVELOPMENT%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%disney%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%disney%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%disney%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%disney%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%resort%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%resort%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%resort%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%resort%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%rentals%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%rentals%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%rentals%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%rentals%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%FUND %'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%FUND %'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%FUND %'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%FUND %'
					AND isnull(b4.seller_NAME_PLAINTIFF_1, '') NOT LIKE '%AUTHORITY%'
					AND isnull(b4.seller_NAME_PLAINTIFF_1_orig, '') NOT LIKE '%AUTHORITY%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2, '') NOT LIKE '%AUTHORITY%'
					AND isnull(b4.seller_NAME_PLAINTIFF_2_orig, '') NOT LIKE '%AUTHORITY%'
					THEN 'N'
				ELSE 'M'
				END AS RESALE_NEW_CONSTRUCTION
		) a1
	WHERE isnull(a.RESALE_NEW_CONSTRUCTION, '') <> isnull(a1.RESALE_NEW_CONSTRUCTION, '')
		AND a.deed_type NOT IN ('T')

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.RESALE_NEW_CONSTRUCTION = 'M'
	--- marie change
	FROM [lien_DTDB].[INFC].[Deed_work] a
	WHERE isnull(a.RESALE_NEW_CONSTRUCTION, '') = 'N'
		AND (
			a.SELLER_NAME_PLAINTIFF_1 LIKE '%Zillow%'
			OR a.SELLER_NAME_PLAINTIFF_2 LIKE '%Zillow%'
			)
		AND a.deed_type NOT IN ('T')

	--
	--             Forclosure, Foreclosure_Flag
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.Forclosure = a3.Forclosure
		,a.FORECLOSURE_FLAG = a1.Fore_closure_flag1
	FROM [lien_DTDB].[INFC].[Deed_work] a
	OUTER APPLY (
		SELECT CASE 
				WHEN Ltrim(rtrim(a.DEED_TYPE)) = 'U'
					THEN 1
				ELSE 0
				END AS Fore_closure_flag1
		) a1
	OUTER APPLY (
		SELECT CASE 
				WHEN a1.Fore_closure_flag1 = '1'
					THEN 'Y'
				ELSE NULL
				END AS Forclosure
		) a3
	WHERE isnull(a.FORCLOSURE, '') <> isnull(a3.Forclosure, '')
		--OR isnull(a.foreclosure_Flag, '') <> a1.Fore_closure_flag1
		OR a.foreclosure_Flag <> a1.Fore_closure_flag1

	--
	-- for transaction type we need the following indicators set and this needs to happend after the mtg merge
	--   RESALE_NEW_CONSTRUCTION
	--   MAP_TYPE_IND
	--
	--			TRANSACTION_TYPE
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.TRANSACTION_TYPE = a1.TRANSACTION_TYPE
	FROM [lien_DTDB].[INFC].[Deed_work] a
	OUTER APPLY (
		SELECT CASE 
				WHEN a.detailed_doc_type IN (
						'AF'
						,'TO'
						)
					THEN '9'
				WHEN ISNULL(a.RESALE_NEW_CONSTRUCTION, '') = 'N'
					AND a.DEED_TYPE IN (
						'Q'
						,'G'
						)
					THEN '3'
				WHEN (
						ISNULL(a.SELLER_NAME_PLAINTIFF1_CORP_IND, '') = 'Y'
						AND ISNULL(a.SELLER_NAME_PLAINTIFF_1, '') = ISNULL(a.MTG1_LENDER_LAST_NAME, '')
						AND ISNULL(a.MTG1_LENDER_LAST_NAME, '') > ''
						)
					OR (
						ISNULL(a.MTG1_PRIVATE_PARTY_LENDER, '') = 'Y'
						AND ISNULL(a.SELLER_NAME_PLAINTIFF_1, '') = ISNULL(a.MTG1_LENDER_LAST_NAME, '') + ' ' + SUBstring(ISNULL(a.MTG1_LENDER_FIRST_NAME, ''), 1, 1)
						AND ISNULL(a.MTG1_LENDER_LAST_NAME, '') > ''
						)
					OR (ISNULL(a.SELLER_NAME_PLAINTIFF_1, '') = ISNULL(a.MTG2_LENDER_LAST_NAME, '') + ' ' + SUBstring(ISNULL(a.MTG2_LENDER_FIRST_NAME, ''), 1, 1))
					AND ISNULL(a.MTG2_LENDER_LAST_NAME, '') > ''
					OR (
						SUBSTRING(ISNULL(a.SELLER_NAME_PLAINTIFF_1, ''), 1, 10) = SUBSTRING((ISNULL(a.MTG1_LENDER_LAST_NAME, '') + ' ' + ISNULL(a.MTG1_LENDER_FIRST_NAME, '')), 1, 10)
						AND ISNULL(a.MTG1_LENDER_LAST_NAME, '') > ''
						)
					OR (
						ISNULL(a.MTG1_PRIVATE_PARTY_LENDER, '') = 'Y'
						AND ISNULL(a.SELLER_NAME_PLAINTIFF_2, '') = ISNULL(a.MTG1_LENDER_LAST_NAME, '') + ' ' + substring(ISNULL(a.MTG1_LENDER_FIRST_NAME, ''), 1, 1)
						AND ISNULL(a.MTG1_LENDER_LAST_NAME, '') > ''
						)
					OR (
						SUBSTRING(ISNULL(a.SELLER_NAME_PLAINTIFF_1, ''), 1, 10) = SUBSTRING((ISNULL(a.MTG2_LENDER_LAST_NAME, '') + ' ' + ISNULL(a.MTG2_LENDER_FIRST_NAME, '')), 1, 10)
						AND ISNULL(a.MTG2_LENDER_LAST_NAME, '') > ''
						)
					OR (ISNULL(a.SELLER_NAME_PLAINTIFF_2, '') = ISNULL(a.MTG2_LENDER_LAST_NAME, '') + ' ' + SUBstring(ISNULL(a.MTG2_LENDER_FIRST_NAME, ''), 1, 1))
					AND ISNULL(a.MTG2_LENDER_LAST_NAME, '') > ''
					THEN '7'
				WHEN ISNULL(a.MTG1_MTG_LOAN_TYPE_CODE, '') = 'PP'
					AND SUBstring(a.SELLER_NAME_PLAINTIFF_1, 1, 4) = SUBstring(a.MTG1_LENDER_LAST_NAME, 1, 4)
					AND ISNULL(a.MTG2_LENDER_LAST_NAME, '') > ''
					THEN '7'
				WHEN ISNULL(a.MAP_TYPE_IND, '') = 'V'
					THEN '4'
				WHEN a.US_STATE NOT IN (
						SELECT CODEVALUE
						FROM [lien].[dbo].[CodeTable]
						WHERE TABLESHORTNAME = 'NonDisc'
						)
					AND a.DEED_TYPE IN (
						'Q'
						,'G'
						,'U'
						)
					AND isnull(a.sALE_aMOUNT, 0) <= 500
					AND isnull(a.DOC_TRANSFER_TAX, 0) <= 10.00
					THEN '9'
				WHEN a.US_STATE IN (
						SELECT CODEVALUE
						FROM [lien].[dbo].[CodeTable]
						WHERE TABLESHORTNAME = 'NonDisc'
						)
					AND a.DEED_TYPE IN (
						'Q'
						,'G'
						,'U'
						)
					AND ISNULL(a.INTER_FAMILY, '') IN (
						'X'
						,'Y'
						)
					THEN '9'
				WHEN a.DEED_TYPE = 'T'
					AND (
						ISNULL(a.MTG1_CONSTRUCTION_LOAN, '') = 'Y'
						OR ISNULL(a.MTG1_MTG_LOAN_TYPE_CODE, '') = 'CL'
						)
					THEN '6'
				WHEN a.DEED_TYPE = 'T'
					THEN '2'
				ELSE '1'
				END AS TRANSACTION_TYPE
		) a1
	WHERE isnull(a.TRANSACTION_TYPE, '') <> isnull(a1.TRANSACTION_TYPE, '')

	--
	--			PRI_CAT_CODE, ARMS_EKNGTH_ID
	--
	UPDATE [lien_DTDB].[INFC].[w]
	SET w.PRI_CAT_CODE = d.PRI_CAT_CODE
		,w.ARMS_LENGTH_ID = CASE 
			WHEN d.PRI_CAT_CODE = 'A'
				AND w.TRANSACTION_TYPE NOT IN ('9') --  us31561
				THEN 1
			ELSE 0
			END
	FROM [lien_DTDB].[infc].[deed_Work] w
	OUTER APPLY (
		SELECT *
		FROM [lien].[dbo].[codetable] t
		WHERE t.tableshortname = 'nondisc'
			AND t.CodeValue = W.US_STATE
		) t
	OUTER APPLY (
		SELECT CASE 
				WHEN w.SALE_AMOUNT = 0.00
					THEN 0
				ELSE (w.MTG1_MTG_AMOUNT / w.SALE_AMOUNT) * 100
				END AS LTV_Calculation
		) l
	OUTER APPLY (
		SELECT CASE 
				WHEN isnull(deed_type, '') = 'U'
					OR isnull(foreclosure_flag, 0) = 1 --'Y'
					THEN 'B'
				WHEN isnull(deed_type, '') = 'T'
					THEN 'D'
				WHEN t.CodeValue IS NULL -- this is for disclosure counties
					THEN CASE 
							WHEN (
									(
										w.Recording_date >= '2015-01-01'
										AND isnull(sale_amount, 0) > 30000
										)
									OR (
										w.Recording_date < '2015-01-01'
										AND isnull(sale_amount, 0) > 15000
										)
									)
								AND isnull(mtg1_mtg_amount, 0) > 0
								AND ISNULL(LTV_Calculation, 0) BETWEEN 1
									AND 135
								AND isnull(inter_family, '') = ''
								AND isnull(sale_code, '') <> 'P'
								AND isnull(partial_interest_ind, '') <> 'Y'
								AND isnull(detailed_doc_type, '') NOT IN (
									'CD'
									,'RD'
									,'AF'
									,'TO'
									)
								THEN 'A'
							WHEN isnull(sale_amount, 0) > 0
								AND isnull(mtg1_mtg_amount, 0) > 0
								AND (
									ISNULL(LTV_Calculation, 0) < 1.00
									OR ISNULL(LTV_Calculation, 0) > 135.00
									)
								THEN 'B'
							WHEN (
									(
										w.Recording_date >= '2015-01-01'
										AND isnull(sale_amount, 0) > 30000
										)
									OR (
										w.Recording_date < '2015-01-01'
										AND isnull(sale_amount, 0) > 15000
										)
									)
								AND isnull(inter_family, '') = ''
								AND isnull(sale_code, '') <> 'P'
								AND isnull(partial_interest_ind, '') <> 'Y'
								AND isnull(detailed_doc_type, '') NOT IN (
									'CD'
									,'RD'
									,'AF'
									,'TO'
									)
								THEN 'A'
							WHEN (
									(
										(
											w.Recording_date >= '2015-01-01'
											AND isnull(sale_amount, 0) < 30001
											)
										OR (
											w.Recording_date < '2015-01-01'
											AND isnull(sale_amount, 0) < 15001
											)
										)
									OR isnull(inter_family, '') IN (
										'X'
										,'Y'
										)
									OR isnull(partial_interest_ind, '') = 'Y'
									OR isnull(sale_code, '') = 'P'
									)
								AND isnull(detailed_doc_type, '') NOT IN (
									'CD'
									,'RD'
									,'AF'
									,'TO'
									)
								THEN 'B'
							WHEN isnull(sale_amount, 0) = 0
								OR isnull(detailed_doc_type, '') IN (
									'CD'
									,'RD'
									,'AF'
									,'TO'
									)
								THEN 'C'
							ELSE NULL
							END
				ELSE -- non disclosure states
					CASE 
						WHEN isnull(sale_amount, 0) = 0
							AND isnull(mtg1_mtg_amount, 0) = 0
							AND isnull(inter_family, '') = ''
							AND isnull(Partial_Interest_ind, '') <> 'Y'
							AND isnull(detailed_doc_type, '') NOT IN (
								'CD'
								,'RD'
								,'AF'
								,'TO'
								)
							THEN 'A'
						WHEN (
								(
									w.Recording_date >= '2015-01-01'
									AND isnull(sale_amount, 0) > 30000
									)
								OR (
									w.Recording_date < '2015-01-01'
									AND isnull(sale_amount, 0) > 15000
									)
								)
							AND isnull(inter_family, '') = ''
							AND isnull(Partial_Interest_ind, '') <> 'Y'
							AND isnull(detailed_doc_type, '') NOT IN (
								'CD'
								,'RD'
								,'AF'
								,'TO'
								)
							THEN 'A'
						WHEN (
								(
									w.Recording_date >= '2015-01-01'
									AND isnull(sale_amount, 0) <= 30000
									)
								OR (
									w.Recording_date < '2015-01-01'
									AND isnull(sale_amount, 0) <= 15000
									)
								)
							AND (
								isnull(inter_family, '') = ''
								OR isnull(Partial_Interest_ind, '') = 'Y'
								)
							AND isnull(detailed_doc_type, '') NOT IN (
								'CD'
								,'RD'
								,'AF'
								,'TO'
								)
							THEN 'B'
						WHEN isnull(inter_family, '') IN (
								'X'
								,'Y'
								)
							AND isnull(Sale_code, '') <> 'E'
							AND isnull(detailed_doc_type, '') NOT IN (
								'CD'
								,'RD'
								,'AF'
								,'TO'
								)
							THEN 'B'
						WHEN (
								(
									isnull(inter_family, '') IN (
										'X'
										,'Y'
										)
									AND isnull(Sale_code, '') = 'E'
									)
								OR isnull(detailed_doc_type, '') IN (
									'CD'
									,'RD'
									,'AF'
									,'TO'
									)
								)
							THEN 'C'
						ELSE NULL
						END
				END AS PRI_CAT_CODE
		) d

	--
	-- set MTG1_MTG_INTEREST_RATE_TYPE to FIX for conditions below
	--
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.MTG1_MTG_INTEREST_RATE_TYPE = b.MTG1_MTG_INTEREST_RATE_TYPE
		--,a.Mtg1_Int_Source = CASE 
		--	WHEN isnull(b.MTG1_MTG_INTEREST_RATE_TYPE, '') = 'FIX'
		--		THEN 'EST'
		--	ELSE a.Mtg1_Int_Source
		--	END
		,a.MTG2_MTG_INTEREST_RATE_TYPE = b.MTG2_MTG_INTEREST_RATE_TYPE
		--,a.Mtg2_Int_Source = CASE 
		--	WHEN isnull(b.MTG2_MTG_INTEREST_RATE_TYPE, '') = 'FIX'
		--		THEN 'EST'
		--	ELSE a.Mtg2_Int_Source
		--	END
		,a.MTG3_MTG_INTEREST_RATE_TYPE = b.MTG3_MTG_INTEREST_RATE_TYPE
		--,a.Mtg3_Int_Source = CASE 
		--	WHEN isnull(b.MTG3_MTG_INTEREST_RATE_TYPE, '') = 'FIX'
		--		THEN 'EST'
		--	ELSE a.Mtg3_Int_Source
		--	END
		,a.MTG4_MTG_INTEREST_RATE_TYPE = b.MTG4_MTG_INTEREST_RATE_TYPE
		--,a.Mtg4_Int_Source = CASE 
		--	WHEN isnull(b.MTG4_MTG_INTEREST_RATE_TYPE, '') = 'FIX'
		--		THEN 'EST'
		--	ELSE a.Mtg4_Int_Source
		--	END
	FROM [lien_DTDB].[infc].[deed_Work] a
	OUTER APPLY (
		SELECT MTG1_MTG_INTEREST_RATE_TYPE = CASE 
				WHEN a.MTG1_MTG_LOAN_TYPE_CODE = 'CNV'
					AND isnull(a.MTG1_MTG_INTEREST_RATE_TYPE, '') = ''
					AND isnull(a.MTG1_MTG_DUE_DATE, '') > ''
					AND isnull(a.MTG1_SELLER_CARRY_BACK, '') = ''
					AND isnull(a.MTG1_PRIVATE_PARTY_LENDER, '') = ''
					THEN 'FIX' -- 'EST'
				ELSE MTG1_MTG_INTEREST_RATE_TYPE
				END
			,MTG2_MTG_INTEREST_RATE_TYPE = CASE 
				WHEN a.MTG2_MTG_LOAN_TYPE_CODE = 'CNV'
					AND isnull(a.MTG2_MTG_INTEREST_RATE_TYPE, '') = ''
					AND isnull(a.MTG2_MTG_DUE_DATE, '') > ''
					AND isnull(a.MTG2_SELLER_CARRY_BACK, '') = ''
					AND isnull(a.MTG2_PRIVATE_PARTY_LENDER, '') = ''
					THEN 'FIX' -- 'EST'
				ELSE MTG2_MTG_INTEREST_RATE_TYPE
				END
			,MTG3_MTG_INTEREST_RATE_TYPE = CASE 
				WHEN a.MTG3_MTG_LOAN_TYPE_CODE = 'CNV'
					AND isnull(a.MTG3_MTG_INTEREST_RATE_TYPE, '') = ''
					AND isnull(a.MTG3_MTG_DUE_DATE, '') > ''
					AND isnull(a.MTG3_SELLER_CARRY_BACK, '') = ''
					AND isnull(a.MTG3_PRIVATE_PARTY_LENDER, '') = ''
					THEN 'FIX' -- 'EST'
				ELSE MTG3_MTG_INTEREST_RATE_TYPE
				END
			,MTG4_MTG_INTEREST_RATE_TYPE = CASE 
				WHEN a.MTG4_MTG_LOAN_TYPE_CODE = 'CNV'
					AND isnull(a.MTG4_MTG_INTEREST_RATE_TYPE, '') = ''
					AND isnull(a.MTG4_MTG_DUE_DATE, '') > ''
					AND isnull(a.MTG4_SELLER_CARRY_BACK, '') = ''
					AND isnull(a.MTG4_PRIVATE_PARTY_LENDER, '') = ''
					THEN 'FIX' -- 'EST'
				ELSE MTG4_MTG_INTEREST_RATE_TYPE
				END
		) b
	WHERE (
			isnull(b.MTG1_MTG_INTEREST_RATE_TYPE, '') <> isnull(a.MTG1_MTG_INTEREST_RATE_TYPE, '')
			OR isnull(b.MTG2_MTG_INTEREST_RATE_TYPE, '') <> isnull(a.MTG2_MTG_INTEREST_RATE_TYPE, '')
			OR isnull(b.MTG3_MTG_INTEREST_RATE_TYPE, '') <> isnull(a.MTG3_MTG_INTEREST_RATE_TYPE, '')
			OR isnull(b.MTG4_MTG_INTEREST_RATE_TYPE, '') <> isnull(a.MTG4_MTG_INTEREST_RATE_TYPE, '')
			)

	----
	----	Remove name duplicates
	----
	--UPDATE d
	--SET d.BYR2_CORP_IND = NULL
	--	,d.BYR2_OWN_NAME = NULL
	--	,d.BYR2_OWNERSHIP_RIGHTS_CODE = NULL
	--	,d.BYR2_OWN_RELATIONSHIP_TYPE = NULL
	--	,d.BYR2_OWNERSHIP = NULL
	--	,d.BYR2_LAST_NAME = NULL
	--	,d.BYR2_FIRST_NAME = NULL
	--	,d.BYR2_MIDDLE_INITIAL = NULL
	--	,d.BYR2_SUFFIX = NULL
	--FROM lien_DTDB.INFC.Deed_work d
	--WHERE d.BYR1_OWN_NAME = d.BYR2_OWN_NAME
	--	AND d.BYR1_OWN_NAME NOT LIKE '%&%'
	--UPDATE d
	--SET d.BYR3_CORP_IND = NULL
	--	,d.BYR3_OWN_NAME = NULL
	--	,d.BYR3_OWNERSHIP_RIGHTS_CODE = NULL
	--	,d.BYR3_OWN_RELATIONSHIP_TYPE = NULL
	--	,d.BYR3_OWNERSHIP = NULL
	--	,d.BYR3_LAST_NAME = NULL
	--	,d.BYR3_FIRST_NAME = NULL
	--	,d.BYR3_MIDDLE_INITIAL = NULL
	--	,d.BYR3_SUFFIX = NULL
	--FROM lien_DTDB.INFC.Deed_work d
	--WHERE d.BYR2_OWN_NAME = d.BYR3_OWN_NAME
	--	AND d.BYR2_OWN_NAME NOT LIKE '%&%'
	--UPDATE d
	--SET d.BYR4_CORP_IND = NULL
	--	,d.BYR4_OWN_NAME = NULL
	--	,d.BYR4_OWNERSHIP_RIGHTS_CODE = NULL
	--	,d.BYR4_OWN_RELATIONSHIP_TYPE = NULL
	--	,d.BYR4_OWNERSHIP = NULL
	--	,d.BYR4_LAST_NAME = NULL
	--	,d.BYR4_FIRST_NAME = NULL
	--	,d.BYR4_MIDDLE_INITIAL = NULL
	--	,d.BYR4_SUFFIX = NULL
	--FROM lien_DTDB.INFC.Deed_work d
	--WHERE d.BYR3_OWN_NAME = d.BYR4_OWN_NAME
	--	AND d.BYR3_OWN_NAME NOT LIKE '%&%'
	--UPDATE d
	--SET d.BYR4_CORP_IND = NULL
	--	,d.BYR4_OWN_NAME = NULL
	--	,d.BYR4_OWNERSHIP_RIGHTS_CODE = NULL
	--	,d.BYR4_OWN_RELATIONSHIP_TYPE = NULL
	--	,d.BYR4_OWNERSHIP = NULL
	--	,d.BYR4_LAST_NAME = NULL
	--	,d.BYR4_FIRST_NAME = NULL
	--	,d.BYR4_MIDDLE_INITIAL = NULL
	--	,d.BYR4_SUFFIX = NULL
	--FROM lien_DTDB.INFC.Deed_work d
	--WHERE d.BYR4_OWN_NAME = d.BYR1_OWN_NAME
	--	AND d.BYR4_OWN_NAME NOT LIKE '%&%'
	--select MTG1_SELLER_CARRY_BACK,MTG2_SELLER_CARRY_BACK,MTG3_SELLER_CARRY_BACK,MTG4_SELLER_CARRY_BACK,*
	--from lien_DTDB.infc.deed d
	--where ur_doc_id in (218394102,219366766 )
	/*

UPDATE a
SET a.MTG1_SELLER_CARRY_BACK = NULL
	,a.MTG2_SELLER_CARRY_BACK = NULL
	,a.MTG3_SELLER_CARRY_BACK = NULL
	,a.MTG4_SELLER_CARRY_BACK = NULL
FROM lien_DTDB.infc.deed a

select MTG1_SELLER_CARRY_BACK,MTG2_SELLER_CARRY_BACK,MTG3_SELLER_CARRY_BACK,MTG4_SELLER_CARRY_BACK,*
SELECT CASE 
		WHEN SELLER_NAME_PLAINTIFF_1 = MTG1_LENDER_LAST_NAME
			OR SELLER_NAME_PLAINTIFF_1 = MTG1_LENDER_LAST_NAME + ' ' + MTG1_LENDER_FIRST_NAME
			THEN 'Y'
		ELSE NULL
		END AS MTG1_SELLER_CARRY_BACK
	,SELLER_NAME_PLAINTIFF_1
	,MTG1_LENDER_LAST_NAME
	,MTG1_LENDER_LAST_NAME
	,MTG1_LENDER_FIRST_NAME
	,ur_doc_id
	,*

FROM lien_DTDB.infc.deed_work
where CASE 
		WHEN SELLER_NAME_PLAINTIFF_1 = MTG1_LENDER_LAST_NAME
			OR SELLER_NAME_PLAINTIFF_1 = MTG1_LENDER_LAST_NAME + ' ' + MTG1_LENDER_FIRST_NAME
			THEN 'Y'
		ELSE NULL
		END  = 'y'


*/
	--select top 100 ur_doc_id, MTG1_SELLER_CARRY_BACK ,* from deed.dbo.deed
	--where MTG2_SELLER_CARRY_BACK is not null
	--order by deedid desc
	--COMMIT
	--select 1/0
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Set_flags'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


