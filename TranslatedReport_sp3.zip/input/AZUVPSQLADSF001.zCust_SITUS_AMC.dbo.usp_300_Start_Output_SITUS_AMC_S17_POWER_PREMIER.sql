SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- ============================================
-- Description:	Process OUTPUT
-- =============================================
CREATE PROCEDURE [zCust_SITUS_AMC].[dbo].[usp_300_Start_Output_SITUS_AMC_S17_POWER_PREMIER]

AS
BEGIN
	
	SET NOCOUNT ON;

	---- DROP and Re-Create the custom OUTPUT table

		DROP TABLE [dbo].[x_Custom_OUTPUT_AVM]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_AVM](
			[FIPS] [varchar](5) NULL,
			[PROPERTYID] [bigint] NULL,
			[INPUT DealID][varchar](250)NULL,
			[INPUT Solution ID][varchar](250)NULL,
			[INPUT Unique RecordID][varchar](250)NULL,
			[INPUT Address][varchar](250)NULL,
			[INPUT City][varchar](250)NULL,
			[INPUT State][varchar](250)NULL,
			[INPUT Zip][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Report Date][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[AVM Coverage][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Event Status][varchar](250)NULL,
		
			[FinalValue][varchar](250)NULL,
			[HighValue][varchar](250)NULL,
			[LowValue][varchar](250)NULL,
			[ConfidenceScore][varchar](250)NULL,
			[StandardDeviation][varchar](250)NULL,
			[ValuationDate][varchar](250)NULL

		) ON [PRIMARY]


	---- POPULATE OUTPUT with Customer Provided Data
		INSERT INTO [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] ([INPUT DealID],[INPUT Solution ID],[INPUT Unique RecordID],[INPUT Address],[INPUT City],[INPUT State]
		,[INPUT Zip])
		Select 
		[Deal ID]
      ,[Solution ID]
      --,convert(bigint,[Unique RecordID])
	  ,[Unique RecordID]
      ,[Address]
      ,[City]
      ,[State]
      ,[Zip]
     FROM 
	 --[dbo].INPUT_RAW_351184VND
	  --[dbo].INPUT_RAW_351325VND
	  INPUT_RAW_CUST
	  where ISNULL([Unique RecordID],'0') not like '0'
	and [Unique RecordID] not like ''
	and [Unique RecordID] is not null
	
		
		Select * From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]


		UPDATE [zCust_SITUS_AMC].[dbo].[a] 
		SET a.PROPERTYID = c.PROPERTYID
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a JOIN 
		[zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c on a.[INPUT Unique RecordID] = c.RAW_ID



		
		Update [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.City = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Report Date] = Convert(date,GetDate())
		, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a JOIN [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] c
					ON a.[INPUT Unique RecordID] = c.RAW_ID

	
		-------POWER AND PREMIER------
		Update [zCust_SITUS_AMC].[dbo].[a]
		set [AVM Coverage] = 1
		--Select B.*
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a JOIN 
		(Select FIPS, count(*) T from [data].[dbo].[vAVM_Holocron] with(NOLOCK)
		where FIPS in 
			(Select Distinct FIPS From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] with(NOLOCK)
			where FIPS is not null)
		Group by FIPS) B  
		ON a.FIPS = b.FIPS
		
		
		---------USES INPUT SOLUTION CODE TO DETERMINE WHICH AVM TO RETURN!!!!----
		--s17_pr = Procision PREMIER AVM
		--s17_pw = Procision Power AVM

		IF (Select count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] with(NOLOCK) 
		where [INPUT Solution ID] like 's17_pw') > 1

		BEGIN

		UPDATE [zCust_SITUS_AMC].[dbo].[A]
		SET 
	
		A.FinalValue = convert(bigint,convert(Money,B.[POWER_FInal_Value]))
		,A.HighValue = convert(bigint,convert(Money,B.[POWER_HIGH_Value]))
		,A.LowValue = convert(bigint,convert(Money,B.[POWER_LOW_Value]))
		,A.ConfidenceScore = B.[POWER_CONFIDENCE_SCORE]
		,A.StandardDeviation = B.[POWER_FORECAST_STANDARD_DEVIATION]
		,A.ValuationDate = Convert(date,B.[ValuationDate])
		
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  B.POWER_FINAL_VALUE > 0


		END


		
		IF (Select count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] with(NOLOCK) 
		where [INPUT Solution ID] like 's17_pr') > 1

		BEGIN

		UPDATE [zCust_SITUS_AMC].[dbo].[A]
		SET 
	
		A.FinalValue = convert(bigint,convert(Money,B.PREMIER_FINAL_VALUE))
		,A.HighValue = convert(bigint,convert(Money,B.PREMIER_HIGH_VALUE))
		,A.LowValue = convert(bigint,convert(Money,B.PREMIER_LOW_VALUE))
		,A.ConfidenceScore = B.PREMIER_CONFIDENCE_SCORE
		,A.StandardDeviation = B.PREMIER_FORECAST_STANDARD_DEVIATION
		,A.ValuationDate = Convert(date,B.[ValuationDate])
		
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  B.PREMIER_FINAL_VALUE > 0


		END

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] 
		SET [AVM Coverage] = CASE WHEN [AVM Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_SITUS_AMC].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a JOIN [zCust_SITUS_AMC].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT Unique RecordID] = b.Raw_ID

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		SET [Property Status] = CASE WHEN PROPERTYID is not null THEN 'Property Found' ELSE 'Property Not Found' END
		
		UPDATE [zCust_SITUS_AMC].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM] a join [zCust_SITUS_AMC].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUT Unique RecordID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'

		

		Update [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		SET [Event Status] = CASE WHEN FinalValue > 0  THEN 'Event Found' ELSE 'Event Not Found' END

		Select [AVM Coverage], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		Group by [AVM Coverage]

		Select [Property Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		Group by [Address Standardization]

		Select [Event Status], count(*) From [zCust_SITUS_AMC].[dbo].[x_Custom_OUTPUT_AVM]
		Group by [Event Status]

		


		--Select * From [x_Custom_OUTPUT_AVM]


END



