/* Source: DWS-ETL02.DATATREE.LOCAL | spdb | dbo.usp_PEt_Apn_Creation_0_Get_Fips_list | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- =============================================
CREATE PROCEDURE [SPDB].[dbo].[usp_PEt_Apn_Creation_0_Get_Fips_list] @fips INT = NULL
	,@Apn_type VARCHAR(5) = NULL
	,@list_Sql INT = 0
AS
DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	2022/02/18	Set tupdate to status to rerun all counties un il the problem with the daily updates are solved
******************************************************************************************************************/
--IF @list_Sql = 0
--BEGIN
--	EXEC MiNelson.dbo.[AddNtpLog] N'info'
--		,N'usp_PEt_Apn_Creation_3_update_control begin'
--		,@mess
--END

--update a set a.Status = 'To_Be_Processed'
--from pet.dbo.PET_APN_Additional_Formats a



SELECT   [FIPS]
          ,apn_type
  FROM [PEt].[dbo].[PET_APN_Additional_Formats]
  where Status = 'To_Be_Processed'


--DECLARE @sql_cmd VARCHAR(max)
--DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
--	,@Rule VARCHAR(max) = NULL --
--	,@Status VARCHAR(20) = NULL --'To_Be_Processed'
--	,@node_delimeter VARCHAR(10) = NULL --'-'

--UPDATE a
--SET a.STATUS = 'Processed'
--FROM verifiedrecord.dbo.PET_APN_Additional_Formats a
--WHERE a.fips = @fips
--	AND a.apn_type = @apn_type

--IF @list_Sql = 0
--BEGIN
--EXEC ntp.Stage.[AddNtpLog] N'info'
--	,N'usp_PEt_Apn_Creation_3_update_control END'
--	,@mess
--end


