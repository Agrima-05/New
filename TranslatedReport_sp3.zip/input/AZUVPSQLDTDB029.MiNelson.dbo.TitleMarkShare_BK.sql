/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.TitleMarkShare_BK | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 4/01/2015
-- Description:	Create MarkShareTitle_Temp1 and MarkShareTitle_Temp2 tables for Markshare_Title job
-- ================================================================================================



CREATE PROCEDURE [MiNelson].[dbo].[TitleMarkShare_BK]
                 
AS 


SET NOCOUNT ON

BEGIN

    IF OBJECT_ID('mktshr.Marketshare_Deed_BK_Final') IS NOT NULL DROP TABLE  mktshr.Marketshare_Deed_BK_Final

 ---------------------------BK Data ---------------------------------
 
       IF OBJECT_ID('mktshr.Marketshare_Deed_BK') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK 

   
 
 select
  MTG1_CONSTRUCTION_LOAN,
  REO_SALE_FLAG, 
  REO_SALE ,
  TRANSACTION_TYPE,
  MTG1_MTG_AMOUNT ,
  Fips ,
  MTG1_EQUITY_FLAG ,
   MTG1_OTHER_SUBORDINATE_LOANS,
   MTG1_LENDER_LAST_NAME,
   TITLE_COMPANY_NAME   ,
        MULTI_APN, 
          RECORDING_DATE,
          SALE_DATE,
          DOC_NBR,
           Recording_Book,
           Recording_Page,
           DeedId,MTG1_DOC_NBR,
           DETAILED_DOC_TYPE,
           SALE_AMOUNT,
           MTG1_MTG_INTEREST_RATE_TYPE ,
           MTG1_MTG_LOAN_TYPE_CODE
  ,SELLER_NAME_PLAINTIFF_1
   ,BYR1_OWN_NAME,BYR1_CORP_IND ,SITUS_CITY,US_COUNTY,US_STATE ,SITUS_ZIP_CODE,
   TITLE_COMPANY_CODE,
         DEED_TYPE, UPDATED,
      FORCLOSURE,
      RESALE_NEW_CONSTRUCTION,
        MTG1_PRIVATE_PARTY_LENDER,
       SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Sales_Source_Ind,      ---------------------change 2/4/2016 to filter AZ affidavits
       REF_ID  ,                  ---------------------Added for update Attorney names 3/14/2016
   source_type, SRC_TBL, CLGX_UNIQUE_ID, MTG2_DOC_NBR, MTG2_MTG_AMOUNT, MTG2_CONSTRUCTION_LOAN, MTG2_EQUITY_FLAG, MTG2_LENDER_LAST_NAME, MTG2_MTG_INTEREST_RATE_TYPE
   ,[MTG1_RECORDING_DATE], [MTG1_DOC_DATE], [MTG1_RECORDING_BOOK],[MTG1_RECORDING_PAGE] , [MTG1_DETAILED_DOC_TYPE] ,[MTG1_LENDER_FIRST_NAME],[MTG1_LENDER_ADDRESS] ,[MTG1_LENDER_CITY] ,[MTG1_LENDER_STATE] ,[MTG1_LENDER_ZIP],[MTG1_MTG_COMPANY_CODE]
   , [MTG1_MTG_TERM_CODE] ,[MTG1_MTG_TERM_],[MTG1_MTG_DUE_DATE] , [MTG1_MTG_INTEREST_RATE] ,[MTG1_SELLER_CARRY_BACK]   ,[MTG1_REFI_FLAG]
    ,[MTG2_RECORDING_DATE]	,[MTG2_DOC_DATE]   ,[MTG2_RECORDING_BOOK]    ,[MTG2_RECORDING_PAGE]    ,[MTG2_DETAILED_DOC_TYPE]  ,[MTG2_LENDER_FIRST_NAME] ,[MTG2_LENDER_ADDRESS]  ,[MTG2_LENDER_CITY] ,[MTG2_LENDER_STATE]   ,[MTG2_LENDER_ZIp]
   ,[MTG2_MTG_COMPANY_CODE] ,[MTG2_MTG_LOAN_TYPE_CODE],[MTG2_MTG_TERM_CODE]  ,[MTG2_MTG_TERM]  ,[MTG2_MTG_DUE_DATE] ,[MTG2_MTG_INTEREST_RATE]   ,[MTG2_SELLER_CARRY_BACK]   ,[MTG2_PRIVATE_PARTY_LENDER] ,[MTG2_REFI_FLAG]   ,[MTG2_OTHER_SUBORDINATE_LOANS] 
    
 into [MiNelson].[mktshr].[Marketshare_Deed_BK]    
FROM [Deed].[dbo].[Deed] t
where isnull(Recording_Date,Sale_Date) >= '2022-01-01' 
and source_type = 'B'
and fips  in (select distinct fips from 
   [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver]
  where source = 'B' or source = 'E')

	  
  ----- Fix Fulton GA

  --update a
  --set a.TITLE_COMPANY_NAME = b.SR_TITLE_CO_NAME , 
  --a.UPDATED = getdate()
  --from Minelson. mktshr.Marketshare_Deed_BK a
  --inner join   MiNelson.dbo.Fulton_GA_BK_to_RT_match b
  --on a.deedid = b.deedid 
  --where a.TITLE_COMPANY_NAME is null 
  --and ( b.SR_TITLE_CO_NAME <>'' and  b.SR_TITLE_CO_NAME <> 'NOT AVAILABLE')
 
 
  --update a
  --set a.MTG1_LENDER_LAST_NAME = b.SR_LNDR_LAST_NAME_1 ,
  --a.MTG1_MTG_AMOUNT = b.SR_LOAN_VAL_1,
  -- a.UPDATED = getdate()
  --from Minelson. mktshr.Marketshare_Deed_BK a
  --inner join   MiNelson.dbo.Fulton_GA_BK_to_RT_match b
  --on a.deedid = b.deedid 
  --where (a.MTG1_LENDER_LAST_NAME is null and a.MTG1_MTG_AMOUNT is null)
  --and ( b.SR_LNDR_LAST_NAME_1 <>'') 

---------------------



--alter table  mktshr.Marketshare_Deed_BK 
--add Link  varchar(2)

--alter table  mktshr.Marketshare_Deed_BK 	add  MTG1_MTG_AMOUNT_new numeric (13,2)
--	alter table  mktshr.Marketshare_Deed_BK 		add MTG1_DOC_NBR_new varchar (12)
--	alter table  mktshr.Marketshare_Deed_BK 	add [MTG1_RECORDING_DATE_new] date
--    alter table  mktshr.Marketshare_Deed_BK      add [MTG1_DOC_DATE_new] date
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_RECORDING_BOOK_new] varchar (6)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_RECORDING_PAGE_new] varchar (6)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_DETAILED_DOC_TYPE_new] varchar (2)
--    alter table  mktshr.Marketshare_Deed_BK    add [MTG1_LENDER_LAST_NAME_new] varchar (30)
--     alter table  mktshr.Marketshare_Deed_BK   add [MTG1_LENDER_FIRST_NAME_new] varchar (30)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_LENDER_ADDRESS_new]varchar (60)
--    alter table mktshr.Marketshare_Deed_BK   add [MTG1_LENDER_CITY_new] varchar (30)
--  alter table  mktshr.Marketshare_Deed_BK     add [MTG1_LENDER_STATE_new] varchar (2)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_MTG_COMPANY_CODE_new] varchar (6)
--  alter table  mktshr.Marketshare_Deed_BK   add [MTG1_MTG_LOAN_TYPE_CODE_new] varchar (3)
--  alter table  mktshr.Marketshare_Deed_BK     add [MTG1_MTG_TERM_CODE_new] varchar (1)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_MTG_DUE_DATE_new] date
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_MTG_INTEREST_RATE_TYPE_new] varchar (3)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_MTG_INTEREST_RATE_new] varchar (7)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG1_SELLER_CARRY_BACK_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_PRIVATE_PARTY_LENDER_new] varchar (1)
--    alter table mktshr.Marketshare_Deed_BK  add [MTG1_CONSTRUCTION_LOAN_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_REFI_FLAG_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_EQUITY_FLAG_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG1_OTHER_SUBORDINATE_LOANS_new] varchar (1)

--alter table  mktshr.Marketshare_Deed_BK 	add  MTG2_MTG_AMOUNT_new numeric (13,2)
--	alter table  mktshr.Marketshare_Deed_BK 		add MTG2_DOC_NBR_new varchar (12)
--			alter table  mktshr.Marketshare_Deed_BK 	add [MTG2_RECORDING_DATE_new] date
--    alter table  mktshr.Marketshare_Deed_BK     add [MTG2_DOC_DATE_new] date
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_RECORDING_BOOK_new] varchar (6)
--   alter table  mktshr.Marketshare_Deed_BK   add [MTG2_RECORDING_PAGE_new] varchar (6)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_DETAILED_DOC_TYPE_new] varchar (2)
--    alter table  mktshr.Marketshare_Deed_BK    add [MTG2_LENDER_LAST_NAME_new] varchar (30)
--     alter table  mktshr.Marketshare_Deed_BK   add [MTG2_LENDER_FIRST_NAME_new] varchar (30)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_LENDER_ADDRESS_new]varchar (60)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_LENDER_CITY_new] varchar (30)
--  alter table  mktshr.Marketshare_Deed_BK     add [MTG2_LENDER_STATE_new] varchar (2)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG2_LENDER_ZIP_new] varchar (9)
--   alter table mktshr.Marketshare_Deed_BK   add [MTG2_MTG_COMPANY_CODE_new] varchar (6)
--  alter table  mktshr.Marketshare_Deed_BK     add [MTG2_MTG_LOAN_TYPE_CODE_new] varchar (3)
--  alter table  mktshr.Marketshare_Deed_BK    add [MTG2_MTG_TERM_CODE_new] varchar (1)
--   alter table  mktshr.Marketshare_Deed_BK   add [MTG2_MTG_TERM_new] varchar (4)
--   alter table  mktshr.Marketshare_Deed_BK   add [MTG2_MTG_DUE_DATE_new] date
--   alter table  mktshr.Marketshare_Deed_BK   add [MTG2_MTG_INTEREST_RATE_TYPE_new] varchar (3)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG2_MTG_INTEREST_RATE_new] varchar (7)
--   alter table  mktshr.Marketshare_Deed_BK    add [MTG2_SELLER_CARRY_BACK_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_PRIVATE_PARTY_LENDER_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_CONSTRUCTION_LOAN_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_REFI_FLAG_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_EQUITY_FLAG_new] varchar (1)
--    alter table  mktshr.Marketshare_Deed_BK   add [MTG2_OTHER_SUBORDINATE_LOANS_new] varchar (1)


---------------------------------------update already link mtg


--update d
--set d.link = 'Y'

--FROM mktshr.Marketshare_Deed_BK  d
--WHERE
--	 Source_Type = 'B'
--	AND (MTG1_MTG_AMOUNT is not null 	and MTG1_MTG_AMOUNT <> 0)
--	AND NULLIF(DOC_NBR, '') IS NOT NULL
--	AND NULLIF(MTG1_DOC_NBR, '') IS NOT NULL
--	AND MTG1_DOC_NBR != DOC_NBR
	
-------------------------set M1 for already link mtg1------------------------------

--  IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S,
-- --x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
-- x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s,
-- -- x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
---- x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
--y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
--      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
--        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
--      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
--      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--        ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
--      ,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
--      ,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
--      ,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
--      ,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
--      ,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
--      ,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--      ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
--      ,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
--      ,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
--      ,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
--      ,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
--      ,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
--      ,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
--      ,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
--      ,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
--      ,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
--      ,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
--      ,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into mktshr.Marketshare_Deed_BK_mtg1

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM mktshr.Marketshare_Deed_BK
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD'  --  and sale_amount is not null 
--and link = 'Y'
												 
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM mktshr.Marketshare_Deed_BK
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and x.RECORDING_DATE = y.RECORDING_DATE 
--order by x.REF_ID


--   update a
--   set a.link = 'M1'
-- from mktshr.Marketshare_Deed_BK a
--    inner join  mktshr.Marketshare_Deed_BK_mtg1 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
-- where 
--(case when  mtg1_doc_nbr_D is null then null else right(mtg1_Doc_nbr_D, 4)end)=
--(case when right(Mtg1_doc_nbr_S, 2) = '-0' then left(right(Mtg1_doc_nbr_S, 6),4) else right(Mtg1_doc_nbr_S, 4) end)



---------------------------------------second mtg for already link---------------------------

--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg2') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg2

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
-- --x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
--, x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s,-- x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
-- --x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
--y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
--      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
--        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
--      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
--      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--         ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
--      ,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
--      ,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
--      ,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
--      ,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
--      ,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
--      ,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--      ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
--      ,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
--      ,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
--      ,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
--      ,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
--      ,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
--      ,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
--      ,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
--      ,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
--      ,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
--      ,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
--      ,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into mktshr.Marketshare_Deed_BK_mtg2

--from 

--(  SELECT 
--  *
--FROM mktshr.Marketshare_Deed_BK
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD' and Mtg2_Mtg_Amount is null --  and sale_amount is not null 
--and link = 'Y'
												 
--)x
--inner join
   
--( SELECT  
-- *
--FROM mktshr.Marketshare_Deed_BK
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and x.RECORDING_DATE = y.RECORDING_DATE 
--order by x.REF_ID

-- update a
--   set a.link = 'B2'
--    ,a.Mtg2_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg2_Doc_NBR_New = Mtg1_Doc_Nbr_S
--   ,a.[MTG2_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
--	,a.[MTG2_DOC_DATE_new] = b.MTG1_DOC_DATE_S
--  ,a.[MTG2_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
--   ,a.[MTG2_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
--   ,a.[MTG2_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG2_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
--    ,a.[MTG2_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
--   ,a.[MTG2_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
--    ,a.[MTG2_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- ,a.[MTG2_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
--   ,a.[MTG2_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
--   ,a.[MTG2_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
--  ,a.[MTG2_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
--  ,a.[MTG2_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
--   ,a.[MTG2_MTG_TERM_new] = b.MTG1_MTG_TERM_S
--  ,a.[MTG2_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
--   ,a.[MTG2_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
--   ,a.[MTG2_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
--   ,a.[MTG2_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
--    ,a.[MTG2_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
--   ,a.[MTG2_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
--    ,a.[MTG2_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
--    ,a.[MTG2_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
--    ,a.[MTG2_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S
 
--      from mktshr.Marketshare_Deed_BK a
--    inner join   mktshr.Marketshare_Deed_BK_mtg2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
--	where b.rn = 1
  

--  ---------------------set mtg1 record--------------
--      update a
--   set a.link = 'M2'
  
--    from mktshr.Marketshare_Deed_BK a
--    inner join  mktshr.Marketshare_Deed_BK_mtg2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
-- where b.rn = 1



---- -----------------------------concurr recording-----------------
 
 
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur

--select 
--     row_number() over(partition by x.FIPS,x.DeedID order by y.MTG1_MTG_AMOUNT desc) as [rn],  
--  x.fips, x.DeedID as DeedID_D, y.DeedID as DeedID_S, x.REF_ID as Ref_ID_D, y.REF_ID as Ref_ID_S,
-- x.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_D , y.CLGX_UNIQUE_ID as CLGX_UNIQUE_ID_S,x.RECORDING_DATE as Recording_Date_D, y.RECORDING_DATE as Recording_Date_S,
-- x.DOC_NBR as Doc_nbr_D, y.DOC_NBR as Doc_nbr_S, x.recording_book as Recording_Book_D, y.Recording_Book as Recording_Book_S,x.Recording_Page as Recording_page_D, y.Recording_page as Recording_Page_S ,x.SALE_AMOUNT as Sale_amount_D, y.SALE_AMOUNT as Sale_amount_S,
-- x.MTG1_DOC_NBR as Mtg1_Doc_nbr_D, y.MTG1_DOC_NBR as Mtg1_Doc_Nbr_S, x.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_D, y.MTG1_MTG_AMOUNT as Mtg1_mtg_amount_S,
-- x.MTG2_DOC_NBR as Mtg2_DOc_Nbr_D, y.MTG2_DOC_NBR as Mtg2_Doc_Nbr_S,  x.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_D , y.MTG2_MTG_AMOUNT as Mtg2_mtg_amount_S
-- --x.PRI_CAT_CODE as Pri_cat_code_D, y.PRI_CAT_CODE as pri_cat_code_S, x.ARMS_LENGTH_ID as Arms_Length_ID_D, y.ARMS_LENGTH_ID as arms_length_ID_S,
-- ,x.TRANSACTION_TYPE as Transaction_type_D, y.TRANSACTION_TYPE as Transation_type_s,-- x.Original_APN as Original_APN_D, Y.original_APN as Original_APN_S,
-- --x.Original_Site_Address as Original_Site_Addess_D, Y.Original_site_address as Original_site_address_S, x.situs_zip_code as Zip_D , y.situs_zip_code as Zip_S,x.MULTI_APN --, X.*, y.*
--y.[MTG1_RECORDING_DATE] as MTG1_RECORDING_DATE_S, x.BYR1_OWN_NAME as BYR1_OWN_NAME_D,  y.BYR1_OWN_NAME as BYR1_OWN_NAME_S 
--      ,y.[MTG1_DOC_DATE] as MTG1_DOC_DATE_S
--        ,y.[MTG1_RECORDING_BOOK] as MTG1_RECORDING_BOOK_S
--      ,y.[MTG1_RECORDING_PAGE] as MTG1_RECORDING_PAGE_S
--      ,y.[MTG1_DETAILED_DOC_TYPE] as MTG1_DETAILED_DOC_TYPE_S
--         ,y.[MTG1_LENDER_LAST_NAME] as MTG1_LENDER_LAST_NAME_S
--      ,y.[MTG1_LENDER_FIRST_NAME] as MTG1_LENDER_FIRST_NAME_S
--      ,y.[MTG1_LENDER_ADDRESS] as MTG1_LENDER_ADDRESS_S
--      ,y.[MTG1_LENDER_CITY] as MTG1_LENDER_CITY_S
--      ,y.[MTG1_LENDER_STATE] as MTG1_LENDER_STATE_S
--      ,y.[MTG1_LENDER_ZIP] as MTG1_LENDER_ZIP_S
--      ,y.[MTG1_MTG_COMPANY_CODE] as MTG1_MTG_COMPANY_CODE_S
--      ,y.[MTG1_MTG_LOAN_TYPE_CODE] as MTG1_MTG_LOAN_TYPE_CODE_S
--      ,y.[MTG1_MTG_TERM_CODE] as MTG1_MTG_TERM_CODE_S
--      ,y.[MTG1_MTG_TERM_] as MTG1_MTG_TERM_S
--      ,y.[MTG1_MTG_DUE_DATE] as MTG1_MTG_DUE_DATE_S
--      ,y.[MTG1_MTG_INTEREST_RATE_TYPE] as MTG1_MTG_INTEREST_RATE_TYPE_S
--      ,y.[MTG1_MTG_INTEREST_RATE] as MTG1_MTG_INTEREST_RATE_S
--      ,y.[MTG1_SELLER_CARRY_BACK] as MTG1_SELLER_CARRY_BACK_S
--      ,y.[MTG1_PRIVATE_PARTY_LENDER] as MTG1_PRIVATE_PARTY_LENDER_S
--      ,y.[MTG1_CONSTRUCTION_LOAN] as MTG1_CONSTRUCTION_LOAN_S
--      ,y.[MTG1_REFI_FLAG] as MTG1_REFI_FLAG_S
--      ,y.[MTG1_EQUITY_FLAG] as MTG1_EQUITY_FLAG_S
--      ,y.[MTG1_OTHER_SUBORDINATE_LOANS] as MTG1_OTHER_SUBORDINATE_LOANS_S
--into  mktshr.Marketshare_Deed_BK_mtg1_concur

--from 

--(  SELECT 
---- fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
-- --MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
--  *
--FROM mktshr.Marketshare_Deed_BK
--where 
-- Source_Type = 'B' and SRC_TBL = 'BKD' -- and sale_amount is not null 
--AND NULLIF(MTG1_DOC_NBR, '') IS NULL and mtg1_mtg_amount is  null
--and link is null
												 
--)x
--inner join
   
--( SELECT  
----fips, DeedID, REF_ID, CLGX_UNIQUE_ID ,ORIGINAL_APN, RECORDING_DATE, DOC_NBR, SALE_AMOUNT, DOC_TRANSFER_TAX,
----MTG1_DOC_NBR, MTG1_MTG_AMOUNT, MTG2_DOC_NBR, MTG2_MTG_AMOUNT , PRI_CAT_CODE, ARMS_LENGTH_ID, TRANSACTION_TYPE, source_type,
-- *
--FROM mktshr.Marketshare_Deed_BK
--where
--Source_Type = 'B' and SRC_TBL = 'BKS' and link is null
--)y
--on x.FIPS = y.FIPS and x.REF_ID = y.REF_ID 
--and x.Source_Type = y.Source_Type 
--and x.RECORDING_DATE = y.RECORDING_DATE 
--order by x.REF_ID



--------------first concur

--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1


--select * into mktshr.Marketshare_Deed_BK_mtg1_concur_1
--from mktshr.Marketshare_Deed_BK_mtg1_concur
--where rn = 1

--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1_final') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1_final
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp


--select    row_number() over(partition by FIPS, ref_id_D order by isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) desc) as [rn_1],
--isnull(case when DOC_NBR_D = '' then null else doc_nbr_D end,Recording_Page_D) as doc_page ,* 
--into mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp
--from  mktshr.Marketshare_Deed_BK_mtg1_concur_1

--select * 
--into mktshr.Marketshare_Deed_BK_mtg1_concur_1_final
--from mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp
--where rn_1 = 1




-- update a
--   set a.link = 'Y1'
--    ,a.Mtg1_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg1_Doc_NBR_New = b.Mtg1_Doc_Nbr_S
--   ,a.[MTG1_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
--	,a.[MTG1_DOC_DATE_new] = b.MTG1_DOC_DATE_S
--  ,a.[MTG1_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
--   ,a.[MTG1_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
--   ,a.[MTG1_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG1_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
--    ,a.[MTG1_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
--   ,a.[MTG1_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
--    ,a.[MTG1_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- ,a.[MTG1_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
--  -- ,a.[MTG1_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
--   ,a.[MTG1_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
--  ,a.[MTG1_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
--  ,a.[MTG1_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
--  -- ,a.[MTG1_MTG_TERM_new] = b.MTG1_MTG_TERM_S
--  ,a.[MTG1_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
--   ,a.[MTG1_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
--   ,a.[MTG1_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
--   ,a.[MTG1_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
--    ,a.[MTG1_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
--   ,a.[MTG1_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
--    ,a.[MTG1_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
--    ,a.[MTG1_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
--    ,a.[MTG1_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S
--    from mktshr.Marketshare_Deed_BK a
--    inner join   mktshr.Marketshare_Deed_BK_mtg1_concur_1_final b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
   
  
  
--      update a
--   set a.link = 'M1'
--     from  mktshr.Marketshare_Deed_BK a
--    inner join    mktshr.Marketshare_Deed_BK_mtg1_concur_1_final b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
 


---------------- second concur mtg

--    IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_2') IS NOT NULL DROP TABLE  mktshr.Marketshare_Deed_BK_mtg1_concur_2


--select * into  mktshr.Marketshare_Deed_BK_mtg1_concur_2
--from mktshr.Marketshare_Deed_BK_mtg1_concur 
--where rn = 2



--   update a
--   set a.link = 'Y2'
--    ,a.Mtg2_mtg_amount_New = b.Mtg1_mtg_amount_S
--   ,a.Mtg2_Doc_NBR_New = Mtg1_Doc_Nbr_S
--   ,a.[MTG2_RECORDING_DATE_new] = b.MTG1_RECORDING_DATE_S
--	,a.[MTG2_DOC_DATE_new] = b.MTG1_DOC_DATE_S
--  ,a.[MTG2_RECORDING_BOOK_new] = b.MTG1_RECORDING_BOOK_S
--   ,a.[MTG2_RECORDING_PAGE_new] = b.MTG1_RECORDING_PAGE_S
--   ,a.[MTG2_DETAILED_DOC_TYPE_new] = b.MTG1_DETAILED_DOC_TYPE_S
--  ,a.[MTG2_LENDER_LAST_NAME_new] = b.MTG1_LENDER_LAST_NAME_S
--    ,a.[MTG2_LENDER_FIRST_NAME_new] = b.MTG1_LENDER_FIRST_NAME_S
--   ,a.[MTG2_LENDER_ADDRESS_new]= b.MTG1_LENDER_ADDRESS_S
--    ,a.[MTG2_LENDER_CITY_new] = b.MTG1_LENDER_CITY_S
-- ,a.[MTG2_LENDER_STATE_new] = b.MTG1_LENDER_STATE_S
--   ,a.[MTG2_LENDER_ZIP_new] = b.MTG1_LENDER_ZIP_S
--   ,a.[MTG2_MTG_COMPANY_CODE_new] = b.MTG1_MTG_COMPANY_CODE_S
--  ,a.[MTG2_MTG_LOAN_TYPE_CODE_new] = b.MTG1_MTG_LOAN_TYPE_CODE_S
--  ,a.[MTG2_MTG_TERM_CODE_new] = b.MTG1_MTG_TERM_CODE_S
--   ,a.[MTG2_MTG_TERM_new] = b.MTG1_MTG_TERM_S
--  ,a.[MTG2_MTG_DUE_DATE_new] = b.MTG1_MTG_DUE_DATE_S
--   ,a.[MTG2_MTG_INTEREST_RATE_TYPE_new] = b.MTG1_MTG_INTEREST_RATE_TYPE_S
--   ,a.[MTG2_MTG_INTEREST_RATE_new] = b.MTG1_MTG_INTEREST_RATE_S
--   ,a.[MTG2_SELLER_CARRY_BACK_new] = b.MTG1_SELLER_CARRY_BACK_S
--    ,a.[MTG2_PRIVATE_PARTY_LENDER_new] = b.MTG1_PRIVATE_PARTY_LENDER_S
--   ,a.[MTG2_CONSTRUCTION_LOAN_new] = b.MTG1_CONSTRUCTION_LOAN_S
--    ,a.[MTG2_REFI_FLAG_new] = b.MTG1_REFI_FLAG_S
--    ,a.[MTG2_EQUITY_FLAG_new] = b.MTG1_EQUITY_FLAG_S
--    ,a.[MTG2_OTHER_SUBORDINATE_LOANS_new] = b.MTG1_OTHER_SUBORDINATE_LOANS_S
--      from  mktshr.Marketshare_Deed_BK a
--    inner join    mktshr.Marketshare_Deed_BK_mtg1_concur_2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_D
  
 
--  ---------------------set mtg1 record--------------
--      update a
--   set a.link = 'M2'
  
--    from  mktshr.Marketshare_Deed_BK a
--    inner join    mktshr.Marketshare_Deed_BK_mtg1_concur_2 b
--    on a.fips = b.fips and a.deedid = b.DeedID_s
 
 
 
 
 -------------------------update original fields_---------------
 
     IF OBJECT_ID('mktshr.Marketshare_Deed_BK_Final') IS NOT NULL DROP TABLE  mktshr.Marketshare_Deed_BK_Final


 
 select * into   [MiNelson].[mktshr].[Marketshare_Deed_BK_Final]
 from  [MiNelson].[mktshr].[Marketshare_Deed_BK]



------------update original fields for fist mtg link

--update a
--set 
-- Mtg1_mtg_amount = Mtg1_mtg_amount_new
--   ,Mtg1_Doc_NBR = Mtg1_Doc_Nbr_new
--   ,[MTG1_RECORDING_DATE] = MTG1_RECORDING_DATE_new
--	,[MTG1_DOC_DATE] = MTG1_DOC_DATE_new
--  ,[MTG1_RECORDING_BOOK] = MTG1_RECORDING_BOOK_new
--   ,[MTG1_RECORDING_PAGE] = MTG1_RECORDING_PAGE_new
--   ,[MTG1_DETAILED_DOC_TYPE] = MTG1_DETAILED_DOC_TYPE_new
--  ,a.[MTG1_LENDER_LAST_NAME] = MTG1_LENDER_LAST_NAME_new
--    ,a.[MTG1_LENDER_FIRST_NAME] = MTG1_LENDER_FIRST_NAME_new
--   ,a.[MTG1_LENDER_ADDRESS]= MTG1_LENDER_ADDRESS_new
--    ,a.[MTG1_LENDER_CITY] = MTG1_LENDER_CITY_new
-- ,a.[MTG1_LENDER_STATE] = MTG1_LENDER_STATE_new
-- --  ,a.[MTG1_LENDER_ZIp] = MTG1_LENDER_ZIP_new
--   ,a.[MTG1_MTG_COMPANY_CODE] = MTG1_MTG_COMPANY_CODE_new
--  ,a.[MTG1_MTG_LOAN_TYPE_CODE] = MTG1_MTG_LOAN_TYPE_CODE_new
--  ,a.[MTG1_MTG_TERM_CODE] = MTG1_MTG_TERM_CODE_new
--  -- ,a.[MTG1_MTG_TERM_] = MTG1_MTG_TERM_new
--  ,a.[MTG1_MTG_DUE_DATE] = MTG1_MTG_DUE_DATE_new
--   ,a.[MTG1_MTG_INTEREST_RATE_TYPE] = MTG1_MTG_INTEREST_RATE_TYPE_new
--   ,a.[MTG1_MTG_INTEREST_RATE] = MTG1_MTG_INTEREST_RATE_new
--   ,a.[MTG1_SELLER_CARRY_BACK] = MTG1_SELLER_CARRY_BACK_new
--    ,a.[MTG1_PRIVATE_PARTY_LENDER] = MTG1_PRIVATE_PARTY_LENDER_new
--   ,a.[MTG1_CONSTRUCTION_LOAN] = MTG1_CONSTRUCTION_LOAN_new
--    ,a.[MTG1_REFI_FLAG] = MTG1_REFI_FLAG_new
--    ,a.[MTG1_EQUITY_FLAG] = MTG1_EQUITY_FLAG_new
--    ,a.[MTG1_OTHER_SUBORDINATE_LOANS] = MTG1_OTHER_SUBORDINATE_LOANS_new

 
--from    mktshr.Marketshare_Deed_BK_Final a
--where link = 'Y1'


-------------------------update original fields for first and second mtg link

--update a
--set 
-- Mtg1_mtg_amount = Mtg1_mtg_amount_new
--   ,Mtg1_Doc_NBR = Mtg1_Doc_Nbr_new
--    ,[MTG1_RECORDING_DATE] = MTG1_RECORDING_DATE_new
--	,[MTG1_DOC_DATE] = MTG1_DOC_DATE_new
--  ,[MTG1_RECORDING_BOOK] = MTG1_RECORDING_BOOK_new
--   ,[MTG1_RECORDING_PAGE] = MTG1_RECORDING_PAGE_new
--   ,[MTG1_DETAILED_DOC_TYPE] = MTG1_DETAILED_DOC_TYPE_new
--  ,a.[MTG1_LENDER_LAST_NAME] = MTG1_LENDER_LAST_NAME_new
--    ,a.[MTG1_LENDER_FIRST_NAME] = MTG1_LENDER_FIRST_NAME_new
--   ,a.[MTG1_LENDER_ADDRESS]= MTG1_LENDER_ADDRESS_new
--    ,a.[MTG1_LENDER_CITY] = MTG1_LENDER_CITY_new
-- ,a.[MTG1_LENDER_STATE] = MTG1_LENDER_STATE_new
-- --  ,a.[MTG1_LENDER_ZIp] = MTG1_LENDER_ZIP_new
--   ,a.[MTG1_MTG_COMPANY_CODE] = MTG1_MTG_COMPANY_CODE_new
--  ,a.[MTG1_MTG_LOAN_TYPE_CODE] = MTG1_MTG_LOAN_TYPE_CODE_new
--  ,a.[MTG1_MTG_TERM_CODE] = MTG1_MTG_TERM_CODE_new
--  -- ,a.[MTG1_MTG_TERM_] = MTG1_MTG_TERM_new
--  ,a.[MTG1_MTG_DUE_DATE] = MTG1_MTG_DUE_DATE_new
--   ,a.[MTG1_MTG_INTEREST_RATE_TYPE] = MTG1_MTG_INTEREST_RATE_TYPE_new
--   ,a.[MTG1_MTG_INTEREST_RATE] = MTG1_MTG_INTEREST_RATE_new
--   ,a.[MTG1_SELLER_CARRY_BACK] = MTG1_SELLER_CARRY_BACK_new
--    ,a.[MTG1_PRIVATE_PARTY_LENDER] = MTG1_PRIVATE_PARTY_LENDER_new
--   ,a.[MTG1_CONSTRUCTION_LOAN] = MTG1_CONSTRUCTION_LOAN_new
--    ,a.[MTG1_REFI_FLAG] = MTG1_REFI_FLAG_new
--    ,a.[MTG1_EQUITY_FLAG] = MTG1_EQUITY_FLAG_new
--    ,a.[MTG1_OTHER_SUBORDINATE_LOANS] = MTG1_OTHER_SUBORDINATE_LOANS_new
 
-- ,Mtg2_mtg_amount = Mtg2_mtg_amount_new
--   ,Mtg2_Doc_NBR = Mtg2_Doc_Nbr_new
--    ,[MTG2_RECORDING_DATE] = MTG2_RECORDING_DATE_new
--	,[MTG2_DOC_DATE] = MTG2_DOC_DATE_new
--  ,[MTG2_RECORDING_BOOK] = MTG2_RECORDING_BOOK_new
--   ,[MTG2_RECORDING_PAGE] = MTG2_RECORDING_PAGE_new
--   ,[MTG2_DETAILED_DOC_TYPE] = MTG2_DETAILED_DOC_TYPE_new
--  ,a.[MTG2_LENDER_LAST_NAME] = MTG2_LENDER_LAST_NAME_new
--    ,a.[MTG2_LENDER_FIRST_NAME] = MTG2_LENDER_FIRST_NAME_new
--   ,a.[MTG2_LENDER_ADDRESS]= MTG2_LENDER_ADDRESS_new
--    ,a.[MTG2_LENDER_CITY] = MTG2_LENDER_CITY_new
-- ,a.[MTG2_LENDER_STATE] = MTG2_LENDER_STATE_new
--   ,a.[MTG2_LENDER_ZIp] = MTG2_LENDER_ZIP_new
--   ,a.[MTG2_MTG_COMPANY_CODE] = MTG2_MTG_COMPANY_CODE_new
--  ,a.[MTG2_MTG_LOAN_TYPE_CODE] = MTG2_MTG_LOAN_TYPE_CODE_new
--  ,a.[MTG2_MTG_TERM_CODE] = MTG2_MTG_TERM_CODE_new
--   ,a.[MTG2_MTG_TERM] = MTG2_MTG_TERM_new
--  ,a.[MTG2_MTG_DUE_DATE] = MTG2_MTG_DUE_DATE_new
--   ,a.[MTG2_MTG_INTEREST_RATE_TYPE] = MTG2_MTG_INTEREST_RATE_TYPE_new
--   ,a.[MTG2_MTG_INTEREST_RATE] = MTG2_MTG_INTEREST_RATE_new
--   ,a.[MTG2_SELLER_CARRY_BACK] = MTG2_SELLER_CARRY_BACK_new
--    ,a.[MTG2_PRIVATE_PARTY_LENDER] = MTG2_PRIVATE_PARTY_LENDER_new
--   ,a.[MTG2_CONSTRUCTION_LOAN] = MTG2_CONSTRUCTION_LOAN_new
--    ,a.[MTG2_REFI_FLAG] = MTG2_REFI_FLAG_new
--    ,a.[MTG2_EQUITY_FLAG] = MTG2_EQUITY_FLAG_new
--    ,a.[MTG2_OTHER_SUBORDINATE_LOANS] = MTG2_OTHER_SUBORDINATE_LOANS_new

--from  mktshr.Marketshare_Deed_BK_Final a
--where link = 'Y2'

----
--------------------------------
--------------update original fields for second mtg link where Bk already link the first

--update a
--set 
--Mtg2_mtg_amount = Mtg2_mtg_amount_new
--   ,Mtg2_Doc_NBR = Mtg2_Doc_Nbr_new
--    ,[MTG2_RECORDING_DATE] = MTG2_RECORDING_DATE_new
--	,[MTG2_DOC_DATE] = MTG2_DOC_DATE_new
--  ,[MTG2_RECORDING_BOOK] = MTG2_RECORDING_BOOK_new
--   ,[MTG2_RECORDING_PAGE] = MTG2_RECORDING_PAGE_new
--   ,[MTG2_DETAILED_DOC_TYPE] = MTG2_DETAILED_DOC_TYPE_new
--  ,a.[MTG2_LENDER_LAST_NAME] = MTG2_LENDER_LAST_NAME_new
--    ,a.[MTG2_LENDER_FIRST_NAME] = MTG2_LENDER_FIRST_NAME_new
--   ,a.[MTG2_LENDER_ADDRESS]= MTG2_LENDER_ADDRESS_new
--    ,a.[MTG2_LENDER_CITY] = MTG2_LENDER_CITY_new
-- ,a.[MTG2_LENDER_STATE] = MTG2_LENDER_STATE_new
--   ,a.[MTG2_LENDER_ZIp] = MTG2_LENDER_ZIP_new
--   ,a.[MTG2_MTG_COMPANY_CODE] = MTG2_MTG_COMPANY_CODE_new
--  ,a.[MTG2_MTG_LOAN_TYPE_CODE] = MTG2_MTG_LOAN_TYPE_CODE_new
--  ,a.[MTG2_MTG_TERM_CODE] = MTG2_MTG_TERM_CODE_new
--   ,a.[MTG2_MTG_TERM] = MTG2_MTG_TERM_new
--  ,a.[MTG2_MTG_DUE_DATE] = MTG2_MTG_DUE_DATE_new
--   ,a.[MTG2_MTG_INTEREST_RATE_TYPE] = MTG2_MTG_INTEREST_RATE_TYPE_new
--   ,a.[MTG2_MTG_INTEREST_RATE] = MTG2_MTG_INTEREST_RATE_new
--   ,a.[MTG2_SELLER_CARRY_BACK] = MTG2_SELLER_CARRY_BACK_new
--    ,a.[MTG2_PRIVATE_PARTY_LENDER] = MTG2_PRIVATE_PARTY_LENDER_new
--   ,a.[MTG2_CONSTRUCTION_LOAN] = MTG2_CONSTRUCTION_LOAN_new
--    ,a.[MTG2_REFI_FLAG] = MTG2_REFI_FLAG_new
--    ,a.[MTG2_EQUITY_FLAG] = MTG2_EQUITY_FLAG_new
--    ,a.[MTG2_OTHER_SUBORDINATE_LOANS] = MTG2_OTHER_SUBORDINATE_LOANS_new
--from  mktshr.Marketshare_Deed_BK_Final a
--where link = 'B2'


--------------------------------



--------------------------------Delete mtg records already link

--Delete

--from mktshr.Marketshare_Deed_BK_Final
--where  link  in ('M1','M2')

------ clean up

--  IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg2') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg2
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1
-- IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1_final') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1_final
--      IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp') IS NOT NULL DROP TABLE mktshr.Marketshare_Deed_BK_mtg1_concur_1_temp
--    IF OBJECT_ID('mktshr.Marketshare_Deed_BK_mtg1_concur_2') IS NOT NULL DROP TABLE  mktshr.Marketshare_Deed_BK_mtg1_concur_2


--------------------------------create Bk mtg1 and mtg2 report


IF OBJECT_ID('[dbo].[MarketShareTitle_Temp1]') IS NOT NULL DROP TABLE [dbo].[MarketShareTitle_Temp1]


select
	DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE,
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
       MTG1_PRIVATE_PARTY_LENDER,
       SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Sales_Source_Ind,
	   REF_ID,
       RECORDING_DATE,
       SALE_DATe, 
        UPDATED,
        Ass_ZipCode,
        Year_Built
     
   into [MiNelson].[dbo].[MarketShareTitle_Temp1]
from (

      SELECT
       1 as DeedSequence,
            case when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' -- Added 4/01/2015 
                           when (REO_SALE_FLAG = 1 Or REO_SALE = 'Y') and deed.TRANSACTION_TYPE != 4 then    -- Added "Cash Sale" split 2/27/2015 -- Added REO_Sale ='Y' 4/13/15
                                         case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'REO - Cash Sale' else 'REO' end
                           when MTG1_EQUITY_FLAG = 'Y' then 'Home Equity'
                           when MTG1_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
                                    else
                        case deed.TRANSACTION_TYPE 
                              when '1' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '2' then 'Refinance'
                              when '3' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Subdivision/Newhome - Cash Sale'
                                    else 'Subdivision/Newhome'
                                    end
                              when '4' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Timeshare - Cash Sale'
                                    else 'Timeshare'
                                    end
                              when '6' then 'Construction Loan'
                              when '7' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) and mc.Fips is not Null then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '9' then 'Refinance'
                              else ''
                        end
                  end as [Transaction Type],
            --isnull(deed.MTG1_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			 case when (deed.MTG1_LENDER_LAST_NAME is null or deed.MTG1_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG1_LENDER_LAST_NAME end as [Lender],
            case when (deed.TITLE_COMPANY_NAME  is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
            'UNKNOWN' as [Attorney],
            MTG1_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                         isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                          case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN, deed.DeedId) as [rn],               -- Corrected problem with row_number 3/09/15----- 4/14 Add DeedID
            deed.DOC_NBR as [Sale Document number],
            deed.MTG1_DOC_NBR as [MGT Document number],
              deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
       --     (deed.MTG1_RECORDING_BOOK + '/' + deed.MTG1_RECORDING_PAGE) as 'Book/Page', -- change 7/6/2015 make unique keys
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change 7/6/2015 make unique keys
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG1_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG1_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG1_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
           -- case when deed.US_STATE = 'KS' ---------adding 4/29/15 ----------take out 5/4/15
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG1_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG1_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null or deed.MTG1_DETAILED_DOC_TYPE='VR' then 'YES'   -- Added 2/20/2015; Added VR check 20180815
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
case when deed.MTG1_MTG_LOAN_TYPE_CODE = 'CNV' then
        case 
            when NBR_OF_RES_UNITS = 1 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
            when NBR_OF_RES_UNITS = 2 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
            when NBR_OF_RES_UNITS = 3 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
            when NBR_OF_RES_UNITS = 4 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
            when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                    and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
            else 'NO'
        end
        else 'NO'
end as [Conforming],
            case when TRANSACTION_TYPE = '3' then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = '9' then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
               case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       deed.TITLE_COMPANY_CODE,
       --MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND ,
       Deed.MTG1_PRIVATE_PARTY_LENDER,
       Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Deed.Sales_Source_Ind,      ---------------------change 2/4/2016 to filter AZ affidavits
       Deed.REF_ID,	               ---------------------Added for update Attorney names 3/14/2016
       deed.RECORDING_DATE,
       deed.SALE_DATe,
       deed.UPDATED,
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
       assr.Year_Built  -----------------------------Added YearBuilt for HI fix
       
      FROM 
            [MiNelson].[mktshr].[Marketshare_Deed_BK_Final] deed with (Nolock)left outer join [Assr].[dbo].[Assr] assr with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  -----------9/8/15 change to use ref_id to join
                deed.REF_ID = assr.REF_ID
                              left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm  with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where
            deed.DETAILED_DOC_TYPE not in ('MO','RD','CD','DT') --, 'TE') -- Added back the 'TE' records on 4/06/15
        --  and (deed.FIPS  between 56001 and 56999)
   --      and deed.US_STATE = 'ME'
  --and isnull(deed.RECORDING_DATE,deed.SALE_DATE) >= '2013-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
            and (MULTI_APN != 'D' or MULTI_APN is Null)
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9') -- Added TransType=9 on 4/07/15
              --   and not (Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null) -- Added Title_Company_Code is Null on 4/06/15 --4/17/15 take out take make filter for AZ
--and (Deed.DeedID >  (SELECT Max([Max_DeedId])FROM [mktshr].[MarketShare_Title_MaxDeedID])
 	--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16
	
 -- and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- take out BK data 8/20/2015  
  
	-- or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131	)) --- Add BK data 3/10/16 
--	  )   
--and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 --- remove 6/9
      )x
where
      rn = 1
--order by
--      [Sale Document number]

------------------

IF OBJECT_ID('[dbo].[MarketShareTitle_Temp2]') IS NOT NULL DROP TABLE [dbo].[MarketShareTitle_Temp2]
      
-------------------------
-- Create 2nd mgt table

select
DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE, 
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
        MTG1_PRIVATE_PARTY_LENDER,
        SELLER_NAME_PLAINTIFF1_CORP_IND,
		sales_source_ind,
		REF_ID,
       RECORDING_DATE,
       SALE_DATe,
       UPDATED,
       Ass_ZipCode,
       Year_Built 
   
   into [MiNelson].[dbo].[MarketShareTitle_Temp2]
from (
  SELECT
       
     2 as DeedSequence,
            --case 
            ----when REO_SALE_FLAG = 1 then    -- Added "Cash Sale" split 2/27/2015
            ----                        case when deed.MTG1_MTG_AMOUNT is Null and mc.Fips is not Null then 'REO - Cash Sale'
            ----                        else 'REO'
            ----                        end
            --      when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity'
            --      when MTG2_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
            --      else
            --            case deed.TRANSACTION_TYPE 
            --                  when 1 then 'Resale'
            --                  when 2 then 'Refinance'
            --                  when 3 then 'Subdivision/Newhome'
            --                  when 4 then 'Timeshare'
            --                  when 6 then 'Construction Loan'
            --                  when 7 then 'Resale'
            --                  when 9 then 'Refinance'
            --                  else ''
            --            end
            --      end as [Transaction Type],
            case when MTG2_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                           when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                            when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity' ---------Added 4/23/15
                           else 'Other Subordinate Loan' end as [Transaction Type],  --- changed 4/1/2015
            --isnull(deed.MTG2_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			 case when (deed.MTG2_LENDER_LAST_NAME is null or deed.MTG2_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG2_LENDER_LAST_NAME end as [Lender],
            case when (deed.TITLE_COMPANY_NAME is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
         --and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null)
       deed.TITLE_COMPANY_CODE,
            'UNKNOWN' as [Attorney],
            MTG2_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                                isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                                case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN, deed.DeedId) as [rn],     -- Corrected problem with row_number 3/09/15--- 4/14 add DeedID
            deed.DOC_NBR as [Sale Document number],
            deed.MTG2_DOC_NBR as [MGT Document number],
            deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
         --   (deed.MTG2_RECORDING_BOOK + '/' + deed.MTG2_RECORDING_PAGE) as 'Book/Page', --change to make uique keys 7/06/2015
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change to make unique keys 7/6/2015
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG2_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG2_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG2_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
    --      case when deed.US_STATE = 'KS' 
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG2_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG2_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null then 'YES'   -- Added 2/20/2015
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
            case when deed.MTG2_MTG_LOAN_TYPE_CODE = 'CNV' then
                  case 
                        when NBR_OF_RES_UNITS = 1 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        when NBR_OF_RES_UNITS = 2 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
                        when NBR_OF_RES_UNITS = 3 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
                        when NBR_OF_RES_UNITS = 4 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
                        when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                              and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        else 'NO'
                  end
                  else 'NO'
            end as [Conforming],
            case when TRANSACTION_TYPE = 3 then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = 9 then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
               case when deed.SITUS_CITY is not null and deed.SITUS_CITY <> '' then deed.SITUS_CITY
			when assr.SITUS_CITY is not null and assr.SITUS_CITY <> '' then assr.SITUS_CITY
			else '' end as [City]
			,deed.US_COUNTY AS [County]
			,deed.US_STATE AS [State]
					  --  isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
			,case when deed.SITUS_ZIP_CODE is not null and deed.SITUS_ZIP_CODE <> '' then left(deed.SITUS_ZIP_CODE,5)
			when assr.SITUS_ZIP_CODE is not null and assr.SITUS_ZIP_CODE <> '' then left(assr.SITUS_ZIP_CODE,5)
			else '' end as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND,
        Deed.MTG1_PRIVATE_PARTY_LENDER,
        Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
		Deed.Sales_Source_ind,
		Deed.REF_ID,
       deed.RECORDING_DATE,
       deed.SALE_DATe,
         deed.UPDATED, 
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
        assr.Year_Built ------------------------------Added yearBuilt for HI Fix
       
      FROM 
           [MiNelson].[mktshr].[Marketshare_Deed_BK_Final] deed with (Nolock) left outer join [Assr].[dbo].[Assr] assr  with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
                 deed.REF_ID = assr.REF_ID
                              left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where
            deed.DETAILED_DOC_TYPE not in ('MO','RD','CD','DT') --, 'TE') 
         --    and (deed.FIPS  between 56001 and 56999)
            --  and deed.US_STATE = 'ME'
   -- and isnull(deed.RECORDING_DATE,deed.SALE_DATE)  >= '2013-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
            and (MULTI_APN != 'D' or MULTI_APN is Null)
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9')
                 -- and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and deed.MTG2_LENDER_LAST_NAME is null)--4/17/15 take out take make filter for AZ
                  and deed.MTG2_MTG_AMOUNT is not null
    --  and (Deed.DeedID >   (SELECT Max([Max_DeedId])FROM [mktshr].[MarketShare_Title_MaxDeedID])
 			--or CONVERT(varchar(10), Deed.updated ,112)>= convert (varchar(10),DATEADD (day,-7,GETDATE()), 112))  --- add updated records 7/14/16


    --         and ((deed.Source_Type != 'B' or deed.Source_Type is null) --- 8/20/215 take out BK data
				--or ( deed.Source_Type = 'B' and  Deed.FIPS in (2110,27007,27013,27049,27057,27061,27131
				--												))  -----add BK data 3/10/2016
				-- --- BK data
				--)
			--	and (deed.Source_Type = 'B' and  Deed.FIPS  in (2122, 20055, 26157 ,27017 ,27021, 49003, 49021, 49027, 49041,53017) ) ---- Add new counties 5/5/16 -- remove 6/9

   )y
where
      rn = 1
--order by
--       [Sale Document number]
  

------

----------------------------------------------------------
---Union Results -----------------------------------------

IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable]


from 
(   
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp1]
       union
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp2]
)x
ORDER BY
       [County],
       [Sale Document number]


	    Delete
			-- select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where TRANSACTION_TYPE = '9'   ---------------------- by MyPhan 10/11/2022
    and isnull([Sales Price],0) = 0 and isnull ([Loan Amount],0) =0

-----------------
   -------HI Fix--------------------changed to all states 20171130
       
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select * from [MiNelson].[mktshr].[Title_MarketShare_BuilderNames])
   --where State = 'HI' and [Transaction Type] = 'Resale' 
   --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from mktshr.Title_MarketShare_HI_BuilerNames)

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select * from [MiNelson].[mktshr].[Title_MarketShare_BuilderNames])
  --where State = 'HI' and [Transaction Type] = 'Resale - Cash Sale' 
 --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from mktshr.Title_MarketShare_HI_BuilerNames)

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where [Transaction Type] = 'Resale'
and [Seller Name] in (select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where [Transaction Type] = 'Resale - Cash Sale'
and [Seller Name] in (select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])


  update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])
  

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome'
and t.Builder in (Select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder])

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale - Cash Sale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
and t.Builder in (Select Builder from [MiNelson].[mktshr].[GlobalBuilderTbl_nonBuilder])

--Castiglione, Caroline Thursday, February 7, 2019 2:56 PM Market Share Report issues email
--Castiglione, Caroline Tuesday, February 26, 2019 8:15 AM NV- Frontier Estates email
--Alan Ratner <alan@zelmanassociates.com>, May 14, 2019 2:05 PM [External] RE: First American DataTree - Builder Sample email
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome'
and (t.Builder like 'OPEN DOOR%'
or t.Builder like 'OPENDOOR%'
or t.Builder in
('OENDOOR HOMES PHOENIX 2 LLC'
,'OOENDOOR HOMES PHOENIX 2 L'
,'OPEADOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR PROERW6 LLC'
,'QPENDOOR HOMES PHOENIX 2 L'
,'FRONTIER ESTATES LLC')
or left(t.Builder,12)='COLONY RIDGE')
update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Resale - Cash Sale',t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
and (t.Builder like 'OPEN DOOR%'
or t.Builder like 'OPENDOOR%'
or t.Builder in
('OENDOOR HOMES PHOENIX 2 LLC'
,'OOENDOOR HOMES PHOENIX 2 L'
,'OPEADOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR HOMES PHOENIX 2 LLC'
,'OPNDOOR PROERW6 LLC'
,'QPENDOOR HOMES PHOENIX 2 L'
,'FRONTIER ESTATES LLC')
or left(t.Builder,12)='COLONY RIDGE')
-----
-------------------------------------------------------------
---- Filter records Resale_CashSale where it is REO

delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] = 'Resale - Cash Sale' and
  ( FORCLOSURE = 'Y' or DEED_TYPE = 'U')
  
  -------------------------------------
  
   -----------------------------------------------------------
  ------Filter cashsale records with no sale price in disclosure states
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
  and [Sales Price] = 0 and State not in ('AZ','AK', 'ID', 'IN', 'KS', 'LA','ME','MS', 'MO', 'MT', 'NM', 'ND', 'TX', 'UT' ,'WY', 'HI')

  -----------------------------------------------------
  
  ------------------------------------------------------------------
  ----------------Update Transaction_Type = ''---------------------
  
  --select * from [dbo].[TitleMarketShare_BaseTable]
  --where [Transaction Type] = '' 
  
  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Transaction Type] =
  (case 
	when [Transaction Type] = '' and [Sales Price] = 0 and [Loan Amount] <> 0 then 'Refinance'
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'M' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Resale - Cash Sale' else 'Resale' end
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'N' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Subdivision/Newhome - Cash Sale' else 'Subdivision/Newhome' end
   else [Transaction Type]
   end)
   
   ----------------------------------------
   
   
  -----------------------------------------------------------------
  -----------------Filter Title_company_code 400 for IL------------
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  TRANSACTION_TYPE =4 
  and (TITLE_COMPANY_CODE <> '00400' or TITLE_COMPANY_CODE is null)
  and state = 'IL'
  
--get Title Company from dtocr_title_extract_lake_master_docNo for UNKNOWN records 2020-07-01
/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp];

SELECT d.Fmt_Doc_Nbr
	,d.FMT_Book_Page
	,m.DeedID
	,[Sale Document number]
	,[Book/Page]
	,DATE
	,m.Fips
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] m INNER JOIN [Deed].[dbo].[Deed] d on m.DeedID=d.DeedID
--CROSS APPLY MiNelson.[dbo].[fn_FmtDocBookPAge_tbl](m.Fips, convert(VARCHAR, DATE, 112), CASE 
--			WHEN PATINDEX('%/%', [Book/Page]) > 0
--				THEN substring([Book/Page], 1, PATINDEX('%/%', [Book/Page]) - 1)
--			ELSE NULL
--			END, CASE 
--			WHEN PATINDEX('%/%', [Book/Page]) > 0
--				THEN substring([Book/Page], PATINDEX('%/%', [Book/Page]) + 1, len([Book/Page]) - PATINDEX('%/%', [Book/Page]))
--			ELSE NULL
--			END, [Sale Document number]) d
WHERE [Title Company] IN ('N/A','NONE AVAILABLE','UNKNOWN')
	AND (m.DeedID NOT IN (Select DeedID from [MiNelson].[mktshr].[TitleMarketShare]) OR m.DeedID IN (Select DeedID from [MiNelson].[mktshr].[TitleMarketShare] where [Title Company] IN ('N/A','NONE AVAILABLE','UNKNOWN')))

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2];

SELECT DISTINCT *
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp]

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3];

SELECT t.*
	,documentnumber
	,TitleId
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2] t
INNER JOIN [MiNelson].[dbo].[Title_Rematch] r ON r.RECORDING_DATE = t.DATE
	AND r.Fips = t.Fips
	AND r.documentnumber = t.Fmt_Doc_Nbr
UNION
SELECT t.*
	,documentnumber
	,TitleId
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp2] t
INNER JOIN [MiNelson].[dbo].[Title_Rematch] r ON r.RECORDING_DATE = t.DATE
	AND r.Fips = t.Fips
	AND r.documentnumber = t.Fmt_Book_Page

/*IF object_id('MiNelson.dbo.TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4') IS NOT NULL
	*/
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4];

SELECT DeedID
	,recommended_value
INTO [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4]
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp3] t
INNER JOIN [MiNelson].[dbo].[dtocr_title_extract_lake_master_docNo] d ON d.title_id = t.TitleId
WHERE recommended_value <> ''

UPDATE [MiNelson].[dbo].[m]
SET [title company] = left(recommended_value, 60),UPDATED=GETDATE()
FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] m
INNER JOIN [MiNelson].[dbo].[TitleMarketShare_BaseTable_UNKNOWN_Title_Company_temp4] t ON t.DeedID = m.DeedID
  --  -----------------------------------------------------------------------------
  ----Filter unknown title, lender records for Non_AZ counties ------------------
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  
            ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and State not in ('AZ','HI')

--Delete
--  FROM [dbo].[TitleMarketShare_BaseTable]
--  where [Transaction Type] not in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
--  and   ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')        
--  and State = 'NV'

  --Delete 
  --FROM [dbo].[TitleMarketShare_BaseTable]
  --where  
  --          ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
  --          and State <> 'AZ'
  
   --Filter unknown title, lender records for AZ counties------------- --------- 
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  [Transaction Type] = 'Resale'
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
            ----------------------------------------------------------------------------------
  --Filter Timeshare when unknown Title for Timshare records in TX and AZ counties
  
          
             Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 -- where [Title Company] = 'unknown' and [transaction type]  = 'Timeshare' --- changed 4/23
 --            and (state = 'TX' or State = 'AZ')
  where [Title Company] = 'unknown' 
	and ([transaction type]  = 'Timeshare' or [Transaction Type]= 'Timeshare - Cash Sale' )
             and (state = 'TX' or State = 'AZ')
             
             
             Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where TRANSACTION_TYPE = '9'   ----------------------changed from 9 to '9' by MyPhan 11/21/2019
  and not ( [Sales Price] = 0 and [Loan Amount]is not null)
  
  alter table [dbo].[TitleMarketShare_BaseTable]
 Alter Column [Attorney] varchar(60)


  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Attorney = [Title Company]
  where TITLE_COMPANY_CODE = '00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Title Company] = 'ATTORNEY ONLY'
  where TITLE_COMPANY_CODE ='00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Property type] = 'unknown' and Corporate != 'YES'
   and state != 'NM'  ----- 10/16 take out NM state
   
 

----- Change Residential Indicator If LOAN_TYPE is FHA or VA and Residential indicator is NO and property type = vacant 
------then change the Residential indicator to YES  ---- 9/22/15

 update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
  where [loan Type] in( 'FHA', 'VA') and Residential = 'NO' and [property type] = 'vacant'
  
  
  -----------------------
  
  ----Change  When the Transaction type is Subdivision/Newhome or Subdivision/Newhome-Cash Sale ---> change Residential to Yes  --- 9/22/15

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] = 'vacant'

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] != 'vacant'

  ---------------------------
  
  ----Change If the Reverse Mortgage Indicator is ‘Y’ and Residential is NO --> change Residential to Y regardless of Property Type --- 9/22/15
 
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] = 'vacant'
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] != 'vacant'
  
  ----------------------
  
  
--  ---For these FIPS lets bypass the changes we put in on Friday:
--Dallas- 48113
--Hennepin-27053
--Philadelphia-42101
--Kern-6029
--Anchorage-2020
--Marion OH-39101
--St Clair IL-17163
--Shasta CA-6089
--Yakima WA-53077
--Erie OH-39043
--Spokane-53063
--Ramsey mn-27123

   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
     where [Property type] in ('vacant' , 'agricultural') and Corporate != 'YES' and residential = 'No' 
   and [loan to value] != 'No data' and round(convert(float,[loan Amount]/[SALEs price]*100),2) > 20
and state not in ( 'TX', 'UT')



    update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'YES'
   where [Loan type] in  ('Conventional', 'VA', 'FHA') and [Property type] in ('vacant' , 'agricultural')
   and residential = 'No' and (state not in ( 'TX', 'UT') or fips = 48113)
   and fips not in (27053, 42101, 6029,2020,39101,17163,6089,53077,39043)

 
 
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
 where state not in ( 'TX', 'UT') 
  and residential = 'Yes' and corporate = 'Yes' 
 and [Sales price] = 0
  and [transaction type] = 'Construction Loan'
  and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
  
  
  
delete from  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   where state not in ( 'TX', 'UT') 
    and [transaction type] in ('Subdivision/NewHome', 'Subdivision/NewHome - Cash Sale', 'REO', 'REO-CASH SALE')
and [sales price] = 0 and [loan Amount] = 0
and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)

--------------------

  
  ----------------------
  
  ---- Change If the Transaction Type is TimeShare or TimeShare - Cash -> change Residential Indicator to NO  --- 9/22/15
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set Residential = 'NO'
    where [Transaction Type] in ('Timeshare', 'Timeshare - Cash Sale') and Residential = 'YES'
    and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
    
    
    ---------------------------
    ---, If the Transaction Type is Construction Loan and the Detailed Doc type is CL and Corp Indicator is Y then make Residential =NO 
---This will take the builders and Construction companies out of the Residential bucket

    
    update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'NO'
    where [Transaction Type] = 'Construction Loan' and DETAILED_DOC_TYPE = 'CL' and Corporate = 'YES' and Residential = 'YES'
   and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
   
   --------------------------------
   
   
   
  ----I do have two changes to suggest, 1) for TX if Property type is Vacant and Buyer is corp change residential to NO 
  
  --select * from [dbo].[TitleMarketShare_BaseTable]
  --where [property type] = 'vacant' and Corporate = 'YES' and Residential = 'YES' and State = 'TX'
  
  ----and in IL if Property types is Apartment and number of residentiail units is less than 2 change to Condo
  ---- 10/15 add logic for IL
  
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set [Property Type] = 'Condominium', Residential = 'YES'
where [Property Type] = 'Apartment' and nbr_of_res_units <2
and State = 'IL'


 update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Condominium', Residential = 'YES'
 where [Property Type] = 'Apartment' and [Sales Price] < 300000 and [Transaction Type] in ('Resale', 'Resale - Cash Sale')
and State = 'IL'
  
   
   
 ---  If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’ and property type to single family
  --- For CA --- 10/20/2015
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   set [Property Type] = 'Single Family Residence', Residential = 'YES'
where [Property Type] = 'vacant' and Residential = 'NO'
and MTG1_CONSTRUCTION_LOAN is null and state = 'CA'


--These changes are for Oregon: ----------10/20/2015
--1) If Property type is Agricultural and Corporate is ‘NO’ and MTG1_COMSTRUCTION_LOAN is null  change RESIDENTIAL to YES
--2) If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’
--3) If Property type is Agricultural and NBR_OF_RES_UNITS is more than 0 change PROPERTY type to Single Family Residence and Residential =”YES’



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and Corporate = 'NO' and MTG1_CONSTRUCTION_LOAN is null
 
   
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and  [Property Type] = 'vacant'  and  Residential = 'NO'
 and MTG1_CONSTRUCTION_LOAN is null and Corporate = 'NO'



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and  nbr_of_res_units > 0 


--Here is one for PA  --- 10/21/15
--If Property type is “vacant’ and if sale price is greater than 10,000 change property type to ‘Single Family Residence’ change Residential to Yes

 
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'PA' and [Property Type] = 'vacant' and  Residential = 'NO'
and  [Sales Price] > 10000 

 --- Change for TX --- 10/22/2015
 --  If NBR_OF_RES_UNITS are null and Corporate Indicator is YES change and Residential is YES, change Residential to NO
   
    
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where State = 'TX' and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units is null

--for 48113, If NBR_OF_RES_UNITS = 0 and Corporate Indicator is YES  and Residential is YES, change Residential to NO   --- 10/22/2015

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where fips =48113 and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units = 0


----Change for MI -- 10/27/2015
--- if Property type is vacant and Corp indicator is NO change Residential to YES
---- if Property type is Amusement Recreation change residentail to Yes

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'vacant' and  Residential = 'NO'
and Corporate = 'NO'

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'Amusement Recreation' and  Residential = 'NO'



------------------------"Contruction loan" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT  distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'





------------------------"Home Equity" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select  distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'



--------------check duplicates-----------------------------

 IF OBJECT_ID('dbo.titlemarketshare_dup') IS NOT NULL 
 DROP TABLE dbo.titlemarketshare_dup


SELECT  
      
      DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate], COUNT (*) count
 into [MiNelson].[dbo].[titlemarketshare_dup]
  FROM [MiNelson].[dbo].[TitleMarketShare_Basetable]
  group by
        DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate]
        having COUNT (*) > 1
        
 
 ------------------Delete duplciates---------------------------
 
         Delete from [MiNelson].[dbo].[TitleMarketShare_Basetable]
        where DeedID in (
SELECT deedid
  FROM [MiNelson].[dbo].[titlemarketshare_dup])
  and deedsequence = 2
-----------------------------------------------------------


--------------------------------------------------------------------------
------updating Zipcode and city------------------------------------------
---------------------------------------------------------------------------


IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]
from 
[MiNelson].[dbo].[TitleMarketShare_BaseTable]
   
  
  ----- add new column for title zipcode-------------------
  
  alter table   dbo.TitleMarketShare_BaseTable_zip add Title_ZipCode varchar(5)
  
   alter table   dbo.TitleMarketShare_BaseTable_zip add Title_city varchar(40)
   
  ----- when Deedid match then populate deed_zip to title_zip----------------
  
   update [MiNelson].[dbo].[t]
   set t.Title_ZipCode = t.[zip code]
   from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
   inner join [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and t.[Zip Code] = z.ZIPCode

----When Deedid dont match update assr_zip to title_zip if it match---------------------------

update [MiNelson].[dbo].[t]
set t.Title_ZipCode = left(t.ass_Zipcode,5)
from 
  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  
     left join  [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and left(t.ass_Zipcode,5) = z.ZIPCode
  where z.ZIPCode is not null and t.[Zip Code] <> '' and t.ass_zipCode is not null
  and t.Title_ZipCode is null and z.ZIPCode is not null
 
 
 
 -----------------------------------------------------------
 
 ---update Preferred city name
 
 IF OBJECT_ID('dbo.ZIPPreferredCity') IS NOT NULL DROP TABLE dbo.ZIPPreferredCity 

 select distinct ZIPCode, Fips, PreferredCity
into [MiNelson].[dbo].[ZIPPreferredCity] 
from   [MiNelson].[dbo].[ZipFipsCityAll]
group by ZIPCode, Fips, PreferredCity

 ------------Update preferred city name--------------------
 
 
 update [MiNelson].[dbo].[t]
 set t.title_city = z.PreferredCity
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  inner join [MiNelson].[dbo].[ZIPPreferredCity] z
  on t.FIPS = z.Fips and t.title_zipcode = z.ZIPCode
 
 -------------------------------------------------------------
 ---Update Deed Zip in update table-----------------------
 
  
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip_update]
 
 -----152,279 with city name or zip different
select *
into [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_city <> t.City or t.Title_ZipCode <> t.[Zip Code]

union
select *
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_ZipCode is null and ( t.[Zip Code] is not null and t.[Zip Code] <> '')



 update [MiNelson].[dbo].[t] 
 set t.[Zip Code] = t.title_ZipCode , t.city = t.title_city
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is not null
 

update [MiNelson].[dbo].[t]
 set t.[Zip Code] = '' , t.city = ''
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is  null
 
 --- update Zip and city in orginal table------------------
 
 --update t
 --set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 --from  [dbo].[TitleMarketShare_BaseTable_zip] t
 --inner join [dbo].[TitleMarketShare_BaseTable_zip_update] u
 --on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 ----update base table ---------------------------------
 
  update [MiNelson].[dbo].[t]
 set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 from  [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
 inner join [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u
 on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip]
 IF OBJECT_ID('[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL DROP TABLE [dbo].[TitleMarketShare_BaseTable_zip_update]
  IF OBJECT_ID('dbo.ZIPPreferredCity') IS NOT NULL DROP TABLE dbo.ZIPPreferredCity 




---------------Add Attorney name from RT--------------------------------------------------------

----------------------------------------------------------------------------------------



-----------------------------------------------------------------------
----- create RT table with only the columns that we need--------------------    
      
--      IF OBJECT_ID('[dbo].[Title_marketshare_RT]') IS NOT NULL DROP TABLE [dbo].[Title_marketshare_RT]


--SELECT[RECORDER_ID]
--      ,[FIPS]
--     ,SR_PROPERTY_ID,SR_UNIQUE_ID
--      ,[SR_DOC_NBR_FMT]
--      ,[SR_DOC_NBR_RAW]
--      , case when [SR_DOC_NBR_FMT] is null then null
--		 when ([SR_DOC_NBR_FMT] <> '' and len([SR_DOC_NBR_FMT]) >  2) then RIGHT(Rtrim([SR_DOC_NBR_FMT]), len([SR_DOC_NBR_FMT]) -2) else null end as RT_Doc_Nbr
--  ,SR_LAWYER_NAME,SR_LAWYER_CODE,SR_TITLE_CO_NAME,SR_TITLE_CO_CODE,SR_DATE_TRANSFER,SR_VAL_TRANSFER,SR_DATE_FILING
 
-- into  dbo.Title_marketshare_RT
-- FROM [ART].[dbo].[RT_Recorder]
-- where SR_DATE_TRANSFER >= '20130101'
 

    -----------------------------------------------------
  
  -------------------------------------------------- 
--           IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_ID

     
       
--       select r.SA_PROPERTY_ID, r.CLGX_UNIQUE_ID, c.* ,
--       case when c.[Book/Page] IS not null then RIGHT(c.[Book/Page], 4)
--       when c.[Sale Document number] IS null then null
--       when len(c.[Sale Document number])<4 then null
--       else RIGHT(Rtrim(c.[Sale Document number]), len(c.[Sale Document number]) -4) end as Deed_Doc_Nbr
--       into  dbo.TitleMarketShare_BaseTable_Attorney_ID from [dbo].[TitleMarketShare_BaseTable] c
--      left join Assr.dbo.PropertyReference r 
--       on c.FIPS = r.FIPS and c.REF_ID =r.REF_ID 
       
      
       
--           IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney
       
--       select r.[RECORDER_ID]
--      ,r.[FIPS] as RT_Fips
--      ,r.[SR_PROPERTY_ID]
--      ,r.[SR_DOC_NBR_FMT]
--      ,r.[SR_DOC_NBR_RAW]
--      ,r.[RT_Doc_Nbr]
--      ,r.[SR_LAWYER_NAME]
--      ,r.[SR_LAWYER_CODE]
--      ,r.[SR_TITLE_CO_NAME]
--      ,r.[SR_TITLE_CO_CODE]
--      ,r.[SR_DATE_TRANSFER]
--      ,r.[SR_VAL_TRANSFER]
--      ,r.[SR_DATE_FILING], I.* 
           
--     into dbo.TitleMarketShare_BaseTable_Attorney 
--     from dbo.TitleMarketShare_BaseTable_Attorney_ID I
--     left outer join dbo.Title_marketshare_RT r
--     on I.FIPS = r.Fips and I.SA_PROPERTY_ID = r.SR_PROPERTY_ID and right(I.Deed_Doc_Nbr,4) = right(r.RT_Doc_Nbr,4)  and  LEFT(CONVERT(varchar,I.RECORDING_DATE,112),8) =r.SR_DATE_TRANSFER
     
   
      
--  IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_final

--select * 
--  into dbo.TitleMarketShare_BaseTable_Attorney_final
--  from 
--(
--SELECT  
--DeedId, 
--[MGT Document number] ,
--[Loan Amount] ,
--Lender ,
--[Transaction Type] ,
--[Loan Type] ,
--[Adjustable Rate]
--,[SR_LAWYER_NAME]
--, row_number() over(partition by DeedId, [MGT Document number] ,[Loan Amount] ,Lender ,[Transaction Type] ,[Loan Type] ,[Adjustable Rate]
--      order by sr_lawyer_name desc) as [rn]
    
--from dbo.TitleMarketShare_BaseTable_Attorney
--)x
--where rn =1


-- ------------update attorney name--------------------


  

--update t1
--set  t1.Attorney =  t2.sr_lawyer_name
--From [dbo].[TitleMarketShare_BaseTable] t1
--left outer join dbo.TitleMarketShare_BaseTable_Attorney_final t2
--on t1.DeedID = t2.DeedID and  isnull (t1.[MGT Document number],'') = isnull(t2.[MGT Document number],'') and
--t1.[Loan Amount] = t2.[Loan Amount] and t1.Lender = t2.Lender and t1.[Transaction Type] = t2.[Transaction Type]
--and t1.[Loan Type] = t2.[Loan Type] and t1.[Adjustable Rate] = t2.[Adjustable Rate]
--where 

-- t1.attorney = 'UNKNOWN' and t2.sr_lawyer_name is not null 
--  and t2.sr_lawyer_name <> ''
--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
--  and  t2.SR_LAWYER_NAME not like '%FCU%'
--  and  t2.SR_LAWYER_NAME not like '%S&L%'
  
--   -- IF OBJECT_ID('[dbo].[Title_marketshare_RT]') IS NOT NULL DROP TABLE [dbo].[Title_marketshare_RT]

--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_ID
  
--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney

--     IF OBJECT_ID('dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL DROP TABLE dbo.TitleMarketShare_BaseTable_Attorney_final

   IF OBJECT_ID('dbo.titlemarketshare_dup') IS NOT NULL  DROP TABLE dbo.titlemarketshare_dup


  
------- Fix for Fulton GA

--update t1
--set  t1.Attorney =  t2.sr_lawyer_name
--From [dbo].[TitleMarketShare_BaseTable] t1
--inner join MiNelson.dbo.Fulton_GA_BK_to_RT_match t2
--on t1.DeedID = t2.DeedID
-- and t1.attorney = 'UNKNOWN'  and t2.sr_lawyer_name is not null 
--  and t2.sr_lawyer_name <> ''
--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
--  and  t2.SR_LAWYER_NAME not like '%FCU%'
--  and  t2.SR_LAWYER_NAME not like '%S&L%'

------------------------------------------------------------------

   IF OBJECT_ID('[dbo].[BK_TitleMarketShare_BaseTable_1]') IS NOT NULL  DROP TABLE [dbo].[BK_TitleMarketShare_BaseTable_1]

 select * 
 into  [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1]
 from 
  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  
 --  select MAX(UPDATED)
 --from  [dbo].[BK_TitleMarketShare_BaseTable_1]
  
      -- select * from [dbo].[BK_TitleMarketShare_BaseTable_1]



  ----------------------------already cut over --------------------------
     IF OBJECT_ID('[dbo].[BK_TitleMarketShare_BaseTable]') IS NOT NULL  DROP TABLE [dbo].[BK_TitleMarketShare_BaseTable]

  select a.* 
  into [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable]
  from   [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1] a
  inner join 
   [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver] b
  on a.FIPS = b.fips
  where b.source = 'B' and CutOver = 'Y'
and (DeedID >  (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
	or CONVERT(varchar(10), a.updated ,112) >= (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
	--(select MAX(rundate) from mktshr.TitleMarketShare )
	)
  and Date >= b.StartDate_BK_New
  


   ----------------------new cut over------------------------------
   union all
   (
    select a.* from   [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1] a
  inner join 
   [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver] b
  on a.FIPS = b.fips
  where b.source = 'B' and CutOver = 'N'
  and Date >= b.StartDate_BK_New
  )
  
  union all
  (
  select a.* from   [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable_1] a
  inner join 
    [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver] b
  on a.FIPS = b.fips
  where b.source = 'E' 
 and (DeedID >  (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
	or CONVERT(varchar(10), a.updated ,112) >= (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])
	)
  and Date >= b.StartDate_BK_New and Date <b.StartDate_UR
  )

  --  select * 
  --  from  mktshr.[TitleMarketShare_County_Source_CutOver] b
  -- where b.source = 'B' and CutOver = 'N'
  

-----borrow from RT ---- adding 7/10/2018 by My Phan

  update [MiNelson].[dbo].[b]
  set b.[title company] = RT_TitleCo
 -- select *
  from  [MiNelson].[mktshr].[BK_vs_RT_Deedid] a
inner join [Minelson].[dbo].[BK_TitleMarketShare_BaseTable] b
on a.deedid = b.deedid
where --b.fips in (15001,15003,15007,15009) and 
b.[title company] is null or b.[title company] in ('NONE AVAILABLE') and 
(RT_TitleCo not in ('','ATTORNEY ONLY', 'other', 'NOT AVAILABLE')
and  RT_TitleCo not like 'E TITLE LLC%'
and RT_TitleCo not like 'INDECOMM%' 
and RT_TitleCo not like 'Document%' 
and RT_TitleCo <> 'DPS' 
and RT_TitleCo not like 'SIMPLIFILE%' 
and RT_TitleCo not  like 'Certified Document%'
and RT_TitleCo not  like'SPL Inc'
and  RT_TitleCo not  like 'ATM corp%'
and RT_TitleCo not  like 'WorldWide%'
and RT_TitleCo not  like  'Texas Recording Services LLC%'
and RT_TitleCo not like 'Doc%'
and RT_TitleCo not  like  'DATA SEARCH%'
and RT_TitleCo not  like  'LENDER RECORDING%'
and RT_TitleCo not  like  'CCS RECORDING TEAM%'
and RT_TitleCo not  like  'Ameristar Info Network Llc%'
and RT_TitleCo not  like  'AMERISTAR INFORMATION NETWORK%'
and RT_TitleCo not like 'ISGN RECORDING DEPT%'
and RT_TitleCo not like 'LSI-LPS E RECORDING SOLUTIONS%'
and RT_TitleCo not like 'CSC DOCUMENT RECORDING%'
and RT_TitleCo not like 'CUSTOM RECORDING SOLUTIONS%'
and RT_TitleCo not like 'US RECORDINGS INC%'
and RT_TitleCo not like 'LSI E RECORDING SOLUTIONS%')

  --- borrow from india research Adding 7/10/2018 by My Phan
  

update [MiNelson].[dbo].[c]
set c.[title company] = b.title_company_on_doc
--select *
from  [MiNelson].[mktshr].[BK_vs_RT_Deedid] a
inner join [Minelson].[mktshr].[FAI_Result_eRecording_Weekly] b
on a.RT_fips = b.fips and (a.Recorder_id +1000000000) = b.Deedid
inner join [Minelson].[dbo].[BK_TitleMarketShare_BaseTable] c 
on a.RT_fips = c.fips and c.Deedid = a.deedid 
where --b.fips in (15001,15003,15007,15009) and 
title_company_on_doc not in ('N/A', 'ACCOMMODATION') 
and ( c.[title company] in ('NONE AVAILABLE', 'ACCOMMODATION') 
 or c.[Title Company] like 'E TITLE LLC%'
or c.[Title Company] like 'INDECOMM%' 
or c.[Title Company] like 'Document%' 
or c.[Title Company] = 'DPS' 
or c.[Title Company] like 'SIMPLIFILE%' 
or c.[Title Company]  like 'Certified Document%'
or c.[Title Company]  like'SPL Inc'
or  c.[Title Company]  like 'ATM corp%'
or c.[Title Company]  like 'WorldWide%'
or c.[Title Company]  like  'Texas Recording Services LLC%'
or c.[Title Company] like 'Doc%'
or c.[Title Company]  like  'DATA SEARCH%'
or c.[Title Company]  like  'LENDER RECORDING%'
or c.[Title Company]  like  'CCS RECORDING TEAM%'
or c.[Title Company]  like  'Ameristar Info Network Llc%'
or c.[Title Company]  like  'AMERISTAR INFORMATION NETWORK%'
or c.[Title Company] like 'ISGN RECORDING DEPT%'
or c.[Title Company] like 'LSI-LPS E RECORDING SOLUTIONS%'
or c.[Title Company] like 'CSC DOCUMENT RECORDING%'
or c.[Title Company] like 'CUSTOM RECORDING SOLUTIONS%'
or c.[Title Company] like 'US RECORDINGS INC%'
or c.[Title Company] like 'LSI E RECORDING SOLUTIONS%')
 
 
-------------Update Opendoor to resale_cash 12/4/2019
--  select * from Minelson.[dbo].[BK_TitleMarketShare_BaseTable]

Update [MiNelson].[dbo].[m] 
Set [Transaction Type] = 'Resale - Cash Sale'
,Lender='UNKNOWN'
,[MGT Document number]=''
,[Sales Price]=case when state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY') then 0 else [Sales Price] end
,[Loan Amount]=0
,[Loan To Value]='No Data'
,[Adjustable Rate]='No'
,[Loan Type]='none'
,[Reverse Mortgage]='No'
,[Conforming]='No'
,MTG1_PRIVATE_PARTY_LENDER=null
--- select *
from 
 [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
inner join [MiNelson].[mktshr].[DirectHome] b on b.Buyer= m.Buyer
where  [Transaction Type] = 'Resale'
and [Sales Price]<1000000
and [Loan Amount]>10000000

-------------Estimated saleprice 12/11/2019 and Loan To Value
--select * from Minelson.[dbo].[BK_TitleMarketShare_BaseTable] 


Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * 1.0225
--- select *
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') ---Adding Indiana per Mike M 12/18/2019
   and [loan type] = 'FHA' 
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ('AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI')
   and [loan type] = 'FHA'
   and [Loan To Value]='No Data'

Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * .98
--- select *
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI' ) 
   and [loan type] = 'VA'
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI' ) 
   and [loan type] = 'VA'
   and [Loan To Value]='No Data'
   
Update [MiNelson].[dbo].[m] 
Set [Sales Price] = [Loan Amount] * 1.33
--- select *
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price] = 0 and [Loan Amount] <> 0 --and [Loan Amount] < 15000000
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') 
   and [loan type] not in ('FHA', 'VA'   ) 
Update [MiNelson].[dbo].[m] 
Set [Loan To Value]=CASE WHEN [Sales Price]<>0 THEN convert(VARCHAR(15), round(convert(FLOAT, [Loan Amount] / [Sales Price] * 100), 2)) + '%' ELSE 'No Data' END
from 
[Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  m 
 where [Transaction Type]  in ('Resale',   'REO',  'Subdivision/NewHome')
  and [Sales Price]<> 0 and [Loan Amount] <> 0
   and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI') 
   and [loan type] not in ('FHA', 'VA'   )
   and [Loan To Value]='No Data'


   ---- Remove low values 12/11/2019

   Delete a
 --  select b.[ARMS_LENGTH_ID],  a.*
from [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]    a 
inner join  [Deed].[dbo].[deed] b
	on a.deedid = b.deedid 
	    where [Transaction Type] in ('Resale', 'Resale - Cash Sale', 'Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale', 
								'REO', 'REO - Cash Sale')
   and ([Sales Price] <> 0 and [Sales Price] <5000)
  -- and  not (  [Loan Amount] <> 0 and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY'))
  -- and not (a.[Sales Price] = 0 and  b.ARMS_LENGTH_ID = 1)   
 --and not (a.[Sales Price] = 0 and [Loan Amount] > 4000) change 12/18/2019 remove per Mike M.
 and not ([Loan Amount] = 0 and [sales price] = 0 and state in ( 'AK','ID','IN','KS','LA','ME','MO','MS','MT','ND','NM','TX','UT','WY', 'HI')) --- 1/08/2020 not deleting cashsale for nondisclosure and HI

 ---- Update FA

 
Update [MiNelson].[dbo].[a]
set a.[Title Company] = 'FIRST AMERICAN TITLE'
,a.Attorney = 'UNKNOWN'
from [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  a
where [Title Company] = 'ATTORNEY ONLY' and Attorney like 'first American%'


---- change high loan value to 04/27/2022
update [MiNelson].[dbo].[a]
set a.[Loan Amount] = 0
FROM
       [Minelson].[dbo].[BK_TitleMarketShare_BaseTable] a
	   inner join
  [deed].[dbo].[deed] b
  on a.deedid = b.deedid
  inner join
       [Assr].[dbo].[Assr] c on
             b.Ref_Id = c.Ref_Id
             and b.Fips = c.Fips
where
   
  a.[Transaction Type] in ( 'Refinance')
       and a.[Loan Amount] > 10000000 
  and a.[Loan Amount] > (case when c.Total_Value_Calculated is not null then c.Total_Value_Calculated else 0 end)*10
     and (case when (a.[loan amount] is not null and c.Total_Value_Calculated is not null) then cast((100*a.[Loan Amount]/(c.Total_Value_Calculated+1)) as float) else null end ) > 1000
 and a.Residential = 'YES'


  ----- remove cashsale in non disclosure state

delete a
  from  [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]  a
  inner join [deed].[dbo].[deed] b
  on a.deedid = b.deedid
    where date >= '2017-01-01' and 
	[Transaction Type] in ( 'Resale - Cash Sale')
  and residential = 'Yes' 
 and (left([seller name],5) = left(buyer,5)   
 or b.DETAILED_DOC_TYPE  in ( 'DI', 'CD','EX','AF','VL', 'AD', 'AN', 'ID', 'QC', 'GF'))
      and [Sales Price] = 0 and State  in ('AK', 'ID', 'IN', 'KS', 'LA','ME','MS', 'MO', 'MT', 'NM', 'ND', 'TX', 'UT' ,'WY')

	 --- Change to Venture Title & Escrow for ID per Coreln 2024-12-18

update [MiNelson].[dbo].[a]
set [title company] =   'VENTURE TITLE & ESCROW'
-- select * 
from [Minelson].[dbo].[BK_TitleMarketShare_BaseTable] a
  where [title company] like 'VENTURE TITLE%'
  and state = 'ID'


  delete 
from [Minelson].[dbo].[BK_TitleMarketShare_BaseTable] 
where date >CONVERT(varchar(10), GETDATE(),126)

	update [MiNelson].[dbo].[a]
		set [county] = Upper([county])
		-- select *
		FROM [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]   a
		where county  COLLATE Latin1_General_CS_AS LIKE '%[abcdefghijklmnopqrstuvwxyz]%';

		
update [MiNelson].[dbo].[a]
set lender  =   'UNKNOWN'
-- select *
from [Minelson].[dbo].[BK_TitleMarketShare_BaseTable]   a
where  
                lender like '%Account%'

                and lender not like '%Accounting%'

                and lender not like '%Accountan%'

                and lender not like '%Account'

                and lender not like '%Account llc%'


END  





