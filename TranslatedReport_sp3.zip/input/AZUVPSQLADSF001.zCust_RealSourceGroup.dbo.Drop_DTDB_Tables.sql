SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [zCust_RealSourceGroup].[dbo].[Drop_DTDB_Tables]
as
BEGIN

/****** Object:  Table [dbo].[w_UniqueRefId]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_UniqueRefId]


/****** Object:  Table [dbo].[w_RAS]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_RAS]


/****** Object:  Table [dbo].[w_PropertyReference]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_PropertyReference]


/****** Object:  Table [dbo].[w_PreForeclosure]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_PreForeclosure]


/****** Object:  Table [dbo].[w_LastSaleDATA]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_LastSaleDATA]


/****** Object:  Table [dbo].[w_HistDeed]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_HistDeed]


/****** Object:  Table [dbo].[w_FCT_DOC_NAME]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_FCT_DOC_NAME]


/****** Object:  Table [dbo].[w_DOC_XREF]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DOC_XREF]


/****** Object:  Table [dbo].[w_DM_Data]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DM_Data]


/****** Object:  Table [dbo].[w_DIM_NOVA_DOCUMENT]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DIM_NOVA_DOCUMENT]


/****** Object:  Table [dbo].[w_DIM_CLNAME]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DIM_CLNAME]


/****** Object:  Table [dbo].[w_DEEDHIST]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DEEDHIST]


/****** Object:  Table [dbo].[w_DEED]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_DEED]


/****** Object:  Table [dbo].[w_AVM_Coverage]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_AVM_Coverage]


/****** Object:  Table [dbo].[w_AVM]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_AVM]


/****** Object:  Table [dbo].[w_Assr]    Script Date: 06/11/2020 4:15:45 AM ******/
DROP TABLE [dbo].[w_Assr]





END

