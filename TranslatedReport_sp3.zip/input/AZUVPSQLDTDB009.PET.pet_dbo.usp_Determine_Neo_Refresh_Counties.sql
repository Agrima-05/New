/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Determine_Neo_Refresh_Counties | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Determine_Neo_Refresh_Counties] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

DECLARE	@ERROR varchar(500)  

EXEC	PET.pet_dbo.usp_Determine_Neo_Refresh_Counties
		@ERROR = @ERROR OUTPUT



******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Determine_Neo_Refresh_Counties'
		,N'Started'

	DECLARE @LinkSvr VARCHAR(100) = ''

	SET @LinkSvr = CASE 
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB009'
				THEN '[DTRA-DTS-NEO08.DATATRACE.LOCAL].'
			WHEN @@SERVERNAME = N'AZUVPSQLDTDB029'
				THEN '[DTRA-DTS-NEO08 Control].'
			ELSE '[AZUVNSQLDTLM011.DATATRACE.LOCAL].'
			END

	DECLARE @sqlcmd VARCHAR(max)

	SET @sqlcmd = N'


DROP TABLE

IF EXISTS Pet.tmp.Neo_dates
	SELECT a.*
	INTO Pet.tmp.Neo_dates
	FROM (
		SELECT a.Update_Date
			,[State_Code]
			,[County_Code]
			,try_cast(fips AS INT) fips
			,[County_Name]
			,ROW_NUMBER() OVER (
				PARTITION BY fips ORDER BY a.Update_Date DESC
				) AS ROW4
		FROM ' + @LinkSvr + '[Neo_Control].[TR00].[Static_Tax_Load_Status] a
		) a
	WHERE row4 = 1

CREATE INDEX idx_fips ON Pet.tmp.Neo_dates (Fips)


UPDATE c
SET c.Process_Flag = 1
FROM pet.dbo.pet_counties a
LEFT JOIN Pet.tmp.Neo_dates b ON b.fips = a.fips
LEFT JOIN pet.dbo.PET_Enhanced_Process_List c ON c.FIPS = a.Fips
WHERE a.STAGE_SSIS_connectiON IS NOT NULL
	AND a.process_Date < b.Update_Date
'

	--SELECT @sqlcmd  
	EXEC (@sqlcmd)

	--select a.Fips, try_cast(a.Process_Date as date) as process_Date
	--,b.*
	--,c.*
	--
	-- Below we detemine that all counties on todays run have ASSR records
	-- If not , then we abort
	--
	-- DECLARE @sqlcmd VARCHAR(MAX)
	DECLARE @assr_Svr VARCHAR(100) = ''

	SET @assr_Svr = CASE 
			WHEN @@SERVERNAME = 'AZUVNSQLDTDB003'
				THEN ''
			ELSE '[dws-etl01].'
			END
	SET @sqlcmd = N'

		 IF (
					SELECT count(1) AS null_cnt
					FROM (
						SELECT l.FIPS
							,a.cnt
						FROM [PET].[dbo].[PET_Enhanced_Process_List] l
						inner join pet.dbo.pet_counties c on c.fips = l.fips
						OUTER APPLY (
							SELECT count(1) AS cnt
							FROM ' + @assr_Svr + 'assr.dbo.assr a
							WHERE a.fips = c.assr_fips
							) a
						WHERE l.[Process_Flag] = 1
						) a
					WHERE a.cnt = 0
					) > 0
			BEGIN
				RAISERROR (
						''One or More counties to run have no ASSR data''
						,16
						,1
						);
			END
'

	--SELECT @sqlcmd  
	EXEC (@sqlcmd)

	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Determine_Neo_Refresh_Counties'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


