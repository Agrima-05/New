SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Parse Features
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_250_Features_Interior_v3]

AS
BEGIN

	SET NOCOUNT ON;
		declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).

		DECLARE @currentDatetime AS DATETIME
		DELETE FROM [src_PlatLabs].[features].[InteriorJSON] WHERE [uid] in (Select [uid] from [src_PlatLabs].[listing].[ListingsRaw_Batch] with(NOLOCK))
		SET @currentDatetime = GETDATE()

		INSERT INTO [src_PlatLabs].[features].[InteriorJSON] 
		SELECT [uid], mls_id, mls_listing_id, j.[key], replace(replace(replace(j.[value],'A/C', 'AC'),'Disability Feature','DisabilityFeature'),'Eco/Green Feature','EcoGreenFeature') as Interior, j.[type], @currentDatetime
		FROM [src_PlatLabs].[listing].[ListingsRaw_Batch] t1 with(NOLOCK) 
		CROSS APPLY OPENJSON(t1.Features) AS t 
		CROSS APPLY OPENJSON(t.value, '$.Interior') AS j
			   
			DROP TABLE IF EXISTS Table_E
			DROP TABLE IF EXISTS Table_F
			DROP TABLE IF EXISTS Table_G
			DROP TABLE IF EXISTS Table_H
			DROP TABLE IF EXISTS Table_I
			DROP TABLE IF EXISTS Table_J
			DROP TABLE IF EXISTS Table_K
			DROP TABLE IF EXISTS Table_L
			DROP TABLE IF EXISTS Table_M
			DROP TABLE IF EXISTS Table_N
			DROP TABLE IF EXISTS Table_O

			Select MLSID,MLS_LISTING_ID,[AC] INTO [src_PlatLabs].[dbo].[Table_e]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(replace([Interior],'A/C','AC')) WITH([AC] varchar(1000)) as AC_array
						WHERE (Interior like '%"A/C"%' OR Interior like '%"AC"%')
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_e(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_e(MLSID)

			Select MLSID,MLS_LISTING_ID,[Appliances] INTO [src_PlatLabs].[dbo].[Table_f]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Appliances] varchar(1000)) as Appliances_array
						WHERE Interior like '%"Appliances"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_f(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_f(MLSID)

			Select MLSID,MLS_LISTING_ID,[Basement] INTO [src_PlatLabs].[dbo].[Table_g]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Basement] varchar(1000)) as Basement_array
						WHERE Interior like '%"Basement"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_g(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_g(MLSID)

			Select MLSID,MLS_LISTING_ID,[DisabilityFeature] INTO [src_PlatLabs].[dbo].[Table_h]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(replace([Interior],'Disability Feature','DisabilityFeature')) WITH([DisabilityFeature] varchar(1000)) as Disability_array
						WHERE Interior like '%"Disability Feature"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_h(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_h(MLSID)

			Select MLSID,MLS_LISTING_ID,[EcoGreenFeature] INTO [src_PlatLabs].[dbo].[Table_i]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON(replace([Interior],'Eco/Green Feature','EcoGreenFeature')) WITH([EcoGreenFeature] varchar(1000)) as Green_array
						WHERE Interior like '%"Eco/Green Feature"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_i(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_i(MLSID)

			Select MLSID,MLS_LISTING_ID,[Fireplace] INTO [src_PlatLabs].[dbo].[Table_j]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Fireplace] varchar(1000)) as Fireplace_array
						WHERE Interior like '%"Fireplace"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_j(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_j(MLSID)

			Select MLSID,MLS_LISTING_ID,[Flooring] INTO [src_PlatLabs].[dbo].[Table_k]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Flooring] varchar(1000)) as Flooring_array
						WHERE Interior like '%"Flooring"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_k(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_k(MLSID)

			Select MLSID,MLS_LISTING_ID,[General] INTO [src_PlatLabs].[dbo].[Table_l]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([General] varchar(1000)) as General_array
						WHERE Interior like '%"General"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_l(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_l(MLSID)

			Select MLSID,MLS_LISTING_ID,[Heating] INTO [src_PlatLabs].[dbo].[Table_m]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Heating] varchar(1000)) as Heating_array
						WHERE Interior like '%"Heating"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_m(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_m(MLSID)

			Select MLSID,MLS_LISTING_ID,[Laundry] INTO [src_PlatLabs].[dbo].[Table_n]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Laundry] varchar(1000)) as Laundry_array
						WHERE Interior like '%"Laundry"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_n(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_n(MLSID)

			Select MLSID,MLS_LISTING_ID,[Rooms] INTO [src_PlatLabs].[dbo].[Table_o]
					from [src_Platlabs].[features].[InteriorJSON] with(NOLOCK)
							CROSS APPLY OPENJSON([Interior]) WITH([Rooms] varchar(1000)) as Rooms_array
						WHERE Interior like '%"Rooms"%'
						and [uid] in(Select [uid] From [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK))

			Create INDEX ix_MlsIDListingID on Table_o(MLSID,MLS_LISTING_ID)
			create INDEX ix_MLSID on Table_o(MLSID)

			Delete FROM [src_PlatLabs].[dbo].[Table_E] WHERE [AC] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_F] WHERE [Appliances] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_G] WHERE [Basement] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_H] WHERE [DisabilityFeature] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_I] WHERE [EcoGreenFeature] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_J] WHERE [Fireplace] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_K] WHERE [Flooring] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_L] WHERE [General] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_M] WHERE [Heating] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_N] WHERE [Laundry] is NULL
			Delete FROM [src_PlatLabs].[dbo].[Table_O] WHERE [Rooms] is NULL


			EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).


END




