SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



-- =============================================
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_300_Start_Output_MONITOR_PROCTOR_STEP3]

AS
BEGIN
	
	SET NOCOUNT ON;

	
		

		/****** Object:  Index [NonClusteredIndex-20180712-100727]    Script Date: 8/31/2018 6:54:05 PM ******/
		CREATE UNIQUE NONCLUSTERED INDEX [NonClusteredIndex-NOD] ON [dbo].[x_Custom_OUTPUT]
		(
			[NOD_NOS_RecordedDocumentNumber] ASC,
			[NOD_NOS_RecordingDate] ASC,
			[INPUTKEY] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	

		Truncate table NOD_NOS_RELEASE_COMBINED

		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]([INPUTKEY],[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr]
	   ,[SUP])
	   Select A.INPUTKEY,NULL,convert(date,B.REcordingDate) as NOD_NOS_RecordingDate,B.DocumentID as NOD_NOS_RecordedDocumentNumber
		,B.Document_Title_Text as NOD_NOS_DocType
		, B.LienAmount as NOD_NOS_DefaultAmount
		, B.LawName as HOA_TrusteeAttorneyName
		,B.LawPhone as HOA_TrusteeAttorneyPhoneNumber
		,B.Auction_Date as HOA_AuctionDate
		,B.OrigRecDate as NOD_NOS_OrigRecDate
		,B.OrigDocNbr as NOD_NOS_OrigDocNbr
		,B.[SUP]
		--,A.Work_REF_ID
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] A JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] as B 
		on A.INPUTKEY = B.INPUTKEY


		

		--Update A
		--Set 
		--A.NOD_NOS_RecordNbr = '1'
		--,A.NOD_NOS_RecordingDate = convert(date,B.REcordingDate)
		--,A.NOD_NOS_RecordedDocumentNumber = B.DocumentID
		--,A.NOD_NOS_DocType = B.Document_Title_Text
		--,A.NOD_NOS_DefaultAmount = B.LienAmount
		--,A.HOA_TrusteeAttorneyName = B.LawName
		--,A.HOA_TrusteeAttorneyPhoneNumber = B.LawPhone
		--,A.HOA_AuctionDate = B.Auction_Date
		--,A.NOD_NOS_OrigRecDate = B.OrigRecDate
		--,A.NOD_NOS_OrigDocNbr =  B.OrigDocNbr
		----Select * 																	
		--FROM x_Custom_OUTPUT A JOIN HOA_NOD as B 
		--on A.INPUTKEY = B.INPUTKEY
		--WHERE B.RowNbr = 1


	


		--SELECT INPUTKEY,count(*)  as NbrOfRecordings FROM HOA_NOD 
		--GROUP BY INPUTKEY
		--having count(*) > 3

		--Select * From HOA_NOD
		--where INPUTKEY = 'NV3979'


		
		UPdate [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [NbrofRecordings_NOD_NOS] = NULL
		
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.[NbrofRecordings_NOD_NOS] = b.[NbrofRecordings_NOD_NOS]
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN (SELECT INPUTKEY,count(*)  as [NbrofRecordings_NOD_NOS] FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD] 
		GROUP BY INPUTKEY) b
		on a.INPUTKEY = b.INPUTKEY


		--UPdate x_custom_OUTPUT
		--Set NbrOfRecordings = NULL
		
		--UPDATE a
		--SET a.NbrOfRecordings = b.NbrOfRecordings
		--FROM x_Custom_OUTPUT a JOIN (SELECT INPUTKEY,count(*)  as NbrOfRecordings FROM HOA_NOD 
		--GROUP BY INPUTKEY) b
		--on a.INPUTKEY = b.INPUTKEY

		---------------------------------------------BUILD OUT RELEASES----------------------------------------------------------------------

		EXEC [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_NOD_NOS_RELEASE]

		--Select --*
		--FIPS, INPUTKEY,REF_ID, Identifier, NOD_NOS_Recorded_Document_Number, DOcType, REcordingDate
		--,OAReference,OAReferenceAlt, LIEN_DOC_NUMBER  
		--From HOA_NOD_NOS_RELEASE

		EXEC [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_LIEN_RELEASE_SUP]



		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist]
		Set toUSE = NULL

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = 'Y'
		--Select convert(date,a.RecordingDate),b.LIENDATE,A.OrigTransRecDate,A.OrigTransDocNumber,B.LIEN_DOC_NUMBER,A.DOcumentTypeDesc
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] b
		on a.Raw_ID = b.INPUTKey
		WHERE 
		convert(date,a.RecordingDate) > convert(date,b.LIENDATE)
		AND Doc_Src_Ind like 'R'
		AND A.OrigTransRecDate = B.LIENDATE
		AND A.OrigTransDocNumber = B.LIEN_DOC_NUMBER
		AND (A.DOcumentTypeDesc like '%Release%' or A.DOcumentTypeDesc like '%Rescission%' or A.DOcumentTypeDesc like '%Recission%')





		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET toUSE = 'Y'
		--Select convert(date,a.RecordingDate),A.OrigTransRecDate,A.OrigTransDocNumber,A.DOcumentTypeDesc
		from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_TRACKING_HIST] b
		on a.Raw_ID = b.INPUTKey
		WHERE 
		convert(date,a.RecordingDate) > convert(date,b.[NOD_NOS_RecordingDate])
		AND Doc_Src_Ind like 'R'
		AND A.OrigTransRecDate = B.[NOD_NOS_RecordingDate]
		AND A.OrigTransDocNumber = B.[NOD_NOS_RecordedDocumentNumber]
		AND (A.DOcumentTypeDesc like '%Release%' or A.DOcumentTypeDesc like '%Rescission%' or A.DOcumentTypeDesc like '%Recission%')



		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]([FIPS],[REF_ID],[INPUTKey],[NOD_NOS_Recording_Date]   ,[NOD_NOS_Recorded_Document_Number] ,[DocType] ,[NOD_NOS_Default_Amount])
		SELECT distinct a.FIPS,a.REF_ID,a.Raw_ID 
		,convert(varchar(8),a.RecordingDate,112)
		,CASE WHEN a.DocumentNbr like '%.%.%' THEN ltrim(rtrim(REPLACE(REPLACE(a.DocumentNbr,'.00','.'),'.0','.'))) ELSE ltrim(rtrim(a.DocumentNbr)) END
		,UPPER(DocumentTypeDesc),isNULL(Value,0)
		--Select * 
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] A
		WHERE toUSE = 'Y' 


		
		INSERT INTO [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]( ID, Fips, REF_ID, PKID, Identifier, CmtId, DocumentId, Sequence, BatchDate, DocType, State, County, RecordingDate, RecordingYear, DocumentDate, 
                         HeaderSequence, LienDate, LienAmount, DateofFirstMissedPayment, NOD_NOS_Recording_Date, NOD_NOS_Recorded_Book, NOD_NOS_Recorded_Page, 
                         NOD_NOS_Recorded_Document_Number, NOD_NOS_Default_Amount, HOA_Auction_Date, CaseNumber, CourtType, MAName, MAAddress, MAZip, MACity, MAState, 
                         MAEmail, MAPhone, MAContact, MASequence, [HOA_Trustee_Attorney Name], HOA_Trustee_Attorney_Phone_Number, LAWName, LAWAddress, LAWZip, LAWCity, 
                         LAWState, LAWEmail, LAWPhone, LAWLastName, LAWFirstName, LAWMI, LAWSfx, OWNLastName, OWNFirstName, OWNMI, OWNSfx, OWNSpouseFirst, 
                         OWNSpouseMiddle, OWNSpouseFlag, OWNSameAsProperty, OWNAddress, OWNZip, OWNCity, OWNState, OWNSequence, PropAPN, PropAddress, PropZip, 
                         PropCity, PropState, PropSequence, OAReference, OAReferenceAlt, ReferenceBook, ReferencePage, ReferenceYear, ReferenceDocNo, ReferenceRecordingDate, 
                         SourceId, SourcePK, SourceCreatedDate, SourceTruncationOccur, MULTI_APN, HOAName, HOAAddress, HOAZip, HOACity, HOAState, HOAEmail, HOAPhone, 
                         HOAContact, SSCC, TAXAPN, Created, updated, FMT_ReferenceDocNo, FMT_ReferenceBookPage, IsHoaLienActive, HOA_Std_FIPS, HOA_Std_Street_Number, 
                         HOA_Std_Direction, HOA_Std_Street_Name, HOA_Std_Street_Type, HOA_Std_Post_Direction, HOA_Std_Unit_Type, HOA_Std_Unit, HOA_Std_City, HOA_Std_State, 
                         HOA_Std_Zip, HOA_Std_Plus4, HOA_Std_PlaceCode, HOA_Std_PlaceName, HOA_Std_Verified, HOA_Std_AddressMatchResults, MA_Std_FIPS, 
                         MA_Std_Street_Number, MA_Std_Direction, MA_Std_Street_Name, MA_Std_Street_Type, MA_Std_Post_Direction, MA_Std_Unit_Type, MA_Std_Unit, MA_Std_City, 
                         MA_Std_State, MA_Std_Zip, MA_Std_Plus4, MA_Std_PlaceCode, MA_Std_PlaceName, MA_Std_Verified, MA_Std_AddressMatchResults, LAW_Std_FIPS, 
                         LAW_Std_Street_Number, LAW_Std_Direction, LAW_Std_Street_Name, LAW_Std_Street_Type, LAW_Std_Post_Direction, LAW_Std_Unit_Type, LAW_Std_Unit, 
                         LAW_Std_City, LAW_Std_State, LAW_Std_Zip, LAW_Std_Plus4, LAW_Std_PlaceCode, LAW_Std_PlaceName, LAW_Std_Verified, LAW_Std_AddressMatchResults, 
                         INPUTKEY, LIEN_DOC_NUMBER, RecordNumber,[SUP])
		SELECT        ID, Fips, REF_ID, PKID, Identifier, CmtId, DocumentId, Sequence, BatchDate, DocType, State, County, RecordingDate, RecordingYear, DocumentDate, 
                         HeaderSequence, LienDate, LienAmount, DateofFirstMissedPayment, NOD_NOS_Recording_Date, NOD_NOS_Recorded_Book, NOD_NOS_Recorded_Page, 
                         NOD_NOS_Recorded_Document_Number, NOD_NOS_Default_Amount, HOA_Auction_Date, CaseNumber, CourtType, MAName, MAAddress, MAZip, MACity, MAState, 
                         MAEmail, MAPhone, MAContact, MASequence, [HOA_Trustee_Attorney Name], HOA_Trustee_Attorney_Phone_Number, LAWName, LAWAddress, LAWZip, LAWCity, 
                         LAWState, LAWEmail, LAWPhone, LAWLastName, LAWFirstName, LAWMI, LAWSfx, OWNLastName, OWNFirstName, OWNMI, OWNSfx, OWNSpouseFirst, 
                         OWNSpouseMiddle, OWNSpouseFlag, OWNSameAsProperty, OWNAddress, OWNZip, OWNCity, OWNState, OWNSequence, PropAPN, PropAddress, PropZip, 
                         PropCity, PropState, PropSequence, OAReference, OAReferenceAlt, ReferenceBook, ReferencePage, ReferenceYear, ReferenceDocNo, ReferenceRecordingDate, 
                         SourceId, SourcePK, SourceCreatedDate, SourceTruncationOccur, MULTI_APN, HOAName, HOAAddress, HOAZip, HOACity, HOAState, HOAEmail, HOAPhone, 
                         HOAContact, SSCC, TAXAPN, Created, updated, FMT_ReferenceDocNo, FMT_ReferenceBookPage, IsHoaLienActive, HOA_Std_FIPS, HOA_Std_Street_Number, 
                         HOA_Std_Direction, HOA_Std_Street_Name, HOA_Std_Street_Type, HOA_Std_Post_Direction, HOA_Std_Unit_Type, HOA_Std_Unit, HOA_Std_City, HOA_Std_State, 
                         HOA_Std_Zip, HOA_Std_Plus4, HOA_Std_PlaceCode, HOA_Std_PlaceName, HOA_Std_Verified, HOA_Std_AddressMatchResults, MA_Std_FIPS, 
                         MA_Std_Street_Number, MA_Std_Direction, MA_Std_Street_Name, MA_Std_Street_Type, MA_Std_Post_Direction, MA_Std_Unit_Type, MA_Std_Unit, MA_Std_City, 
                         MA_Std_State, MA_Std_Zip, MA_Std_Plus4, MA_Std_PlaceCode, MA_Std_PlaceName, MA_Std_Verified, MA_Std_AddressMatchResults, LAW_Std_FIPS, 
                         LAW_Std_Street_Number, LAW_Std_Direction, LAW_Std_Street_Name, LAW_Std_Street_Type, LAW_Std_Post_Direction, LAW_Std_Unit_Type, LAW_Std_Unit, 
                         LAW_Std_City, LAW_Std_State, LAW_Std_Zip, LAW_Std_Plus4, LAW_Std_PlaceCode, LAW_Std_PlaceName, LAW_Std_Verified, LAW_Std_AddressMatchResults, 
                         INPUTKEY, LIEN_DOC_NUMBER, RecordNumber,[SUP]
		FROM            [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_LIEN_RELEASE]
		

		--Select * From HOA_NOD_NOS_RELEASE
		

		--Select * From [HOA_LIEN_RELEASE] as A join LIEN_TRACKING_HIST as B on 
		--A.INputkey = B.INPUTKEY
		--and A.NOD_NOS_Recorded_Document_Number  = B.LIEN_DOC_NUMBER

		
		--Select * From HOA_NOD_NOS_RELEASE

			Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
			--Select A.INPUTKEY, FIPS, A.REF_ID, DocType, REcordingDate,  NOD_NOS_Recorded_Document_Number, OAReference, 
			--RELEASE_RecordingDate	,RELEASE_RecordedDocumentNumber	,DATE_SENT
			From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] as B on 
			A.INPUTKEY = B.INPUTKEY
			and A.NOD_NOS_Recorded_Document_Number = B.RELEASE_RecordedDocumentNumber
			--Order by A.INPUTKEY


			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]
			Set REcordNumber = 0

		
			UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY INPUTKEY,REF_ID ORDER BY RecordingDate DESC) AS RowNum
				FROM 
			[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] t ) r ON t.REF_ID = r.REF_ID AND (t.NOD_NOS_Recorded_Document_Number = r.NOD_NOS_Recorded_Document_Number 
			OR t.DocumentId = R.DocumentId)
			and t.INPUTKEY = r.INPUTKEY



		------------------------COMBINED NOD_NOS_RELEASE-----------
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED](INPUTKEY,[RecordNumber]      ,[NOD_NOS_RecordingDate]      ,[NOD_NOS_RecordedDocumentNumber]      ,[NOD_NOS_DocType]      ,[NOD_NOS_DefaultAmount]
       ,[HOA_TrusteeAttorneyName]      ,[HOA_TrusteeAttorneyPhoneNumber]      ,[HOA_AuctionDate]      ,[NOD_NOS_OrigRecDate]      ,[NOD_NOS_OrigDocNbr],[SUP])

	   Select 	distinct A.INPUTKEY,NULL,
	   convert(date,convert(varchar(10),B.REcordingDate,126))
		, B.NOD_NOS_Recorded_Document_Number
		--,B.DocType
		--,A.FIPS,A.CountyName
		,D.Full_Name
		, B.LienAmount
		, B.LawName
		, B.LawPhone
		,NULL
		,NULL
		,NULL
		--Select B.* 	
		,[SUP]						
		FROM  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] as B 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] A 
		on A.INPUTKEY = B.INPUTKEY
		-----Changed 20191114 to use new doc table----
		join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D
		on B.DocType = D.DocType
		--join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
		--on B.DocType = D.[HOA_Doc_Type]
		--where D.Full_Name is null
		



			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
			Set REcordNumber = 0

			--Select * From NOD_NOS_RELEASE_COMBINED
			--Order by RecordNumber desc

		

		
			UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET REcordNumber = RowNum
			--Select *
			FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY [NOD_NOS_RecordingDate] DESC) AS RowNum
				FROM 
			[zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] t ) r ON t.INPUTKEY = r.INPUTKEY AND (t.[NOD_NOS_RecordedDocumentNumber] = r.[NOD_NOS_RecordedDocumentNumber])
			and t.INPUTKEY = r.INPUTKEY
			--Order by RowNum


			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.INPUTKEY,A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			(A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Inst_Nbr OR 
			A.NOD_NOS_RecordedDocumentNumber = B.Fmt_Book_Page 
			)
			where 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null


			
			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
			Set A.HOA_AuctionDate = B.Auction_Date
			--Select A.INPUTKEY,A.NOD_NOS_RecordedDocumentNumber,A.HOA_AuctionDate
			--,B.Fmt_Inst_Nbr, B.Fmt_Book_Page, B.Auction_Date
			FRom [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] AS A 
			join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Preforeclosure] as B on A.NOD_NOS_RecordingDate = B.Recording_Date
			and 
			A.NOD_NOS_RecordedDocumentNumber =
			left(Fmt_Inst_Nbr,len(Fmt_Inst_Nbr)-charindex('.',REVERSE(Fmt_Inst_Nbr))) + '.' 
			+ SUBSTRING(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1), PATINDEX('%[^0]%', Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)+'.'), LEN(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)))
			where A.NOD_NOS_RecordedDocumentNumber like '%.%.%'
			AND Fmt_Inst_Nbr like '%.%.%'
			AND 
			(A.HOA_AuctionDate is null or A.HOA_AuctionDate like '')
			AND B.Auction_Date is not null



			--Select Fmt_Inst_Nbr,
			--left(Fmt_Inst_Nbr,len(Fmt_Inst_Nbr)-charindex('.',REVERSE(Fmt_Inst_Nbr))) + '.' 
			----, Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)
			--+ SUBSTRING(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1), PATINDEX('%[^0]%', Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)+'.'), LEN(Right(Fmt_Inst_Nbr, charindex('.',REVERSE(Fmt_Inst_Nbr))-1)))
			-- From w_Preforeclosure
			--where REF_ID = '83205017'

			--Select * From NOD_NOS_RELEASE_COMBINED
			--where INPUTKEY = '1548405'



			--Select top 10 * FRom NOD_NOS_RELEASE_COMBINED

			--Select top 10 * FRom w_Preforeclosure

		--Select * From NOD_NOS_RELEASE_COMBINED as A join x_custom_OUTPUT as B on A.INPUTKEY = B.INPUTKEY
		--where B.WORK_REF_ID in  ('35679608','35294290')


								
------------------------Added 20191105 per NH - Need to add REO Deeds with recording date in the last 60 days 
---------------------AND more recent than most recent HOA Lien recording date if one is populated----
---------------Per NH - REO is now to go in the NOD section - NOT HOA Lien---AARGH!!!!!!-------
		

		Select NOD_NOS_DocType, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
		Group by NOD_NOS_DocType
		Order by NOD_NOS_DocType


		Select B.REF_ID, B.DocumentNbr, B.DocumentType, B.RecordingDate , B.Doc_Src_Ind
		,C.State, C.[County Name], A.NOD_NOS_DocType
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] as A 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] as B on A.INPUTKEY = B.RAW_ID
		and A.NOD_NOS_RecordedDocumentNumber = B.DocumentNbr
		join [global].[dbo].[county] as C on B.FIPS = C.FIPSCODE
		where NOD_NOS_DocType like 'LIS PENDENS%'
		Order by B.DocumentType

		--Select * From NOD_NOS_RELEASE_COMBINED
		--where INPUTKEY = '0578945606 4817648'

		--Select * From x_Custom_OUTPUT where WORK_REF_ID = '34113007'

		--Select FIPS, REF_ID, Fmt_Inst_Nbr, Lis_Pendens_Type, Document_Type From w_PreForeclosure where REF_ID = '34113007'

		--Select * From HOA.dbo.HOA_Lien with(NOLOCK)
		--where REF_ID = '34113007'

		--Select B.FIPS, B.CountyName, B.WORK_REF_ID,A.* From NOD_NOS_RELEASE_COMBINED as A join x_Custom_OUTPUT as B on 
		--A.INPUTKEY = B.INPUTKey
		--where A.NOD_NOS_DocType is null

		--Select * From HOA.dbo.HOA_LIEN
		--where REF_ID = '2987837'


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist]
		Set ToUse = NULL
		where ToUSe is not null

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.ToUse = 'Y'
		--Select B.MAX_LIENDATE,A.*
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on 
		A.RAW_ID = B.INPUTKEY
		where A.DOc_SRc_Ind like 'D'
		--and (A.RecordingDate > B.MAX_LIENDATE
		--or B.MAX_LIENDATE is null)
		AND A.RecordingDate >= Getdate()-60
		AND A.Foreclosure_Flag like '1'


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.DocumentTypeDesc = B.Document_Name
		--Select A.DocumentType, A.DocumentTypeDesc, B.*
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist] as A join 
		[AZUVPSQLDTDB029.datatree.local].[NovaDimDoc].[dbo].Doc_Types as B on
		Convert(int,A.FIPS) = B.FIPS
		AND A.DocumentType = B.Output_Code
		where A.ToUSe = 'Y'
		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.Document_Name,'')


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.DocumentTypeDesc = B.[Code Description]
		--Select A.DocumentType, A.DocumentTypeDesc, B.*
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist] as A join 
		[AZUVPSQLDTDB029.datatree.local].[Deed].[dbo].[DeedLookup] as B on
		A.DocumentType = b.Value
		where A.ToUSe = 'Y'
		AND (Ltrim(Rtrim([Deed_Table_Column_name])) like 'DETAILED_DOC_TYPE'
				or [Deed_Table_Column_name] like 'DETAILED_DOC_TYPE ')
		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.[Code Description],'')
		

		Select DocumentType,DocumentTypeDesc, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist]
		where ToUse = 'Y'
		Group by DocumentType,DocumentTypeDesc
		Order by DocumentType,DocumentTypeDesc

		
		--Exec dbo.usp_502_Pull_FLANK_DATA_V2

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist_FLANK]
		Set ToUse = NULL
		where ToUSe is not null


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.ToUse = 'Y'
		--Select B.MAX_LIENDATE,A.*
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist_FLANK] as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as B on 
		A.RAW_ID = B.INPUTKEY
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.RAW_ID = B.INPUTKey
		where A.DOc_SRc_Ind like 'D'
		--and (A.RecordingDate > B.MAX_LIENDATE
		--or B.MAX_LIENDATE is null)
		AND A.RecordingDate >= Getdate()-60
		AND A.REO like '1'
		and (convert(date,A.RecordingDate) > convert(date,C.MAX_REO_DATE)
		OR C.MAX_REO_DATE is null)
		--Order by B.MAX_LIENDATE desc

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.DocumentTypeDesc = B.CodeDesc
		--Select A.PROPERTYID,A.DocumentType, A.DocumentTypeDesc, A.FIPS, A.DocumentNbr,A.RecordingDate,C.State, C.[County Name],B.*
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist_FLANK] as A join 
		[Global].[dbo].[lkup_Doc_Type] as B on
		A.DocumentType = B.DocTypeID
		join [global].[dbo].[county] as C with(NOLOCK) on A.FIPS = C.FIPSCODE
		where A.ToUSe = 'Y'
		and ISNULL(A.DocumentTypeDesc,'') not like ISNULL(B.CodeDesc,'')

		--Select FIPS, FAPropertyId, DocNbrSrce, CMTIDInstNbr,DocumentTypeCode, Reo, REOSale From data.dbo.Deed with(NOLOCK)
		--where FIPS = '12099' and FAPropertyId = '33844930'
		-----30901.730
		-----116083973

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] ([INPUTKEY],NOD_NOS_RecordedDocumentNumber,NOD_NOS_DocType,NOD_NOS_RecordingDate,NOD_NOS_DefaultAmount
		,HOA_TrusteeAttorneyPhoneNumber)
		
	   Select DISTINCT A.RAW_ID
	   ,case when ISNULL(DocumentNbr,'') like '' then 'Unknown' else DocumentNbr end
	   ,A.DocumentTypeDesc 
	   ,A.RecordingDate
	   ,A.Value
	   ,'REO'
	   --,B.MAX_REO_DATE
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist_FLANK] as A 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.INPUTKEY
		--join x_custom_OUTPUT as B on 
		--A.RAW_ID = B.INPUTKEY
		where A.ToUse = 'Y'
		and (convert(date,A.RecordingDate) > convert(date,B.MAX_REO_DATE)
		OR B.MAX_REO_DATE is null)
		Order by A.DocumentTypeDesc 

		

		-----Backfill with DTDB-----
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] ([INPUTKEY],NOD_NOS_RecordedDocumentNumber,NOD_NOS_DocType,NOD_NOS_RecordingDate,NOD_NOS_DefaultAmount
		,HOA_TrusteeAttorneyPhoneNumber)

	   Select DISTINCT A.RAW_ID
	    ,case when ISNULL(DocumentNbr,'') like '' then 'Unknown' else DocumentNbr end
	   ,A.DocumentTypeDesc 
	   ,A.RecordingDate
	   ,A.Value
	   ,'REO'
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_Transhist] as A --join x_custom_OUTPUT as B on 
		--A.RAW_ID = B.INPUTKEY
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.RAW_ID = B.INPUTKEY
		where A.ToUse = 'Y'
		and A.RAW_ID not in (Select Distinct INPUTKey from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] with(NOLOCK)
		where HOA_TrusteeAttorneyPhoneNumber like 'REO')
		and (convert(date,A.RecordingDate) > convert(date,B.MAX_REO_DATE)
		OR B.MAX_REO_DATE is null)
		Order by A.DocumentTypeDesc 

		
		Select A.NOD_NOS_RecordingDate, B.MAX_REO_DATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.INPUTKEY = B.INPUTKEY
		where HOA_TrusteeAttorneyPhoneNumber like 'REO'
		Order by B.MAX_REO_DATE

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
		--where INPUTKey = '0578945606 4817648'
		where NOD_NOS_RecordedDocumentNumber ='2018.'

		Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
		where NOD_NOS_RecordedDocumentNumber ='2018.'

		Delete from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
		where NOD_NOS_RecordedDocumentNumber ='2020.'


		
			Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
			Set REcordNumber = 0

		
			UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET REcordNumber = RowNum
			FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY INPUTKEY ORDER BY [NOD_NOS_RecordingDate] DESC) AS RowNum
				FROM 
			[zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] t ) r ON t.INPUTKEY = r.INPUTKEY AND (t.[NOD_NOS_RecordedDocumentNumber] = r.[NOD_NOS_RecordedDocumentNumber])
			and t.INPUTKEY = r.INPUTKEY

			Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
			where RecordNumber is null

			----Check for dups---
			Select INPUTKEY, RecordNumber, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
			Group by INPUTKEY, RecordNumber
			having count(*) > 1

			Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]
			where INPUTKEY = '0578228325 2912034'

			Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR]
			where INPUTKEY = '0579482269 6122233'

			Select * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK)
			where REF_ID = '86343459'


		----------------20181004 - KL - Per NH - populate NOD/NOS fields first - then build down with what is left-------


		-----********************Uncomment & RUN!!!!!!!!*********************************
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set 
		A.NOD_NOS_RecordNbr = B.REcordNumber
		,A.NOD_NOS_RecordingDate = B.NOD_NOS_RecordingDate
		,A.NOD_NOS_RecordedDocumentNumber = B.NOD_NOS_RecordedDocumentNumber
		,A.NOD_NOS_DocType = B.NOD_NOS_DocType
		,A.NOD_NOS_DefaultAmount = B.NOD_NOS_DefaultAmount
		,A.HOA_TrusteeAttorneyName = B.HOA_TrusteeAttorneyName
		,A.HOA_TrusteeAttorneyPhoneNumber = B.HOA_TrusteeAttorneyPhoneNumber
		,A.HOA_AuctionDate = B.HOA_AuctionDate
		,A.NOD_NOS_OrigRecDate = B.NOD_NOS_OrigRecDate
		,A.NOD_NOS_OrigDocNbr =  B.NOD_NOS_OrigDocNbr
		------------Added 20190329 to track SUP records----
		,A.NOD_NOS_SUP = B.SUP
		------------Added 20191105 to track REO records----
		,A.[NOD_NOS_REO] = case when B.HOA_TrusteeAttorneyPhoneNumber like 'REO' then 'REO' else NULL end ---Note This field forced to REO when the record is an REO in the data collection above
		--Select len(B.HOA_TrusteeAttorneyPhoneNumber),B.HOA_TrusteeAttorneyPhoneNumber 																	
		FROM  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] as B 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] A 
		on A.INPUTKEY = B.INPUTKEY
		WHERE B.REcordNumber = 1
		And A.NOD_NOS_RecordNbr is null
		--Order by len(B.REcordNumber) desc

		

	
		

		UPdate [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [NbrofRecordings_RELEASED] = 0
		
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.[NbrofRecordings_RELEASED] = b.NbrOfRecordings
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN 
		(
			Select INPUTKEY, sum(NbrOfRecordings) as NbrOfRecordings From (
			--(SELECT INPUTKEY,count(*)  as NbrOfRecordings FROM HOA_NOD_NOS_RELEASE 
			--GROUP BY INPUTKEY) 
			--UNION ALL
			(SELECT INPUTKEY,count(*)  as NbrOfRecordings FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] 
			where NOD_NOS_DocType like 'Release%' or NOD_NOS_DocType like 'Rescission%'
			GROUP BY INPUTKEY)
			)A Group by INPUTKEY
		) 		
		 b
		on a.INPUTKEY = b.INPUTKEY



		--Select NOD_NOS_DocType, count(*) FRom NOD_NOS_RELEASE_COMBINED
		--where ISNULL(HOA_TrusteeAttorneyPhoneNumber,'') not like 'REO' or HOA_TrusteeAttorneyPhoneNumber like ''
		--Group by NOD_NOS_DocType
		--Order by NOD_NOS_DocType
		--Select * From HOA_NOD_NOS_RELEASE

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[Number_of_HOA_Liens_RELEASED] = b.NbrOfRecordings
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN 
		(
		Select INPUTKEY, sum(NbrOfRecordings) as NbrOfRecordings From (
		(SELECT INPUTKEY,NOD_NOS_Recorded_Document_Number as DOC,count(*)  as NbrOfRecordings FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] 
		where LTRIM(RTRIM(DocType)) in ('CDLNRL','HALNPR','HALNRL','HALVRL','HR','VR','HLNPRL','HLNREL','h3','HALNPR','HLNPRL','LENPRL','LN PR',
		'LN PRL','LNPRL','ALNREL','cdlnrl','cr','halnrl','halvrl','HLNREL','HLNVIOREL','hr','LENREL','LN REL','LN RL','LNREL','R','RE ASM','RL','vr')
		GROUP BY INPUTKEY,NOD_NOS_Recorded_Document_Number) 
		
		UNION 
		(SELECT INPUTKEY,NOD_NOS_RecordedDocumentNumber  as DOC,count(*)  as NbrOfRecordings FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] 
		where 
		(NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien%' OR
		NOD_NOS_DocType like 'Release of Homeowners Association Lien%' OR
		NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations%' OR
		NOD_NOS_DocType like 'Release of Lien%' )
		GROUP BY INPUTKEY,NOD_NOS_RecordedDocumentNumber)
		)A 
		Group by INPUTKEY) 		
		 b
		on a.INPUTKEY = b.INPUTKEY

		--Select NOD_NOS_DOcType, count(*) FROm NOD_NOS_RELEASE_COMBINED
		--Group by NOD_NOS_DOcType
		--Order by NOD_NOS_DOcType

		--Select * From HOA_NOD_NOS_RELEASE A
		--where A.INPUTkey like '0578542722 4161135'

		--Select * From NOD_NOS_RELEASE_COMBINED A
		--where A.INPUTkey like '0578542722 4161135'


		--Select * from zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705]
		--where Full_Name like '%lien%' and 
		--(Full_Name like '%Rel%' OR Full_Name like '%REs%')


		UPdate [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [NbrofRecordings] = 0
		
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.[NbrofRecordings] = b.NbrOfRecordings
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN (SELECT INPUTKEY,count(*)  as NbrOfRecordings FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED] 
		GROUP BY INPUTKEY) b
		on a.INPUTKEY = b.INPUTKEY


			--Select MAX(convert(int,[NbrofRecordings_RELEASED])) FROM x_Custom_OUTPUT
		--Select MAX(convert(int,Number_of_HOA_Liens)) FROM x_Custom_OUTPUT


		----------------------------------------BUILD DOWN    COMBINED-----NOD_NOS_RELEASES PER NH 20181004------------------------------------
		IF (Select max(convert(int,RecordNumber)) from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_NOS_RELEASE_COMBINED]) > 1
		BEGIN
		
		Truncate table dbo.RELEASE_BUILD_DOWN_COLUMNS

		
		Insert into  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_BUILD_DOWN_COLUMNS] 
		Select * From (
		Select 
		Stuff(
        (
        Select Distinct ', [' +   B.Name + ']'
		 From [zCust_ProctorFinancial_HOA_LIEN].[sys].[tables] as A join [zCust_ProctorFinancial_HOA_LIEN].[sys].[columns] as B on 
			A.OBJECT_ID = b.object_id
			where A.Name like 'x_custom_OUTPUT'
			and B.Name not in ('NOD_NOS_RecordNbr','NOD_NOS_RecordingDate ','NOD_NOS_RecordedDocumentNumber','NOD_NOS_DocType','NOD_NOS_DefaultAmount'
			,'HOA_TrusteeAttorneyName','HOA_TrusteeAttorneyPhoneNumber','HOA_AuctionDate','NOD_NOS_OrigRecDate','NOD_NOS_OrigDocNbr','NOD_NOS_SUP','NOD_NOS_REO')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		--Select * From dbo.RELEASE_BUILD_DOWN_COLUMNS


		--If (Select MAX(convert(int,NbrofRecordings_RELEASED)) FROM x_Custom_OUTPUT) > 0
		--BEGIN

		

								Declare @BeginNbrOfTrans6 int
								Declare @EndNbrOfTrans6 int
								DECLARE @FIELDLIST3 nvarchar(max)
								DECLARE @FIELDLIST4 nvarchar(max)
								DECLARE @SQL6 nvarchar(max)

								

								Set @FIELDLIST3 = (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])
								Set @FIELDLIST4 = (Select 'A.' + REPLACE(Columns,', [',',A.[') From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_BUILD_DOWN_COLUMNS])

								SET @BeginNbrOfTrans6 = 2
								Select @EndNbrOfTrans6 =  MAX(convert(int,[NbrofRecordings])) FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]

									WHILE (@BeginNbrOfTrans6 <= @EndNbrOfTrans6)
										BEGIN

				 
											DECLARE @RecNbr6 as varchar(5)
											SET @RecNbr6 = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans6),3)

												EXEC('
												Insert into x_custom_OUTPUT(
												' +  @FIELDLIST3 + '

												  ,[NOD_NOS_RecordNbr]
												  ,[NOD_NOS_RecordingDate]
												  ,[NOD_NOS_RecordedDocumentNumber]
												  ,[NOD_NOS_DocType]
												  ,[NOD_NOS_DefaultAmount]
												  ,[HOA_TrusteeAttorneyName]
												  ,[HOA_TrusteeAttorneyPhoneNumber]
												  ,[HOA_AuctionDate]
												  ,[NOD_NOS_OrigRecDate]
												  ,[NOD_NOS_OrigDocNbr]
												  ,[NOD_NOS_SUP]
												  ,[NOD_NOS_REO])
												  
											  Select 
											 ' +  @FIELDLIST4 + '

												 ,B.REcordNumber
												  ,B.[NOD_NOS_RecordingDate]
												  ,B.[NOD_NOS_RecordedDocumentNumber]
												  ,B.[NOD_NOS_DocType]
												  ,B.[NOD_NOS_DefaultAmount]
												  ,B.[HOA_TrusteeAttorneyName]
												  ,B.[HOA_TrusteeAttorneyPhoneNumber]
												  ,B.[HOA_AuctionDate]
												  ,B.[NOD_NOS_OrigRecDate]
												  ,B.[NOD_NOS_OrigDocNbr]
												  ,B.[SUP]
												  ,case when B.HOA_TrusteeAttorneyPhoneNumber like ''REO'' then B.HOA_TrusteeAttorneyPhoneNumber else NULL END
										--Select B.* 	
										
										FROM  NOD_NOS_RELEASE_COMBINED as B 
										join x_Custom_OUTPUT A 
										on A.INPUTKEY = B.INPUTKEY
										WHERE 
										B.REcordNumber = ''' + @BeginNbrOfTrans6 + '''
										')
										

												
										SET @BeginNbrOfTrans6 = @BeginNbrOfTrans6 + 1
				
										END

										

						
			--END

			END

			
--		Select A.FIPS, WORK_REF_ID, A.INPUTKey, NbrofRecordings, NbrofRecordings_NOD_NOS,NbrofRecordings_RELEASED
--		,Number_of_HOA_Liens_RELEASED ,A.NOD_NOS_RECORDNBR
--		,A.NOD_NOS_RecordingDate	,A.NOD_NOS_RecordedDocumentNumber,	A.NOD_NOS_DocType, A.NOD_NOS_REO
--		,Freebie,B.MAX_REO_DATE
--		From x_custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKey = B.INPUTKEY
--		where A.NOD_NOS_RECORDNBR > 0

--		and A.WORK_REF_ID in ('35682029',
--'37161277',
--'32064000',
--'29146959',
--'37843979',
--'37246727',
--'29179795')

--		Order by Inputkey,A.NOD_NOS_RECORDNBR desc

			
--		Select A.FIPS, WORK_REF_ID, A.INPUTKey, NbrofRecordings
--		,NbrofRecordings_NOD_NOS,ISNULL(NbrofRecordings_NOD_NOS,'0') + 1 as NEWRECORDCOUNT
--		,A.NOD_NOS_RECORDNBR
--		,A.NOD_NOS_RecordingDate	,A.NOD_NOS_RecordedDocumentNumber,	A.NOD_NOS_DocType, A.NOD_NOS_REO
--		,B.MAX_REO_DATE
--		From x_custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKey = B.INPUTKEY
--		where A.NOD_NOS_RECORDNBR > 0 and A.NOD_NOS_REO like 'REO'
--		Order by Inputkey,A.NOD_NOS_RECORDNBR desc


		
		
		 


		UPdate [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set NbrofRecordings_NOD_NOS = NbrofRecordings - ISNULL(NbrofRecordings_RELEASED,'0')
		where NbrofRecordings > 0


		--Select count(*) FRom a_ASP_IN_STD

		

		Update  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKey] = b.Raw_ID


		

		---------Persist Address Standardization----
		--Update  a
		--SET a.AddressStandardization = B.AddressStandardization
		----Select a.[INPUTKey], a.AddressStandardization,B.AddressStandardization
		--FROM x_Custom_OUTPUT a JOIN zzz_Proctor_20190213_OUTPUT b
		--on a.[INPUTKey] = b.[INPUTKey]
		--where  (a.AddressStandardization is null or  a.AddressStandardization  like '')
		--and  B.AddressStandardization is not null

	

		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		SET PropertyStatus = CASE WHEN WORK_REF_ID is not null or [PROPERTYID_INT] is not null THEN 'Property Found' ELSE 'Property Not Found' END

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a] SET PropertyStatus = 'Multiple Properties Found' 
		--Select * 
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK] b
		on a.[INPUTKey] = b.RAW_ID
		WHERE b.MultiMatch = 'M' and (a.Work_REF_ID is null AND A.[PROPERTYID_INT] is null)


		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where 
		--PropertyStatus like 'Property Found'
		--and 
		(ISNULL(WORK_REF_ID,'') like '' or WORK_REF_ID like '0')
		and ISNULL([PROPERTYID_INT],'') not like '' and [PROPERTYID_INT] not like '0'
	
		
			
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		set [CoverageStatus_PREFC] = CASE WHEN [CoverageStatus_PREFC] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END
		

		

		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set HAS_HOA_RECORD = 'Y'
		where 
		(
			(HOA_Name is not null and  HOA_Name not like '')
			OR
			(HOA_Type is not null and  HOA_Type not like '')
			OR
			(HOA_Contact_Name is not null and  HOA_Contact_Name not like '')
			OR
			(HOA_Address_Mailing is not null and  HOA_Address_Mailing not like '')
			OR
			(HOA_City_Mailing is not null and  HOA_City_Mailing not like '')
			OR
			(HOA_State_Mailing is not null and  HOA_State_Mailing not like '')
			OR
			(HOA_Zip_Mailing is not null and  HOA_Zip_Mailing not like '')
		)
		AND (HAS_HOA_RECORD is null or HAS_HOA_RECORD like '')
			------------Per NH - 20180604----------
		-------------Changed 20180604 per NH to a NEW HOA Lien (based on tracking the max recording date found for HOA Lien data per REF_ID)
		------------– OR – 
		------------a NEW NOD record (based on tracking the max recording date found for NOD data per REF_ID)
		---------OR------------
		----------a NEW HOA Found OR NO HOA when there was one before ----------------

		---------Initial----
		--UPDATE A 
		--Set  A.EventStatus = case when [Number_of_HOA_Liens] > 0 OR NbrOfRecordings > 0
		--OR 
		--(A.[HAS_HOA_RECORD] like 'Y' )
		
		--then 'Event Found' ELSE 'Event Not Found' END
		----Select * 
		--From   x_Custom_OUTPUT
		--as A 
		
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] 
		Set  EventStatus = NULL

		


		--------------------Changed to ONLY return Event Found when HOA Lien, NOD/NOS, REscission/Release found per NH 20190125----
		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A] 
		Set  A.EventStatus = case when [Number_of_HOA_Liens] > 0 OR NbrOfRecordings > 0
		--OR 
		--(A.[HAS_HOA_RECORD] like 'Y' and B.[HOA_FOUND] is null)
		--OR
		--(A.[HAS_HOA_RECORD] is null and B.[HOA_FOUND] like 'Y')
		------Added 20181001 per NH----
		OR NbrofRecordings_RELEASED > 0
		then 'Event Found' ELSE 'Event Not Found' END
		--Select A.INPUTKEY ,A.[HAS_HOA_RECORD],B.[HOA_FOUND]
		From   [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		as A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as B on A.INPUTKEY = B.INPUTKEY
		
				


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [AddressMatch] = case when INPUTADDRESS = PropertyAddress --and INPUTCity = City and INPUTState = State  
		then 'Total'
		when left(INPUTADDRESS,8) = left(PropertyAddress,8) and  INPUTADDRESS <> PropertyAddress then 'Partial'
		when left(INPUTADDRESS,8) <> left(PropertyAddress,8) then 'NoMatch'
		else NULL END

		-------Added 20190114 per NH----
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [AddressMatch] = 'Partial'
		where left(INPUTADDRESS,7) = left(PropertyAddress,7) and  INPUTADDRESS <> PropertyAddress 
		and [AddressMatch] like 'NoMatch'


		----------------------------------------Added 20190320 as Proctor wants the most recent transaction returned if there are no NEW transactions per NH-----
		EXEC('
		Update A
		Set
		A.[Number_of_HOA_Liens] = ''1''
		,A.[HOA_LienDocType_001] = B.[HOA_LienDocType]
		,A.[HOA_LienRecordingDate_001] = B.[HOA_LienRecordingDate]
		,A.[HOA_LienRecordedDocumentNumber_001] = B.[HOA_LienRecordedDocumentNumber]
		,A.[HOA_LienAmount_001] = B.[HOA_LienAmount]
		,A.[HOA_LienName_001] = B.[HOA_LienName]
		,A.[HOA_LienAgency_001] = B.[HOA_LienAgency]
		,A.[HOA_LienContactCompany_001] = B.[HOA_LienContactCompany]
		,A.[HOA_LienContactName_001] = B.[HOA_LienContactName]
		,A.[HOA_LienAddressMailing_001] = B.[HOA_LienAddressMailing]
		,A.[HOA_LienCityMailing_001] = B.[HOA_LienCityMailing]
		,A.[HOA_LienStateMailing_001] = B.[HOA_LienStateMailing]
		,A.[HOA_LienZipMailing_001] = B.[HOA_LienZipMailing]
		,A.[HOA_LienContactPhone_001] = B.[HOA_LienContactPhone]
		,A.[HOA_OrigRecordingDate_001] = B.[HOA_OrigRecordingDate]
		,A.[HOA_OrigDocNumber_001] = B.[HOA_OrigDocNumber]


		--Select B.* 
		From x_custom_OUTPUT as A 
		join 

						(Select A.INPUTKEY, [HOA_LienDocType]
					  ,[HOA_LienRecordingDate]
					  ,[HOA_LienRecordedDocumentNumber]
					  ,[HOA_LienAmount]
					  ,[HOA_LienName]
					  ,[HOA_LienAgency]
					  ,[HOA_LienContactCompany]
					  ,[HOA_LienContactName]
					  ,[HOA_LienAddressMailing]
					  ,[HOA_LienCityMailing]
					  ,[HOA_LienStateMailing]
					  ,[HOA_LienZipMailing]
					  ,[HOA_LienContactPhone]
					  ,[HOA_OrigRecordingDate]
					  ,[HOA_OrigDocNumber]
					  ,A.DOCTYPE
					  ,A.RECDATE
					  From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A with(NOLOCK)
					  join 
							(Select DISTINCT A.INPUTKEY, A.DOCTYPE,MAXDATE From [PROCTOR_ALL_TRACKING] as A join 
									(Select INPUTKEY, MAX(RECDATE) as MAXDATE from [PROCTOR_ALL_TRACKING]
									Group by INPUTKEY) B on 
							A.INPUTKEY = B.INPUTKEY and A.RECDATE = B.MAXDATE)B 
						on A.INPUTKEY = B.INPUTKEY 
								AND A.RECDATE = B.MAXDATE
								AND A.DOCTYPE = B.DOCTYPE
			) B on A.INPUTKEY = B.INPUTKEY
		where 
		(A.[Number_of_HOA_Liens] is null  or A.[Number_of_HOA_Liens] like '''' or A.[Number_of_HOA_Liens] like ''0'')
		AND 
		(A.NbrofRecordings is null  or A.NbrofRecordings like '''' or A.NbrofRecordings like ''0'')
		AND B.DOCTYPE like ''LIEN''

		')
------------------------START HERE----------------


		----Update w_TransHist
		----Set toUSE = NULL

		----UPDATE a
		----SET toUSE = 'Y'
		------Select A.RAW_ID, B.DATE_ADDED, B.MAX_LIENDATE, B.MAX_NODDATE, A.DocumentType, A.DocumentNbr, A.RecordingDate, A.Value
		------,C.*
		----from w_TransHist a JOIN [INPUT_MONITOR] b
		----on a.Raw_ID = b.INPUTKey
		----join w_preforeclosure as C on A.FIPS = C.FIPS
		----and A.REF_ID = C.REF_ID
		----and A.DocumentNbr = C.Fmt_Inst_Nbr
		----And A.DocumentType = C.Document_Type
		----WHERE 
		----	----------------------Changed 20181217 to include JUDGEMENTS as they contain the Auction Date info------------
		----	(
		----		(Lis_Pendens_Type like '2' and Document_Type not like 'LIS%') 
		----		or 
			
		----	------Changed 20200131 per NH to only return Judgements not in the HOA Lien table where Default Amount is populated & Below 50K (no 0's or NULLS)
		----		(Document_Type like 'JDG'  AND ((C.Default_Amount > 0 and C.Default_Amount < 50000) or (C.Judgment_Amount > 0 and  C.Judgment_Amount < 50000)))
		----	)
		----	AND 
		----	(
		----			(convert(date,a.RecordingDate) > convert(date,b.[MAX_NODDATE])
		----			or convert(date,a.DocDate) > convert(date,b.[MAX_NODDATE])
		----			--OR B.[MAX_NODDATE] is null
		----			)
		----			--AND A.REF_ID =  '26810023'
		----		OR 
		----			(B.[MAX_NODDATE] is null
		----			AND (case when B.InputBorrowerName is null or B.InputBorrowerName like '' then B.OwnerStdName1Full else B.InputBorrowerName end) 
		----			like '%' + left(A.BuyerBorrower,4) + '%'
		----			AND A.BuyerBorrower is not null AND A.BuyerBorrower not like '')
		----	)
		----	--Order by A.DocumentType
		----	And A.REF_ID not like '196878235'



		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set
		A.[NbrofRecordings] = '1'
		,A.[NOD_NOS_RecordNbr] = '1'
		,A.[NOD_NOS_RecordingDate] = B.[NOD_NOS_RecordingDate]
		,A.[NOD_NOS_RecordedDocumentNumber] = B.[NOD_NOS_RecordedDocumentNumber]
		,A.[NOD_NOS_DocType] = B.[NOD_NOS_DocType]
		,A.[NOD_NOS_DefaultAmount] = B.[NOD_NOS_DefaultAmount]
		,A.[HOA_TrusteeAttorneyName] = B.[HOA_TrusteeAttorneyName]
		,A.[HOA_TrusteeAttorneyPhoneNumber] = B.[HOA_TrusteeAttorneyPhoneNumber]
		,A.[HOA_AuctionDate] = B.[HOA_AuctionDate]
		,A.[NOD_NOS_OrigRecDate] = B.[NOD_NOS_OrigRecDate]
		,A.[NOD_NOS_OrigDocNbr] = B.[NOD_NOS_OrigDocNbr]
		,A.[NOD_NOS_REO] = case when B.DOCTYPE like 'REO' then 'REO' else null end
		--Select B.* 
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as A 
		join 

		

						(Select A.INPUTKEY
						 ,[NOD_NOS_RecordingDate]
						  ,[NOD_NOS_RecordedDocumentNumber]
						  ,[NOD_NOS_DocType]
						  ,[NOD_NOS_DefaultAmount]
						  ,[HOA_TrusteeAttorneyName]
						  ,[HOA_TrusteeAttorneyPhoneNumber]
						  ,[HOA_AuctionDate]
						  ,[NOD_NOS_OrigRecDate]
						  ,[NOD_NOS_OrigDocNbr]
					  ,A.DOCTYPE
					  ,A.RECDATE
					   From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A with(NOLOCK)
					  join 
							(Select DISTINCT A.INPUTKEY, A.DOCTYPE,MAXDATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A join 
									(Select INPUTKEY, MAX(RECDATE) as MAXDATE from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING]
									Group by INPUTKEY) B on 
							A.INPUTKEY = B.INPUTKEY and A.RECDATE = B.MAXDATE)B 
						on A.INPUTKEY = B.INPUTKEY 
								AND A.RECDATE = B.MAXDATE
								AND A.DOCTYPE = B.DOCTYPE
																
			) B on A.INPUTKEY = B.INPUTKEY
		where 
		(A.[Number_of_HOA_Liens] is null  or A.[Number_of_HOA_Liens] like '' or A.[Number_of_HOA_Liens] like '0')
		AND 
		(A.NbrofRecordings is null  or A.NbrofRecordings like '' or A.NbrofRecordings like '0')
		AND B.DOCTYPE NOT like  'LIEN'
		and B.NOD_NOS_DocType not like 'JUDG%'


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set
		A.[NbrofRecordings] = '1'
		,A.[NOD_NOS_RecordNbr] = '1'
		,A.[NOD_NOS_RecordingDate] = B.[NOD_NOS_RecordingDate]
		,A.[NOD_NOS_RecordedDocumentNumber] = B.[NOD_NOS_RecordedDocumentNumber]
		,A.[NOD_NOS_DocType] = B.[NOD_NOS_DocType]
		,A.[NOD_NOS_DefaultAmount] = B.[NOD_NOS_DefaultAmount]
		,A.[HOA_TrusteeAttorneyName] = B.[HOA_TrusteeAttorneyName]
		,A.[HOA_TrusteeAttorneyPhoneNumber] = B.[HOA_TrusteeAttorneyPhoneNumber]
		,A.[HOA_AuctionDate] = B.[HOA_AuctionDate]
		,A.[NOD_NOS_OrigRecDate] = B.[NOD_NOS_OrigRecDate]
		,A.[NOD_NOS_OrigDocNbr] = B.[NOD_NOS_OrigDocNbr]
		,A.[NOD_NOS_REO] = case when B.DOCTYPE like 'REO' then 'REO' else null end
		--Select B.* 
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as A 
		join 

		

						(Select A.INPUTKEY
						 ,[NOD_NOS_RecordingDate]
						  ,[NOD_NOS_RecordedDocumentNumber]
						  ,[NOD_NOS_DocType]
						  ,[NOD_NOS_DefaultAmount]
						  ,[HOA_TrusteeAttorneyName]
						  ,[HOA_TrusteeAttorneyPhoneNumber]
						  ,[HOA_AuctionDate]
						  ,[NOD_NOS_OrigRecDate]
						  ,[NOD_NOS_OrigDocNbr]
					  ,A.DOCTYPE
					  ,A.RECDATE
					   From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A with(NOLOCK)
					  join 
							(Select DISTINCT A.INPUTKEY, A.DOCTYPE,MAXDATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A join 
									(Select INPUTKEY, MAX(RECDATE) as MAXDATE from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING]
									Group by INPUTKEY) B on 
							A.INPUTKEY = B.INPUTKEY and A.RECDATE = B.MAXDATE)B 
						on A.INPUTKEY = B.INPUTKEY 
								AND A.RECDATE = B.MAXDATE
								AND A.DOCTYPE = B.DOCTYPE
																
			) B on A.INPUTKEY = B.INPUTKEY
		where 
		(A.[Number_of_HOA_Liens] is null  or A.[Number_of_HOA_Liens] like '' or A.[Number_of_HOA_Liens] like '0')
		AND 
		(A.NbrofRecordings is null  or A.NbrofRecordings like '' or A.NbrofRecordings like '0')
		AND B.NOD_NOS_DocType like 'JUDG%'
		and  convert(money,B.NOD_NOS_DefaultAmount) > 0 and convert(money,B.NOD_NOS_DefaultAmount) < 50000
		


		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [NOD_NOS_REO] = [HOA_TrusteeAttorneyPhoneNumber]
		--Select FIPS, INPUTKey, EventStatus,[HOA_TrusteeAttorneyPhoneNumber],[NOD_NOS_REO]
		--,NbrofRecordings,Number_of_HOA_Liens
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		where [HOA_TrusteeAttorneyPhoneNumber] like 'REO'
		and [NOD_NOS_REO] is null


		Select inputkey , count(*) From (
		Select DISTINCT A.INPUTKEY, A.DOCTYPE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as A join 
		(Select INPUTKEY, MAX(RECDATE) as MAXDATE from [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING]
		Group by INPUTKEY) B on 
		A.INPUTKEY = B.INPUTKEY and A.RECDATE = B.MAXDATE)A
		Group by INPUTKEY
		having count(*) > 1


		--Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING]  as A with(NOLOCK)
		--where INPUTKEY in ('0555845898 822774','0578186254 2482980','0578603088 4123166')
		--Order by INPUTKEY


		Select NOD_NOS_DocType,NOD_NOS_REO, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where NbrofRecordings > 0
		Group by NOD_NOS_DocType,NOD_NOS_REO
		Order by NOD_NOS_DocType

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where NOD_NOS_REO is null
		and NOD_NOS_DocType in ('Certificate of Transfer','Commissioners Assignment of Lease (Hawaii)','Correction Deed','Deed','Deed in Lieu of Foreclosure'
		,'Foreclosure','Foreclosure Deed','Quit Claim Deed','Sheriff''s Deed','Sheriff’s Deed','Special Warranty Deed','Trustee’s Deed (Certificate of Title)'
		,'Warranty Deed')

		Select FIPS, WORK_REF_ID, INPUTKey, PROPERTYID, FREEBIE, PropertyStatus, EventStatus
		,NbrofRecordings, NbrofRecordings_NOD_NOS, NOD_NOS_RecordingDate,	NOD_NOS_RecordedDocumentNumber,	NOD_NOS_DocType
		,HOA_TrusteeAttorneyPhoneNumber,NOD_NOS_REO
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where NOD_NOS_REO is null
		and HOA_TrusteeAttorneyPhoneNumber like 'REO'
		



			


		---------------------UNCOMMENT & RUN to FIND MAX RECORD DATE-----------------
		IF  EXISTS (SELECT * FROM [zCust_ProctorFinancial_HOA_LIEN].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[FIND_MAX_RECORD]') AND type in (N'U'))
		DROP TABLE [dbo].[FIND_MAX_RECORD]

	
		EXEC('
		Select A.* into [dbo].[FIND_MAX_RECORD]
		From 
		(
		Select INPUTKEY, WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT
		where [Number_of_HOA_Liens] > 0
		
		UNION ALL
		
		Select INPUTKEY, WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			-------20200116 - Changed per NH----
			---when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''LIS PENDENS%'' and NOD_NOS_DocType not like ''%Release%'' then ''LIS''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '',''Partial Release of Homeowners Association Lien   '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			when  NOD_NOS_DocType in ( ''LIS PENDENS <HOA> RELEASE'',''Release of Homeowners Association Lien'',''Release of Lis Pendens'',''Release of Lien'') then ''REL_LIEN''
			when  NOD_NOS_DocType in (''HOA JUDGEMENT'',''JUDGMENT'') then ''NOS''
			when [NOD_NOS_REO] like ''REO'' then ''REO''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT
		where NbrOfRecordings > 0
		)A

		join 
		(Select INPUTKEY,WORK_REF_ID,max(RECORD_DATE) as MAXDATE FROM (
		Select INPUTKEY, WORK_REF_ID,[HOA_LienRecordingDate_001] as RECORD_DATE
		,''HOA_LIEN'' as DOCTYPE
		 From x_Custom_OUTPUT
		where [Number_of_HOA_Liens] > 0
		
		UNION ALL
		
		Select INPUTKEY, WORK_REF_ID,NOD_NOS_RecordingDate as RECORD_DATE
		,case when NOD_NOS_DocType like ''%NOTICE OF DEFAULT%'' then ''NOD'' 
			when NOD_NOS_DocType like ''%NOTICE OF SALE%'' then ''NOS'' 
			when NOD_NOS_DocType like ''%NOTICE OF TRUSTEES SALE%'' then ''NOS'' 
			-------20200116 - Changed per NH----
			--when  NOD_NOS_DocType like ''LIS PENDENS'' then ''NOF''
			when  NOD_NOS_DocType like ''LIS PENDENS%'' and NOD_NOS_DocType not like ''%Release%'' then ''LIS''
			when  NOD_NOS_DocType like ''HOMEOWNERS ASSOCIATION LIEN FORECLOSURE'' then ''NOF''
			when  NOD_NOS_DocType like ''NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN'' then ''NOF''
			when  NOD_NOS_DocType in (''Release of Homeowners Association Lien    '', ''Release of Homeowners Association Lien    '' ,''Release of Condominium Homeowners Association Lien   ''
			,''Release of Homeowners Association Lien for Violations  '',''Partial Release of Homeowners Association Lien   '')
			then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Condominium Homeowners Association Lien   '' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''HOA LIEN  RELEASE'' then ''REL_LIEN''
			when  NOD_NOS_DocType like ''Release of Homeowners Association Lien for Violations  '' then ''REL_LIEN''
			when  NOD_NOS_DocType in ( ''LIS PENDENS <HOA> RELEASE'',''Release of Homeowners Association Lien'',''Release of Lis Pendens'',''Release of Lien'') then ''REL_LIEN''
			when  NOD_NOS_DocType in (''HOA JUDGEMENT'',''JUDGMENT'') then ''NOS''
			when [NOD_NOS_REO] like ''REO'' then ''REO''
			else NOD_NOS_DocType end
		as DOCTYPE		
		 From x_Custom_OUTPUT
		where NbrOfRecordings > 0
		)A
		Group by INPUTKEY,WORK_REF_ID) B  
		on A.INPUTKey = B.INPUTKey
		and A.RECORD_DATE = B.MAXDATE
		')

		Select DoCType, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD]
		Group by DocType


		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD]
		where DOCTYPE is null

		Select NOD_NOS_DocType, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		Group by NOD_NOS_DocType
		Order by NOD_NOS_DocType

		Select A.FIPS,B.State, B.[County Name],INPUTKEY, WORK_REF_ID, NbrofRecordings, NbrofRecordings_NOD_NOS, NbrofRecordings_RELEASED
		,NOD_NOS_RecordNbr,NOD_NOS_RecordingDate,NOD_NOS_RecordedDocumentNumber,NOD_NOS_DocType
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [Global].[dbo].[county] as B on A.FIPS = B.FIPSCODE
		where INPUTKEY in (
		Select INPUTKey From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD]
		where DOCTYPE is null)

		Select * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK) where REF_ID = '83930310'

		Select * From [zCust_BOA].[dbo].[HOA_LIEN_DOC_TYPES_20180705] where HOA_Doc_Type like 'NDF%'
		Select * From [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]  where DocType like 'NDF%' --NDF
	
		--Update [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113]
		--Set Full_Name = 'Notice of Sale'
		--where DocType like 'ASLSLE%'

		--Update x_Custom_OUTPUT
		--Set NOD_NOS_DocType = 'NOTICE OF SALE'
		--where INPUTKEY = '0579425331 5825235'
		--and NOD_NOS_RecordedDocumentNumber = '4752525'


		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] where REF_ID = '82894134' Order by RecordingDate desc

		--Select NOD_NOS_DocType
		--,case when NOD_NOS_DocType like '%NOTICE OF DEFAULT%' then 'NOD' 
		--	when NOD_NOS_DocType like '%NOTICE OF SALE%' then 'NOS' 
		--	when NOD_NOS_DocType like '%NOTICE OF TRUSTEES SALE%' then 'NOS' 
		--	when  NOD_NOS_DocType like 'LIS PENDENS' then 'NOF'
		--	when  NOD_NOS_DocType like 'HOMEOWNERS ASSOCIATION LIEN FORECLOSURE' then 'NOF'
		--	when  NOD_NOS_DocType like 'NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN' then 'NOF'
		--	when  NOD_NOS_DocType in ('Release of Homeowners Association Lien    ', 'Release of Homeowners Association Lien    ' ,'Release of Condominium Homeowners Association Lien   '
		--	,'Release of Homeowners Association Lien for Violations  ')
		--	then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien   ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'HOA LIEN  RELEASE' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations  ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE' then 'REL_LIEN'
		--	when [NOD_NOS_REO] like 'REO' then 'REO'
		--	else NOD_NOS_DocType end
		--as DOCTYPE		
		-- From x_Custom_OUTPUT
		--where NbrOfRecordings > 0
		--Group by NOD_NOS_DocType,case when NOD_NOS_DocType like '%NOTICE OF DEFAULT%' then 'NOD' 
		--	when NOD_NOS_DocType like '%NOTICE OF SALE%' then 'NOS' 
		--	when NOD_NOS_DocType like '%NOTICE OF TRUSTEES SALE%' then 'NOS' 
		--	when  NOD_NOS_DocType like 'LIS PENDENS' then 'NOF'
		--	when  NOD_NOS_DocType like 'HOMEOWNERS ASSOCIATION LIEN FORECLOSURE' then 'NOF'
		--	when  NOD_NOS_DocType like 'NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN' then 'NOF'
		--	when  NOD_NOS_DocType in ('Release of Homeowners Association Lien    ', 'Release of Homeowners Association Lien    ' ,'Release of Condominium Homeowners Association Lien   '
		--	,'Release of Homeowners Association Lien for Violations  ')
		--	then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien   ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'HOA LIEN  RELEASE' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations  ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE' then 'REL_LIEN'
		--	when [NOD_NOS_REO] like 'REO' then 'REO'
		--	else NOD_NOS_DocType end
		--Order by case when NOD_NOS_DocType like '%NOTICE OF DEFAULT%' then 'NOD' 
		--	when NOD_NOS_DocType like '%NOTICE OF SALE%' then 'NOS' 
		--	when NOD_NOS_DocType like '%NOTICE OF TRUSTEES SALE%' then 'NOS' 
		--	when  NOD_NOS_DocType like 'LIS PENDENS' then 'NOF'
		--	when  NOD_NOS_DocType like 'HOMEOWNERS ASSOCIATION LIEN FORECLOSURE' then 'NOF'
		--	when  NOD_NOS_DocType like 'NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN' then 'NOF'
		--	when  NOD_NOS_DocType in ('Release of Homeowners Association Lien    ', 'Release of Homeowners Association Lien    ' ,'Release of Condominium Homeowners Association Lien   '
		--	,'Release of Homeowners Association Lien for Violations  ')
		--	then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien   ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'HOA LIEN  RELEASE' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations  ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE' then 'REL_LIEN'
		--	when [NOD_NOS_REO] like 'REO' then 'REO'
		--	else NOD_NOS_DocType end



		Select A.FIPS, A.WORK_REF_ID, A.INPUTKEY, A.INPUTADDRESS, NOD_NOS_RecordNbr	,NOD_NOS_RecordingDate,	NOD_NOS_RecordedDocumentNumber,	NOD_NOS_DocType 
		,B.STATE, B.[County Name]
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] A
		join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		where NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE'

		----Select * From NOD_NOS_RELEASE_COMBINED
		----where INPUTKEY = '0578653666 4449618'

		--Select * From HOA.dbo.HOA_LIEN
		--where DocType like 'HOA'
		--where REF_ID  = '64282421'

		--Select * From [Data].[dbo].[HOA_Lien_Sup]  A with(NOLOCK)
	 --   join Assr.dbo.Assr as B with(NOLOCK) on A.LIC_PROPERTYID = B.LIC_PROPERTYID
		--where B.REF_ID  = '64282421'

		--Select * From HOA_NOD_NOS



		--Select * From NOD_NOS_RELEASE_COMBINED
		--where NOD_NOS_DOcType like 'NOTICE OF HOMEOWNERS ASSOCIATION'

		--Select B.* From HOA.dbo.HOA_LIEN as A with(NOLOCK)
		--join x_custom_OUTPUT as B on A.REF_ID = B.WORK_REF_ID
		--where B.INPUTKEY in ('2617674','3238356')
		--and A.DOcumentID in ('10485.1701','27643.266')



		--Select * From zcust_Boa.dbo.[HOA_LIEN_DOC_TYPES_20180705]
		--where  HOA_DOC_TYPE in ('halnrl','halnrl','halnrl','ha','LN','halnrl','HA','HA')

		--Select * From HOA_NOD_NOS
		--where REF_ID in ('35679608','35294290')


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD_HIST]
		Select *, convert(date,Getdate())
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD]

		--Select * From [FIND_MAX_RECORD_HIST]

		
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[LastDocTypeRecorded] = B.DocType
		,A.[DaysSinceRecording] = DATEDIFF("DD",convert(date,B.RECORD_DATE),Getdate())
		--Select B.DocType , B.RECORD_DATE,DATEDIFF("DD",convert(date,B.RECORD_DATE),Getdate())
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as A join 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[FIND_MAX_RECORD] as B on 
		A.INputkey = B.INputkey

		Select [LastDocTypeRecorded], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		where NbrofRecordings > 0 OR [Number_of_HOA_Liens] > 0
		Group by [LastDocTypeRecorded]
		Order by [LastDocTypeRecorded]

		Select [LastDocTypeRecorded], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		where NbrofRecordings like '0' and [Number_of_HOA_Liens] like '0'
		Group by [LastDocTypeRecorded]
		Order by [LastDocTypeRecorded]

		Select A.INPUTKEY, A.[LastDocTypeRecorded],A.NbrofRecordings, A.[Number_of_HOA_Liens]
		,B.EventStatus, B.NbrofRecordings, B.[Number_of_HOA_Liens], B.DOCTYPE, B.Rundate
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as A join 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as B on 
		A.INPUTKEY = B.INPUTKEY
		where A.[LastDocTypeRecorded] is null


		
		
		  

		-----------Backfill HOA Data-------------
		
		
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set 
		[HOA_Name]= B.Name
      ,[HOA_Type]=  B.Type
      ,[HOA_Contact_Name] =  B.ContactName
      ,[HOA_Address_Mailing]= B.Address
      ,[HOA_City_Mailing]= B.City
      ,[HOA_State_Mailing] = B.State
      ,[HOA_Zip_Mailing]= B.Zip
      ,[HOA_Contact_Phone] = B.BusinessPhoneNbr
      ,[HOA_Contact_Email] = B.Email
      ,[HOA_Fee_Value]= B.Amount
      ,[HOA_Fee_Minimum_Value]= B.MinAmount
      ,[HOA_Fee_Maximum_Value] = B.MaxAmount
      ,[HOA_Fee_Type] = B.FeeType
      ,[HOA_Fee_Frequency]= B.FeeFrequency
	 --Select * 
	  FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] a JOIN [HOA].[dbo].[OAFulfillment] as B with(NOLOCK)
		on a.FIPS = Right(('0' + convert(varchar(5),b.HOAFIPS)),5)
		and a.Work_REF_ID = b.REF_ID 
		where A.Work_REF_ID is not null
		AND (A.[HAS_HOA_RECORD] is null or A.[HAS_HOA_RECORD] like '')
		AND HOARanking = 1



		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set HAS_HOA_RECORD = 'Y'
		where 
		((
			(HOA_Name is not null and  HOA_Name not like '')
			OR
			(HOA_Type is not null and  HOA_Type not like '')
			OR
			(HOA_Contact_Name is not null and  HOA_Contact_Name not like '')
			OR
			(HOA_Address_Mailing is not null and  HOA_Address_Mailing not like '')
			OR
			(HOA_City_Mailing is not null and  HOA_City_Mailing not like '')
			OR
			(HOA_State_Mailing is not null and  HOA_State_Mailing not like '')
			OR
			(HOA_Zip_Mailing is not null and  HOA_Zip_Mailing not like '')
		)
		---------------ADDED 20181219 per NH ------------
		OR Number_of_HOA_Liens > 0 )
		AND (HAS_HOA_RECORD is null or HAS_HOA_RECORD like '')


		---------------ADDED 20181219 per NH ------------

		


		UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.HAS_HOA_RECORD = 'Y'
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]  as A 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as B on 
		A.INPUTKEY = B.INPUTKEY
		where A.HAS_HOA_RECORD is null or A.HAS_HOA_RECORD like ''

		-----Added 20191211 to force Has Hoa Record since this ref id has an HOA related NOS
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set HAS_HOA_RECORD = 'Y'
		where WORK_REF_ID = '42937455'


		--------------Changed 20181217 to include NOF doc type in high prioritization per NH - KL---
		Update [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Set [Prioritization] = 
		case 
		when [SuperLienState] like 'Y' AND [LastDocTypeRecorded] like 'NOS' AND [HAS_HOA_RECORD] like 'Y' then 'Extreme'
		when [SuperLienState] like 'Y' AND [LastDocTypeRecorded] in ('NOD','NOF','LIS') AND [HAS_HOA_RECORD] like 'Y' then 'High'
		when [SuperLienState] like 'Y' AND [LastDocTypeRecorded] like 'HOA_LIEN' AND [HAS_HOA_RECORD] like 'Y' then 'Med'
		when [SuperLienState] is null AND [LastDocTypeRecorded] is not null  and [LastDocTypeRecorded] not like 'REO' then 'Low'
		when [SuperLienState] is null AND [LastDocTypeRecorded] is null and [HAS_HOA_RECORD] like 'Y'  then 'Low'
		----Added 20191114 per NH:  4.	Are we to use the REO in setting their Prioritization field? Yes
		--a.	If so – what Priority should be set (would they all be set to Extreme – regardless of the Super Lien State status or HOA Found status)? 
		--NH Response:  Extreme regardless (they are only supposed to be sending us super lien state properties and are working on removing the ones that are not)
		when [LastDocTypeRecorded] like 'REO'  then 'Extreme'

		Else 'Low' END


		Select [SuperLienState], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [SuperLienState]


		Select [LastDocTypeRecorded],[SuperLienState],[Prioritization], [HAS_HOA_RECORD],count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[zzz_Proctor_20200909_OUTPUT]
		Group by [LastDocTypeRecorded],[SuperLienState],[Prioritization], [HAS_HOA_RECORD]
		Order by [Prioritization]

		Select [LastDocTypeRecorded],[SuperLienState],[Prioritization], [HAS_HOA_RECORD],count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [LastDocTypeRecorded],[SuperLienState],[Prioritization], [HAS_HOA_RECORD]
		Order by [Prioritization]


		Select A.FIPS, B.State, B.[County Name], A.INPUTKEY,A.[PROPERTYID_INT], A.WORK_REF_ID, A.INPUTADDRESS,[SuperLienState], [HAS_HOA_RECORD],[Prioritization]
		--,Number_of_HOA_Liens, HOA_LienDocType_001,HOA_LienRecordingDate_001,	HOA_LienRecordedDocumentNumber_001,	HOA_LienAmount_001
		,NOD_NOS_RecordNbr	,NOD_NOS_RecordingDate	,NOD_NOS_RecordedDocumentNumber	,NOD_NOS_DocType
		 From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		where [LastDocTypeRecorded] = 'NOS'
		and [HAS_HOA_RECORD] is null

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		where WORK_REF_ID in ('42937455','196878235')

		Select * From [HOA].[dbo].[OAFulfillment] with(NOLOCK)
		where REF_ID in ('42937455','196878235')

		Select * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK) where REF_ID in ('64485364')

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR]
		where INPUTADDRESS like '7201 Cr%'

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		where INPUTKey = '0578592084 4207518'

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING]
		where INPUTKey = '0578592084 4207518'

		Select * From [HOA].[dbo].[HOA_LIEN] with(NOLOCK) 
		where 
		--REF_ID in ('64485364')
		--OR 
		FIPS = '24033'
		AND DocumentId like '42342%453'

		Select * From [AZUVPSQLDTDB029.datatree.local].NovaDimDoc.dbo.DIM_NOVA_DOCUMENT
		where FIPS = 24033
		and Doc_Number like '42342%453'
		--REF_ID in ('64485364')

		Select * From [AZUVPSQLDTDB029.datatree.local].Pre_Foreclosure.dbo.PreForeclosure
		where REF_ID in ('64485364')

		Select * From [AZUVPSQLDTDB029.datatree.local].Pre_Foreclosure.dbo.PreForeclosure
		where FIPS = 24033
		and REcording_book like '%42342' and REcording_Page like '%453'


		Select A.* From [Data].[dbo].[HOA_Lien_Sup]  A with(NOLOCK)
		join [Assr].[dbo].[Assr] as B with(NOLOCK) on A.LIC_PROPERTYID = B.LIC_PROPERTYID
		where B.REF_ID = '64485364'

		Select * From [global].[dbo].[county] where FIPSCODE = '24033'



		--UPdate A
		--Set A.AddressStandardization = B.AddressStandardization
		--From x_custom_OUTPUT as A join zzz_Proctor_20190308_OUTPUT as B on 
		--A.INPUTKEY = B.INPUTKEY


		--UPdate A
		--Set A.AddressMatch = B.AddressMatch
		--From x_custom_OUTPUT as A join zzz_Proctor_20190308_OUTPUT as B on 
		--A.INPUTKEY = B.INPUTKEY

		--------------20190318 - Added to track new data being sent for properties with previously sent data as this is NOT charged the $6 per Nicole---
		Update  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[FREEBIE] = 'Y'
		--Select * 
		FRom [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] As A 
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] B
		on A.INPUTKEY = B.INPUTKEY

		------Added 20200110 to remove Freebie flag for input keys Nicole designated as Free for Nov & Dec 2019 files - but should be charged go forward per NH
		------Update  A
		------Set A.[FREEBIE] = NULL
		--------Select A.INPUTKEY ,A.Freebie,A.Number_of_HOA_Liens,A.NbrofRecordings,C.RunDate
		------FRom x_Custom_OUTPUT As A 
		------join [NO_CHARGE_INPUT_KEYS_20200110] B
		------on A.INPUTKEY = B.[NO_CHARGE_INPUTKEYS]
		------join [PROCTOR_ALL_TRACKING] C on A.INPUTKEY = C.INPUTKEY
		------where C.RunDate < '2020-01-01'
		------and A.Freebie like 'Y'

		Update  [zCust_ProctorFinancial_HOA_LIEN].[dbo].[A]
		Set A.[FREEBIE] = NULL
		--Select A.INPUTKEY ,A.Freebie,A.Number_of_HOA_Liens,A.NbrofRecordings,B.MAXDATE
		FRom [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] As A 
		join 
			(Select A.INPUTKEY, Max(Rundate) as MAXDATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as 
			A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NO_CHARGE_INPUT_KEYS_20200110] as B on 
			A.INPUTKEY = B.[NO_CHARGE_INPUTKEYS]
			Group by A.INPUTKEY) B
		on A.INPUTKEY = B.INPUTKEY
		where B.MAXDATE < '2020-01-01'
		and A.Freebie like 'Y'
		
		


		Select A.INPUTKEY, Max(Rundate) as MAXDATE From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[PROCTOR_ALL_TRACKING] as 
		A join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NO_CHARGE_INPUT_KEYS_20200110] as B on 
		A.INPUTKEY = B.[NO_CHARGE_INPUTKEYS]
		Group by A.INPUTKEY

		




		Select EventStatus, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where [FREEBIE] = 'Y'
		Group by EventStatus


		--------------------Update to NOT FOUND when just sending FULL replacement for SUP record---------
		----************Need to build out for Liens other than 001 & for NOD/NOS/Releases********

		EXEC('UPDATE A 
		Set  A.EventStatus = ''Event Not Found''
		--Select * 
		From   x_Custom_OUTPUT
		as A join [HOA_LIEN_DATA_REPLACE_SUP] as B on A.INPUTKEY = B.INPUTKEY
		and 
		A.HOA_LienRecordedDocumentNumber_001 = B.DocumentId AND Number_of_HOA_Liens = 1

		UPDATE A 
		Set  A.EventStatus = ''Event Not Found''
		--Select * 
		From   x_Custom_OUTPUT
		as A join [HOA_LIEN_DATA_REPLACE_SUP] as B on A.INPUTKEY = B.INPUTKEY
		and 
		A.HOA_LienRecordedDocumentNumber_001 = B.DocumentId
		AND 
		A.HOA_LienRecordedDocumentNumber_002 = B.DocumentId
		AND 
		Number_of_HOA_Liens = 2

		')



		Select [FREEBIE], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [FREEBIE]
		
		Select AddressStandardization, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by AddressStandardization
	

		Select EventStatus, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by EventStatus

		--Select EventStatus, count(*) From zzz_Proctor_20200312_OUTPUT
		--Group by EventStatus

		Select PropertyStatus, count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by PropertyStatus

		--Select * From x_custom_OUTPUT
		--where EventStatus like 'Event Found' or PropertyStatus in ('Property Not Found','Multiple Properties Found')

		Select EventStatus, count(*) from (
		Select Inputkey,EventStatus, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by Inputkey,EventStatus)A
		Group  by EventStatus

		Select PropertyStatus, count(*) from (
		Select Inputkey,PropertyStatus, count(*) as TOTAL From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by Inputkey,PropertyStatus)A
		Group  by PropertyStatus
		

		Select [CoverageStatus_PREFC], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [CoverageStatus_PREFC]

		Select [CoverageStatus_HOA_LIEN], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [CoverageStatus_HOA_LIEN]

		
		Select [AddressMatch], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [AddressMatch]

		Select [HAS_HOA_RECORD], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [HAS_HOA_RECORD]

		Select [Prioritization], count(*) From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_custom_OUTPUT]
		Group by [Prioritization]




		----------------HOA Liens------------------
		Select  A.FIPS, WORK_REF_ID, HAS_HOA_RECORD,[PROPERTYID_INT],A.INPUTKey,DATE_ADDED,A.INputAddress, EventStatus,[Prioritization],[SuperLienState],[FREEBIE],[LastDocTypeRecorded],Number_of_HOA_Liens
		--,HOA_LienRecordingDate_001 ,HOA_LienRecordedDocumentNumber_001      ,HOA_LienAmount_001       ,HOA_LienName_001, HOA_LienDocType_001,[HOA_SUP_001]
		--,HOA_LienRecordingDate_002 ,HOA_LienRecordedDocumentNumber_002      ,HOA_LienAmount_002       ,HOA_LienName_002, HOA_LienDocType_002,[HOA_SUP_002]
		--,HOA_LienRecordingDate_003 ,HOA_LienRecordedDocumentNumber_003      ,HOA_LienAmount_003       ,HOA_LienName_003, HOA_LienDocType_003,[HOA_SUP_003]
		--,HOA_LienRecordingDate_004 ,HOA_LienRecordedDocumentNumber_004      ,HOA_LienAmount_004       ,HOA_LienName_004, HOA_LienDocType_004
		--,HOA_LienRecordingDate_005 ,HOA_LienRecordedDocumentNumber_005      ,HOA_LienAmount_005       ,HOA_LienName_005, HOA_LienDocType_005
		--,HOA_LienRecordingDate_006 ,HOA_LienRecordedDocumentNumber_006      ,HOA_LienAmount_006       ,HOA_LienName_006, HOA_LienDocType_006
		--,HOA_LienRecordingDate_007 ,HOA_LienRecordedDocumentNumber_007      ,HOA_LienAmount_007       ,HOA_LienName_007, HOA_LienDocType_007
		--,HOA_LienRecordingDate_008 ,HOA_LienRecordedDocumentNumber_008      ,HOA_LienAmount_008       ,HOA_LienName_008, HOA_LienDocType_008
		,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount
		,A.MAX_LIENDATE
		,B.State, B.[County Name]
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
		where Number_of_HOA_Liens > 0
		Order by EventStatus,Number_of_HOA_Liens desc

		
		


		Select  A.FIPS, WORK_REF_ID, [PROPERTYID_INT],A.INPUTKey,DATE_ADDED,EventStatus,A.INputAddress, A.MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS]
		,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount,[NOD_NOS_REO],Freebie
		,B.State, B.[County Name]
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.INPUTKey = C.INPUTKEY
		where NbrofRecordings > 0
		and EventStatus like 'Event Found'
		--And Freebie is null
		Order by INPUTKEY,NbrofRecordings desc,  NOD_NOS_RecordNbr

		

		Select  A.FIPS, WORK_REF_ID, [PROPERTYID_INT],A.INPUTKey,DATE_ADDED,EventStatus,A.INputAddress, A.MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS]
		,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount,Freebie
		,B.State, B.[County Name]
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] as C on A.INPUTKey = C.INPUTKEY
		where A.NOD_NOS_DocType like 'JUDGMENT'
		Order by convert(money,NOD_NOS_DefaultAmount) desc


		Select * From [HOA].[dbo].[HOA_LIEN] where REF_ID = '38482738'

		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_TransHist] where REF_ID = '38482738'
		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[w_PreForeclosure]  where REF_ID = '38482738'

	
	    -----------------------Combination of below 2 queries MUST equal above query!!!----------------------------------
		----------------NOD/NOS------------------
		Select  A.FIPS, WORK_REF_ID, A.[PROPERTYID_INT],A.INPUTKey,A.INputAddress,EventStatus,A. MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS],[Number_of_HOA_Liens_RELEASED]
		,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount,Freebie
		,B.State, B.[County Name], C.DATE_ADDED
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[Input_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
		where [NbrofRecordings_NOD_NOS] > 0
		Order by NbrofRecordings desc, A.INPUTKEY

		----------------Releases------------------
		Select  A.FIPS, WORK_REF_ID, A.[PROPERTYID_INT],A.INPUTKey,A.INputAddress, EventStatus,A.MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS]
		,[Number_of_HOA_Liens_RELEASED],NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount
		,B.State, B.[County Name], C.DATE_ADDED,Freebie
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT] as A join [global].[dbo].[county] as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[Input_MONITOR] as C on A.INPUTKEY = C.INPUTKEY
		where NbrofRecordings_RELEASED > 0
		OR [Number_of_HOA_Liens_RELEASED] > 0
		Order by NbrofRecordings desc, A.INPUTKEY


		----------------Check to make sure Release hasn't already been sent------------
		--Select * From RELEASE_TRACKING_HIST where INPUTKEY in (
		--Select INPUTKEY from (
		--Select  FIPS, WORK_REF_ID, [PROPERTYID_INT],INPUTKey,INputAddress, MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS]
		--,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount
		--,B.State, B.[County Name]
		--From dbo.x_Custom_OUTPUT as A join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		--where NbrofRecordings_RELEASED > 0)A)
		--Order by INPUTKEY 


		
		-----------------------Check that FULL REcords were sent------------****************************
		--Select * From [HOA_LIEN_DATA_REPLACE_SUP]

		--Select  A.FIPS, WORK_REF_ID, A.[PROPERTYID_INT],A.INPUTKey,A.INputAddress,EventStatus,A. MAX_NODDATE,NbrofRecordings,NbrofRecordings_RELEASED,[NbrofRecordings_NOD_NOS],[Number_of_HOA_Liens_RELEASED]
		--,NOD_NOS_RecordNbr,  NOD_NOS_RecordingDate,     NOD_NOS_RecordedDocumentNumber    ,NOD_NOS_DocType       ,NOD_NOS_DefaultAmount,Freebie
		--,B.State, B.[County Name], C.DATE_ADDED
		--,[Prioritization],[SuperLienState],[FREEBIE],[LastDocTypeRecorded],Number_of_HOA_Liens
		--,HOA_LienRecordingDate_001 ,HOA_LienRecordedDocumentNumber_001      ,HOA_LienAmount_001       ,HOA_LienName_001, HOA_LienDocType_001,[HOA_SUP_001]
		--,HOA_LienRecordingDate_002 ,HOA_LienRecordedDocumentNumber_002      ,HOA_LienAmount_002       ,HOA_LienName_002, HOA_LienDocType_002,[HOA_SUP_002]
		--,SUP.*
		--From dbo.x_Custom_OUTPUT as A join global.dbo.county as B with(NOLOCK) on A.FIPS = B.FIPSCODE
		--join Input_MONITOR as C on A.INPUTKEY = C.INPUTKEY
		--join [HOA_LIEN_DATA_REPLACE_SUP] AS SUP on A.INPUTKEY = SUP.INPUTKEY
	


		--Select * From x_Custom_OUTPUT
		--where inputkey = '1548405'

		--Select * From HOA.dbo.HOA_LIEN
		--where REF_ID = '83205017'
		--Order by REcordingDate desc

		--Select * From w_TRANSHIST
		--where  REF_ID = '83205017'
		--Order by REcordingDate desc

		--Select * From w_Preforeclosure
		--where  REF_ID = '83205017'
		--Order by REcording_Date desc

		--Select * From  HOA.dbo.HOA_LIEN
		--where DocType = 'HASL'
		--and HOA_Auction_Date is not null


		--Select * From x_Custom_OUTPUT
		--where  inputkey in ( '0000040002 3426991','0000040003 3426170','0000040004 3426161','0000040009 3426992','0000040013 3426254','0000040018 3426256','0000040022 3426376','0000040023 3426165')

		--Select * From x_Custom_OUTPUT
		--where inputkey = '0520595302 799993'

		--Select * From INPUT_MONITOR
		--where inputkey = '0520595302 799993'

		--Select * From HOA.dbo.HOA_LIEN
		--where 
		--FIPS = '32003' and 
		--(
		----REF_ID = '83386850' OR 
		--DocumentID like '2018.509.3362' OR DocumentID like '2015.605.4261')

		--Select * From HOA.dbo.HOA_LIEN with(NOLOCK)
		--where REF_ID = '29172040'

		--Select * From [Data].[dbo].[HOA_Lien_Sup]
		--where LIC_PropertyID = '32856094'


		--------------These are the historical records appended because there are no new records for the input key OR Freebie records ---
		Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[x_Custom_OUTPUT]
		where EventStatus like 'Event Not Found'
		and 
		(Number_of_HOA_Liens > 0 OR NbrofRecordings > 0)


		--Select min([CoverageStatus_HOALienBeginDate]) From x_Custom_OUTPUT
		--where [CoverageStatus_HOALienBeginDate] not like '' and [CoverageStatus_HOALienBeginDate] is not null


		--Select max([CoverageStatus_HOALienEndDate]) From x_Custom_OUTPUT
		--where [CoverageStatus_HOALienEndDate] not like '' and [CoverageStatus_HOALienEndDate] is not null

			
		--Select * From LIEN_TRACKING	
		--where SUP like 'Y'


		--Select * From x_Custom_OUTPUT
		--where iNPUTKEY = '0515376646 774005'


		--Select A.* From [Data].[dbo].[HOA_Lien_Sup]  A with(NOLOCK)
		--join Assr.dbo.Assr as B with(NOLOCK) on A.LIC_PROPERTYID = B.LIC_PROPERTYID
		--join x_Custom_OUTPUT as C on B.REF_ID = C.WORK_REF_ID
		--where iNPUTKEY = '0515376646 774005'

		--Select A.* From [Data].[dbo].[HOA_Lien_Sup]  A with(NOLOCK)
		--where LIC_PROPERTYID = '29168086'

		--Select * From HOA_LIEN_SUP
		--where LIC_PROPERTYID = '29168086'

		--Select * From [LIEN_TRACKING_HIST]
		--where iNPUTKEY = '0515376646 774005'


		------------------------MANUAL CORRECTIONS FOR INCORRECT LIEN AMOUNTS ON SUP RECORDS----------
		----Update [LIEN_TRACKING_HIST]
		----Set LIEN_AMOUNT = '771.56'
		----where LIEN_DOC_NUMBER = '17889.865'
		----and iNPUTKEY = '0515376646 774005'


		----Select A.*, D.Fmt_NMD_document_number, D.LienAmount 
		----,convert(money,ROUND(A.LIEN_AMOUNT,0) / 100)
		----From [LIEN_TRACKING_HIST] as A 
		----join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		----join ASSR.dbo.Assr as C on B.REF_ID = C.REF_ID
		----join [Data].[dbo].[HOA_Lien_Sup] AS D on C.LIC_PROPERTYID = D.LIC_PROPERTYID
		----and A.LIEN_DOC_NUMBER = D.Fmt_NMD_document_number
		----where ROUND(A.LIEN_AMOUNT,0) <> convert(money,D.LienAmount)
		----AND SUP like 'Y'

		----Update A
		----Set A.LIEN_AMOUNT = convert(money,D.LienAmount)
		------Select A.*, D.Fmt_NMD_document_number, D.LienAmount ,SUP
		------,round(convert(money,A.LIEN_AMOUNT),0,1),round(convert(money,D.LienAmount) ,0,1)
		------,convert(money,D.LienAmount)
		------,(round(convert(money,D.LienAmount) ,0,1)  - round(convert(money,A.LIEN_AMOUNT),0,1))
		----From [LIEN_TRACKING_HIST] as A 
		----join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		----join ASSR.dbo.Assr as C on B.REF_ID = C.REF_ID
		----join [Data].[dbo].[HOA_Lien_Sup] AS D on C.LIC_PROPERTYID = D.LIC_PROPERTYID
		----and A.LIEN_DOC_NUMBER = D.Fmt_NMD_document_number
		----where 
		----round(convert(money,A.LIEN_AMOUNT),0,1) <> round(convert(money,D.LienAmount) ,0,1)
		----and 
		----(
		----	round(convert(money,D.LienAmount) ,0,1)  - round(convert(money,A.LIEN_AMOUNT),0,1) > 1
		----	OR
		----	round(convert(money,D.LienAmount) ,0,1)  - round(convert(money,A.LIEN_AMOUNT),0,1) < -1
		----)
		----AND SUP like 'Y'
		------AND 
		------A.INPUTKEY  like '0578498424 4023048'

		

		--Select A.LIC_PROPERTYID, A.Fmt_NMD_document_number, A.LienAmount From [Data].[dbo].[HOA_Lien_Sup] as A 
		--join Assr.dbo.assr as B on A.LIC_PROPERTYID = B.LIC_PROPERTYID
		--where B.REF_ID = '36621615'

		--Select * From HOA.dbo.HOA_LIEN
		--where REF_ID = '36621615'

		----Select * From LIEN_TRACKING_HIST

		----Update A
		----Set A.HOA_LIENAMOUNT = B.LIEN_AMOUNT
		------Select A.INPUTKEY, A.FIPS, C.State, C.[County Name],A.HOA_LienRecordedDocumentNumber, B.LIEN_DOC_NUMBER, A.HOA_LIENAMOUNT, B.LIEN_AMOUNT, SUP, DATE_SENT
		----From [PROCTOR_ALL_TRACKING] as A 
		----join LIEN_TRACKING_HIST as B on A.INPUTKEY = B.INPUTKEY
		----AND A.HOA_LienRecordedDocumentNumber = B.LIEN_DOC_NUMBER
		----join global.dbo.county as C with(NOLOCK) on A.FIPS = C.FIPSCODE
		----WHERE 
		----convert(money,A.HOA_LIENAMOUNT) <> convert(money,B.LIEN_AMOUNT)
		----AND round(convert(money,A.HOA_LIENAMOUNT),0,1) <> round(convert(money,B.LIEN_AMOUNT) ,0,1)
		----and 
		----(
		----	round(convert(money,B.LIEN_AMOUNT) ,0,1)  - round(convert(money,A.HOA_LIENAMOUNT),0,1) > 1000
		----	OR
		----	round(convert(money,B.LIEN_AMOUNT) ,0,1)  - round(convert(money,A.HOA_LIENAMOUNT),0,1) < -1000
		----)
		----AND convert(money,B.LIEN_AMOUNT) > 0
		----AND A.FIPS not like '32%'
		----AND 
		----A.INPUTKEY not in ( '0578151680 2299922')


		------------------------MANUAL CORRECTIONS TO INCLUDE HOA NAME FOR SUP RECORDS-------------------
		--Select A.INPUTKEY,A.HOA_LienRecordedDocumentNumber_001,A.HOA_LienName_001
		--,B.Fmt_NMD_document_number, B.Assn1NameFull
		-- From x_custom_OUTPUT as A join HOA_LIEN_SUP as B on 
		--A.INPUTKEY = B.INPUTKEY
		--and A.HOA_LienRecordedDocumentNumber_001 = B.Fmt_NMD_document_number
		--where ISNULL(A.HOA_LienName_001,'') like '' and ISNULL(B.Assn1NameFull,'') not like ''


		--Select A.INPUTKEY,A.HOA_LienRecordedDocumentNumber_002,A.HOA_LienName_002
		--,B.Fmt_NMD_document_number, B.Assn1NameFull
		-- From x_custom_OUTPUT as A join HOA_LIEN_SUP as B on 
		--A.INPUTKEY = B.INPUTKEY
		--and A.HOA_LienRecordedDocumentNumber_002 = B.Fmt_NMD_document_number
		--where ISNULL(A.HOA_LienName_002,'') like '' and ISNULL(B.Assn1NameFull,'') not like ''

		
		--Select * From [PROCTOR_ALL_TRACKING]
		--where INPUTKEY = '0578498424 4023048'

		--Select * From x_custom_OUTPUT
		--where INPUTKEY = '0578498424 4023048'

		--Select A.* From [Data].[dbo].[HOA_Lien_Sup] as A 
		--join ASSR.dbo.ASSR as B on A.LIC_PROPERTYID = B.LIC_PROPERTYID
		--where B.REF_ID in ('36621615')


		----Update A
		----Set A.HOA_LienName = LTRIM(RTRIM(D.Assn1NameFull))
		------Select A.INPUTKEY,A.RUNDATE,A.HOA_LienName,D.Fmt_NMD_document_number, D.Assn1NameFull
		----From [PROCTOR_ALL_TRACKING] as A 
		----join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		----join ASSR.dbo.Assr as C on B.REF_ID = C.REF_ID
		----join [Data].[dbo].[HOA_Lien_Sup] AS D on C.LIC_PROPERTYID = D.LIC_PROPERTYID
		----AND A.HOA_LienRecordedDocumentNumber = D.Fmt_NMD_document_number
		----WHERE ISNULL(A.HOA_LienName,'') like '' and ISNULL(D.Assn1NameFull,'') not like ''
		------AND A.INPUTKEY  like '0388959645 759864'


		--Select WORK_REF_ID, INPUTKEY, HOA_LienRecordingDate_001	,HOA_LienRecordedDocumentNumber_001	,HOA_LienAmount_001	,HOA_LienName_001 From x_Custom_OUTPUT
		--where INPUTKEY in ('0515376646 774005','0578148809 2298751','0578498424 4023048')


		--Select NOD_NOS_DocType, case when NOD_NOS_DocType like '%NOTICE OF DEFAULT%' then 'NOD' 
		--	when NOD_NOS_DocType like '%NOTICE OF SALE%' then 'NOS' 
		--	when NOD_NOS_DocType like '%NOTICE OF TRUSTEES SALE%' then 'NOS' 
		--	when  NOD_NOS_DocType like 'LIS PENDENS' then 'NOF'
		--	when  NOD_NOS_DocType like 'HOMEOWNERS ASSOCIATION LIEN FORECLOSURE' then 'NOF'
		--	when  NOD_NOS_DocType like 'NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN' then 'NOF'
		--	when  NOD_NOS_DocType in ('Release of Homeowners Association Lien    ', 'Release of Homeowners Association Lien    ' ,'Release of Condominium Homeowners Association Lien   '
		--	,'Release of Homeowners Association Lien for Violations  ')
		--	then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien   ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'HOA LIEN  RELEASE' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations  ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE' then 'REL_LIEN'
		--	when [NOD_NOS_REO] like 'REO' then 'REO'
		--	else NOD_NOS_DocType end
		--as DOCTYPE		,count(*) From x_custom_OUTPUT
		--where NOD_NOS_RECORDNBR > 0
		--Group by NOD_NOS_DocType, case when NOD_NOS_DocType like '%NOTICE OF DEFAULT%' then 'NOD' 
		--	when NOD_NOS_DocType like '%NOTICE OF SALE%' then 'NOS' 
		--	when NOD_NOS_DocType like '%NOTICE OF TRUSTEES SALE%' then 'NOS' 
		--	when  NOD_NOS_DocType like 'LIS PENDENS' then 'NOF'
		--	when  NOD_NOS_DocType like 'HOMEOWNERS ASSOCIATION LIEN FORECLOSURE' then 'NOF'
		--	when  NOD_NOS_DocType like 'NOTICE OF PENDENCY OF FORECLOSURE OF HOMEOWNERS ASSOCIATION LIEN' then 'NOF'
		--	when  NOD_NOS_DocType in ('Release of Homeowners Association Lien    ', 'Release of Homeowners Association Lien    ' ,'Release of Condominium Homeowners Association Lien   '
		--	,'Release of Homeowners Association Lien for Violations  ')
		--	then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Condominium Homeowners Association Lien   ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'HOA LIEN  RELEASE' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'Release of Homeowners Association Lien for Violations  ' then 'REL_LIEN'
		--	when  NOD_NOS_DocType like 'LIS PENDENS <HOA> RELEASE' then 'REL_LIEN'
		--	when [NOD_NOS_REO] like 'REO' then 'REO'
		--	else NOD_NOS_DocType end
		--Order by NOD_NOS_DocType

		--Select count(*) From INPUT_MONITOR
		--Select count(*) From (
		--Select INPUTKey,count(*) as TOTAL From x_Custom_OUTPUT
		--Group by INPUTKey)A

		--Select * From zCust_ProctorFinancial_HOA_LIEN.dbo.x_Custom_OUTPUT
		--where NOD_NOS_DocType is not null
		--order by INPUTKey

	

		--Select INPUTKey, NbrofRecordings, Number_of_HOA_Liens_RELEASED, NbrofRecordings_NOD_NOS
		--, NbrofRecordings_RELEASED
		-- From x_custom_OUTPUT
		--where NbrofRecordings > 0
		--Order by Number_of_HOA_Liens_RELEASED desc

		--Select A.INPUTKey,A.WORK_REF_ID,A.FIPS,B.DATE_ADDED,A.NbrofRecordings, A.Number_of_HOA_Liens_RELEASED, A.NbrofRecordings_NOD_NOS
		--, A.NbrofRecordings_RELEASED,NOD_NOS_REO,  Freebie,EventStatus
		--,A.NOD_NOS_RecordNbr	,A.NOD_NOS_RecordingDate	,A.NOD_NOS_RecordedDocumentNumber	,A.NOD_NOS_DocType
		-- From x_Custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		--where A.INPUTKey = '0578542722 4161135'

		--Select A.INPUTKey,A.WORK_REF_ID,A.FIPS,B.DATE_ADDED,A.NbrofRecordings, A.Number_of_HOA_Liens_RELEASED, A.NbrofRecordings_NOD_NOS
		--, A.NbrofRecordings_RELEASED,NOD_NOS_REO,  Freebie,EventStatus
		--,A.NOD_NOS_RecordNbr	,A.NOD_NOS_RecordingDate	,A.NOD_NOS_RecordedDocumentNumber	,A.NOD_NOS_DocType
		-- From x_Custom_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		--where A.Freebie = 'Y' and EventStatus like 'Event Not Found'


		--	Select A.INPUTKey,A.WORK_REF_ID,A.FIPS,B.DATE_ADDED,A.NbrofRecordings, A.Number_of_HOA_Liens_RELEASED, A.NbrofRecordings_NOD_NOS
		--, A.NbrofRecordings_RELEASED,  Freebie,EventStatus
		--,A.NOD_NOS_RecordNbr	,A.NOD_NOS_RecordingDate	,A.NOD_NOS_RecordedDocumentNumber	,A.NOD_NOS_DocType
		-- From zzz_Proctor_20191002_OUTPUT as A join INPUT_MONITOR as B on A.INPUTKEY = B.INPUTKEY
		--where A.Freebie = 'Y' and EventStatus like 'Event Not Found'


		--Select [Owner Borrower Match], count(*) From x_Custom_OUTPUT
		--Group by [Owner Borrower Match]

		------------------------FL Properties--Ini HOA where there are no recordings for FAI to research PER NH 20191118------------------
		---------------PROPERTYID is REF_ID - PROPERTYID_INT is FLANK PropertyID!!!-----------
		--SET CONCAT_NULL_YIELDS_NULL OFF
		--Select  A.FIPS, A.[WORK_REF_ID], A.INPUTBORROWER --,A.INPUTAddress
		--,Assr.FORMATTED_APN
		--, Assr.SITUS_HOUSE_NBR, Assr.SITUS_HOUSE_NBR_#2, Assr.SITUS_HOUSE_NBR_SUFFIX, Assr.SITUS_DIRECTION, Assr.SITUS_STREET_NAME, Assr.SITUS_MODE, Assr.SITUS_UNIT_NBR
		--,REPLACE( Assr.SITUS_HOUSE_NBR + ' ' + Assr.SITUS_HOUSE_NBR_#2 + ' ' + Assr.SITUS_HOUSE_NBR_SUFFIX + ' ' + Assr.SITUS_DIRECTION + ' ' + Assr.SITUS_STREET_NAME + ' ' + Assr.SITUS_MODE + ' ' + Assr.SITUS_UNIT_NBR,'  ',' ') 
		--,Assr.SITUS_CITY, Assr.SITUS_STATE, Assr.SITUS_ZIP_CODE
		----,HOA.*
		--from x_Custom_OUTPUT as A 
		--join Assr.dbo.Assr as Assr with(NOLOCK) on 
		--A.FIPS = Assr.FIPS and A.WORK_REF_ID = Assr.REF_ID
		----join HOA.dbo.HOA_Lien as HOA with(NOLOCK) on A.WORK_REF_ID = HOA.REF_ID
		--where A.FIPS like '12%' 
		--AND A.HAS_HOA_RECORD like 'Y'
		--and A.Number_of_HOA_Liens = 0
		--and A.NbrofRecordings = 0
		----and HOA.IsHoaLienActive = 1
		--Order by A.[WORK_REF_ID]


		-------Original 4K records per NH 20191119---
		--Select  Distinct A.FIPS, A.[WORK_REF_ID], A.INPUTBORROWER --,A.INPUTAddress
		--,Assr.FORMATTED_APN, Assr.SITUS_HOUSE_NBR, Assr.SITUS_HOUSE_NBR_#2, Assr.SITUS_HOUSE_NBR_SUFFIX, Assr.SITUS_DIRECTION, Assr.SITUS_STREET_NAME, Assr.SITUS_MODE, Assr.SITUS_UNIT_NBR
		--,REPLACE( Assr.SITUS_HOUSE_NBR + ' ' + Assr.SITUS_HOUSE_NBR_#2 + ' ' + Assr.SITUS_HOUSE_NBR_SUFFIX + ' ' + Assr.SITUS_DIRECTION + ' ' + Assr.SITUS_STREET_NAME + ' ' + Assr.SITUS_MODE + ' ' + Assr.SITUS_UNIT_NBR,'  ',' ') 
		--,Assr.SITUS_CITY, Assr.SITUS_STATE, Assr.SITUS_ZIP_CODE
		--,A.MAX_LIENDATE
		----,HOA.*
		--from x_Custom_OUTPUT as A 
		--join Assr.dbo.Assr as Assr with(NOLOCK) on 
		--A.FIPS = Assr.FIPS and A.WORK_REF_ID = Assr.REF_ID
		--join [20191119_Use_to_Pull_FL] as C on C.PropertyID = Assr.REF_ID
		----join HOA.dbo.HOA_Lien as HOA with(NOLOCK) on A.WORK_REF_ID = HOA.REF_ID
		--where A.FIPS like '12%' 
		--AND A.HAS_HOA_RECORD like 'Y'
		--and A.Number_of_HOA_Liens = 0
		--and A.NbrofRecordings = 0
		----and HOA.IsHoaLienActive = 1
		--Order by A.[WORK_REF_ID]

		--Select * From HOA.dbo.HOA_Lien with(NOLOCK)
		--where REF_ID = '29217887'

		--Select * From x_Custom_OUTPUT where WORK_REF_ID = '29217887'
		--Select Property_Id, Date_Transfer_Latest From [w_DM_Data] where Property_Id = '29217887'

		--Select * From INPUT_MONITOR
		--where INPUTSTATE like 'FL'
		--and HOA_FOUND like 'Y'

		--Select * From x_custom_OUTPUT where WORK_REF_ID = '37855161'

		--Select * From w_TransHist 
		--a JOIN [INPUT_MONITOR] b
		--on a.Raw_ID = b.INPUTKey
		--join w_preforeclosure as C on A.FIPS = C.FIPS
		--and A.REF_ID = C.REF_ID
		--and A.DocumentNbr = C.Fmt_Inst_Nbr
		--And A.DocumentType = C.Document_Type
		--where A.REF_ID = '37855161'


		--Select * From [x_Custom_OUTPUT]

		--Select A.FIPS, A.WORK_REF_ID,A.Inputkey, A.InputAddress,A.HOA_LienDocType_001 ,A.HOA_LienRecordedDocumentNumber_001 
		--,B.RunDate
		--From [x_Custom_OUTPUT] as A 
		--join [PROCTOR_ALL_TRACKING] as B on A.Inputkey = B.INputkey
		--and A.HOA_LienRecordedDocumentNumber_001 = B.HOA_LienRecordedDocumentNumber
		--where A.Number_of_HOA_Liens > 0
		--and A.HOA_LienDocType_001 like '%LIS%'
		--Order by A.HOA_LienDocType_001

		--Select A.FIPS, A.INPUTKey, A.WORK_REF_ID,A.PROPERTYID,A.NOD_NOS_RecordingDate,	A.NOD_NOS_RecordedDocumentNumber,	A.NOD_NOS_DocType
		--,A.NOD_NOS_DefaultAmount
		--,B.RunDate, B.HOA_LienRecordedDocumentNumber, B.NOD_NOS_RecordedDocumentNumber
		----,C.*
		--From [x_Custom_OUTPUT] as A 
		--left outer join [PROCTOR_ALL_TRACKING] as B on A.Inputkey = B.INputkey
		--and A.HOA_LienRecordedDocumentNumber_001 = B.HOA_LienRecordedDocumentNumber
		--left outer join HOA.dbo.HOA_LIEN as C with(NOLOCK)
		--on convert(int,A.FIPS) = convert(int,C.FIPS) and convert(bigint,A.WORK_REF_ID) = convert(bigint,C.REF_ID)
		--and A.NOD_NOS_RecordedDocumentNumber = C.DocumentId
		--where A.NOD_NOS_DocType like '%jud%'
		--ANd C.DocumentId is null
		----A.NOD_NOS_RecordNbr > 0
		----and A.NOD_NOS_DocType like '%J%'
		----and A.NOD_NOS_DocType like '%HOA%'
		--and A.WORK_REF_ID in ('35682029','37161277','32064000','29146959','37843979','37246727','29179795')
		--Order by A.WORK_REF_ID
		----Select * From  [x_Custom_OUTPUT] as A
		----join HOA.dbo.HOA_LIEN as C with(NOLOCK)
		----on convert(int,A.FIPS) = convert(int,C.FIPS) and convert(bigint,A.WORK_REF_ID) = convert(bigint,C.REF_ID)
		----and A.NOD_NOS_RecordedDocumentNumber = C.DocumentId
		----where NOD_NOS_DocType like '%jud%'


		--Select * From HOA.dbo.HOA_LIEN with(NOLOCK)
		--where REF_ID in ('35682029','37161277','32064000','29146959','37843979','37246727','29179795')
		----Order by REF_ID
		--and DocType like '%J%'

		
		--Select * From w_transhist with(NOLOCK)
		--where REF_ID in ('35682029','37161277','32064000','29146959','37843979','37246727','29179795')
		--and DocumentType like '%J%'


		--Select * From [PROCTOR_ALL_TRACKING]
		--where RUNDATE > getdate()-8

		----Delete from [PROCTOR_ALL_TRACKING]
		----where RUNDATE = '2020-01-26'
		

		--Select A.FIPS,A.WORK_REF_ID, B.HOAFIPS,B.REF_ID, B.HOARanking  From x_custom_OUTPUT as A 
		--left outer join HOA.dbo.OAFulfillment as B with(NOLOCK)
		--on 
		--A.WORK_REF_ID = B.REF_ID
		----and  a.FIPS = Right(('0' + convert(varchar(5),b.HOAFIPS)),5)
		--where A.WORK_REF_ID not like ''
		--and A.HAS_HOA_RECORD like ''
		--and B.REF_ID is not null


		--Select A.FIPS,A.WORK_REF_ID,A.HAS_HOA_RECORD, A.MonitorBeginDate From x_custom_OUTPUT as A 
		--left outer join HOA.dbo.OAFulfillment as B with(NOLOCK)
		--on 
		--A.WORK_REF_ID = B.REF_ID
		--where A.WORK_REF_ID not like ''
		--and A.HAS_HOA_RECORD like ''
		--and B.REF_ID is null


		--Select * From x_custom_OUTPUT

END






