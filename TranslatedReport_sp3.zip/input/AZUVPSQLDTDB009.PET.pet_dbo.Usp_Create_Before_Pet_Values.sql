/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.Usp_Create_Before_Pet_Values | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
--create or 

CREATE PROCEDURE [PET].[pet_dbo].[Usp_Create_Before_Pet_Values] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

select * from  pet.Pet_tmp.Pet_ref_ids_Apns_before

select * from pet.Pet_tmp.Pet_ref_ids_Legal_before


******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555,  N'info'
		,N'Usp_Create_Before_Pet_Values'
		,N'Started'

DROP TABLE

IF EXISTS [pet].[Pet_tmp].[Pet_ref_ids_Apns_before]
	SELECT DISTINCT pa.fips
		,pa.ref_id
		,pa.apn
	INTO [pet].[Pet_tmp].[Pet_ref_ids_Apns_before]
	FROM [pet].[dbo].[pet_apn] pa WITH (
			NOLOCK
			,INDEX (ixb_fips_ref_id)
			)
	INNER JOIN [Pet].[Pet_tmp].[Assr] pt WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON pt.fips = pa.fips
		AND pt.ref_id = pa.ref_id

create clustered index idx_fips_apn on [pet].[Pet_tmp].[Pet_ref_ids_Apns_before] (fips,apn)


--get the before neo_legals

DROP TABLE

IF EXISTS [pet].[Pet_tmp].[Pet_ref_ids_Legal_before]
	SELECT DISTINCT pl.fips
		,pl.ref_id
		,pl.NEO_TITLE_LEGAL
		,pl.neo_apn
	INTO [pet].[Pet_tmp].[Pet_ref_ids_legal_before]
	FROM [pet].[dbo].[pet_neo_legals] pl WITH (
			NOLOCK
			,INDEX (ix_fips_ref_id)
			)

	INNER JOIN [Pet].[Pet_tmp].[Assr] pt WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON pt.fips = pl.fips
		AND pt.ref_id = pl.ref_id

	

create clustered index idx_fips_apn on [pet].[Pet_tmp].[Pet_ref_ids_legal_before] (fips,NEO_TITLE_LEGAL)


	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	EXEC [PET].[dbo].[AddPetlog] 55555,  N'info'
		,N'Usp_Create_Before_Pet_Values'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH



