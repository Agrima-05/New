/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.USP_Extract_Property | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[USP_Extract_Property] @ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
MArie	7.30.2024	Add Pl_ref_id logic
******************************************************************************************************************/
BEGIN TRY
	SET NOCOUNT ON

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'USP_PropertyHeader'
		,N'Started'

	/*

USE lien_dtdb
GO

DECLARE	@return_value int

EXEC	@return_value = INFC.USP_PropertyHeader

SELECT	'Return Value' = @return_value

GO

select top 100 * from lien_DTDB.infc.Property_extract


*/
	DROP TABLE

	IF EXISTS [lien_DTDB].[infc].[Property_extract]
		SELECT a.*
		INTO [lien_DTDB].[infc].[Property_extract]
		FROM (
			SELECT p.doc_id AS doc_id
				,p.property_id_sequence_number
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_apn_portion, '')))) AS legal_desc_apn_portion
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_easement_flag, '')))) AS legal_desc_easement_flag
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_apn_split, '')))) AS legal_desc_apn_split
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_apn, '')))) AS ORIGINAL_APN
				,CASE 
					WHEN isnull(p.Pa_ref_id, 0) = 0
						THEN NULL
					ELSE ltrim(rtrim(p.pa_ref_id))
					END AS pa_ref_id
				,CASE 
					WHEN isnull(p.ps_ref_id, 0) = 0
						THEN NULL
					ELSE ltrim(rtrim(p.ps_Ref_id))
					END AS ps_ref_id
				--,CASE 
				--	WHEN isnull(pp.ref_id, 0) = 0
				--		THEN NULL
				--	ELSE ltrim(rtrim(pp.ref_id))
				--	END AS ref_id
				--,pp._ref_id AS ref_id
				,ar.ref_id AS ref_id
				--,CASE 
				--	WHEN isnull(ar.fips, 0) = 0
				--		THEN try_cast(d.fips_code AS INT)
				--	WHEN substring(d.fips_code, 1, 2) IN (
				--			'02'
				--			,'15'
				--			)
				--		AND isnull(ar.fips, 0) > 0
				--		THEN ar.fips
				--	WHEN ar.fips IN (
				--			36005
				--			,36047
				--			,36061
				--			,36081
				--			,36085
				--			)
				--		THEN ar.fips
				--	ELSE try_cast(d.fips_code AS INT)
				--	END AS Fips
				--,coalesce(ar.fips,pr.fips, pp._fips) AS fips
				--,pp._fips AS fips
				,CASE 
					WHEN isnull(pp._fips, 0) = 36150
						AND isnull(p.Pa_ref_id, 0) = 0
						AND isnull(p.ps_ref_id, 0) = 0
						THEN CASE 
								WHEN p.legal_desc_district = '1'
									THEN 36061 -- New York / Manhattan
								WHEN p.legal_desc_district = '2'
									THEN 36005 -- Bronx
								WHEN p.legal_desc_district = '3'
									THEN 36047 -- Kings / Brooklyn
								WHEN p.legal_desc_district = '4'
									THEN 36081 -- Queens
								WHEN p.legal_desc_district = '5'
									THEN 36085 -- Richmond/Staten Island 
								ELSE pp._fips
								END
					ELSE pp._fips
					END AS fips
				,UPPER(ltrim(rtrim(isnull(ar.unformatted_apn, '')))) AS APN_unformatted
				,UPPER(ltrim(rtrim(isnull(ar.formatted_apn, '')))) AS APN_formatted_UNIVERSAL
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_apn, '')))) AS legal_desc_apn
				,UPPER(ltrim(rtrim(isnull(ar.APN_SEQUENCE_NBR, '')))) AS APN_SEQUENCE_NBR
				,UPPER(ltrim(rtrim(isnull(ar.ACCOUNT_NBR, '')))) AS ACCOUNT_NBR
				,UPPER(ltrim(rtrim(isnull(p.HouseNumber, '')))) AS SITUS_HOUSE_NBR
				,'' AS SITUS_HOUSE_NBR2
				,'' AS SITUS_HOUSE_NBR_SUFFIX
				,UPPER(ltrim(rtrim(isnull(p.Direction, '')))) AS SITUS_DIRECTION
				,UPPER(ltrim(rtrim(isnull(p.Street_Name, '')))) AS SITUS_STREET_NAME
				,UPPER(ltrim(rtrim(isnull(p.Street_Type, '')))) AS SITUS_MODE
				,UPPER(ltrim(rtrim(isnull(p.Post_Direction, '')))) AS SITUS_POST_DIRECTION
				,UPPER(ltrim(rtrim(isnull(p.Unit, '')))) AS SITUS_UNIT_NBR
				,UPPER(ltrim(rtrim(isnull(p.City, '')))) AS SITUS_CITY
				,UPPER(ltrim(rtrim(isnull(p.STATE, '')))) AS SITUS_STATE
				,UPPER(ltrim(rtrim(isnull(p.Zip, '')))) + UPPER(ltrim(rtrim(isnull(p.Plus4, '')))) AS SITUS_ZIP_CODE
				,UPPER(ltrim(rtrim(isnull(p.crrt, '')))) AS SITUS_CARRIER_CODE
				--,UPPER(ltrim(rtrim(isnull(p.legal_desc_address, '')))) AS ORIGINAL_SITE_ADDRESS
				,upper(ltrim(rtrim(CASE 
								WHEN CHARINDEX('|', p.legal_desc_address) > 0
									THEN LEFT(p.legal_desc_address, CHARINDEX('|', p.legal_desc_address) - 1)
								ELSE ISNULL(p.legal_desc_address, '')
								END))) AS ORIGINAL_SITE_ADDRESS
				,UPPER(ltrim(rtrim(isnull(p._unit, '')))) AS legal_desc_map_unit_low
				,UPPER(ltrim(rtrim(isnull(p._lot, '')))) AS legal_desc_map_lot_low
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_block, '')))) AS legal_desc_map_block
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_building, '')))) AS legal_desc_map_building
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_plat_name, '')))) AS legal_desc_map_plat_name
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_plat_number, '')))) AS legal_desc_map_plat_number
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_plat_type_indicator, '')))) AS legal_desc_map_plat_type_indicator
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_plat_book, '')))) AS legal_desc_map_plat_book
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_map_plat_page, '')))) AS legal_desc_map_plat_page
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_str_section, '')))) AS legal_desc_str_section
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_str_township, '')))) AS legal_desc_str_township
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_str_range, '')))) AS legal_desc_str_range
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_district, '')))) AS legal_desc_district
				,P.MULTI_APN
				,D.m_status_id
				,UPPER(ltrim(rtrim(isnull(ar.PREVIOUS_PARCEL_NBR, '')))) AS PREVIOUS_PARCEL_NBR
				,UPPER(ltrim(rtrim(isnull(ar.PREVIOUS_PARCEL_SEQUENCE_NBR, '')))) AS PREVIOUS_PARCEL_SEQUENCE_NBR
				,UPPER(ltrim(rtrim(isnull(p.AddressMatchResults, '')))) AS AddressMatchResults
				,ROW_NUMBER() OVER (
					PARTITION BY pp._fips --coalesce(ar.fips,pr.fips, pp._fips)
					--pc.FIPS
					,pc.doc_type
					--,CASE 
					--	WHEN pc.Fips BETWEEN 15000
					--			AND 16000
					--		THEN coalesce(nullif(p.ps_ref_id, 0), nullif(p.pa_ref_id, 0))
					--	ELSE coalesce(nullif(p.pa_ref_id, 0), nullif(p.ps_ref_id, 0))
					--	END
					,pp._ref_id
					,[SPDB].[dbo].[RemoveSpecialChars](ISNULL(p.legal_desc_apn, ''))
					,ISNULL(pc.Instrument_nbr, '')
					,ISNULL(pc.recording_date_d, '')
					,isnull(d.source, '') ORDER BY ISNULL(p.legal_desc_apn, '')
						,isnull(p.legal_desc_address, '') DESC
					) AS ROW4
				,UPPER(ltrim(rtrim(isnull(p.legal_desc_qualifier, '')))) AS legal_desc_qualifier
				,UPPER(ltrim(rtrim(isnull(ar.Land_use, '')))) AS Land_use
			FROM [lien].[UR].[PROPERTYheader] p WITH (
					NOLOCK
					,INDEX (ix_doc_id)
					)
			INNER JOIN [lien_DTDB].[tmp].[reprocess_records_to_be_processed] pc WITH (
					NOLOCK
					,INDEX (idx)
					) ON pc.doc_id = p.doc_id
			OUTER APPLY (
				SELECT CASE 
						WHEN isnull(p.Ps_ref_id, 0) > 0
							THEN 'S'
						END AS Fips_ref_id_S
					,CASE 
						WHEN isnull(p.Pa_ref_id, 0) > 0
							THEN 'A'
						END AS Fips_ref_id_A
					--,CASE WHEN isnull(p.Pa_ref_id, 0) > 0 AND p.Legal_desc_Apn_Portion <> 'Y' THEN 'A' end as Fips_ref_id_A -- BUG799240  -- Marie
					,CASE 
						WHEN isnull(p.Pl_ref_id, 0) > 0
							THEN 'L'
						END AS Fips_ref_id_L
					,CASE 
						WHEN isnull(p.Ps_ref_id, 0) = 0
							AND isnull(p.Pa_ref_id, 0) = 0
							AND isnull(p.PL_ref_id, 0) = 0
							THEN 'D'
						END AS Fips_ref_id_D
				) rf
			OUTER APPLY (
				SELECT CASE 
						WHEN (
								pc.Fips BETWEEN 15000
									AND 16000
								OR pc.fips IN (
									36150
									,36005
									,36047
									,36061
									,36081
									,36085
									)
								OR pc.Fips BETWEEN 02000
									AND 03000
								)
							THEN CASE 
									--when af.Use_Actual_Fips = 0
									--	then pc.fips
									WHEN rf.Fips_ref_id_S = 'S'
										THEN p.ps_fips
									WHEN rf.Fips_ref_id_a = 'A'
										THEN p.pA_fips
									WHEN rf.Fips_ref_id_L = 'L'
										THEN p.pl_fips
									ELSE pc.fips
									END
						WHEN (
								pc.Fips BETWEEN 51000
									AND 52000
								)
							THEN CASE 
									WHEN rf.Fips_ref_id_a = 'A'
										THEN p.pA_fips
									WHEN rf.Fips_ref_id_S = 'S'
										THEN p.ps_fips
									WHEN rf.Fips_ref_id_L = 'L'
										THEN p.pl_fips
									ELSE pc.fips
									END
						ELSE pc.fips
							--CASE 
							--	WHEN rf.Fips_ref_id_A = 'A'
							--		THEN p.pa_fips
							--	WHEN rf.Fips_ref_id_S = 'S'
							--		THEN p.ps_fips
							--	WHEN rf.Fips_ref_id_l = 'L'
							--		THEN p.pl_fips
							--	ELSE pc.fips
							--	END
						END AS _fips --????????????????????????????????????????????????????????????????
					,CASE 
						WHEN (
								pc.Fips BETWEEN 15000
									AND 16000
								OR pc.fips IN (
									36150
									,36005
									,36047
									,36061
									,36081
									,36085
									)
								OR pc.Fips BETWEEN 02000
									AND 03000
								)
							THEN CASE 
									WHEN rf.Fips_ref_id_S = 'S'
										THEN p.ps_Ref_id
									WHEN rf.Fips_ref_id_A = 'A'
										THEN p.pA_Ref_id
									WHEN rf.Fips_ref_id_l = 'L'
										THEN p.pl_Ref_id
									ELSE NULL
									END
						ELSE CASE 
								WHEN rf.Fips_ref_id_A = 'A'
									THEN p.pa_Ref_id
								WHEN rf.Fips_ref_id_S = 'S'
									THEN p.ps_Ref_id
								WHEN rf.Fips_ref_id_L = 'L'
									THEN p.pl_Ref_id
								ELSE NULL
								END
						END AS _ref_id
				) pp
			LEFT JOIN [assr].[dbo].[assr] ar WITH (
					NOLOCK
					,INDEX (IDX_Assr_Ref_ID)
					) ON ar.ref_id = pp._ref_id
					and ar.fips in ( select TranslatedFips from [assr].[dbo].[translate_fips] where fips = pc.fips)

			--LEFT JOIN assr.dbo.PropertyReference pr WITH (
			--		NOLOCK
			--		,INDEX (PK_PropertyReference)
			--		) ON pr.ref_id = pp._ref_id
			LEFT JOIN [lien].[ur].[document] d WITH (
					NOLOCK
					,INDEX (pk_document)
					) ON d.doc_id = p.doc_id
			) a
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--LEFT JOIN lien_DTDB.tmp.multi_apn_wrk_doc_final m ON m.doc_id = p.doc_id
	--	AND m.property_id_sequence_number = p.property_id_sequence_number
	CREATE CLUSTERED INDEX idx_doc_id ON [lien_DTDB].[infc].[Property_extract] (doc_id)

	EXEC [lien_DTDB].[Infc].[AddInfcLog] N'info'
		,N'USP_PropertyHeader'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


