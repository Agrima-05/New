SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	parse Photo Links
-- ================================================================================

CREATE procedure [src_PlatLabs].[dbo].[usp_260_NormalizedAddress]

AS
BEGIN


	SET NOCOUNT ON;
	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


		TRUNCATE TABLE NormalizedAddress.NormalizedAddressData_Batch

		INSERT INTO [src_platlabs].[NormalizedAddress].[NormalizedAddressData_Batch]
		Select [uid],[mls_id],[mls_listing_id],complete_address as NormalizedAddress_CompleteAddress
		,street_number as NormalizedAddress_StreetNumber
		,street_name as NormalizedAddress_StreetName
		,street_suffix as NormalizedAddress_StreetSuffix
		,street_postdirection as NormalizedAddress_StreetPostdirection
		,street_predirection as NormalizedAddress_StreetPredirection
		,secondary_number as NormalizedAddress_SecondaryNumber
		,secondary_designator as NormalizedAddress_SecondaryDesignator
		,extra_secondary_number as NormalizedAddress_ExtraSecondaryNumber
		,extra_secondary_designator as NormalizedAddress_ExtraSecondaryDesignator
		,city as NormalizedAddress_City
		,zip as NormalizedAddress_Zip
		,state as NormalizedAddress_State
		,GetDate() as LoadDate
		 from (Select [uid],mls_id,mls_listing_id,[normalized_address] from [src_PlatLabs].[listing].[ListingsRaw_Batch] WITH(NOLOCK)) info
				CROSS APPLY OPENJSON([normalized_address]) WITH(
					complete_address varchar(500)
					  ,street_number varchar(20)
					  ,street_name varchar(100)
					  ,street_suffix varchar(20)
					  ,street_postdirection varchar(20)
					  ,street_predirection varchar(20)
					  ,secondary_number varchar(20)
					  ,secondary_designator varchar(20)
					  ,extra_secondary_number varchar(20)
					  ,extra_secondary_designator varchar(20)
					  ,city varchar(10)
					  ,zip varchar(20)
					  ,state varchar(20)
					 ) as NormalizedAddress_Array;

		INSERT INTO [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData_History]
		SELECT *,GetDate() as ArchiveDate FROM [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData]
		where [uid] in(Select [uid] from [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData_Batch])

		Delete from [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData]
		where [uid] in(Select [uid] from [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData_Batch])

		insert into [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData]
		Select * from [src_PlatLabs].[NormalizedAddress].[NormalizedAddressData_Batch]

		EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).

END




