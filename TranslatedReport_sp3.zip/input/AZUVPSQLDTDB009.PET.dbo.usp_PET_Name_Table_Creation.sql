/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | dbo.usp_PET_Name_Table_Creation | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =====================================================================================================================
-- Author:		<Marie Pretorius>
-- Create date: <02/09/2022>
-- Description:	<Create Pet Name Entries from NOVACL>
-- =====================================================================================================================
CREATE PROCEDURE [PET].[dbo].[usp_PET_Name_Table_Creation] @Fips INT = NULL
	,@Refresh BIT = NULL
	,@Ref_Id INT = NULL
	,@ERROR VARCHAR(500) OUTPUT
AS
BEGIN
	/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	7/31/22		Add the begin transaction logic
******************************************************************************************************************/
	BEGIN TRY
		--declare @Fips INT = 1
		--	,@Refresh BIT = 0
		--	,@Ref_Id INT = NULL
		--	,@ERROR varchar(500)
		DECLARE @SQL VARCHAR(MAX)
			,@LinkSvr VARCHAR(100) = ''

		SET @LinkSvr = CASE 
				WHEN @@SERVERNAME = N'AZUVPSQLDTDB009'
					THEN '[DWS-ETL01].'
				WHEN @@SERVERNAME = N'AZUVPSQLDTDB029'
					THEN '[DWS-ETL01.DATATREE.LOCAL].'
				ELSE ''
				END

		/*-----------------------------------------------
   Delete all records for the incoming county
  -----------------------------------------------*/
		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_PET_Name_Table_Creation'
			,N'Started'

		/*------------------------------------------
  Pull County Information into Temp tables 
  -----------------------------------------*/
		SET @SQL = '
				DROP TABLE if exists pet.tmp.NOVACL_XREF
				Select *
                into pet.tmp.NOVACL_XREF
                from ' + @LinkSvr + 'Novacl.dbo.NOVACL_XREF
                where Fips = ' + Cast(@Fips AS CHAR) + 'CREATE CLUSTERED INDEX [Idx_FipsRefId] ON pet.tmp.NOVACL_XREF (FIPS ASC, REF_ID ASC)'

		----Print @SQL
		EXEC (@SQL)

		SET @SQL = '
				DROP TABLE if exists pet.tmp.DIM_CLNAME
				Select *
                into pet.tmp.DIM_CLNAME
                from ' + @LinkSvr + 'Novacl.dbo.DIM_CLNAME
                where Fips = ' + Cast(@Fips AS CHAR) + 'CREATE CLUSTERED INDEX [Idx_Apn_ID] ON pet.tmp.DIM_CLNAME (Fips, Name_Id ASC)'

		--Print @SQL
		EXEC (@SQL)

		DROP TABLE

		IF EXISTS #name
			SELECT a.*
			INTO #name
			FROM (
				SELECT r.Fips
					,r.Ref_ID
					,n1.Last_Name
					,n1.First_Name
					,n1.Middle_Name
					,n1.Name_Type
					,n1.Suffix
					,ROW_NUMBER() OVER (
						PARTITION BY r.Fips
						,r.Ref_ID
						,n1.Last_Name
						,n1.First_Name
						,n1.Middle_Name
						,n1.Name_Type
						,n1.Suffix ORDER BY (
								SELECT 0
								)
						) AS ROW4
					,n1.Full_Name
					,n1.Raw_name
				FROM [PEt].[tmp].[NOVACL_XREF] r
				INNER JOIN [PEt].[tmp].[DIM_CLNAME] n ON r.fips = n.Fips
					AND r.Name_Id = n.Name_Id
				OUTER APPLY (
					SELECT nullif(n.Last_Name, '') AS Last_Name
						,nullif(n.First_Name, '') AS First_Name
						,nullif(n.Middle_Name, '') AS Middle_Name
						,nullif(n.Name_Type, '') AS Name_Type
						,nullif(n.Suffix, '') AS Suffix
						,nullif(n.Full_Name, '') AS Full_Name
						,nullif(n.Raw_name, '') AS Raw_name
					) n1
				) a
			WHERE row4 = 1
				AND (
					isnull(@Ref_Id, 0) = 0
					OR isnull(@ref_id, 0) = a.Ref_id
					)

		CREATE INDEX idx ON #name (
			fips
			,Ref_id
			,full_name
			,Last_Name
			,First_Name
			,Middle_Name
			,Name_Type
			,Suffix
			)

		BEGIN TRANSACTION

		IF @Refresh = 1
		BEGIN
			DELETE n
			FROM [pet].[dbo].[pet_name] n
			WHERE Fips = @Fips
		END
		ELSE IF @Refresh = 0
		BEGIN
			DELETE n
			FROM [pet].[dbo].[pet_name] n
			WHERE Fips = @Fips
				AND Ref_ID = @Ref_Id
		END

		/*--------------------------------------------------
   Insert records Into Pet.dbo.PET_Name from NovaCL
  --------------------------------------------------*/
		INSERT INTO [PET].[dbo].[PET_NAME] (
			Fips
			,REF_ID
			,Last_Name
			,First_Name
			,Middle_Name
			,Full_Name
			,Name_Type
			,created
			,updated
			,Suffix
			,Raw_Name
			)
		SELECT n.Fips
			,n.Ref_ID
			,n.Last_Name
			,n.First_Name
			,n.Middle_Name
			,n.Full_Name
			,n.Name_Type
			,getdate() AS created
			,getdate() AS updated
			,n.Suffix
			,n.Raw_Name
		FROM #name n

		COMMIT

		EXEC [PET].[dbo].[AddPetLog] @Fips
			,N'info'
			,N'usp_PET_Name_Table_Creation'
			,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		--ROLLBACK
		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


