SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_Solidifi].[dbo].[usp_300_Start_Output_S17]

AS
BEGIN
	
	SET NOCOUNT ON;

		DROP TABLE [dbo].[x_Custom_OUTPUT]

		CREATE TABLE [dbo].[x_Custom_OUTPUT](
			[FIPS] [varchar](5) NULL,
			[WORK_REF_ID] [bigint] NULL,
			[PROPERTYID] [bigint] NULL,

			

		[INPUT UniqueID][varchar](250)NULL,
		[INPUT Sample Date][varchar](250)NULL,
		[INPUT Address][varchar](250)NULL,
		[INPUT City][varchar](250)NULL,
		[INPUT State][varchar](250)NULL,
		[INPUT Zip][varchar](250)NULL,
		[INPUT County][varchar](250)NULL,
		[INPUT ST Fips][varchar](250)NULL,
		[INPUT CO Fips][varchar](250)NULL,
		[Property Address][varchar](250)NULL,
		[City][varchar](250)NULL,
		[State][varchar](250)NULL,
		[Zip Code][varchar](250)NULL,
		[Report Date][varchar](250)NULL,
		[AddressStandardization][varchar](250)NULL,
		[AVM Coverage ][varchar](250)NULL,
		[Property Status][varchar](250)NULL,
		[Event Status][varchar](250)NULL,
		[PropertyClassInd][varchar](250)NULL,
		[LandUseCode][varchar](250)NULL,
		[PowerFinalValue][varchar](250)NULL,
		[PowerHighValue][varchar](250)NULL,
		[PowerLowValue][varchar](250)NULL,
		[PowerConfidenceScore][varchar](250)NULL,
		[PowerStandardDeviation][varchar](250)NULL,
		[PremierFinalValue][varchar](250)NULL,
		[PremierHighValue][varchar](250)NULL,
		[PremierLowValue][varchar](250)NULL,
		[PremierConfidenceScore][varchar](250)NULL,
		[PremierStandardDeviation][varchar](250)NULL,
		[PriorSaleDate][varchar](250)NULL,
		[PriorSalePrice][varchar](250)NULL,
		[ValuationDate][varchar](250)NULL,


			

			
		) ON [PRIMARY]


		SET CONCAT_NULL_YIELDS_NULL OFF
		INSERT INTO [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] ([INPUT UniqueID],
			[INPUT Sample Date],
			[INPUT Address],
			[INPUT City],
			[INPUT State],
			[INPUT Zip],
			[INPUT County],
			[INPUT ST Fips],
			[INPUT CO Fips])
	
		
		Select convert(bigint,[Unique id]),convert(Date,[Sample Date]),Address,City,State,Zip,County,[ST FIPS],[CO FIPS]
		From [zCust_Solidifi].[dbo].[INPUT_RAW_CUST_NEW]
		

		Select * From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]


		UPDATE [zCust_Solidifi].[dbo].[a] 
		SET 
		a.WORK_REF_ID = c.REF_ID
		,A.PropertYID =C.PropertYID
		,A.FIPS = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		, a.[Report Date] = convert(date,GetDate())
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Solidifi].[dbo].[a_PropMatch_WORK_FLANK] c on a.[INPUT UniqueID] = c.RAW_ID

	
		Update [zCust_Solidifi].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Solidifi].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUT UniqueID] = c.RAW_ID


			
	

		-------POWER  & PREMIER WHEN JON APPROVED TO ADD PREMIER PER JON 20260130  FOR NOW JUST PLACEHOLDERS------
		Update [zCust_Solidifi].[dbo].[a]
		set [AVM Coverage] = 1
		--Select B.*
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN 
		(Select FIPS, count(*) T from [data].[dbo].[vAVM_Holocron] with(NOLOCK)
		where FIPS in 
			(Select Distinct FIPS From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] with(NOLOCK)
			where FIPS is not null)
		Group by FIPS) B  
		ON a.FIPS = b.FIPS



		Update [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] 
		SET [AVM Coverage] = CASE WHEN [AVM Coverage] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_Solidifi].[dbo].[a]
		SET a.AddressStandardization = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN [zCust_Solidifi].[dbo].[a_ASP_IN_STD] b
		on a.[INPUT UniqueID] = b.Raw_ID

		
		Update [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		SET [Property Status] = CASE WHEN 
		(PropertyID is not null and PropertyID not like '0' and PropertyID not like '')
		THEN 'Property Found' ELSE 'Property Not Found' END
				

		UPDATE [zCust_Solidifi].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a join [zCust_Solidifi].[dbo].[a_PropMatch_WORK_FLANK] b
		on a.[INPUT UniqueID] = b.RAW_ID
		WHERE b.MultiMatch = 'M'


			
		Update [zCust_Solidifi].[dbo].[A]
		Set 
		A.[PropertyClassInd] = B.PropertyClassID
		,A.[LandUseCode] = B.StdLandusecode
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] A JOIN
		[data].[dbo].[Property] as B with(NOLOCK) 
		on A.FIPS = B.FIPS and A.PropertyID = B.PropertyID



		UPDATE [zCust_Solidifi].[dbo].[a] 
		SET 
		A.[PropertyClassInd] = B.[CodeDesc]
		--Select top 10 * 
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN [global].[dbo].[lkup_Property_Class] B
		on A.[PropertyClassInd] = B.[PropClass]

			
		UPDATE [zCust_Solidifi].[dbo].[a] 
		SET 
		A.[LandUseCode] = B.[CodeDesc]
		--Select top 10 * 
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a JOIN [global].[dbo].[lkup_STD_LUSE] B
		on A.[LandUseCode] = B.[BKFSCode]



	--------POWER ------
	

		UPDATE [zCust_Solidifi].[dbo].[A]
		SET 
	
		A.[PowerFinalValue] = convert(bigint,convert(Money,B.[POWER_FInal_Value]))
		,A.[PowerHighValue] = convert(bigint,convert(Money,B.[POWER_HIGH_Value]))
		,A.[PowerLowValue] = convert(bigint,convert(Money,B.[POWER_LOW_Value]))
		,A.[PowerConfidenceScore] = B.[POWER_CONFIDENCE_SCORE]
		,A.[PowerStandardDeviation] = B.[POWER_FORECAST_STANDARD_DEVIATION]
		--,A.[ValuationDate] = Convert(date,B.[ValuationDate])
		-----Added 20240502 per MS & BR--to pull from PROCISION & NO LONGER FLANK----
		,A.PriorSaleDate = B.LASTKNOWNSALEDATE
		,A.PriorSalePrice = B.LASTKNOWNSALEPRICE
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  B.POWER_FINAL_VALUE > 0



		---------------Premier-------------
		------------------WAITING FOR APPROVAL BY JON!!!  20260130
		-------20260820 - Aproved per Jon (via email from Natasha)
		UPDATE [zCust_Solidifi].[dbo].[A]
		SET 
	
		A.[PremierFinalValue] = convert(bigint,convert(Money,B.[Premier_FInal_Value]))
		,A.[PremierHighValue] = convert(bigint,convert(Money,B.[Premier_HIGH_Value]))
		,A.[PremierLowValue] = convert(bigint,convert(Money,B.[Premier_LOW_Value]))
		,A.[PremierConfidenceScore] = B.[Premier_CONFIDENCE_SCORE]
		,A.[PremierStandardDeviation] = B.[Premier_FORECAST_STANDARD_DEVIATION]
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  B.Premier_FINAL_VALUE > 0


		---------------USE THIS WHEN PREMIER IS APPROVED!!!!!-------------
		UPDATE [zCust_Solidifi].[dbo].[A]
		SET 
	
		A.[ValuationDate] = Convert(date,B.[ValuationDate])
		-----Added 20240502 per MS & BR--to pull from PROCISION & NO LONGER FLANK----
		,A.PriorSaleDate = B.LASTKNOWNSALEDATE
		,A.PriorSalePrice = B.LASTKNOWNSALEPRICE
		FROM [zCust_Solidifi].[dbo].[x_Custom_OUTPUT] a 
		JOIN [data].[dbo].[vAVM_Holocron] as B with(NOLOCK) 
		on a.FIPS = b.FIPS
			and  A.PROPERTYID = B.PropertyID
			
		where  
		B.POWER_FINAL_VALUE > 0
		OR 
		B.Premier_FINAL_VALUE > 0



		
		---------------------------------------------------------------------------------------------------------------------

		--Select * From x_Custom_OUTPUT

		Update [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		SET [Event Status] = CASE WHEN   [PowerFinalValue] > 0 
		OR [PremierFinalValue] > 0 
		THEN 'Event Found' ELSE 'Event Not Found' END


		Select * From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event Found'
		and ([AVM Coverage] like 'Not%' or [Property Status] like '%not%' or [Property Status] like '%multiple%')

		--Select * From x_Custom_OUTPUT 
		--where [Event Status] like 'Event Not Found'
		--and [Property Status]  like 'Property Found'


		-----VALUE BUT NO CONF SCORE
		Select FIPS, [INPUT UniqueID],  PropertyID, 
		PowerFinalValue, PowerConfidenceScore, ValuationDate
		From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event Found'
		and 
		(PowerFinalValue is not null and PowerConfidenceScore is null)


		------No Value but date----
		Select FIPS, [INPUT UniqueID],  PropertyID 
		,PowerFinalValue, PowerConfidenceScore, ValuationDate
		From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where [Event Status] like 'Event not Found'
		and PropertyID is not null
		and ( ValuationDate is not null)
		

	

		------Has Final Value but missing some other field----
		Select FIPS, [INPUT UniqueID],  PropertyID
		,PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,ValuationDate
		From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where 
		(PowerFinalValue > 0 
			and 
			(PowerConfidenceScore is null or PowerHighValue is null or PowerLowValue is null or PowerStandardDeviation is null or ValuationDate is null)
		)

		
		------Checking Field Population----
		Select FIPS, [INPUT UniqueID],  PropertyID, 
		PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,ValuationDate
		From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where 
		PowerFinalValue is null

		

		------Checking Field Population----
		Select FIPS, [INPUT UniqueID],  PropertyID 
		,PowerFinalValue, PowerConfidenceScore,PowerHighValue,PowerLowValue,PowerStandardDeviation,ValuationDate
		From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		where 
		PowerFinalValue > 0 
		
		

		Select top 100 * From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]


		Select [Property Status], count(*) From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		Group by [Property Status]

		Select [Event Status], count(*) From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		Group by [Event Status]

		Select [AVM Coverage], count(*) From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		Group by [AVM Coverage]

		Select AddressStandardization, count(*) From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]
		Group by AddressStandardization
		
		Select top 10000 *  From [zCust_Solidifi].[dbo].[x_Custom_OUTPUT]

END




