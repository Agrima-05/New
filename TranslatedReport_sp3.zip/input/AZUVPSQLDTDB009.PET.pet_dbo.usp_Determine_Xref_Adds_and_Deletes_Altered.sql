/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Determine_Xref_Adds_and_Deletes_Altered | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */
 
-- =============================================  
-- Author:  Sean Dang  
-- Create date: 02/12/2025  
-- Description: Determine Rows to Add or Delete  
-- =============================================  
CREATE PROCEDURE [PET].[pet_dbo].[usp_Determine_Xref_Adds_and_Deletes_Altered]
	-- Add the parameters for the stored procedure here  
	(
	@Fips INT = 0
	,@ERROR VARCHAR(500) OUTPUT
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from  
	-- interfering with SELECT statements.  
	SET NOCOUNT ON;

	--rows that must be add  
	BEGIN TRY
		EXEC [PET].[dbo].[AddPetLog] @Fips
		  ,N'info'
		  ,N'usp_Determine_Xref_Adds_and_Deletes_Altered'
		  ,N'Started'

		TRUNCATE TABLE [PET].[pet_tmp].[Pet_Incremental_Add]

		UPDATE [PET].[pet_dbo].[b]
		SET b.PORTION_IND = a.PORTION_IND
		FROM [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips] a WITH (
				NOLOCK
				,INDEX (ixb)
				)
		INNER JOIN [PET].[dbo].[PET_NEO_Xref_Full] b WITH (
				NOLOCK
				,INDEX (ixb)
				) ON b.FIPS = a.FIPS
			AND b.NEO_APN = a.NEO_APN
			AND b.NEO_LAND_TYPE = a.NEO_LAND_TYPE
			AND b.NEO_TITLE_LEGAL = a.NEO_TITLE_LEGAL
			AND isnull(b.PORTION_IND, 0) <> isnull(a.PORTION_IND, 0)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		UPDATE [PET].[pet_dbo].[b]
		SET b.PORTION_IND = a.PORTION_IND
		FROM [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips] a WITH (
				NOLOCK
				,INDEX (ixb)
				)
		INNER JOIN [PET].[dbo].[PET_NEO_LEGALS] b WITH (
				NOLOCK
				,INDEX (ix_fipsNEO)
				) ON b.FIPS = a.FIPS
			AND b.NEO_APN = a.NEO_APN
			AND b.NEO_LAND_TYPE = a.NEO_LAND_TYPE
			AND b.NEO_TITLE_LEGAL = a.NEO_TITLE_LEGAL
			AND isnull(b.PORTION_IND, 0) <> isnull(a.PORTION_IND, 0)
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

		INSERT INTO [PET].[pet_tmp].[Pet_Incremental_Add]
		SELECT a.*
		FROM (
			SELECT FIPS
				,NEO_APN
				,NEO_LAND_TYPE
				,NEO_TITLE_LEGAL
				,PORTION_IND
			FROM [PET].[pet_tmp].[Pet_NEO_Xreff_Full_Fips]
			
			EXCEPT
			
			(
				SELECT FIPS
					,NEO_APN
					,NEO_LAND_TYPE
					,NEO_TITLE_LEGAL
					,PORTION_IND
				FROM [PET].[dbo].[PET_NEO_Xref_Full] WITH (
						NOLOCK
						,INDEX (ixa_fips)
						)
				WHERE fips = @Fips
				)
			) a
		--WHERE a.NEO_TITLE_LEGAL IS NOT NULL;

		EXEC [PET].[dbo].[AddPetLog] @Fips
		  ,N'info'
		  ,N'usp_Determine_Xref_Adds_and_Deletes_Altered'
		  ,N'Ended'
	END TRY

	BEGIN CATCH
		SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

		RAISERROR (
				@ERROR
				,16
				,1
				)
	END CATCH
END


