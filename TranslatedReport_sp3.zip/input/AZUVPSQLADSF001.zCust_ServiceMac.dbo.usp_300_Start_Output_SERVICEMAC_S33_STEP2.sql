SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [zCust_ServiceMac].[dbo].[usp_300_Start_Output_SERVICEMAC_S33_STEP2]

AS
BEGIN
	
	SET NOCOUNT ON;



			---------------------BUILD DOWN----------


		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordNbr] [int]NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordingDate] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_RecordedDocumentNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_DocType] [varchar](250) NULL')

		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [NOD_NOS_DefaultAmount] [varchar](250) NULL')
										
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_TrusteeAttorneyName] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_TrusteeAttorneyPhoneNumber] [varchar](250) NULL')
		EXEC('ALTER Table x_Custom_OUTPUT_S33 ADD [HOA_AuctionDate] [varchar](250) NULL')

	
	


END



