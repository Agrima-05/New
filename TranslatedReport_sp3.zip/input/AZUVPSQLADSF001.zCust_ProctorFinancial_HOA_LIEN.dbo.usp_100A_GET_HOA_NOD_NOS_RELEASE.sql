SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




-- =============================================
-- GET BKY DATA
-- =============================================
CREATE PROCEDURE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[usp_100A_GET_HOA_NOD_NOS_RELEASE]

AS
BEGIN

	SET NOCOUNT ON;

	--Select top 10 * From HOA_NOD_NOS_RELEASE
	

	------PULL ACTIVE HOA LIEN RECORDS-----IF multiple records per lien due to owners - pull only 1 owner per NH 20180322---
	 TRUNCATE TABLE  dbo.HOA_NOD_NOS_RELEASE

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end,
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY ,NULL
	 --,B.*
	 --Select B.*,
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	  -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	 left outer join  (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] with(NOLOCK) where ISNULL(REF_ID,'') not like '' ) as R on 
	 A.REF_ID = ISNULL(R.REF_ID,'0')
	 and (case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end) = R.RELEASE_RecordedDocumentNumber
	 where B.REF_ID is not null and ISNULL(R.REF_ID,'') not like '' 
	 AND R.RELEASE_RecordedDocumentNumber is null
	----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	AND 
	(
		REPLACE(REPLACE(REPLACE(B.NOD_NOS_RecordedDocumentNumber,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-','')
		OR
		REPLACE(REPLACE(REPLACE(B.NOD_NOS_RecordedDocumentNumber,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-','')
	)
	
	AND B.RELEASED_YN is null




	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end,
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY ,NULL
	 --,B.*
	 --Select B.*,
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	   -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	 left outer join  (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] with(NOLOCK) where ISNULL(REF_ID,'') not like '' ) as R on 
	 A.REF_ID = R.REF_ID
	 and (case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end) = R.RELEASE_RecordedDocumentNumber
	 where B.REF_ID is not null
	 AND R.RELEASE_RecordedDocumentNumber is null
	 ----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')

	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	AND 
	(
		REPLACE(REPLACE(REPLACE(B.NOD_NOS_RecordedDocumentNumber,'.',''),' ',''),'-','') =  left(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),4) + 
		Right(left(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),8),4) + 
		SUBSTRING((Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) ), PATINDEX('%[^0]%', (Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) )), 
		LEN((Right(REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-',''),7) )))

		OR

		REPLACE(REPLACE(REPLACE(B.NOD_NOS_RecordedDocumentNumber,'.',''),' ',''),'-','') = left(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),4) + 
		Right(left(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),8),4) + 
		SUBSTRING((Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) ), PATINDEX('%[^0]%', (Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) )), 
		LEN((Right(REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-',''),7) )))
	)

	AND B.RELEASED_YN is null



		--Select * From HOA_NOD_NOS_RELEASE
		--where INPUTKEY in ( 'DC563','DC1335')
	
	--Select * From RELEASE_TRACKING_HIST
	--Select A.*, D.*  FROM [HOA].[dbo].[HOA_Lien] A with(NOLOCK) 
	--join [HOA_LIEN_DOC_TYPES_20180705] as D
	-- on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	-- where A.REF_ID = '82859652' 
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	
	--Select *  FROM NOD_TRACKING_HIST where REF_ID = '82859652'


	--Select * From [HOA_LIEN_DOC_TYPES_20180705]
	--where [HOA_Doc_Type] = 'hadfrl'


	 --Select top 10 * From [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)

	

	 

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
            ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
      ,[INPUTKEY]      ,[RecordNumber],[SUP]
	  )
	 Select A.Lic_PropertyID    ,convert(int,[FipsCode])      ,F.REF_ID      ,[DetailDocumentType]      ,convert(varchar(10),[RecordingDt])      ,[LienAmount]     
	  --,convert(varchar(10),[RecordingDt]) 
	  --,[NMD_document_Book]     
		 --  ,[NMD_document_Page]     
		 --  ,[Fmt_NMD_document_number]     
		, [ReleaseDate]      ,A.[ReleaseBook]
      ,A.ReleasePage     ,A.ReleaseDocNumber 
		   ,[Owner1LastName]      ,left([Owner1FirstName],60)     ,left([Owner1MiddleName],60)      ,left([Owner2FirstName] ,200)     ,left([Owner2MiddleName],10)      ,left([SitusStdFullStreetAddress],200)
      ,left([SitusStdCity],100)       ,left([SitusStdState],2)      ,left([SitusStdZIP5] ,15)     ,left([FormattedAPN] ,200)     
	  ,left([SitusStdFullStreetAddress],200)           ,left([SitusStdCity],100)      ,[SitusStdState],left([SitusStdZIP5] ,15)  
	 ,C.INPUTKEY ,NULL	 
	 ,'Y'
	 --FROM  [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 --Select * 
	  FROM  [Data].[dbo].[HOA_Lien_Default_Sup]  A with(NOLOCK)
	   join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PropertyID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[NOD_TRACKING_HIST] as C on B.RAW_ID = C.INPUTKEY
	   -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(D.DocType))
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]
	  left outer join  (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] with(NOLOCK) where ISNULL(REF_ID,'') not like '' ) as R on 
	 F.REF_ID = R.REF_ID
	 and A.ReleaseDocNumber = R.RELEASE_RecordedDocumentNumber
	 where B.PropertyID is not null
	 AND R.RELEASE_RecordedDocumentNumber is null
	 and A.RecordingDt is not null
	 ----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')

	 --AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	 AND 
	(
		REPLACE(REPLACE(REPLACE(C.NOD_NOS_RecordedDocumentNumber,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(Fmt_NMD_document_number,'.',''),' ',''),'-','')
		
	)
	AND C.RELEASED_YN is null


	-------Get Lien Releases-----

	  Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]      ,[Fips]      ,[REF_ID]      ,[PKID]      ,[Identifier]      ,[CmtId]      ,[DocumentId]      ,[Sequence]      ,[BatchDate]      ,[DocType]
      ,[State]      ,[County]      ,[RecordingDate]      ,[RecordingYear]      ,[DocumentDate]      ,[HeaderSequence]      ,[LienDate]      ,[LienAmount]      ,[DateofFirstMissedPayment]
      ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number]      ,[NOD_NOS_Default_Amount]      ,[HOA_Auction_Date]
      ,[CaseNumber]      ,[CourtType]      ,[MAName]      ,[MAAddress]      ,[MAZip]      ,[MACity]      ,[MAState]      ,[MAEmail]      ,[MAPhone]      ,[MAContact]      ,[MASequence]
      ,[HOA_Trustee_Attorney Name]      ,[HOA_Trustee_Attorney_Phone_Number]      ,[LAWName]      ,[LAWAddress]      ,[LAWZip]      ,[LAWCity]      ,[LAWState]      ,[LAWEmail]
      ,[LAWPhone]      ,[LAWLastName]      ,[LAWFirstName]      ,[LAWMI]      ,[LAWSfx]      ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSfx]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]
      ,[OWNSpouseFlag]      ,[OWNSameAsProperty]      ,[OWNAddress]      ,[OWNZip]      ,[OWNCity]      ,[OWNState]      ,[OWNSequence]      ,[PropAPN]      ,[PropAddress]      ,[PropZip]
      ,[PropCity]      ,[PropState]      ,[PropSequence]      ,[OAReference]      ,[OAReferenceAlt]      ,[ReferenceBook]      ,[ReferencePage]      ,[ReferenceYear]      ,[ReferenceDocNo]
      ,[ReferenceRecordingDate]      ,[SourceId]      ,[SourcePK]      ,[SourceCreatedDate]      ,[SourceTruncationOccur]      ,[MULTI_APN]      ,[HOAName]      ,[HOAAddress]      ,[HOAZip]
      ,[HOACity]      ,[HOAState]      ,[HOAEmail]      ,[HOAPhone]      ,[HOAContact]      ,[SSCC]      ,[TAXAPN]      ,[Created]      ,[updated]      ,[FMT_ReferenceDocNo]      ,[FMT_ReferenceBookPage]
      ,[IsHoaLienActive]      ,[HOA_Std_FIPS]      ,[HOA_Std_Street_Number]      ,[HOA_Std_Direction]      ,[HOA_Std_Street_Name]      ,[HOA_Std_Street_Type]      ,[HOA_Std_Post_Direction]
      ,[HOA_Std_Unit_Type]      ,[HOA_Std_Unit]      ,[HOA_Std_City]      ,[HOA_Std_State]      ,[HOA_Std_Zip]      ,[HOA_Std_Plus4]      ,[HOA_Std_PlaceCode]      ,[HOA_Std_PlaceName]      ,[HOA_Std_Verified]
      ,[HOA_Std_AddressMatchResults]      ,[MA_Std_FIPS]      ,[MA_Std_Street_Number]      ,[MA_Std_Direction]      ,[MA_Std_Street_Name]      ,[MA_Std_Street_Type]      ,[MA_Std_Post_Direction]      ,[MA_Std_Unit_Type]
      ,[MA_Std_Unit]      ,[MA_Std_City]      ,[MA_Std_State]      ,[MA_Std_Zip]      ,[MA_Std_Plus4]      ,[MA_Std_PlaceCode]      ,[MA_Std_PlaceName]      ,[MA_Std_Verified]      ,[MA_Std_AddressMatchResults]
      ,[LAW_Std_FIPS]      ,[LAW_Std_Street_Number]      ,[LAW_Std_Direction]      ,[LAW_Std_Street_Name]      ,[LAW_Std_Street_Type]      ,[LAW_Std_Post_Direction]      ,[LAW_Std_Unit_Type]
      ,[LAW_Std_Unit]      ,[LAW_Std_City]      ,[LAW_Std_State]      ,[LAW_Std_Zip]      ,[LAW_Std_Plus4]      ,[LAW_Std_PlaceCode]      ,[LAW_Std_PlaceName]      ,[LAW_Std_Verified]      ,[LAW_Std_AddressMatchResults]
      ,[INPUTKEY]      ,[RecordNumber])

	 Select A.[ID],A.[Fips],A.[REF_ID]--,A.[NEW_REF_ID]
	 ,A.[PKID],A.[Identifier],A.[CmtId],A.[DocumentId],A.[Sequence],A.[BatchDate],A.[DocType],A.[State],A.[County],A.[RecordingDate],A.[RecordingYear],
A.[DocumentDate],A.[HeaderSequence],A.[LienDate],A.[LienAmount],A.[DateofFirstMissedPayment],A.[NOD_NOS_Recording_Date],A.[NOD_NOS_Recorded_Book],A.[NOD_NOS_Recorded_Page]
,case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end,
A.[NOD_NOS_Default_Amount],A.[HOA_Auction_Date],A.[CaseNumber],A.[CourtType],A.[MAName],A.[MAAddress],A.[MAZip],A.[MACity],A.[MAState],A.[MAEmail],A.[MAPhone],A.[MAContact],A.[MASequence],A.[HOA_Trustee_Attorney Name],
A.[HOA_Trustee_Attorney_Phone_Number],A.[LAWName],A.[LAWAddress],A.[LAWZip],A.[LAWCity],A.[LAWState],A.[LAWEmail],A.[LAWPhone],A.[LAWLastName],A.[LAWFirstName],A.[LAWMI],A.[LAWSfx],A.[OWNLastName],A.[OWNFirstName],
A.[OWNMI],A.[OWNSfx],A.[OWNSpouseFirst],A.[OWNSpouseMiddle],A.[OWNSpouseFlag],A.[OWNSameAsProperty],A.[OWNAddress],A.[OWNZip],A.[OWNCity],A.[OWNState],A.[OWNSequence],A.[PropAPN],A.[PropAddress],
A.[PropZip],A.[PropCity],A.[PropState],A.[PropSequence],A.[OAReference],A.[OAReferenceAlt],A.[ReferenceBook],A.[ReferencePage],A.[ReferenceYear],A.[ReferenceDocNo],A.[ReferenceRecordingDate],
A.[SourceId],A.[SourcePK],A.[SourceCreatedDate],A.[SourceTruncationOccur],A.[MULTI_APN],A.[HOAName],A.[HOAAddress],A.[HOAZip],A.[HOACity],A.[HOAState],A.[HOAEmail],A.[HOAPhone],A.[HOAContact],
A.[SSCC],A.[TAXAPN],A.[Created],A.[updated],A.[FMT_ReferenceDocNo],A.[FMT_ReferenceBookPage],A.[IsHoaLienActive],A.[HOA_Std_FIPS],A.[HOA_Std_Street_Number],A.[HOA_Std_Direction],A.[HOA_Std_Street_Name],
A.[HOA_Std_Street_Type],A.[HOA_Std_Post_Direction],A.[HOA_Std_Unit_Type],A.[HOA_Std_Unit],A.[HOA_Std_City],A.[HOA_Std_State],A.[HOA_Std_Zip],A.[HOA_Std_Plus4],A.[HOA_Std_PlaceCode],A.[HOA_Std_PlaceName],
A.[HOA_Std_Verified],A.[HOA_Std_AddressMatchResults],A.[MA_Std_FIPS],A.[MA_Std_Street_Number],A.[MA_Std_Direction],A.[MA_Std_Street_Name],A.[MA_Std_Street_Type],A.[MA_Std_Post_Direction],A.[MA_Std_Unit_Type],
A.[MA_Std_Unit],A.[MA_Std_City],A.[MA_Std_State],A.[MA_Std_Zip],A.[MA_Std_Plus4],A.[MA_Std_PlaceCode],A.[MA_Std_PlaceName],A.[MA_Std_Verified],A.[MA_Std_AddressMatchResults],A.[LAW_Std_FIPS],A.[LAW_Std_Street_Number],
A.[LAW_Std_Direction],A.[LAW_Std_Street_Name],A.[LAW_Std_Street_Type],A.[LAW_Std_Post_Direction],A.[LAW_Std_Unit_Type],A.[LAW_Std_Unit],A.[LAW_Std_City],A.[LAW_Std_State],A.[LAW_Std_Zip],
A.[LAW_Std_Plus4],A.[LAW_Std_PlaceCode],A.[LAW_Std_PlaceName],A.[LAW_Std_Verified],A.[LAW_Std_AddressMatchResults],B.INPUTKEY ,NULL
	 --,B.*
	 --Select B.*,
	 FROM [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as B with(NOLOCK)
	  on A.REF_ID = B.REF_ID
	     -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DocType)) = LTRIM(RTRIM(D.DocType))
	 --  join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]

	  left outer join  (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] with(NOLOCK) where ISNULL(REF_ID,'') not like '' ) as R on 
	 A.REF_ID = R.REF_ID
	 and (case when A.[NOD_NOS_Recorded_Document_Number] is null then A.DocumentID else A.[NOD_NOS_Recorded_Document_Number] end) = R.RELEASE_RecordedDocumentNumber
	 where ISNULL(B.REF_ID,'') not like ''
	 AND R.RELEASE_RecordedDocumentNumber is null
	  ----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')

	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	AND 
	(
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReference,'.',''),' ',''),'-','')
		OR
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(OAReferencealt,'.',''),' ',''),'-','')
	)
	
	AND B.RELEASED_YN is null

		--Select * From HOA_NOD_NOS_RELEASE
		--where INPUTKEY in ( 'DC563','DC1335')

	--Select A.*, D.*  FROM [HOA].[dbo].[HOA_Lien] A with(NOLOCK) 
	--join [HOA_LIEN_DOC_TYPES_20180705] as D
	-- on LTRIM(RTRIM(A.DocType)) = D.[HOA_Doc_Type]
	-- where A.REF_ID = '82859652' 
	--AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	
	--Select *  FROM NOD_TRACKING_HIST where REF_ID = '82859652'


	--Select * From [HOA_LIEN_DOC_TYPES_20180705]
	--where [HOA_Doc_Type] = 'hadfrl'


	 --Select top 10 * From [HOA].[dbo].[HOA_Lien]  A with(NOLOCK)

	 Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]      ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  ,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
            ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
      ,[INPUTKEY]      ,[RecordNumber],[SUP]
	  )
	 Select A.Lic_PropertyID    ,convert(int,[FipsCode])      ,F.REF_ID      ,[DetailDocumentType]      ,convert(varchar(10),[RecordingDt])      ,[LienAmount]      ,convert(varchar(10),[RecordingDt]) ,[NMD_document_Book]     
		   ,[NMD_document_Page]     
		   ,[Fmt_NMD_document_number]      
		   ,[Owner1LastName]      ,left([Owner1FirstName],60)     ,left([Owner1MiddleName],60)      ,left([Owner2FirstName] ,200)     ,left([Owner2MiddleName],10)      ,left([SitusStdFullStreetAddress],200)
      ,left([SitusStdCity],100)       ,left([SitusStdState],2)      ,left([SitusStdZIP5] ,15)     ,left([FormattedAPN] ,200)     
	  ,left([SitusStdFullStreetAddress],200)           ,left([SitusStdCity],100)      ,[SitusStdState],left([SitusStdZIP5] ,15)  
	 ,C.INPUTKEY ,NULL	 
	 ,'Y'
	 --FROM  [Data].[dbo].[HOA_Lien_sup]  A with(NOLOCK)
	 --Select * 
	  FROM  [Data].[dbo].[HOA_Lien_Default_Sup]  A with(NOLOCK)
	   join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[a_PropMatch_WORK_FLANK] as B with(NOLOCK)
	 on A.LIC_PROPERTYID = B.PropertyID
	 join [Assr].[dbo].[Assr] as F with(NOLOCK) on B.PropertyID = F.LIC_PRopertyID
	 join [zCust_ProctorFinancial_HOA_LIEN].[dbo].[LIEN_TRACKING_HIST] as C on B.RAW_ID = C.INPUTKEY
	     -----Changed 20191114 to use new doc type table---
	  join [HOALIEN].[dbo].[HOA_DOC_TYPE_USE_20191113] as D 
	   on LTRIM(RTRIM(A.DetailDocumentType)) = LTRIM(RTRIM(D.DocType))
	 --join zCust_BOA.dbo.[HOA_LIEN_DOC_TYPES_20180705] as D
	 --on LTRIM(RTRIM(A.DetailDocumentType)) = D.[HOA_Doc_Type]

	   left outer join  (Select * From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[RELEASE_TRACKING_HIST] with(NOLOCK) where ISNULL(REF_ID,'') not like '' ) as R on 
	 F.REF_ID = R.REF_ID
	 and A.ReleaseDocNumber = R.RELEASE_RecordedDocumentNumber
	 where B.PropertyID is not null
	 AND R.RELEASE_RecordedDocumentNumber is null
	 	 and A.RecordingDt is not null
		  ----Changed 20191114 to use new Doc Type Table---
	AND D.HOA_Data_Type in ('NOD/NOS/REO/Release','Partial Release','release')

	 --AND (Full_Name like '%release%' or Full_Name like '%Recission%' or Full_Name like '%Rescission%')
	 AND 
	(
		REPLACE(REPLACE(REPLACE(LIEN_DOC_NUMBER,'.',''),' ',''),'-','') = REPLACE(REPLACE(REPLACE(Fmt_NMD_document_number,'.',''),' ',''),'-','')
		
	)
	AND C.RELEASED_YN is null





	 --Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
	 --   ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	 -- --,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
  -- --         ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
		--	--,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
  --    ,[INPUTKEY]      ,[RecordNumber],[OAReference]
	 -- )
	
	 -- Select PropertyID, FIPS,REF_ID,'CDLNRL','20180824','6071.50','2018-04-10',NULL,NULL,'2018.085490'
	 -- ,INPUTKEY,NULL,'2018.085316'
	 -- From INPUT_MONITOR 
	 -- where INPUTKEY = 'DC1335'


	  -- Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
	  --  ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  ----,[OWNLastName]      ,[OWNFirstName]      ,[OWNMI]      ,[OWNSpouseFirst]      ,[OWNSpouseMiddle]      ,[OWNAddress]
   ----         ,[OWNCity]      ,[OWNState] ,[OWNZip]     ,[PropAPN]      
			----,[PropAddress]          ,[PropCity]      ,[PropState],[PropZip]  
   --   ,[INPUTKEY]      ,[RecordNumber],[OAReference]
	  --)
	
	  --Select PropertyID, FIPS,REF_ID,'HALNRL','20180906','5044.21','2018-04-01',NULL,NULL,'2018.089875'
	  --,INPUTKEY,NULL,'2018.021392'
	  --From INPUT_MONITOR where INPUTKEY = 'DC563'



	  --   Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
	  --  ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  --   ,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
	  --Select PropertyID, FIPS,REF_ID,'HALNRL','20180906','4072.79','2018-01-16',NULL,NULL,'2018.089874'
	  --,INPUTKEY,NULL,'2018.004863'
	  --From INPUT_MONITOR where INPUTKEY = 'DC563'

	  
	  --   Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
	  --  ,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
	  --   ,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
	  --Select PropertyID, FIPS,REF_ID,'HALNRL','20180906','2997.34','2017-08-04',NULL,NULL,'2018.089873'
	  --,INPUTKEY,NULL,'2017.085963'
	  --From INPUT_MONITOR where INPUTKEY = 'DC563'


		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HALNRL','20181015','2746.47','2018-10-15',NULL,NULL,'2018.1015.1135'
		--,INPUTKEY,NULL
		--,'2013.0329.409'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV4613'

		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HADFRL','20181015',NULL,'2018-10-15',NULL,NULL,'2018.1015.1131'
		--,INPUTKEY,NULL
		--,'2014.0910.31'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV4613'





		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HALNRL','20181003','1315.00','2018-10-03',NULL,NULL,'2018.1003.1673'
		--,INPUTKEY,NULL
		--,'2008.0711.1530'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV2135'

		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HADFRL','20181003',NULL,'2018-10-03',NULL,NULL,'2018.1003.1677'
		--,INPUTKEY,NULL
		--,'2008.1112.1129'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV2135'





	  
		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HALNRL','20181015',NULL,'2018-10-15',NULL,NULL,'2018.1015.1140'
		--,INPUTKEY,NULL,'2010.0929.206'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV763'


		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HADFRL','20181015',NULL,'2018-10-15',NULL,NULL,'2018.1015.1136'
		--,INPUTKEY,NULL,'2011.0118.858'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV763'






		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HALNRL','20181011',NULL,'2018-10-11',NULL,NULL,'2018.1011.1348'
		--,INPUTKEY,NULL,'2018.0828.2456'
		--From INPUT_MONITOR where INPUTKEY = 'NV15862'


		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181018',NULL,'2018-10-18',NULL,NULL,'2018.1018.414'
		,INPUTKEY,NULL
		,'2015.0825.2104'----Reference number
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV5548'


			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181018',NULL,'2018-10-18',NULL,NULL,'2018.1018.415'
		,INPUTKEY,NULL
		,'2015.0702.1937'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV5548'


		
			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181017',NULL,'2018-10-17',NULL,NULL,'2018.1017.1265'
		,INPUTKEY,NULL
		,'2018.0823.1677'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV10359'




		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181025',NULL,'2018-10-25',NULL,NULL
		,'2018.1025.2740'
		,INPUTKEY,NULL
		,'2014.0423.88'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4531'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181025',NULL,'2018-10-25',NULL,NULL
		,'2018.1025.2192'
		,INPUTKEY,NULL
		,'2014.0823.636'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV10610'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181025',NULL,'2018-10-25',NULL,NULL
		,'2018.1025.2191'
		,INPUTKEY,NULL
		,'2018.0712.1101'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV10610'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181025',NULL,'2018-10-25',NULL,NULL
		,'2018.1025.2011'
		,INPUTKEY,NULL
		,'2011.0210.3903'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV3634'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181025',NULL,'2018-10-25',NULL,NULL
		,'2018.1025.2014'
		,INPUTKEY,NULL
		,'2011.0404.812'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV3634'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181106',NULL,'2018-11-06',NULL,NULL
		,'2018.1106.2829'
		,INPUTKEY,NULL
		,'2015.1005.2553'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4867'


			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181109',NULL,'2018-11-09',NULL,NULL
		,'2018.1109.1302'
		,INPUTKEY,NULL
		,'2018.1005.567'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV3258'

		


		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HASLRL','20181106',NULL,'2018-11-06',NULL,NULL
		--,'2018.1106.2830'
		--,INPUTKEY,NULL
		--,'2018.0925.2673'----REference
		--From INPUT_MONITOR where INPUTKEY = 'NV4867'


			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181109',NULL,'2018-11-09',NULL,NULL
		,'2018.1109.1715'
		,INPUTKEY,NULL
		,'2018.0111.1138'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV6718'

			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181108',NULL,'2018-11-08',NULL,NULL
		,'2018.1108.1927'
		,INPUTKEY,NULL
		,'2011.0602.1315'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV6833'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181108',NULL,'2018-11-08',NULL,NULL
		,'2018.1108.2446'
		,INPUTKEY,NULL
		,'2018.1018.394'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV7627'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181108',NULL,'2018-11-08',NULL,NULL
		,'2018.1108.2537'
		,INPUTKEY,NULL
		,'2018.0716.535'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV3908'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181108',NULL,'2018-11-08',NULL,NULL
		,'2018.1108.2613'
		,INPUTKEY,NULL
		,'2018.0928.1799'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV3908'


			Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181107',NULL,'2018-11-07',NULL,NULL
		,'2018.1107.219'
		,INPUTKEY,NULL
		,'2018.0911.1250'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV1416'


		----------20181126----
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181116',NULL,'2018-11-16',NULL,NULL
		,'2018.1116.1486'
		,INPUTKEY,NULL
		,'2018.0323.1966'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV12943'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2054'
		,INPUTKEY,NULL
		,'2008.1126.4492'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4436'

		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2055'
		,INPUTKEY,NULL
		,'2013.1017.1639'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4436'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2121'
		,INPUTKEY,NULL
		,'2012.0126.2500'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV2572'


		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2126'
		,INPUTKEY,NULL
		,'2012.0329.2281'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV2572'
		

		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2157'
		,INPUTKEY,NULL
		,'2018.0914.312'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV1231'


		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2158'
		,INPUTKEY,NULL
		,'2009.0817.2692'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4436'

		
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2159'
		,INPUTKEY,NULL
		,'2011.0728.1915'----REference
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4436'


		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference]
		,[SUP] )
	
		Select PropertyID, FIPS,REF_ID,'HALNRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2358'
		,INPUTKEY,NULL
		,'2018.0626.841'----REference
		,'Y'
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV1231'


			
		Insert into [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE]  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		,[INPUTKEY]      ,[RecordNumber],[OAReference] 
		,[SUP] )
	
		Select PropertyID, FIPS,REF_ID,'HASLRL','20181115',NULL,'2018-11-15',NULL,NULL
		,'2018.1115.2832'
		,INPUTKEY,NULL
		,'2011.1106.2830'----REference
		,'Y'
		From [zCust_ProctorFinancial_HOA_LIEN].[dbo].[INPUT_MONITOR] where INPUTKEY = 'NV4867'

		--Update NOD_TRACKING_HIST
		--Set RELEASED_YN = NULL
		--where INPUTKEY = 'NV4867'
		--AND NOD_NOS_RecordedDocumentNumber = '2018.925.2673'
		



		--Select * From INPUT_MONITOR where INPUTKEY = 'NV10359'
		

		--------------------Check!

		--Insert into dbo.HOA_NOD_NOS_RELEASE  ([ID]     ,[Fips]      ,[REF_ID]      ,[DocType]      ,[RecordingDate]      ,[LienAmount]       ,[NOD_NOS_Recording_Date]      ,[NOD_NOS_Recorded_Book]   
		--,[NOD_NOS_Recorded_Page]      ,[NOD_NOS_Recorded_Document_Number] 
		--,[INPUTKEY]      ,[RecordNumber],[OAReference] )
	
		--Select PropertyID, FIPS,REF_ID,'HALNRL','20180906','2997.34','2017-08-04',NULL,NULL,'2018.089873'
		--,INPUTKEY,NULL,'2017.085963'
		--From INPUT_MONITOR where INPUTKEY = 'NV15862'


		--Select * From [HOA_LIEN_DOC_TYPES_20180705]
		--where HOA_DOC_TYPE like 'HALNRL'
		--OR FULL_NAME like '%sal%'
		--OR FULL_NAME like '%resc%'


	 -- Select * From INPUT_MONITOR where INPUTKEY = 'NV15862'
	 -- OR INPUTADDRESS like '6612%'

	  --Select * From [HOA_LIEN_DOC_TYPES_20180705]
	  --where Full_Name like '%Resc%'
	  --OR  HOA_DOC_TYPE in ('HALNRL','HASLRL')
	  --and Full_Name like '%condo%'


	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] SET RecordNumber = NULL

	 
	  
	 UPDATE [zCust_ProctorFinancial_HOA_LIEN].[dbo].[t] SET RecordNumber = RowNum
		FROM [zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] t LEFT JOIN
		(SELECT * 
			,ROW_NUMBER() OVER(PARTITION BY REF_ID,INPUTKEY ORDER BY NOD_NOS_Recording_Date DESC)  AS RowNum
			FROM 
		[zCust_ProctorFinancial_HOA_LIEN].[dbo].[HOA_NOD_NOS_RELEASE] t  ) r ON t.REF_ID = r.REF_ID and t.[ID] = r.[ID] and t.INPUTKEY = r.INPUTKEY


	--Select * From HOA_NOD_NOS
	--Order by REF_ID
			
			


END





