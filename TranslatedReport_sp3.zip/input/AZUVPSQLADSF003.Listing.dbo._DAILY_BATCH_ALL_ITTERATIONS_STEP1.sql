SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE Procedure [Listing].[dbo].[_DAILY_BATCH_ALL_ITTERATIONS_STEP1]
as
Begin
-----Run to obtain ALL Listing Tracking IDs------

				DECLARE @query NVARCHAR(MAX)
				DECLARE @body NVARCHAR(MAX)
				DECLARE @Subject NVARCHAR(MAX)
				DECLARE @DATE VARCHAR(10)
				DECLARE @tab char(1) = CHAR(9)
				DECLARE @query_attachment_filename NVARCHAR(MAX)
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @Subject = 'Listing Daily Batch -ALL ITTERATIONS - Process Starting - ' + @Date 
				SET @body = NULL
		

				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = @body,
				@body_format ='HTML',
				--@recipients = 'klowe@firstam.com;MicSmith@firstam.com;jeschmeyer@firstam.com',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1
						;


Truncate table dbo._LISTINGS_DAILY_BATCH_ALL_ITTERATIONS
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT1]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT2]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT3]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT4]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT5]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT6]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT7]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT8]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT9]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT10]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT11]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT12]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT13]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT14]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT15]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT16]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT17]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT18]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT19]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT20]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT31]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT32]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT33]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT34]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT35]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT36]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT37]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT38]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT39]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT40]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT41]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT42]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT43]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT44]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT45]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT46]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT47]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT48]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT49]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT50]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT51]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT52]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT53]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT54]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT55]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT56]

Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT80]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT81]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT82]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT83]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT84]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT85]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT86]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT87]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT88]
Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_SPLIT89]


Truncate table dbo.[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS_DELETE]




------************************--UNCOMMENT AFTER 20260810!!!******************
--CREATE NONCLUSTERED INDEX [NonClusteredIndex-ID_SEQ] ON FA_Listing.[dbo].[Listing]
--(
--	[Listing_ID] ASC,
--	[UpdateSeq] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
------*****************************************************



--Select Update_Timestamp, count(*) From _LISTINGS_DAILY_BATCH_ALL_ITTERATIONS
--Group by Update_Timestamp
--Order by Update_Timestamp desc

--Delete from _LISTINGS_ALL_ITTERATIONS
--where Update_Timestamp >= '2018-01-23 01:43:30.790'

--Select Update_Timestamp, count(*) From _LISTINGS_ALL_ITTERATIONS
----where Update_Timestamp >= '2018-01-23 01:43:30.790'
--Group by Update_Timestamp
--Order by Update_Timestamp desc

--Select count(*) From [_Listings_TO_PULL]

--Delete from [_Listings_TO_PULL]
--From [_Listings_TO_PULL] as A join (Select distinct Listing_Tracking_ID from _LISTINGS_DAILY_BATCH_ALL_ITTERATIONS) as B on 
--A.Listing_ID = B.Listing_Tracking_ID

--Select count(*) From [_Listings_TO_PULL]


TRUNCATE table [_Listings_TO_PULL]

DECLARE @STARTDATE datetime
SET @STARTDATE = (Select MAX_UPDATETIMESTAMP+.00001 from [Listing].[dbo].[LISTING_TRACKING] with(NOLOCK) where CUSTOMER = 'DAILY_BATCH_ALL_ITTERATIONS' and DATA_TYPE = 'Listing')
--Set @STARTDATE = '2018-06-28 10:31:29.630'


--Select max([Update_Timestamp]), count(*) from _LISTINGS_ALL_ITTERATIONS
--Group by [Update_Timestamp]
--Order by max([Update_Timestamp]) desc

--Delete from [_LISTINGS_ALL_ITTERATIONS]
--where [Update_Timestamp] > '2018-06-28 10:30:29.630'


Select * From [Listing].[dbo].[_Listings_TO_PULL]

Insert into [Listing].[dbo].[_Listings_TO_PULL](Listing_ID)
--Select DISTINCT LISTING_ID  
--From FA_Listing.dbo.ListingHistory with(NOLOCK)
--where UpdateTimestamp >= @STARTDATE
--ORder by LISTING_ID
Select DISTINCT A.LISTING_ID From [FA_Listing].[dbo].[ListingHistory] as A with(NOLOCK)
join [FA_Listing].[dbo].[ListingChange] as B with(NOLOCK) on A.Listing_ID = B.Listing_ID and A.UPDATE_FLAG_DATE_STD = B.ChangeDate
join [FA_Listing].[dbo].[Listing] as C with(NOLOCK) on A.Listing_ID = C.Listing_ID
join [Listing].[dbo].[County] as D with(NOLOCK) on Right(('0' + (convert(varchar(5),C.FIPS))),5) = D.FIPSCODE
where 
 A.UpdateTimestamp > @STARTDATE
 AND B.FIELDID in (1,10 ,104 ,105 ,106 ,107 ,11 ,111 ,18 ,19 ,2 ,20 ,21 ,22 ,23 ,26 ,27 ,28 ,29 ,3 ,31 ,32 ,35 	
,36 ,38 ,39 ,4 ,40 ,43 ,44 ,45 ,46 ,48 ,5 ,52 ,53 ,55 ,56 ,58 ,59 ,6 ,60 ,61 ,62 ,64 ,67 	
,68 ,69 ,7 ,70 ,71 ,72 ,74 ,8 ,88 ,89 ,9 ,93 )
------REMOVE WI----
----------------20190131 - REMOVED WI RESTRICTION PER BR-----------
--AND C.FIPS not like '55%'
Order by A.LISTING_ID







--Insert into [_Listings_TO_PULL](Listing_ID)
----Select DISTINCT LISTING_ID  
----From FA_Listing.dbo.ListingHistory with(NOLOCK)
----where UpdateTimestamp >= @STARTDATE
----ORder by LISTING_ID
--Select top 30000 * from 
--(Select DISTINCT A.LISTING_ID From FA_Listing.dbo.Listing as A with(NOLOCK)
--join Listing.dbo.County as D with(NOLOCK) on Right(('0' + (convert(varchar(5),A.FIPS))),5) = D.FIPSCODE
--left outer join FA_Listing.dbo.ListingChange as B with(NOLOCK) on A.Listing_ID = B.Listing_ID 
--left outer join [_Listings_TO_PULL] as PULL on A.Listing_ID = Pull.Listing_ID
--left outer join Listing.dbo._LISTINGS_ALL_ITTERATIONS as E with(NOLOCK) on A.Listing_ID = E.Listing_Tracking_ID
--where 
-- --A.UpdateTimestamp > @STARTDATE
----AND 
--B.Listing_ID is null
--AND Pull.Listing_ID is null
--and E.Listing_Tracking_ID is null
--and A.MLS_STATUS_STD not like 'Fail')A


--Insert into [_Listings_TO_PULL](Listing_ID)
----Select DISTINCT LISTING_ID  
----From FA_Listing.dbo.ListingHistory with(NOLOCK)
----where UpdateTimestamp >= @STARTDATE
----ORder by LISTING_ID
--Select top 2000 * from 
--(Select DISTINCT A.LISTING_ID From FA_Listing.dbo.Listing as A with(NOLOCK)
--join Listing.dbo.County as D with(NOLOCK) on Right(('0' + (convert(varchar(5),A.FIPS))),5) = D.FIPSCODE
--left outer join FA_Listing.dbo.ListingChange as B with(NOLOCK) on A.Listing_ID = B.Listing_ID 
--left outer join [_Listings_TO_PULL] as PULL on A.Listing_ID = Pull.Listing_ID
--left outer join Listing.dbo._LISTINGS_ALL_ITTERATIONS as E with(NOLOCK) on A.Listing_ID = E.Listing_Tracking_ID
--where 
-- --A.UpdateTimestamp > @STARTDATE
----AND 
--B.Listing_ID is null
--AND Pull.Listing_ID is null
--and E.Listing_Tracking_ID is null
--and A.MLS_STATUS_STD  like 'Fail')A


--EXEC Listing.dbo._Listing_Catchup



Truncate table [Listing].[dbo].[CHECK_MAX_SEQ]



Insert into [Listing].[dbo].[CHECK_MAX_SEQ](Listing_Tracking_ID, MAXSEQ,CURR_SEQ,[STATUS_CURR])
Select Listing_Tracking_ID, max(A.UPdateSeq) as MAXSEQ 
,B.UpdateSeq, B.MLS_STATUS_STD
From [Listing].[dbo].[_LISTINGS_ALL_ITTERATIONS]  as A with(NOLOCK)
join  [FA_Listing].[dbo].[Listing] as B with(NOLOCK) on A.Listing_Tracking_ID = B.Listing_ID
where Add_Change_Delete_Indicator not like 'D' 
--and B.MLS_STATUS_STD <>  A.status 
and B.PROVIDER_TYPE like 'FMA'
Group by Listing_Tracking_ID,B.UpdateSeq, B.MLS_STATUS_STD


Update [Listing].[dbo].[A]
Set A.[STATUS] = B.Status
From [Listing].[dbo].[CHECK_MAX_SEQ] as A join 
[Listing].[dbo].[_LISTINGS_ALL_ITTERATIONS]  as B with(NOLOCK) on A.Listing_Tracking_ID = B.Listing_Tracking_ID
and A.MAXSEQ = B.UpdateSeq



--Update A
--Set A.Curr_SEQ = B.UpdateSeq
----Select count(*)
--From Listing.dbo.CHECK_MAX_SEQ as A with(NOLOCK)
--join  FA_Listing.dbo.Listing as B with(NOLOCK) on A.Listing_Tracking_ID = B.Listing_ID
--where A.MAXSEQ < B.UPdateSeq
--and B.Updated < Getdate()-3
--AND ISNULL(B.Provider_Type,'') not like 'ALTOS'


Truncate table [_Listings_TO_PULL_MISSING]
Insert into [Listing].[dbo].[_Listings_TO_PULL_MISSING](Listing_ID,Curr_SEQ)
Select top 60000 Listing_Tracking_ID, Curr_Seq 
From [Listing].[dbo].[CHECK_MAX_SEQ] as A with(NOLOCK)
--join  FA_Listing.dbo.Listing as B with(NOLOCK) on A.Listing_Tracking_ID = B.Listing_ID
where MAXSEQ < Curr_SEQ
and MAXSEQ is not null
and [STATUS] <> [STATUS_CURR]
Order by Listing_Tracking_ID


--Select count(*) From Listing.dbo.CHECK_MAX_SEQ
--where MAXSEQ < Curr_SEQ
--and MAXSEQ is not null


--Select * From Listing.dbo.CHECK_MAX_SEQ
--where MAXSEQ < Curr_SEQ
--and MAXSEQ is not null
--Order by Listing_Tracking_ID





--Select DISTINCT LISTING_ID  
--From FA_Listing.dbo.Listing with(NOLOCK)
--where UPDATE_FLAG_DATE_STD >= @STARTDATE
--ORder by LISTING_ID


				
				

				--DECLARE @body NVARCHAR(MAX)
				--DECLARE @Subject NVARCHAR(MAX)
				--DECLARE @DATE VARCHAR(10)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				--DECLARE @tab char(1) = CHAR(9)

				DECLARE @TIME VARCHAR(40)
				DECLARE @MAXDATE_CHECK VARCHAR(40)
				--DECLARE @tab char(1) = CHAR(9)
				--DECLARE @query_attachment_filename NVARCHAR(MAX)
				DECLARE @Ticket NVARCHAR(MAX)
				DECLARE @RECORDSTOPULL BIGINT
				Set @RECORDSTOPULL = (SELECT count(*) FROM [Listing].[dbo].[_Listings_TO_PULL] with(NOLOCK))
				Set @Date = Convert(varchar(10),Getdate(),112)
				Set @TIME = CONVERT(varchar(20),getdate(),112) + '_' + REPLACE(CONVERT(varchar(5),getdate(),108),':','')
				Set @Subject = 'LISTING_Daily_Batch_Process_ALL_ITTERATIONS_RecordsToPull - ' + @Date + ' - ' + convert(varchar(250),@RECORDSTOPULL)
				
				-----------sp_send_dbmail example-------------
				EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
				@query =  NULL,
				@body = NULL,
				@body_format ='HTML',
				--@recipients = 'klowe@firstam.com;MicSmith@firstam.com;jeschmeyer@firstam.com',
				@recipients = 'klowe@firstam.com',
				@subject = @subject,
				@attach_query_result_as_file = 0,
				@query_attachment_filename = @query_attachment_filename,
				@query_result_separator=@tab,
				@query_result_no_padding=1
						;

--Select count(*) From [_Listings_TO_PULL]

--Delete from [_Listings_TO_PULL]
--From [_Listings_TO_PULL] as A join (Select distinct Listing_Tracking_ID from _LISTINGS_DAILY_BATCH_ALL_ITTERATIONS) as B on 
--A.Listing_ID = B.Listing_Tracking_ID

--Select count(*) From [_Listings_TO_PULL]


--DECLARE @STARTDATE datetime
--SET @STARTDATE = (Select MAX_UPDATETIMESTAMP+.00001 from Listing.dbo.[LISTING_TRACKING] with(NOLOCK) where CUSTOMER = 'DAILY_BATCH_ALL_ITTERATIONS' and DATA_TYPE = 'Listing')
--Set @STARTDATE = '2018-05-30 03:19:09.880'

DECLARE @ENDDATE datetime
Set @ENDDATE = (Select max([Update_Timestamp]) from [Listing].[dbo].[_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS])

--DECLARE @COUNTY varchar(5)
--DECLARE @LISTING bigint

--DECLARE db_LISTINGRUN CURSOR FOR  
----Select DISTINCT LISTING_ID  
----From FA_Listing.dbo.ListingHistory with(NOLOCK)
----where UpdateTimestamp >= @STARTDATE
----ORder by LISTING_ID

--Select DISTINCT Listing_ID from [_Listings_TO_PULL] with(NOLOCK)
--Order by Listing_ID

----Insert into [_Listings_TO_PULL](Listing_ID)
----Select DISTINCT LISTING_ID  
----From FA_Listing.dbo.ListingHistory with(NOLOCK)
----where UpdateTimestamp >= '2017-10-05 04:07:35.487'
----ORder by LISTING_ID

----Select FIPSCODE from County with(NOLOCK)
----Order by FIPSCODE

----Delete from [_Listings_TO_PULL]
----where Listing_ID in (Select distinct Listing_Tracking_ID from [_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS])


  
--OPEN db_LISTINGRUN   
--FETCH NEXT FROM db_LISTINGRUN INTO @LISTING

--WHILE @@FETCH_STATUS = 0   
--	BEGIN   
       
--Print @LISTING


--EXEC('

--Insert into [_LISTINGS_DAILY_BATCH_ALL_ITTERATIONS]([Property_Address]
--      ,[StreetNum]
--      ,[Direction]
--      ,[Street_Name]
--      ,[Street_Type]
--      ,[Post_Direction]
--      ,[Unit]
--      ,[Property_City]
--      ,[Property_State]
--      ,[Property_Zip]
--      ,[Property_Zip_PLUS_4]
--      ,[Assessors_Parcel_Identification_Number]
--      ,[County_FIPS]
--      ,[Internal_FA_Property_Ref_ID]
--      ,[Property_Type]
--      ,[Property_SubType]
--      ,[Lot_Size_Sq_Ft]
--      ,[Home_Size]
--      ,[Home_or_Building_Style]
--      ,[Heating_Type]
--      ,[Heating_Fuel_Type]
--      ,[Cooling_Type]
--      ,[Cooling_Fuel_Type]
--      ,[Number_of_Stories]
--      ,[Year_Built]
--      ,[Roof_Type]
--      ,[Exterior_Construction]
--      ,[Number_of_Bedrooms]
--      ,[Number_of_Bathrooms]
--      ,[Number_of_Garages]
--      ,[Garage_Type]
--      ,[Pool_Features]
--      ,[View_Features]
--      ,[Price_per_Square_Feet]
--      ,[Porch]
--      ,[Patio]
--      ,[Deck]
--      ,[Basement]
--      ,[Air_Conditioner]
--      ,[Number_of_Fireplaces]
--      ,[Presence_of_Fireplace]
--      ,[Fireplace_Description]
--      ,[Interior_Features]
--      ,[Exterior_Features]
--      ,[Existing_Structures]
--      ,[Property_Details]
--      ,[Lot_Features]
--      ,[Zoning]
--      ,[Neighborhood]
--      ,[School_District]
--      ,[Elementary_School]
--      ,[Middle_School]
--      ,[High_School]
--      ,[Appliances]
--      ,[Approximate_Lot_Dimensions]
--      ,[Topogrophy]
--      ,[Waterfront_Features]
--      ,[Water]
--      ,[Water_Source]
--      ,[Water_Amenities]
--      ,[Water_Access]
--      ,[Water_Heater]
--      ,[FA_Initial_List_Date]
--      ,[FA_Calculated_Days_on_Market]
--      ,[Current_Original_Listing_Date]
--      ,[Initial_List_Status]
--      ,[Listing_Number]
--      ,[Status]
--      ,[Status_Sub_Type]
--      ,[Rental_Indicator]
--      ,[Current_Listing_Price]
--      ,[Max_List_Price]
--      ,[Max_List_Price_Date]
--      ,[Min_List_Price]
--      ,[Min_List_Price_Date]
--      ,[Sold_Price]
--      ,[Sold_Date]
--      ,[FA_Adjusted_Sold_Price]
--      ,[FA_Sold_Price_Range]
--      ,[Last_Listing_Price_Change_Amount]
--      ,[Last_Listing_Price_Change_Date]
--      ,[Prior_Listing_Price_Change_Amount]
--      ,[Prior_Listing_Price_Change_Date]
--      ,[Last_Listing_Status_Change]
--      ,[Last_Listing_Status_Change_Date]
--      ,[Last_Listing_Status_Sub_Type_Change]
--      ,[Last_Listing_Status_Sub_Type_Change_Date]
--      ,[Prior_Listing_Status_Change]
--      ,[Prior_Listing_Status_Change_Date]
--      ,[Prior_Listing_Status_Sub_Type_Change]
--      ,[Prior_Listing_Status_Sub_Type_Change_Date]
--      ,[Listing_Tracking_ID]
--      ,[FA_Unique_Listing_Identifier_Ref_ID]
--      ,[Update_Timestamp]
--      ,[Add_Change_Delete_Indicator]
--      ,[Listing_Agent_License_Number]
--      ,[Listing_Agent_Name]
--      ,[Listing_Agent_Address]
--      ,[Listing_Agent_Phone]
--      ,[Listing_Agent_Email]
--      ,[Office_Name]
--      ,[Office_Address]
--      ,[Office_Phone]
--      ,[Office_Email]
--      ,[RAW_House_Number]
--      ,[RAW_Street]
--      ,[RAW_City]
--      ,[RAW_State]
--      ,[RAW_ZIP]
--      ,[RAW_County_Name]
--	   ,[Street_Name_Post]
--      ,[FA_POSTDATE]
--      ,[LIST_OFFICE_CODE]
--      ,[LIST_AGENT_CODE]
--      ,[UpdateFlagDateSTD]
--      ,[UpdateSeq]
--      ,[APN_LISTING_DATA]
--      ,[FIPS]
--      ,[Current_Listing_Ind]
--      ,[Current_Rental_Ind]
--      ,[FIELDLIST])
--	  Select 
--	  [Property Address]
--	  ,RTRIM(ISNULL(LTRIM(Substring(addr.HouseNumber,1,LEN(addr.HouseNumber))),''''))
--	  ,RTRIM(ISNULL(LTRIM(Substring(addr.Direction,1,LEN(addr.Direction))),''''))
--	  ,RTRIM(ISNULL(LTRIM(Substring(addr.Street_Name,1,LEN(addr.Street_Name))),''''))
--	  ,RTRIM(ISNULL(LTRIM(Substring(addr.Street_Type,1,LEN(addr.Street_Type))),''''))
--	  ,RTRIM(ISNULL(LTRIM(Substring(addr.Post_Direction,1,LEN(addr.Post_Direction))),''''))
--      ,RTRIM(ISNULL(LTRIM(Substring(addr.Unit,1,LEN(addr.Unit))),''''))
--	  ,[Property City]
--      ,[Property State]
--      ,[Property Zip]
--      ,[Property Zip + 4]
--      ,[Assessor''s Parcel Identification Number]
--      ,RIGHT(''0'' + convert(varchar(5),A.[County FIPS]),5)
--      ,[Internal FA Property Ref ID]
--      ,[Property Type]
--      ,[Property Sub-Type]
--      ,[Lot Size (Sq Ft)]
--      ,[Home Size]
--      ,[Home or Building Style]
--      ,[Heating Type]
--      ,[Heating Fuel Type]
--      ,[Cooling Type]
--      ,[Cooling Fuel Type]
--      ,[Number of Stories]
--      ,[Year Built]
--      ,[Roof Type]
--      ,[Exterior Construction]
--      ,[Number of Bedrooms]
--      ,[Number of Bathrooms]
--      ,[Number of Garages]
--      ,[Garage Type]
--      ,[Pool Features]
--      ,[View Features]
--      ,[Price per Square Feet]
--      ,[Porch]
--      ,[Patio]
--      ,[Deck]
--      ,[Basement]
--      ,[Air Conditioner]
--      ,[Number of Fireplaces]
--      ,[Presence of Fireplace]
--      ,[Fireplace Description]
--      ,[Interior Features]
--      ,[Exterior Features]
--      ,[Existing Structures]
--      --,[Property Details]
--	  	  ,Case when RIGHT(''0'' + convert(varchar(5),A.[County FIPS]),5) in (''11001'',''10001'',''10003'',''10005'',''24001'',''24003'',''24510'',''24005'',''24009'',''24011'',''24013'',''24015'',''24017'',''24019'',''24021'',''24023'',
--	''24025'',''24027'',''24029'',''24031'',''24033'',''24035'',''24039'',''24037'',''24041'',''24043'',''24045'',''24047'',''34005'',''34007'',''34011'',''34015'',''34021'',''34033'',''42001'',
--	''42011'',''42017'',''42029'',''42041'',''42043'',''42045'',''42055'',''42057'',''42071'',''42075'',''42091'',''42099'',''42101'',''42107'',''42133'',''51510'',''51013'',''51033'',''51043'',''51047'',
--	''51600'',''51059'',''51610'',''51061'',''51069'',''51630'',''51099'',''51107'',''51113'',''51683'',''51685'',''51137'',''51139'',''51153'',''51157'',''51171'',''51177'',''51179'',''51187'',
--	''54003'',''54023'',''54027'',''54031'',''54037'',''54057'',''54065'',''54071'')
--	then NULL else [Property Details] end

--      ,[Lot Features]
--      ,[Zoning]
--      ,[Neighborhood]
--      ,[School District]
--      ,[Elementary School]
--      ,[Middle School]
--      ,[High School]
--      ,[Appliances]
--      ,[Approximate Lot Dimensions]
--      ,[Topogrophy]
--      ,[Waterfront Features]
--      ,[Water]
--      ,[Water Source]
--      ,[Water Amenities]
--      ,[Water Access]
--      ,[Water Heater]
--      ,[FA Initial List Date]
--      ,[FA Calculated Days on Market]
--      ,[Current Original Listing Date]
--      ,[Initial List Status]
--      ,[Listing Number]
--      ,[Status]
--      ,[Status Sub Type]
--      ,[Rental Indicator]
--      ,[Current Listing Price]
--      ,[Max List Price]
--      ,[Max List Price Date]
--      ,[Min List Price]
--      ,[Min List Price Date]
--      ,[Sold Price]
--      ,[Sold Date]
--      ,[FA Adjusted Sold Price]
--      ,[FA Sold Price Range]
--      ,[Last Listing Price Change Amount]
--      ,[Last Listing Price Change Date]
--      ,[Prior Listing Price Change Amount]
--      ,[Prior Listing Price Change Date]
--      ,[Last Listing Status Change]
--      ,[Last Listing Status Change Date]
--      ,[Last Listing Status Sub Type Change]
--      ,[Last Listing Status Sub Type Change Date]
--      ,[Prior Listing Status Change]
--      ,[Prior Listing Status Change Date]
--      ,[Prior Listing Status Sub Type Change]
--      ,[Prior Listing Status Sub Type Change Date]
--      ,[Listing Tracking ID]
--      ,[FA Unique Listing Identifier - Ref ID]
--      ,[Update Timestamp]
--      ,[Add, Change, Delete Indicator]
--      ,[Listing Agent License Number]
--      ,[Listing Agent Name]
--      ,[Listing Agent Address]
--      ,[Listing Agent Phone]
--      ,left([Listing Agent Email],50)
--      ,[Office Name]
--      ,[Office Address]
--      ,[Office Phone]
--      ,[Office Email]
--	  ,B.[House_NBR]
--	  ,B.[Street]
--      ,B.[City]
--      ,B.[State]
--      ,B.[ZIP]
--      ,B.[County_Name]
--	  ,B.[Street]
--  	  ,Getdate()
--	  ,[LIST_OFFICE_CODE]
--	  ,[LIST_AGENT_CODE]
--	  ,A.UPDATE_FLAG_DATE_STD
--	  ,A.UpdateSeq
--	  ,[Assessor''s Parcel Identification Number]
--	  ,RIGHT(''0'' + convert(varchar(5),A.[County FIPS]),5)
--	  ,B.[Current_Listing_Ind]
--	  ,B.[Current_Rental_Ind]
--	  ,LFLD.FIELDLIST
	 

--	FROM Listing.dbo.vBulk_Current_Listing_NEW_Timestamp_DATETIME_ALL_CHANGES as A with(NOLOCK) 
--		CROSS APPLY (
--		SELECT COUNT(*) AS ChangeCount
--		FROM FA_Listing.dbo.ListingChange lc with(NOLOCK)
--		WHERE lc.Listing_ID = A.[Listing Tracking ID]
--			AND lc.ChangeDate = A.UPDATE_FLAG_DATE_STD
--			--AND lc.FieldId IN (
--				--22)
--			) lc
--		CROSS APPLY (
--		SELECT STUFF((SELECT '','' + cast(FieldID as varchar) 
--		FROM FA_Listing.dbo.listingchange as LC2 with(NOLOCK)
--		where LC2.Listing_ID = A.[Listing Tracking ID]
--		and LC2.ChangeDate = A.UPDATE_FLAG_DATE_STD
--		FOR XML PATH('''')) ,1,1,'''') AS FIELDLIST
--			) LFLD
--	join FA_Listing.dbo.Listing as B with(NOLOCK)
--	on A.[Listing Tracking ID] = B.Listing_ID

--	LEFT JOIN FA_Listing.dbo.FA_MLS_Raw_Std_Address  addr with(NOLOCK) ON addr.Row_Id = B.AddrId AND addr.Addr_type = ''S''

--		WHERE  (A.UpdateSeq = 1	OR ChangeCount > 0)
--	and [Update Timestamp] >= '''+ @STARTDATE + '''
--	--and [Update Timestamp] <= '''+ @ENDDATE + '''
--	and A.[Listing Tracking ID] = ''' + @LISTING + '''
--	and Right((''0'' + (convert(varchar(5),A.[County FIPS]))),5)  in (Select FIPSCODE from County with(NOLOCK))
--	--and Right((''0'' + (convert(varchar(5),A.[County FIPS]))),5) = ''' + @COUNTY + '''
--	and LEFT(Right((''0'' + (convert(varchar(5),A.[County FIPS]))),5),2) not like ''55'' 


--	AND A.[Office Address] not like ''% WI %''
--   AND A.[Listing Agent Address] not like ''% WI %''

	
--')

-- FETCH NEXT FROM db_LISTINGRUN INTO  @LISTING
--	END   

--CLOSE db_LISTINGRUN   
--DEALLOCATE db_LISTINGRUN



END





