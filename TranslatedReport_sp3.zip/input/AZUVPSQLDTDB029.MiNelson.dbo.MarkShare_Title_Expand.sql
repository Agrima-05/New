/* Source: AZUVPSQLDTDB029.datatree.local | MiNelson | dbo.MarkShare_Title_Expand | type=P */






-- ===============================================================================================
-- Author:		My Phan
-- Create date: 3/22/2021
-- Description:	Create MarkShareTitle_Expand
-- ================================================================================================

CREATE PROCEDURE [MiNelson].[dbo].[MarkShare_Title_Expand]
                
AS 


SET NOCOUNT ON

BEGIN
 



/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp1]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp1]


select
	DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE,
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
       MTG1_PRIVATE_PARTY_LENDER,
       SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Sales_Source_Ind,
	   REF_ID,
       RECORDING_DATE,
       SALE_DATe, 
        UPDATED,
        Ass_ZipCode,
        Year_Built
       ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
   into [MiNelson].[dbo].[MarketShareTitle_Temp1]
from (

      SELECT
       1 as DeedSequence,
            case when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' -- Added 4/01/2015 
                           when (REO_SALE_FLAG = 1 Or REO_SALE = 'Y') and deed.TRANSACTION_TYPE != 4 then    -- Added "Cash Sale" split 2/27/2015 -- Added REO_Sale ='Y' 4/13/15
                                         case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0) 
										-- and mc.Fips is not Null 
										 then 'REO - Cash Sale' else 'REO' end
                           when MTG1_EQUITY_FLAG = 'Y' then 'Home Equity'
                           when MTG1_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
                                    else
                        case deed.TRANSACTION_TYPE 
                              when '1' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)  
									--and mc.Fips is not Null 
									then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '2' then 'Refinance'
                              when '3' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)  
									--and mc.Fips is not Null 
									then 'Subdivision/Newhome - Cash Sale'
                                    else 'Subdivision/Newhome'
                                    end
                              when '4' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)  
								--	and mc.Fips is not Null 
									then 'Timeshare - Cash Sale'
                                    else 'Timeshare'
                                    end
                              when '6' then 'Construction Loan'
                              when '7' then 
                                    case when (deed.MTG1_MTG_AMOUNT is Null or deed.MTG1_MTG_AMOUNT = 0)  
									--and mc.Fips is not Null 
									then 'Resale - Cash Sale'
                                    else 'Resale'
                                    end
                              when '9' then 'Refinance'
                              else ''
                        end
                  end as [Transaction Type],
            --isnull(deed.MTG1_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			case when (deed.MTG1_LENDER_LAST_NAME is null or deed.MTG1_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG1_LENDER_LAST_NAME end as [Lender],
     case when (deed.TITLE_COMPANY_NAME  is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
     
            'UNKNOWN' as [Attorney],
            MTG1_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                         isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                          case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN, deed.DeedId) as [rn],               -- Corrected problem with row_number 3/09/15----- 4/14 Add DeedID
              case when (deed.us_state = 'IN' and deed.source_type = 'M' and deed.Doc_nbr is null) then left(UR_REMARKS,20) else deed.doc_nbr end   as [Sale Document number], 
            deed.MTG1_DOC_NBR as [MGT Document number],
              deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
       --     (deed.MTG1_RECORDING_BOOK + '/' + deed.MTG1_RECORDING_PAGE) as 'Book/Page', -- change 7/6/2015 make unique keys
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change 7/6/2015 make unique keys
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG1_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG1_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG1_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
           -- case when deed.US_STATE = 'KS' ---------adding 4/29/15 ----------take out 5/4/15
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG1_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG1_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null then 'YES'   -- Added 2/20/2015
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
            case when deed.MTG1_MTG_LOAN_TYPE_CODE = 'CNV' then
                  case 
                        when NBR_OF_RES_UNITS = 1 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        when NBR_OF_RES_UNITS = 2 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
                        when NBR_OF_RES_UNITS = 3 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
                        when NBR_OF_RES_UNITS = 4 and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
                        when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                              and deed.MTG1_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        else 'NO'
                  end
                  else 'NO'
            end as [Conforming],
            case when TRANSACTION_TYPE = '3' then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = '9' then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
            isnull(deed.SITUS_CITY,'') as [City],
            deed.US_COUNTY as [County],
            deed.US_STATE as [State],
            isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       deed.TITLE_COMPANY_CODE,
       --MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND ,
       Deed.MTG1_PRIVATE_PARTY_LENDER,
       Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
	   Deed.Sales_Source_Ind,      ---------------------change 2/4/2016 to filter AZ affidavits
       Deed.REF_ID,	               ---------------------Added for update Attorney names 3/14/2016
       deed.RECORDING_DATE,
       deed.SALE_DATe,
       deed.UPDATED,
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
       assr.Year_Built  -----------------------------Added YearBuilt for HI fix
         ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      FROM 
            [Deed].[dbo].[vDeed] deed with (Nolock)left outer join [Assr].[dbo].[Assr] assr with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  -----------9/8/15 change to use ref_id to join
                deed.REF_ID = assr.REF_ID
                             -- inner join [MiNelson].[mktshr].[ConformingLimits] cnf with (Nolock) on
                  --deed.FIPS = cnf.fips
				    left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm  with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where
	--  deed.Source_Type in ( 'E' , 'M')and  
deed.fips in ( select fips from [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver_Bulk_expand])
	
  --and StartDate_UR is not null --- using control table
   and
            deed.DETAILED_DOC_TYPE not in ('MO','RD') --, 'TE') -- Added back the 'TE' records on 4/06/15
        --  and (deed.FIPS  between 56001 and 56999)
   --      and deed.US_STATE = 'ME'
  and isnull(deed.RECORDING_DATE,deed.SALE_DATE) >= '2025-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
            and (MULTI_APN != 'D' or MULTI_APN is Null)
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9') -- Added TransType=9 on 4/07/15
    and  (deed.DeedID > (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID]
								where rundate !=  CONVERT(varchar(10), GETDATE(),112)
							)
		or 
		CONVERT(varchar(10), deed.updated ,112) >=  (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID]
								where rundate < (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])	))
	
	)x
where
      rn = 1
--order by
--      [Sale Document number]


------------------

/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp2]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp2]
      
-------------------------
-- Create 2nd mgt table

select
DeedSequence,
      [Transaction Type],
      [Lender],
      [Title Company],
       TITLE_COMPANY_CODE,
      [Attorney],
      [Sale Document number],
      [MGT Document number],
      [Book/Page],
      [Sales Price],
      [Loan Amount],
      [Loan To Value],
      [Date],
      [Adjustable Rate],
      [Loan Type],
      [Reverse Mortgage],
      [Conforming],
      [Builder],
      [Seller Name],
      [Buyer],
      [Residential],
      [Corporate],
      [City],
      [County],
      [State],
      [Zip Code],
      [FIPS],
      [Census Tract #],
      [Property Type]

       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
        DEED_TYPE,
       FORCLOSURE, 
       RESALE_NEW_CONSTRUCTION,
       MULTI_APN,
       DeedID,
       BYR1_CORP_IND,
       [CHECK] as NBR_OF_RES_UNITS,
        MTG1_PRIVATE_PARTY_LENDER,
        SELLER_NAME_PLAINTIFF1_CORP_IND,
		sales_source_ind,
		REF_ID,
       RECORDING_DATE,
       SALE_DATe,
       UPDATED,
       Ass_ZipCode,
       Year_Built   ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
   
   into [MiNelson].[dbo].[MarketShareTitle_Temp2]
from (
  SELECT
       
     2 as DeedSequence,
            --case 
            ----when REO_SALE_FLAG = 1 then    -- Added "Cash Sale" split 2/27/2015
            ----                        case when deed.MTG1_MTG_AMOUNT is Null and mc.Fips is not Null then 'REO - Cash Sale'
            ----                        else 'REO'
            ----                        end
            --      when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity'
            --      when MTG2_OTHER_SUBORDINATE_LOANS = 'Y' then 'Other Subordinate Loan'   -- Added 2/19/2015
            --      else
            --            case deed.TRANSACTION_TYPE 
            --                  when 1 then 'Resale'
            --                  when 2 then 'Refinance'
            --                  when 3 then 'Subdivision/Newhome'
            --                  when 4 then 'Timeshare'
            --                  when 6 then 'Construction Loan'
            --                  when 7 then 'Resale'
            --                  when 9 then 'Refinance'
            --                  else ''
            --            end
            --      end as [Transaction Type],
            case when MTG2_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                           when MTG1_CONSTRUCTION_LOAN = 'Y' then 'Construction Loan' --- Added 4/1/2015
                            when MTG2_EQUITY_FLAG = 'Y' then 'Home Equity' ---------Added 4/23/15
                           else 'Other Subordinate Loan' end as [Transaction Type],  --- changed 4/1/2015
            --isnull(deed.MTG2_LENDER_LAST_NAME,'UNKNOWN') as [Lender],
            --isnull(deed.TITLE_COMPANY_NAME,'UNKNOWN') as [Title Company],
			 case when (deed.MTG2_LENDER_LAST_NAME is null or deed.MTG2_LENDER_LAST_NAME = '') then 'UNKNOWN' else deed.MTG2_LENDER_LAST_NAME end as [Lender],
     case when (deed.TITLE_COMPANY_NAME is null or deed.TITLE_COMPANY_NAME = '') then 'UNKNOWN' else deed.TITLE_COMPANY_NAME end as [Title Company],
  
         --and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and Deed.MTG1_LENDER_LAST_NAME is null)
       deed.TITLE_COMPANY_CODE,
            'UNKNOWN' as [Attorney],
            MTG2_EQUITY_FLAG,
            deed.MULTI_APN,  --
            --row_number() over(partition by deed.FIPS,deed.RECORDING_DATE,deed.DOC_NBR order by deed.MULTI_APN) as [rn],
            row_number() over(partition by deed.FIPS,
                                isnull(deed.RECORDING_DATE,deed.SALE_DATE),
                                case when isnull(deed.DOC_NBR, '')  <>'' then deed.DOC_NBR 
							else  (deed.Recording_Book + '/' + deed.Recording_Page) end
                              order by deed.MULTI_APN, deed.DeedId) as [rn],     -- Corrected problem with row_number 3/09/15--- 4/14 add DeedID
             case when (deed.us_state = 'IN' and deed.source_type = 'M' and deed.Doc_nbr is null) then left(UR_REMARKS,20) else deed.doc_nbr end   as [Sale Document number],
            deed.MTG2_DOC_NBR as [MGT Document number],
            deed.DETAILED_DOC_TYPE as [Detailed Doc Type],
         --   (deed.MTG2_RECORDING_BOOK + '/' + deed.MTG2_RECORDING_PAGE) as 'Book/Page', --change to make uique keys 7/06/2015
            (deed.Recording_Book + '/' + deed.Recording_Page) as 'Book/Page', -- change to make unique keys 7/6/2015
            isnull(deed.SALE_AMOUNT,0) as [Sales Price],    -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.SALE_AMOUNT,0) as money),-1) as [Sales Price],
            isnull(deed.MTG2_MTG_AMOUNT,0) as [Loan Amount],      -- Reformatted as currency 2/27/2015
            --'$'+convert(varchar(50), cast(isnull(deed.MTG1_MTG_AMOUNT,0) as money),-1) as [Loan Amount],
            case when deed.MTG2_MTG_AMOUNT is not Null and deed.SALE_AMOUNT is not Null and deed.SALE_AMOUNT != 0
                  then convert(varchar(15),round(convert(float,deed.MTG2_MTG_AMOUNT/deed.SALE_AMOUNT*100),2)) + '%'
                  else 'No Data'
            end as [Loan To Value],
            isnull(deed.RECORDING_DATE,deed.SALE_DATE) as [Date],
    --      case when deed.US_STATE = 'KS' 
				--then isnull(deed.SALE_DATE, deed.RECORDING_DATE)
				--else isnull(deed.RECORDING_DATE,deed.SALE_DATE) end as [Date],
            case when deed.MTG2_MTG_INTEREST_RATE_TYPE = 'ADJ' then 'YES'
                  else 'NO'
            end as [Adjustable Rate],
            --deed.MTG1_MTG_LOAN_TYPE_CODE,
            case deed.MTG2_MTG_LOAN_TYPE_CODE
                  when 'CNV' then 'Conventional'
                  when 'FHA' then 'FHA'
                  when 'VA' then 'VA'
                  else 'none'
            end as [Loan Type],
      --case when deed.DETAILED_DOC_TYPE = 'MG' then 'YES'  -- Old logic, replaced on 2/19/15
            case when rm.Fips is not Null then 'YES'   -- Added 2/20/2015
                  else 'NO'
            end as [Reverse Mortgage],
            --'Need table' as [Conforming],     -- <<<---  Need the conforming table            <<<<<<<<<<<<<<<<<<<<<<
                  NBR_OF_RES_UNITS as [check],
            case when deed.MTG2_MTG_LOAN_TYPE_CODE = 'CNV' then
                  case 
                        when NBR_OF_RES_UNITS = 1 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        when NBR_OF_RES_UNITS = 2 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  2] then 'YES'
                        when NBR_OF_RES_UNITS = 3 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  3] then 'YES'
                        when NBR_OF_RES_UNITS = 4 and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  4] then 'YES'
                        when (NBR_OF_RES_UNITS = 0 or NBR_OF_RES_UNITS is Null) 
                              and deed.MTG2_MTG_AMOUNT <= cnf.[NBR_OF_RES_UNITS  1 ] then 'YES'
                        else 'NO'
                  end
                  else 'NO'
            end as [Conforming],
            case when TRANSACTION_TYPE = 3 then deed.SELLER_NAME_PLAINTIFF_1
                  else 'UNKNOWN'
            end as [Builder],
            case when deed.TRANSACTION_TYPE = 9 then ''
                  else isnull(deed.SELLER_NAME_PLAINTIFF_1,'')
            end as [Seller Name],
            isnull(deed.BYR1_OWN_NAME,'') as [Buyer],
            case when assr.PROPERTY_INDICATOR in ('10','11','21') then 'YES'
                  else 'NO'
            end as [Residential],
            case when deed.BYR1_CORP_IND = 'Y' then 'YES'
                  else 'NO'
            end as [Corporate],
            isnull(deed.SITUS_CITY,'') as [City],
            deed.US_COUNTY as [County],
            deed.US_STATE as [State],
            isnull(left(deed.SITUS_ZIP_CODE,5),'') as [Zip Code],
            deed.FIPS as [FIPS],
            isnull(left(assr.CENSUS_TRACT,4),'') as [Census Tract #],
            case assr.PROPERTY_INDICATOR
                  when '10' then 'Single Family Residence'
                  when '11' then 'Condominium'
                  when '20' then 'Commercial'
                  when '21' then 'Duplex (Triplex, Quadplex)'
                  when '22' then 'Apartment'
                  when '23' then 'Hotel, Motel'
                  when '24' then 'Commercial Condominium'
                  when '25' then 'Retail'
                  when '26' then 'Service'
                  when '27' then 'Office Building'
                  when '28' then 'Warehouse'
                  when '29' then 'Financial Institution'
                  when '30' then 'Hospital (Medical Complex)'
                  when '31' then 'Parking'
                  when '32' then 'Amusement Recreation'
                  when '50' then 'Industrial'
                  when '51' then 'Industrial Light'
                  when '52' then 'Industrial Heavy'
                  when '53' then 'Transport'
                  when '54' then 'Utilities'
                  when '70' then 'Agricultural'
                  when '80' then 'Vacant'
                  when '90' then 'Exempt'
                  else 'Unknown'
            end as [Property Type]
       ,MTG1_CONSTRUCTION_LOAN,
       REO_SALE_FLAG,
       MTG1_EQUITY_FLAG,
       MTG1_OTHER_SUBORDINATE_LOANS,
       TRANSACTION_TYPE,
       DETAILED_DOC_TYPE,
       deed.DEED_TYPE,
       Deed.FORCLOSURE,
       Deed.RESALE_NEW_CONSTRUCTION,
       Deed.DeedID,
       Deed.BYR1_CORP_IND,
        Deed.MTG1_PRIVATE_PARTY_LENDER,
        Deed.SELLER_NAME_PLAINTIFF1_CORP_IND,
		Deed.Sales_Source_ind,
		Deed.REF_ID,
       deed.RECORDING_DATE,
       deed.SALE_DATe,
         deed.UPDATED, 
       assr.SITUS_ZIP_CODE as Ass_ZipCode, -----------Added for checking wrong zipcode
        assr.Year_Built ------------------------------Added yearBuilt for HI Fix
         ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
      FROM 
          [Deed].[dbo].[vDeed] deed with (Nolock) left outer join [Assr].[dbo].[Assr] assr  with (Nolock) on
                  deed.FIPS = assr.FIPS and
                --  deed.ORIGINAL_APN = assr.ORIGINAL_APN  ------------9/8/15 change to use Red_id
                 deed.REF_ID = assr.REF_ID
                              --inner join [MiNelson].[mktshr].[ConformingLimits] cnf with (Nolock) on
                --  deed.FIPS = cnf.fips
				  left outer join [MiNelson].[mktshr].[ConformingLimits_ByYear] cnf with (Nolock) on
                  deed.FIPS = cnf.fips and cast(left(cast(deed.RECORDING_DATE as varchar),4) as int)=cnf.Year
                              left outer join [MiNelson].[mktshr].[ReverseMortgage] rm with (Nolock) on
                  deed.Fips = rm.Fips and
                  deed.Ref_Id = rm.Ref_Id and
                  deed.DeedId = rm.DeedId
                              left outer join [MiNelson].[mktshr].[MtgCoverage] mc with (Nolock) on
                  deed.Fips = mc.Fips
      where --deed.Source_Type in ( 'E', 'M') and 

	deed.fips in ( select fips from [MiNelson].[mktshr].[TitleMarketShare_County_Source_CutOver_Bulk_expand])
	 and
            deed.DETAILED_DOC_TYPE not in ('MO','RD') --, 'TE') 
         --    and (deed.FIPS  between 56001 and 56999)
            --  and deed.US_STATE = 'ME'
    and isnull(deed.RECORDING_DATE,deed.SALE_DATE)  >= '2025-01-01'
            and (deed.MTG1_MTG_AMOUNT != 1 or deed.MTG1_MTG_AMOUNT is Null)   -- Exclude HUD Reverse Mortgages
            and (MULTI_APN != 'D' or MULTI_APN is Null)
            and not(deed.MTG1_MTG_AMOUNT is null and deed.SALE_AMOUNT is null and deed.TRANSACTION_TYPE = '9')
                 -- and not(Deed.TITLE_COMPANY_NAME is null and Deed.TITLE_COMPANY_CODE is null and deed.MTG2_LENDER_LAST_NAME is null)--4/17/15 take out take make filter for AZ
                  and (deed.MTG2_MTG_AMOUNT is not null and deed.MTG2_MTG_AMOUNT <> 0)
     and  (deed.DeedID > (SELECT Max([Max_DeedId])FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID]
								where rundate !=  CONVERT(varchar(10), GETDATE(),112)
							)
		or 
		CONVERT(varchar(10), deed.updated ,112) >=  (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID]
								where rundate < (SELECT CONVERT(varchar(10),max(rundate) ,112) FROM [MiNelson].[mktshr].[MarketShare_Title_MaxDeedID])	))
   )y
where
      rn = 1
--order by
--       [Sale Document number]


  
  /*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable]



from 
(   
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp1]
       union
       SELECT *
       FROM [MiNelson].[dbo].[MarketShareTitle_Temp2]
)x
ORDER BY
       [County],
       [Sale Document number]


	




-----------------
   -------HI Fix--------------------changed to all states 20171130
       
       update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome'
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select * from [Minelson].[mktshr].[Title_MarketShare_BuilderNames])
  --where State = 'HI' and [Transaction Type] = 'Resale' 
   --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from Minelson.mktshr.Title_MarketShare_HI_BuilerNames)


update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale'
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select * from [Minelson].[mktshr].[Title_MarketShare_BuilderNames])
  --where State = 'HI' and [Transaction Type] = 'Resale - Cash Sale' 
 --and   (cast ((left(CONVERT(varchar(10), recording_date,112),4)) as int) - cast (YEAR_BUILT as int)) <=2
  --and [Seller Name] in (select * from Minelson.mktshr.Title_MarketShare_HI_BuilerNames)

update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])


  update [MiNelson].[dbo].[t]
set t.[Transaction Type] = 'Subdivision/Newhome - Cash Sale', t.Builder=t.[Seller Name] 
--select *
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
  where [Transaction Type] = 'Resale - Cash Sale' 
  and [Seller Name] in (select builder from [MiNelson].[dbo].[WSL_BuilderClean_20250321])
  

-----
-------------------------------------------------------------
---- Filter records Resale_CashSale where it is REO

delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] = 'Resale - Cash Sale' and
  ( FORCLOSURE = 'Y' or DEED_TYPE = 'U')
  
  -------------------------------------
  
   -----------------------------------------------------------
  ------Filter cashsale records with no sale price in disclosure states
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where [Transaction Type] in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
  and [Sales Price] = 0 and State not in ('AZ','AK', 'ID', 'IN', 'KS', 'LA','ME','MS', 'MO', 'MT', 'NM', 'ND', 'TX', 'UT' ,'WY', 'HI')

  -----------------------------------------------------
  
  ------------------------------------------------------------------
  ----------------Update Transaction_Type = ''---------------------
  
  --select * from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  --where [Transaction Type] = '' 
  
  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Transaction Type] =
  (case 
	when [Transaction Type] = '' and [Sales Price] = 0 and [Loan Amount] <> 0 then 'Refinance'
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'M' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Resale - Cash Sale' else 'Resale' end
	When [Transaction Type] = '' and RESALE_NEW_CONSTRUCTION = 'N' 
		then case when [Sales Price] <> 0 and [Loan Amount] = 0 then 'Subdivision/Newhome - Cash Sale' else 'Subdivision/Newhome' end
   else [Transaction Type]
   end)
   
   ----------------------------------------
   
   
  -----------------------------------------------------------------
  -----------------Filter Title_company_code 400 for IL------------
  
  Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  TRANSACTION_TYPE =4 
  and (TITLE_COMPANY_CODE <> '00400' or TITLE_COMPANY_CODE is null)
  and state = 'IL'
  
  --  -----------------------------------------------------------------------------
  ----Filter unknown title, lender records for Non_AZ counties ------------------
  
  ---------------------------------------------taking this filter out 2/10/2025
 -- Delete
 ---- select count(*)
 -- FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 -- where  
 --           ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
 --           and State not in ('AZ','HI')

--Delete
--  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
--  where [Transaction Type] not in ('REO - Cash Sale', 'Resale - Cash Sale', 'Subdivision/Newhome - Cash Sale', 'Timeshare - Cash Sale')
--  and   ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')        
--  and State = 'NV'

  --Delete 
  --FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  --where  
  --          ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
  --          and State <> 'AZ'
  
   --Filter unknown title, lender records for AZ counties------------- --------- 
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  ([Title Company] = 'unknown' and TITLE_COMPANY_CODE is null and Lender = 'unknown')
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
  Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where  [Transaction Type] = 'Resale'
            and detailed_doc_type <> 'SW'
            and [Sales Price] = 0
            and State = 'AZ'
  
  
            ----------------------------------------------------------------------------------
  --Filter Timeshare when unknown Title for Timshare records in TX and AZ counties
  
          
             Delete 
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 -- where [Title Company] = 'unknown' and [transaction type]  = 'Timeshare' --- changed 4/23
 --            and (state = 'TX' or State = 'AZ')
  where [Title Company] = 'unknown' 
	and ([transaction type]  = 'Timeshare' or [Transaction Type]= 'Timeshare - Cash Sale' )
             and (state = 'TX' or State = 'AZ')
             
             
             Delete
  FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  where TRANSACTION_TYPE = 9
  and not ( [Sales Price] = 0 and [Loan Amount]is not null)
  
  alter table [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 Alter Column [Attorney] varchar(60)


  update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Attorney = [Title Company]
  where TITLE_COMPANY_CODE = '00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set [Title Company] = 'ATTORNEY ONLY'
  where TITLE_COMPANY_CODE ='00400'
  
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Property type] = 'unknown' and Corporate != 'YES'
   and state != 'NM'  ----- 10/16 take out NM state
   
 

----- Change Residential Indicator If LOAN_TYPE is FHA or VA and Residential indicator is NO and property type = vacant 
------then change the Residential indicator to YES  ---- 9/22/15

 update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
  where [loan Type] in( 'FHA', 'VA') and Residential = 'NO' and [property type] = 'vacant'
  
  
  -----------------------
  
  ----Change  When the Transaction type is Subdivision/Newhome or Subdivision/Newhome-Cash Sale ---> change Residential to Yes  --- 9/22/15

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] = 'vacant'

     update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
    where [Transaction Type] in ('Subdivision/Newhome', 'Subdivision/Newhome - Cash Sale') and Residential = 'NO'  and [Property Type] != 'vacant'

  ---------------------------
  
  ----Change If the Reverse Mortgage Indicator is ‘Y’ and Residential is NO --> change Residential to Y regardless of Property Type --- 9/22/15
 
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] = 'vacant'
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES', [Property Type] = 'Unknown'
   where [Reverse Mortgage] = 'YES' and Residential = 'NO' and [Property Type] != 'vacant'
  
  ----------------------
  
  
--  ---For these FIPS lets bypass the changes we put in on Friday:
--Dallas- 48113
--Hennepin-27053
--Philadelphia-42101
--Kern-6029
--Anchorage-2020
--Marion OH-39101
--St Clair IL-17163
--Shasta CA-6089
--Yakima WA-53077
--Erie OH-39043
--Spokane-53063
--Ramsey mn-27123

   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  set Residential = 'YES'
     where [Property type] in ('vacant' , 'agricultural') and Corporate != 'YES' and residential = 'No' 
   and [loan to value] != 'No data' and round(convert(float,[loan Amount]/[SALEs price]*100),2) > 20
and state not in ( 'TX', 'UT')



    update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'YES'
   where [Loan type] in  ('Conventional', 'VA', 'FHA') and [Property type] in ('vacant' , 'agricultural')
   and residential = 'No' and (state not in ( 'TX', 'UT') or fips = 48113)
   and fips not in (27053, 42101, 6029,2020,39101,17163,6089,53077,39043)

 
 
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
 where state not in ( 'TX', 'UT') 
  and residential = 'Yes' and corporate = 'Yes' 
 and [Sales price] = 0
  and [transaction type] = 'Construction Loan'
  and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
  
  
  
delete from  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   where state not in ( 'TX', 'UT') 
    and [transaction type] in ('Subdivision/NewHome', 'Subdivision/NewHome - Cash Sale', 'REO', 'REO-CASH SALE')
and [sales price] = 0 and [loan Amount] = 0
and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)

--------------------

  
  ----------------------
  
  ---- Change If the Transaction Type is TimeShare or TimeShare - Cash -> change Residential Indicator to NO  --- 9/22/15
   update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set Residential = 'NO'
    where [Transaction Type] in ('Timeshare', 'Timeshare - Cash Sale') and Residential = 'YES'
    and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
    
    
    ---------------------------
    ---, If the Transaction Type is Construction Loan and the Detailed Doc type is CL and Corp Indicator is Y then make Residential =NO 
---This will take the builders and Construction companies out of the Residential bucket

    
    update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
    set Residential = 'NO'
    where [Transaction Type] = 'Construction Loan' and DETAILED_DOC_TYPE = 'CL' and Corporate = 'YES' and Residential = 'YES'
   and fips not in (48113, 27053, 42101, 6029,2020,39101,17163,6089,53077,39043,53063,27123)
   
   --------------------------------
   
   
   
  ----I do have two changes to suggest, 1) for TX if Property type is Vacant and Buyer is corp change residential to NO 
  
  --select * from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
  --where [property type] = 'vacant' and Corporate = 'YES' and Residential = 'YES' and State = 'TX'
  
  ----and in IL if Property types is Apartment and number of residentiail units is less than 2 change to Condo
  ---- 10/15 add logic for IL
  
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set [Property Type] = 'Condominium', Residential = 'YES'
where [Property Type] = 'Apartment' and nbr_of_res_units <2
and State = 'IL'


 update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Condominium', Residential = 'YES'
 where [Property Type] = 'Apartment' and [Sales Price] < 300000 and [Transaction Type] in ('Resale', 'Resale - Cash Sale')
and State = 'IL'
  
   
   
 ---  If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’ and property type to single family
  --- For CA --- 10/20/2015
  
   update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
   set [Property Type] = 'Single Family Residence', Residential = 'YES'
where [Property Type] = 'vacant' and Residential = 'NO'
and MTG1_CONSTRUCTION_LOAN is null and state = 'CA'


--These changes are for Oregon: ----------10/20/2015
--1) If Property type is Agricultural and Corporate is ‘NO’ and MTG1_COMSTRUCTION_LOAN is null  change RESIDENTIAL to YES
--2) If the [Property Type] = 'vacant'  and Residential = 'no' and MTG1_CONSTRUCTION_LOAN is  null then change Residential to ‘YES’
--3) If Property type is Agricultural and NBR_OF_RES_UNITS is more than 0 change PROPERTY type to Single Family Residence and Residential =”YES’



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and Corporate = 'NO' and MTG1_CONSTRUCTION_LOAN is null
 
   
update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'YES'
where State = 'OR' and  [Property Type] = 'vacant'  and  Residential = 'NO'
 and MTG1_CONSTRUCTION_LOAN is null and Corporate = 'NO'



update [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'OR' and [Property Type] = 'Agricultural' and  Residential = 'NO'
and  nbr_of_res_units > 0 


--Here is one for PA  --- 10/21/15
--If Property type is “vacant’ and if sale price is greater than 10,000 change property type to ‘Single Family Residence’ change Residential to Yes

 
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
 set [Property Type] = 'Single Family Residence', Residential = 'YES'
where State = 'PA' and [Property Type] = 'vacant' and  Residential = 'NO'
and  [Sales Price] > 10000 

 --- Change for TX --- 10/22/2015
 --  If NBR_OF_RES_UNITS are null and Corporate Indicator is YES change and Residential is YES, change Residential to NO
   
    
update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where State = 'TX' and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units is null

--for 48113, If NBR_OF_RES_UNITS = 0 and Corporate Indicator is YES  and Residential is YES, change Residential to NO   --- 10/22/2015

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set Residential = 'NO'
where fips =48113 and Corporate = 'YES'  and  Residential = 'YES' and  nbr_of_res_units = 0


----Change for MI -- 10/27/2015
--- if Property type is vacant and Corp indicator is NO change Residential to YES
---- if Property type is Amusement Recreation change residentail to Yes

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'vacant' and  Residential = 'NO'
and Corporate = 'NO'

update  [MiNelson].[dbo].[TitleMarketShare_BaseTable]
set  Residential = 'YES'
where State = 'MI' and [Property Type] = 'Amusement Recreation' and  Residential = 'NO'



------------------------"Contruction loan" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT  distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Construction Loan'





------------------------"Home Equity" with Builder name is not unknown----------------------

update [MiNelson].[dbo].[t] 
set t.Builder = 'UNKNOWN'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
where DeedID not in (
	select  distinct deedid 
	from [MiNelson].[dbo].[TitleMarketShare_BaseTable]
	where DeedID in (
		SELECT distinct deedid
		FROM [MiNelson].[dbo].[TitleMarketShare_BaseTable]
		where Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'
	)   
	and [transaction type] = 'Subdivision/Newhome'
	) 
	
	and Builder != 'UNKNOWN' and [Transaction Type] = 'Home Equity'



--------------check duplicates-----------------------------

 /*IF OBJECT_ID('Minelson.dbo.titlemarketshare_dup') IS NOT NULL 
 */
DROP TABLE IF EXISTS [Minelson].[dbo].[titlemarketshare_dup]


SELECT  
      
      DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate], COUNT (*) count
 into [Minelson].[dbo].[titlemarketshare_dup]
  FROM [MiNelson].[dbo].[TitleMarketShare_Basetable]
  group by
        DeedId, [MGT Document number], [Loan Amount], Lender, [Transaction Type], [Loan Type],  [Adjustable Rate]
        having COUNT (*) > 1
        
 
 ------------------Delete duplciates---------------------------
 
         Delete from [MiNelson].[dbo].[TitleMarketShare_Basetable]
        where DeedID in (
SELECT deedid
  FROM [Minelson].[dbo].[titlemarketshare_dup])
  and deedsequence = 2
-----------------------------------------------------------


--------------------------------------------------------------------------
------updating Zipcode and city------------------------------------------
---------------------------------------------------------------------------


/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]

select * 
into  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]
from 
[Minelson].[dbo].[TitleMarketShare_BaseTable]
   
  
  ----- add new column for title zipcode-------------------
  
  alter table   [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] add Title_ZipCode varchar(5)
  
   alter table   [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] add Title_city varchar(40)
   
  ----- when Deedid match then populate deed_zip to title_zip----------------
  
   update [MiNelson].[dbo].[t]
   set t.Title_ZipCode = t.[zip code]
   from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
   inner join [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and t.[Zip Code] = z.ZIPCode

----When Deedid dont match update assr_zip to title_zip if it match---------------------------

update [MiNelson].[dbo].[t]
set t.Title_ZipCode = left(t.ass_Zipcode,5)
from 
  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  
     left join  [MiNelson].[dbo].[ZipFipsCityAll] z
  on t.FIPS = z.Fips and left(t.ass_Zipcode,5) = z.ZIPCode
  where z.ZIPCode is not null and t.[Zip Code] <> '' and t.ass_zipCode is not null
  and t.Title_ZipCode is null and z.ZIPCode is not null
 
 
 
 -----------------------------------------------------------
 
 ---update Preferred city name
 
 /*IF OBJECT_ID('Minelson.dbo.ZIPPreferredCity') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[ZIPPreferredCity] 

 select distinct ZIPCode, Fips, PreferredCity
into [Minelson].[dbo].[ZIPPreferredCity] 
from   [Minelson].[dbo].[ZipFipsCityAll]
group by ZIPCode, Fips, PreferredCity

 ------------Update preferred city name--------------------
 
 
 update [MiNelson].[dbo].[t]
 set t.title_city = z.PreferredCity
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
  inner join [Minelson].[dbo].[ZIPPreferredCity] z
  on t.FIPS = z.Fips and t.title_zipcode = z.ZIPCode
 
 -------------------------------------------------------------
 ---Update Deed Zip in update table-----------------------
 
  
 /*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
 
 -----152,279 with city name or zip different
select *
into [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_city <> t.City or t.Title_ZipCode <> t.[Zip Code]

union
select *
from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
where t.Title_ZipCode is null and ( t.[Zip Code] is not null and t.[Zip Code] <> '')



 update [MiNelson].[dbo].[t] 
 set t.[Zip Code] = t.title_ZipCode , t.city = t.title_city
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is not null
 

update [MiNelson].[dbo].[t]
 set t.[Zip Code] = '' , t.city = ''
  from [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] t
 where t.title_zipcode is  null
 
 --- update Zip and city in orginal table------------------
 
 --update t
 --set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 --from  [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip] t
 --inner join [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u
 --on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 ----update base table ---------------------------------
 
  update [MiNelson].[dbo].[t]
 set t.[Zip Code] = u.[Zip Code] , t.City = u.City
 from  [MiNelson].[dbo].[TitleMarketShare_BaseTable] t
 inner join [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update] u
 on t.DeedID = u.DeedID and t.DeedSequence = u.DeedSequence
 
 
 /*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip]
 /*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable_zip_update]
  /*IF OBJECT_ID('Minelson.dbo.ZIPPreferredCity') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[dbo].[ZIPPreferredCity] 




---------------Add Attorney name from RT--------------------------------------------------------

----------------------------------------------------------------------------------------



-----------------------------------------------------------------------
----- create RT table with only the columns that we need--------------------    
      
--      /*IF OBJECT_ID('[MiNelson].[dbo].[Title_marketshare_RT]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Title_marketshare_RT]


--SELECT[RECORDER_ID]
--      ,[FIPS]
--     ,SR_PROPERTY_ID,SR_UNIQUE_ID
--      ,[SR_DOC_NBR_FMT]
--      ,[SR_DOC_NBR_RAW]
--      , case when [SR_DOC_NBR_FMT] is null then null
--		 when ([SR_DOC_NBR_FMT] <> '' and len([SR_DOC_NBR_FMT]) >  2) then RIGHT(Rtrim([SR_DOC_NBR_FMT]), len([SR_DOC_NBR_FMT]) -2) else null end as RT_Doc_Nbr
--  ,SR_LAWYER_NAME,SR_LAWYER_CODE,SR_TITLE_CO_NAME,SR_TITLE_CO_CODE,SR_DATE_TRANSFER,SR_VAL_TRANSFER,SR_DATE_FILING
 
-- into  Minelson.dbo.Title_marketshare_RT
-- FROM [ART].[dbo].[RT_Recorder]
-- where SR_DATE_TRANSFER >= '20130101'
 

    -----------------------------------------------------
  
  -------------------------------------------------- 
--           /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID

     
       
--       select r.SA_PROPERTY_ID, r.CLGX_UNIQUE_ID, c.* ,
--       case when c.[Book/Page] IS not null then RIGHT(c.[Book/Page], 4)
--       when c.[Sale Document number] IS null then null
--       when len(c.[Sale Document number])<4 then null
--       else RIGHT(Rtrim(c.[Sale Document number]), len(c.[Sale Document number]) -4) end as Deed_Doc_Nbr
--       into  Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID 
--	   from [MiNelson].[dbo].[TitleMarketShare_BaseTable] c
--      left join Assr.dbo.PropertyReference r 
--       on c.FIPS = r.FIPS and c.REF_ID =r.REF_ID 
       
      
       
--           /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney
       
--       select r.[RECORDER_ID]
--      ,r.[FIPS] as RT_Fips
--      ,r.[SR_PROPERTY_ID]
--      ,r.[SR_DOC_NBR_FMT]
--      ,r.[SR_DOC_NBR_RAW]
--      ,r.[RT_Doc_Nbr]
--      ,r.[SR_LAWYER_NAME]
--      ,r.[SR_LAWYER_CODE]
--      ,r.[SR_TITLE_CO_NAME]
--      ,r.[SR_TITLE_CO_CODE]
--      ,r.[SR_DATE_TRANSFER]
--      ,r.[SR_VAL_TRANSFER]
--      ,r.[SR_DATE_FILING], I.* 
           
--     into Minelson.dbo.TitleMarketShare_BaseTable_Attorney 
--     from Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID I
--     left outer join Minelson.dbo.Title_marketshare_RT r
--     on I.FIPS = r.Fips and I.SA_PROPERTY_ID = r.SR_PROPERTY_ID and right(I.Deed_Doc_Nbr,4) = right(r.RT_Doc_Nbr,4)  and  LEFT(CONVERT(varchar,I.RECORDING_DATE,112),8) =r.SR_DATE_TRANSFER
     
   
      
--  /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final

--select * 
--  into Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final
--  from 
--(
--SELECT  
--DeedId, 
--[MGT Document number] ,
--[Loan Amount] ,
--Lender ,
--[Transaction Type] ,
--[Loan Type] ,
--[Adjustable Rate]
--,[SR_LAWYER_NAME]
--, row_number() over(partition by DeedId, [MGT Document number] ,[Loan Amount] ,Lender ,[Transaction Type] ,[Loan Type] ,[Adjustable Rate]
--      order by sr_lawyer_name desc) as [rn]
    
--from Minelson.dbo.TitleMarketShare_BaseTable_Attorney
--)x
--where rn =1


-- ------------update attorney name--------------------


  

--update t1
--set  t1.Attorney =  t2.sr_lawyer_name
--From [MiNelson].[dbo].[TitleMarketShare_BaseTable] t1
--left outer join Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final t2
--on t1.DeedID = t2.DeedID and  isnull (t1.[MGT Document number],'') = isnull(t2.[MGT Document number],'') and
--t1.[Loan Amount] = t2.[Loan Amount] and t1.Lender = t2.Lender and t1.[Transaction Type] = t2.[Transaction Type]
--and t1.[Loan Type] = t2.[Loan Type] and t1.[Adjustable Rate] = t2.[Adjustable Rate]
--where 

-- t1.attorney = 'UNKNOWN' and t2.sr_lawyer_name is not null 
--  and t2.sr_lawyer_name <> ''
--  and  t2.SR_LAWYER_NAME  not like '%BANK%'
--  and  t2.SR_LAWYER_NAME  not like '%MORTGAGE%'
--  and  t2.SR_LAWYER_NAME not like '%TITLE%'
--  and  t2.SR_LAWYER_NAME  not like '%LOAN%'
--  and  t2.SR_LAWYER_NAME not like '%LENDING%'
--  and  t2.SR_LAWYER_NAME not like '%FCU%'
--  and  t2.SR_LAWYER_NAME not like '%S&L%'
  
-- --   /*IF OBJECT_ID('[MiNelson].[dbo].[Title_marketshare_RT]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[Title_marketshare_RT]

--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_ID
  
--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney

--     /*IF OBJECT_ID('Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final') IS NOT NULL */
DROP TABLE IF EXISTS Minelson.dbo.TitleMarketShare_BaseTable_Attorney_final

   /*IF OBJECT_ID('Minelson.dbo.titlemarketshare_dup') IS NOT NULL  */
DROP TABLE IF EXISTS [Minelson].[dbo].[titlemarketshare_dup]

     /*IF OBJECT_ID('Minelson.mktshr.Marketshare_Deed_BK_Final') IS NOT NULL */
DROP TABLE IF EXISTS [Minelson].[mktshr].[Marketshare_Deed_BK_Final]




   --- step 4
   
 



    
update [MiNelson].[dbo].[A]
set A.[Title company] = b.[Title Company Edited]

From  [MiNelson].[dbo].[TitleMarketShare_BaseTable]  a
   inner join [MiNelson].[mktshr].[TitleMarketShare_TitleCompanyName_Edit] b
   on a.state = b.state and a.[Title Company] = b.[Title Company]

update [MiNelson].[dbo].[A]
set A.[Title company] = b.[Title Company Edited]
From  [MiNelson].[dbo].[TitleMarketShare_BaseTable] a
   inner join [MiNelson].[mktshr].[TitleMarketShare_TitleCompanyName_Edit] b
   on  b.state = 'NN' and a.[Title Company] = b.[Title Company] and a.date >= b.[Transfer Date]

update [MiNelson].[dbo].[A]
set A.[Title Company] = 'FIRST AMERICAN TITLE'
from [MiNelson].[dbo].[TitleMarketShare_BaseTable]  a
where a.state = 'UT' and a.[Title Company] in
('FIRST AMERICAN LENDERS ADVANTA'
,'FIRST AMERICAN LNDRS ABSTRACT'
,'FIRST AMERICAN MORTGAGE SOLUTIONS LLC'
,'FIRST AMERICAN MTG SVCS'
,'FIRST AMERICAN-BOUNTIFUL')
and [transaction type] in ('Resale', 'Resale - Cash Sale')

update [MiNelson].[dbo].[t]
set t.County = n.marketshare_county_name
from [MiNelson].[dbo].[TitleMarketShare_BaseTable]  t
  inner join [MiNelson].[mktshr].[TitleMarketShare_Fips_CountyName] n
   on t.fips = n.fips
   where t.county <> n.marketshare_county_name


   Delete a from [MiNelson].[dbo].[TitleMarketShare_BaseTable]   a
left join [MiNelson].[mktshr].[Market_Share_Coverage_ZipCode] b
on a.[zip code] = isnull (b.[Zip Code], '')
where b.[zip code] is null and a.[zip code] <> ''



 /*IF OBJECT_ID('[MiNelson].[mktshr].[TitleMarketShare_Bulk_Expand_incremental]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[TitleMarketShare_Bulk_Expand_incremental]



   SELECT  [DeedID]
      ,[Transaction Type]
      ,[Lender]
      ,[Title Company]
      ,[Attorney]
      ,[Sale Document number]
      ,[MGT Document number]
      ,[Book/Page]
      ,[Sales Price]
      ,[Loan Amount]
      ,[Loan To Value]
      ,[Date]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Builder]
      ,[Seller Name]
      ,[Buyer]
      ,[Residential]
      ,[Corporate]
      ,[City]
      ,[County]
      ,[State]
      ,[Zip Code]
      ,[FIPS]
      ,[Census Tract #]
      ,[Property Type]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
     -- ,CONVERT(varchar(10), GETDATE(),112) as [Rundate]
	    ,[FMT_DOC_NBR]
      ,[FMT_Book_Page]
      ,[FMT_MTG1_DOC_NBR]
      ,[FMT_MTG2_DOC_NBR]
      ,[FMT_MTG1_Book_Page]
      ,[FMT_MTG2_Book_Page]
	  ,Ref_ID
	  into [MiNelson].[mktshr].[TitleMarketShare_Bulk_Expand_incremental]
  FROM  [MiNelson].[dbo].[TitleMarketShare_BaseTable] 
  
 


  ----------------------------------------------------------------------------------------------------------------





------ Clean up

/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp1]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp1]

/*IF OBJECT_ID('[MiNelson].[dbo].[MarketShareTitle_Temp2]') IS NOT NULL */
DROP TABLE IF EXISTS [MiNelson].[dbo].[MarketShareTitle_Temp2]

/*IF OBJECT_ID('[MiNelson].[dbo].[BK_TitleMarketShare_BaseTable]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[dbo].[BK_TitleMarketShare_BaseTable]

/*IF OBJECT_ID('[MiNelson].[dbo].[TitleMarketShare_BaseTable]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[dbo].[TitleMarketShare_BaseTable]

 /*IF OBJECT_ID('[MiNelson].[mktshr].[TitleMarketShare_Bulk_Expand_Update]') IS NOT NULL  */
DROP TABLE IF EXISTS [MiNelson].[mktshr].[TitleMarketShare_Bulk_Expand_Update]


end


