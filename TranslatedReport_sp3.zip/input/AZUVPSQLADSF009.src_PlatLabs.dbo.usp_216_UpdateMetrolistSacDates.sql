SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [src_PlatLabs].[dbo].[usp_216_UpdateMetrolistSacDates]

As
Begin

	declare @SpNameLocal varchar(100) = '[' + OBJECT_NAME(@@PROCID) + ']', @SpNewIdLocal uniqueidentifier = NEWID() -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (1 of 3 line).
	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'Start', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal -- Licensing Daily Load process. Beginning of daily sp Staging DB Only uncomment (2 of 3 line).


update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET pending_date = status_change_date
,LoadDate = GetDate()
where mls_id = 2648 and status in('pending')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET list_date = status_change_date
,LoadDate = GetDate()
where mls_id = 2648 and status in('active')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET contingent_date = status_change_date
,LoadDate = GetDate()
where mls_id = 2648 and status in('contingent','backup')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET sold_date = status_change_date
,close_date = status_change_date
,LoadDate = CASE WHEN status_change_date >= '2024-01-01' THEN GetDate() ELSE LoadDate END
where mls_id = 2648 and status in('sold')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET withdrawn_date = status_change_date
,close_date = status_change_date
,LoadDate = CASE WHEN status_change_date >= '2024-01-01' THEN GetDate() ELSE LoadDate END
where mls_id = 2648 and status in('withdrawn')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET expiration_date = status_change_date
,close_date = status_change_date
,LoadDate = CASE WHEN status_change_date >= '2024-01-01' THEN GetDate() ELSE LoadDate END
where mls_id = 2648 and status in('expired')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET cancelled_date = status_change_date
,close_date = status_change_date
,LoadDate = CASE WHEN status_change_date >= '2024-01-01' THEN GetDate() ELSE LoadDate END
where mls_id = 2648 and status in('cancelled')

update [src_PlatLabs].[listing].[ListingsRaw_Batch]
SET off_market_date = status_change_date
,close_date = status_change_date
,LoadDate = CASE WHEN status_change_date >= '2024-01-01' THEN GetDate() ELSE LoadDate END
where mls_id = 2648 and status in('off_market')

	EXEC [src_MLS_Processing].[dbo].[90000_sp_meta_data] @StartEnd = 'End', @SpName = @SpNameLocal, @SpNewId = @SpNewIdLocal  -- Licensing Daily Load process. Ending of daily sp Staging DB Only uncomment (3 of 3 line).



END

