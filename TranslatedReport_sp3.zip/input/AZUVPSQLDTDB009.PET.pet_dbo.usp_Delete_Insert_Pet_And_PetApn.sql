/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_Delete_Insert_Pet_And_PetApn | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

CREATE PROCEDURE [PET].[pet_dbo].[usp_Delete_Insert_Pet_And_PetApn] @fips INT
	,@Refresh BIT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change

******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Delete_Insert_Pet_And_PetApn'
		,N'Started'

	IF @Refresh = 0
	BEGIN
		DELETE p
		FROM [pet].[dbo].[pet] p WITH (
				NOLOCK
				,INDEX (IDX_FIPS_REF_ID)
				)
		INNER JOIN [pet].[pet_tmp].[PET_WRK] a WITH (
				NOLOCK
				,INDEX (IDX_FIPS_REF_ID)
				) ON a.fips = p.fips
			AND a.ref_id = p.ref_id
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);
	END
	ELSE
	BEGIN
		DELETE
		FROM [pet].[dbo].[pet]
		WHERE fips = @fips
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			)
	END

	--
	-- insert into pet
	--
	INSERT INTO [PET].[dbo].[PET] (
		[REF_ID]
		,[FIPS]
		,[UNFORMATTED_APN]
		,[APN_SEQUENCE_NBR]
		,[SOURCE]
		,[DQ_PROP_ID]
		,[DQ_APN]
		,[BK_PROP_ID]
		,[BK_APN]
		,[RT_PROP_ID]
		,[RT_APN]
		,[NEO_APN]
		,[NEO_LAND_TYPE]
		,[NEO_TITLE_LEGAL]
		,[StreetNumber]
		,[Pre_Direction]
		,[StreetName]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[State]
		,[Zip]
		,[Plus4]
		,[Label1]
		,[Value1]
		,[Label2]
		,[Value2]
		,[Label3]
		,[Value3]
		,[Label4]
		,[Value4]
		,[Label5]
		,[Value5]
		,[Label6]
		,[Value6]
		,[Label7]
		,[Value7]
		,[Label8]
		,[Value8]
		,[Label9]
		,[Value9]
		,[Label10]
		,[Value10]
		,[Label11]
		,[Value11]
		,[Label12]
		,[Value12]
		,[Label13]
		,[Value13]
		,[Label14]
		,[Value14]
		,[Label15]
		,[Value15]
		,[Label16]
		,[Value16]
		,[Label17]
		,[Value17]
		,[Label18]
		,[Value18]
		,[Label19]
		,[Value19]
		,[Label20]
		,[Value20]
		,[Label21]
		,[Value21]
		,[Label22]
		,[Value22]
		,[Label23]
		,[Value23]
		,[BookType]
		,[Full_Address]
		,[Check_Sum]
		,[created]
		,[updated]
		,[FORMATTED_APN]
		,[U_Apn_Dup_Ind]
		,[F_Apn_Dup_Ind]
		,[Legal_Dup_Ind]
		,[Addr_Dup_Ind]
		,[Dup_Key]
		,[SF_Address]
		,[SF_City]
		,[SF_Unit]
		,[SF_Address_5]
		,[AddressCity]
		,[Unit_Ind]
		,[BLOCK_NBR]
		,[LOT_NBR_1]
		,[LOT_NBR_2]
		,[LOT_NBR_3]
		,[SUBDIV_TRACT_NBR]
		,[SUBDIV_PLAT_BOOK]
		,[SUBDIV_PLAT_PAGE]
		,[SUBDIV_NAME]
		,[EXTENDED_LEGAL_DESCRIPTION]
		,[RANGE]
		,[TOWNSHIP]
		,[SECTION]
		,[QUARTER_SECTION]
		,[MUNICIPALITY_NAME]
		,[MUNICIPALITY_CODE]
		,[NEO_Legal_cnt]
		,[COUNTY_USE_CODE]
		,[NEO_LAND_TYPE_AN]
		,[NEO_LAND_TYPE_AT]
		,[NEO_LAND_TYPE_MC]
		,[NEO_LAND_TYPE_SB]
		,[NEO_LAND_TYPE_SC]
		,[SF_Address_10]
		,[AddressMatchResults]
		)
	SELECT a.[REF_ID]
		,a.[FIPS]
		,a.[UNFORMATTED_APN]
		,a.[APN_SEQUENCE_NBR]
		,a.[SOURCE]
		,a.[DQ_PROP_ID]
		,a.[DQ_APN]
		,a.[BK_PROP_ID]
		,a.[BK_APN]
		,a.[RT_PROP_ID]
		,a.[RT_APN]
		,a.[NEO_APN]
		,a.[NEO_LAND_TYPE]
		,a.[NEO_TITLE_LEGAL]
		,a.[StreetNumber]
		,a.[Pre_Direction]
		,a.[StreetName]
		,a.[Street_Type]
		,a.[Post_Direction]
		,a.[Unit_Type]
		,a.[Unit]
		,a.[City]
		,a.[State]
		,a.[Zip]
		,a.[Plus4]
		,a.[Label1]
		,a.[Value1]
		,a.[Label2]
		,a.[Value2]
		,a.[Label3]
		,a.[Value3]
		,a.[Label4]
		,a.[Value4]
		,a.[Label5]
		,a.[Value5]
		,a.[Label6]
		,a.[Value6]
		,a.[Label7]
		,a.[Value7]
		,a.[Label8]
		,a.[Value8]
		,a.[Label9]
		,a.[Value9]
		,a.[Label10]
		,a.[Value10]
		,a.[Label11]
		,a.[Value11]
		,a.[Label12]
		,a.[Value12]
		,a.[Label13]
		,a.[Value13]
		,a.[Label14]
		,a.[Value14]
		,a.[Label15]
		,a.[Value15]
		,a.[Label16]
		,a.[Value16]
		,a.[Label17]
		,a.[Value17]
		,a.[Label18]
		,a.[Value18]
		,a.[Label19]
		,a.[Value19]
		,a.[Label20]
		,a.[Value20]
		,a.[Label21]
		,a.[Value21]
		,a.[Label22]
		,a.[Value22]
		,a.[Label23]
		,a.[Value23]
		,a.[BookType]
		,a.[Full_Address]
		--,CASE 
		--	WHEN a.[Full_Address] IS NOT NULL
		--		THEN HashBytes('MD5', addr.[Full_Address])
		--	ELSE NULL
		--	END AS [Check_Sum]
		,a.[Check_Sum]
		,getdate() AS [created]
		,getdate() AS [updated]
		,a.[FORMATTED_APN]
		,0 AS [U_Apn_Dup_Ind]
		,0 AS [F_Apn_Dup_Ind]
		,0 AS [Legal_Dup_Ind]
		,0 AS [Addr_Dup_Ind]
		,0 AS [Dup_Key]
		,a.[SF_Address]
		,a.[SF_City]
		,a.[SF_Unit]
		,a.[SF_Address_5]
		,a.[AddressCity]
		,a.[Unit_Ind]
		,ar.[BLOCK_NBR]
		,ar.[LOT_NBR_1]
		,ar.[LOT_NBR_2]
		,ar.[LOT_NBR_3]
		,ar.[SUBDIV_TRACT_NBR]
		,ar.[SUBDIV_PLAT_BOOK]
		,ar.[SUBDIV_PLAT_PAGE]
		,ar.[SUBDIV_NAME]
		,ar.[EXTENDED_LEGAL_DESCRIPTION]
		,ar.[RANGE]
		,ar.[TOWNSHIP]
		,ar.[SECTION]
		,ar.[QUARTER_SECTION]
		,ar.[MUNICIPALITY_NAME]
		,ar.[MUNICIPALITY_CODE]
		,0 AS [NEO_Legal_cnt]
		,ar.[COUNTY_USE_CODE]
		,0 AS [NEO_LAND_TYPE_AN]
		,0 AS [NEO_LAND_TYPE_AT]
		,0 AS [NEO_LAND_TYPE_MC]
		,0 AS [NEO_LAND_TYPE_SB]
		,0 AS [NEO_LAND_TYPE_SC]
		,a.[SF_Address_10]
		,a.[AddressMatchResults]
	FROM [pet].[pet_tmp].[PET_WRK] a WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			)
	INNER JOIN [pet].[pet_tmp].[assr] ar WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON ar.fips = a.fips
		AND ar.ref_id = a.ref_id
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		)

	--select top 100 * from pet.pet_tmp.assr
	TRUNCATE TABLE [pet].[pet_tmp].[pet_apn_wrk]

	INSERT INTO [pet].[pet_tmp].[pet_apn_wrk] (
		ref_id
		,fips
		,apn_type
		,apn
		,created
		)
	SELECT a.REF_ID
		,a.FIPS
		,b.APN_Type
		,b.APN
		,getdate() AS created
	FROM [PET].[pet_tmp].[PET_WRK] a WITH (
			NOLOCK
			,INDEX (IDX_FIPS_REF_ID)
			)
	INNER JOIN [pet].[pet_tmp].[assr] ar WITH (
			NOLOCK
			,INDEX (idx_fips_ref_id)
			) ON ar.fips = a.fips
		AND ar.ref_id = a.ref_id
	OUTER APPLY (
		SELECT a.UNFORMATTED_APN AS apn
			,'UNF' AS apn_type
		
		UNION ALL
		
		SELECT a.DQ_APN AS apn
			,'DQ' AS apn_type
		
		UNION ALL
		
		SELECT a.BK_APN AS apn
			,'BK' AS apn_type
		
		UNION ALL
		
		SELECT a.rt_APN AS apn
			,'RT' AS apn_type
		
		UNION ALL
		
		SELECT ar.FORMATTED_APN AS apn
			,'FMT' AS apn_type
		
		UNION ALL
		
		SELECT ar.ORIGINAL_APN AS apn
			,'orig' AS apn_type
		
		UNION ALL
		
		SELECT ar.PREVIOUS_PARCEL_NBR AS apn
			,'prev' AS apn_type
		
		UNION ALL
		
		SELECT ar.P_ID_IRIS_FRMTD AS apn
			,'iris' AS apn_type
		
		UNION ALL
		
		SELECT ar.ALTERNATE_APN AS apn
			,'alt' AS apn_type
		
		UNION ALL
		
		SELECT ar.ACCOUNT_NBR AS apn
			,'acct' AS apn_type
		
		UNION ALL
		
		SELECT ar.Vendor_Original_Apn AS apn
			,'VOA' AS apn_type
		) b
	WHERE b.apn IS NOT NULL
	OPTION (
		RECOMPILE
		,MAXDOP 20
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	IF @Refresh = 0 --incremental
	BEGIN
		DELETE pa
		FROM [pet].[dbo].[pet_apn] pa WITH (
				NOLOCK
				,INDEX (fips_ref_id_apntype)
				)
		INNER JOIN [pet].[pet_tmp].[pet_apn_wrk] pw WITH (
				NOLOCK
				,INDEX (fips_ref_id_apntype)
				) ON pw.FIPS = pa.fips
			AND pw.REF_ID = pa.REF_ID
		--AND pw.APN_Type = pa.APN_Type
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			)
	END
	ELSE
	BEGIN
		DELETE
		FROM [pet].[dbo].[pet_apn]
		WHERE fips = @fips
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			)
	END

	INSERT INTO [PET].[dbo].[PET_APN] (
		[REF_ID]
		,[FIPS]
		,[APN_Type]
		,[APN_ID]
		,[APN]
		,[created]
		,[updated]
		,[Dup_ind]
		)
	SELECT [REF_ID]
		,[FIPS]
		,[APN_Type]
		,0 AS [APN_ID]
		,[APN]
		,[created]
		,[created]
		,NULL AS [Dup_ind]
	FROM [pet].[pet_tmp].[pet_apn_wrk]
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		)

	--	select * from Pet.[pet_tmp].[pet_daily_tracker]
	EXEC [PET].[dbo].[AddPetlog] 55555
		,N'info'
		,N'usp_Delete_Insert_Pet_And_PetApn'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


