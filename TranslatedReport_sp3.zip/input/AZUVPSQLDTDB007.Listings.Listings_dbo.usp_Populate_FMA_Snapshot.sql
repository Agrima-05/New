/* Source: AZUVNSQLDTDB003.datatree.local | Listings | Listings_dbo.usp_Populate_FMA_Snapshot | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */


CREATE PROCEDURE [Listings].[Listings_dbo].[usp_Populate_FMA_Snapshot] @ERROR VARCHAR(500) OUTPUT
AS
SET NOCOUNT ON

/******************************************************************************************************************
CHANGE LOG:
==========
who			date        change

******************************************************************************************************************/


BEGIN TRY
	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Populate_FMA_Snapshot'
		,N'Started'

   --Truncate table LISTINGS.Listings_dbo.[FMA_Snapshot] -- ??????????????????????????????????????????? delete when we start run multi days



	INSERT INTO [LISTINGS].[Listings_dbo].[FMA_Snapshot] (
			[id]
			,[property_id]
			,[current_market_status]
			,[date_first_advertised]
			,[date_last_advertised]
			,[asking_price_high]
			,[asking_price_high_on]
			,[asking_price_low]
			,[asking_price_low_on]
			,[asking_price_current]
			,[street_address]
			,[city]
			,[urbanization]
			,[county_name]
			,[STATE]
			,[postal_code]
			,[cass_street_address]
			,[cass_city]
			,[cass_urbanization]
			,[cass_county_name]
			,[cass_state]
			,[cass_postal_code]
			,[cass_dpbc]
			,[cass_unit_type]
			,[cass_unit_number]
			,[cass_dpv]
			,[cass_building_type]
			,[cass_return_code]
			,[cass_updated_on]
			,[gnis_feature_id]
			,[scf]
			,[fips]
			,[msa]
			,[latitude]
			,[longitude]
			,[property_type_description]
			,[subdivision]
			,[bedrooms_string]
			,[bedrooms_int]
			,[bathrooms_string]
			,[bathrooms_total]
			,[bathrooms_full]
			,[bathrooms_3_4]
			,[bathrooms_half]
			,[lot_size_string]
			,[lot_size_decimal]
			,[lot_size_unit]
			,[square_feet_string]
			,[square_feet_foundation]
			,[square_feet_total]
			,[square_feet_finished]
			,[square_feet_above_ground]
			,[square_feet_below_ground]
			,[garage_description]
			,[garage_stalls]
			,[year_built]
			,[stories]
			,[water_source]
			,[sewer_source]
			,[school_district]
			,[school_elementary]
			,[school_middle]
			,[school_senior_high]
			,[construction_description]
			,[floor_description]
			,[cooling_description]
			,[heating_description]
			,[basement_description]
			,[fireplace_description]
			,[interior_description]
			,[general_description]
			,[parking_description]
			,[exterior_description]
			,[roof_description]
			,[pool_description]
			,[lot_dimensions]
			,[zoning_description]
			,[land_description]
			,[green_energy_description]
			,[hoa_amenities]
			,[disabled_accessibility_description]
			,[design_features_description]
			,[legal_description]
			,[included_items]
			,[has_pool]
			,[has_water_front]
			,[body_of_water]
			,[water_front_type]
			,[agent_name]
			,[agent_telephone]
			,[agent_email]
			,[agent_website]
			,[brokerage_name]
			,[brokerage_street_address]
			,[brokerage_city]
			,[brokerage_state]
			,[brokerage_postal_code]
			,[brokerage_telephone]
			,[brokerage_website]
			,[is_fsbo]
			,[is_lender_owned]
			,[is_short_sale]
			,[has_notice_of_default]
			,[local_assessor_id]
			,[tax_year]
			,[tax_amount]
			,[assessments]
			,[association_fees]
			,[association_fees_frequency]
			,[is_active]
			,[created_at]
			,[last_price_change]
			,[last_price_change_on]
			,[inactive_on]
			,[sold_on]
			,[asking_price_original]
			,[checksum]
			,[created]
			,[updated]
			)
		SELECT w.[id]
			,w.[property_id]
			,w.[current_market_status]
			,w.[date_first_advertised]
			,w.[date_last_advertised]
			,w.[asking_price_high]
			,w.[asking_price_high_on]
			,w.[asking_price_low]
			,w.[asking_price_low_on]
			,w.[asking_price_current]
			,w.[street_address]
			,w.[city]
			,w.[urbanization]
			,w.[county_name]
			,w.[STATE]
			,w.[postal_code]
			,w.[cass_street_address]
			,w.[cass_city]
			,w.[cass_urbanization]
			,w.[cass_county_name]
			,w.[cass_state]
			,w.[cass_postal_code]
			,w.[cass_dpbc]
			,w.[cass_unit_type]
			,w.[cass_unit_number]
			,w.[cass_dpv]
			,w.[cass_building_type]
			,w.[cass_return_code]
			,w.[cass_updated_on]
			,w.[gnis_feature_id]
			,w.[scf]
			,w.[fips]
			,w.[msa]
			,w.[latitude]
			,w.[longitude]
			,w.[property_type_description]
			,w.[subdivision]
			,w.[bedrooms_string]
			,w.[bedrooms_int]
			,w.[bathrooms_string]
			,w.[bathrooms_total]
			,w.[bathrooms_full]
			,w.[bathrooms_3_4]
			,w.[bathrooms_half]
			,w.[lot_size_string]
			,w.[lot_size_decimal]
			,w.[lot_size_unit]
			,w.[square_feet_string]
			,w.[square_feet_foundation]
			,w.[square_feet_total]
			,w.[square_feet_finished]
			,w.[square_feet_above_ground]
			,w.[square_feet_below_ground]
			,w.[garage_description]
			,w.[garage_stalls]
			,w.[year_built]
			,w.[stories]
			,w.[water_source]
			,w.[sewer_source]
			,w.[school_district]
			,w.[school_elementary]
			,w.[school_middle]
			,w.[school_senior_high]
			,w.[construction_description]
			,w.[floor_description]
			,w.[cooling_description]
			,w.[heating_description]
			,w.[basement_description]
			,w.[fireplace_description]
			,w.[interior_description]
			,w.[general_description]
			,w.[parking_description]
			,w.[exterior_description]
			,w.[roof_description]
			,w.[pool_description]
			,w.[lot_dimensions]
			,w.[zoning_description]
			,w.[land_description]
			,w.[green_energy_description]
			,w.[hoa_amenities]
			,w.[disabled_accessibility_description]
			,w.[design_features_description]
			,w.[legal_description]
			,w.[included_items]
			,w.[has_pool]
			,w.[has_water_front]
			,w.[body_of_water]
			,w.[water_front_type]
			,w.[agent_name]
			,w.[agent_telephone]
			,w.[agent_email]
			,w.[agent_website]
			,w.[brokerage_name]
			,w.[brokerage_street_address]
			,w.[brokerage_city]
			,w.[brokerage_state]
			,w.[brokerage_postal_code]
			,w.[brokerage_telephone]
			,w.[brokerage_website]
			,w.[is_fsbo]
			,w.[is_lender_owned]
			,w.[is_short_sale]
			,w.[has_notice_of_default]
			,w.[local_assessor_id]
			,w.[tax_year]
			,w.[tax_amount]
			,w.[assessments]
			,w.[association_fees]
			,w.[association_fees_frequency]
			,w.[is_active]
			,w.[created_at]
			,w.[last_price_change]
			,w.[last_price_change_on]
			,w.[inactive_on]
			,w.[sold_on]
			,w.[asking_price_original]
			,w.[checksum]
			,w.[created]
			,w.[updated]


		FROM [Listings].[Listings_tmp].[FMA_Snapshot_wrk] w WITH (NOLOCK)
		left join [Listings].[Listings_dbo].[FMA_Snapshot] s with(nolock,index(idx_id_created)) on s.id = w.id and s.created =w.created
		where s.id is null

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,N'usp_Populate_FMA_Snapshot'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + isnull(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + isnull(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


