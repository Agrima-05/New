SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- ================================================================================
-- Description:	Refresh DTDB data
-- ================================================================================

Create procedure [src_PlatLabs].[dbo].[usp_861_CreateDTDBAgentOffice]

AS
BEGIN


	SET NOCOUNT ON;

			DROP TABLE [DTDBListings].[dbo].[Agents]

			SELECT * INTO [DTDBListings].[dbo].[Agents] 
			FROM [src_PlatLabs].[dbo].[vAgents]
			WHERE mls_id in(Select mls_id from [src_PlatLabs].[dbo].[platlabs_update_config] where code like '%_39' and active = '1')


			DROP TABLE [DTDBListings].[dbo].[Offices]

			SELECT * INTO [DTDBListings].[dbo].[Offices] 
			FROM [src_PlatLabs].[dbo].[vOffices]
			WHERE mls_id in(Select mls_id from [src_PlatLabs].[dbo].[platlabs_update_config] where code like '%_39' and active = '1')


END




