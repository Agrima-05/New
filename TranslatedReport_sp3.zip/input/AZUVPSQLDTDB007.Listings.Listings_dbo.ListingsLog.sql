/* Source: AZUVNSQLDTDB003.datatree.local | Listings | listings_dbo.ListingsLog | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

create PROCEDURE [Listings].[Listings_dbo].[ListingsLog]
	@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
INSERT INTO [listings].[listings_dbo].[ListingLog] (
	LogTimestamp
	,[Level]
	,Logger
	,[Message]
	)
VALUES (
	getdate()
	,@Level
	,@Logger
	,@Message
	)

