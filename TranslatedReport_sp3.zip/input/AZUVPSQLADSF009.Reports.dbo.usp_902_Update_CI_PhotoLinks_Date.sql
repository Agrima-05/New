SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Update Date Sent Updates for CI Listings
-- =============================================
CREATE PROCEDURE [Reports].[dbo].[usp_902_Update_CI_PhotoLinks_Date]
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [Reports].[dbo].[SentToCI_Photos] 
	SET DateSentUpdates = GetDate()

END

