SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





-- =============================================
-- Create date: 20151215
-- Description:	Step 2 of Process, Pull datasets needed
-- =============================================
CREATE PROCEDURE [zCust_PropertyOnion].[dbo].[usp_502_Pull_FLANK_DATA] 
	
AS
BEGIN


	SET NOCOUNT ON;

    	--GET ADS TRANSACTIONS FROM FLANK

		---- DEEDS
		IF  EXISTS (SELECT * FROM [zCust_PropertyOnion].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_DEEDS]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_DEEDS]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,CASE WHEN Seller1FullName is NULL THEN Seller1CompanyName ELSE Seller1FullName END SellerLender
		,SalesPrice,DocumentTypeCode,d.CodeDesc as DocType,DeedTransactionType,t.CodeDesc as TransType, 'D' as DocSrcInd,[ChronoKey] 
		INTO [zCust_PropertyOnion].[dbo].[w_FLANK_DEEDS]
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.DeedTransactionType = t.TransType
		ORDER BY RAW_ID,RecordingDt

		---- MORTGAGES

		IF  EXISTS (SELECT * FROM [zCust_PropertyOnion].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_MTG]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_MTG]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		, case when Borrower1FullName is null then Borrower1CompanyName else Borrower1FullName end as BuyerBorrower,LenderName AS SellerLender,LoanAmount,DocumentTypeCode
		,d.CodeDesc as DocType,LoanTransType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] 
		INTO [zCust_PropertyOnion].[dbo].[w_FLANK_MTG]
		 from [data].[dbo].[Mortgage] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentTypeCode = d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.LoanTransType = t.TransType
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_PropertyOnion].[dbo].[w_FLANK_MTG]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,Loan1RecordingDt,Loan1Document,Loan1Book,Loan1Page,NULL,NULL
		,CASE WHEN Buyer1FullName is NULL THEN Buyer1CompanyName ELSE Buyer1FullName END as BuyerBorrower,Loan1LenderName AS SellerLender,Loan1Amount,Loan1DocumentTypeCode,d.CodeDesc as DocType
		,Loan1TransactionType,t.CodeDesc as TransType , 'M' as DocSrcInd,[ChronoKey] 
		from [data].[dbo].[deed] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.Loan1DocumentTypeCode like d.DocTypeID
		LEFT OUTER JOIN  [Global].[dbo].[Lkup_Trans_Type] t
		on a.Loan1TransactionType Like t.TransType
		WHERE Loan1RecordingDt is not null
		ORDER BY RAW_ID,RecordingDt 

		----ASSIGN/REL

		IF  EXISTS (SELECT * FROM [zCust_PropertyOnion].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_ASR]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_ASR]

		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt, 'A' as DocSrcInd,[ChronoKey] 
		INTO [zCust_PropertyOnion].[dbo].[w_FLANK_ASR]
		FROM [data].[dbo].[Assignment] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		ORDER BY RAW_ID,RecordingDt

		INSERT INTO [zCust_PropertyOnion].[dbo].[w_FLANK_ASR]
		select b.RAW_ID,a.FIPS,TransactionID,FAPropertyID,RecordingDt,DocNbrSrce,BookSrce,PageSrce,DocNbrFrmt,BkPgFrmt
		,CASE WHEN BorrowerFullName is NULL THEN Borrower1CompanyName ELSE BorrowerFullName END as BuyerBorrower
		,DocumentType,d.CodeDesc as DocType,RecordType
		,OrigDeedRecordingDt,OrigDeedDocNbr,OrigDeedBook,OrigDeedPage,OrigDeedContractDt,OrigLenderBen,OrigLoanAmt, 'R' as DocSrcInd,[ChronoKey] 
		FROM [data].[dbo].[Release] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		ORDER BY RAW_ID,RecordingDt


		---- PREFORCLOSURE/NOD

		IF  EXISTS (SELECT * FROM [zCust_PropertyOnion].[sys].[objects] WHERE object_id = OBJECT_ID(N'[dbo].[w_FLANK_NOD]') AND type in (N'U'))
		DROP TABLE [dbo].[w_FLANK_NOD]


		Select a.*,Raw_ID,CodeDesc as DocType
		INTO [zCust_PropertyOnion].[dbo].[w_FLANK_NOD]
		FROM [data].[dbo].[FORECLOSURE] a with(NOLOCK) JOIN [zCust_PropertyOnion].[dbo].[a_PropMatch_Work] b
		on convert(int,a.FIPS) = convert(int,b.FIPS)
			and a.FAPropertyID = b.PRopertyID
		LEFT OUTER JOIN [Global].[dbo].[Lkup_Doc_Type] d
			on a.DocumentType = d.DocTypeID
		ORDER BY RAW_ID,RecordingDt


		---- CREATE TransHist 

		TRUNCATE TABLE w_TransHist_FLANK

		INSERT INTO [zCust_PropertyOnion].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey])
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[SalesPrice]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
		FROM [zCust_PropertyOnion].[dbo].[w_FLANK_DEEDS]


		INSERT INTO [zCust_PropertyOnion].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey])
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentTypeCode]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[LoanAmount]
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,[DocSrcInd]
			  ,NULL
			  ,[DocType]
			  ,[TransType]
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
		FROM [zCust_PropertyOnion].[dbo].[w_FLANK_MTG]

		INSERT INTO [zCust_PropertyOnion].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey])
		SELECT [FIPS]
			  ,[FAPropertyID]
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentType]
			  ,LEFT(CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END,250)
			  ,left([BuyerBorrower],250)
			  ,NULL
			  ,NULL
			  ,OrigDeedRecordingDt
			  ,OrigLoanAmt
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'R'
			  ,NULL
			  ,CASE WHEN [DocSrcInd] = 'R' THEN 'RELEASE' ELSE 'ASSIGNMENT' END
			  ,left([DocType],250)
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
		FROM [zCust_PropertyOnion].[dbo].[w_FLANK_ASR]

		INSERT INTO [zCust_PropertyOnion].[dbo].[w_TransHist_FLANK]([Fips]
			  ,[REF_ID]
			  ,[RecordNumber]
			  ,[RecordingDate]
			  ,[DocumentType]
			  ,[DocumentNbr]
			  ,[BuyerBorrower]
			  ,[SellerLender]
			  ,[Value]
			  ,[OrigTransRecDate]
			  ,[OrigTransDocNumber]
			  ,[Lien_Pos]
			  ,[CmtId]
			  ,[Source_Type]
			  ,[Doc_Id]
			  ,[Doc_Src_Ind]
			  ,[OrigDoc_Id]
			  ,[DocumentTypeDesc]
			  ,[TransType]
			  ,[ToUse]
			  ,[RAW_ID]
			  ,[ChronoKey])
		SELECT FIPS
			  ,FAPropertyID
			  ,NULL
			  ,[RecordingDt]
			  ,[DocumentType]
			  ,CASE WHEN [DocNbrSrce] is NULL THEN BookSrce + '.' + PageSrce ELSE [DocNbrSrce] END
			  ,isnull(TrustOrBorrower1LastNameOrCorp,'') + ' ' + isnull(TrustOrBorrower1FirstNameMi,'')
			  ,NULL
			  ,NULL
			  ,LoanRecordingDt
			  ,OrigLoanAmt
			  ,NULL
			  ,NULL
			  ,NULL
			  ,NULL
			  ,'R'
			  ,NULL
			  ,[DocType]
			  ,NULL
			  ,NULL
			  ,[RAW_ID]
			  ,ChronoKey
		FROM [zCust_PropertyOnion].[dbo].[w_FLANK_NOD]


		UPDATE [zCust_PropertyOnion].[dbo].[a] 
		set a.propertyID = b.propertyID
		FROM [zCust_PropertyOnion].[dbo].[w_transHist_Flank] a JOIN [zCust_PropertyOnion].[dbo].[a_propMatch_work] b
		on convert(int,a.Fips) = convert(int,b.Fips)
		and a.RAW_ID = b.RAW_ID

		
		UPDATE [zCust_PropertyOnion].[dbo].[a] 
		set a.REF_ID = b.REF_ID
		FROM [zCust_PropertyOnion].[dbo].[w_transHist_Flank] a JOIN [zCust_PropertyOnion].[dbo].[a_propMatch_work] b
		on convert(int,a.Fips) = convert(int,b.Fips)
		and a.RAW_ID = b.RAW_ID



END




