SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE PROCEDURE [zCust_PropertyOnion].[dbo].[usp_300_Start_Output_PROPERTY_ONION]


AS
BEGIN
	
	SET NOCOUNT ON;


	---- Create the custom OUTPUT table
	DROP TABLE [dbo].[x_Custom_OUTPUT] 

	CREATE TABLE [dbo].[x_Custom_OUTPUT](
	   [redash_id][varchar](250)NULL,
		[FIPS][varchar](250)NULL,
		[PropertyID][varchar](250)NULL,
		[APN][varchar](250)NULL,
		[TaxAccountNumber][varchar](250)NULL,
		[SitusFullStreetAddress][varchar](250)NULL,
		[SitusHouseNbr][varchar](250)NULL,
		[SitusHouseNbrSuffix][varchar](250)NULL,
		[SitusDirectionLeft][varchar](250)NULL,
		[SitusStreet][varchar](250)NULL,
		[SitusMode][varchar](250)NULL,
		[SitusDirectionRight][varchar](250)NULL,
		[SitusUnitType][varchar](250)NULL,
		[SitusUnitNbr][varchar](250)NULL,
		[SitusCity][varchar](250)NULL,
		[SitusState][varchar](250)NULL,
		[SitusZIP5][varchar](250)NULL,
		[SitusLatitude][float]NULL,
		[SitusLongitude][float]NULL,
		[SitusGeoStatusCode][varchar](250)NULL,
		[PropertyClassID][varchar](250)NULL,
		[LandUseCode][varchar](250)NULL,
		[CountyLandUseCode][varchar](250)NULL,
		[Zoning][varchar](250)NULL,
		[MobileHomeInd][varchar](250)NULL,
		[SchoolDistrictName][varchar](250)NULL,
		[LotSizeFrontageFeet][varchar](250)NULL,
		[LotSizeDepthFeet][varchar](250)NULL,
		[LotSizeAcres][varchar](250)NULL,
		[LotSizeSqFt][varchar](250)NULL,
		[Owner1CorpInd][varchar](250)NULL,
		[Owner1LastName][varchar](250)NULL,
		[Owner1FirstName][varchar](250)NULL,
		[Owner1MiddleName][varchar](250)NULL,
		[Owner1Suffix][varchar](250)NULL,
		[Owner2CorpInd][varchar](250)NULL,
		[Owner2LastName][varchar](250)NULL,
		[Owner2FirstName][varchar](250)NULL,
		[Owner2MiddleName][varchar](250)NULL,
		[Owner2Suffix][varchar](250)NULL,
		[OwnerNAME1FULL][varchar](250)NULL,
		[OwnerNAME2FULL][varchar](250)NULL,
		[OwnerOccupied][varchar](250)NULL,
		[Owner1OwnershipRights][varchar](250)NULL,
		[MailingFullStreetAddress][varchar](250)NULL,
		[MailingHouseNbr][varchar](250)NULL,
		[MailingHouseNbrSuffix][varchar](250)NULL,
		[MailingDirectionLeft][varchar](250)NULL,
		[MailingStreet][varchar](250)NULL,
		[MailingMode][varchar](250)NULL,
		[MailingDirectionRight][varchar](250)NULL,
		[MailingUnitType][varchar](250)NULL,
		[MailingUnitNbr][varchar](250)NULL,
		[MailingCity][varchar](250)NULL,
		[MailingState][varchar](250)NULL,
		[MailingZIP5][varchar](250)NULL,
		[MailingOptOut][varchar](250)NULL,
		[MailingCOName][varchar](250)NULL,
		[AssdTotalValue][varchar](250)NULL,
		[AssdLandValue][varchar](250)NULL,
		[AssdImprovementValue][varchar](250)NULL,
		[MarketTotalValue][varchar](250)NULL,
		[MarketValueLand][varchar](250)NULL,
		[MarketValueImprovement][varchar](250)NULL,
		[TaxAmt][varchar](250)NULL,
		[TaxYear][varchar](250)NULL,
		[TaxDeliquentYear][varchar](250)NULL,
		[MarketYear][varchar](250)NULL,
		[AssdYear][varchar](250)NULL,
		[TaxRateCodeArea][varchar](250)NULL,
		[SchoolTaxDistrict1Code][varchar](250)NULL,
		[SchoolTaxDistrict2Code][varchar](250)NULL,
		[SchoolTaxDistrict3Code][varchar](250)NULL,
		[HomesteadInd][varchar](250)NULL,
		[VeteranInd][varchar](250)NULL,
		[DisabledInd][varchar](250)NULL,
		[WidowInd][varchar](250)NULL,
		[SeniorInd][varchar](250)NULL,
		[SchoolCollegeInd][varchar](250)NULL,
		[ReligiousInd][varchar](250)NULL,
		[WelfareInd][varchar](250)NULL,
		[PublicUtilityInd][varchar](250)NULL,
		[CemeteryInd][varchar](250)NULL,
		[HospitalInd][varchar](250)NULL,
		[LibraryInd][varchar](250)NULL,
		[BuildingArea][varchar](250)NULL,
		[BuildingAreaInd][varchar](250)NULL,
		[SumBuildingSqFt][varchar](250)NULL,
		[SumLivingAreaSqFt][varchar](250)NULL,
		[SumGroundFloorSqFt][varchar](250)NULL,
		[SumGrossAreaSqFt][varchar](250)NULL,
		[SumAdjAreaSqFt][varchar](250)NULL,
		[AtticSqFt][varchar](250)NULL,
		[AtticUnfinishedSqFt][varchar](250)NULL,
		[AtticFinishedSqFt][varchar](250)NULL,
		[SumBasementSqFt][varchar](250)NULL,
		[BasementUnfinishedSqFt][varchar](250)NULL,
		[BasementFinishedSqFt][varchar](250)NULL,
		[SumGarageSqFt][varchar](250)NULL,
		[GarageUnFinishedSqFt][varchar](250)NULL,
		[GarageFinishedSqFt][varchar](250)NULL,
		[YearBuilt][varchar](250)NULL,
		[EffectiveYearBuilt][varchar](250)NULL,
		[Bedrooms][varchar](250)NULL,
		[BathTotalCalc][varchar](250)NULL,
		[BathFull][varchar](250)NULL,
		[BathsPartialNbr][varchar](250)NULL,
		[BathFixturesNbr][varchar](250)NULL,
		[Amenities][varchar](250)NULL,
		[AirConditioningCode][varchar](250)NULL,
		[BasementCode][varchar](250)NULL,
		[BuildingClassCode][varchar](250)NULL,
		[BuildingConditionCode][varchar](250)NULL,
		[ConstructionTypeCode][varchar](250)NULL,
		[DeckInd][varchar](250)NULL,
		[ExteriorWallsCode][varchar](250)NULL,
		[InteriorWallsCode][varchar](250)NULL,
		[FireplaceCode][varchar](250)NULL,
		[FloorCoverCode][varchar](250)NULL,
		[Garage][varchar](250)NULL,
		[HeatCode][varchar](250)NULL,
		[HeatingFuelTypeCode][varchar](250)NULL,
		[SiteInfluenceCode][varchar](250)NULL,
		[GarageParkingNbr][varchar](250)NULL,
		[DrivewayCode][varchar](250)NULL,
		[OtherRooms][varchar](250)NULL,
		[PatioCode][varchar](250)NULL,
		[PoolCode][varchar](250)NULL,
		[PorchCode][varchar](250)NULL,
		[BuildingQualityCode][varchar](250)NULL,
		[RoofCoverCode][varchar](250)NULL,
		[RoofTypeCode][varchar](250)NULL,
		[SewerCode][varchar](250)NULL,
		[StoriesNbrCode][varchar](250)NULL,
		[SumResidentialUnits][varchar](250)NULL,
		[SumBuildingsNbr][varchar](250)NULL,
		[SumCommercialUnits][varchar](250)NULL,
		[TopographyCode][varchar](250)NULL,
		[WaterCode][varchar](250)NULL,
		[LotCode][varchar](250)NULL,
		[LotNbr][varchar](250)NULL,
		[LandLot][varchar](250)NULL,
		[Block][varchar](250)NULL,
		[Section][varchar](250)NULL,
		[District][varchar](250)NULL,
		[LegalUnit][varchar](250)NULL,
		[Municipality][varchar](250)NULL,
		[SubdivisionName][varchar](250)NULL,
		[LegalDescription][varchar](2000)NULL,
		[CurrentSaleTransactionId][varchar](250)NULL,
		[CurrentSaleDocNbr][varchar](250)NULL,
		[CurrentSaleBook][varchar](250)NULL,
		[CurrentSalePage][varchar](250)NULL,
		[CurrentSaleRecordingDate][varchar](250)NULL,
		[CurrentSaleContractDate][varchar](250)NULL,
		[CurrentSaleDocumentType][varchar](250)NULL,
		[CurrentSalesPrice][varchar](250)NULL,
		[CurrentSalesPriceCode][varchar](250)NULL,
		[CurrentSaleBuyer1FullName][varchar](250)NULL,
		[CurrentSaleBuyer2FullName][varchar](250)NULL,
		[CurrentSaleSeller1FullName][varchar](250)NULL,
		[CurrentSaleSeller2FullName][varchar](250)NULL,
		[ConcurrentMtg1DocNbr][varchar](250)NULL,
		[ConcurrentMtg1Book][varchar](250)NULL,
		[ConcurrentMtg1Page][varchar](250)NULL,
		[ConcurrentMtg1RecordingDate][varchar](250)NULL,
		[ConcurrentMtg1LoanAmt][varchar](250)NULL,
		[ConcurrentMtg1Lender][varchar](250)NULL,
		[ConcurrentMtg1Term][varchar](250)NULL,
		[ConcurrentMtg1InterestRate][varchar](250)NULL,
		[ConcurrentMtg1LoanDueDate][varchar](250)NULL,
		[ConcurrentMtg1AdjOrFix][varchar](250)NULL,
		[ConcurrentMtg1LoanType][varchar](250)NULL,
		[ConcurrentMtg1TypeFinancing][varchar](250)NULL,
		[ConcurrentMtg2DocNbr][varchar](250)NULL,
		[ConcurrentMtg2Book][varchar](250)NULL,
		[ConcurrentMtg2Page][varchar](250)NULL,
		[ConcurrentMtg2RecordingDate][varchar](250)NULL,
		[ConcurrentMtg2LoanAmt][varchar](250)NULL,
		[ConcurrentMtg2Lender][varchar](250)NULL,
		[ConcurrentMtg2Term][varchar](250)NULL,
		[ConcurrentMtg2InterestRate][varchar](250)NULL,
		[ConcurrentMtg2LoanDueDate][varchar](250)NULL,
		[ConcurrentMtg2AdjOrFix][varchar](250)NULL,
		[ConcurrentMtg2LoanType][varchar](250)NULL,
		[ConcurrentMtg2Typefinancing][varchar](250)NULL,
		[PrevSaleTransactionId][varchar](250)NULL,
		[PrevSaleDocNbr][varchar](250)NULL,
		[PrevSaleBook][varchar](250)NULL,
		[PrevSalePage][varchar](250)NULL,
		[PrevSaleRecordingDate][varchar](250)NULL,
		[PrevSaleContractDate][varchar](250)NULL,
		[PrevSaleDocumentType][varchar](250)NULL,
		[PrevSalesPrice][varchar](250)NULL,
		[PrevSalesPriceCode][varchar](250)NULL,
		[PrevSaleBuyer1FullName][varchar](250)NULL,
		[PrevSaleBuyer2FullName][varchar](250)NULL,
		[PrevSaleSeller1FullName][varchar](250)NULL,
		[PrevSaleSeller2FullName][varchar](250)NULL,
		[PrevMtg1DocNbr][varchar](250)NULL,
		[PrevMtg1Book][varchar](250)NULL,
		[PrevMtg1Page][varchar](250)NULL,
		[PrevMtg1RecordingDate][varchar](250)NULL,
		[PrevMtg1LoanAmt][varchar](250)NULL,
		[PrevMtg1Lender][varchar](250)NULL,
		[PrevMtg1Term][varchar](250)NULL,
		[PrevMtg1InterestRate][varchar](250)NULL,
		[PrevMtg1LoanDueDate][varchar](250)NULL,
		[PrevMtg1AdjRider][varchar](250)NULL,
		[PrevMtg1LoanType][varchar](250)NULL,
		[PrevMtg1TypeFinancing][varchar](250)NULL,
		[TotalOpenLienNbr][varchar](250)NULL,
		[TotalOpenLienAmt][varchar](250)NULL,
		[Mtg1TransactionId][varchar](250)NULL,
		[Mtg1RecordingDate][varchar](250)NULL,
		[Mtg1LoanAmt][varchar](250)NULL,
		[Mtg1Lender][varchar](250)NULL,
		[Mtg1PrivateLender][varchar](250)NULL,
		[Mtg1Term][varchar](250)NULL,
		[Mtg1LoanDueDate][varchar](250)NULL,
		[Mtg1AdjRider][varchar](250)NULL,
		[Mtg1LoanType][varchar](250)NULL,
		[Mtg1TypeFinancing][varchar](250)NULL,
		[Mtg1LienPosition][varchar](250)NULL,
		[Mtg2TransactionId][varchar](250)NULL,
		[Mtg2RecordingDate][varchar](250)NULL,
		[Mtg2LoanAmt][varchar](250)NULL,
		[Mtg2Lender][varchar](250)NULL,
		[Mtg2PrivateLender][varchar](250)NULL,
		[Mtg2Term][varchar](250)NULL,
		[Mtg2LoanDueDate][varchar](250)NULL,
		[Mtg2AdjRider][varchar](250)NULL,
		[Mtg2LoanType][varchar](250)NULL,
		[Mtg2TypeFinancing][varchar](250)NULL,
		[Mtg2LienPosition][varchar](250)NULL,
		[Mtg3TransactionId][varchar](250)NULL,
		[Mtg3RecordingDate][varchar](250)NULL,
		[Mtg3LoanAmt][varchar](250)NULL,
		[Mtg3Lender][varchar](250)NULL,
		[Mtg3PrivateLender][varchar](250)NULL,
		[Mtg3Term][varchar](250)NULL,
		[Mtg3LoanDueDate][varchar](250)NULL,
		[Mtg3AdjRider][varchar](250)NULL,
		[Mtg3LoanType][varchar](250)NULL,
		[Mtg3TypeFinancing][varchar](250)NULL,
		[Mtg3LienPosition][varchar](250)NULL,
		[Mtg4TransactionId][varchar](250)NULL,
		[Mtg4RecordingDate][varchar](250)NULL,
		[Mtg4LoanAmt][varchar](250)NULL,
		[Mtg4Lender][varchar](250)NULL,
		[Mtg4PrivateLender][varchar](250)NULL,
		[Mtg4Term][varchar](250)NULL,
		[Mtg4LoanDueDate][varchar](250)NULL,
		[Mtg4AdjRider][varchar](250)NULL,
		[Mtg4LoanType][varchar](250)NULL,
		[Mtg4TypeFinancing][varchar](250)NULL,
		[Mtg4LienPosition][varchar](250)NULL,
		[CurrentAVMValue][varchar](250)NULL,
		[vLowValue][varchar](250)NULL,
		[vHighValue][varchar](250)NULL,
		[vConfidenceScore][varchar](250)NULL,
		[vStandardDeviation][varchar](250)NULL,
		[vValuationDate][varchar](250)NULL,
		[VacantFlag][varchar](250)NULL,
		[VacantFlagDate][varchar](250)NULL,
		[FATimeStamp][varchar](250)NULL,
		[FARecordType][varchar](250)NULL,
		------Added 20210603---
		[FARooftopLatitude][float]NULL,
		[FARooftopLongitude][float]NULL
		
) ON [PRIMARY] 

 
	 INSERT INTO [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT]
			Select 
			A.RAW_ID as [REDASH_ID]
			,B.[FIPS] as [FIPS]
		,B.[PropertyID] as [PropertyID]
		,B.[FormattedAPN] as [APN]
		,B.[TaxAccountNumber] as [TaxAccountNumber]
		,B.[SitusStdFullStreetAddress] as [SitusFullStreetAddress]
		,B.[SitusStdHouseNbr] as [SitusHouseNbr]
		,B.[SitusStdHouseNbrSuffix] as [SitusHouseNbrSuffix]
		,B.[SitusStdDirectionLeft] as [SitusDirectionLeft]
		,B.[SitusStdStreet] as [SitusStreet]
		,B.[SitusStdMode] as [SitusMode]
		,B.[SitusStdDirectionRight] as [SitusDirectionRight]
		,B.[SitusStdUnitType] as [SitusUnitType]
		,B.[SitusStdUnitNbr] as [SitusUnitNbr]
		,B.[SitusStdCity] as [SitusCity]
		,B.[SitusStdState] as [SitusState]
		,B.[SitusStdZIP5] as [SitusZIP5]
		,B.[SitusLatitude] as [SitusLatitude]
		,B.[SitusLongitude] as [SitusLongitude]
		,B.[SitusGeoStatusCode] as [SitusGeoStatusCode]
		,B.[PropertyClassID] as [PropertyClassID]
		,B.[StdLandUseCode] as [LandUseCode]
		,B.[CountyLandUseCode] as [CountyLandUseCode]
		,B.[Zoning] as [Zoning]
		,B.[MobileHomeInd] as [MobileHomeInd]
		,B.[SchoolDistrictName] as [SchoolDistrictName]
		,B.[LotSizeFrontageFeet] as [LotSizeFrontageFeet]
		,B.[LotSizeDepthFeet] as [LotSizeDepthFeet]
		,B.[LotSizeAcres] as [LotSizeAcres]
		,B.[LotSizeSqFt] as [LotSizeSqFt]
		,B.[OwnerStd1CorpInd] as [Owner1CorpInd]
		,B.[OwnerStd1LastName] as [Owner1LastName]
		,B.[OwnerStd1FirstName] as [Owner1FirstName]
		,B.[OwnerStd1MiddleName] as [Owner1MiddleName]
		,B.[OwnerStd1Suffix] as [Owner1Suffix]
		,B.[OwnerStd2CorpInd] as [Owner2CorpInd]
		,B.[OwnerStd2LastName] as [Owner2LastName]
		,B.[OwnerStd2FirstName] as [Owner2FirstName]
		,B.[OwnerStd2MiddleName] as [Owner2MiddleName]
		,B.[OwnerStd2Suffix] as [Owner2Suffix]
		,B.[OwnerStdNAME1FULL] as [OwnerNAME1FULL]
		,B.[OwnerStdNAME2FULL] as [OwnerNAME2FULL]
		,B.[OwnerOccupied] as [OwnerOccupied]
		,B.[OwnerStd1OwnershipRights] as [Owner1OwnershipRights]
		,B.[MailingStdFullStreetAddress] as [MailingFullStreetAddress]
		,B.[MailingStdHouseNbr] as [MailingHouseNbr]
		,B.[MailingStdHouseNbrSuffix] as [MailingHouseNbrSuffix]
		,B.[MailingStdDirectionLeft] as [MailingDirectionLeft]
		,B.[MailingStdStreet] as [MailingStreet]
		,B.[MailingStdMode] as [MailingMode]
		,B.[MailingStdDirectionRight] as [MailingDirectionRight]
		,B.[MailingStdUnitType] as [MailingUnitType]
		,B.[MailingStdUnitNbr] as [MailingUnitNbr]
		,B.[MailingStdCity] as [MailingCity]
		,B.[MailingStdState] as [MailingState]
		,B.[MailingStdZIP5] as [MailingZIP5]
		,B.[MailingOptOut] as [MailingOptOut]
		,B.[MailingCareOfName] as [MailingCOName]
		,B.[AssdTotalValue] as [AssdTotalValue]
		,B.[AssdLandValue] as [AssdLandValue]
		,B.[AssdImprovementValue] as [AssdImprovementValue]
		,B.[MarketTotalValue] as [MarketTotalValue]
		,B.[MarketValueLand] as [MarketValueLand]
		,B.[MarketValueImprovement] as [MarketValueImprovement]
		,B.[TaxAmount] as [TaxAmt]
		,B.[TaxYear] as [TaxYear]
		,B.[TaxDeliquentYear1] as [TaxDeliquentYear]
		,B.[MarketValueYear] as [MarketYear]
		,B.[AssdYear] as [AssdYear]
		,B.[TaxRateCodeArea] as [TaxRateCodeArea]
		,B.[SchoolTaxDistrict1Code] as [SchoolTaxDistrict1Code]
		,B.[SchoolTaxDistrict2Code] as [SchoolTaxDistrict2Code]
		,B.[SchoolTaxDistrict3Code] as [SchoolTaxDistrict3Code]
		,B.[HomesteadInd] as [HomesteadInd]
		,B.[VeteranInd] as [VeteranInd]
		,B.[DisabledInd] as [DisabledInd]
		,B.[WidowInd] as [WidowInd]
		,B.[SeniorInd] as [SeniorInd]
		,B.[SchoolCollegeInd] as [SchoolCollegeInd]
		,B.[ReligiousInd] as [ReligiousInd]
		,B.[WelfareInd] as [WelfareInd]
		,B.[PublicUtilityInd] as [PublicUtilityInd]
		,B.[CemeteryInd] as [CemeteryInd]
		,B.[HospitalInd] as [HospitalInd]
		,B.[LibraryInd] as [LibraryInd]
		,B.[BuildingArea] as [BuildingArea]
		,B.[BuildingAreaInd] as [BuildingAreaInd]
		,B.[SumBuildingSqFt] as [SumBuildingSqFt]
		,B.[SumLivingAreaSqFt] as [SumLivingAreaSqFt]
		,B.[SumGroundFloorSqFt] as [SumGroundFloorSqFt]
		,B.[SumGrossAreaSqFt] as [SumGrossAreaSqFt]
		,B.[SumAdjAreaSqFt] as [SumAdjAreaSqFt]
		,B.[AtticSqFt] as [AtticSqFt]
		,B.[AtticUnfinSqFt] as [AtticUnfinishedSqFt]
		,B.[AtticFinishSqFt] as [AtticFinishedSqFt]
		,B.[SumBasementSqFt] as [SumBasementSqFt]
		,B.[BasementUnfinSqFt] as [BasementUnfinishedSqFt]
		,B.[BasementFinishSqFt] as [BasementFinishedSqFt]
		,B.[SumGarageSqFt] as [SumGarageSqFt]
		,B.[GarageUnFinSqFt] as [GarageUnFinishedSqFt]
		,B.[GarageFinishSqFt] as [GarageFinishedSqFt]
		,B.[YearBuilt] as [YearBuilt]
		,B.[EffectiveYearBuilt] as [EffectiveYearBuilt]
		,B.[Bedrooms] as [Bedrooms]
		,B.[BathTotalCalc] as [BathTotalCalc]
		,B.[BathFull] as [BathFull]
		,B.[BathsParcialNbr] as [BathsPartialNbr]
		,B.[BathFixturesNbr] as [BathFixturesNbr]
		,B.[Amenities] as [Amenities]
		,B.[AirConditioningCode] as [AirConditioningCode]
		,B.[BasementCode] as [BasementCode]
		,B.[BuildingClassCode] as [BuildingClassCode]
		,B.[BuildingConditionCode] as [BuildingConditionCode]
		,B.[ConstructionTypeCode] as [ConstructionTypeCode]
		,B.[DeckCode] as [DeckInd]
		,B.[ExteriorWallsCode] as [ExteriorWallsCode]
		,B.[InteriorWallsCode] as [InteriorWallsCode]
		,B.[FireplaceCode] as [FireplaceCode]
		,B.[FloorCoverCode] as [FloorCoverCode]
		,B.[Garage] as [Garage]
		,B.[HeatCode] as [HeatCode]
		,B.[HeatingFuelTypeCode] as [HeatingFuelTypeCode]
		,B.[SiteInfluenceCode] as [SiteInfluenceCode]
		,B.[GarageParkingNbr] as [GarageParkingNbr]
		,B.[DrivewayCode] as [DrivewayCode]
		,B.[OtherRooms] as [OtherRooms]
		,B.[PatioCode] as [PatioCode]
		,B.[PoolCode] as [PoolCode]
		,B.[PorchCode] as [PorchCode]
		,B.[BuildingQualityCode] as [BuildingQualityCode]
		,B.[RoofCoverCode] as [RoofCoverCode]
		,B.[RoofTypeCode] as [RoofTypeCode]
		,B.[SewerCode] as [SewerCode]
		,B.[StoriesNbrCode] as [StoriesNbrCode]
		,B.[SumResidentialUnits] as [SumResidentialUnits]
		,B.[SumBuildingsNbr] as [SumBuildingsNbr]
		,B.[SumCommercialUnits] as [SumCommercialUnits]
		,B.[TopographyCode] as [TopographyCode]
		,B.[WaterCode] as [WaterCode]
		,B.[LotCode] as [LotCode]
		,B.[LotNumber] as [LotNbr]
		,B.[LandLot] as [LandLot]
		,B.[Block] as [Block]
		,B.[Section] as [Section]
		,B.[District] as [District]
		,B.[LegalUnit] as [LegalUnit]
		,B.[Municipality] as [Municipality]
		,B.[SubdivisionName] as [SubdivisionName]
		,B.[LegalDescription] as [LegalDescription]
		,B.[CurrentSaleTransactionId] as [CurrentSaleTransactionId]
		,B.[CurrSaleInputDocNbr] as [CurrentSaleDocNbr]
		,B.[CurrSaleInputBook] as [CurrentSaleBook]
		,B.[CurrSaleInputPage] as [CurrentSalePage]
		,B.[CurrSaleRecordingDate] as [CurrentSaleRecordingDate]
		,B.[CurrSaleContractDate] as [CurrentSaleContractDate]
		,B.[CurrSaleDocumentType] as [CurrentSaleDocumentType]
		,B.[CurrSalesPrice] as [CurrentSalesPrice]
		,B.[CurrSalesPriceCode] as [CurrentSalesPriceCode]
		,B.[CurrSaleBuyer1FullName] as [CurrentSaleBuyer1FullName]
		,B.[CurrSaleBuyer2FullName] as [CurrentSaleBuyer2FullName]
		,B.[CurrSaleSeller1FullName] as [CurrentSaleSeller1FullName]
		,B.[CurrSaleSeller2FullName] as [CurrentSaleSeller2FullName]
		,B.[ConCurrMtg1InputDocNbr] as [ConcurrentMtg1DocNbr]
		,B.[ConCurrMtg1InputBook] as [ConcurrentMtg1Book]
		,B.[ConCurrMtg1InputPage] as [ConcurrentMtg1Page]
		,B.[ConCurrMtg1RecordingDt] as [ConcurrentMtg1RecordingDate]
		,B.[ConCurrMtg1LoanAmt] as [ConcurrentMtg1LoanAmt]
		,B.[ConCurrMtg1Lender] as [ConcurrentMtg1Lender]
		,B.[ConCurrMtg1Term] as [ConcurrentMtg1Term]
		,B.[ConCurrMtg1InterestRate] as [ConcurrentMtg1InterestRate]
		,B.[ConCurrMtg1LoanDueDt] as [ConcurrentMtg1LoanDueDate]
		,B.[ConCurrMtg1AdjOrFix] as [ConcurrentMtg1AdjOrFix]
		,B.[ConCurrMtg1LoanType] as [ConcurrentMtg1LoanType]
		,B.[ConCurrMtg1Typefinancing] as [ConcurrentMtg1TypeFinancing]
		,B.[ConCurrMtg2InputDocNbr] as [ConcurrentMtg2DocNbr]
		,B.[ConCurrMtg2InputBook] as [ConcurrentMtg2Book]
		,B.[ConCurrMtg2InputPage] as [ConcurrentMtg2Page]
		,B.[ConCurrMtg2RecordingDt] as [ConcurrentMtg2RecordingDate]
		,B.[ConCurrMtg2LoanAmt] as [ConcurrentMtg2LoanAmt]
		,B.[ConCurrMtg2Lender] as [ConcurrentMtg2Lender]
		,B.[ConCurrMtg2Term] as [ConcurrentMtg2Term]
		,B.[ConCurrMtg2InterestRate] as [ConcurrentMtg2InterestRate]
		,B.[ConCurrMtg2LoanDueDt] as [ConcurrentMtg2LoanDueDate]
		,B.[ConCurrMtg2AdjOrFix] as [ConcurrentMtg2AdjOrFix]
		,B.[ConCurrMtg2LoanType] as [ConcurrentMtg2LoanType]
		,B.[ConCurrMtg2Typefinancing] as [ConcurrentMtg2Typefinancing]
		,B.[PrevSaleTransactionId] as [PrevSaleTransactionId]
		,B.[PrevSaleInputDocNbr] as [PrevSaleDocNbr]
		,B.[PrevSaleInputBook] as [PrevSaleBook]
		,B.[PrevSaleInputPage] as [PrevSalePage]
		,B.[PrevSaleRecordingDate] as [PrevSaleRecordingDate]
		,B.[PrevSaleContractDate] as [PrevSaleContractDate]
		,B.[PrevSaleDocumentType] as [PrevSaleDocumentType]
		,B.[PrevSalesPrice] as [PrevSalesPrice]
		,B.[PrevSalesPriceCode] as [PrevSalesPriceCode]
		,B.[PrevSaleBuyer1FullName] as [PrevSaleBuyer1FullName]
		,B.[PrevSaleBuyer2FullName] as [PrevSaleBuyer2FullName]
		,B.[PrevSaleSeller1FullName] as [PrevSaleSeller1FullName]
		,B.[PrevSaleSeller2FullName] as [PrevSaleSeller2FullName]
		,B.[PrevMtg1InputDocNbr] as [PrevMtg1DocNbr]
		,B.[PrevMtg1InputBook] as [PrevMtg1Book]
		,B.[PrevMtg1InputPage] as [PrevMtg1Page]
		,B.[PrevMtg1RecordingDt] as [PrevMtg1RecordingDate]
		,B.[PrevMtg1LoanAmt] as [PrevMtg1LoanAmt]
		,B.[PrevMtg1Lender] as [PrevMtg1Lender]
		,B.[PrevMtg1Term] as [PrevMtg1Term]
		,B.[PrevMtg1InterestRate] as [PrevMtg1InterestRate]
		,B.[PrevMtg1LoanDueDt] as [PrevMtg1LoanDueDate]
		,B.[PrevMtg1AdjRider] as [PrevMtg1AdjRider]
		,B.[PrevMtg1LoanType] as [PrevMtg1LoanType]
		,B.[PrevMtg1Typefinancing] as [PrevMtg1TypeFinancing]
		,B.[TotalOpenLienNbr] as [TotalOpenLienNbr]
		,B.[TotalOpenLienAmt] as [TotalOpenLienAmt]
		,B.[Mtg1TransactionId] as [Mtg1TransactionId]
		,B.[Mtg1RecordingDt] as [Mtg1RecordingDate]
		,B.[Mtg1LoanAmt] as [Mtg1LoanAmt]
		,B.[Mtg1Lender] as [Mtg1Lender]
		,B.[Mtg1PrivateLender] as [Mtg1PrivateLender]
		,B.[Mtg1Term] as [Mtg1Term]
		,B.[Mtg1LoanDueDt] as [Mtg1LoanDueDate]
		,B.[Mtg1AdjRider] as [Mtg1AdjRider]
		,B.[Mtg1LoanType] as [Mtg1LoanType]
		,B.[Mtg1Typefinancing] as [Mtg1TypeFinancing]
		,B.[Mtg1LienPosition] as [Mtg1LienPosition]
		,B.[Mtg2TransactionId] as [Mtg2TransactionId]
		,B.[Mtg2RecordingDt] as [Mtg2RecordingDate]
		,B.[Mtg2LoanAmt] as [Mtg2LoanAmt]
		,B.[Mtg2Lender] as [Mtg2Lender]
		,B.[Mtg2PrivateLender] as [Mtg2PrivateLender]
		,B.[Mtg2Term] as [Mtg2Term]
		,B.[Mtg2LoanDueDt] as [Mtg2LoanDueDate]
		,B.[Mtg2AdjRider] as [Mtg2AdjRider]
		,B.[Mtg2LoanType] as [Mtg2LoanType]
		,B.[Mtg2Typefinancing] as [Mtg2TypeFinancing]
		,B.[Mtg2LienPosition] as [Mtg2LienPosition]
		,B.[Mtg3TransactionId] as [Mtg3TransactionId]
		,B.[Mtg3RecordingDt] as [Mtg3RecordingDate]
		,B.[Mtg3LoanAmt] as [Mtg3LoanAmt]
		,B.[Mtg3Lender] as [Mtg3Lender]
		,B.[Mtg3PrivateLender] as [Mtg3PrivateLender]
		,B.[Mtg3Term] as [Mtg3Term]
		,B.[Mtg3LoanDueDt] as [Mtg3LoanDueDate]
		,B.[Mtg3AdjRider] as [Mtg3AdjRider]
		,B.[Mtg3LoanType] as [Mtg3LoanType]
		,B.[Mtg3Typefinancing] as [Mtg3TypeFinancing]
		,B.[Mtg3LienPosition] as [Mtg3LienPosition]
		,B.[Mtg4TransactionId] as [Mtg4TransactionId]
		,B.[Mtg4RecordingDt] as [Mtg4RecordingDate]
		,B.[Mtg4LoanAmt] as [Mtg4LoanAmt]
		,B.[Mtg4Lender] as [Mtg4Lender]
		,B.[Mtg4PrivateLender] as [Mtg4PrivateLender]
		,B.[Mtg4Term] as [Mtg4Term]
		,B.[Mtg4LoanDueDt] as [Mtg4LoanDueDate]
		,B.[Mtg4AdjRider] as [Mtg4AdjRider]
		,B.[Mtg4LoanType] as [Mtg4LoanType]
		,B.[Mtg4Typefinancing] as [Mtg4TypeFinancing]
		,B.[Mtg4LienPosition] as [Mtg4LienPosition]
		,B.[FirstAmericanCurrentAVM] as [CurrentAVMValue]
		,B.[Low_Value] as [vLowValue]
		,B.[High_Value] as [vHighValue]
		,B.[ConfidenceScore] as [vConfidenceScore]
		,B.[StandardDeviation] as [vStandardDeviation]
		,B.[VALUATIONDATE] as [vValuationDate]
		,B.[VacantFlag] as [VacantFlag]
		,B.[VacantFlagDate] as [VacantFlagDate]
		,B.[FATimestamp] as [FATimeStamp]
		,B.[FAUCIDFlag] as [FARecordType]
		----Added 20210603 Per CR--
		,B.[FARooftopLatitude]
		,B.[FARooftopLongitude]


		From [zCust_PropertyOnion].[dbo].[a_PropMatch_WORK_FLANK] as A
		left outer join [data].[dbo].[vAssessor_PREMIUM_NEW] as B with(NOLOCK) on 
		A.FIPS = B.FIPS
		and A.PropertyID = B.PropertyID

		

		Select count(*) From [zCust_PropertyOnion].[dbo].[x_Custom_OUTPUT]
		Select count(*) From [zCust_PropertyOnion].[dbo].[a_PropMatch_WORK_FLANK]

	--Select * From INPUT_RAW_PROPERTYONION_20200827

	--------PFC----
	--Select 
	--A.RAW_ID as [PropertyOnion ID]
	--,B.FIPS as [FIPS]
	--,B.TransactionId as [FATransactionID]
	--,B.APN as [APN]
	--,B.MultiAPNCode as [MultiAPN]
	--,B.SitusFullStreetAddress as [SitusFullStreetAddress]
	--,B.SitusStdHouseNbr as [SitusHouseNbr]
	--,B.SitusStdHouseNbrSuffix as [SitusHouseNbrSuffix]
	--,B.SitusStdDirectionLeft as [SitusDirectionLeft]
	--,B.SitusStdStreet as [SitusStreet]
	--,B.SitusStdMode as [SitusMode]
	--,B.SitusStdDirectionRight as [SitusDirectionRight]
	--,B.SitusStdUnitType as [SitusUnitType]
	--,B.SitusStdUnitNbr as [SitusUnitNbr]
	--,B.SitusStdCity as [SitusCity]
	--,B.SitusStdState as [SitusState]
	--,B.SitusStdZIP5 as [SitusZIP5]
	--,B.SitusStdZIP4 as [SitusZIP4]
	--,B.SitusStdCarrierCode as [SitusCarrierCode]
	--,B.RecordingDt as [RecordingDate]
	--,B.DocNbrSrce as [DocumentNbr]
	--,B.BookSrce as [RecordingBook]
	--,B.PageSrce as [RecordingPage]
	--,B.DocumentType as [DocumentType]
	--,B.LoanNumber as [LoanNumber]
	--,B.CaseNumber as [CaseNumber]
	--,B.DefaultDate as [DefaultDate]
	--,B.UnpaidBalance as [UnpaidBalance]
	--,B.PastDueAmount as [PastDueAmount]
	--,B.PaymentDueDt as [DueDate]
	--,B.CurrentBeneficiary as [CurrentLenderName]
	--,B.AuctionDate as [AuctionDate]
	--,B.AuctionTime as [AuctionTime]
	--,B.AuctionLocation as [AuctionLocation]
	--,B.AuctionCity as [AuctionCity]
	--,B.AuctionMinBidAmt as [AuctionMinimumBidAmount]
	--,B.OrigNODRecordingDt as [OriginalNODRecordingDate]
	--,B.OrigNODDocumentNbr as [OriginalNODDocumentNumber]
	--,B.OrigNODBook as [OriginalNODBookNumber]
	--,B.OrigNODPage as [OriginalNODPageNumber]
	--,B.LoanRecordingDt as [LoanRecordingDate]
	--,B.LoanContractDt as [OriginalDateofContract]
	--,B.LoanDocumentNbr as [LoanDocumentNumber]
	--,B.LoanBook as [LoanBookNumber]
	--,B.LoanPage as [LoanPageNumber]
	--,B.OrigBeneficiaryLender as [OriginalLenderName]
	--,B.OrigLoanAmt as [OriginalLoanAmount]
	--,B.TitleCompany as [TitleCompany]
	--,B.ContactInputFirstMiddleName as [ContactFirstName&MiddleName]
	--,B.ContactInputLastNameOrCorp as [ContactLastNameORCorporationName]
	--,B.MailAttentionTo as [MailAttentionTo]
	--,B.MailingFullStreetAddress as [MailingFullStreetAddress]
	--,B.MailingHouseNbr as [MailingHouseNbr]
	--,B.MailingHouseNbrSuffix as [MailingHouseNbrSuffix]
	--,B.MailingDirectionLeft as [MailingDirectionLeft]
	--,B.MailingStreet as [MailingStreet]
	--,B.MailingMode as [MailingMode]
	--,B.MailingDirectionRight as [MailingDirectionRight]
	--,B.MailingUnitType as [MailingUnitType]
	--,B.MailingUnitNbr as [MailingUnitNbr]
	--,B.MailingCity as [MailingCity]
	--,B.MailingState as [MailingState]
	--,B.MailingZIP5 as [MailingZIP5]
	--,B.MailingZIP4 as [MailingZIP4]
	--,B.TrusteePhone as [TrusteeTelephoneNumber]
	--,B.TrusteeFullAddress as [TrusteeFullStreetAddress]
	--,B.TrusteeAptNumber as [TrusteeUnitNumber]
	--,B.TrusteeCity as [TrusteeCityName]
	--,B.TrusteeState as [TrusteeStateCode]
	--,B.TrusteeZip5 as [TrusteeZipCode]
	--,B.TrusteeZip4 as [TrusteeZipplus4]
	--,B.TrusteeFirstNameMiddleInitial as [TrusteeFirstName&MiddleInitial]
	--,B.TrusteeLastNameorCorp as [TrusteeLastNameORCorporationName]
	--,B.TrusteeMailCareOfName as [TrusteeCareofName]
	--,B.TrusteeSalesNumber as [TrusteeSaleNumber]
	--,B.TrustOrBorrower1FirstNameMi as [Borrower1FirstName&MiddleName]
	--,B.TrustOrBorrower1LastNameOrCorp as [Borrower1LastNameORCorporationName]
	--,B.TrustOrBorrower2FirstNameMi as [Borrower2FirstName&MiddleName]
	--,B.TrustOrBorrower2LlstNameOrCorp as [Borrower2LastNameORCorporationName]
	--,B.NODLegalSubdivision as [SubdivisionName]
	--,B.NODLegalBlock as [Block]
	--,B.NODLegalBriefDescr as [LegalDescription]
	--,B.NODLegalLot as [LotNumber]
	--,B.FAPropertyId as [PropertyID]
	--,B.FADeedId as [DeedFATransactionID]
	--,B.FASAMId as [MortgageFATransactionID]
	--,B.FATimestamp as [FATimeStamp]
	--,B.FAUCIDFlag as [FARecordType]
	--,B.PFCType as [PFCType]

	--From dbo.a_PropMatch_WORK_FLANK as A
	--left outer join data.dbo.vForeclosure as B with(NOLOCK) on 
	--A.FIPS = B.FIPS
	--and A.PropertyID = B.FAPropertyID
	--where B.FAUCIDFLAG not like 'D'




END





