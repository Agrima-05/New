/* Source: DWS-ETL02.DATATREE.LOCAL | Pet | pet_dbo.usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr | type=P | staged_for_host_folder=AZUVPSQLDTDB009.datatree.local (package runs on AZUVPSQLDTDB009.datatree.local / execution SQL) */

-- =============================================  
-- Author:        <Author,,Name>  
-- Create date: <Create Date,,>   
-- Description:   <Description,,>  
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'  
-- =============================================  
CREATE PROCEDURE [PET].[pet_dbo].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_INCR] @fips INT = NULL
	,@FeatureName AS VARCHAR(50) = NULL
	,@ServiceName AS VARCHAR(50) = NULL
	,@FormatId AS VARCHAR(10) = NULL
	,@Incremental_Flag BIT
AS
--Set @FormatId = Case when @fips in (6059,6065) then 'TT' else @FormatId end  
EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr'
	,N'Started'

DECLARE @GetDynamicFormat tmpGetDynamicFormat

--SET @Incremental_Flag = isnull(@Incremental_Flag, 0)  
INSERT INTO @GetDynamicFormat (
	[FeatureName]
	,[ServiceName]
	,[FormatId]
	,[SubFormatId]
	,[Field]
	,[Offset]
	,[Length]
	,[Justification]
	,[PadChar]
	,[FollowSuffixRule]
	,[IsThruField]
	,[OutputField]
	,[LongDesc]
	,[Label]
	,[MsgLabel]
	,[Partner]
	,[PartnerType]
	,[WildStart]
	,[DataType]
	,[Required]
	,[Enumeration]
	,[TabIndex]
	,[FromField]
	,[DataTreeIndexes]
	,[FormatChar]
	,[_overlay]
	,[ROW4]
	)
EXEC [pet].[dbo].[GetDynamicFormat] @FeatureName --'TITLE_SERVICES'  
	,@ServiceName --'SUBDIVIDED'  
	,@FormatId --@PPLNT_PLAT_ID_FRMT  

UPDATE [PET].[pet_dbo].[t1]
SET t1._overlay = (
		SELECT count(1)
		FROM @GetDynamicFormat t2
		WHERE t2.ROW4 < t1.ROW4
			AND t1.Offset BETWEEN t2.Offset
				AND (t2.Offset + t2.[Length])
		)
FROM @GetDynamicFormat t1

SELECT 'Subdivided parms' AS aaaa
	,*
FROM @GetDynamicFormat

DECLARE @year_pos INT = (
		SELECT p.offset
		FROM @GetDynamicFormat p
		WHERE p.Field = 'Year'
		)
	,@Ref_id INT = NULL --13580129  

DROP TABLE

IF EXISTS [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr_temp]
	SELECT DISTINCT a.REF_ID
		,a.neo_apn
		,a.NEO_LAND_TYPE
		,a.NEO_TITLE_LEGAL
		--,/*CASE   
		-- WHEN ltrim(Rtrim(a._field)) = 'TorTeeNAme'  
		--  THEN*/ CASE   
		--    WHEN substring(a._field, len(a._field), 1) = '1' and ltrim(Rtrim(a._field)) = 'TorTeeNAme'  
		--     THEN 'GrantorName'  
		--    WHEN substring(a._field, len(a._field), 1) = '2' and ltrim(Rtrim(a._field)) = 'TorTeeNAme'  
		--     THEN 'GranteeName'  
		--    ELSE a._field  
		--    END  
		-- /*ELSE a._field*/ AS _field  
		----,Replace(Replace(Replace(ltrim(a._value), 'T', ''), 'C', ''), 'M', '') AS _value  
		,CASE 
			WHEN ltrim(Rtrim(a._field)) = 'TorTeeNAme'
				THEN CASE 
						WHEN substring(a._field, len(a._field), 1) = '1'
							THEN 'GrantorName'
						WHEN substring(a._field, len(a._field), 1) = '2'
							THEN 'GranteeName'
						ELSE a._field
						END
			ELSE a._field
			END AS _field
		,CASE 
			WHEN a._field IN (
					'Book'
					,'Tract'
					)
				THEN CASE 
						WHEN substring(ltrim(a._value), 1, 1) IN (
								'A'
								,'C'
								,'G'
								,'Q'
								,'T'
								,'X'
								,'W'
								)
							AND @fips IN (
								6001
								,6093
								,6013
								,6029
								,6037
								,6059
								,6065
								,6083
								,6071
								,6075
								,6073
								,6081
								,6111
								)
							THEN substring(ltrim(a._value), 2, 10)
								-- WHEN substring(ltrim(a._value), 1, 1) IN ('A','C','G','T','X') AND @fips = 6065  
								--THEN substring(ltrim(a._value), 2, 10)  
						ELSE a._value
						END
			ELSE a._value
			END AS _value
		,CASE 
			WHEN a._field IN (
					'Book'
					,'Tract'
					)
				THEN CASE 
						WHEN substring(ltrim(a._value), 1, 1) IN (
								'A'
								,'C'
								,'G'
								,'Q'
								,'T'
								,'X'
								,'W'
								)
							AND @fips IN (
								6001
								,6093
								,6013
								,6029
								,6037
								,6059
								,6065
								,6083
								,6071
								,6075
								,6073
								,6081
								,6111
								)
							THEN substring(ltrim(a._value), 1, 1)
						ELSE ''
						END
			ELSE ' '
			END AS bookType
		,a.fips
		,a.ROW4
	INTO [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr_temp]
	FROM (
		SELECT -- top 100   
			t.REF_ID
			,t.neo_apn
			,t.NEO_LAND_TYPE
			,t.NEO_TITLE_LEGAL AS NEO_TITLE_LEGAL
			,t.Fips
			,p.ROW4
			,CASE 
				WHEN substring(ltrim(t.NEO_TITLE_LEGAL), 1, 1) IN (
						'T'
						,'W'
						)
					AND Field = 'Book'
					THEN 'Tract'
				WHEN substring(ltrim(t.NEO_TITLE_LEGAL), 1, 1) IN (
						'T'
						,'W'
						)
					AND Field = 'Page'
					THEN 'TractId'
				WHEN substring(ltrim(t.NEO_TITLE_LEGAL), 1, 1) IN (/*'T',*/ 'W')
					AND Field = 'Sublot'
					THEN 'Unit'
				ELSE Field
				END AS _field
			--,CASE   
			-- WHEN @year_pos <> 0  
			--  AND isdate(substring(t.NEO_TITLE_LEGAL, @year_pos, 4)) = 1  
			--  AND p.Field IN ('Year','Instrument')  
			--  OR (  
			--   isdate(substring(t.NEO_TITLE_LEGAL, @year_pos, 4)) = 0  
			--   AND p.Field IN ('Book','PAge')  
			--   )  
			--  OR (  
			--   p.Field NOT IN ('Book','PAge','Year','Instrument')  
			--   )  
			--  THEN substring(t.NEO_TITLE_LEGAL, Offset, [Length]) -- it is Year and Document  
			-- END AS _value  
			,CASE 
				WHEN (
						tt._year_instrument = 'year'
						AND p.Field NOT IN (
							'book'
							,'Page'
							)
						)
					OR (
						tt._year_instrument = 'book'
						AND p.Field NOT IN (
							'Year'
							,'Instrument'
							)
						)
					THEN substring(t.NEO_TITLE_LEGAL, Offset, [Length])
				ELSE NULL
				END AS _value

		from  [PET].[pet_tmp].[Pet_Incremental_Add] incr WITH (NOLOCK,INDEX (idx_fips_neoAPN))
		cross APPLY (
			SELECT *
			FROM [pet].[dbo].[PET_neo_legals] t WITH (
					NOLOCK
					,INDEX (ix_fipsNEO)
					)
			WHERE t.fips = incr.fips
				AND t.neo_apn = incr.neo_apn
				and t.NEO_TITLE_LEGAL = incr.NEO_TITLE_LEGAL
				AND t.NEO_LAND_TYPE IN ('SB')
			) t

		OUTER APPLY (
			SELECT CASE 
					WHEN @year_pos <> 0
						AND substring(t.NEO_TITLE_LEGAL, @year_pos + 4, 1) = ''
						AND isdate(substring(t.NEO_TITLE_LEGAL, @year_pos, 4)) = 1
						THEN 'year'
					ELSE 'book'
					END AS _year_instrument
			) tt
		OUTER APPLY (
			SELECT *
			FROM @GetDynamicFormat -- where _overlay = 0   
			) p
	
		WHERE incr.fips = @fips
			AND incr.NEO_LAND_TYPE IN ('SB')
			--AND (
			--	@ref_id IS NULL
			--	OR t.ref_id = @ref_id
			--	)
			--AND(  
			-- @Incremental_Flag = 0  
			-- OR (  
			--  @Incremental_Flag = 1  
			--  AND incr.neo_apn IS NOT NULL  
			-- )  
			--)  
		) a
	WHERE isnull(a._value, '') > ''

/*  
'      C11189 1385          3435     P                       '  
 123456789012345678901234567890123456789012345678901234567890  
          1         2         3         4         5         6  
SELECT * FROM @GetDynamicFormat   
Select * from pet.pet_tmp.usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr_temp where _value = ''  
  
--truncate table [PET].[dbo].[Pet_LabelColumns]  
*/
CREATE UNIQUE INDEX ix_fips_ref_id_field ON [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr_temp] (
	fips
	,Ref_id
	,neo_apn
	,NEO_TITLE_LEGAL
	,_Field
	)

INSERT INTO [PET].[dbo].[Pet_LabelColumns_Multi_Legals] (
	[Fips]
	,[NEO_APN]
	,[REF_ID]
	,[NEO_LAND_TYPE]
	,[NEO_TITLE_LEGAL]
	,[_field]
	,[_value]
	,[row4]
	,[BookType]
	)
SELECT b.fips
	,b.NEO_APN
	,b.[REF_ID]
	,b.[NEO_LAND_TYPE]
	,b.[NEO_TITLE_LEGAL]
	,b.[_field]
	,b.[_value]
	,b.ROW4
	,b.bookType
FROM [pet].[pet_tmp].[usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr_temp] b WITH (
		NOLOCK
		,INDEX (ix_fips_ref_id_field)
		)
LEFT JOIN [PET].[dbo].[Pet_LabelColumns_Multi_Legals] c WITH (
		NOLOCK
		,INDEX ([ClusteredIndex-20170302-172737])
		) ON c.ref_id = b.ref_id
	AND c.neo_apn = b.neo_apn
	AND c.NEO_TITLE_LEGAL = b.NEO_TITLE_LEGAL
	AND c._value = b._value
WHERE c.ref_id IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

EXEC [PET].[dbo].[AddPetLog] @Fips
	,N'info'
	,N'usp_ProcessPetCounty_subdivided_Multi_Legals_Teletitle_Incr'
	,N'Ended'


