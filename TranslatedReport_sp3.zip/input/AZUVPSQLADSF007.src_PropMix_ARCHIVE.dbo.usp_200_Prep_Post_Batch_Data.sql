SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- pull and link MLS data
-- =============================================
CREATE PROCEDURE [src_PropMix_ARCHIVE].[dbo].[usp_200_Prep_Post_Batch_Data] 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Date varchar(8) = convert(varchar(8),Getdate(),112)
		
		----- Cleanup PROC
	
	EXEC('UPDATE [AZUVPSQLADSF001].[Jobs].[dbo].[SystemProperty]
	SET [Value] = ''Y''
	,UpdateDate = GETDATE()
	WHERE [Name] = ''IsDevworxRunning''
	')


		TRUNCATE TABLE [dbo].[PostStatus]

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[PostStatus](Step,StartTimestamp)
			VALUES ('1',Getdate())

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET ModificationTimestamp = NULL 
			WHERE isDATE(isNULL(ModificationTimestamp,'2023-06-17')) = 0

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET CloseDate = NULL 
			WHERE isDATE(isNULL(CloseDate,'2023-06-17')) = 0

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET OffMarketDate = NULL 
			WHERE isDATE(isNULL(OffMarketDate,'2023-06-17')) = 0

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET PriceChangeTimestamp = NULL 
			WHERE isDATE(isNULL(PriceChangeTimestamp,'2023-06-17')) = 0

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET StatusChangeTimestamp = NULL 
			WHERE isDATE(isNULL(StatusChangeTimestamp,'2023-06-17')) = 0

			UPDATE [src_PropMix].[dbo].[market_data_daily_raw]
			SET EventTimestamp = PropMixModificationTimestamp 
			WHERE isDATE(isNULL(EventTimestamp,'2023-06-17')) = 0

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[Market_data_Raw_history]([ListingId]
			  ,[ListingKey]
			  ,[PMXPropertyID]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[ParcelNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[LotSizeSquareFeet]
			  ,[LivingArea]
			  ,[ArchitecturalStyle]
			  ,[Heating]
			  ,[Cooling]
			  ,[StoriesTotal]
			  ,[YearBuilt]
			  ,[Roof]
			  ,[ConstructionMaterials]
			  ,[BedroomsTotal]
			  ,[BathroomsTotalInteger]
			  ,[ParkingFeatures]
			  ,[PoolFeatures]
			  ,[View]
			  ,[PatioAndPorchFeatures]
			  ,[Basement]
			  ,[FireplacesTotal]
			  ,[InteriorFeatures]
			  ,[ExteriorFeatures]
			  ,[PublicRemarks]
			  ,[LotFeatures]
			  ,[Zoning]
			  ,[Appliances]
			  ,[LotSizeDimensions]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[StandardStatus]
			  ,[GarageYN]
			  ,[GarageSpaces]
			  ,[MlsListingNumber]
			  ,[ModificationTimestamp]
			  ,[FIPS]
			  ,[PriceperSquareFeet]
			  ,[WaterfrontFeatures]
			  ,[DaysOnMarket]
			  ,[Address]
			  ,[RoomsTotal]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[AboveGradeFinishedArea]
			  ,[AttachedGarageYN]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[CoolingYN]
			  ,[CountyOrParish]
			  ,[CoveredSpaces]
			  ,[CumulativeDaysOnMarket]
			  ,[Fencing]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[HeatingYN]
			  ,[Levels]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[OriginalListPrice]
			  ,[ParkingTotal]
			  ,[PendingTimestamp]
			  ,[PoolPrivateYN]
			  ,[PreviousListPrice]
			  ,[PriceChangeTimestamp]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[PurchaseContractDate]
			  ,[SpaYN]
			  ,[StatusChangeTimestamp]
			  ,[Stories]
			  ,[ViewYN]
			  ,[WaterfrontYN]
			  ,[WithdrawnDate]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[PropMixModificationTimestamp]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[MlsCode]
			  ,[EventTimestamp]
			  ,[LoadDate])
		SELECT  [ListingId]
			  ,[ListingKey]
			  ,[PMXPropertyID]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[ParcelNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[LotSizeSquareFeet]
			  ,[LivingArea]
			  ,[ArchitecturalStyle]
			  ,[Heating]
			  ,[Cooling]
			  ,[StoriesTotal]
			  ,[YearBuilt]
			  ,[Roof]
			  ,[ConstructionMaterials]
			  ,[BedroomsTotal]
			  ,[BathroomsTotalInteger]
			  ,[ParkingFeatures]
			  ,[PoolFeatures]
			  ,[View]
			  ,[PatioAndPorchFeatures]
			  ,[Basement]
			  ,[FireplacesTotal]
			  ,[InteriorFeatures]
			  ,[ExteriorFeatures]
			  ,[PublicRemarks]
			  ,[LotFeatures]
			  ,[Zoning]
			  ,[Appliances]
			  ,[LotSizeDimensions]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[StandardStatus]
			  ,[GarageYN]
			  ,[GarageSpaces]
			  ,[MlsListingNumber]
			  ,[ModificationTimestamp]
			  ,[FIPS]
			  ,[PriceperSquareFeet]
			  ,[WaterfrontFeatures]
			  ,[DaysOnMarket]
			  ,[Address]
			  ,[RoomsTotal]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[AboveGradeFinishedArea]
			  ,[AttachedGarageYN]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[CoolingYN]
			  ,[CountyOrParish]
			  ,[CoveredSpaces]
			  ,[CumulativeDaysOnMarket]
			  ,[Fencing]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[HeatingYN]
			  ,[Levels]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[OriginalListPrice]
			  ,[ParkingTotal]
			  ,[PendingTimestamp]
			  ,[PoolPrivateYN]
			  ,[PreviousListPrice]
			  ,[PriceChangeTimestamp]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[PurchaseContractDate]
			  ,[SpaYN]
			  ,[StatusChangeTimestamp]
			  ,[Stories]
			  ,[ViewYN]
			  ,[WaterfrontYN]
			  ,[WithdrawnDate]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[PropMixModificationTimestamp]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[MlsCode]
			  ,[EventTimestamp]
			  ,GetDate()
		  FROM [src_PropMix].[dbo].[market_data_daily_raw]

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work]([ListingId]
			  ,[ListingKey]
			  ,[PMXPropertyID]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[ParcelNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[LotSizeSquareFeet]
			  ,[LivingArea]
			  ,[ArchitecturalStyle]
			  ,[Heating]
			  ,[Cooling]
			  ,[StoriesTotal]
			  ,[YearBuilt]
			  ,[Roof]
			  ,[ConstructionMaterials]
			  ,[BedroomsTotal]
			  ,[BathroomsTotalInteger]
			  ,[ParkingFeatures]
			  ,[PoolFeatures]
			  ,[View]
			  ,[PatioAndPorchFeatures]
			  ,[Basement]
			  ,[FireplacesTotal]
			  ,[InteriorFeatures]
			  ,[ExteriorFeatures]
			  ,[PublicRemarks]
			  ,[LotFeatures]
			  ,[Zoning]
			  ,[Appliances]
			  ,[LotSizeDimensions]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[StandardStatus]
			  ,[GarageYN]
			  ,[GarageSpaces]
			  ,[MlsListingNumber]
			  ,[ModificationTimestamp]
			  ,[FIPS]
			  ,[PriceperSquareFeet]
			  ,[WaterfrontFeatures]
			  ,[DaysOnMarket]
			  ,[Address]
			  ,[RoomsTotal]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[AboveGradeFinishedArea]
			  ,[AttachedGarageYN]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[CoolingYN]
			  ,[CountyOrParish]
			  ,[CoveredSpaces]
			  ,[CumulativeDaysOnMarket]
			  ,[Fencing]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[HeatingYN]
			  ,[Levels]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[OriginalListPrice]
			  ,[ParkingTotal]
			  ,[PendingTimestamp]
			  ,[PoolPrivateYN]
			  ,[PreviousListPrice]
			  ,[PriceChangeTimestamp]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[PurchaseContractDate]
			  ,[SpaYN]
			  ,[StatusChangeTimestamp]
			  ,[Stories]
			  ,[ViewYN]
			  ,[WaterfrontYN]
			  ,[WithdrawnDate]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[PropMixModificationTimestamp]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[MlsCode]
			  ,[EventTimestamp]
			  ,[LoadDate])
		SELECT  [ListingId]
			  ,[ListingKey]
			  ,[PMXPropertyID]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[ParcelNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[LotSizeSquareFeet]
			  ,[LivingArea]
			  ,[ArchitecturalStyle]
			  ,[Heating]
			  ,[Cooling]
			  ,[StoriesTotal]
			  ,[YearBuilt]
			  ,[Roof]
			  ,[ConstructionMaterials]
			  ,[BedroomsTotal]
			  ,[BathroomsTotalInteger]
			  ,[ParkingFeatures]
			  ,[PoolFeatures]
			  ,[View]
			  ,[PatioAndPorchFeatures]
			  ,[Basement]
			  ,[FireplacesTotal]
			  ,[InteriorFeatures]
			  ,[ExteriorFeatures]
			  ,[PublicRemarks]
			  ,[LotFeatures]
			  ,[Zoning]
			  ,[Appliances]
			  ,[LotSizeDimensions]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[StandardStatus]
			  ,[GarageYN]
			  ,[GarageSpaces]
			  ,[MlsListingNumber]
			  ,[ModificationTimestamp]
			  ,CASE WHEN LEN([FIPS]) = 4 THEN '0' + [FIPS] ELSE [FIPS] END
			  ,[PriceperSquareFeet]
			  ,[WaterfrontFeatures]
			  ,[DaysOnMarket]
			  ,[Address]
			  ,[RoomsTotal]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[AboveGradeFinishedArea]
			  ,[AttachedGarageYN]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[CoolingYN]
			  ,[CountyOrParish]
			  ,[CoveredSpaces]
			  ,[CumulativeDaysOnMarket]
			  ,[Fencing]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[HeatingYN]
			  ,[Levels]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[OriginalListPrice]
			  ,[ParkingTotal]
			  ,[PendingTimestamp]
			  ,[PoolPrivateYN]
			  ,[PreviousListPrice]
			  ,[PriceChangeTimestamp]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[PurchaseContractDate]
			  ,[SpaYN]
			  ,[StatusChangeTimestamp]
			  ,[Stories]
			  ,[ViewYN]
			  ,[WaterfrontYN]
			  ,[WithdrawnDate]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[PropMixModificationTimestamp]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[MlsCode]
			  ,[EventTimestamp]
			  ,GetDate()
		  FROM [src_PropMix].[dbo].[market_data_daily_raw]

			TRUNCATE TABLE [src_PropMix].[dbo].[market_data_daily_raw]

		EXEC [src_PropMix].[dbo].[usp_001_Clean_Extra_Ascii_from_table]

		UPDATE [src_PropMix_ARCHIVE].[dbo].[PostStatus]
			SET FinishTimestamp = Getdate()
			WHERE Step = '1'

		----- LISTING PROC

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[PostStatus](Step,StartTimestamp)
		VALUES ('2',Getdate())

		EXEC [src_PropMix_ARCHIVE].[dbo].[usp_220_ASP_LINK]

		DROP TABLE IF EXISTS dbo.Market_data_StandardizedAddress_Batch

		Select distinct [PMXPropertyID]
		,[MlsCode]
		,[ListingId]
		,[UnparsedAddress] as RawAddress
		,a.[City] as RawCity
		,[StateOrProvince] as RawState
		,[PostalCode] as RawZip
		,[CountyOrParish] as RawCounty
		,b.[ASP_ID]
		,b.[RAW_ID]
		,b.[FullStreetAddress]
		,b.[HouseNbr]
      ,b.[LeftDirection]
      ,b.[Street]
      ,b.[Mode]
      ,b.[RightDirection]
      ,b.[UnitNumber]
      ,b.[City]
      ,b.[State]
      ,b.[Zip]
      ,b.[ZIP4]
      ,b.[Latitude]
      ,b.[Longitude]
      ,b.[CarrierCode]
      ,b.[CensusTractBlock]
      ,b.[UnitType]
      ,b.[MatchCode]
      ,b.[DPVCount]
      ,b.[DPVFootnote]
      ,b.[LACS]
      ,b.[LACSLinkInd]
      ,b.[DPCheckDigit]
      ,b.[DPCheckCode]
      ,b.[CensusBlock]
      ,b.[CensusTract]
      ,b.[GeoCoded]
      ,b.[GeoErrorCode]
      ,b.[GeoStatusCode]
      ,b.[HouseNbrPad]
      ,b.[UnitNbrPad]
      ,b.[StreetPad]
      ,b.[ZipCombine]
      ,CASE WHEN LEN(b.[FIPS]) = 4 THEN '0' + b.[FIPS] ELSE b.[FIPS] END as FIPS
      ,a.[REF_ID]
	  ,a.[PropertyID]
      ,b.[AssrMatchCode]
      ,b.[AssrMultiMatch]
      ,b.[AddressMatchResults]
      ,b.[CountyName]
		,GetDate() ProcessDate
		INTO [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress_Batch]
		from [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work] a JOIN [src_PropMix_ARCHIVE].[dbo].[a_ASP_IN_STD] b
		on a.[PMXPropertyID] = b.[RAW_ID]
		--JOIN [dbo].[a_PropMatch_Work_FLANK] c on a.[PMXPropertyID] = c.[RAW_ID]
		

		Delete from [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress]
		FROM [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress] a JOIN [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress_Batch] b
		on a.[MlsCode] = b.[MlsCode]
			and a.[PMXPropertyID] = b.[PMXPropertyID]

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress]
		Select * from [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress_Batch]

		UPDATE [src_PropMix_ARCHIVE].[dbo].[PostStatus]
			SET FinishTimestamp = Getdate()
			WHERE Step = '2'

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[PostStatus](Step,StartTimestamp)
			VALUES ('3',Getdate())

		UPDATE [src_PropMix_ARCHIVE].[dbo].[a]
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.REF_ID
		,a.FATimestamp = GetDate()
		FROM [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] a JOIN [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress] b
		on a.MlsCode = b.MlsCode
		and a.PMXPropertyID = b.PMXPropertyID
		WHERE a.Propertyid is null
			and b.PropertyID is not null

		UPDATE [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work]
		SET LoadDate = GETDATE()
		WHERE LoadDate is null


		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[Market_Data_History]
		Select a.*,GetDate() 
		FROM [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] a JOIN [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work] b
		on a.[MlsCode] = b.[MlsCode]
			and a.[PMXPropertyID] = b.[PMXPropertyID]


		DELETE FROM [src_PropMix_ARCHIVE].[dbo].[a]
		FROM [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] a JOIN [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work] b
		on a.[MlsCode] = b.[MlsCode]
			and a.[PMXPropertyID] = b.[PMXPropertyID]

		INSERT INTO [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current]([MlsCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[PMXPropertyID]
			  ,[ListingId]
			  ,[ListingKey]
			  ,[MlsListingNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[StandardStatus]
			  ,[ParcelNumber]
			  ,[FIPS]
			  ,[CountyOrParish]
			  ,[Address]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[PreviousListPrice]
			  ,[OriginalListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[DaysOnMarket]
			  ,[CumulativeDaysOnMarket]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[PendingTimestamp]
			  ,[WithdrawnDate]
			  ,[PriceChangeTimestamp]
			  ,[ModificationTimestamp]
			  ,[PurchaseContractDate]
			  ,[StatusChangeTimestamp]
			  ,[PriceperSquareFeet]
			  ,[LotSizeSquareFeet]
			  ,[LotFeatures]
			  ,[LotSizeDimensions]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[PublicRemarks]
			  ,[AboveGradeFinishedArea]
			  ,[Appliances]
			  ,[ArchitecturalStyle]
			  ,[AttachedGarageYN]
			  ,[Basement]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BathroomsTotalInteger]
			  ,[BedroomsTotal]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[CoolingYN]
			  ,[CoveredSpaces]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplacesTotal]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[GarageYN]
			  ,[Heating]
			  ,[HeatingYN]
			  ,[InteriorFeatures]
			  ,[Levels]
			  ,[LivingArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[PoolPrivateYN]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[Roof]
			  ,[RoomsTotal]
			  ,[SpaYN]
			  ,[Stories]
			  ,[StoriesTotal]
			  ,[View]
			  ,[ViewYN]
			  ,[WaterfrontFeatures]
			  ,[WaterfrontYN]
			  ,[YearBuilt]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[Zoning]
			  ,[PropMixModificationTimestamp]
			  ,[EventTimestamp]
			  ,[LoadDate]
			  ,[FATimestamp])
		Select [MlsCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[PMXPropertyID]
			  ,[ListingId]
			  ,[ListingKey]
			  ,[MlsListingNumber]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[StandardStatus]
			  ,[ParcelNumber]
			  ,[FIPS]
			  ,[CountyOrParish]
			  ,[Address]
			  ,[UnparsedAddress]
			  ,[City]
			  ,[StateOrProvince]
			  ,[PostalCode]
			  ,[StdUnparsedAddress]
			  ,[StdCity]
			  ,[StdStateOrProvince]
			  ,[StdPostalCode]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[PreviousListPrice]
			  ,[OriginalListPrice]
			  ,[ClosePrice]
			  ,[CloseDate]
			  ,[DaysOnMarket]
			  ,[CumulativeDaysOnMarket]
			  ,[OffMarketDate]
			  ,[OnMarketDate]
			  ,[PendingTimestamp]
			  ,[WithdrawnDate]
			  ,[PriceChangeTimestamp]
			  ,[ModificationTimestamp]
			  ,[PurchaseContractDate]
			  ,[StatusChangeTimestamp]
			  ,[PriceperSquareFeet]
			  ,[LotSizeSquareFeet]
			  ,[LotFeatures]
			  ,[LotSizeDimensions]
			  ,[LotSizeAcres]
			  ,[LotSizeArea]
			  ,[SubdivisionName]
			  ,[Model]
			  ,[PublicRemarks]
			  ,[AboveGradeFinishedArea]
			  ,[Appliances]
			  ,[ArchitecturalStyle]
			  ,[AttachedGarageYN]
			  ,[Basement]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsOneQuarter]
			  ,[BathroomsPartial]
			  ,[BathroomsThreeQuarter]
			  ,[BathroomsTotalInteger]
			  ,[BedroomsTotal]
			  ,[BelowGradeFinishedArea]
			  ,[BuildingAreaTotal]
			  ,[BuildingFeatures]
			  ,[CarportYN]
			  ,[CommonWalls]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[CoolingYN]
			  ,[CoveredSpaces]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplacesTotal]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[GarageYN]
			  ,[Heating]
			  ,[HeatingYN]
			  ,[InteriorFeatures]
			  ,[Levels]
			  ,[LivingArea]
			  ,[MainLevelBathrooms]
			  ,[MainLevelBedrooms]
			  ,[NewConstructionYN]
			  ,[OpenParkingSpaces]
			  ,[OpenParkingYN]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[PoolPrivateYN]
			  ,[PropertyAttachedYN]
			  ,[PropertyCondition]
			  ,[Roof]
			  ,[RoomsTotal]
			  ,[SpaYN]
			  ,[Stories]
			  ,[StoriesTotal]
			  ,[View]
			  ,[ViewYN]
			  ,[WaterfrontFeatures]
			  ,[WaterfrontYN]
			  ,[YearBuilt]
			  ,[YearBuiltDetails]
			  ,[YearBuiltEffective]
			  ,[Zoning]
			  ,[PropMixModificationTimestamp]
			  ,[EventTimestamp]
			  ,[LoadDate]
			  ,[LoadDate]
		from [src_PropMix_ARCHIVE].[dbo].[market_data_daily_Work]
		order by [ModificationTimestamp] desc

		TRUNCATE TABLE dbo.[market_data_daily_Work]

		UPDATE [src_PropMix_ARCHIVE].[dbo].[a]
			SET a.MaxModifiedTimestamp = b.MaxMod
			,a.MaxListDate = c.MaxListDt
			,a.MaxOnMarketDate = d.MaxOnMkt
			,a.MaxSoldDate = e.MaxSoldDt
			,a.MinListDate = f.MinListDt
			,a.MinOnMarketDate = g.MinOnMkt
			,a.MinSoldDate = h.MinSoldDt
			,a.[TotalListingCount] = i.TotalListings
			,a.[TotalActiveStatusTypes] = i.TotalActiveStatusTypes
			,a.[TotalInActiveStatusTypes] = i.TotalInActiveStatusTypes
			,a.[TotalSoldStatusTypes] = i.TotalSoldStatusTypes
			,a.[MaxLoadDate] = j.MaxLoadDt
			FROM [src_PropMix].[dbo].[PropMix_Global] a 
				JOIN (Select [MlsCode],Max(Cast([ModificationTimestamp] as datetime))as MaxMod from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([ModificationTimestamp] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) b
			on a.MLScode = b.[MlsCode]
				JOIN (Select [MlsCode],Max(Cast([ListingContractDate] as datetime)) as MaxListDt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([ListingContractDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) c
			on a.MLScode = c.[MlsCode]
				JOIN (Select [MlsCode],Max(Cast([OnMarketDate] as datetime)) as MaxOnMkt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([OnMarketDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) d
			on a.MLScode = d.[MlsCode]
				JOIN (Select [MlsCode],Max(Cast([CloseDate] as datetime)) as MaxSoldDt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([CloseDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) e
			on a.MLScode = e.[MlsCode]
				JOIN (Select [MlsCode],Min(Cast([ListingContractDate] as datetime)) as MinListDt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([ListingContractDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) f
			on a.MLScode = f.[MlsCode]
				JOIN (Select [MlsCode],Min(Cast([OnMarketDate] as datetime)) as MinOnMkt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([OnMarketDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) g
			on a.MLScode = g.[MlsCode]
				JOIN (Select [MlsCode],Min(Cast([CloseDate] as datetime)) as MinSoldDt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([CloseDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) h
			on a.MLScode = h.[MlsCode]
				JOIN (Select MLSCode,Count(*) as TotalListings
					,SUM(CASE WHEN StandardStatus in('active','backup','coming_soon','pending') THEN 1 ELSE 0 END) as TotalActiveStatusTypes
					,SUM(CASE WHEN StandardStatus in('sold','withdrawn','canceled','expired') THEN 1 ELSE 0 END) as TotalInActiveStatusTypes
					,SUM(CASE WHEN StandardStatus in('sold') THEN 1 ELSE 0 END) as TotalSoldStatusTypes
					 from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK)
					  group by [MlsCode]) i
			on a.MLScode = i.[MlsCode]
				JOIN (Select [MlsCode],Max(Cast([LoadDate] as datetime)) as MaxLoadDt from [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] with(NOLOCK) WHERE Cast([LoadDate] as datetime) BETWEEN '1950-01-01' and GETDATE() group by [MlsCode]) j
			on a.MLScode = d.[MlsCode]

 
 
			UPDATE [src_PropMix_ARCHIVE].[dbo].[PostStatus]
			SET FinishTimestamp = Getdate()
			WHERE Step = '3'


		DROP INDEX IF EXISTS [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL]

		DROP INDEX IF EXISTS [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL]

		 TRUNCATE TABLE [Devworx].[dbo].[Devworx_ALL]

			INSERT INTO [Devworx].[dbo].[Devworx_ALL]([MLSID]
			  ,[FIPSCode]
			  ,[PropertyID]
			  ,[REF_ID]
			  ,[ParcelNumber]
			  ,[FullStreetAddress]
			  ,[HouseNbr]
			  ,[LeftDirection]
			  ,[Street]
			  ,[Mode]
			  ,[RightDirection]
			  ,[UnitType]
			  ,[UnitNumber]
			  ,[City]
			  ,[State]
			  ,[Zip]
			  ,[ZIP4]
			  ,[CarrierCode]
			  ,[Latitude]
			  ,[Longitude]
			  ,[GeoStatusCode]
			  ,[ListingId]
			  ,[MlsStatus]
			  ,[StandardStatus]
			  ,[ListingContractDate]
			  ,[ListPrice]
			  ,[OriginalListPrice]
			  ,[PreviousListPrice]
			  ,[CloseDate]
			  ,[ClosePrice]
			  ,[PropertyType]
			  ,[PropertySubType]
			  ,[OnMarketDate]
			  ,[OffMarketDate]
			  ,[PendingTimestamp]
			  ,[FATimestamp]
			  ,[DaysOnMarket]
			  ,[PhotosCount]
			  ,[Appliances]
			  ,[BedroomsTotal]
			  ,[BathroomsFull]
			  ,[BathroomsHalf]
			  ,[BathroomsTotal]
			  ,[BuildingAreaTotal]
			  ,[CommunityFeatures]
			  ,[ConstructionMaterials]
			  ,[Cooling]
			  ,[ExteriorFeatures]
			  ,[Fencing]
			  ,[FireplaceFeatures]
			  ,[Flooring]
			  ,[FoundationDetails]
			  ,[GarageSpaces]
			  ,[Heating]
			  ,[InteriorFeatures]
			  ,[LivingArea]
			  ,[LotFeatures]
			  ,[LotSizeAcres]
			  ,[LotSizeSquareFeet]
			  ,[OtherStructures]
			  ,[ParkingFeatures]
			  ,[ParkingTotal]
			  ,[PatioAndPorchFeatures]
			  ,[PoolFeatures]
			  ,[Roof]
			  ,[SecurityFeatures]
			  ,[Sewer]
			  ,[Stories]
			  ,[Utilities]
			  ,[View]
			  ,[WaterSource]
			  ,[WaterfrontFeatures]
			  ,[WaterBodyName]
			  ,[WindowFeatures]
			  ,[YearBuilt]
			  ,[PublicRemarks]
			  ,[PrivateRemarks]
			  ,[SyndicationRemarks]
			  ,[Disclosures]
			  ,[AssociationFee]
			  ,[AssociationFeeFrequency]
			  ,[AssociationFeeIncludes]
			  ,[AssociationName]
			  ,[AssociationPhone]
			  ,[ElementarySchool]
			  ,[MiddleOrJuniorSchool]
			  ,[HighSchool]
			  ,[HighSchoolDistrict]
			  ,[SubdivisionName]
			  ,[TaxLegalDescription]
			  ,[GreenEnergyEfficient]
			  ,[NewConstructionYN]
			  ,[NumberOfBuildings]
			  ,[NumberOfUnitsTotal]
			  ,[ForSaleForRent]
			  ,[LotSizeArea]
			  ,[AboveGradeFinishedArea]
			  ,[BelowGradeFinishedArea]
			  ,[BelowGradeFinishedAreaUnits]
			  ,[FireplacesTotal]
			  ,[YearBuiltEffective]
			  ,[Levels]
			  ,[TaxYear]
			  ,[BuyerFinancing]
			  ,[Concessions]
			  ,[ConcessionsAmount]
			  ,[ElementarySchoolDistrict]
			  ,[MiddleOrJuniorSchoolDistrict]
			  ,[CoveredSpaces]
			  ,[CarportSpaces]
			  ,[SpaFeatures]
			  ,[LotSizeUnits]
			  ,[LivingAreaUnits]
			  ,[RoomsTotal]
			  ,[ZoningDescription])
		Select a.[MlsCode]
			,a.[FIPS]
			,a.[PropertyID]
			,a.[REF_ID]
			,LEFT([ParcelNumber],50)
			,CASE WHEN LEFT(b.[FULLStreetAddress],116) is NULL THEN LEFT(a.StdUnparsedAddress,116) ELSE LEFT(b.FullStreetAddress,116) END
			,LEFT([HouseNbr],30)
			,LEFT([LeftDirection],2)
			,LEFT([Street],55)
			,LEFT([Mode],10)
			,LEFT([RightDirection],2)
			,LEFT([UnitType],20)
			,LEFT([UnitNumber],15)
			,LEFT(b.[City],55)
			,LEFT([State],2)
			,LEFT([Zip],10)
			,[ZIP4]
			,[CarrierCode]
			,[Latitude]
			,[Longitude]
			,[GeoStatusCode]
			,a.[ListingId]
			,NULL
			,[StandardStatus]
			,[ListingContractDate]
			,[ListPrice]
			,[OriginalListPrice]
			,[PreviousListPrice]
			,[CloseDate]
			,[ClosePrice]
			,LEFT([PropertyType],50)
			,LEFT([PropertySubType],50)
			,[OnMarketDate]
			,[OffMarketDate]
			,[PendingTimestamp]
			,[FATimestamp] as FATimestamp
			,[DaysOnMarket]
			,NULL
			,LEFT([Appliances],1024)
			,[BedroomsTotal]
			,[BathroomsFull]
			,[BathroomsHalf]
			,[BathroomsTotalInteger]
			,[BuildingAreaTotal]
			,NULL
			,LEFT([ConstructionMaterials],1024)
			,LEFT([Cooling],1024)
			,LEFT([ExteriorFeatures],1024)
			,LEFT([Fencing],1024)
			,NULL
			,LEFT([Flooring],1024)
			,LEFT([FoundationDetails],1024)
			,LEFT([GarageSpaces],15)
			,LEFT([Heating],1024)
			,LEFT([InteriorFeatures],1024)
			,LEFT([LivingArea],15)
			,LEFT([LotFeatures],1024)
			,LEFT([LotSizeAcres],5)
			,LEFT([LotSizeSquareFeet],15)
			,NULL
			,LEFT([ParkingFeatures],1024)
			,LEFT([ParkingTotal],15)
			,LEFT([PatioAndPorchFeatures],1024)
			,LEFT([PoolFeatures],1024)
			,LEFT([Roof],1024)
			,NULL
			,NULL
			,LEFT([Stories],5)
			,NULL
			,LEFT([View],1024)
			,NULL
			,LEFT([WaterfrontFeatures],1024)
			,NULL
			,NULL
			,LEFT([YearBuilt],5)
			,LEFT([PublicRemarks],4000)
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,LEFT([SubdivisionName],50)
			,NULL
			,NULL
			,[NewConstructionYN]
			,NULL
			,NULL
			,NULL
			,LEFT([LotSizeArea],15)
			,NULL
			,NULL
			,NULL
			,LEFT([FireplacesTotal],15)
			,LEFT([YearBuiltEffective],5)
			,[Levels]
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,NULL
			,LEFT([CoveredSpaces],15)
			,NULL
			,LEFT([SpaYN],1024)
			,NULL
			,'SQFT'
			,LEFT([RoomsTotal],15)
			,LEFT([Zoning],255)
			FROM [src_PropMix_ARCHIVE].[dbo].[Market_Data_Current] a LEFT OUTER JOIN [src_PropMix_ARCHIVE].[dbo].[Market_data_StandardizedAddress] b
			on a.[PMXPropertyID] = b.[PMXPropertyID]
							and a.[MlsCode] = b.[MlsCode]
								and a.ListingId = b.ListingId
			WHERE [ListingContractDate] <= CAST(GETDATE() as DATE)

		CREATE NONCLUSTERED INDEX [ix_FipsCode] ON [Devworx].[dbo].[Devworx_ALL]
		([FIPSCode] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85) ON [PRIMARY]
			
		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [Devworx].[dbo].[Devworx_ALL]
		([FIPSCode] ASC, [PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85) ON [PRIMARY]
			

	EXEC('UPDATE [AZUVPSQLADSF001].[Jobs].[dbo].[SystemProperty]
	SET [Value] = ''N''
	,UpdateDate = GETDATE()
	WHERE [Name] = ''IsDevworxRunning''
	')


	EXEC [DevWorx].[dbo].[015_Append_ALL_Devworx_Materialized_V2];
	--EXEC [DevWorx].[dbo].[090_CREATE_MKTSHR_DEVWORX_PM];
	EXEC [DevWorx].[dbo].[500_CreateCheckStatus];

 			DECLARE @1 varchar(155) = 'afowler@firstam.com;micsmith@firstam.com;jeschmeyer@firstam.com;HeenaPatel@firstam.com;JDivse@firstam.com', 
				--DECLARE @1 varchar(155) = 'micsmith@firstam.com', 
				@t_profile_name1 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject1 varchar(50) = 'PropMix Listing Load Process Finished',
				@t_body1 varchar(1000) = 'The PropMix listing load posting process has finished, including Devworx and MktShr_Devworx'


				SET NOCOUNT ON;
				DECLARE @t_getdate1 datetime = GETDATE()
				SET @t_body1 = @t_body1 + '
					**** ' + Convert(varchar(25),@t_getdate1,120) + ' PT ****
					'

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @1,
					@profile_name = @t_profile_name1,
					@subject = @t_subject1,
					@body = @t_body1


END


