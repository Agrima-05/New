SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- UPDATE src_IndependentPlatlabs.dbo.PlatlabsGlobal
-- =============================================
CREATE PROCEDURE [src_IndependentPlatlabs].[dbo].[usp_100_PostCredentialUpdates] 

AS
BEGIN

	SET NOCOUNT ON;

		DELETE FROM [src_IndependentPlatlabs].[dbo].[PlatlabsCreds] 
		WHERE RealStaq_Code is null;


	---- ADD NEW ENTRIES
		INSERT INTO [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal]
           ([State]
           ,[MLSFullName]
           ,[PlatlabsCode]
           ,[active]
           ,[ID_client_id_username]
           ,[Password_token_client_secret]
           ,[Originating_ID]
           ,[Sub_Board]
           ,[Server_URL]
           ,[Vendor]
           ,[Notes]
           ,[DBName]
           ,[LastUpdateDate]
		   ,[Priority]
		   ,[Mapping_active])
		SELECT a.[State]
           ,a.[MLSFullName]
           ,a.[RealStaq_Code]
           ,a.[active]
           ,a.[ID_client_id_username]
           ,a.[Password_token_client_secret]
           ,a.[Originating_ID]
           ,a.[Sub_Board]
           ,a.[Server_URL]
           ,a.[Vendor]
           ,a.[Notes]
		   ,a.[Priority]
		   ,a.[Mapping_active]
		   ,'mls_' + replace(b.[PlatlabsCode],'_39','')
           ,GETDATE()
		FROM [src_IndependentPlatlabs].[dbo].[PlatlabsCreds] a with(NOLOCK) LEFT OUTER JOIN [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] b
		ON a.RealStaq_Code = b.[PlatlabsCode]
		WHERE a.RealStaq_Code is NULL


	---- POST UPDATES
		update [src_IndependentPlatlabs].[dbo].[a]
		SET a.ID_client_id_username = CASE WHEN isNULL(b.[ID_client_id_username],'') != isNULL(a.ID_client_id_username,'') THEN b.[ID_client_id_username] ELSE a.ID_client_id_username END
		,a.MLSFullName = CASE WHEN isNULL(b.MLSFullName,'') != isNULL(a.MLSFullName,'') THEN b.MLSFullName ELSE a.MLSFullName END
		,a.Notes = CASE WHEN isNULL(b.Notes,'') != isNULL(a.Notes,'') THEN b.Notes ELSE a.Notes END
		,a.Originating_ID = CASE WHEN isNULL(b.[Originating_ID],'') != isNULL(a.Originating_ID,'') THEN b.[Originating_ID] ELSE a.Originating_ID END
		,a.Password_token_client_secret = CASE WHEN isNULL(b.[Password_token_client_secret],'') != isNULL(a.Password_token_client_secret,'') THEN b.[Password_token_client_secret] ELSE a.Password_token_client_secret END
		,a.Server_URL = CASE WHEN isNULL(b.[Server_URL],'') != isNULL(a.Server_URL,'') THEN b.[Server_URL] ELSE a.Server_URL END
		,a.[State] = CASE WHEN LEN(b.[State])>2 THEN a.[State] ELSE CASE WHEN isNULL(b.[State],'') != isNULL(a.[State],'') THEN b.[State] ELSE a.[State] END END
		,a.Vendor = CASE WHEN isNULL(b.Vendor,'') != isNULL(a.Vendor,'') THEN b.Vendor ELSE a.Vendor END
		,a.[Priority] = CASE WHEN isNULL(b.[Priority],'') != isNULL(a.[Priority],'') THEN b.[Priority] ELSE a.[Priority] END
		,a.[Mapping_active] = CASE WHEN isNULL(b.[Mapping_active],'') != isNULL(a.[Mapping_active],'') THEN b.[Mapping_active] ELSE a.[Mapping_active] END
		,a.LastUpdateDate = GETDATE()
		from [src_IndependentPlatlabs].[dbo].[PlatlabsGlobal] a JOIN [src_IndependentPlatlabs].[dbo].[PlatlabsCreds] b  
		on a.[PlatlabsCode] = b.[RealStaq_Code]



		TRUNCATE TABLE dbo.[PlatlabsCreds]

END

