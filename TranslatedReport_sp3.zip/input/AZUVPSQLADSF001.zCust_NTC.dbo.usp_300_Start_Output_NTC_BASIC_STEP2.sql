SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [zCust_NTC].[dbo].[usp_300_Start_Output_NTC_BASIC_STEP2]

AS
BEGIN
	
	SET NOCOUNT ON;

	
	


----	20240909 - Solution Notes:
----Doc retrieval of the Mortgage is REQUIRED, if no Matched Mortgage document imgage found, no return
----Foreclosure Deed: Return only if next Deed Recording after Matched Input Lien Recording Date is a Foreclosure Deed
----Rerecording Logic:
----Once target mortgage is found (MTG001), return any mortgage found after target mortgage recording date with the same address and loan amount 
----In Coverage (MTG coverage in County from Input MTG Recording Date forward); Not In Coverage (No MTG coverage for County OR Input recording date prior to County Start Date)
	
-----Step 2 - NULL Mtg fields for those with no image & set FLAG.   Then find other recordings for those with image
	


	----------------Check matched records with no image-------
			--Select A.[UNique ID], A.PropertyID, A.[INPUT Orig Mtg Date]	,[INPUT Orig Mtg Loan Amount]	,[INPUT Orig Mtg Instrument #],	[INPUT Borrower Name]
			--,C.Value,C.RecordingDate,C.DocDate,C.DocumentType, C.ToUse
			--From  x_Custom_OUTPUT_BASIC A with(NOLOCK)
			--left outer join (Select INPUTKEY From z_Images_To_Pull where XosStatus like 'Completed') B
			--on A.[Unique ID] = B.INPUTKEY
			--join w_Transhist_FLANK as C with(NOLOCK) on A.[UNique ID] = C.RAW_ID
			--where B.INPUTKEY is null
			--and A.PropertyID is not null
			--and A.[MTGRecording Date] is null
			--and [In Coverage] = 1
			--and C.Doc_Src_Ind like 'M'
			--	and Convert(MONEY,A.[INPUT Orig Mtg Loan Amount]) 
			--	between convert(money,C.Value) 	- (convert(money,C.Value) * .05  / 100) and convert(money,C.Value) 
			--	+ (convert(money,C.Value) * .05 / 100)
			--		and (convert(DATETIME,[INPUT Orig Mtg Date]) BETWEEN convert(DATETIME,C.RecordingDate)-180 
			--		and convert(DATETIME,C.RecordingDate)+ 365
			--		   or convert(DATETIME,[INPUT Orig Mtg Date]) BETWEEN convert(DATETIME,DocDate)-180  
			--		  and convert(DATETIME,DocDate)+ 365
			--		  )
			--			--and buyerborrower LIKE '%' + LTRIM(RTRIM([INPUT BorrowerLastName])) + '%'
			--				AND C.DocumentType not like 'MO'

		--Select * From w_Transhist_II
		--where RAW_ID = '430032172_26218199'

				
			UPDATE [zCust_NTC].[dbo].[A] 
			SET 
			--A.[OrigTrans RecDate] = NULL
			--,A.[OrigTrans DocNumber] = NULL
			--,A.[OrigTrans LoanAmount] = NULL
			--,A.[OrigTransBkPg] = NULL
			A.[MTGRecording Date]  =NULL
			,A.[MTGLoan Amount] = NULL
			,A.[MTGInstrument #] = NULL
			,A.[MTGBookPage] = NULL
			,A.[MTGDoc Type] = NULL
			,A.[MTGBorrower Name] = NULL
			,A.InputMTGRecNoImage = 'Y'
			--Select A.*
			From  [zCust_NTC].[dbo].[x_Custom_OUTPUT_BASIC] A with(NOLOCK)
			left outer join (Select INPUTKEY From [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') B
			on A.[Unique ID] = B.INPUTKEY
			where B.INPUTKEY is null
			and A.[MTGRecording Date] is not null

		
			


	
		----------------------------------Find Once target mortgage is found (MTG001), return any mortgage found after target mortgage recording date with the same address and loan amount -----------------------
		----------------------------------Find Loan Mod for Matched Mtg, Find Release for Matched Mtg, Find first FC Deed recorded after matched mtg (if there is one) -----------------------

		-------Delete records with no images as Flag has already been set--------
		Delete from [zCust_NTC].[dbo].[z_Images_To_Pull]
		where ISNULL(XosStatus,'') not like 'Completed'



		Select XosStatus, count(*) from [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XosStatus

		-------FIND ADD'l MTGS----
			
		UPdate [zCust_NTC].[dbo].[w_TransHist]
		Set Touse = null 
		where Touse is not null


		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'MG'
		--Select A.RAW_ID, A.RecordingDate, A.Value, B.RecordingDate, B.Value, A.Doc_Id, B.Doc_Id, A.DocumentNbr
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate From [zCust_NTC].[dbo].[w_TransHist_II] as A join 
			(Select INPUTKEY from [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') 
			as B on A.RAW_ID = B.INPUTKEY) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind like 'M'
		and A.DocumentType not in ('MO','MD','MOD')
		and A.RecordingDate >= B.RecordingDate
		and A.Value = B.Value
		and A.Doc_Id <> B.Doc_Id





		-------FIND MOD----
			
	
		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'MO'
		--Select A.RAW_ID, A.RecordingDate, A.Value,A.OrigTransRecDate,A.OrigTransValue, A.[OrigTransDocNumber],A.OrigTransBkPg, A.DocumentType
		--,B.RecordingDate, B.Value, B.DocumentNbr
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate, DocDate,DocumentNbr From [zCust_NTC].[dbo].[w_TransHist_II] as A join 
			(Select INPUTKEY from [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') 
			as B on A.RAW_ID = B.INPUTKEY) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind in ('R','M')
		and (A.DocumentType like 'MO%' or A.DocumentType like 'MD')
		--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate)
		and 
		(
		--(convert(money,A.OrigTransValue) = convert(money,B.Value) and ISNULL(A.OrigTransValue,'') not like '')
		--OR 
			(REPLACE(REPLACE(A.[OrigTransDocNumber],'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate OR A.OrigDoc_Id = B.Doc_Id)
			)
			OR
			(REPLACE(REPLACE(A.OrigTransBkPg,'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0',''))
						
			--)
		)
		


		--Select * From w_TransHist A
		--where RAW_ID = '430032538_26218320'
		--and (A.DocumentType like 'MO%' or A.DocumentType like 'MD' or DocumentNbr like '2018.12968')
	

		-------FIND REL----
			
	
		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'R'
		--Select A.RAW_ID, A.RecordingDate, A.Value,A.OrigTransRecDate,A.OrigTransValue, A.[OrigTransDocNumber],A.OrigTransBkPg
		--,B.RecordingDate, B.Value, B.DocumentNbr
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate, DocDate,DocumentNbr From [zCust_NTC].[dbo].[w_TransHist_II] as A join 
			(Select INPUTKEY from [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') 
			as B on A.RAW_ID = B.INPUTKEY) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind in ('R')
		and A.DocumentType like '%REL%'
		
		--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate)
		and 
		(
		--(convert(money,A.OrigTransValue) = convert(money,B.Value) and ISNULL(A.OrigTransValue,'') not like '')
		--OR 
			(REPLACE(REPLACE(A.[OrigTransDocNumber],'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate OR A.OrigDoc_Id = B.Doc_Id)
			)
			OR
			REPLACE(REPLACE(A.OrigTransBkPg,'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--)
			OR A.OrigDoc_Id = B.Doc_Id

		)

		--Select * From w_TransHist
		--where DocumentType like 'REL'
		--or RAW_ID = 430031156


			-------FIND ASN----
			
	
		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'A'
		--Select A.RAW_ID, A.RecordingDate, A.Value,A.OrigTransRecDate,A.OrigTransValue, A.[OrigTransDocNumber],A.OrigTransBkPg
		--,B.RecordingDate, B.Value, B.DocumentNbr
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate, DocDate,DocumentNbr From [zCust_NTC].[dbo].[w_TransHist_II] as A join 
			(Select INPUTKEY from [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') 
			as B on A.RAW_ID = B.INPUTKEY) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind in ('R')
		and (A.DocumentType like '%ASN%' or (A.DocumentType like '%AS%' and A.DocumentTypeDesc like '%Assign%'))
		--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate)
		and 
		(
		--(convert(money,A.OrigTransValue) = convert(money,B.Value) and ISNULL(A.OrigTransValue,'') not like '')
		--OR 
			(REPLACE(REPLACE(A.[OrigTransDocNumber],'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--and (A.OrigTransRecDate = B.RecordingDate OR A.OrigTransRecDate = B.DocDate OR A.OrigDoc_Id = B.Doc_Id)
			)
			OR
			REPLACE(REPLACE(A.OrigTransBkPg,'.',''),'0','') = REPLACE(REPLACE(B.DocumentNbr ,'.',''),'0','')
			--)
			OR A.OrigDoc_Id = B.Doc_Id
		)

		--Select * From w_TransHist
		--where DocumentType like 'ASN'


		-------FIND FIRST FC DEED----
			
	
		UPdate [zCust_NTC].[dbo].[A]
		Set A.Touse = 'U'
		--Select A.RAW_ID, A.RecordingDate, A.DocumentType
		--,B.RecordingDate
		From [zCust_NTC].[dbo].[w_TransHist] as A 
		join 
			(Select RAW_ID, Doc_Id, Value, RecordingDate, DocumentNbr From [zCust_NTC].[dbo].[w_TransHist_II] as A join 
			(Select INPUTKEY from [zCust_NTC].[dbo].[z_Images_To_Pull] where XosStatus like 'Completed') 
			as B on A.RAW_ID = B.INPUTKEY) B 
		on A.RAW_ID = B.RAW_ID
		where A.Doc_Src_Ind in ('D')
		and A.DocumentType like 'U'
		and A.RecordingDate >= B.RecordingDate


		Select * From [zCust_NTC].[dbo].[w_TransHist]
		where DocumentType like 'U'




		Update [zCust_NTC].[dbo].[w_TransHist]
		set RecordNumber = NULL

			UPDATE [zCust_NTC].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_NTC].[dbo].[w_TransHist] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RecordingDate ASC) AS RowNum
				FROM 
			[zCust_NTC].[dbo].[w_TransHist] t WHERE ToUse = 'U'  ) r ON t.RAW_ID = r.RAW_ID AND t.DOC_ID = r.Doc_ID


		Select RAW_ID,count(*) From [zCust_NTC].[dbo].[w_TransHist]
		WHERE ToUse = 'U'
		Group by RAW_ID
		having count(*) > 1


		Select A.* From [zCust_NTC].[dbo].[w_TransHist] as A 
		join (Select RAW_ID,count(*) as TOTAL From [zCust_NTC].[dbo].[w_TransHist]
		WHERE ToUse = 'U'
		Group by RAW_ID
		having count(*) > 1) B on A.RAW_ID = B.RAW_ID
		WHERE ToUse = 'U'


		Update [zCust_NTC].[dbo].[w_TransHist]
		set RecordNumber = NULL
		where ToUse = 'U'
		and RecordNumber > 1


		
		Select ToUse, count(*) From [zCust_NTC].[dbo].[w_TransHist]
		where ToUse is not null
		Group by ToUse

		Select RAW_ID, count(*) From [zCust_NTC].[dbo].[w_TransHist]
		where ToUse is not null
		Group by RAW_ID
		Order by count(*) Desc

		--Select * From w_TransHist
		--where RAW_ID = 430031106
		--and ToUse is not null
		--Order by RecordingDate 

		--Select * From w_RAS
		--where REF_ID = 97065568

	

	---------------------NOW PULL IMAGES FOR ALL SUBSEQUENT RECORDINGS COLLECTED---------------------------
		-----Already flagged MTGs with no image above so removing them so as not to pull any not already pulled
		Delete from [zCust_NTC].[dbo].[z_Images_To_Pull]
		where XOSStatus not like 'Completed'
		OR XOSStatus is null


		Truncate table w_TransHist_II

		INSERT INTO [zCust_NTC].[dbo].[w_TransHist_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,OrigTransBkPg, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					--,Borrower1,Borrower2
					, OrigTransValue
					)
		SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr, BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,OrigTransBkPg, Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, 
					DocumentTypeDesc, ToUse, BuyerBorrowerLastName, BuyerBorrowerFirstName, SellerLenderLastName, SellerLenderFirstName, Updated_Date, MTG_Term, MTG_TermType, Loan_Type, Int_Rate, Rate_Type, RAW_ID, DocDate
					, OrigTransValue
					--,Borrower1,Borrower2
		FROM     [zCust_NTC].[dbo].[w_TransHist]
		WHERE  (ToUse  is not null)
		

		-----Inserting all subsequent images to pull
		INSERT INTO [zCust_NTC].[dbo].[z_Images_To_Pull]
		(INPUTKEY
		,[Fips]
		,[DocumentNbr]
		,[CmtId]
		,[RecordingDate]
		,[ImageName]
		,[DOCTYPE]
		)
		SELECT 
		A.RAW_ID
		,RIGHT(('0' + convert(varchar(5),A.[Fips])),5)
		,A.DocumentNbr
		,case when [CmtId] is null then '0' else [CmtId] end
		,[RecordingDate]
		--,A.RAW_ID + '_' + right(('000' + A.RecordNumber),3)
		,A.RAW_ID + '_' + 'SMR' + '_' +  case when A.DocumentType like 'MO%' then 'MOD'
		when A.DocumentType like 'U' then 'FCD'
		else A.DocumentType end + '_' +  A.DocumentNbr
		,case when A.DocumentType like 'MO%' then 'MOD' 
		when A.DocumentType like 'U' then 'FCD'
		else A.DocumentType end
		--Select  A.DocumentNbr, A.FMT_DOC_NBR, A.FMT_Book_Page, A.BookSrce, A.PageSrce
		From [zCust_NTC].[dbo].[w_TransHist_II] as A join [zCust_NTC].[dbo].[x_Custom_OUTPUT_BASIC] as B on A.RAW_ID = B.[Unique ID]
		where A.ToUse is not null
		Order by A.RAW_ID


		Select ImageName ,[DOCTYPE]
		--,left(right(ImageName,len(ImageName)-10),charindex('_',right(ImageName,len(ImageName)-10))-1)
		From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Order by [DOCTYPE]


		Select XOSStatus, count(*) From [zCust_NTC].[dbo].[z_Images_To_Pull]
		Group by XOSStatus
	

		Select * From [zCust_NTC].[dbo].[z_Images_To_Pull]
		where XOSStatus is null




		---------------------NOW PULL IMAGES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



		
		



END






