SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF




CREATE PROCEDURE [zCust_PennyMac].[dbo].[usp_350_Finish_Archive_Success_Exception]
		AS
BEGIN
	
	-------This process runs at 8AM PT after the once per day extracts are created & delivered to PNMAC----

		-----Archive Exceptions
		INSERT INTO [zCust_PennyMac].[dbo].[x_Custom_OUT_EXCEPTION_SEND_HIST](ReportDate, PropertyStatus, MortgageCoverageStatus, MortgageThroughDate, [Mortgage Event Status], [Legal Event Status], [Required Title Fields Event Status], LoanId, assessors_parcel_id_number, land_records_type, 
                  legal_description, mortgage_tax_paid, original_borrower, original_deed_date, original_grantee_vesting, original_grantor_vesting, original_loan_date, original_mortgage_loan_amount, original_mortgagee, original_mtg_recorded_date, 
                  original_source_book, original_source_instrument_number, original_source_page, re_recording_book, re_recording_date, re_recording_instrument_number, re_recording_page, recording_source_book, recording_source_date, 
                  recording_source_instrument_number, recording_source_page, section_block_lot, short_legal, transfer_cert_title_number, MortgageStartDate, State,DATE_SENT
				  ,REQUEST_DATE)
		SELECT ReportDate, PropertyStatus, MortgageCoverageStatus, MortgageThroughDate, [Mortgage Event Status], [Legal Event Status], [Required Title Fields Event Status], LoanId, assessors_parcel_id_number, land_records_type, 
						  legal_description, mortgage_tax_paid, original_borrower, original_deed_date, original_grantee_vesting, original_grantor_vesting, original_loan_date, original_mortgage_loan_amount, original_mortgagee, original_mtg_recorded_date, 
						  original_source_book, original_source_instrument_number, original_source_page, re_recording_book, re_recording_date, re_recording_instrument_number, re_recording_page, recording_source_book, recording_source_date, 
						  recording_source_instrument_number, recording_source_page, section_block_lot, short_legal, transfer_cert_title_number, MortgageStartDate, State, CONVERT(date, GETDATE())
						  ,REQUEST_DATE
		FROM     [zCust_PennyMac].[dbo].[x_Custom_OUT_EXCEPTION_SEND]

		--Select distinct * From [x_Custom_OUT_EXCEPTION_SEND_HIST]
		--where DATE_SENT = '2020-10-16'
		--and legal_description not like 'NOT%'
		--and legal_description not like '%“%'
		--and legal_description not like '%”%'
		----Group by LoanID
		--Order by LoanID

		Truncate table x_Custom_OUT_EXCEPTION_SEND


		----Archive Success
		Insert into [zCust_PennyMac].[dbo].[x_Custom_OUT_SUCCESS_HIST]
		Select * ,convert(date,Getdate())
		From [zCust_PennyMac].[dbo].[x_Custom_OUT_SUCCESS]

		--Select distinct * From [x_Custom_OUT_SUCCESS_HIST]
		--where DATE_SENT = '2020-10-16'
		--and legal_description not like 'NOT%'
		--and legal_description not like '%“%'
		--and legal_description not like '%”%'
		----Group by LoanID
		--Order by LoanID

		Truncate table [x_Custom_OUT_SUCCESS]

		Truncate table [x_Custom_OUTPUT]


		
	
		


END






