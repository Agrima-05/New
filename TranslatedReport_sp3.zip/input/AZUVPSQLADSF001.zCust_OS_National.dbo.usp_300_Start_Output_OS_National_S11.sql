SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE PROCEDURE [zCust_OS_National].[dbo].[usp_300_Start_Output_OS_National_S11]


AS
BEGIN
	
	SET NOCOUNT ON;

	-----20231030---




		DROP TABLE [dbo].[x_Custom_OUTPUT_S11]

		CREATE TABLE [dbo].[x_Custom_OUTPUT_S11](
			[FIPS][varchar](5)NULL,
			--[WORK_REF_ID][varchar](250)NULL,
			[PROPERTYID][varchar](250)NULL,
			[INPUTKEY][varchar](250)Null,
			[INPUT_Customer ID][varchar](250)NULL,
			[INPUT_UniqueID][varchar](250)NULL,
			[INPUT_ADDRESS][varchar](250)NULL,
			[INPUT_CITY][varchar](250)NULL,
			[INPUT_STATE][varchar](250)NULL,
			[INPUT_ZIPCODE][varchar](250)NULL,
			[INPUT_CURRENTOWNER][varchar](250)NULL,
			[Property Address][varchar](250)NULL,
			[City][varchar](250)NULL,
			[State][varchar](250)NULL,
			[Zip Code][varchar](250)NULL,
			[Run Date][varchar](250)NULL,
			[Coverage Status][varchar](250)NULL,
			[Address Standardization][varchar](250)NULL,
			[Property Status][varchar](250)NULL,
			[Transaction Status][varchar](250)NULL,
			--[Against Input Lien][varchar](250)NULL,


			----------INTERNAL---------
			[Start Date][varchar](250)Null,
			[MAX_PFC_RECDATE]	[varchar](250)NULL,
			[Nbr of Transactions][varchar](250)Null
			
			--,[DATE_ADDED]	[varchar](250)NULL
	
			
			
		) ON [PRIMARY]

		

	
		SET CONCAT_NULL_YIELDS_NULL OFF
		

		  INSERT INTO [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] ([INPUTKEY],
			[INPUT_Customer ID],
			[INPUT_UniqueID],
			[INPUT_ADDRESS],
			[INPUT_CITY],
			[INPUT_STATE],
			[INPUT_ZIPCODE],
			FIPS,
			PROPERTYID,
			[MAX_PFC_RECDATE],
			[Start Date],
			[INPUT_CURRENTOWNER]
	   )
	
		Select 	
		[INPUTKEY]
		,CUSTOMERID
		,[UniqueId]
		,[Address]
		,[City]
		,[State]
		,[ZipCODE]
		,FIPS
		,[PROPERTYID]
		,[MAX_PFC_RECDATE]
		,convert(Date,[START DATE])
		,[INPUT_OWNER]
		--Select * 
	   
	   FROM [zCust_OS_National].[dbo].[INPUT_MONITOR]
		where [Monitoring Type] not like 'D'
		and [INPUTKEY] is not null

		
		------********ONLY RUN FULL PORTFOLIO on 5th of month or next bus day****-------
		DECLARE @TODAY date = convert(date,getdate())
		DECLARE @5th date = (Select top 1  [CalendarDate] FROM [Global].[dbo].[Calendar]	A with(NOLOCK)
		where 
		convert(varchar(6),[CalendarDate],112) = convert(varchar(6),getdate(),112)
		AND [CalendarDate] >= convert(date,(DATEADD("DD",3,FirstDateOfMonth))) 
		and BusinessDay = 1 
		and FAHoliday = 0
		and	Calendarday >= 5
		Order by A.[CalendarDate] asc) 

		
		IF @TODAY <> @5th
		BEGIN
		
		Delete from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		--Select * 
		From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] as A join [zCust_OS_National].[dbo].[INPUT_MONITOR] as B on 
		A.INPUTKEY = B.INPUTKEY
		where B.DATE_RECEIVED < convert(Date,getdate())


		END

		
		

	

	  
	  
	  Select top 100 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] as A 
	  Order by FIPS
	  
	  
		--UPDATE a 
		--SET 
		--a.Fips = C.FIPS
		--FROM x_Custom_OUTPUT_S11 a JOIN data.dbo.Property as  c with(NOLOCK)
		--on a.PropertyID = c.PropertyID

			

		--UPDATE a 
		--SET 
		--a.[PROPERTYID] = c.[PROPERTYID]
		--,a.WORK_REF_ID = c.REF_ID
		--,a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		--FROM x_Custom_OUTPUT_S11 a JOIN [dbo].a_PropMatch_Work_FLANK c on a.[INPUTKey] = c.RAW_ID

		

		Update [zCust_OS_National].[dbo].[a]
		SET a.[Property Address] = c.FullStreetAddress
		, a.[City] = c.City
		, a.[State] = c.[State]
		, a.[Zip Code] = c.Zip + c.Zip4
		, a.[Run Date] = convert(date,GetDate())
		--, a.Fips = CASE WHEN LEN(c.FIPS) = 4 THEN '0' + c.FIPS ELSE c.FIPS END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] c
					ON a.[INPUTKey] = c.RAW_ID


		
		Update [zCust_OS_National].[dbo].[a]
		set 
		[Coverage Status] = B.ForeclosureActive
		--[PreForeclosure Coverage ] = B.ForeclosureActive
		--,A.[Preforeclosure Thru Date] = convert(date,B.ForeclosureMaxRecordDate)
		--,A.[Deed Coverage] = B.DeedActive
		--,A.[Deed Thru Date]= convert(date,B.DeedMaxREcordDate)
		--Select D_Flag 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] a 
			JOIN [Global].[dbo].[county] b  with(NOLOCK)
			ON a.FIPs = b.FIPSCODE

	
		------------------------------------------------------------------------

		   Update [zCust_OS_National].[dbo].[w_TransHist_FLANK] 
		   SET toUse = NULL
		   where toUse is not null

		 

		   ----PFC records---
		   ------20231030 - Per Nicole - Return All PFC recordings after their input date
		   	------20231211 - Per EC - Cust will not always have an input start date.  
			------If they do not - we use the Curr Sale recording date - if none - return ALLL

			UPDATE [zCust_OS_National].[dbo].[A]
			SET ToUse = 'Y' 
			--Select B.[INPUTKey], B.[INPUT Start Date], A.PropertyID,A.Doc_Id,DocumentTypeDesc--, C.*
			FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK] a JOIN [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] as B on 
			A.RAW_ID = B.[INPUTKey]  
			join [zCust_OS_National].[dbo].[w_FLANK_NOD] as C on A.RAW_ID = C.RAW_ID and A.Doc_Id = C.TransactionId
			left outer join [data].[dbo].[PROPERTY] as D with(NOLOCK) on B.FIPS = D.FIPS and B.PropertyID = D.PropertyiD
			where Doc_Src_Ind like 'R'
			and DocumentTypeDesc not like 'RELEASE' and DocumentTypeDesc not like 'Assignment%'
			and convert(date,A.recordingdate) >case 
				when B.[Start Date] is NOT null then convert(date,B.[Start Date])
				when B.[Start Date] is NULL and ISNULL(D.CurrSaleRecordingDate,'') not like '' then  convert(date,D.CurrSaleRecordingDate)
				else convert(date,'1900-01-01') end 
			AND (convert(date,A.recordingdate) > B.MAX_PFC_RECDATE
			OR B.MAX_PFC_RECDATE is null)


		
		
	

		

	Truncate table [dbo].w_TransHist_FLANK_II

	INSERT INTO [zCust_OS_National].[dbo].[w_TransHist_FLANK_II](Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate,[PROPERTYID],REO,REOSALE )
SELECT Fips, REF_ID, RecordNumber, RecordingDate, DocumentType, DocumentNbr,  BuyerBorrower, SellerLender, Value, OrigTransRecDate, OrigTransDocNumber,  OrigLoanAmount, 
                  Lien_Pos, CmtId, Source_Type, Doc_Id, Doc_Src_Ind, OrigDoc_Id, DocumentTypeDesc, TransType, ToUse, RAW_ID, ChronoKey, NewLenderAssignee, OldLenderAssignor, FA_DocNbrFmt, FA_YearDocNbrFmt, FA_YearDayDocNumFmt, 
                  FA_BookPageFmt, FA_YearBookPageFmt, FA_CMTID_DocNum, FA_CMTID_YearDocNum, FA_CMTID_YearDateDocNum, FA_CMTID_BookPage, FA_CMTID_YearBookPage, DocDate,  
                   LOANTYPE, BuyerBorrower1, BuyerBorrower2, PURCHASE, RateType, Rate ,[PROPERTYID],REO,REOSALE
FROM     [zCust_OS_National].[dbo].[w_TransHist_FLANK]
WHERE  (ToUse = 'Y')


			UPDATE [zCust_OS_National].[dbo].[t] SET RecordNumber = RowNum
			FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] t LEFT JOIN
			(SELECT * 
				,ROW_NUMBER() OVER(PARTITION BY RAW_ID ORDER BY RAW_ID,RecordingDate DESC) AS RowNum
				FROM 
			[zCust_OS_National].[dbo].[w_TransHist_FLANK_II] t WHERE ToUse = 'Y' ) r ON t.RAW_ID = r.RAW_ID 
			AND t.Doc_ID = r.Doc_ID and T.Doc_Src_Ind = R.Doc_Src_Ind


		Select RAW_ID, REF_ID, REcordingDate, DocumentType, DOcumentNbr, REcordNumber From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		Order by RAW_ID, RecordingDate

		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		where RecordNumber is null


		Select * From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] as A join 
		(Select RAW_ID, REcordNumber, count(*) as TOTAL From [zCust_OS_National].[dbo].[w_TransHist_FLANK_II]
		Group by RAW_ID, REcordNumber
		having count(*) > 1)B on 
		A.RAW_ID = B.RAW_ID and A.REcordNumber = B.RecordNumber
		Order by A.RAW_ID,A.REcordNumber

		
		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Set [Nbr of Transactions] = NULL

		UPDATE [zCust_OS_National].[dbo].[a]
		SET a.[Nbr of Transactions] = b.NbrOfRecordings
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] a JOIN (SELECT RAW_ID,MAX(RecordNumber) NbrOfRecordings 
		FROM [zCust_OS_National].[dbo].[w_TransHist_FLANK_II] GROUP BY RAW_ID) b
		on a.[INPUTKey] = b.RAW_ID

		Select max(convert(int,[Nbr of Transactions])) from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]

		


		Declare @BeginNbrOfTrans int
		Declare @EndNbrOfTrans int

		SET @BeginNbrOfTrans = 1
		Select @EndNbrOfTrans = case when max(convert(int,[Nbr of Transactions])) is null then 1 else  
		max(convert(int,[Nbr of Transactions])) end FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		

			WHILE (@BeginNbrOfTrans <= @EndNbrOfTrans)
				BEGIN
				 
					DECLARE @RecNbr as varchar(5)
					SET @RecNbr = RIGHT('000' + convert(varchar(5),@BeginNbrOfTrans),3)

					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Record Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Against Input Lien_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Document Type_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Document Nbr_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Value_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Borrower/Buyer_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Lender/Seller_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Document Nbr_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Recording Date_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Original Loan Amount_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeTelephoneNumber_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeFullStreetAddress_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeUnitNumber_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeCityName_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeStateCode_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeZipCode_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeZipplus4_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeFirstName&MiddleInitial_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [UnPaid Balance_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Location Street_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Location City_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Location State_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Location Zip_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Trustee_' + @RecNbr + '] [varchar](250) NULL')
					EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Attorney_' + @RecNbr + '] [varchar](250) NULL')

					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeLastNameORCorporationName_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeCareofName_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [TrusteeSaleNumber_' + @RecNbr + '] [varchar](250) NULL')
					--EXEC('ALTER Table x_Custom_OUTPUT_S11 ADD [Auction Date_' + @RecNbr + '] [varchar](250) NULL')

					-----20231030 - Per Nicole:
					----Force Auction State as Situs State
					----There is no Auction ZIp so leave BLANK
					----Trustee & Attorney are same field - so ONLY populate Trustee field
					----Leave Against Input Lien field blank
				
					EXEC('UPDATE a
					SET 
					A.[Record Nbr_' + @RecNbr + '] = b.REcordNumber
					,A.[Recording Date_' + @RecNbr + '] = b.RecordingDate
					,A.[Document Type_' + @RecNbr + '] = b.DocumentType
					,A.[Document Nbr_' + @RecNbr + '] = b.DocumentNbr
					,A.[Original Document Nbr_' + @RecNbr + '] = b.OrigTransDocNumber
					,A.[Original Recording Date_' + @RecNbr + '] = convert(date,b.OrigTransRecDate)
					,A.[Unpaid Balance_' + @RecNbr + '] = C.UNPAIDBALANCE
					,A.[Auction Location Street_' + @RecNbr + '] = C.AuctionLocation
					,A.[Auction Location City_' + @RecNbr + '] = C.AuctionCity
					,A.[Auction Location State_' + @RecNbr + '] = A.State
					,A.[Trustee_' + @RecNbr + '] = case when ISNULL(C.TrusteeFirstNameMiddleInitial,'''') like ''''
					then C.TrusteeLastNameorCorp else C.TrusteeFirstNameMiddleInitial + '' '' + C.TrusteeLastNameorCorp end

					--Select B.* , C.*
					FROM x_Custom_OUTPUT_S11 a JOIN 
					w_TransHist_FLANK_II as B on 
					a.[INPUTKey] = b.RAW_ID
					join w_FLANK_NOD as C on B.FIPS = C.FIPS and B.PropertyID = C.FAPROPERTYID
					and B.DOC_ID = C.Transactionid
					AND B.REcordNumber = ' + @BeginNbrOfTrans + '') 

					

					

					EXEC('
					Update A
					SET A.[Document Type_' + @RecNbr + '] = Upper(b.[Codedesc])
					from x_Custom_OUTPUT_S11 a join [Global].[dbo].[lkup_Doc_Type] b with(NOLOCK)
					ON A.[Document Type_' + @RecNbr + '] = b.[DocTypeID]
					')


							


					SET @BeginNbrOfTrans = @BeginNbrOfTrans + 1
				
				END


		----------------------

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] 
		SET [Coverage Status] = CASE WHEN [Coverage Status] = '1' THEN 'In Coverage' ELSE 'Not In Coverage' END

		
		Update  [zCust_OS_National].[dbo].[a]
		SET a.[Address Standardization] = CASE WHEN (b.CarrierCode is not null and b.CarrierCode not like '') THEN 'Standardized' ELSE 'Not Standardized' END
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] a JOIN [zCust_OS_National].[dbo].[a_ASP_IN_STD] b
		on a.[INPUTKey] = b.Raw_ID

		Update [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		SET [Property Status] = CASE WHEN 
		--(WORK_REF_ID is not null and WORK_REF_ID not like '' and WORK_REF_ID not like '0') 
		--or 
		(PropertyID is not null and PropertyID not like '' and PropertyID not like '0') 
		THEN 'Property Found' ELSE 'Property Not Found' END


		UPDATE [zCust_OS_National].[dbo].[a] SET [Property Status] = 'Multiple Properties Found' 
		FROM [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11] a join [zCust_OS_National].[dbo].[a_PropMatch_Work_FLANK] b
		on a.[INPUTKey] = b.RAW_ID
		WHERE b.MultiMatch = 'M'
		--AND (A.WORK_REF_ID is null OR A.WORK_REF_ID like '' OR A.WORK_REF_ID like '0') 
		AND 
		(A.PropertyID is null OR A.PropertyID like '' OR A.PropertyID like '0') 

	
		Update  [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Set [Transaction Status] = case when [Nbr of Transactions] > 0 then  'Event Found' else 'Event Not Found'
		end
		


		Select * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		where [Nbr of Transactions] > 0 and 
		[Transaction Status] = 'Event Not Found' 
		

		
		Select [Property Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Property Status]

		Select [Address Standardization], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Address Standardization]

		Select [Transaction Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Transaction Status]

		
		Select [Coverage Status], count(*) From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Group by [Coverage Status]

		Select * from [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		where [Property Status] like 'Property Not Found'

		Select top 1000 * From [zCust_OS_National].[dbo].[x_Custom_OUTPUT_S11]
		Order by convert(int,[Nbr of Transactions]) desc

	
	

END





