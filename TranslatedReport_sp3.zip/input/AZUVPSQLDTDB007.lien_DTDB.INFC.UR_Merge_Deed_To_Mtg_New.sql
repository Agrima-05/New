/* Source: AZUVNSQLDTDB003.datatree.local | lien_DTDB | INFC.UR_Merge_Deed_To_Mtg_New | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [lien_DTDB].[INFC].[UR_Merge_Deed_To_Mtg_New] @ERROR VARCHAR(500) OUTPUT
	/*
input 
	UR_Deedwrk and UR_Mortgagewrk 
		module where Deed is merge into UR_Deedwrk and UR_Mortgagewrk
				UR_Insert_Existing_Deed_Into_UR_DeedWrk
					-- delete Deed records for which we have a record with a re-processflag
					-- create UR_Deed_Reject records if the incoming record is found on the DB and the doc_id is not the same
					   and then delete the record on the Deed db
					-- insert into UR_DeedWrk all the records for a ref_id if the doc_type not in 'CD','RD','MO'
						and the first 4 of buyer is the same on the Deed and UR_MortgageWrk
					-- Delete duplicates on UR_DeedWrk


				UR_Insert_Existing_Mortgage_Into_UR_MortgageWrk
					-- delete Deed records for which we have a record with a re-processflag and the Deed.doc_nbr is compare to UR_MortgageWrk.doc_nubmer
						?? this means a reporcess of a mortgage the is already linked to a Deed is not removed from the Deed table
					-- Create a UR_Mtg_Reject if you find the Deed.doc_nbr is compare to UR_MortgageWrk.doc_nubmer 
					    and then the Deed record is deleted - this will only be truu if the record on Deed table is stand alone
					-- Insert into UR_MortgageWrk - i dont get it
						they read Deed_wrk,and then link to Deed where source tbl is EPM which means they only link to stand alone mortgages
						??? when will they pick up the mortgages that is already merged into a Deed
					-- then they delete the stand alone mortgage on Deed table 

					nowhere is records kept of wha they delete from Deed - how is the normandy tables maintained?
		
-- end prodict is  Deed wrk and mtg wrk

EXEC DEED.[dbo].[UR_Merge_Deed_To_Mtg_New_Paul]

--
--implementation notes
-- change the column names on Deedmtg2 from buyr1_5 to 4

*/
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
paul	20221018	removed the check where Deedid and mtgid is the same
paul	20221021	check all buyer name and make about null
paul	20221026	Only check buyer name 1 of the Deed to all the buyer names on the mortgage
Marie and paul 
		20230929	USe Situs from Mortgate if not available on deed
Marie and paul
		20240322	change the merge logic to zero space fill the doc number 
Marie and paul
		20250718	B30718 -- add test 7 for dedupe of records without ref_id and apn
******************************************************************************************************************/
--declare @ERROR VARCHAR(500) OUTPUT
BEGIN TRY
	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Merge_Deed_To_Mtg_New'
		,N'Started'

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp]
		CREATE TABLE [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] (
			[ROW4] [bigint] NULL
			,[origin] [varchar](3) NULL
			,[_DeedMtg] [varchar](1) NULL
			,[DeedID] [int] NULL
			,[FIPS] [int] NULL
			,[REF_ID] [numeric](12, 0) NULL
			,[US_STATE] [char](2) NULL
			,[US_COUNTY] [varchar](36) NULL
			,[APN_unformatted] [varchar](45) NULL
			,[APN_formatted_UNIVERSAL] [varchar](60) NULL
			,[APN_SEQUENCE_NBR] [smallint] NULL
			,[ORIGINAL_APN] [varchar](45) NULL
			,[ACCOUNT_NBR] [varchar](15) NULL
			,[PENDING_TRANS] [char](1) NULL
			,[BYR1_CORP_IND] [char](1) NULL
			,[BYR1_OWN_NAME] [varchar](60) NOT NULL
			,[BYR1_OWN_ETAL_IND] [char](1) NULL
			,[BYR1_CO_NAME] [varchar](60) NULL
			,[BYR1_OWNERSHIP_RIGHTS_CODE] [char](3) NULL
			,[BYR1_OWN_RELATIONSHIP_TYPE] [char](3) NULL
			,[BYR1_OWNERSHIP] [varchar](3) NULL
			,[BYR2_CORP_IND] [char](1) NULL
			,[BYR2_OWN_NAME] [varchar](60) NOT NULL
			,[BYR2_OWNERSHIP_RIGHTS_CODE] [char](3) NULL
			,[BYR2_OWN_RELATIONSHIP_TYPE] [char](3) NULL
			,[BYR2_OWNERSHIP] [char](3) NULL
			,[BYR3_CORP_IND] [char](1) NULL
			,[BYR3_OWN_NAME] [varchar](60) NOT NULL
			,[BYR3_OWNERSHIP_RIGHTS_CODE] [char](3) NULL
			,[BYR3_OWN_RELATIONSHIP_TYPE] [char](3) NULL
			,[BYR3_OWNERSHIP] [char](3) NULL
			,[BYR4_CORP_IND] [char](1) NULL
			,[BYR4_OWN_NAME] [varchar](60) NOT NULL
			,[BYR4_OWNERSHIP_RIGHTS_CODE] [char](3) NULL
			,[BYR4_OWN_RELATIONSHIP_TYPE] [char](3) NULL
			,[BYR4_OWNERSHIP] [char](3) NULL
			,[BYR1_LAST_NAME] [varchar](30) NULL
			,[BYR1_FIRST_NAME] [varchar](32) NULL
			,[BYR1_MIDDLE_INITIAL] [varchar](12) NULL
			,[BYR1_SUFFIX] [char](4) NULL
			,[BYR2_LAST_NAME] [varchar](30) NULL
			,[BYR2_FIRST_NAME] [varchar](32) NULL
			,[BYR2_MIDDLE_INITIAL] [varchar](12) NULL
			,[BYR2_SUFFIX] [char](4) NULL
			,[BYR3_LAST_NAME] [varchar](30) NULL
			,[BYR3_FIRST_NAME] [varchar](32) NULL
			,[BYR3_MIDDLE_INITIAL] [varchar](12) NULL
			,[BYR3_SUFFIX] [char](4) NULL
			,[BYR4_LAST_NAME] [varchar](30) NULL
			,[BYR4_FIRST_NAME] [varchar](32) NULL
			,[BYR4_MIDDLE_INITIAL] [varchar](12) NULL
			,[BYR4_SUFFIX] [char](4) NULL
			,[MA_HOUSE_NBR_PREFIX] [char](5) NULL
			,[MA_HOUSE_NBR] [varchar](10) NULL
			,[MA_HOUSE_NBR_SUFFIX] [varchar](5) NULL
			,[MA_STREET_DIRECTION] [char](2) NULL
			,[MA_STREET_NAME] [varchar](30) NULL
			,[MA_MODE] [varchar](5) NULL
			,[MA_QUADRANT] [char](2) NULL
			,[MA_APARTMENT_UNIT] [char](11) NULL
			,[MA_CITY] [varchar](40) NULL
			,[MA_STATE] [char](2) NULL
			,[MA_ZIP_CODE] [varchar](9) NULL
			,[MA_CARRIER_CODE] [char](4) NULL
			,[MA_ORIGINAL_MAILING_ADDRESS] [varchar](60) NULL
			,[MA_DO_NOT_PUBLISH_FLAG] [char](1) NULL
			,[SITUS_HOUSE_NBR] [char](10) NULL
			,[SITUS_HOUSE_NBR2] [char](10) NULL
			,[SITUS_HOUSE_NBR_SUFFIX] [varchar](10) NULL
			,[SITUS_DIRECTION] [char](2) NULL
			,[SITUS_STREET_NAME] [varchar](30) NULL
			,[SITUS_MODE] [varchar](5) NULL
			,[SITUS_POST_DIRECTION] [char](2) NULL
			,[SITUS_UNIT_NBR] [varchar](11) NULL
			,[SITUS_CITY] [varchar](40) NULL
			,[SITUS_STATE] [char](2) NULL
			,[SITUS_ZIP_CODE] [varchar](9) NULL
			,[SITUS_CARRIER_CODE] [char](4) NULL
			,[ORIGINAL_SITE_ADDRESS] [varchar](60) NULL
			,[CLGX_UNIQUE_ID] [decimal](15, 0) NULL
			,[RECORDING_DATE] [date] NULL
			,[SALE_DATE] [date] NULL
			,[DOC_NBR] [varchar](12) NULL
			,[RECORDING_BOOK] [char](6) NULL
			,[RECORDING_PAGE] [char](6) NULL
			,[HAWAII_LAND_COURT_DOC_NBR] [varchar](12) NULL
			,[HAWAII_TCT_CERTIFICATE_NBR] [varchar](12) NULL
			,[WA_EXCISE_NBR] [varchar](12) NULL
			,[Deed_TYPE] [varchar](1) NULL
			,[DETAILED_DOC_TYPE] [char](2) NULL
			,[TRANSACTION_TYPE] [char](1) NULL
			,[SELLER_NAME_PLAINTIFF_1] [varchar](60) NOT NULL
			,[SELLER_NAME_PLAINTIFF1_CORP_IND] [char](1) NULL
			,[SELLER_NAME_PLAINTIFF_2] [varchar](60) NOT NULL
			,[SELLER_NAME_PLAINTIFF_2_CORP_IND] [char](1) NULL
			,[SALE_AMOUNT] [decimal](13, 2) NULL
			,[DOC_TRANSFER_TAX] [decimal](13, 2) NULL
			,[SALE_CODE] [char](1) NULL
			,[PARTIAL_INTEREST_IND] [char](1) NULL
			,[RESALE_NEW_CONSTRUCTION] [char](1) NULL
			,[INTER_FAMILY] [char](1) NULL
			,[FORCLOSURE] [char](1) NULL
			,[REO_SALE] [char](1) NULL
			,[MTG1_RECORDING_DATE] [date] NULL
			,[MTG1_DOC_DATE] [date] NULL
			,[MTG1_DOC_NBR] [varchar](12) NULL
			,[MTG1_RECORDING_BOOK] [char](6) NULL
			,[MTG1_RECORDING_PAGE] [char](6) NULL
			,[MTG1_DETAILED_DOC_TYPE] [char](2) NULL
			,[MTG1_MTG_AMOUNT] [decimal](13, 2) NULL
			,[MTG1_LENDER_LAST_NAME] [varchar](30) NULL
			,[MTG1_LENDER_FIRST_NAME] [varchar](30) NULL
			,[MTG1_LENDER_ADDRESS] [varchar](60) NULL
			,[MTG1_LENDER_CITY] [varchar](30) NULL
			,[MTG1_LENDER_STATE] [char](2) NULL
			,[MTG1_LENDER_ZIP] [varchar](9) NULL
			,[MTG1_MTG_COMPANY_CODE] [char](6) NULL
			,[MTG1_MTG_LOAN_TYPE_CODE] [char](3) NULL
			,[MTG1_MTG_TERM_CODE] [char](1) NULL
			,[MTG1_MTG_TERM_] [char](4) NULL
			,[MTG1_MTG_DUE_DATE] [date] NULL
			,[MTG1_MTG_INTEREST_RATE_TYPE] [char](3) NULL
			,[MTG1_MTG_INTEREST_RATE] [char](7) NULL
			,[MTG1_SELLER_CARRY_BACK] [char](1) NULL
			,[MTG1_PRIVATE_PARTY_LENDER] [char](1) NULL
			,[MTG1_CONSTRUCTION_LOAN] [char](1) NULL
			,[MTG1_REFI_FLAG] [char](1) NULL
			,[MTG1_EQUITY_FLAG] [char](1) NULL
			,[MTG1_OTHER_SUBORDINATE_LOANS] [char](1) NULL
			,[MTG2_RECORDING_DATE] [date] NULL
			,[MTG2_DOC_DATE] [date] NULL
			,[MTG2_DOC_NBR] [char](12) NULL
			,[MTG2_RECORDING_BOOK] [char](6) NULL
			,[MTG2_RECORDING_PAGE] [char](6) NULL
			,[MTG2_DETAILED_DOC_TYPE] [char](2) NULL
			,[MTG2_MTG_AMOUNT] [decimal](13, 2) NULL
			,[MTG2_LENDER_LAST_NAME] [varchar](30) NULL
			,[MTG2_LENDER_FIRST_NAME] [varchar](30) NULL
			,[MTG2_LENDER_ADDRESS] [varchar](60) NULL
			,[MTG2_LENDER_CITY] [varchar](30) NULL
			,[MTG2_LENDER_STATE] [char](2) NULL
			,[MTG2_LENDER_ZIP] [varchar](9) NULL
			,[MTG2_MTG_COMPANY_CODE] [char](6) NULL
			,[MTG2_MTG_LOAN_TYPE_CODE] [char](3) NULL
			,[MTG2_MTG_TERM_CODE] [char](1) NULL
			,[MTG2_MTG_TERM] [char](4) NULL
			,[MTG2_MTG_DUE_DATE] [date] NULL
			,[MTG2_MTG_INTEREST_RATE_TYPE] [char](3) NULL
			,[MTG2_MTG_INTEREST_RATE] [char](7) NULL
			,[MTG2_SELLER_CARRY_BACK] [char](1) NULL
			,[MTG2_PRIVATE_PARTY_LENDER] [char](1) NULL
			,[MTG2_CONSTRUCTION_LOAN] [char](1) NULL
			,[MTG2_REFI_FLAG] [char](1) NULL
			,[MTG2_EQUITY_FLAG] [char](1) NULL
			,[MTG2_OTHER_SUBORDINATE_LOANS] [char](1) NULL
			,[MTG3_RECORDING_DATE] [date] NULL
			,[MTG3_DOC_DATE] [date] NULL
			,[MTG3_DOC_NBR] [varchar](12) NULL
			,[MTG3_RECORDING_BOOK] [char](6) NULL
			,[MTG3_RECORDING_PAGE] [char](6) NULL
			,[MTG3_DETAILED_DOC_TYPE] [char](2) NULL
			,[MTG3_MTG_AMOUNT] [decimal](13, 2) NULL
			,[MTG3_LENDER_LAST_NAME] [varchar](30) NULL
			,[MTG3_LENDER_FIRST_NAME] [varchar](30) NULL
			,[MTG3_LENDER_ADDRESS] [varchar](60) NULL
			,[MTG3_LENDER_CITY] [varchar](30) NULL
			,[MTG3_LENDER_STATE] [char](2) NULL
			,[MTG3_LENDER_ZIP] [varchar](9) NULL
			,[MTG3_MTG_COMPANY_CODE] [char](6) NULL
			,[MTG3_MTG_LOAN_TYPE_CODE] [char](3) NULL
			,[MTG3_MTG_TERM_CODE] [char](1) NULL
			,[MTG3_MTG_TERM] [char](4) NULL
			,[MTG3_MTG_DUE_DATE] [date] NULL
			,[MTG3_MTG_INTEREST_RATE_TYPE] [char](3) NULL
			,[MTG3_MTG_INTEREST_RATE] [char](7) NULL
			,[MTG3_SELLER_CARRY_BACK] [char](1) NULL
			,[MTG3_PRIVATE_PARTY_LENDER] [char](1) NULL
			,[MTG3_CONSTRUCTION_LOAN] [char](1) NULL
			,[MTG3_REFI_FLAG] [char](1) NULL
			,[MTG3_EQUITY_FLAG] [char](1) NULL
			,[MTG3_OTHER_SUBORDINATE_LOANS] [char](1) NULL
			,[MTG4_RECORDING_DATE] [date] NULL
			,[MTG4_DOC_DATE] [date] NULL
			,[MTG4_DOC_NBR] [char](12) NULL
			,[MTG4_RECORDING_BOOK] [char](6) NULL
			,[MTG4_RECORDING_PAGE] [char](6) NULL
			,[MTG4_DETAILED_DOC_TYPE] [char](2) NULL
			,[MTG4_MTG_AMOUNT] [decimal](13, 2) NULL
			,[MTG4_LENDER_LAST_NAME] [varchar](30) NULL
			,[MTG4_LENDER_FIRST_NAME] [varchar](30) NULL
			,[MTG4_LENDER_ADDRESS] [varchar](60) NULL
			,[MTG4_LENDER_CITY] [varchar](30) NULL
			,[MTG4_LENDER_STATE] [char](2) NULL
			,[MTG4_LENDER_ZIP] [varchar](9) NULL
			,[MTG4_MTG_COMPANY_CODE] [char](6) NULL
			,[MTG4_MTG_LOAN_TYPE_CODE] [char](3) NULL
			,[MTG4_MTG_TERM_CODE] [char](1) NULL
			,[MTG4_MTG_TERM] [char](4) NULL
			,[MTG4_MTG_DUE_DATE] [date] NULL
			,[MTG4_MTG_INTEREST_RATE_TYPE] [char](3) NULL
			,[MTG4_MTG_INTEREST_RATE] [char](7) NULL
			,[MTG4_SELLER_CARRY_BACK] [char](1) NULL
			,[MTG4_PRIVATE_PARTY_LENDER] [char](1) NULL
			,[MTG4_CONSTRUCTION_LOAN] [char](1) NULL
			,[MTG4_REFI_FLAG] [char](1) NULL
			,[MTG4_EQUITY_FLAG] [char](1) NULL
			,[MTG4_OTHER_SUBORDINATE_LOANS] [char](1) NULL
			,[ORIGINAL_RECORDED_DATE] [date] NULL
			,[ORIGINAL_BKPG] [varchar](12) NULL
			,[ORIGINAL_DOC_NBR] [varchar](12) NULL
			,[SECTION] [char](3) NULL
			,[TOWNSHIP] [char](3) NULL
			,[RANGE] [char](3) NULL
			,[DISTRICT_CODE] [varchar](8) NULL
			,[LOT] [char](6) NULL
			,[BLOCK] [char](6) NULL
			,[SUBDIVISION_NAME] [varchar](60) NULL
			,[UNIT] [varchar](8) NULL
			,[BUILDING] [varchar](8) NULL
			,[PLAT_SUBD_MAP_BOOK] [char](6) NULL
			,[PLAT_SUBD_MAP_PAGE] [char](6) NULL
			,[MAP_TYPE_IND] [char](3) NULL
			,[EXPANDED_LEGAL] [varchar](250) NULL
			,[TRACT_NBR] [varchar](30) NULL
			,[LAND_LOT] [char](6) NULL
			,[TITLE_COMPANY_NAME] [varchar](60) NULL
			,[TITLE_COMPANY_CODE] [varchar](5) NULL
			,[MULTI_APN] [char](1) NULL
			,[SALES_SOURCE_IND] [char](1) NULL
			,[TIMESTAMP_DATE] [date] NULL
			,[RECORD_TYPE] [char](1) NULL
			,[PRI_CAT_CODE] [char](1) NULL
			,[CREATED] [datetime] NULL
			,[PREVIOUS_PARCEL_NBR] [varchar](45) NULL
			,[PREVIOUS_PARCEL_SEQUENCE_NBR] [smallint] NULL
			,[FMT_DOC_NBR] [varchar](20) NULL
			,[CMT_ID_DOC_NBR] [int] NULL
			,[FMT_MTG1_DOC_NBR] [varchar](20) NULL
			,[CMT_ID_MTG1_DOC_NBR] [int] NULL
			,[FMT_MTG2_DOC_NBR] [varchar](20) NULL
			,[CMT_ID_MTG2_DOC_NBR] [int] NULL
			,[FMT_MTG3_DOC_NBR] [varchar](20) NULL
			,[CMT_ID_MTG3_DOC_NBR] [int] NULL
			,[FMT_MTG4_DOC_NBR] [varchar](20) NULL
			,[CMT_ID_MTG4_DOC_NBR] [int] NULL
			,[FMT_Book_Page] [varchar](20) NULL
			,[CMT_ID_Book_Page] [int] NULL
			,[FMT_MTG1_Book_Page] [varchar](20) NULL
			,[CMT_ID_MTG1_Book_Page] [int] NULL
			,[FMT_MTG2_Book_Page] [varchar](20) NULL
			,[CMT_ID_MTG2_Book_Page] [int] NULL
			,[FMT_MTG3_Book_Page] [varchar](20) NULL
			,[CMT_ID_MTG3_Book_Page] [int] NULL
			,[FMT_MTG4_Book_Page] [varchar](20) NULL
			,[CMT_ID_MTG4_Book_Page] [int] NULL
			,[Source_type] [char](1) NULL
			,[SRC_TBL] [varchar](3) NULL
			,[MOD_RAS_CLGX_UNIQUE_ID] [decimal](15, 0) NULL
			,[UR_Doc_Unique_Id] [varchar](200) NULL
			,[UR_Doc_Id] [int] NULL
			,[UR_Property_Id] [int] NULL
			,[UR_Name_Id] [int] NULL
			,[UR_Reference_Id] [int] NULL
			,[FORECLOSURE_FLAG] [bit] NULL
			,[REO_SALE_FLAG] [bit] NULL
			,[ARMS_LENGTH_ID] [bit] NULL
			,[MTG1_UR_Doc_Id] [int] NULL
			,[MTG2_UR_Doc_Id] [int] NULL
			,[MTG3_UR_Doc_Id] [int] NULL
			,[MTG4_UR_Doc_Id] [int] NULL
			,[DATA_SRC_IND] [varchar](1) NULL
			,[UR_Prop_Seq_Num] [int] NULL
			,[UR_Reprocess_Flag] [varchar](1) NULL
			,[Attorney_Name_identifier] [char](1) NULL
			,[Attorney_Last_Name] [varchar](60) NULL
			,[Attorney_First_Name] [varchar](32) NULL
			,[Attorney_Middle_Initial] [varchar](30) NULL
			,[Attorney_suffix] [varchar](5) NULL
			,[Attorney_address] [varchar](60) NULL
			,[Attorney_Address_City] [varchar](30) NULL
			,[Attorney_Address_State] [varchar](4) NULL
			,[Attorney_Address_Zip] [varchar](9) NULL
			,[Attorney_Phone] [varchar](15) NULL
			,[Attorney_Full_Name] [varchar](60) NULL
			,[UR_REMARKS] [varchar](200) NULL
			,[BYR1_4] [varchar](4) NULL
			,[BYR2_4] [varchar](4) NULL
			,[BYR3_4] [varchar](4) NULL
			,[BYR4_4] [varchar](4) NULL
			,[mtg_occ] [int] NOT NULL
			,[HI_PRefix] [varchar](1) NULL
			,[dup_doc_nbr] [bigint] NULL
			,[_ld] [varchar](1) NULL
			,[ORIG_MTG1_Lender_Name] [varchar](30) NULL    
			,[ORIG_MTG2_Lender_Name] [varchar](30) NULL    
			,[ORIG_MTG3_Lender_Name] [varchar](30) NULL    
			,[ORIG_MTG4_Lender_Name] [varchar](30) NULL    
			,[NMLSLenderName_1] [varchar](200) NULL    
			,[NMLSLenderId_1] [int] NULL    
			,[NMLSBrokerName_1] [varchar](200) NULL    
			,[NMLSBrokerId_1] [int] NULL    
			,[NMLSAgentName_1] [varchar](200) NULL    
			,[NMLSAgentId_1] [int] NULL 
			,[NMLSLenderName_2] [varchar](200) NULL    
			,[NMLSLenderId_2] [int] NULL    
			,[NMLSBrokerName_2] [varchar](200) NULL    
			,[NMLSBrokerId_2] [int] NULL    
			,[NMLSAgentName_2] [varchar](200) NULL    
			,[NMLSAgentId_2] [int] NULL 
			,[NMLSLenderName_3] [varchar](200) NULL    
			,[NMLSLenderId_3] [int] NULL    
			,[NMLSBrokerName_3] [varchar](200) NULL    
			,[NMLSBrokerId_3] [int] NULL    
			,[NMLSAgentName_3] [varchar](200) NULL    
			,[NMLSAgentId_3] [int] NULL 
			,[NMLSLenderName_4] [varchar](200) NULL    
			,[NMLSLenderId_4] [int] NULL    
			,[NMLSBrokerName_4] [varchar](200) NULL    
			,[NMLSBrokerId_4] [int] NULL    
			,[NMLSAgentName_4] [varchar](200) NULL    
			,[NMLSAgentId_4] [int] NULL 
			,[Attorney_Email] [varchar](100) NULL
			,[Attorney_Firm_Name] [varchar](60) NULL
			,[Mtg1_Int_Source] [varchar](10) NULL
			,[Mtg2_Int_Source] [varchar](10) NULL
			,[Mtg3_Int_Source] [varchar](10) NULL
			,[Mtg4_Int_Source] [varchar](10) NULL
			)

	--
	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] (deedid)

	--
	INSERT INTO [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] (
		[ROW4]
		,[origin]
		,[_DeedMtg]
		,[DeedID]
		,[FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[Deed_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[FORECLOSURE_FLAG]
		,[REO_SALE_FLAG]
		,[ARMS_LENGTH_ID]
		,[MTG1_UR_Doc_Id]
		,[MTG2_UR_Doc_Id]
		,[MTG3_UR_Doc_Id]
		,[MTG4_UR_Doc_Id]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[UR_REMARKS]
		,[BYR1_4]
		,[BYR2_4]
		,[BYR3_4]
		,[BYR4_4]
		,[mtg_occ]
		,[dup_doc_nbr]
		,[_ld]    
		,[ORIG_MTG1_Lender_Name]      
		,[ORIG_MTG2_Lender_Name]      
		,[ORIG_MTG3_Lender_Name]      
		,[ORIG_MTG4_Lender_Name]      
		,[NMLSLenderName_1]       
		,[NMLSLenderId_1]       
		,[NMLSBrokerName_1]       
		,[NMLSBrokerId_1]       
		,[NMLSAgentName_1]       
		,[NMLSAgentId_1]       
		,[NMLSLenderName_2]       
		,[NMLSLenderId_2]       
		,[NMLSBrokerName_2]       
		,[NMLSBrokerId_2]       
		,[NMLSAgentName_2]       
		,[NMLSAgentId_2]       
		,[NMLSLenderName_3]       
		,[NMLSLenderId_3]       
		,[NMLSBrokerName_3]       
		,[NMLSBrokerId_3]       
		,[NMLSAgentName_3]       
		,[NMLSAgentId_3]       
		,[NMLSLenderName_4]       
		,[NMLSLenderId_4]       
		,[NMLSBrokerName_4]       
		,[NMLSBrokerId_4]       
		,[NMLSAgentName_4]       
		,[NMLSAgentId_4]   
		,[Attorney_Email]
		,[Attorney_Firm_Name]
		,[Mtg1_Int_Source]
		,[Mtg2_Int_Source]
		,[Mtg3_Int_Source]
		,[Mtg4_Int_Source]
		)
	SELECT ROW_NUMBER() OVER (
			PARTITION BY a.FIPS
			,a.REF_ID
			,substring(a.BYR1_OWN_NAME, 1, 5)
			,a.RECORDING_DATE ORDER BY isnull(a._DeedMtg, '')
				,isnull(a.Deed_TYPE, '')
				,isnull(a.DOC_NBR, '')
				,isnull(a.RECORDING_BOOK, '')
				,isnull(a.RECORDING_PAGE, '')
				,isnull(a.SALE_DATE, '') DESC
			) AS row4
		,a.Origin
		,a._DeedMtg
		,a.DeedID
		,a.FIPS
		,a.REF_ID
		,a.US_STATE
		,a.US_COUNTY
		,a.APN_unformatted
		,a.APN_formatted_UNIVERSAL
		,a.APN_SEQUENCE_NBR
		,a.ORIGINAL_APN
		,a.ACCOUNT_NBR
		,a.PENDING_TRANS
		,a.BYR1_CORP_IND
		,a.BYR1_OWN_NAME
		,a.BYR1_OWN_ETAL_IND
		,a.BYR1_CO_NAME
		,a.BYR1_OWNERSHIP_RIGHTS_CODE
		,a.BYR1_OWN_RELATIONSHIP_TYPE
		,a.BYR1_OWNERSHIP
		,a.BYR2_CORP_IND
		,a.BYR2_OWN_NAME
		,a.BYR2_OWNERSHIP_RIGHTS_CODE
		,a.BYR2_OWN_RELATIONSHIP_TYPE
		,a.BYR2_OWNERSHIP
		,a.BYR3_CORP_IND
		,a.BYR3_OWN_NAME
		,a.BYR3_OWNERSHIP_RIGHTS_CODE
		,a.BYR3_OWN_RELATIONSHIP_TYPE
		,a.BYR3_OWNERSHIP
		,a.BYR4_CORP_IND
		,a.BYR4_OWN_NAME
		,a.BYR4_OWNERSHIP_RIGHTS_CODE
		,a.BYR4_OWN_RELATIONSHIP_TYPE
		,a.BYR4_OWNERSHIP
		,a.BYR1_LAST_NAME
		,a.BYR1_FIRST_NAME
		,a.BYR1_MIDDLE_INITIAL
		,a.BYR1_SUFFIX
		,a.BYR2_LAST_NAME
		,a.BYR2_FIRST_NAME
		,a.BYR2_MIDDLE_INITIAL
		,a.BYR2_SUFFIX
		,a.BYR3_LAST_NAME
		,a.BYR3_FIRST_NAME
		,a.BYR3_MIDDLE_INITIAL
		,a.BYR3_SUFFIX
		,a.BYR4_LAST_NAME
		,a.BYR4_FIRST_NAME
		,a.BYR4_MIDDLE_INITIAL
		,a.BYR4_SUFFIX
		,a.MA_HOUSE_NBR_PREFIX
		,a.MA_HOUSE_NBR
		,a.MA_HOUSE_NBR_SUFFIX
		,a.MA_STREET_DIRECTION
		,a.MA_STREET_NAME
		,a.MA_MODE
		,a.MA_QUADRANT
		,a.MA_APARTMENT_UNIT
		,a.MA_CITY
		,a.MA_STATE
		,a.MA_ZIP_CODE
		,a.MA_CARRIER_CODE
		,a.MA_ORIGINAL_MAILING_ADDRESS
		,a.MA_DO_NOT_PUBLISH_FLAG
		,a.SITUS_HOUSE_NBR
		,a.SITUS_HOUSE_NBR2
		,a.SITUS_HOUSE_NBR_SUFFIX
		,a.SITUS_DIRECTION
		,a.SITUS_STREET_NAME
		,a.SITUS_MODE
		,a.SITUS_POST_DIRECTION
		,a.SITUS_UNIT_NBR
		,a.SITUS_CITY
		,a.SITUS_STATE
		,a.SITUS_ZIP_CODE
		,a.SITUS_CARRIER_CODE
		,a.ORIGINAL_SITE_ADDRESS
		,a.CLGX_UNIQUE_ID
		,a.RECORDING_DATE
		,a.SALE_DATE
		,a.DOC_NBR
		,a.RECORDING_BOOK
		,a.RECORDING_PAGE
		,a.HAWAII_LAND_COURT_DOC_NBR
		,a.HAWAII_TCT_CERTIFICATE_NBR
		,a.WA_EXCISE_NBR
		,a.Deed_TYPE
		,a.DETAILED_DOC_TYPE
		,a.TRANSACTION_TYPE
		,a.SELLER_NAME_PLAINTIFF_1
		,a.SELLER_NAME_PLAINTIFF1_CORP_IND
		,a.SELLER_NAME_PLAINTIFF_2
		,a.SELLER_NAME_PLAINTIFF_2_CORP_IND
		,a.SALE_AMOUNT
		,a.DOC_TRANSFER_TAX
		,a.SALE_CODE
		,a.PARTIAL_INTEREST_IND
		,a.RESALE_NEW_CONSTRUCTION
		,a.INTER_FAMILY
		,a.FORCLOSURE
		,a.REO_SALE
		,a.MTG1_RECORDING_DATE
		,a.MTG1_DOC_DATE
		,a.MTG1_DOC_NBR
		,a.MTG1_RECORDING_BOOK
		,a.MTG1_RECORDING_PAGE
		,a.MTG1_DETAILED_DOC_TYPE
		,a.MTG1_MTG_AMOUNT
		,a.MTG1_LENDER_LAST_NAME
		,a.MTG1_LENDER_FIRST_NAME
		,a.MTG1_LENDER_ADDRESS
		,a.MTG1_LENDER_CITY
		,a.MTG1_LENDER_STATE
		,a.MTG1_LENDER_ZIP
		,a.MTG1_MTG_COMPANY_CODE
		,a.MTG1_MTG_LOAN_TYPE_CODE
		,a.MTG1_MTG_TERM_CODE
		,a.MTG1_MTG_TERM_
		,a.MTG1_MTG_DUE_DATE
		,a.MTG1_MTG_INTEREST_RATE_TYPE
		,a.MTG1_MTG_INTEREST_RATE
		,a.MTG1_SELLER_CARRY_BACK
		,a.MTG1_PRIVATE_PARTY_LENDER
		,a.MTG1_CONSTRUCTION_LOAN
		,a.MTG1_REFI_FLAG
		,a.MTG1_EQUITY_FLAG
		,a.MTG1_OTHER_SUBORDINATE_LOANS
		,a.MTG2_RECORDING_DATE
		,a.MTG2_DOC_DATE
		,a.MTG2_DOC_NBR
		,a.MTG2_RECORDING_BOOK
		,a.MTG2_RECORDING_PAGE
		,a.MTG2_DETAILED_DOC_TYPE
		,a.MTG2_MTG_AMOUNT
		,a.MTG2_LENDER_LAST_NAME
		,a.MTG2_LENDER_FIRST_NAME
		,a.MTG2_LENDER_ADDRESS
		,a.MTG2_LENDER_CITY
		,a.MTG2_LENDER_STATE
		,a.MTG2_LENDER_ZIP
		,a.MTG2_MTG_COMPANY_CODE
		,a.MTG2_MTG_LOAN_TYPE_CODE
		,a.MTG2_MTG_TERM_CODE
		,a.MTG2_MTG_TERM
		,a.MTG2_MTG_DUE_DATE
		,a.MTG2_MTG_INTEREST_RATE_TYPE
		,a.MTG2_MTG_INTEREST_RATE
		,a.MTG2_SELLER_CARRY_BACK
		,a.MTG2_PRIVATE_PARTY_LENDER
		,a.MTG2_CONSTRUCTION_LOAN
		,a.MTG2_REFI_FLAG
		,a.MTG2_EQUITY_FLAG
		,a.MTG2_OTHER_SUBORDINATE_LOANS
		,a.MTG3_RECORDING_DATE
		,a.MTG3_DOC_DATE
		,a.MTG3_DOC_NBR
		,a.MTG3_RECORDING_BOOK
		,a.MTG3_RECORDING_PAGE
		,a.MTG3_DETAILED_DOC_TYPE
		,a.MTG3_MTG_AMOUNT
		,a.MTG3_LENDER_LAST_NAME
		,a.MTG3_LENDER_FIRST_NAME
		,a.MTG3_LENDER_ADDRESS
		,a.MTG3_LENDER_CITY
		,a.MTG3_LENDER_STATE
		,a.MTG3_LENDER_ZIP
		,a.MTG3_MTG_COMPANY_CODE
		,a.MTG3_MTG_LOAN_TYPE_CODE
		,a.MTG3_MTG_TERM_CODE
		,a.MTG3_MTG_TERM
		,a.MTG3_MTG_DUE_DATE
		,a.MTG3_MTG_INTEREST_RATE_TYPE
		,a.MTG3_MTG_INTEREST_RATE
		,a.MTG3_SELLER_CARRY_BACK
		,a.MTG3_PRIVATE_PARTY_LENDER
		,a.MTG3_CONSTRUCTION_LOAN
		,a.MTG3_REFI_FLAG
		,a.MTG3_EQUITY_FLAG
		,a.MTG3_OTHER_SUBORDINATE_LOANS
		,a.MTG4_RECORDING_DATE
		,a.MTG4_DOC_DATE
		,a.MTG4_DOC_NBR
		,a.MTG4_RECORDING_BOOK
		,a.MTG4_RECORDING_PAGE
		,a.MTG4_DETAILED_DOC_TYPE
		,a.MTG4_MTG_AMOUNT
		,a.MTG4_LENDER_LAST_NAME
		,a.MTG4_LENDER_FIRST_NAME
		,a.MTG4_LENDER_ADDRESS
		,a.MTG4_LENDER_CITY
		,a.MTG4_LENDER_STATE
		,a.MTG4_LENDER_ZIP
		,a.MTG4_MTG_COMPANY_CODE
		,a.MTG4_MTG_LOAN_TYPE_CODE
		,a.MTG4_MTG_TERM_CODE
		,a.MTG4_MTG_TERM
		,a.MTG4_MTG_DUE_DATE
		,a.MTG4_MTG_INTEREST_RATE_TYPE
		,a.MTG4_MTG_INTEREST_RATE
		,a.MTG4_SELLER_CARRY_BACK
		,a.MTG4_PRIVATE_PARTY_LENDER
		,a.MTG4_CONSTRUCTION_LOAN
		,a.MTG4_REFI_FLAG
		,a.MTG4_EQUITY_FLAG
		,a.MTG4_OTHER_SUBORDINATE_LOANS
		,a.ORIGINAL_RECORDED_DATE
		,a.ORIGINAL_BKPG
		,a.ORIGINAL_DOC_NBR
		,a.SECTION
		,a.TOWNSHIP
		,a.RANGE
		,a.DISTRICT_CODE
		,a.LOT
		,a.BLOCK
		,a.SUBDIVISION_NAME
		,a.UNIT
		,a.BUILDING
		,a.PLAT_SUBD_MAP_BOOK
		,a.PLAT_SUBD_MAP_PAGE
		,a.MAP_TYPE_IND
		,a.EXPANDED_LEGAL
		,a.TRACT_NBR
		,a.LAND_LOT
		,a.TITLE_COMPANY_NAME
		,a.TITLE_COMPANY_CODE
		,a.MULTI_APN
		,a.SALES_SOURCE_IND
		,a.TIMESTAMP_DATE
		,a.RECORD_TYPE
		,a.PRI_CAT_CODE
		,a.CREATED
		,a.PREVIOUS_PARCEL_NBR
		,a.PREVIOUS_PARCEL_SEQUENCE_NBR
		,a.FMT_DOC_NBR
		,a.CMT_ID_DOC_NBR
		,a.FMT_MTG1_DOC_NBR
		,a.CMT_ID_MTG1_DOC_NBR
		,a.FMT_MTG2_DOC_NBR
		,a.CMT_ID_MTG2_DOC_NBR
		,a.FMT_MTG3_DOC_NBR
		,a.CMT_ID_MTG3_DOC_NBR
		,a.FMT_MTG4_DOC_NBR
		,a.CMT_ID_MTG4_DOC_NBR
		,a.FMT_Book_Page
		,a.CMT_ID_Book_Page
		,a.FMT_MTG1_Book_Page
		,a.CMT_ID_MTG1_Book_Page
		,a.FMT_MTG2_Book_Page
		,a.CMT_ID_MTG2_Book_Page
		,a.FMT_MTG3_Book_Page
		,a.CMT_ID_MTG3_Book_Page
		,a.FMT_MTG4_Book_Page
		,a.CMT_ID_MTG4_Book_Page
		,a.Source_type
		,a.SRC_TBL
		,a.MOD_RAS_CLGX_UNIQUE_ID
		,a.UR_Doc_Unique_Id
		,a.UR_Doc_Id
		,a.UR_Property_Id
		,a.UR_Name_Id
		,a.UR_Reference_Id
		,a.FORECLOSURE_FLAG
		,a.REO_SALE_FLAG
		,a.ARMS_LENGTH_ID
		,a.MTG1_UR_Doc_Id
		,a.MTG2_UR_Doc_Id
		,a.MTG3_UR_Doc_Id
		,a.MTG4_UR_Doc_Id
		,a.DATA_SRC_IND
		,a.UR_Prop_Seq_Num
		,a.UR_Reprocess_Flag
		,a.Attorney_Name_identifier
		,a.Attorney_Last_Name
		,a.Attorney_First_Name
		,a.Attorney_Middle_Initial
		,a.Attorney_suffix
		,a.Attorney_address
		,a.Attorney_Address_City
		,a.Attorney_Address_State
		,a.Attorney_Address_Zip
		,a.Attorney_Phone
		,a.Attorney_Full_Name
		,a.UR_REMARKS
		,a.BYR1_4
		,a.BYR2_4
		,a.BYR3_4
		,a.BYR4_4
		,a.mtg_occ
		,ROW_NUMBER() OVER (
			PARTITION BY FIPS
			,REF_ID
			,substring(BYR1_OWN_NAME, 1, 5)
			,RECORDING_DATE
			,isnull(_DeedMtg, '')
			,isnull(Deed_TYPE, '')
			,isnull(DOC_NBR, '')
			,isnull(RECORDING_BOOK, '')
			,isnull(RECORDING_PAGE, '') ORDER BY UR_Doc_Id DESC
			) AS dup_doc_nbr
		,a._ld   
		,a.[ORIG_MTG1_Lender_Name]      
		,a.[ORIG_MTG2_Lender_Name]      
		,a.[ORIG_MTG3_Lender_Name]      
		,a.[ORIG_MTG4_Lender_Name]      
		,a.[NMLSLenderName_1]       
		,a.[NMLSLenderId_1]       
		,a.[NMLSBrokerName_1]       
		,a.[NMLSBrokerId_1]       
		,a.[NMLSAgentName_1]       
		,a.[NMLSAgentId_1]   
		,a.[NMLSLenderName_2]       
		,a.[NMLSLenderId_2]       
		,a.[NMLSBrokerName_2]       
		,a.[NMLSBrokerId_2]       
		,a.[NMLSAgentName_2]       
		,a.[NMLSAgentId_2]   
		,a.[NMLSLenderName_3]       
		,a.[NMLSLenderId_3]       
		,a.[NMLSBrokerName_3]       
		,a.[NMLSBrokerId_3]       
		,a.[NMLSAgentName_3]       
		,a.[NMLSAgentId_3]       
		,a.[NMLSLenderName_4]       
		,a.[NMLSLenderId_4]       
		,a.[NMLSBrokerName_4]       
		,a.[NMLSBrokerId_4]       
		,a.[NMLSAgentName_4]       
		,a.[NMLSAgentId_4]   
		,a.[Attorney_Email]
		,a.[Attorney_Firm_Name]
		,a.[Mtg1_Int_Source]
		,a.[Mtg2_Int_Source]
		,a.[Mtg3_Int_Source]
		,a.[Mtg4_Int_Source]
	FROM (
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'D' AS _DeedMtg
			,d.DeedID
			,d.FIPS
			,d.REF_ID
			,d.US_STATE
			,d.US_COUNTY
			,d.APN_unformatted
			,d.APN_formatted_UNIVERSAL
			,d.APN_SEQUENCE_NBR
			,d.ORIGINAL_APN
			,d.ACCOUNT_NBR
			,d.PENDING_TRANS
			,d.BYR1_CORP_IND
			,isnull(d.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,d.BYR1_OWN_ETAL_IND
			,d.BYR1_CO_NAME
			,d.BYR1_OWNERSHIP_RIGHTS_CODE
			,d.BYR1_OWN_RELATIONSHIP_TYPE
			,d.BYR1_OWNERSHIP
			,d.BYR2_CORP_IND
			,isnull(d.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,d.BYR2_OWNERSHIP_RIGHTS_CODE
			,d.BYR2_OWN_RELATIONSHIP_TYPE
			,d.BYR2_OWNERSHIP
			,d.BYR3_CORP_IND
			,isnull(d.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,d.BYR3_OWNERSHIP_RIGHTS_CODE
			,d.BYR3_OWN_RELATIONSHIP_TYPE
			,d.BYR3_OWNERSHIP
			,d.BYR4_CORP_IND
			,isnull(d.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,d.BYR4_OWNERSHIP_RIGHTS_CODE
			,d.BYR4_OWN_RELATIONSHIP_TYPE
			,d.BYR4_OWNERSHIP
			,d.BYR1_LAST_NAME
			,d.BYR1_FIRST_NAME
			,d.BYR1_MIDDLE_INITIAL
			,d.BYR1_SUFFIX
			,d.BYR2_LAST_NAME
			,d.BYR2_FIRST_NAME
			,d.BYR2_MIDDLE_INITIAL
			,d.BYR2_SUFFIX
			,d.BYR3_LAST_NAME
			,d.BYR3_FIRST_NAME
			,d.BYR3_MIDDLE_INITIAL
			,d.BYR3_SUFFIX
			,d.BYR4_LAST_NAME
			,d.BYR4_FIRST_NAME
			,d.BYR4_MIDDLE_INITIAL
			,d.BYR4_SUFFIX
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
			,d.MA_DO_NOT_PUBLISH_FLAG
			,d.SITUS_HOUSE_NBR
			,d.SITUS_HOUSE_NBR2
			,d.SITUS_HOUSE_NBR_SUFFIX
			,d.SITUS_DIRECTION
			,d.SITUS_STREET_NAME
			,d.SITUS_MODE
			,d.SITUS_POST_DIRECTION
			,d.SITUS_UNIT_NBR
			,d.SITUS_CITY
			,d.SITUS_STATE
			,d.SITUS_ZIP_CODE
			,d.SITUS_CARRIER_CODE
			,d.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,d.CLGX_UNIQUE_ID
			,d.RECORDING_DATE
			,d.SALE_DATE
			,d.DOC_NBR
			,d.RECORDING_BOOK
			,d.RECORDING_PAGE
			,d.HAWAII_LAND_COURT_DOC_NBR
			,d.HAWAII_TCT_CERTIFICATE_NBR
			,d.WA_EXCISE_NBR
			,d.Deed_TYPE
			,d.DETAILED_DOC_TYPE
			,d.TRANSACTION_TYPE
			,isnull(d.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,d.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(d.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,d.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,d.SALE_AMOUNT
			,d.DOC_TRANSFER_TAX
			,d.SALE_CODE
			,d.PARTIAL_INTEREST_IND
			,d.RESALE_NEW_CONSTRUCTION
			,d.INTER_FAMILY
			,d.FORCLOSURE
			,d.REO_SALE
			,NULL AS MTG1_RECORDING_DATE
			,NULL AS MTG1_DOC_DATE
			,NULL AS MTG1_DOC_NBR
			,NULL AS MTG1_RECORDING_BOOK
			,NULL AS MTG1_RECORDING_PAGE
			,NULL AS MTG1_DETAILED_DOC_TYPE
			,NULL AS MTG1_MTG_AMOUNT
			,NULL AS MTG1_LENDER_LAST_NAME
			,NULL AS MTG1_LENDER_FIRST_NAME
			,NULL AS MTG1_LENDER_ADDRESS
			,NULL AS MTG1_LENDER_CITY
			,NULL AS MTG1_LENDER_STATE
			,NULL AS MTG1_LENDER_ZIP
			,NULL AS MTG1_MTG_COMPANY_CODE
			,NULL AS MTG1_MTG_LOAN_TYPE_CODE
			,NULL AS MTG1_MTG_TERM_CODE
			,NULL AS MTG1_MTG_TERM_
			,NULL AS MTG1_MTG_DUE_DATE
			,NULL AS MTG1_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG1_MTG_INTEREST_RATE
			,NULL AS MTG1_SELLER_CARRY_BACK
			,NULL AS MTG1_PRIVATE_PARTY_LENDER
			,NULL AS MTG1_CONSTRUCTION_LOAN
			,NULL AS MTG1_REFI_FLAG
			,NULL AS MTG1_EQUITY_FLAG
			,NULL AS MTG1_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,d.ORIGINAL_RECORDED_DATE
			,d.ORIGINAL_BKPG
			,d.ORIGINAL_DOC_NBR
			,d.SECTION
			,d.TOWNSHIP
			,d.RANGE
			,d.DISTRICT_CODE
			,d.LOT
			,d.BLOCK
			,d.SUBDIVISION_NAME
			,d.UNIT
			,d.BUILDING
			,d.PLAT_SUBD_MAP_BOOK
			,d.PLAT_SUBD_MAP_PAGE
			,d.MAP_TYPE_IND
			,d.EXPANDED_LEGAL
			,d.TRACT_NBR
			,d.LAND_LOT
			,d.TITLE_COMPANY_NAME
			,d.TITLE_COMPANY_CODE
			,d.MULTI_APN
			,d.SALES_SOURCE_IND
			,d.TIMESTAMP_DATE
			,d.RECORD_TYPE
			,d.PRI_CAT_CODE
			,d.CREATED
			,d.PREVIOUS_PARCEL_NBR
			,d.PREVIOUS_PARCEL_SEQUENCE_NBR
			,isnull(d.FMT_DOC_NBR, '') AS FMT_DOC_NBR
			,d.CMT_ID_DOC_NBR
			,NULL AS FMT_MTG1_DOC_NBR
			,NULL AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,isnull(d.FMT_Book_Page, '') AS FMT_Book_Page
			,d.CMT_ID_Book_Page
			,NULL AS FMT_MTG1_Book_Page
			,NULL AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,d.Source_type
			,d.SRC_TBL
			,d.MOD_RAS_CLGX_UNIQUE_ID
			,d.UR_Doc_Unique_Id
			,d.UR_Doc_Id
			,d.UR_Property_Id
			,d.UR_Name_Id
			,d.UR_Reference_Id
			,d.FORECLOSURE_FLAG
			,d.REO_SALE_FLAG
			,d.ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,d.DATA_SRC_IND
			,d.UR_Prop_Seq_Num
			,d.UR_Reprocess_Flag
			,d.Attorney_Name_identifier
			,d.Attorney_Last_Name
			,d.Attorney_First_Name
			,d.Attorney_Middle_Initial
			,d.Attorney_suffix
			,d.Attorney_address
			,d.Attorney_Address_City
			,d.Attorney_Address_State
			,d.Attorney_Address_Zip
			,d.Attorney_Phone
			,d.Attorney_Full_Name
			,d.UR_REMARKS
			,substring(isnull(d.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(d.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(d.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(d.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,0 AS mtg_occ
			,'z' AS _ld    
			,NULL AS [ORIG_MTG1_Lender_Name]      
			,NULL AS [ORIG_MTG2_Lender_Name]      
			,NULL AS [ORIG_MTG3_Lender_Name]      
			,NULL AS [ORIG_MTG4_Lender_Name]
			,NULL AS [NMLSLenderName_1]       
			,NULL AS [NMLSLenderId_1]       
			,NULL AS [NMLSBrokerName_1]       
			,NULL AS [NMLSBrokerId_1]       
			,NULL AS [NMLSAgentName_1]       
			,NULL AS [NMLSAgentId_1]
			,NULL AS [NMLSLenderName_2]       
			,NULL AS [NMLSLenderId_2]       
			,NULL AS [NMLSBrokerName_2]       
			,NULL AS [NMLSBrokerId_2]       
			,NULL AS [NMLSAgentName_2]       
			,NULL AS [NMLSAgentId_2]  
			,NULL AS [NMLSLenderName_3]       
			,NULL AS [NMLSLenderId_3]       
			,NULL AS [NMLSBrokerName_3]       
			,NULL AS [NMLSBrokerId_3]       
			,NULL AS [NMLSAgentName_3]       
			,NULL AS [NMLSAgentId_3]
			,NULL AS [NMLSLenderName_4]       
			,NULL AS [NMLSLenderId_4]       
			,NULL AS [NMLSBrokerName_4]       
			,NULL AS [NMLSBrokerId_4]       
			,NULL AS [NMLSAgentName_4]       
			,NULL AS [NMLSAgentId_4]   
			,d.Attorney_Email
			,d.Attorney_Firm_Name
			,NULL AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Deed_work] d
		--OUTER APPLY (
		--	SELECT clgx_unique_id
		--	FROM deed.dbo.deed b
		--	WHERE b.ur_doc_id = d.ur_doc_id
		--		AND b.ref_id = d.ref_id
		--	) b
		WHERE d.Deed_TYPE NOT IN ('t')
		
		UNION ALL
		
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'T' AS _DeedMtg
			,d.DeedID
			,d.FIPS
			,d.REF_ID
			,d.US_STATE
			,d.US_COUNTY
			,d.APN_unformatted
			,d.APN_formatted_UNIVERSAL
			,d.APN_SEQUENCE_NBR
			,d.ORIGINAL_APN
			,d.ACCOUNT_NBR
			,d.PENDING_TRANS
			,d.BYR1_CORP_IND
			,isnull(d.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,d.BYR1_OWN_ETAL_IND
			,d.BYR1_CO_NAME
			,d.BYR1_OWNERSHIP_RIGHTS_CODE
			,d.BYR1_OWN_RELATIONSHIP_TYPE
			,d.BYR1_OWNERSHIP
			,d.BYR2_CORP_IND
			,isnull(d.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,d.BYR2_OWNERSHIP_RIGHTS_CODE
			,d.BYR2_OWN_RELATIONSHIP_TYPE
			,d.BYR2_OWNERSHIP
			,d.BYR3_CORP_IND
			,isnull(d.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,d.BYR3_OWNERSHIP_RIGHTS_CODE
			,d.BYR3_OWN_RELATIONSHIP_TYPE
			,d.BYR3_OWNERSHIP
			,d.BYR4_CORP_IND
			,isnull(d.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,d.BYR4_OWNERSHIP_RIGHTS_CODE
			,d.BYR4_OWN_RELATIONSHIP_TYPE
			,d.BYR4_OWNERSHIP
			,d.BYR1_LAST_NAME
			,d.BYR1_FIRST_NAME
			,d.BYR1_MIDDLE_INITIAL
			,d.BYR1_SUFFIX
			,d.BYR2_LAST_NAME
			,d.BYR2_FIRST_NAME
			,d.BYR2_MIDDLE_INITIAL
			,d.BYR2_SUFFIX
			,d.BYR3_LAST_NAME
			,d.BYR3_FIRST_NAME
			,d.BYR3_MIDDLE_INITIAL
			,d.BYR3_SUFFIX
			,d.BYR4_LAST_NAME
			,d.BYR4_FIRST_NAME
			,d.BYR4_MIDDLE_INITIAL
			,d.BYR4_SUFFIX
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
			,d.MA_DO_NOT_PUBLISH_FLAG
			,d.SITUS_HOUSE_NBR
			,d.SITUS_HOUSE_NBR2
			,d.SITUS_HOUSE_NBR_SUFFIX
			,d.SITUS_DIRECTION
			,d.SITUS_STREET_NAME
			,d.SITUS_MODE
			,d.SITUS_POST_DIRECTION
			,d.SITUS_UNIT_NBR
			,d.SITUS_CITY
			,d.SITUS_STATE
			,d.SITUS_ZIP_CODE
			,d.SITUS_CARRIER_CODE
			,d.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,d.CLGX_UNIQUE_ID
			,MTG1_RECORDING_DATE AS RECORDING_DATE
			,MTG1_DOC_DATE AS SALE_DATE
			,MTG1_DOC_NBR AS DOC_NBR
			,MTG1_RECORDING_BOOK AS RECORDING_BOOK
			,MTG1_RECORDING_PAGE AS RECORDING_PAGE
			,d.HAWAII_LAND_COURT_DOC_NBR
			,d.HAWAII_TCT_CERTIFICATE_NBR
			,d.WA_EXCISE_NBR
			,'T' AS Deed_TYPE
			,MTG1_DETAILED_DOC_TYPE AS DETAILED_DOC_TYPE
			,d.TRANSACTION_TYPE
			,isnull(d.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,d.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(d.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,d.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,d.SALE_AMOUNT
			,d.DOC_TRANSFER_TAX
			,d.SALE_CODE
			,d.PARTIAL_INTEREST_IND
			,d.RESALE_NEW_CONSTRUCTION
			,d.INTER_FAMILY
			,d.FORCLOSURE
			,d.REO_SALE
			,MTG1_RECORDING_DATE AS MTG1_RECORDING_DATE
			,MTG1_DOC_DATE AS MTG1_DOC_DATE
			,MTG1_DOC_NBR AS MTG1_DOC_NBR
			,MTG1_RECORDING_BOOK AS MTG1_RECORDING_BOOK
			,MTG1_RECORDING_PAGE AS MTG1_RECORDING_PAGE
			,MTG1_DETAILED_DOC_TYPE AS MTG1_DETAILED_DOC_TYPE
			,MTG1_MTG_AMOUNT AS MTG1_MTG_AMOUNT
			,MTG1_LENDER_LAST_NAME AS MTG1_LENDER_LAST_NAME
			,MTG1_LENDER_FIRST_NAME AS MTG1_LENDER_FIRST_NAME
			,MTG1_LENDER_ADDRESS AS MTG1_LENDER_ADDRESS
			,MTG1_LENDER_CITY AS MTG1_LENDER_CITY
			,MTG1_LENDER_STATE AS MTG1_LENDER_STATE
			,MTG1_LENDER_ZIP AS MTG1_LENDER_ZIP
			,MTG1_MTG_COMPANY_CODE AS MTG1_MTG_COMPANY_CODE
			,MTG1_MTG_LOAN_TYPE_CODE AS MTG1_MTG_LOAN_TYPE_CODE
			,MTG1_MTG_TERM_CODE AS MTG1_MTG_TERM_CODE
			,MTG1_MTG_TERM_ AS MTG1_MTG_TERM_
			,MTG1_MTG_DUE_DATE AS MTG1_MTG_DUE_DATE
			,MTG1_MTG_INTEREST_RATE_TYPE AS MTG1_MTG_INTEREST_RATE_TYPE
			,MTG1_MTG_INTEREST_RATE AS MTG1_MTG_INTEREST_RATE
			,MTG1_SELLER_CARRY_BACK AS MTG1_SELLER_CARRY_BACK
			,MTG1_PRIVATE_PARTY_LENDER AS MTG1_PRIVATE_PARTY_LENDER
			,MTG1_CONSTRUCTION_LOAN AS MTG1_CONSTRUCTION_LOAN
			,MTG1_REFI_FLAG AS MTG1_REFI_FLAG
			,MTG1_EQUITY_FLAG AS MTG1_EQUITY_FLAG
			,MTG1_OTHER_SUBORDINATE_LOANS AS MTG1_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,d.ORIGINAL_RECORDED_DATE
			,d.ORIGINAL_BKPG
			,d.ORIGINAL_DOC_NBR
			,d.SECTION
			,d.TOWNSHIP
			,d.RANGE
			,d.DISTRICT_CODE
			,d.LOT
			,d.BLOCK
			,d.SUBDIVISION_NAME
			,d.UNIT
			,d.BUILDING
			,d.PLAT_SUBD_MAP_BOOK
			,d.PLAT_SUBD_MAP_PAGE
			,d.MAP_TYPE_IND
			,d.EXPANDED_LEGAL
			,d.TRACT_NBR
			,d.LAND_LOT
			,d.TITLE_COMPANY_NAME
			,d.TITLE_COMPANY_CODE
			,d.MULTI_APN
			,d.SALES_SOURCE_IND
			,d.TIMESTAMP_DATE
			,d.RECORD_TYPE
			,d.PRI_CAT_CODE
			,d.CREATED
			,d.PREVIOUS_PARCEL_NBR
			,d.PREVIOUS_PARCEL_SEQUENCE_NBR
			,FMT_MTG1_DOC_NBR AS FMT_DOC_NBR
			,CMT_ID_MTG1_DOC_NBR AS CMT_ID_DOC_NBR
			,FMT_MTG1_DOC_NBR AS FMT_MTG1_DOC_NBR
			,CMT_ID_MTG1_DOC_NBR AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,FMT_MTG1_Book_Page AS FMT_Book_Page
			,CMT_ID_MTG1_Book_Page AS CMT_ID_Book_Page
			,FMT_MTG1_Book_Page AS FMT_MTG1_Book_Page
			,CMT_ID_MTG1_Book_Page AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,d.Source_type
			,CASE 
				WHEN d.Source_type = 'E'
					THEN 'EPM'
				ELSE 'MDM'
				END AS SRC_TBL
			,d.MOD_RAS_CLGX_UNIQUE_ID
			,d.UR_Doc_Unique_Id
			,MTG1_UR_Doc_Id AS UR_Doc_Id
			,d.UR_Property_Id
			,d.UR_Name_Id
			,d.UR_Reference_Id
			,d.FORECLOSURE_FLAG
			,d.REO_SALE_FLAG
			,d.ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,d.DATA_SRC_IND
			,d.UR_Prop_Seq_Num
			,d.UR_Reprocess_Flag
			,d.Attorney_Name_identifier
			,d.Attorney_Last_Name
			,d.Attorney_First_Name
			,d.Attorney_Middle_Initial
			,d.Attorney_suffix
			,d.Attorney_address
			,d.Attorney_Address_City
			,d.Attorney_Address_State
			,d.Attorney_Address_Zip
			,d.Attorney_Phone
			,d.Attorney_Full_Name
			,d.UR_REMARKS
			,substring(isnull(d.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(d.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(d.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(d.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,1 AS mtg_occ
			,'z' AS _ld   
			,ORIG_MTG1_Lender_Name AS ORIG_MTG1_Lender_Name
			,NULL AS ORIG_MTG2_Lender_Name
			,NULL AS ORIG_MTG3_Lender_Name    
			,NULL AS ORIG_MTG4_Lender_Name  
			,NMLSLenderName_1      AS NMLSLenderName_1       
			,NMLSLenderId_1        AS NMLSLenderId_1       
			,NMLSBrokerName_1      AS NMLSBrokerName_1       
			,NMLSBrokerId_1        AS NMLSBrokerId_1       
			,NMLSAgentName_1       AS NMLSAgentName_1       
			,NMLSAgentId_1    AS NMLSAgentId_1   
			,NULL AS NMLSLenderName_2       
			,NULL AS NMLSLenderId_2       
			,NULL AS NMLSBrokerName_2       
			,NULL AS NMLSBrokerId_2       
			,NULL AS NMLSAgentName_2       
			,NULL AS NMLSAgentId_2    
			,NULL AS NMLSLenderName_3       
			,NULL AS NMLSLenderId_3       
			,NULL AS NMLSBrokerName_3       
			,NULL AS NMLSBrokerId_3       
			,NULL AS NMLSAgentName_3       
			,NULL AS NMLSAgentId_3      
			,NULL AS NMLSLenderName_4       
			,NULL AS NMLSLenderId_4       
			,NULL AS NMLSBrokerName_4       
			,NULL AS NMLSBrokerId_4       
			,NULL AS NMLSAgentName_4       
			,NULL AS NMLSAgentId_4  
			,d.Attorney_Email
			,d.Attorney_Firm_Name
			,d.Mtg1_Int_Source AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Deed_work] d
		--OUTER APPLY (
		--SELECT clgx_unique_id
		--FROM deed.dbo.deed b
		--WHERE b.ur_doc_id = d.ur_doc_id
		--	AND b.ref_id = d.ref_id
		--) b
		WHERE d.Deed_TYPE NOT IN ('t')
		
		UNION ALL
		
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'T' AS _DeedMtg
			,d.DeedID
			,d.FIPS
			,d.REF_ID
			,d.US_STATE
			,d.US_COUNTY
			,d.APN_unformatted
			,d.APN_formatted_UNIVERSAL
			,d.APN_SEQUENCE_NBR
			,d.ORIGINAL_APN
			,d.ACCOUNT_NBR
			,d.PENDING_TRANS
			,d.BYR1_CORP_IND
			,isnull(d.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,d.BYR1_OWN_ETAL_IND
			,d.BYR1_CO_NAME
			,d.BYR1_OWNERSHIP_RIGHTS_CODE
			,d.BYR1_OWN_RELATIONSHIP_TYPE
			,d.BYR1_OWNERSHIP
			,d.BYR2_CORP_IND
			,isnull(d.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,d.BYR2_OWNERSHIP_RIGHTS_CODE
			,d.BYR2_OWN_RELATIONSHIP_TYPE
			,d.BYR2_OWNERSHIP
			,d.BYR3_CORP_IND
			,isnull(d.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,d.BYR3_OWNERSHIP_RIGHTS_CODE
			,d.BYR3_OWN_RELATIONSHIP_TYPE
			,d.BYR3_OWNERSHIP
			,d.BYR4_CORP_IND
			,isnull(d.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,d.BYR4_OWNERSHIP_RIGHTS_CODE
			,d.BYR4_OWN_RELATIONSHIP_TYPE
			,d.BYR4_OWNERSHIP
			,d.BYR1_LAST_NAME
			,d.BYR1_FIRST_NAME
			,d.BYR1_MIDDLE_INITIAL
			,d.BYR1_SUFFIX
			,d.BYR2_LAST_NAME
			,d.BYR2_FIRST_NAME
			,d.BYR2_MIDDLE_INITIAL
			,d.BYR2_SUFFIX
			,d.BYR3_LAST_NAME
			,d.BYR3_FIRST_NAME
			,d.BYR3_MIDDLE_INITIAL
			,d.BYR3_SUFFIX
			,d.BYR4_LAST_NAME
			,d.BYR4_FIRST_NAME
			,d.BYR4_MIDDLE_INITIAL
			,d.BYR4_SUFFIX
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
			,d.MA_DO_NOT_PUBLISH_FLAG
			,d.SITUS_HOUSE_NBR
			,d.SITUS_HOUSE_NBR2
			,d.SITUS_HOUSE_NBR_SUFFIX
			,d.SITUS_DIRECTION
			,d.SITUS_STREET_NAME
			,d.SITUS_MODE
			,d.SITUS_POST_DIRECTION
			,d.SITUS_UNIT_NBR
			,d.SITUS_CITY
			,d.SITUS_STATE
			,d.SITUS_ZIP_CODE
			,d.SITUS_CARRIER_CODE
			,d.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,d.CLGX_UNIQUE_ID
			,MTG2_RECORDING_DATE AS RECORDING_DATE
			,MTG2_DOC_DATE AS SALE_DATE
			,MTG2_DOC_NBR AS DOC_NBR
			,MTG2_RECORDING_BOOK AS RECORDING_BOOK
			,MTG2_RECORDING_PAGE AS RECORDING_PAGE
			,d.HAWAII_LAND_COURT_DOC_NBR
			,d.HAWAII_TCT_CERTIFICATE_NBR
			,d.WA_EXCISE_NBR
			,'T' AS Deed_TYPE
			,MTG2_DETAILED_DOC_TYPE AS DETAILED_DOC_TYPE
			,d.TRANSACTION_TYPE
			,isnull(d.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,d.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(d.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,d.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,d.SALE_AMOUNT
			,d.DOC_TRANSFER_TAX
			,d.SALE_CODE
			,d.PARTIAL_INTEREST_IND
			,d.RESALE_NEW_CONSTRUCTION
			,d.INTER_FAMILY
			,d.FORCLOSURE
			,d.REO_SALE
			,MTG2_RECORDING_DATE AS MTG1_RECORDING_DATE
			,MTG2_DOC_DATE AS MTG1_DOC_DATE
			,MTG2_DOC_NBR AS MTG1_DOC_NBR
			,MTG2_RECORDING_BOOK AS MTG1_RECORDING_BOOK
			,MTG2_RECORDING_PAGE AS MTG1_RECORDING_PAGE
			,MTG2_DETAILED_DOC_TYPE AS MTG1_DETAILED_DOC_TYPE
			,MTG2_MTG_AMOUNT AS MTG1_MTG_AMOUNT
			,MTG2_LENDER_LAST_NAME AS MTG1_LENDER_LAST_NAME
			,MTG2_LENDER_FIRST_NAME AS MTG1_LENDER_FIRST_NAME
			,MTG2_LENDER_ADDRESS AS MTG1_LENDER_ADDRESS
			,MTG2_LENDER_CITY AS MTG1_LENDER_CITY
			,MTG2_LENDER_STATE AS MTG1_LENDER_STATE
			,MTG2_LENDER_ZIP AS MTG1_LENDER_ZIP
			,MTG2_MTG_COMPANY_CODE AS MTG1_MTG_COMPANY_CODE
			,MTG2_MTG_LOAN_TYPE_CODE AS MTG1_MTG_LOAN_TYPE_CODE
			,MTG2_MTG_TERM_CODE AS MTG1_MTG_TERM_CODE
			,MTG2_MTG_TERM AS MTG1_MTG_TERM_
			,MTG2_MTG_DUE_DATE AS MTG1_MTG_DUE_DATE
			,MTG2_MTG_INTEREST_RATE_TYPE AS MTG1_MTG_INTEREST_RATE_TYPE
			,MTG2_MTG_INTEREST_RATE AS MTG1_MTG_INTEREST_RATE
			,MTG2_SELLER_CARRY_BACK AS MTG1_SELLER_CARRY_BACK
			,MTG2_PRIVATE_PARTY_LENDER AS MTG1_PRIVATE_PARTY_LENDER
			,MTG2_CONSTRUCTION_LOAN AS MTG1_CONSTRUCTION_LOAN
			,MTG2_REFI_FLAG AS MTG1_REFI_FLAG
			,MTG2_EQUITY_FLAG AS MTG1_EQUITY_FLAG
			,MTG2_OTHER_SUBORDINATE_LOANS AS MTG1_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,d.ORIGINAL_RECORDED_DATE
			,d.ORIGINAL_BKPG
			,d.ORIGINAL_DOC_NBR
			,d.SECTION
			,d.TOWNSHIP
			,d.RANGE
			,d.DISTRICT_CODE
			,d.LOT
			,d.BLOCK
			,d.SUBDIVISION_NAME
			,d.UNIT
			,d.BUILDING
			,d.PLAT_SUBD_MAP_BOOK
			,d.PLAT_SUBD_MAP_PAGE
			,d.MAP_TYPE_IND
			,d.EXPANDED_LEGAL
			,d.TRACT_NBR
			,d.LAND_LOT
			,d.TITLE_COMPANY_NAME
			,d.TITLE_COMPANY_CODE
			,d.MULTI_APN
			,d.SALES_SOURCE_IND
			,d.TIMESTAMP_DATE
			,d.RECORD_TYPE
			,d.PRI_CAT_CODE
			,d.CREATED
			,d.PREVIOUS_PARCEL_NBR
			,d.PREVIOUS_PARCEL_SEQUENCE_NBR
			,FMT_MTG2_DOC_NBR AS FMT_DOC_NBR
			,CMT_ID_MTG2_DOC_NBR AS CMT_ID_DOC_NBR
			,FMT_MTG2_DOC_NBR AS FMT_MTG1_DOC_NBR
			,CMT_ID_MTG2_DOC_NBR AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,FMT_MTG2_Book_Page AS FMT_Book_Page
			,CMT_ID_MTG2_Book_Page AS CMT_ID_Book_Page
			,FMT_MTG2_Book_Page AS FMT_MTG1_Book_Page
			,CMT_ID_MTG2_Book_Page AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,d.Source_type
			,CASE 
				WHEN d.Source_type = 'E'
					THEN 'EPM'
				ELSE 'MDM'
				END AS SRC_TBL
			,d.MOD_RAS_CLGX_UNIQUE_ID
			,d.UR_Doc_Unique_Id
			,MTG2_UR_Doc_Id AS UR_Doc_Id
			,d.UR_Property_Id
			,d.UR_Name_Id
			,d.UR_Reference_Id
			,d.FORECLOSURE_FLAG
			,d.REO_SALE_FLAG
			,d.ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,d.DATA_SRC_IND
			,d.UR_Prop_Seq_Num
			,d.UR_Reprocess_Flag
			,d.Attorney_Name_identifier
			,d.Attorney_Last_Name
			,d.Attorney_First_Name
			,d.Attorney_Middle_Initial
			,d.Attorney_suffix
			,d.Attorney_address
			,d.Attorney_Address_City
			,d.Attorney_Address_State
			,d.Attorney_Address_Zip
			,d.Attorney_Phone
			,d.Attorney_Full_Name
			,d.UR_REMARKS
			,substring(isnull(d.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(d.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(d.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(d.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,2 AS mtg_occ
			,'z' AS _ld  
			,ORIG_MTG2_Lender_Name AS ORIG_MTG1_Lender_Name  
			,NULL AS ORIG_MTG2_Lender_Name
			,NULL AS ORIG_MTG3_Lender_Name
			,NULL AS ORIG_MTG4_Lender_Name
			,NMLSLenderName_2      AS NMLSLenderName_1       
			,NMLSLenderId_2        AS NMLSLenderId_1       
			,NMLSBrokerName_2      AS NMLSBrokerName_1       
			,NMLSBrokerId_2        AS NMLSBrokerId_1       
			,NMLSAgentName_2       AS NMLSAgentName_1       
			,NMLSAgentId_2   AS NMLSAgentId_1   
			,NULL AS NMLSLenderName_2       
			,NULL AS NMLSLenderId_2       
			,NULL AS NMLSBrokerName_2       
			,NULL AS NMLSBrokerId_2       
			,NULL AS NMLSAgentName_2       
			,NULL AS NMLSAgentId_2    
			,NULL AS NMLSLenderName_3       
			,NULL AS NMLSLenderId_3       
			,NULL AS NMLSBrokerName_3       
			,NULL AS NMLSBrokerId_3       
			,NULL AS NMLSAgentName_3       
			,NULL AS NMLSAgentId_3  
			,NULL AS NMLSLenderName_4       
			,NULL AS NMLSLenderId_4       
			,NULL AS NMLSBrokerName_4       
			,NULL AS NMLSBrokerId_4       
			,NULL AS NMLSAgentName_4       
			,NULL AS NMLSAgentId_4  
			,d.Attorney_Email
			,d.Attorney_Firm_Name
			,d.Mtg2_Int_Source AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Deed_work] d
		--OUTER APPLY (
		--	SELECT clgx_unique_id
		--	FROM deed.dbo.deed b
		--	WHERE b.ur_doc_id = d.ur_doc_id
		--		AND b.ref_id = d.ref_id
		--	) b
		WHERE d.Deed_TYPE NOT IN ('t')
		
		UNION ALL
		
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'T' AS _DeedMtg
			,d.DeedID
			,d.FIPS
			,d.REF_ID
			,d.US_STATE
			,d.US_COUNTY
			,d.APN_unformatted
			,d.APN_formatted_UNIVERSAL
			,d.APN_SEQUENCE_NBR
			,d.ORIGINAL_APN
			,d.ACCOUNT_NBR
			,d.PENDING_TRANS
			,d.BYR1_CORP_IND
			,isnull(d.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,d.BYR1_OWN_ETAL_IND
			,d.BYR1_CO_NAME
			,d.BYR1_OWNERSHIP_RIGHTS_CODE
			,d.BYR1_OWN_RELATIONSHIP_TYPE
			,d.BYR1_OWNERSHIP
			,d.BYR2_CORP_IND
			,isnull(d.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,d.BYR2_OWNERSHIP_RIGHTS_CODE
			,d.BYR2_OWN_RELATIONSHIP_TYPE
			,d.BYR2_OWNERSHIP
			,d.BYR3_CORP_IND
			,isnull(d.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,d.BYR3_OWNERSHIP_RIGHTS_CODE
			,d.BYR3_OWN_RELATIONSHIP_TYPE
			,d.BYR3_OWNERSHIP
			,d.BYR4_CORP_IND
			,isnull(d.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,d.BYR4_OWNERSHIP_RIGHTS_CODE
			,d.BYR4_OWN_RELATIONSHIP_TYPE
			,d.BYR4_OWNERSHIP
			,d.BYR1_LAST_NAME
			,d.BYR1_FIRST_NAME
			,d.BYR1_MIDDLE_INITIAL
			,d.BYR1_SUFFIX
			,d.BYR2_LAST_NAME
			,d.BYR2_FIRST_NAME
			,d.BYR2_MIDDLE_INITIAL
			,d.BYR2_SUFFIX
			,d.BYR3_LAST_NAME
			,d.BYR3_FIRST_NAME
			,d.BYR3_MIDDLE_INITIAL
			,d.BYR3_SUFFIX
			,d.BYR4_LAST_NAME
			,d.BYR4_FIRST_NAME
			,d.BYR4_MIDDLE_INITIAL
			,d.BYR4_SUFFIX
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
			,d.MA_DO_NOT_PUBLISH_FLAG
			,d.SITUS_HOUSE_NBR
			,d.SITUS_HOUSE_NBR2
			,d.SITUS_HOUSE_NBR_SUFFIX
			,d.SITUS_DIRECTION
			,d.SITUS_STREET_NAME
			,d.SITUS_MODE
			,d.SITUS_POST_DIRECTION
			,d.SITUS_UNIT_NBR
			,d.SITUS_CITY
			,d.SITUS_STATE
			,d.SITUS_ZIP_CODE
			,d.SITUS_CARRIER_CODE
			,d.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,d.CLGX_UNIQUE_ID
			,MTG3_RECORDING_DATE AS RECORDING_DATE
			,MTG3_DOC_DATE AS SALE_DATE
			,MTG3_DOC_NBR AS DOC_NBR
			,MTG3_RECORDING_BOOK AS RECORDING_BOOK
			,MTG3_RECORDING_PAGE AS RECORDING_PAGE
			,d.HAWAII_LAND_COURT_DOC_NBR
			,d.HAWAII_TCT_CERTIFICATE_NBR
			,d.WA_EXCISE_NBR
			,'T' AS Deed_TYPE
			,MTG3_DETAILED_DOC_TYPE AS DETAILED_DOC_TYPE
			,d.TRANSACTION_TYPE
			,isnull(d.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,d.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(d.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,d.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,d.SALE_AMOUNT
			,d.DOC_TRANSFER_TAX
			,d.SALE_CODE
			,d.PARTIAL_INTEREST_IND
			,d.RESALE_NEW_CONSTRUCTION
			,d.INTER_FAMILY
			,d.FORCLOSURE
			,d.REO_SALE
			,MTG3_RECORDING_DATE AS MTG1_RECORDING_DATE
			,MTG3_DOC_DATE AS MTG1_DOC_DATE
			,MTG3_DOC_NBR AS MTG1_DOC_NBR
			,MTG3_RECORDING_BOOK AS MTG1_RECORDING_BOOK
			,MTG3_RECORDING_PAGE AS MTG1_RECORDING_PAGE
			,MTG3_DETAILED_DOC_TYPE AS MTG1_DETAILED_DOC_TYPE
			,MTG3_MTG_AMOUNT AS MTG1_MTG_AMOUNT
			,MTG3_LENDER_LAST_NAME AS MTG1_LENDER_LAST_NAME
			,MTG3_LENDER_FIRST_NAME AS MTG1_LENDER_FIRST_NAME
			,MTG3_LENDER_ADDRESS AS MTG1_LENDER_ADDRESS
			,MTG3_LENDER_CITY AS MTG1_LENDER_CITY
			,MTG3_LENDER_STATE AS MTG1_LENDER_STATE
			,MTG3_LENDER_ZIP AS MTG1_LENDER_ZIP
			,MTG3_MTG_COMPANY_CODE AS MTG1_MTG_COMPANY_CODE
			,MTG3_MTG_LOAN_TYPE_CODE AS MTG1_MTG_LOAN_TYPE_CODE
			,MTG3_MTG_TERM_CODE AS MTG1_MTG_TERM_CODE
			,MTG3_MTG_TERM AS MTG1_MTG_TERM_
			,MTG3_MTG_DUE_DATE AS MTG1_MTG_DUE_DATE
			,MTG3_MTG_INTEREST_RATE_TYPE AS MTG1_MTG_INTEREST_RATE_TYPE
			,MTG3_MTG_INTEREST_RATE AS MTG1_MTG_INTEREST_RATE
			,MTG3_SELLER_CARRY_BACK AS MTG1_SELLER_CARRY_BACK
			,MTG3_PRIVATE_PARTY_LENDER AS MTG1_PRIVATE_PARTY_LENDER
			,MTG3_CONSTRUCTION_LOAN AS MTG1_CONSTRUCTION_LOAN
			,MTG3_REFI_FLAG AS MTG1_REFI_FLAG
			,MTG3_EQUITY_FLAG AS MTG1_EQUITY_FLAG
			,MTG3_OTHER_SUBORDINATE_LOANS AS MTG1_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,d.ORIGINAL_RECORDED_DATE
			,d.ORIGINAL_BKPG
			,d.ORIGINAL_DOC_NBR
			,d.SECTION
			,d.TOWNSHIP
			,d.RANGE
			,d.DISTRICT_CODE
			,d.LOT
			,d.BLOCK
			,d.SUBDIVISION_NAME
			,d.UNIT
			,d.BUILDING
			,d.PLAT_SUBD_MAP_BOOK
			,d.PLAT_SUBD_MAP_PAGE
			,d.MAP_TYPE_IND
			,d.EXPANDED_LEGAL
			,d.TRACT_NBR
			,d.LAND_LOT
			,d.TITLE_COMPANY_NAME
			,d.TITLE_COMPANY_CODE
			,d.MULTI_APN
			,d.SALES_SOURCE_IND
			,d.TIMESTAMP_DATE
			,d.RECORD_TYPE
			,d.PRI_CAT_CODE
			,d.CREATED
			,d.PREVIOUS_PARCEL_NBR
			,d.PREVIOUS_PARCEL_SEQUENCE_NBR
			,FMT_MTG3_DOC_NBR AS FMT_DOC_NBR
			,CMT_ID_MTG3_DOC_NBR AS CMT_ID_DOC_NBR
			,FMT_MTG3_DOC_NBR AS FMT_MTG1_DOC_NBR
			,CMT_ID_MTG3_DOC_NBR AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,FMT_MTG3_Book_Page AS FMT_Book_Page
			,CMT_ID_MTG3_Book_Page AS CMT_ID_Book_Page
			,FMT_MTG3_Book_Page AS FMT_MTG1_Book_Page
			,CMT_ID_MTG3_Book_Page AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,d.Source_type
			,CASE 
				WHEN d.Source_type = 'E'
					THEN 'EPM'
				ELSE 'MDM'
				END AS SRC_TBL
			,d.MOD_RAS_CLGX_UNIQUE_ID
			,d.UR_Doc_Unique_Id
			,MTG3_UR_Doc_Id AS UR_Doc_Id
			,d.UR_Property_Id
			,d.UR_Name_Id
			,d.UR_Reference_Id
			,d.FORECLOSURE_FLAG
			,d.REO_SALE_FLAG
			,d.ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,d.DATA_SRC_IND
			,d.UR_Prop_Seq_Num
			,d.UR_Reprocess_Flag
			,d.Attorney_Name_identifier
			,d.Attorney_Last_Name
			,d.Attorney_First_Name
			,d.Attorney_Middle_Initial
			,d.Attorney_suffix
			,d.Attorney_address
			,d.Attorney_Address_City
			,d.Attorney_Address_State
			,d.Attorney_Address_Zip
			,d.Attorney_Phone
			,d.Attorney_Full_Name
			,d.UR_REMARKS
			,substring(isnull(d.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(d.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(d.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(d.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,3 AS mtg_occ
			,'z' AS _ld    
			,d.ORIG_MTG3_Lender_Name AS ORIG_MTG1_Lender_Name
			,NULL AS ORIG_MTG2_Lender_Name  
			,NULL AS ORIG_MTG3_Lender_Name
			,NULL AS ORIG_MTG4_Lender_Name
			,d.NMLSLenderName_3      AS NMLSLenderName_1       
			,d.NMLSLenderId_3        AS NMLSLenderId_1       
			,d.NMLSBrokerName_3      AS NMLSBrokerName_1       
			,d.NMLSBrokerId_3        AS NMLSBrokerId_1       
			,d.NMLSAgentName_3       AS NMLSAgentName_1       
			,d.NMLSAgentId_3   AS NMLSAgentId_1   
			,NULL AS NMLSLenderName_2       
			,NULL AS NMLSLenderId_2       
			,NULL AS NMLSBrokerName_2       
			,NULL AS NMLSBrokerId_2       
			,NULL AS NMLSAgentName_2       
			,NULL AS NMLSAgentId_2    
			,NULL AS NMLSLenderName_3       
			,NULL AS NMLSLenderId_3       
			,NULL AS NMLSBrokerName_3       
			,NULL AS NMLSBrokerId_3       
			,NULL AS NMLSAgentName_3       
			,NULL AS NMLSAgentId_3  
			,NULL AS NMLSLenderName_4       
			,NULL AS NMLSLenderId_4       
			,NULL AS NMLSBrokerName_4       
			,NULL AS NMLSBrokerId_4       
			,NULL AS NMLSAgentName_4       
			,NULL AS NMLSAgentId_4   
			,d.Attorney_Email
			,d.Attorney_Firm_Name
			,d.Mtg3_Int_Source AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Deed_work] d
		--OUTER APPLY (
		--	SELECT clgx_unique_id
		--	FROM deed.dbo.deed b
		--	WHERE b.ur_doc_id = d.ur_doc_id
		--		AND b.ref_id = d.ref_id
		--	) b
		WHERE d.Deed_TYPE NOT IN ('t')
		
		UNION ALL
		
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'T' AS _DeedMtg
			,d.DeedID
			,d.FIPS
			,d.REF_ID
			,d.US_STATE
			,d.US_COUNTY
			,d.APN_unformatted
			,d.APN_formatted_UNIVERSAL
			,d.APN_SEQUENCE_NBR
			,d.ORIGINAL_APN
			,d.ACCOUNT_NBR
			,d.PENDING_TRANS
			,d.BYR1_CORP_IND
			,isnull(d.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,d.BYR1_OWN_ETAL_IND
			,d.BYR1_CO_NAME
			,d.BYR1_OWNERSHIP_RIGHTS_CODE
			,d.BYR1_OWN_RELATIONSHIP_TYPE
			,d.BYR1_OWNERSHIP
			,d.BYR2_CORP_IND
			,isnull(d.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,d.BYR2_OWNERSHIP_RIGHTS_CODE
			,d.BYR2_OWN_RELATIONSHIP_TYPE
			,d.BYR2_OWNERSHIP
			,d.BYR3_CORP_IND
			,isnull(d.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,d.BYR3_OWNERSHIP_RIGHTS_CODE
			,d.BYR3_OWN_RELATIONSHIP_TYPE
			,d.BYR3_OWNERSHIP
			,d.BYR4_CORP_IND
			,isnull(d.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,d.BYR4_OWNERSHIP_RIGHTS_CODE
			,d.BYR4_OWN_RELATIONSHIP_TYPE
			,d.BYR4_OWNERSHIP
			,d.BYR1_LAST_NAME
			,d.BYR1_FIRST_NAME
			,d.BYR1_MIDDLE_INITIAL
			,d.BYR1_SUFFIX
			,d.BYR2_LAST_NAME
			,d.BYR2_FIRST_NAME
			,d.BYR2_MIDDLE_INITIAL
			,d.BYR2_SUFFIX
			,d.BYR3_LAST_NAME
			,d.BYR3_FIRST_NAME
			,d.BYR3_MIDDLE_INITIAL
			,d.BYR3_SUFFIX
			,d.BYR4_LAST_NAME
			,d.BYR4_FIRST_NAME
			,d.BYR4_MIDDLE_INITIAL
			,d.BYR4_SUFFIX
			,d.MA_HOUSE_NBR_PREFIX
			,d.MA_HOUSE_NBR
			,d.MA_HOUSE_NBR_SUFFIX
			,d.MA_STREET_DIRECTION
			,d.MA_STREET_NAME
			,d.MA_MODE
			,d.MA_QUADRANT
			,d.MA_APARTMENT_UNIT
			,d.MA_CITY
			,d.MA_STATE
			,d.MA_ZIP_CODE
			,d.MA_CARRIER_CODE
			,d.MA_ORIGINAL_MAILING_ADDRESS
			,d.MA_DO_NOT_PUBLISH_FLAG
			,d.SITUS_HOUSE_NBR
			,d.SITUS_HOUSE_NBR2
			,d.SITUS_HOUSE_NBR_SUFFIX
			,d.SITUS_DIRECTION
			,d.SITUS_STREET_NAME
			,d.SITUS_MODE
			,d.SITUS_POST_DIRECTION
			,d.SITUS_UNIT_NBR
			,d.SITUS_CITY
			,d.SITUS_STATE
			,d.SITUS_ZIP_CODE
			,d.SITUS_CARRIER_CODE
			,d.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,d.CLGX_UNIQUE_ID
			,MTG4_RECORDING_DATE AS RECORDING_DATE
			,MTG4_DOC_DATE AS SALE_DATE
			,MTG4_DOC_NBR AS DOC_NBR
			,MTG4_RECORDING_BOOK AS RECORDING_BOOK
			,MTG4_RECORDING_PAGE AS RECORDING_PAGE
			,d.HAWAII_LAND_COURT_DOC_NBR
			,d.HAWAII_TCT_CERTIFICATE_NBR
			,d.WA_EXCISE_NBR
			,'T' AS Deed_TYPE
			,MTG4_DETAILED_DOC_TYPE AS DETAILED_DOC_TYPE
			,d.TRANSACTION_TYPE
			,isnull(d.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,d.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(d.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,d.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,d.SALE_AMOUNT
			,d.DOC_TRANSFER_TAX
			,d.SALE_CODE
			,d.PARTIAL_INTEREST_IND
			,d.RESALE_NEW_CONSTRUCTION
			,d.INTER_FAMILY
			,d.FORCLOSURE
			,d.REO_SALE
			,MTG4_RECORDING_DATE AS MTG1_RECORDING_DATE
			,MTG4_DOC_DATE AS MTG1_DOC_DATE
			,MTG4_DOC_NBR AS MTG1_DOC_NBR
			,MTG4_RECORDING_BOOK AS MTG1_RECORDING_BOOK
			,MTG4_RECORDING_PAGE AS MTG1_RECORDING_PAGE
			,MTG4_DETAILED_DOC_TYPE AS MTG1_DETAILED_DOC_TYPE
			,MTG4_MTG_AMOUNT AS MTG1_MTG_AMOUNT
			,MTG4_LENDER_LAST_NAME AS MTG1_LENDER_LAST_NAME
			,MTG4_LENDER_FIRST_NAME AS MTG1_LENDER_FIRST_NAME
			,MTG4_LENDER_ADDRESS AS MTG1_LENDER_ADDRESS
			,MTG4_LENDER_CITY AS MTG1_LENDER_CITY
			,MTG4_LENDER_STATE AS MTG1_LENDER_STATE
			,MTG4_LENDER_ZIP AS MTG1_LENDER_ZIP
			,MTG4_MTG_COMPANY_CODE AS MTG1_MTG_COMPANY_CODE
			,MTG4_MTG_LOAN_TYPE_CODE AS MTG1_MTG_LOAN_TYPE_CODE
			,MTG4_MTG_TERM_CODE AS MTG1_MTG_TERM_CODE
			,MTG4_MTG_TERM AS MTG1_MTG_TERM
			,MTG4_MTG_DUE_DATE AS MTG1_MTG_DUE_DATE
			,MTG4_MTG_INTEREST_RATE_TYPE AS MTG1_MTG_INTEREST_RATE_TYPE
			,MTG4_MTG_INTEREST_RATE AS MTG1_MTG_INTEREST_RATE
			,MTG4_SELLER_CARRY_BACK AS MTG1_SELLER_CARRY_BACK
			,MTG4_PRIVATE_PARTY_LENDER AS MTG1_PRIVATE_PARTY_LENDER
			,MTG4_CONSTRUCTION_LOAN AS MTG1_CONSTRUCTION_LOAN
			,MTG4_REFI_FLAG AS MTG1_REFI_FLAG
			,MTG4_EQUITY_FLAG AS MTG1_EQUITY_FLAG
			,MTG4_OTHER_SUBORDINATE_LOANS AS MTG1_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG2_RECORDING_DATE
			,NULL AS MTG2_DOC_DATE
			,NULL AS MTG2_DOC_NBR
			,NULL AS MTG2_RECORDING_BOOK
			,NULL AS MTG2_RECORDING_PAGE
			,NULL AS MTG2_DETAILED_DOC_TYPE
			,NULL AS MTG2_MTG_AMOUNT
			,NULL AS MTG2_LENDER_LAST_NAME
			,NULL AS MTG2_LENDER_FIRST_NAME
			,NULL AS MTG2_LENDER_ADDRESS
			,NULL AS MTG2_LENDER_CITY
			,NULL AS MTG2_LENDER_STATE
			,NULL AS MTG2_LENDER_ZIP
			,NULL AS MTG2_MTG_COMPANY_CODE
			,NULL AS MTG2_MTG_LOAN_TYPE_CODE
			,NULL AS MTG2_MTG_TERM_CODE
			,NULL AS MTG2_MTG_TERM
			,NULL AS MTG2_MTG_DUE_DATE
			,NULL AS MTG2_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG2_MTG_INTEREST_RATE
			,NULL AS MTG2_SELLER_CARRY_BACK
			,NULL AS MTG2_PRIVATE_PARTY_LENDER
			,NULL AS MTG2_CONSTRUCTION_LOAN
			,NULL AS MTG2_REFI_FLAG
			,NULL AS MTG2_EQUITY_FLAG
			,NULL AS MTG2_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG3_RECORDING_DATE
			,NULL AS MTG3_DOC_DATE
			,NULL AS MTG3_DOC_NBR
			,NULL AS MTG3_RECORDING_BOOK
			,NULL AS MTG3_RECORDING_PAGE
			,NULL AS MTG3_DETAILED_DOC_TYPE
			,NULL AS MTG3_MTG_AMOUNT
			,NULL AS MTG3_LENDER_LAST_NAME
			,NULL AS MTG3_LENDER_FIRST_NAME
			,NULL AS MTG3_LENDER_ADDRESS
			,NULL AS MTG3_LENDER_CITY
			,NULL AS MTG3_LENDER_STATE
			,NULL AS MTG3_LENDER_ZIP
			,NULL AS MTG3_MTG_COMPANY_CODE
			,NULL AS MTG3_MTG_LOAN_TYPE_CODE
			,NULL AS MTG3_MTG_TERM_CODE
			,NULL AS MTG3_MTG_TERM
			,NULL AS MTG3_MTG_DUE_DATE
			,NULL AS MTG3_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG3_MTG_INTEREST_RATE
			,NULL AS MTG3_SELLER_CARRY_BACK
			,NULL AS MTG3_PRIVATE_PARTY_LENDER
			,NULL AS MTG3_CONSTRUCTION_LOAN
			,NULL AS MTG3_REFI_FLAG
			,NULL AS MTG3_EQUITY_FLAG
			,NULL AS MTG3_OTHER_SUBORDINATE_LOANS
			,NULL AS MTG4_RECORDING_DATE
			,NULL AS MTG4_DOC_DATE
			,NULL AS MTG4_DOC_NBR
			,NULL AS MTG4_RECORDING_BOOK
			,NULL AS MTG4_RECORDING_PAGE
			,NULL AS MTG4_DETAILED_DOC_TYPE
			,NULL AS MTG4_MTG_AMOUNT
			,NULL AS MTG4_LENDER_LAST_NAME
			,NULL AS MTG4_LENDER_FIRST_NAME
			,NULL AS MTG4_LENDER_ADDRESS
			,NULL AS MTG4_LENDER_CITY
			,NULL AS MTG4_LENDER_STATE
			,NULL AS MTG4_LENDER_ZIP
			,NULL AS MTG4_MTG_COMPANY_CODE
			,NULL AS MTG4_MTG_LOAN_TYPE_CODE
			,NULL AS MTG4_MTG_TERM_CODE
			,NULL AS MTG4_MTG_TERM
			,NULL AS MTG4_MTG_DUE_DATE
			,NULL AS MTG4_MTG_INTEREST_RATE_TYPE
			,NULL AS MTG4_MTG_INTEREST_RATE
			,NULL AS MTG4_SELLER_CARRY_BACK
			,NULL AS MTG4_PRIVATE_PARTY_LENDER
			,NULL AS MTG4_CONSTRUCTION_LOAN
			,NULL AS MTG4_REFI_FLAG
			,NULL AS MTG4_EQUITY_FLAG
			,NULL AS MTG4_OTHER_SUBORDINATE_LOANS
			,d.ORIGINAL_RECORDED_DATE
			,d.ORIGINAL_BKPG
			,d.ORIGINAL_DOC_NBR
			,d.SECTION
			,d.TOWNSHIP
			,d.RANGE
			,d.DISTRICT_CODE
			,d.LOT
			,d.BLOCK
			,d.SUBDIVISION_NAME
			,d.UNIT
			,d.BUILDING
			,d.PLAT_SUBD_MAP_BOOK
			,d.PLAT_SUBD_MAP_PAGE
			,d.MAP_TYPE_IND
			,d.EXPANDED_LEGAL
			,d.TRACT_NBR
			,d.LAND_LOT
			,d.TITLE_COMPANY_NAME
			,d.TITLE_COMPANY_CODE
			,d.MULTI_APN
			,d.SALES_SOURCE_IND
			,d.TIMESTAMP_DATE
			,d.RECORD_TYPE
			,d.PRI_CAT_CODE
			,d.CREATED
			,d.PREVIOUS_PARCEL_NBR
			,d.PREVIOUS_PARCEL_SEQUENCE_NBR
			,FMT_MTG4_DOC_NBR AS FMT_DOC_NBR
			,CMT_ID_MTG4_DOC_NBR AS CMT_ID_DOC_NBR
			,FMT_MTG4_DOC_NBR AS FMT_MTG1_DOC_NBR
			,CMT_ID_MTG4_DOC_NBR AS CMT_ID_MTG1_DOC_NBR
			,NULL AS FMT_MTG2_DOC_NBR
			,NULL AS CMT_ID_MTG2_DOC_NBR
			,NULL AS FMT_MTG3_DOC_NBR
			,NULL AS CMT_ID_MTG3_DOC_NBR
			,NULL AS FMT_MTG4_DOC_NBR
			,NULL AS CMT_ID_MTG4_DOC_NBR
			,FMT_MTG4_Book_Page AS FMT_Book_Page
			,CMT_ID_MTG4_Book_Page AS CMT_ID_Book_Page
			,FMT_MTG4_Book_Page AS FMT_MTG1_Book_Page
			,CMT_ID_MTG4_Book_Page AS CMT_ID_MTG1_Book_Page
			,NULL AS FMT_MTG2_Book_Page
			,NULL AS CMT_ID_MTG2_Book_Page
			,NULL AS FMT_MTG3_Book_Page
			,NULL AS CMT_ID_MTG3_Book_Page
			,NULL AS FMT_MTG4_Book_Page
			,NULL AS CMT_ID_MTG4_Book_Page
			,d.Source_type
			,CASE 
				WHEN d.Source_type = 'E'
					THEN 'EPM'
				ELSE 'MDM'
				END AS SRC_TBL
			,d.MOD_RAS_CLGX_UNIQUE_ID
			,d.UR_Doc_Unique_Id
			,MTG4_UR_Doc_Id AS UR_Doc_Id
			,d.UR_Property_Id
			,d.UR_Name_Id
			,d.UR_Reference_Id
			,d.FORECLOSURE_FLAG
			,d.REO_SALE_FLAG
			,d.ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,d.DATA_SRC_IND
			,d.UR_Prop_Seq_Num
			,d.UR_Reprocess_Flag
			,d.Attorney_Name_identifier
			,d.Attorney_Last_Name
			,d.Attorney_First_Name
			,d.Attorney_Middle_Initial
			,d.Attorney_suffix
			,d.Attorney_address
			,d.Attorney_Address_City
			,d.Attorney_Address_State
			,d.Attorney_Address_Zip
			,d.Attorney_Phone
			,d.Attorney_Full_Name
			,d.UR_REMARKS
			,substring(isnull(d.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(d.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(d.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(d.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,4 AS mtg_occ
			,'z' AS _ld   
			,d.ORIG_MTG4_Lender_Name AS ORIG_MTG1_Lender_Name  
			,NULL AS ORIG_MTG2_Lender_Name  
			,NULL AS ORIG_MTG3_Lender_Name
			,NULL AS ORIG_MTG4_Lender_Name
			,d.NMLSLenderName_4      AS NMLSLenderName_1       
			,d.NMLSLenderId_4        AS NMLSLenderId_1       
			,d.NMLSBrokerName_4      AS NMLSBrokerName_1       
			,d.NMLSBrokerId_4        AS NMLSBrokerId_1       
			,d.NMLSAgentName_4       AS NMLSAgentName_1       
			,d.NMLSAgentId_4   AS NMLSAgentId_1   
			,NULL AS NMLSLenderName_2       
			,NULL AS NMLSLenderId_2       
			,NULL AS NMLSBrokerName_2       
			,NULL AS NMLSBrokerId_2       
			,NULL AS NMLSAgentName_2       
			,NULL AS NMLSAgentId_2    
			,NULL AS NMLSLenderName_3       
			,NULL AS NMLSLenderId_3       
			,NULL AS NMLSBrokerName_3       
			,NULL AS NMLSBrokerId_3       
			,NULL AS NMLSAgentName_3       
			,NULL AS NMLSAgentId_3      
			,NULL AS NMLSLenderName_4       
			,NULL AS NMLSLenderId_4       
			,NULL AS NMLSBrokerName_4       
			,NULL AS NMLSBrokerId_4       
			,NULL AS NMLSAgentName_4       
			,NULL AS NMLSAgentId_4   
			,d.Attorney_Email
			,d.Attorney_Firm_Name
			,d.Mtg4_Int_Source AS Mtg1_Int_Source
			,NULL AS Mtg2_Int_Source
			,NULL AS Mtg3_Int_Source
			,NULL AS Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Deed_work] d
		--OUTER APPLY (
		--	SELECT clgx_unique_id
		--	FROM deed.dbo.deed b
		--	WHERE b.ur_doc_id = d.ur_doc_id
		--		AND b.ref_id = d.ref_id
		--	) b
		WHERE d.Deed_TYPE NOT IN ('t')
		
		UNION ALL
		
		SELECT 0 AS row4
			,'ETL' AS Origin
			,'T' AS _DeedMtg
			,m.DeedID
			,m.FIPS
			,m.REF_ID
			,m.US_STATE
			,m.US_COUNTY
			,m.APN_unformatted
			,m.APN_formatted_UNIVERSAL
			,m.APN_SEQUENCE_NBR
			,m.ORIGINAL_APN
			,m.ACCOUNT_NBR
			,m.PENDING_TRANS
			,m.BYR1_CORP_IND
			,isnull(m.BYR1_OWN_NAME, '') AS BYR1_OWN_NAME
			,m.BYR1_OWN_ETAL_IND
			,m.BYR1_CO_NAME
			,m.BYR1_OWNERSHIP_RIGHTS_CODE
			,m.BYR1_OWN_RELATIONSHIP_TYPE
			,m.BYR1_OWNERSHIP
			,m.BYR2_CORP_IND
			,isnull(m.BYR2_OWN_NAME, '') AS BYR2_OWN_NAME
			,m.BYR2_OWNERSHIP_RIGHTS_CODE
			,m.BYR2_OWN_RELATIONSHIP_TYPE
			,m.BYR2_OWNERSHIP
			,m.BYR3_CORP_IND
			,isnull(m.BYR3_OWN_NAME, '') AS BYR3_OWN_NAME
			,m.BYR3_OWNERSHIP_RIGHTS_CODE
			,m.BYR3_OWN_RELATIONSHIP_TYPE
			,m.BYR3_OWNERSHIP
			,m.BYR4_CORP_IND
			,isnull(m.BYR4_OWN_NAME, '') AS BYR4_OWN_NAME
			,m.BYR4_OWNERSHIP_RIGHTS_CODE
			,m.BYR4_OWN_RELATIONSHIP_TYPE
			,m.BYR4_OWNERSHIP
			,m.BYR1_LAST_NAME
			,m.BYR1_FIRST_NAME
			,m.BYR1_MIDDLE_INITIAL
			,m.BYR1_SUFFIX
			,m.BYR2_LAST_NAME
			,m.BYR2_FIRST_NAME
			,m.BYR2_MIDDLE_INITIAL
			,m.BYR2_SUFFIX
			,m.BYR3_LAST_NAME
			,m.BYR3_FIRST_NAME
			,m.BYR3_MIDDLE_INITIAL
			,m.BYR3_SUFFIX
			,m.BYR4_LAST_NAME
			,m.BYR4_FIRST_NAME
			,m.BYR4_MIDDLE_INITIAL
			,m.BYR4_SUFFIX
			,m.MA_HOUSE_NBR_PREFIX
			,m.MA_HOUSE_NBR
			,m.MA_HOUSE_NBR_SUFFIX
			,m.MA_STREET_DIRECTION
			,m.MA_STREET_NAME
			,m.MA_MODE
			,m.MA_QUADRANT
			,m.MA_APARTMENT_UNIT
			,m.MA_CITY
			,m.MA_STATE
			,m.MA_ZIP_CODE
			,m.MA_CARRIER_CODE
			,m.MA_ORIGINAL_MAILING_ADDRESS
			,m.MA_DO_NOT_PUBLISH_FLAG
			,m.SITUS_HOUSE_NBR
			,m.SITUS_HOUSE_NBR2
			,m.SITUS_HOUSE_NBR_SUFFIX
			,m.SITUS_DIRECTION
			,m.SITUS_STREET_NAME
			,m.SITUS_MODE
			,m.SITUS_POST_DIRECTION
			,m.SITUS_UNIT_NBR
			,m.SITUS_CITY
			,m.SITUS_STATE
			,m.SITUS_ZIP_CODE
			,m.SITUS_CARRIER_CODE
			,m.ORIGINAL_SITE_ADDRESS
			--,CASE 
			--	WHEN b.CLGX_UNIQUE_ID IS NOT NULL
			--		THEN b.CLGX_UNIQUE_ID
			--	ELSE d.CLGX_UNIQUE_ID
			--	END AS CLGX_UNIQUE_ID
			,m.CLGX_UNIQUE_ID
			,m.mtg1_RECORDING_DATE AS RECORDING_DATE
			,m.mtg1_DOC_DATE AS SALE_DATE
			,m.mtg1_DOC_NBR AS DOC_NBR
			,m.mtg1_RECORDING_BOOK AS RECORDING_BOOK
			,m.mtg1_RECORDING_PAGE AS RECORDING_PAGE
			,m.HAWAII_LAND_COURT_DOC_NBR
			,m.HAWAII_TCT_CERTIFICATE_NBR
			,m.WA_EXCISE_NBR
			,'T' AS Deed_TYPE
			,DETAILED_DOC_TYPE
			,m.TRANSACTION_TYPE
			,isnull(m.SELLER_NAME_PLAINTIFF_1, '') AS SELLER_NAME_PLAINTIFF_1
			,m.SELLER_NAME_PLAINTIFF1_CORP_IND
			,isnull(m.SELLER_NAME_PLAINTIFF_2, '') AS SELLER_NAME_PLAINTIFF_2
			,m.SELLER_NAME_PLAINTIFF_2_CORP_IND
			,m.SALE_AMOUNT
			,m.DOC_TRANSFER_TAX
			,m.SALE_CODE
			,m.PARTIAL_INTEREST_IND
			,m.RESALE_NEW_CONSTRUCTION
			,m.INTER_FAMILY
			,m.FORCLOSURE
			,m.REO_SALE
			,m.mtg1_RECORDING_DATE
			,m.mtg1_DOC_DATE
			,m.mtg1_DOC_NBR
			,m.mtg1_RECORDING_BOOK
			,m.mtg1_RECORDING_PAGE
			,m.mtg1_DETAILED_DOC_TYPE
			,m.mtg1_MTG_AMOUNT
			,m.mtg1_LENDER_LAST_NAME
			,m.mtg1_LENDER_FIRST_NAME
			,m.mtg1_LENDER_ADDRESS
			,m.mtg1_LENDER_CITY
			,m.mtg1_LENDER_STATE
			,m.mtg1_LENDER_ZIP
			,m.mtg1_MTG_COMPANY_CODE
			,m.mtg1_MTG_LOAN_TYPE_CODE
			,m.mtg1_MTG_TERM_CODE
			,m.mtg1_MTG_TERM_
			,m.mtg1_MTG_DUE_DATE
			,m.mtg1_MTG_INTEREST_RATE_TYPE
			,m.mtg1_MTG_INTEREST_RATE
			,m.mtg1_SELLER_CARRY_BACK
			,m.mtg1_PRIVATE_PARTY_LENDER
			,m.mtg1_CONSTRUCTION_LOAN
			,m.mtg1_REFI_FLAG
			,m.mtg1_EQUITY_FLAG
			,m.mtg1_OTHER_SUBORDINATE_LOANS
			,m.MTG2_RECORDING_DATE
			,m.MTG2_DOC_DATE
			,m.MTG2_DOC_NBR
			,m.MTG2_RECORDING_BOOK
			,m.MTG2_RECORDING_PAGE
			,m.MTG2_DETAILED_DOC_TYPE
			,m.MTG2_MTG_AMOUNT
			,m.MTG2_LENDER_LAST_NAME
			,m.MTG2_LENDER_FIRST_NAME
			,m.MTG2_LENDER_ADDRESS
			,m.MTG2_LENDER_CITY
			,m.MTG2_LENDER_STATE
			,m.MTG2_LENDER_ZIP
			,m.MTG2_MTG_COMPANY_CODE
			,m.MTG2_MTG_LOAN_TYPE_CODE
			,m.MTG2_MTG_TERM_CODE
			,m.MTG2_MTG_TERM
			,m.MTG2_MTG_DUE_DATE
			,m.MTG2_MTG_INTEREST_RATE_TYPE
			,m.MTG2_MTG_INTEREST_RATE
			,m.MTG2_SELLER_CARRY_BACK
			,m.MTG2_PRIVATE_PARTY_LENDER
			,m.MTG2_CONSTRUCTION_LOAN
			,m.MTG2_REFI_FLAG
			,m.MTG2_EQUITY_FLAG
			,m.MTG2_OTHER_SUBORDINATE_LOANS
			,m.MTG3_RECORDING_DATE
			,m.MTG3_DOC_DATE
			,m.MTG3_DOC_NBR
			,m.MTG3_RECORDING_BOOK
			,m.MTG3_RECORDING_PAGE
			,m.MTG3_DETAILED_DOC_TYPE
			,m.MTG3_MTG_AMOUNT
			,m.MTG3_LENDER_LAST_NAME
			,m.MTG3_LENDER_FIRST_NAME
			,m.MTG3_LENDER_ADDRESS
			,m.MTG3_LENDER_CITY
			,m.MTG3_LENDER_STATE
			,m.MTG3_LENDER_ZIP
			,m.MTG3_MTG_COMPANY_CODE
			,m.MTG3_MTG_LOAN_TYPE_CODE
			,m.MTG3_MTG_TERM_CODE
			,m.MTG3_MTG_TERM
			,m.MTG3_MTG_DUE_DATE
			,m.MTG3_MTG_INTEREST_RATE_TYPE
			,m.MTG3_MTG_INTEREST_RATE
			,m.MTG3_SELLER_CARRY_BACK
			,m.MTG3_PRIVATE_PARTY_LENDER
			,m.MTG3_CONSTRUCTION_LOAN
			,m.MTG3_REFI_FLAG
			,m.MTG3_EQUITY_FLAG
			,m.MTG3_OTHER_SUBORDINATE_LOANS
			,m.MTG4_RECORDING_DATE
			,m.MTG4_DOC_DATE
			,m.MTG4_DOC_NBR
			,m.MTG4_RECORDING_BOOK
			,m.MTG4_RECORDING_PAGE
			,m.MTG4_DETAILED_DOC_TYPE
			,m.MTG4_MTG_AMOUNT
			,m.MTG4_LENDER_LAST_NAME
			,m.MTG4_LENDER_FIRST_NAME
			,m.MTG4_LENDER_ADDRESS
			,m.MTG4_LENDER_CITY
			,m.MTG4_LENDER_STATE
			,m.MTG4_LENDER_ZIP
			,m.MTG4_MTG_COMPANY_CODE
			,m.MTG4_MTG_LOAN_TYPE_CODE
			,m.MTG4_MTG_TERM_CODE
			,m.MTG4_MTG_TERM
			,m.MTG4_MTG_DUE_DATE
			,m.MTG4_MTG_INTEREST_RATE_TYPE
			,m.MTG4_MTG_INTEREST_RATE
			,m.MTG4_SELLER_CARRY_BACK
			,m.MTG4_PRIVATE_PARTY_LENDER
			,m.MTG4_CONSTRUCTION_LOAN
			,m.MTG4_REFI_FLAG
			,m.MTG4_EQUITY_FLAG
			,m.MTG4_OTHER_SUBORDINATE_LOANS
			,m.ORIGINAL_RECORDED_DATE
			,m.ORIGINAL_BKPG
			,m.ORIGINAL_DOC_NBR
			,m.SECTION
			,m.TOWNSHIP
			,m.RANGE
			,m.DISTRICT_CODE
			,m.LOT
			,m.BLOCK
			,m.SUBDIVISION_NAME
			,m.UNIT
			,m.BUILDING
			,m.PLAT_SUBD_MAP_BOOK
			,m.PLAT_SUBD_MAP_PAGE
			,m.MAP_TYPE_IND
			,m.EXPANDED_LEGAL
			,m.TRACT_NBR
			,m.LAND_LOT
			,m.TITLE_COMPANY_NAME
			,m.TITLE_COMPANY_CODE
			,m.MULTI_APN
			,m.SALES_SOURCE_IND
			,m.TIMESTAMP_DATE
			,m.RECORD_TYPE
			,m.PRI_CAT_CODE
			,m.CREATED
			,m.PREVIOUS_PARCEL_NBR
			,m.PREVIOUS_PARCEL_SEQUENCE_NBR
			,FMT_DOC_NBR
			,CMT_ID_DOC_NBR
			,FMT_MTG1_DOC_NBR
			,CMT_ID_MTG1_DOC_NBR
			,FMT_MTG2_DOC_NBR
			,CMT_ID_MTG2_DOC_NBR
			,FMT_MTG3_DOC_NBR
			,CMT_ID_MTG3_DOC_NBR
			,FMT_MTG4_DOC_NBR
			,CMT_ID_MTG4_DOC_NBR
			,FMT_Book_Page
			,CMT_ID_Book_Page
			,FMT_MTG1_Book_Page
			,CMT_ID_MTG1_Book_Page
			,FMT_MTG2_Book_Page
			,CMT_ID_MTG2_Book_Page
			,FMT_MTG3_Book_Page
			,CMT_ID_MTG3_Book_Page
			,FMT_MTG4_Book_Page
			,CMT_ID_MTG4_Book_Page
			,m.Source_type
			,m.SRC_TBL
			,m.MOD_RAS_CLGX_UNIQUE_ID
			,m.UR_Doc_Unique_Id
			,m.UR_Doc_Id
			,m.UR_Property_Id
			,m.UR_Name_Id
			,m.UR_Reference_Id
			,NULL AS FORECLOSURE_FLAG
			,NULL AS REO_SALE_FLAG
			,NULL AS ARMS_LENGTH_ID
			,NULL AS MTG1_UR_Doc_Id
			,NULL AS MTG2_UR_Doc_Id
			,NULL AS MTG3_UR_Doc_Id
			,NULL AS MTG4_UR_Doc_Id
			,m.DATA_SRC_IND
			,m.UR_Prop_Seq_Num
			,m.UR_Reprocess_Flag
			,m.Attorney_Name_identifier
			,m.Attorney_Last_Name
			,m.Attorney_First_Name
			,m.Attorney_Middle_Initial
			,m.Attorney_suffix
			,m.Attorney_address
			,m.Attorney_Address_City
			,m.Attorney_Address_State
			,m.Attorney_Address_Zip
			,m.Attorney_Phone
			,m.Attorney_Full_Name
			,m.UR_REMARKS
			,substring(isnull(m.BYR1_OWN_NAME, ''), 1, 4) AS BYR1_4
			,substring(isnull(m.BYR2_OWN_NAME, ''), 1, 4) AS BYR2_4
			,substring(isnull(m.BYR3_OWN_NAME, ''), 1, 4) AS BYR3_4
			,substring(isnull(m.BYR4_OWN_NAME, ''), 1, 4) AS BYR4_4
			,1 AS mtg_occ
			,'z' AS _ld   
			,m.ORIG_MTG1_Lender_Name
			,m.ORIG_MTG2_Lender_Name
			,m.ORIG_MTG3_Lender_Name
			,m.ORIG_MTG4_Lender_Name
			,m.NMLSLenderName_1       
			,m.NMLSLenderId_1       
			,m.NMLSBrokerName_1       
			,m.NMLSBrokerId_1       
			,m.NMLSAgentName_1       
			,m.NMLSAgentId_1   
			,m.NMLSLenderName_2       
			,m.NMLSLenderId_2       
			,m.NMLSBrokerName_2       
			,m.NMLSBrokerId_2       
			,m.NMLSAgentName_2       
			,m.NMLSAgentId_2    
			,m.NMLSLenderName_3       
			,m.NMLSLenderId_3       
			,m.NMLSBrokerName_3       
			,m.NMLSBrokerId_3       
			,m.NMLSAgentName_3       
			,m.NMLSAgentId_3  
			,m.NMLSLenderName_4       
			,m.NMLSLenderId_4       
			,m.NMLSBrokerName_4       
			,m.NMLSBrokerId_4       
			,m.NMLSAgentName_4       
			,m.NMLSAgentId_4
			,m.Attorney_Email
			,m.Attorney_Firm_Name
			,m.Mtg1_Int_Source
			,m.Mtg2_Int_Source
			,m.Mtg3_Int_Source
			,m.Mtg4_Int_Source
		FROM [lien_DTDB].[INFC].[Mortgage_work] m
		--OUTER APPLY (
		--	SELECT clgx_unique_id
		--	FROM deed.dbo.deed b
		--	WHERE b.ur_doc_id = m.ur_doc_id
		--		AND b.ref_id = m.ref_id
		--	) b
		WHERE ref_id IS NOT NULL
		) a
	WHERE a.ref_id IS NOT NULL
		AND a.RECORDING_DATE IS NOT NULL
		AND isnull(a.DETAILED_DOC_TYPE, '') NOT IN (
			'CD'
			,'RD'
			,'MO'
			,'SX'
			,'AF'
			)

	--select fips,ur_doc_id,ref_id, clgx_unique_id, count(1) as cnt
	--from lien_dtdb.tmp.UR_Merge_Deed_To_Mtg_New_temp
	--where ref_id is not null and clgx_unique_id is not null
	--group by fips,ur_doc_id,ref_id, clgx_unique_id
	--having count(1) > 1
	--select * from lien_dtdb.tmp.UR_Merge_Deed_To_Mtg_New_temp 
	--where fips = 35035 and ur_doc_id = 258997508 and ref_id = 88504035
	--nessie
	UPDATE [lien_DTDB].[INFC].[t]
	SET t.HI_PRefix = l.HI_PRefix
	FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] t
	OUTER APPLY (
		SELECT TOP 1 CASE 
				WHEN substring(l.recording_doc_number, 1, 1) IN (
						'T'
						,'A'
						)
					AND t.fips BETWEEN 15000
						AND 16000
					THEN substring(l.recording_doc_number, 1, 1)
				ELSE ''
				END HI_PRefix
		FROM [lien].[ur].[document] l
		WHERE l.doc_id = t.ur_doc_id
		) l

	--
	--
	TRUNCATE TABLE [lien_DTDB].[infc].[DeedMtg2]

	--
	-- split the Deed wrk table into seperate documents; one for the Deed and one for each mortgage on the Deed and one for each mortgage work
	--
	INSERT INTO [lien_DTDB].[infc].[DeedMtg2] (
		[ROW4]
		,[origin]
		,[_DeedMtg]
		,[DeedID]
		,[FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[Deed_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[FORECLOSURE_FLAG]
		,[REO_SALE_FLAG]
		,[ARMS_LENGTH_ID]
		,[MTG1_UR_Doc_Id]
		,[MTG2_UR_Doc_Id]
		,[MTG3_UR_Doc_Id]
		,[MTG4_UR_Doc_Id]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[UR_REMARKS]
		,[BYR1_4]
		,[BYR2_4]
		,[BYR3_4]
		,[BYR4_4]
		,[mtg_occ]
		,[HI_prefix]
		,[dup_doc_nbr]      
		,[ORIG_MTG1_Lender_Name]      
		,[ORIG_MTG2_Lender_Name]      
		,[ORIG_MTG3_Lender_Name]      
		,[ORIG_MTG4_Lender_Name]      
		,[NMLSLenderName_1]       
		,[NMLSLenderId_1]       
		,[NMLSBrokerName_1]       
		,[NMLSBrokerId_1]       
		,[NMLSAgentName_1]       
		,[NMLSAgentId_1]       
		,[NMLSLenderName_2]       
		,[NMLSLenderId_2]       
		,[NMLSBrokerName_2]       
		,[NMLSBrokerId_2]       
		,[NMLSAgentName_2]       
		,[NMLSAgentId_2]       
		,[NMLSLenderName_3]       
		,[NMLSLenderId_3]       
		,[NMLSBrokerName_3]       
		,[NMLSBrokerId_3]       
		,[NMLSAgentName_3]       
		,[NMLSAgentId_3]       
		,[NMLSLenderName_4]       
		,[NMLSLenderId_4]       
		,[NMLSBrokerName_4]       
		,[NMLSBrokerId_4]       
		,[NMLSAgentName_4]       
		,[NMLSAgentId_4]
		,Attorney_Email
		,Attorney_Firm_Name
		,Mtg1_Int_Source
		,Mtg2_Int_Source
		,Mtg3_Int_Source
		,Mtg4_Int_Source
		)
	SELECT [ROW4]
		,[origin]
		,[_DeedMtg]
		,[DeedID]
		,[FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,CASE 
			WHEN fips BETWEEN 26000
					AND 27000
				THEN (
						CASE 
							WHEN recording_date IS NOT NULL
								THEN recording_date
							ELSE sale_date
							END
						)
			ELSE recording_date
			END AS [RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[Deed_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[FORECLOSURE_FLAG]
		,[REO_SALE_FLAG]
		,[ARMS_LENGTH_ID]
		,[MTG1_UR_Doc_Id]
		,[MTG2_UR_Doc_Id]
		,[MTG3_UR_Doc_Id]
		,[MTG4_UR_Doc_Id]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[UR_REMARKS]
		,[BYR1_4]
		,[BYR2_4]
		,[BYR3_4]
		,[BYR4_4]
		,[mtg_occ]
		,[HI_prefix]
		,[dup_doc_nbr]     
		,[ORIG_MTG1_Lender_Name]      
		,[ORIG_MTG2_Lender_Name]      
		,[ORIG_MTG3_Lender_Name]      
		,[ORIG_MTG4_Lender_Name]      
		,[NMLSLenderName_1]       
		,[NMLSLenderId_1]       
		,[NMLSBrokerName_1]       
		,[NMLSBrokerId_1]       
		,[NMLSAgentName_1]       
		,[NMLSAgentId_1]       
		,[NMLSLenderName_2]       
		,[NMLSLenderId_2]       
		,[NMLSBrokerName_2]       
		,[NMLSBrokerId_2]       
		,[NMLSAgentName_2]       
		,[NMLSAgentId_2]       
		,[NMLSLenderName_3]       
		,[NMLSLenderId_3]       
		,[NMLSBrokerName_3]       
		,[NMLSBrokerId_3]       
		,[NMLSAgentName_3]       
		,[NMLSAgentId_3]       
		,[NMLSLenderName_4]       
		,[NMLSLenderId_4]       
		,[NMLSBrokerName_4]       
		,[NMLSBrokerId_4]       
		,[NMLSAgentName_4]       
		,[NMLSAgentId_4]   
		,Attorney_Email
		,Attorney_Firm_Name
		,Mtg1_Int_Source
		,Mtg2_Int_Source
		,Mtg3_Int_Source
		,Mtg4_Int_Source
	FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp]

	--
	-- Link mtg to Deed
	--
	DROP TABLE

	IF EXISTS [lien_DTDB].[INFC].[UR_MErge_rep]
		SELECT d.ID AS Deed_Deed
			,t.id AS trust_id
			,t.INTER_FAMILY
			,t.ROW4
			,t.origin
			,t._DeedMtg
			,t.DeedID
			,t.FIPS
			,t.REF_ID
			,t.SELLER_NAME_PLAINTIFF_1
			,t.SELLER_NAME_PLAINTIFF_2
			,t.BYR1_OWN_NAME
			,t.BYR2_OWN_NAME
			,t.BYR3_OWN_NAME
			,t.BYR4_OWN_NAME
			,t.RECORDING_DATE
			,t.SALE_DATE
			,t.DOC_NBR
			,t.RECORDING_BOOK
			,t.RECORDING_PAGE
			,t.Deed_TYPE
			,t.DETAILED_DOC_TYPE
			,t.TRANSACTION_TYPE
			,t.SALE_AMOUNT
			,t.FMT_DOC_NBR
			,t.FMT_Book_Page
			,t.Source_type
			,t.SRC_TBL
			,t.ur_doc_id
			,t.BYR1_4
			,t.BYR2_4
			,t.BYR3_4
			,t.BYR4_4
			,t.mtg_occ
		INTO [lien_DTDB].[INFC].[UR_MErge_rep]
		FROM [lien_DTDB].[infc].[DeedMtg2] t
		OUTER APPLY (
			SELECT TOP 1 d.*
			FROM [lien_DTDB].[infc].[DeedMtg2] d
			WHERE d.FIPS = t.FIPS
				AND d.REF_ID = t.REF_ID
				AND (
					(
						d.BYR1_4 IN (
							t.BYR1_4
							,t.BYR2_4
							,t.BYR3_4
							,t.BYR4_4
							)
						AND d.BYR1_4 <> ''
						)
					)
				AND (
					(
						t.RECORDING_DATE BETWEEN d.RECORDING_DATE
							AND Dateadd(day, 5, d.RECORDING_DATE)
						)
					OR (
						d.fips BETWEEN 26000
							AND 27000
						AND t.RECORDING_DATE BETWEEN Dateadd(day, - 5, d.RECORDING_DATE)
							AND d.RECORDING_DATE
						)
					)
				AND t.Source_type = d.Source_type
				AND d._DeedMtg = 'D'
				AND t._DeedMtg = 't'
				AND t.HI_PRefix = d.HI_PRefix
				AND (
					t.fips NOT BETWEEN 26000
						AND 27000
					OR (
						t.fips BETWEEN 26000
							AND 27000
						AND isnull(t.CMT_ID_DOC_NBR, 0) = isnull(d.CMT_ID_DOC_NBR, 0)
						)
					)
				AND (
					(
						t.fips IN (
							01111
							,29029
							,21237
							)
						OR t.fips BETWEEN 26000
							AND 27000
						)
					OR (
						t.fips NOT IN (
							01111
							,29029
							,21237
							)
						AND (
							(
								isnull(d.DOC_NBR, '') < isnull(t.DOC_NBR, '')
								AND isnull(d.doc_nbr, '') > ''
								)
							OR (
								isnull(d.RECORDING_BOOK, '') + isnull(d.RECORDING_page, '') < isnull(t.RECORDING_BOOK, '') + isnull(t.RECORDING_Page, '')
								AND isnull(d.RECORDING_page, '') > ''
								)
							OR (
								isnull(d.doc_nbr, '') > ''
								AND isnull(d.RECORDING_page, '') > ''
								)
							)
						)
					)
			ORDER BY d.FIPS
				,d.REF_ID
				,d.BYR1_4
				,d.RECORDING_DATE
				,ISNULL(d.SALE_AMOUNT, 0) DESC -- Marie So that we merge to deed with the sale amount
				--,CASE 
				--     WHEN isnull(d.TRANSACTION_TYPE, '') = ''
				--           THEN '9'
				--     ELSE d.TRANSACTION_TYPE
				--     END
				,CASE 
					WHEN d.INTER_FAMILY IS NOT NULL
						THEN 0
					ELSE 1
					END
				--,(isnull(d.DOC_NBR, '') + isnull(d.RECORDING_BOOK, '') + isnull(d.RECORDING_page, '')) DESC
				,(right('000000000000' + (isnull(d.DOC_NBR, '')), 12) + isnull(d.RECORDING_BOOK, '') + isnull(d.RECORDING_page, '')) ASC
				,d._DeedMtg
				,CASE 
					WHEN d.SALE_DATE = t.SALE_DATE
						THEN 1
					ELSE 0
					END
				,d.ur_doc_id ASC
			) d
		WHERE t.ref_id IN (
				SELECT DISTINCT ref_id
				FROM [lien_DTDB].[infc].[DeedMtg2] b
				WHERE b._DeedMtg = 't'
				)
			AND d.id IS NOT NULL
			AND t.RECORDING_DATE IS NOT NULL
		ORDER BY t.FIPS
			,t.REF_ID
			,t.BYR1_4
			,t.RECORDING_DATE
			,t.FMT_DOC_NBR
			,t.FMT_Book_Page
			,t._DeedMtg
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX ix_a ON [lien_DTDB].[INFC].[UR_MErge_rep] (Deed_Deed)

	--SELECT Deed_Deed
	--	,count(1) AS cnt
	--FROM lien_DTDB.INFC.UR_MErge_rep
	--GROUP BY Deed_Deed
	--HAVING count(1) > 1
	--SELECT *
	--FROM lien_DTDB.INFC.Deed_work
	--WHERE ref_id = 2876472
	--SELECT *
	--FROM lien_DTDB.INFC.Mortgage_work
	--WHERE ref_id = 2876472
	--SELECT *
	--FROM lien_DTDB.infc.DeedMtg2
	--WHERE id = 3136
	--SELECT *
	--FROM lien_DTDB.INFC.UR_MErge_rep
	--WHERE Deed_Deed = 3136
	TRUNCATE TABLE [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link]

	INSERT INTO [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link] (
		rn
		,fips
		,DeedID_D
		,DeedID_M
		,Ref_ID_D
		,Ref_ID_M
		,CLGX_UNIQUE_ID_D
		,CLGX_UNIQUE_ID_M
		,Recording_Date_D
		,Recording_Date_M
		,Doc_nbr_D
		,Doc_nbr_M
		,Recording_Book_D
		,Recording_Book_M
		,Recording_page_D
		,Recording_Page_M
		,Sale_amount_D
		,Sale_amount_M
		,SITUS_HOUSE_NBR
		,SITUS_HOUSE_NBR2
		,SITUS_HOUSE_NBR_SUFFIX
		,SITUS_DIRECTION
		,SITUS_STREET_NAME
		,SITUS_MODE
		,SITUS_POST_DIRECTION
		,SITUS_UNIT_NBR
		,SITUS_CITY
		,SITUS_STATE
		,SITUS_ZIP_CODE
		,SITUS_CARRIER_CODE
		,ORIGINAL_SITE_ADDRESS
		,MTG1_RECORDING_DATE_M
		,MTG1_DOC_DATE_M
		,MTG1_DOC_NBR_M
		,MTG1_RECORDING_BOOK_M
		,MTG1_RECORDING_PAGE_M
		,MTG1_DETAILED_DOC_TYPE_M
		,MTG1_MTG_AMOUNT_M
		,MTG1_LENDER_LAST_NAME_M
		,MTG1_LENDER_FIRST_NAME_M
		,MTG1_LENDER_ADDRESS_M
		,MTG1_LENDER_CITY_M
		,MTG1_LENDER_STATE_M
		,MTG1_LENDER_ZIP_M
		,MTG1_MTG_COMPANY_CODE_M
		,MTG1_MTG_LOAN_TYPE_CODE_M
		,MTG1_MTG_TERM_CODE_M
		,MTG1_MTG_TERM_M
		,MTG1_MTG_DUE_DATE_M
		,MTG1_MTG_INTEREST_RATE_TYPE_M
		,MTG1_MTG_INTEREST_RATE_M
		,MTG1_SELLER_CARRY_BACK_M
		,MTG1_PRIVATE_PARTY_LENDER_M
		,MTG1_CONSTRUCTION_LOAN_M
		,MTG1_REFI_FLAG_M
		,MTG1_EQUITY_FLAG_M
		,MTG1_OTHER_SUBORDINATE_LOANS_M
		,FMT_MTG1_DOC_NBR_M
		,CMT_ID_MTG1_DOC_NBR_M
		,FMT_MTG1_Book_Page_M
		,CMT_ID_MTG1_Book_Page_M
		,MTG_UR_Doc_Id
		,[ORIG_MTG1_Lender_Name]      
		,[NMLSLenderName_1]       
		,[NMLSLenderId_1]       
		,[NMLSBrokerName_1]       
		,[NMLSBrokerId_1]       
		,[NMLSAgentName_1]       
		,[NMLSAgentId_1]  
		,Mtg1_Int_Source
		)
	SELECT k.rn2
		,k.fips
		,k.DeedID_D
		,k.DeedID_M
		,k.Ref_ID_d
		,k.Ref_id_m
		,k.CLGX_UNIQUE_ID_d
		,k.CLGX_UNIQUE_ID_m
		,k.Recording_Date_d
		,k.Recording_Date_m
		,k.Doc_nbr_d
		,k.Doc_nbr_m
		,k.Recording_Book_d
		,k.Recording_Book_m
		,k.Recording_page_d
		,k._Recording_page_m
		,k.Sale_amount_d
		,k.Sale_amount_m
		,k.SITUS_HOUSE_NBR
		,k.SITUS_HOUSE_NBR2
		,k.SITUS_HOUSE_NBR_SUFFIX
		,k.SITUS_DIRECTION
		,k.SITUS_STREET_NAME
		,k.SITUS_MODE
		,k.SITUS_POST_DIRECTION
		,k.SITUS_UNIT_NBR
		,k.SITUS_CITY
		,k.SITUS_STATE
		,k.SITUS_ZIP_CODE
		,k.SITUS_CARRIER_CODE
		,k.ORIGINAL_SITE_ADDRESS
		,k.MTG1_RECORDING_DATE
		,k.MTG1_DOC_DATE
		,k.MTG1_DOC_NBR
		,k.MTG1_RECORDING_BOOK
		,k.MTG1_RECORDING_PAGE
		,k.MTG1_DETAILED_DOC_TYPE
		,k.MTG1_MTG_AMOUNT
		,k.MTG1_LENDER_LAST_NAME
		,k.MTG1_LENDER_FIRST_NAME
		,k.MTG1_LENDER_ADDRESS
		,k.MTG1_LENDER_CITY
		,k.MTG1_LENDER_STATE
		,k.MTG1_LENDER_ZIP
		,k.MTG1_MTG_COMPANY_CODE
		,k.MTG1_MTG_LOAN_TYPE_CODE
		,k.MTG1_MTG_TERM_CODE
		,k.MTG1_MTG_TERM_
		,k.MTG1_MTG_DUE_DATE
		,k.MTG1_MTG_INTEREST_RATE_TYPE
		,k.MTG1_MTG_INTEREST_RATE
		,k.MTG1_SELLER_CARRY_BACK
		,k.MTG1_PRIVATE_PARTY_LENDER
		,k.MTG1_CONSTRUCTION_LOAN
		,k.MTG1_REFI_FLAG
		,k.MTG1_EQUITY_FLAG
		,k.MTG1_OTHER_SUBORDINATE_LOANS
		,k.FMT_MTG1_DOC_NBR
		,k.CMT_ID_MTG1_DOC_NBR
		,k.FMT_MTG1_Book_Page
		,k.CMT_ID_MTG1_Book_Page
		,k.MTG1_UR_Doc_Id
		,k.ORIG_MTG1_Lender_Name     
		,k.NMLSLenderName_1      
		,k.NMLSLenderId_1      
		,k.NMLSBrokerName_1      
		,k.NMLSBrokerId_1      
		,k.NMLSAgentName_1      
		,k.NMLSAgentId_1  
		,k.Mtg1_Int_Source
	FROM (
		SELECT row_number() OVER (
				PARTITION BY d.FIPS
				,d.DeedID ORDER BY ms._sort DESC
				) AS rn
			,ROW_NUMBER() OVER (
				PARTITION BY d.FIPS
				,d.DeedID ORDER BY ms._sort
				) AS rn2
			,ms._sort
			,d.fips
			,d.DeedID AS DeedID_D
			,mw.DeedID AS DeedID_M
			,d.Ref_ID AS Ref_ID_d
			,mw.Ref_ID AS Ref_id_m
			,d.CLGX_UNIQUE_ID AS CLGX_UNIQUE_ID_d
			,mw.CLGX_UNIQUE_ID AS CLGX_UNIQUE_ID_m
			,d.Recording_Date AS Recording_Date_d
			,mw.Recording_Date AS Recording_Date_m
			,d.Doc_nbr AS Doc_nbr_d
			,mw.Doc_nbr AS Doc_nbr_m
			,d.Recording_Book AS Recording_Book_d
			,mw.Recording_Book AS Recording_Book_m
			,d.Recording_page AS Recording_page_d
			,mw.Recording_Page AS _Recording_page_m
			,d.Sale_amount AS Sale_amount_d
			,mw.Sale_amount AS Sale_amount_m
			,mw.SITUS_HOUSE_NBR
			,mw.SITUS_HOUSE_NBR2
			,mw.SITUS_HOUSE_NBR_SUFFIX
			,mw.SITUS_DIRECTION
			,mw.SITUS_STREET_NAME
			,mw.SITUS_MODE
			,mw.SITUS_POST_DIRECTION
			,mw.SITUS_UNIT_NBR
			,mw.SITUS_CITY
			,mw.SITUS_STATE
			,mw.SITUS_ZIP_CODE
			,mw.SITUS_CARRIER_CODE
			,mw.ORIGINAL_SITE_ADDRESS
			,mw.MTG1_RECORDING_DATE
			,mw.MTG1_DOC_DATE
			,mw.MTG1_DOC_NBR
			,mw.MTG1_RECORDING_BOOK
			,mw.MTG1_RECORDING_PAGE
			,mw.MTG1_DETAILED_DOC_TYPE
			,mw.MTG1_MTG_AMOUNT
			,mw.MTG1_LENDER_LAST_NAME
			,mw.MTG1_LENDER_FIRST_NAME
			,mw.MTG1_LENDER_ADDRESS
			,mw.MTG1_LENDER_CITY
			,mw.MTG1_LENDER_STATE
			,mw.MTG1_LENDER_ZIP
			,mw.MTG1_MTG_COMPANY_CODE
			,mw.MTG1_MTG_LOAN_TYPE_CODE
			,mw.MTG1_MTG_TERM_CODE
			,mw.MTG1_MTG_TERM_
			,mw.MTG1_MTG_DUE_DATE
			,mw.MTG1_MTG_INTEREST_RATE_TYPE
			,mw.MTG1_MTG_INTEREST_RATE
			,mw.MTG1_SELLER_CARRY_BACK
			,mw.MTG1_PRIVATE_PARTY_LENDER
			,mw.MTG1_CONSTRUCTION_LOAN
			,mw.MTG1_REFI_FLAG
			,mw.MTG1_EQUITY_FLAG
			,mw.MTG1_OTHER_SUBORDINATE_LOANS
			,mw.FMT_MTG1_DOC_NBR
			,mw.CMT_ID_MTG1_DOC_NBR
			,mw.FMT_MTG1_Book_Page
			,mw.CMT_ID_MTG1_Book_Page
			,mw.ur_doc_id AS MTG1_UR_Doc_Id
			,mw.ORIG_MTG1_Lender_Name     
			,mw.NMLSLenderName_1      
			,mw.NMLSLenderId_1      
			,mw.NMLSBrokerName_1      
			,mw.NMLSBrokerId_1      
			,mw.NMLSAgentName_1      
			,mw.NMLSAgentId_1 
			,mw.Mtg1_Int_Source
		FROM [lien_DTDB].[infc].[DeedMtg2] d
		OUTER APPLY (
			SELECT mw1.*
			FROM [lien_DTDB].[INFC].[UR_MErge_rep] t
			OUTER APPLY (
				SELECT *
				FROM [lien_DTDB].[infc].[DeedMtg2] mw
				WHERE mw.id = t.trust_id
				) mw1
			WHERE t.Deed_Deed = d.id
			) mw
		OUTER APPLY (
			SELECT CASE 
					WHEN mw.MTG1_DETAILED_DOC_TYPE = 'VR'
						THEN left('Z' + isnull(mw.MTG1_DOC_NBR, '') + isnull(mw.MTG1_RECORDING_BOOK, '') + isnull(mw.MTG1_RECORDING_PAGE, '') + right('000000000000000', 15) + '0000000000000000000000000000000000000000', 40)
					ELSE left('A' + right(try_cast((isnull(mw.MTG1_MTG_AMOUNT, 1.00) - 99999999999.99) AS VARCHAR), 15) + '0000000000000000000000000000000000000000', 40)
					END AS _sort
			) ms
		WHERE d.id IN (
				SELECT DISTINCT Deed_Deed
				FROM [lien_DTDB].[INFC].[UR_MErge_rep]
				)
			AND d._DeedMtg = 'D'
			AND mw.DeedID IS NOT NULL
		) k

	----SELECT 'UR_Deedwrk ' AS _UR_Deedwrk
	----	,*
	----FROM lien_DTDB.INFC.Deed_work
	----WHERE /*Deedid = 7818*/ ref_id = 239041263
	----	AND RECORDING_DATE = '20220727'
	----SELECT 'UR_Mortgagewrk' AS _UR_Mortgagewrk
	----	,*
	----FROM lien_DTDB.INFC.Mortgage_work
	----WHERE ref_id = 239041263
	----	AND RECORDING_DATE = '20220727'
	----SELECT 'DeedMtg2' AS _DeedMtg2
	----	,*
	----FROM lien_DTDB.infc.DeedMtg2
	----WHERE ref_id = 239041263
	----	AND RECORDING_DATE = '20220727' --id in (3136,3137, 3138, 3139)
	----SELECT 'lien_DTDB.INFC.UR_MErge_rep' AS _lien_DTDB.INFC.UR_MErge_rep
	----	,*
	----FROM lien_DTDB.INFC.UR_MErge_rep
	----WHERE ref_id = 239041263
	----	AND RECORDING_DATE = '20220727' --Deed_Deed = 3136
	----SELECT 'UR_Deed_Mortgage_Link' AS _UR_Deed_Mortgage_Link
	----	,*
	----FROM lien_DTDB.INFC.UR_Deed_Mortgage_Link
	----WHERE fips = 27053
	----	AND Ref_ID_D = 239041263
	/* delete duplicate mtgs 
	how do we make sure we get the latestone here meaning we have a change on a mortgage on LIEN db and then we need to replace the on on Deed db
	*/
	DELETE a
	FROM (
		SELECT *
			,row_number() OVER (
				PARTITION BY DeedID_D
				,MTG1_MTG_AMOUNT_M
				,MTG1_RECORDING_DATE_M
				,MTG1_DOC_NBR_M
				,MTG1_RECORDING_BOOK_M
				,MTG1_RECORDING_PAGE_M ORDER BY DeedID_D
					,rn
				) AS dup_rnk
		FROM [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link]
		) AS a
	WHERE dup_rnk > 1

	--
	--reset mtg columns on Deedwrk
	--
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.MTG1_RECORDING_DATE = NULL
		,d.MTG1_DOC_DATE = NULL
		,d.MTG1_DOC_NBR = NULL
		,d.MTG1_RECORDING_BOOK = NULL
		,d.MTG1_RECORDING_PAGE = NULL
		,d.MTG1_DETAILED_DOC_TYPE = NULL
		,d.MTG1_MTG_AMOUNT = NULL
		,d.MTG1_LENDER_LAST_NAME = NULL
		,d.MTG1_LENDER_FIRST_NAME = NULL
		,d.MTG1_LENDER_ADDRESS = NULL
		,d.MTG1_LENDER_CITY = NULL
		,d.MTG1_LENDER_STATE = NULL
		,d.MTG1_LENDER_ZIP = NULL
		,d.MTG1_MTG_COMPANY_CODE = NULL
		,d.MTG1_MTG_LOAN_TYPE_CODE = NULL
		,d.MTG1_MTG_TERM_CODE = NULL
		,d.MTG1_MTG_TERM_ = NULL
		,d.MTG1_MTG_DUE_DATE = NULL
		,d.MTG1_MTG_INTEREST_RATE_TYPE = NULL
		,d.MTG1_MTG_INTEREST_RATE = NULL
		,d.MTG1_SELLER_CARRY_BACK = NULL
		,d.MTG1_PRIVATE_PARTY_LENDER = NULL
		,d.MTG1_CONSTRUCTION_LOAN = NULL
		,d.MTG1_REFI_FLAG = NULL
		,d.MTG1_EQUITY_FLAG = NULL
		,d.MTG1_OTHER_SUBORDINATE_LOANS = NULL
		,d.FMT_MTG1_DOC_NBR = NULL
		,d.CMT_ID_MTG1_DOC_NBR = NULL
		,d.FMT_MTG1_Book_Page = NULL
		,d.CMT_ID_MTG1_Book_Page = NULL
		,d.MTG1_UR_Doc_Id = NULL
		,d.MTG2_RECORDING_DATE = NULL
		,d.MTG2_DOC_DATE = NULL
		,d.MTG2_DOC_NBR = NULL
		,d.MTG2_RECORDING_BOOK = NULL
		,d.MTG2_RECORDING_PAGE = NULL
		,d.MTG2_DETAILED_DOC_TYPE = NULL
		,d.MTG2_MTG_AMOUNT = NULL
		,d.MTG2_LENDER_LAST_NAME = NULL
		,d.MTG2_LENDER_FIRST_NAME = NULL
		,d.MTG2_LENDER_ADDRESS = NULL
		,d.MTG2_LENDER_CITY = NULL
		,d.MTG2_LENDER_STATE = NULL
		,d.MTG2_LENDER_ZIP = NULL
		,d.MTG2_MTG_COMPANY_CODE = NULL
		,d.MTG2_MTG_LOAN_TYPE_CODE = NULL
		,d.MTG2_MTG_TERM_CODE = NULL
		,d.MTG2_MTG_TERM = NULL
		,d.MTG2_MTG_DUE_DATE = NULL
		,d.MTG2_MTG_INTEREST_RATE_TYPE = NULL
		,d.MTG2_MTG_INTEREST_RATE = NULL
		,d.MTG2_SELLER_CARRY_BACK = NULL
		,d.MTG2_PRIVATE_PARTY_LENDER = NULL
		,d.MTG2_CONSTRUCTION_LOAN = NULL
		,d.MTG2_REFI_FLAG = NULL
		,d.MTG2_EQUITY_FLAG = NULL
		,d.MTG2_OTHER_SUBORDINATE_LOANS = NULL
		,d.FMT_MTG2_DOC_NBR = NULL
		,d.CMT_ID_MTG2_DOC_NBR = NULL
		,d.FMT_MTG2_Book_Page = NULL
		,d.CMT_ID_MTG2_Book_Page = NULL
		,d.MTG2_UR_Doc_Id = NULL
		,d.MTG3_RECORDING_DATE = NULL
		,d.MTG3_DOC_DATE = NULL
		,d.MTG3_DOC_NBR = NULL
		,d.MTG3_RECORDING_BOOK = NULL
		,d.MTG3_RECORDING_PAGE = NULL
		,d.MTG3_DETAILED_DOC_TYPE = NULL
		,d.MTG3_MTG_AMOUNT = NULL
		,d.MTG3_LENDER_LAST_NAME = NULL
		,d.MTG3_LENDER_FIRST_NAME = NULL
		,d.MTG3_LENDER_ADDRESS = NULL
		,d.MTG3_LENDER_CITY = NULL
		,d.MTG3_LENDER_STATE = NULL
		,d.MTG3_LENDER_ZIP = NULL
		,d.MTG3_MTG_COMPANY_CODE = NULL
		,d.MTG3_MTG_LOAN_TYPE_CODE = NULL
		,d.MTG3_MTG_TERM_CODE = NULL
		,d.MTG3_MTG_TERM = NULL
		,d.MTG3_MTG_DUE_DATE = NULL
		,d.MTG3_MTG_INTEREST_RATE_TYPE = NULL
		,d.MTG3_MTG_INTEREST_RATE = NULL
		,d.MTG3_SELLER_CARRY_BACK = NULL
		,d.MTG3_PRIVATE_PARTY_LENDER = NULL
		,d.MTG3_CONSTRUCTION_LOAN = NULL
		,d.MTG3_REFI_FLAG = NULL
		,d.MTG3_EQUITY_FLAG = NULL
		,d.MTG3_OTHER_SUBORDINATE_LOANS = NULL
		,d.FMT_MTG3_DOC_NBR = NULL
		,d.CMT_ID_MTG3_DOC_NBR = NULL
		,d.FMT_MTG3_Book_Page = NULL
		,d.CMT_ID_MTG3_Book_Page = NULL
		,d.MTG3_UR_Doc_Id = NULL
		,d.MTG4_RECORDING_DATE = NULL
		,d.MTG4_DOC_DATE = NULL
		,d.MTG4_DOC_NBR = NULL
		,d.MTG4_RECORDING_BOOK = NULL
		,d.MTG4_RECORDING_PAGE = NULL
		,d.MTG4_DETAILED_DOC_TYPE = NULL
		,d.MTG4_MTG_AMOUNT = NULL
		,d.MTG4_LENDER_LAST_NAME = NULL
		,d.MTG4_LENDER_FIRST_NAME = NULL
		,d.MTG4_LENDER_ADDRESS = NULL
		,d.MTG4_LENDER_CITY = NULL
		,d.MTG4_LENDER_STATE = NULL
		,d.MTG4_LENDER_ZIP = NULL
		,d.MTG4_MTG_COMPANY_CODE = NULL
		,d.MTG4_MTG_LOAN_TYPE_CODE = NULL
		,d.MTG4_MTG_TERM_CODE = NULL
		,d.MTG4_MTG_TERM = NULL
		,d.MTG4_MTG_DUE_DATE = NULL
		,d.MTG4_MTG_INTEREST_RATE_TYPE = NULL
		,d.MTG4_MTG_INTEREST_RATE = NULL
		,d.MTG4_SELLER_CARRY_BACK = NULL
		,d.MTG4_PRIVATE_PARTY_LENDER = NULL
		,d.MTG4_CONSTRUCTION_LOAN = NULL
		,d.MTG4_REFI_FLAG = NULL
		,d.MTG4_EQUITY_FLAG = NULL
		,d.MTG4_OTHER_SUBORDINATE_LOANS = NULL
		,d.FMT_MTG4_DOC_NBR = NULL
		,d.CMT_ID_MTG4_DOC_NBR = NULL
		,d.FMT_MTG4_Book_Page = NULL
		,d.CMT_ID_MTG4_Book_Page = NULL
		,d.MTG4_UR_Doc_Id = NULL   
		,d.[ORIG_MTG1_Lender_Name]   = NULL    
		,d.[ORIG_MTG2_Lender_Name]   = NULL    
		,d.[ORIG_MTG3_Lender_Name]   = NULL    
		,d.[ORIG_MTG4_Lender_Name]   = NULL    
		,d.[NMLSLenderName_1]    = NULL    
		,d.[NMLSLenderId_1]    = NULL    
		,d.[NMLSBrokerName_1]    = NULL    
		,d.[NMLSBrokerId_1]    = NULL    
		,d.[NMLSAgentName_1]    = NULL    
		,d.[NMLSAgentId_1]    = NULL    
		,d.[NMLSLenderName_2]    = NULL    
		,d.[NMLSLenderId_2]    = NULL    
		,d.[NMLSBrokerName_2]    = NULL    
		,d.[NMLSBrokerId_2]    = NULL    
		,d.[NMLSAgentName_2]    = NULL    
		,d.[NMLSAgentId_2]    = NULL    
		,d.[NMLSLenderName_3]    = NULL    
		,d.[NMLSLenderId_3]    = NULL    
		,d.[NMLSBrokerName_3]    = NULL    
		,d.[NMLSBrokerId_3]    = NULL    
		,d.[NMLSAgentName_3]    = NULL    
		,d.[NMLSAgentId_3]    = NULL    
		,d.[NMLSLenderName_4]    = NULL    
		,d.[NMLSLenderId_4]    = NULL    
		,d.[NMLSBrokerName_4]    = NULL    
		,d.[NMLSBrokerId_4]    = NULL    
		,d.[NMLSAgentName_4]    = NULL    
		,d.[NMLSAgentId_4]    = NULL
		,d.Mtg1_Int_Source = NULL
		,d.Mtg2_Int_Source = NULL
		,d.Mtg3_Int_Source = NULL
		,d.Mtg4_Int_Source = NULL
	FROM [lien_DTDB].[INFC].[Deed_work] d

	--
	--
	--
	----UPDATE ml
	----SET ml.rn = dw1.mtg_cnt + ml.rn
	----FROM lien_DTDB.INFC.UR_Deed_Mortgage_Link ml WITH (INDEX (ixa_Deedid))
	----INNER JOIN lien_DTDB.INFC.Deed_work dw /*WITH (INDEX (IDX_Unique_DeedID1))*/ ON dw.DeedID = ml.DeedID_D
	----OUTER APPLY (
	----	SELECT CASE 
	----			WHEN isnull(dw.MTG1_RECORDING_DATE, '') > ''
	----				THEN 1
	----			ELSE 0
	----			END + CASE 
	----			WHEN isnull(dw.MTG2_RECORDING_DATE, '') > ''
	----				THEN 1
	----			ELSE 0
	----			END + CASE 
	----			WHEN isnull(dw.MTG3_RECORDING_DATE, '') > ''
	----				THEN 1
	----			ELSE 0
	----			END + CASE 
	----			WHEN isnull(dw.MTG4_RECORDING_DATE, '') > ''
	----				THEN 1
	----			ELSE 0
	----			END AS mtg_cnt
	----	) dw1
	----WHERE dw.fips = ml.fips
	--ORDER BY DeedID_D
	--Calculating Rank for the Mortgage
	/* LINK MTG1 TO Deed RECORDS */
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.SITUS_HOUSE_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR
			ELSE l.SITUS_HOUSE_NBR
			END
		,d.SITUS_HOUSE_NBR2 = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR2
			ELSE l.SITUS_HOUSE_NBR2
			END
		,d.SITUS_HOUSE_NBR_SUFFIX = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR_SUFFIX
			ELSE l.SITUS_HOUSE_NBR_SUFFIX
			END
		,d.SITUS_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_DIRECTION
			ELSE l.SITUS_DIRECTION
			END
		,d.SITUS_STREET_NAME = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STREET_NAME
			ELSE l.SITUS_STREET_NAME
			END
		,d.SITUS_MODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_MODE
			ELSE l.SITUS_MODE
			END
		,d.SITUS_POST_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_POST_DIRECTION
			ELSE l.SITUS_POST_DIRECTION
			END
		,d.SITUS_UNIT_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_UNIT_NBR
			ELSE l.SITUS_UNIT_NBR
			END
		,d.SITUS_CITY = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CITY
			ELSE l.SITUS_CITY
			END
		,d.SITUS_STATE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STATE
			ELSE l.SITUS_STATE
			END
		,d.SITUS_ZIP_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_ZIP_CODE
			ELSE l.SITUS_ZIP_CODE
			END
		,d.SITUS_CARRIER_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CARRIER_CODE
			ELSE l.SITUS_CARRIER_CODE
			END
		,d.ORIGINAL_SITE_ADDRESS = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.ORIGINAL_SITE_ADDRESS
			ELSE l.ORIGINAL_SITE_ADDRESS
			END
		,d.MTG1_RECORDING_DATE = l.MTG1_RECORDING_DATE_M
		,d.MTG1_DOC_DATE = l.MTG1_DOC_DATE_M
		,d.MTG1_DOC_NBR = l.MTG1_DOC_NBR_M
		,d.MTG1_RECORDING_BOOK = l.MTG1_RECORDING_BOOK_M
		,d.MTG1_RECORDING_PAGE = l.MTG1_RECORDING_PAGE_M
		,d.MTG1_DETAILED_DOC_TYPE = l.MTG1_DETAILED_DOC_TYPE_M
		,d.MTG1_MTG_AMOUNT = l.MTG1_MTG_AMOUNT_M
		,d.MTG1_LENDER_LAST_NAME = l.MTG1_LENDER_LAST_NAME_M
		,d.MTG1_LENDER_FIRST_NAME = l.MTG1_LENDER_FIRST_NAME_M
		,d.MTG1_LENDER_ADDRESS = l.MTG1_LENDER_ADDRESS_M
		,d.MTG1_LENDER_CITY = l.MTG1_LENDER_CITY_M
		,d.MTG1_LENDER_STATE = l.MTG1_LENDER_STATE_M
		,d.MTG1_LENDER_ZIP = l.MTG1_LENDER_ZIP_M
		,d.MTG1_MTG_COMPANY_CODE = l.MTG1_MTG_COMPANY_CODE_M
		,d.MTG1_MTG_LOAN_TYPE_CODE = l.MTG1_MTG_LOAN_TYPE_CODE_M
		,d.MTG1_MTG_TERM_CODE = l.MTG1_MTG_TERM_CODE_M
		,d.MTG1_MTG_TERM_ = l.MTG1_MTG_TERM_M
		,d.MTG1_MTG_DUE_DATE = l.MTG1_MTG_DUE_DATE_M
		,d.MTG1_MTG_INTEREST_RATE_TYPE = l.MTG1_MTG_INTEREST_RATE_TYPE_M
		,d.MTG1_MTG_INTEREST_RATE = l.MTG1_MTG_INTEREST_RATE_M
		,d.MTG1_SELLER_CARRY_BACK = l.MTG1_SELLER_CARRY_BACK_M
		,d.MTG1_PRIVATE_PARTY_LENDER = l.MTG1_PRIVATE_PARTY_LENDER_M
		,d.MTG1_CONSTRUCTION_LOAN = l.MTG1_CONSTRUCTION_LOAN_M
		,d.MTG1_REFI_FLAG = l.MTG1_REFI_FLAG_M
		,d.MTG1_EQUITY_FLAG = l.MTG1_EQUITY_FLAG_M
		,d.MTG1_OTHER_SUBORDINATE_LOANS = l.MTG1_OTHER_SUBORDINATE_LOANS_M
		,d.FMT_MTG1_DOC_NBR = l.FMT_MTG1_DOC_NBR_M
		,d.CMT_ID_MTG1_DOC_NBR = l.CMT_ID_MTG1_DOC_NBR_M
		,d.FMT_MTG1_Book_Page = l.FMT_MTG1_Book_Page_M
		,d.CMT_ID_MTG1_Book_Page = l.CMT_ID_MTG1_Book_Page_M
		,d.MTG1_UR_Doc_Id = l.MTG_UR_Doc_Id
		,d.ORIG_MTG1_Lender_Name = l.ORIG_MTG1_Lender_Name     
		,d.NMLSLenderName_1   = l.NMLSLenderName_1      
		,d.NMLSLenderId_1   = l.NMLSLenderId_1      
		,d.NMLSBrokerName_1   = l.NMLSBrokerName_1      
		,d.NMLSBrokerId_1   = l.NMLSBrokerId_1      
		,d.NMLSAgentName_1   = l.NMLSAgentName_1      
		,d.NMLSAgentId_1   = l.NMLSAgentId_1  
		,d.Attorney_Email = n.Attorney_Email
		,d.Attorney_Firm_Name = n.Attorney_Firm_Name
		,d.Mtg1_Int_Source = l.Mtg1_Int_Source
		,d.TITLE_COMPANY_NAME = n.new_TITLE_COMPANY_NAME
		,d.Attorney_Name_identifier = n2.Attorney_Name_identifier
		,d.Attorney_Last_Name = n2.Attorney_Last_Name
		,d.Attorney_First_Name = n2.Attorney_First_Name
		,d.Attorney_Middle_Initial = n2.Attorney_Middle_Initial
		,d.Attorney_suffix = n2.Attorney_suffix
		,d.Attorney_address = n2.Attorney_address
		,d.Attorney_Address_City = n2.Attorney_Address_City
		,d.Attorney_Address_State = n2.Attorney_Address_State
		,d.Attorney_Address_Zip = n2.Attorney_Address_Zip
		,d.Attorney_Phone = n2.Attorney_Phone
		,d.Attorney_Full_Name = n2.Attorney_Full_Name
	--  select L.*
	/* 
    select * from lien_DTDB.INFC.Deed_work 
   select * from lien_DTDB.INFC.UR_Deed_Mortgage_Link
   select * from lien_dtdb.tmp.UR_Merge_Deed_To_Mtg_New_temp
  
   */
	FROM [lien_DTDB].[INFC].[Deed_work] d
	INNER JOIN [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link] l ON d.fips = l.fips
		AND d.DeedID = l.DeedID_D
	OUTER APPLY (
		SELECT CASE 
				WHEN replace(isnull(d.SITUS_HOUSE_NBR, '') + isnull(d.SITUS_DIRECTION, '') + isnull(d.SITUS_STREET_NAME, '') + isnull(d.SITUS_MODE, '') + isnull(d.SITUS_POST_DIRECTION, '') + isnull(d.SITUS_CITY, '') + isnull(d.SITUS_STATE, '') + isnull(d.SITUS_ZIP_CODE, '') + isnull(d.SITUS_CARRIER_CODE, ''), ' ', '') > ''
					THEN 1
				ELSE 0
				END _use_deed_situs
		) b
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] m WITH (
				NOLOCK
				,INDEX (idx_deedid)
				)
		WHERE m.deedid = l.DeedID_m
			AND m._DeedMtg = 't'
		) m
	OUTER APPLY (
		SELECT CASE 
				WHEN d.TITLE_COMPANY_NAME IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME NOT IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME > ''
					THEN m.TITLE_COMPANY_NAME
				ELSE d.TITLE_COMPANY_NAME
				END AS new_TITLE_COMPANY_NAME
			,CASE 
				WHEN isnull(d.Attorney_Last_Name, '') = ''
					AND isnull(m.Attorney_Last_Name, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg
			,CASE 
				WHEN isnull(d.Attorney_address, '') = ''
					AND isnull(m.Attorney_address, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg_addr
			,CASE 
				WHEN isnull(d.attorney_firm_name, '') > ''
					THEN d.attorney_firm_name
				ELSE m.attorney_firm_name
				END AS attorney_firm_name
			,CASE 
				WHEN isnull(d.Attorney_Email, '') > ''
					THEN d.Attorney_Email
				ELSE m.Attorney_Email
				END AS Attorney_Email
		) n
	OUTER APPLY (
		SELECT CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Name_identifier
				ELSE m.Attorney_Name_identifier
				END AS Attorney_Name_identifier
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Last_Name
				ELSE m.Attorney_Last_Name
				END AS Attorney_Last_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_First_Name
				ELSE m.Attorney_First_Name
				END AS Attorney_First_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Middle_Initial
				ELSE m.Attorney_Middle_Initial
				END AS Attorney_Middle_Initial
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_suffix
				ELSE m.Attorney_suffix
				END AS Attorney_suffix
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_address
				ELSE m.Attorney_address
				END AS Attorney_address
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_City
				ELSE m.Attorney_Address_City
				END AS Attorney_Address_City
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_State
				ELSE m.Attorney_Address_State
				END AS Attorney_Address_State
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_Zip
				ELSE m.Attorney_Address_Zip
				END AS Attorney_Address_Zip
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Phone
				ELSE m.Attorney_Phone
				END AS Attorney_Phone
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Full_Name
				ELSE m.Attorney_Full_Name
				END AS Attorney_Full_Name
		) n2
	WHERE l.rn = 1

	/* SET FLAG IN MTG TABLE */
	--update m
	--set m.link='M1'
	--from 
	--lien_DTDB.INFC.Mortgage_work m
	--inner join
	--lien_DTDB.INFC.UR_Deed_Mortgage_Link l
	--on m.fips=l.fips
	--and m.DeedID=l.DeedID_M
	--where l.rn=1
	/* LINK MTG2 TO Deed RECORDS */
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.SITUS_HOUSE_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR
			ELSE l.SITUS_HOUSE_NBR
			END
		,d.SITUS_HOUSE_NBR2 = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR2
			ELSE l.SITUS_HOUSE_NBR2
			END
		,d.SITUS_HOUSE_NBR_SUFFIX = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR_SUFFIX
			ELSE l.SITUS_HOUSE_NBR_SUFFIX
			END
		,d.SITUS_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_DIRECTION
			ELSE l.SITUS_DIRECTION
			END
		,d.SITUS_STREET_NAME = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STREET_NAME
			ELSE l.SITUS_STREET_NAME
			END
		,d.SITUS_MODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_MODE
			ELSE l.SITUS_MODE
			END
		,d.SITUS_POST_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_POST_DIRECTION
			ELSE l.SITUS_POST_DIRECTION
			END
		,d.SITUS_UNIT_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_UNIT_NBR
			ELSE l.SITUS_UNIT_NBR
			END
		,d.SITUS_CITY = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CITY
			ELSE l.SITUS_CITY
			END
		,d.SITUS_STATE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STATE
			ELSE l.SITUS_STATE
			END
		,d.SITUS_ZIP_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_ZIP_CODE
			ELSE l.SITUS_ZIP_CODE
			END
		,d.SITUS_CARRIER_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CARRIER_CODE
			ELSE l.SITUS_CARRIER_CODE
			END
		,d.ORIGINAL_SITE_ADDRESS = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.ORIGINAL_SITE_ADDRESS
			ELSE l.ORIGINAL_SITE_ADDRESS
			END
		,d.MTG2_RECORDING_DATE = l.MTG1_RECORDING_DATE_M
		,d.MTG2_DOC_DATE = l.MTG1_DOC_DATE_M
		,d.MTG2_DOC_NBR = l.MTG1_DOC_NBR_M
		,d.MTG2_RECORDING_BOOK = l.MTG1_RECORDING_BOOK_M
		,d.MTG2_RECORDING_PAGE = l.MTG1_RECORDING_PAGE_M
		,d.MTG2_DETAILED_DOC_TYPE = l.MTG1_DETAILED_DOC_TYPE_M
		,d.MTG2_MTG_AMOUNT = l.MTG1_MTG_AMOUNT_M
		,d.MTG2_LENDER_LAST_NAME = l.MTG1_LENDER_LAST_NAME_M
		,d.MTG2_LENDER_FIRST_NAME = l.MTG1_LENDER_FIRST_NAME_M
		,d.MTG2_LENDER_ADDRESS = l.MTG1_LENDER_ADDRESS_M
		,d.MTG2_LENDER_CITY = l.MTG1_LENDER_CITY_M
		,d.MTG2_LENDER_STATE = l.MTG1_LENDER_STATE_M
		,d.MTG2_LENDER_ZIP = l.MTG1_LENDER_ZIP_M
		,d.MTG2_MTG_COMPANY_CODE = l.MTG1_MTG_COMPANY_CODE_M
		,d.MTG2_MTG_LOAN_TYPE_CODE = l.MTG1_MTG_LOAN_TYPE_CODE_M
		,d.MTG2_MTG_TERM_CODE = l.MTG1_MTG_TERM_CODE_M
		,d.MTG2_MTG_TERM = l.MTG1_MTG_TERM_M
		,d.MTG2_MTG_DUE_DATE = l.MTG1_MTG_DUE_DATE_M
		,d.MTG2_MTG_INTEREST_RATE_TYPE = l.MTG1_MTG_INTEREST_RATE_TYPE_M
		,d.MTG2_MTG_INTEREST_RATE = l.MTG1_MTG_INTEREST_RATE_M
		,d.MTG2_SELLER_CARRY_BACK = l.MTG1_SELLER_CARRY_BACK_M
		,d.MTG2_PRIVATE_PARTY_LENDER = l.MTG1_PRIVATE_PARTY_LENDER_M
		,d.MTG2_CONSTRUCTION_LOAN = l.MTG1_CONSTRUCTION_LOAN_M
		,d.MTG2_REFI_FLAG = l.MTG1_REFI_FLAG_M
		,d.MTG2_EQUITY_FLAG = l.MTG1_EQUITY_FLAG_M
		,d.MTG2_OTHER_SUBORDINATE_LOANS = l.MTG1_OTHER_SUBORDINATE_LOANS_M
		,d.FMT_MTG2_DOC_NBR = l.FMT_MTG1_DOC_NBR_M
		,d.CMT_ID_MTG2_DOC_NBR = l.CMT_ID_MTG1_DOC_NBR_M
		,d.FMT_MTG2_Book_Page = l.FMT_MTG1_Book_Page_M
		,d.CMT_ID_MTG2_Book_Page = l.CMT_ID_MTG1_Book_Page_M
		,d.MTG2_UR_Doc_Id = l.MTG_UR_Doc_Id
		,d.ORIG_MTG2_Lender_Name = l.ORIG_MTG1_Lender_Name     
		,d.NMLSLenderName_2   = l.NMLSLenderName_1      
		,d.NMLSLenderId_2   = l.NMLSLenderId_1      
		,d.NMLSBrokerName_2   = l.NMLSBrokerName_1      
		,d.NMLSBrokerId_2   = l.NMLSBrokerId_1      
		,d.NMLSAgentName_2   = l.NMLSAgentName_1      
		,d.NMLSAgentId_2   = l.NMLSAgentId_1  
		,d.Attorney_Email = n.Attorney_Email
		,d.Attorney_Firm_Name = n.Attorney_Firm_Name
		,d.Mtg2_Int_Source = l.Mtg1_Int_Source
		,d.TITLE_COMPANY_NAME = n.new_TITLE_COMPANY_NAME
		,d.Attorney_Name_identifier = n2.Attorney_Name_identifier
		,d.Attorney_Last_Name = n2.Attorney_Last_Name
		,d.Attorney_First_Name = n2.Attorney_First_Name
		,d.Attorney_Middle_Initial = n2.Attorney_Middle_Initial
		,d.Attorney_suffix = n2.Attorney_suffix
		,d.Attorney_address = n2.Attorney_address
		,d.Attorney_Address_City = n2.Attorney_Address_City
		,d.Attorney_Address_State = n2.Attorney_Address_State
		,d.Attorney_Address_Zip = n2.Attorney_Address_Zip
		,d.Attorney_Phone = n2.Attorney_Phone
		,d.Attorney_Full_Name = n2.Attorney_Full_Name
	-- select n.new_TITLE_COMPANY_NAME
	FROM [lien_DTDB].[INFC].[Deed_work] d
	INNER JOIN [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link] l ON d.fips = l.fips
		AND d.DeedID = l.DeedID_D
	OUTER APPLY (
		SELECT CASE 
				WHEN replace(isnull(d.SITUS_HOUSE_NBR, '') + isnull(d.SITUS_DIRECTION, '') + isnull(d.SITUS_STREET_NAME, '') + isnull(d.SITUS_MODE, '') + isnull(d.SITUS_POST_DIRECTION, '') + isnull(d.SITUS_CITY, '') + isnull(d.SITUS_STATE, '') + isnull(d.SITUS_ZIP_CODE, '') + isnull(d.SITUS_CARRIER_CODE, ''), ' ', '') > ''
					THEN 1
				ELSE 0
				END _use_deed_situs
		) b
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] m WITH (
				NOLOCK
				,INDEX (idx_deedid)
				)
		WHERE m.deedid = l.DeedID_m
			AND m._DeedMtg = 't'
		) m
	OUTER APPLY (
		SELECT CASE 
				WHEN d.TITLE_COMPANY_NAME IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME NOT IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME > ''
					THEN m.TITLE_COMPANY_NAME
				ELSE d.TITLE_COMPANY_NAME
				END AS new_TITLE_COMPANY_NAME
			,CASE 
				WHEN isnull(d.Attorney_Last_Name, '') = ''
					AND isnull(m.Attorney_Last_Name, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg
			,CASE 
				WHEN isnull(d.Attorney_address, '') = ''
					AND isnull(m.Attorney_address, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg_addr
			,CASE 
				WHEN isnull(d.attorney_firm_name, '') > ''
					THEN d.attorney_firm_name
				ELSE m.attorney_firm_name
				END AS attorney_firm_name
			,CASE 
				WHEN isnull(d.Attorney_Email, '') > ''
					THEN d.Attorney_Email
				ELSE m.Attorney_Email
				END AS Attorney_Email
		) n
	OUTER APPLY (
		SELECT CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Name_identifier
				ELSE m.Attorney_Name_identifier
				END AS Attorney_Name_identifier
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Last_Name
				ELSE m.Attorney_Last_Name
				END AS Attorney_Last_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_First_Name
				ELSE m.Attorney_First_Name
				END AS Attorney_First_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Middle_Initial
				ELSE m.Attorney_Middle_Initial
				END AS Attorney_Middle_Initial
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_suffix
				ELSE m.Attorney_suffix
				END AS Attorney_suffix
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_address
				ELSE m.Attorney_address
				END AS Attorney_address
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_City
				ELSE m.Attorney_Address_City
				END AS Attorney_Address_City
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_State
				ELSE m.Attorney_Address_State
				END AS Attorney_Address_State
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_Zip
				ELSE m.Attorney_Address_Zip
				END AS Attorney_Address_Zip
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Phone
				ELSE m.Attorney_Phone
				END AS Attorney_Phone
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Full_Name
				ELSE m.Attorney_Full_Name
				END AS Attorney_Full_Name
		) n2
	WHERE l.rn = 2

	/* SET FLAG IN MTG TABLE */
	--update m
	--set m.link='M2'
	--from 
	--lien_DTDB.INFC.Mortgage_work m
	--inner join
	--lien_DTDB.INFC.UR_Deed_Mortgage_Link l
	--on m.fips=l.fips
	--and m.DeedID=l.DeedID_M
	--where l.rn=2
	/* LINK MTG3 TO Deed RECORDS */
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.SITUS_HOUSE_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR
			ELSE l.SITUS_HOUSE_NBR
			END
		,d.SITUS_HOUSE_NBR2 = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR2
			ELSE l.SITUS_HOUSE_NBR2
			END
		,d.SITUS_HOUSE_NBR_SUFFIX = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR_SUFFIX
			ELSE l.SITUS_HOUSE_NBR_SUFFIX
			END
		,d.SITUS_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_DIRECTION
			ELSE l.SITUS_DIRECTION
			END
		,d.SITUS_STREET_NAME = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STREET_NAME
			ELSE l.SITUS_STREET_NAME
			END
		,d.SITUS_MODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_MODE
			ELSE l.SITUS_MODE
			END
		,d.SITUS_POST_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_POST_DIRECTION
			ELSE l.SITUS_POST_DIRECTION
			END
		,d.SITUS_UNIT_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_UNIT_NBR
			ELSE l.SITUS_UNIT_NBR
			END
		,d.SITUS_CITY = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CITY
			ELSE l.SITUS_CITY
			END
		,d.SITUS_STATE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STATE
			ELSE l.SITUS_STATE
			END
		,d.SITUS_ZIP_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_ZIP_CODE
			ELSE l.SITUS_ZIP_CODE
			END
		,d.SITUS_CARRIER_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CARRIER_CODE
			ELSE l.SITUS_CARRIER_CODE
			END
		,d.ORIGINAL_SITE_ADDRESS = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.ORIGINAL_SITE_ADDRESS
			ELSE l.ORIGINAL_SITE_ADDRESS
			END
		,d.MTG3_RECORDING_DATE = l.MTG1_RECORDING_DATE_M
		,d.MTG3_DOC_DATE = l.MTG1_DOC_DATE_M
		,d.MTG3_DOC_NBR = l.MTG1_DOC_NBR_M
		,d.MTG3_RECORDING_BOOK = l.MTG1_RECORDING_BOOK_M
		,d.MTG3_RECORDING_PAGE = l.MTG1_RECORDING_PAGE_M
		,d.MTG3_DETAILED_DOC_TYPE = l.MTG1_DETAILED_DOC_TYPE_M
		,d.MTG3_MTG_AMOUNT = l.MTG1_MTG_AMOUNT_M
		,d.MTG3_LENDER_LAST_NAME = l.MTG1_LENDER_LAST_NAME_M
		,d.MTG3_LENDER_FIRST_NAME = l.MTG1_LENDER_FIRST_NAME_M
		,d.MTG3_LENDER_ADDRESS = l.MTG1_LENDER_ADDRESS_M
		,d.MTG3_LENDER_CITY = l.MTG1_LENDER_CITY_M
		,d.MTG3_LENDER_STATE = l.MTG1_LENDER_STATE_M
		,d.MTG3_LENDER_ZIP = l.MTG1_LENDER_ZIP_M
		,d.MTG3_MTG_COMPANY_CODE = l.MTG1_MTG_COMPANY_CODE_M
		,d.MTG3_MTG_LOAN_TYPE_CODE = l.MTG1_MTG_LOAN_TYPE_CODE_M
		,d.MTG3_MTG_TERM_CODE = l.MTG1_MTG_TERM_CODE_M
		,d.MTG3_MTG_TERM = l.MTG1_MTG_TERM_M
		,d.MTG3_MTG_DUE_DATE = l.MTG1_MTG_DUE_DATE_M
		,d.MTG3_MTG_INTEREST_RATE_TYPE = l.MTG1_MTG_INTEREST_RATE_TYPE_M
		,d.MTG3_MTG_INTEREST_RATE = l.MTG1_MTG_INTEREST_RATE_M
		,d.MTG3_SELLER_CARRY_BACK = l.MTG1_SELLER_CARRY_BACK_M
		,d.MTG3_PRIVATE_PARTY_LENDER = l.MTG1_PRIVATE_PARTY_LENDER_M
		,d.MTG3_CONSTRUCTION_LOAN = l.MTG1_CONSTRUCTION_LOAN_M
		,d.MTG3_REFI_FLAG = l.MTG1_REFI_FLAG_M
		,d.MTG3_EQUITY_FLAG = l.MTG1_EQUITY_FLAG_M
		,d.MTG3_OTHER_SUBORDINATE_LOANS = l.MTG1_OTHER_SUBORDINATE_LOANS_M
		,d.FMT_MTG3_DOC_NBR = l.FMT_MTG1_DOC_NBR_M
		,d.CMT_ID_MTG3_DOC_NBR = l.CMT_ID_MTG1_DOC_NBR_M
		,d.FMT_MTG3_Book_Page = l.FMT_MTG1_Book_Page_M
		,d.CMT_ID_MTG3_Book_Page = l.CMT_ID_MTG1_Book_Page_M
		,d.MTG3_UR_Doc_Id = l.MTG_UR_Doc_Id
		,d.ORIG_MTG3_Lender_Name = l.ORIG_MTG1_Lender_Name     
		,d.NMLSLenderName_3   = l.NMLSLenderName_1      
		,d.NMLSLenderId_3   = l.NMLSLenderId_1      
		,d.NMLSBrokerName_3   = l.NMLSBrokerName_1      
		,d.NMLSBrokerId_3   = l.NMLSBrokerId_1      
		,d.NMLSAgentName_3   = l.NMLSAgentName_1      
		,d.NMLSAgentId_3   = l.NMLSAgentId_1  
		,d.Attorney_Email = n.Attorney_Email
		,d.Attorney_Firm_Name = n.Attorney_Firm_Name
		,d.Mtg3_Int_Source = l.Mtg1_Int_Source
		,d.TITLE_COMPANY_NAME = n.new_TITLE_COMPANY_NAME
		,d.Attorney_Name_identifier = n2.Attorney_Name_identifier
		,d.Attorney_Last_Name = n2.Attorney_Last_Name
		,d.Attorney_First_Name = n2.Attorney_First_Name
		,d.Attorney_Middle_Initial = n2.Attorney_Middle_Initial
		,d.Attorney_suffix = n2.Attorney_suffix
		,d.Attorney_address = n2.Attorney_address
		,d.Attorney_Address_City = n2.Attorney_Address_City
		,d.Attorney_Address_State = n2.Attorney_Address_State
		,d.Attorney_Address_Zip = n2.Attorney_Address_Zip
		,d.Attorney_Phone = n2.Attorney_Phone
		,d.Attorney_Full_Name = n2.Attorney_Full_Name
	FROM [lien_DTDB].[INFC].[Deed_work] d
	INNER JOIN [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link] l ON d.fips = l.fips
		AND d.DeedID = l.DeedID_D
	OUTER APPLY (
		SELECT CASE 
				WHEN replace(isnull(d.SITUS_HOUSE_NBR, '') + isnull(d.SITUS_DIRECTION, '') + isnull(d.SITUS_STREET_NAME, '') + isnull(d.SITUS_MODE, '') + isnull(d.SITUS_POST_DIRECTION, '') + isnull(d.SITUS_CITY, '') + isnull(d.SITUS_STATE, '') + isnull(d.SITUS_ZIP_CODE, '') + isnull(d.SITUS_CARRIER_CODE, ''), ' ', '') > ''
					THEN 1
				ELSE 0
				END _use_deed_situs
		) b
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] m WITH (
				NOLOCK
				,INDEX (idx_deedid)
				)
		WHERE m.deedid = l.DeedID_m
			AND m._DeedMtg = 't'
		) m
	OUTER APPLY (
		SELECT CASE 
				WHEN d.TITLE_COMPANY_NAME IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME NOT IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME > ''
					THEN m.TITLE_COMPANY_NAME
				ELSE d.TITLE_COMPANY_NAME
				END AS new_TITLE_COMPANY_NAME
			,CASE 
				WHEN isnull(d.Attorney_Last_Name, '') = ''
					AND isnull(m.Attorney_Last_Name, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg
			,CASE 
				WHEN isnull(d.Attorney_address, '') = ''
					AND isnull(m.Attorney_address, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg_addr
			,CASE 
				WHEN isnull(d.attorney_firm_name, '') > ''
					THEN d.attorney_firm_name
				ELSE m.attorney_firm_name
				END AS attorney_firm_name
			,CASE 
				WHEN isnull(d.Attorney_Email, '') > ''
					THEN d.Attorney_Email
				ELSE m.Attorney_Email
				END AS Attorney_Email
		) n
	OUTER APPLY (
		SELECT CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Name_identifier
				ELSE m.Attorney_Name_identifier
				END AS Attorney_Name_identifier
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Last_Name
				ELSE m.Attorney_Last_Name
				END AS Attorney_Last_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_First_Name
				ELSE m.Attorney_First_Name
				END AS Attorney_First_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Middle_Initial
				ELSE m.Attorney_Middle_Initial
				END AS Attorney_Middle_Initial
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_suffix
				ELSE m.Attorney_suffix
				END AS Attorney_suffix
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_address
				ELSE m.Attorney_address
				END AS Attorney_address
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_City
				ELSE m.Attorney_Address_City
				END AS Attorney_Address_City
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_State
				ELSE m.Attorney_Address_State
				END AS Attorney_Address_State
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_Zip
				ELSE m.Attorney_Address_Zip
				END AS Attorney_Address_Zip
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Phone
				ELSE m.Attorney_Phone
				END AS Attorney_Phone
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Full_Name
				ELSE m.Attorney_Full_Name
				END AS Attorney_Full_Name
		) n2
	WHERE l.rn = 3

	/* SET FLAG IN MTG TABLE */
	--update m
	--set m.link='M3'
	--from 
	--lien_DTDB.INFC.Mortgage_work m
	--inner join
	--lien_DTDB.INFC.UR_Deed_Mortgage_Link l
	--on m.fips=l.fips
	--and m.DeedID=l.DeedID_M
	--where l.rn=3
	/* LINK MTG4 TO Deed RECORDS */
	UPDATE [lien_DTDB].[INFC].[d]
	SET d.SITUS_HOUSE_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR
			ELSE l.SITUS_HOUSE_NBR
			END
		,d.SITUS_HOUSE_NBR2 = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR2
			ELSE l.SITUS_HOUSE_NBR2
			END
		,d.SITUS_HOUSE_NBR_SUFFIX = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_HOUSE_NBR_SUFFIX
			ELSE l.SITUS_HOUSE_NBR_SUFFIX
			END
		,d.SITUS_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_DIRECTION
			ELSE l.SITUS_DIRECTION
			END
		,d.SITUS_STREET_NAME = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STREET_NAME
			ELSE l.SITUS_STREET_NAME
			END
		,d.SITUS_MODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_MODE
			ELSE l.SITUS_MODE
			END
		,d.SITUS_POST_DIRECTION = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_POST_DIRECTION
			ELSE l.SITUS_POST_DIRECTION
			END
		,d.SITUS_UNIT_NBR = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_UNIT_NBR
			ELSE l.SITUS_UNIT_NBR
			END
		,d.SITUS_CITY = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CITY
			ELSE l.SITUS_CITY
			END
		,d.SITUS_STATE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_STATE
			ELSE l.SITUS_STATE
			END
		,d.SITUS_ZIP_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_ZIP_CODE
			ELSE l.SITUS_ZIP_CODE
			END
		,d.SITUS_CARRIER_CODE = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.SITUS_CARRIER_CODE
			ELSE l.SITUS_CARRIER_CODE
			END
		,d.ORIGINAL_SITE_ADDRESS = CASE 
			WHEN b._use_deed_situs = 1
				THEN d.ORIGINAL_SITE_ADDRESS
			ELSE l.ORIGINAL_SITE_ADDRESS
			END
		,d.MTG4_RECORDING_DATE = l.MTG1_RECORDING_DATE_M
		,d.MTG4_DOC_DATE = l.MTG1_DOC_DATE_M
		,d.MTG4_DOC_NBR = l.MTG1_DOC_NBR_M
		,d.MTG4_RECORDING_BOOK = l.MTG1_RECORDING_BOOK_M
		,d.MTG4_RECORDING_PAGE = l.MTG1_RECORDING_PAGE_M
		,d.MTG4_DETAILED_DOC_TYPE = l.MTG1_DETAILED_DOC_TYPE_M
		,d.MTG4_MTG_AMOUNT = l.MTG1_MTG_AMOUNT_M
		,d.MTG4_LENDER_LAST_NAME = l.MTG1_LENDER_LAST_NAME_M
		,d.MTG4_LENDER_FIRST_NAME = l.MTG1_LENDER_FIRST_NAME_M
		,d.MTG4_LENDER_ADDRESS = l.MTG1_LENDER_ADDRESS_M
		,d.MTG4_LENDER_CITY = l.MTG1_LENDER_CITY_M
		,d.MTG4_LENDER_STATE = l.MTG1_LENDER_STATE_M
		,d.MTG4_LENDER_ZIP = l.MTG1_LENDER_ZIP_M
		,d.MTG4_MTG_COMPANY_CODE = l.MTG1_MTG_COMPANY_CODE_M
		,d.MTG4_MTG_LOAN_TYPE_CODE = l.MTG1_MTG_LOAN_TYPE_CODE_M
		,d.MTG4_MTG_TERM_CODE = l.MTG1_MTG_TERM_CODE_M
		,d.MTG4_MTG_TERM = l.MTG1_MTG_TERM_M
		,d.MTG4_MTG_DUE_DATE = l.MTG1_MTG_DUE_DATE_M
		,d.MTG4_MTG_INTEREST_RATE_TYPE = l.MTG1_MTG_INTEREST_RATE_TYPE_M
		,d.MTG4_MTG_INTEREST_RATE = l.MTG1_MTG_INTEREST_RATE_M
		,d.MTG4_SELLER_CARRY_BACK = l.MTG1_SELLER_CARRY_BACK_M
		,d.MTG4_PRIVATE_PARTY_LENDER = l.MTG1_PRIVATE_PARTY_LENDER_M
		,d.MTG4_CONSTRUCTION_LOAN = l.MTG1_CONSTRUCTION_LOAN_M
		,d.MTG4_REFI_FLAG = l.MTG1_REFI_FLAG_M
		,d.MTG4_EQUITY_FLAG = l.MTG1_EQUITY_FLAG_M
		,d.MTG4_OTHER_SUBORDINATE_LOANS = l.MTG1_OTHER_SUBORDINATE_LOANS_M
		,d.FMT_MTG4_DOC_NBR = l.FMT_MTG1_DOC_NBR_M
		,d.CMT_ID_MTG4_DOC_NBR = l.CMT_ID_MTG1_DOC_NBR_M
		,d.FMT_MTG4_Book_Page = l.FMT_MTG1_Book_Page_M
		,d.CMT_ID_MTG4_Book_Page = l.CMT_ID_MTG1_Book_Page_M
		,d.MTG4_UR_Doc_Id = l.MTG_UR_Doc_Id
		,d.ORIG_MTG4_Lender_Name = l.ORIG_MTG1_Lender_Name     
		,d.NMLSLenderName_4   = l.NMLSLenderName_1      
		,d.NMLSLenderId_4   = l.NMLSLenderId_1      
		,d.NMLSBrokerName_4   = l.NMLSBrokerName_1      
		,d.NMLSBrokerId_4   = l.NMLSBrokerId_1      
		,d.NMLSAgentName_4   = l.NMLSAgentName_1      
		,d.NMLSAgentId_4   = l.NMLSAgentId_1  
		,d.Attorney_Email = n.Attorney_Email
		,d.Attorney_Firm_Name = n.Attorney_Firm_Name
		,d.Mtg4_Int_Source = l.Mtg1_Int_Source
		,d.TITLE_COMPANY_NAME = n.new_TITLE_COMPANY_NAME
		,d.Attorney_Name_identifier = n2.Attorney_Name_identifier
		,d.Attorney_Last_Name = n2.Attorney_Last_Name
		,d.Attorney_First_Name = n2.Attorney_First_Name
		,d.Attorney_Middle_Initial = n2.Attorney_Middle_Initial
		,d.Attorney_suffix = n2.Attorney_suffix
		,d.Attorney_address = n2.Attorney_address
		,d.Attorney_Address_City = n2.Attorney_Address_City
		,d.Attorney_Address_State = n2.Attorney_Address_State
		,d.Attorney_Address_Zip = n2.Attorney_Address_Zip
		,d.Attorney_Phone = n2.Attorney_Phone
		,d.Attorney_Full_Name = n2.Attorney_Full_Name
	FROM [lien_DTDB].[INFC].[Deed_work] d
	INNER JOIN [lien_DTDB].[INFC].[UR_Deed_Mortgage_Link] l ON d.fips = l.fips
		AND d.DeedID = l.DeedID_D
	OUTER APPLY (
		SELECT CASE 
				WHEN replace(isnull(d.SITUS_HOUSE_NBR, '') + isnull(d.SITUS_DIRECTION, '') + isnull(d.SITUS_STREET_NAME, '') + isnull(d.SITUS_MODE, '') + isnull(d.SITUS_POST_DIRECTION, '') + isnull(d.SITUS_CITY, '') + isnull(d.SITUS_STATE, '') + isnull(d.SITUS_ZIP_CODE, '') + isnull(d.SITUS_CARRIER_CODE, ''), ' ', '') > ''
					THEN 1
				ELSE 0
				END _use_deed_situs
		) b
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [lien_dtdb].[tmp].[UR_Merge_Deed_To_Mtg_New_temp] m WITH (
				NOLOCK
				,INDEX (idx_deedid)
				)
		WHERE m.deedid = l.DeedID_m
			AND m._DeedMtg = 't'
		) m
	OUTER APPLY (
		SELECT CASE 
				WHEN d.TITLE_COMPANY_NAME IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME NOT IN (
						'NONE LISTED ON DOCUMENT'
						,'NEW TITLE COMPANY NAME'
						)
					AND m.TITLE_COMPANY_NAME > ''
					THEN m.TITLE_COMPANY_NAME
				ELSE d.TITLE_COMPANY_NAME
				END AS new_TITLE_COMPANY_NAME
			,CASE 
				WHEN isnull(d.Attorney_Last_Name, '') = ''
					AND isnull(m.Attorney_Last_Name, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg
			,CASE 
				WHEN isnull(d.Attorney_address, '') = ''
					AND isnull(m.Attorney_address, '') > ''
					THEN 'm'
				ELSE 'd'
				END AS Pick_deed_or_mtg_addr
			,CASE 
				WHEN isnull(d.attorney_firm_name, '') > ''
					THEN d.attorney_firm_name
				ELSE m.attorney_firm_name
				END AS attorney_firm_name
			,CASE 
				WHEN isnull(d.Attorney_Email, '') > ''
					THEN d.Attorney_Email
				ELSE m.Attorney_Email
				END AS Attorney_Email
		) n
	OUTER APPLY (
		SELECT CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Name_identifier
				ELSE m.Attorney_Name_identifier
				END AS Attorney_Name_identifier
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Last_Name
				ELSE m.Attorney_Last_Name
				END AS Attorney_Last_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_First_Name
				ELSE m.Attorney_First_Name
				END AS Attorney_First_Name
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Middle_Initial
				ELSE m.Attorney_Middle_Initial
				END AS Attorney_Middle_Initial
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_suffix
				ELSE m.Attorney_suffix
				END AS Attorney_suffix
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_address
				ELSE m.Attorney_address
				END AS Attorney_address
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_City
				ELSE m.Attorney_Address_City
				END AS Attorney_Address_City
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_State
				ELSE m.Attorney_Address_State
				END AS Attorney_Address_State
			,CASE 
				WHEN n.Pick_deed_or_mtg_addr = 'd'
					THEN d.Attorney_Address_Zip
				ELSE m.Attorney_Address_Zip
				END AS Attorney_Address_Zip
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Phone
				ELSE m.Attorney_Phone
				END AS Attorney_Phone
			,CASE 
				WHEN n.Pick_deed_or_mtg = 'd'
					THEN d.Attorney_Full_Name
				ELSE m.Attorney_Full_Name
				END AS Attorney_Full_Name
		) n2
	WHERE l.rn = 4

	--
	--Insert mortgages that were linked that are not linked anymore
	--
	INSERT INTO [lien_dtdb].[infc].[Mortgage_work] (
		[FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[Deed_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,[Link]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[UR_REMARKS]
		,ORIG_MTG1_Lender_Name
		,ORIG_MTG2_Lender_Name
		,ORIG_MTG3_Lender_Name
		,ORIG_MTG4_Lender_Name
		,NMLSLenderName_1
		,NMLSLenderId_1
		,NMLSBrokerName_1
		,NMLSBrokerId_1
		,NMLSAgentName_1
		,NMLSAgentId_1
		,NMLSLenderName_2
		,NMLSLenderId_2
		,NMLSBrokerName_2
		,NMLSBrokerId_2
		,NMLSAgentName_2
		,NMLSAgentId_2
		,NMLSLenderName_3
		,NMLSLenderId_3
		,NMLSBrokerName_3
		,NMLSBrokerId_3
		,NMLSAgentName_3
		,NMLSAgentId_3
		,NMLSLenderName_4
		,NMLSLenderId_4
		,NMLSBrokerName_4
		,NMLSBrokerId_4
		,NMLSAgentName_4
		,NMLSAgentId_4
		,Attorney_Email
		,Attorney_Firm_Name
		,[Mtg1_Int_Source]
		,[Mtg2_Int_Source]
		,[Mtg3_Int_Source]
		,[Mtg4_Int_Source]
		)
	SELECT [FIPS]
		,[REF_ID]
		,[US_STATE]
		,[US_COUNTY]
		,[APN_unformatted]
		,[APN_formatted_UNIVERSAL]
		,[APN_SEQUENCE_NBR]
		,[ORIGINAL_APN]
		,[ACCOUNT_NBR]
		,[PENDING_TRANS]
		,[BYR1_CORP_IND]
		,[BYR1_OWN_NAME]
		,[BYR1_OWN_ETAL_IND]
		,[BYR1_CO_NAME]
		,[BYR1_OWNERSHIP_RIGHTS_CODE]
		,[BYR1_OWN_RELATIONSHIP_TYPE]
		,[BYR1_OWNERSHIP]
		,[BYR2_CORP_IND]
		,[BYR2_OWN_NAME]
		,[BYR2_OWNERSHIP_RIGHTS_CODE]
		,[BYR2_OWN_RELATIONSHIP_TYPE]
		,[BYR2_OWNERSHIP]
		,[BYR3_CORP_IND]
		,[BYR3_OWN_NAME]
		,[BYR3_OWNERSHIP_RIGHTS_CODE]
		,[BYR3_OWN_RELATIONSHIP_TYPE]
		,[BYR3_OWNERSHIP]
		,[BYR4_CORP_IND]
		,[BYR4_OWN_NAME]
		,[BYR4_OWNERSHIP_RIGHTS_CODE]
		,[BYR4_OWN_RELATIONSHIP_TYPE]
		,[BYR4_OWNERSHIP]
		,[BYR1_LAST_NAME]
		,[BYR1_FIRST_NAME]
		,[BYR1_MIDDLE_INITIAL]
		,[BYR1_SUFFIX]
		,[BYR2_LAST_NAME]
		,[BYR2_FIRST_NAME]
		,[BYR2_MIDDLE_INITIAL]
		,[BYR2_SUFFIX]
		,[BYR3_LAST_NAME]
		,[BYR3_FIRST_NAME]
		,[BYR3_MIDDLE_INITIAL]
		,[BYR3_SUFFIX]
		,[BYR4_LAST_NAME]
		,[BYR4_FIRST_NAME]
		,[BYR4_MIDDLE_INITIAL]
		,[BYR4_SUFFIX]
		,[MA_HOUSE_NBR_PREFIX]
		,[MA_HOUSE_NBR]
		,[MA_HOUSE_NBR_SUFFIX]
		,[MA_STREET_DIRECTION]
		,[MA_STREET_NAME]
		,[MA_MODE]
		,[MA_QUADRANT]
		,[MA_APARTMENT_UNIT]
		,[MA_CITY]
		,[MA_STATE]
		,[MA_ZIP_CODE]
		,[MA_CARRIER_CODE]
		,[MA_ORIGINAL_MAILING_ADDRESS]
		,[MA_DO_NOT_PUBLISH_FLAG]
		,[SITUS_HOUSE_NBR]
		,[SITUS_HOUSE_NBR2]
		,[SITUS_HOUSE_NBR_SUFFIX]
		,[SITUS_DIRECTION]
		,[SITUS_STREET_NAME]
		,[SITUS_MODE]
		,[SITUS_POST_DIRECTION]
		,[SITUS_UNIT_NBR]
		,[SITUS_CITY]
		,[SITUS_STATE]
		,[SITUS_ZIP_CODE]
		,[SITUS_CARRIER_CODE]
		,[ORIGINAL_SITE_ADDRESS]
		,[CLGX_UNIQUE_ID]
		,[RECORDING_DATE]
		,[SALE_DATE]
		,[DOC_NBR]
		,[RECORDING_BOOK]
		,[RECORDING_PAGE]
		,[HAWAII_LAND_COURT_DOC_NBR]
		,[HAWAII_TCT_CERTIFICATE_NBR]
		,[WA_EXCISE_NBR]
		,[Deed_TYPE]
		,[DETAILED_DOC_TYPE]
		,[TRANSACTION_TYPE]
		,[SELLER_NAME_PLAINTIFF_1]
		,[SELLER_NAME_PLAINTIFF1_CORP_IND]
		,[SELLER_NAME_PLAINTIFF_2]
		,[SELLER_NAME_PLAINTIFF_2_CORP_IND]
		,[SALE_AMOUNT]
		,[DOC_TRANSFER_TAX]
		,[SALE_CODE]
		,[PARTIAL_INTEREST_IND]
		,[RESALE_NEW_CONSTRUCTION]
		,[INTER_FAMILY]
		,[FORCLOSURE]
		,[REO_SALE]
		,[MTG1_RECORDING_DATE]
		,[MTG1_DOC_DATE]
		,[MTG1_DOC_NBR]
		,[MTG1_RECORDING_BOOK]
		,[MTG1_RECORDING_PAGE]
		,[MTG1_DETAILED_DOC_TYPE]
		,[MTG1_MTG_AMOUNT]
		,[MTG1_LENDER_LAST_NAME]
		,[MTG1_LENDER_FIRST_NAME]
		,[MTG1_LENDER_ADDRESS]
		,[MTG1_LENDER_CITY]
		,[MTG1_LENDER_STATE]
		,[MTG1_LENDER_ZIP]
		,[MTG1_MTG_COMPANY_CODE]
		,[MTG1_MTG_LOAN_TYPE_CODE]
		,[MTG1_MTG_TERM_CODE]
		,[MTG1_MTG_TERM_]
		,[MTG1_MTG_DUE_DATE]
		,[MTG1_MTG_INTEREST_RATE_TYPE]
		,[MTG1_MTG_INTEREST_RATE]
		,[MTG1_SELLER_CARRY_BACK]
		,[MTG1_PRIVATE_PARTY_LENDER]
		,[MTG1_CONSTRUCTION_LOAN]
		,[MTG1_REFI_FLAG]
		,[MTG1_EQUITY_FLAG]
		,[MTG1_OTHER_SUBORDINATE_LOANS]
		,[MTG2_RECORDING_DATE]
		,[MTG2_DOC_DATE]
		,[MTG2_DOC_NBR]
		,[MTG2_RECORDING_BOOK]
		,[MTG2_RECORDING_PAGE]
		,[MTG2_DETAILED_DOC_TYPE]
		,[MTG2_MTG_AMOUNT]
		,[MTG2_LENDER_LAST_NAME]
		,[MTG2_LENDER_FIRST_NAME]
		,[MTG2_LENDER_ADDRESS]
		,[MTG2_LENDER_CITY]
		,[MTG2_LENDER_STATE]
		,[MTG2_LENDER_ZIP]
		,[MTG2_MTG_COMPANY_CODE]
		,[MTG2_MTG_LOAN_TYPE_CODE]
		,[MTG2_MTG_TERM_CODE]
		,[MTG2_MTG_TERM]
		,[MTG2_MTG_DUE_DATE]
		,[MTG2_MTG_INTEREST_RATE_TYPE]
		,[MTG2_MTG_INTEREST_RATE]
		,[MTG2_SELLER_CARRY_BACK]
		,[MTG2_PRIVATE_PARTY_LENDER]
		,[MTG2_CONSTRUCTION_LOAN]
		,[MTG2_REFI_FLAG]
		,[MTG2_EQUITY_FLAG]
		,[MTG2_OTHER_SUBORDINATE_LOANS]
		,[MTG3_RECORDING_DATE]
		,[MTG3_DOC_DATE]
		,[MTG3_DOC_NBR]
		,[MTG3_RECORDING_BOOK]
		,[MTG3_RECORDING_PAGE]
		,[MTG3_DETAILED_DOC_TYPE]
		,[MTG3_MTG_AMOUNT]
		,[MTG3_LENDER_LAST_NAME]
		,[MTG3_LENDER_FIRST_NAME]
		,[MTG3_LENDER_ADDRESS]
		,[MTG3_LENDER_CITY]
		,[MTG3_LENDER_STATE]
		,[MTG3_LENDER_ZIP]
		,[MTG3_MTG_COMPANY_CODE]
		,[MTG3_MTG_LOAN_TYPE_CODE]
		,[MTG3_MTG_TERM_CODE]
		,[MTG3_MTG_TERM]
		,[MTG3_MTG_DUE_DATE]
		,[MTG3_MTG_INTEREST_RATE_TYPE]
		,[MTG3_MTG_INTEREST_RATE]
		,[MTG3_SELLER_CARRY_BACK]
		,[MTG3_PRIVATE_PARTY_LENDER]
		,[MTG3_CONSTRUCTION_LOAN]
		,[MTG3_REFI_FLAG]
		,[MTG3_EQUITY_FLAG]
		,[MTG3_OTHER_SUBORDINATE_LOANS]
		,[MTG4_RECORDING_DATE]
		,[MTG4_DOC_DATE]
		,[MTG4_DOC_NBR]
		,[MTG4_RECORDING_BOOK]
		,[MTG4_RECORDING_PAGE]
		,[MTG4_DETAILED_DOC_TYPE]
		,[MTG4_MTG_AMOUNT]
		,[MTG4_LENDER_LAST_NAME]
		,[MTG4_LENDER_FIRST_NAME]
		,[MTG4_LENDER_ADDRESS]
		,[MTG4_LENDER_CITY]
		,[MTG4_LENDER_STATE]
		,[MTG4_LENDER_ZIP]
		,[MTG4_MTG_COMPANY_CODE]
		,[MTG4_MTG_LOAN_TYPE_CODE]
		,[MTG4_MTG_TERM_CODE]
		,[MTG4_MTG_TERM]
		,[MTG4_MTG_DUE_DATE]
		,[MTG4_MTG_INTEREST_RATE_TYPE]
		,[MTG4_MTG_INTEREST_RATE]
		,[MTG4_SELLER_CARRY_BACK]
		,[MTG4_PRIVATE_PARTY_LENDER]
		,[MTG4_CONSTRUCTION_LOAN]
		,[MTG4_REFI_FLAG]
		,[MTG4_EQUITY_FLAG]
		,[MTG4_OTHER_SUBORDINATE_LOANS]
		,[ORIGINAL_RECORDED_DATE]
		,[ORIGINAL_BKPG]
		,[ORIGINAL_DOC_NBR]
		,[SECTION]
		,[TOWNSHIP]
		,[RANGE]
		,[DISTRICT_CODE]
		,[LOT]
		,[BLOCK]
		,[SUBDIVISION_NAME]
		,[UNIT]
		,[BUILDING]
		,[PLAT_SUBD_MAP_BOOK]
		,[PLAT_SUBD_MAP_PAGE]
		,[MAP_TYPE_IND]
		,[EXPANDED_LEGAL]
		,[TRACT_NBR]
		,[LAND_LOT]
		,[TITLE_COMPANY_NAME]
		,[TITLE_COMPANY_CODE]
		,[MULTI_APN]
		,[SALES_SOURCE_IND]
		,[TIMESTAMP_DATE]
		,[RECORD_TYPE]
		,[PRI_CAT_CODE]
		,[CREATED]
		,[PREVIOUS_PARCEL_NBR]
		,[PREVIOUS_PARCEL_SEQUENCE_NBR]
		,[FMT_DOC_NBR]
		,[CMT_ID_DOC_NBR]
		,[FMT_MTG1_DOC_NBR]
		,[CMT_ID_MTG1_DOC_NBR]
		,[FMT_MTG2_DOC_NBR]
		,[CMT_ID_MTG2_DOC_NBR]
		,[FMT_MTG3_DOC_NBR]
		,[CMT_ID_MTG3_DOC_NBR]
		,[FMT_MTG4_DOC_NBR]
		,[CMT_ID_MTG4_DOC_NBR]
		,[FMT_Book_Page]
		,[CMT_ID_Book_Page]
		,[FMT_MTG1_Book_Page]
		,[CMT_ID_MTG1_Book_Page]
		,[FMT_MTG2_Book_Page]
		,[CMT_ID_MTG2_Book_Page]
		,[FMT_MTG3_Book_Page]
		,[CMT_ID_MTG3_Book_Page]
		,[FMT_MTG4_Book_Page]
		,[CMT_ID_MTG4_Book_Page]
		,[Source_type]
		,[SRC_TBL]
		,[MOD_RAS_CLGX_UNIQUE_ID]
		,[UR_Doc_Unique_Id]
		,[UR_Doc_Id]
		,[UR_Property_Id]
		,[UR_Name_Id]
		,[UR_Reference_Id]
		,NULL AS [Link]
		,[DATA_SRC_IND]
		,[UR_Prop_Seq_Num]
		,[UR_Reprocess_Flag]
		,[Attorney_Name_identifier]
		,[Attorney_Last_Name]
		,[Attorney_First_Name]
		,[Attorney_Middle_Initial]
		,[Attorney_suffix]
		,[Attorney_address]
		,[Attorney_Address_City]
		,[Attorney_Address_State]
		,[Attorney_Address_Zip]
		,[Attorney_Phone]
		,[Attorney_Full_Name]
		,[UR_REMARKS]
		,ORIG_MTG1_Lender_Name
		,ORIG_MTG2_Lender_Name
		,ORIG_MTG3_Lender_Name
		,ORIG_MTG4_Lender_Name
		,NMLSLenderName_1
		,NMLSLenderId_1
		,NMLSBrokerName_1
		,NMLSBrokerId_1
		,NMLSAgentName_1
		,NMLSAgentId_1
		,NMLSLenderName_2
		,NMLSLenderId_2
		,NMLSBrokerName_2
		,NMLSBrokerId_2
		,NMLSAgentName_2
		,NMLSAgentId_2
		,NMLSLenderName_3
		,NMLSLenderId_3
		,NMLSBrokerName_3
		,NMLSBrokerId_3
		,NMLSAgentName_3
		,NMLSAgentId_3
		,NMLSLenderName_4
		,NMLSLenderId_4
		,NMLSBrokerName_4
		,NMLSBrokerId_4
		,NMLSAgentName_4
		,NMLSAgentId_4
		,Attorney_Email
		,Attorney_Firm_Name
		,[Mtg1_Int_Source]
		,[Mtg2_Int_Source]
		,[Mtg3_Int_Source]
		,[Mtg4_Int_Source]
	FROM [lien_DTDB].[infc].[DeedMtg2] t
	WHERE _DeedMtg = 'T'
		AND (
			SELECT count(1)
			FROM [lien_DTDB].[INFC].[Deed_work] d
			WHERE d.MTG1_UR_Doc_Id = t.UR_Doc_Id
			) = 0
		AND (
			SELECT count(1)
			FROM [lien_DTDB].[INFC].[Deed_work] d
			WHERE d.MTG2_UR_Doc_Id = t.UR_Doc_Id
			) = 0
		AND (
			SELECT count(1)
			FROM [lien_DTDB].[INFC].[Deed_work] d
			WHERE d.MTG3_UR_Doc_Id = t.UR_Doc_Id
			) = 0
		AND (
			SELECT count(1)
			FROM [lien_DTDB].[INFC].[Deed_work] d
			WHERE d.MTG4_UR_Doc_Id = t.UR_Doc_Id
			) = 0
		AND (
			SELECT count(1)
			FROM [lien_DTDB].[INFC].[Mortgage_work] d
			WHERE d.UR_Doc_Id = t.UR_Doc_Id
			) = 0

	--
	--identify mortgage records on the deed table that should be delete
	--
	DROP TABLE

	IF EXISTS [lien_DTDB].[tmp].[Mortgage_delete]
		SELECT fips
			,CLGX_UNIQUE_ID
			,SRC_TBL
			,source_type
			,DeedID
			,REF_ID
			,ur_doc_id
		INTO [lien_DTDB].[tmp].[Mortgage_delete]
		FROM [lien_DTDB].[infc].[DeedMtg2] t
		WHERE _DeedMtg = 'T'
			AND (
				(
					SELECT count(1)
					FROM [lien_DTDB].[INFC].[Deed_work] d
					WHERE d.MTG1_UR_Doc_Id = t.UR_Doc_Id
						AND d.ref_id = t.ref_id
					) > 0
				OR (
					SELECT count(1)
					FROM [lien_DTDB].[INFC].[Deed_work] d
					WHERE d.MTG2_UR_Doc_Id = t.UR_Doc_Id
						AND d.ref_id = t.ref_id
					) > 0
				OR (
					SELECT count(1)
					FROM [lien_DTDB].[INFC].[Deed_work] d
					WHERE d.MTG3_UR_Doc_Id = t.UR_Doc_Id
						AND d.ref_id = t.ref_id
					) > 0
				OR (
					SELECT count(1)
					FROM [lien_DTDB].[INFC].[Deed_work] d
					WHERE d.MTG4_UR_Doc_Id = t.UR_Doc_Id
						AND d.ref_id = t.ref_id
					) > 0
				)

	CREATE INDEX idx_unique_key ON [lien_DTDB].[tmp].[Mortgage_delete] (
		fips
		,ref_id
		,ur_doc_id
		,SRC_TBL
		,source_type
		)

	CREATE INDEX idx_doc_id ON [lien_DTDB].[tmp].[Mortgage_delete] (ur_doc_id)

	/* SET FLAG IN MTG TABLE */
	--update m
	--set m.link='M4'
	--from 
	--lien_DTDB.INFC.Mortgage_work m
	--inner join
	--lien_DTDB.INFC.UR_Deed_Mortgage_Link l
	--on m.fips=l.fips
	--and m.DeedID=l.DeedID_M
	--where l.rn=4
	BEGIN
		--delete from lien_DTDB.INFC.Mortgage_work where link is not null
		DELETE m
		FROM [lien_DTDB].[INFC].[Mortgage_work] m
		INNER JOIN [lien_DTDB].[INFC].[Deed_work] d ON d.MTG1_UR_Doc_Id = m.UR_Doc_Id
			AND d.ref_id = m.ref_id

		DELETE m
		FROM [lien_DTDB].[INFC].[Mortgage_work] m
		INNER JOIN [lien_DTDB].[INFC].[Deed_work] d ON d.MTG2_UR_Doc_Id = m.UR_Doc_Id
			AND d.ref_id = m.ref_id

		DELETE m
		FROM [lien_DTDB].[INFC].[Mortgage_work] m
		INNER JOIN [lien_DTDB].[INFC].[Deed_work] d ON d.MTG3_UR_Doc_Id = m.UR_Doc_Id
			AND d.ref_id = m.ref_id

		DELETE m
		FROM [lien_DTDB].[INFC].[Mortgage_work] m
		INNER JOIN [lien_DTDB].[INFC].[Deed_work] d ON d.MTG4_UR_Doc_Id = m.UR_Doc_Id
			AND d.ref_id = m.ref_id
			------	SET @sql = N'
			--------final standalone
			------SELECT *
			------INTO lien_DTDB.INFC.Mortgage_work_' + @date + '_before_delete
			------FROM lien_DTDB.INFC.Mortgage_work
			------'
			------	--Select @sql as N'@sql'
			------	EXEC (@sql)
			------		--DELETE m
			------		--FROM lien_DTDB.INFC.Mortgage_work m
			------		--INNER JOIN lien_DTDB.infc.DeedMtg2 d ON d.UR_Doc_Id = m.UR_Doc_Id
			------		--WHERE d.dup_doc_nbr > 1
	END

	BEGIN
		UPDATE [lien_DTDB].[INFC].[Deed_work]
		SET MTG1_DOC_DATE = SALE_DATE
		FROM [lien_DTDB].[INFC].[Deed_work]
		WHERE Deed_TYPE = 'G'
			AND source_type = 'E'
			AND fips != ''
			AND Ref_Id IS NOT NULL
			AND FMT_DOC_NBR != ''
			AND FMT_DOC_NBR != FMT_MTG1_DOC_NBR
			AND SALE_DATE IS NOT NULL
			AND MTG1_MTG_AMOUNT IS NOT NULL
			AND MTG1_MTG_AMOUNT != '0.00'
			AND (
				MTG1_DOC_DATE <> SALE_DATE
				OR MTG1_DOC_DATE IS NULL
				)
	END

	--create a temp table for every fips on deed_work
	-- then assign the maximum value + 1 to the first for the fips
	-- and increment then value for every next record
	-- befor ethis , assign the clgx id form deed.dbo.deed to deed_work for the same ur_doc_id and ref_id
	-- remember to bring in property_Seq in this assignment
	-- onthou om die mortgages wat gemerge het te delte as hulle of the deed.dbo.deed is
	--update a set a.CLGX_UNIQUE_ID = null from lien_DTDB.infc.deed_work a
	--update a set a.CLGX_UNIQUE_ID = null from lien_DTDB.infc.mortgage_work a
	--we need to get the clgx for existing ones before we assign ones
	--select a.fips,a.ur_doc_id,a.ref_id,a.ORIGINAL_APN ,a.* from lien_DTDB.infc.deed_work a order by a.fips,a.ur_doc_id,a.ref_id,a.ORIGINAL_APN
	--select a.fips,a.ur_doc_id,a.ref_id,a.ORIGINAL_APN ,a.* from deed.dbo.deed a order by  a.fips,a.ur_doc_id,a.ref_id,a.ORIGINAL_APN
	-- when property extarct, dont duplicate for hte same ref_id for the same for the same document_number
	-- add the property_seq nbr to the deed and mortgage extract
	--
	-- get clgx_unique_id from RAS table if record already exist
	--
	--select * from lien_DTDB.infc.mortgage_work where CLGX_UNIQUE_ID is null
	--
	-- insert mortgage_work into deed_work
	--
	INSERT INTO [lien_DTDB].[infc].[deed_work] (
		FIPS
		,REF_ID
		,US_STATE
		,US_COUNTY
		,APN_unformatted
		,APN_formatted_UNIVERSAL
		,APN_SEQUENCE_NBR
		,ORIGINAL_APN
		,ACCOUNT_NBR
		,PENDING_TRANS
		,BYR1_CORP_IND
		,BYR1_OWN_NAME
		,BYR1_OWN_ETAL_IND
		,BYR1_CO_NAME
		,BYR1_OWNERSHIP_RIGHTS_CODE
		,BYR1_OWN_RELATIONSHIP_TYPE
		,BYR1_OWNERSHIP
		,BYR2_CORP_IND
		,BYR2_OWN_NAME
		,BYR2_OWNERSHIP_RIGHTS_CODE
		,BYR2_OWN_RELATIONSHIP_TYPE
		,BYR2_OWNERSHIP
		,BYR3_CORP_IND
		,BYR3_OWN_NAME
		,BYR3_OWNERSHIP_RIGHTS_CODE
		,BYR3_OWN_RELATIONSHIP_TYPE
		,BYR3_OWNERSHIP
		,BYR4_CORP_IND
		,BYR4_OWN_NAME
		,BYR4_OWNERSHIP_RIGHTS_CODE
		,BYR4_OWN_RELATIONSHIP_TYPE
		,BYR4_OWNERSHIP
		,BYR1_LAST_NAME
		,BYR1_FIRST_NAME
		,BYR1_MIDDLE_INITIAL
		,BYR1_SUFFIX
		,BYR2_LAST_NAME
		,BYR2_FIRST_NAME
		,BYR2_MIDDLE_INITIAL
		,BYR2_SUFFIX
		,BYR3_LAST_NAME
		,BYR3_FIRST_NAME
		,BYR3_MIDDLE_INITIAL
		,BYR3_SUFFIX
		,BYR4_LAST_NAME
		,BYR4_FIRST_NAME
		,BYR4_MIDDLE_INITIAL
		,BYR4_SUFFIX
		,MA_HOUSE_NBR_PREFIX
		,MA_HOUSE_NBR
		,MA_HOUSE_NBR_SUFFIX
		,MA_STREET_DIRECTION
		,MA_STREET_NAME
		,MA_MODE
		,MA_QUADRANT
		,MA_APARTMENT_UNIT
		,MA_CITY
		,MA_STATE
		,MA_ZIP_CODE
		,MA_CARRIER_CODE
		,MA_ORIGINAL_MAILING_ADDRESS
		,MA_DO_NOT_PUBLISH_FLAG
		,SITUS_HOUSE_NBR
		,SITUS_HOUSE_NBR2
		,SITUS_HOUSE_NBR_SUFFIX
		,SITUS_DIRECTION
		,SITUS_STREET_NAME
		,SITUS_MODE
		,SITUS_POST_DIRECTION
		,SITUS_UNIT_NBR
		,SITUS_CITY
		,SITUS_STATE
		,SITUS_ZIP_CODE
		,SITUS_CARRIER_CODE
		,ORIGINAL_SITE_ADDRESS
		,CLGX_UNIQUE_ID
		,RECORDING_DATE
		,SALE_DATE
		,DOC_NBR
		,RECORDING_BOOK
		,RECORDING_PAGE
		,HAWAII_LAND_COURT_DOC_NBR
		,HAWAII_TCT_CERTIFICATE_NBR
		,WA_EXCISE_NBR
		,DEED_TYPE
		,DETAILED_DOC_TYPE
		,TRANSACTION_TYPE
		,SELLER_NAME_PLAINTIFF_1
		,SELLER_NAME_PLAINTIFF1_CORP_IND
		,SELLER_NAME_PLAINTIFF_2
		,SELLER_NAME_PLAINTIFF_2_CORP_IND
		,SALE_AMOUNT
		,DOC_TRANSFER_TAX
		,SALE_CODE
		,PARTIAL_INTEREST_IND
		,RESALE_NEW_CONSTRUCTION
		,INTER_FAMILY
		,FORCLOSURE
		,REO_SALE
		,MTG1_RECORDING_DATE
		,MTG1_DOC_DATE
		,MTG1_DOC_NBR
		,MTG1_RECORDING_BOOK
		,MTG1_RECORDING_PAGE
		,MTG1_DETAILED_DOC_TYPE
		,MTG1_MTG_AMOUNT
		,MTG1_LENDER_LAST_NAME
		,MTG1_LENDER_FIRST_NAME
		,MTG1_LENDER_ADDRESS
		,MTG1_LENDER_CITY
		,MTG1_LENDER_STATE
		,MTG1_LENDER_ZIP
		,MTG1_MTG_COMPANY_CODE
		,MTG1_MTG_LOAN_TYPE_CODE
		,MTG1_MTG_TERM_CODE
		,MTG1_MTG_TERM_
		,MTG1_MTG_DUE_DATE
		,MTG1_MTG_INTEREST_RATE_TYPE
		,MTG1_MTG_INTEREST_RATE
		,MTG1_SELLER_CARRY_BACK
		,MTG1_PRIVATE_PARTY_LENDER
		,MTG1_CONSTRUCTION_LOAN
		,MTG1_REFI_FLAG
		,MTG1_EQUITY_FLAG
		,MTG1_OTHER_SUBORDINATE_LOANS
		,MTG2_RECORDING_DATE
		,MTG2_DOC_DATE
		,MTG2_DOC_NBR
		,MTG2_RECORDING_BOOK
		,MTG2_RECORDING_PAGE
		,MTG2_DETAILED_DOC_TYPE
		,MTG2_MTG_AMOUNT
		,MTG2_LENDER_LAST_NAME
		,MTG2_LENDER_FIRST_NAME
		,MTG2_LENDER_ADDRESS
		,MTG2_LENDER_CITY
		,MTG2_LENDER_STATE
		,MTG2_LENDER_ZIP
		,MTG2_MTG_COMPANY_CODE
		,MTG2_MTG_LOAN_TYPE_CODE
		,MTG2_MTG_TERM_CODE
		,MTG2_MTG_TERM
		,MTG2_MTG_DUE_DATE
		,MTG2_MTG_INTEREST_RATE_TYPE
		,MTG2_MTG_INTEREST_RATE
		,MTG2_SELLER_CARRY_BACK
		,MTG2_PRIVATE_PARTY_LENDER
		,MTG2_CONSTRUCTION_LOAN
		,MTG2_REFI_FLAG
		,MTG2_EQUITY_FLAG
		,MTG2_OTHER_SUBORDINATE_LOANS
		,MTG3_RECORDING_DATE
		,MTG3_DOC_DATE
		,MTG3_DOC_NBR
		,MTG3_RECORDING_BOOK
		,MTG3_RECORDING_PAGE
		,MTG3_DETAILED_DOC_TYPE
		,MTG3_MTG_AMOUNT
		,MTG3_LENDER_LAST_NAME
		,MTG3_LENDER_FIRST_NAME
		,MTG3_LENDER_ADDRESS
		,MTG3_LENDER_CITY
		,MTG3_LENDER_STATE
		,MTG3_LENDER_ZIP
		,MTG3_MTG_COMPANY_CODE
		,MTG3_MTG_LOAN_TYPE_CODE
		,MTG3_MTG_TERM_CODE
		,MTG3_MTG_TERM
		,MTG3_MTG_DUE_DATE
		,MTG3_MTG_INTEREST_RATE_TYPE
		,MTG3_MTG_INTEREST_RATE
		,MTG3_SELLER_CARRY_BACK
		,MTG3_PRIVATE_PARTY_LENDER
		,MTG3_CONSTRUCTION_LOAN
		,MTG3_REFI_FLAG
		,MTG3_EQUITY_FLAG
		,MTG3_OTHER_SUBORDINATE_LOANS
		,MTG4_RECORDING_DATE
		,MTG4_DOC_DATE
		,MTG4_DOC_NBR
		,MTG4_RECORDING_BOOK
		,MTG4_RECORDING_PAGE
		,MTG4_DETAILED_DOC_TYPE
		,MTG4_MTG_AMOUNT
		,MTG4_LENDER_LAST_NAME
		,MTG4_LENDER_FIRST_NAME
		,MTG4_LENDER_ADDRESS
		,MTG4_LENDER_CITY
		,MTG4_LENDER_STATE
		,MTG4_LENDER_ZIP
		,MTG4_MTG_COMPANY_CODE
		,MTG4_MTG_LOAN_TYPE_CODE
		,MTG4_MTG_TERM_CODE
		,MTG4_MTG_TERM
		,MTG4_MTG_DUE_DATE
		,MTG4_MTG_INTEREST_RATE_TYPE
		,MTG4_MTG_INTEREST_RATE
		,MTG4_SELLER_CARRY_BACK
		,MTG4_PRIVATE_PARTY_LENDER
		,MTG4_CONSTRUCTION_LOAN
		,MTG4_REFI_FLAG
		,MTG4_EQUITY_FLAG
		,MTG4_OTHER_SUBORDINATE_LOANS
		,ORIGINAL_RECORDED_DATE
		,ORIGINAL_BKPG
		,ORIGINAL_DOC_NBR
		,SECTION
		,TOWNSHIP
		,RANGE
		,DISTRICT_CODE
		,LOT
		,BLOCK
		,SUBDIVISION_NAME
		,UNIT
		,BUILDING
		,PLAT_SUBD_MAP_BOOK
		,PLAT_SUBD_MAP_PAGE
		,MAP_TYPE_IND
		,EXPANDED_LEGAL
		,TRACT_NBR
		,LAND_LOT
		,TITLE_COMPANY_NAME
		,TITLE_COMPANY_CODE
		,MULTI_APN
		,SALES_SOURCE_IND
		,TIMESTAMP_DATE
		,RECORD_TYPE
		,PRI_CAT_CODE
		,CREATED
		,PREVIOUS_PARCEL_NBR
		,PREVIOUS_PARCEL_SEQUENCE_NBR
		,DATA_SRC_IND
		,FMT_DOC_NBR
		,CMT_ID_DOC_NBR
		,FMT_MTG1_DOC_NBR
		,CMT_ID_MTG1_DOC_NBR
		,FMT_MTG2_DOC_NBR
		,CMT_ID_MTG2_DOC_NBR
		,FMT_MTG3_DOC_NBR
		,CMT_ID_MTG3_DOC_NBR
		,FMT_MTG4_DOC_NBR
		,CMT_ID_MTG4_DOC_NBR
		,FMT_Book_Page
		,CMT_ID_Book_Page
		,FMT_MTG1_Book_Page
		,CMT_ID_MTG1_Book_Page
		,FMT_MTG2_Book_Page
		,CMT_ID_MTG2_Book_Page
		,FMT_MTG3_Book_Page
		,CMT_ID_MTG3_Book_Page
		,FMT_MTG4_Book_Page
		,CMT_ID_MTG4_Book_Page
		,Source_Type
		,SRC_TBL
		,MOD_RAS_CLGX_UNIQUE_ID
		,UR_Doc_Unique_Id
		,UR_Doc_Id
		,UR_Property_Id
		,UR_Name_Id
		,UR_Reference_Id
		,UR_Prop_Seq_Num
		,UR_Reprocess_Flag
		,Attorney_middle_initial
		,Attorney_name_identifier
		,Attorney_Last_Name
		,Attorney_first_name
		,Attorney_suffix
		,Attorney_address
		,Attorney_address_city
		,Attorney_address_state
		,Attorney_address_zip
		,Attorney_phone
		,Attorney_Full_Name
		,UR_REMARKS
		,MTG1_UR_Doc_Id
		,ORIG_MTG1_Lender_Name
		,ORIG_MTG2_Lender_Name
		,ORIG_MTG3_Lender_Name
		,ORIG_MTG4_Lender_Name
		,NMLSLenderName_1
		,NMLSLenderId_1
		,NMLSBrokerName_1
		,NMLSBrokerId_1
		,NMLSAgentName_1
		,NMLSAgentId_1
		,NMLSLenderName_2
		,NMLSLenderId_2
		,NMLSBrokerName_2
		,NMLSBrokerId_2
		,NMLSAgentName_2
		,NMLSAgentId_2
		,NMLSLenderName_3
		,NMLSLenderId_3
		,NMLSBrokerName_3
		,NMLSBrokerId_3
		,NMLSAgentName_3
		,NMLSAgentId_3
		,NMLSLenderName_4
		,NMLSLenderId_4
		,NMLSBrokerName_4
		,NMLSBrokerId_4
		,NMLSAgentName_4
		,NMLSAgentId_4
		,Attorney_Email
		,Attorney_Firm_Name
		,[Mtg1_Int_Source]
		,[Mtg2_Int_Source]
		,[Mtg3_Int_Source]
		,[Mtg4_Int_Source]
		)
	SELECT m.FIPS
		,m.REF_ID
		,m.US_STATE
		,m.US_COUNTY
		,m.APN_unformatted
		,m.APN_formatted_UNIVERSAL
		,m.APN_SEQUENCE_NBR
		,m.ORIGINAL_APN
		,m.ACCOUNT_NBR
		,m.PENDING_TRANS
		,m.BYR1_CORP_IND
		,m.BYR1_OWN_NAME
		,m.BYR1_OWN_ETAL_IND
		,m.BYR1_CO_NAME
		,m.BYR1_OWNERSHIP_RIGHTS_CODE
		,m.BYR1_OWN_RELATIONSHIP_TYPE
		,m.BYR1_OWNERSHIP
		,m.BYR2_CORP_IND
		,m.BYR2_OWN_NAME
		,m.BYR2_OWNERSHIP_RIGHTS_CODE
		,m.BYR2_OWN_RELATIONSHIP_TYPE
		,m.BYR2_OWNERSHIP
		,m.BYR3_CORP_IND
		,m.BYR3_OWN_NAME
		,m.BYR3_OWNERSHIP_RIGHTS_CODE
		,m.BYR3_OWN_RELATIONSHIP_TYPE
		,m.BYR3_OWNERSHIP
		,m.BYR4_CORP_IND
		,m.BYR4_OWN_NAME
		,m.BYR4_OWNERSHIP_RIGHTS_CODE
		,m.BYR4_OWN_RELATIONSHIP_TYPE
		,m.BYR4_OWNERSHIP
		,m.BYR1_LAST_NAME
		,m.BYR1_FIRST_NAME
		,m.BYR1_MIDDLE_INITIAL
		,m.BYR1_SUFFIX
		,m.BYR2_LAST_NAME
		,m.BYR2_FIRST_NAME
		,m.BYR2_MIDDLE_INITIAL
		,m.BYR2_SUFFIX
		,m.BYR3_LAST_NAME
		,m.BYR3_FIRST_NAME
		,m.BYR3_MIDDLE_INITIAL
		,m.BYR3_SUFFIX
		,m.BYR4_LAST_NAME
		,m.BYR4_FIRST_NAME
		,m.BYR4_MIDDLE_INITIAL
		,m.BYR4_SUFFIX
		,m.MA_HOUSE_NBR_PREFIX
		,m.MA_HOUSE_NBR
		,m.MA_HOUSE_NBR_SUFFIX
		,m.MA_STREET_DIRECTION
		,m.MA_STREET_NAME
		,m.MA_MODE
		,m.MA_QUADRANT
		,m.MA_APARTMENT_UNIT
		,m.MA_CITY
		,m.MA_STATE
		,m.MA_ZIP_CODE
		,m.MA_CARRIER_CODE
		,m.MA_ORIGINAL_MAILING_ADDRESS
		,m.MA_DO_NOT_PUBLISH_FLAG
		,m.SITUS_HOUSE_NBR
		,m.SITUS_HOUSE_NBR2
		,m.SITUS_HOUSE_NBR_SUFFIX
		,m.SITUS_DIRECTION
		,m.SITUS_STREET_NAME
		,m.SITUS_MODE
		,m.SITUS_POST_DIRECTION
		,m.SITUS_UNIT_NBR
		,m.SITUS_CITY
		,m.SITUS_STATE
		,m.SITUS_ZIP_CODE
		,m.SITUS_CARRIER_CODE
		,m.ORIGINAL_SITE_ADDRESS
		,m.CLGX_UNIQUE_ID
		,m.RECORDING_DATE
		,m.SALE_DATE
		,m.DOC_NBR
		,m.RECORDING_BOOK
		,m.RECORDING_PAGE
		,m.HAWAII_LAND_COURT_DOC_NBR
		,m.HAWAII_TCT_CERTIFICATE_NBR
		,m.WA_EXCISE_NBR
		,m.DEED_TYPE
		,m.DETAILED_DOC_TYPE
		,m.TRANSACTION_TYPE
		,m.SELLER_NAME_PLAINTIFF_1
		,m.SELLER_NAME_PLAINTIFF1_CORP_IND
		,m.SELLER_NAME_PLAINTIFF_2
		,m.SELLER_NAME_PLAINTIFF_2_CORP_IND
		,m.SALE_AMOUNT
		,m.DOC_TRANSFER_TAX
		,m.SALE_CODE
		,m.PARTIAL_INTEREST_IND
		,m.RESALE_NEW_CONSTRUCTION
		,m.INTER_FAMILY
		,m.FORCLOSURE
		,m.REO_SALE
		,m.MTG1_RECORDING_DATE
		,m.MTG1_DOC_DATE
		,m.MTG1_DOC_NBR
		,m.MTG1_RECORDING_BOOK
		,m.MTG1_RECORDING_PAGE
		,m.MTG1_DETAILED_DOC_TYPE
		,m.MTG1_MTG_AMOUNT
		,m.MTG1_LENDER_LAST_NAME
		,m.MTG1_LENDER_FIRST_NAME
		,m.MTG1_LENDER_ADDRESS
		,m.MTG1_LENDER_CITY
		,m.MTG1_LENDER_STATE
		,m.MTG1_LENDER_ZIP
		,m.MTG1_MTG_COMPANY_CODE
		,m.MTG1_MTG_LOAN_TYPE_CODE
		,m.MTG1_MTG_TERM_CODE
		,m.MTG1_MTG_TERM_
		,m.MTG1_MTG_DUE_DATE
		,m.MTG1_MTG_INTEREST_RATE_TYPE
		,m.MTG1_MTG_INTEREST_RATE
		,m.MTG1_SELLER_CARRY_BACK
		,m.MTG1_PRIVATE_PARTY_LENDER
		,m.MTG1_CONSTRUCTION_LOAN
		,m.MTG1_REFI_FLAG
		,m.MTG1_EQUITY_FLAG
		,m.MTG1_OTHER_SUBORDINATE_LOANS
		,m.MTG2_RECORDING_DATE
		,m.MTG2_DOC_DATE
		,m.MTG2_DOC_NBR
		,m.MTG2_RECORDING_BOOK
		,m.MTG2_RECORDING_PAGE
		,m.MTG2_DETAILED_DOC_TYPE
		,m.MTG2_MTG_AMOUNT
		,m.MTG2_LENDER_LAST_NAME
		,m.MTG2_LENDER_FIRST_NAME
		,m.MTG2_LENDER_ADDRESS
		,m.MTG2_LENDER_CITY
		,m.MTG2_LENDER_STATE
		,m.MTG2_LENDER_ZIP
		,m.MTG2_MTG_COMPANY_CODE
		,m.MTG2_MTG_LOAN_TYPE_CODE
		,m.MTG2_MTG_TERM_CODE
		,m.MTG2_MTG_TERM
		,m.MTG2_MTG_DUE_DATE
		,m.MTG2_MTG_INTEREST_RATE_TYPE
		,m.MTG2_MTG_INTEREST_RATE
		,m.MTG2_SELLER_CARRY_BACK
		,m.MTG2_PRIVATE_PARTY_LENDER
		,m.MTG2_CONSTRUCTION_LOAN
		,m.MTG2_REFI_FLAG
		,m.MTG2_EQUITY_FLAG
		,m.MTG2_OTHER_SUBORDINATE_LOANS
		,m.MTG3_RECORDING_DATE
		,m.MTG3_DOC_DATE
		,m.MTG3_DOC_NBR
		,m.MTG3_RECORDING_BOOK
		,m.MTG3_RECORDING_PAGE
		,m.MTG3_DETAILED_DOC_TYPE
		,m.MTG3_MTG_AMOUNT
		,m.MTG3_LENDER_LAST_NAME
		,m.MTG3_LENDER_FIRST_NAME
		,m.MTG3_LENDER_ADDRESS
		,m.MTG3_LENDER_CITY
		,m.MTG3_LENDER_STATE
		,m.MTG3_LENDER_ZIP
		,m.MTG3_MTG_COMPANY_CODE
		,m.MTG3_MTG_LOAN_TYPE_CODE
		,m.MTG3_MTG_TERM_CODE
		,m.MTG3_MTG_TERM
		,m.MTG3_MTG_DUE_DATE
		,m.MTG3_MTG_INTEREST_RATE_TYPE
		,m.MTG3_MTG_INTEREST_RATE
		,m.MTG3_SELLER_CARRY_BACK
		,m.MTG3_PRIVATE_PARTY_LENDER
		,m.MTG3_CONSTRUCTION_LOAN
		,m.MTG3_REFI_FLAG
		,m.MTG3_EQUITY_FLAG
		,m.MTG3_OTHER_SUBORDINATE_LOANS
		,m.MTG4_RECORDING_DATE
		,m.MTG4_DOC_DATE
		,m.MTG4_DOC_NBR
		,m.MTG4_RECORDING_BOOK
		,m.MTG4_RECORDING_PAGE
		,m.MTG4_DETAILED_DOC_TYPE
		,m.MTG4_MTG_AMOUNT
		,m.MTG4_LENDER_LAST_NAME
		,m.MTG4_LENDER_FIRST_NAME
		,m.MTG4_LENDER_ADDRESS
		,m.MTG4_LENDER_CITY
		,m.MTG4_LENDER_STATE
		,m.MTG4_LENDER_ZIP
		,m.MTG4_MTG_COMPANY_CODE
		,m.MTG4_MTG_LOAN_TYPE_CODE
		,m.MTG4_MTG_TERM_CODE
		,m.MTG4_MTG_TERM
		,m.MTG4_MTG_DUE_DATE
		,m.MTG4_MTG_INTEREST_RATE_TYPE
		,m.MTG4_MTG_INTEREST_RATE
		,m.MTG4_SELLER_CARRY_BACK
		,m.MTG4_PRIVATE_PARTY_LENDER
		,m.MTG4_CONSTRUCTION_LOAN
		,m.MTG4_REFI_FLAG
		,m.MTG4_EQUITY_FLAG
		,m.MTG4_OTHER_SUBORDINATE_LOANS
		,m.ORIGINAL_RECORDED_DATE
		,m.ORIGINAL_BKPG
		,m.ORIGINAL_DOC_NBR
		,m.SECTION
		,m.TOWNSHIP
		,m.RANGE
		,m.DISTRICT_CODE
		,m.LOT
		,m.BLOCK
		,m.SUBDIVISION_NAME
		,m.UNIT
		,m.BUILDING
		,m.PLAT_SUBD_MAP_BOOK
		,m.PLAT_SUBD_MAP_PAGE
		,m.MAP_TYPE_IND
		,m.EXPANDED_LEGAL
		,m.TRACT_NBR
		,m.LAND_LOT
		,m.TITLE_COMPANY_NAME
		,m.TITLE_COMPANY_CODE
		,m.MULTI_APN
		,m.SALES_SOURCE_IND
		,m.TIMESTAMP_DATE
		,m.RECORD_TYPE
		,m.PRI_CAT_CODE
		,m.CREATED
		,m.PREVIOUS_PARCEL_NBR
		,m.PREVIOUS_PARCEL_SEQUENCE_NBR
		,m.DATA_SRC_IND AS DATA_SRC_IND
		,m.FMT_DOC_NBR
		,m.CMT_ID_DOC_NBR
		,m.FMT_MTG1_DOC_NBR
		,m.CMT_ID_MTG1_DOC_NBR
		,m.FMT_MTG2_DOC_NBR
		,m.CMT_ID_MTG2_DOC_NBR
		,m.FMT_MTG3_DOC_NBR
		,m.CMT_ID_MTG3_DOC_NBR
		,m.FMT_MTG4_DOC_NBR
		,m.CMT_ID_MTG4_DOC_NBR
		,m.FMT_Book_Page
		,m.CMT_ID_Book_Page
		,m.FMT_MTG1_Book_Page
		,m.CMT_ID_MTG1_Book_Page
		,m.FMT_MTG2_Book_Page
		,m.CMT_ID_MTG2_Book_Page
		,m.FMT_MTG3_Book_Page
		,m.CMT_ID_MTG3_Book_Page
		,m.FMT_MTG4_Book_Page
		,m.CMT_ID_MTG4_Book_Page
		,m.Source_Type
		,m.SRC_TBL
		,m.MOD_RAS_CLGX_UNIQUE_ID
		,m.UR_Doc_Unique_Id
		,m.UR_Doc_Id
		,m.UR_Property_Id
		,m.UR_Name_Id
		,m.UR_Reference_Id
		,m.UR_Prop_Seq_Num
		,m.UR_Reprocess_Flag
		,m.Attorney_middle_initial
		,m.Attorney_name_identifier
		,m.Attorney_Last_Name
		,m.Attorney_first_name
		,m.Attorney_suffix
		,m.Attorney_address
		,m.Attorney_address_city
		,m.Attorney_address_state
		,m.Attorney_address_zip
		,m.Attorney_phone
		,m.Attorney_Full_Name
		,m.UR_REMARKS
		,NULL AS MTG1_UR_Doc_Id
		,m.ORIG_MTG1_Lender_Name
		,m.ORIG_MTG2_Lender_Name
		,m.ORIG_MTG3_Lender_Name
		,m.ORIG_MTG4_Lender_Name
		,m.NMLSLenderName_1
		,m.NMLSLenderId_1
		,m.NMLSBrokerName_1
		,m.NMLSBrokerId_1
		,m.NMLSAgentName_1
		,m.NMLSAgentId_1
		,m.NMLSLenderName_2
		,m.NMLSLenderId_2
		,m.NMLSBrokerName_2
		,m.NMLSBrokerId_2
		,m.NMLSAgentName_2
		,m.NMLSAgentId_2
		,m.NMLSLenderName_3
		,m.NMLSLenderId_3
		,m.NMLSBrokerName_3
		,m.NMLSBrokerId_3
		,m.NMLSAgentName_3
		,m.NMLSAgentId_3
		,m.NMLSLenderName_4
		,m.NMLSLenderId_4
		,m.NMLSBrokerName_4
		,m.NMLSBrokerId_4
		,m.NMLSAgentName_4
		,m.NMLSAgentId_4
		,m.Attorney_Email
		,m.Attorney_Firm_Name
		,m.[Mtg1_Int_Source]
		,m.[Mtg2_Int_Source]
		,m.[Mtg3_Int_Source]
		,m.[Mtg4_Int_Source]
	FROM [lien_DTDB].[INFC].[Mortgage_work] m

	--
	-- ref_ids
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_refids]
		SELECT DISTINCT a.fips
			,a.ref_id
		INTO [lien_dtdb].[tmp].[deed_refids]
		FROM [lien_DTDB].[INFC].[deed_Work] a
		WHERE isnull(a.ref_id, 0) > 0

	CREATE INDEX idx_fips_ref_id ON [lien_dtdb].[tmp].[deed_refids] (
		fips
		,ref_id
		)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Temp_deed]
		SELECT d.CLGX_UNIQUE_ID
			,d.deedid
			,d.FIPS
			,d.FMT_DOC_NBR
			,d.FMT_Book_Page
			,d.recording_date
			,d.SRC_TBL
			,d.ORIGINAL_APN
			,d.ref_id
		INTO [lien_dtdb].[tmp].[Temp_deed]
		FROM [lien_dtdb].[tmp].[deed_refids] a WITH (
				NOLOCK
				,INDEX (idx_fips_ref_id)
				)
		LEFT JOIN [deed].[dbo].[deed] d WITH (
				NOLOCK
				,INDEX (Idx_Deed_Fips_RefID_RecordDate_Include)
				) ON d.fips = a.fips
			AND d.ref_id = a.ref_id
			AND d.source_type IN (
				'e'
				,'m'
				)
		WHERE d.deedid IS NOT NULL
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	/****** Object:  Index [idx_recording_method]    Script Date: 5/20/2024 3:18:04 PM ******/
	CREATE CLUSTERED INDEX [idx_recording_method] ON [lien_dtdb].[tmp].[Temp_deed] (
		[FIPS] ASC
		,[RECORDING_DATE] ASC
		,[FMT_DOC_NBR] ASC
		,[FMT_Book_Page] ASC
		,[SRC_TBL] ASC
		,[REF_ID] ASC
		,[ORIGINAL_APN] ASC
		)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				) ON [Primary]

	-- select * from lien_dtdb.tmp.Temp_deed
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.ref_id
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_recording_method)
					)
			INNER JOIN [lien_dtdb].[tmp].[Temp_deed] b WITH (
					NOLOCK
					,INDEX (idx_recording_method)
					) ON b.FIPS = a.FIPS
				AND isnull(b.FMT_DOC_NBR, '') = isnull(a.FMT_DOC_NBR, '')
				AND isnull(b.FMT_Book_Page, '') = isnull(a.FMT_Book_Page, '')
				AND isnull(b.recording_date, '') = isnull(a.recording_date, '')
				AND b.SRC_TBL = a.SRC_TBL
				--AND isnull(b.ORIGINAL_APN, '') = isnull(a.ORIGINAL_APN, '')
				AND isnull(b.ref_id, 0) = isnull(a.ref_id, 0)
				AND a.ref_id > 0
			WHERE b.CLGX_UNIQUE_ID IS NOT NULL
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[deed_clgx] (deedid)

	--
	--apn
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_orig_apn]
		SELECT fips
			,ORIGINAL_APN
		INTO [lien_dtdb].[tmp].[deed_orig_apn]
		FROM [lien_DTDB].[INFC].[deed_Work]
		WHERE isnull(ref_id, 0) = 0
			AND nullif(ORIGINAL_APN, '') IS NOT NULL

	CREATE INDEX idx_fips_ref_id ON [lien_dtdb].[tmp].[deed_orig_apn] (
		fips
		,ORIGINAL_APN
		)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[Temp_deed_org_apn]
		SELECT b.CLGX_UNIQUE_ID
			,b.deedid
			,b.fips
			,b.FMT_DOC_NBR
			,b.FMT_Book_Page
			,b.recording_date
			,b.SRC_TBL
			,b.ORIGINAL_APN
			,b.ORIGINAL_SITE_ADDRESS
			,b.ref_id
		INTO [lien_dtdb].[tmp].[Temp_deed_org_apn]
		FROM [lien_dtdb].[tmp].[deed_orig_apn] a WITH (NOLOCK)
		LEFT JOIN [deed].[dbo].[deed] b WITH (NOLOCK) ON b.fips = a.fips
			AND b.ORIGINAL_APN = a.ORIGINAL_APN
		WHERE b.deedid IS NOT NULL
			AND b.ref_id IS NULL
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE CLUSTERED INDEX [idx_recording_method] ON [lien_dtdb].[tmp].[Temp_deed_org_apn] (
		[FIPS] ASC
		,[RECORDING_DATE] ASC
		,[FMT_DOC_NBR] ASC
		,[FMT_Book_Page] ASC
		,[SRC_TBL] ASC
		,[ORIGINAL_APN] ASC
		)
		WITH (
				PAD_INDEX = OFF
				,STATISTICS_NORECOMPUTE = OFF
				,SORT_IN_TEMPDB = OFF
				,DROP_EXISTING = OFF
				,ONLINE = OFF
				,ALLOW_ROW_LOCKS = ON
				,ALLOW_PAGE_LOCKS = ON
				,FILLFACTOR = 85
				) ON [PRIMARY]

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_2]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_2]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_recording_method)
					) --with(nolock,index(idx_deedid)) --
			INNER JOIN [lien_dtdb].[tmp].[Temp_deed_org_apn] b WITH (
					NOLOCK
					,INDEX (idx_recording_method)
					) ON b.fips = a.fips
				AND isnull(b.FMT_DOC_NBR, '') = isnull(a.FMT_DOC_NBR, '')
				AND isnull(b.FMT_Book_Page, '') = isnull(a.FMT_Book_Page, '')
				AND isnull(b.recording_date, '') = isnull(a.recording_date, '')
				AND b.SRC_TBL = a.SRC_TBL
				AND isnull(b.ORIGINAL_APN, '') = isnull(a.ORIGINAL_APN, '')
				AND isnull(b.ORIGINAL_SITE_ADDRESS, '') = isnull(a.ORIGINAL_SITE_ADDRESS, '')
				AND isnull(b.ref_id, 0) = 0
				AND isnull(a.ref_id, 0) = 0
			WHERE a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx]
					)
				AND b.CLGX_UNIQUE_ID IS NOT NULL
				AND b.ref_id IS NULL
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--
	--no ref_id or apn or address 
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_orig_no_prop_info]
		SELECT fips
			,ur_doc_id
			,deedid
		INTO [lien_dtdb].[tmp].[deed_orig_no_prop_info]
		FROM [lien_DTDB].[INFC].[deed_Work] b
		WHERE isnull(ref_id, 0) = 0
			AND nullif(ORIGINAL_APN, '') IS NULL
			AND nullif(b.ORIGINAL_SITE_ADDRESS, '') IS NULL

	--select top 100 * from lien_DTDB.INFC.deed_Work
	CREATE INDEX idx_ur_doc_id ON [lien_dtdb].[tmp].[deed_orig_no_prop_info] (ur_doc_id)

	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[deed_orig_no_prop_info] (deedid)

	--DROP TABLE
	--IF EXISTS lien_dtdb.tmp.Temp_deed_no_prop_info
	--	SELECT b.CLGX_UNIQUE_ID
	--		,b.deedid
	--		,b.fips
	--		,b.FMT_DOC_NBR
	--		,b.FMT_Book_Page
	--		,b.recording_date
	--		,b.SRC_TBL
	--		,b.ORIGINAL_APN
	--		,b.ORIGINAL_SITE_ADDRESS
	--		,b.ref_id
	--	INTO lien_dtdb.tmp.Temp_deed_org_apn
	--	FROM lien_dtdb.tmp.deed_orig_apn a WITH (NOLOCK)
	--	LEFT JOIN deed.dbo.deed b WITH (NOLOCK) ON b.fips = a.fips
	--		AND b.ORIGINAL_APN = a.ORIGINAL_APN
	--	WHERE b.deedid IS NOT NULL
	--		AND b.ref_id IS NULL
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);
	--CREATE CLUSTERED INDEX [idx_recording_method] ON lien_dtdb.tmp.Temp_deed_org_apn (
	--	[FIPS] ASC
	--	,[RECORDING_DATE] ASC
	--	,[FMT_DOC_NBR] ASC
	--	,[FMT_Book_Page] ASC
	--	,[SRC_TBL] ASC
	--	,[ORIGINAL_APN] ASC
	--	)
	--	WITH (
	--			PAD_INDEX = OFF
	--			,STATISTICS_NORECOMPUTE = OFF
	--			,SORT_IN_TEMPDB = OFF
	--			,DROP_EXISTING = OFF
	--			,ONLINE = OFF
	--			,ALLOW_ROW_LOCKS = ON
	--			,ALLOW_PAGE_LOCKS = ON
	--			,FILLFACTOR = 85
	--			) ON [PRIMARY]
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_3]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_3]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_deedid)
					) --with(nolock,index(idx_deedid)) --
			INNER JOIN [lien_dtdb].[tmp].[deed_orig_no_prop_info] aa ON aa.deedid = a.deedid
			INNER JOIN [deed].[dbo].[deed] b WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					) ON b.ur_doc_id = aa.ur_doc_id
			WHERE isnull(b.ref_id, 0) = 0
				AND nullif(b.ORIGINAL_APN, '') IS NULL
				AND nullif(b.ORIGINAL_SITE_ADDRESS, '') IS NULL
				AND a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_2]
					)
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--select * from lien_dtdb.tmp.deed_clgx_3
	--select fips,CLGX_UNIQUE_ID, count(1) as cnt
	--from (
	--select fips,CLGX_UNIQUE_ID from  lien_dtdb.tmp.deed_clgx
	--union all
	--select fips, CLGX_UNIQUE_ID from  lien_dtdb.tmp.deed_clgx_2
	--) a
	--group by fips,CLGX_UNIQUE_ID
	--having count(1) > 1
	--select * from  lien_dtdb.tmp.deed_clgx where  CLGX_UNIQUE_Id = 2017060100525
	--select FIPS
	--,FMT_DOC_NBR
	--,FMT_Book_Page
	--,recording_date
	--,SRC_TBL
	--,ORIGINAL_APN
	--,ref_id
	--,ORIGINAL_SITE_ADDRESS
	--,*
	--from lien_dtdb.infc.deed_work where deedid in (244067, 262164)
	--mp Start---------------------------------------------------------
	--
	-- Ref_Id on Input, but No Ref_id On Deed - Must match on Docid, recording date and confirm on Recording_date, docnbr, bkpg, apn or address 
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_NorefID_Confirm_Fields]
		SELECT fips
			,ur_doc_id
			,deedid
		INTO [lien_dtdb].[tmp].[deed_NorefID_Confirm_Fields]
		FROM [lien_DTDB].[INFC].[deed_Work] b
		WHERE b.deedid NOT IN (
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx_2]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx_3]
				)

	CREATE INDEX idx_ur_doc_id ON [lien_dtdb].[tmp].[deed_NorefID_Confirm_Fields] (ur_doc_id)

	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[deed_NorefID_Confirm_Fields] (deedid)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_4]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_4]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_deedid)
					)
			INNER JOIN [lien_dtdb].[tmp].[deed_NorefID_Confirm_Fields] aa WITH (
					NOLOCK
					,INDEX (idx_deedid)
					) ON aa.deedid = a.deedid
			INNER JOIN [deed].[dbo].[deed] b WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					) ON b.ur_doc_id = aa.ur_doc_id
			WHERE isnull(a.ref_id, 0) > 0
				AND isnull(b.ref_id, 0) = 0
				AND b.SRC_TBL = a.SRC_TBL
				AND isnull(b.recording_date, '') = isnull(a.recording_date, '')
				AND isnull(b.FMT_DOC_NBR, '') = isnull(a.FMT_DOC_NBR, '')
				AND isnull(a.FMT_DOC_NBR, '') > ''
				AND (
					(
						isnull(b.ORIGINAL_APN, '') = isnull(a.ORIGINAL_APN, '')
						AND isnull(a.ORIGINAL_APN, '') > ''
						)
					OR (
						isnull(b.ORIGINAL_SITE_ADDRESS, '') = isnull(a.ORIGINAL_SITE_ADDRESS, '')
						AND isnull(a.ORIGINAL_SITE_ADDRESS, '') > ''
						)
					)
				AND a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_2]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_3]
					)
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--select * from lien_dtdb.tmp.deed_clgx_4
	--
	-- No Ref_Id on Input, No Ref_id On Deed  
	--
	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_NorefID_NoApn_NoAddr]
		SELECT fips
			,ur_doc_id
			,deedid
		INTO [lien_dtdb].[tmp].[deed_NorefID_NoApn_NoAddr]
		FROM [lien_DTDB].[INFC].[deed_Work] b
		WHERE ISNULL(b.ref_id, 0) = 0
			AND isnull(b.ORIGINAL_APN, '') = ''
			AND isnull(b.ORIGINAL_SITE_ADDRESS, '') = ''
			AND b.deedid NOT IN (
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx_2]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx_3]
				
				UNION ALL
				
				SELECT deedid
				FROM [lien_dtdb].[tmp].[deed_clgx_4]
				)

	CREATE INDEX idx_ur_doc_id ON [lien_dtdb].[tmp].[deed_NorefID_NoApn_NoAddr] (ur_doc_id)

	CREATE INDEX idx_deedid ON [lien_dtdb].[tmp].[deed_NorefID_NoApn_NoAddr] (deedid)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_5]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_5]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_deedid)
					)
			INNER JOIN [lien_dtdb].[tmp].[deed_NorefID_NoApn_NoAddr] aa WITH (
					NOLOCK
					,INDEX (idx_deedid)
					) ON aa.deedid = a.deedid
			INNER JOIN [deed].[dbo].[deed] b WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					) ON b.ur_doc_id = aa.ur_doc_id
			WHERE isnull(a.ref_id, 0) = 0
				AND isnull(b.ref_id, 0) = 0
				AND b.SRC_TBL = a.SRC_TBL
				AND isnull(a.recording_date, '') = isnull(b.recording_date, '')
				AND isnull(a.ORIGINAL_APN, '') = ''
				AND isnull(b.ORIGINAL_APN, '') = ''
				AND isnull(a.ORIGINAL_SITE_ADDRESS, '') = ''
				AND isnull(b.ORIGINAL_SITE_ADDRESS, '') = ''
				AND a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_2]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_3]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_4]
					)
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	--mp End---------------------------------------------------------
	CREATE INDEX idx_ur_doc_id ON [lien_dtdb].[tmp].[deed_clgx] (
		ur_doc_id
		,fips
		,UR_Prop_Seq_Num
		,SRC_TBL
		,Deedid
		)

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_6]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_6]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_deedid)
					)
			--INNER JOIN lien_dtdb.tmp.deed_NorefID_NoApn_NoAddr aa WITH (
			--		NOLOCK
			--		,INDEX (idx_deedid)
			--		) ON aa.deedid = a.deedid
			INNER JOIN [deed].[dbo].[deed] b WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					) ON b.ur_doc_id = a.ur_doc_id
			WHERE isnull(a.ref_id, 0) <> isnull(b.ref_id, 0)
				AND isnull(a.ref_id, 0) > 0
				AND isnull(b.ref_id, 0) > 0
				--and b.deedid = 528273691
				AND b.SRC_TBL = a.SRC_TBL
				AND isnull(a.recording_date, '') = isnull(b.recording_date, '')
				AND (
					(
						isnull(a.ORIGINAL_APN, '') = isnull(b.ORIGINAL_APN, '')
						AND isnull(b.ORIGINAL_APN, '') > ''
						)
					OR (
						isnull(a.ORIGINAL_SITE_ADDRESS, '') = isnull(b.ORIGINAL_SITE_ADDRESS, '')
						AND isnull(b.ORIGINAL_SITE_ADDRESS, '') > ''
						)
					)
				AND a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_2]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_3]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_4]
					
					UNION ALL
					
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_5]
					)
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx] (Deedid)

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_2] (Deedid)

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_3] (deedid)

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_4] (deedid)

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_5] (deedid)

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_6] (deedid)

	--select * from lien_dtdb.tmp.deed_clgx
	--select * from lien_dtdb.tmp.deed_clgx_2
	--select * from lien_dtdb.tmp.deed_clgx_3
	--select * from lien_dtdb.tmp.deed_clgx_4
	--select * from lien_dtdb.tmp.deed_clgx_5
	-- select CLGX_UNIQUE_ID,  * from   lien_dtdb.tmp.deed_clgx where CLGX_UNIQUE_ID = null
	--where ref_id is null
	----where UR_Prop_Seq_Num is null
	--select ur_doc_id,fips,ref_id,UR_Prop_Seq_Num,SRC_TBL,CLGX_UNIQUE_ID , * from lien_dtdb.infc.deed_work  where fips = 28047 and ur_doc_id = 179957407 and UR_Prop_Seq_Num = 10
	--select ur_doc_id,fips,ref_id,UR_Prop_Seq_Num,SRC_TBL,CLGX_UNIQUE_ID ,* from deed.dbo.deed where fips = 28047 and ur_doc_id = 179957407 and UR_Prop_Seq_Num = 10
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_2] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_3] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--mp start--------------------
	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_4] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_5] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_6] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	DROP TABLE

	IF EXISTS [lien_dtdb].[tmp].[deed_clgx_7]
		SELECT b.*
		INTO [lien_dtdb].[tmp].[deed_clgx_7]
		FROM (
			SELECT a.Deedid
				,a.ur_doc_id
				,a.fips
				,a.UR_Prop_Seq_Num
				,a.SRC_TBL
				,b.CLGX_UNIQUE_ID
				,b.deedid AS b_deedid
				,a.ORIGINAL_APN
				,a.ORIGINAL_SITE_ADDRESS
				,a.ref_id
				,ROW_NUMBER() OVER (
					PARTITION BY a.Deedid ORDER BY a.ur_doc_id
					) AS ROW4
			FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
					NOLOCK
					,INDEX (idx_deedid)
					)
			INNER JOIN [deed].[dbo].[deed] b WITH (
					NOLOCK
					,INDEX (idx_ur_doc_id)
					) ON b.ur_doc_id = a.ur_doc_id
			WHERE isnull(a.ref_id, 0) = 0
				AND isnull(b.ref_id, 0) = 0
				AND b.SRC_TBL = a.SRC_TBL
				AND isnull(b.recording_date, '') = isnull(a.recording_date, '')
				AND isnull(b.FMT_DOC_NBR, '') = isnull(a.FMT_DOC_NBR, '')
				AND isnull(b.FMT_Book_Page, '') = isnull(a.FMT_Book_Page, '')
				AND (
					(isnull(b.ORIGINAL_APN, '') = isnull(a.ORIGINAL_APN, ''))
					AND (isnull(b.ORIGINAL_SITE_ADDRESS, '') = isnull(a.ORIGINAL_SITE_ADDRESS, ''))
					)
				AND a.deedid NOT IN (
					SELECT deedid
					FROM [lien_dtdb].[tmp].[deed_clgx_6]
					)
				AND a.CLGX_UNIQUE_ID IS NULL
			) b
		WHERE b.row4 = 1
		OPTION (
			RECOMPILE
			,MAXDOP 12
			,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
			);

	CREATE INDEX idx_b_deed_id ON [lien_dtdb].[tmp].[deed_clgx_7] (deedid)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.CLGX_UNIQUE_ID --+ (ROW4 - 1)
	FROM [lien_DTDB].[INFC].[deed_Work] a WITH (
			NOLOCK
			,INDEX (idx_deedid)
			)
	INNER JOIN [lien_dtdb].[tmp].[deed_clgx_7] b WITH (
			NOLOCK
			,INDEX (idx_b_deed_id)
			) ON b.Deedid = a.Deedid
	OPTION (
		RECOMPILE
		,MAXDOP 12
		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
		);

	--
	-- get highest number from deed and deedwork so that we can assign new clgx nubmers
	--
	DROP TABLE

	IF EXISTS [lien_DTDB].[tmp].[fips_clgx_deed]
		SELECT a.*
			,b.*
			,right('00' + try_cast(a.fips AS VARCHAR(5)), 5) AS Fips_a
		INTO [lien_DTDB].[tmp].[fips_clgx_deed]
		FROM (
			SELECT DISTINCT Fips
			FROM [lien_DTDB].[infc].[Deed_work] a
			) a
		OUTER APPLY (
			SELECT CASE 
					WHEN b.CLGX_UNIQUE_ID IS NULL
						THEN CASE 
								WHEN len(fips) = 5
									THEN try_cast(try_cast(a.fips AS VARCHAR(5)) + try_cast('000000001' AS VARCHAR) AS DECIMAL(15, 0))
								ELSE try_cast(try_cast(a.fips AS VARCHAR(5)) + try_cast('0000000001' AS VARCHAR) AS DECIMAL(15, 0))
								END
					ELSE b.CLGX_UNIQUE_ID
					END AS CLGX_UNIQUE_ID
			FROM (
				SELECT max(CLGX_UNIQUE_ID) AS CLGX_UNIQUE_ID
				FROM (
					SELECT max(c.CLGX_UNIQUE_ID) AS CLGX_UNIQUE_ID
					FROM (
						SELECT max(CLGX_UNIQUE_ID) AS CLGX_UNIQUE_ID
						FROM [lien_DTDB].[infc].[Deed_work] b
						WHERE b.fips = a.fips
						
						UNION ALL
						
						SELECT max(CLGX_UNIQUE_ID) AS CLGX_UNIQUE_ID
						FROM [Deed].[dbo].[deed] b
						WHERE b.fips = a.fips
						) c
					) b0
				) b
			) b

	CREATE CLUSTERED INDEX idx_fips ON [lien_DTDB].[tmp].[fips_clgx_deed] (fips)

	DROP TABLE

	IF EXISTS [lien_DTDB].[tmp].[Deed_work_a]
		SELECT a.deedid
			,fips
			,start_CLGX_UNIQUE_id + row4 AS new_CLGX_UNIQUE_ID
			,row4
		INTO [lien_DTDB].[tmp].[Deed_work_a]
		FROM (
			SELECT ROW_NUMBER() OVER (
					PARTITION BY a.fips ORDER BY (
							SELECT 0
							)
					) AS ROW4
				,b.CLGX_UNIQUE_ID AS start_CLGX_UNIQUE_id
				,b.fips
				,a.deedid
			FROM [lien_DTDB].[INFC].[Deed_work] a
			INNER JOIN [lien_DTDB].[tmp].[fips_clgx_deed] b ON b.fips = a.fips
			WHERE a.CLGX_UNIQUE_ID IS NULL
			) a

	CREATE CLUSTERED INDEX idx_mtgid ON [lien_DTDB].[tmp].[Deed_work_a] (deedid)

	UPDATE [lien_DTDB].[INFC].[a]
	SET a.CLGX_UNIQUE_ID = b.new_CLGX_UNIQUE_ID
	FROM [lien_DTDB].[INFC].[Deed_work] a
	INNER JOIN [lien_DTDB].[tmp].[Deed_work_a] b ON b.deedid = a.deedid

	--
	--Detemin Multi APn flag
	--
	--DROP TABLE
	--IF EXISTS lien_dtdb.tmp.US641335_Multi_apn
	--	SELECT *
	--	INTO lien_dtdb.tmp.US641335_Multi_apn
	--	FROM [LIEN_DTDB].[INFC].[Deed_Work]
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);
	--CREATE INDEX idx_deedid ON lien_dtdb.tmp.US641335_Multi_apn (deedid)
	--
	-- get the sort parms for the records on the deed_work so that we can detemine the row_number
	--
	--DROP TABLE

	--IF EXISTS lien_dtdb.tmp.Multi_apn_temp1
	--	SELECT a.ur_doc_id
	--		,d.*
	--		,ROW_NUMBER() OVER (
	--			PARTITION BY d.fips_code
	--			,d.Instrument_nbr
	--			,d.recording_date_d
	--			,d.doc_type
	--			,d.cmt_id
	--			,a.FMT_DOC_NBR
	--			,a.FMT_Book_Page ORDER BY ur_doc_id
	--				,ref_id
	--				,ORIGINAL_APN
	--				,ORIGINAL_SITE_ADDRESS
	--			) AS ROW4
	--		,a.deedid
	--		,a.fips
	--		,a.ref_id
	--	INTO lien_dtdb.tmp.Multi_apn_temp1
	--	FROM Lien_dtdb.infc.deed_work a
	--	OUTER APPLY (
	--		SELECT d.fips_code
	--			,d.Instrument_nbr
	--			,d.recording_date_d
	--			,d.doc_type
	--			,d.cmt_id
	--		FROM lien.ur.document d WITH (
	--				NOLOCK
	--				,INDEX (PK_DOCUMENT)
	--				)
	--		WHERE doc_id = a.ur_doc_id
	--		) d
	--	WHERE a.source_type IN (
	--			'e'
	--			,'M'
	--			)
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);

	--CREATE INDEX idx_multi ON lien_dtdb.tmp.Multi_apn_temp1 (
	--	fips_code
	--	,Instrument_nbr
	--	,recording_date_d
	--	,doc_type
	--	,cmt_id
	--	)

	----
	----identify records that have multiple occurences on the deed work for the same document
	----
	--DROP TABLE

	--IF EXISTS lien_dtdb.tmp.Multi_apn_temp2
	--	SELECT DISTINCT d.fips_code
	--		,d.Instrument_nbr
	--		,d.recording_date_d
	--		,d.doc_type
	--		,d.cmt_id
	--	INTO lien_dtdb.tmp.Multi_apn_temp2
	--	FROM lien_dtdb.tmp.Multi_apn_temp1 d
	--	WHERE row4 > 1
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);

	--CREATE INDEX idx_multi ON lien_dtdb.tmp.Multi_apn_temp2 (
	--	fips_code
	--	,Instrument_nbr
	--	,recording_date_d
	--	,doc_type
	--	,cmt_id
	--	)

	----
	---- assign the M or D so that we can set the multi_apn flag
	----
	--DROP TABLE

	--IF EXISTS lien_dtdb.tmp.Multi_apn_temp2_apn
	--	SELECT c.deedid
	--		,CASE 
	--			WHEN c.row4 = 1
	--				THEN 'M'
	--			ELSE 'D'
	--			END AS Multi_apn
	--	INTO lien_dtdb.tmp.Multi_apn_temp2_apn
	--	FROM (
	--		SELECT b.*
	--		FROM lien_dtdb.tmp.Multi_apn_temp2 a WITH (
	--				NOLOCK
	--				,INDEX (idx_multi)
	--				)
	--		INNER JOIN lien_dtdb.tmp.Multi_apn_temp1 b WITH (
	--				NOLOCK
	--				,INDEX (idx_multi)
	--				) ON b.fips_code = a.fips_code
	--			AND b.Instrument_nbr = a.Instrument_nbr
	--			AND b.recording_date_d = a.recording_date_d
	--			AND b.doc_type = a.doc_type
	--			AND isnull(b.cmt_id, 0) = isnull(a.cmt_id, 0)
	--		) c
	--	ORDER BY c.fips_code
	--		,c.Instrument_nbr
	--		,c.recording_date_d
	--		,c.doc_type
	--		,c.cmt_id
	--		,c.ROW4
	--	OPTION (
	--		RECOMPILE
	--		,MAXDOP 12
	--		,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--		);

	--CREATE INDEX idx_deedid ON lien_dtdb.tmp.Multi_apn_temp2_apn (deedid)

	----select a.deedid, a.Multi_apn
	----from lien_dtdb.tmp.Multi_apn_temp2_apn a with(nolock,index(idx_deedid)) 
	----inner join Lien_dtdb.infc.deed_work d with(nolock,index(idx_deedid)) on d.deedid = a.deedid
	----where isnull(d.multi_apn,'') <> isnull(a.multi_apn,'')
	--UPDATE d
	--SET d.multi_apn = a.multi_apn
	--FROM lien_dtdb.tmp.Multi_apn_temp2_apn a WITH (
	--		NOLOCK
	--		,INDEX (idx_deedid)
	--		)
	--INNER JOIN Lien_dtdb.infc.deed_work d WITH (
	--		NOLOCK
	--		,INDEX (idx_deedid)
	--		) ON d.deedid = a.deedid
	--WHERE isnull(d.multi_apn, '') <> isnull(a.multi_apn, '')
	--OPTION (
	--	RECOMPILE
	--	,MAXDOP 12
	--	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	--	);

	EXEC [lien_DTDB].[INFC].[AddINFCLog] N'info'
		,N'UR_Merge_Deed_To_Mtg_New'
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


