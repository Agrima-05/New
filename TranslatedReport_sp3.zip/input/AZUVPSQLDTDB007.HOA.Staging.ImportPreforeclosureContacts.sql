/* Source: AZUVNSQLDTDB003.datatree.local | HOA | Staging.ImportPreforeclosureContacts | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */
CREATE PROCEDURE [HOA].[Staging].[ImportPreforeclosureContacts]
AS

