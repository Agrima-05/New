/* Source: AZUVNSQLDTDB003.datatree.local | Listings | pet_mtc.usp_Situs_Pet_Match_Input | type=P | staged_for_host_folder=AZUVPSQLDTDB007.datatree.local (package runs on AZUVPSQLDTDB007.datatree.local / execution SQL) */

CREATE PROCEDURE [Listings].[pet_mtc].[usp_Situs_Pet_Match_Input] @fileid INT
	,@ERROR VARCHAR(500) OUTPUT
AS
/******************************************************************************************************************
CHANGE LOG:
==========
who		date		change
Marie	2025/01/31	Initial Creation


Notes 
1. the where clause need to limit the data to the daily input

DECLARE @Error_Msg varchar(500),
		@ERROR varchar(500)

EXEC	Listings.Listings_dbo.usp_Combine_Daily_Adds_and_Snapshot
		@ERROR = @ERROR OUTPUT

 SET  @Error_Msg = @ERROR

--SELECT ? = @Error_Msg 


******************************************************************************************************************/
--declare @fileid INT = 1 ,@ERROR VARCHAR(500) --OUTPUT
BEGIN TRY
	DECLARE @msg VARCHAR(500) = 'usp_Situs_Pet_Match_Input: ' + try_cast(@fileid AS VARCHAR(20))

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Started'

	--EXEC PET_Match_Service.[pet_mtc].[Add_match_Log] N'info'
	--	,@msg
	--	,N'Started'
	--
	-- here the logic start that you  want to run by fips
	--
	--DECLARE @fileid INT = ?
	TRUNCATE TABLE [Listings].[listings_tmp].[Situs_Std_Address]

	TRUNCATE TABLE [LISTINGS].[listings_tmp].[Situs_Std_Address_Result]

	INSERT INTO [Listings].[listings_tmp].[Situs_Std_Address] (
		[Fileid]
		,[ID]
		,[FIPS]
		,[legal_desc_address]
		,[legal_desc_address_city]
		,[legal_desc_address_state]
		,[legal_desc_address_zip]
		,[legal_desc_map_unit_low]
		,[Raw_Address]
		,[HouseNumber]
		,[Street_Number]
		,[Direction]
		,[Street_Name]
		,[Street_Type]
		,[Post_Direction]
		,[Unit_Type]
		,[Unit]
		,[City]
		,[State]
		,[Zip]
		,[Plus4]
		,[CRRT]
		,[CountyName]
		,[PMB]
		,[PMSA]
		,[MSA]
		,[ZipType]
		,[Urbanization]
		,[CongressionalDistrict]
		,[CountryCode]
		,[CityAbbreviation]
		,[AddressTypeCode]
		,[AddressTypeString]
		,[DPV_Count]
		,[DPV_Footnotes]
		,[CMRA]
		,[ELOT_Number]
		,[ELOT_Order]
		,[LACS]
		,[LACS_LinkIndicator]
		,[EWS_Flag]
		,[RBDI]
		,[SuiteLinkReturnCode]
		,[DeliveryPointCheckDigit]
		,[DeliveryPointCode]
		,[CensusBlock]
		,[CensusTract]
		,[PlaceCode]
		,[PlaceName]
		,[CBSACode]
		,[CBSALevel]
		,[CBSATitle]
		,[CBSADivisionCode]
		,[CBSADivisionLevel]
		,[CBSADivisionTitle]
		,[Latitude]
		,[Longitude]
		,[Verified]
		,[Geocoded]
		,[AddressMatchResults]
		,[GeoErrorCode]
		,[GeoStatusCode]
		,[AddressType]
		,[sf_address]
		,[Ref_id]
		,[Match_code]
		,[Use_Actual_Fips]
		)
	SELECT @fileid AS Fileid
		,a.Row_id AS [ID]
		,a.fips AS [FIPS]
		,p.[legal_desc_address] AS [legal_desc_address]
		,p.[legal_desc_address_city] AS [legal_desc_address_city]
		,p.[legal_desc_address_state] AS [legal_desc_address_state]
		,p.[legal_desc_address_zip] AS [legal_desc_address_zip]
		,p.[legal_desc_map_unit_low] AS [legal_desc_map_unit_low]
		--,REPLACE(ltrim(rtrim(Street_Number)) + ' ' + ltrim(rtrim(Direction)) + ' ' + ltrim(rtrim(Street_Name)) + ' ' + ltrim(rtrim(Street_Type)) + ' ' + ltrim(rtrim(Post_Direction))+ ' ' + ltrim(rtrim([City])) + ' ' + ltrim(rtrim([State]))+ ' ' + ltrim(rtrim([Zip])),'  ',' ') 
		--as [Raw_Address]
		,substring(replace(Replace(P.legal_desc_address + ' ,' + isnull(P.legal_desc_address_city, '') + ' ,' + isnull(P.legal_desc_address_state, '') + ' ,' + isnull(P.legal_desc_address_zip, ''), 'NUll', ''), '  ', ''), 1, 200) AS Raw_Address
		,a.[HouseNumber] AS [HouseNumber]
		,a.[Street_Number] AS [Street_Number]
		,a.[Direction] AS [Direction]
		,a.[Street_Name] AS [Street_Name]
		,a.[Street_Type] AS [Street_Type]
		,a.[Post_Direction] AS [Post_Direction]
		,a.[Unit_Type] AS [Unit_Type]
		,a.[Unit] AS [Unit]
		,a.[City] AS [City]
		,a.[std_State] AS [State]
		,a.[Zip] AS [Zip]
		,a.[Plus4] AS [Plus4]
		,a.[CRRT] AS [CRRT]
		,a.[CountyName] AS [CountyName]
		,a.[PMB] AS [PMB]
		,a.[PMSA] AS [PMSA]
		,a.[MSA] AS [MSA]
		,a.[ZipType] AS [ZipType]
		,a.[Urbanization] AS [Urbanization]
		,a.[CongressionalDistrict] AS [CongressionalDistrict]
		,a.[CountryCode] AS [CountryCode]
		,a.[CityAbbreviation] AS [CityAbbreviation]
		,a.[AddressTypeCode] AS [AddressTypeCode]
		,a.[AddressTypeString] AS [AddressTypeString]
		,a.[DPV_Count] AS [DPV_Count]
		,a.[DPV_Footnotes] AS [DPV_Footnotes]
		,a.[CMRA] AS [CMRA]
		,a.[ELOT_Number] AS [ELOT_Number]
		,a.[ELOT_Order] AS [ELOT_Order]
		,a.[LACS] AS [LACS]
		,a.[LACS_LinkIndicator] AS [LACS_LinkIndicator]
		,a.[EWS_Flag] AS [EWS_Flag]
		,a.[RBDI] AS [RBDI]
		,a.[SuiteLinkReturnCode] AS [SuiteLinkReturnCode]
		,a.[DeliveryPointCheckDigit] AS [DeliveryPointCheckDigit]
		,a.[DeliveryPointCode] AS [DeliveryPointCode]
		,a.[CensusBlock] AS [CensusBlock]
		,a.[CensusTract] AS [CensusTract]
		,a.[PlaceCode] AS [PlaceCode]
		,a.[PlaceName] AS [PlaceName]
		,a.[CBSACode] AS [CBSACode]
		,a.[CBSALevel] AS [CBSALevel]
		,a.[CBSATitle] AS [CBSATitle]
		,a.[CBSADivisionCode] AS [CBSADivisionCode]
		,a.[CBSADivisionLevel] AS [CBSADivisionLevel]
		,a.[CBSADivisionTitle] AS [CBSADivisionTitle]
		,a.[Latitude] AS [Latitude]
		,a.[Longitude] AS [Longitude]
		,a.[Verified] AS [Verified]
		,a.[Geocoded] AS [Geocoded]
		,a.[AddressMatchResults] AS [AddressMatchResults]
		,a.[GeoErrorCode] AS [GeoErrorCode]
		,a.[GeoStatusCode] AS [GeoStatusCode]
		,a.Addr_type AS [AddressType]
		,SUBSTRING(REPLACE(ltrim(rtrim(Street_Number)) + ' ' + ltrim(rtrim(Direction)) + ' ' + ltrim(rtrim(Street_Name)) + ' ' + ltrim(rtrim(Street_Type)) + ' ' + ltrim(rtrim(Post_Direction)), '  ', ' '), 1, 10) AS [sf_address]
		,NULL AS [Ref_id]
		,NULL AS [Match_code]
		,0 AS [Use_Actual_Fips]
	FROM [LISTINGS].[Listings_tmp].[Listings_Raw_Std_Address_wrk] a
	OUTER APPLY (
		SELECT a.[Raw_HOUSE_NBR] + [Raw_STREET] AS legal_desc_address
			,a.[Raw_CITY] AS legal_desc_address_city
			,a.[Raw_STATE] AS legal_desc_address_state
			,a.[Raw_ZIP] AS legal_desc_address_zip
			,a.unit AS legal_desc_map_unit_low
		) p
	ORDER BY a.row_id DESC

	EXEC [Listings].[listings_dbo].[ListingsLog] N'info'
		,@msg
		,N'Ended'
END TRY

BEGIN CATCH
	SET @ERROR = ERROR_MESSAGE() + CHAR(10) + ISNULL(OBJECT_SCHEMA_NAME(@@PROCID), '') + '.' + ISNULL(OBJECT_NAME(@@PROCID), '') + ' - Error at line ' + CONVERT(VARCHAR, ERROR_LINE())

	--ROLLBACK
	RAISERROR (
			@ERROR
			,16
			,1
			)
END CATCH


