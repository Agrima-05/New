SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE Proc [dbo].[GetAddressTriggerList]
AS
BEGIN
	Declare @tab as Table (TriggerId int
							, AppId int
							, AppName Varchar(25)
							, TableName Varchar(50)
							, InputSPName Varchar(100)
							, PostSPName Varchar(100)
							, ProcessTypeCode Char(1)
							, Process_Flag Char(1)
							, CreatedDateTime DateTime
							, LastUpdatedDateTime DateTime
							, CompletedDateTime DateTime)

	Insert Into @tab (TriggerId, AppId, AppName, TableName, ProcessTypeCode, Process_Flag, CreatedDateTime
						, LastUpdatedDateTime, CompletedDateTime, InputSPName, PostSPName)
	Select Top 4 T.TriggerId, A.AppId, A.AppName, T.TableName, T.ProcessTypeCode, T.Process_Flag, T.CreatedDateTime
						, T.LastUpdatedDateTime, T.CompletedDateTime
						, (Select Top 1 SPS.SPName 
							From AddrAppSps as ASP
								Inner Join AddrStoredProcs as SPS
								On Asp.SPID = SPS.SPId
									And SPS.SPType = 'I'
							Where ASP.AppId = A.AppId
								And ASP.ProcessTypeID = PT.ProcessTypeId
							)
						, (Select Top 1 SPS.SPName 
							From AddrAppSps as ASP
								Inner Join AddrStoredProcs as SPS
								On Asp.SPID = SPS.SPId
									And SPS.SPType = 'P'
							Where ASP.AppId = A.AppId
								And ASP.ProcessTypeID = PT.ProcessTypeId
							)
						--, CASE When SPS.SpType = 'I' THEN SPS.SpName ELSE NULL END
						--, CASE When SPS.SpType = 'P' THEN SPS.SpName ELSE NULL END
	From STDTrigger as T
		Inner Join AddrApplication as A
			On T.AppName = A.AppName
		Inner Join AddrProcessType as PT
			On PT.Code = T.ProcessTypeCode
		--Inner Join AddrAppSps as ASP
		--	On ASP.AppId = A.AppId
		--		And ASP.ProcessTypeId = PT.ProcessTypeId
		--Inner Join AddrStoredProcs as SPS
		--	On SPS.SpId = ASP.SpId
	Where T.Process_Flag = 'R'
	
	Update AT
		Set AT.Process_Flag = 'I'
			, AT.LastUpdatedDateTime = GETDATE()
	From @tab as T
		Inner Join STDTrigger as AT
			On T.TriggerId = AT.TriggerId

	Select T.TriggerId
		, T.AppId
		, T.AppName
		, T.TableName
		, T.InputSPName
		, T.PostSPName
		, T.ProcessTypeCode
		, T.Process_Flag as ProcessFlag
		, T.CreatedDateTime
		, T.LastUpdatedDateTime
		, T.CompletedDateTime
	From @tab T
	ORDER BY T.TriggerId ASC
END


