SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- ===============================================================
-- Description:	Roll up Last and Prior Sale data to Property Table
-- ===============================================================
CREATE PROCEDURE [dbo].[d400_last_and_prior_sale_rollup_UPDATE] 
AS
BEGIN

	---- GET Deed Data Needed

	DROP TABLE dbo.[DeedWorkUpdateTbl]

	SELECT d.[FIPS]
      ,[FAPropertyID]
      ,[Loan1Document]
      ,[Loan1Book]
      ,[Loan1Page]
      ,[Loan1RecordingDt]
      ,[Loan1Amount]
      ,[Loan1LenderName]
      ,[Loan1LenderTypeCode]
      ,[Loan1LenderPrivateInd]
      ,[Loan1DueDate]
      ,[Loan1Type]
      ,[Loan1TermMonths]
      ,[Loan1TypeFinance]
      ,[Loan2Document]
      ,[Loan2Book]
      ,[Loan2Page]
      ,[Loan2RecordingDt]
      ,[Loan2Amount]
      ,[Loan2LenderName]
      ,[Loan2LenderTypeCode]
      ,[Loan2LenderPrivateInd]
      ,[Loan2DueDate]
      ,[Loan2Type]
      ,[Loan2TermMonths]
      ,[Loan2TypeFinance]
      ,[TransactionId]
      ,[ChronoKey]
      ,[DocNbrSrce]
	  ,[YearDocNbrFrmt]
      ,[BookSrce]
      ,[PageSrce]
	  ,[BkPgFrmt]
      ,[RecordingDt]
      ,[DocumentTypeCode]
      ,[SalesPrice]
      ,[SalesPriceCode]
      ,[Saledate]
	  ,[DeedTransactionType]
      ,[Buyer1FullName]
      ,[Buyer2FullName]
      ,[Seller1FullName]
      ,[Seller2FullName]
      ,0 as [FASalePosition]
	  ,d.[FASourceInd]
	  ,d.[FAUCIDFlag]
      ,d.[FADateReceived]
      ,[Loan1InterestRate]
      ,[Loan2InterestRate]
      ,[Loan1YearDocNbrFmt]
      ,[Loan1BookPageFmt]
      ,[Loan2YearDocNbrFmt]
      ,[Loan2BookPageFmt]
	INTO dbo.[DeedWorkUpdateTbl]
	From [Data].dbo.[Deed] d with(NOLOCK) JOIN [dbo].[PropertyWorkUpdate]  z with(NOLOCK)
			ON d.FIPS = z.FIPS
				and d.FAPropertyID = z.PropertyID
	WHERE (d.DeedTransactionType in ('2','3','4','5','6','7','8','9')	
				OR (d.DeedTransactionType = 1 and d.SalesPrice > 5000)
					OR (d.FASourceInd = 'X' and isNULL(ltrim(rtrim(DeedTransactionType)),'') like ''))
			AND isNULL(d.FAUCIDFlag,'') != 'D'
	
		CREATE NONCLUSTERED INDEX [ix_Chronokey] ON [dbo].[DeedWorkUpdateTbl]
		([Chronokey] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsPropId] ON [dbo].[DeedWorkUpdateTbl]
		([FIPS] ASC,[FAPropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsTransactionId] ON [dbo].[DeedWorkUpdateTbl]
		([FIPS] ASC,[TransactionId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		UPDATE w
		SET FASalePosition = d.RowNum
		FROM dbo.DeedWork w JOIN (
				SELECT 
				Fips,FAPropertyID,TransactionId,ChronoKey,RecordingDt,
				ROW_NUMBER() OVER(PARTITION BY w.FAPROPERTYID ORDER BY w.CHRONOKEY desc) AS RowNum
			FROM [dbo].[DeedWorkUpdateTbl] w with(nolock)  ) d 
		on w.fips = d.FIPS and w.TransactionId = d.TransactionId
		
		CREATE NONCLUSTERED INDEX [ix_FASalePosition] ON [dbo].[DeedWorkUpdateTbl]
		([FASalePosition] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	---- ADDED 20170131 To Clear OUT Current and Prior data before updates MAS

	UPDATE P
	SET [ConCurrMtg1InputDocNbr]=NULL,
			[ConCurrMtg1InputBook]=NULL,
			[ConCurrMtg1InputPage]=NULL,
			[ConCurrMtg1RecordingDt]=NULL,
			[ConCurrMtg1LoanAmt]=NULL,
			[ConCurrMtg1Lender]=NULL,
			[ConCurrMtg1LenderType]=NULL,
			[ConCurrMtg1PrivateLender]=NULL,
			[ConCurrMtg1LoanDueDt]=NULL,
			[ConCurrMtg1LoanType]=NULL,
			[ConCurrMtg1Term]=NULL,
			[ConCurrMtg1Typefinancing]=NULL,
			[ConCurrMtg1InterestRate]= NULL,
			[ConCurrMtg1FormatDocNbr]= NULL,
			[ConCurrMtg1FormatBook]= NULL,
			[ConCurrMtg1FormatPage]= NULL,
			[ConCurrMtg2FormatDocNbr]= NULL,
			[ConCurrMtg2FormatBook]= NULL,
			[ConCurrMtg2FormatPage]= NULL,
			[ConCurrMtg2InputDocNbr]=NULL,
			[ConCurrMtg2InputBook]=NULL,
			[ConCurrMtg2InputPage]=NULL,
			[ConCurrMtg2RecordingDt]=NULL,
			[ConCurrMtg2LoanAmt]=NULL,
			[ConCurrMtg2Lender]=NULL,
			[ConCurrMtg2LenderType]=NULL,
			[ConCurrMtg2PrivateLender]=NULL,
			[ConCurrMtg2LoanDueDt]=NULL,
			[ConCurrMtg2LoanType]=NULL,
			[ConCurrMtg2Term]=NULL,
			[ConCurrMtg2Typefinancing]=NULL,
			[ConCurrMtg2InterestRate]= NULL,
			[CurrentSaleTransactionId] = NULL,
			[CurrentSaleChronoKey]=NULL,
			[CurrSaleInputDocNbr]=NULL,
			[CurrSaleInputBook]=NULL,
			[CurrSaleInputPage]=NULL,
			[CurrSaleRecordingDate]=NULL,
			[CurrSaleDocumentType] = NULL,
			[CurrSalesPrice]= NULL,
			[CurrSalesPriceCode]=NULL,
			[CurrSaleContractDate]=NULL,
			[CurrSaleBuyer1FullName]=NULL,
			[CurrSaleBuyer2FullName]=NULL,
			[CurrSaleSeller1FullName]=NULL,
			[CurrSaleSeller2FullName]=NULL,
			[PrevMtg1InputDocNbr]=NULL,
			[PrevMtg1InputBook]=NULL,
			[PrevMtg1InputPage]=NULL,
			[PrevMtg1RecordingDt]=NULL,
			[PrevMtg1LoanAmt]=NULL,
			[PrevMtg1Lender]=NULL,
			[PrevMtg1LenderType]=NULL,
			[PrevMtg1PrivateLender]=NULL,
			[PrevMtg1LoanDueDt]=NULL,
			[PrevMtg1LoanType]=NULL,
			[PrevMtg1Term]=NULL,
			[PrevMtg1Typefinancing]=NULL,
			[PrevMtg1InterestRate]= NULL,
			[PrevMtg1FormatDocNbr]= NULL,
			[PrevMtg1FormatBook]= NULL,
			[PrevMtg1FormatPage]= NULL,
			[PrevSaleTransactionId] = NULL,
			[PrevSaleChronoKey]=NULL,
			[PrevSaleInputDocNbr]=NULL,
			[PrevSaleInputBook]=NULL,
			[PrevSaleInputPage]=NULL,
			[PrevSaleRecordingDate]=NULL,
			[PrevSaleDocumentType] = NULL,
			[PrevSalesPrice]= NULL,
			[PrevSalesPriceCode]=NULL,
			[PrevSaleContractDate]=NULL,
			[PrevSaleBuyer1FullName]=NULL,
			[PrevSaleBuyer2FullName]=NULL,
			[PrevSaleSeller1FullName]=NULL,
			[PrevSaleSeller2FullName]=NULL	
	From [dbo].[PropertyWorkUpdate]  P JOIN [dbo].[DeedWorkUpdateTbl] d
	     on D.FIPS = P.FIPS and d.fapropertyid = P.PropertyId
	where D.[FASalePosition] = '1'

	UPDATE P
	Set	P.FATimestamp = GETDATE()
	,[ConCurrMtg1InputDocNbr]=[Loan1Document],
			[ConCurrMtg1InputBook]=[Loan1Book],
			[ConCurrMtg1InputPage]=[Loan1Page],
			[ConCurrMtg1RecordingDt]=[Loan1RecordingDt],
			[ConCurrMtg1LoanAmt]=Cast([Loan1Amount] as Int),
			[ConCurrMtg1Lender]=Substring([Loan1LenderName],1,30),
			[ConCurrMtg1LenderType]=[Loan1LenderTypeCode],
			[ConCurrMtg1PrivateLender]=[Loan1LenderPrivateInd],
			[ConCurrMtg1LoanDueDt]=[Loan1DueDate],
			[ConCurrMtg1LoanType]=[Loan1Type],
			[ConCurrMtg1Term]=[Loan1TermMonths],
			[ConCurrMtg1Typefinancing]=[Loan1TypeFinance],
			[ConCurrMtg1InterestRate]=[Loan1InterestRate],
			[ConCurrMtg1FormatDocNbr]= [Loan1YearDocNbrFmt],
			[ConCurrMtg1FormatBook]= LEFT(LTRIM(RTRIM(Substring([Loan1BookPageFmt],1,CHARINDEX('.',[Loan1BookPageFmt])-1))),10),							--LEFT(Global.dbo.Before1stCharacter([Loan1BookPageFmt],'.'),10),
			[ConCurrMtg1FormatPage]=  LEFT(LTRIM(RTRIM(Substring([Loan1BookPageFmt],CHARINDEX('.',[Loan1BookPageFmt])+1,LEN([Loan1BookPageFmt])))),10),		--LEFT(Global.dbo.After1stCharacter([Loan1BookPageFmt],'.'),10),
			[ConCurrMtg2FormatDocNbr]= [Loan2YearDocNbrFmt],
			[ConCurrMtg2FormatBook]= LEFT(LTRIM(RTRIM(Substring([Loan2BookPageFmt],1,CHARINDEX('.',[Loan2BookPageFmt])-1))),10),							--LEFT(Global.dbo.Before1stCharacter([Loan2BookPageFmt],'.'),10),
			[ConCurrMtg2FormatPage]= LEFT(LTRIM(RTRIM(Substring([Loan2BookPageFmt],CHARINDEX('.',[Loan2BookPageFmt])+1,LEN([Loan2BookPageFmt])))),10),		--LEFT(Global.dbo.After1stCharacter([Loan2BookPageFmt],'.'),10),
			[ConCurrMtg2InputDocNbr]=[Loan2Document],
			[ConCurrMtg2InputBook]=[Loan2Book],
			[ConCurrMtg2InputPage]=[Loan2Page],
			[ConCurrMtg2RecordingDt]=[Loan2RecordingDt],
			[ConCurrMtg2LoanAmt]=Cast([Loan2Amount] as int),
			[ConCurrMtg2Lender]=Substring([Loan2LenderName],1,30),
			[ConCurrMtg2LenderType]=[Loan2LenderTypeCode],
			[ConCurrMtg2PrivateLender]=[Loan2LenderPrivateInd],
			[ConCurrMtg2LoanDueDt]=[Loan2DueDate],
			[ConCurrMtg2LoanType]=[Loan2Type],
			[ConCurrMtg2Term]=[Loan2TermMonths],
			[ConCurrMtg2Typefinancing]=[Loan2TypeFinance],
			[ConCurrMtg2InterestRate]=[Loan2InterestRate],
			[CurrentSaleTransactionId] = [TransactionId],
			[CurrentSaleChronoKey]=[ChronoKey],
			[CurrSaleInputDocNbr]=[DocNbrSrce],
			[CurrSaleInputBook]=[BookSrce],
			[CurrSaleInputPage]=[PageSrce],
			[CurrSaleFormatDocNbr] = [YearDocNbrFrmt],
			[CurrSaleFormatBook] =  LEFT(LTRIM(RTRIM(Substring([BkPgFrmt],1,CHARINDEX('.',[BkPgFrmt])-1))),10),							--LEFT(Global.dbo.Before1stCharacter([BkPgFrmt],'.'),10),
			[CurrSaleFormatPage] =  LEFT(LTRIM(RTRIM(Substring([BkPgFrmt],CHARINDEX('.',[BkPgFrmt])+1,LEN([BkPgFrmt])))),10),			--LEFT(Global.dbo.After1stCharacter([BkPgFrmt],'.'),10),
			[CurrSaleRecordingDate]=[RecordingDt],
			[CurrSaleDocumentType] = [DocumentTypeCode],
			[CurrSalesPrice]= Cast([SalesPrice] as int),
			[CurrSalesPriceCode]=[SalesPriceCode],
			[CurrSaleContractDate]=[Saledate],
			[CurrSaleBuyer1FullName]=Substring([Buyer1FullName],1,60),
			[CurrSaleBuyer2FullName]=Substring([Buyer2FullName],1,60),
			[CurrSaleSeller1FullName]=Substring([Seller1FullName],1,60),
			[CurrSaleSeller2FullName]=Substring([Seller2FullName],1,60)
	From [dbo].[PropertyWorkUpdate]  P JOIN [dbo].[DeedWorkUpdateTbl] d
	     on D.FIPS = P.FIPS and d.fapropertyid = P.PropertyId
	where D.[FASalePosition] = '1'


	UPDATE P
	Set		[PrevMtg1InputDocNbr]=[Loan1Document],
			[PrevMtg1InputBook]=[Loan1Book],
			[PrevMtg1InputPage]=[Loan1Page],
			[PrevMtg1RecordingDt]=[Loan1RecordingDt],
			[PrevMtg1LoanAmt]=Cast([Loan1Amount] as Int),
			[PrevMtg1Lender]=Substring([Loan1LenderName],1,30),
			[PrevMtg1LenderType]=[Loan1LenderTypeCode],
			[PrevMtg1PrivateLender]=[Loan1LenderPrivateInd],
			[PrevMtg1LoanDueDt]=[Loan1DueDate],
			[PrevMtg1LoanType]=[Loan1Type],
			[PrevMtg1Term]=[Loan1TermMonths],
			[PrevMtg1Typefinancing]=[Loan1TypeFinance],
			[PrevMtg1InterestRate]=[Loan1InterestRate],
			[PrevSaleTransactionId] = [TransactionId],
			[PrevSaleChronoKey]=[ChronoKey],
			[PrevSaleInputDocNbr]=[DocNbrSrce],
			[PrevSaleInputBook]=[BookSrce],
			[PrevSaleInputPage]=[PageSrce],
			[PrevSaleFormatDocNbr] = [YearDocNbrFrmt],
			[PrevSaleFormatBook] = LEFT(LTRIM(RTRIM(Substring([BkPgFrmt],1,CHARINDEX('.',[BkPgFrmt])-1))),10),							--left(Global.dbo.Before1stCharacter([BkPgFrmt],'.'),10),
			[PrevSaleFormatPage] =  LEFT(LTRIM(RTRIM(Substring([BkPgFrmt],CHARINDEX('.',[BkPgFrmt])+1,LEN([BkPgFrmt])))),10),			--left(Global.dbo.After1stCharacter([BkPgFrmt],'.'),10),
			[PrevSaleRecordingDate]=[RecordingDt],
			[PrevSaleDocumentType] = [DocumentTypeCode],
			[PrevSalesPrice] = Cast([SalesPrice] as int),
			[PrevSalesPriceCode] = [SalesPriceCode],
			[PrevSaleContractDate] = [Saledate],
			[PrevSaleBuyer1FullName] = Substring([Buyer1FullName],1,60),
			[PrevSaleBuyer2FullName] = Substring([Buyer2FullName],1,60),
			[PrevSaleSeller1FullName] = Substring([Seller1FullName],1,60),
			[PrevSaleSeller2FullName] = Substring([Seller2FullName],1,60),
			[PrevMtg1FormatDocNbr] = [Loan1YearDocNbrFmt],
			[PrevMtg1FormatBook] = LEFT(LTRIM(RTRIM(Substring([Loan1BookPageFmt],1,CHARINDEX('.',[Loan1BookPageFmt])-1))),10),							--left(Global.dbo.Before1stCharacter([Loan1BookPageFmt],'.'),10),
			[PrevMtg1FormatPage] = LEFT(LTRIM(RTRIM(Substring([Loan1BookPageFmt],CHARINDEX('.',[Loan1BookPageFmt])+1,LEN([Loan1BookPageFmt])))),10)		--left(Global.dbo.After1stCharacter([Loan1BookPageFmt],'.'),10)
	From [dbo].[PropertyWorkUpdate]  P JOIN [dbo].[DeedWorkUpdateTbl] d
	     on D.FIPS = P.FIPS and d.fapropertyid = P.PropertyId
	where [FASalePosition] = '2'


	--------------ADDED 20190201 To Fill 2nd and 3rd previous sale data MAS 
	---- 2nd Previous
		-----

			UPDATE P
			Set	[SecondPrevSaleTransactionId] = x.[TransactionID]
				,[SecondPrevSaleRecordingDate] = x.RecordingDt
				,[SecondPrevSalesPrice]= Cast(x.[SalesPrice] as int)
			From [dbo].[PropertyWorkUpdate]  P JOIN [dbo].[DeedWorkUpdateTbl] x
					ON x.FIPS = P.FIPS and x.fapropertyid = P.PropertyId
			WHERE FASalePosition = 3


	-----  3rd Previous
		-----

			UPDATE p
			Set	[ThirdPrevSaleTransactionId] = x.[TransactionID]
				,[ThirdPrevSaleRecordingDate] = x.RecordingDt
				,[ThirdPrevSalesPrice]= Cast(x.[SalesPrice] as int)
			From [dbo].[PropertyWorkUpdate]  P JOIN [dbo].[DeedWorkUpdateTbl] x
					ON x.FIPS = P.FIPS and x.fapropertyid = P.PropertyId
			WHERE FASalePosition = 4


	TRUNCATE TABLE [dbo].[DeedWorkUpdateTbl]


END

