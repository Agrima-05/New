SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[Roll_DBS_Tax_To_Property_REROLL]
	--@FipsState varchar(2)
AS
BEGIN
	SET NOCOUNT ON;

		UPDATE  xMSmith.dbo.DBSTaxUpdateCount
		SET  DBSTaxUpdateCount = 0

		DECLARE @FipsCode varchar(5)
		DECLARE @DT varchar(8) = Convert(varchar(8),GETDATE(),112)

		--TRUNCATE TABLE [DBS_Tax_Lic].dbo.AvailableFIPS

		--UPDATE DBS_Tax_Lic.dbo.Licensing_Deliverable
		--SET LIC_FIPS = Right('0' + convert(varchar(5),FIPS),5)
		--WHERE LIC_FIPS is null

		--INSERT INTO  [DBS_Tax_Lic].dbo.AvailableFIPS
		--SELECT FIPS,LIC_FIPS FROM Licensing_Deliverable
		--GROUP BY FIPS,LIC_FIPS
		--ORDER BY FIPS

		DECLARE RollUpToPropII CURSOR FOR  
			SELECT LIC_FIPS 
			FROM [DBS_Tax_Lic].dbo.AvailableFIPS
			--WHERE LIC_FIPS > '21235' --and LIC_FIPS < '22001' 
			ORDER BY LIC_FIPS desc


		OPEN RollUpToPropII   
				FETCH NEXT FROM RollUpToPropII INTO @FipsCode

			IF(Select DBSTaxUpdateCount from  xMSmith.dbo.DBSTaxUpdateCount) < 3000000
			BEGIN

				WHILE @@FETCH_STATUS = 0   
				BEGIN   
 
							--- RUN THIS TO REFRESH DBS TAX DATA IN PROPERTY
									EXEC('UPDATE a
									SET DBSTaxAmount = TOTAL_BASE_TAX_AMOUNT*100
									,DBSTaxYear = TAX_YEAR_BEGIN
									,FATimestamp = GetDate()+1
									,FAUserID = ''DBS Tax Update_' + @DT + '''
									FROM Data.dbo.Property a JOIN DBS_Tax_Lic.dbo.Licensing_Deliverable b with(NOLOCK)
									ON a.FIPS = b.LIC_FIPS
									and a.PropertyID = b.FAPropertyID
									Where b.FIPS = '''+@FipsCode+'''
										AND a.FIPS = '''+@FipsCode+'''
											AND ((DBSTaxYear < TAX_YEAR_BEGIN
												 OR DBSTaxYear is NULL)
													OR convert(Money,DBSTaxAmount) <> Convert(Money,TOTAL_BASE_TAX_AMOUNT*100))
										')

									EXEC('Update xMSmith.dbo.DBSTaxUpdateCount
									SET DBSTaxUpdateCount = DBSTaxUpdateCount + (Select COUNT(*) from Data.dbo.Property with(NOLOCK) 
									where FIPS = ''' + @FipsCode + ''' and FATimestamp > convert(varchar(10),GetDate()+1,120))
									')

						PRINT @FipsCode
				

							FETCH NEXT FROM RollUpToPropII INTO @FipsCode   
						END   

						CLOSE RollUpToPropII   
						DEALLOCATE RollUpToPropII 

			END 

END
