SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_MemCounterLoader]
AS
BEGIN

SET NOCOUNT ON

-- Page Life Expectancy
INSERT [Data_Archive].[dbo].[MemoryPerfCounters] (MemCounterName,MemCounterValue,MemCounterTimestamp) 
SELECT [counter_name], [cntr_value], GETDATE() FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Buffer Manager%' AND [counter_name] = 'Page life expectancy'
-- MAXBP(MB)/1024/4*300 == 246141 / 1024 / 4 * 300 == 18028

-- Buffer Cache hit ratio
INSERT [Data_Archive].[dbo].[MemoryPerfCounters] (MemCounterName,MemCounterValue,MemCounterTimestamp) 
SELECT [counter_name], [cntr_value], GETDATE() FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Buffer Manager%' AND [counter_name] = 'Buffer cache hit ratio'

-- Page reads / sec, Page writes / sec and Lazy writes / sec Measurements
INSERT [Data_Archive].[dbo].[MemoryPerfCounters] (MemCounterName,MemCounterValue,MemCounterTimestamp) 
SELECT [counter_name], [cntr_value], GETDATE() FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Buffer Manager%' AND [counter_name] IN ('Page reads/sec', 'Page writes/sec', 'Lazy writes/sec')

-- Memory Grants Pending
INSERT [Data_Archive].[dbo].[MemoryPerfCounters] (MemCounterName,MemCounterValue,MemCounterTimestamp) 
SELECT [counter_name], [cntr_value], GETDATE() FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Memory Manager%' AND [counter_name] = 'Memory Grants Pending'

-- Total Server Memory and Target Server Memory
INSERT [Data_Archive].[dbo].[MemoryPerfCounters] (MemCounterName,MemCounterValue,MemCounterTimestamp) 
SELECT [counter_name], [cntr_value], GETDATE() FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Memory Manager%' AND [counter_name] IN ('Total Server Memory (KB)', 'Target Server Memory (KB)')

-- select * from [Data_Archive].[dbo].[MemoryPerfCounters] 
-- truncate table [Data_Archive].[dbo].[MemoryPerfCounters]
-- select MemCounterName, MemCounterTimestamp, MemCounterValue from [Data_Archive].[dbo].[MemoryPerfCounters] order by MemCounterName, MemCounterValue
-- EXEC [Data_Archive].[dbo].[usp_MemCounterLoader]
 
SET NOCOUNT OFF

END

