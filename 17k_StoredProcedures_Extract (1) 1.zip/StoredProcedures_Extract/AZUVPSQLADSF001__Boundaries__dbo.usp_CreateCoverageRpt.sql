SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE dbo.usp_CreateCoverageRpt
AS
BEGIN

	SET NOCOUNT ON;

 
				 Select b.FIPSCode,b.[State],b.[County Name] as County, Count(*) as TotalCount
				, SUM(CASE WHEN [GeoSource] like 'Parcel%' THEN 1 ELSE 0 END) as NbrOfParcels
				, SUM(CASE WHEN [GeoSource] like 'Parcel%' THEN 0 ELSE 1 END) as NbrOfPoints
				from boundaries.dbo.vFASpot_FULL a JOIN Global.dbo.County b
				on a.Fips = b.FIPSCode
				Group by b.FIPSCode,b.[State],b.[County Name]
				order by FIPSCode


END

