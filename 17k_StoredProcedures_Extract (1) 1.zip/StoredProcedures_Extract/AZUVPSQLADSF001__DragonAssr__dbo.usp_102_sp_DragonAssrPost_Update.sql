SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

			CREATE procedure [dbo].[usp_102_sp_DragonAssrPost_Update] (@tableName varchar(40)) 
			as  
			declare @sql varchar(max) = ''

				set @sql = '
				   UPDATE  [DragonAssr].[dbo].[DragonAssr_Update_STD]
				   set [FullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetNumber])) + '' '' +  DragonAssr.[dbo].[DragonAssr_Update_STD].[PreDir])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetName]))))) + '' '' + ltrim(rtrim(UPPER( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetType]))) + '' '' +  DragonAssr.[dbo].[DragonAssr_Update_STD].[PostDir]))))  + '' '' + ltrim(rtrim(ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[SuiteType])) + '' '' + (ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Suite] + '' '' + ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PrivateMailbox])))))))))
					,[CountyFips]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CountyFips]))
					,[StreetNumber]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetNumber]))
					,[PreDir]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PreDir]))
					,[StreetName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetName]))
					,[StreetType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[StreetType]))
					,[PostDir]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PostDir]))
					,[SuiteType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[SuiteType]))
					,[Suite]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Suite]))
					,[City]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[City]))
					,[State]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[State]))
					,[Zip]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Zip]))
					,[Plus4]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Plus4]))
					,[CarrierRoute]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CarrierRoute]))
					,[CountyName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CountyName]))
					,[PrivateMailbox]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PrivateMailbox]))
					,[Pmsa]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Pmsa]))
					,[Msa]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Msa]))
					,[ZipType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[ZipType]))
					,[Urbanization]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Urbanization]))
					,[CongressionalDistrict]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CongressionalDistrict]))
					,[CityAbbreviation]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CityAbbreviation]))
					,[AddressTypeCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[AddressTypeCode]))
					,[AddressTypeString]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[AddressTypeString]))
					,[DPVCount]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[DPVCount]))
					,[DPVFootnotes]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[DPVFootnotes]))
					,[CMRA]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CMRA]))
					,[ELotNumber]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[ELotNumber]))
					,[ELotOrder]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[ELotOrder]))
					,[Lacs]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Lacs]))
					,[LACSLinkIndicator]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[LACSLinkIndicator]))
					,[EWSFlag]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[EWSFlag]))
					,[RBDI]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[RBDI]))
					,[SuiteLinkReturnCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[SuiteLinkReturnCode]))
					,[DeliveryPointCheckDigit]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[DeliveryPointCheckDigit]))
					,[DeliveryPointCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[DeliveryPointCode]))
					,[Verified]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Verified]))
					,[AddressMatchResults]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[AddressMatchResults]))
					,[CensusBlock]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CensusBlock]))
					,[CensusTract]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CensusTract]))
					,[PlaceCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PlaceCode]))
					,[PlaceName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[PlaceName]))
					,[CBSACode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSACode]))
					,[CBSALevel]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSALevel]))
					,[CBSATitle]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSATitle]))
					,[CBSADivisionCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSADivisionCode]))
					,[CBSADivisionLevel]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSADivisionLevel]))
					,[CBSADivisionTitle]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CBSADivisionTitle]))
					,[Latitude]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Latitude]))
					,[Longitude]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Longitude]))
					,[Geocoded]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[Geocoded]))
					,[GeoErrorCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[GeoErrorCode]))
					,[GeoStatusCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[GeoStatusCode]))
					,[GeoCodeResults]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[GeoCodeResults]))
					,[CountryCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_Update_STD].[CountryCode]))


				 From  [DragonAssr].[dbo].[DragonAssr_Update_STD]

				 	UPDATE
						Table_A
					SET
						Table_A.raw_id = Table_B.raw_id
					FROM
						 [DragonAssr].[dbo].[DragonAssr_Update_STD] Table_A
					INNER JOIN
						 [DragonAssr].[dbo].[DragonAssr_Update] Table_B
					ON
						Table_A.RecordId = Table_B.RecordId

				'
			print @sql
			exec (@sql)
