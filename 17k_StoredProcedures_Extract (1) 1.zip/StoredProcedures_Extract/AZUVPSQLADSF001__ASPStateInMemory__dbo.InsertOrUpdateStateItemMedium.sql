SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.InsertOrUpdateStateItemMedium(
	@SessionId nvarchar(88) NOT NULL,
	@NewItem bit NOT NULL,
	@Initialized bit NOT NULL,
	@LockCookie int NOT NULL,
	@Timeout int NOT NULL,
	@ItemSize bigint NOT NULL,
	@Item1 varbinary(7000) NOT NULL,
	@Item2 varbinary(7000) NOT NULL,
	@Item3 varbinary(7000),
	@Item4 varbinary(7000),
	@Item5 varbinary(7000),
	@Item6 varbinary(7000),
	@Item7 varbinary(7000),
	@Item8 varbinary(7000),
	@Item9 varbinary(7000)
) WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()
	DECLARE @Expires AS datetime2 NOT NULL = DATEADD(minute, @Timeout, @Now)
			
	IF @NewItem = 1
	BEGIN
		INSERT dbo.Sessions
			(SessionId,
			Created,
			Expires,
			Initialized,
			Locked,
			LockDate,
			LockCookie,
			Timeout,
			ItemSize,
			Item)
		VALUES 
			(@SessionId,
			@Now,
			@Expires,
			@Initialized,
			0, -- Locked
			@Now, -- LockDate
			@LockCookie,
			@Timeout,
			@ItemSize,
			NULL)
		END
	ELSE
	BEGIN
		DECLARE @OldItemSize bigint = 0

		UPDATE dbo.Sessions
		SET
			@OldItemSize = ItemSize,
			Expires = @Expires,
			Locked = 0,
			Timeout = @Timeout,
			ItemSize = @ItemSize,
			Item = NULL
		WHERE SessionId = @SessionId AND LockCookie = @LockCookie

		IF @@ROWCOUNT = 0 RETURN;

		IF @OldItemSize > 7000
		BEGIN
			DELETE dbo.SessionItems WHERE SessionId = @SessionId
		END
	END

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 1, @Item1)

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 2, @Item2)

	-- At least two items were expected.

	IF @Item3 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 3, @Item3)

	IF @Item4 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 4, @Item4)

	IF @Item5 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 5, @Item5)

	IF @Item6 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 6, @Item6)

	IF @Item7 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 7, @Item7)

	IF @Item8 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 8, @Item8)

	IF @Item9 IS NULL RETURN;

	INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
	VALUES (@SessionId, 9, @Item9)
END 

