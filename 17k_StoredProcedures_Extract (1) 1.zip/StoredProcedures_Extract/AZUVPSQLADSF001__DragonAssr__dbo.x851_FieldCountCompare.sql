SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[x851_FieldCountCompare] @Fipscode varchar(5)
AS
BEGIN

	SET NOCOUNT ON;
  
		--DECLARE @Fipscode varchar(5) = '12029'

		EXEC('Select FIPS
		,[State]
		,[County Name]
		,sum(CASE WHEN (len(ltrim(rtrim(FIPS))) > 0 and FIPS  <> ''0'') THEN 1 ELSE 0 END) AS TotalCnt
		,sum(CASE WHEN (len(ltrim(rtrim(PropertyID))) > 0 and PropertyID  <> ''0'') THEN 1 ELSE 0 END) AS PropertyID
		,sum(CASE WHEN (len(ltrim(rtrim(FormattedAPN))) > 0 and FormattedAPN  <> ''0'') THEN 1 ELSE 0 END) AS FormattedAPN
		,sum(CASE WHEN (len(ltrim(rtrim(APNSeqNbr))) > 0 and APNSeqNbr  <> ''0'') THEN 1 ELSE 0 END) AS APNSeqNbr
		,sum(CASE WHEN (len(ltrim(rtrim(UnformattedAPN))) > 0 and UnformattedAPN  <> ''0'') THEN 1 ELSE 0 END) AS UnformattedAPN
		,sum(CASE WHEN (len(ltrim(rtrim(OldAPN))) > 0 and OldAPN  <> ''0'') THEN 1 ELSE 0 END) AS OldAPN
		,sum(CASE WHEN (len(ltrim(rtrim(OLDAPNSeqNbr))) > 0 and OLDAPNSeqNbr  <> ''0'') THEN 1 ELSE 0 END) AS OLDAPNSeqNbr
		,sum(CASE WHEN (len(ltrim(rtrim(TaxAccountNumber))) > 0 and TaxAccountNumber  <> ''0'') THEN 1 ELSE 0 END) AS TaxAccountNumber
		,sum(CASE WHEN (len(ltrim(rtrim(RecordType))) > 0 and RecordType  <> ''0'') THEN 1 ELSE 0 END) AS RecordType
		,sum(CASE WHEN (len(ltrim(rtrim(VendorPID))) > 0 and VendorPID  <> ''0'') THEN 1 ELSE 0 END) AS VendorPID
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdFullStreetAddress))) > 0 and SitusStdFullStreetAddress  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdFullStreetAddress
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbr))) > 0 and SitusStdHouseNbr  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbr2))) > 0 and SitusStdHouseNbr2  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbr2
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbrSuffix))) > 0 and SitusStdHouseNbrSuffix  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbrSuffix
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdDirectionLeft))) > 0 and SitusStdDirectionLeft  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdDirectionLeft
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdStreet))) > 0 and SitusStdStreet  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdStreet
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdMode))) > 0 and SitusStdMode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdMode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdDirectionRight))) > 0 and SitusStdDirectionRight  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdDirectionRight
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdUnitNbr))) > 0 and SitusStdUnitNbr  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdUnitNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdCity))) > 0 and SitusStdCity  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdCity
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdState))) > 0 and SitusStdState  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdState
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdZIP5))) > 0 and SitusStdZIP5  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdZIP5
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdZIP4))) > 0 and SitusStdZIP4  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdZIP4
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLatitude))) > 0 and SitusLatitude  <> ''0'') THEN 1 ELSE 0 END) AS SitusLatitude
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLongitude))) > 0 and SitusLongitude  <> ''0'') THEN 1 ELSE 0 END) AS SitusLongitude
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdCarrierCode))) > 0 and SitusStdCarrierCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdCarrierCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusTract))) > 0 and SitusCensusTract  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusTract
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusTractBlock))) > 0 and SitusCensusTractBlock  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusTractBlock
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdUnitType))) > 0 and SitusStdUnitType  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdUnitType
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdMatchCode))) > 0 and SitusStdMatchCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdMatchCode
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeSqFt))) > 0 and LotSizeSqFt  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeAcres))) > 0 and LotSizeAcres  <> ''0000000000'') THEN 1 ELSE 0 END) AS LotSizeAcres
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeFrontageFeet))) > 0 and LotSizeFrontageFeet  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeFrontageFeet
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeDepthFeet))) > 0 and LotSizeDepthFeet  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeDepthFeet
		,sum(CASE WHEN (len(ltrim(rtrim(LotIrregularInd))) > 0 and LotIrregularInd  <> ''0'') THEN 1 ELSE 0 END) AS LotIrregularInd
		,sum(CASE WHEN (len(ltrim(rtrim(LotUsableSize))) > 0 and LotUsableSize  <> ''0'') THEN 1 ELSE 0 END) AS LotUsableSize
		,sum(CASE WHEN (len(ltrim(rtrim(PropertyClassID))) > 0 and PropertyClassID  <> ''0'') THEN 1 ELSE 0 END) AS PropertyClassID
		,sum(CASE WHEN (len(ltrim(rtrim(StdLandUseCode))) > 0 and StdLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS StdLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(StateLandUseCode))) > 0 and StateLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS StateLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(CountyLandUseCode))) > 0 and CountyLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS CountyLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(CountyLandUseDescription))) > 0 and CountyLandUseDescription  <> ''0'') THEN 1 ELSE 0 END) AS CountyLandUseDescription
		,sum(CASE WHEN (len(ltrim(rtrim(TimeshareCode))) > 0 and TimeshareCode  <> ''0'') THEN 1 ELSE 0 END) AS TimeshareCode
		,sum(CASE WHEN (len(ltrim(rtrim(Zoning))) > 0 and Zoning  <> ''0'') THEN 1 ELSE 0 END) AS Zoning
		,sum(CASE WHEN (len(ltrim(rtrim(SiteInfluenceCode))) > 0 and SiteInfluenceCode  <> ''0'') THEN 1 ELSE 0 END) AS SiteInfluenceCode
		,sum(CASE WHEN (len(ltrim(rtrim(NeighborhoodCode))) > 0 and NeighborhoodCode  <> ''0'') THEN 1 ELSE 0 END) AS NeighborhoodCode
		,sum(CASE WHEN (len(ltrim(rtrim(TopographyCode))) > 0 and TopographyCode  <> ''0'') THEN 1 ELSE 0 END) AS TopographyCode
		,sum(CASE WHEN (len(ltrim(rtrim(MobileHomeInd))) > 0 and MobileHomeInd  <> ''0'') THEN 1 ELSE 0 END) AS MobileHomeInd
		,sum(CASE WHEN (len(ltrim(rtrim(LotCode))) > 0 and LotCode  <> ''0'') THEN 1 ELSE 0 END) AS LotCode
		,sum(CASE WHEN (len(ltrim(rtrim(LotNumber))) > 0 and LotNumber  <> ''0'') THEN 1 ELSE 0 END) AS LotNumber
		,sum(CASE WHEN (len(ltrim(rtrim(LandLot))) > 0 and LandLot  <> ''0'') THEN 1 ELSE 0 END) AS LandLot
		,sum(CASE WHEN (len(ltrim(rtrim(Block))) > 0 and Block  <> ''0'') THEN 1 ELSE 0 END) AS Block
		,sum(CASE WHEN (len(ltrim(rtrim(Section))) > 0 and Section  <> ''0'') THEN 1 ELSE 0 END) AS Section
		,sum(CASE WHEN (len(ltrim(rtrim(District))) > 0 and District  <> ''0'') THEN 1 ELSE 0 END) AS District
		,sum(CASE WHEN (len(ltrim(rtrim(LegalUnit))) > 0 and LegalUnit  <> ''0'') THEN 1 ELSE 0 END) AS LegalUnit
		,sum(CASE WHEN (len(ltrim(rtrim(Municipality))) > 0 and Municipality  <> ''0'') THEN 1 ELSE 0 END) AS Municipality
		,sum(CASE WHEN (len(ltrim(rtrim(LegalSection))) > 0 and LegalSection  <> ''0'') THEN 1 ELSE 0 END) AS LegalSection
		,sum(CASE WHEN (len(ltrim(rtrim(LegalTownship))) > 0 and LegalTownship  <> ''0'') THEN 1 ELSE 0 END) AS LegalTownship
		,sum(CASE WHEN (len(ltrim(rtrim(LegalRange))) > 0 and LegalRange  <> ''0'') THEN 1 ELSE 0 END) AS LegalRange
		,sum(CASE WHEN (len(ltrim(rtrim(Meridian))) > 0 and Meridian  <> ''0'') THEN 1 ELSE 0 END) AS Meridian
		,sum(CASE WHEN (len(ltrim(rtrim(LegalQuarter))) > 0 and LegalQuarter  <> ''0'') THEN 1 ELSE 0 END) AS LegalQuarter
		,sum(CASE WHEN (len(ltrim(rtrim(LegalQuarterQuarter))) > 0 and LegalQuarterQuarter  <> ''0'') THEN 1 ELSE 0 END) AS LegalQuarterQuarter
		,sum(CASE WHEN (len(ltrim(rtrim(LegalDescription))) > 0 and LegalDescription  <> ''0'') THEN 1 ELSE 0 END) AS LegalDescription
		,sum(CASE WHEN (len(ltrim(rtrim(AssessorsMapRef1))) > 0 and AssessorsMapRef1  <> ''0'') THEN 1 ELSE 0 END) AS AssessorsMapRef1
		,sum(CASE WHEN (len(ltrim(rtrim(AssessorsMapRef2))) > 0 and AssessorsMapRef2  <> ''0'') THEN 1 ELSE 0 END) AS AssessorsMapRef2
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionName))) > 0 and SubdivisionName  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionName
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPhaseNbr))) > 0 and SubdivisionPhaseNbr  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPhaseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionTractNbr))) > 0 and SubdivisionTractNbr  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionTractNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPlatBook))) > 0 and SubdivisionPlatBook  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPlatBook
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPlatPage))) > 0 and SubdivisionPlatPage  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPlatPage
		,sum(CASE WHEN (len(ltrim(rtrim(NewRecordType))) > 0 and NewRecordType  <> ''0'') THEN 1 ELSE 0 END) AS NewRecordType
		,sum(CASE WHEN (len(ltrim(rtrim(SwiSCodeNY))) > 0 and SwiSCodeNY  <> ''0'') THEN 1 ELSE 0 END) AS SwiSCodeNY
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCareOfName))) > 0 and MailingCareOfName  <> ''0'') THEN 1 ELSE 0 END) AS MailingCareOfName
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdFullStreetAddress))) > 0 and MailingStdFullStreetAddress  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdFullStreetAddress
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbr))) > 0 and MailingStdHouseNbr  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbr2))) > 0 and MailingStdHouseNbr2  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbr2
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbrSuffix))) > 0 and MailingStdHouseNbrSuffix  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbrSuffix
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdDirectionLeft))) > 0 and MailingStdDirectionLeft  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdDirectionLeft
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdStreet))) > 0 and MailingStdStreet  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdStreet
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdMode))) > 0 and MailingStdMode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdMode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdDirectionRight))) > 0 and MailingStdDirectionRight  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdDirectionRight
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdUnitNbr))) > 0 and MailingStdUnitNbr  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdUnitNbr
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdCity))) > 0 and MailingStdCity  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdCity
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdState))) > 0 and MailingStdState  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdState
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdZIP5))) > 0 and MailingStdZIP5  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdZIP5
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdZIP4))) > 0 and MailingStdZIP4  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdZIP4
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdCarrierCode))) > 0 and MailingStdCarrierCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdCarrierCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdUnitType))) > 0 and MailingStdUnitType  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdUnitType
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdMatchCode))) > 0 and MailingStdMatchCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdMatchCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingOptOut))) > 0 and MailingOptOut  <> ''0'') THEN 1 ELSE 0 END) AS MailingOptOut
		,sum(CASE WHEN (len(ltrim(rtrim(MailingOptOutDate))) > 0 and MailingOptOutDate  <> ''0'') THEN 1 ELSE 0 END) AS MailingOptOutDate
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerOccupied))) > 0 and OwnerOccupied  <> ''0'') THEN 1 ELSE 0 END) AS OwnerOccupied
		,sum(CASE WHEN (len(ltrim(rtrim(AbsenteeOwner))) > 0 and AbsenteeOwner  <> ''0'') THEN 1 ELSE 0 END) AS AbsenteeOwner
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME1FULL))) > 0 and OwnerStdNAME1FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME1FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME2FULL))) > 0 and OwnerStdNAME2FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME2FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME3FULL))) > 0 and OwnerStdNAME3FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME3FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME4FULL))) > 0 and OwnerStdNAME4FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME4FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerEtALIndicator))) > 0 and OwnerEtALIndicator  <> ''0'') THEN 1 ELSE 0 END) AS OwnerEtALIndicator
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1CorpInd))) > 0 and OwnerStd1CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1LastName))) > 0 and OwnerStd1LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1FirstName))) > 0 and OwnerStd1FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1MiddleName))) > 0 and OwnerStd1MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1Suffix))) > 0 and OwnerStd1Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1CorpName))) > 0 and OwnerStd1CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1OwnershipRights))) > 0 and OwnerStd1OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1RelationshipType))) > 0 and OwnerStd1RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner1DoNotParse))) > 0 and Owner1DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner1DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2CorpInd))) > 0 and OwnerStd2CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2LastName))) > 0 and OwnerStd2LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2FirstName))) > 0 and OwnerStd2FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2MiddleName))) > 0 and OwnerStd2MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2Suffix))) > 0 and OwnerStd2Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2CorpName))) > 0 and OwnerStd2CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2OwnershipRights))) > 0 and OwnerStd2OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2RelationshipType))) > 0 and OwnerStd2RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner2DoNotParse))) > 0 and Owner2DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner2DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3CorpInd))) > 0 and OwnerStd3CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3LastName))) > 0 and OwnerStd3LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3FirstName))) > 0 and OwnerStd3FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3MiddleName))) > 0 and OwnerStd3MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3Suffix))) > 0 and OwnerStd3Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3CorpName))) > 0 and OwnerStd3CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3OwnershipRights))) > 0 and OwnerStd3OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3RelationshipType))) > 0 and OwnerStd3RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner3DoNotParse))) > 0 and Owner3DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner3DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4CorpInd))) > 0 and OwnerStd4CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4LastName))) > 0 and OwnerStd4LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4FirstName))) > 0 and OwnerStd4FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4MiddleName))) > 0 and OwnerStd4MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4Suffix))) > 0 and OwnerStd4Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4CorpName))) > 0 and OwnerStd4CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4OwnershipRights))) > 0 and OwnerStd4OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4RelationshipType))) > 0 and OwnerStd4RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner4DoNotParse))) > 0 and Owner4DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner4DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeStd1Name))) > 0 and AssesseeStd1Name  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeStd1Name
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeStd2Name))) > 0 and AssesseeStd2Name  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeStd2Name
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeNameIndicator))) > 0 and AssesseeNameIndicator  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeNameIndicator
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeNameIndicator2))) > 0 and AssesseeNameIndicator2  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeNameIndicator2
		,sum(CASE WHEN (len(ltrim(rtrim(Amenities))) > 0 and Amenities  <> ''0'') THEN 1 ELSE 0 END) AS Amenities
		,sum(CASE WHEN (len(ltrim(rtrim(DrivewayCode))) > 0 and DrivewayCode  <> ''0'') THEN 1 ELSE 0 END) AS DrivewayCode
		,sum(CASE WHEN (len(ltrim(rtrim(EasementInd))) > 0 and EasementInd  <> ''0'') THEN 1 ELSE 0 END) AS EasementInd
		,sum(CASE WHEN (len(ltrim(rtrim(QualityCode))) > 0 and QualityCode  <> ''0'') THEN 1 ELSE 0 END) AS QualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ViewInd))) > 0 and ViewInd  <> ''0'') THEN 1 ELSE 0 END) AS ViewInd
		,sum(CASE WHEN (len(ltrim(rtrim(ViewCode))) > 0 and ViewCode  <> ''0'') THEN 1 ELSE 0 END) AS ViewCode
		,sum(CASE WHEN (len(ltrim(rtrim(ViewQualityCode))) > 0 and ViewQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS ViewQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterAccessableInd))) > 0 and WaterAccessableInd  <> ''0'') THEN 1 ELSE 0 END) AS WaterAccessableInd
		,sum(CASE WHEN (len(ltrim(rtrim(WaterFeatureInd))) > 0 and WaterFeatureInd  <> ''0'') THEN 1 ELSE 0 END) AS WaterFeatureInd
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontCode))) > 0 and WaterfrontCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontFeet))) > 0 and WaterfrontFeet  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontFeet
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontQualityCode))) > 0 and WaterfrontQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingArea))) > 0 and BuildingArea  <> ''0'') THEN 1 ELSE 0 END) AS BuildingArea
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingAreaInd))) > 0 and BuildingAreaInd  <> ''0'') THEN 1 ELSE 0 END) AS BuildingAreaInd
		,sum(CASE WHEN (len(ltrim(rtrim(TotalRooms))) > 0 and TotalRooms  <> ''0'') THEN 1 ELSE 0 END) AS TotalRooms
		,sum(CASE WHEN (len(ltrim(rtrim(Bedrooms))) > 0 and Bedrooms  <> ''0'') THEN 1 ELSE 0 END) AS Bedrooms
		,sum(CASE WHEN (len(ltrim(rtrim(BathTotalCalc))) > 0 and BathTotalCalc  <> ''0'') THEN 1 ELSE 0 END) AS BathTotalCalc
		,sum(CASE WHEN (len(ltrim(rtrim(BathFull))) > 0 and BathFull  <> ''0'') THEN 1 ELSE 0 END) AS BathFull
		,sum(CASE WHEN (len(ltrim(rtrim(BathsParcialNbr))) > 0 and BathsParcialNbr  <> ''0'') THEN 1 ELSE 0 END) AS BathsParcialNbr
		,sum(CASE WHEN (len(ltrim(rtrim(BathHalf))) > 0 and BathHalf  <> ''0'') THEN 1 ELSE 0 END) AS BathHalf
		,sum(CASE WHEN (len(ltrim(rtrim(Bath1QTR))) > 0 and Bath1QTR  <> ''0'') THEN 1 ELSE 0 END) AS Bath1QTR
		,sum(CASE WHEN (len(ltrim(rtrim(Bath3QTR))) > 0 and Bath3QTR  <> ''0'') THEN 1 ELSE 0 END) AS Bath3QTR
		,sum(CASE WHEN (len(ltrim(rtrim(BathFixturesNbr))) > 0 and BathFixturesNbr  <> ''0'') THEN 1 ELSE 0 END) AS BathFixturesNbr
		,sum(CASE WHEN (len(ltrim(rtrim(OtherRooms))) > 0 and OtherRooms  <> ''0'') THEN 1 ELSE 0 END) AS OtherRooms
		,sum(CASE WHEN (len(ltrim(rtrim(AirConditioningCode))) > 0 and AirConditioningCode  <> ''0'') THEN 1 ELSE 0 END) AS AirConditioningCode
		,sum(CASE WHEN (len(ltrim(rtrim(AirConditioningTypeCode))) > 0 and AirConditioningTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS AirConditioningTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(BasementCode))) > 0 and BasementCode  <> ''0'') THEN 1 ELSE 0 END) AS BasementCode
		,sum(CASE WHEN (len(ltrim(rtrim(BasementFinishedCode))) > 0 and BasementFinishedCode  <> ''0'') THEN 1 ELSE 0 END) AS BasementFinishedCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingClassCode))) > 0 and BuildingClassCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingClassCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingConditionCode))) > 0 and BuildingConditionCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingConditionCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingQualityCode))) > 0 and BuildingQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConstructionTypeCode))) > 0 and ConstructionTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS ConstructionTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(DeckCode))) > 0 and DeckCode  <> ''0'') THEN 1 ELSE 0 END) AS DeckCode
		,sum(CASE WHEN (len(ltrim(rtrim(ElectricityCode))) > 0 and ElectricityCode  <> ''0'') THEN 1 ELSE 0 END) AS ElectricityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ExteriorWallsCode))) > 0 and ExteriorWallsCode  <> ''0'') THEN 1 ELSE 0 END) AS ExteriorWallsCode
		,sum(CASE WHEN (len(ltrim(rtrim(FireplaceCode))) > 0 and FireplaceCode  <> ''0'') THEN 1 ELSE 0 END) AS FireplaceCode
		,sum(CASE WHEN (len(ltrim(rtrim(FloorCoverCode))) > 0 and FloorCoverCode  <> ''0'') THEN 1 ELSE 0 END) AS FloorCoverCode
		,sum(CASE WHEN (len(ltrim(rtrim(FloorTypeCode))) > 0 and FloorTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS FloorTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(FoundationInd))) > 0 and FoundationInd  <> ''0'') THEN 1 ELSE 0 END) AS FoundationInd
		,sum(CASE WHEN (len(ltrim(rtrim(FrameCode))) > 0 and FrameCode  <> ''0'') THEN 1 ELSE 0 END) AS FrameCode
		,sum(CASE WHEN (len(ltrim(rtrim(Garage))) > 0 and Garage  <> ''0'') THEN 1 ELSE 0 END) AS Garage
		,sum(CASE WHEN (len(ltrim(rtrim(GarageParkingNbr))) > 0 and GarageParkingNbr  <> ''0'') THEN 1 ELSE 0 END) AS GarageParkingNbr
		,sum(CASE WHEN (len(ltrim(rtrim(HeatCode))) > 0 and HeatCode  <> ''0'') THEN 1 ELSE 0 END) AS HeatCode
		,sum(CASE WHEN (len(ltrim(rtrim(HeatingFuelTypeCode))) > 0 and HeatingFuelTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS HeatingFuelTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(InteriorWallsCode))) > 0 and InteriorWallsCode  <> ''0'') THEN 1 ELSE 0 END) AS InteriorWallsCode
		,sum(CASE WHEN (len(ltrim(rtrim(PavingCode))) > 0 and PavingCode  <> ''0'') THEN 1 ELSE 0 END) AS PavingCode
		,sum(CASE WHEN (len(ltrim(rtrim(PatioCode))) > 0 and PatioCode  <> ''0'') THEN 1 ELSE 0 END) AS PatioCode
		,sum(CASE WHEN (len(ltrim(rtrim(PoolCode))) > 0 and PoolCode  <> ''0'') THEN 1 ELSE 0 END) AS PoolCode
		,sum(CASE WHEN (len(ltrim(rtrim(PorchCode))) > 0 and PorchCode  <> ''0'') THEN 1 ELSE 0 END) AS PorchCode
		,sum(CASE WHEN (len(ltrim(rtrim(RoofCoverCode))) > 0 and RoofCoverCode  <> ''0'') THEN 1 ELSE 0 END) AS RoofCoverCode
		,sum(CASE WHEN (len(ltrim(rtrim(RoofTypeCode))) > 0 and RoofTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS RoofTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(SewerCode))) > 0 and SewerCode  <> ''0'') THEN 1 ELSE 0 END) AS SewerCode
		,sum(CASE WHEN (len(ltrim(rtrim(ShapeCode))) > 0 and ShapeCode  <> ''0'') THEN 1 ELSE 0 END) AS ShapeCode
		,sum(CASE WHEN (len(ltrim(rtrim(StoriesCode))) > 0 and StoriesCode  <> ''0'') THEN 1 ELSE 0 END) AS StoriesCode
		,sum(CASE WHEN (len(ltrim(rtrim(StoriesNbrCode))) > 0 and StoriesNbrCode  <> ''0'') THEN 1 ELSE 0 END) AS StoriesNbrCode
		,sum(CASE WHEN (len(ltrim(rtrim(StyleCode))) > 0 and StyleCode  <> ''0'') THEN 1 ELSE 0 END) AS StyleCode
		,sum(CASE WHEN (len(ltrim(rtrim(WallExteriorCode))) > 0 and WallExteriorCode  <> ''0'') THEN 1 ELSE 0 END) AS WallExteriorCode
		,sum(CASE WHEN (len(ltrim(rtrim(WallheightCode))) > 0 and WallheightCode  <> ''0'') THEN 1 ELSE 0 END) AS WallheightCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterCode))) > 0 and WaterCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterCode
		,sum(CASE WHEN (len(ltrim(rtrim(YearBuilt))) > 0 and YearBuilt  <> ''0'') THEN 1 ELSE 0 END) AS YearBuilt
		,sum(CASE WHEN (len(ltrim(rtrim(EffectiveYearBuilt))) > 0 and EffectiveYearBuilt  <> ''0'') THEN 1 ELSE 0 END) AS EffectiveYearBuilt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBuildingsNbr))) > 0 and SumBuildingsNbr  <> ''0'') THEN 1 ELSE 0 END) AS SumBuildingsNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SumAboveGradeLivingSqFt))) > 0 and SumAboveGradeLivingSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumAboveGradeLivingSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumAdjAreaSqFt))) > 0 and SumAdjAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumAdjAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBasementSqFt))) > 0 and SumBasementSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumBasementSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBuildingSqFt))) > 0 and SumBuildingSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumBuildingSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGarageSqFt))) > 0 and SumGarageSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGarageSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGrossAreaSqFt))) > 0 and SumGrossAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGrossAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGroundFloorSqFt))) > 0 and SumGroundFloorSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGroundFloorSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumLivingAreaSqFt))) > 0 and SumLivingAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumLivingAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumResidentialUnits))) > 0 and SumResidentialUnits  <> ''0'') THEN 1 ELSE 0 END) AS SumResidentialUnits
		,sum(CASE WHEN (len(ltrim(rtrim(SumCommercialUnits))) > 0 and SumCommercialUnits  <> ''0'') THEN 1 ELSE 0 END) AS SumCommercialUnits
		,sum(CASE WHEN (len(ltrim(rtrim(AssdLandValue))) > 0 and AssdLandValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdImprovementValue))) > 0 and AssdImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdTotalValue))) > 0 and AssdTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdYear))) > 0 and AssdYear  <> ''0'') THEN 1 ELSE 0 END) AS AssdYear
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueLand))) > 0 and MarketValueLand  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueLand
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueImprovement))) > 0 and MarketValueImprovement  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueImprovement
		,sum(CASE WHEN (len(ltrim(rtrim(MarketTotalValue))) > 0 and MarketTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS MarketTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueYear))) > 0 and MarketValueYear  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueYear
		,sum(CASE WHEN (len(ltrim(rtrim(ApprLandValue))) > 0 and ApprLandValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprImprovementValue))) > 0 and ApprImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprTotalValue))) > 0 and ApprTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprYear))) > 0 and ApprYear  <> ''0'') THEN 1 ELSE 0 END) AS ApprYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxValueLand))) > 0 and TaxValueLand  <> ''0'') THEN 1 ELSE 0 END) AS TaxValueLand
		,sum(CASE WHEN (len(ltrim(rtrim(TaxValueImprovement))) > 0 and TaxValueImprovement  <> ''0'') THEN 1 ELSE 0 END) AS TaxValueImprovement
		,sum(CASE WHEN (len(ltrim(rtrim(TaxTotalValue))) > 0 and TaxTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS TaxTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(TaxableYear))) > 0 and TaxableYear  <> ''0'') THEN 1 ELSE 0 END) AS TaxableYear
		,sum(CASE WHEN (len(ltrim(rtrim(UNVLandValue))) > 0 and UNVLandValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVImprovementValue))) > 0 and UNVImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVTotalValue))) > 0 and UNVTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVValueYear))) > 0 and UNVValueYear  <> ''0'') THEN 1 ELSE 0 END) AS UNVValueYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxRateCodeArea))) > 0 and TaxRateCodeArea  <> ''0'') THEN 1 ELSE 0 END) AS TaxRateCodeArea
		,sum(CASE WHEN (len(ltrim(rtrim(p.TaxYear))) > 0 and p.TaxYear  <> ''0'') THEN 1 ELSE 0 END) AS TaxYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxAmount))) > 0 and TaxAmount  <> ''0'') THEN 1 ELSE 0 END) AS TaxAmount
		,sum(CASE WHEN (len(ltrim(rtrim(TaxDeliquentYear1))) > 0 and TaxDeliquentYear1  <> ''0'') THEN 1 ELSE 0 END) AS TaxDeliquentYear1
		,sum(CASE WHEN (len(ltrim(rtrim(TaxDeliquentValue1))) > 0 and TaxDeliquentValue1  <> ''0'') THEN 1 ELSE 0 END) AS TaxDeliquentValue1
		,sum(CASE WHEN (len(ltrim(rtrim(TaxExemptionCode))) > 0 and TaxExemptionCode  <> ''0'') THEN 1 ELSE 0 END) AS TaxExemptionCode
		,sum(CASE WHEN (len(ltrim(rtrim(TaxexemptInd))) > 0 and TaxexemptInd  <> ''0'') THEN 1 ELSE 0 END) AS TaxexemptInd
		,sum(CASE WHEN (len(ltrim(rtrim(CalifHomeownerInd))) > 0 and CalifHomeownerInd  <> ''0'') THEN 1 ELSE 0 END) AS CalifHomeownerInd
		,sum(CASE WHEN (len(ltrim(rtrim(CemeteryInd))) > 0 and CemeteryInd  <> ''0'') THEN 1 ELSE 0 END) AS CemeteryInd
		,sum(CASE WHEN (len(ltrim(rtrim(DisabledInd))) > 0 and DisabledInd  <> ''0'') THEN 1 ELSE 0 END) AS DisabledInd
		,sum(CASE WHEN (len(ltrim(rtrim(HomesteadInd))) > 0 and HomesteadInd  <> ''0'') THEN 1 ELSE 0 END) AS HomesteadInd
		,sum(CASE WHEN (len(ltrim(rtrim(HospitalInd))) > 0 and HospitalInd  <> ''0'') THEN 1 ELSE 0 END) AS HospitalInd
		,sum(CASE WHEN (len(ltrim(rtrim(LibraryInd))) > 0 and LibraryInd  <> ''0'') THEN 1 ELSE 0 END) AS LibraryInd
		,sum(CASE WHEN (len(ltrim(rtrim(PublicUtilityInd))) > 0 and PublicUtilityInd  <> ''0'') THEN 1 ELSE 0 END) AS PublicUtilityInd
		,sum(CASE WHEN (len(ltrim(rtrim(ReligiousInd))) > 0 and ReligiousInd  <> ''0'') THEN 1 ELSE 0 END) AS ReligiousInd
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolCollegeInd))) > 0 and SchoolCollegeInd  <> ''0'') THEN 1 ELSE 0 END) AS SchoolCollegeInd
		,sum(CASE WHEN (len(ltrim(rtrim(SeniorInd))) > 0 and SeniorInd  <> ''0'') THEN 1 ELSE 0 END) AS SeniorInd
		,sum(CASE WHEN (len(ltrim(rtrim(VeteranInd))) > 0 and VeteranInd  <> ''0'') THEN 1 ELSE 0 END) AS VeteranInd
		,sum(CASE WHEN (len(ltrim(rtrim(WelfareInd))) > 0 and WelfareInd  <> ''0'') THEN 1 ELSE 0 END) AS WelfareInd
		,sum(CASE WHEN (len(ltrim(rtrim(WidowInd))) > 0 and WidowInd  <> ''0'') THEN 1 ELSE 0 END) AS WidowInd
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict1Code))) > 0 and SchoolTaxDistrict1Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict1Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict1Ind))) > 0 and SchoolTaxDistrict1Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict1Ind
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict2Code))) > 0 and SchoolTaxDistrict2Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict2Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict2Ind))) > 0 and SchoolTaxDistrict2Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict2Ind
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict3Code))) > 0 and SchoolTaxDistrict3Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict3Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict3Ind))) > 0 and SchoolTaxDistrict3Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict3Ind
		,sum(CASE WHEN (len(ltrim(rtrim(FADeleteFlag))) > 0 and FADeleteFlag  <> ''0'') THEN 1 ELSE 0 END) AS FADeleteFlag
		,sum(CASE WHEN (len(ltrim(rtrim(CurrentSaleTransactionId))) > 0 and CurrentSaleTransactionId  <> ''0'') THEN 1 ELSE 0 END) AS CurrentSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(CurrentSaleChronoKey))) > 0 and CurrentSaleChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS CurrentSaleChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputDocNbr))) > 0 and CurrSaleInputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputBook))) > 0 and CurrSaleInputBook  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputBook
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputPage))) > 0 and CurrSaleInputPage  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputPage
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatDocNbr))) > 0 and CurrSaleFormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatBook))) > 0 and CurrSaleFormatBook  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatPage))) > 0 and CurrSaleFormatPage  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleRecordingDate))) > 0 and CurrSaleRecordingDate  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleDocumentType))) > 0 and CurrSaleDocumentType  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleDocumentType
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSalesPrice))) > 0 and CurrSalesPrice  <> ''0'') THEN 1 ELSE 0 END) AS CurrSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSalesPriceCode))) > 0 and CurrSalesPriceCode  <> ''0'') THEN 1 ELSE 0 END) AS CurrSalesPriceCode
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleContractDate))) > 0 and CurrSaleContractDate  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleContractDate
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer1FullName))) > 0 and CurrSaleBuyer1FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer2FullName))) > 0 and CurrSaleBuyer2FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer3FullName))) > 0 and CurrSaleBuyer3FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer3FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer4FullName))) > 0 and CurrSaleBuyer4FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer4FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleSeller1FullName))) > 0 and CurrSaleSeller1FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleSeller1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleSeller2FullName))) > 0 and CurrSaleSeller2FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleSeller2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputDocNbr))) > 0 and ConCurrMtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputBook))) > 0 and ConCurrMtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputPage))) > 0 and ConCurrMtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatDocNbr))) > 0 and ConCurrMtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatBook))) > 0 and ConCurrMtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatPage))) > 0 and ConCurrMtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1RecordingDt))) > 0 and ConCurrMtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanAmt))) > 0 and ConCurrMtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Lender))) > 0 and ConCurrMtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LenderCode))) > 0 and ConCurrMtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LenderType))) > 0 and ConCurrMtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1PrivateLender))) > 0 and ConCurrMtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Term))) > 0 and ConCurrMtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanDueDt))) > 0 and ConCurrMtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1AdjOrFix))) > 0 and ConCurrMtg1AdjOrFix  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1AdjOrFix
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanType))) > 0 and ConCurrMtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Typefinancing))) > 0 and ConCurrMtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LienPosition))) > 0 and ConCurrMtg1LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputDocNbr))) > 0 and ConCurrMtg2InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputBook))) > 0 and ConCurrMtg2InputBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputPage))) > 0 and ConCurrMtg2InputPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatDocNbr))) > 0 and ConCurrMtg2FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatBook))) > 0 and ConCurrMtg2FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatPage))) > 0 and ConCurrMtg2FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2RecordingDt))) > 0 and ConCurrMtg2RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanAmt))) > 0 and ConCurrMtg2LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Lender))) > 0 and ConCurrMtg2Lender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Lender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LenderCode))) > 0 and ConCurrMtg2LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LenderType))) > 0 and ConCurrMtg2LenderType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2PrivateLender))) > 0 and ConCurrMtg2PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Term))) > 0 and ConCurrMtg2Term  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Term
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanDueDt))) > 0 and ConCurrMtg2LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2AdjOrFix))) > 0 and ConCurrMtg2AdjOrFix  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2AdjOrFix
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanType))) > 0 and ConCurrMtg2LoanType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Typefinancing))) > 0 and ConCurrMtg2Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LienPosition))) > 0 and ConCurrMtg2LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1TransactionId))) > 0 and Mtg1TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1ChronoKey))) > 0 and Mtg1ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanAmt))) > 0 and Mtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Lender))) > 0 and Mtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LenderCode))) > 0 and Mtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LenderType))) > 0 and Mtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1PrivateLender))) > 0 and Mtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Term))) > 0 and Mtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanDueDt))) > 0 and Mtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1AdjRider))) > 0 and Mtg1AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanType))) > 0 and Mtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Typefinancing))) > 0 and Mtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LienPosition))) > 0 and Mtg1LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2TransactionId))) > 0 and Mtg2TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2ChronoKey))) > 0 and Mtg2ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputDocNbr))) > 0 and Mtg2InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputBook))) > 0 and Mtg2InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputPage))) > 0 and Mtg2InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatDocNbr))) > 0 and Mtg2FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatBook))) > 0 and Mtg2FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatPage))) > 0 and Mtg2FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2RecordingDt))) > 0 and Mtg2RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanAmt))) > 0 and Mtg2LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Lender))) > 0 and Mtg2Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LenderCode))) > 0 and Mtg2LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LenderType))) > 0 and Mtg2LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2PrivateLender))) > 0 and Mtg2PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Term))) > 0 and Mtg2Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanDueDt))) > 0 and Mtg2LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2AdjRider))) > 0 and Mtg2AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanType))) > 0 and Mtg2LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Typefinancing))) > 0 and Mtg2Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LienPosition))) > 0 and Mtg2LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3TransactionId))) > 0 and Mtg3TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3ChronoKey))) > 0 and Mtg3ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputDocNbr))) > 0 and Mtg3InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputBook))) > 0 and Mtg3InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputPage))) > 0 and Mtg3InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatDocNbr))) > 0 and Mtg3FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatBook))) > 0 and Mtg3FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatPage))) > 0 and Mtg3FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3RecordingDt))) > 0 and Mtg3RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanAmt))) > 0 and Mtg3LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Lender))) > 0 and Mtg3Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LenderCode))) > 0 and Mtg3LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LenderType))) > 0 and Mtg3LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3PrivateLender))) > 0 and Mtg3PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Term))) > 0 and Mtg3Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanDueDt))) > 0 and Mtg3LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3AdjRider))) > 0 and Mtg3AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanType))) > 0 and Mtg3LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Typefinancing))) > 0 and Mtg3Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LienPosition))) > 0 and Mtg3LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4TransactionId))) > 0 and Mtg4TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4ChronoKey))) > 0 and Mtg4ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputDocNbr))) > 0 and Mtg4InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputBook))) > 0 and Mtg4InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputPage))) > 0 and Mtg4InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatDocNbr))) > 0 and Mtg4FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatBook))) > 0 and Mtg4FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatPage))) > 0 and Mtg4FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4RecordingDt))) > 0 and Mtg4RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanAmt))) > 0 and Mtg4LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Lender))) > 0 and Mtg4Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LenderCode))) > 0 and Mtg4LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LenderType))) > 0 and Mtg4LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4PrivateLender))) > 0 and Mtg4PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Term))) > 0 and Mtg4Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanDueDt))) > 0 and Mtg4LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4AdjRider))) > 0 and Mtg4AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanType))) > 0 and Mtg4LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Typefinancing))) > 0 and Mtg4Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LienPosition))) > 0 and Mtg4LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleTransactionId))) > 0 and PrevSaleTransactionId  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleChronoKey))) > 0 and PrevSaleChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputDocNbr))) > 0 and PrevSaleInputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputBook))) > 0 and PrevSaleInputBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputPage))) > 0 and PrevSaleInputPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatDocNbr))) > 0 and PrevSaleFormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatBook))) > 0 and PrevSaleFormatBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatPage))) > 0 and PrevSaleFormatPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleRecordingDate))) > 0 and PrevSaleRecordingDate  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSalesPrice))) > 0 and PrevSalesPrice  <> ''0'') THEN 1 ELSE 0 END) AS PrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSalesPriceCode))) > 0 and PrevSalesPriceCode  <> ''0'') THEN 1 ELSE 0 END) AS PrevSalesPriceCode
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleContractDate))) > 0 and PrevSaleContractDate  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleContractDate
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleDocumentType))) > 0 and PrevSaleDocumentType  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleDocumentType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer1FullName))) > 0 and PrevSaleBuyer1FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer2FullName))) > 0 and PrevSaleBuyer2FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer3FullName))) > 0 and PrevSaleBuyer3FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer3FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer4FullName))) > 0 and PrevSaleBuyer4FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer4FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleSeller1FullName))) > 0 and PrevSaleSeller1FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleSeller1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleSeller2FullName))) > 0 and PrevSaleSeller2FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleSeller2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputDocNbr))) > 0 and PrevMtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputBook))) > 0 and PrevMtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputPage))) > 0 and PrevMtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatDocNbr))) > 0 and PrevMtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatBook))) > 0 and PrevMtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatPage))) > 0 and PrevMtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1RecordingDt))) > 0 and PrevMtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanAmt))) > 0 and PrevMtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Lender))) > 0 and PrevMtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LenderCode))) > 0 and PrevMtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LenderType))) > 0 and PrevMtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1PrivateLender))) > 0 and PrevMtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Term))) > 0 and PrevMtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanDueDt))) > 0 and PrevMtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1AdjRider))) > 0 and PrevMtg1AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanType))) > 0 and PrevMtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Typefinancing))) > 0 and PrevMtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPVCount))) > 0 and SitusDPVCount  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPVCount
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPVFootnote))) > 0 and SitusDPVFootnote  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPVFootnote
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLACS))) > 0 and SitusLACS  <> ''0'') THEN 1 ELSE 0 END) AS SitusLACS
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLACSLinkInd))) > 0 and SitusLACSLinkInd  <> ''0'') THEN 1 ELSE 0 END) AS SitusLACSLinkInd
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPCheckDigit))) > 0 and SitusDPCheckDigit  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPCheckDigit
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPCheckCode))) > 0 and SitusDPCheckCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPCheckCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusBlock))) > 0 and SitusCensusBlock  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusBlock
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoErrorCode))) > 0 and SitusGeoErrorCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoErrorCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoStatusCode))) > 0 and SitusGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPVCount))) > 0 and MailingDPVCount  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPVCount
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPVFootnote))) > 0 and MailingDPVFootnote  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPVFootnote
		,sum(CASE WHEN (len(ltrim(rtrim(MailingLACS))) > 0 and MailingLACS  <> ''0'') THEN 1 ELSE 0 END) AS MailingLACS
		,sum(CASE WHEN (len(ltrim(rtrim(MailingLACSLinkInd))) > 0 and MailingLACSLinkInd  <> ''0'') THEN 1 ELSE 0 END) AS MailingLACSLinkInd
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPCheckDigit))) > 0 and MailingDPCheckDigit  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPCheckDigit
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPCheckCode))) > 0 and MailingDPCheckCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPCheckCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCensusBlock))) > 0 and MailingCensusBlock  <> ''0'') THEN 1 ELSE 0 END) AS MailingCensusBlock
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCensusTract))) > 0 and MailingCensusTract  <> ''0'') THEN 1 ELSE 0 END) AS MailingCensusTract
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoErrorCode))) > 0 and MailingGeoErrorCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoErrorCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoStatusCode))) > 0 and MailingGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(CheckOwnership))) > 0 and CheckOwnership  <> ''0'') THEN 1 ELSE 0 END) AS CheckOwnership
		,sum(CASE WHEN (len(ltrim(rtrim(FAUCIDFlag))) > 0 and FAUCIDFlag  <> ''0'') THEN 1 ELSE 0 END) AS FAUCIDFlag
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatBook))) > 0 and Mtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatDocNbr))) > 0 and Mtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatPage))) > 0 and Mtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputBook))) > 0 and Mtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputDocNbr))) > 0 and Mtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputPage))) > 0 and Mtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1RecordingDt))) > 0 and Mtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticFinishSqFt))) > 0 and AtticFinishSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticSqFt))) > 0 and AtticSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticUnfinSqFt))) > 0 and AtticUnfinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticUnfinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(BankOwned))) > 0 and BankOwned  <> ''0'') THEN 1 ELSE 0 END) AS BankOwned
		,sum(CASE WHEN (len(ltrim(rtrim(BasementFinishSqFt))) > 0 and BasementFinishSqFt   <> ''0'') THEN 1 ELSE 0 END) AS BasementFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(BasementUnfinSqFt))) > 0 and BasementUnfinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS BasementUnfinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(p.EditionNumber))) > 0 and p.EditionNumber  <> ''0'') THEN 1 ELSE 0 END) AS EditionNumber
		,sum(CASE WHEN (len(ltrim(rtrim(FAEstLotSqFt))) > 0 and FAEstLotSqFt  <> ''0'') THEN 1 ELSE 0 END) AS FAEstLotSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(FAGeoStatusCode))) > 0 and FAGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS FAGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedFlag))) > 0 and FAIsListedFlag  <> ''0'') THEN 1 ELSE 0 END) AS FAIsListedFlag
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedFlagDt))) is not null) THEN 1 ELSE 0 END) AS FAIsListedFlagDt
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedPriceRange))) > 0 and FAIsListedPriceRange  <> ''0'') THEN 1 ELSE 0 END) AS FAIsListedPriceRange
		,sum(CASE WHEN (len(ltrim(rtrim(FALatitude))) > 0 and FALatitude  <> ''0'') THEN 1 ELSE 0 END) AS FALatitude
		,sum(CASE WHEN (len(ltrim(rtrim(FALongitude))) > 0 and FALongitude  <> ''0'') THEN 1 ELSE 0 END) AS FALongitude
		,sum(CASE WHEN (len(ltrim(rtrim(FAOLTV))) > 0 and FAOLTV  <> ''0'') THEN 1 ELSE 0 END) AS FAOLTV
		,sum(CASE WHEN (len(ltrim(rtrim(GarageFinishSqFt))) > 0 and GarageFinishSqFt  <> ''0'') THEN 1 ELSE 0 END) AS GarageFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(GarageUnFinSqFt))) > 0 and GarageUnFinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS GarageUnFinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(LienPosUpdateDate)))is not null) THEN 1 ELSE 0 END) AS LienPosUpdateDate
		,sum(CASE WHEN (len(ltrim(rtrim(LienPosUpdateFlag))) > 0 and LienPosUpdateFlag  <> ''0'') THEN 1 ELSE 0 END) AS LienPosUpdateFlag
		,sum(CASE WHEN (len(ltrim(rtrim(MailForeignAddrInd))) > 0 and MailForeignAddrInd  <> ''0'') THEN 1 ELSE 0 END) AS MailForeignAddrInd
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoCodeResults))) > 0 and MailingGeoCodeResults  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoCodeResults
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputDocNbr))) > 0 and Mtg3InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatBook))) > 0 and Mtg4FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatDocNbr))) > 0 and Mtg4FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatPage))) > 0 and Mtg4FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputDocNbr))) > 0 and Mtg4InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolDistrictName))) > 0 and SchoolDistrictName  <> ''0'') THEN 1 ELSE 0 END) AS SchoolDistrictName
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoCodeResults))) > 0 and SitusGeoCodeResults  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoCodeResults
		,sum(CASE WHEN (len(ltrim(rtrim(TotalOpenLienAmt))) > 0 and TotalOpenLienAmt  <> ''0'') THEN 1 ELSE 0 END) AS TotalOpenLienAmt
		,sum(CASE WHEN (len(ltrim(rtrim(TotalOpenLienNbr))) > 0 and TotalOpenLienNbr  <> ''0'') THEN 1 ELSE 0 END) AS TotalOpenLienNbr
		,sum(CASE WHEN (len(ltrim(rtrim(TPGeoStatusCode))) > 0 and TPGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS TPGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(TPLatitude))) > 0 and TPLatitude  <> ''0'') THEN 1 ELSE 0 END) AS TPLatitude
		,sum(CASE WHEN (len(ltrim(rtrim(TPLongitude))) > 0 and TPLongitude  <> ''0'') THEN 1 ELSE 0 END) AS TPLongitude
		,sum(CASE WHEN (len(ltrim(rtrim(VacantFlag))) > 0 and VacantFlag  <> ''0'') THEN 1 ELSE 0 END) AS VacantFlag
		,sum(CASE WHEN (VacantFlagDate is not null) THEN 1 ELSE 0 END) AS VacantFlagDate
		,sum(CASE WHEN (len(ltrim(rtrim(MailingFIPS))) > 0 and MailingFIPS  <> ''0'') THEN 1 ELSE 0 END) AS MailingFIPS
		,sum(CASE WHEN (len(ltrim(rtrim(DBSTaxAmount))) > 0 and DBSTaxAmount  <> ''0'') THEN 1 ELSE 0 END) AS DBSTaxAmount
		,sum(CASE WHEN (len(ltrim(rtrim(p.DBSTaxYear))) > 0 and p.DBSTaxYear  <> ''0'') THEN 1 ELSE 0 END) AS DBSTaxYear
		,sum(CASE WHEN ([FATimestamp] is not null) THEN 1 ELSE 0 END) AS FATimestamp
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken0 ))) > 0 and  AssessorLkupToken0   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken0
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken1 ))) > 0 and  AssessorLkupToken1   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken1
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken2 ))) > 0 and  AssessorLkupToken2   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken2
		,sum(CASE WHEN (len(ltrim(rtrim( ConCurrMtg1InterestRate ))) > 0 and  ConCurrMtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  ConCurrMtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( ConCurrMtg2InterestRate ))) > 0 and  ConCurrMtg2InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  ConCurrMtg2InterestRate
		,sum(CASE WHEN ( FAActiveDt  is not null) THEN 1 ELSE 0 END) AS  FAActiveDt  
		,sum(CASE WHEN ( FAAddressParsedMailing  is not null) THEN 1 ELSE 0 END) AS  FAAddressParsedMailing  
		,sum(CASE WHEN (len(ltrim(rtrim( FACLTV ))) > 0 and  FACLTV   <> ''0'') THEN 1 ELSE 0 END) AS  FACLTV
		,sum(CASE WHEN ( FACreateDt  is not null) THEN 1 ELSE 0 END) AS  FACreateDt  
		,sum(CASE WHEN ( FADataArchiveDate  is not null) THEN 1 ELSE 0 END) AS  FADataArchiveDate  
		,sum(CASE WHEN (len(ltrim(rtrim( FADateReceived ))) > 0 and  FADateReceived   <> ''0'') THEN 1 ELSE 0 END) AS  FADateReceived
		,sum(CASE WHEN ( FADeriveProcessDt  is not null) THEN 1 ELSE 0 END) AS  FADeriveProcessDt  
		,sum(CASE WHEN ( FAEnhanceprocessDt  is not null) THEN 1 ELSE 0 END) AS  FAEnhanceprocessDt  
		,sum(CASE WHEN ( FAOwnershipUpdateDt  is not null) THEN 1 ELSE 0 END) AS  FAOwnershipUpdateDt  
		,sum(CASE WHEN (len(ltrim(rtrim( FAOwnerTransactionId ))) > 0 and  FAOwnerTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  FAOwnerTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( FASourceInd ))) > 0 and  FASourceInd   <> ''0'') THEN 1 ELSE 0 END) AS  FASourceInd
		,sum(CASE WHEN (len(ltrim(rtrim( FAUserId ))) > 0 and  FAUserId   <> ''0'') THEN 1 ELSE 0 END) AS  FAUserId
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1EstLoanBalance ))) > 0 and  Mtg1EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1EstPaymentAmt ))) > 0 and  Mtg1EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1InterestRate ))) > 0 and  Mtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2EstLoanBalance ))) > 0 and  Mtg2EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2EstPaymentAmt ))) > 0 and  Mtg2EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2InterestRate ))) > 0 and  Mtg2InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3EstLoanBalance ))) > 0 and  Mtg3EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3EstPaymentAmt ))) > 0 and  Mtg3EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3InterestRate ))) > 0 and  Mtg3InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4EstLoanBalance ))) > 0 and  Mtg4EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4EstPaymentAmt ))) > 0 and  Mtg4EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4InterestRate ))) > 0 and  Mtg4InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( OldApnIndicator ))) > 0 and  OldApnIndicator   <> ''0'') THEN 1 ELSE 0 END) AS  OldApnIndicator
		,sum(CASE WHEN (len(ltrim(rtrim( PrevMtg1InterestRate ))) > 0 and  PrevMtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  PrevMtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( VendorLoadDate ))) > 0 and  VendorLoadDate   <> ''0'') THEN 1 ELSE 0 END) AS  VendorLoadDate
		,sum(CASE WHEN (len(ltrim(rtrim( VersionId ))) > 0 and  VersionId   <> ''0'') THEN 1 ELSE 0 END) AS  VersionId
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSaleTransactionId ))) > 0 and  SecondPrevSaleTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSaleRecordingDate ))) > 0 and  SecondPrevSaleRecordingDate   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSalesPrice ))) > 0 and  SecondPrevSalesPrice   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSaleTransactionId ))) > 0 and  ThirdPrevSaleTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSaleRecordingDate ))) > 0 and  ThirdPrevSaleRecordingDate   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSalesPrice ))) > 0 and  ThirdPrevSalesPrice   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim( HouseFacingDirection ))) > 0 and  HouseFacingDirection   <> ''0'') THEN 1 ELSE 0 END) AS  HouseFacingDirection -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( FARooftopLatitude ))) > 0 and  FARooftopLatitude   <> ''0'') THEN 1 ELSE 0 END) AS  FARooftopLatitude -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( FARooftopLongitude ))) > 0 and  FARooftopLongitude   <> ''0'') THEN 1 ELSE 0 END) AS  FARooftopLongitude -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( BuildingEstFootprintSqFt ))) > 0 and  BuildingEstFootprintSqFt   <> ''0'') THEN 1 ELSE 0 END) AS  BuildingEstFootprintSqFt -- GM added 20190314
		,sum(CASE WHEN (len(ltrim(rtrim( BathTotalCalcEst ))) > 0 and  BathTotalCalcEst   <> ''0'') THEN 1 ELSE 0 END) AS  BathTotalCalcEst  -- GM added 20190415
		,sum(CASE WHEN (len(ltrim(rtrim( DQOZ_TractType ))) > 0 and  DQOZ_TractType   <> ''0'') THEN 1 ELSE 0 END) AS  DQOZ_TractType  -- GM added 20190416
		,sum(CASE WHEN (len(ltrim(rtrim( DQOZ_ACSDataSource ))) > 0 and  DQOZ_ACSDataSource   <> ''0'') THEN 1 ELSE 0 END) AS  DQOZ_ACSDataSource  -- GM added 20190416
		,sum(CASE WHEN (len(ltrim(rtrim( VacantScore ))) > 0 and  VacantScore   <> ''0'') THEN 1 ELSE 0 END) AS  VacantScore  -- GM added 20190715
		,sum(CASE WHEN (len(ltrim(rtrim( BedroomsEst ))) > 0 and  BedroomsEst   <> ''0'') THEN 1 ELSE 0 END) AS  BedroomsEst  -- GM added 20191001
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_REF_ID ))) > 0 and  DTDB_REF_ID   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_REF_ID  -- GM added 20191205
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_FORMATTED_APN ))) > 0 and  DTDB_FORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_FORMATTED_APN  -- GM added 20191205
		,sum(CASE WHEN (len(ltrim(rtrim( MailingLabelName ))) > 0 and  MailingLabelName   <> ''0'') THEN 1 ELSE 0 END) AS  MailingLabelName -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( Name1TypeInd ))) > 0 and  Name1TypeInd   <> ''0'') THEN 1 ELSE 0 END) AS  Name1TypeInd -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( Name2TypeInd ))) > 0 and  Name2TypeInd   <> ''0'') THEN 1 ELSE 0 END) AS  Name2TypeInd -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( TaxSourceInd ))) > 0 and  TaxSourceInd   <> ''0'') THEN 1 ELSE 0 END) AS  TaxSourceInd -- GM added 20200312
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionName ))) > 0 and  FASubdivisionName   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionName -- GM added 20200427
		,sum(CASE WHEN (len(ltrim(rtrim( FAComplexNbrUnits ))) > 0 and  FAComplexNbrUnits   <> ''0'') THEN 1 ELSE 0 END) AS  FAComplexNbrUnits -- GM added 20200427
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionNameID ))) > 0 and  FASubdivisionNameID   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionNameID -- GM added 20201027
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionPhase ))) > 0 and  FASubdivisionPhase   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionPhase -- GM added 20201113
		,sum(CASE WHEN (len(ltrim(rtrim( ElevatorCode ))) > 0 and  ElevatorCode   <> ''0'') THEN 1 ELSE 0 END) AS  ElevatorCode -- GM added 20201210
		,sum(CASE WHEN (len(ltrim(rtrim( FAEstimatedMultiPolygonFlag ))) > 0 and  FAEstimatedMultiPolygonFlag   <> ''0'') THEN 1 ELSE 0 END) AS  FAEstimatedMultiPolygonFlag -- GM added 20201210 rename 20210204
		,sum(CASE WHEN (len(ltrim(rtrim( FAEstimatedNumberofBuildings ))) > 0 and  FAEstimatedNumberofBuildings   <> ''0'') THEN 1 ELSE 0 END) AS  FAEstimatedNumberofBuildings -- GM added 20201210
		,sum(CASE WHEN (len(ltrim(rtrim( Poverty ))) > 0 and  Poverty   <> ''0'') THEN 1 ELSE 0 END) AS  Poverty -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( UnEmployment ))) > 0 and  UnEmployment   <> ''0'') THEN 1 ELSE 0 END) AS  UnEmployment -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( PopulationLoss ))) > 0 and  PopulationLoss   <> ''0'') THEN 1 ELSE 0 END) AS  PopulationLoss -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( RemoteRural ))) > 0 and  RemoteRural   <> ''0'') THEN 1 ELSE 0 END) AS  RemoteRural -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( Distressed ))) > 0 and  Distressed   <> ''0'') THEN 1 ELSE 0 END) AS  Distressed -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( UnderServed ))) > 0 and  UnderServed   <> ''0'') THEN 1 ELSE 0 END) AS  UnderServed -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_UNFORMATTED_APN ))) > 0 and  DTDB_UNFORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_UNFORMATTED_APN -- GM added 20210505
		,sum(CASE WHEN (len(ltrim(rtrim( ConformingLoanLimitYear ))) > 0 and  ConformingLoanLimitYear   <> ''0'') THEN 1 ELSE 0 END) AS  ConformingLoanLimitYear -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( ConformingLoanLimit ))) > 0 and  ConformingLoanLimit   <> ''0'') THEN 1 ELSE 0 END) AS  ConformingLoanLimit -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( PriorConformingLoanLimitYear ))) > 0 and  PriorConformingLoanLimitYear   <> ''0'') THEN 1 ELSE 0 END) AS  PriorConformingLoanLimitYear -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( PriorConformingLoanLimit ))) > 0 and  PriorConformingLoanLimit   <> ''0'') THEN 1 ELSE 0 END) AS  PriorConformingLoanLimit -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( MTG1InterestRateSrce ))) > 0 and  MTG1InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG1InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG2InterestRateSrce ))) > 0 and  MTG2InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG2InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG3InterestRateSrce ))) > 0 and  MTG3InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG3InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG4InterestRateSrce ))) > 0 and  MTG4InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG4InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( CS_FORMATTED_APN ))) > 0 and  CS_FORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  CS_FORMATTED_APN -- GM added 20210718
		,sum(CASE WHEN (len(ltrim(rtrim( CS_UNFORMATTED_APN ))) > 0 and  CS_UNFORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  CS_UNFORMATTED_APN -- GM added 20210718
	from [data].[dbo].[property] p with(NOLOCK),[Global].[dbo].[County] g with(NOLOCK)
	where FIPS = '''+@FipsCode+''' and FIPSCODE = '''+@FipsCode+'''
		and FAUCIDFlag <>''D''
	group by [fips],[State],[County Name]
UNION ALL
	Select FIPS
		,[State]
		,[County Name]
		,sum(CASE WHEN (len(ltrim(rtrim(FIPS))) > 0 and FIPS  <> ''0'') THEN 1 ELSE 0 END) AS TotalCnt
		,sum(CASE WHEN (len(ltrim(rtrim(PropertyID))) > 0 and PropertyID  <> ''0'') THEN 1 ELSE 0 END) AS PropertyID
		,sum(CASE WHEN (len(ltrim(rtrim(FormattedAPN))) > 0 and FormattedAPN  <> ''0'') THEN 1 ELSE 0 END) AS FormattedAPN
		,sum(CASE WHEN (len(ltrim(rtrim(APNSeqNbr))) > 0 and APNSeqNbr  <> ''0'') THEN 1 ELSE 0 END) AS APNSeqNbr
		,sum(CASE WHEN (len(ltrim(rtrim(UnformattedAPN))) > 0 and UnformattedAPN  <> ''0'') THEN 1 ELSE 0 END) AS UnformattedAPN
		,sum(CASE WHEN (len(ltrim(rtrim(OldAPN))) > 0 and OldAPN  <> ''0'') THEN 1 ELSE 0 END) AS OldAPN
		,sum(CASE WHEN (len(ltrim(rtrim(OLDAPNSeqNbr))) > 0 and OLDAPNSeqNbr  <> ''0'') THEN 1 ELSE 0 END) AS OLDAPNSeqNbr
		,sum(CASE WHEN (len(ltrim(rtrim(TaxAccountNumber))) > 0 and TaxAccountNumber  <> ''0'') THEN 1 ELSE 0 END) AS TaxAccountNumber
		,sum(CASE WHEN (len(ltrim(rtrim(RecordType))) > 0 and RecordType  <> ''0'') THEN 1 ELSE 0 END) AS RecordType
		,sum(CASE WHEN (len(ltrim(rtrim(VendorPID))) > 0 and VendorPID  <> ''0'') THEN 1 ELSE 0 END) AS VendorPID
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdFullStreetAddress))) > 0 and SitusStdFullStreetAddress  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdFullStreetAddress
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbr))) > 0 and SitusStdHouseNbr  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbr2))) > 0 and SitusStdHouseNbr2  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbr2
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdHouseNbrSuffix))) > 0 and SitusStdHouseNbrSuffix  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdHouseNbrSuffix
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdDirectionLeft))) > 0 and SitusStdDirectionLeft  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdDirectionLeft
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdStreet))) > 0 and SitusStdStreet  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdStreet
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdMode))) > 0 and SitusStdMode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdMode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdDirectionRight))) > 0 and SitusStdDirectionRight  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdDirectionRight
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdUnitNbr))) > 0 and SitusStdUnitNbr  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdUnitNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdCity))) > 0 and SitusStdCity  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdCity
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdState))) > 0 and SitusStdState  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdState
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdZIP5))) > 0 and SitusStdZIP5  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdZIP5
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdZIP4))) > 0 and SitusStdZIP4  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdZIP4
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLatitude))) > 0 and SitusLatitude  <> ''0'') THEN 1 ELSE 0 END) AS SitusLatitude
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLongitude))) > 0 and SitusLongitude  <> ''0'') THEN 1 ELSE 0 END) AS SitusLongitude
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdCarrierCode))) > 0 and SitusStdCarrierCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdCarrierCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusTract))) > 0 and SitusCensusTract  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusTract
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusTractBlock))) > 0 and SitusCensusTractBlock  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusTractBlock
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdUnitType))) > 0 and SitusStdUnitType  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdUnitType
		,sum(CASE WHEN (len(ltrim(rtrim(SitusStdMatchCode))) > 0 and SitusStdMatchCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusStdMatchCode
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeSqFt))) > 0 and LotSizeSqFt  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeAcres))) > 0 and LotSizeAcres  <> ''0000000000'') THEN 1 ELSE 0 END) AS LotSizeAcres
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeFrontageFeet))) > 0 and LotSizeFrontageFeet  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeFrontageFeet
		,sum(CASE WHEN (len(ltrim(rtrim(LotSizeDepthFeet))) > 0 and LotSizeDepthFeet  <> ''0'') THEN 1 ELSE 0 END) AS LotSizeDepthFeet
		,sum(CASE WHEN (len(ltrim(rtrim(LotIrregularInd))) > 0 and LotIrregularInd  <> ''0'') THEN 1 ELSE 0 END) AS LotIrregularInd
		,sum(CASE WHEN (len(ltrim(rtrim(LotUsableSize))) > 0 and LotUsableSize  <> ''0'') THEN 1 ELSE 0 END) AS LotUsableSize
		,sum(CASE WHEN (len(ltrim(rtrim(PropertyClassID))) > 0 and PropertyClassID  <> ''0'') THEN 1 ELSE 0 END) AS PropertyClassID
		,sum(CASE WHEN (len(ltrim(rtrim(StdLandUseCode))) > 0 and StdLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS StdLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(StateLandUseCode))) > 0 and StateLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS StateLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(CountyLandUseCode))) > 0 and CountyLandUseCode  <> ''0'') THEN 1 ELSE 0 END) AS CountyLandUseCode
		,sum(CASE WHEN (len(ltrim(rtrim(CountyLandUseDescription))) > 0 and CountyLandUseDescription  <> ''0'') THEN 1 ELSE 0 END) AS CountyLandUseDescription
		,sum(CASE WHEN (len(ltrim(rtrim(TimeshareCode))) > 0 and TimeshareCode  <> ''0'') THEN 1 ELSE 0 END) AS TimeshareCode
		,sum(CASE WHEN (len(ltrim(rtrim(Zoning))) > 0 and Zoning  <> ''0'') THEN 1 ELSE 0 END) AS Zoning
		,sum(CASE WHEN (len(ltrim(rtrim(SiteInfluenceCode))) > 0 and SiteInfluenceCode  <> ''0'') THEN 1 ELSE 0 END) AS SiteInfluenceCode
		,sum(CASE WHEN (len(ltrim(rtrim(NeighborhoodCode))) > 0 and NeighborhoodCode  <> ''0'') THEN 1 ELSE 0 END) AS NeighborhoodCode
		,sum(CASE WHEN (len(ltrim(rtrim(TopographyCode))) > 0 and TopographyCode  <> ''0'') THEN 1 ELSE 0 END) AS TopographyCode
		,sum(CASE WHEN (len(ltrim(rtrim(MobileHomeInd))) > 0 and MobileHomeInd  <> ''0'') THEN 1 ELSE 0 END) AS MobileHomeInd
		,sum(CASE WHEN (len(ltrim(rtrim(LotCode))) > 0 and LotCode  <> ''0'') THEN 1 ELSE 0 END) AS LotCode
		,sum(CASE WHEN (len(ltrim(rtrim(LotNumber))) > 0 and LotNumber  <> ''0'') THEN 1 ELSE 0 END) AS LotNumber
		,sum(CASE WHEN (len(ltrim(rtrim(LandLot))) > 0 and LandLot  <> ''0'') THEN 1 ELSE 0 END) AS LandLot
		,sum(CASE WHEN (len(ltrim(rtrim(Block))) > 0 and Block  <> ''0'') THEN 1 ELSE 0 END) AS Block
		,sum(CASE WHEN (len(ltrim(rtrim(Section))) > 0 and Section  <> ''0'') THEN 1 ELSE 0 END) AS Section
		,sum(CASE WHEN (len(ltrim(rtrim(District))) > 0 and District  <> ''0'') THEN 1 ELSE 0 END) AS District
		,sum(CASE WHEN (len(ltrim(rtrim(LegalUnit))) > 0 and LegalUnit  <> ''0'') THEN 1 ELSE 0 END) AS LegalUnit
		,sum(CASE WHEN (len(ltrim(rtrim(Municipality))) > 0 and Municipality  <> ''0'') THEN 1 ELSE 0 END) AS Municipality
		,sum(CASE WHEN (len(ltrim(rtrim(LegalSection))) > 0 and LegalSection  <> ''0'') THEN 1 ELSE 0 END) AS LegalSection
		,sum(CASE WHEN (len(ltrim(rtrim(LegalTownship))) > 0 and LegalTownship  <> ''0'') THEN 1 ELSE 0 END) AS LegalTownship
		,sum(CASE WHEN (len(ltrim(rtrim(LegalRange))) > 0 and LegalRange  <> ''0'') THEN 1 ELSE 0 END) AS LegalRange
		,sum(CASE WHEN (len(ltrim(rtrim(Meridian))) > 0 and Meridian  <> ''0'') THEN 1 ELSE 0 END) AS Meridian
		,sum(CASE WHEN (len(ltrim(rtrim(LegalQuarter))) > 0 and LegalQuarter  <> ''0'') THEN 1 ELSE 0 END) AS LegalQuarter
		,sum(CASE WHEN (len(ltrim(rtrim(LegalQuarterQuarter))) > 0 and LegalQuarterQuarter  <> ''0'') THEN 1 ELSE 0 END) AS LegalQuarterQuarter
		,sum(CASE WHEN (len(ltrim(rtrim(LegalDescription))) > 0 and LegalDescription  <> ''0'') THEN 1 ELSE 0 END) AS LegalDescription
		,sum(CASE WHEN (len(ltrim(rtrim(AssessorsMapRef1))) > 0 and AssessorsMapRef1  <> ''0'') THEN 1 ELSE 0 END) AS AssessorsMapRef1
		,sum(CASE WHEN (len(ltrim(rtrim(AssessorsMapRef2))) > 0 and AssessorsMapRef2  <> ''0'') THEN 1 ELSE 0 END) AS AssessorsMapRef2
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionName))) > 0 and SubdivisionName  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionName
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPhaseNbr))) > 0 and SubdivisionPhaseNbr  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPhaseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionTractNbr))) > 0 and SubdivisionTractNbr  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionTractNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPlatBook))) > 0 and SubdivisionPlatBook  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPlatBook
		,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionPlatPage))) > 0 and SubdivisionPlatPage  <> ''0'') THEN 1 ELSE 0 END) AS SubdivisionPlatPage
		,sum(CASE WHEN (len(ltrim(rtrim(NewRecordType))) > 0 and NewRecordType  <> ''0'') THEN 1 ELSE 0 END) AS NewRecordType
		,sum(CASE WHEN (len(ltrim(rtrim(SwiSCodeNY))) > 0 and SwiSCodeNY  <> ''0'') THEN 1 ELSE 0 END) AS SwiSCodeNY
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCareOfName))) > 0 and MailingCareOfName  <> ''0'') THEN 1 ELSE 0 END) AS MailingCareOfName
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdFullStreetAddress))) > 0 and MailingStdFullStreetAddress  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdFullStreetAddress
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbr))) > 0 and MailingStdHouseNbr  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbr
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbr2))) > 0 and MailingStdHouseNbr2  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbr2
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdHouseNbrSuffix))) > 0 and MailingStdHouseNbrSuffix  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdHouseNbrSuffix
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdDirectionLeft))) > 0 and MailingStdDirectionLeft  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdDirectionLeft
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdStreet))) > 0 and MailingStdStreet  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdStreet
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdMode))) > 0 and MailingStdMode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdMode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdDirectionRight))) > 0 and MailingStdDirectionRight  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdDirectionRight
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdUnitNbr))) > 0 and MailingStdUnitNbr  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdUnitNbr
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdCity))) > 0 and MailingStdCity  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdCity
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdState))) > 0 and MailingStdState  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdState
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdZIP5))) > 0 and MailingStdZIP5  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdZIP5
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdZIP4))) > 0 and MailingStdZIP4  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdZIP4
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdCarrierCode))) > 0 and MailingStdCarrierCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdCarrierCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdUnitType))) > 0 and MailingStdUnitType  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdUnitType
		,sum(CASE WHEN (len(ltrim(rtrim(MailingStdMatchCode))) > 0 and MailingStdMatchCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingStdMatchCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingOptOut))) > 0 and MailingOptOut  <> ''0'') THEN 1 ELSE 0 END) AS MailingOptOut
		,sum(CASE WHEN (len(ltrim(rtrim(MailingOptOutDate))) > 0 and MailingOptOutDate  <> ''0'') THEN 1 ELSE 0 END) AS MailingOptOutDate
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerOccupied))) > 0 and OwnerOccupied  <> ''0'') THEN 1 ELSE 0 END) AS OwnerOccupied
		,sum(CASE WHEN (len(ltrim(rtrim(AbsenteeOwner))) > 0 and AbsenteeOwner  <> ''0'') THEN 1 ELSE 0 END) AS AbsenteeOwner
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME1FULL))) > 0 and OwnerStdNAME1FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME1FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME2FULL))) > 0 and OwnerStdNAME2FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME2FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME3FULL))) > 0 and OwnerStdNAME3FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME3FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStdNAME4FULL))) > 0 and OwnerStdNAME4FULL  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStdNAME4FULL
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerEtALIndicator))) > 0 and OwnerEtALIndicator  <> ''0'') THEN 1 ELSE 0 END) AS OwnerEtALIndicator
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1CorpInd))) > 0 and OwnerStd1CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1LastName))) > 0 and OwnerStd1LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1FirstName))) > 0 and OwnerStd1FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1MiddleName))) > 0 and OwnerStd1MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1Suffix))) > 0 and OwnerStd1Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1CorpName))) > 0 and OwnerStd1CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1OwnershipRights))) > 0 and OwnerStd1OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd1RelationshipType))) > 0 and OwnerStd1RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd1RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner1DoNotParse))) > 0 and Owner1DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner1DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2CorpInd))) > 0 and OwnerStd2CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2LastName))) > 0 and OwnerStd2LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2FirstName))) > 0 and OwnerStd2FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2MiddleName))) > 0 and OwnerStd2MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2Suffix))) > 0 and OwnerStd2Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2CorpName))) > 0 and OwnerStd2CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2OwnershipRights))) > 0 and OwnerStd2OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd2RelationshipType))) > 0 and OwnerStd2RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd2RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner2DoNotParse))) > 0 and Owner2DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner2DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3CorpInd))) > 0 and OwnerStd3CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3LastName))) > 0 and OwnerStd3LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3FirstName))) > 0 and OwnerStd3FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3MiddleName))) > 0 and OwnerStd3MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3Suffix))) > 0 and OwnerStd3Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3CorpName))) > 0 and OwnerStd3CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3OwnershipRights))) > 0 and OwnerStd3OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd3RelationshipType))) > 0 and OwnerStd3RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd3RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner3DoNotParse))) > 0 and Owner3DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner3DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4CorpInd))) > 0 and OwnerStd4CorpInd  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4CorpInd
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4LastName))) > 0 and OwnerStd4LastName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4LastName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4FirstName))) > 0 and OwnerStd4FirstName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4FirstName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4MiddleName))) > 0 and OwnerStd4MiddleName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4MiddleName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4Suffix))) > 0 and OwnerStd4Suffix  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4Suffix
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4CorpName))) > 0 and OwnerStd4CorpName  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4CorpName
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4OwnershipRights))) > 0 and OwnerStd4OwnershipRights  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4OwnershipRights
		,sum(CASE WHEN (len(ltrim(rtrim(OwnerStd4RelationshipType))) > 0 and OwnerStd4RelationshipType  <> ''0'') THEN 1 ELSE 0 END) AS OwnerStd4RelationshipType
		,sum(CASE WHEN (len(ltrim(rtrim(Owner4DoNotParse))) > 0 and Owner4DoNotParse  <> ''0'') THEN 1 ELSE 0 END) AS Owner4DoNotParse
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeStd1Name))) > 0 and AssesseeStd1Name  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeStd1Name
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeStd2Name))) > 0 and AssesseeStd2Name  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeStd2Name
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeNameIndicator))) > 0 and AssesseeNameIndicator  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeNameIndicator
		,sum(CASE WHEN (len(ltrim(rtrim(AssesseeNameIndicator2))) > 0 and AssesseeNameIndicator2  <> ''0'') THEN 1 ELSE 0 END) AS AssesseeNameIndicator2
		,sum(CASE WHEN (len(ltrim(rtrim(Amenities))) > 0 and Amenities  <> ''0'') THEN 1 ELSE 0 END) AS Amenities
		,sum(CASE WHEN (len(ltrim(rtrim(DrivewayCode))) > 0 and DrivewayCode  <> ''0'') THEN 1 ELSE 0 END) AS DrivewayCode
		,sum(CASE WHEN (len(ltrim(rtrim(EasementInd))) > 0 and EasementInd  <> ''0'') THEN 1 ELSE 0 END) AS EasementInd
		,sum(CASE WHEN (len(ltrim(rtrim(QualityCode))) > 0 and QualityCode  <> ''0'') THEN 1 ELSE 0 END) AS QualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ViewInd))) > 0 and ViewInd  <> ''0'') THEN 1 ELSE 0 END) AS ViewInd
		,sum(CASE WHEN (len(ltrim(rtrim(ViewCode))) > 0 and ViewCode  <> ''0'') THEN 1 ELSE 0 END) AS ViewCode
		,sum(CASE WHEN (len(ltrim(rtrim(ViewQualityCode))) > 0 and ViewQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS ViewQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterAccessableInd))) > 0 and WaterAccessableInd  <> ''0'') THEN 1 ELSE 0 END) AS WaterAccessableInd
		,sum(CASE WHEN (len(ltrim(rtrim(WaterFeatureInd))) > 0 and WaterFeatureInd  <> ''0'') THEN 1 ELSE 0 END) AS WaterFeatureInd
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontCode))) > 0 and WaterfrontCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontFeet))) > 0 and WaterfrontFeet  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontFeet
		,sum(CASE WHEN (len(ltrim(rtrim(WaterfrontQualityCode))) > 0 and WaterfrontQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterfrontQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingArea))) > 0 and BuildingArea  <> ''0'') THEN 1 ELSE 0 END) AS BuildingArea
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingAreaInd))) > 0 and BuildingAreaInd  <> ''0'') THEN 1 ELSE 0 END) AS BuildingAreaInd
		,sum(CASE WHEN (len(ltrim(rtrim(TotalRooms))) > 0 and TotalRooms  <> ''0'') THEN 1 ELSE 0 END) AS TotalRooms
		,sum(CASE WHEN (len(ltrim(rtrim(Bedrooms))) > 0 and Bedrooms  <> ''0'') THEN 1 ELSE 0 END) AS Bedrooms
		,sum(CASE WHEN (len(ltrim(rtrim(BathTotalCalc))) > 0 and BathTotalCalc  <> ''0'') THEN 1 ELSE 0 END) AS BathTotalCalc
		,sum(CASE WHEN (len(ltrim(rtrim(BathFull))) > 0 and BathFull  <> ''0'') THEN 1 ELSE 0 END) AS BathFull
		,sum(CASE WHEN (len(ltrim(rtrim(BathsParcialNbr))) > 0 and BathsParcialNbr  <> ''0'') THEN 1 ELSE 0 END) AS BathsParcialNbr
		,sum(CASE WHEN (len(ltrim(rtrim(BathHalf))) > 0 and BathHalf  <> ''0'') THEN 1 ELSE 0 END) AS BathHalf
		,sum(CASE WHEN (len(ltrim(rtrim(Bath1QTR))) > 0 and Bath1QTR  <> ''0'') THEN 1 ELSE 0 END) AS Bath1QTR
		,sum(CASE WHEN (len(ltrim(rtrim(Bath3QTR))) > 0 and Bath3QTR  <> ''0'') THEN 1 ELSE 0 END) AS Bath3QTR
		,sum(CASE WHEN (len(ltrim(rtrim(BathFixturesNbr))) > 0 and BathFixturesNbr  <> ''0'') THEN 1 ELSE 0 END) AS BathFixturesNbr
		,sum(CASE WHEN (len(ltrim(rtrim(OtherRooms))) > 0 and OtherRooms  <> ''0'') THEN 1 ELSE 0 END) AS OtherRooms
		,sum(CASE WHEN (len(ltrim(rtrim(AirConditioningCode))) > 0 and AirConditioningCode  <> ''0'') THEN 1 ELSE 0 END) AS AirConditioningCode
		,sum(CASE WHEN (len(ltrim(rtrim(AirConditioningTypeCode))) > 0 and AirConditioningTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS AirConditioningTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(BasementCode))) > 0 and BasementCode  <> ''0'') THEN 1 ELSE 0 END) AS BasementCode
		,sum(CASE WHEN (len(ltrim(rtrim(BasementFinishedCode))) > 0 and BasementFinishedCode  <> ''0'') THEN 1 ELSE 0 END) AS BasementFinishedCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingClassCode))) > 0 and BuildingClassCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingClassCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingConditionCode))) > 0 and BuildingConditionCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingConditionCode
		,sum(CASE WHEN (len(ltrim(rtrim(BuildingQualityCode))) > 0 and BuildingQualityCode  <> ''0'') THEN 1 ELSE 0 END) AS BuildingQualityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConstructionTypeCode))) > 0 and ConstructionTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS ConstructionTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(DeckCode))) > 0 and DeckCode  <> ''0'') THEN 1 ELSE 0 END) AS DeckCode
		,sum(CASE WHEN (len(ltrim(rtrim(ElectricityCode))) > 0 and ElectricityCode  <> ''0'') THEN 1 ELSE 0 END) AS ElectricityCode
		,sum(CASE WHEN (len(ltrim(rtrim(ExteriorWallsCode))) > 0 and ExteriorWallsCode  <> ''0'') THEN 1 ELSE 0 END) AS ExteriorWallsCode
		,sum(CASE WHEN (len(ltrim(rtrim(FireplaceCode))) > 0 and FireplaceCode  <> ''0'') THEN 1 ELSE 0 END) AS FireplaceCode
		,sum(CASE WHEN (len(ltrim(rtrim(FloorCoverCode))) > 0 and FloorCoverCode  <> ''0'') THEN 1 ELSE 0 END) AS FloorCoverCode
		,sum(CASE WHEN (len(ltrim(rtrim(FloorTypeCode))) > 0 and FloorTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS FloorTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(FoundationInd))) > 0 and FoundationInd  <> ''0'') THEN 1 ELSE 0 END) AS FoundationInd
		,sum(CASE WHEN (len(ltrim(rtrim(FrameCode))) > 0 and FrameCode  <> ''0'') THEN 1 ELSE 0 END) AS FrameCode
		,sum(CASE WHEN (len(ltrim(rtrim(Garage))) > 0 and Garage  <> ''0'') THEN 1 ELSE 0 END) AS Garage
		,sum(CASE WHEN (len(ltrim(rtrim(GarageParkingNbr))) > 0 and GarageParkingNbr  <> ''0'') THEN 1 ELSE 0 END) AS GarageParkingNbr
		,sum(CASE WHEN (len(ltrim(rtrim(HeatCode))) > 0 and HeatCode  <> ''0'') THEN 1 ELSE 0 END) AS HeatCode
		,sum(CASE WHEN (len(ltrim(rtrim(HeatingFuelTypeCode))) > 0 and HeatingFuelTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS HeatingFuelTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(InteriorWallsCode))) > 0 and InteriorWallsCode  <> ''0'') THEN 1 ELSE 0 END) AS InteriorWallsCode
		,sum(CASE WHEN (len(ltrim(rtrim(PavingCode))) > 0 and PavingCode  <> ''0'') THEN 1 ELSE 0 END) AS PavingCode
		,sum(CASE WHEN (len(ltrim(rtrim(PatioCode))) > 0 and PatioCode  <> ''0'') THEN 1 ELSE 0 END) AS PatioCode
		,sum(CASE WHEN (len(ltrim(rtrim(PoolCode))) > 0 and PoolCode  <> ''0'') THEN 1 ELSE 0 END) AS PoolCode
		,sum(CASE WHEN (len(ltrim(rtrim(PorchCode))) > 0 and PorchCode  <> ''0'') THEN 1 ELSE 0 END) AS PorchCode
		,sum(CASE WHEN (len(ltrim(rtrim(RoofCoverCode))) > 0 and RoofCoverCode  <> ''0'') THEN 1 ELSE 0 END) AS RoofCoverCode
		,sum(CASE WHEN (len(ltrim(rtrim(RoofTypeCode))) > 0 and RoofTypeCode  <> ''0'') THEN 1 ELSE 0 END) AS RoofTypeCode
		,sum(CASE WHEN (len(ltrim(rtrim(SewerCode))) > 0 and SewerCode  <> ''0'') THEN 1 ELSE 0 END) AS SewerCode
		,sum(CASE WHEN (len(ltrim(rtrim(ShapeCode))) > 0 and ShapeCode  <> ''0'') THEN 1 ELSE 0 END) AS ShapeCode
		,sum(CASE WHEN (len(ltrim(rtrim(StoriesCode))) > 0 and StoriesCode  <> ''0'') THEN 1 ELSE 0 END) AS StoriesCode
		,sum(CASE WHEN (len(ltrim(rtrim(StoriesNbrCode))) > 0 and StoriesNbrCode  <> ''0'') THEN 1 ELSE 0 END) AS StoriesNbrCode
		,sum(CASE WHEN (len(ltrim(rtrim(StyleCode))) > 0 and StyleCode  <> ''0'') THEN 1 ELSE 0 END) AS StyleCode
		,sum(CASE WHEN (len(ltrim(rtrim(WallExteriorCode))) > 0 and WallExteriorCode  <> ''0'') THEN 1 ELSE 0 END) AS WallExteriorCode
		,sum(CASE WHEN (len(ltrim(rtrim(WallheightCode))) > 0 and WallheightCode  <> ''0'') THEN 1 ELSE 0 END) AS WallheightCode
		,sum(CASE WHEN (len(ltrim(rtrim(WaterCode))) > 0 and WaterCode  <> ''0'') THEN 1 ELSE 0 END) AS WaterCode
		,sum(CASE WHEN (len(ltrim(rtrim(YearBuilt))) > 0 and YearBuilt  <> ''0'') THEN 1 ELSE 0 END) AS YearBuilt
		,sum(CASE WHEN (len(ltrim(rtrim(EffectiveYearBuilt))) > 0 and EffectiveYearBuilt  <> ''0'') THEN 1 ELSE 0 END) AS EffectiveYearBuilt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBuildingsNbr))) > 0 and SumBuildingsNbr  <> ''0'') THEN 1 ELSE 0 END) AS SumBuildingsNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SumAboveGradeLivingSqFt))) > 0 and SumAboveGradeLivingSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumAboveGradeLivingSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumAdjAreaSqFt))) > 0 and SumAdjAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumAdjAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBasementSqFt))) > 0 and SumBasementSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumBasementSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumBuildingSqFt))) > 0 and SumBuildingSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumBuildingSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGarageSqFt))) > 0 and SumGarageSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGarageSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGrossAreaSqFt))) > 0 and SumGrossAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGrossAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumGroundFloorSqFt))) > 0 and SumGroundFloorSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumGroundFloorSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumLivingAreaSqFt))) > 0 and SumLivingAreaSqFt  <> ''0'') THEN 1 ELSE 0 END) AS SumLivingAreaSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(SumResidentialUnits))) > 0 and SumResidentialUnits  <> ''0'') THEN 1 ELSE 0 END) AS SumResidentialUnits
		,sum(CASE WHEN (len(ltrim(rtrim(SumCommercialUnits))) > 0 and SumCommercialUnits  <> ''0'') THEN 1 ELSE 0 END) AS SumCommercialUnits
		,sum(CASE WHEN (len(ltrim(rtrim(AssdLandValue))) > 0 and AssdLandValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdImprovementValue))) > 0 and AssdImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdTotalValue))) > 0 and AssdTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS AssdTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(AssdYear))) > 0 and AssdYear  <> ''0'') THEN 1 ELSE 0 END) AS AssdYear
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueLand))) > 0 and MarketValueLand  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueLand
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueImprovement))) > 0 and MarketValueImprovement  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueImprovement
		,sum(CASE WHEN (len(ltrim(rtrim(MarketTotalValue))) > 0 and MarketTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS MarketTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(MarketValueYear))) > 0 and MarketValueYear  <> ''0'') THEN 1 ELSE 0 END) AS MarketValueYear
		,sum(CASE WHEN (len(ltrim(rtrim(ApprLandValue))) > 0 and ApprLandValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprImprovementValue))) > 0 and ApprImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprTotalValue))) > 0 and ApprTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS ApprTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(ApprYear))) > 0 and ApprYear  <> ''0'') THEN 1 ELSE 0 END) AS ApprYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxValueLand))) > 0 and TaxValueLand  <> ''0'') THEN 1 ELSE 0 END) AS TaxValueLand
		,sum(CASE WHEN (len(ltrim(rtrim(TaxValueImprovement))) > 0 and TaxValueImprovement  <> ''0'') THEN 1 ELSE 0 END) AS TaxValueImprovement
		,sum(CASE WHEN (len(ltrim(rtrim(TaxTotalValue))) > 0 and TaxTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS TaxTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(TaxableYear))) > 0 and TaxableYear  <> ''0'') THEN 1 ELSE 0 END) AS TaxableYear
		,sum(CASE WHEN (len(ltrim(rtrim(UNVLandValue))) > 0 and UNVLandValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVLandValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVImprovementValue))) > 0 and UNVImprovementValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVImprovementValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVTotalValue))) > 0 and UNVTotalValue  <> ''0'') THEN 1 ELSE 0 END) AS UNVTotalValue
		,sum(CASE WHEN (len(ltrim(rtrim(UNVValueYear))) > 0 and UNVValueYear  <> ''0'') THEN 1 ELSE 0 END) AS UNVValueYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxRateCodeArea))) > 0 and TaxRateCodeArea  <> ''0'') THEN 1 ELSE 0 END) AS TaxRateCodeArea
		,sum(CASE WHEN (len(ltrim(rtrim(p.TaxYear))) > 0 and p.TaxYear  <> ''0'') THEN 1 ELSE 0 END) AS TaxYear
		,sum(CASE WHEN (len(ltrim(rtrim(TaxAmount))) > 0 and TaxAmount  <> ''0'') THEN 1 ELSE 0 END) AS TaxAmount
		,sum(CASE WHEN (len(ltrim(rtrim(TaxDeliquentYear1))) > 0 and TaxDeliquentYear1  <> ''0'') THEN 1 ELSE 0 END) AS TaxDeliquentYear1
		,sum(CASE WHEN (len(ltrim(rtrim(TaxDeliquentValue1))) > 0 and TaxDeliquentValue1  <> ''0'') THEN 1 ELSE 0 END) AS TaxDeliquentValue1
		,sum(CASE WHEN (len(ltrim(rtrim(TaxExemptionCode))) > 0 and TaxExemptionCode  <> ''0'') THEN 1 ELSE 0 END) AS TaxExemptionCode
		,sum(CASE WHEN (len(ltrim(rtrim(TaxexemptInd))) > 0 and TaxexemptInd  <> ''0'') THEN 1 ELSE 0 END) AS TaxexemptInd
		,sum(CASE WHEN (len(ltrim(rtrim(CalifHomeownerInd))) > 0 and CalifHomeownerInd  <> ''0'') THEN 1 ELSE 0 END) AS CalifHomeownerInd
		,sum(CASE WHEN (len(ltrim(rtrim(CemeteryInd))) > 0 and CemeteryInd  <> ''0'') THEN 1 ELSE 0 END) AS CemeteryInd
		,sum(CASE WHEN (len(ltrim(rtrim(DisabledInd))) > 0 and DisabledInd  <> ''0'') THEN 1 ELSE 0 END) AS DisabledInd
		,sum(CASE WHEN (len(ltrim(rtrim(HomesteadInd))) > 0 and HomesteadInd  <> ''0'') THEN 1 ELSE 0 END) AS HomesteadInd
		,sum(CASE WHEN (len(ltrim(rtrim(HospitalInd))) > 0 and HospitalInd  <> ''0'') THEN 1 ELSE 0 END) AS HospitalInd
		,sum(CASE WHEN (len(ltrim(rtrim(LibraryInd))) > 0 and LibraryInd  <> ''0'') THEN 1 ELSE 0 END) AS LibraryInd
		,sum(CASE WHEN (len(ltrim(rtrim(PublicUtilityInd))) > 0 and PublicUtilityInd  <> ''0'') THEN 1 ELSE 0 END) AS PublicUtilityInd
		,sum(CASE WHEN (len(ltrim(rtrim(ReligiousInd))) > 0 and ReligiousInd  <> ''0'') THEN 1 ELSE 0 END) AS ReligiousInd
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolCollegeInd))) > 0 and SchoolCollegeInd  <> ''0'') THEN 1 ELSE 0 END) AS SchoolCollegeInd
		,sum(CASE WHEN (len(ltrim(rtrim(SeniorInd))) > 0 and SeniorInd  <> ''0'') THEN 1 ELSE 0 END) AS SeniorInd
		,sum(CASE WHEN (len(ltrim(rtrim(VeteranInd))) > 0 and VeteranInd  <> ''0'') THEN 1 ELSE 0 END) AS VeteranInd
		,sum(CASE WHEN (len(ltrim(rtrim(WelfareInd))) > 0 and WelfareInd  <> ''0'') THEN 1 ELSE 0 END) AS WelfareInd
		,sum(CASE WHEN (len(ltrim(rtrim(WidowInd))) > 0 and WidowInd  <> ''0'') THEN 1 ELSE 0 END) AS WidowInd
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict1Code))) > 0 and SchoolTaxDistrict1Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict1Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict1Ind))) > 0 and SchoolTaxDistrict1Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict1Ind
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict2Code))) > 0 and SchoolTaxDistrict2Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict2Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict2Ind))) > 0 and SchoolTaxDistrict2Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict2Ind
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict3Code))) > 0 and SchoolTaxDistrict3Code  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict3Code
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolTaxDistrict3Ind))) > 0 and SchoolTaxDistrict3Ind  <> ''0'') THEN 1 ELSE 0 END) AS SchoolTaxDistrict3Ind
		,sum(CASE WHEN (len(ltrim(rtrim(FADeleteFlag))) > 0 and FADeleteFlag  <> ''0'') THEN 1 ELSE 0 END) AS FADeleteFlag
		,sum(CASE WHEN (len(ltrim(rtrim(CurrentSaleTransactionId))) > 0 and CurrentSaleTransactionId  <> ''0'') THEN 1 ELSE 0 END) AS CurrentSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(CurrentSaleChronoKey))) > 0 and CurrentSaleChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS CurrentSaleChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputDocNbr))) > 0 and CurrSaleInputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputBook))) > 0 and CurrSaleInputBook  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputBook
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleInputPage))) > 0 and CurrSaleInputPage  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleInputPage
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatDocNbr))) > 0 and CurrSaleFormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatBook))) > 0 and CurrSaleFormatBook  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleFormatPage))) > 0 and CurrSaleFormatPage  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleFormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleRecordingDate))) > 0 and CurrSaleRecordingDate  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleDocumentType))) > 0 and CurrSaleDocumentType  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleDocumentType
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSalesPrice))) > 0 and CurrSalesPrice  <> ''0'') THEN 1 ELSE 0 END) AS CurrSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSalesPriceCode))) > 0 and CurrSalesPriceCode  <> ''0'') THEN 1 ELSE 0 END) AS CurrSalesPriceCode
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleContractDate))) > 0 and CurrSaleContractDate  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleContractDate
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer1FullName))) > 0 and CurrSaleBuyer1FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer2FullName))) > 0 and CurrSaleBuyer2FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer3FullName))) > 0 and CurrSaleBuyer3FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer3FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleBuyer4FullName))) > 0 and CurrSaleBuyer4FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleBuyer4FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleSeller1FullName))) > 0 and CurrSaleSeller1FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleSeller1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(CurrSaleSeller2FullName))) > 0 and CurrSaleSeller2FullName  <> ''0'') THEN 1 ELSE 0 END) AS CurrSaleSeller2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputDocNbr))) > 0 and ConCurrMtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputBook))) > 0 and ConCurrMtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1InputPage))) > 0 and ConCurrMtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatDocNbr))) > 0 and ConCurrMtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatBook))) > 0 and ConCurrMtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1FormatPage))) > 0 and ConCurrMtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1RecordingDt))) > 0 and ConCurrMtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanAmt))) > 0 and ConCurrMtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Lender))) > 0 and ConCurrMtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LenderCode))) > 0 and ConCurrMtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LenderType))) > 0 and ConCurrMtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1PrivateLender))) > 0 and ConCurrMtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Term))) > 0 and ConCurrMtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanDueDt))) > 0 and ConCurrMtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1AdjOrFix))) > 0 and ConCurrMtg1AdjOrFix  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1AdjOrFix
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LoanType))) > 0 and ConCurrMtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1Typefinancing))) > 0 and ConCurrMtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg1LienPosition))) > 0 and ConCurrMtg1LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg1LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputDocNbr))) > 0 and ConCurrMtg2InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputBook))) > 0 and ConCurrMtg2InputBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2InputPage))) > 0 and ConCurrMtg2InputPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatDocNbr))) > 0 and ConCurrMtg2FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatBook))) > 0 and ConCurrMtg2FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2FormatPage))) > 0 and ConCurrMtg2FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2RecordingDt))) > 0 and ConCurrMtg2RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanAmt))) > 0 and ConCurrMtg2LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Lender))) > 0 and ConCurrMtg2Lender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Lender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LenderCode))) > 0 and ConCurrMtg2LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LenderType))) > 0 and ConCurrMtg2LenderType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2PrivateLender))) > 0 and ConCurrMtg2PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Term))) > 0 and ConCurrMtg2Term  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Term
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanDueDt))) > 0 and ConCurrMtg2LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2AdjOrFix))) > 0 and ConCurrMtg2AdjOrFix  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2AdjOrFix
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LoanType))) > 0 and ConCurrMtg2LoanType  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2Typefinancing))) > 0 and ConCurrMtg2Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(ConCurrMtg2LienPosition))) > 0 and ConCurrMtg2LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS ConCurrMtg2LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1TransactionId))) > 0 and Mtg1TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1ChronoKey))) > 0 and Mtg1ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanAmt))) > 0 and Mtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Lender))) > 0 and Mtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LenderCode))) > 0 and Mtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LenderType))) > 0 and Mtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1PrivateLender))) > 0 and Mtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Term))) > 0 and Mtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanDueDt))) > 0 and Mtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1AdjRider))) > 0 and Mtg1AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LoanType))) > 0 and Mtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1Typefinancing))) > 0 and Mtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1LienPosition))) > 0 and Mtg1LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2TransactionId))) > 0 and Mtg2TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2ChronoKey))) > 0 and Mtg2ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputDocNbr))) > 0 and Mtg2InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputBook))) > 0 and Mtg2InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2InputPage))) > 0 and Mtg2InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatDocNbr))) > 0 and Mtg2FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatBook))) > 0 and Mtg2FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2FormatPage))) > 0 and Mtg2FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2RecordingDt))) > 0 and Mtg2RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanAmt))) > 0 and Mtg2LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Lender))) > 0 and Mtg2Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LenderCode))) > 0 and Mtg2LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LenderType))) > 0 and Mtg2LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2PrivateLender))) > 0 and Mtg2PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Term))) > 0 and Mtg2Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanDueDt))) > 0 and Mtg2LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2AdjRider))) > 0 and Mtg2AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LoanType))) > 0 and Mtg2LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2Typefinancing))) > 0 and Mtg2Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg2LienPosition))) > 0 and Mtg2LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg2LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3TransactionId))) > 0 and Mtg3TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3ChronoKey))) > 0 and Mtg3ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputDocNbr))) > 0 and Mtg3InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputBook))) > 0 and Mtg3InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputPage))) > 0 and Mtg3InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatDocNbr))) > 0 and Mtg3FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatBook))) > 0 and Mtg3FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3FormatPage))) > 0 and Mtg3FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3RecordingDt))) > 0 and Mtg3RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanAmt))) > 0 and Mtg3LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Lender))) > 0 and Mtg3Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LenderCode))) > 0 and Mtg3LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LenderType))) > 0 and Mtg3LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3PrivateLender))) > 0 and Mtg3PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Term))) > 0 and Mtg3Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanDueDt))) > 0 and Mtg3LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3AdjRider))) > 0 and Mtg3AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LoanType))) > 0 and Mtg3LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3Typefinancing))) > 0 and Mtg3Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3LienPosition))) > 0 and Mtg3LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4TransactionId))) > 0 and Mtg4TransactionId  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4TransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4ChronoKey))) > 0 and Mtg4ChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4ChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputDocNbr))) > 0 and Mtg4InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputBook))) > 0 and Mtg4InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputPage))) > 0 and Mtg4InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatDocNbr))) > 0 and Mtg4FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatBook))) > 0 and Mtg4FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatPage))) > 0 and Mtg4FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4RecordingDt))) > 0 and Mtg4RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanAmt))) > 0 and Mtg4LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Lender))) > 0 and Mtg4Lender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Lender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LenderCode))) > 0 and Mtg4LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LenderType))) > 0 and Mtg4LenderType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4PrivateLender))) > 0 and Mtg4PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Term))) > 0 and Mtg4Term  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Term
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanDueDt))) > 0 and Mtg4LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4AdjRider))) > 0 and Mtg4AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LoanType))) > 0 and Mtg4LoanType  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4Typefinancing))) > 0 and Mtg4Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4LienPosition))) > 0 and Mtg4LienPosition  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4LienPosition
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleTransactionId))) > 0 and PrevSaleTransactionId  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleChronoKey))) > 0 and PrevSaleChronoKey  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleChronoKey
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputDocNbr))) > 0 and PrevSaleInputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputBook))) > 0 and PrevSaleInputBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleInputPage))) > 0 and PrevSaleInputPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleInputPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatDocNbr))) > 0 and PrevSaleFormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatBook))) > 0 and PrevSaleFormatBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleFormatPage))) > 0 and PrevSaleFormatPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleFormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleRecordingDate))) > 0 and PrevSaleRecordingDate  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSalesPrice))) > 0 and PrevSalesPrice  <> ''0'') THEN 1 ELSE 0 END) AS PrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSalesPriceCode))) > 0 and PrevSalesPriceCode  <> ''0'') THEN 1 ELSE 0 END) AS PrevSalesPriceCode
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleContractDate))) > 0 and PrevSaleContractDate  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleContractDate
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleDocumentType))) > 0 and PrevSaleDocumentType  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleDocumentType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer1FullName))) > 0 and PrevSaleBuyer1FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer2FullName))) > 0 and PrevSaleBuyer2FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer3FullName))) > 0 and PrevSaleBuyer3FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer3FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleBuyer4FullName))) > 0 and PrevSaleBuyer4FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleBuyer4FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleSeller1FullName))) > 0 and PrevSaleSeller1FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleSeller1FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevSaleSeller2FullName))) > 0 and PrevSaleSeller2FullName  <> ''0'') THEN 1 ELSE 0 END) AS PrevSaleSeller2FullName
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputDocNbr))) > 0 and PrevMtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputBook))) > 0 and PrevMtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1InputPage))) > 0 and PrevMtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatDocNbr))) > 0 and PrevMtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatBook))) > 0 and PrevMtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1FormatPage))) > 0 and PrevMtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1RecordingDt))) > 0 and PrevMtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanAmt))) > 0 and PrevMtg1LoanAmt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanAmt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Lender))) > 0 and PrevMtg1Lender  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Lender
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LenderCode))) > 0 and PrevMtg1LenderCode  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LenderCode
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LenderType))) > 0 and PrevMtg1LenderType  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LenderType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1PrivateLender))) > 0 and PrevMtg1PrivateLender  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1PrivateLender
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Term))) > 0 and PrevMtg1Term  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Term
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanDueDt))) > 0 and PrevMtg1LoanDueDt  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanDueDt
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1AdjRider))) > 0 and PrevMtg1AdjRider  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1AdjRider
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1LoanType))) > 0 and PrevMtg1LoanType  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1LoanType
		,sum(CASE WHEN (len(ltrim(rtrim(PrevMtg1Typefinancing))) > 0 and PrevMtg1Typefinancing  <> ''0'') THEN 1 ELSE 0 END) AS PrevMtg1Typefinancing
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPVCount))) > 0 and SitusDPVCount  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPVCount
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPVFootnote))) > 0 and SitusDPVFootnote  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPVFootnote
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLACS))) > 0 and SitusLACS  <> ''0'') THEN 1 ELSE 0 END) AS SitusLACS
		,sum(CASE WHEN (len(ltrim(rtrim(SitusLACSLinkInd))) > 0 and SitusLACSLinkInd  <> ''0'') THEN 1 ELSE 0 END) AS SitusLACSLinkInd
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPCheckDigit))) > 0 and SitusDPCheckDigit  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPCheckDigit
		,sum(CASE WHEN (len(ltrim(rtrim(SitusDPCheckCode))) > 0 and SitusDPCheckCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusDPCheckCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusCensusBlock))) > 0 and SitusCensusBlock  <> ''0'') THEN 1 ELSE 0 END) AS SitusCensusBlock
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoErrorCode))) > 0 and SitusGeoErrorCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoErrorCode
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoStatusCode))) > 0 and SitusGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPVCount))) > 0 and MailingDPVCount  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPVCount
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPVFootnote))) > 0 and MailingDPVFootnote  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPVFootnote
		,sum(CASE WHEN (len(ltrim(rtrim(MailingLACS))) > 0 and MailingLACS  <> ''0'') THEN 1 ELSE 0 END) AS MailingLACS
		,sum(CASE WHEN (len(ltrim(rtrim(MailingLACSLinkInd))) > 0 and MailingLACSLinkInd  <> ''0'') THEN 1 ELSE 0 END) AS MailingLACSLinkInd
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPCheckDigit))) > 0 and MailingDPCheckDigit  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPCheckDigit
		,sum(CASE WHEN (len(ltrim(rtrim(MailingDPCheckCode))) > 0 and MailingDPCheckCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingDPCheckCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCensusBlock))) > 0 and MailingCensusBlock  <> ''0'') THEN 1 ELSE 0 END) AS MailingCensusBlock
		,sum(CASE WHEN (len(ltrim(rtrim(MailingCensusTract))) > 0 and MailingCensusTract  <> ''0'') THEN 1 ELSE 0 END) AS MailingCensusTract
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoErrorCode))) > 0 and MailingGeoErrorCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoErrorCode
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoStatusCode))) > 0 and MailingGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(CheckOwnership))) > 0 and CheckOwnership  <> ''0'') THEN 1 ELSE 0 END) AS CheckOwnership
		,sum(CASE WHEN (len(ltrim(rtrim(FAUCIDFlag))) > 0 and FAUCIDFlag  <> ''0'') THEN 1 ELSE 0 END) AS FAUCIDFlag
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatBook))) > 0 and Mtg1FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatDocNbr))) > 0 and Mtg1FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1FormatPage))) > 0 and Mtg1FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputBook))) > 0 and Mtg1InputBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputDocNbr))) > 0 and Mtg1InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1InputPage))) > 0 and Mtg1InputPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1InputPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg1RecordingDt))) > 0 and Mtg1RecordingDt  <> ''0'') THEN 1 ELSE 0 END) AS Mtg1RecordingDt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticFinishSqFt))) > 0 and AtticFinishSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticSqFt))) > 0 and AtticSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(AtticUnfinSqFt))) > 0 and AtticUnfinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS AtticUnfinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(BankOwned))) > 0 and BankOwned  <> ''0'') THEN 1 ELSE 0 END) AS BankOwned
		,sum(CASE WHEN (len(ltrim(rtrim(BasementFinishSqFt))) > 0 and BasementFinishSqFt   <> ''0'') THEN 1 ELSE 0 END) AS BasementFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(BasementUnfinSqFt))) > 0 and BasementUnfinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS BasementUnfinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(p.EditionNumber))) > 0 and p.EditionNumber  <> ''0'') THEN 1 ELSE 0 END) AS EditionNumber
		,sum(CASE WHEN (len(ltrim(rtrim(FAEstLotSqFt))) > 0 and FAEstLotSqFt  <> ''0'') THEN 1 ELSE 0 END) AS FAEstLotSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(FAGeoStatusCode))) > 0 and FAGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS FAGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedFlag))) > 0 and FAIsListedFlag  <> ''0'') THEN 1 ELSE 0 END) AS FAIsListedFlag
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedFlagDt))) is not null) THEN 1 ELSE 0 END) AS FAIsListedFlagDt
		,sum(CASE WHEN (len(ltrim(rtrim(FAIsListedPriceRange))) > 0 and FAIsListedPriceRange  <> ''0'') THEN 1 ELSE 0 END) AS FAIsListedPriceRange
		,sum(CASE WHEN (len(ltrim(rtrim(FALatitude))) > 0 and FALatitude  <> ''0'') THEN 1 ELSE 0 END) AS FALatitude
		,sum(CASE WHEN (len(ltrim(rtrim(FALongitude))) > 0 and FALongitude  <> ''0'') THEN 1 ELSE 0 END) AS FALongitude
		,sum(CASE WHEN (len(ltrim(rtrim(FAOLTV))) > 0 and FAOLTV  <> ''0'') THEN 1 ELSE 0 END) AS FAOLTV
		,sum(CASE WHEN (len(ltrim(rtrim(GarageFinishSqFt))) > 0 and GarageFinishSqFt  <> ''0'') THEN 1 ELSE 0 END) AS GarageFinishSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(GarageUnFinSqFt))) > 0 and GarageUnFinSqFt  <> ''0'') THEN 1 ELSE 0 END) AS GarageUnFinSqFt
		,sum(CASE WHEN (len(ltrim(rtrim(LienPosUpdateDate)))is not null) THEN 1 ELSE 0 END) AS LienPosUpdateDate
		,sum(CASE WHEN (len(ltrim(rtrim(LienPosUpdateFlag))) > 0 and LienPosUpdateFlag  <> ''0'') THEN 1 ELSE 0 END) AS LienPosUpdateFlag
		,sum(CASE WHEN (len(ltrim(rtrim(MailForeignAddrInd))) > 0 and MailForeignAddrInd  <> ''0'') THEN 1 ELSE 0 END) AS MailForeignAddrInd
		,sum(CASE WHEN (len(ltrim(rtrim(MailingGeoCodeResults))) > 0 and MailingGeoCodeResults  <> ''0'') THEN 1 ELSE 0 END) AS MailingGeoCodeResults
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg3InputDocNbr))) > 0 and Mtg3InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg3InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatBook))) > 0 and Mtg4FormatBook  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatBook
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatDocNbr))) > 0 and Mtg4FormatDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4FormatPage))) > 0 and Mtg4FormatPage  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4FormatPage
		,sum(CASE WHEN (len(ltrim(rtrim(Mtg4InputDocNbr))) > 0 and Mtg4InputDocNbr  <> ''0'') THEN 1 ELSE 0 END) AS Mtg4InputDocNbr
		,sum(CASE WHEN (len(ltrim(rtrim(SchoolDistrictName))) > 0 and SchoolDistrictName  <> ''0'') THEN 1 ELSE 0 END) AS SchoolDistrictName
		,sum(CASE WHEN (len(ltrim(rtrim(SitusGeoCodeResults))) > 0 and SitusGeoCodeResults  <> ''0'') THEN 1 ELSE 0 END) AS SitusGeoCodeResults
		,sum(CASE WHEN (len(ltrim(rtrim(TotalOpenLienAmt))) > 0 and TotalOpenLienAmt  <> ''0'') THEN 1 ELSE 0 END) AS TotalOpenLienAmt
		,sum(CASE WHEN (len(ltrim(rtrim(TotalOpenLienNbr))) > 0 and TotalOpenLienNbr  <> ''0'') THEN 1 ELSE 0 END) AS TotalOpenLienNbr
		,sum(CASE WHEN (len(ltrim(rtrim(TPGeoStatusCode))) > 0 and TPGeoStatusCode  <> ''0'') THEN 1 ELSE 0 END) AS TPGeoStatusCode
		,sum(CASE WHEN (len(ltrim(rtrim(TPLatitude))) > 0 and TPLatitude  <> ''0'') THEN 1 ELSE 0 END) AS TPLatitude
		,sum(CASE WHEN (len(ltrim(rtrim(TPLongitude))) > 0 and TPLongitude  <> ''0'') THEN 1 ELSE 0 END) AS TPLongitude
		,sum(CASE WHEN (len(ltrim(rtrim(VacantFlag))) > 0 and VacantFlag  <> ''0'') THEN 1 ELSE 0 END) AS VacantFlag
		,sum(CASE WHEN (VacantFlagDate is not null) THEN 1 ELSE 0 END) AS VacantFlagDate
		,sum(CASE WHEN (len(ltrim(rtrim(MailingFIPS))) > 0 and MailingFIPS  <> ''0'') THEN 1 ELSE 0 END) AS MailingFIPS
		,sum(CASE WHEN (len(ltrim(rtrim(DBSTaxAmount))) > 0 and DBSTaxAmount  <> ''0'') THEN 1 ELSE 0 END) AS DBSTaxAmount
		,sum(CASE WHEN (len(ltrim(rtrim(p.DBSTaxYear))) > 0 and p.DBSTaxYear  <> ''0'') THEN 1 ELSE 0 END) AS DBSTaxYear
		,sum(CASE WHEN ([FATimestamp] is not null) THEN 1 ELSE 0 END) AS FATimestamp
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken0 ))) > 0 and  AssessorLkupToken0   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken0
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken1 ))) > 0 and  AssessorLkupToken1   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken1
		,sum(CASE WHEN (len(ltrim(rtrim( AssessorLkupToken2 ))) > 0 and  AssessorLkupToken2   <> ''0'') THEN 1 ELSE 0 END) AS  AssessorLkupToken2
		,sum(CASE WHEN (len(ltrim(rtrim( ConCurrMtg1InterestRate ))) > 0 and  ConCurrMtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  ConCurrMtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( ConCurrMtg2InterestRate ))) > 0 and  ConCurrMtg2InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  ConCurrMtg2InterestRate
		,sum(CASE WHEN ( FAActiveDt  is not null) THEN 1 ELSE 0 END) AS  FAActiveDt  
		,sum(CASE WHEN ( FAAddressParsedMailing  is not null) THEN 1 ELSE 0 END) AS  FAAddressParsedMailing  
		,sum(CASE WHEN (len(ltrim(rtrim( FACLTV ))) > 0 and  FACLTV   <> ''0'') THEN 1 ELSE 0 END) AS  FACLTV
		,sum(CASE WHEN ( FACreateDt  is not null) THEN 1 ELSE 0 END) AS  FACreateDt  
		,sum(CASE WHEN ( FADataArchiveDate  is not null) THEN 1 ELSE 0 END) AS  FADataArchiveDate  
		,sum(CASE WHEN (len(ltrim(rtrim( FADateReceived ))) > 0 and  FADateReceived   <> ''0'') THEN 1 ELSE 0 END) AS  FADateReceived
		,sum(CASE WHEN ( FADeriveProcessDt  is not null) THEN 1 ELSE 0 END) AS  FADeriveProcessDt  
		,sum(CASE WHEN ( FAEnhanceprocessDt  is not null) THEN 1 ELSE 0 END) AS  FAEnhanceprocessDt  
		,sum(CASE WHEN ( FAOwnershipUpdateDt  is not null) THEN 1 ELSE 0 END) AS  FAOwnershipUpdateDt  
		,sum(CASE WHEN (len(ltrim(rtrim( FAOwnerTransactionId ))) > 0 and  FAOwnerTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  FAOwnerTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( FASourceInd ))) > 0 and  FASourceInd   <> ''0'') THEN 1 ELSE 0 END) AS  FASourceInd
		,sum(CASE WHEN (len(ltrim(rtrim( FAUserId ))) > 0 and  FAUserId   <> ''0'') THEN 1 ELSE 0 END) AS  FAUserId
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1EstLoanBalance ))) > 0 and  Mtg1EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1EstPaymentAmt ))) > 0 and  Mtg1EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg1InterestRate ))) > 0 and  Mtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2EstLoanBalance ))) > 0 and  Mtg2EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2EstPaymentAmt ))) > 0 and  Mtg2EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg2InterestRate ))) > 0 and  Mtg2InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg2InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3EstLoanBalance ))) > 0 and  Mtg3EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3EstPaymentAmt ))) > 0 and  Mtg3EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg3InterestRate ))) > 0 and  Mtg3InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg3InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4EstLoanBalance ))) > 0 and  Mtg4EstLoanBalance   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4EstLoanBalance
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4EstPaymentAmt ))) > 0 and  Mtg4EstPaymentAmt   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4EstPaymentAmt
		,sum(CASE WHEN (len(ltrim(rtrim( Mtg4InterestRate ))) > 0 and  Mtg4InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  Mtg4InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( OldApnIndicator ))) > 0 and  OldApnIndicator   <> ''0'') THEN 1 ELSE 0 END) AS  OldApnIndicator
		,sum(CASE WHEN (len(ltrim(rtrim( PrevMtg1InterestRate ))) > 0 and  PrevMtg1InterestRate   <> ''0'') THEN 1 ELSE 0 END) AS  PrevMtg1InterestRate
		,sum(CASE WHEN (len(ltrim(rtrim( VendorLoadDate ))) > 0 and  VendorLoadDate   <> ''0'') THEN 1 ELSE 0 END) AS  VendorLoadDate
		,sum(CASE WHEN (len(ltrim(rtrim( VersionId ))) > 0 and  VersionId   <> ''0'') THEN 1 ELSE 0 END) AS  VersionId
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSaleTransactionId ))) > 0 and  SecondPrevSaleTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSaleRecordingDate ))) > 0 and  SecondPrevSaleRecordingDate   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim( SecondPrevSalesPrice ))) > 0 and  SecondPrevSalesPrice   <> ''0'') THEN 1 ELSE 0 END) AS  SecondPrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSaleTransactionId ))) > 0 and  ThirdPrevSaleTransactionId   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSaleTransactionId
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSaleRecordingDate ))) > 0 and  ThirdPrevSaleRecordingDate   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSaleRecordingDate
		,sum(CASE WHEN (len(ltrim(rtrim( ThirdPrevSalesPrice ))) > 0 and  ThirdPrevSalesPrice   <> ''0'') THEN 1 ELSE 0 END) AS  ThirdPrevSalesPrice
		,sum(CASE WHEN (len(ltrim(rtrim( HouseFacingDirection ))) > 0 and  HouseFacingDirection   <> ''0'') THEN 1 ELSE 0 END) AS  HouseFacingDirection -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( FARooftopLatitude ))) > 0 and  FARooftopLatitude   <> ''0'') THEN 1 ELSE 0 END) AS  FARooftopLatitude -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( FARooftopLongitude ))) > 0 and  FARooftopLongitude   <> ''0'') THEN 1 ELSE 0 END) AS  FARooftopLongitude -- GM added 20190226
		,sum(CASE WHEN (len(ltrim(rtrim( BuildingEstFootprintSqFt ))) > 0 and  BuildingEstFootprintSqFt   <> ''0'') THEN 1 ELSE 0 END) AS  BuildingEstFootprintSqFt -- GM added 20190314
		,sum(CASE WHEN (len(ltrim(rtrim( BathTotalCalcEst ))) > 0 and  BathTotalCalcEst   <> ''0'') THEN 1 ELSE 0 END) AS  BathTotalCalcEst  -- GM added 20190415
		,sum(CASE WHEN (len(ltrim(rtrim( DQOZ_TractType ))) > 0 and  DQOZ_TractType   <> ''0'') THEN 1 ELSE 0 END) AS  DQOZ_TractType  -- GM added 20190416
		,sum(CASE WHEN (len(ltrim(rtrim( DQOZ_ACSDataSource ))) > 0 and  DQOZ_ACSDataSource   <> ''0'') THEN 1 ELSE 0 END) AS  DQOZ_ACSDataSource  -- GM added 20190416
		,sum(CASE WHEN (len(ltrim(rtrim( VacantScore ))) > 0 and  VacantScore   <> ''0'') THEN 1 ELSE 0 END) AS  VacantScore  -- GM added 20190715
		,sum(CASE WHEN (len(ltrim(rtrim( BedroomsEst ))) > 0 and  BedroomsEst   <> ''0'') THEN 1 ELSE 0 END) AS  BedroomsEst  -- GM added 20191001
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_REF_ID ))) > 0 and  DTDB_REF_ID   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_REF_ID  -- GM added 20191205
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_FORMATTED_APN ))) > 0 and  DTDB_FORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_FORMATTED_APN  -- GM added 20191205
		,sum(CASE WHEN (len(ltrim(rtrim( MailingLabelName ))) > 0 and  MailingLabelName   <> ''0'') THEN 1 ELSE 0 END) AS  MailingLabelName -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( Name1TypeInd ))) > 0 and  Name1TypeInd   <> ''0'') THEN 1 ELSE 0 END) AS  Name1TypeInd -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( Name2TypeInd ))) > 0 and  Name2TypeInd   <> ''0'') THEN 1 ELSE 0 END) AS  Name2TypeInd -- GM added 20200310
		,sum(CASE WHEN (len(ltrim(rtrim( TaxSourceInd ))) > 0 and  TaxSourceInd   <> ''0'') THEN 1 ELSE 0 END) AS  TaxSourceInd -- GM added 20200312
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionName ))) > 0 and  FASubdivisionName   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionName -- GM added 20200427
		,sum(CASE WHEN (len(ltrim(rtrim( FAComplexNbrUnits ))) > 0 and  FAComplexNbrUnits   <> ''0'') THEN 1 ELSE 0 END) AS  FAComplexNbrUnits -- GM added 20200427
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionNameID ))) > 0 and  FASubdivisionNameID   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionNameID -- GM added 20201027
		,sum(CASE WHEN (len(ltrim(rtrim( FASubdivisionPhase ))) > 0 and  FASubdivisionPhase   <> ''0'') THEN 1 ELSE 0 END) AS  FASubdivisionPhase -- GM added 20201113
		,sum(CASE WHEN (len(ltrim(rtrim( ElevatorCode ))) > 0 and  ElevatorCode   <> ''0'') THEN 1 ELSE 0 END) AS  ElevatorCode -- GM added 20201210
		,sum(CASE WHEN (len(ltrim(rtrim( FAEstimatedMultiPolygonFlag ))) > 0 and  FAEstimatedMultiPolygonFlag   <> ''0'') THEN 1 ELSE 0 END) AS  FAEstimatedMultiPolygonFlag -- GM added 20201210 rename 20210204
		,sum(CASE WHEN (len(ltrim(rtrim( FAEstimatedNumberofBuildings ))) > 0 and  FAEstimatedNumberofBuildings   <> ''0'') THEN 1 ELSE 0 END) AS  FAEstimatedNumberofBuildings -- GM added 20201210
		,sum(CASE WHEN (len(ltrim(rtrim( Poverty ))) > 0 and  Poverty   <> ''0'') THEN 1 ELSE 0 END) AS  Poverty -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( UnEmployment ))) > 0 and  UnEmployment   <> ''0'') THEN 1 ELSE 0 END) AS  UnEmployment -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( PopulationLoss ))) > 0 and  PopulationLoss   <> ''0'') THEN 1 ELSE 0 END) AS  PopulationLoss -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( RemoteRural ))) > 0 and  RemoteRural   <> ''0'') THEN 1 ELSE 0 END) AS  RemoteRural -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( Distressed ))) > 0 and  Distressed   <> ''0'') THEN 1 ELSE 0 END) AS  Distressed -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( UnderServed ))) > 0 and  UnderServed   <> ''0'') THEN 1 ELSE 0 END) AS  UnderServed -- GM added 20210303
		,sum(CASE WHEN (len(ltrim(rtrim( DTDB_UNFORMATTED_APN ))) > 0 and  DTDB_UNFORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  DTDB_UNFORMATTED_APN -- GM added 20210505
		,sum(CASE WHEN (len(ltrim(rtrim( ConformingLoanLimitYear ))) > 0 and  ConformingLoanLimitYear   <> ''0'') THEN 1 ELSE 0 END) AS  ConformingLoanLimitYear -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( ConformingLoanLimit ))) > 0 and  ConformingLoanLimit   <> ''0'') THEN 1 ELSE 0 END) AS  ConformingLoanLimit -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( PriorConformingLoanLimitYear ))) > 0 and  PriorConformingLoanLimitYear   <> ''0'') THEN 1 ELSE 0 END) AS  PriorConformingLoanLimitYear -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( PriorConformingLoanLimit ))) > 0 and  PriorConformingLoanLimit   <> ''0'') THEN 1 ELSE 0 END) AS  PriorConformingLoanLimit -- GM added 20211119
		,sum(CASE WHEN (len(ltrim(rtrim( MTG1InterestRateSrce ))) > 0 and  MTG1InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG1InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG2InterestRateSrce ))) > 0 and  MTG2InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG2InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG3InterestRateSrce ))) > 0 and  MTG3InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG3InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( MTG4InterestRateSrce ))) > 0 and  MTG4InterestRateSrce   <> ''0'') THEN 1 ELSE 0 END) AS  MTG4InterestRateSrce -- GM added 20220607
		,sum(CASE WHEN (len(ltrim(rtrim( CS_FORMATTED_APN ))) > 0 and  CS_FORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  CS_FORMATTED_APN -- GM added 20210718
		,sum(CASE WHEN (len(ltrim(rtrim( CS_UNFORMATTED_APN ))) > 0 and  CS_UNFORMATTED_APN   <> ''0'') THEN 1 ELSE 0 END) AS  CS_UNFORMATTED_APN -- GM added 20210718
	from [DragonAssr].[dbo].[propertywork_'+@FipsCode+'] p with(NOLOCK),[Global].[dbo].[County] g with(NOLOCK)
	WHERE g.fipscode = '''+@FipsCode+'''
	group by [fips],[State],[County Name]
	')

END
