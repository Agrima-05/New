SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[UpdatePoint--](@fips int) as
                              update d
                              set d.points= p.point
                              from addr.dbo.DMaddr1231 d,points_20121231.dbo.points p
                              where d.fips = @fips
                              and d.PARCEL_APN = p.apn
                              and len(apn)<>0


