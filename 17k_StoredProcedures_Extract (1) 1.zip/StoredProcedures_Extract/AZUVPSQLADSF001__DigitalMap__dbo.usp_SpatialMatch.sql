SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[usp_SpatialMatch] 
AS
BEGIN
--'159','041','089','049', '045'
truncate table	[DigitalMap].[dbo].[ParcelBoundaryAll_HJ_Columbus_OH_Counties]
insert into [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_Columbus_OH_Counties]
select * from [DigitalMap].[dbo].[vParcelBoundaryAll_HJ] where Fips in('39159','39041','39089','39049', '39045')


truncate table	[DigitalMap].[dbo].[Point_HJ_Columbus_OH_Counties]
insert into [Point_HJ_Columbus_OH_Counties]
SELECT [FIPS]
      ,[PropertyID]
      
      ,[SitusLatitude]
      ,[SitusLongitude]
      , (geometry::STGeomFromText( 'POINT('+cast(cast([SitusLongitude] as decimal(13,6)) as varchar(20)) +' ' +cast(cast([SitusLatitude] as decimal(13,6)) as varchar(20)) + ')'  ,4269)) as [LatLonGeometry]
	  ,[SitusGeoCodeResults]
  FROM [Data].[dbo].[Property]where Fips in('39159','39041','39089','39049', '39045') and [SitusGeoCodeResults] in ('GS05', 'GS06')


drop table 
	  [DigitalMap].[dbo].[Matched_HJ_Columbus_OH]

SELECT s.PropertyId,
	   c.id as GID
	   ,'P' as MatchSource
	  into
	  -- drop table 
	  [DigitalMap].[dbo].[Matched_HJ_Columbus_OH]
  FROM [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_Columbus_OH_Counties] s with(index([SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269]))
    inner join xGtrang.dbo.cmh_boundaries_for_datatree_sample c on s.[ParcelGeometry4269].STIntersects(c.GEOM) = 1
	where s.PropertyId is not null



insert into [DigitalMap].[dbo].[Matched_HJ_Columbus_OH] 
SELECT s.PropertyId,
	   c.id as GID
	   ,'L'  as MatchSource
	 
  FROM [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_Columbus_OH_Counties] s with(index([SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269]))
    inner join xGtrang.dbo.cmh_boundaries_for_datatree_sample c on s.[ParcelGeometry4269].STIntersects(c.GEOM) = 1
	where s.PropertyId is not null
	and  not exists (select 1 from  [DigitalMap].[dbo].[Matched_HJ_Columbus_OH]  m where m.PropertyId = s.PropertyId and m.GID = c.id)
END
