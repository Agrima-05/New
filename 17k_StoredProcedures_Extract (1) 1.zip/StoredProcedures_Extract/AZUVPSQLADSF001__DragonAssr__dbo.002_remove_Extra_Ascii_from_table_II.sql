SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[002_remove_Extra_Ascii_from_table_II] @table varchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @colName VARCHAR(255)
	DECLARE @prec VARCHAR(255)
	DECLARE @sqlCmd VARCHAR(max)

	DECLARE db_cursor CURSOR FOR  

	SELECT c.name ColumnName
	FROM sys.columns c with(NOLOCK) INNER JOIN
		 sys.tables t with(NOLOCK) ON c.object_id = t.object_id INNER JOIN
		 sys.schemas s with(NOLOCK) ON t.schema_id = s.schema_id
	where t.name = @table 
	and c.System_type_id not in(40,42,48,52,56,61,62,104,106,108,127)
	order by ColumnName

	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @colName   

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		BEGIN
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''\'','''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%\%''')

		END
		FETCH NEXT FROM db_cursor INTO @colName
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

END

