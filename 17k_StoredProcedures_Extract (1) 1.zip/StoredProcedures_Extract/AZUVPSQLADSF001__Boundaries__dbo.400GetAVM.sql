SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
Create PROCEDURE [dbo].[400GetAVM] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

-----------STEP 1

INSERT INTO [GISService_ETL].[gis].[FASpot_a_AVM]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[APN]
           ,[FIPS]
           ,[REF_ID]
           ,[DIRECT_FINAL_VALUE]
           ,[DIRECT_HIGH_VALUE]
           ,[DIRECT_LOW_VALUE]
           ,[DIRECT_CONFIDENCE_SCORE]
           ,[DIRECT_FORECAST_STANDARD_DEVIATION]
           ,[Procision_ValuationDate])

Select      [REF_ID]
           ,a.[PropertyID]
           ,[FormattedAPN]
           ,DTDB_FORMATTED_APN
           ,fipscode
           ,[REF_ID]
           ,[DIRECT_FINAL_VALUE]
           ,[DIRECT_HIGH_VALUE]
           ,[DIRECT_LOW_VALUE]
           ,[DIRECT_CONFIDENCE_SCORE]
           ,[DIRECT_FORECAST_STANDARD_DEVIATION]
           ,[VALUE_AS_OF]
FROM [Holocron].[dbo].[Holocron] a with (nolock)
join data..property p with (Nolock)
on a.[Fipscode] = p.fips
and a.propertyid = p.propertyid
where [Fipscode] = @fips
and [DIRECT_FINAL_VALUE] is not null

INSERT INTO [Boundaries].[dbo].[zz_400GetAVM_Run]
           ([Fips],[DateTime])
 Select @fips,GetDate()

END

