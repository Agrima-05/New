SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_ReRun_Generated]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @FipsCode varchar(5)

		DECLARE CurGen CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE [STATE] in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
			ORDER BY [FIPSCode]


		OPEN CurGen   
		FETCH NEXT FROM CurGen INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC [dbo].[CreateFASpotGenerated_FAST] @FipsCode

			EXEC('DELETE FROM FASpot
			WHERE UCIDFlag = ''D''
			and FIPS = ''' + @FipsCode + '''
			')

			  EXEC('update [dbo].[FASpot_Generated]
			  SET [CentroidLatitude] = [ParcelGeometry].STCentroid().STY
			  ,[CentroidLongitude] = [ParcelGeometry].STCentroid().STX
			  WHERE FIPS = ''' + @FipsCode + '''
				')
			  
			  EXEC('update [dbo].[FASpot_Generated]
			  SET [CentroidPointGeom] = geography::Point([CentroidLatitude],[CentroidLongitude],  4269)
			  WHERE FIPS = ''' + @FipsCode + '''
			  ')
			
			FETCH NEXT FROM CurGen INTO @FipsCode   
		END   

		CLOSE CurGen   
		DEALLOCATE CurGen 
END
