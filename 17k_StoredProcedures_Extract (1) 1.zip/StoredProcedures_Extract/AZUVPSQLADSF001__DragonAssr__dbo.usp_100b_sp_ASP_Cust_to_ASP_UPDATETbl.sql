SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[usp_100b_sp_ASP_Cust_to_ASP_UPDATETbl]
AS
BEGIN

		truncate table [dbo].[a_ASP_IN_Updatetbl]
		truncate table [dbo].[a_ASP_IN_Updatetbl_STD]

		truncate table [dbo].[DragonAssr_UpdateTbl]
		truncate table [dbo].[DragonAssr_UpdateTbl_STD]

		EXEC('INSERT INTO [dbo].[a_ASP_IN_Updatetbl]
		(
			   [RAW_ID]
			  ,[FullStreetAddress]
			  ,[City]
			  ,[State]
			  ,[ZIP5]
		)
		SELECT [DTDB_Ref_ID]
			  ,[SitusStdFullStreetAddress]
			  ,[SitusStdCity]
			  ,[SitusStdState]
			  ,[SitusStdZIP5]
		FROM [dbo].[PropertyWorkUpdateTbl] 
		WHERE DTDB_REF_ID is not NULL')


		update [a_ASP_IN_Updatetbl] SET State = NULL Where len(STATE)>2


		IF (Select COUNT(*) FROM dbo.[a_ASP_IN_Updatetbl] with(NOLOCK) WHERE Processed = 'N') > 0 
			BEGIN

				WHILE (Select COUNT(*) FROM [a_ASP_IN_Updatetbl] with(NOLOCK) WHERE Processed = 'N') > 0
					BEGIN
				
						truncate table dbo.DragonAssr_Updatetbl
						truncate table [dbo].[DragonAssr_UpdateTbl_STD]

						INSERT INTO dbo.DragonAssr_Updatetbl(RecordId,[FullStreetAddress],[City],[State],[Zip],[raw_id])
						SELECT TOP 200000 ASP_ID,LEFT([FullStreetAddress],255),LEFT([City],55),[State],[ZIP5],[RAW_ID]
						FROM a_ASP_IN_Updatetbl 
						WHERE PROCESSED = 'N'

						EXEC('INSERT INTO  [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
						 (''DragonAssr_UpdateTbl'',''DragonAssr_UpdateTbl'',''B'',''R'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
						 ')

					---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

							IF (SELECT COUNT(*) FROM [dbo].DragonAssr_Updatetbl with(NOLOCK)) = 0
								BEGIN
									RETURN;
								END
							ELSE
								BEGIN
									---- 1 min wait periods until ASP is complete
									DECLARE @CheckASP as int
				
										SET @CheckASP = 0

									WHILE @CheckASP = 0
										BEGIN
											WAITFOR DELAY '00:01'
							
										---- Checks for completion ** If not wait again
										SET @CheckASP = (Select COUNT(*) from [dbo].[DragonAssr_UpdateTbl_STD] with(NOLOCK))
										END
								END

						EXEC dbo.[usp_100c_sp_ASP_Cust_STD_UpdateTbl]

						UPDATE a_ASP_IN_Updatetbl SET Processed = 'Y'
						WHERE ASP_ID in(Select ASP_ID from [dbo].[a_ASP_IN_Updatetbl_STD])

					END
		END



END



