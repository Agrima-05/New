SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================

CREATE PROCEDURE [dbo].[d500_Ownership_Update_UPDATE]
AS
BEGIN

	DECLARE @FADateReceived varchar(8)
	DECLARE @FATimeStamp Datetime
	SELECT @FADateReceived = FADateReceived FROM [Global].dbo.[DailyTimestamp]
	SELECT @FATimeStamp = FATimeStamp FROM [Global].dbo.[DailyTimestamp]

	TRUNCATE TABLE Data.[dbo].[Transaction_Deed_OwnerRollup]

	DROP TABLE IF EXISTS #OwnerRollUp
	SELECT 
		d.[FIPS]
		,d.[FAPropertyId]
		,d.[RecordingDt]
		,CAST(d.[FIPS]  +
					(CASE WHEN FAPropertyId is not null  
						THEN REPLICATE('0', 10 - LEN([FAPropertyId])) + Cast ([FAPropertyId] as varchar)
						else Cast('0000000000' as varchar)  end)
						
			
			+
					(CASE WHEN isNULL([Saledate],'') Not like '' THEN [Saledate]
						 WHEN isNULL([Saledate],'') like '' and isNULL([RecordingDt],'') Not like '' THEN [RecordingDt]
						 WHEN isNULL([Saledate],'') like '' and isNULL([RecordingDt],'') like '' and [Loan1RecordingDt] is not null THEN [Loan1RecordingDt]
						 WHEN isNULL([Saledate],'') like '' and isNULL([RecordingDt],'') like '' and [Loan2RecordingDt] is not null THEN [Loan2RecordingDt]
						 else Cast ('00000000' as varchar) End) 
						 
			+ 
					CASE WHEN isNULL(DocNbrFrmt,'') Not like ''
						  THEN RIGHT(REPLICATE('0', 8) 
							+ Substring(CASE WHEN DocNbrFrmt LIKE '%.%' THEN global.dbo.After1stcharacter(DocNbrFrmt,'.') ELSE DocNbrFrmt END,1,8)
								, 8)

						 WHEN isNULL(BkPgFrmt,'') Not like '' 
						  THEN RIGHT(REPLICATE('0', 8) 
						    + Substring(replace(BkPgFrmt,'.',''),1,8), 8)
						ELSE '00000000'
					END

					as varchar(31))	  as [ChronoKey]
		,d.[DocumentTypeCode]
		,d.[FAUCIDFlag]
		,d.[Buyer1FullName]
		,d.[Buyer1NoParsInd]
		,d.[Buyer1LastName]
		,d.[Buyer1FirstName]
		,d.[Buyer1MiddleInitial]
		,d.[Buyer1NameSiffix]
		,d.[BuyerVestingCode]
		,d.[Buyer1IDCode]
		,d.[Buyer1CompanyName]
		,d.[Buyer2FullName]
		,d.[Buyer2NoParsInd]
		,d.[Buyer2LastName]
		,d.[Buyer2FirstName]
		,d.[Buyer2MiddleInitial]
		,d.[Buyer2NameSuffix]
		,d.[Buyer2CompanyName]
		,d.[Buyer2IDCode]
		,d.[Buyer3FullName]
		,d.[Buyer3NoParsInd]
		,d.[Buyer3LastName]
		,d.[Buyer3FirstName]
		,d.[Buyer3MiddleInitial]
		,d.[Buyer3NameSuffix]
		,d.[Buyer3IDCode]
		,d.[Buyer3CompanyName]
		,d.[Buyer4FullName]
		,d.[Buyer4NoParsInd]
		,d.[Buyer4LastName]
		,d.[Buyer4FirstName]
		,d.[Buyer4MiddleInitial]
		,d.[Buyer4NameSuffix]
		,d.[Buyer4IDCode]
		,d.[Buyer4CompanyName]
		,d.TransactionId
		,d.[BuyerMailFullAddress]
		,d.[BuyerMailHouseNbr]
		,d.[BuyerMailHouseNbrSuffix]
		,d.[BuyerMailLeftDirection]
		,d.[BuyerMailStreetName]
		,d.[BuyerMailMode]
		,d.[BuyerMailRightDirection]
		,d.[BuyerMailUnitNumber]
		,d.[BuyerMailCity]
		,d.[BuyerMailState]
		,d.[BuyerMailZip5]
		,d.[BuyerMailZip4]
		,d.[BuyerMailCarrierCode]
		,d.[BuyerMailUnitType]
		,d.[BuyerMailGeoStatusCode]
		,d.[SitusStdFullStreetAddress]
		,d.[SitusStdHouseNbr]
		,d.[SitusStdHouseNbrSuffix]
		,d.[SitusStdDirectionLeft]
		,d.[SitusStdStreet]
		,d.[SitusStdMode]
		,d.[SitusStdDirectionRight]
		,d.[SitusStdUnitNbr]
		,d.[SitusStdCity]
		,d.[SitusStdState]
		,d.[SitusStdZIP5]
		,d.[SitusStdZIP4]
		,d.[SitusStdCarrierCode]
		,d.[SitusStdUnitType]
		,d.[SitusGeoStatusCode]
		,d.[MailingFips]
		,d.[Name1TypeIndBuyer]
		,d.[Name2TypeIndBuyer]
		,d.[RecentOwnership]
		,d.SaleDate
		,d.[MailingLabelNameBuyer]
	INTO #OwnerRollUp
	FROM [Data].[dbo].[Deed] d with(Nolock) 
	WHERE isNULL(d.FAUCIDFlag,'') != 'D'

	CREATE INDEX ix_DocType ON #OwnerRollUp([DocumentTypeCode])
	CREATE INDEX ix_FipsPropIDChronoKey ON #OwnerRollUp([FIPS],[FAPropertyID],[ChronoKey])

		DROP INDEX if exists [RecordingDate] ON [Data].[dbo].[Transaction_Deed_OwnerRollup]
		DROP INDEX if exists [FIPS_ChronoKey] ON [Data].[dbo].[Transaction_Deed_OwnerRollup]

	INSERT INTO [Data].[dbo].[Transaction_Deed_OwnerRollup]([FIPS]
           ,[PropertyID]
           ,[ChronoKey])
	SELECT 
		d.[FIPS]
		,d.[FAPropertyId] 
		,Max(d.[ChronoKey])
	FROM #OwnerRollUp d with(Nolock) 
		JOIN [GLOBAL].dbo.COUNTY g with(Nolock)
			on d.FIPS = g.FIPSCode
	--where Convert(DateTime,Coalesce(CASE WHEN d.SaleDate Like '' THEN NULL ELSE d.Saledate END,d.[RecordingDt])) > DATEADD(MM,-12,Convert(DateTime,isNULL(g.[CertificationDate],'2000-01-01')))
		where Convert(DateTime,Coalesce(NULLIF([SaleDate],''),d.[RecordingDt])) > DATEADD(MM,-12,Convert(DateTime,isNULL(CASE WHEN g.[CertificationDate] < convert(varchar(8),GETDATE()-540,112) THEN NULL ELSE g.[CertificationDate] END,convert(varchar(8),GetDate()-180,112))))
			AND (d.DocumentTypeCode NOT IN('11','26','6','5','51','R','45','38') -- 20230217 Removed 54 MAS 
				OR (d.DocumentTypeCode NOT IN('21','61') AND SaleDate is NULL))
	group by d.[FIPS], d.[FAPropertyId]
				
		---- ADDED FOR FAMILY TRUSTS 20210907
		INSERT INTO [Data].[dbo].[Transaction_Deed_OwnerRollup]([FIPS]
			   ,[PropertyID]
			   ,[ChronoKey])
		SELECT 
			d.[FIPS]
			,d.[FAPropertyId] 
			,Max(d.[ChronoKey])
		FROM #OwnerRollUp d with(Nolock) 
			JOIN [GLOBAL].dbo.COUNTY g with(Nolock)
				on d.FIPS = g.FIPSCode
		--where Convert(DateTime,Coalesce(CASE WHEN d.SaleDate Like '' THEN NULL ELSE d.Saledate END,d.[RecordingDt])) > DATEADD(MM,-18,Convert(DateTime,isNULL(g.[CertificationDate],'2000-01-01')))
		where Convert(DateTime,Coalesce(NULLIF([SaleDate],''),d.[RecordingDt])) > DATEADD(MM,-12,Convert(DateTime,isNULL(CASE WHEN g.[CertificationDate] < convert(varchar(8),GETDATE()-540,112) THEN NULL ELSE g.[CertificationDate] END,convert(varchar(8),GetDate()-180,112))))
				AND (isNULL(d.DocumentTypeCode,'') NOT IN('','11','26','6','5','51','R','45','38')
				OR (d.DocumentTypeCode NOT IN('21','61') AND SaleDate is NULL))
						AND d.Buyer1FirstName like '%Family%'
		group by d.[FIPS], d.[FAPropertyId]


		CREATE NONCLUSTERED INDEX [FIPS_ChronoKey] ON [Data].[dbo].[Transaction_Deed_OwnerRollup]
		([FIPS] ASC,
			[ChronoKey] ASC,
			[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		ALTER INDEX [ix_Chrono] ON [Data].[dbo].[Transaction_Deed_OwnerRollup] REBUILD PARTITION = ALL WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		CREATE NONCLUSTERED INDEX [RecordingDate] ON [Data].[dbo].[Transaction_Deed_OwnerRollup]
		([RecordingDate] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [FIPS_FipsPropID] ON #OwnerRollUp
		([FIPS] ASC,
			[FAPropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	UPDATE D
	Set D.[RecentOwnership] = 'y' 
	From [Data].[dbo].[Transaction_Deed_OwnerRollup] O JOIN #OwnerRollUp D
		  on O.Fips = D.fips   
			and O.[PropertyID] = D.FAPropertyId 
				and O.ChronoKey = D.ChronoKey 


	-- UPDATE Property with Recent Ownership

	UPDATE P
		Set P.[FATimestamp] = @FATimeStamp,
		P.[FAOwnershipUpdateDt] = @FATimeStamp,
		P.[OwnerStdNAME1FULL] =Substring([Buyer1FullName],1,80), 
		P.[OwnerStd1CorpInd]=[Buyer1NoParsInd],
		P.[OwnerStd1LastName]=Substring([Buyer1LastName],1,30),
		P.[OwnerStd1FirstName]=Substring([Buyer1FirstName],1,30),
		P.[OwnerStd1MiddleName]=Substring([Buyer1MiddleInitial],1,20),
		P.[OwnerStd1Suffix]=[Buyer1NameSiffix],
		P.[OwnerStd1OwnershipRights] = CASE WHEN [BuyerVestingCode] is NULL THEN [Buyer1IDCode] ELSE [BuyerVestingCode] END,
		P.[OwnerStd1RelationshipType] = [Buyer1IDCode],
		P.[OwnerStd1CorpName]=Substring([Buyer1CompanyName],1,45), 
		P.[Owner1DoNotParse]=[Buyer1NoParsInd],
		P.[OwnerStdNAME2FULL]=Substring([Buyer2FullName],1,80), 
		P.[OwnerStd2CorpInd]=[Buyer2NoParsInd],
		P.[OwnerStd2LastName]=Substring([Buyer2LastName],1,30),
		P.[OwnerStd2FirstName]=Substring([Buyer2FirstName],1,30),
		P.[OwnerStd2MiddleName]=Substring([Buyer2MiddleInitial],1,20),
		P.[OwnerStd2Suffix]=[Buyer2NameSuffix],
		P.[OwnerStd2CorpName]=Substring([Buyer2CompanyName],1,45),
		P.[Owner2DoNotParse]=[Buyer2NoParsInd],
		P.[OwnerStd2RelationshipType] = [Buyer2IDCode],
		P.[FAOwnerTransactionId] = TransactionId, 
		P.[OwnerStdNAME3FULL]=Substring([Buyer3FullName],1,80), 
		P.[OwnerStd3CorpInd]=[Buyer3NoParsInd],
		P.[OwnerStd3LastName]=Substring([Buyer3LastName],1,30),
		P.[OwnerStd3FirstName]=Substring([Buyer3FirstName],1,30),
		P.[OwnerStd3MiddleName]=Substring([Buyer3MiddleInitial],1,20),
		P.[OwnerStd3Suffix]=[Buyer3NameSuffix],
		P.[OwnerStd3CorpName]=Substring([Buyer3CompanyName],1,45),
		P.[Owner3DoNotParse]=[Buyer3NoParsInd],
		P.[OwnerStd3RelationshipType] = [Buyer3IDCode],
		P.[OwnerStdNAME4FULL]=Substring([Buyer4FullName],1,80), 
		P.[OwnerStd4CorpInd]=[Buyer4NoParsInd],
		P.[OwnerStd4LastName]=Substring([Buyer4LastName],1,30),
		P.[OwnerStd4FirstName]=Substring([Buyer4FirstName],1,30),
		P.[OwnerStd4MiddleName]=Substring([Buyer4MiddleInitial],1,20),
		P.[OwnerStd4Suffix]=[Buyer4NameSuffix],
		P.[OwnerStd4CorpName]=Substring([Buyer4CompanyName],1,45),
		P.[Owner4DoNotParse]=[Buyer4NoParsInd],
		P.[OwnerStd4RelationshipType] = [Buyer4IDCode],

		-- ADDED CASE STATEMENT 20160315  MAS
		P.[MailingStdFullStreetAddress]= CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdFullStreetAddress] ELSE [BuyerMailFullAddress] END,
		P.[MailingStdHouseNbr]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdHouseNbr] ELSE [BuyerMailHouseNbr] END,
		P.[MailingStdHouseNbrSuffix]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdHouseNbrSuffix] ELSE [BuyerMailHouseNbrSuffix] END,
		P.[MailingStdDirectionLeft]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdDirectionLeft] ELSE [BuyerMailLeftDirection] END,
		P.[MailingStdStreet]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdStreet] ELSE [BuyerMailStreetName] END,
		P.[MailingStdMode]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdMode] ELSE [BuyerMailMode] END,
		P.[MailingStdDirectionRight]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdDirectionRight] ELSE [BuyerMailRightDirection] END,
		P.[MailingStdUnitNbr]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdUnitNbr] ELSE [BuyerMailUnitNumber] END,
		P.[MailingStdCity]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdCity] ELSE [BuyerMailCity] END,
		P.[MailingStdState]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdState] ELSE [BuyerMailState] END,
		P.[MailingStdZIP5]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdZIP5] ELSE [BuyerMailZip5] END,
		P.[MailingStdZIP4]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdZIP4] ELSE [BuyerMailZip4] END,
		P.[MailingStdCarrierCode]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdCarrierCode] ELSE [BuyerMailCarrierCode] END,
		P.[MailingStdUnitType]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusStdUnitType] ELSE [BuyerMailUnitType] END,
		P.[MailingStdMatchCode]=CASE WHEN isNULL([BuyerMailFullAddress],'') like '' THEN d.[SitusGeoStatusCode] ELSE [BuyerMailGeoStatusCode] END,
		P.[MailingFIPS] = CASE WHEN isNULL(d.[MailingFips],'') like '' THEN d.[Fips] ELSE d.[MailingFips] END,
		P.[FAAddressParsedMailing] = NULL,
		 P.[Name1TypeInd] = d.[Name1TypeIndBuyer],
		 P.[Name2TypeInd] = d.[Name2TypeIndBuyer],
		 P.[MailingOptOut] = NULL,
		 P.[MailingOptOutDate] = NULL,
		P.[MailForeignAddrInd] = NULL,
		P.[MailingLabelName] = d.[MailingLabelNameBuyer]
	From #OwnerRollUp d
	where D.[RecentOwnership] = 'y'

	UPDATE P
	SET P.[HomesteadInd] = null
	 ,P.[CalifHomeownerInd] = null
	 ,P.[VeteranInd] = null
	 ,P.[DisabledInd] = null
	 ,P.[WidowInd] = null
	 ,P.[SeniorInd] = null
	 ,P.[BankOwned] = null
	From #OwnerRollUp D with(NOLOCK)
	where D.[RecentOwnership] = 'y'
	and LEFT(isNULL(P.[OwnerStdNAME1FULL],''),8) != LEFT(isNULL([Buyer1FullName],''),8)


			UPDATE p
			SET MailingOptOut = 1,
			MailingOptOutDate = Convert(varchar(8),GETDATE(),112)
			FROM dbo.PropertyWorkUpdate p
			WHERE p.FIPS IN ('17017','17109','17193','20001','20003','20005','20007','20009','20013','20015','20017','20019',
				'20021','20023','20025','20027','20029','20031','20033','20035','20039','20041','20043','20045','20047','20049',
				'20051','20053','20055','20057','20059','20061','20063','20065','20067','20069','20071','20073','20075','20077',
				'20079','20081','20083','20085','20087','20089','20093','20095','20097','20099','20101','20103','20105','20107',
				'20109','20111','20113','20115','20117','20119','20121','20123','20125','20127','20129','20131','20133','20135',
				'20137','20139','20141','20143','20145','20147','20149','20151','20153','20155','20157','20159','20161','20163',
				'20165','20167','20169','20171','20175','20177','20179','20181','20183','20185','20187','20189','20191','20193',
				'20195','20197','20199','20201','20203','20205','20207','20209','26009','26055','26097','26123','26129','29083',
				'30087','30105','49023','20037','20011','30033','30005','30099','30003','30015','30103','30095','30109','30037',
				'01081','30083','30017','30093','30019','30041','30079','30071','30085','30025','53071','30011','30091','30077',
				'30107','30065','26039','20173','26027','20091','21177','30075','30073','45011','30097','16033','30069','30035',
				'21197','30001','16035','30059','16039','30051','30089','16071','30043','30101','16061','16025','16057','16047',
				'16029','30067','16059','30007','16031','16049','16087','16063','30009','16003','16007','53009','16067','16009',
				'16073','16037','30039','16079','16043','16023','16077','30055','16045','16015','30045','30061','30053','16069',
				'30057','16065','30021','16021','16053','30023','16041','16011','30029','16081','17029','45029','16051','16017',
				'30027','16085','26151','30047','16075','16013','30049','30081','26159','26045','17169','30013','16083','16019',
				'30031','16005','30063','29047','16055','42101','16027','30111','16001','49035','48413','45001','45003','45005'
				,'45007','45009','45011','45013','45015','45017','45019','45021','45023','45025','45027','45029','45031','45033','45035'
				,'45037','45039','45041','45043','45045','45047','45049','45051','45053','45055','45057','45059','45061','45063','45065'
				,'45067','45069','45071','45073','45075','45077','45079','45081','45083','45085','45087','45089','45091'
				)
			AND (MailingOptOut = 0 or MailingOptOut is NULL)


---- CLEAR OwnerOccupied 

	Update dbo.PropertyWorkUpdate 
	Set [OwnerOccupied] = null,
	[FATimestamp] = @FATimeStamp
	FROM dbo.PropertyWorkUpdate p


---- UPDATE OwnerOccupied
	Update dbo.PropertyWorkUpdate 
	Set [OwnerOccupied] = 'Y'
	FROM dbo.PropertyWorkUpdate p
	where isNULL([SitusStdFullStreetAddress],'') not like ''
			AND [SitusStdFullStreetAddress] = [MailingStdFullStreetAddress]
				AND propertyclassid in ('r','v') 
					AND Owner1DoNotParse is null
						AND isNULL([OwnerOccupied],'') Like ''

	Update dbo.PropertyWorkUpdate 
	Set [OwnerOccupied] = 'Y'
	FROM dbo.PropertyWorkUpdate p 
	where isNULL([SitusStdFullStreetAddress],'') not like ''
			AND [SitusStdFullStreetAddress] = [MailingStdFullStreetAddress]
				AND propertyclassid in ('r') 
					AND Owner1DoNotParse = 1
						AND isNULL([OwnerOccupied],'') Like ''
							AND OwnerStd1OwnershipRights in('FM','LV','RT','TR','TS','FL','FR') --= 'TR'

	Update dbo.PropertyWorkUpdate 
	Set [OwnerOccupied] = 'Y'
	FROM dbo.PropertyWorkUpdate p
	where isNULL([OwnerOccupied],'') Like '' and ([HomesteadInd] = 1 OR [SeniorInd] = 1
	OR [WelfareInd] = 1 OR [WidowInd] = 1 OR [VeteranInd] = 1)

	Update dbo.PropertyWorkUpdate 
	Set [OwnerOccupied] = 'Y'
	FROM dbo.PropertyWorkUpdate p
	where isNULL([OwnerOccupied],'') Like '' and [CalifHomeownerInd] = 1 


	TRUNCATE TABLE Data.[dbo].[Transaction_Deed_OwnerRollup]

	Drop Table #OwnerRollUp

	-- GM ~2 minutes 20170701 fix BK data 
	update dbo.PropertyWorkUpdate set OwnerOccupied = 'Y' where FADateReceived = Convert(varchar(8),GetDate(),112) and OwnerOccupied = 'B'


			UPDATE d
			SET MailingStdCity = [SitusStdCity]
			,MailingStdZIP5 = [SitusStdState]
			,[FAAddressParsedMailing] = NULL
			FROM dbo.PropertyWorkUpdate d
			WHERE SitusStdFullStreetAddress = MailingStdFullStreetAddress
			and (SitusStdCity <> MailingStdCity or SitusStdZIP5 <> MailingStdZip5)
			and SitusStdCarrierCode not like ''
			and MailingStdCarrierCode like ''


			UPdate P
			SET P.[MailingStdFullStreetAddress]= P.[SitusStdFullStreetAddress],
				P.[MailingStdHouseNbr]=P.[SitusStdHouseNbr],
				P.[MailingStdHouseNbrSuffix]=P.[SitusStdHouseNbrSuffix],
				P.[MailingStdDirectionLeft]=P.[SitusStdDirectionLeft],
				P.[MailingStdStreet]=P.[SitusStdStreet],
				P.[MailingStdMode]=P.[SitusStdMode],
				P.[MailingStdDirectionRight]=P.[SitusStdDirectionRight],
				P.[MailingStdUnitNbr]=P.[SitusStdUnitNbr],
				P.[MailingStdCity]=P.[SitusStdCity],
				P.[MailingStdState]=P.[SitusStdState],
				P.[MailingStdZIP5]=P.[SitusStdZIP5],
				P.[MailingStdZIP4]=P.[SitusStdZIP4],
				P.[MailingStdCarrierCode]=P.[SitusStdCarrierCode],
				P.[MailingStdUnitType]=P.[SitusStdUnitType],
				P.[MailingStdMatchCode]=P.[SitusGeoStatusCode],
				P.[MailingFIPS] = P.[Fips],
				P.[FAAddressParsedMailing] = NULL,
				P.[MailForeignAddrInd] = NULL
				From dbo.PropertyWorkUpdate P
				where isNULL(MailingStdFullStreetAddress,'') like ''
						and HomesteadInd = 1


				UPDATE dbo.PropertyWorkUpdate 
				SET OwnerStd1OwnershipRights = CASE WHEN OwnerStdNAME1FULL like '% Family Trust' THEN 'FM'
					WHEN OwnerStdNAME1FULL like '% Family Living Trust' THEN 'FL' 
					WHEN OwnerStdNAME1FULL like '% Family Living Trust' THEN 'FL' 
					WHEN OwnerStdNAME1FULL like '% Family Revocable Trust' THEN 'FR' 
					WHEN OwnerStdNAME1FULL like '% Irrevocable Trust' THEN 'IR' 
					WHEN OwnerStdNAME1FULL like '% Revocable Trust %' THEN 'RT' 
					WHEN OwnerStdNAME1FULL like '% Revocable Living Trust' THEN 'RL' 
					WHEN OwnerStdNAME1FULL like '% Revocable Living' THEN 'RL' 
					WHEN OwnerStdNAME1FULL like '% REVOCABLE LVG %' THEN 'RL' 
					WHEN OwnerStdNAME1FULL like '% Revocable %' THEN 'RT' 
					WHEN OwnerStdNAME1FULL like '% Irrevocable Living Trust' THEN 'IL' 
					WHEN OwnerStdNAME1FULL like '% Living %' THEN 'LT' 
					WHEN OwnerStdNAME1FULL like '% Living' THEN 'LT' 
					WHEN OwnerStdNAME1FULL like '% LVG %' THEN 'LT' 
					WHEN OwnerStdNAME1FULL like '% Trust' THEN 'TS' 
					WHEN OwnerStdNAME1FULL like '% Trust %' THEN 'TS'
					ELSE 'TR'
					END
				,FATimestamp = @FATimeStamp
				where Name1TypeInd like 'TRUST'
					and OwnerStd1OwnershipRights is null

				UPDATE dbo.PropertyWorkUpdate 
				SET OwnerStd2OwnershipRights = CASE WHEN OwnerStdNAME2FULL like '% Family Trust' THEN 'FM'
					WHEN OwnerStdNAME2FULL like '% Family Living Trust' THEN 'FL' 
					WHEN OwnerStdNAME2FULL like '% Family Living Trust' THEN 'FL' 
					WHEN OwnerStdNAME2FULL like '% Family Revocable Trust' THEN 'FR' 
					WHEN OwnerStdNAME2FULL like '% Irrevocable Trust' THEN 'IR' 
					WHEN OwnerStdNAME2FULL like '% Revocable Trust %' THEN 'RT' 
					WHEN OwnerStdNAME2FULL like '% Revocable Living Trust' THEN 'RL' 
					WHEN OwnerStdNAME2FULL like '% Revocable Living' THEN 'RL' 
					WHEN OwnerStdNAME2FULL like '% REVOCABLE LVG %' THEN 'RL' 
					WHEN OwnerStdNAME2FULL like '% Revocable %' THEN 'RT' 
					WHEN OwnerStdNAME2FULL like '% Irrevocable Living Trust' THEN 'IL' 
					WHEN OwnerStdNAME2FULL like '% Living %' THEN 'LT' 
					WHEN OwnerStdNAME2FULL like '% Living' THEN 'LT' 
					WHEN OwnerStdNAME2FULL like '% LVG %' THEN 'LT' 
					WHEN OwnerStdNAME2FULL like '% Trust' THEN 'TS' 
					WHEN OwnerStdNAME2FULL like '% Trust %' THEN 'TS'
					ELSE 'TR'
					END
				,FATimestamp = @FATimeStamp
				where Name2TypeInd like 'TRUST'
					and OwnerStd2OwnershipRights is null

				UPDATE P
					Set P.[FATimestamp] = @FATimeStamp,
					P.[OwnerStdNAME3FULL]=NULL, 
					P.[OwnerStd3CorpInd]=NULL,
					P.[OwnerStd3LastName]=NULL,
					P.[OwnerStd3FirstName]=NULL,
					P.[OwnerStd3MiddleName]=NULL,
					P.[OwnerStd3Suffix]=NULL,
					P.[OwnerStd3CorpName]=NULL,
					P.[Owner3DoNotParse]=NULL,
					P.[OwnerStd3RelationshipType] = NULL,
					P.[OwnerStdNAME4FULL]=NULL, 
					P.[OwnerStd4CorpInd]=NULL,
					P.[OwnerStd4LastName]=NULL,
					P.[OwnerStd4FirstName]=NULL,
					P.[OwnerStd4MiddleName]=NULL,
					P.[OwnerStd4Suffix]=NULL,
					P.[OwnerStd4CorpName]=NULL,
					P.[Owner4DoNotParse]=NULL,
					P.[OwnerStd4RelationshipType] = NULL
				From dbo.PropertyWorkUpdate P
			WHERE isNULL([OwnerStdNAME3FULL],'') NOT LIKE ''
			and [OwnerStdNAME2FULL] = [OwnerStdNAME3FULL]


				UPDATE dbo.PropertyWorkUpdate 
				SET OwnerStd1OwnershipRights = NULL
				WHERE isNULL(OwnerStd1OwnershipRights,'') NOT IN (SELECT [BKFSCode] FROM [Global].[dbo].[lkup_Assessee_Vesting])


END





