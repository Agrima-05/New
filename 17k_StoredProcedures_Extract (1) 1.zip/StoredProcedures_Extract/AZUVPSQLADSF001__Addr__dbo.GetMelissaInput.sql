SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[GetMelissaInput](@tableName varchar(30))
as
declare @sql varchar(max) = ''

set @sql = '
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))
DROP TABLE ' + rtrim(@tableName) + '_STD'
exec (@sql)

	set @sql = '
	create table ' + rtrim(@tableName) + '_STD (' + '
	[ID] [int] NULL,
	[FIPS] [int] NULL,
	StreetNumber [char](25) NULL,
	PreDirection [char](2) NULL,
	StreetName [char](50) NULL,
	Suffix [char](4) NULL,
	PostDirection [char](2) NULL,
	UnitType [char](10) NULL,
	[Unit] [char](15) NULL,
	[City] [char](55) NULL,
	[State] [char](2) NULL,
	[Zip] [char](9) NULL,
	[Plus4] [char](4) NULL,
	[CRRT] [char](4) NULL,
	[CountyName] [char](35) NULL,
	[PMB] [varchar](30) NULL,
	[PMSA] [char](2) NULL,
	[MSA] [char](70) NULL,
	[ZipType] [char](2) NULL,
	[Urbanization] [char](6) NULL,
	[CongressionalDistrict] [char](2) NULL,
	[CountryCode] [char](10) NULL,
	[CityAbbreviation] [char](13) NULL,
	[AddressTypeCode] [char](1) NULL,
	[AddressTypeString] [char](60) NULL,
	[DPV_Count] [char](5) NULL,
	[DPV_Footnotes] [char](4) NULL,
	[CMRA] [char](1) NULL,
	[ELOT_Number] [char](5) NULL,
	[ELOT_Order] [char](2) NULL,
	[LACS] [char](1) NULL,
	[LACS_LinkIndicator] [char](1) NULL,
	[EWS_Flag] [char](1) NULL,
	[RBDI] [char](1) NULL,
	[SuiteLinkReturnCode] [char](1) NULL,
	[DeliveryPointCheckDigit] [char](1) NULL,
	[DeliveryPointCode] [char](2) NULL,
	[CensusBlock] [char](4) NULL,
	[CensusTract] [char](6) NULL,
	[PlaceCode] [char](7) NULL,
	[PlaceName] [char](60) NULL,
	[CBSA_Code] [char](5) NULL,
	[CBSA_Level] [char](30) NULL,
	[CBSA_Title] [char](50) NULL,
	[CBSA_DivisionCode] [char](5) NULL,
	[CBSA_DivisionLevel] [char](30) NULL,
	[CBSA_DivisionTitle] [char](50) NULL,
	[Latitude] [numeric](10, 6) NULL,
	[Longitude] [numeric](10, 6) NULL,
	[Verified] [bit] NULL,
	[Geocoded] [bit] NULL,
	[AddressMatchResults] [char](30) NULL,
	[GeoCodeResults] [char](30) NULL,
	[GeoErrorCode] [char](1) NULL,
	[GeoStatusCode] [char](1) NULL)
	'
  	--print @sql
  	exec (@sql)


--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that.
set @sql = '
SELECT addrid as id
	  --,HouseNumber
	  , HouseNumber = dbo.fnGetHouseNumber(HOUSE_NBR, HOUSE_NBR_#2, HOUSE_NBR_SUFFIX)
	  ,FIPS
	  ,rtrim(rtrim(rtrim(rtrim(rtrim(
		--ISNULL(SUBSTRING(rtrim(isnull(HouseNumber, ''''))
		--				, PATINDEX(''%[^0]%'', ISNULL(HouseNumber, ''''))
		--				, LEN(HouseNumber)), '''') + ' + '''' + ' ' +  '''' + '+
		
		ISNULL(SUBSTRING(rtrim(isnull(dbo.fnGetHouseNumber(HOUSE_NBR, HOUSE_NBR_#2, HOUSE_NBR_SUFFIX), ''''))
						, PATINDEX(''%[^0]%'', ISNULL(dbo.fnGetHouseNumber(HOUSE_NBR, HOUSE_NBR_#2, HOUSE_NBR_SUFFIX), ''''))
						, LEN(dbo.fnGetHouseNumber(HOUSE_NBR, HOUSE_NBR_#2, HOUSE_NBR_SUFFIX))), '''') + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(DIRECTION, ''''))) + ' + '''' + ' ' +  '''' + '+
	  ISNULL(SUBSTRING(rtrim(isnull(STREET_NAME, '''')) 
	  					, PATINDEX(''%[^0]%'', ISNULL(STREET_NAME, ''''))
						, LEN(STREET_NAME)), '''') ) + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(MODE, ''''))) + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(QUADRANT, ''''))) + ' + '''' + ' ' +  '''' + '+
	  CASE WHEN LEN(ISNULL(SUBSTRING(rtrim(isnull(UNIT_NBR, ''''))
						, PATINDEX(''%[^0]%'', ISNULL(UNIT_NBR, ''''))
						, LEN(UNIT_NBR)), '''')) > 0 THEN
				 ''#'' + ISNULL(SUBSTRING(rtrim(isnull(UNIT_NBR, ''''))
							, PATINDEX(''%[^0]%'', ISNULL(UNIT_NBR, ''''))
							, LEN(UNIT_NBR)), '''')
			ELSE '''' END) as addressLine
	  ,isnull(CITY, '''') as city
	  ,isnull(STATE, '''') as state
	  ,isnull(ZIP_CODE, '''') as zip  FROM ' + @tableName + 
	  ' ORDER BY ZIP_CODE ASC'
--SELECT addrid as id
--	  ,HouseNumber
--	  ,FIPS
--	  ,rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(isnull(HouseNumber, '''')) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(DIRECTION, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(STREET_NAME, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(MODE, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(QUADRANT, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(UNIT_NBR, ''''))) as addressLine
--	  ,isnull(CITY, '''') as city
--	  ,isnull(STATE, '''') as state
--	  ,isnull(ZIP_CODE, '''') as zip  FROM ' + @tableName + 
--	  ' ORDER BY ZIP_CODE ASC'
exec (@sql)





