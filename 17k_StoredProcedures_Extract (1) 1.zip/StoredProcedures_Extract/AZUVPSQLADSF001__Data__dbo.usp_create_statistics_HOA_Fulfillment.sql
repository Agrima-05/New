SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[usp_create_statistics_HOA_Fulfillment] 
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
						ORDER BY [FIPSCode]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode 
			
			exec('DROP STATISTICS dbo.HOA_Fulfillment.st_HOA_Fulfillment_FIPS_' + @FipsCode + ';
			
			CREATE statistics st_HOA_Fulfillment_FIPS_' + @FipsCode + '
				on Data.dbo.HOA_Fulfillment(FIPS)
				where [FIPS] = ''' + @FipsCode + '''
				with fullscan;
				')

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 


END

