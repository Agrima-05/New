SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[ParcelPointTaxAcct_Match](@fips as varchar(5))
AS
BEGIN

 update [DigitalMap].[dbo].ParcelPoint_toMatch
  Set [PropertyID] = p.propertyID
  ,[Match] = '9'
  from [DigitalMap].[dbo].ParcelPoint_toMatch d
  join [src_Parcel].[dbo].[zProp_Address] p with (nolock)
  on p.fips = d.FIPS
 -- and OldAPN_unfmt = PARCELAPN_unfmt
  where d.fips = @fips
  and OldAPN_unfmt = PARCELAPN_unfmt
  and d.[PropertyID] is null

  update [DigitalMap].[dbo].ParcelPoint_toMatch
  Set [PropertyID] = p.propertyID
  ,[Match] = '9'
  from [DigitalMap].[dbo].ParcelPoint_toMatch d
  join [src_Parcel].[dbo].[zProp_Address] p with (nolock)
  on p.fips = d.FIPS
 -- and OldAPN_unfmt = PARCELAPN_unfmt
  where d.fips = @fips
  and OldAPN_unfmt = PARCELAPN_unfmt + '0000'
  and d.[PropertyID] is null

  update [DigitalMap].[dbo].ParcelPoint_toMatch
  Set [PropertyID] = p.propertyID
  ,[Match] = '9'
  from [DigitalMap].[dbo].ParcelPoint_toMatch d
  join [src_Parcel].[dbo].[zProp_Address] p with (nolock)
  on p.fips = d.FIPS
 -- and OldAPN_unfmt = PARCELAPN_unfmt
  where d.fips = @fips
  and OldAPN_unfmt = PARCELAPN_unfmt + '000'
  and d.[PropertyID] is null
  
  update [DigitalMap].[dbo].ParcelPoint_toMatch
  Set [PropertyID] = p.propertyID
  ,[Match] = '9'
  from [DigitalMap].[dbo].ParcelPoint_toMatch d
  join [src_Parcel].[dbo].[zProp_Address] p with (nolock)
  on p.fips = d.FIPS
 -- and OldAPN_unfmt = PARCELAPN_unfmt
  where d.fips = @fips
  and OldAPN_unfmt = PARCELAPN_unfmt + '00'
  and d.[PropertyID] is null
  
  update [DigitalMap].[dbo].ParcelPoint_toMatch
  Set [PropertyID] = p.propertyID
  ,[Match] = '9'
  from [DigitalMap].[dbo].ParcelPoint_toMatch d
  join [src_Parcel].[dbo].[zProp_Address] p with (nolock)
  on p.fips = d.FIPS
 -- and OldAPN_unfmt = PARCELAPN_unfmt
  where d.fips = @fips
  and OldAPN_unfmt = PARCELAPN_unfmt + '0'
  and d.[PropertyID] is null

  Insert into [DigitalMap].[dbo].[ParcelPoint_toMatch_Run]
             (fips)
  Select @fips

END



