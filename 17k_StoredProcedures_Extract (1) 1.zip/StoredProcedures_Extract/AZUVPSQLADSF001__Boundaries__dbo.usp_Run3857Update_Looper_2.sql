SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_Run3857Update_Looper_2]
AS
BEGIN
	SET NOCOUNT ON;

Declare @Fipscode2 varchar(5)

			DECLARE curPostgresql2 CURSOR FOR  
				SELECT [FIPSCode] 
				FROM dbo.[Run3857]
				WHERE [Session] = 2 AND COMPLETE = 'N'
				ORDER BY [FIPSCode]


			OPEN curPostgresql2   
			FETCH NEXT FROM curPostgresql2 INTO @Fipscode2

			WHILE @@FETCH_STATUS = 0   
			BEGIN   
			PRINT @Fipscode2
 
				UPDATE [dbo].[PostgreSQL_PROC] SET [Complete] = NULL Where thread = 2


				UPDATE [dbo].[Move_to_postgres_auto]
				SET fips = @Fipscode2
				WHERE thread = 2

				DECLARE @var0 smallint = 1
				Declare @execution_id bigint
				EXEC [SSISDB].[catalog].[create_execution] @package_name='Package2.dtsx', @execution_id=@execution_id OUTPUT, @folder_name='spot_data_move', @project_name='Spot_data_move', @use32bitruntime=False, @reference_id=Null
				EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=50, @parameter_name=N'LOGGING_LEVEL', @parameter_value=@var0
				EXEC [SSISDB].[catalog].[start_execution] @execution_id


				WHILE (Select Complete from dbo.PostgreSQL_PROC Where thread = 2) is NULL
					BEGIN
						WAITFOR DELAY '00:00:30';
					END
				  		
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode2) in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN

					--EXEC('update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot a 
					--where a.FIPS = '''+@Fipscode2+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated a 
					--where a.FIPS = '''+@Fipscode2+'''

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					')
					
					EXEC('UPDATE dbo.FASpot 
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode2+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode2+''' and ParcelGeometry3857 is NULL
					')
					
					END	
					
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode2) NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN
					 	
					--update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_a a 
					--where a.FIPS = '''+@Fipscode2+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated_a a 
					--where a.FIPS = '''+@Fipscode2+'''
					--')

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

				-------------------------
					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL


				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+'''

				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_2] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode2+''' and b.FIPS = '''+@Fipscode2+''' and b.UniqueGuid is NULL

					UPDATE dbo.FASpot_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode2+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode2+''' and ParcelGeometry3857 is NULL
					')

					END

					EXEC('UPDATE dbo.[Run3857]
							SET Complete = ''Y''
							WHERE FIPSCode = '''+@Fipscode2+'''
							')

					FETCH NEXT FROM curPostgresql2 INTO @Fipscode2 
			END   

				CLOSE curPostgresql2   
				DEALLOCATE curPostgresql2 		


END
