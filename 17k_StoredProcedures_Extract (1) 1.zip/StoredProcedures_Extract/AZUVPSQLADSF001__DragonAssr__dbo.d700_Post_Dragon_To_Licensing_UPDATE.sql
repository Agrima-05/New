SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- ===============================================================
-- Description:	Roll up Last and Prior Sale data to Property Table
-- ===============================================================
CREATE PROCEDURE [dbo].[d700_Post_Dragon_To_Licensing_UPDATE] --@FIPS varchar(5)
AS
BEGIN

		Declare @DATE varchar(8) = convert(varchar(8),GetDate()+1,112)
		Declare @DateTime varchar(10) = convert(varchar(10),GetDate()+1,120)

	IF(Select Count(*) FROM DragonAssr.dbo.PropertyWorkUpdate WITH(NOLOCK) WHERE isNULL(PropertyID,0)= 0) > 0
		BEGIN
			EXEC('
				DECLARE @PropertyId_max1 bigint;
				DECLARE @u_PropertyID bigint;
				DECLARE @u_FIPS varchar (5);
				DECLARE @u_APN varchar (45);
				DECLARE @u_PID varchar (10);
				DECLARE @u_APNSeqNbr varchar (2);
				DECLARE @u_OldAPN varchar (31);
				DECLARE @u_FormattedAPN varchar (45);

					DECLARE c_Property_PropertyID CURSOR FOR 
						SELECT [PropertyID],[FIPS],[FormattedAPN],CASE WHEN [APNSeqNbr] = ''1'' THEN NULL ELSE [APNSeqNbr] END,OldAPN,[FormattedAPN],[VendorPID]
						FROM DragonAssr.dbo.PropertyWorkUpdate WITH(NOLOCK)
						WHERE [PropertyID] is null;

					SET @PropertyId_max1 = (SELECT max(FAPropertyId) FROM [Global].[dbo].[Property_Master] WITH(NOLOCK)) + 1;

					OPEN c_Property_PropertyID

					FETCH NEXT FROM c_Property_PropertyID INTO @u_PropertyID, @u_FIPS, @u_APN, @u_APNSeqNbr, @u_OldAPN, @u_FormattedAPN,@u_PID;
					WHILE @@FETCH_STATUS = 0
					BEGIN
						INSERT INTO [Global].[dbo].[property_master] (
							[FAPropertyId]
						   ,[FIPS]
						   ,[APN]
						   ,[DuplicateAPN]
						   ,[OldAPN]
						   ,[FormattedAPN]
						   ,[PID]
						   ,[APN_change_date])
						VALUES (
							@PropertyId_max1
						   ,@u_FIPS
						   ,@u_APN
						   ,@u_APNSeqNbr
						   ,@u_OldAPN
						   ,@u_FormattedAPN
						   ,@u_PID
						   ,GETDATE())

					SET @PropertyId_max1 = @PropertyId_max1 + 1;

					FETCH NEXT FROM c_Property_PropertyID INTO @u_PropertyID, @u_FIPS, @u_APN, @u_APNSeqNbr, @u_OldAPN, @u_FormattedAPN, @u_PID;
					END;

					CLOSE c_Property_PropertyID;
					DEALLOCATE c_Property_PropertyID
				')
		END

			UPDATE a
			SET PropertyID = b.FAPropertyId
			FROM DragonAssr.dbo.PropertyWorkUpdate a JOIN Global.dbo.property_master b
			on a.FIPS = b.FIPS
			and a.FormattedAPN = b.APN
			WHERE PropertyID is NULL
		
		EXEC [dbo].[002_remove_Extra_Ascii_from_table_II] PropertyWorkUpdate

			update propertyworkUpdate
			SET [FireplaceCode] = NULL
			Where [FireplaceCode] like 'N'
			
			update DragonAssr.dbo.propertyworkUpdate
			SET [RoofTypeCode] = NULL
			Where [RoofTypeCode] in('NUL','A','SLT','G')

											
		UPDATE DragonAssr.dbo.PropertyWorkUpdate
			SET UNVLandValue = cast(convert(Money,UNVLandValue) as INT)
			,UNVImprovementValue = cast(convert(Money,UNVImprovementValue) as INT)
			,UNVTotalValue = cast(convert(Money,UNVTotalValue) as INT)
			
		UPDATE a
		SET StdLandUseCode = c.FlankCode
		,PropertyClassID = c.PropClassID
		from dbo.PropertyWorkUpdate a JOIN [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR b with(NOLOCK)
		ON DTDB_Ref_ID = REF_ID
		JOIN dbo.LandUseLookup c on b.Land_use = c.Value
		where b.Fips = a.FIPS and (StdLandUseCode is NULL or StdLandUseCode != FlankCode or PropertyClassID != PropClassID)

		update dbo.PropertyWorkUpdate 
		SET DTDB_FORMATTED_APN = NULL
		,DTDB_UNFORMATTED_APN = NULL
		WHERE DTDB_FORMATTED_APN like '%|%'
		
		UPDATE dbo.PropertyWorkUpdate
		SET CS_FORMATTED_APN = DTDB_FORMATTED_APN
		,CS_UNFORMATTED_APN = DTDB_UNFORMATTED_APN
		WHERE isNULL(DTDB_FORMATTED_APN,'') not like ''
		and isNULL(CS_FORMATTED_APN,'') like ''

		update [DragonAssr].[dbo].[PropertyWorkUpdate] 
		  set [LotSizeFrontageFeet] = NULL
		  Where [LotSizeFrontageFeet] > 50000
		  or LotSizeDepthFeet is NULL
	  
	  	 UPDATE [DragonAssr].[dbo].[PropertyWorkUpdate]
			SET [TaxDeliquentValue1] = CASE WHEN convert(bigint,[TaxDeliquentValue1]) > 200000000 THEN NULL ELSE [TaxDeliquentValue1] END


			DELETE
			FROM [DragonAssr].[dbo].[PropertyWorkUpdate]
			WHERE PropertyID in(SELECT PropertyID
				  FROM [DragonAssr].[dbo].[PropertyWorkUpdate] with(NOLOCK)
				  group by propertyid
				  having Count(*) > 1)

			--Select * From dbo.PropertyWorkUpdate order by Propertyid
---------------------------------------------------------
		--Declare @DATE varchar(8) = convert(varchar(8),GetDate(),112)
		--Declare @DateTime varchar(10) = convert(varchar(10),GetDate(),120)


		INSERT INTO [Data_Archive].[dbo].[Property_del] (
		   [FIPS]
		  ,[PropertyID]
		  ,[FormattedAPN]
		  ,[APNSeqNbr]
		  ,[UnformattedAPN]
		  ,[OldAPN]
		  ,[OLDAPNSeqNbr]
		  ,[TaxAccountNumber]
		  ,[RecordType]
		  ,[VendorPID]
		  ,[SitusStdFullStreetAddress]
		  ,[SitusStdHouseNbr]
		  ,[SitusStdHouseNbr2]
		  ,[SitusStdHouseNbrSuffix]
		  ,[SitusStdDirectionLeft]
		  ,[SitusStdStreet]
		  ,[SitusStdMode]
		  ,[SitusStdDirectionRight]
		  ,[SitusStdUnitNbr]
		  ,[SitusStdCity]
		  ,[SitusStdState]
		  ,[SitusStdZIP5]
		  ,[SitusStdZIP4]
		  ,[SitusLatitude]
		  ,[SitusLongitude]
		  ,[SitusStdCarrierCode]
		  ,[SitusCensusTract]
		  ,[SitusCensusTractBlock]
		  ,[SitusStdUnitType]
		  ,[SitusStdMatchCode]
		  ,[LotSizeSqFt]
		  ,[LotSizeAcres]
		  ,[LotSizeFrontageFeet]
		  ,[LotSizeDepthFeet]
		  ,[LotIrregularInd]
		  ,[LotUsableSize]
		  ,[PropertyClassID]
		  ,[StdLandUseCode]
		  ,[StateLandUseCode]
		  ,[CountyLandUseCode]
		  ,[CountyLandUseDescription]
		  ,[TimeshareCode]
		  ,[Zoning]
		  ,[SiteInfluenceCode]
		  ,[NeighborhoodCode]
		  ,[TopographyCode]
		  ,[MobileHomeInd]
		  ,[LotCode]
		  ,[LotNumber]
		  ,[LandLot]
		  ,[Block]
		  ,[Section]
		  ,[District]
		  ,[LegalUnit]
		  ,[Municipality]
		  ,[LegalSection]
		  ,[LegalTownship]
		  ,[LegalRange]
		  ,[Meridian]
		  ,[LegalQuarter]
		  ,[LegalQuarterQuarter]
		  ,[LegalDescription]
		  ,[AssessorsMapRef1]
		  ,[AssessorsMapRef2]
		  ,[SubdivisionName]
		  ,[SubdivisionPhaseNbr]
		  ,[SubdivisionTractNbr]
		  ,[SubdivisionPlatBook]
		  ,[SubdivisionPlatPage]
		  ,[NewRecordType]
		  ,[SwiSCodeNY]
		  ,[MailingCareOfName]
		  ,[MailingStdFullStreetAddress]
		  ,[MailingStdHouseNbr]
		  ,[MailingStdHouseNbr2]
		  ,[MailingStdHouseNbrSuffix]
		  ,[MailingStdDirectionLeft]
		  ,[MailingStdStreet]
		  ,[MailingStdMode]
		  ,[MailingStdDirectionRight]
		  ,[MailingStdUnitNbr]
		  ,[MailingStdCity]
		  ,[MailingStdState]
		  ,[MailingStdZIP5]
		  ,[MailingStdZIP4]
		  ,[MailingStdCarrierCode]
		  ,[MailingStdUnitType]
		  ,[MailingStdMatchCode]
		  ,[MailingOptOut]
		  ,[MailingOptOutDate]
		  ,[OwnerOccupied]
		  ,[AbsenteeOwner]
		  ,[OwnerStdNAME1FULL]
		  ,[OwnerStdNAME2FULL]
		  ,[OwnerStdNAME3FULL]
		  ,[OwnerStdNAME4FULL]
		  ,[OwnerEtALIndicator]
		  ,[OwnerStd1CorpInd]
		  ,[OwnerStd1LastName]
		  ,[OwnerStd1FirstName]
		  ,[OwnerStd1MiddleName]
		  ,[OwnerStd1Suffix]
		  ,[OwnerStd1CorpName]
		  ,[OwnerStd1OwnershipRights]
		  ,[OwnerStd1RelationshipType]
		  ,[Owner1DoNotParse]
		  ,[OwnerStd2CorpInd]
		  ,[OwnerStd2LastName]
		  ,[OwnerStd2FirstName]
		  ,[OwnerStd2MiddleName]
		  ,[OwnerStd2Suffix]
		  ,[OwnerStd2CorpName]
		  ,[OwnerStd2OwnershipRights]
		  ,[OwnerStd2RelationshipType]
		  ,[Owner2DoNotParse]
		  ,[OwnerStd3CorpInd]
		  ,[OwnerStd3LastName]
		  ,[OwnerStd3FirstName]
		  ,[OwnerStd3MiddleName]
		  ,[OwnerStd3Suffix]
		  ,[OwnerStd3CorpName]
		  ,[OwnerStd3OwnershipRights]
		  ,[OwnerStd3RelationshipType]
		  ,[Owner3DoNotParse]
		  ,[OwnerStd4CorpInd]
		  ,[OwnerStd4LastName]
		  ,[OwnerStd4FirstName]
		  ,[OwnerStd4MiddleName]
		  ,[OwnerStd4Suffix]
		  ,[OwnerStd4CorpName]
		  ,[OwnerStd4OwnershipRights]
		  ,[OwnerStd4RelationshipType]
		  ,[Owner4DoNotParse]
		  ,[AssesseeStd1Name]
		  ,[AssesseeStd2Name]
		  ,[AssesseeNameIndicator]
		  ,[AssesseeNameIndicator2]
		  ,[Amenities]
		  ,[DrivewayCode]
		  ,[EasementInd]
		  ,[QualityCode]
		  ,[ViewInd]
		  ,[ViewCode]
		  ,[ViewQualityCode]
		  ,[WaterAccessableInd]
		  ,[WaterFeatureInd]
		  ,[WaterfrontCode]
		  ,[WaterfrontFeet]
		  ,[WaterfrontQualityCode]
		  ,[BuildingArea]
		  ,[BuildingAreaInd]
		  ,[TotalRooms]
		  ,[Bedrooms]
		  ,[BathTotalCalc]
		  ,[BathFull]
		  ,[BathsParcialNbr]
		  ,[BathHalf]
		  ,[Bath1QTR]
		  ,[Bath3QTR]
		  ,[BathFixturesNbr]
		  ,[OtherRooms]
		  ,[AirConditioningCode]
		  ,[AirConditioningTypeCode]
		  ,[BasementCode]
		  ,[BasementFinishedCode]
		  ,[BuildingClassCode]
		  ,[BuildingConditionCode]
		  ,[BuildingQualityCode]
		  ,[ConstructionTypeCode]
		  ,[DeckCode]
		  ,[ElectricityCode]
		  ,[ExteriorWallsCode]
		  ,[FireplaceCode]
		  ,[FloorCoverCode]
		  ,[FloorTypeCode]
		  ,[FoundationInd]
		  ,[FrameCode]
		  ,[Garage]
		  ,[GarageParkingNbr]
		  ,[HeatCode]
		  ,[HeatingFuelTypeCode]
		  ,[InteriorWallsCode]
		  ,[PavingCode]
		  ,[PatioCode]
		  ,[PoolCode]
		  ,[PorchCode]
		  ,[RoofCoverCode]
		  ,[RoofTypeCode]
		  ,[SewerCode]
		  ,[ShapeCode]
		  ,[StoriesCode_OLD]
		  ,[StoriesNbrCode_OLD]
		  ,[StyleCode]
		  ,[WallExteriorCode]
		  ,[WallheightCode]
		  ,[WaterCode]
		  ,[YearBuilt]
		  ,[EffectiveYearBuilt]
		  ,[SumBuildingsNbr]
		  ,[SumAboveGradeLivingSqFt]
		  ,[SumAdjAreaSqFt]
		  ,[SumBasementSqFt]
		  ,[SumBuildingSqFt]
		  ,[SumGarageSqFt]
		  ,[SumGrossAreaSqFt]
		  ,[SumGroundFloorSqFt]
		  ,[SumLivingAreaSqFt]
		  ,[SumResidentialUnits]
		  ,[SumCommercialUnits]
		  ,[AssdLandValue]
		  ,[AssdImprovementValue]
		  ,[AssdTotalValue]
		  ,[AssdYear]
		  ,[MarketValueLand]
		  ,[MarketValueImprovement]
		  ,[MarketTotalValue]
		  ,[MarketValueYear]
		  ,[ApprLandValue]
		  ,[ApprImprovementValue]
		  ,[ApprTotalValue]
		  ,[ApprYear]
		  ,[TaxValueLand]
		  ,[TaxValueImprovement]
		  ,[TaxTotalValue]
		  ,[TaxableYear]
		  ,[UNVLandValue]
		  ,[UNVImprovementValue]
		  ,[UNVTotalValue]
		  ,[UNVValueYear]
		  ,[TaxRateCodeArea]
		  ,[TaxYear]
		  ,[TaxAmount]
		  ,[TaxDeliquentYear1]
		  ,[TaxDeliquentValue1]
		  ,[TaxExemptionCode]
		  ,[TaxexemptInd]
		  ,[CalifHomeownerInd]
		  ,[CemeteryInd]
		  ,[DisabledInd]
		  ,[HomesteadInd]
		  ,[HospitalInd]
		  ,[LibraryInd]
		  ,[PublicUtilityInd]
		  ,[ReligiousInd]
		  ,[SchoolCollegeInd]
		  ,[SeniorInd]
		  ,[VeteranInd]
		  ,[WelfareInd]
		  ,[WidowInd]
		  ,[SchoolTaxDistrict1Code]
		  ,[SchoolTaxDistrict1Ind]
		  ,[SchoolTaxDistrict2Code]
		  ,[SchoolTaxDistrict2Ind]
		  ,[SchoolTaxDistrict3Code]
		  ,[SchoolTaxDistrict3Ind]
		  ,[FADeleteFlag]
		  ,[FADeleteFlagDate]
		  ,[CurrentSaleTransactionId]
		  ,[CurrentSaleChronoKey]
		  ,[CurrSaleInputDocNbr]
		  ,[CurrSaleInputBook]
		  ,[CurrSaleInputPage]
		  ,[CurrSaleFormatDocNbr]
		  ,[CurrSaleFormatBook]
		  ,[CurrSaleFormatPage]
		  ,[CurrSaleRecordingDate]
		  ,[CurrSaleDocumentType]
		  ,[CurrSalesPrice]
		  ,[CurrSalesPriceCode]
		  ,[CurrSaleContractDate]
		  ,[CurrSaleBuyer1FullName]
		  ,[CurrSaleBuyer2FullName]
		  ,[CurrSaleBuyer3FullName]
		  ,[CurrSaleBuyer4FullName]
		  ,[CurrSaleSeller1FullName]
		  ,[CurrSaleSeller2FullName]
		  ,[ConCurrMtg1InputDocNbr]
		  ,[ConCurrMtg1InputBook]
		  ,[ConCurrMtg1InputPage]
		  ,[ConCurrMtg1FormatDocNbr]
		  ,[ConCurrMtg1FormatBook]
		  ,[ConCurrMtg1FormatPage]
		  ,[ConCurrMtg1RecordingDt]
		  ,[ConCurrMtg1LoanAmt]
		  ,[ConCurrMtg1Lender]
		  ,[ConCurrMtg1LenderCode]
		  ,[ConCurrMtg1LenderType]
		  ,[ConCurrMtg1PrivateLender]
		  ,[ConCurrMtg1Term]
		  ,[ConCurrMtg1LoanDueDt]
		  ,[ConCurrMtg1AdjOrFix]
		  ,[ConCurrMtg1LoanType]
		  ,[ConCurrMtg1Typefinancing]
		  ,[ConCurrMtg1LienPosition]
		  ,[ConCurrMtg2InputDocNbr]
		  ,[ConCurrMtg2InputBook]
		  ,[ConCurrMtg2InputPage]
		  ,[ConCurrMtg2FormatDocNbr]
		  ,[ConCurrMtg2FormatBook]
		  ,[ConCurrMtg2FormatPage]
		  ,[ConCurrMtg2RecordingDt]
		  ,[ConCurrMtg2LoanAmt]
		  ,[ConCurrMtg2Lender]
		  ,[ConCurrMtg2LenderCode]
		  ,[ConCurrMtg2LenderType]
		  ,[ConCurrMtg2PrivateLender]
		  ,[ConCurrMtg2LoanDueDt]
		  ,[ConCurrMtg2AdjOrFix]
		  ,[ConCurrMtg2LoanType]
		  ,[ConCurrMtg2Typefinancing]
		  ,[ConCurrMtg2LienPosition]
		  ,[Mtg1TransactionId]
		  ,[Mtg1ChronoKey]
		  ,[Mtg1LoanAmt]
		  ,[Mtg1Lender]
		  ,[Mtg1LenderCode]
		  ,[Mtg1LenderType]
		  ,[Mtg1PrivateLender]
		  ,[Mtg1LoanDueDt]
		  ,[Mtg1AdjRider]
		  ,[Mtg1LoanType]
		  ,[Mtg1Typefinancing]
		  ,[Mtg1LienPosition]
		  ,[Mtg2TransactionId]
		  ,[Mtg2ChronoKey]
		  ,[Mtg2InputDocNbr]
		  ,[Mtg2InputBook]
		  ,[Mtg2InputPage]
		  ,[Mtg2FormatDocNbr]
		  ,[Mtg2FormatBook]
		  ,[Mtg2FormatPage]
		  ,[Mtg2RecordingDt]
		  ,[Mtg2LoanAmt]
		  ,[Mtg2Lender]
		  ,[Mtg2LenderCode]
		  ,[Mtg2LenderType]
		  ,[Mtg2PrivateLender]
		  ,[Mtg2LoanDueDt]
		  ,[Mtg2AdjRider]
		  ,[Mtg2LoanType]
		  ,[Mtg2Typefinancing]
		  ,[Mtg2LienPosition]
		  ,[Mtg3TransactionId]
		  ,[Mtg3ChronoKey]
		  ,[Mtg3InputDocNbr]
		  ,[Mtg3InputBook]
		  ,[Mtg3InputPage]
		  ,[Mtg3FormatDocNbr]
		  ,[Mtg3FormatBook]
		  ,[Mtg3FormatPage]
		  ,[Mtg3RecordingDt]
		  ,[Mtg3LoanAmt]
		  ,[Mtg3Lender]
		  ,[Mtg3LenderCode]
		  ,[Mtg3LenderType]
		  ,[Mtg3PrivateLender]
		  ,[Mtg3LoanDueDt]
		  ,[Mtg3AdjRider]
		  ,[Mtg3LoanType]
		  ,[Mtg3Typefinancing]
		  ,[Mtg3LienPosition]
		  ,[Mtg4TransactionId]
		  ,[Mtg4ChronoKey]
		  ,[Mtg4InputDocNbr]
		  ,[Mtg4InputBook]
		  ,[Mtg4InputPage]
		  ,[Mtg4FormatDocNbr]
		  ,[Mtg4FormatBook]
		  ,[Mtg4FormatPage]
		  ,[Mtg4RecordingDt]
		  ,[Mtg4LoanAmt]
		  ,[Mtg4Lender]
		  ,[Mtg4LenderCode]
		  ,[Mtg4LenderType]
		  ,[Mtg4PrivateLender]
		  ,[Mtg4LoanDueDt]
		  ,[Mtg4AdjRider]
		  ,[Mtg4LoanType]
		  ,[Mtg4Typefinancing]
		  ,[Mtg4LienPosition]
		  ,[PrevSaleTransactionId]
		  ,[PrevSaleChronoKey]
		  ,[PrevSaleInputDocNbr]
		  ,[PrevSaleInputBook]
		  ,[PrevSaleInputPage]
		  ,[PrevSaleFormatDocNbr]
		  ,[PrevSaleFormatBook]
		  ,[PrevSaleFormatPage]
		  ,[PrevSaleRecordingDate]
		  ,[PrevSalesPrice]
		  ,[PrevSalesPriceCode]
		  ,[PrevSaleContractDate]
		  ,[PrevSaleBuyer1FullName]
		  ,[PrevSaleBuyer2FullName]
		  ,[PrevSaleBuyer3FullName]
		  ,[PrevSaleBuyer4FullName]
		  ,[PrevSaleSeller1FullName]
		  ,[PrevSaleSeller2FullName]
		  ,[PrevMtg1InputDocNbr]
		  ,[PrevMtg1InputBook]
		  ,[PrevMtg1InputPage]
		  ,[PrevMtg1FormatDocNbr]
		  ,[PrevMtg1FormatBook]
		  ,[PrevMtg1FormatPage]
		  ,[PrevMtg1RecordingDt]
		  ,[PrevMtg1LoanAmt]
		  ,[PrevMtg1Lender]
		  ,[PrevMtg1LenderCode]
		  ,[PrevMtg1LenderType]
		  ,[PrevMtg1PrivateLender]
		  ,[PrevMtg1LoanDueDt]
		  ,[PrevMtg1AdjRider]
		  ,[PrevMtg1LoanType]
		  ,[PrevMtg1Typefinancing]
		  ,[EditionNumber]
		  ,[VersionId]
		  ,[VendorLoadDate]
		  ,[FASourceInd]
		  ,[FATimestamp]
		  ,[FAUserId]
		  ,[FACreateDt]
		  ,[FADeriveProcessDt]
		  ,[FAEnhanceprocessDt]
		  ,[FAOwnershipUpdateDt]
		  ,[FAActiveDt]
		  ,[SitusDPVCount]
		  ,[SitusDPVFootnote]
		  ,[SitusLACS]
		  ,[SitusLACSLinkInd]
		  ,[SitusDPCheckDigit]
		  ,[SitusDPCheckCode]
		  ,[SitusCensusBlock]
		  ,[SitusGeoErrorCode]
		  ,[SitusGeoStatusCode]
		  ,[MailingDPVCount]
		  ,[MailingDPVFootnote]
		  ,[MailingLACS]
		  ,[MailingLACSLinkInd]
		  ,[MailingDPCheckDigit]
		  ,[MailingDPCheckCode]
		  ,[MailingCensusBlock]
		  ,[MailingCensusTract]
		  ,[MailingGeoErrorCode]
		  ,[MailingGeoStatusCode]
		  ,[CheckOwnership]
		  ,[Mtg1InputDocNbr]
		  ,[Mtg1InputBook]
		  ,[Mtg1FormatDocNbr]
		  ,[Mtg1FormatBook]
		  ,[Mtg1FormatPage]
		  ,[Mtg1RecordingDt]
		  ,[Mtg1InputPage]
		  ,[FAUCIDFlag]
		  ,[FADateReceived]
		  ,[FAIsListedFlag]
		  ,[FAIsListedFlagDt]
		  ,[FAIsListedPriceRange]
		  ,[FAAddressParsedSitus]
		  ,[FAAddressParsedMailing]
		  ,[TPLatitude]
		  ,[TPLongitude]
		  ,[TPGeoStatusCode]
		  ,[FALatitude]
		  ,[FALongitude]
		  ,[FAGeoStatusCode]
		  ,[SitusGeoCodeResults]
		  ,[MailingGeoCodeResults]
		  ,[MailForeignAddrInd]
		  ,[FACLTV]
		  ,[FAEstLotSqFt]
		  ,[FAOLTV]
		  ,[FAOwnerTransactionId]
		  ,[LienPosUpdateFlag]
		  ,[LienPosUpdateDate]
		  ,[TotalOpenLienAmt]
		  ,[TotalOpenLienNbr]
		  ,[VacantFlag]
		  ,[VacantFlagDate]
		  ,[AssessorLkupToken0]
		  ,[AssessorLkupToken1]
		  ,[SchoolDistrictName]
		  ,[AssessorLkupToken2]
		  ,[FADataArchiveDate]
		  ,[ConCurrMtg2Term]
		  ,[Mtg1Term]
		  ,[Mtg2Term]
		  ,[Mtg3Term]
		  ,[Mtg4Term]
		  ,[PrevMtg1Term]
		  ,[BankOwned]
		  ,[StoriesCode]
		  ,[StoriesNbrCode]
		  ,[BasementFinishSqFt]
		  ,[BasementUnfinSqFt]
		  ,[GarageFinishSqFt]
		  ,[GarageUnFinSqFt]
		  ,[AtticSqFt]
		  ,[AtticFinishSqFt]
		  ,[AtticUnfinSqFt]
		  ,[Mtg4InterestRate]
		  ,[Mtg4EstPaymentAmt]
		  ,[Mtg3InterestRate]
		  ,[Mtg3EstPaymentAmt]
		  ,[Mtg2InterestRate]
		  ,[Mtg2EstPaymentAmt]
		  ,[Mtg1InterestRate]
		  ,[Mtg1EstPaymentAmt]
		  ,[ConCurrMtg1InterestRate]
		  ,[ConCurrMtg2InterestRate]
		  ,[PrevMtg1InterestRate]
		  ,[MailingFIPS]
		  ,[DBSTaxAmount]
		  ,[DBSTaxYear]
		  ,[Mtg1EstLoanBalance]
		  ,[Mtg2EstLoanBalance]
		  ,[Mtg3EstLoanBalance]
		  ,[Mtg4EstLoanBalance]
		  ,[OldApnIndicator]
		  ,[PrevSaleDocumentType]
		  ,[SecondPrevSaleTransactionId]
		  ,[SecondPrevSaleRecordingDate]
		  ,[SecondPrevSalesPrice]
		  ,[ThirdPrevSaleTransactionId]
		  ,[ThirdPrevSaleRecordingDate]
		  ,[ThirdPrevSalesPrice]
		  ,[HouseFacingDirection]
		  ,[FARooftopLatitude]
		  ,[FARooftopLongitude]
		  ,[BuildingEstFootprintSqFt]
		  ,[BathTotalCalcEst]
		  ,[DQOZ_TractType]
		  ,[DQOZ_ACSDataSource]
		  ,[VacantScore]
		  ,[BedroomsEst]
		  ,[DTDB_REF_ID]
		  ,[DTDB_FORMATTED_APN]
		  ,[MailingLabelName]
		  ,[Name1TypeInd]
		  ,[Name2TypeInd]
		  ,[TaxSourceInd]
		  ,[FASubdivisionName]
		  ,[FAComplexNbrUnits]
		  ,[FASubdivisionNameID]
		  ,[FASubdivisionPhase]
		  ,[ElevatorCode]
		  ,[FAEstimatedMultiPolygonFlag]
		  ,[FAEstimatedNumberofBuildings]
		  ,[Poverty]
		  ,[UnEmployment]
		  ,[PopulationLoss]
		  ,[RemoteRural]
		  ,[Distressed]
		  ,[UnderServed]
		  ,[DTDB_UNFORMATTED_APN]
		  ,[ConformingLoanLimitYear]
		  ,[ConformingLoanLimit]
		  ,[PriorConformingLoanLimitYear]
		  ,[PriorConformingLoanLimit]
		  ,[MTG3InterestRateSrce]
		  ,[MTG1InterestRateSrce]
		  ,[MTG2InterestRateSrce]
		  ,[MTG4InterestRateSrce]
		  ,[CS_FORMATTED_APN]
		  ,[CS_UNFORMATTED_APN])
		SELECT
		   [FIPS]
		  ,[PropertyID]
		  ,[FormattedAPN]
		  ,[APNSeqNbr]
		  ,[UnformattedAPN]
		  ,[OldAPN]
		  ,[OLDAPNSeqNbr]
		  ,[TaxAccountNumber]
		  ,[RecordType]
		  ,[VendorPID]
		  ,[SitusStdFullStreetAddress]
		  ,[SitusStdHouseNbr]
		  ,[SitusStdHouseNbr2]
		  ,[SitusStdHouseNbrSuffix]
		  ,[SitusStdDirectionLeft]
		  ,[SitusStdStreet]
		  ,[SitusStdMode]
		  ,[SitusStdDirectionRight]
		  ,[SitusStdUnitNbr]
		  ,[SitusStdCity]
		  ,[SitusStdState]
		  ,[SitusStdZIP5]
		  ,[SitusStdZIP4]
		  ,[SitusLatitude]
		  ,[SitusLongitude]
		  ,[SitusStdCarrierCode]
		  ,[SitusCensusTract]
		  ,[SitusCensusTractBlock]
		  ,[SitusStdUnitType]
		  ,[SitusStdMatchCode]
		  ,[LotSizeSqFt]
		  ,[LotSizeAcres]
		  ,[LotSizeFrontageFeet]
		  ,[LotSizeDepthFeet]
		  ,[LotIrregularInd]
		  ,[LotUsableSize]
		  ,[PropertyClassID]
		  ,[StdLandUseCode]
		  ,[StateLandUseCode]
		  ,[CountyLandUseCode]
		  ,[CountyLandUseDescription]
		  ,[TimeshareCode]
		  ,[Zoning]
		  ,[SiteInfluenceCode]
		  ,[NeighborhoodCode]
		  ,[TopographyCode]
		  ,[MobileHomeInd]
		  ,[LotCode]
		  ,[LotNumber]
		  ,[LandLot]
		  ,[Block]
		  ,[Section]
		  ,[District]
		  ,[LegalUnit]
		  ,[Municipality]
		  ,[LegalSection]
		  ,[LegalTownship]
		  ,[LegalRange]
		  ,[Meridian]
		  ,[LegalQuarter]
		  ,[LegalQuarterQuarter]
		  ,[LegalDescription]
		  ,[AssessorsMapRef1]
		  ,[AssessorsMapRef2]
		  ,[SubdivisionName]
		  ,[SubdivisionPhaseNbr]
		  ,[SubdivisionTractNbr]
		  ,[SubdivisionPlatBook]
		  ,[SubdivisionPlatPage]
		  ,[NewRecordType]
		  ,[SwiSCodeNY]
		  ,[MailingCareOfName]
		  ,[MailingStdFullStreetAddress]
		  ,[MailingStdHouseNbr]
		  ,[MailingStdHouseNbr2]
		  ,[MailingStdHouseNbrSuffix]
		  ,[MailingStdDirectionLeft]
		  ,[MailingStdStreet]
		  ,[MailingStdMode]
		  ,[MailingStdDirectionRight]
		  ,[MailingStdUnitNbr]
		  ,[MailingStdCity]
		  ,[MailingStdState]
		  ,[MailingStdZIP5]
		  ,[MailingStdZIP4]
		  ,[MailingStdCarrierCode]
		  ,[MailingStdUnitType]
		  ,[MailingStdMatchCode]
		  ,[MailingOptOut]
		  ,[MailingOptOutDate]
		  ,[OwnerOccupied]
		  ,[AbsenteeOwner]
		  ,[OwnerStdNAME1FULL]
		  ,[OwnerStdNAME2FULL]
		  ,[OwnerStdNAME3FULL]
		  ,[OwnerStdNAME4FULL]
		  ,[OwnerEtALIndicator]
		  ,[OwnerStd1CorpInd]
		  ,[OwnerStd1LastName]
		  ,[OwnerStd1FirstName]
		  ,[OwnerStd1MiddleName]
		  ,[OwnerStd1Suffix]
		  ,[OwnerStd1CorpName]
		  ,[OwnerStd1OwnershipRights]
		  ,[OwnerStd1RelationshipType]
		  ,[Owner1DoNotParse]
		  ,[OwnerStd2CorpInd]
		  ,[OwnerStd2LastName]
		  ,[OwnerStd2FirstName]
		  ,[OwnerStd2MiddleName]
		  ,[OwnerStd2Suffix]
		  ,[OwnerStd2CorpName]
		  ,[OwnerStd2OwnershipRights]
		  ,[OwnerStd2RelationshipType]
		  ,[Owner2DoNotParse]
		  ,[OwnerStd3CorpInd]
		  ,[OwnerStd3LastName]
		  ,[OwnerStd3FirstName]
		  ,[OwnerStd3MiddleName]
		  ,[OwnerStd3Suffix]
		  ,[OwnerStd3CorpName]
		  ,[OwnerStd3OwnershipRights]
		  ,[OwnerStd3RelationshipType]
		  ,[Owner3DoNotParse]
		  ,[OwnerStd4CorpInd]
		  ,[OwnerStd4LastName]
		  ,[OwnerStd4FirstName]
		  ,[OwnerStd4MiddleName]
		  ,[OwnerStd4Suffix]
		  ,[OwnerStd4CorpName]
		  ,[OwnerStd4OwnershipRights]
		  ,[OwnerStd4RelationshipType]
		  ,[Owner4DoNotParse]
		  ,[AssesseeStd1Name]
		  ,[AssesseeStd2Name]
		  ,[AssesseeNameIndicator]
		  ,[AssesseeNameIndicator2]
		  ,[Amenities]
		  ,[DrivewayCode]
		  ,[EasementInd]
		  ,[QualityCode]
		  ,[ViewInd]
		  ,[ViewCode]
		  ,[ViewQualityCode]
		  ,[WaterAccessableInd]
		  ,[WaterFeatureInd]
		  ,[WaterfrontCode]
		  ,[WaterfrontFeet]
		  ,[WaterfrontQualityCode]
		  ,[BuildingArea]
		  ,[BuildingAreaInd]
		  ,[TotalRooms]
		  ,[Bedrooms]
		  ,[BathTotalCalc]
		  ,[BathFull]
		  ,[BathsParcialNbr]
		  ,[BathHalf]
		  ,[Bath1QTR]
		  ,[Bath3QTR]
		  ,[BathFixturesNbr]
		  ,[OtherRooms]
		  ,[AirConditioningCode]
		  ,[AirConditioningTypeCode]
		  ,[BasementCode]
		  ,[BasementFinishedCode]
		  ,[BuildingClassCode]
		  ,[BuildingConditionCode]
		  ,[BuildingQualityCode]
		  ,[ConstructionTypeCode]
		  ,[DeckCode]
		  ,[ElectricityCode]
		  ,[ExteriorWallsCode]
		  ,[FireplaceCode]
		  ,[FloorCoverCode]
		  ,[FloorTypeCode]
		  ,[FoundationInd]
		  ,[FrameCode]
		  ,[Garage]
		  ,[GarageParkingNbr]
		  ,[HeatCode]
		  ,[HeatingFuelTypeCode]
		  ,[InteriorWallsCode]
		  ,[PavingCode]
		  ,[PatioCode]
		  ,[PoolCode]
		  ,[PorchCode]
		  ,[RoofCoverCode]
		  ,[RoofTypeCode]
		  ,[SewerCode]
		  ,[ShapeCode]
		  ,[StoriesCode_OLD]
		  ,[StoriesNbrCode_OLD]
		  ,[StyleCode]
		  ,[WallExteriorCode]
		  ,[WallheightCode]
		  ,[WaterCode]
		  ,[YearBuilt]
		  ,[EffectiveYearBuilt]
		  ,[SumBuildingsNbr]
		  ,[SumAboveGradeLivingSqFt]
		  ,[SumAdjAreaSqFt]
		  ,[SumBasementSqFt]
		  ,[SumBuildingSqFt]
		  ,[SumGarageSqFt]
		  ,[SumGrossAreaSqFt]
		  ,[SumGroundFloorSqFt]
		  ,[SumLivingAreaSqFt]
		  ,[SumResidentialUnits]
		  ,[SumCommercialUnits]
		  ,[AssdLandValue]
		  ,[AssdImprovementValue]
		  ,[AssdTotalValue]
		  ,[AssdYear]
		  ,[MarketValueLand]
		  ,[MarketValueImprovement]
		  ,[MarketTotalValue]
		  ,[MarketValueYear]
		  ,[ApprLandValue]
		  ,[ApprImprovementValue]
		  ,[ApprTotalValue]
		  ,[ApprYear]
		  ,[TaxValueLand]
		  ,[TaxValueImprovement]
		  ,[TaxTotalValue]
		  ,[TaxableYear]
		  ,[UNVLandValue]
		  ,[UNVImprovementValue]
		  ,[UNVTotalValue]
		  ,[UNVValueYear]
		  ,[TaxRateCodeArea]
		  ,[TaxYear]
		  ,[TaxAmount]
		  ,[TaxDeliquentYear1]
		  ,[TaxDeliquentValue1]
		  ,[TaxExemptionCode]
		  ,[TaxexemptInd]
		  ,[CalifHomeownerInd]
		  ,[CemeteryInd]
		  ,[DisabledInd]
		  ,[HomesteadInd]
		  ,[HospitalInd]
		  ,[LibraryInd]
		  ,[PublicUtilityInd]
		  ,[ReligiousInd]
		  ,[SchoolCollegeInd]
		  ,[SeniorInd]
		  ,[VeteranInd]
		  ,[WelfareInd]
		  ,[WidowInd]
		  ,[SchoolTaxDistrict1Code]
		  ,[SchoolTaxDistrict1Ind]
		  ,[SchoolTaxDistrict2Code]
		  ,[SchoolTaxDistrict2Ind]
		  ,[SchoolTaxDistrict3Code]
		  ,[SchoolTaxDistrict3Ind]
		  ,[FADeleteFlag]
		  ,[FADeleteFlagDate]
		  ,[CurrentSaleTransactionId]
		  ,[CurrentSaleChronoKey]
		  ,[CurrSaleInputDocNbr]
		  ,[CurrSaleInputBook]
		  ,[CurrSaleInputPage]
		  ,[CurrSaleFormatDocNbr]
		  ,[CurrSaleFormatBook]
		  ,[CurrSaleFormatPage]
		  ,[CurrSaleRecordingDate]
		  ,[CurrSaleDocumentType]
		  ,[CurrSalesPrice]
		  ,[CurrSalesPriceCode]
		  ,[CurrSaleContractDate]
		  ,[CurrSaleBuyer1FullName]
		  ,[CurrSaleBuyer2FullName]
		  ,[CurrSaleBuyer3FullName]
		  ,[CurrSaleBuyer4FullName]
		  ,[CurrSaleSeller1FullName]
		  ,[CurrSaleSeller2FullName]
		  ,[ConCurrMtg1InputDocNbr]
		  ,[ConCurrMtg1InputBook]
		  ,[ConCurrMtg1InputPage]
		  ,[ConCurrMtg1FormatDocNbr]
		  ,[ConCurrMtg1FormatBook]
		  ,[ConCurrMtg1FormatPage]
		  ,[ConCurrMtg1RecordingDt]
		  ,[ConCurrMtg1LoanAmt]
		  ,[ConCurrMtg1Lender]
		  ,[ConCurrMtg1LenderCode]
		  ,[ConCurrMtg1LenderType]
		  ,[ConCurrMtg1PrivateLender]
		  ,[ConCurrMtg1Term]
		  ,[ConCurrMtg1LoanDueDt]
		  ,[ConCurrMtg1AdjOrFix]
		  ,[ConCurrMtg1LoanType]
		  ,[ConCurrMtg1Typefinancing]
		  ,[ConCurrMtg1LienPosition]
		  ,[ConCurrMtg2InputDocNbr]
		  ,[ConCurrMtg2InputBook]
		  ,[ConCurrMtg2InputPage]
		  ,[ConCurrMtg2FormatDocNbr]
		  ,[ConCurrMtg2FormatBook]
		  ,[ConCurrMtg2FormatPage]
		  ,[ConCurrMtg2RecordingDt]
		  ,[ConCurrMtg2LoanAmt]
		  ,[ConCurrMtg2Lender]
		  ,[ConCurrMtg2LenderCode]
		  ,[ConCurrMtg2LenderType]
		  ,[ConCurrMtg2PrivateLender]
		  ,[ConCurrMtg2LoanDueDt]
		  ,[ConCurrMtg2AdjOrFix]
		  ,[ConCurrMtg2LoanType]
		  ,[ConCurrMtg2Typefinancing]
		  ,[ConCurrMtg2LienPosition]
		  ,[Mtg1TransactionId]
		  ,[Mtg1ChronoKey]
		  ,[Mtg1LoanAmt]
		  ,[Mtg1Lender]
		  ,[Mtg1LenderCode]
		  ,[Mtg1LenderType]
		  ,[Mtg1PrivateLender]
		  ,[Mtg1LoanDueDt]
		  ,[Mtg1AdjRider]
		  ,[Mtg1LoanType]
		  ,[Mtg1Typefinancing]
		  ,[Mtg1LienPosition]
		  ,[Mtg2TransactionId]
		  ,[Mtg2ChronoKey]
		  ,[Mtg2InputDocNbr]
		  ,[Mtg2InputBook]
		  ,[Mtg2InputPage]
		  ,[Mtg2FormatDocNbr]
		  ,[Mtg2FormatBook]
		  ,[Mtg2FormatPage]
		  ,[Mtg2RecordingDt]
		  ,[Mtg2LoanAmt]
		  ,[Mtg2Lender]
		  ,[Mtg2LenderCode]
		  ,[Mtg2LenderType]
		  ,[Mtg2PrivateLender]
		  ,[Mtg2LoanDueDt]
		  ,[Mtg2AdjRider]
		  ,[Mtg2LoanType]
		  ,[Mtg2Typefinancing]
		  ,[Mtg2LienPosition]
		  ,[Mtg3TransactionId]
		  ,[Mtg3ChronoKey]
		  ,[Mtg3InputDocNbr]
		  ,[Mtg3InputBook]
		  ,[Mtg3InputPage]
		  ,[Mtg3FormatDocNbr]
		  ,[Mtg3FormatBook]
		  ,[Mtg3FormatPage]
		  ,[Mtg3RecordingDt]
		  ,[Mtg3LoanAmt]
		  ,[Mtg3Lender]
		  ,[Mtg3LenderCode]
		  ,[Mtg3LenderType]
		  ,[Mtg3PrivateLender]
		  ,[Mtg3LoanDueDt]
		  ,[Mtg3AdjRider]
		  ,[Mtg3LoanType]
		  ,[Mtg3Typefinancing]
		  ,[Mtg3LienPosition]
		  ,[Mtg4TransactionId]
		  ,[Mtg4ChronoKey]
		  ,[Mtg4InputDocNbr]
		  ,[Mtg4InputBook]
		  ,[Mtg4InputPage]
		  ,[Mtg4FormatDocNbr]
		  ,[Mtg4FormatBook]
		  ,[Mtg4FormatPage]
		  ,[Mtg4RecordingDt]
		  ,[Mtg4LoanAmt]
		  ,[Mtg4Lender]
		  ,[Mtg4LenderCode]
		  ,[Mtg4LenderType]
		  ,[Mtg4PrivateLender]
		  ,[Mtg4LoanDueDt]
		  ,[Mtg4AdjRider]
		  ,[Mtg4LoanType]
		  ,[Mtg4Typefinancing]
		  ,[Mtg4LienPosition]
		  ,[PrevSaleTransactionId]
		  ,[PrevSaleChronoKey]
		  ,[PrevSaleInputDocNbr]
		  ,[PrevSaleInputBook]
		  ,[PrevSaleInputPage]
		  ,[PrevSaleFormatDocNbr]
		  ,[PrevSaleFormatBook]
		  ,[PrevSaleFormatPage]
		  ,[PrevSaleRecordingDate]
		  ,[PrevSalesPrice]
		  ,[PrevSalesPriceCode]
		  ,[PrevSaleContractDate]
		  ,[PrevSaleBuyer1FullName]
		  ,[PrevSaleBuyer2FullName]
		  ,[PrevSaleBuyer3FullName]
		  ,[PrevSaleBuyer4FullName]
		  ,[PrevSaleSeller1FullName]
		  ,[PrevSaleSeller2FullName]
		  ,[PrevMtg1InputDocNbr]
		  ,[PrevMtg1InputBook]
		  ,[PrevMtg1InputPage]
		  ,[PrevMtg1FormatDocNbr]
		  ,[PrevMtg1FormatBook]
		  ,[PrevMtg1FormatPage]
		  ,[PrevMtg1RecordingDt]
		  ,[PrevMtg1LoanAmt]
		  ,[PrevMtg1Lender]
		  ,[PrevMtg1LenderCode]
		  ,[PrevMtg1LenderType]
		  ,[PrevMtg1PrivateLender]
		  ,[PrevMtg1LoanDueDt]
		  ,[PrevMtg1AdjRider]
		  ,[PrevMtg1LoanType]
		  ,[PrevMtg1Typefinancing]
		  ,[EditionNumber]
		  ,[VersionId]
		  ,[VendorLoadDate]
		  ,[FASourceInd]
		  ,[FATimestamp]
		  ,[FAUserId]
		  ,[FACreateDt]
		  ,[FADeriveProcessDt]
		  ,[FAEnhanceprocessDt]
		  ,[FAOwnershipUpdateDt]
		  ,[FAActiveDt]
		  ,[SitusDPVCount]
		  ,[SitusDPVFootnote]
		  ,[SitusLACS]
		  ,[SitusLACSLinkInd]
		  ,[SitusDPCheckDigit]
		  ,[SitusDPCheckCode]
		  ,[SitusCensusBlock]
		  ,[SitusGeoErrorCode]
		  ,[SitusGeoStatusCode]
		  ,[MailingDPVCount]
		  ,[MailingDPVFootnote]
		  ,[MailingLACS]
		  ,[MailingLACSLinkInd]
		  ,[MailingDPCheckDigit]
		  ,[MailingDPCheckCode]
		  ,[MailingCensusBlock]
		  ,[MailingCensusTract]
		  ,[MailingGeoErrorCode]
		  ,[MailingGeoStatusCode]
		  ,[CheckOwnership]
		  ,[Mtg1InputDocNbr]
		  ,[Mtg1InputBook]
		  ,[Mtg1FormatDocNbr]
		  ,[Mtg1FormatBook]
		  ,[Mtg1FormatPage]
		  ,[Mtg1RecordingDt]
		  ,[Mtg1InputPage]
		  ,[FAUCIDFlag]
		  ,[FADateReceived]
		  ,[FAIsListedFlag]
		  ,[FAIsListedFlagDt]
		  ,[FAIsListedPriceRange]
		  ,[FAAddressParsedSitus]
		  ,[FAAddressParsedMailing]
		  ,[TPLatitude]
		  ,[TPLongitude]
		  ,[TPGeoStatusCode]
		  ,[FALatitude]
		  ,[FALongitude]
		  ,[FAGeoStatusCode]
		  ,[SitusGeoCodeResults]
		  ,[MailingGeoCodeResults]
		  ,[MailForeignAddrInd]
		  ,[FACLTV]
		  ,[FAEstLotSqFt]
		  ,[FAOLTV]
		  ,[FAOwnerTransactionId]
		  ,[LienPosUpdateFlag]
		  ,[LienPosUpdateDate]
		  ,[TotalOpenLienAmt]
		  ,[TotalOpenLienNbr]
		  ,[VacantFlag]
		  ,[VacantFlagDate]
		  ,[AssessorLkupToken0]
		  ,[AssessorLkupToken1]
		  ,[SchoolDistrictName]
		  ,[AssessorLkupToken2]
		  ,GETDATE() [FADataArchiveDate]
		  ,[ConCurrMtg2Term]
		  ,[Mtg1Term]
		  ,[Mtg2Term]
		  ,[Mtg3Term]
		  ,[Mtg4Term]
		  ,[PrevMtg1Term]
		  ,[BankOwned]
		  ,[StoriesCode]
		  ,[StoriesNbrCode]
		  ,[BasementFinishSqFt]
		  ,[BasementUnfinSqFt]
		  ,[GarageFinishSqFt]
		  ,[GarageUnFinSqFt]
		  ,[AtticSqFt]
		  ,[AtticFinishSqFt]
		  ,[AtticUnfinSqFt]
		  ,[Mtg4InterestRate]
		  ,[Mtg4EstPaymentAmt]
		  ,[Mtg3InterestRate]
		  ,[Mtg3EstPaymentAmt]
		  ,[Mtg2InterestRate]
		  ,[Mtg2EstPaymentAmt]
		  ,[Mtg1InterestRate]
		  ,[Mtg1EstPaymentAmt]
		  ,[ConCurrMtg1InterestRate]
		  ,[ConCurrMtg2InterestRate]
		  ,[PrevMtg1InterestRate]
		  ,[MailingFIPS]
		  ,[DBSTaxAmount]
		  ,[DBSTaxYear]
		  ,[Mtg1EstLoanBalance]
		  ,[Mtg2EstLoanBalance]
		  ,[Mtg3EstLoanBalance]
		  ,[Mtg4EstLoanBalance]
		  ,[OldApnIndicator]
		  ,[PrevSaleDocumentType]
		  ,[SecondPrevSaleTransactionId]
		  ,[SecondPrevSaleRecordingDate]
		  ,[SecondPrevSalesPrice]
		  ,[ThirdPrevSaleTransactionId]
		  ,[ThirdPrevSaleRecordingDate]
		  ,[ThirdPrevSalesPrice]
		  ,[HouseFacingDirection]
		  ,[FARooftopLatitude]
		  ,[FARooftopLongitude]
		  ,[BuildingEstFootprintSqFt]
		  ,[BathTotalCalcEst]
		  ,[DQOZ_TractType]
		  ,[DQOZ_ACSDataSource]
		  ,[VacantScore]
		  ,[BedroomsEst]
		  ,[DTDB_REF_ID]
		  ,[DTDB_FORMATTED_APN]
		  ,[MailingLabelName]
		  ,[Name1TypeInd]
		  ,[Name2TypeInd]
		  ,[TaxSourceInd]
		  ,[FASubdivisionName]
		  ,[FAComplexNbrUnits]
		  ,[FASubdivisionNameID]
		  ,[FASubdivisionPhase]
		  ,[ElevatorCode]
		  ,[FAEstimatedMultiPolygonFlag]
		  ,[FAEstimatedNumberofBuildings]
		  ,[Poverty]
		  ,[UnEmployment]
		  ,[PopulationLoss]
		  ,[RemoteRural]
		  ,[Distressed]
		  ,[UnderServed]
		  ,[DTDB_UNFORMATTED_APN]
		  ,[ConformingLoanLimitYear]
		  ,[ConformingLoanLimit]
		  ,[PriorConformingLoanLimitYear]
		  ,[PriorConformingLoanLimit]
		  ,[MTG3InterestRateSrce]
		  ,[MTG1InterestRateSrce]
		  ,[MTG2InterestRateSrce]
		  ,[MTG4InterestRateSrce]
		  ,[CS_FORMATTED_APN]
		  ,[CS_UNFORMATTED_APN]
		FROM  [Data].[dbo].[Property] A	JOIN (Select Fips fipscode,PropertyID PropID FROM [DragonAssr].[dbo].[PropertyWorkUpdate]) B
		ON a.FIPS = b.fipscode 
			and a.PropertyID = b.PropID


		DELETE FROM a
		FROM [Data].[dbo].[Property] a	JOIN [DragonAssr].[dbo].[PropertyWorkUpdate] B
		ON a.FIPS = b.FIPS 
			and a.PropertyID = b.PropertyID


		INSERT INTO [Data].[dbo].[Property] (
		   [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[APNSeqNbr]
      ,[UnformattedAPN]
      ,[OldAPN]
      ,[OLDAPNSeqNbr]
      ,[TaxAccountNumber]
      ,[RecordType]
      ,[VendorPID]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdHouseNbr2]
      ,[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusStdCarrierCode]
      ,[SitusCensusTract]
      ,[SitusCensusTractBlock]
      ,[SitusStdUnitType]
      ,[SitusStdMatchCode]
      ,[LotSizeSqFt]
      ,[LotSizeAcres]
      ,[LotSizeFrontageFeet]
      ,[LotSizeDepthFeet]
      ,[LotIrregularInd]
      ,[LotUsableSize]
      ,[PropertyClassID]
      ,[StdLandUseCode]
      ,[StateLandUseCode]
      ,[CountyLandUseCode]
      ,[CountyLandUseDescription]
      ,[TimeshareCode]
      ,[Zoning]
      ,[SiteInfluenceCode]
      ,[NeighborhoodCode]
      ,[TopographyCode]
      ,[MobileHomeInd]
      ,[LotCode]
      ,[LotNumber]
      ,[LandLot]
      ,[Block]
      ,[Section]
      ,[District]
      ,[LegalUnit]
      ,[Municipality]
      ,[LegalSection]
      ,[LegalTownship]
      ,[LegalRange]
      ,[Meridian]
      ,[LegalQuarter]
      ,[LegalQuarterQuarter]
      ,[LegalDescription]
      ,[AssessorsMapRef1]
      ,[AssessorsMapRef2]
      ,[SubdivisionName]
      ,[SubdivisionPhaseNbr]
      ,[SubdivisionTractNbr]
      ,[SubdivisionPlatBook]
      ,[SubdivisionPlatPage]
      ,[NewRecordType]
      ,[SwiSCodeNY]
      ,[MailingCareOfName]
      ,[MailingStdFullStreetAddress]
      ,[MailingStdHouseNbr]
      ,[MailingStdHouseNbr2]
      ,[MailingStdHouseNbrSuffix]
      ,[MailingStdDirectionLeft]
      ,[MailingStdStreet]
      ,[MailingStdMode]
      ,[MailingStdDirectionRight]
      ,[MailingStdUnitNbr]
      ,[MailingStdCity]
      ,[MailingStdState]
      ,[MailingStdZIP5]
      ,[MailingStdZIP4]
      ,[MailingStdCarrierCode]
      ,[MailingStdUnitType]
      ,[MailingStdMatchCode]
      ,[MailingOptOut]
      ,[MailingOptOutDate]
      ,[OwnerOccupied]
      ,[AbsenteeOwner]
      ,[OwnerStdNAME1FULL]
      ,[OwnerStdNAME2FULL]
      ,[OwnerStdNAME3FULL]
      ,[OwnerStdNAME4FULL]
      ,[OwnerEtALIndicator]
      ,[OwnerStd1CorpInd]
      ,[OwnerStd1LastName]
      ,[OwnerStd1FirstName]
      ,[OwnerStd1MiddleName]
      ,[OwnerStd1Suffix]
      ,[OwnerStd1CorpName]
      ,[OwnerStd1OwnershipRights]
      ,[OwnerStd1RelationshipType]
      ,[Owner1DoNotParse]
      ,[OwnerStd2CorpInd]
      ,[OwnerStd2LastName]
      ,[OwnerStd2FirstName]
      ,[OwnerStd2MiddleName]
      ,[OwnerStd2Suffix]
      ,[OwnerStd2CorpName]
      ,[OwnerStd2OwnershipRights]
      ,[OwnerStd2RelationshipType]
      ,[Owner2DoNotParse]
      ,[OwnerStd3CorpInd]
      ,[OwnerStd3LastName]
      ,[OwnerStd3FirstName]
      ,[OwnerStd3MiddleName]
      ,[OwnerStd3Suffix]
      ,[OwnerStd3CorpName]
      ,[OwnerStd3OwnershipRights]
      ,[OwnerStd3RelationshipType]
      ,[Owner3DoNotParse]
      ,[OwnerStd4CorpInd]
      ,[OwnerStd4LastName]
      ,[OwnerStd4FirstName]
      ,[OwnerStd4MiddleName]
      ,[OwnerStd4Suffix]
      ,[OwnerStd4CorpName]
      ,[OwnerStd4OwnershipRights]
      ,[OwnerStd4RelationshipType]
      ,[Owner4DoNotParse]
      ,[AssesseeStd1Name]
      ,[AssesseeStd2Name]
      ,[AssesseeNameIndicator]
      ,[AssesseeNameIndicator2]
      ,[Amenities]
      ,[DrivewayCode]
      ,[EasementInd]
      ,[QualityCode]
      ,[ViewInd]
      ,[ViewCode]
      ,[ViewQualityCode]
      ,[WaterAccessableInd]
      ,[WaterFeatureInd]
      ,[WaterfrontCode]
      ,[WaterfrontFeet]
      ,[WaterfrontQualityCode]
      ,[BuildingArea]
      ,[BuildingAreaInd]
      ,[TotalRooms]
      ,[Bedrooms]
      ,[BathTotalCalc]
      ,[BathFull]
      ,[BathsParcialNbr]
      ,[BathHalf]
      ,[Bath1QTR]
      ,[Bath3QTR]
      ,[BathFixturesNbr]
      ,[OtherRooms]
      ,[AirConditioningCode]
      ,[AirConditioningTypeCode]
      ,[BasementCode]
      ,[BasementFinishedCode]
      ,[BuildingClassCode]
      ,[BuildingConditionCode]
      ,[BuildingQualityCode]
      ,[ConstructionTypeCode]
      ,[DeckCode]
      ,[ElectricityCode]
      ,[ExteriorWallsCode]
      ,[FireplaceCode]
      ,[FloorCoverCode]
      ,[FloorTypeCode]
      ,[FoundationInd]
      ,[FrameCode]
      ,[Garage]
      ,[GarageParkingNbr]
      ,[HeatCode]
      ,[HeatingFuelTypeCode]
      ,[InteriorWallsCode]
      ,[PavingCode]
      ,[PatioCode]
      ,[PoolCode]
      ,[PorchCode]
      ,[RoofCoverCode]
      ,[RoofTypeCode]
      ,[SewerCode]
      ,[ShapeCode]
      ,[StoriesCode_OLD]
      ,[StoriesNbrCode_OLD]
      ,[StyleCode]
      ,[WallExteriorCode]
      ,[WallheightCode]
      ,[WaterCode]
      ,[YearBuilt]
      ,[EffectiveYearBuilt]
      ,[SumBuildingsNbr]
      ,[SumAboveGradeLivingSqFt]
      ,[SumAdjAreaSqFt]
      ,[SumBasementSqFt]
      ,[SumBuildingSqFt]
      ,[SumGarageSqFt]
      ,[SumGrossAreaSqFt]
      ,[SumGroundFloorSqFt]
      ,[SumLivingAreaSqFt]
      ,[SumResidentialUnits]
      ,[AssdLandValue]
      ,[AssdImprovementValue]
      ,[AssdTotalValue]
      ,[AssdYear]
      ,[MarketValueLand]
      ,[MarketValueImprovement]
      ,[MarketTotalValue]
      ,[MarketValueYear]
      ,[ApprLandValue]
      ,[ApprImprovementValue]
      ,[ApprTotalValue]
      ,[ApprYear]
      ,[TaxValueLand]
      ,[TaxValueImprovement]
      ,[TaxTotalValue]
      ,[TaxableYear]
      ,[UNVLandValue]
      ,[UNVImprovementValue]
      ,[UNVTotalValue]
      ,[UNVValueYear]
      ,[TaxRateCodeArea]
      ,[TaxYear]
      ,[TaxAmount]
      ,[TaxDeliquentYear1]
      ,[TaxDeliquentValue1]
      ,[TaxExemptionCode]
      ,[TaxexemptInd]
      ,[CalifHomeownerInd]
      ,[CemeteryInd]
      ,[DisabledInd]
      ,[HomesteadInd]
      ,[HospitalInd]
      ,[LibraryInd]
      ,[PublicUtilityInd]
      ,[ReligiousInd]
      ,[SchoolCollegeInd]
      ,[SeniorInd]
      ,[VeteranInd]
      ,[WelfareInd]
      ,[WidowInd]
      ,[SchoolTaxDistrict1Code]
      ,[SchoolTaxDistrict1Ind]
      ,[SchoolTaxDistrict2Code]
      ,[SchoolTaxDistrict2Ind]
      ,[SchoolTaxDistrict3Code]
      ,[SchoolTaxDistrict3Ind]
      ,[FADeleteFlag]
      ,[FADeleteFlagDate]
      ,[CurrentSaleTransactionId]
      ,[CurrentSaleChronoKey]
      ,[CurrSaleInputDocNbr]
      ,[CurrSaleInputBook]
      ,[CurrSaleInputPage]
      ,[CurrSaleFormatDocNbr]
      ,[CurrSaleFormatBook]
      ,[CurrSaleFormatPage]
      ,[CurrSaleRecordingDate]
      ,[CurrSaleDocumentType]
      ,[CurrSalesPrice]
      ,[CurrSalesPriceCode]
      ,[CurrSaleContractDate]
      ,[CurrSaleBuyer1FullName]
      ,[CurrSaleBuyer2FullName]
      ,[CurrSaleBuyer3FullName]
      ,[CurrSaleBuyer4FullName]
      ,[CurrSaleSeller1FullName]
      ,[CurrSaleSeller2FullName]
      ,[ConCurrMtg1InputDocNbr]
      ,[ConCurrMtg1InputBook]
      ,[ConCurrMtg1InputPage]
      ,[ConCurrMtg1FormatDocNbr]
      ,[ConCurrMtg1FormatBook]
      ,[ConCurrMtg1FormatPage]
      ,[ConCurrMtg1RecordingDt]
      ,[ConCurrMtg1LoanAmt]
      ,[ConCurrMtg1Lender]
      ,[ConCurrMtg1LenderCode]
      ,[ConCurrMtg1LenderType]
      ,[ConCurrMtg1PrivateLender]
      ,[ConCurrMtg1Term]
      ,[ConCurrMtg1LoanDueDt]
      ,[ConCurrMtg1AdjOrFix]
      ,[ConCurrMtg1LoanType]
      ,[ConCurrMtg1Typefinancing]
      ,[ConCurrMtg1LienPosition]
      ,[ConCurrMtg2InputDocNbr]
      ,[ConCurrMtg2InputBook]
      ,[ConCurrMtg2InputPage]
      ,[ConCurrMtg2FormatDocNbr]
      ,[ConCurrMtg2FormatBook]
      ,[ConCurrMtg2FormatPage]
      ,[ConCurrMtg2RecordingDt]
      ,[ConCurrMtg2LoanAmt]
      ,[ConCurrMtg2Lender]
      ,[ConCurrMtg2LenderCode]
      ,[ConCurrMtg2LenderType]
      ,[ConCurrMtg2PrivateLender]
      ,[ConCurrMtg2LoanDueDt]
      ,[ConCurrMtg2AdjOrFix]
      ,[ConCurrMtg2LoanType]
      ,[ConCurrMtg2Typefinancing]
      ,[ConCurrMtg2LienPosition]
      ,[Mtg1TransactionId]
      ,[Mtg1ChronoKey]
      ,[Mtg1LoanAmt]
      ,[Mtg1Lender]
      ,[Mtg1LenderCode]
      ,[Mtg1LenderType]
      ,[Mtg1PrivateLender]
      ,[Mtg1LoanDueDt]
      ,[Mtg1AdjRider]
      ,[Mtg1LoanType]
      ,[Mtg1Typefinancing]
      ,[Mtg1LienPosition]
      ,[Mtg2TransactionId]
      ,[Mtg2ChronoKey]
      ,[Mtg2InputDocNbr]
      ,[Mtg2InputBook]
      ,[Mtg2InputPage]
      ,[Mtg2FormatDocNbr]
      ,[Mtg2FormatBook]
      ,[Mtg2FormatPage]
      ,[Mtg2RecordingDt]
      ,[Mtg2LoanAmt]
      ,[Mtg2Lender]
      ,[Mtg2LenderCode]
      ,[Mtg2LenderType]
      ,[Mtg2PrivateLender]
      ,[Mtg2LoanDueDt]
      ,[Mtg2AdjRider]
      ,[Mtg2LoanType]
      ,[Mtg2Typefinancing]
      ,[Mtg2LienPosition]
      ,[Mtg3TransactionId]
      ,[Mtg3ChronoKey]
      ,[Mtg3InputDocNbr]
      ,[Mtg3InputBook]
      ,[Mtg3InputPage]
      ,[Mtg3FormatDocNbr]
      ,[Mtg3FormatBook]
      ,[Mtg3FormatPage]
      ,[Mtg3RecordingDt]
      ,[Mtg3LoanAmt]
      ,[Mtg3Lender]
      ,[Mtg3LenderCode]
      ,[Mtg3LenderType]
      ,[Mtg3PrivateLender]
      ,[Mtg3LoanDueDt]
      ,[Mtg3AdjRider]
      ,[Mtg3LoanType]
      ,[Mtg3Typefinancing]
      ,[Mtg3LienPosition]
      ,[Mtg4TransactionId]
      ,[Mtg4ChronoKey]
      ,[Mtg4InputDocNbr]
      ,[Mtg4InputBook]
      ,[Mtg4InputPage]
      ,[Mtg4FormatDocNbr]
      ,[Mtg4FormatBook]
      ,[Mtg4FormatPage]
      ,[Mtg4RecordingDt]
      ,[Mtg4LoanAmt]
      ,[Mtg4Lender]
      ,[Mtg4LenderCode]
      ,[Mtg4LenderType]
      ,[Mtg4PrivateLender]
      ,[Mtg4LoanDueDt]
      ,[Mtg4AdjRider]
      ,[Mtg4LoanType]
      ,[Mtg4Typefinancing]
      ,[Mtg4LienPosition]
      ,[PrevSaleTransactionId]
      ,[PrevSaleChronoKey]
      ,[PrevSaleInputDocNbr]
      ,[PrevSaleInputBook]
      ,[PrevSaleInputPage]
      ,[PrevSaleFormatDocNbr]
      ,[PrevSaleFormatBook]
      ,[PrevSaleFormatPage]
      ,[PrevSaleRecordingDate]
      ,[PrevSalesPrice]
      ,[PrevSalesPriceCode]
      ,[PrevSaleContractDate]
      ,[PrevSaleBuyer1FullName]
      ,[PrevSaleBuyer2FullName]
      ,[PrevSaleBuyer3FullName]
      ,[PrevSaleBuyer4FullName]
      ,[PrevSaleSeller1FullName]
      ,[PrevSaleSeller2FullName]
      ,[PrevMtg1InputDocNbr]
      ,[PrevMtg1InputBook]
      ,[PrevMtg1InputPage]
      ,[PrevMtg1FormatDocNbr]
      ,[PrevMtg1FormatBook]
      ,[PrevMtg1FormatPage]
      ,[PrevMtg1RecordingDt]
      ,[PrevMtg1LoanAmt]
      ,[PrevMtg1Lender]
      ,[PrevMtg1LenderCode]
      ,[PrevMtg1LenderType]
      ,[PrevMtg1PrivateLender]
      ,[PrevMtg1LoanDueDt]
      ,[PrevMtg1AdjRider]
      ,[PrevMtg1LoanType]
      ,[PrevMtg1Typefinancing]
      ,[EditionNumber]
      ,[VersionId]
      ,[VendorLoadDate]
      ,[FASourceInd]
      ,[FATimestamp]
      ,[FAUserId]
      ,[FACreateDt]
      ,[FADeriveProcessDt]
      ,[FAEnhanceprocessDt]
      ,[FAOwnershipUpdateDt]
      ,[FAActiveDt]
      ,[SitusDPVCount]
      ,[SitusDPVFootnote]
      ,[SitusLACS]
      ,[SitusLACSLinkInd]
      ,[SitusDPCheckDigit]
      ,[SitusDPCheckCode]
      ,[SitusCensusBlock]
      ,[SitusGeoErrorCode]
      ,[SitusGeoStatusCode]
      ,[MailingDPVCount]
      ,[MailingDPVFootnote]
      ,[MailingLACS]
      ,[MailingLACSLinkInd]
      ,[MailingDPCheckDigit]
      ,[MailingDPCheckCode]
      ,[MailingCensusBlock]
      ,[MailingCensusTract]
      ,[MailingGeoErrorCode]
      ,[MailingGeoStatusCode]
      ,[CheckOwnership]
      ,[Mtg1InputDocNbr]
      ,[Mtg1InputBook]
      ,[Mtg1FormatDocNbr]
      ,[Mtg1FormatBook]
      ,[Mtg1FormatPage]
      ,[Mtg1RecordingDt]
      ,[Mtg1InputPage]
      ,[FAUCIDFlag]
      ,[FADateReceived]
      ,[FAAddressParsedSitus]
      ,[FAAddressParsedMailing]
      ,[FACLTV]
      ,[FAOLTV]
      ,[FALatitude]
      ,[FALongitude]
      ,[FAEstLotSqFt]
      ,[FAOwnerTransactionId]
      ,[MailForeignAddrInd]
      ,[FAIsListedFlag]
      ,[FAIsListedFlagDt]
      ,[FAIsListedPriceRange]
      ,[TPLatitude]
      ,[TPLongitude]
      ,[TPGeoStatusCode]
      ,[FAGeoStatusCode]
      ,[SumCommercialUnits]
      ,[SitusGeoCodeResults]
      ,[MailingGeoCodeResults]
      ,[LienPosUpdateFlag]
      ,[LienPosUpdateDate]
      ,[TotalOpenLienAmt]
      ,[TotalOpenLienNbr]
      ,[VacantFlag]
      ,[VacantFlagDate]
      ,[AssessorLkupToken0]
      ,[AssessorLkupToken1]
      ,[SchoolDistrictName]
      ,[AssessorLkupToken2]
      ,[FADataArchiveDate]
      ,[ConCurrMtg2Term]
      ,[Mtg1Term]
      ,[Mtg2Term]
      ,[Mtg3Term]
      ,[Mtg4Term]
      ,[PrevMtg1Term]
      ,[BankOwned]
      ,[StoriesCode]
      ,[StoriesNbrCode]
      ,[BasementFinishSqFt]
      ,[BasementUnfinSqFt]
      ,[GarageFinishSqFt]
      ,[GarageUnFinSqFt]
      ,[AtticSqFt]
      ,[AtticFinishSqFt]
      ,[AtticUnfinSqFt]
      ,[Mtg1EstPaymentAmt]
      ,[Mtg1InterestRate]
      ,[Mtg2EstPaymentAmt]
      ,[Mtg2InterestRate]
      ,[Mtg3EstPaymentAmt]
      ,[Mtg3InterestRate]
      ,[Mtg4EstPaymentAmt]
      ,[Mtg4InterestRate]
      ,[ConCurrMtg1InterestRate]
      ,[ConCurrMtg2InterestRate]
      ,[PrevMtg1InterestRate]
      ,[MailingFIPS]
      ,[DBSTaxAmount]
      ,[DBSTaxYear]
      ,[Mtg1EstLoanBalance]
      ,[Mtg2EstLoanBalance]
      ,[Mtg3EstLoanBalance]
      ,[Mtg4EstLoanBalance]
      ,[OldApnIndicator]
      ,[PrevSaleDocumentType]
      ,[SecondPrevSaleTransactionId]
      ,[SecondPrevSaleRecordingDate]
      ,[SecondPrevSalesPrice]
      ,[ThirdPrevSaleTransactionId]
      ,[ThirdPrevSaleRecordingDate]
      ,[ThirdPrevSalesPrice]
      ,[HouseFacingDirection]
      ,[FARooftopLatitude]
      ,[FARooftopLongitude]
      ,[BuildingEstFootprintSqFt]
      ,[BathTotalCalcEst]
      ,[DQOZ_TractType]
      ,[DQOZ_ACSDataSource]
      ,[VacantScore]
      ,[BedroomsEst]
      ,[DTDB_Ref_ID]
      ,[DTDB_FORMATTED_APN]
      ,[MailingLabelName]
      ,[Name1TypeInd]
      ,[Name2TypeInd]
      ,[TaxSourceInd]
      ,[FASubdivisionName]
      ,[FAComplexNbrUnits]
      ,[FASubdivisionNameID]
      ,[FASubdivisionPhase]
      ,[ElevatorCode]
      ,[FAEstimatedMultiPolygonFlag]
      ,[FAEstimatedNumberofBuildings]
      ,[Poverty]
      ,[UnEmployment]
      ,[PopulationLoss]
      ,[RemoteRural]
      ,[Distressed]
      ,[UnderServed]
      ,[DTDB_UNFORMATTED_APN]
      ,[ConformingLoanLimitYear]
      ,[ConformingLoanLimit]
      ,[PriorConformingLoanLimitYear]
      ,[PriorConformingLoanLimit]
      ,[MTG1InterestRateSrce]
      ,[MTG2InterestRateSrce]
      ,[MTG3InterestRateSrce]
      ,[MTG4InterestRateSrce]
      ,[CS_FORMATTED_APN]
      ,[CS_UNFORMATTED_APN]
		  )
		SELECT
		   [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[APNSeqNbr]
      ,[UnformattedAPN]
      ,[OldAPN]
      ,[OLDAPNSeqNbr]
      ,[TaxAccountNumber]
      ,[RecordType]
      ,[VendorPID]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdHouseNbr2]
      ,[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusStdCarrierCode]
      ,[SitusCensusTract]
      ,[SitusCensusTractBlock]
      ,[SitusStdUnitType]
      ,[SitusStdMatchCode]
      ,[LotSizeSqFt]
      ,[LotSizeAcres]
      ,[LotSizeFrontageFeet]
      ,[LotSizeDepthFeet]
      ,[LotIrregularInd]
      ,[LotUsableSize]
      ,[PropertyClassID]
      ,[StdLandUseCode]
      ,[StateLandUseCode]
      ,[CountyLandUseCode]
      ,[CountyLandUseDescription]
      ,[TimeshareCode]
      ,[Zoning]
      ,[SiteInfluenceCode]
      ,[NeighborhoodCode]
      ,[TopographyCode]
      ,[MobileHomeInd]
      ,[LotCode]
      ,[LotNumber]
      ,[LandLot]
      ,[Block]
      ,[Section]
      ,[District]
      ,[LegalUnit]
      ,[Municipality]
      ,[LegalSection]
      ,[LegalTownship]
      ,[LegalRange]
      ,[Meridian]
      ,[LegalQuarter]
      ,[LegalQuarterQuarter]
      ,[LegalDescription]
      ,[AssessorsMapRef1]
      ,[AssessorsMapRef2]
      ,[SubdivisionName]
      ,[SubdivisionPhaseNbr]
      ,[SubdivisionTractNbr]
      ,[SubdivisionPlatBook]
      ,[SubdivisionPlatPage]
      ,[NewRecordType]
      ,[SwiSCodeNY]
      ,[MailingCareOfName]
      ,[MailingStdFullStreetAddress]
      ,[MailingStdHouseNbr]
      ,[MailingStdHouseNbr2]
      ,[MailingStdHouseNbrSuffix]
      ,[MailingStdDirectionLeft]
      ,[MailingStdStreet]
      ,[MailingStdMode]
      ,[MailingStdDirectionRight]
      ,[MailingStdUnitNbr]
      ,[MailingStdCity]
      ,[MailingStdState]
      ,[MailingStdZIP5]
      ,[MailingStdZIP4]
      ,[MailingStdCarrierCode]
      ,[MailingStdUnitType]
      ,[MailingStdMatchCode]
      ,[MailingOptOut]
      ,[MailingOptOutDate]
      ,[OwnerOccupied]
      ,[AbsenteeOwner]
      ,[OwnerStdNAME1FULL]
      ,[OwnerStdNAME2FULL]
      ,[OwnerStdNAME3FULL]
      ,[OwnerStdNAME4FULL]
      ,[OwnerEtALIndicator]
      ,[OwnerStd1CorpInd]
      ,[OwnerStd1LastName]
      ,[OwnerStd1FirstName]
      ,[OwnerStd1MiddleName]
      ,[OwnerStd1Suffix]
      ,[OwnerStd1CorpName]
      ,[OwnerStd1OwnershipRights]
      ,[OwnerStd1RelationshipType]
      ,[Owner1DoNotParse]
      ,[OwnerStd2CorpInd]
      ,[OwnerStd2LastName]
      ,[OwnerStd2FirstName]
      ,[OwnerStd2MiddleName]
      ,[OwnerStd2Suffix]
      ,[OwnerStd2CorpName]
      ,[OwnerStd2OwnershipRights]
      ,[OwnerStd2RelationshipType]
      ,[Owner2DoNotParse]
      ,[OwnerStd3CorpInd]
      ,[OwnerStd3LastName]
      ,[OwnerStd3FirstName]
      ,[OwnerStd3MiddleName]
      ,[OwnerStd3Suffix]
      ,[OwnerStd3CorpName]
      ,[OwnerStd3OwnershipRights]
      ,[OwnerStd3RelationshipType]
      ,[Owner3DoNotParse]
      ,[OwnerStd4CorpInd]
      ,[OwnerStd4LastName]
      ,[OwnerStd4FirstName]
      ,[OwnerStd4MiddleName]
      ,[OwnerStd4Suffix]
      ,[OwnerStd4CorpName]
      ,[OwnerStd4OwnershipRights]
      ,[OwnerStd4RelationshipType]
      ,[Owner4DoNotParse]
      ,[AssesseeStd1Name]
      ,[AssesseeStd2Name]
      ,[AssesseeNameIndicator]
      ,[AssesseeNameIndicator2]
      ,[Amenities]
      ,[DrivewayCode]
      ,[EasementInd]
      ,[QualityCode]
      ,[ViewInd]
      ,[ViewCode]
      ,[ViewQualityCode]
      ,[WaterAccessableInd]
      ,[WaterFeatureInd]
      ,[WaterfrontCode]
      ,[WaterfrontFeet]
      ,[WaterfrontQualityCode]
      ,[BuildingArea]
      ,[BuildingAreaInd]
      ,[TotalRooms]
      ,[Bedrooms]
      ,[BathTotalCalc]
      ,[BathFull]
      ,[BathsParcialNbr]
      ,[BathHalf]
      ,[Bath1QTR]
      ,[Bath3QTR]
      ,[BathFixturesNbr]
      ,[OtherRooms]
      ,[AirConditioningCode]
      ,[AirConditioningTypeCode]
      ,[BasementCode]
      ,[BasementFinishedCode]
      ,[BuildingClassCode]
      ,[BuildingConditionCode]
      ,[BuildingQualityCode]
      ,[ConstructionTypeCode]
      ,[DeckCode]
      ,[ElectricityCode]
      ,[ExteriorWallsCode]
      ,[FireplaceCode]
      ,[FloorCoverCode]
      ,[FloorTypeCode]
      ,[FoundationInd]
      ,[FrameCode]
      ,[Garage]
      ,[GarageParkingNbr]
      ,[HeatCode]
      ,[HeatingFuelTypeCode]
      ,[InteriorWallsCode]
      ,[PavingCode]
      ,[PatioCode]
      ,[PoolCode]
      ,[PorchCode]
      ,[RoofCoverCode]
      ,[RoofTypeCode]
      ,[SewerCode]
      ,[ShapeCode]
      ,[StoriesCode_OLD]
      ,[StoriesNbrCode_OLD]
      ,[StyleCode]
      ,[WallExteriorCode]
      ,[WallheightCode]
      ,[WaterCode]
      ,[YearBuilt]
      ,[EffectiveYearBuilt]
      ,[SumBuildingsNbr]
      ,[SumAboveGradeLivingSqFt]
      ,[SumAdjAreaSqFt]
      ,[SumBasementSqFt]
      ,[SumBuildingSqFt]
      ,[SumGarageSqFt]
      ,[SumGrossAreaSqFt]
      ,[SumGroundFloorSqFt]
      ,[SumLivingAreaSqFt]
      ,[SumResidentialUnits]
      ,[AssdLandValue]
      ,[AssdImprovementValue]
      ,[AssdTotalValue]
      ,[AssdYear]
      ,[MarketValueLand]
      ,[MarketValueImprovement]
      ,[MarketTotalValue]
      ,[MarketValueYear]
      ,[ApprLandValue]
      ,[ApprImprovementValue]
      ,[ApprTotalValue]
      ,[ApprYear]
      ,[TaxValueLand]
      ,[TaxValueImprovement]
      ,[TaxTotalValue]
      ,[TaxableYear]
      ,[UNVLandValue]
      ,[UNVImprovementValue]
      ,[UNVTotalValue]
      ,[UNVValueYear]
      ,[TaxRateCodeArea]
      ,[TaxYear]
      ,[TaxAmount]
      ,[TaxDeliquentYear1]
      ,[TaxDeliquentValue1]
      ,[TaxExemptionCode]
      ,[TaxexemptInd]
      ,[CalifHomeownerInd]
      ,[CemeteryInd]
      ,[DisabledInd]
      ,[HomesteadInd]
      ,[HospitalInd]
      ,[LibraryInd]
      ,[PublicUtilityInd]
      ,[ReligiousInd]
      ,[SchoolCollegeInd]
      ,[SeniorInd]
      ,[VeteranInd]
      ,[WelfareInd]
      ,[WidowInd]
      ,[SchoolTaxDistrict1Code]
      ,[SchoolTaxDistrict1Ind]
      ,[SchoolTaxDistrict2Code]
      ,[SchoolTaxDistrict2Ind]
      ,[SchoolTaxDistrict3Code]
      ,[SchoolTaxDistrict3Ind]
      ,[FADeleteFlag]
      ,[FADeleteFlagDate]
      ,[CurrentSaleTransactionId]
      ,[CurrentSaleChronoKey]
      ,[CurrSaleInputDocNbr]
      ,[CurrSaleInputBook]
      ,[CurrSaleInputPage]
      ,[CurrSaleFormatDocNbr]
      ,[CurrSaleFormatBook]
      ,[CurrSaleFormatPage]
      ,[CurrSaleRecordingDate]
      ,[CurrSaleDocumentType]
      ,[CurrSalesPrice]
      ,[CurrSalesPriceCode]
      ,[CurrSaleContractDate]
      ,[CurrSaleBuyer1FullName]
      ,[CurrSaleBuyer2FullName]
      ,[CurrSaleBuyer3FullName]
      ,[CurrSaleBuyer4FullName]
      ,[CurrSaleSeller1FullName]
      ,[CurrSaleSeller2FullName]
      ,[ConCurrMtg1InputDocNbr]
      ,[ConCurrMtg1InputBook]
      ,[ConCurrMtg1InputPage]
      ,[ConCurrMtg1FormatDocNbr]
      ,[ConCurrMtg1FormatBook]
      ,[ConCurrMtg1FormatPage]
      ,[ConCurrMtg1RecordingDt]
      ,[ConCurrMtg1LoanAmt]
      ,[ConCurrMtg1Lender]
      ,[ConCurrMtg1LenderCode]
      ,[ConCurrMtg1LenderType]
      ,[ConCurrMtg1PrivateLender]
      ,[ConCurrMtg1Term]
      ,[ConCurrMtg1LoanDueDt]
      ,[ConCurrMtg1AdjOrFix]
      ,[ConCurrMtg1LoanType]
      ,[ConCurrMtg1Typefinancing]
      ,[ConCurrMtg1LienPosition]
      ,[ConCurrMtg2InputDocNbr]
      ,[ConCurrMtg2InputBook]
      ,[ConCurrMtg2InputPage]
      ,[ConCurrMtg2FormatDocNbr]
      ,[ConCurrMtg2FormatBook]
      ,[ConCurrMtg2FormatPage]
      ,[ConCurrMtg2RecordingDt]
      ,[ConCurrMtg2LoanAmt]
      ,[ConCurrMtg2Lender]
      ,[ConCurrMtg2LenderCode]
      ,[ConCurrMtg2LenderType]
      ,[ConCurrMtg2PrivateLender]
      ,[ConCurrMtg2LoanDueDt]
      ,[ConCurrMtg2AdjOrFix]
      ,[ConCurrMtg2LoanType]
      ,[ConCurrMtg2Typefinancing]
      ,[ConCurrMtg2LienPosition]
      ,[Mtg1TransactionId]
      ,[Mtg1ChronoKey]
      ,[Mtg1LoanAmt]
      ,[Mtg1Lender]
      ,[Mtg1LenderCode]
      ,[Mtg1LenderType]
      ,[Mtg1PrivateLender]
      ,[Mtg1LoanDueDt]
      ,[Mtg1AdjRider]
      ,[Mtg1LoanType]
      ,[Mtg1Typefinancing]
      ,[Mtg1LienPosition]
      ,[Mtg2TransactionId]
      ,[Mtg2ChronoKey]
      ,[Mtg2InputDocNbr]
      ,[Mtg2InputBook]
      ,[Mtg2InputPage]
      ,[Mtg2FormatDocNbr]
      ,[Mtg2FormatBook]
      ,[Mtg2FormatPage]
      ,[Mtg2RecordingDt]
      ,[Mtg2LoanAmt]
      ,[Mtg2Lender]
      ,[Mtg2LenderCode]
      ,[Mtg2LenderType]
      ,[Mtg2PrivateLender]
      ,[Mtg2LoanDueDt]
      ,[Mtg2AdjRider]
      ,[Mtg2LoanType]
      ,[Mtg2Typefinancing]
      ,[Mtg2LienPosition]
      ,[Mtg3TransactionId]
      ,[Mtg3ChronoKey]
      ,[Mtg3InputDocNbr]
      ,[Mtg3InputBook]
      ,[Mtg3InputPage]
      ,[Mtg3FormatDocNbr]
      ,[Mtg3FormatBook]
      ,[Mtg3FormatPage]
      ,[Mtg3RecordingDt]
      ,[Mtg3LoanAmt]
      ,[Mtg3Lender]
      ,[Mtg3LenderCode]
      ,[Mtg3LenderType]
      ,[Mtg3PrivateLender]
      ,[Mtg3LoanDueDt]
      ,[Mtg3AdjRider]
      ,[Mtg3LoanType]
      ,[Mtg3Typefinancing]
      ,[Mtg3LienPosition]
      ,[Mtg4TransactionId]
      ,[Mtg4ChronoKey]
      ,[Mtg4InputDocNbr]
      ,[Mtg4InputBook]
      ,[Mtg4InputPage]
      ,[Mtg4FormatDocNbr]
      ,[Mtg4FormatBook]
      ,[Mtg4FormatPage]
      ,[Mtg4RecordingDt]
      ,[Mtg4LoanAmt]
      ,[Mtg4Lender]
      ,[Mtg4LenderCode]
      ,[Mtg4LenderType]
      ,[Mtg4PrivateLender]
      ,[Mtg4LoanDueDt]
      ,[Mtg4AdjRider]
      ,[Mtg4LoanType]
      ,[Mtg4Typefinancing]
      ,[Mtg4LienPosition]
      ,[PrevSaleTransactionId]
      ,[PrevSaleChronoKey]
      ,[PrevSaleInputDocNbr]
      ,[PrevSaleInputBook]
      ,[PrevSaleInputPage]
      ,[PrevSaleFormatDocNbr]
      ,[PrevSaleFormatBook]
      ,[PrevSaleFormatPage]
      ,[PrevSaleRecordingDate]
      ,[PrevSalesPrice]
      ,[PrevSalesPriceCode]
      ,[PrevSaleContractDate]
      ,[PrevSaleBuyer1FullName]
      ,[PrevSaleBuyer2FullName]
      ,[PrevSaleBuyer3FullName]
      ,[PrevSaleBuyer4FullName]
      ,[PrevSaleSeller1FullName]
      ,[PrevSaleSeller2FullName]
      ,[PrevMtg1InputDocNbr]
      ,[PrevMtg1InputBook]
      ,[PrevMtg1InputPage]
      ,[PrevMtg1FormatDocNbr]
      ,[PrevMtg1FormatBook]
      ,[PrevMtg1FormatPage]
      ,[PrevMtg1RecordingDt]
      ,[PrevMtg1LoanAmt]
      ,[PrevMtg1Lender]
      ,[PrevMtg1LenderCode]
      ,[PrevMtg1LenderType]
      ,[PrevMtg1PrivateLender]
      ,[PrevMtg1LoanDueDt]
      ,[PrevMtg1AdjRider]
      ,[PrevMtg1LoanType]
      ,[PrevMtg1Typefinancing]
      ,[EditionNumber]
      ,[VersionId]
      ,[VendorLoadDate]
      ,[FASourceInd]
      ,@DateTime as [FATimestamp]
      ,[FAUserId]
      ,[FACreateDt]
      ,[FADeriveProcessDt]
      ,[FAEnhanceprocessDt]
      ,[FAOwnershipUpdateDt]
      ,[FAActiveDt]
      ,[SitusDPVCount]
      ,[SitusDPVFootnote]
      ,[SitusLACS]
      ,[SitusLACSLinkInd]
      ,[SitusDPCheckDigit]
      ,[SitusDPCheckCode]
      ,[SitusCensusBlock]
      ,[SitusGeoErrorCode]
      ,[SitusGeoStatusCode]
      ,[MailingDPVCount]
      ,[MailingDPVFootnote]
      ,[MailingLACS]
      ,[MailingLACSLinkInd]
      ,[MailingDPCheckDigit]
      ,[MailingDPCheckCode]
      ,[MailingCensusBlock]
      ,[MailingCensusTract]
      ,[MailingGeoErrorCode]
      ,[MailingGeoStatusCode]
      ,[CheckOwnership]
      ,[Mtg1InputDocNbr]
      ,[Mtg1InputBook]
      ,[Mtg1FormatDocNbr]
      ,[Mtg1FormatBook]
      ,[Mtg1FormatPage]
      ,[Mtg1RecordingDt]
      ,[Mtg1InputPage]
      ,'C' as [FAUCIDFlag]
      ,@DATE as [FADateReceived]
      ,[FAAddressParsedSitus]
      ,[FAAddressParsedMailing]
      ,[FACLTV]
      ,[FAOLTV]
      ,[FALatitude]
      ,[FALongitude]
      ,[FAEstLotSqFt]
      ,[FAOwnerTransactionId]
      ,[MailForeignAddrInd]
      ,[FAIsListedFlag]
      ,[FAIsListedFlagDt]
      ,[FAIsListedPriceRange]
      ,[TPLatitude]
      ,[TPLongitude]
      ,[TPGeoStatusCode]
      ,[FAGeoStatusCode]
      ,[SumCommercialUnits]
      ,[SitusGeoCodeResults]
      ,[MailingGeoCodeResults]
      ,[LienPosUpdateFlag]
      ,[LienPosUpdateDate]
      ,[TotalOpenLienAmt]
      ,[TotalOpenLienNbr]
      ,[VacantFlag]
      ,[VacantFlagDate]
      ,[AssessorLkupToken0]
      ,[AssessorLkupToken1]
      ,[SchoolDistrictName]
      ,[AssessorLkupToken2]
      ,[FADataArchiveDate]
      ,[ConCurrMtg2Term]
      ,[Mtg1Term]
      ,[Mtg2Term]
      ,[Mtg3Term]
      ,[Mtg4Term]
      ,[PrevMtg1Term]
      ,[BankOwned]
      ,[StoriesCode]
      ,[StoriesNbrCode]
      ,[BasementFinishSqFt]
      ,[BasementUnfinSqFt]
      ,[GarageFinishSqFt]
      ,[GarageUnFinSqFt]
      ,[AtticSqFt]
      ,[AtticFinishSqFt]
      ,[AtticUnfinSqFt]
      ,[Mtg1EstPaymentAmt]
      ,[Mtg1InterestRate]
      ,[Mtg2EstPaymentAmt]
      ,[Mtg2InterestRate]
      ,[Mtg3EstPaymentAmt]
      ,[Mtg3InterestRate]
      ,[Mtg4EstPaymentAmt]
      ,[Mtg4InterestRate]
      ,[ConCurrMtg1InterestRate]
      ,[ConCurrMtg2InterestRate]
      ,[PrevMtg1InterestRate]
      ,[MailingFIPS]
      ,[DBSTaxAmount]
      ,[DBSTaxYear]
      ,[Mtg1EstLoanBalance]
      ,[Mtg2EstLoanBalance]
      ,[Mtg3EstLoanBalance]
      ,[Mtg4EstLoanBalance]
      ,[OldApnIndicator]
      ,[PrevSaleDocumentType]
      ,[SecondPrevSaleTransactionId]
      ,[SecondPrevSaleRecordingDate]
      ,[SecondPrevSalesPrice]
      ,[ThirdPrevSaleTransactionId]
      ,[ThirdPrevSaleRecordingDate]
      ,[ThirdPrevSalesPrice]
      ,[HouseFacingDirection]
      ,[FARooftopLatitude]
      ,[FARooftopLongitude]
      ,[BuildingEstFootprintSqFt]
      ,[BathTotalCalcEst]
      ,[DQOZ_TractType]
      ,[DQOZ_ACSDataSource]
      ,[VacantScore]
      ,[BedroomsEst]
      ,[DTDB_Ref_ID]
      ,[DTDB_FORMATTED_APN]
      ,[MailingLabelName]
      ,[Name1TypeInd]
      ,[Name2TypeInd]
      ,[TaxSourceInd]
      ,[FASubdivisionName]
      ,[FAComplexNbrUnits]
      ,[FASubdivisionNameID]
      ,[FASubdivisionPhase]
      ,[ElevatorCode]
      ,[FAEstimatedMultiPolygonFlag]
      ,[FAEstimatedNumberofBuildings]
      ,[Poverty]
      ,[UnEmployment]
      ,[PopulationLoss]
      ,[RemoteRural]
      ,[Distressed]
      ,[UnderServed]
      ,[DTDB_UNFORMATTED_APN]
      ,[ConformingLoanLimitYear]
      ,[ConformingLoanLimit]
      ,[PriorConformingLoanLimitYear]
      ,[PriorConformingLoanLimit]
      ,[MTG1InterestRateSrce]
      ,[MTG2InterestRateSrce]
      ,[MTG3InterestRateSrce]
      ,[MTG4InterestRateSrce]
      ,[CS_FORMATTED_APN]
      ,[CS_UNFORMATTED_APN]
	  FROM [DragonAssr].[dbo].[PropertyWorkUpdate] 
	  WHERE isNULL(PropertyID,0) <> 0
	  
	  INSERT INTO Data.dbo.DailyPropID_II
	  Select Fips,PropertyID,@DATE,'P'
	  FROM [DragonAssr].[dbo].[PropertyWorkUpdate] 
	  WHERE isNULL(PropertyID,0) <> 0


	  UPDATE Global.dbo.County
	  SET FALastUpdateDate = @DATE
	   Where FIPSCode in(Select Distinct FIPS FROM [DragonAssr].[dbo].[PropertyWorkUpdate])


	   		--Declare @DATE varchar(8) = convert(varchar(8),GetDate()+1,112)

 		DECLARE @New varchar(50) 
		SET @New = 'PropertyWorkUpdate_' + @DATE

		DECLARE @NewFULL varchar(50) = '[DragonAssr].[dbo].[' + @New + ']'

		IF object_id(@NewFULL) IS NOT NULL
             EXEC('DROP TABLE ' + @NewFULL + '');

		EXEC sp_RENAME 'PropertyWorkUpdate',@New

		--Drop table [DragonAssr].[dbo].[PropertyWorkUpdate]
		CREATE TABLE [DragonAssr].[dbo].[PropertyWorkUpdate](
			[FIPS] [char](5) NULL,
			[PropertyID] [bigint] NULL,
			[FormattedAPN] [varchar](45) NULL,
			[APNSeqNbr] [char](2) NULL,
			[UnformattedAPN] [varchar](45) NULL,
			[OldAPN] [varchar](31) NULL,
			[OLDAPNSeqNbr] [varchar](31) NULL,
			[TaxAccountNumber] [varchar](30) NULL,
			[RecordType] [varchar](2) NULL,
			[VendorPID] [bigint] NULL,
			[SitusStdFullStreetAddress] [varchar](116) NULL,
			[SitusStdHouseNbr] [varchar](30) NULL,
			[SitusStdHouseNbr2] [varchar](10) NULL,
			[SitusStdHouseNbrSuffix] [varchar](10) NULL,
			[SitusStdDirectionLeft] [varchar](2) NULL,
			[SitusStdStreet] [varchar](60) NULL,
			[SitusStdMode] [varchar](10) NULL,
			[SitusStdDirectionRight] [varchar](2) NULL,
			[SitusStdUnitNbr] [varchar](15) NULL,
			[SitusStdCity] [varchar](55) NULL,
			[SitusStdState] [varchar](2) NULL,
			[SitusStdZIP5] [varchar](9) NULL,
			[SitusStdZIP4] [varchar](4) NULL,
			[SitusLatitude] [float] NULL,
			[SitusLongitude] [float] NULL,
			[SitusStdCarrierCode] [varchar](4) NULL,
			[SitusCensusTract] [varchar](6) NULL,
			[SitusCensusTractBlock] [varchar](20) NULL,
			[SitusStdUnitType] [varchar](20) NULL,
			[SitusStdMatchCode] [varchar](30) NULL,
			[LotSizeSqFt] [varchar](15) NULL,
			[LotSizeAcres] [varchar](10) NULL,
			[LotSizeFrontageFeet] [varchar](10) NULL,
			[LotSizeDepthFeet] [varchar](10) NULL,
			[LotIrregularInd] [varchar](15) NULL,
			[LotUsableSize] [varchar](10) NULL,
			[PropertyClassID] [varchar](2) NULL,
			[StdLandUseCode] [char](5) NULL,
			[StateLandUseCode] [char](10) NULL,
			[CountyLandUseCode] [char](10) NULL,
			[CountyLandUseDescription] [varchar](45) NULL,
			[TimeshareCode] [char](1) NULL,
			[Zoning] [varchar](25) NULL,
			[SiteInfluenceCode] [varchar](10) NULL,
			[NeighborhoodCode] [varchar](10) NULL,
			[TopographyCode] [varchar](10) NULL,
			[MobileHomeInd] [varchar](15) NULL,
			[LotCode] [char](2) NULL,
			[LotNumber] [char](7) NULL,
			[LandLot] [char](10) NULL,
			[Block] [char](7) NULL,
			[Section] [char](7) NULL,
			[District] [varchar](12) NULL,
			[LegalUnit] [char](6) NULL,
			[Municipality] [varchar](30) NULL,
			[LegalSection] [varchar](30) NULL,
			[LegalTownship] [varchar](30) NULL,
			[LegalRange] [varchar](30) NULL,
			[Meridian] [varchar](30) NULL,
			[LegalQuarter] [varchar](30) NULL,
			[LegalQuarterQuarter] [varchar](30) NULL,
			[LegalDescription] [varchar](2000) NULL,
			[AssessorsMapRef1] [varchar](15) NULL,
			[AssessorsMapRef2] [varchar](15) NULL,
			[SubdivisionName] [varchar](40) NULL,
			[SubdivisionPhaseNbr] [char](7) NULL,
			[SubdivisionTractNbr] [char](10) NULL,
			[SubdivisionPlatBook] [char](10) NULL,
			[SubdivisionPlatPage] [char](10) NULL,
			[NewRecordType] [char](2) NULL,
			[SwiSCodeNY] [varchar](10) NULL,
			[MailingCareOfName] [varchar](80) NULL,
			[MailingStdFullStreetAddress] [varchar](116) NULL,
			[MailingStdHouseNbr] [varchar](30) NULL,
			[MailingStdHouseNbr2] [varchar](10) NULL,
			[MailingStdHouseNbrSuffix] [varchar](10) NULL,
			[MailingStdDirectionLeft] [varchar](2) NULL,
			[MailingStdStreet] [varchar](60) NULL,
			[MailingStdMode] [varchar](10) NULL,
			[MailingStdDirectionRight] [varchar](2) NULL,
			[MailingStdUnitNbr] [varchar](15) NULL,
			[MailingStdCity] [varchar](55) NULL,
			[MailingStdState] [varchar](2) NULL,
			[MailingStdZIP5] [varchar](9) NULL,
			[MailingStdZIP4] [varchar](9) NULL,
			[MailingStdCarrierCode] [varchar](4) NULL,
			[MailingStdUnitType] [varchar](20) NULL,
			[MailingStdMatchCode] [varchar](30) NULL,
			[MailingOptOut] [varchar](15) NULL,
			[MailingOptOutDate] [varchar](8) NULL,
			[OwnerOccupied] [char](1) NULL,
			[AbsenteeOwner] [char](1) NULL,
			[OwnerStdNAME1FULL] [varchar](80) NULL,
			[OwnerStdNAME2FULL] [varchar](80) NULL,
			[OwnerStdNAME3FULL] [varchar](80) NULL,
			[OwnerStdNAME4FULL] [varchar](80) NULL,
			[OwnerEtALIndicator] [varchar](5) NULL,
			[OwnerStd1CorpInd] [varchar](15) NULL,
			[OwnerStd1LastName] [varchar](30) NULL,
			[OwnerStd1FirstName] [varchar](30) NULL,
			[OwnerStd1MiddleName] [varchar](20) NULL,
			[OwnerStd1Suffix] [varchar](5) NULL,
			[OwnerStd1CorpName] [varchar](45) NULL,
			[OwnerStd1OwnershipRights] [varchar](5) NULL,
			[OwnerStd1RelationshipType] [varchar](5) NULL,
			[Owner1DoNotParse] [varchar](15) NULL,
			[OwnerStd2CorpInd] [varchar](15) NULL,
			[OwnerStd2LastName] [varchar](30) NULL,
			[OwnerStd2FirstName] [varchar](30) NULL,
			[OwnerStd2MiddleName] [varchar](20) NULL,
			[OwnerStd2Suffix] [varchar](5) NULL,
			[OwnerStd2CorpName] [varchar](45) NULL,
			[OwnerStd2OwnershipRights] [varchar](5) NULL,
			[OwnerStd2RelationshipType] [varchar](5) NULL,
			[Owner2DoNotParse] [varchar](15) NULL,
			[OwnerStd3CorpInd] [varchar](15) NULL,
			[OwnerStd3LastName] [varchar](30) NULL,
			[OwnerStd3FirstName] [varchar](30) NULL,
			[OwnerStd3MiddleName] [varchar](20) NULL,
			[OwnerStd3Suffix] [varchar](5) NULL,
			[OwnerStd3CorpName] [varchar](45) NULL,
			[OwnerStd3OwnershipRights] [varchar](5) NULL,
			[OwnerStd3RelationshipType] [varchar](5) NULL,
			[Owner3DoNotParse] [varchar](15) NULL,
			[OwnerStd4CorpInd] [varchar](15) NULL,
			[OwnerStd4LastName] [varchar](30) NULL,
			[OwnerStd4FirstName] [varchar](30) NULL,
			[OwnerStd4MiddleName] [varchar](20) NULL,
			[OwnerStd4Suffix] [varchar](5) NULL,
			[OwnerStd4CorpName] [varchar](45) NULL,
			[OwnerStd4OwnershipRights] [varchar](5) NULL,
			[OwnerStd4RelationshipType] [varchar](5) NULL,
			[Owner4DoNotParse] [varchar](15) NULL,
			[AssesseeStd1Name] [varchar](80) NULL,
			[AssesseeStd2Name] [varchar](80) NULL,
			[AssesseeNameIndicator] [varchar](1) NULL,
			[AssesseeNameIndicator2] [varchar](1) NULL,
			[Amenities] [varchar](10) NULL,
			[DrivewayCode] [varchar](10) NULL,
			[EasementInd] [varchar](15) NULL,
			[QualityCode] [varchar](10) NULL,
			[ViewInd] [varchar](15) NULL,
			[ViewCode] [varchar](10) NULL,
			[ViewQualityCode] [varchar](10) NULL,
			[WaterAccessableInd] [varchar](15) NULL,
			[WaterFeatureInd] [varchar](15) NULL,
			[WaterfrontCode] [varchar](10) NULL,
			[WaterfrontFeet] [varchar](15) NULL,
			[WaterfrontQualityCode] [varchar](10) NULL,
			[BuildingArea] [varchar](15) NULL,
			[BuildingAreaInd] [varchar](2) NULL,
			[TotalRooms] [varchar](15) NULL,
			[Bedrooms] [varchar](15) NULL,
			[BathTotalCalc] [numeric](5, 2) NULL,
			[BathFull] [varchar](15) NULL,
			[BathsParcialNbr] [varchar](15) NULL,
			[BathHalf] [varchar](15) NULL,
			[Bath1QTR] [varchar](15) NULL,
			[Bath3QTR] [varchar](15) NULL,
			[BathFixturesNbr] [varchar](15) NULL,
			[OtherRooms] [varchar](5) NULL,
			[AirConditioningCode] [varchar](15) NULL,
			[AirConditioningTypeCode] [varchar](15) NULL,
			[BasementCode] [varchar](15) NULL,
			[BasementFinishedCode] [varchar](15) NULL,
			[BuildingClassCode] [varchar](15) NULL,
			[BuildingConditionCode] [varchar](15) NULL,
			[BuildingQualityCode] [varchar](15) NULL,
			[ConstructionTypeCode] [varchar](15) NULL,
			[DeckCode] [varchar](15) NULL,
			[ElectricityCode] [varchar](15) NULL,
			[ExteriorWallsCode] [varchar](15) NULL,
			[FireplaceCode] [varchar](15) NULL,
			[FloorCoverCode] [varchar](15) NULL,
			[FloorTypeCode] [varchar](15) NULL,
			[FoundationInd] [varchar](15) NULL,
			[FrameCode] [varchar](15) NULL,
			[Garage] [varchar](15) NULL,
			[GarageParkingNbr] [varchar](15) NULL,
			[HeatCode] [varchar](15) NULL,
			[HeatingFuelTypeCode] [varchar](15) NULL,
			[InteriorWallsCode] [varchar](15) NULL,
			[PavingCode] [varchar](15) NULL,
			[PatioCode] [varchar](15) NULL,
			[PoolCode] [varchar](15) NULL,
			[PorchCode] [varchar](15) NULL,
			[RoofCoverCode] [varchar](15) NULL,
			[RoofTypeCode] [varchar](15) NULL,
			[SewerCode] [varchar](15) NULL,
			[ShapeCode] [varchar](15) NULL,
			[StoriesCode_OLD] [varchar](15) NULL,
			[StoriesNbrCode_OLD] [varchar](15) NULL,
			[StyleCode] [varchar](15) NULL,
			[WallExteriorCode] [varchar](15) NULL,
			[WallheightCode] [varchar](15) NULL,
			[WaterCode] [varchar](15) NULL,
			[YearBuilt] [varchar](4) NULL,
			[EffectiveYearBuilt] [varchar](4) NULL,
			[SumBuildingsNbr] [varchar](15) NULL,
			[SumAboveGradeLivingSqFt] [varchar](15) NULL,
			[SumAdjAreaSqFt] [varchar](15) NULL,
			[SumBasementSqFt] [varchar](15) NULL,
			[SumBuildingSqFt] [varchar](15) NULL,
			[SumGarageSqFt] [varchar](15) NULL,
			[SumGrossAreaSqFt] [varchar](15) NULL,
			[SumGroundFloorSqFt] [varchar](15) NULL,
			[SumLivingAreaSqFt] [varchar](15) NULL,
			[SumResidentialUnits] [varchar](15) NULL,
			[AssdLandValue] [varchar](15) NULL,
			[AssdImprovementValue] [varchar](15) NULL,
			[AssdTotalValue] [varchar](15) NULL,
			[AssdYear] [char](4) NULL,
			[MarketValueLand] [varchar](15) NULL,
			[MarketValueImprovement] [varchar](15) NULL,
			[MarketTotalValue] [varchar](15) NULL,
			[MarketValueYear] [char](4) NULL,
			[ApprLandValue] [varchar](15) NULL,
			[ApprImprovementValue] [varchar](15) NULL,
			[ApprTotalValue] [varchar](15) NULL,
			[ApprYear] [char](4) NULL,
			[TaxValueLand] [varchar](15) NULL,
			[TaxValueImprovement] [varchar](15) NULL,
			[TaxTotalValue] [varchar](15) NULL,
			[TaxableYear] [char](4) NULL,
			[UNVLandValue] [varchar](15) NULL,
			[UNVImprovementValue] [varchar](15) NULL,
			[UNVTotalValue] [varchar](15) NULL,
			[UNVValueYear] [char](4) NULL,
			[TaxRateCodeArea] [varchar](20) NULL,
			[TaxYear] [char](4) NULL,
			[TaxAmount] [bigint] NULL,
			[TaxDeliquentYear1] [char](4) NULL,
			[TaxDeliquentValue1] [varchar](15) NULL,
			[TaxExemptionCode] [varchar](10) NULL,
			[TaxexemptInd] [varchar](15) NULL,
			[CalifHomeownerInd] [varchar](15) NULL,
			[CemeteryInd] [varchar](15) NULL,
			[DisabledInd] [varchar](15) NULL,
			[HomesteadInd] [varchar](15) NULL,
			[HospitalInd] [varchar](15) NULL,
			[LibraryInd] [varchar](15) NULL,
			[PublicUtilityInd] [varchar](15) NULL,
			[ReligiousInd] [varchar](15) NULL,
			[SchoolCollegeInd] [varchar](15) NULL,
			[SeniorInd] [varchar](15) NULL,
			[VeteranInd] [varchar](15) NULL,
			[WelfareInd] [varchar](15) NULL,
			[WidowInd] [varchar](15) NULL,
			[SchoolTaxDistrict1Code] [varchar](15) NULL,
			[SchoolTaxDistrict1Ind] [char](1) NULL,
			[SchoolTaxDistrict2Code] [varchar](15) NULL,
			[SchoolTaxDistrict2Ind] [char](1) NULL,
			[SchoolTaxDistrict3Code] [varchar](15) NULL,
			[SchoolTaxDistrict3Ind] [char](1) NULL,
			[FADeleteFlag] [varchar](15) NULL,
			[FADeleteFlagDate] [datetime] NULL,
			[CurrentSaleTransactionId] [bigint] NULL,
			[CurrentSaleChronoKey] [varchar](31) NULL,
			[CurrSaleInputDocNbr] [varchar](20) NULL,
			[CurrSaleInputBook] [varchar](10) NULL,
			[CurrSaleInputPage] [varchar](10) NULL,
			[CurrSaleFormatDocNbr] [varchar](20) NULL,
			[CurrSaleFormatBook] [varchar](10) NULL,
			[CurrSaleFormatPage] [varchar](10) NULL,
			[CurrSaleRecordingDate] [varchar](8) NULL,
			[CurrSaleDocumentType] [varchar](30) NULL,
			[CurrSalesPrice] [varchar](15) NULL,
			[CurrSalesPriceCode] [varchar](5) NULL,
			[CurrSaleContractDate] [varchar](8) NULL,
			[CurrSaleBuyer1FullName] [varchar](60) NULL,
			[CurrSaleBuyer2FullName] [varchar](60) NULL,
			[CurrSaleBuyer3FullName] [varchar](60) NULL,
			[CurrSaleBuyer4FullName] [varchar](60) NULL,
			[CurrSaleSeller1FullName] [varchar](60) NULL,
			[CurrSaleSeller2FullName] [varchar](60) NULL,
			[ConCurrMtg1InputDocNbr] [varchar](20) NULL,
			[ConCurrMtg1InputBook] [varchar](10) NULL,
			[ConCurrMtg1InputPage] [varchar](10) NULL,
			[ConCurrMtg1FormatDocNbr] [varchar](20) NULL,
			[ConCurrMtg1FormatBook] [varchar](10) NULL,
			[ConCurrMtg1FormatPage] [varchar](10) NULL,
			[ConCurrMtg1RecordingDt] [varchar](10) NULL,
			[ConCurrMtg1LoanAmt] [varchar](15) NULL,
			[ConCurrMtg1Lender] [varchar](30) NULL,
			[ConCurrMtg1LenderCode] [varchar](10) NULL,
			[ConCurrMtg1LenderType] [varchar](5) NULL,
			[ConCurrMtg1PrivateLender] [varchar](15) NULL,
			[ConCurrMtg1Term] [varchar](3) NULL,
			[ConCurrMtg1LoanDueDt] [varchar](10) NULL,
			[ConCurrMtg1AdjOrFix] [varchar](1) NULL,
			[ConCurrMtg1LoanType] [varchar](10) NULL,
			[ConCurrMtg1Typefinancing] [varchar](10) NULL,
			[ConCurrMtg1LienPosition] [varchar](15) NULL,
			[ConCurrMtg2InputDocNbr] [varchar](20) NULL,
			[ConCurrMtg2InputBook] [varchar](10) NULL,
			[ConCurrMtg2InputPage] [varchar](10) NULL,
			[ConCurrMtg2FormatDocNbr] [varchar](20) NULL,
			[ConCurrMtg2FormatBook] [varchar](10) NULL,
			[ConCurrMtg2FormatPage] [varchar](10) NULL,
			[ConCurrMtg2RecordingDt] [varchar](10) NULL,
			[ConCurrMtg2LoanAmt] [varchar](15) NULL,
			[ConCurrMtg2Lender] [varchar](30) NULL,
			[ConCurrMtg2LenderCode] [varchar](10) NULL,
			[ConCurrMtg2LenderType] [varchar](5) NULL,
			[ConCurrMtg2PrivateLender] [varchar](15) NULL,
			[ConCurrMtg2LoanDueDt] [varchar](10) NULL,
			[ConCurrMtg2AdjOrFix] [varchar](1) NULL,
			[ConCurrMtg2LoanType] [varchar](10) NULL,
			[ConCurrMtg2Typefinancing] [varchar](10) NULL,
			[ConCurrMtg2LienPosition] [varchar](15) NULL,
			[Mtg1TransactionId] [bigint] NULL,
			[Mtg1ChronoKey] [varchar](31) NULL,
			[Mtg1LoanAmt] [int] NULL,
			[Mtg1Lender] [varchar](30) NULL,
			[Mtg1LenderCode] [varchar](10) NULL,
			[Mtg1LenderType] [varchar](10) NULL,
			[Mtg1PrivateLender] [varchar](15) NULL,
			[Mtg1LoanDueDt] [varchar](10) NULL,
			[Mtg1AdjRider] [varchar](1) NULL,
			[Mtg1LoanType] [varchar](10) NULL,
			[Mtg1Typefinancing] [varchar](10) NULL,
			[Mtg1LienPosition] [varchar](15) NULL,
			[Mtg2TransactionId] [bigint] NULL,
			[Mtg2ChronoKey] [varchar](31) NULL,
			[Mtg2InputDocNbr] [varchar](20) NULL,
			[Mtg2InputBook] [varchar](10) NULL,
			[Mtg2InputPage] [varchar](10) NULL,
			[Mtg2FormatDocNbr] [varchar](20) NULL,
			[Mtg2FormatBook] [varchar](10) NULL,
			[Mtg2FormatPage] [varchar](10) NULL,
			[Mtg2RecordingDt] [varchar](10) NULL,
			[Mtg2LoanAmt] [int] NULL,
			[Mtg2Lender] [varchar](30) NULL,
			[Mtg2LenderCode] [varchar](10) NULL,
			[Mtg2LenderType] [varchar](10) NULL,
			[Mtg2PrivateLender] [varchar](15) NULL,
			[Mtg2LoanDueDt] [varchar](10) NULL,
			[Mtg2AdjRider] [varchar](1) NULL,
			[Mtg2LoanType] [varchar](10) NULL,
			[Mtg2Typefinancing] [varchar](10) NULL,
			[Mtg2LienPosition] [varchar](15) NULL,
			[Mtg3TransactionId] [bigint] NULL,
			[Mtg3ChronoKey] [varchar](31) NULL,
			[Mtg3InputDocNbr] [varchar](20) NULL,
			[Mtg3InputBook] [varchar](10) NULL,
			[Mtg3InputPage] [varchar](10) NULL,
			[Mtg3FormatDocNbr] [varchar](20) NULL,
			[Mtg3FormatBook] [varchar](10) NULL,
			[Mtg3FormatPage] [varchar](10) NULL,
			[Mtg3RecordingDt] [varchar](10) NULL,
			[Mtg3LoanAmt] [int] NULL,
			[Mtg3Lender] [varchar](30) NULL,
			[Mtg3LenderCode] [varchar](10) NULL,
			[Mtg3LenderType] [varchar](10) NULL,
			[Mtg3PrivateLender] [varchar](15) NULL,
			[Mtg3LoanDueDt] [varchar](10) NULL,
			[Mtg3AdjRider] [varchar](1) NULL,
			[Mtg3LoanType] [varchar](10) NULL,
			[Mtg3Typefinancing] [varchar](10) NULL,
			[Mtg3LienPosition] [varchar](15) NULL,
			[Mtg4TransactionId] [bigint] NULL,
			[Mtg4ChronoKey] [varchar](31) NULL,
			[Mtg4InputDocNbr] [varchar](20) NULL,
			[Mtg4InputBook] [varchar](10) NULL,
			[Mtg4InputPage] [varchar](10) NULL,
			[Mtg4FormatDocNbr] [varchar](20) NULL,
			[Mtg4FormatBook] [varchar](10) NULL,
			[Mtg4FormatPage] [varchar](10) NULL,
			[Mtg4RecordingDt] [varchar](10) NULL,
			[Mtg4LoanAmt] [int] NULL,
			[Mtg4Lender] [varchar](30) NULL,
			[Mtg4LenderCode] [varchar](10) NULL,
			[Mtg4LenderType] [varchar](10) NULL,
			[Mtg4PrivateLender] [varchar](15) NULL,
			[Mtg4LoanDueDt] [varchar](10) NULL,
			[Mtg4AdjRider] [varchar](1) NULL,
			[Mtg4LoanType] [varchar](10) NULL,
			[Mtg4Typefinancing] [varchar](10) NULL,
			[Mtg4LienPosition] [varchar](15) NULL,
			[PrevSaleTransactionId] [bigint] NULL,
			[PrevSaleChronoKey] [varchar](31) NULL,
			[PrevSaleInputDocNbr] [varchar](20) NULL,
			[PrevSaleInputBook] [varchar](10) NULL,
			[PrevSaleInputPage] [varchar](10) NULL,
			[PrevSaleFormatDocNbr] [varchar](20) NULL,
			[PrevSaleFormatBook] [varchar](10) NULL,
			[PrevSaleFormatPage] [varchar](10) NULL,
			[PrevSaleRecordingDate] [varchar](8) NULL,
			[PrevSalesPrice] [int] NULL,
			[PrevSalesPriceCode] [varchar](5) NULL,
			[PrevSaleContractDate] [varchar](8) NULL,
			[PrevSaleBuyer1FullName] [varchar](60) NULL,
			[PrevSaleBuyer2FullName] [varchar](60) NULL,
			[PrevSaleBuyer3FullName] [varchar](60) NULL,
			[PrevSaleBuyer4FullName] [varchar](60) NULL,
			[PrevSaleSeller1FullName] [varchar](60) NULL,
			[PrevSaleSeller2FullName] [varchar](60) NULL,
			[PrevMtg1InputDocNbr] [varchar](20) NULL,
			[PrevMtg1InputBook] [varchar](10) NULL,
			[PrevMtg1InputPage] [varchar](10) NULL,
			[PrevMtg1FormatDocNbr] [varchar](20) NULL,
			[PrevMtg1FormatBook] [varchar](10) NULL,
			[PrevMtg1FormatPage] [varchar](10) NULL,
			[PrevMtg1RecordingDt] [varchar](10) NULL,
			[PrevMtg1LoanAmt] [int] NULL,
			[PrevMtg1Lender] [varchar](30) NULL,
			[PrevMtg1LenderCode] [varchar](10) NULL,
			[PrevMtg1LenderType] [varchar](5) NULL,
			[PrevMtg1PrivateLender] [varchar](15) NULL,
			[PrevMtg1LoanDueDt] [varchar](10) NULL,
			[PrevMtg1AdjRider] [varchar](1) NULL,
			[PrevMtg1LoanType] [varchar](10) NULL,
			[PrevMtg1Typefinancing] [varchar](10) NULL,
			[EditionNumber] [char](2) NULL,
			[VersionId] [numeric](9, 0) NULL,
			[VendorLoadDate] [varchar](8) NULL,
			[FASourceInd] [varchar](2) NULL,
			[FATimestamp] [datetime2](7) NULL,
			[FAUserId] [varchar](50) NULL,
			[FACreateDt] [datetime2](7) NULL,
			[FADeriveProcessDt] [datetime2](7) NULL,
			[FAEnhanceprocessDt] [datetime2](7) NULL,
			[FAOwnershipUpdateDt] [datetime2](7) NULL,
			[FAActiveDt] [datetime2](7) NULL,
			[SitusDPVCount] [char](5) NULL,
			[SitusDPVFootnote] [char](4) NULL,
			[SitusLACS] [char](1) NULL,
			[SitusLACSLinkInd] [char](1) NULL,
			[SitusDPCheckDigit] [char](1) NULL,
			[SitusDPCheckCode] [char](2) NULL,
			[SitusCensusBlock] [char](4) NULL,
			[SitusGeoErrorCode] [char](1) NULL,
			[SitusGeoStatusCode] [char](1) NULL,
			[MailingDPVCount] [char](5) NULL,
			[MailingDPVFootnote] [char](4) NULL,
			[MailingLACS] [char](1) NULL,
			[MailingLACSLinkInd] [char](1) NULL,
			[MailingDPCheckDigit] [char](1) NULL,
			[MailingDPCheckCode] [char](2) NULL,
			[MailingCensusBlock] [char](4) NULL,
			[MailingCensusTract] [char](6) NULL,
			[MailingGeoErrorCode] [char](1) NULL,
			[MailingGeoStatusCode] [char](1) NULL,
			[CheckOwnership] [varchar](1) NULL,
			[Mtg1InputDocNbr] [varchar](20) NULL,
			[Mtg1InputBook] [varchar](10) NULL,
			[Mtg1FormatDocNbr] [varchar](20) NULL,
			[Mtg1FormatBook] [varchar](10) NULL,
			[Mtg1FormatPage] [varchar](10) NULL,
			[Mtg1RecordingDt] [varchar](10) NULL,
			[Mtg1InputPage] [varchar](10) NULL,
			[FAUCIDFlag] [char](1) NULL,
			[FADateReceived] [varchar](8) NULL,
			[FAAddressParsedSitus] [datetime] NULL,
			[FAAddressParsedMailing] [datetime] NULL,
			[FACLTV] [decimal](10, 2) NULL,
			[FAOLTV] [decimal](10, 2) NULL,
			[FALatitude] [float] NULL,
			[FALongitude] [float] NULL,
			[FAEstLotSqFt] [bigint] NULL,
			[FAOwnerTransactionId] [bigint] NULL,
			[MailForeignAddrInd] [varchar](1) NULL,
			[FAIsListedFlag] [char](1) NULL,
			[FAIsListedFlagDt] [varchar](8) NULL,
			[FAIsListedPriceRange] [varchar](25) NULL,
			[TPLatitude] [float] NULL,
			[TPLongitude] [float] NULL,
			[TPGeoStatusCode] [varchar](20) NULL,
			[FAGeoStatusCode] [varchar](20) NULL,
			[SumCommercialUnits] [varchar](15) NULL,
			[SitusGeoCodeResults] [varchar](30) NULL,
			[MailingGeoCodeResults] [varchar](30) NULL,
			[LienPosUpdateFlag] [varchar](1) NULL,
			[LienPosUpdateDate] [datetime] NULL,
			[TotalOpenLienAmt] [varchar](15) NULL,
			[TotalOpenLienNbr] [varchar](15) NULL,
			[VacantFlag] [varchar](1) NULL,
			[VacantFlagDate] [datetime] NULL,
			[AssessorLkupToken0] [varchar](50) NULL,
			[AssessorLkupToken1] [varchar](50) NULL,
			[SchoolDistrictName] [varchar](80) NULL,
			[AssessorLkupToken2] [varchar](50) NULL,
			[FADataArchiveDate] [datetime] NULL,
			[ConCurrMtg2Term] [varchar](3) NULL,
			[Mtg1Term] [varchar](3) NULL,
			[Mtg2Term] [varchar](3) NULL,
			[Mtg3Term] [varchar](3) NULL,
			[Mtg4Term] [varchar](3) NULL,
			[PrevMtg1Term] [varchar](3) NULL,
			[BankOwned] [varchar](1) NULL,
			[StoriesCode] [varchar](10) NULL,
			[StoriesNbrCode] [varchar](10) NULL,
			[BasementFinishSqFt] [varchar](11) NULL,
			[BasementUnfinSqFt] [varchar](11) NULL,
			[GarageFinishSqFt] [varchar](11) NULL,
			[GarageUnFinSqFt] [varchar](11) NULL,
			[AtticSqFt] [varchar](11) NULL,
			[AtticFinishSqFt] [varchar](11) NULL,
			[AtticUnfinSqFt] [varchar](11) NULL,
			[Mtg1EstPaymentAmt] [varchar](15) NULL,
			[Mtg1InterestRate] [varchar](6) NULL,
			[Mtg2EstPaymentAmt] [varchar](15) NULL,
			[Mtg2InterestRate] [varchar](6) NULL,
			[Mtg3EstPaymentAmt] [varchar](15) NULL,
			[Mtg3InterestRate] [varchar](6) NULL,
			[Mtg4EstPaymentAmt] [varchar](15) NULL,
			[Mtg4InterestRate] [varchar](6) NULL,
			[ConCurrMtg1InterestRate] [varchar](6) NULL,
			[ConCurrMtg2InterestRate] [varchar](6) NULL,
			[PrevMtg1InterestRate] [varchar](6) NULL,
			[MailingFIPS] [varchar](5) NULL,
			[DBSTaxAmount] [bigint] NULL,
			[DBSTaxYear] [varchar](4) NULL,
			[Mtg1EstLoanBalance] [int] NULL,
			[Mtg2EstLoanBalance] [int] NULL,
			[Mtg3EstLoanBalance] [int] NULL,
			[Mtg4EstLoanBalance] [int] NULL,
			[OldApnIndicator] [varchar](1) NULL,
			[PrevSaleDocumentType] [varchar](2) NULL,
			[SecondPrevSaleTransactionId] [bigint] NULL,
			[SecondPrevSaleRecordingDate] [varchar](8) NULL,
			[SecondPrevSalesPrice] [varchar](15) NULL,
			[ThirdPrevSaleTransactionId] [bigint] NULL,
			[ThirdPrevSaleRecordingDate] [varchar](8) NULL,
			[ThirdPrevSalesPrice] [varchar](15) NULL,
			[HouseFacingDirection] [varchar](2) NULL,
			[FARooftopLatitude] [float] NULL,
			[FARooftopLongitude] [float] NULL,
			[BuildingEstFootprintSqFt] [varchar](15) NULL,
			[BathTotalCalcEst] [numeric](5, 2) NULL,
			[DQOZ_TractType] [varchar](50) NULL,
			[DQOZ_ACSDataSource] [varchar](10) NULL,
			[VacantScore] [varchar](3) NULL,
			[BedroomsEst] [varchar](15) NULL,
			[DTDB_Ref_ID] [bigint] NULL,
			[DTDB_FORMATTED_APN] [varchar](60) NULL,
			[MailingLabelName] [varchar](100) NULL,
			[Name1TypeInd] [varchar](15) NULL,
			[Name2TypeInd] [varchar](15) NULL,
			[TaxSourceInd] [varchar](2) NULL,
			[FASubdivisionName] [varchar](40) NULL,
			[FAComplexNbrUnits] [varchar](15) NULL,
			[FASubdivisionNameID] [varchar](15) NULL,
			[FASubdivisionPhase] [varchar](5) NULL,
			[ElevatorCode] [varchar](3) NULL,
			[FAEstimatedMultiPolygonFlag] [varchar](1) NULL,
			[FAEstimatedNumberofBuildings] [varchar](15) NULL,
			[Poverty] [varchar](1) NULL,
			[UnEmployment] [varchar](1) NULL,
			[PopulationLoss] [varchar](1) NULL,
			[RemoteRural] [varchar](1) NULL,
			[Distressed] [varchar](1) NULL,
			[UnderServed] [varchar](1) NULL,
			[DTDB_UNFORMATTED_APN] [varchar](60) NULL,
			[ConformingLoanLimitYear] [varchar](4) NULL,
			[ConformingLoanLimit] [int] NULL,
			[PriorConformingLoanLimitYear] [varchar](4) NULL,
			[PriorConformingLoanLimit] [int] NULL,
			[MTG1InterestRateSrce] varchar(2) NULL,
			[MTG2InterestRateSrce] varchar(2) NULL,
			[MTG3InterestRateSrce] varchar(2) NULL,
			[MTG4InterestRateSrce] varchar(2) NULL,
			[CS_FORMATTED_APN] varchar(60) NULL,
			[CS_UNFORMATTED_APN] varchar(60) NULL,
			[SPOT_ID] bigint NULL,
			[CERTIFICATION_DATE] date NULL
		) ON [PRIMARY]

		/****** Object:  Index [ix_FipsAPN]    Script Date: 12/30/2020 7:30:18 AM ******/
		CREATE NONCLUSTERED INDEX [ix_FipsAPN] ON [dbo].[PropertyWorkUpdate]
		([FIPS] ASC,	[FormattedAPN] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsDTDB_Ref_ID] ON [dbo].[PropertyWorkUpdate]
		([FIPS] ASC,[DTDB_Ref_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[PropertyWorkUpdate]
		([FIPS] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


		INSERT INTO DragonProcessingTracker
		Select 'Rename Update Finish ' + @DATE as ProcessingStep,GETDATE() as ProcessingStartTime 



END
