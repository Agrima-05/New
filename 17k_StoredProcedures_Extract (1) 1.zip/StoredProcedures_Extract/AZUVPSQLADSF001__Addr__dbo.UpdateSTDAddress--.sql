SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create procedure [dbo].[UpdateSTDAddress--] (@fips int) as
 Update d
		SET  d.STD_FIPS = a.FIPS
       ,   d.STD_StreetNumber = a.StreetNumber
      ,   d.STD_PreDirection =a.PreDirection
      ,   d.STD_StreetName =a.StreetName
      ,   d.STD_Suffix =a.Suffix
      ,   d.STD_PostDirection =a.PostDirection
      ,   d.STD_UnitType =a.UnitType
      ,   d.STD_Unit =a.Unit
      ,   d.STD_City =a.City
      ,   d.STD_State =a.State
      ,   d.STD_Zip =a.Zip
      ,   d.STD_Plus4 =a.Plus4
      ,   d.STD_CRRT =a.CRRT
      ,   d.STD_CountyName =a.CountyName
      ,   d.STD_PMB =a.PMB
      ,   d.STD_PMSA =a.PMSA
      ,   d.STD_MSA =a.MSA
      ,   d.STD_ZipType =a.ZipType
      ,   d.STD_Urbanization =a.Urbanization
      ,   d.STD_CongressionalDistrict =a.CongressionalDistrict
      ,   d.STD_CountryCode =a.CountryCode
      ,   d.STD_CityAbbreviation =a.CityAbbreviation
      ,   d.STD_AddressTypeCode =a.AddressTypeCode
      ,   d.STD_AddressTypeString =a.AddressTypeString
      ,   d.STD_DPV_Count =a.DPV_Count
      ,   d.STD_DPV_Footnotes =a.DPV_Footnotes
      ,   d.STD_CMRA =a.CMRA
      ,   d.STD_ELOT_Number =a.ELOT_Number
      ,   d.STD_ELOT_Order =a.ELOT_Order
      ,   d.STD_LACS =a.LACS
      ,   d.STD_LACS_LinkIndicator =a.LACS_LinkIndicator
      ,   d.STD_EWS_Flag =a.EWS_Flag
      ,   d.STD_RBDI =a.RBDI
      ,   d.STD_SuiteLinkReturnCode =a.SuiteLinkReturnCode
      ,   d.STD_DeliveryPointCheckDigit =a.DeliveryPointCheckDigit
      ,   d.STD_DeliveryPointCode =a.DeliveryPointCode
      ,   d.STD_CensusBlock =a.CensusBlock
      ,   d.STD_CensusTract =a.CensusTract
      ,   d.STD_PlaceCode =a.PlaceCode
      ,   d.STD_PlaceName =a.PlaceName
      ,   d.STD_CBSA_Code =a.CBSA_Code
      ,   d.STD_CBSA_Level =a.CBSA_Level
      ,   d.STD_CBSA_Title =a.CBSA_Title
      ,   d.STD_CBSA_DivisionCode =a.CBSA_DivisionCode
      ,   d.STD_CBSA_DivisionLevel =a.CBSA_DivisionLevel
      ,   d.STD_CBSA_DivisionTitle =a.CBSA_DivisionTitle
      ,   d.STD_Latitude =a.Latitude
      ,   d.STD_Longitude =a.Longitude
      ,   d.STD_AddressMatchResults =a.AddressMatchResults
      ,   d.STD_Verified =a.Verified
      ,   d.STD_Geocoded =a.Geocoded
      ,   d.STD_GeoErrorCode =a.GeoErrorCode
      ,   d.STD_GeoStatusCode =a.GeoStatusCode
       from addr.dbo.DMaddr1231 d, Address_20121231.dbo.Address_STD a
      where  d.fips = @fips
      and   d.PARCEL_APN = a.PARCEL_APN
      and len(d.PARCEL_APN)<>0


