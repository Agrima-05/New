SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankDeedSupBuyermailPost] (@tableName varchar(40)) -- @tableName = 'Deed_Sup_Buyermail' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild BuyermailFullStreetAddress and BuyermailCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Deed_Sup_Buyermail_STD]
	   --set [BuyerMailFullAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailLeftDirection])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailStreetName]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailMode]))) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailRightDirection]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitNumber])))))))
       set [BuyerMailFullAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailLeftDirection]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailStreetName])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailRightDirection])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitNumber]))))
       ,[BuyerMailHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailHouseNbr]))
       ,[BuyerMailLeftDirection] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailLeftDirection]))
       ,[BuyerMailStreetName] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailStreetName])))
       ,[BuyerMailMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailMode])))
       ,[BuyerMailRightDirection] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailRightDirection]))
       ,[BuyerMailUnitNumber] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitNumber]))
       ,[BuyerMailCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailCity])))
       ,[BuyerMailState] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailState]))
       ,[BuyerMailZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailZIP5]))
       ,[BuyerMailZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailZIP4]))
       ,[BuyerMailCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailCarrierCode]))
	   ,[BuyerMailCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailCensusTract]))
       ,[BuyerMailUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailUnitType])))
       ,[BuyerMailDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailDPVCount]))
       ,[BuyerMailDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailDPVFootnote]))
       ,[BuyerMailLACS] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailLACS]))
       ,[BuyerMailLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailLACSLinkInd]))
       ,[BuyerMailDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailDPCheckDigit]))
       ,[BuyerMailDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailDPCheckCode]))
       ,[BuyerMailCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailCensusBlock]))
	   ,[BuyerMailStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailStdMatchCode]))
       ,[BuyerMailGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailGeoErrorCode]))
       ,[BuyerMailGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailGeoStatusCode]))
       ,[BuyerMailGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[BuyerMailGeoCodeResults]))
	   ,[FIPS] = CASE WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[FIPS]))) = 1 THEN NULL 
	             WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[FIPS]))) = 4 THEN ''0'' + ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[FIPS])) 
				 ELSE ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Buyermail_STD].[FIPS])) END
	 From [AddressSTD].[dbo].[Deed_Sup_Buyermail_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Deed_Sup_Buyermail_to_Licensing

