SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

                     CREATE procedure [dbo].[usp_101_sp_AddressMaster_ASPInput](@tableName varchar(40)) -- @tableName = 'AddressMaster_ASP' (from Addr.dbo.STDTrigger.TableName)
                     as  
                     declare @sql varchar(max) = ''  

                     -- Create table_STD
                     set @sql = '  
                     IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
                     DROP TABLE ' + rtrim(@tableName) + '_STD'  
                     print(@sql)
                     exec (@sql)  
                     print(2)
                           set @sql = '  
                           create table dbo.' + rtrim(@tableName) + '_STD (' + '  
                                [RecordId] [bigint] NOT NULL,
								[AddressLine] [varchar](120) NULL,
								[Address2] [varchar](20) NULL,
								[CityStateZip] [varchar](41) NULL,
								[PreDir] [varchar](4) NULL,
								[StreetNumber] [varchar](30) NULL,
								[StreetName] [varchar](60) NULL,
								[PostDir] [varchar](4) NULL,
								[StreetType] [varchar](10) NULL,
								[SuiteType] [varchar](20) NULL,
								[Suite] [varchar](32) NULL,
								[City] [varchar](28) NULL,
								[State] [varchar](3) NULL,
								[Zip] [varchar](6) NULL,
								[Plus4] [varchar](5) NULL,
								[PrivateMailbox] [varchar](10) NULL,
								[Pmsa] [varchar](1) NULL,
								[Msa] [varchar](1) NULL,
								[ZipType] [varchar](2) NULL,
								[Urbanization] [varchar](1) NULL,
								[TimeZoneCode] [varchar](3) NULL,
								[TimeZone] [varchar](14) NULL,
								[CongressionalDistrict] [varchar](3) NULL,
								[CountryCode] [varchar](3) NULL,
								[CountyFips] [varchar](5) NULL,
								[CountyName] [varchar](55) NULL,
								[CityAbbreviation] [varchar](14) NULL,
								[AddressTypeString] [varchar](17) NULL,
								[AddressTypeCode] [varchar](3) NULL,
								[DPVFootnotes] [varchar](7) NULL,
								[CarrierRoute] [varchar](5) NULL,
								[ELotOrder] [varchar](2) NULL,
								[ELotNumber] [varchar](6) NULL,
								[Lacs] [varchar](2) NULL,
								[LACSLinkIndicator] [varchar](2) NULL,
								[LACSLinkReturnCode] [varchar](3) NULL,
								[EWSFlag] [varchar](2) NULL,
								[RBDI] [varchar](2) NULL,
								[SuiteLinkReturnCode] [varchar](3) NULL,
								[AddressMatchResults] [varchar](45) NULL,
								[AddressMatchResultString] [varchar](2000) NULL,
								[DeliveryPointCheckDigit] [varchar](2) NULL,
								[DeliveryPointCode] [varchar](3) NULL,
								[Latitude] [float] NULL,
								[Longitude] [float] NULL,
								[GeoErrorCode] [varchar](2) NULL,
								[GeoStatusCode] [varchar](2) NULL,
								[GeoCodeResults] [varchar](5) NULL,
								[CensusTract] [varchar](7) NULL,
								[CensusBlock] [varchar](5) NULL,
								[PlaceCode] [varchar](8) NULL,
								[PlaceName] [varchar](58) NULL,
								[CBSACode] [varchar](6) NULL,
								[CBSALevel] [varchar](30) NULL,
								[CBSATitle] [varchar](47) NULL,
								[CBSADivisionCode] [varchar](6) NULL,
								[CBSADivisionTitle] [varchar](51) NULL,
								[CBSADivisionLevel] [varchar](30) NULL,
								[CMRA] [varchar](2) NULL,
								[Verified] [int] NULL,
								[Geocoded] [int] NULL,
								[DsfNoStats] [varchar](2) NULL,
								[DsfDNA] [varchar](2) NULL,
                                [DPVCount] [varchar](5) NULL,
                                [raw_id] [varchar] (100) NULL
                              )
                           '  
                     print @sql
                     exec (@sql)
                     print (3)

                     --Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

                     set @sql = '  
                     SELECT RecordId  as id  ,  '''' as HouseNumber
                             , 0 as FIPS, isnull([AddressLine], '''') AddressLine ,isnull(City, '''') as city  ,isnull(State, '''') as state  ,
                     isnull(Zip, '''') as zip  
                     FROM ' + @tableName +   
                        ' WITH (NOLOCK) ORDER BY Zip desc'  

                     exec (@sql) 
                     --truncate table AddressMaster.[dbo].AddressMaster_ASP
                     
