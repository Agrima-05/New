SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create proc [dbo].[updatedmaddr1213--] (@start varchar (20), @end varchar(20)) as
declare @sql varchar(max) = ''
set @sql = '
update a set parcel = b.parcel, points = b.points

  FROM [AddrBase].[dbo].[DMaddr1231] a, [Addr06].[dbo].[DMaddr1231] b
  where a.id = b.ID
  and a.id >= ' + @start + ' and a.id <= ' + @end 
  
  exec (@sql)  


