SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[usp_101_MatchUnmatchedByRefId] 
AS
BEGIN
	SET NOCOUNT ON;

--/****** Object:  Table [dbo].[z_FADigitalMapParcelNoPoint]    Script Date: 2/24/2016 8:05:56 AM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[m_FADigitalMapParcelNoPoint](
--	[PropertyID] [bigint] NULL,
--	[APN] [varchar](45) NULL,
--	[FIPS] [varchar](5) NULL,
--	[Latitude] [float] NULL,
--	[Longitude] [float] NULL,
--	[ParcelGeography] [geography] NULL,
--	[ParcelGeometry] [geometry] NULL,
--	[ParcelPointGeography] [geography] NULL,
--	[ParcelPointGeometry] [geometry] NULL,
--	[EstLotSizeSqFt] [bigint] NULL,
--	[AddressScore] [varchar](1) NULL,
--	[GeoSource] [varchar](30) NULL,
--	[PARCELAPN] [varchar](50) NULL,
--	[MatchedBy] [varchar](50) NULL,
--	[PARCELAPNMask] [varchar](50) NULL
--) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

--GO

--SET ANSI_PADDING OFF
--GO


UPDATE n 
	set n.PropertyId = m.FAPropertyParent,
	n.MatchedBy = 'Historic Matched via Ref_Id'
	from [dbo].[m_FADMNoMatched] n
	inner join dbo.MasterMatchedParcelAllUnique o with(nolock) on n.Fips = o.Fips and n.PARCELAPN = o.DmApn
	inner join Global.dbo.Property_Master m with(nolock) on m.Fips = o.Fips and m.DTDB_Ref_ID = o.Ref_id 
	where n.PropertyId is null

END

