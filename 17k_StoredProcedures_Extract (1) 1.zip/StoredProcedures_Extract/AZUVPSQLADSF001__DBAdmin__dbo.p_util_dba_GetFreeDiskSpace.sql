SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON














CREATE  PROCEDURE [dbo].[p_util_dba_GetFreeDiskSpace]

AS
/*******************************************************************************************
Author:              Thomas Lee 
Modified by:         Arun Agunuru , Raju Permandla                                         

Description:
Used to get disk and MountPoint available free disk space and to send a DAILY ALERT e-mail starting at
85% full: only 15% free disk space remaining.  

       Modified By:  Date          Description


********************************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON

declare @svrName varchar(255)
declare @sql varchar(400)


exec sp_configure 'xp_cmdshell',1
reconfigure with override

--creating a temporary tables

CREATE TABLE #t_util_DbFileStats(
       [Drive] [varchar](50) NULL,
       [Free Disk Space (GB)] [float] NULL,
       [TotalDisk Space (GB)] [float] NULL,
       [PercentUsed] [float] NULL,
       [PercentFree] [float] NULL,
       [LoadDate] [datetime] NOT NULL
) 

CREATE TABLE #output

(line varchar(255))


--by default it will take the current server name, we can the set the server name as well
set @svrName = @@SERVERNAME

set @sql = 'powershell.exe -c "Get-WmiObject -Class Win32_Volume -Filter ''DriveType = 3'' | select name,capacity,freespace | foreach{$_.name+''|''+$_.capacity/1048576+''%''+$_.freespace/1048576+''*''}"'


--inserting disk name, total space and free space value in to temporary table

insert #output
EXEC xp_cmdshell @sql


--script to retrieve the values in GB from PS Script output

select rtrim(ltrim(SUBSTRING(line,1,CHARINDEX('|',line) -1))) as drive

,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('%',line)+1,

(CHARINDEX('*',line) -1)-CHARINDEX('%',line)) )) as Float) /1024 ,0)as 'Free Disk Space (GB)'

,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('|',line)+1,

(CHARINDEX('%',line) -1)-CHARINDEX('|',line)) )) as Float)/1024,0) as 'TotalDisk Space (GB)'

 
 ,(round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('|',line)+1,

(CHARINDEX('%',line) -1)-CHARINDEX('|',line)) )) as Float)/1024,0)) * 100 as PercentFreedENOMINATOR
INTO #DiskStats
from #output
where line like '[A-Z][:]%'
order by drive

DELETE #DiskStats
where [TotalDisk Space (GB)] = 0

INSERT #t_util_DbFileStats
(
          [drive]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,[LoadDate]
)
SELECT DISTINCT drive,[Free Disk Space (GB)],[TotalDisk Space (GB)]
,( 1 - [Free Disk Space (GB)]/[TotalDisk Space (GB)]) * 100 as 'PercentUsed'
,([Free Disk Space (GB)]/[TotalDisk Space (GB)]) * 100 as 'PercentFree'
, GETDATE() as LoadDate
FROM #DiskStats
order by drive

INSERT DBAdmin.dbo.t_util_DbFileStats
(
          [drive]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,[LoadDate]
)
SELECT
          [drive]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,[LoadDate]

FROM #t_util_DbFileStats
where 
( [TotalDisk Space (GB)] <= 1024 and [PercentFree] < 10) or 
( [TotalDisk Space (GB)] between 1024  and 2048 and PercentFree <= 10 and [Free Disk Space (GB)] <= 150) or
( [TotalDisk Space (GB)] between 2048  and 10240 and PercentFree <= 5 and [Free Disk Space (GB)] <= 200)


--------------------------------------------------------------------------
  DECLARE @subject2 NVARCHAR(400)
  DECLARE @tableHTML2  NVARCHAR(MAX) 
  DECLARE @nCount tinyint
  DECLARE @nCount2 tinyint

    SET @subject2 = 'WARNING: '+ 'These Drives\MountPoints are almost FULL on ' + @@ServerName +  ' on ' + (SELECT CAST(GETDATE() AS NVARCHAR(30))) 

    -- The below code is for generating the report in XML format
    
  SELECT @nCount = COUNT(*) from #t_util_DbFileStats

  IF @nCount>0
  SET @tableHTML2 =
    N'<H1><b><p style="text-align:center;">Drive Space Alert</p></b></H1>' +
    N'<table border="1">' +
    N'<tr><th>Drive</th>' +
       N'<th>FreeDiskSpace(GB)</th>' + 
       N'<th>TotalDiskSpace(GB)</th>' + 
       N'<th>PercentUsed</th>' + 
       N'<th>PercentFree</th>' + 
    N'<th>LoadDate</th></tr>' +
       CAST ((       SELECT 
       td = ISNULL(cast(Drive as varchar(50)), ' '),'',
       td = ISNULL(cast([Free Disk Space (GB)] as varchar(30)), ' '),'',
       td = ISNULL(cast([TotalDisk Space (GB)] as varchar(30)), ' '),'',
       td = ISNULL(cast(CONVERT(DECIMAL(10,2),PercentUsed) as nvarchar), ' '),'',
       td = ISNULL(cast(CONVERT(DECIMAL(10,2),PercentFree) as nvarchar), ' '),'',
       td = ISNULL(cast(LoadDate as varchar(30)),'')
  FROM #t_util_DbFileStats
WHERE  ( [TotalDisk Space (GB)] <= 1024 and PercentFree < 10) or 
( [TotalDisk Space (GB)] between 1024  and 2048 and PercentFree <= 10 and [Free Disk Space (GB)] <= 150) or
( [TotalDisk Space (GB)] between 2048  and 10240 and PercentFree <= 5 and [Free Disk Space (GB)] <= 200)
  ORDER BY [PercentFree]
       FOR XML PATH('tr'), TYPE 
              ) AS NVARCHAR(MAX) ) +
    N'</table>' ;


--       declare @oper_email nvarchar(255)
--set @oper_email = (select email_address from msdb.dbo.sysoperators where name = 'INIT-SQL-DBA@firstam.com')
     
 
 --set @oper_email = @oper_email + ';' + 'Hgarcia@firstam.com;Skinra@firstam.com;AAgunuru@firstam.com;'

  SELECT @nCount2 = COUNT(*) from #t_util_DbFileStats  
  WHERE  ( [TotalDisk Space (GB)] <= 1024 and PercentFree < 10) or 
( [TotalDisk Space (GB)] between 1024  and 2048 and PercentFree <= 10 and [Free Disk Space (GB)] <= 150) or
( [TotalDisk Space (GB)] between 2048  and 10240 and PercentFree <= 5 and [Free Disk Space (GB)] <= 200)

  --WHERE PercentFree <= 5
  IF @nCount2 > 0
      
  exec msdb. [dbo].[sp_send_dbmail]
   @profile_name ='FAOH-DL-DBS_Fulfillment',       
   @recipients = 'Tree_Trace_DBA_Team@firstam.com;GMathes@firstam.com;rpermandla@firstam.com;',
 
   --@recipients = @oper_email,
   @body_format = 'HTML',
   @subject = @subject2,
   @body = @tableHTML2
   
--------------------------------------------------------------------------  
--script to drop the temporary tables
drop table #output
drop table #DiskStats

THEEND:
RETURN 0




