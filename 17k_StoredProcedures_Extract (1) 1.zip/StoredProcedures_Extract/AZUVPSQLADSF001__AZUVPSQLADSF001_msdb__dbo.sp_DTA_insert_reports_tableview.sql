SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
create procedure sp_DTA_insert_reports_tableview
	@SessionID	int,
	@TableID	int,
	@ViewID		int
as
begin
	declare @retval  int							
	set nocount on

	exec @retval =  sp_DTA_check_permission @SessionID

	if @retval = 1
	begin
		raiserror(31002,-1,-1)
		return(1)
	end	

	insert into [msdb].[dbo].[DTA_reports_tableview]([TableID], [ViewID])
	values(@TableID,@ViewID)
	

end	

GRANT EXECUTE ON [dbo].[sp_DTA_insert_reports_tableview] TO [public] AS [dbo]
