SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create Proc [dbo].[GetAddrTriggerByTriggerId]
(
	@TriggerId int
)
AS
/*
--Start Testing
Declare @TriggerId int
Select @TriggerId = 1
--End Testing
*/
Begin
	Select T.TriggerId
		, A.AppId
		, T.AppName
		, A.ServerName
		, A.ConnectionString
		, T.TableName
		, T.ProcessTypeCode
		, T.Process_Flag
		, T.CreatedDateTime
		, T.LastUpdatedDateTime
		, T.CompletedDateTime
	From STDTrigger as T
		Inner Join AddrApplication as A
			On T.AppName = A.AppName
		Inner Join AddrProcessType as P
			On P.Code = T.ProcessTypeCode
	Where T.TriggerId = @TriggerId

	Select ASP.AppSpId
		, SP.SpName
		, SP.SpType
		--, T.ProcessTypeCode
	from AddrAppSps as ASP
		Inner Join AddrStoredProcs as SP
			On ASP.SpId = SP.SpID
		Inner Join AddrApplication as A
			On A.AppId = ASP.AppId
		Inner Join AddrProcessType as PT
			On PT.ProcessTypeId = ASP.ProcessTypeId
		Inner Join STDTrigger as T
			On T.AppName = A.AppName
				And T.ProcessTypeCode = PT.Code
	Where T.TriggerId = @TriggerId

	Select M.ColumnMappingId
		, M.AppID
		, A.AppName
		, M.ProcessTypeId
		, PT.Code
		, M.SourceColumnName
		, M.DestColumnName
	From AddrColumnMapping as M
		Inner Join AddrProcessType as PT
			On PT.ProcessTypeId = M.ProcessTypeID
		Inner Join AddrApplication as A
			On A.AppId = M.AppId
		Inner Join STDTrigger as T
			On T.AppName = A.AppName
				And T.ProcessTypeCode = PT.Code
	Where T.TriggerId = @TriggerId
End


