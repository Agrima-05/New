SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

			CREATE procedure [dbo].[usp_101_sp_DragonAssrInput](@tableName varchar(40)) -- @tableName = 'DragonAssr' (from Addr.dbo.STDTrigger.TableName)
			as  
			declare @sql varchar(max) = ''  

			-- Create table_STD
			set @sql = '  
			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
			DROP TABLE ' + rtrim(@tableName) + '_STD'  
			--print(@sql)
			exec (@sql)  
			print(2)
				set @sql = '  
				create table ' + rtrim(@tableName) + '_STD (' + '  
				   [RecordId] [bigint] NOT NULL,
				   [FullStreetAddress] [varchar](255) NULL,
				   [CountyFips] [varchar](5) NULL,
				   [StreetNumber] [varchar](25) NULL,
				   [PreDir] [varchar](2) NULL,
				   [StreetName] [varchar](100) NULL,
				   [StreetType] [varchar](4) NULL,
				   [PostDir] [varchar](2) NULL,
				   [SuiteType] [varchar](10) NULL,
				   [Suite] [varchar](15) NULL,
				   [City] [varchar](55) NULL,
				   [State] [varchar](2) NULL,
				   [Zip] [varchar](9) NULL,
				   [Plus4] [varchar](4) NULL,
				   [CarrierRoute] [varchar](4) NULL,
				   [CountyName] [varchar](35) NULL,
				   [PrivateMailbox] [varchar](30) NULL,
				   [Pmsa] [varchar](2) NULL,
				   [Msa] [varchar](70) NULL,
				   [ZipType] [varchar](2) NULL,
				   [Urbanization] [varchar](6) NULL,
				   [CongressionalDistrict] [varchar](2) NULL,
				   [CityAbbreviation] [varchar](13) NULL,
				   [AddressTypeCode] [varchar](1) NULL,
				   [AddressTypeString] [varchar](60) NULL,
				   [DPVCount] [varchar](5) NULL,
				   [DPVFootnotes] [varchar](4) NULL,
				   [CMRA] [varchar](1) NULL,
				   [ELotNumber] [varchar](5) NULL,
				   [ELotOrder] [varchar](2) NULL,
				   [Lacs] [varchar](1) NULL,
				   [LACSLinkIndicator] [varchar](255) NULL,
				   [EWSFlag] [varchar](1) NULL,
				   [RBDI] [varchar](1) NULL,
				   [SuiteLinkReturnCode] [varchar](1) NULL,
				   [DeliveryPointCheckDigit] [varchar](1) NULL,
				   [DeliveryPointCode] [varchar](2) NULL,
				   [Verified] [varchar](5) NULL,
				   [AddressMatchResults] [varchar](30) NULL,
				   [CensusBlock] [varchar](4) NULL,
				   [CensusTract] [varchar](6) NULL,
				   [PlaceCode] [varchar](7) NULL,
				   [PlaceName] [varchar](60) NULL,
				   [CBSACode] [varchar](5) NULL,
				   [CBSALevel] [varchar](30) NULL,
				   [CBSATitle] [varchar](50) NULL,
				   [CBSADivisionCode] [varchar](5) NULL,
				   [CBSADivisionLevel] [varchar](30) NULL,
				   [CBSADivisionTitle] [varchar](50) NULL,
				   [Latitude] [varchar](16) NULL,
				   [Longitude] [varchar](16) NULL,
				   [Geocoded] [varchar](2) NULL,
				   [GeoErrorCode] [varchar](2) NULL,
				   [GeoStatusCode] [varchar](2) NULL,
				   [GeoCodeResults] [varchar](30) NULL,
				   [CountryCode] [varchar](10) NULL,
				   [raw_id] [varchar] (250) NULL
				   )
				'  
			print @sql
			exec (@sql)
			print (3)
 
			--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

			set @sql = '  
			SELECT RecordId  as id  ,  '''' as HouseNumber
				  , 0 as FIPS, isnull([FullStreetAddress], '''') addressLine ,isnull(City, '''') as city  ,isnull(State, '''') as state  ,
			isnull(Zip, '''') as zip  
			FROM ' + @tableName +   
			   ' WITH (NOLOCK) ORDER BY Zip desc'  

			exec (@sql) 
			
