SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankMortgageLenderInput](@tableName varchar(40)) -- @tableName = 'Mortgage_Lender' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + '  
	[MortgageUniqueID] [bigint] NOT NULL,
	[LenderFullMailAddress] [varchar](116) NULL,
	[LenderMailHouseNbr] [varchar](30) NULL,
	[LenderMailLeftDirection] [varchar](2) NULL,
	[LenderMailStreetName] [varchar](60) NULL,
	[LenderMailRightDirection] [varchar](2) NULL,
	[LenderMailMode] [varchar](10) NULL,
	[LenderMailUnitNumber] [varchar](15) NULL,
	[LenderMailCity] [varchar](55) NULL,
	[LenderMailState] [varchar](2) NULL,
	[LenderMailZip5] [varchar](9) NULL,
	[LenderMailZip4] [varchar](4) NULL,
	[LenderMailUnitType] [varchar](20) NULL,
	[LenderMailDPVCount] [varchar](5) NULL,
	[LenderMailDPVFootnote] [varchar](4) NULL,
	[LenderMailLACS] [varchar](1) NULL,
	[LenderMailLACSLinkInd] [varchar](1) NULL,
	[LenderMailDPCheckDigit] [varchar](1) NULL,
	[LenderMailDPCheckCode] [varchar](2) NULL,
	[LenderMailCensusBlock] [varchar](4) NULL,
	[LenderMailCensusTract] [varchar](6) NULL,
	[LenderMailMatchCode] [varchar](30) NULL,
	[LenderMailCarrierCode] [varchar](4) NULL,
	[LenderMailGeoCodeResults][varchar](30) NULL,
	[LenderMailGeoErrorCode] [varchar](1) NULL,
	[LenderMailGeoStatusCode] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT MortgageUniqueID as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([LenderFullMailAddress], '''') addressLine ,isnull(LenderMailCity, '''') as city  ,isnull(LenderMailState, '''') as state  ,
isnull(LenderMailZip5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY LenderMailZip5 desc'  

exec (@sql)  

