SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankDeedSupSitusInput](@tableName varchar(40)) -- @tableName = 'Deed_Sup_Situs' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + '  
	[DeedUniqueID] [bigint] NOT NULL,
	[SitusStdFullStreetAddress] [varchar](116) NULL,
	[SitusStdHouseNbr] [varchar](50) NULL,
	[SitusStdDirectionLeft] [varchar](2) NULL,
	[SitusStdStreet] [varchar](60) NULL,
	[SitusStdMode] [varchar](10) NULL,
	[SitusStdDirectionRight] [varchar](2) NULL,
	[SitusStdUnitNbr] [varchar](15) NULL,
	[SitusStdCity] [varchar](55) NULL,
	[SitusStdState] [varchar](2) NULL,
	[SitusStdZIP5] [varchar](9) NULL,
	[SitusStdZIP4] [varchar](4) NULL,
	[SitusLatitude] [numeric] (10,6)  NULL,
	[SitusLongitude] [numeric] (10,6)  NULL,
	[SitusStdCarrierCode] [varchar](4) NULL,
	[SitusCensusTractBlock] [varchar](20) NULL,
	[SitusStdUnitType] [varchar](20) NULL,
	[SitusStdMatchCode] [varchar](30) NULL,
	[SitusDPVCount] [varchar](5) NULL,
	[SitusDPVFootnote] [varchar](4) NULL,
	[SitusLACS] [varchar](1) NULL,
	[SitusLACSLinkInd] [varchar](1) NULL,
	[SitusDPCheckDigit] [varchar](1) NULL,
	[SitusDPCheckCode] [varchar](2) NULL,
	[SitusCensusBlock] [varchar](4) NULL,
	[SitusCensusTract] [varchar](6) NULL,
	[SitusGeoCodeResults] [varchar](30) NULL,
	[SitusGeoErrorCode] [varchar](1) NULL,
	[SitusGeoStatusCode] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT DeedUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([SitusStdFullStreetAddress], '''') addressLine ,isnull(SitusStdCity, '''') as city  ,isnull(SitusStdState, '''') as state  ,
isnull(SitusStdZIP5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY SitusStdZIP5 desc'  

exec (@sql)  

