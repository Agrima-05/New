SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF


CREATE PROCEDURE [dbo].[AutoBilling_Process]
as 
BEGIN

------Added 20210421 for one time push of records that had to be written elsewhere as CMAS db was put in read only---

INSERT INTO [SNAPNSQLDTDB010.DATATREE.LOCAL].CMAS.dbo.AutomatedBilling(AppSource, BatchId, BatchType, CreateDate, ImportDate, TotalRecords, TotalMatched, TotalUnMatched, TotalDuplicate, TotalExpired, TotalInCoverage, TotalNotInCoverage, TotalPropertiesFound, 
                  TotalPropertiesNotFound, IsBillable, TotalMultiplePropertiesFound, TotalAddressStandardized, TotalAddressNotStandardized, TotalWithEventsFound, TotalWithoutEventsFound, TicketNumber, BillingDate, 
                  ExtractionDate, BillingOption, AccountNumber, DaysToMonitor, CustomerName, ClientName, CMASProductCode, CMASProductName, OracleProductCode, OracleProductName, Title, DocImageCounts, 
                  MonitorEndDate, TotalBillableUnits, ContractExecuted, PRODUCT1, PRODUCT2, PRODUCT3, PROCESSED_YN, NUM_PRODUCTS, CMAS_PRODUCT_SHAREPOINT, STATUS, SOW, WO, STATE, PRODUCT4, 
                  PRODUCT5, PRODUCT6, PRODUCT7, PRODUCT8, PRODUCT9)
SELECT  A.AppSource, A.BatchId, A.BatchType, A.CreateDate, A.ImportDate, A.TotalRecords, A.TotalMatched, A.TotalUnMatched, A.TotalDuplicate, A.TotalExpired, A.TotalInCoverage, A.TotalNotInCoverage, A.TotalPropertiesFound, 
                  A.TotalPropertiesNotFound, A.IsBillable, A.TotalMultiplePropertiesFound, A.TotalAddressStandardized, A.TotalAddressNotStandardized, A.TotalWithEventsFound, A.TotalWithoutEventsFound, A.TicketNumber, A.BillingDate, 
                  A.ExtractionDate, A.BillingOption, A.AccountNumber, A.DaysToMonitor, A.CustomerName, A.ClientName, A.CMASProductCode, A.CMASProductName, A.OracleProductCode, A.OracleProductName, A.Title, A.DocImageCounts, 
                  A.MonitorEndDate, A.TotalBillableUnits, A.ContractExecuted, A.PRODUCT1, A.PRODUCT2, A.PRODUCT3, A.PROCESSED_YN, A.NUM_PRODUCTS, A.CMAS_PRODUCT_SHAREPOINT, A.STATUS, A.SOW, A.WO, A.STATE, A.PRODUCT4, 
                  A.PRODUCT5, A.PRODUCT6, A.PRODUCT7, A.PRODUCT8, A.PRODUCT9
FROM     Data.dbo.AutomatedBilling AS A LEFT OUTER JOIN
                  [SNAPNSQLDTDB010.DATATREE.LOCAL].CMAS.dbo.AutomatedBilling AS B ON A.CustomerName = B.CustomerName AND A.TotalRecords = B.TotalRecords AND A.CreateDate = B.CreateDate
WHERE  (B.TotalREcords IS NULL)


INSERT INTO [SNAPNSQLDTDB010.DATATREE.LOCAL].CMAS.dbo.AutomatedBilling(AppSource, BatchId, BatchType, CreateDate, ImportDate, TotalRecords, TotalMatched, TotalUnMatched, TotalDuplicate, TotalExpired, TotalInCoverage, TotalNotInCoverage, TotalPropertiesFound, 
                  TotalPropertiesNotFound, IsBillable, TotalMultiplePropertiesFound, TotalAddressStandardized, TotalAddressNotStandardized, TotalWithEventsFound, TotalWithoutEventsFound, TicketNumber, BillingDate, 
                  ExtractionDate, BillingOption, AccountNumber, DaysToMonitor, CustomerName, ClientName, CMASProductCode, CMASProductName, OracleProductCode, OracleProductName, Title, DocImageCounts, 
                  MonitorEndDate, TotalBillableUnits, ContractExecuted, PRODUCT1, PRODUCT2, PRODUCT3, PROCESSED_YN, NUM_PRODUCTS, CMAS_PRODUCT_SHAREPOINT, STATUS, SOW, WO, STATE, PRODUCT4, 
                  PRODUCT5, PRODUCT6, PRODUCT7, PRODUCT8, PRODUCT9)
SELECT  A.AppSource, A.BatchId, A.BatchType, A.CreateDate, A.ImportDate, A.TotalRecords, A.TotalMatched, A.TotalUnMatched, A.TotalDuplicate, A.TotalExpired, A.TotalInCoverage, A.TotalNotInCoverage, A.TotalPropertiesFound, 
                  A.TotalPropertiesNotFound, A.IsBillable, A.TotalMultiplePropertiesFound, A.TotalAddressStandardized, A.TotalAddressNotStandardized, A.TotalWithEventsFound, A.TotalWithoutEventsFound, A.TicketNumber, A.BillingDate, 
                  A.ExtractionDate, A.BillingOption, A.AccountNumber, A.DaysToMonitor, A.CustomerName, A.ClientName, A.CMASProductCode, A.CMASProductName, A.OracleProductCode, A.OracleProductName, A.Title, A.DocImageCounts, 
                  A.MonitorEndDate, A.TotalBillableUnits, A.ContractExecuted, A.PRODUCT1, A.PRODUCT2, A.PRODUCT3, A.PROCESSED_YN, A.NUM_PRODUCTS, A.CMAS_PRODUCT_SHAREPOINT, A.STATUS, A.SOW, A.WO, A.STATE, A.PRODUCT4, 
                  A.PRODUCT5, A.PRODUCT6, A.PRODUCT7, A.PRODUCT8, A.PRODUCT9
FROM     [AZUVNSQLDTDB001.datatree.local].CMAS.dbo.AutomatedBilling AS A LEFT OUTER JOIN
                  [SNAPNSQLDTDB010.DATATREE.LOCAL].CMAS.dbo.AutomatedBilling AS B ON A.CustomerName = B.CustomerName AND A.TotalRecords = B.TotalRecords AND A.CreateDate = B.CreateDate
WHERE  (B.TotalREcords IS NULL)
Order by CreateDate desc

--Select * From  [SNAPNSQLDTDB010.DATATREE.LOCAL].CMAS.dbo.AutomatedBilling
--where CustomerName like 'House Buyers of America, Inc'

--------------------Added 20190522 to include FLAT FEE records per MD-----
----------------------------------------------------

	INSERT INTO [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,A.Created----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL----TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,A.ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,A.[Billing_x0020_Type]----BillingOption
			,A.Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,A.Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate
			--Select top 100 *
			FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as A 
			left outer join [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling as B on 
			A.ID = B.TicketNumber
			left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
			where A.[Billing_x0020_Type] like 'Flat Fee'
			and CUrrent_x0020_Status like '15-Closed'
			and A.Modified >= Getdate()-60
			AND (B.TicketNumber is null) --or A.Modified > B.CreateDate
			AND (C.TicketNumber is null) --or A.Modified > C.CreateDate
			

				INSERT INTO [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,A.Created----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL----TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,A.ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,A.[Billing_x0020_Type]----BillingOption
			,A.Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,A.Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate
			--Select top 100 *
			FROM [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as A 
			left outer join [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling as B on 
			A.ID = B.TicketNumber
			left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
			where A.[Billing_x0020_Type] like 'Flat Fee'
			and CUrrent_x0020_Status like '15-Closed'
			and A.Modified >= Getdate()-60
			AND (B.TicketNumber is null) --or A.Modified > B.CreateDate
			AND (C.TicketNumber is null) --or A.Modified > C.CreateDate
			


			--Select ID, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
			--where [Billing_x0020_Type] like 'Flat Fee'

			--Select TicketNumber,* From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
			--where TicketNumber in (Select ID From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
			--where [Billing_x0020_Type] like 'Flat Fee')


-------------Added 20201229 for PennyMac Billing----------------

	INSERT INTO [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,(Select count(*) From (
			Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
			where  [Legal Event Status] like 'Found'
			AND DATE_BILLED is null)A)---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'4922'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'3 - Bill for every record that had an event'----BillingOption
			,'133759'----AccountNumber
			,NULL----DaysToMonitor
			,'PennyMac'----CustomerName
			,NULL----ClientName
			,'S20'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


		
Select count(*) From (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null)A

Select [Loan Number], count(*)  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null
Group by [Loan Number]
having count(*) > 1

Select [Loan Number], DATE_RECEIVED,DATE_SENT_TO_PNMAC From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where [Loan Number] in (
Select [Loan Number] from (
Select [Loan Number], count(*)  as TOTAl From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null
Group by [Loan Number]
having count(*) > 1)A)
Order by [Loan Number]


Update zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null



Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where TicketNumber = '4922'

Select count(*) From (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
and  DATE_BILLED not like 'N/A' and
convert(date,DATE_BILLED) = convert(date,Getdate())
)A


Select DATE_BILLED, count(*) From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
Group by DATE_BILLED
Order by DATE_BILLED desc


-----Query for PNMAC Detail file---
Select [Loan Number],1 as 'UNITS',convert(money,'6') as 	'Cost/Unit',convert(money,'6') as	'Total'
from (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
and  convert(date,DATE_BILLED) = convert(date,Getdate())
)A
Order by DATE_SENT_TO_PNMAC




--------------*******--------20210428 - Added for METASOURCE Billing Report per NH-----******------------------

----Check Order Date Range to be sure it is within billing cycle---
Select [Order Date], count(*) as TOTAL From zCust_Metasource.dbo.Billing_Report
where DATE_BILLED is null
Group by [Order Date]
Order by [Order Date]

-----Make sure NO NULL VALUES!!!!!-----
Select [Billable Event], count(*) as TOTAL From zCust_Metasource.dbo.Billing_Report
where DATE_BILLED is null
Group by [Billable Event]
Order by [Billable Event]


Update zCust_Metasource.dbo.Billing_Report
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null





--------------------Added 20200824 for COVIUS MANUAL DOC IMAGE CREDITS PER NH---
----------------------------------------------------

	INSERT INTO [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL----TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'4463'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'3 - Bill for every record that had an event'----BillingOption
			,'132941'----AccountNumber
			,NULL----DaysToMonitor
			,'Covius'----CustomerName
			,NULL----ClientName
			,'S50'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,'-1'----DocImageCounts
			,NULL----MonitorEndDate
			



---------Added 20180419 KL - For USA Home Listings-----
--Insert into [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING_HIST]
--Select * From [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING]

--Truncate table [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING]

Select CreateDate, DocImageCOunts From  [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where customerName like 'Covius'
ORder by DocImageCOunts


--------Added 20190503 - KL  for AUCTION 10 X Monitor Job------------------------------------------------------------------


--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'BATCH'               --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,COUNT(DISTINCT [Reference Number])   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'3469'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'131949'    --[AccountNumber]
--      ,'Auction.com' --[CustomerName]
--      ,'S20'                      --[CMASProductCode]
--      ,'S20 - Custom Solution'  --[CMASProductName]
--	from  zCust_Auction.dbo.[AUCTION_BILLING] --Where RecordFlag = 'A'





--INSERT INTO zCust_Auction.dbo.[AUCTION_BILLING_HIST]([Order Date]
--      ,[UserID]
--      ,[Product]
--      ,[Reference Number]
--      ,[Group Name]
--      ,[Search Criteria]
--      ,[Pricing]
--      ,[DATE_BILLED])
--SELECT       [Order Date]
--      ,[UserID]
--      ,[Product]
--      ,[Reference Number]
--      ,[Group Name]
--      ,[Search Criteria]
--      ,[Pricing]
--       ,convert(date,Getdate())
--FROM       zCust_Auction.dbo.[AUCTION_BILLING]



--Truncate table zCust_Auction.dbo.[AUCTION_BILLING]


Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where Ticketnumber in (3788,3712)

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] 
where Ticketnumber in (3788,3712)


-----------Added 20200114 KL for Green River per customer wants all billed records included with invoice each month----
Select count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is null

Update zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Select count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT

Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Report Date]
Order by [Report Date]


Select [Client Name],[INPUT KEY], count(*)  From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Client Name],[INPUT KEY]
having count(*) > 1

Select A.* From zCust_ADS_GreenRiver.dbo.BILLING_REPORT as A 
join 
(Select [Client Name],[INPUT KEY], count(*) as TOTAL From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Client Name],[INPUT KEY]
having count(*) > 1) B on 
A.[Client Name] = B.[Client Name]
and A.[INPUT KEY] = B.[INPUT KEY]
Order by [Client Name],[INPUT KEY]




Insert into zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Select * From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]

Truncate table zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]

Insert into zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Select distinct  * From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is not null

Select * From zCust_ADS_GreenRiver.dbo.ADS_COUNTS
ORder by CreateDate desc


Delete from zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is not null

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
where DATE_BILLED = convert(date,Getdate())


Select Status, count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Group by Status

Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Group by [Report Date]
Order by [Report Date]


Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Group by [Report Date]
Order by [Report Date]

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]

Select sum(TotalMatched) From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where AccountNumber = '118751'
and BillingDate is null



--Select sum(TotalMatched) From [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'

--Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status From [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'


Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where AccountNumber = '118751'



------Added 20191105 - KL  for Finance of America Monitor Job-----------------------------------------------------------
----------------Billing - $5.00 for ANY record in REVERSE OR COMMERCIAL that had Event Found in ANY Solution---
-----------********Changed 20200805 per EC & Juston Backs to bill for EVERY EVENT FOUND PER SOLUTION****---
--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,A.MAXEVENTFOUND   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,A.MAXEVENTFOUND         --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'4024'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'131666'    --[AccountNumber]
--      ,'Finance of America' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]

--from  
--(Select max(MAXCOUNT) as MAXEVENTFOUND From 
--(
--	(Select max(Event_Found) as MAXCOUNT From zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING 
--	where DATE_BILLED is null)
--	UNION ALL
--	(Select max(Event_Found) as MAXCOUNT From zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING 
--	where DATE_BILLED is null)
		
--	--(Select max(TotalWithEventsFound) as MAXCOUNT From zCust_FinanceOfAmerica_REVERSE.dbo.ADS_COUNTS 
--	--where DATE_BILLED is null)
--	--UNION ALL
--	--(Select max(TotalWithEventsFound) as MAXCOUNT From zCust_FinanceOfAmerica_COMM.dbo.ADS_COUNTS 
--	--where DATE_BILLED is null)
--)A)A where MAXEVENTFOUND > 0

----------------Testing-----------


--Select * From zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING 
--where DATE_BILLED is null Order by EVENT_FOUND desc
--Select * From zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING 
--where DATE_BILLED is null Order by EVENT_FOUND desc

--Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '4024'  


--Update zCust_FinanceOfAmerica_REVERSE.dbo.ADS_COUNTS
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Update zCust_FinanceOfAmerica_COMM.dbo.ADS_COUNTS
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null


--Update zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Update zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where TicketNumber = 4024



------Added 20210129 - KL  for SITUS AMC  - Per EC _ Their billing is based on the solution(s) chosen 
------& can be per event OR Input record & there can be add ons!!1-----------------------------------------------
Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where CustomerName = 'Situs AMC'


--------------Set Date Billed-----------


Select * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where DATE_BILLED is null 


Update zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into  zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT_HIST]
Select * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where DATE_BILLED = convert(date,Getdate())

Truncate table zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]





------Added 20200601 - KL  for APEX WO6 Monitor Job - Per NH they are only billed once for two extracts per month-----------------------------------------------
----------------Billing - Per MATCHED Record so taking the Max Number of Matched records per month---
insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'WO6'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select max(TOTALRECORDS) from  zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS with(NOLOCK)	where [DATE_BILLED] is null)   --[TotalRecords]
      ,(Select max(TOTALMatched) from  zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS with(NOLOCK)	where [DATE_BILLED] is null)                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0        --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'4410'                 --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'119863'    --[AccountNumber]
      ,'Apex Lien Solutions ' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]

--from  zCust_ADS_S20_APEX.dbo.ADS_COUNTS	where [DATE_BILLED] is null

Select * From zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS


Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '4410'  Order by CreateDate desc


--------------Set Date Billed-----------


Select * From zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS
where DATE_BILLED is null 

Update zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 






------Added 20201111 - KL  for DOMIDOCS Monitor Job - Per CR they are only billed once per month-----------------------------------------------
----------------Billing - Billed once per month for the MAX number of records in the portfolio during the billing cycle ---
insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'Monitor'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select max(TOTALRECORDS) from  zCust_DomiDocs.dbo.ADS_COUNTS with(NOLOCK)	where BILLINGDATE is null
	  and BatchType like 'Portfolio')   --[TotalRecords]
      ,0
	  --(Select max(TotalPropertiesFound) from  zCust_DomiDocs.dbo.ADS_COUNTS with(NOLOCK)	where BILLINGDATE is null)   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0        --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'4987'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'133789'    --[AccountNumber]
      ,'DomiDocs, Inc' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]

--from  zCust_ADS_S20_APEX.dbo.ADS_COUNTS	where [DATE_BILLED] is null

Select * From zCust_DomiDocs.dbo.ADS_COUNTS where batchType like 'BATCH' and CreateDate > Getdate()-35 Order by CreateDate Desc

Select count(*) from zCust_DomiDocs.dbo.INPUT_MONITOR with(NOLOCK)


Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '4987'  and Billingdate is null 


--------------Set Date Billed-----------


Select * From zCust_DomiDocs.dbo.ADS_COUNTS
where BILLINGDATE is null 

Update zCust_DomiDocs.dbo.ADS_COUNTS
Set BILLINGDATE = convert(date,Getdate())
where BILLINGDATE is null 

 



------Added 20200407 - KL  for Computershare Daily Batch job Job-----------------------------------------------------------
----------------Billing - $2.00 per Doc Image Returned---
---------Ticket 4457 is for the  $2.00 per image
-----20200424 - The job pushes the counts - no need to push them separately any longer
--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--	   ,[DocImageCounts])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'BATCH'             --[BatchType]
--      ,DATE_RUN             --[CreateDate]
--      ,DATE_RUN              --[ImportDate]
--      ,0					   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,Sum(convert(int,[Images Delivered]))                      --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'4457'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'133084'    --[AccountNumber]
--      ,'ComputerShare' --[CustomerName]
--      ,'S50'                      --[CMASProductCode]
--      ,'S50 - Doc Images'  --[CMASProductName]
--	  ,Sum(convert(int,[Images Delivered]))  ----[DocImageCount]
	  
--from  zcust_Computershare_REL.dbo.[REL_BILLING]  A
--where DATE_BILLED is null --and DATE_RUN < '2020-04-01'
--Group by DATE_RUN
--Order by A.DATE_RUN


Select ID, CustomerName,BatchType,CreateDate, TotalREcords, TotalWithEventsFound,
CMASPRoductCOde, DocImageCounts, TicketNUmber
From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where (Ticketnumber in ( '4457','5092')
OR CustomerName like 'Computershare') and billingdate is null
Order by CreateDate



----Covius----
Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where TicketNumber = '4463'
Order by Createdate desc


--Delete from [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
--where ID in (216374,216373,216375,216376,215201,216377,215214,216378,216379,216380,216381,216382,216383,216384,216385,216386,216387,216388,216389)

-------Testing----
Select BatchType, sum( DocImageCounts)
From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where (Ticketnumber in ( '4457','5092')
OR CustomerName like 'Computershare') and billingdate is null
Group by BatchType


Select sum(	convert(int,[Images Delivered]	))
From zcust_Computershare_REL.dbo.[REL_BILLING] 
where  DATE_BILLED is null

Select * From zcust_Computershare_REL.dbo.[REL_BILLING]
where DATE_BILLED is null
--Order by DATE_RUN 
Order by [Total Fee] 

Select sum(	convert(int,[Images Delivered]	))
From zcust_Computershare_ASN.dbo.[ASN_BILLING] 
where  DATE_BILLED is null


Select CreateDate, DocImageCounts, TicketNumber
From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
where (Ticketnumber in ( '4457','5092')
OR CustomerName like 'COmputershare') and billingdate is null
ORder by TicketNumber,DocImageCounts

 
Update zcust_Computershare_REL.dbo.[REL_BILLING] 
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 


Select [Order Number],	[Loan Number]	,[Investor Code],	[Borrower Name]	,[County]	
,[State],	[Fee Type],[Fee Description],	[Images Delivered]	,[Total Fee]
,DATE_RUN
From zcust_Computershare_REL.dbo.[REL_BILLING] 
where  DATE_BILLED like convert(date,Getdate())
--Order by [Total Fee]
 Order by DATE_RUN 


 

Update zcust_Computershare_ASN.dbo.[ASN_BILLING] 
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 


Select [Order Number],	[Loan Number]	,[Investor Code],	[Borrower Name]	,[County]	
,[State],	[Fee Type],[Fee Description],	[Images Delivered]	,[Total Fee]
,DATE_RUN
From zcust_Computershare_ASN.dbo.[ASN_BILLING] 
where  DATE_BILLED like convert(date,Getdate())
--Order by [Total Fee]
 Order by DATE_RUN 

 



------Added 20190722 - KL  for GENESIS CAPITAL Monitor Job-----------------------------------------------------------
----------------Billing - $7.50 for initial run - $2.00 per month for ongoing runs---
---------Ticket 3788 is for the  $7.50 for the initial run per input record
---------Ticket 3712 is for the  $2.00 for the ongoing runs per input record
insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,COUNT(DISTINCT [INPUTKey])   --[TotalRecords]
      ,0                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0                       --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3788'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'132113'    --[AccountNumber]
      ,'Genesis Capital' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]

from  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN --Where RecordFlag = 'A'
where DATE_BILLED is null



Update zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null


--Select * From  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN  as A 
--Where DATE_BILLED = convert(date,Getdate())


insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,COUNT(DISTINCT [INPUTKey])   --[TotalRecords]
      ,0                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0                       --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3712'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'132113'    --[AccountNumber]
      ,'Genesis Capital' --[CustomerName]
      ,NULL                    --[CMASProductCode]
      ,NULL --[CMASProductName]
	 --Select * 
	 from  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING 
	  where DATE_BILLED  is null

Update zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null

Select DATE_BILLED, count(*) From zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING
Group by DATE_BILLED
Order by DATE_BILLED desc

----Truncate table zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING 


-----Commented out 20191219 as no longer customer-----
------Added 20170104 - KL  for HTL Monitor Job-----------------------------------------------------------
--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,COUNT(DISTINCT UNIQUEID)   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'542'                 --[TicketNumber]
--      ,'1 - Bill for every record in the Input file'   --[BillingOption]
--      ,'119840'    --[AccountNumber]
--           ,'Home Title Lock' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]
--from  zCust_ADS_HomeTitleLock.dbo.Input_Raw_Billing --Where RecordFlag = 'A'


--INSERT INTO zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_BillingHistory([UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]
--      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]      ,[OwnerName]      ,[RecordFlag]      ,[ProcessDate]      ,APN,[BillingDate])
--SELECT        [UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]      ,[ProcessDate]      ,[APN],Getdate()
--FROM            zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing



--Truncate table zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing

--Insert into zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing([UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]  ,[APN],[ProcessDate])
--Select [UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]      ,[APN],Getdate() 
--	  From zCust_ADS_HomeTitleLock.dbo.INPUT_IN_Monitor







------Added 20190501 - KL  for EVOLVE_VACA_RENTALS Monitor Job-----------------------------

---------20200320 - Per CR changed to billing type 2 - bill for every MATCHED record....

insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select COUNT(DISTINCT INPUTKey) from  zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_IN_MONITOR)   --[TotalRecords]
      ,(Select COUNT(DISTINCT [UNIQUE ID]) from  zCust_ADS_S15_EvolveVacaRentals.dbo.Input_Raw_Billing)   --[TotalMatched]
	  ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0                       --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3465'                 --[TicketNumber]
	  ,'2 - Bill for every record that was matched to a property'
      --,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'119840'    --[AccountNumber]
           ,'Evolve Vacation Rental' --[CustomerName]
      ,'S15'                      --[CMASProductCode]
      ,'S15 - Sales Listings'  --[CMASProductName]
	  
		--from  zCust_ADS_S15_EvolveVacaRentals.dbo.Input_Raw_Billing --Where RecordFlag = 'A'
	
		Select * from zCust_ADS_S15_EvolveVacaRentals.dbo.ADS_COUNTS 
		Order by CreateDate desc


INSERT INTO zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_BillingHistory([Unique ID]
      ,[Geocode: Street (clean)]
      ,[Geocode: City (clean)]
      ,[Apt#/Unit #]
      ,[Zip]
      ,[Geocode: State/Province (clean)]
      ,[RECORD_TYPE]
      ,[DATE_ADDED]
      ,[DATE_DELETED]
	  ,[BillingDate])
SELECT       [Unique ID]
      ,[Geocode: Street (clean)]
      ,[Geocode: City (clean)]
      ,[Apt#/Unit #]
      ,[Zip]
      ,[Geocode: State/Province (clean)]
      ,[RECORD_TYPE]
      ,[DATE_ADDED]
      ,[DATE_DELETED]
	  ,convert(date,Getdate())
FROM            zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing



Truncate table zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing

Insert into zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing([Unique ID]
      ,[Geocode: Street (clean)]
      ,[Geocode: City (clean)]
      ,[Apt#/Unit #]
      ,[Zip]
      ,[Geocode: State/Province (clean)]
      ,[RECORD_TYPE]
      ,[DATE_ADDED]
      ,[DATE_DELETED])
Select [INPUTKey]
      ,[INPUTAddress]
	   ,[INPUTCity]
      ,[INPUTUnit]
	   ,[INPUTZip]
      ,[INPUTState]
      ,[INPUTRecordType]
      ,[DATE_ADDED]
      ,[DATE_DELETED]
	  From zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_IN_Monitor
	  where REF_ID is not null




------Added 20170105 - KL  for 1Tract Monitor Job Doc Image Counts-----
----20210125 - Commented out as job is no longer running

--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--	  ,[DocImageCounts]
--	  ,STATE)
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'1096'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'120268 '    --[AccountNumber]
--           ,'1Tract ' --[CustomerName]
--      ,'S50'                      --[CMASProductCode]
--      ,'Doc Images'  --[CMASProductName]
--	  ,sum([DocImageCounts])
--	  ,STATE
--	  FROM zCust_ADS_S20_1Track.dbo.ADS_COUNTS 
--		Where 
--		DATE_BILLED is null and
--		DocImageCounts > 0
--		and CmasProductCOde = 'S50 - Doc Images'
--		Group by STATE


-------Added 20170105 for 1Tract Matched Record Count---


-- Update A
--	  Set  A.[INPUTMonitorStartDate] = B.[INPUTMonitorStartDate]
--	  ,A.[PropertyAddress] = B.[PropertyAddress]
--      ,A.[City] = B.[City]
--      ,A.[State] = B.[State]
--      ,A.[ZipCode] = B.[ZipCode]
--      ,A.[CoverageStatus] = B.[CoverageStatus]
--      ,A.[AddressStandardization] = B.[AddressStandardization]
--      ,A.[PropertyStatus] = B.[PropertyStatus]
--	  --Select * 
--	  From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING] as A join zCust_ADS_S20_1Track.dbo.[x_Custom_OUTPUT] as B on 
--	   A.Inputkey = B.Inputkey



--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--	  ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--	  ,Count(*)
--      ,Count(*)                --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,Count(*)                --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'1096'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'120268 '    --[AccountNumber]
--           ,'1Tract ' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'Portfolio Monitoring'  --[CMASProductName]
----Select count(*)
--from  
--zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]
--  where [PropertyStatus] like 'Property Found'
--  and [CoverageStatus] like 'In Coverage'
  



----Select * From zCust_ADS_S20_1Track.dbo.ADS_COUNTS

--	Select * From zCust_ADS_S20_1Track.dbo.ADS_COUNTS
--	where DATE_BILLED is null

--  UPdate zCust_ADS_S20_1Track.dbo.ADS_COUNTS
--  Set DATE_BILLED = convert(varchar(10),Getdate(),112)
--  where DATE_BILLED is null

--  Insert into zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST]
--  Select *, convert(varchar(10),Getdate(),112) From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]

  
--  --Select * From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST]

--  -- Select * From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST] 
--  --where DATE_BILLED = '20181126' and [PropertyStatus] like 'Property Found'
--  --and [CoverageStatus] like 'In Coverage'
--  --order by DATE_BILLED desc

--  Truncate table zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]

--  Insert into zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]([INPUTKey],[ClientName],[INPUTAddress],[INPUTUnitNbr],[INPUTCity],[INPUTState],[INPUTZip],[INPUTAPN],[AgencyID],[FileID],[FileNbr])
--  Select [INPUTKey],[ClientName],[INPUTAddress],[INPUTUnitNbr],[INPUTCity],[INPUTState],[INPUTZip],[INPUTAPN],[AgencyID],[FileID],[FileNbr]
--  From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR] where RecordFlag not like 'D'




  -------------------------Pitch Point Listing S15 Monitor--------------------
  ----------------------Cancelled 8/22/2019-------------------------
----  --Select * from  [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
----  --where CMASProductName like '%NMLS%' 

----  --Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode,CMASProductName,OracleProductCode,OracleProductName)
----  --Values('Bulk - PACE','Bulk - PACE','18719','Bulk - PACE')

----  -- Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode,CMASProductName,OracleProductCode,OracleProductName)
----  --Values('S86','PACE','16647','ADS - PACE')

----  Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
----  where CustomerName like 'Pitch%'

  
----insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
----      ,[BatchType]
----      ,[CreateDate]
----      ,[ImportDate]
----	  ,[TotalRecords]
----      ,[TotalMatched]
----      ,[TotalUnMatched]
----      ,[TotalDuplicate]
----      ,[TotalExpired]
----      ,[TotalInCoverage]
----      ,[TotalNotInCoverage]
----      ,[TotalPropertiesFound]
----      ,[TotalPropertiesNotFound]
----      ,[IsBillable]
----      ,[TotalMultiplePropertiesFound]
----      ,[TotalAddressStandardized]
----      ,[TotalAddressNotStandardized]
----      ,[TotalWithEventsFound]
----      ,[TotalWithoutEventsFound]
----      ,[TicketNumber]
----      ,[BillingOption]
----      ,[AccountNumber]
----      ,[CustomerName]
----      ,[CMASProductCode]
----      ,[CMASProductName])
----       SELECT 'SQL ADS'      --[AppSource]
----      ,'MONITOR'             --[BatchType]
----      ,GetDate()               --[CreateDate]
----      ,GetDate()               --[ImportDate]
----	  ,Count(*)				   --[TotalRecords]
----      ,NULL                   --[TotalMatched]
----      ,NULL                       --[TotalUnMatched]
----      ,NULL                       --[TotalDuplicate]
----      ,NULL                       --[TotalExpired]
----      ,NULL                       --[TotalInCoverage]
----      ,NULL                       --[TotalNotInCoverage]
----      ,NULL                --[TotalPropertiesFound]
----      ,NULL                       --[TotalPropertiesNotFound]
----      ,'YES'                 --[IsBillable]
----      ,NULL                       --[TotalMultiplePropertiesFound]
----      ,NULL                       --[TotalAddressStandardized]
----      ,NULL                       --[TotalAddressNotStandardized]
----      ,NULL                       --[TotalWithEventsFound]
----      ,NULL                       --[TotalWithoutEventsFound]
----      --,'1714'                 --[TicketNumber]
----	  ,'2818'                 --[TicketNumber] - Changed 20181212 for new profile
----	  ,'1 - Bill for every record in the Input file'   --[BillingOption]
----      ,'120141 '    --[AccountNumber]
----      ,'Pitch Point ' --[CustomerName]
----      ,'S15'                      --[CMASProductCode]
----      ,'Sales Listings'  --[CMASProductName]

---- FROM [zCust_ADS_S15_PitchPoint].[dbo].[INPUT_IN_MONITOR_BILLING]


---- Insert into [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING_HIST
---- Select * From [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING

---- TRUNCATE TABLE [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING




 
  -------------------------Reed Smith S20 Monitor----CANCELLED 20180725 PER MD----------------
--  Select * from  [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] 
  
--insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--	  ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--	  ,Count(*)				   --[TotalRecords]
--      ,NULL                   --[TotalMatched]
--      ,NULL                       --[TotalUnMatched]
--      ,NULL                       --[TotalDuplicate]
--      ,NULL                       --[TotalExpired]
--      ,NULL                       --[TotalInCoverage]
--      ,NULL                       --[TotalNotInCoverage]
--      ,NULL                --[TotalPropertiesFound]
--      ,NULL                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,NULL                       --[TotalMultiplePropertiesFound]
--      ,NULL                       --[TotalAddressStandardized]
--      ,NULL                       --[TotalAddressNotStandardized]
--      ,NULL                       --[TotalWithEventsFound]
--      ,NULL                       --[TotalWithoutEventsFound]
--      ,'1851'                 --[TicketNumber]
--      ,'1 - Bill for every record in the Input file'   --[BillingOption]
--      ,'130253 '    --[AccountNumber]
--      ,'Reed Smith ' --[CustomerName]
--      ,'S20'                      --[CMASProductCode]
--      ,'Custom Solution'  --[CMASProductName]

-- FROM [zCust_ADS_S20_ReedSmith].[dbo].[INPUT_IN_MONITOR_BILLING]


-- Insert into [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING_HIST
-- Select * From [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING

-- TRUNCATE TABLE [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING


------------------------------BANK OF AMERICA HOA LIENS-----SUBMIT MAX NUMBER OF MATCHED RECORDS EACH MONTH PER NH 20180824-------


insert into [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
	  ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT distinct 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
	  ,NULL    		  --[TotalRecords]
      ,(Select MAX(TotalMatched) as PropertiesMatched 	FROM zcust_boa.dbo.ADS_COUNTS	
				WHERE 	Convert(date,CreateDate) >= convert(date,Getdate()-31)  )                --[TotalMatched]
      ,NULL                       --[TotalUnMatched]
      ,NULL                       --[TotalDuplicate]
      ,NULL                       --[TotalExpired]
      ,NULL                       --[TotalInCoverage]
      ,NULL                       --[TotalNotInCoverage]
      ,NULL                --[TotalPropertiesFound]
      ,NULL                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,NULL                       --[TotalMultiplePropertiesFound]
      ,NULL                       --[TotalAddressStandardized]
      ,NULL                       --[TotalAddressNotStandardized]
      ,NULL                       --[TotalWithEventsFound]
      ,NULL                       --[TotalWithoutEventsFound]
      ,'2134'                 --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'130667 '    --[AccountNumber]
      ,'Bank of America ' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'Custom Solution'  --[CMASProductName]
	  
 FROM [zCust_BOA].[dbo].[ADS_COUNTS]

Select MAX(TotalMatched) as PropertiesMatched 	FROM zcust_boa.dbo.ADS_COUNTS	
WHERE 	Convert(date,CreateDate) >= convert(date,Getdate()-31)  

  Select * From zcust_boa.dbo.ADS_COUNTS
 where Convert(date,CreateDate) >= convert(date,Getdate()-31)  
 Order by TotalMatched desc


 Select *  From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where TicketNumber = 2134

 --Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 --where ID = 248196
-------------------------------------------------------------------------

	-- Rerun step
-- UPDATE CMAS.dbo.AutomatedBilling SET BillingDate = NULL
-- DELETE CMAS.dbo.AutomatedBilling WHERE CMASProductName = 'S50 - Doc Images'

--Drop table dbo.TEST
--Select * into dbo.TEST
--from [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]

-----------------Everything in the queue ---------------

Select A.ID,A.TicketNumber,A.CustomerName, A.CreateDate,A.BatchType,B.Title,CUrrent_x0020_Status as Status
, A.TotalRecords, A.BillingOption,A.TotalWithEventsFound,A.TotalMatched,A.TotalBillableUnits, A.AccountNumber
,A.[CMASProductName]
,A.CMASProductCOde, 
Replace(Product,';#','') as Product
,A.OracleProductCode, A.ContractExecuted
,A.DocImageCounts
,Billing_x0020_Type as Billing_Type
,Billing_x0020_Number as CustomerNumber
,A.BillingDate
,A.NUM_PRODUCTS
,A.Product1
,A.Product2
,A.Product3
,B.SOW
,B.WO
,A.BillingDate
,Replace(Assigned_x0020_f,';#',' ') as Assignee
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
on A.ticketNumber = B.ID
where 
(A.BillingDate is  null or (A.BillingDate > Getdate()-1.25 and A.BillingOption  not like 'Monthly Fee' and A.BillingOption  not like 'N/A - Non-billable'))
and B.CUrrent_x0020_Status not like '18-Request Cancelled'
order by Client_X0020_Name,B.Title, A.TicketNumber,A.CreateDate, A.BatchType

Select ID,CustomerName, BatchType, CReateDate, TotalRecords,TotalWithEventsFound,BillingDate,BillingOption, AccountNumber, DocImageCounts 
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where convert(date,BillingDate) = '2021-05-22'
and CreateDate < '2021-04-23'
Order by A.CustomerName,A.CReateDate

--Delete  From A
----Select A.CustomerName, A.BatchType, A.CReateDate, A.TotalRecords,A.TotalWithEventsFound,A.BillingDate,A.BillingOption, A.AccountNumber, A.DocImageCounts 
--From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
--join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory B on 
--A.CustomerName = B.CustomerName
--and A.CReateDate = B.CReateDate
--and A.TotalRecords = B.TotalRecords
----and A.DocImageCounts = B.DocImageCounts
--where convert(date,A.BillingDate) = '2021-05-22'
--and A.CreateDate < '2021-04-23'
--and A.CustomerName like 'Dividend Finance'
----Order by A.CustomerName,A.CReateDate


Select A.CustomerName, A.BatchType, A.CReateDate, A.TotalRecords,A.TotalWithEventsFound,A.BillingDate,A.BillingOption, A.AccountNumber, A.DocImageCounts 
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory A
where CustomerName like 'Dividend Finance'
Order by CreateDate desc






--INSERT INTO [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] (
--       [Id]
--      ,[AppSource]
--      ,[BatchId]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingDate]
--      ,[ExtractionDate]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[DaysToMonitor]
--      ,[CustomerName]
--      ,[ClientName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--      ,[OracleProductCode]
--      ,[OracleProductName]
--      ,[Title]
--      ,[DocImageCounts]
--      ,[MonitorEndDate]
--      ,[TotalBillableUnits]
--      ,[ContractExecuted]
--	  ,SOW
--	  ,WO)
--SELECT [Id]
--      ,[AppSource]
--      ,[BatchId]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingDate]
--      ,GETDATE() -- [ExtractionDate]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[DaysToMonitor]
--      ,[CustomerName]
--      ,[ClientName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--      ,[OracleProductCode]
--      ,[OracleProductName]
--      ,[Title]
--      ,[DocImageCounts]
--      ,[MonitorEndDate]
--      ,[TotalBillableUnits]
--      ,[ContractExecuted]
--	  ,SOW
--	  ,WO
-- FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--WHERE 
--((BillingDate IS NOT NULL and PROCESSED_YN = 'Y')
-- or ([BillingOption] like 'N/A - Non-billable' and BillingDate IS NOT NULL))
--AND convert(date,BillingDate) = '2021-05-22'
--and CreateDate < '2021-04-23'


Select CustomerName, BatchType, CReateDate, TotalRecords,TotalWithEventsFound,BillingDate,BillingOption, AccountNumber, DocImageCounts 
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory A
where 
--convert(date,BillingDate) = '2021-05-22'
--and 
CreateDate < '2021-04-23'
and CustomerName like 'Covius'
Order by A.CustomerName,A.CReateDate desc




Select CustomerName, BatchType, CReateDate, TotalRecords, BillingDate, AccountNumber, DocImageCounts From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where Ticketnumber = 5092
Order by CreateDate 

--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--Set TotalWithEventsFound = NULL
--where ID in (234038,234045,234055)

--Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--where ID in (244831,246228,247612,246513)

Select ID,TicketNumber,CustomerName, BatchType, CreateDate, TotalRecords, TotalMatched, TotalWithEventsFound 
,CMASProductCode
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ( '3465','4393','4388','4895')
and BillingDate is null
Order by BatchType,CreateDate

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
where ID in ( '3465','4393','4388','4895')



Select ID, Ticketnumber, CreateDate, TotalRecords, CustomerName, TotalMatched, BillingOption From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where Ticketnumber in ('3465')
Order by A.Ticketnumber, A.CreateDate

Select ID, Ticketnumber, CreateDate, TotalRecords, CustomerName, TotalMatched From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where Ticketnumber in ('3353','3380','2799','2809','2809','3425','3444','3444','2994','3453','2994','2994','2134')
Order by A.Ticketnumber, A.CreateDate

-------------------------------CHECK FOR TICKETS NOT PUSHED TO BILLING-----------------------
Select A.ID as Sharepoint_Ticket, Client_X0020_Name as Customer_Name,A.Title, Requested_x0020_Data_x0020_Type as RequestType,
Request_x0020_Type as PROD_EVAL,Actual_x0020__x002d__x0020_Scopi as ExpirationDate,
CUrrent_x0020_Status as Status,
Replace(Product,';#','') as Product, Replace(Assigned_x0020_f,';#',' ') as Assignee,Billing_x0020_Type as Billing_Type
, Billing_x0020_Number as CustomerNumber,Created,Modified,Due_X0020_Date as Due_Date, 
Date_x0020_Delivered_x0020_to_x0 as Delivered_Date
,Replace(Replace(Replace(Replace(Right(SME_x0020_Notes_x0020_to_x0020_d,len(SME_x0020_Notes_x0020_to_x0020_d)-Charindex('>\\corp.',SME_x0020_Notes_x0020_to_x0020_d)),'</a>',''),'</p>',''),'</div>',''),'<p>','')
as Workorder_Loc
,Sales_x0020_Rep0 as SalesRep
,Author as Author

 --From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
 FROM [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] as B with(NOLOCK) on A.ID = B.TicketNumber
left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
where A.CUrrent_x0020_Status like '%Closed%' 
and B.TicketNumber is null
and C.TicketNumber is null
AND Modified >= Getdate()-30
and left(Billing_x0020_Type,1)  in ('1','2','3','4','5')


Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber = '5266'--'3286'

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
where ID = '4241'--'3286'

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].AutomatedBillingHistory
where TicketNumber = '3286'

---------------------------INSERT MISSING TICKETS-------------------------
DECLARE @TICKETNUMBER2 varchar(20)
DECLARE @TOTAL bigint

Set @TICKETNUMBER2 = '5400'
Set @TOTAL = '150'

EXEC('
	INSERT INTO [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select ''SQL ADS''----AppSource
			,NULL----BatchId
			,''BATCH''----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,''' + @TOTAL + '''----TotalRecords
			,''' + @TOTAL + '''----TotalMatched
			,''0''----TotalUnMatched
			,''0''----TotalDuplicate
			,''0''----TotalExpired
			,''' + @TOTAL + '''----TotalInCoverage
			,''0''----TotalNotInCoverage
			,''' + @TOTAL + '''----TotalPropertiesFound
			,''0''----TotalPropertiesNotFound
			,''YES''----IsBillable
			,''0''----TotalMultiplePropertiesFound
			,''0''----TotalAddressStandardized
			,''0''----TotalAddressNotStandardized
			,''' + @TOTAL + '''----TotalWithEventsFound
			,''0''----TotalWithoutEventsFound
			,ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,Billing_x0020_Type----BillingOption
			,Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,''0''----DocImageCounts
			,NULL----MonitorEndDate

			FROM [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] 
			where ID = ''' + @TICKETNUMBER2 + '''


			Select * From [AZUVNSQLDTDB001.datatree.local].CMAS.dbo.AutomatedBilling
			where TicketNumber = ''' + @TICKETNUMBER2 + '''

			Select * From [SNAPNSQLDTDB010.datatree.local].CMAS.dbo.AutomatedBilling
			where TicketNumber = ''' + @TICKETNUMBER2 + '''

			')



--Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where ID in (70517,70609)

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ( '5380','5400')



----------------------------Nicoles query to check for closed tickets------------------------------------------------------
Select  A.ID as Sharepoint_Ticket, Client_X0020_Name as Customer_Name,A.Title, Requested_x0020_Data_x0020_Type as RequestType,
Request_x0020_Type as PROD_EVAL,Actual_x0020__x002d__x0020_Scopi as ExpirationDate,
CUrrent_x0020_Status as Status,
Replace(Product,';#','') as Product, Replace(Assigned_x0020_f,';#',' ') as Assignee,Billing_x0020_Type as Billing_Type
, Billing_x0020_Number as CustomerNumber,Created,Modified,Due_X0020_Date as Due_Date, 
Date_x0020_Delivered_x0020_to_x0 as Delivered_Date
,Replace(Replace(Replace(Replace(Right(SME_x0020_Notes_x0020_to_x0020_d,len(SME_x0020_Notes_x0020_to_x0020_d)-Charindex('>\\corp.',SME_x0020_Notes_x0020_to_x0020_d)),'</a>',''),'</p>',''),'</div>',''),'<p>','')
as Workorder_Loc
,Sales_x0020_Rep0 as SalesRep
,Author as Author

,Record_x0020_Count as RecordCount
,Priority

--from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
from [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] as B with(NOLOCK) on A.ID = B.TicketNumber
left outer join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as C on A.ID = C.TicketNumber 
Where A.Date_x0020_Delivered_x0020_to_x0 >= '2019-11-19' and 
A.Billing_x0020_Type not in ('N/A - Non-billable','Monthly Fee')
And A.CUrrent_x0020_Status not like '18-Request Cancelled'
and B.TicketNumber is null
and C.TicketNumber is null
Order by Client_X0020_Name
--------------------------------------------------------------------------------------------------------------------------------------------------
--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--Set BillingOption = 'N/A - Non-billable'
--where Ticketnumber in (1884,1857,1660,1700,1754,1808)


Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ('5399','5333','5365','5346','5339')

Select * From [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ('5399','5333','5365','5346','5339')


Select * From  [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
where ID = '4895'

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
where CustomerName like 'Alliance%'

Select *  From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where CustomerName like 'Green%'

--Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where ID in (70580,70583)


Select TicketNumber, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A where ticketnumber in ('1724','1691','1697','1684')
Order by A.ticketnumber,Createdate desc


Select TicketNumber, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
where CustomerName like 'AAM%'
Order by Createdate desc

Select TicketNumber, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] 
where CustomerName like 'AAM%'
Order by Createdate desc

Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] where ID = '454'






-- Delete last months processed jobs

	Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate, B.BillingDate,A.DocImageCounts, B.DocImageCounts FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	inner join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	A.TicketNumber = B.TicketNumber
	and 
	A.BillingDate = B.BillingDate
	and 
	ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	and
	A.TotalBillableUnits = B.TotalBillableUnits
    WHERE A.BillingDate IS NOT NULL
	--and A.CustomerName like '1Tract'
	order by A.CustomerName, A.TicketNumber,A.CreateDate


	Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	where BillingDate is not null
	Order by BillingDate

	Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	where Ticketnumber in ('2994')

	Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
	where Ticketnumber in ('2994')




	--Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate, A.BillingDate,A.TotalRecords,A.TotalBillableUnits FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	--WHERE A.BillingDate IS NOT NULL
	--order by A.CustomerName, A.TicketNumber,A.CreateDate

	--Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate,A.BillingDate,A.TotalRecords,A.TotalBillableUnits FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]  AS A
	--WHERE A.BillingDate IS NOT NULL and A.TicketNumber = '1096' and A.CreateDate = '2017-06-23 11:44:11.263'
	--order by A.CustomerName, A.TicketNumber,A.CreateDate



	DELETE A
	--Select * 
	FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	inner join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	A.TicketNumber = B.TicketNumber
	and 
	A.BillingDate = B.BillingDate
	and 
	ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	and
	ISNULL(A.TotalBillableUnits,'') = ISNULL(B.TotalBillableUnits,'')
    WHERE A.BillingDate IS NOT NULL --AND BillingOption != 'N/A - Non-billable'

	--Delete 
	----Select * 
	--from [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	--where BillingDate < '2017-12-25 06:43:16.017'

---------------------------------------------------------PROCESS BILLING FILE----------------------------------------------------------------------------------------
-- Update the automated billing table where Share Point ID equals automated billing ticket number.
		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.Billing_X0020_Type,MA.Client_x0020_Name,MA.Billing_x0020_Number,REPLACE(MA.Product,';#',''),MA.Title,MA.Contract_x0020_Executed,MA.CUrrent_x0020_Status
		--,cast(cast(left(MA.SOW,3) as money) as int) ,cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.*
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVNSQLDTDB001.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		--JOIN [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		--WHERE MA.Current_x0020_Status = '15-Closed'
--        WHERE MA.Date_x0020_Delivered_x0020_to_x0 > DATEADD(month, -1, GETDATE()) AND MA.Current_x0020_Status = '15-Closed'
		--AND AB.TicketNumber   in (5380,5400)

		--Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where TicketNumber   in (3466,4537)

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where ticketnumber in (3788,3712)

		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.Billing_X0020_Type,MA.Client_x0020_Name,MA.Billing_x0020_Number,REPLACE(MA.Product,';#',''),MA.Title,MA.Contract_x0020_Executed,MA.CUrrent_x0020_Status
		--,cast(cast(left(MA.SOW,3) as money) as int) ,cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.*
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		--JOIN [AZUVNSQLDTDB001.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		JOIN [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		

	-------Update CreateDate where null
		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVNSQLDTDB001.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null

		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null

	-----------------Determine number of products & split them out------------------
		
		Update A
		Set 
		A.NUM_PRODUCTS = (Select ((len(product) - Len(Replace(Product,';#','')))/2)-1)
	
		,A.PRODUCT1 = left((Replace(Product,';#','')),charindex(';#',Product,3)-3) 
		,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
			left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
		,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
			left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

		,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3)  END

		,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),3)-3) END
	
		
		--Select * 
		From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVNSQLDTDB001.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		--AND 
		--A.TicketNumber   in (5380,5400)

			Update A
			Set 
			A.NUM_PRODUCTS = (Select ((len(product) - Len(Replace(Product,';#','')))/2)-1)
		
			,A.PRODUCT1 = left((Replace(Product,';#','')),charindex(';#',Product,3)-3) 
			,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
			left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
			,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
			left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

			,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3)  END

			,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),3)-3) END
		
	
			From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
			join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
			on A.ticketNumber = B.ID
			where 
			A.NUM_PRODUCTS is null
			AND 
			LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
	



		Select * From  [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		where TicketNumber   in (3712)

		--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		--Set 
		--Product1 = 'S10 - Property Info'
		--,Product2 = 'S11 - Foreclosure Status'
		--,Product3 = 'S12 - Open Lien Search'
		--,Product4 = 'S13 - Mortgages & Deeds'
		--,Product5 = 'S15 - Sales Listings'
		--,Product6 = 'S17 - Estimate of Market Value'
		--,Product7 = 'S29 - Voluntary Lien'
		--,Product8 = 'S33 - Owner Association'
		--,Product9 = 'S32 - Address Verification'
		--where Ticketnumber = 3304


		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		where Ticketnumber = 3304


	


		--Select CustomerName, Title, Product1, Product2, Product3 From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where BillingDate is null
		--and NUM_PRODUCTS > 1
		--Order by CustomerName


		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where TicketNumber = '1096'


		Update A
		Set 
		[CMASProductName] = [PRODUCT1]
		,[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		--where CMAS_PRODUCT_SHAREPOINT  like '%S50%'
		--WHERE A.TicketNumber   in (1096)
		where 
		[CMASProductName] is null
			--AND A.TicketNumber    in (5380,5400)

			--Select * FRom [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] 
			--where TicketNumber   in (3596)


		--Update A
		--Set 
		--[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		----where CMAS_PRODUCT_SHAREPOINT  like '%S50%'
		--WHERE A.TicketNumber   in (1096)
		
		
		

		----------------------TWO products on one ticket - ADD NEW RECORD-------------
		Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT2,3)
	  ,PRODUCT2
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT2 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  FROm [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 2
	  ISNULL(PRODUCT2,'') NOT LIKE ''
	  and Status = '15-Closed'
	  and CustomerName not like '1Tract '
	  AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT2 not like 'Counts'
	   AND PRODUCT2 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
	  --and CMAS_PRODUCT_SHAREPOINT like '%S50%'
	  --and TicketNumber  in (4950)
	  And BillingDate is null
	  
	  


	  Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'
	    Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
	  where ticketnumber = '3712'
	  Order by BillingDate Desc

	

	  --------------------------------3 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT3,3)
	  ,PRODUCT3
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT3 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 3
	  ISNULL(PRODUCT3,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT3 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT3 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'


	  --------------------------------4 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT4,3)
	  ,PRODUCT4
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT4 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 4
	  ISNULL(PRODUCT4,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT4 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT4 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'


	--------------------------------5 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT5,3)
	  ,PRODUCT5
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT4 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 5
	  ISNULL(PRODUCT5,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT5 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT5 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
	    
	    

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'



		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		where CustomerName like '%texas%'

		--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'DMP Parcel Boundaries'
		--where Id = 117480

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CustomerName like '%texas%'

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		where CMASProductCode is null

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		Order by CMASProductName

		

		--Insert into [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode, CMASProductName,OracleProductCode, OracleProductName)
		--Values('DMP Parcel Boundaries','DMP Parcel Boundaries','18712','Bulk - Points & Polygons')

		
		
		Update A
		Set 
		[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where ([CMASProductName] like 'S50%' or PRODUCT1 like 'S50%')
		and [TotalBillableUnits] is null
			--AND TicketNumber   in (5380,5400)

		

	

	  -- Update CMASProductCode with from CMASProductName
		UPDATE AB
		SET AB.CMASProductCode = case when LEFT([CMASProductName],6) like 'S__ - ' and [CMASProductName] not like '%Bulk%'	then substring([CMASProductName],1,3)
		else [CMASProductName] end
		--Select [CMASProductName]
		--Select * 
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE 
		(AB.CMASProductCode IS NULL or AB.CMASProductCode = '')
		 and Status = '15-Closed'
		  --and    AB.TicketNumber   in (5380,5400)
		AND AB.BillingDate is null


		UPDATE AB
		SET AB.CMASProductCode = [CMASProductName] 
		--Select AB.CMASProductCode ,[CMASProductName]
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE CMASProductCode like 'Bul' 
		and CMASProductCode  <> [CMASProductName]
		 and Status = '15-Closed'
		 AND AB.BillingDate is null


		 --Select * From  [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		 --where customername like 'Baupost%'

		 Select * FRom [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		 where CMASProductName like '%bound%'

		 
		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'

	   
		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber in ('4388','4393')


		UPDATE [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET CMASProductCode = CMASProductName
		--Select * from [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CMASProductCode like 'Bul%'
		and CMASProductCode <> CMASProductName
		AND BillingDate is null
		
		
	-- Update the automated billing table with the Oracle product code and name based on the lookup table.
		UPDATE AB
		SET AB.OracleProductCode = AP.OracleProductCode,
		AB.OracleProductName = AP.OracleProductName
		 --SELECT AB.OracleProductCode,AP.OracleProductCode
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		JOIN [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		ON AB.CMASProductCode = AP.CMASProductCode
		where AB.Status = '15-Closed'
		--and AB.TicketNumber  in (5380,5400)
		AND AB.BillingDate is null


		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where TicketNumber in ( '3712','3788','4537')

	

		Select TicketNumber,CustomerName,CreateDate,CMASProductCode, CMASProductName, OracleProductCode, BillingDate, Status, BillingOption From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where OracleProductName is null and Status = '15-Closed'

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		Order by CMASProductCode

		


		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CustomerName like 'Managed%' and Billingdate is null


		


		--UPDATE AB
		--SET AB.OracleProductCode = '18720',
		--AB.OracleProductName = 'Bulk â€“ Other'
		-- --SELECT *
		--FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		--where AB.TicketNumber   in (2784)
		

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		where --CMASProductCode = 'Bulk - Other'  
		CMASProductCode = 'Bulk â€“ Other'
						  --'Bulk - Other'
		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where ticketnumber in (2784)


		--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'Bulk - List'
		--where ticketnumber in (1937,1946)
		
		  --and AB.TicketNumber in ('1558','1548','1526','1547','1559')

		  Select * From  [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		  Order by CMASProductName

		--Select * From  [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
		--where CustomerName like 'Managed%'

		Select *  FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CustomerName like 'Managed%'
		  
	
	Select CustomerName, CreateDate, BillingOption ,* From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] A
	Order by  A.CustomerName, A.CreateDate
	

	-- Update TotalBillableUnits based on BillingOption
		UPDATE [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.automatedbilling
		SET TotalBillableUnits = case
		when substring(BillingOption,1,1) = '1' then TotalRecords
		when substring(BillingOption,1,1) = '2' then TotalMatched
		when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		else 0 end 
		where CMASProductCode != 'S50'
		and Status = '15-Closed'
		  --and TicketNumber in (5380,5400)
		AND BillingDate is null
		--AND BillingDate  >= Getdate()-.05 and TotalBillableUnits = 0

		
		--Select Ticketnumber, CustomerName,TotalBillableUnits,TotalWithEventsFound
		--,case
		--when substring(BillingOption,1,1) = '1' then TotalRecords
		--when substring(BillingOption,1,1) = '2' then TotalMatched
		--when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		--when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		--when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		--when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		--else 0 end 
		--From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.automatedbilling
		--where Ticketnumber = 4024


		-- Update Billing date to getdate()
		UPDATE [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE 
		[AccountNumber] IS NOT NULL 
		AND [BillingOption] IS NOT NULL 
		AND [CMASProductCode] IS NOT NULL 
		AND [ContractExecuted] = 'Yes' 
		AND OracleProductCode is not NULL
		AND [BatchType] is not null
		AND STATUS like '15-Closed'
		and BillingDate is null
		  --and TicketNumber in (5380,5400)
		  


				
		----------------Per Nicole 20191025 - Push the Fams post Close & FAPC records to Finance even though there is not account number!!!---
		---------------Changed FAMS is no longer billable oer Nicole ----
		Select  CMASProductName, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		where TicketNumber = '1940'
		Order by CreateDate, TotalRecords,A.CMASProductName


		UPDATE [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE TicketNumber = '1940'
		and BillingDate is null


		----FAPC---
		Select  CMASProductName, * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		where TicketNumber = '4029'
		Order by CreateDate, TotalRecords,A.CMASProductName

		UPDATE [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE TicketNumber = '4029'
		and BillingDate is null

		----------------------------Start here------------------

		---------------------------------------------------------------------------------
		Select TicketNumber, CustomerName,BillingDate,PROCESSED_YN,[AccountNumber],[BillingOption],[CMASProductCode],[ContractExecuted],OracleProductCode, [BatchType], STATUS
		From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where BillingDate is null and BillingOption not like 'N/A - Non-billable' and Status not like '18-Request Cancelled'
		Order by TicketNumber

		--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set [CMASProductCode] = 'Bulk - Involuntary Lien'
		--where ticketnumber in (5380,5400)

		Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		Order by CMASProductName
		--Bulk - Involuntary Liens
		
		Select *  From [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling] where CustomerName like 'Managed%'
		and BillingDate is null
		Order by CreateDate

		--UPdate [SNAPNSQLDTDB010.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'S20'
		--where TicketNumber = '1234'
		--and CMASProductCode = 'Cou'
		

		------Email any bad records------
		
		--DECLARE @xml NVARCHAR(MAX)
		--DECLARE @body NVARCHAR(MAX)
		--DECLARE @Subject NVARCHAR(MAX)
		--DECLARE @DATE varchar(10)

		--Set @Date = convert(varchar(10),Getdate(),112)
		--Set @Subject = 'ADS AutoBilling - POTENTIAL BAD RECORDS_' + @Date

		--SET @xml = 
		--CAST(( SELECT 
		--CUSTOMERNAME as 'td',''
		--,TicketNumber as 'td',''
		--,Processed_YN as 'td',''
		--,TotalWithEventsFound as 'td',''
		--,BillingOption as 'td',''
		--,Status as 'td',''
		--,case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end  as 'td','',
		--[CMAS_PRODUCT_SHAREPOINT] as 'td',''
		--,[TotalRecords] as 'td',''
		--, case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end  as 'td','',
		--case when [BatchType] IS NULL then 'empty' else [BatchType] end  as 'td','',
		--case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as 'td','',
		--case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end  as 'td',''
		--,DocImageCounts as 'td'
		--FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--WHERE 
		--[CMASProductCode] IS NULL or [CMASProductCode] like ''
		--OR
		--([TotalRecords] < 1 AND [CMASProductCode] NOT LIKE 'S50') 
		--OR
		--[AccountNumber] IS NULL or [AccountNumber] like ''
		--OR
		--[BatchType] IS NULL or [BatchType] like ''
		--OR
		--([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%') 
		--OR
		--([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		--OR
		--[ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null
		--OR TotalBillableUnits = 0 or TotalBillableUnits is null
		--or STatus != '15-Closed'
		--order by CUSTOMERNAME
		--FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


		--SET @body =
		--'<html><body><H3>ADS AutoBilling - POTENTIAL BAD RECORDS_' + @Date + '</H3>
		--<table border = 1> 
		--<tr><th> CUSTOMERNAME  </th> <th> TicketNumber </th> <th> Processed_YN </th> <th> TotalWithEventsFound </th> <th> BillingOption  </th> <th> Status  </th> <th> CMASProductCode   </th> <th> CMAS_PRODUCT_SHAREPOINT 
		--  </th> <th> TotalRecords   </th> <th> AccountNumber   </th> <th> BatchType   </th> <th> ContractExecuted   </th> <th> TotalBillableUnits 
		--    </th> <th> DocImageCounts   </th></tr>'   

		--SET @body = 
		--case when (Select count(*) FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--WHERE 
		--[CMASProductCode] IS NULL or [CMASProductCode] like ''
		--OR
		--([TotalRecords] < 1 AND [CMASProductCode] NOT LIKE 'S50') 
		--OR
		--[AccountNumber] IS NULL or [AccountNumber] like ''
		--OR
		--[BatchType] IS NULL or [BatchType] like ''
		--OR
		--([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%') 
		--OR
		--([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		--OR
		--[ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null
		--OR TotalBillableUnits = 0 or TotalBillableUnits is null
		--or STatus != '15-Closed') = 0 then 'All records OK' 
		-- else
		--@body + @xml +'</table></body></html>' 
		--END

		-------------sp_send_dbmail example-------------
		--EXEC msdb.dbo.sp_send_dbmail
		--@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
		--@body = @body,
		--@body_format ='HTML',
		--@recipients = 'klowe@firstam.com',
		--@subject = @subject;

	


	--------CHECK FOR GREEN RIVER-------------------------------------------------------------------------

	
	Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
	where AccountNumber = '118751'



	-- Check field validation. If key fields are NULL or zero send alert email
		SELECT 
		CUSTOMERNAME, TicketNumber,Processed_YN,TotalWithEventsFound,TotalMatched,BillingOption,Status,
		case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end as [CMASProductCode],CMASPRODUCTNAME,[ORACLEProductCode],
		[CMAS_PRODUCT_SHAREPOINT],
		[TotalRecords], 
		case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end as [AccountNumber],
		case when [BatchType] IS NULL then 'empty' else [BatchType] end as [BatchType],
		case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as [ContractExecuted],
		case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end as TotalBillableUnits
		,DocImageCounts, CreateDate,BillingDate
		FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE 
		((([CMASProductCode] IS NULL or [CMASProductCode] like ''
		OR
		[ORACLEProductCode] IS NULL or [ORACLEProductCode] like '') AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([TotalRecords] < 1 AND [CMASProductCode] NOT LIKE 'S50' AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee'))  
		OR
		(([AccountNumber] IS NULL or [AccountNumber] like '' or AccountNumber like 'N/A' or AccountNumber like 'empty') AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([BatchType] IS NULL or [BatchType] like '')
		OR
		([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%' and 
				(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		OR
		(([ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null) AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR 
		((TotalBillableUnits = 0 or TotalBillableUnits is null) AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		or (STatus != '15-Closed')
		)
		AND  STatus != '18-Request Cancelled'
		order by CUSTOMERNAME
		

		

		--Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--where TicketNumber = '3844'

		Select ID, BatchType,CustomerName, TicketNUmber,CreateDate, TotalMatched,TotalREcords, TotalWithEventsFound, BillingDate, CMASProductCode , DocimageCounts
		,TotalBillableUnits
		From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		where ticketnumber in (4512,3465,4950) 
		--AND CMASProductCode like 'S50'
		Order by BatchType,CreateDate

		
		
		--Delete from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--where ID in (202148,202355,202364,202376,202377,202371,202365,202356,202350,202361,202367,202373,202139,202374,202368,202362,202354,202369,202375,202141)

		--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--Set TotalwithEventsFound = TotalRecords
		--where ticketnumber in (4024)


	--Delete from  [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
	--where ID in (70607,70608)

----Update BillingDate for non-billable tickets

Update [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
SET BillingDate = Getdate() 
WHERE (BillingDate IS NULL and [BillingOption] like 'N/A - Non-billable'
and Status like '15-Closed')
OR
(BillingDate IS NULL and CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization'
and AccountNumber = '118108')
OR
([BillingOption] like  'Monthly Fee' and BillingDate is null
and Status like '15-Closed')
OR
([BillingOption] like  'Flat Fee' and BillingDate is null
and Status like '15-Closed' and AccountNumber is not null)




--Update [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--Set PROCESSED_YN = 'Y'
--where Ticketnumber = '1838'


INSERT INTO [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] (
       [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,[ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO)
SELECT [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,GETDATE() -- [ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO
 FROM [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
WHERE 
(BillingDate IS NOT NULL and PROCESSED_YN = 'Y')
 or ([BillingOption] like 'N/A - Non-billable' and BillingDate IS NOT NULL)
-- and Createdate < Getdate() - 30 )
-- OR (CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
-- and BillingDate IS NOT NULL)
-- --OR ID in (2452,2718,2733,2610,2881)
 --CustomerName like 'States Title' and BillingDate IS NOT NULL


  Select CustomerName, CMASProductCOde,ID, * from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
  where TicketNUmber = '2994'
Order by A.CMASProductCOde

 Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where [AccountNumber] = '130372'


 --Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 --where BillingDate = '2019-03-25 08:33:08.157'
 --and BillingOption not in ('Monthly Fee','N/A - Non-billable')



 -----------------------REMOVE WELLS FARGO-------------
 Select * from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where 
 CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
 and BillingDate IS NOT NULL


 Select * from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
 where 
 Title like 'WF Monthly Lien Monitoring - Old & New (soft close) ' and AccountNumber = '118108'
 and BillingDate IS NOT NULL
 Order by CreateDate desc


Select * from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] as A join 
[SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
A.TicketNumber = B.TicketNumber and A.CMASProductCode = B.CMASProductCode
and A.BillingDate = B.BillingDate
where 
--A.CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and 
A.AccountNumber = '118108'
and A.BillingDate IS NOT NULL

Select * 
 --Delete 
 from [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where 
 CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
 and BillingDate IS NOT NULL
 


 ------------------------------------------------------------------------------------------
 --Select * From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
 --where TicketNumber = '812'



--		Select *, 
--((len(product) - Len(Replace(Product,';#','')))/2)-1 as NUM_PRODUCTS,
--left((Replace(Product,';#','')),charindex(';#',Product,3)-3) as Product1,

--case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then '' else 
--Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END as Product2,

--case when (Case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then 0 else 
--charindex(';#',Product,(charindex(';#',Product,charindex(';#',Product,3)+3))+3) END) = 0 then '' else 
--Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END as Product3

--From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
--join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
--on A.ticketNumber = B.ID
--where A.BillingDate is null
--order by Client_X0020_Name, A.TicketNumber



Select A.AccountNumber,A.ID,A.TicketNumber,A.CustomerName, A.CreateDate,A.BatchType,B.Title,A.CMASProductCOde,CUrrent_x0020_Status as Status, A.TotalRecords,A.TotalBillableUnits, A.BillingOption 
,A.[CMASProductName]
,Replace(Product,';#','') as Product
,A.OracleProductCode, A.ContractExecuted
,A.DocImageCounts
,Billing_x0020_Type as Billing_Type
,Billing_x0020_Number as CustomerNumber
,A.BillingDate
,A.NUM_PRODUCTS
,A.Product1
,A.Product2
,A.Product3
,B.SOW
,B.WO
,A.BillingDate
From [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
join [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
on A.ticketNumber = B.ID
where A.BillingOption not like 'N/A - Non-billable'
--and CUrrent_x0020_Status like '15-Closed'
order by A.AccountNumber, B.Title,A.CMASProductCOde


Select TicketNumber,CmasProductCode,* From  [SNAPNSQLDTDB010.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where CustomerName like 'Gateway%'
Order by A.TicketNumber



END








