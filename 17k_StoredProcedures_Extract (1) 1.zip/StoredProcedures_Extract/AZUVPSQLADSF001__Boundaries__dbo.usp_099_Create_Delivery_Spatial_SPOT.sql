SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[usp_099_Create_Delivery_Spatial_SPOT]
AS
BEGIN

	SET NOCOUNT ON;

		DECLARE @DATE as varchar(8)
		SET @DATE = convert(varchar(8),GETDATE(),112)

		EXEC('DROP TABLE IF EXISTS [Delivery].[Spatial_SPOT_WORK_' + @Date + ']
				DROP TABLE IF EXISTS [Delivery].[Spatial_SPOT_' + @Date + ']

		SELECT * INTO [Delivery].[Spatial_SPOT_WORK_' + @Date + '] FROM [Delivery].[Spatial_SPOT_Template]

		TRUNCATE table [Delivery].[Spatial_SPOT_WORK_' + @Date + ']
		
		SELECT * INTO [Delivery].[Spatial_SPOT_' + @Date + '] FROM [Delivery].[Spatial_SPOT_Template]

		TRUNCATE table [Delivery].[Spatial_SPOT_' + @Date + ']
		')

		Declare @StartREFID as bigint
		SELECT @StartREFID = MAX(PropertyID) FROM Delivery.[CreatedREFID] WHERE Used = 'N'

			EXEC('INSERT INTO [Delivery].[Spatial_SPOT_WORK_' + @Date + ']
			SELECT CASE WHEN PropertyID IS NULL THEN (' + @StartREFID + ' - (ROW_NUMBER() OVER(PARTITION BY PropertyID ORDER BY PropertyID)-1)) ELSE PropertyID END as PropertyID
			,[FIPS]
			,[LotSqFt]
			  ,[Shell]
			  ,[Multi]
			  ,[Parcel].MakeValid()
			  ,[Latitude]
			  ,[Longitude]
			  ,[Point]
			  ,[SourceID]
			  ,CASE WHEN (PropertyID is NULL and Parcel is null) then 5 ELSE [SourceGeocodeID] END [SourceGeocodeID]
			  ,Case when (PropertyID is NULL and Parcel is null) then 1 ELSE [FAGeocodeID] END as [FAGeocodeID]
			  ,[ProcessDate]
			  ,[CurrencyDate]
			  ,[Stacked]
			  ,[RowRevision]
			  ,[CREATED]
			  ,[Precision]
			  ,cast(NULL as int)  PropIDSeq
			  FROM [Boundaries].[dbo].[vSPOT_DTDB_V2]
			  ')
		  
			EXEC('INSERT INTO [Delivery].[Spatial_SPOT_' + @Date + ']
			SELECT PropertyID
			,[FIPS]
			,[LotSqFt]
			  ,[Shell]
			  ,[Multi]
			  ,[Parcel]
			  ,[Latitude]
			  ,[Longitude]
			  ,[Point]
			  ,[SourceID]
			  ,[SourceGeocodeID]
			  ,[FAGeocodeID]
			  ,[ProcessDate]
			  ,[CurrencyDate]
			  ,[Stacked]
			  ,[RowRevision]
			  ,[CREATED]
			  ,[Precision]
			  ,ROW_NUMBER() OVER(PARTITION BY PropertyID ORDER BY PropertyID)  PropIDSeq
			  FROM [Delivery].[Spatial_SPOT_WORK_' + @Date + ']
			 ') 

			EXEC('Delete from [Delivery].[Spatial_SPOT_' + @Date + '] where PropIDSeq <> 1 or PropertyID is NULL

			Alter table [Delivery].[Spatial_SPOT_' + @Date + '] drop column PropIDSeq

			  ')


			EXEC('INSERT INTO [Delivery].[Spatial_SPOT_' + @Date + ']
					   ([PropertyId]
						  ,[FIPS]
						  ,[LotSqFt]
						  ,[Shell]
						  ,[Multi]
						  ,[Parcel]
						  ,[Latitude]
						  ,[Longitude]
						  ,[Point]
						  ,[SourceId]
						  ,[SourceGeoCodeId]
						  ,[FAGeoCodeId]
						  ,[ProcessDate]
						  ,[CurrencyDate]
						  ,[Stacked]
						  ,[RowRevision]
						  ,[created]
						  ,[Precision])
				Select  
					   [REF_ID]																	--PropertyID
					   ,RIGHT(''0'' + convert(varchar(5),ltrim(rtrim(b.Fips))),5)					--FIPS
					   ,NULL																	--[LotSqFt]
					   ,0																		--[Shell]
					   ,0																		--[Multi]
					   ,b.GEOM3857.MakeValid()													--[Parcel]				--ParcelGeometry
					   ,b.[Latitude]															--[Latitude]			--Latitude
					   ,b.[Longitude]															--[Longitude]			--Longitude
					   ,b.GEOM4269																--[Point]				--ParcelPointGeometry
					   ,3																		--[SourceId]
					   ,CASE WHEN GeoCodeResults = ''GS05'' THEN 1
							 WHEN GeoCodeResults = ''GS06'' THEN 2
							 WHEN GeoCodeResults = ''GS01'' THEN 3
							 WHEN GeoCodeResults = ''GS02'' THEN 4
							 WHEN GeoCodeResults = ''GS03'' THEN 5
							 WHEN GeoCodeResults = ''GS04'' THEN 6
							 WHEN GeoCodeResults = ''GE01'' THEN 7
							 WHEN GeoCodeResults = ''GE02'' THEN 8
							ELSE 5
							END 																--[SourceGeoCodeId]
					   ,CASE WHEN GeoCodeResults = ''GS05'' THEN 1
							 WHEN GeoCodeResults = ''GS06'' THEN 2
							 WHEN GeoCodeResults = ''GS01'' THEN 3
							 WHEN GeoCodeResults = ''GS02'' THEN 4
							 WHEN GeoCodeResults = ''GS03'' THEN 5
							 WHEN GeoCodeResults = ''GS04'' THEN 7
							END																	--[FAGeoCodeId]
					   ,b.updated_date															--[ProcessDate]
					   ,GETDATE()																--[CurrencyDate]
					   ,0																		--[Stacked]
						,Cast(updated_date as varbinary)										--[RowRevision]
						,GETDATE()																--[created]
						,[Precision]

					from [Delivery].[Spatial_SPOT_' + @Date + ']  a 
						Right outer JOIN (Select ADDRID,FIPS,REF_ID,Latitude,Longitude,updated_date,created
						,geometry::STGeomFromText(''POINT(''+cast(cast(dbo.LongToMercatorX(Longitude)as decimal(17,6)) as varchar(30))+'' ''+cast(cast(dbo.LatToMercatorY(Latitude) as decimal(17,6)) as varchar(30))+'')'',3857) as GEOM3857
						,geography::Point([Latitude],[Longitude],  4269) as GEOM4269
						,AddressTypeCode,GeoCodeResults
						 from [AZUVPSQLDTDB029.datatree.local].Addr.dbo.CL_Address_Base with(NOLOCK)
							WHERE GeoCodeResults is NOT NULL
							and isNULL(latitude,0) <> 0 and isNULL(longitude,0) <> 0
							and Address_Type = ''S'') b
					on a.[PropertyID] = b.REF_ID
					where a.[PropertyID] is null
				
					')



			EXEC('INSERT INTO [Delivery].[Spatial_SPOT_' + @Date + ']
					   ([PropertyId]
						  ,[FIPS]
						  ,[LotSqFt]
						  ,[Shell]
						  ,[Multi]
						  ,[Parcel]
						  ,[Latitude]
						  ,[Longitude]
						  ,[Point]
						  ,[SourceId]
						  ,[SourceGeoCodeId]
						  ,[FAGeoCodeId]
						  ,[ProcessDate]
						  ,[CurrencyDate]
						  ,[Stacked]
						  ,[RowRevision]
						  ,[created])
				Select  
					   [DTDB_REF_ID]																	--PropertyID
					   ,b.Fips																			--FIPS
					   ,NULL																			--[LotSqFt]
					   ,0																				--[Shell]
					   ,0																				--[Multi]
					   ,b.GEOM3857.MakeValid()															--[Parcel]														--ParcelGeometry
					   ,b.[Lat]																			--[Latitude]													--Latitude
					   ,b.[Long]																		--[Longitude]													--Longitude
					   ,b.GEOM4269																		--[Point]													--ParcelPointGeometry
					   ,3																				--[SourceId]
					   ,CASE WHEN SitusGeoCodeResults = ''GS05'' THEN 1
							 WHEN SitusGeoCodeResults = ''GS06'' THEN 2
							 WHEN SitusGeoCodeResults = ''GS01'' THEN 3
							 WHEN SitusGeoCodeResults = ''GS02'' THEN 4
							 WHEN SitusGeoCodeResults = ''GS03'' THEN 5
							 WHEN SitusGeoCodeResults = ''GS04'' THEN 6
							 WHEN SitusGeoCodeResults = ''GE01'' THEN 7
							 WHEN SitusGeoCodeResults = ''GE02'' THEN 8
							 ELSE 5
							END 																		--[SourceGeoCodeId]
					   ,CASE WHEN SitusGeoCodeResults = ''GS05'' THEN 1
							 WHEN SitusGeoCodeResults = ''GS06'' THEN 2
							 WHEN SitusGeoCodeResults = ''GS01'' THEN 3
							 WHEN SitusGeoCodeResults = ''GS02'' THEN 4
							 WHEN SitusGeoCodeResults = ''GS03'' THEN 5
							 WHEN SitusGeoCodeResults = ''GS04'' THEN 7
							END																			--[FAGeoCodeId]
					   ,b.FATimestamp																	--[ProcessDate]
					   ,GETDATE()																		--[CurrencyDate]
					   ,0																				--[Stacked]
						,Cast(cast(FATimestamp as datetime) as varbinary)													--[RowRevision]
						,GETDATE()																		--[created]

					from [Delivery].[Spatial_SPOT_' + @Date + '] a 
						Right outer JOIN (
							Select PROPERTYID,FIPS,DTDB_REF_ID,[SitusLatitude] as Lat,[SitusLongitude] Long,FATimestamp,FADateReceived
								,geometry::STGeomFromText(''POINT(''+cast(cast(dbo.LongToMercatorX([SitusLongitude])as decimal(17,6)) as varchar(30))+'' ''+cast(cast(dbo.LatToMercatorY([SitusLatitude]) as decimal(17,6)) as varchar(30))+'')'',3857) as GEOM3857
								,geography::Point([SitusLatitude],[SitusLongitude],  4269) as GEOM4269
								,SitusGeoCodeResults
								 from data.dbo.property with(NOLOCK)
								 where SitusGeoCodeResults is not null and SitusGeoCodeResults Not like ''''
								 and isNULL([SitusLatitude],0) <> 0 and isNULL([SitusLongitude],0) <> 0
					) b
				on a.[PropertyID] = b.DTDB_REF_ID
				where a.[PropertyID] is null and b.DTDB_REF_ID is NOT NULL			
				')


			Select RefID, SqFt INTO #PointSqft from OPENQuery([AZUVPSQLDTDB034],'Select RefID,SqFt from Spot.dlvry.point')

			Create index ix_REFID on #PointSqft(RefID)

			EXEC('UPDATE a
			SET a.[LotSqFt] = round(b.SqFt,0)
			FROM [Delivery].[Spatial_SPOT_' + @Date + '] a JOIN #PointSqft b
			on a.PropertyID = b.RefID
			Where a.[LotSqFt] is null
			')

			EXEC('UPDATE [Delivery].[Spatial_SPOT_' + @Date + ']
			SET [LotSqFt] = NULL 
			WHERE parcel.STAsText() like ''%point%''
			and [LotSqFt] is NOT NULL')

			EXEC('update [Delivery].[Spatial_SPOT_' + @Date + ']
					set LotSqFt = Round(LotSqFt,0)
					Where LotSqFt is not null and str(LotSqFt,20,4) not like ''%.0000''')

			EXEC('UPDATE a
			SET a.[Precision] = b.[Precision] 
			FROM [Delivery].[Spatial_SPOT_' + @Date + '] a JOIN delivery.GeoCodeMapping b With(NOLOCK)
			ON a.[SourceGeoCodeId] = b.[SourceGeoCodeId]
			WHERE b.[SourceId] = 8
			and a.[Precision] is NULL')

				EXEC('UPDATE a
				SET a.Used = ''Y''
				,DateUsed = GetDate()
				FROM Delivery.[CreatedREFID] a JOIN [Delivery].[Spatial_SPOT_WORK_' + @Date + '] b
				ON a.PropertyID = b.PropertyID
				')

				EXEC('update a
				SET a.FAGeoCodeId = b.FAGeoCodeId
				,a.Precision = b.Precision
				from Boundaries.Delivery.Spatial_SPOT_WORK_' + @Date + ' a JOIN Boundaries.Delivery.GeoCodeMapping b with(NOLOCK)
				on a.SourceGeoCodeId = b.SourceGeoCodeId
				and a.SourceId = b.SourceId
				where a.FAGeoCodeId is NULL and a.SourceId = 3 and a.SourceGeoCodeId = 5
				')

				EXEC('update Delivery.Spatial_SPOT_WORK_' + @Date + ' set LotSqFt = Round(LotSqFt,0) Where LotSqFt like ''%.%''')

				EXEC('update a
				SET a.Precision = b.Precision
				from Boundaries.Delivery.Spatial_SPOT_WORK_' + @Date + ' a JOIN Boundaries.Delivery.GeoCodeMapping b with(NOLOCK)
				on a.FAGeoCodeId = b.FAGeoCodeId
				and a.SourceGeoCodeId = b.SourceGeoCodeId
				and a.SourceId = b.SourceId
				where a.Precision != b.Precision
				')

				EXEC('Update Boundaries.Delivery.Spatial_SPOT_WORK_' + @Date + ' set parcel = parcel.MakeValid() where parcel.STIsValid() = 0')


END

