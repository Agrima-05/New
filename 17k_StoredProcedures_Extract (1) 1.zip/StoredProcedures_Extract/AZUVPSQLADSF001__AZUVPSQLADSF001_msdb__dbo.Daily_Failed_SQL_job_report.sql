SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE PROCEDURE [dbo].[Daily_Failed_SQL_job_report] 
(		@job_name  nvarchar (4000) = NULL, 
   		@date_from       varchar(20) = NULL
		
)	
AS 
    SET NOCOUNT ON  
BEGIN                      
 SET NOCOUNT ON  
--a Specific job completion report
/*
Author: Arun Agunuru & Jerry Ho
Date Created: 06/26/2018
*/
declare @jobname nvarchar (4000)
Declare @SQL Varchar(max)

declare @SQLPrint varchar(max) 
Declare @SQLExec varchar(Max)
Declare @procParameters nvarchar(max)
declare @t as table(Servername sysname,Job_Name varchar(1000),--Run_Status bit,
Run_Status_Report varchar(100),Number_of_Failures int,Completion_Time_HHMMSS varchar(20),[Start_Date] datetime,[Error_Message] varchar(max))
set nocount ON


IF @date_from IS NULL
	SET @date_from = CONVERT(varchar(20),GETDATE()-7,110)

declare curjobs cursor for
select j.Name from msdb.dbo.sysjobs AS j 
where name LIKE '%' + @job_name + '%' OR @job_name is null
--select @job_name = @jobname,
--@date_from  = NULL 
set @SQL =
'Declare @Failurecount nvarchar(4000)
SELECT  @Failurecount =  COUNT(*) 
FROM msdb.dbo.sysjobhistory h
INNER JOIN msdb.dbo.sysjobs j ON h.job_id = j.job_id
WHERE j.name = ''@jobname'' and  msdb.dbo.agent_datetime(run_date, run_time) >=  ''' + @date_from + ''' and run_status <> 1 and step_id =0

SELECT serverName=@@SERVERNAME,
    j.Name as Job_Name,
   -- h.Run_Status,
      CASE h.Run_Status  
WHEN ''0'' THEN ''Failed''
WHEN ''1'' THEN ''Success''
WHEN ''2'' THEN ''Retry''
WHEN ''3'' THEN ''Canceled''
WHEN ''4'' THEN ''In progress''
   END AS Run_Status_Report,  
   Number_of_Failures =@Failurecount,
          Completion_Time_HHMMSS = STUFF(STUFF(REPLACE(STR(h.run_duration,6,0),
        '' '',''0''),3,0,'':''),6,0,'':''),
    [Start_Date] = CONVERT(DATETIME, RTRIM(run_date) + '' ''
        + STUFF(STUFF(REPLACE(STR(RTRIM(h.run_time),6,0),
        '' '',''0''),3,0,'':''),6,0,'':'')),
    
        message as Error_Message
FROM
    msdb.dbo.sysjobs AS j
INNER JOIN
    (
        SELECT job_id, instance_id = MAX(instance_id)
            FROM msdb.dbo.sysjobhistory
            GROUP BY job_id
    ) AS l
    ON j.job_id = l.job_id
INNER JOIN
    msdb.dbo.sysjobhistory AS h
    ON h.job_id = l.job_id
    AND h.instance_id = l.instance_id
    where run_status <> 1
    and  msdb.dbo.agent_datetime(run_date, run_time) >=  ''' + @date_from + '''
      and name = ''@jobname''' +'
ORDER BY
    CONVERT(INT, h.run_duration) DESC,
    [start_date] DESC

'






open curJobs
fetch next from curJobs into @jobname
while (@@FETCH_STATUS=0)
Begin

     Begin  
                SET @jobname = REPLACE(@jobname,'''','''''')  
                  SET @SQLExec = REPLACE(@SQL,'@jobname',@jobname)
                  SET @SQLPrint =  @SQLExec + CHAR(10) + 'GO'
                    --PRINT @SQLPrint
                    INSERT INTO @t
                    EXEC(@SQLExec)
              --PRINT (REPLACE(@SQL,'@jobname',@jobname))
       End
       fetch next from curJobs into @jobname
End
SELECT * FROM @t
close curJobs
DeAllocate curJobs

END



