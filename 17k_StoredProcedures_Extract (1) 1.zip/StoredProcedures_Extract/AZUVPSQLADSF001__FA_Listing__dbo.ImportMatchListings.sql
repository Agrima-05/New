SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[ImportMatchListings] @PartitionCount INT
AS
--SSMSBOOST UNBLOCK
-- declare @PartitionCount INT
SET XACT_ABORT ON
SET NOCOUNT ON

DECLARE @Timestamp VARCHAR(25)

SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Set Rental_Ind'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

DROP TABLE

IF EXISTS #HasRental
	SELECT Row_id
	INTO #HasRental
	FROM [FA_Listing].[tmp].[FA_MLS] f
	LEFT JOIN FA_Listing.dbo.[MedianSalePrice_Rolling6Month] z ON left(f.zip, 5) = z.situszip
	WHERE z.rolling_6_months = '2018-05'
		AND (
			MLS_STATUS_STD IN (
				'active'
				,'pending'
				,'contingent'
				)
			OR MLS_STATUS_STD LIKE '%RENT%'
			OR MLS_STATUS_STD LIKE '%active%'
			OR f.PROPERTY_TYPE IN (
				'Apartment Lease'
				,'Commercial Lease'
				,'Commercial-Lease'
				,'Condo Rental'
				,'House for Rent'
				,'LSE-Apartment'
				,'LSE-Condo Townhome'
				,'LSE-Duplex'
				,'LSE-House'
				,'Rental'
				,'Rental - Single Family Detached'
				,'Rental Commercial'
				,'Rental Income'
				,'Residential Lease'
				,'Residential Rental'
				,'RNT'
				)
			OR f.PROPERTY_SUB_TYPE IN (
				'Apartment Lease'
				,'Commercial Lease'
				,'Commercial-Lease'
				,'Condo Rental'
				,'House for Rent'
				,'LSE-Apartment'
				,'LSE-Condo Townhome'
				,'LSE-Duplex'
				,'LSE-House'
				,'Rental'
				,'Rental - Single Family Detached'
				,'Rental Commercial'
				,'Rental Income'
				,'Residential Lease'
				,'Residential Rental'
				,'RNT'
				)
			)
		AND ---- change to use MLS_Status_STD 11/9/2018 
		left(f.zip, 5) NOT IN (
			'35133'
			,'65360'
			,'65265'
			,'27932'
			)
		AND (
			f.PROPERTY_SUB_TYPE NOT IN (
				'Vacant Land'
				,'Lots And Land'
				,'Lot'
				,'Residential - Vacant Land'
				,'Industrial - Vacant Land'
				,'Commercial - Vacant Land'
				)
			OR f.PROPERTY_SUB_TYPE IS NULL
			)
		AND (
			(
				f.property_type NOT LIKE 'lot%'
				AND f.property_type NOT LIKE 'vacant%'
				AND f.property_type NOT LIKE 'Mobile%'
				AND f.Property_type NOT LIKE 'Manufactured%'
				AND f.Property_type NOT LIKE 'Boat%'
				AND f.property_type NOT LIKE '40 - Res-Less%'
				AND f.property_type NOT LIKE '(Manufactured%'
				AND f.property_type NOT LIKE '(Lot%'
				AND f.property_type NOT LIKE '1 - 10 Acres%'
				AND f.property_type NOT LIKE 'Land%'
				AND f.property_type NOT LIKE 'Residential Lot%'
				AND f.property_type NOT LIKE 'Residential Mobile%'
				AND f.property_type NOT LIKE 'Residential (Manufactured%'
				AND f.property_type NOT LIKE '%Time%'
				AND f.property_type NOT LIKE '%Share%'
				AND f.property_type NOT LIKE 'undeveloped land%'
				AND f.Property_type NOT LIKE 'share%'
				AND f.Property_type NOT LIKE 'Residential - Mobile Home%'
				AND f.property_type NOT LIKE 'Parking%'
				AND f.property_type NOT LIKE 'other Residential land%'
				AND f.property_type NOT LIKE 'MFD'
				AND f.property_type NOT LIKE 'LND%'
				AND f.property_type NOT LIKE 'Farm%'
				AND f.property_type NOT LIKE 'Agricultural%'
				AND f.property_type NOT LIKE 'Acreage%'
				AND f.property_type NOT LIKE '21 - %'
				AND f.property_type NOT LIKE 'Agriculture%'
				AND f.property_type NOT LIKE 'All Other Attached%'
				AND f.property_type NOT LIKE 'Comm Bus Opp%'
				AND f.property_type NOT LIKE 'Dock%'
				AND f.property_type NOT LIKE 'Double Wide%'
				AND f.property_type NOT LIKE 'Food%'
				AND f.property_type NOT LIKE 'Fract %'
				AND f.property_type NOT LIKE 'Fraction%'
				AND f.property_type NOT LIKE 'Garage%'
				AND f.property_type NOT LIKE 'Hospitality'
				AND f.property_type NOT LIKE 'Business%'
				AND f.property_type NOT LIKE 'Improved Land%'
				AND f.property_type NOT LIKE 'Moorage'
				AND f.property_type NOT LIKE 'Non-Buildable%'
				AND f.property_type NOT LIKE 'Single Family Acreage'
				AND f.property_type NOT LIKE 'Stock Cooperative'
				AND f.property_type NOT LIKE 'Unimproved Land%'
				AND f.property_type NOT LIKE 'UnimprovedLand%'
				AND f.property_type NOT LIKE 'Water Position%'
				)
			OR f.property_type IS NULL
			)
		AND (
			(
				--fa.MLS_STATUS LIKE '%RENTED-LEASED%' or
				MLS_STATUS_STD LIKE '%RENT%'
				OR f.PROPERTY_TYPE IN (
					'Apartment Lease'
					,'Commercial Lease'
					,'Commercial-Lease'
					,'Condo Rental'
					,'House for Rent'
					,'LSE-Apartment'
					,'LSE-Condo Townhome'
					,'LSE-Duplex'
					,'LSE-House'
					,'Rental'
					,'Rental - Single Family Detached'
					,'Rental Commercial'
					,'Rental Income'
					,'Residential Lease'
					,'Residential Rental'
					,'RNT'
					)
				OR f.PROPERTY_SUB_TYPE IN (
					'Apartment Lease'
					,'Commercial Lease'
					,'Commercial-Lease'
					,'Condo Rental'
					,'House for Rent'
					,'LSE-Apartment'
					,'LSE-Condo Townhome'
					,'LSE-Duplex'
					,'LSE-House'
					,'Rental'
					,'Rental - Single Family Detached'
					,'Rental Commercial'
					,'Rental Income'
					,'Residential Lease'
					,'Residential Rental'
					,'RNT'
					)
				)
			OR (
				CASE 
					WHEN MLS_STATUS_STD = 'SOLD'
						THEN (
								NULLIF(CASE 
										WHEN ISNUMERIC(f.SOLD_PRICE_STD) = 1
											THEN ROUND(CAST(f.SOLD_PRICE_STD AS DECIMAL(15, 2)), 0)
										END, 0)
								)
					ELSE (
							NULLIF(CASE 
									WHEN ISNUMERIC(f.MLS_LIST_PRICE_STD) = 1
										THEN ROUND(CAST(f.MLS_LIST_PRICE_STD AS DECIMAL(15, 2)), 0)
									END, 0)
							)
					END < (
					CASE 
						WHEN z.medSalePrice >= 500000
							THEN (z.medSalePrice * 0.05)
						ELSE z.medSalePrice * 0.01
						END
					)
				)
			)

UPDATE m
SET Rental_Ind = CASE 
		WHEN rt.Row_id IS NOT NULL
			THEN 1
		ELSE 0
		END
FROM Fa_Listing.tmp.FA_MLS m
LEFT JOIN #HasRental rt ON m.Row_Id = rt.Row_Id

---------------------------------
--SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
RAISERROR (
		'%s Target Match'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

DROP TABLE

IF EXISTS #famls
	SELECT *
	INTO #famls
	FROM famls.dbo.fa_mls f WITH (
			NOLOCK
			,INDEX (idx_property_id)
			)
	WHERE f.Property_ID IN (
			SELECT DISTINCT property_id
			FROM Fa_Listing.tmp.FA_MLS WITH (NOLOCK)
			)

CREATE INDEX idx_property_id ON #famls (property_id)

UPDATE a
SET TargetMatchId = try_cast(substring(SEL_OFFICE2_EMAIL, 6, 50) AS INT)
	,MatchTypeId = 49
FROM Fa_Listing.tmp.FA_MLS a
WHERE substring(SEL_OFFICE2_EMAIL, 1, 5) = 'fail:'

UPDATE a
SET TargetMatchId = mt.Listing_ID
	,MatchTypeId = 50
FROM Fa_Listing.tmp.FA_MLS a WITH (
		NOLOCK
		,INDEX (IX_TargetMatchId)
		)
CROSS APPLY (
	SELECT TOP 1 lr.listing_id
		,f.ref_id
		,lr.MLS_Listing_Number
		,lr.MLS_Listing_Number_edited
		,lr.Rental_Ind
		,f.Row_Id
		,f.Property_ID
		,lr.AddrId
		,lr.LastRow_Id
		,lr.Created
	FROM #famls f WITH (
			NOLOCK
			,INDEX (idx_property_id)
			)
	CROSS APPLY (
		SELECT lr.*
			,l.*
		FROM fa_listing.dbo.listingRow lr WITH (
				NOLOCK
				,INDEX (PK__ListingR__7C36D07E31E64438)
				)
		OUTER APPLY (
			SELECT l.MLS_Listing_Number
				,l.MLS_Listing_Number_edited
				,l.Rental_Ind
				,l.AddrId
				,l.LastRow_Id
				,l.Created
			FROM fa_listing.dbo.listing l WITH (
					NOLOCK
					,INDEX (PK__Listing__A91E6F4D32656725)
					)
			WHERE l.listing_id = lr.Listing_id
			) l
		WHERE lr.row_id = f.row_id
			AND lr.Listing_deleted IS NULL
		) lr
	WHERE f.property_id = a.property_id
		AND (
			isnull(lr.MLS_Listing_Number_edited, '') = isnull(a.MLS_Listing_Number_edited, '')
			OR isnull(lr.MLS_Listing_Number, '') = isnull(a.MLS_Listing_Number, '')
			)
		AND isnull(lr.MLS_Listing_Number, '') > ''
		AND f.row_id <> a.row_id -- do not match against a
		--AND isnull(a.Rental_Ind, 0) = isnull(b.Rental_Ind, 0) -- ask if this can happen
	ORDER BY f.created
		,f.row_id
	) mt
WHERE a.TargetMatchId IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

UPDATE a
SET TargetMatchId = mt.Listing_ID
	,MatchTypeId = 51
FROM Fa_Listing.tmp.FA_MLS a WITH (
		NOLOCK
		,INDEX (IX_TargetMatchId)
		)
CROSS APPLY (
	SELECT TOP 1 lr.listing_id
		,f.ref_id
		,lr.MLS_Listing_Number
		,lr.MLS_Listing_Number_edited
		,lr.Rental_Ind
		,f.Row_Id
		,f.Property_ID
		,lr.AddrId
		,lr.LastRow_Id
		,lr.Created
	FROM #famls f WITH (
			NOLOCK
			,INDEX (idx_property_id)
			)
	CROSS APPLY (
		SELECT lr.*
			,l.*
		FROM fa_listing.dbo.listingRow lr WITH (
				NOLOCK
				,INDEX (PK__ListingR__7C36D07E31E64438)
				)
		OUTER APPLY (
			SELECT l.MLS_Listing_Number
				,l.MLS_Listing_Number_edited
				,l.Rental_Ind
				,l.AddrId
				,l.LastRow_Id
				,l.Created
				,l.ref_id
			FROM fa_listing.dbo.listing l WITH (
					NOLOCK
					,INDEX (PK__Listing__A91E6F4D32656725)
					)
			WHERE l.listing_id = lr.Listing_id
			) l
		WHERE lr.row_id = f.row_id
			AND lr.Listing_deleted IS NULL
		) lr
	WHERE f.property_id = a.property_id
		AND isnull(lr.ref_id, 0) = isnull(a.ref_id, 0)
		AND isnull(lr.ref_id, 0) > 0
		AND isnull(lr.MLS_Listing_Number, '') = ''
		AND isnull(a.MLS_Listing_Number, '') = ''
		AND f.row_id <> a.row_id -- do not match against a
		--AND isnull(a.Rental_Ind, 0) = isnull(b.Rental_Ind, 0) -- ask if this can happen
	ORDER BY f.created
		,f.row_id
	) mt
WHERE a.TargetMatchId IS NULL
	AND a.MLS_Listing_Number IS NULL
OPTION (
	RECOMPILE
	,MAXDOP 12
	,USE HINT('ENABLE_PARALLEL_PLAN_PREFERENCE')
	);

--  DECLARE @Timestamp VARCHAR(25)
SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Self Match'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

DROP TABLE

IF EXISTS #SelfMatchFull
	CREATE TABLE #SelfMatchFull (
		Id INT IDENTITY(1, 1) PRIMARY KEY
		,Parent INT
		,Child INT
		,MatchTypeId TINYINT
		)

INSERT INTO #SelfMatchFull
--
--
-- the first select is "joining" input fa_mls records that matched to the sale FA_LISTING record
SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,30
FROM Fa_Listing.tmp.FA_MLS a
INNER LOOP JOIN Fa_Listing.tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.TargetMatchId = b.TargetMatchId
	AND a.Rental_Ind = b.Rental_Ind
--AND (
--	(
--		a.Property_ID > 1000000000
--		AND b.Property_ID > 1000000000
--		)
--	OR (
--		a.Property_ID < 1000000000
--		AND b.Property_ID < 1000000000
--		)
--	)

UNION

--
--Join Two incoming records with each other using property_id and MLS_Listing_Number
--
SELECT a.Row_Id
	,b.Row_Id
	,150
FROM Fa_Listing.tmp.FA_MLS a
INNER LOOP JOIN Fa_Listing.tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.property_id = b.property_id
	AND (
		a.MLS_Listing_Number = b.MLS_Listing_Number
		OR a.MLS_Listing_Number_edited = b.MLS_Listing_Number_edited
		)
	AND a.MLS_Listing_Number IS NOT NULL
WHERE a.TargetMatchId IS NULL
and b.TargetMatchId IS NULL
--AND a.Rental_Ind = b.Rental_Ind
--AND (
--	(
--		a.Property_ID > 1000000000
--		AND b.Property_ID > 1000000000
--		)
--	OR (
--		a.Property_ID < 1000000000
--		AND b.Property_ID < 1000000000
--		)
--	)

UNION

--
--Join Two incoming records with each other using property_id and ref_id
--
SELECT a.Row_Id
	,b.Row_Id
	,151
FROM Fa_Listing.tmp.FA_MLS a
INNER LOOP JOIN Fa_Listing.tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.property_id = b.property_id
	AND isnull(b.ref_id, 0) = isnull(a.ref_id, 0)
	AND isnull(a.ref_id, 0) > 0
	AND isnull(b.MLS_Listing_Number, '') = ''
	AND isnull(a.MLS_Listing_Number, '') = ''
WHERE a.TargetMatchId IS NULL
and b.TargetMatchId IS NULL

DROP TABLE

IF EXISTS Fa_listing.tmp.SelfMatchFull
	SELECT *
	INTO Fa_listing.tmp.SelfMatchFull
	FROM #SelfMatchFull

--  DECLARE @Timestamp VARCHAR(25)  ,@PartitionCount INT
DROP TABLE

IF EXISTS #SelfMatch
	CREATE TABLE #SelfMatch (
		Parent INT NOT NULL
		,Child INT NOT NULL
		,MatchTypeId TINYINT PRIMARY KEY (
			Parent
			,Child
			)
		)

INSERT INTO #SelfMatch
SELECT Parent
	,Child
	,MIN(MatchTypeId)
FROM (
	SELECT Parent
		,Child
		,MatchTypeId
	FROM #SelfMatchFull
	
	UNION
	
	SELECT Child
		,Parent
		,MatchTypeId
	FROM #SelfMatchFull
	) t
GROUP BY Parent
	,Child

DROP TABLE

IF EXISTS Fa_listing.tmp.selfmatch
	SELECT *
	INTO Fa_listing.tmp.selfmatch
	FROM #selfmatch

UPDATE Fa_Listing.tmp.FA_MLS
SET SelfMatchId = NULL
WHERE SelfMatchId IS NOT NULL

WHILE 1 = 1
BEGIN
	UPDATE a
	SET SelfMatchId = COALESCE(b.SelfMatchId, m.Child)
		,MatchTypeId = m.MatchTypeId
	FROM Fa_Listing.tmp.FA_MLS a
	INNER JOIN #SelfMatch m ON a.Row_Id = m.Parent
	LEFT JOIN Fa_Listing.tmp.FA_MLS b ON m.Child = b.Row_Id
		AND b.SelfMatchId < m.Child
	WHERE COALESCE(b.SelfMatchId, m.Child) < a.SelfMatchId
		OR a.SelfMatchId IS NULL

	IF @@ROWCOUNT = 0
		BREAK
END

UPDATE Fa_Listing.tmp.FA_MLS
SET SelfMatchId = Row_Id
WHERE SelfMatchId IS NULL

UPDATE a
SET TargetMatchId = b.TargetMatchId
FROM Fa_Listing.tmp.FA_MLS a
INNER JOIN (
	SELECT SelfMatchId
		,MIN(TargetMatchId) AS TargetMatchId
	FROM Fa_Listing.tmp.FA_MLS
	WHERE TargetMatchId IS NOT NULL
	GROUP BY SelfMatchId
	) b ON a.SelfMatchId = b.SelfMatchId
WHERE a.TargetMatchId IS NULL
	OR a.TargetMatchId <> b.TargetMatchId

SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Set RowSeq'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

-- Set RowSeq
UPDATE m
SET RowSeq = t.RowSeq
FROM Fa_Listing.tmp.FA_MLS m
INNER JOIN (
	SELECT Row_Id
		,ROW_NUMBER() OVER (
			PARTITION BY SelfMatchId ORDER BY UPDATE_FLAG_DATE_STD
				,MLS_LIST_DATE_STD
				,SOLD_DATE_STD
				,Row_Id
			) AS RowSeq
	FROM Fa_Listing.tmp.FA_MLS
	) t ON m.Row_Id = t.Row_Id

-- Set Match Partitions
TRUNCATE TABLE fa_listing.dbo.ImportMatchPartition

DECLARE @PartitionSize INT = (
		SELECT COUNT(*)
		FROM Fa_Listing.tmp.FA_MLS
		) / @PartitionCount + 1

INSERT INTO fa_listing.dbo.ImportMatchPartition
SELECT 1 AS Id
	,MIN(SelfMatchId) AS BeginRow
	,MAX(SelfMatchId) AS EndRow
	,count(*) AS [Count]
FROM Fa_Listing.tmp.FA_MLS

-- Set next identity value for Fa_listing.tmp.Listing
TRUNCATE TABLE Fa_listing.tmp.Listing

DECLARE @MaxListingID INT = (
		SELECT MAX(Listing_ID)
		FROM Fa_Listing.dbo.Listing
		)

IF @MaxListingID IS NOT NULL
BEGIN
	SET IDENTITY_INSERT Fa_listing.tmp.Listing ON

	INSERT INTO Fa_listing.tmp.Listing (
		Listing_ID
		,Created
		,Current_Listing_Ind
		,Current_Rental_Ind
		,LastRow_Id
		,UpdateSeq
		)
	VALUES (
		@MaxListingID
		,GETDATE()
		,0
		,0
		,0
		,0
		)

	SET IDENTITY_INSERT Fa_listing.tmp.Listing OFF

	DELETE
	FROM Fa_listing.tmp.Listing
	WHERE Listing_ID = @MaxListingID

	SET IDENTITY_INSERT Fa_listing.tmp.Listing ON

	INSERT INTO Fa_listing.tmp.Listing (
		Listing_ID
		,UPDATE_FLAG_DATE_STD
		,MLS_LIST_DATE_STD
		,MLS_STATUS_STD
		,MLS_Listing_Number
		,MLS_Listing_Agent_CODE
		,MLS_OFFICE_CODE
		,Created
		,Updated
		,Fips
		,REF_ID
		,STATE
		,Current_Listing_Ind
		,Current_Rental_Ind
		,Concurrent_Listed_Ind
		,SOLD_DATE_STD
		,AddrId
		,MLS_LISTING_AGENT2_CODE
		,SEL_AGENT_CODE
		,SEL_AGENT2_CODE
		,LISTING_OFFICE2_CODE
		,SEL_OFFICE_CODE
		,SEL_OFFICE2_CODE
		,Rental_Ind
		,LastRow_Id
		,NBR_BEDRMS_STD
		,MLS_LIST_PRICE_STD
		,SOLD_PRICE_STD
		,BSMT_FIN_SQFT_STD
		,HOME_SIZE_STD
		,LOT_SIZE_STD
		,PRICE_PER_SQFT_STD
		,YEAR_BUILT_STD
		,REO_IND
		,SHORT_SALE_IND
		,MLS_STATUS_SUB_TYPE_STD
		,NBR_BATH_STD
		,NBR_GRG_STD
		,NBR_FIREPLACE_STD
		,NBR_STORIES_STD
		,FIREPLACE_DESC_STD
		,UpdateSeq
		,APX_LOT_DIMENSIONS
		,PROPERTY_DETAILS
		,APN
		,APX_LOT_IS_L85
		,COUNTY_NAME
		,HOUSE_NBR
		,STREET
		,CITY
		,ZIP
		,OTHER_FTRS
		,PROVIDER_TYPE
		,Point
		,Land_Use
		,Original_UPDATE_FLAG_DATE_STD
		,MLS_Listing_Number_edited
		)
	SELECT Listing_ID
		,UPDATE_FLAG_DATE_STD
		,MLS_LIST_DATE_STD
		,MLS_STATUS_STD
		,MLS_Listing_Number
		,MLS_Listing_Agent_CODE
		,MLS_OFFICE_CODE
		,Created
		,Updated
		,Fips
		,REF_ID
		,STATE
		,Current_Listing_Ind
		,Current_Rental_Ind
		,Concurrent_Listed_Ind
		,SOLD_DATE_STD
		,AddrId
		,MLS_LISTING_AGENT2_CODE
		,SEL_AGENT_CODE
		,SEL_AGENT2_CODE
		,LISTING_OFFICE2_CODE
		,SEL_OFFICE_CODE
		,SEL_OFFICE2_CODE
		,Rental_Ind
		,LastRow_Id
		,NBR_BEDRMS_STD
		,MLS_LIST_PRICE_STD
		,SOLD_PRICE_STD
		,BSMT_FIN_SQFT_STD
		,HOME_SIZE_STD
		,LOT_SIZE_STD
		,PRICE_PER_SQFT_STD
		,YEAR_BUILT_STD
		,REO_IND
		,SHORT_SALE_IND
		,MLS_STATUS_SUB_TYPE_STD
		,NBR_BATH_STD
		,NBR_GRG_STD
		,NBR_FIREPLACE_STD
		,NBR_STORIES_STD
		,FIREPLACE_DESC_STD
		,UpdateSeq
		,APX_LOT_DIMENSIONS
		,PROPERTY_DETAILS
		,APN
		,APX_LOT_IS_L85
		,COUNTY_NAME
		,HOUSE_NBR
		,STREET
		,CITY
		,ZIP
		,OTHER_FTRS
		,PROVIDER_TYPE
		,Point
		,Land_Use
		,Original_UPDATE_FLAG_DATE_STD
		,MLS_Listing_Number_edited
	FROM Fa_Listing.dbo.Listing
	WHERE Listing_ID IN (
			SELECT TargetMatchId
			FROM Fa_Listing.tmp.FA_MLS
			)

	SET IDENTITY_INSERT Fa_listing.tmp.Listing OFF
END


