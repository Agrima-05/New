SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE migration.usp_CompareInventory
    @SourceCaptureRunId int = NULL,   -- default: newest Source capture from another server
    @TargetCaptureRunId int = NULL,   -- default: newest Target capture from this server
    @AllowSameServer    bit = 0,      -- test hook: permit source and target on one server
    @ComparisonRunId    int = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;   -- a mid-persist error must never half-commit a run
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SET LOCK_TIMEOUT 5000;

    /* v2.4.2b: @Msg removed - declared here and never assigned or read.
       Every RAISERROR in this procedure uses an inline literal with %s args. */
    DECLARE @ToolVersion nvarchar(20) = N'2.6.0',
            @LocalServer sysname      = CONVERT(sysname, SERVERPROPERTY('ServerName'));

    /* ---- capture selection & validation --------------------------------- */
    IF @SourceCaptureRunId IS NULL
        SELECT TOP (1) @SourceCaptureRunId = CaptureRunId
        FROM migration.CaptureRun
        WHERE CaptureRole = N'Source'
          AND (ServerName <> @LocalServer OR @AllowSameServer = 1)
        ORDER BY CaptureRunId DESC;
    IF @TargetCaptureRunId IS NULL
        SELECT TOP (1) @TargetCaptureRunId = CaptureRunId
        FROM migration.CaptureRun
        WHERE CaptureRole = N'Target'
          AND (ServerName = @LocalServer OR @AllowSameServer = 1)
        ORDER BY CaptureRunId DESC;

    IF @SourceCaptureRunId IS NULL
    BEGIN
        RAISERROR(N'No Source capture from another server exists in this database. Either the DBAdmin restore has not happened or the capture was never run on the source.', 16, 1);
        RETURN 1;
    END
    IF @TargetCaptureRunId IS NULL
    BEGIN
        RAISERROR(N'No Target capture from this server exists. Run 02_Capture-Inventory.sql here first.', 16, 1);
        RETURN 1;
    END

    DECLARE @SrcServer sysname, @SrcVersion nvarchar(30), @SrcEdition nvarchar(60),
            /* v2.4.2b: @SrcDateLocal removed - it was assigned from
               CaptureRun.CaptureDateLocal and never read. Only the TARGET's
               local/UTC pair is needed (@TgtUtcOffsetMin below), because every
               time comparison converts msdb times recorded on the target. */
            @SrcDateUtc datetime2(0), @SrcComplete bit,
            @SrcSchema nvarchar(10), @SrcRole nvarchar(10),
            @SrcMachine sysname,   -- v2.4: corroborates provenance across a rename
            @TgtServer sysname, @TgtVersion nvarchar(30), @TgtEdition nvarchar(60),
            @TgtDateUtc datetime2(0), @TgtDateLocal datetime2(0), @TgtComplete bit,
            @TgtSchema nvarchar(10), @TgtRole nvarchar(10);

    SELECT @SrcServer = ServerName, @SrcVersion = ProductVersion, @SrcEdition = Edition,
           @SrcDateUtc = CaptureDateUtc,
           @SrcComplete = IsComplete, @SrcSchema = SchemaVersion, @SrcRole = CaptureRole, @SrcMachine = MachineName
    FROM migration.CaptureRun WHERE CaptureRunId = @SourceCaptureRunId;
    SELECT @TgtServer = ServerName, @TgtVersion = ProductVersion, @TgtEdition = Edition,
           @TgtDateUtc = CaptureDateUtc, @TgtDateLocal = CaptureDateLocal,
           @TgtComplete = IsComplete,
           @TgtSchema = SchemaVersion, @TgtRole = CaptureRole
    FROM migration.CaptureRun WHERE CaptureRunId = @TargetCaptureRunId;

    IF @SrcServer IS NULL OR @TgtServer IS NULL
    BEGIN
        RAISERROR(N'A specified CaptureRunId does not exist.', 16, 1);
        RETURN 1;
    END
    IF @SrcRole <> N'Source' OR @TgtRole <> N'Target'
    BEGIN
        RAISERROR(N'Capture roles are wrong for this comparison (source run must be Role=Source, target run Role=Target).', 16, 1);
        RETURN 1;
    END
    IF @SrcServer = @TgtServer AND @AllowSameServer = 0
    BEGIN
        RAISERROR(N'Source and target captures are from the SAME server (%s) - the DBAdmin on this server does not contain a restored source capture.', 16, 1, @SrcServer);
        RETURN 1;
    END
    IF @SrcSchema <> @TgtSchema
    BEGIN
        RAISERROR(N'Capture schema versions differ (source %s, target %s). Re-capture with matching tool versions.', 16, 1, @SrcSchema, @TgtSchema);
        RETURN 1;
    END
    /* v2.3: the pair matching each other is not enough - they must also match
       THIS procedure, or a newer compare would silently run over data captured
       with older semantics. */
    DECLARE @ProcSchemaVersion nvarchar(10) = N'2.6';
    IF @SrcSchema <> @ProcSchemaVersion
    BEGIN
        RAISERROR(N'The captures were taken with schema version %s, but this comparison procedure is schema version %s. Re-run 01_Install-MigrationSchema.sql and re-capture BOTH sides with one tool version.', 16, 1, @SrcSchema, @ProcSchemaVersion);
        RETURN 1;
    END
    /* 1:1 design: more than one distinct foreign source server captured here
       means a consolidation attempt, which this tool does not support. */
    IF (SELECT COUNT(DISTINCT ServerName) FROM migration.CaptureRun
        WHERE CaptureRole = N'Source' AND ServerName <> @TgtServer) > 1
    BEGIN
        RAISERROR(N'Captures from MORE THAN ONE source server exist in this database. This tool validates exactly one source per target.', 16, 1);
        RETURN 1;
    END

    /* ---- config --------------------------------------------------------- */
    DECLARE @StalenessDays  int = ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue WHERE ConfigName = N'StalenessWarningDays')), 7),
            @CertWarnDays   int = ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue WHERE ConfigName = N'CertificateExpiryWarningDays')), 90),
            @CheckDbDays    int = ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue WHERE ConfigName = N'CheckDbWarningDays')), 30),
            @MinFreePct     int = ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue WHERE ConfigName = N'MinimumTargetVolumeFreePercent')), 10);

    /* v2.4: the target engine's NATIVE compatibility level, derived from its
       major version. Used by CompatibilityLevelNotRaised to spot a database
       that matches the source exactly and is therefore invisible to every
       difference-based rule, yet is still running at the OLD version's level.
       Unknown/newer majors fall back to 0, which disables the check rather
       than guessing - a new SQL version must not manufacture findings. */
    /* v2.4.2b: hoisted OUT of the Instance section's ELSE block.

       These are read by CompatibilityLevelNotRaised, which lives in the
       DATABASES section - a different gate. T-SQL scopes a variable to the
       whole batch but only ASSIGNS it when the DECLARE actually executes, so
       if the Instance module had failed on either side both stayed NULL,
       `@TgtMajor > @SrcMajor` evaluated to UNKNOWN, and the rule emitted
       nothing at all - with no SKIPPED marker, in a file whose stated
       invariant is that no section ever skips silently. They are derived from
       CaptureRun.ProductVersion, which is available regardless of whether the
       Instance MODULE succeeded, so there was never a reason to gate them. */
    DECLARE @SrcMajor int = TRY_CONVERT(int, LEFT(@SrcVersion, CHARINDEX(N'.', @SrcVersion + N'.') - 1)),
            @TgtMajor int = TRY_CONVERT(int, LEFT(@TgtVersion, CHARINDEX(N'.', @TgtVersion + N'.') - 1));

    DECLARE @TgtNativeCompat int =
        CASE TRY_CONVERT(int, LEFT(@TgtVersion, CHARINDEX(N'.', @TgtVersion + N'.') - 1))
             WHEN 13 THEN 130   -- SQL Server 2016
             WHEN 14 THEN 140   -- SQL Server 2017
             WHEN 15 THEN 150   -- SQL Server 2019
             WHEN 16 THEN 160   -- SQL Server 2022
             WHEN 17 THEN 170   -- SQL Server 2025
             ELSE 0 END;

    /* v2.4.2b: LIKE pattern matching the source host's MACHINE-LOCAL
       principals ("SRCHOST\..."). Used by the Logins/Existence rule, which
       must not call such a login a cutover blocker - it cannot exist on the
       target under the same name.

       The machine name is escaped before it becomes a pattern: '_' and '[' are
       LIKE metacharacters and a host called SQL_01 would otherwise match
       SQLX01\... too. Escape '[' FIRST, or it would re-escape the brackets the
       other two replacements introduce. When @SrcMachine is NULL the pattern
       is NULL, every LIKE against it is UNKNOWN, and the rule falls through to
       its normal FAIL - the safe direction. */
    DECLARE @SrcMachinePrefix nvarchar(300) =
        REPLACE(REPLACE(REPLACE(@SrcMachine, N'[', N'[[]'), N'_', N'[_]'), N'%', N'[%]') + N'\%';

    /* ---- working tables --------------------------------------------------
       COLLATE DATABASE_DEFAULT everywhere: temp tables otherwise inherit the
       tempdb (instance) collation and comparisons against the admin database's
       columns raise error 468 whenever the two collations differ. */
    CREATE TABLE #Finding (
        Category          nvarchar(60)   COLLATE DATABASE_DEFAULT NOT NULL,
        ObjectType        nvarchar(60)   COLLATE DATABASE_DEFAULT NOT NULL,
        ObjectName        nvarchar(400)  COLLATE DATABASE_DEFAULT NOT NULL,
        SubObjectName     nvarchar(400)  COLLATE DATABASE_DEFAULT NULL,
        CheckName         nvarchar(100)  COLLATE DATABASE_DEFAULT NOT NULL,
        Status            nvarchar(30)   COLLATE DATABASE_DEFAULT NOT NULL,
        Severity          nvarchar(20)   COLLATE DATABASE_DEFAULT NOT NULL,
        IsBlocker         bit            NOT NULL DEFAULT 0,
        SourceValue       nvarchar(4000) COLLATE DATABASE_DEFAULT NULL,
        TargetValue       nvarchar(4000) COLLATE DATABASE_DEFAULT NULL,
        Explanation       nvarchar(2000) COLLATE DATABASE_DEFAULT NOT NULL,
        RecommendedAction nvarchar(1000) COLLATE DATABASE_DEFAULT NULL,
        ExceptionId       int            NULL
    );

    /* Module-level capture errors gate their compare sections on BOTH sides.

       v2.6: IsNotApplicable travels with the row. Gating is UNCHANGED - a
       section whose data does not exist must still be skipped, never guessed,
       whatever the reason - but the REPORTING of that skip now depends on why.
       A module that failed is a problem to fix; a module whose feature the
       source engine never had is a fact to state. MIN() because a module is
       only "not applicable" if EVERY row recorded for it says so: a source that
       lacks the feature paired with a target that genuinely failed to collect
       it is still a real collection failure and must not be softened. */
    CREATE TABLE #ModErr (Side nvarchar(6) COLLATE DATABASE_DEFAULT NOT NULL,
                          ModuleName sysname COLLATE DATABASE_DEFAULT NOT NULL,
                          IsNotApplicable bit NOT NULL,
                          PRIMARY KEY (Side, ModuleName));
    INSERT #ModErr
    SELECT N'Source', ModuleName, MIN(CONVERT(int, IsNotApplicable)) FROM migration.CaptureError
    WHERE CaptureRunId = @SourceCaptureRunId AND ItemName IS NULL
    GROUP BY ModuleName
    UNION ALL
    SELECT N'Target', ModuleName, MIN(CONVERT(int, IsNotApplicable)) FROM migration.CaptureError
    WHERE CaptureRunId = @TargetCaptureRunId AND ItemName IS NULL
    GROUP BY ModuleName;

    /* Per-database item errors (DatabaseHealth) skip just that database */
    CREATE TABLE #ItemErr (Side nvarchar(6) COLLATE DATABASE_DEFAULT NOT NULL,
                           ModuleName sysname COLLATE DATABASE_DEFAULT NOT NULL,
                           ItemName nvarchar(400) COLLATE DATABASE_DEFAULT NOT NULL);
    INSERT #ItemErr
    SELECT DISTINCT N'Source', ModuleName, ItemName FROM migration.CaptureError
    WHERE CaptureRunId = @SourceCaptureRunId AND ItemName IS NOT NULL
    UNION
    SELECT DISTINCT N'Target', ModuleName, ItemName FROM migration.CaptureError
    WHERE CaptureRunId = @TargetCaptureRunId AND ItemName IS NOT NULL;

    /* Enabled rule exceptions + hit accounting (never silent) */
    CREATE TABLE #Exception (ExceptionId int PRIMARY KEY,
                             Scope nvarchar(60) COLLATE DATABASE_DEFAULT,
                             NamePattern nvarchar(400) COLLATE DATABASE_DEFAULT,
                             TreatAs nvarchar(20) COLLATE DATABASE_DEFAULT,
                             Reason nvarchar(400) COLLATE DATABASE_DEFAULT,
                             Hits int NOT NULL DEFAULT 0,
                             /* v2.4: Matched counts OBJECTS THE PATTERN MATCHES;
                                Hits counts what the exception actually did.
                                They are different questions and conflating them
                                produced a guaranteed false positive - see
                                ExceptionMatchedNothing near the end of this proc. */
                             Matched int NOT NULL DEFAULT 0,
                             SectionRan bit NOT NULL DEFAULT 0);
    INSERT #Exception (ExceptionId, Scope, NamePattern, TreatAs, Reason)
    SELECT ExceptionId, Scope, NamePattern, TreatAs, Reason
    FROM migration.RuleException WHERE IsEnabled = 1;

    /* v2.4: does the pattern match anything at all, in either capture?

       Answered ONCE, here, straight from the capture tables - independent of
       whether the exception went on to suppress or downgrade a finding, and
       independent of whether the owning section ran. SectionRan records the
       second question separately, so a skipped section can never make its
       exceptions look stale. */
    UPDATE x SET
        Matched = CASE x.Scope
            WHEN N'Database' THEN (SELECT COUNT(DISTINCT d.DatabaseName) FROM migration.DatabaseInfo d
                                   WHERE d.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                                     AND d.IsSystem = 0 AND d.DatabaseName LIKE x.NamePattern)
            WHEN N'Login' THEN (SELECT COUNT(DISTINCT l.LoginName) FROM migration.LoginInfo l
                                WHERE l.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                                  AND l.LoginName LIKE x.NamePattern)
            WHEN N'AgentJob' THEN (SELECT COUNT(DISTINCT j.JobName) FROM migration.AgentJob j
                                   WHERE j.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                                     AND j.JobName LIKE x.NamePattern)
            WHEN N'LinkedServer' THEN (SELECT COUNT(DISTINCT ls.LinkedServerName) FROM migration.LinkedServerInfo ls
                                       WHERE ls.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                                         AND ls.LinkedServerName LIKE x.NamePattern)
            WHEN N'SystemDbObject' THEN (SELECT COUNT(DISTINCT o.DatabaseName + N'.' + o.SchemaName + N'.' + o.ObjectName)
                                         FROM migration.SystemDbObject o
                                         WHERE o.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                                           AND o.DatabaseName + N'.' + o.SchemaName + N'.' + o.ObjectName LIKE x.NamePattern)
            ELSE 0 END,
        SectionRan = CASE WHEN EXISTS (SELECT 1 FROM #ModErr
                                       WHERE ModuleName = CASE x.Scope
                                                              WHEN N'Database'       THEN N'Databases'
                                                              WHEN N'Login'          THEN N'Logins'
                                                              WHEN N'AgentJob'       THEN N'Agent'
                                                              WHEN N'LinkedServer'   THEN N'LinkedServers'
                                                              WHEN N'SystemDbObject' THEN N'SystemDbObjects'
                                                              ELSE N'(none)' END)
                          THEN 0 ELSE 1 END
    FROM #Exception AS x;

    /* An exception with an unsupported scope would otherwise sit in the table
       looking effective while matching nothing - warn loudly instead. */
    INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                     SourceValue, Explanation, RecommendedAction, ExceptionId)
    SELECT N'RuleExceptions', N'RuleException', LEFT(x.Scope + N': ' + x.NamePattern, 400),
           N'UnsupportedExceptionScope', N'WARNING', N'Medium',
           x.TreatAs,
           N'Rule exception scope ''' + x.Scope + N''' is NOT applied by this comparison (supported scopes: Database, Login, AgentJob, LinkedServer, SystemDbObject). The exception has NO effect - the objects it names are still compared normally.',
           N'Use a supported scope, or remove the exception and handle its findings during review.',
           x.ExceptionId
    FROM #Exception AS x
    WHERE x.Scope NOT IN (N'Database', N'Login', N'AgentJob', N'LinkedServer', N'SystemDbObject');

    /* ---- every capture error is itself a visible finding ----------------

       v2.6: split by IsNotApplicable. Both kinds stay VISIBLE - nothing is
       hidden - but they are no longer the same claim. Calling "SQL 2014 has no
       database-scoped configuration" a COLLECTION ERROR was wrong twice over:
       it told the operator to go fix something that cannot be fixed, and
       because @CollErr feeds the verdict it pinned every future run on that
       server to READY WITH WARNINGS. NOT APPLICABLE / Informational is counted
       in none of the verdict buckets, so a genuinely clean older source can
       now be certified clean. */
    INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName,
                     Status, Severity, SourceValue, TargetValue, Explanation, RecommendedAction)
    SELECT N'CaptureErrors', N'CaptureModule',
           ce.ModuleName, ce.ItemName,
           CASE WHEN ce.IsNotApplicable = 1 THEN N'NotApplicableOnThisVersion' ELSE N'CollectionFailed' END,
           CASE WHEN ce.IsNotApplicable = 1 THEN N'NOT APPLICABLE' ELSE N'COLLECTION ERROR' END,
           CASE WHEN ce.IsNotApplicable = 1 THEN N'Informational' ELSE N'Medium' END,
           CASE WHEN ce.CaptureRunId = @SourceCaptureRunId THEN ce.ErrorMessage END,
           CASE WHEN ce.CaptureRunId = @TargetCaptureRunId THEN ce.ErrorMessage END,
           -- LEFT: the composed text must truncate, never abort the comparison
           LEFT(N'Module ''' + ce.ModuleName + N''''
             + ISNULL(N' (item ''' + ce.ItemName + N''')', N'')
             + CASE WHEN ce.IsNotApplicable = 1
                    THEN N' is not available on the ' ELSE N' failed during the ' END
             + CASE WHEN ce.CaptureRunId = @SourceCaptureRunId THEN N'SOURCE' ELSE N'TARGET' END
             + CASE WHEN ce.IsNotApplicable = 1 THEN N' engine version: ' ELSE N' capture: ' END
             + ce.ErrorMessage, 2000),
           CASE WHEN ce.IsNotApplicable = 1
                THEN N'No action: the feature does not exist on that engine version. The affected checks are reported as not applicable rather than validated, and the message above names where the equivalent setting lives on that version.'
                ELSE N'Fix the collection error (usually permissions) and re-run the capture; affected checks are skipped, not validated.' END
    FROM migration.CaptureError AS ce
    WHERE ce.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId);

    /* ---- capture freshness & restore sequencing ------------------------- */
    IF @SrcDateUtc < DATEADD(DAY, -@StalenessDays, SYSUTCDATETIME())
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'CaptureRun', @SrcServer, N'SourceCaptureStale',
                N'WARNING', N'Medium',
                CONVERT(nvarchar(30), @SrcDateUtc, 120) + N' UTC', NULL,
                N'The source capture is older than ' + CONVERT(nvarchar(10), @StalenessDays)
                  + N' days. Server-level changes made on the source since then are invisible to this validation.',
                N'Re-run the capture on the source, re-backup/restore DBAdmin, and compare again if the source may have changed.');

    /* Target-capture freshness matters too: a target captured days before the
       final restores validates a state that no longer exists. */
    IF @TgtDateUtc < DATEADD(DAY, -@StalenessDays, SYSUTCDATETIME())
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'CaptureRun', @TgtServer, N'TargetCaptureStale',
                N'WARNING', N'Medium',
                NULL, CONVERT(nvarchar(30), @TgtDateUtc, 120) + N' UTC',
                N'The target capture is older than ' + CONVERT(nvarchar(10), @StalenessDays)
                  + N' days. Restores and configuration done on the target since then are invisible to this validation.',
                N'Re-run EXEC migration.usp_CaptureInventory on the target and compare again.');

    /* The source capture must PREDATE the DBAdmin restore that carried it
       here; a source capture newer than the restore is physically impossible
       unless someone captured with the wrong role on this server.
       TIME ZONES: msdb restore_date is the TARGET's local clock, while the
       source capture happened on the SOURCE's clock. Convert both to UTC
       using each capture's own recorded local-vs-UTC offset, and allow a
       60-minute tolerance for clock skew / DST transitions in between. */
    DECLARE @AdminRestoreDate datetime2(0) =
        (SELECT MAX(RestoreDate) FROM migration.RestoreEvent
         WHERE CaptureRunId = @TargetCaptureRunId AND DatabaseName = DB_NAME() COLLATE DATABASE_DEFAULT);
    DECLARE @TgtUtcOffsetMin int = DATEDIFF(MINUTE, @TgtDateUtc, @TgtDateLocal);
    DECLARE @AdminRestoreUtc datetime2(0) = DATEADD(MINUTE, -@TgtUtcOffsetMin, @AdminRestoreDate);
    /* v2.3: when the RestoreHistory module itself failed on the target, the
       sequencing check has no data - say SO, instead of the misleading
       "history window may be too short" row below (and a real sequencing
       violation must not silently pass as unverified). */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE Side = N'Target' AND ModuleName = N'RestoreHistory')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'ComparisonSection', DB_NAME(), N'SequencingCheck',
                N'SKIPPED', N'Medium',
                N'The RestoreHistory module failed during the target capture; the restore-sequencing check was skipped (restore dates were not collected).',
                N'Fix the capture error (usually msdb read permissions) and re-run the target capture.');
    ELSE IF @AdminRestoreUtc IS NOT NULL AND @SrcDateUtc > DATEADD(MINUTE, 60, @AdminRestoreUtc)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'CaptureRun', @SrcServer, N'SequencingViolation',
                N'FAIL', N'High', 1,
                N'captured ' + CONVERT(nvarchar(30), @SrcDateUtc, 120) + N' UTC',
                N'restored ' + CONVERT(nvarchar(30), @AdminRestoreUtc, 120) + N' UTC (converted from target local time)',
                N'The "source" capture is NEWER (in UTC, beyond a 60-minute tolerance) than the restore of this database - it cannot have come from the source server. A capture was probably run with @Role=Source on the wrong server.',
                N'Remove the bad capture run (delete its migration.ComparisonRun rows first - see RUNBOOK.md "Removing stale or bad captures"), re-capture on the real source, and restore DBAdmin again.');
    ELSE IF @AdminRestoreDate IS NULL AND @AllowSameServer = 0
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'CaptureRun', DB_NAME(), N'AdminDbRestoreUnverified',
                N'MANUAL REVIEW', N'Low',
                N'No restore of [' + DB_NAME() + N'] appears in the captured msdb restore history, so the restore sequencing cannot be verified (the history window may simply be too short).',
                N'Confirm this database was restored from the source server''s backup.');

    IF @SrcComplete = 0 OR @TgtComplete = 0
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        VALUES (N'CaptureIntegrity', N'CaptureRun',
                CASE WHEN @SrcComplete = 0 THEN @SrcServer ELSE @TgtServer END,
                /* v2.3: COLLECTION ERROR, not FAIL - a required-module failure
                   must yield INCOMPLETE VALIDATION ("re-capture"), not NOT
                   READY ("fix migration defects"). @Incomplete picks it up
                   via IsComplete = 0. */
                N'CaptureIncomplete', N'COLLECTION ERROR', N'High',
                CASE WHEN @SrcComplete = 0 THEN N'INCOMPLETE' ELSE N'complete' END,
                CASE WHEN @TgtComplete = 0 THEN N'INCOMPLETE' ELSE N'complete' END,
                N'A required capture module failed, so this validation is incomplete and cannot certify readiness.',
                N'Fix the capture errors and re-run the failed capture before relying on this comparison.');

    /* ======================================================================
       Section: Instance - version, collation, authentication, properties
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Instance')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Instance', N'ComparisonSection', N'Instance', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Instance module failed on at least one side; instance-level checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'Instance', @TgtServer, N'VersionDirection',
               /* v2.3: an unparseable version must not fall through to the
                  happy-path ELSE - it is unverified, not expected. */
               CASE WHEN @SrcMajor IS NULL OR @TgtMajor IS NULL THEN N'MANUAL REVIEW'
                    WHEN @TgtMajor < @SrcMajor THEN N'FAIL'
                    WHEN @TgtMajor = @SrcMajor THEN N'PASS'
                    ELSE N'EXPECTED DIFFERENCE' END,
               CASE WHEN @SrcMajor IS NULL OR @TgtMajor IS NULL THEN N'Medium'
                    WHEN @TgtMajor < @SrcMajor THEN N'Critical' ELSE N'Informational' END,
               CASE WHEN @TgtMajor < @SrcMajor THEN 1 ELSE 0 END,
               @SrcVersion, @TgtVersion,
               CASE WHEN @SrcMajor IS NULL OR @TgtMajor IS NULL
                    THEN N'A captured ProductVersion could not be parsed - the version direction is UNVERIFIED.'
                    WHEN @TgtMajor < @SrcMajor
                    THEN N'The target runs an OLDER SQL Server version than the source - databases cannot be restored downlevel.'
                    ELSE N'SQL Server version (upgrade is the expected direction for this migration).' END,
               CASE WHEN @SrcMajor IS NULL OR @TgtMajor IS NULL THEN N'Verify the SQL Server versions manually (SELECT @@VERSION on both sides).'
                    WHEN @TgtMajor < @SrcMajor THEN N'Rebuild the target on the intended (newer) SQL Server version.' END;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'Instance', @TgtServer, N'Edition',
               CASE WHEN @SrcEdition = @TgtEdition THEN N'PASS' ELSE N'MANUAL REVIEW' END,
               CASE WHEN @SrcEdition = @TgtEdition THEN N'Informational' ELSE N'Medium' END,
               @SrcEdition, @TgtEdition,
               CASE WHEN @SrcEdition = @TgtEdition THEN N'Edition matches.'
                    ELSE N'The edition differs. Enterprise-only features (compression, partitioning, RG, online ops) fail or degrade on a lower edition.' END,
               CASE WHEN @SrcEdition <> @TgtEdition THEN N'Verify no Enterprise-only feature is in use, or align editions.' END;

        /* Instance property rules: one row per property with its diff
           classification. Properties captured by their own module get that
           module checked when the row is missing on one side. */
        ;WITH s AS (SELECT PropertyName, PropertyValue FROM migration.InstanceProperty WHERE CaptureRunId = @SourceCaptureRunId),
              t AS (SELECT PropertyName, PropertyValue FROM migration.InstanceProperty WHERE CaptureRunId = @TargetCaptureRunId),
        r (PropertyName, OwnerModule, DiffStatus, DiffSeverity, DiffBlocker, Explanation, Action) AS (SELECT * FROM (VALUES
            (N'ServerCollation',            N'Instance', N'FAIL',          N'High',   1,
             N'Server collation differs. tempdb and cross-database joins will raise collation conflicts.',
             N'Rebuild the target with the source server collation (setup /SQLCOLLATION).'),
            (N'AuthenticationMode',         N'Instance', N'WARNING',       N'High',   0,
             N'Authentication mode differs. If the source allows SQL logins and the target is Windows-only, every SQL login is dead at cutover.',
             N'Align the authentication mode in server properties (restart required).'),
            (N'IsClustered',                N'Instance', N'MANUAL REVIEW', N'Medium', 0,
             N'Clustering configuration differs; verify HA expectations for the target.', NULL),
            (N'IsHadrEnabled',              N'Instance', N'MANUAL REVIEW', N'Medium', 0,
             N'Always On availability differs; AG replicas must be reconfigured on the target after cutover.', NULL),
            /* IsFullTextInstalled / FilestreamEffectiveLevel / IFI are handled
               by the DIRECTIONAL block below - only a target with LESS than
               the source matters; extra capability on the target is expected.
               DELIBERATELY NOT COMPARED (2026-08-12 lean-report review):
               OperatingSystem, HyperthreadRatio, IsPolyBaseInstalled and the
               Data/Log/Tempdb/Backup drive roles - the at-a-glance table shows
               them side by side, and as findings they only ever produced
               expected-difference noise on legitimate migrations. */
            (N'AgentUseDatabaseMail',       N'AgentMail', N'WARNING',      N'Medium', 0,
             N'SQL Agent alert-mail configuration differs; job/alert notifications may not send on the target.',
             N'Configure Agent to use Database Mail with the correct profile, then restart Agent.'),
            (N'AgentDatabaseMailProfile',   N'AgentMail', N'WARNING',      N'Medium', 0,
             N'SQL Agent mail profile differs; job/alert notifications may not send on the target.',
             N'Point Agent at the migrated Database Mail profile, then restart Agent.'),
            (N'ResourceGovernorEnabled',    N'ResourceGovernor', N'WARNING', N'High', 0,
             N'Resource Governor enablement differs; workload limits from the source are not in force.',
             N'Recreate and enable the Resource Governor configuration on the target.'),
            (N'ResourceGovernorClassifier', N'ResourceGovernor', N'WARNING', N'High', 0,
             N'Resource Governor classifier differs; workloads will not be routed as on the source.',
             N'Recreate the classifier function and reconfigure Resource Governor.'),
            /* v2.4: Informational, not Low.
               @ManualActionable counts every non-Informational MANUAL REVIEW, so
               these two demoted the verdict on essentially every migration to new
               hardware - where a different socket count and NUMA layout are the
               NORMAL outcome, not a question. They remain visible as findings and
               side by side in the at-a-glance table; they just no longer stand
               between a clean migration and a plain READY. Anything with a real
               decision behind it (Edition, TcpPort, MaxMemoryVsNewRam, AGs) keeps
               its Medium severity deliberately. */
            (N'CpuSockets',                 N'CpuInfo',  N'MANUAL REVIEW', N'Informational', 0,
             N'CPU socket count differs; verify licensing and NUMA expectations.', NULL),
            /* v2.4.1: OwnerModule corrected from 'Instance' to 'Hardware'.
               NumaNodes is captured by the Hardware module (02), so with the
               old mapping a Hardware failure took the "(not configured there)"
               branch below - asserting the server has no NUMA configuration
               when the truth is that nobody measured it. */
            (N'NumaNodes',                  N'Hardware', N'MANUAL REVIEW', N'Informational', 0,
             N'NUMA topology differs; MAXDOP and memory-per-node behavior change with it.', NULL),
            (N'TcpPort',                    N'Network',  N'MANUAL REVIEW', N'Medium', 0,
             N'The SQL Server TCP port differs. Connection strings, firewall rules and SPNs must reflect the target port.',
             N'Align the port or update every consumer as part of cutover.'),
            (N'TcpDynamicPorts',            N'Network',  N'WARNING', N'Medium', 0,
             N'Dynamic-port configuration differs; production instances should normally use a fixed TCP port.',
             N'Configure a static port on the target.'),
            (N'AvailabilityGroups',         N'AlwaysOn', N'MANUAL REVIEW', N'Medium', 0,
             N'Availability-group configuration differs; AGs must be rebuilt on the target after cutover.', NULL),
            (N'AgListeners',                N'AlwaysOn', N'MANUAL REVIEW', N'Medium', 0,
             N'AG listener configuration differs; applications connecting via the listener need it recreated (and DNS updated).', NULL)
        ) AS v (PropertyName, OwnerModule, DiffStatus, DiffSeverity, DiffBlocker, Explanation, Action))
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'InstanceProperty', @TgtServer, r.PropertyName,
               CASE WHEN s.PropertyName IS NULL OR t.PropertyName IS NULL THEN
                         CASE WHEN EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = r.OwnerModule)
                              THEN N'SKIPPED' ELSE N'MANUAL REVIEW' END
                    ELSE r.DiffStatus END,
               CASE WHEN s.PropertyName IS NULL OR t.PropertyName IS NULL THEN N'Low'
                    ELSE r.DiffSeverity END,
               CASE WHEN s.PropertyName IS NOT NULL AND t.PropertyName IS NOT NULL THEN r.DiffBlocker ELSE 0 END,
               s.PropertyValue, t.PropertyValue,
               CASE WHEN s.PropertyName IS NULL OR t.PropertyName IS NULL
                    THEN N'Property ''' + r.PropertyName + N''' was not captured on one side'
                         + CASE WHEN EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = r.OwnerModule)
                                THEN N' because its capture module failed - not validated.'
                                ELSE N' (not configured there).' END
                    ELSE r.Explanation END,
               r.Action
        FROM r
        LEFT JOIN s ON s.PropertyName = r.PropertyName
        LEFT JOIN t ON t.PropertyName = r.PropertyName
        WHERE NOT (s.PropertyName IS NULL AND t.PropertyName IS NULL)
          AND (s.PropertyName IS NULL OR t.PropertyName IS NULL
               OR ISNULL(s.PropertyValue, N'') <> ISNULL(t.PropertyValue, N''));

        /* v2.3: the hardware/feature blocks below INNER JOIN on properties
           whose capture modules (CpuInfo, Ifi) are optional - if one failed,
           the rows vanish and the check would disappear without a trace.
           Emit an explicit SKIPPED marker instead (Severity Low: an optional
           module must not force INCOMPLETE VALIDATION - pre-SP2 2016 sources
           fail the Ifi module on every run by design). */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        SELECT N'Instance', N'ComparisonSection', @TgtServer,
               CASE m.ModuleName WHEN N'Ifi'      THEN N'InstantFileInitializationEnabled'
                                 WHEN N'CpuInfo'  THEN N'CpuSocketComparison'
                                 ELSE N'HardwareComparison' END,
               N'SKIPPED',
               CASE m.ModuleName WHEN N'Hardware' THEN N'Medium' ELSE N'Low' END,
               N'The ' + m.ModuleName + N' capture module failed on at least one side; the dependent check was skipped, not validated.'
                 + CASE m.ModuleName WHEN N'Hardware'
                        THEN N' The CPU-core and physical-memory "same or better" sizing comparison did NOT run.' ELSE N'' END,
               N'Fix the capture error and re-capture (on pre-SP2 SQL 2016 sources the Ifi module cannot run - verify instant file initialization manually).'
        /* v2.4.1: 'Hardware' added.
           CpuLogicalCores and MemoryPhysicalMB - the two properties the
           "same or better" sizing rule below INNER JOINs on - are captured by
           the HARDWARE module, not CpuInfo (which owns only CpuSockets). So a
           Hardware failure made the sizing comparison return zero rows and
           vanish without a trace, while the marker literally named
           HardwareComparison fired only for socket count. Severity Medium for
           Hardware (unlike Ifi/CpuInfo at Low) because losing the CPU/RAM
           capacity check is a material gap in a migration validation. */
        FROM (SELECT DISTINCT ModuleName FROM #ModErr
              WHERE ModuleName IN (N'Ifi', N'CpuInfo', N'Hardware')) AS m;

        /* Hardware "same or better" rules: fewer cores / less RAM on the
           target than the source is a genuine performance risk. */
        ;WITH hw AS (
            SELECT s.PropertyName,
                   TRY_CONVERT(bigint, s.PropertyValue) AS SrcNum,
                   TRY_CONVERT(bigint, t.PropertyValue) AS TgtNum
            FROM migration.InstanceProperty AS s
            JOIN migration.InstanceProperty AS t
              ON t.CaptureRunId = @TargetCaptureRunId AND t.PropertyName = s.PropertyName
            WHERE s.CaptureRunId = @SourceCaptureRunId
              AND s.PropertyName IN (N'CpuLogicalCores', N'MemoryPhysicalMB'))
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'Hardware', @TgtServer, hw.PropertyName,
               CASE WHEN hw.TgtNum < hw.SrcNum THEN N'WARNING'
                    WHEN hw.TgtNum > hw.SrcNum THEN N'EXPECTED DIFFERENCE'
                    ELSE N'PASS' END,
               CASE WHEN hw.TgtNum < hw.SrcNum THEN N'High' ELSE N'Informational' END,
               CONVERT(nvarchar(20), hw.SrcNum), CONVERT(nvarchar(20), hw.TgtNum),
               CASE WHEN hw.TgtNum < hw.SrcNum
                    THEN CASE hw.PropertyName
                             WHEN N'CpuLogicalCores' THEN N'The target has FEWER logical CPU cores than the source - the "same or better" sizing rule is violated.'
                             ELSE N'The target has LESS physical memory than the source - the "same or better" sizing rule is violated.' END
                    WHEN hw.TgtNum > hw.SrcNum THEN N'The target has more than the source - fine.'
                    ELSE N'Matches the source.' END,
               CASE WHEN hw.TgtNum < hw.SrcNum THEN N'Resize the target VM (or document the accepted capacity reduction).' END
        FROM hw
        WHERE hw.SrcNum IS NOT NULL AND hw.TgtNum IS NOT NULL;

        /* Feature availability is directional too: only a TARGET lacking
           capability the source has matters; more on the target is expected. */
        ;WITH feat AS (
            SELECT s.PropertyName,
                   TRY_CONVERT(int, s.PropertyValue) AS SrcNum,
                   TRY_CONVERT(int, t.PropertyValue) AS TgtNum
            FROM migration.InstanceProperty AS s
            JOIN migration.InstanceProperty AS t
              ON t.CaptureRunId = @TargetCaptureRunId AND t.PropertyName = s.PropertyName
            WHERE s.CaptureRunId = @SourceCaptureRunId
              AND s.PropertyName IN (N'IsFullTextInstalled', N'FilestreamEffectiveLevel',
                                     N'InstantFileInitializationEnabled'))
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'InstanceProperty', @TgtServer, feat.PropertyName,
               CASE WHEN feat.TgtNum >= feat.SrcNum THEN N'EXPECTED DIFFERENCE'
                    WHEN feat.PropertyName = N'InstantFileInitializationEnabled' THEN N'WARNING'
                    ELSE N'FAIL' END,
               CASE WHEN feat.TgtNum >= feat.SrcNum THEN N'Informational'
                    WHEN feat.PropertyName = N'InstantFileInitializationEnabled' THEN N'Low'
                    ELSE N'High' END,
               CONVERT(nvarchar(20), feat.SrcNum), CONVERT(nvarchar(20), feat.TgtNum),
               CASE WHEN feat.TgtNum >= feat.SrcNum
                    THEN N'The target has MORE of this capability than the source - fine (e.g. a golden image with the feature pre-installed).'
                    ELSE CASE feat.PropertyName
                              WHEN N'IsFullTextInstalled' THEN N'Full-Text Search is available on the source but NOT on the target; full-text indexes/queries fail there.'
                              WHEN N'FilestreamEffectiveLevel' THEN N'FILESTREAM is configured LOWER on the target than the source; FILESTREAM databases cannot restore without it.'
                              ELSE N'Instant file initialization is enabled on the source but not the target; data-file growth and restores are slower there.' END END,
               CASE WHEN feat.TgtNum < feat.SrcNum THEN
                         CASE feat.PropertyName
                              WHEN N'IsFullTextInstalled' THEN N'Install the Full-Text feature on the target.'
                              WHEN N'FilestreamEffectiveLevel' THEN N'Enable FILESTREAM at least at the source level on the target.'
                              ELSE N'Grant "Perform volume maintenance tasks" to the target service account.' END END
        FROM feat
        WHERE feat.SrcNum IS NOT NULL AND feat.TgtNum IS NOT NULL
          AND feat.SrcNum <> feat.TgtNum;

        /* RAM changed but 'max server memory (MB)' was copied verbatim ->
           the memory cap no longer fits the new hardware. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'Hardware', @TgtServer, N'MaxMemoryVsNewRam',
               N'MANUAL REVIEW', N'Medium',
               N'RAM=' + sr.PropertyValue + N' MB, max server memory=' + CONVERT(nvarchar(20), sc.RunningValue),
               N'RAM=' + tr.PropertyValue + N' MB, max server memory=' + CONVERT(nvarchar(20), tc.RunningValue),
               CASE WHEN tc.RunningValue = 2147483647
                    THEN N'The physical memory changed between source and target and ''max server memory (MB)'' is UNCAPPED (2147483647) on both - the target should get a cap sized for its RAM.'
                    ELSE N'The physical memory changed between source and target but ''max server memory (MB)'' is identical - the setting was copied rather than sized for the new RAM.' END,
               N'Recalculate max server memory for the target''s RAM (leave headroom for the OS and other services).'
        FROM migration.InstanceProperty AS sr
        JOIN migration.InstanceProperty AS tr
          ON tr.CaptureRunId = @TargetCaptureRunId AND tr.PropertyName = N'MemoryPhysicalMB'
        JOIN migration.ConfigurationSetting AS sc
          ON sc.CaptureRunId = @SourceCaptureRunId AND sc.SettingName = N'max server memory (MB)'
        JOIN migration.ConfigurationSetting AS tc
          ON tc.CaptureRunId = @TargetCaptureRunId AND tc.SettingName = N'max server memory (MB)'
        WHERE sr.CaptureRunId = @SourceCaptureRunId AND sr.PropertyName = N'MemoryPhysicalMB'
          AND ISNULL(sr.PropertyValue, N'') <> ISNULL(tr.PropertyValue, N'')
          AND sc.RunningValue = tc.RunningValue;   -- uncapped-on-both with changed RAM is covered by the CASE above

        /* one PASS summary for everything that matched */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Instance', N'InstanceProperty', @TgtServer, N'MatchingProperties', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' instance properties match between source and target.'
        FROM migration.InstanceProperty AS s
        JOIN migration.InstanceProperty AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.PropertyName = s.PropertyName
        WHERE s.CaptureRunId = @SourceCaptureRunId
          AND ISNULL(s.PropertyValue, N'') = ISNULL(t.PropertyValue, N'')
          AND s.PropertyName NOT IN (N'CpuLogicalCores', N'MemoryPhysicalMB')   -- reported individually above
        HAVING COUNT(*) > 0;

        /* ------------------------------------------------------------------
           Services.

           v2.4.1 - THE GATE THIS BLOCK WAS MISSING.

           migration.ServerService is written by the HARDWARE module (02), not
           by Instance - Hardware was split out of Instance in v2.4 precisely
           because sys.dm_server_services and sys.dm_os_sys_info need VIEW
           SERVER STATE and a lower-privileged capture should not fail the
           whole required Instance module. The 02-side split was made; this
           03-side gate was not, and nothing else in the file referenced the
           module name at all.

           The consequence was the worst kind of defect this tool can have: a
           PERMISSIONS FAILURE on the target left ServerService empty, and the
           FULL OUTER JOIN below read "absent" as "deleted", emitting one
           FAIL/High per source service - "SQL Server service missing on the
           target, install it" - about services that were running perfectly.
           That is enough to force NOT READY, and because Hardware is not a
           required module the run was not even marked incomplete. An
           executive saw a red banner citing missing SQL services.

           Absence of evidence is not evidence of absence: if the module did
           not run, say so and compare nothing.
           ------------------------------------------------------------------ */
        IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Hardware')
            INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
            SELECT N'Instance', N'ComparisonSection', @TgtServer, N'ServicesComparison', N'SKIPPED', N'Medium',
                   N'The Hardware capture module failed on the ' + me.Sides
                     + N', so the Windows service inventory was never collected there. Service presence, startup type and running state were NOT compared - this is not a statement that the services are correct.',
                   N'Grant VIEW SERVER STATE to the capturing login and re-capture.'
            FROM (SELECT CASE WHEN COUNT(DISTINCT Side) > 1 THEN N'source AND target'
                              WHEN MAX(Side) = N'Source' THEN N'source' ELSE N'target' END AS Sides
                  FROM #ModErr WHERE ModuleName = N'Hardware') AS me;
        ELSE
        BEGIN
        /* Services: compare by service TYPE (name up to the '(INSTANCE)')
           so renamed instances still pair up. */
        ;WITH s AS (SELECT RTRIM(LEFT(ServiceName, CHARINDEX(N'(', ServiceName + N'(') - 1)) AS ServiceKey,
                           StartupTypeDesc, StatusDesc, ServiceAccount
                    FROM migration.ServerService WHERE CaptureRunId = @SourceCaptureRunId),
              t AS (SELECT RTRIM(LEFT(ServiceName, CHARINDEX(N'(', ServiceName + N'(') - 1)) AS ServiceKey,
                           StartupTypeDesc, StatusDesc, ServiceAccount
                    FROM migration.ServerService WHERE CaptureRunId = @TargetCaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Instance', N'ServerService', ISNULL(s.ServiceKey, t.ServiceKey), v.CheckName,
               v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM s FULL OUTER JOIN t ON t.ServiceKey = s.ServiceKey
        CROSS APPLY (VALUES
            (N'ServicePresence',
             CASE WHEN s.ServiceKey IS NULL THEN N'TARGET ONLY'
                  WHEN t.ServiceKey IS NULL THEN N'FAIL' END,
             CASE WHEN t.ServiceKey IS NULL THEN N'High' ELSE N'Low' END,
             CASE WHEN s.ServiceKey IS NULL THEN NULL ELSE s.ServiceKey END,
             CASE WHEN t.ServiceKey IS NULL THEN NULL ELSE t.ServiceKey END,
             /* v2.4.1: text and action now branch. The action used to read
                "install the missing service on the target" on BOTH branches,
                including the one where the service exists only ON the target. */
             CASE WHEN t.ServiceKey IS NULL
                  THEN N'This SQL Server service runs on the source but was not found on the target (e.g. Agent or Full-text not installed there).'
                  ELSE N'This SQL Server service exists only on the target; the source did not run it.' END,
             CASE WHEN t.ServiceKey IS NULL
                  THEN N'Install/configure the missing service on the target.'
                  ELSE N'Confirm the extra service is intentional.' END),
            (N'ServiceStartupType',
             CASE WHEN s.ServiceKey IS NOT NULL AND t.ServiceKey IS NOT NULL
                       AND ISNULL(s.StartupTypeDesc, N'') <> ISNULL(t.StartupTypeDesc, N'')
                  THEN N'WARNING' END,
             N'Medium', s.StartupTypeDesc, t.StartupTypeDesc,
             N'Service startup type differs; a Manual service will not survive a target reboot.',
             N'Set the target service startup type to match.'),
            /* service ACCOUNTS deliberately not compared: they differ on every
               cross-domain migration by nature (they stay visible in the
               captured ServerService rows for reference). */
            /* v2.4.2b: a DEMAND-START service that is merely idle is not a
               defect. The Full-text Filter Daemon Launcher and Launchpad are
               Manual/on-demand: on a production source that has served
               full-text or ML queries they read Running, and on a freshly
               restored target that has served none they read Stopped. Windows
               starts them on first use, so the difference is a workload
               artefact - it warned on every migration and told the operator to
               start a service that starts itself. An AUTOMATIC service that is
               not running IS a real finding and still warns. */
            (N'ServiceStatus',
             CASE WHEN s.ServiceKey IS NOT NULL AND t.ServiceKey IS NOT NULL
                       AND ISNULL(s.StatusDesc, N'') = N'Running'
                       AND ISNULL(t.StatusDesc, N'') <> N'Running'
                       AND ISNULL(t.StartupTypeDesc, N'') NOT IN (N'Manual', N'Disabled')
                  THEN N'WARNING' END,
             N'Medium', s.StatusDesc, t.StatusDesc,
             N'The service is set to start automatically and runs on the source, but is not running on the target.',
             N'Start the service on the target (and check its startup type).')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;
        END
    END

    /* ======================================================================
       Section: Configuration (sp_configure)
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Configuration')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Configuration', N'ComparisonSection', N'Configuration', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Configuration module failed on at least one side; sp_configure checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* v2.4.2b: the 'Required' class is GONE, and with it the only FAIL this
           section could produce.

           'backup compression default' was its sole member, so any difference
           in it - IN EITHER DIRECTION - was a FAIL, and a single FAIL anywhere
           forces NOT READY. A 2016 source left at the shipped default 0 and a
           2025 target built to a modern standard with 1 therefore turned the
           whole migration red, for a setting that is a storage/throughput
           preference and affects nothing about restore compatibility,
           correctness or cutover. Meanwhile every genuinely consequential
           option - max server memory, MAXDOP, xp_cmdshell, clr enabled - sat
           at 'Review'. The severity ordering was inverted.

           No sp_configure option is required-to-match for a lift-and-shift:
           they are all tunable on the new hardware, and the ones that carry
           real risk are exactly the ones a human must look at rather than a
           rule must fail. So the class, its three CASE branches and the
           RequiredSettingNotEvaluated typo-guard that only served it are all
           removed rather than left as unreachable code. Server COLLATION,
           which genuinely must match, is a server property and still FAILs at
           its own rule above. */
        DECLARE @ConfigClass TABLE (SettingName nvarchar(70) PRIMARY KEY, Class nvarchar(10));
        INSERT @ConfigClass VALUES
            (N'backup compression default',        N'Review'),
            (N'max server memory (MB)',            N'Review'), (N'min server memory (MB)',      N'Review'),
            (N'max degree of parallelism',         N'Review'), (N'cost threshold for parallelism', N'Review'),
            (N'optimize for ad hoc workloads',     N'Review'), (N'remote admin connections',    N'Review'),
            (N'clr enabled',                       N'Review'), (N'Database Mail XPs',           N'Review'),
            (N'Agent XPs',                         N'Review'), (N'Ad Hoc Distributed Queries',  N'Review'),
            (N'default trace enabled',             N'Review'), (N'blocked process threshold (s)', N'Review'),
            (N'query wait (s)',                    N'Review'), (N'remote query timeout (s)',    N'Review'),
            (N'max worker threads',                N'Review'), (N'network packet size (B)',     N'Review'),
            (N'xp_cmdshell',                       N'Review'), (N'cross db ownership chaining', N'Review');

        ;WITH s AS (SELECT SettingName, ConfiguredValue, RunningValue FROM migration.ConfigurationSetting WHERE CaptureRunId = @SourceCaptureRunId),
              t AS (SELECT SettingName, ConfiguredValue, RunningValue FROM migration.ConfigurationSetting WHERE CaptureRunId = @TargetCaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Configuration', N'ConfigurationSetting', s.SettingName, N'RunningValue',
               CASE cc.Class WHEN N'Review' THEN N'MANUAL REVIEW'
                             ELSE N'EXPECTED DIFFERENCE' END,
               CASE cc.Class WHEN N'Review' THEN N'Medium'
                             ELSE N'Low' END,
               CONVERT(nvarchar(30), s.RunningValue), CONVERT(nvarchar(30), t.RunningValue),
               CASE cc.Class
                    WHEN N'Review' THEN N'This operationally significant setting differs. Values rarely transfer 1:1 to new hardware - confirm the target value is intentional.'
                    ELSE N'Setting differs; typically version-default or benign, listed for completeness.' END,
               CASE cc.Class WHEN N'Review' THEN N'Confirm the target value suits the new hardware, or align it.' END
        FROM s
        JOIN t ON t.SettingName = s.SettingName
        LEFT JOIN @ConfigClass AS cc ON cc.SettingName = s.SettingName
        WHERE s.RunningValue <> t.RunningValue
          /* NOTE: this branch is deliberately the both-sides comparison.
             One-sided settings are handled by ConfigurationPresence below -
             before v2.4 the INNER JOIN silently dropped them entirely. */
          /* v2.3: the engine floors 'min server memory' 0 -> 16 on 64-bit,
             and versions differ in WHEN the floored value shows up in
             value_in_use - 0 vs 16 across sides is the same configuration,
             not a difference. */
          AND NOT (s.SettingName = N'min server memory (MB)'
                   AND ((s.RunningValue = 0  AND t.RunningValue = 16)
                     OR (s.RunningValue = 16 AND t.RunningValue = 0)));

        /* v2.4: one-sided sp_configure settings.

           The RunningValue rule above INNER JOINs the two captures, so a
           setting present in only one of them produced NO finding at all -
           and the only guard, RequiredSettingNotEvaluated, covers exactly one
           setting name. An option removed, renamed or newly introduced
           between 2016 and 2025 is precisely the kind of thing this tool
           exists to surface, and a Review-class option such as 'xp_cmdshell'
           or 'clr enabled' going missing from one side was invisible.

           A setting only on the SOURCE means the target engine no longer
           exposes it (behaviour may now be fixed, or moved elsewhere); a
           setting only on the TARGET is new in the newer version. Both are
           reviewable, neither is a failure. */
        ;WITH s AS (SELECT SettingName, RunningValue FROM migration.ConfigurationSetting WHERE CaptureRunId = @SourceCaptureRunId),
              t AS (SELECT SettingName, RunningValue FROM migration.ConfigurationSetting WHERE CaptureRunId = @TargetCaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Configuration', N'ConfigurationSetting',
               ISNULL(s.SettingName, t.SettingName), N'ConfigurationPresence',
               /* v2.4: SOURCE ONLY, the mirror of TARGET ONLY. Until now no
                  rule in the entire procedure emitted this status, so
                  ComparisonRun.SourceOnly was permanently 0, the @SrcOnly term
                  in the verdict was dead code, and the value was documented in
                  the schema but unreachable. A setting that exists only on the
                  source is exactly what it is meant to describe. */
               N'SOURCE ONLY', N'Low',
               CONVERT(nvarchar(30), s.RunningValue), CONVERT(nvarchar(30), t.RunningValue),
               N'This sp_configure option exists on the source but NOT on the target - the newer engine no longer exposes it, so whatever it controlled is now either fixed behaviour or configured elsewhere.',
               N'Confirm the behaviour this option controlled is acceptable at the target version default.'
        FROM s
        FULL OUTER JOIN t ON t.SettingName = s.SettingName
        /* v2.4.2b: TARGET ONLY rows are aggregated by the rule below.
           sys.configurations grew from ~77 rows on 2016 to ~95 on 2025, so
           every option introduced in between produced its own finding that
           counted toward @TgtOnly and demoted the verdict. The v2.4.1 note in
           the verdict section already identified this ("a 2016 -> 2025
           migration reliably produces TARGET ONLY rows") and fixed only the
           WORDING of the reason sentence; the rows themselves kept voting. */
        WHERE t.SettingName IS NULL;

        /* v2.4.2b: one row for every sp_configure option new in the target
           version. EXPECTED DIFFERENCE, so a version artefact is recorded
           without steering the verdict. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Configuration', N'ConfigurationSetting', @TgtServer,
               N'ConfigurationOptionsNewInTargetVersion',
               N'EXPECTED DIFFERENCE', N'Informational',
               N'not exposed by SQL ' + ISNULL(@SrcVersion, N'?'),
               CONVERT(nvarchar(10), COUNT(*)) + N' new option(s)',
               LEFT(N'The target engine exposes ' + CONVERT(nvarchar(10), COUNT(*))
                 + N' sp_configure option(s) the source version did not have, each running at its default: '
                 + ISNULL(STUFF((SELECT N', ' + t2.SettingName
                                 FROM migration.ConfigurationSetting AS t2
                                 WHERE t2.CaptureRunId = @TargetCaptureRunId
                                   AND NOT EXISTS (SELECT 1 FROM migration.ConfigurationSetting s2
                                                   WHERE s2.CaptureRunId = @SourceCaptureRunId
                                                     AND s2.SettingName = t2.SettingName)
                                 ORDER BY t2.SettingName
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?')
                 + N'.', 2000),
               N'No cutover action. Review the new defaults and set any that matter for your workload.'
        FROM migration.ConfigurationSetting AS t3
        WHERE t3.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM migration.ConfigurationSetting s3
                          WHERE s3.CaptureRunId = @SourceCaptureRunId
                            AND s3.SettingName = t3.SettingName)
        HAVING COUNT(*) > 0;

        /* pending (configured <> running) per side; the engine floors
           'min server memory' 0 -> 16 on 64-bit forever - not a pending change */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Configuration', N'ConfigurationSetting', c.SettingName,
               N'PendingConfiguration', N'WARNING', N'Medium',
               CASE WHEN c.CaptureRunId = @SourceCaptureRunId
                    THEN N'configured=' + CONVERT(nvarchar(30), c.ConfiguredValue) + N' running=' + CONVERT(nvarchar(30), c.RunningValue) END,
               CASE WHEN c.CaptureRunId = @TargetCaptureRunId
                    THEN N'configured=' + CONVERT(nvarchar(30), c.ConfiguredValue) + N' running=' + CONVERT(nvarchar(30), c.RunningValue) END,
               N'The configured value has not taken effect ('
                 + CASE WHEN c.CaptureRunId = @SourceCaptureRunId THEN N'source' ELSE N'target' END
                 + N'); a RECONFIGURE or restart is pending and the compared running value may change.',
               N'Run RECONFIGURE (or restart for static options) and re-capture.'
        FROM migration.ConfigurationSetting AS c
        WHERE c.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
          AND c.ConfiguredValue <> c.RunningValue
          AND NOT (c.SettingName = N'min server memory (MB)' AND c.ConfiguredValue = 0 AND c.RunningValue = 16);

        /* v2.4.2b: RequiredSettingNotEvaluated removed with the 'Required'
           class it guarded - its WHERE was `cc.Class = N'Required'`, so with
           no Required members left it could never emit a row. A Review-class
           setting absent from one capture is already covered, by name, by
           ConfigurationPresence above. */

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Configuration', N'ConfigurationSetting', @TgtServer, N'MatchingSettings', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' sp_configure running values match between source and target.'
        FROM migration.ConfigurationSetting AS s
        JOIN migration.ConfigurationSetting AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.SettingName = s.SettingName
        WHERE s.CaptureRunId = @SourceCaptureRunId AND s.RunningValue = t.RunningValue
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: TraceFlags (globally enabled)
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'TraceFlags')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'TraceFlags', N'ComparisonSection', N'TraceFlags', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The TraceFlags module failed on at least one side (DBCC TRACESTATUS needs elevated rights); trace-flag checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* v2.4: flags whose MEANING changed on the way to a modern version.
           The comparison was purely presence-based, which is fine for an unknown
           flag but says nothing useful about the handful that became default-on
           (or stopped existing) after 2016 - exactly the ones a 2016 -> 2025 move
           has to think about. Anything not listed here still compares on presence
           alone; the note is added, never substituted. */
        /* v2.4.2b: Obsolete marks flags whose BEHAVIOUR became the engine
           default (or moved to a per-database setting) at or before the target
           version. For those, absence on the newer target is the expected
           outcome, not a warning - the notes below already said "usually
           redundant" / "normally unnecessary" / "purely cosmetic" while the
           finding beside them said WARNING and told the operator to add the
           flag back to the target's startup parameters. The note was appended
           to the finding rather than being allowed to change it. */
        DECLARE @TfNote TABLE (TraceFlag int PRIMARY KEY, Note nvarchar(400), Obsolete bit NOT NULL DEFAULT 0);
        INSERT @TfNote (TraceFlag, Note, Obsolete) VALUES
            (4199, N'TF 4199 enables optimizer hotfixes globally. From SQL 2016 onward the same fixes are governed per database by the QUERY_OPTIMIZER_HOTFIXES scoped configuration and by compatibility level - check the UpgradeBehaviour findings before simply re-adding the flag.', 0),
            (9481, N'TF 9481 forces the legacy (pre-2014) cardinality estimator. On a modern target this belongs in the LEGACY_CARDINALITY_ESTIMATION database-scoped configuration instead - see the UpgradeBehaviour findings.', 0),
            /* v2.6: 2312 and 4136 join 9481 and 4199. All four are how a
               pre-2016 source expresses what a 2016+ target expresses as a
               database-scoped configuration, and on a SQL 2014 source they are
               the ONLY place that information exists - the scoped-configuration
               section is reported not-applicable there, and these notes are
               what carry the reader across the gap. Annotating two of the four
               and leaving the other two bare made the translation look
               incomplete exactly where it matters most. */
            (2312, N'TF 2312 forces the NEW (2014+) cardinality estimator, the counterpart to 9481. From SQL 2016 the same choice is made per database by compatibility level and by the LEGACY_CARDINALITY_ESTIMATION scoped configuration - check the UpgradeBehaviour findings before carrying the flag across.', 0),
            (4136, N'TF 4136 disables parameter sniffing globally. From SQL 2016 this is the per-database PARAMETER_SNIFFING scoped configuration, so a target that sets it per database does not need the global flag - and one that needs the behaviour must not silently lose it.', 0),
            (2371, N'TF 2371 makes statistics auto-update thresholds dynamic. This became the DEFAULT behaviour from SQL 2016 at compatibility level 130+, so the flag is usually redundant on the target.', 1),
            (1117, N'TF 1117 grew all files in a filegroup together. From SQL 2016 this is a per-filegroup AUTOGROW_ALL_FILES setting (and the default for tempdb), so the global flag is normally unnecessary.', 1),
            (1118, N'TF 1118 forced uniform extent allocation. From SQL 2016 this is the default for tempdb and is settable per database, so the global flag is normally unnecessary.', 1),
            /* v2.4.1: direction-neutral. This note used to say "its absence on
               the target will make the log noisier" and was appended on BOTH
               branches - including the one where the flag is present only on
               the target, contradicting the finding it was attached to. */
            (3226, N'TF 3226 suppresses successful-backup messages in the error log. Purely cosmetic: whichever side lacks it will have a noisier error log than the other.', 1);

        ;WITH s AS (SELECT TraceFlag FROM migration.TraceFlag WHERE CaptureRunId = @SourceCaptureRunId AND IsGlobal = 1 AND IsEnabled = 1),
              t AS (SELECT TraceFlag FROM migration.TraceFlag WHERE CaptureRunId = @TargetCaptureRunId AND IsGlobal = 1 AND IsEnabled = 1)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'TraceFlags', N'TraceFlag', CONVERT(nvarchar(10), ISNULL(s.TraceFlag, t.TraceFlag)),
               N'GlobalTraceFlag',
               CASE WHEN t.TraceFlag IS NULL AND ISNULL(n.Obsolete, 0) = 1 THEN N'EXPECTED DIFFERENCE'
                    WHEN t.TraceFlag IS NULL THEN N'WARNING' ELSE N'MANUAL REVIEW' END,
               CASE WHEN t.TraceFlag IS NULL AND ISNULL(n.Obsolete, 0) = 1 THEN N'Informational'
                    WHEN t.TraceFlag IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN s.TraceFlag IS NULL THEN NULL ELSE N'enabled' END,
               CASE WHEN t.TraceFlag IS NULL THEN NULL ELSE N'enabled' END,
               LEFT(CASE WHEN t.TraceFlag IS NULL AND ISNULL(n.Obsolete, 0) = 1
                    THEN N'Global trace flag enabled on the source and not on the target - and it is obsolete at the target version, so its absence is the expected outcome rather than a gap.'
                    WHEN t.TraceFlag IS NULL
                    THEN N'Global trace flag enabled on the source but not on the target; engine behavior the source depends on may change.'
                    ELSE N'Global trace flag enabled only on the target; confirm it is intentional.' END
                  + ISNULL(N' ' + n.Note, N''), 2000),
               CASE WHEN t.TraceFlag IS NULL AND ISNULL(n.Obsolete, 0) = 1 THEN NULL
                    WHEN t.TraceFlag IS NULL
                    THEN N'Evaluate whether the flag is still needed on the new version; add it to the target startup parameters if so.' END
        FROM s FULL OUTER JOIN t ON t.TraceFlag = s.TraceFlag
        LEFT JOIN @TfNote AS n ON n.TraceFlag = ISNULL(s.TraceFlag, t.TraceFlag)
        WHERE s.TraceFlag IS NULL OR t.TraceFlag IS NULL;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'TraceFlags', N'TraceFlag', @TgtServer, N'MatchingTraceFlags', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' global trace flags match.'
        FROM migration.TraceFlag AS s
        JOIN migration.TraceFlag AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.TraceFlag = s.TraceFlag
         AND t.IsGlobal = 1 AND t.IsEnabled = 1
        WHERE s.CaptureRunId = @SourceCaptureRunId AND s.IsGlobal = 1 AND s.IsEnabled = 1
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: Volumes (capacity sanity on the target)
       ====================================================================== */
    /* v2.4: gated on the TARGET side only.

       Every check in this section reads the TARGET capture and nothing else -
       there is no source-vs-target comparison here at all. The old gate tested
       #ModErr with no Side predicate, so a SOURCE-side Volumes capture failure
       (very common: VIEW SERVER STATE on the old server) suppressed the target
       free-space check entirely, and a target about to run out of disk passed
       silently. Where a section genuinely compares both sides, the both-sides
       gate below it is still correct and deliberate. */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Volumes' AND Side = N'Target')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Volumes', N'ComparisonSection', N'Volumes', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Volumes module failed on the TARGET; drive-capacity checks were skipped.',
                N'Fix the capture error (VIEW SERVER STATE) and re-capture the target.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Volumes', N'Volume', v.MountPoint, N'TargetFreeSpace',
               N'WARNING', N'High',
               NULL,
               CONVERT(nvarchar(20), v.AvailableMB) + N' MB free of ' + CONVERT(nvarchar(20), v.TotalMB) + N' MB',
               N'A target volume holding SQL Server files has less than ' + CONVERT(nvarchar(10), @MinFreePct)
                 + N'% free space. Growth, restores and index maintenance may fail.',
               N'Free up or extend the volume before cutover.'
        FROM migration.Volume AS v
        WHERE v.CaptureRunId = @TargetCaptureRunId
          AND v.TotalMB > 0
          AND v.AvailableMB * 100.0 / v.TotalMB < @MinFreePct;

        /* mount-point PRESENCE deliberately not compared: drive layouts change
           by design in a lift-and-shift; the at-a-glance drive roles and the
           free-space check above cover what matters. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Volumes', N'Volume', @TgtServer, N'VolumesHealthy', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' target volumes have adequate free space.'
        FROM migration.Volume AS v
        WHERE v.CaptureRunId = @TargetCaptureRunId
          AND v.TotalMB > 0
          AND v.AvailableMB * 100.0 / v.TotalMB >= @MinFreePct
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: Databases - existence (the restore itself) + settings
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Databases')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Databases', N'ComparisonSection', N'Databases', N'SectionSkipped', N'SKIPPED', N'High',
                N'The Databases module failed on at least one side; database existence and settings checks were skipped. The validation is NOT meaningful without them.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* user databases, minus Exclude exceptions (counted, never silent) */
        SELECT d.DatabaseName, d.OwnerName, d.CollationName, d.CompatibilityLevel,
               d.RecoveryModelDesc, d.StateDesc, d.UserAccessDesc, d.IsReadOnly,
               d.PageVerifyOptionDesc, d.IsTrustworthyOn,
               d.IsBrokerEnabled, d.IsCdcEnabled, d.IsPublished, d.IsSubscribed,
               d.IsEncrypted, d.DataFileCount, d.LogFileCount,
               d.LastFullBackup, d.LastLogBackup
        INTO #SrcDb
        FROM migration.DatabaseInfo AS d
        WHERE d.CaptureRunId = @SourceCaptureRunId AND d.IsSystem = 0
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND d.DatabaseName LIKE x.NamePattern);
        SELECT d.DatabaseName, d.OwnerName, d.CollationName, d.CompatibilityLevel,
               d.RecoveryModelDesc, d.StateDesc, d.UserAccessDesc, d.IsReadOnly,
               d.PageVerifyOptionDesc, d.IsTrustworthyOn,
               d.IsBrokerEnabled, d.IsCdcEnabled, d.IsPublished, d.IsSubscribed,
               d.IsEncrypted, d.DataFileCount, d.LogFileCount,
               d.LastFullBackup, d.LastLogBackup
        INTO #TgtDb
        FROM migration.DatabaseInfo AS d
        WHERE d.CaptureRunId = @TargetCaptureRunId AND d.IsSystem = 0
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND d.DatabaseName LIKE x.NamePattern);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(DISTINCT d.DatabaseName) FROM migration.DatabaseInfo AS d
               WHERE d.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                 AND d.IsSystem = 0 AND d.DatabaseName LIKE x.NamePattern)
        FROM #Exception AS x WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude';
        /* v2.3: every excluded object is listed BY NAME - an Exclude that
           swallows a would-be Critical (e.g. a missing database) must leave a
           per-object trace, not just an aggregate hit count. USER-ADDED
           exceptions only: the seeded prophylactic ones matching is their
           normal state and would be pure noise. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, ExceptionId)
        SELECT DISTINCT N'Databases', N'Database', LEFT(d.DatabaseName, 400), N'ExcludedByException',
               N'EXPECTED DIFFERENCE', N'Informational',
               LEFT(N'Excluded from ALL database comparisons by rule exception ('
                    + x.NamePattern + N'): ' + x.Reason, 2000),
               x.ExceptionId
        FROM migration.DatabaseInfo AS d
        JOIN #Exception AS x ON x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND d.DatabaseName LIKE x.NamePattern
        WHERE d.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId) AND d.IsSystem = 0
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                      WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

        /* missing on target = the restore is missing (or Expected exception) */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId)
        SELECT N'Databases', N'Database', s.DatabaseName, N'Existence',
               CASE WHEN x.ExceptionId IS NULL THEN N'FAIL' ELSE N'EXPECTED DIFFERENCE' END,
               CASE WHEN x.ExceptionId IS NULL THEN N'Critical' ELSE N'Informational' END,
               CASE WHEN x.ExceptionId IS NULL THEN 1 ELSE 0 END,
               s.StateDesc, NULL,
               CASE WHEN x.ExceptionId IS NULL
                    THEN N'Source user database was not found on the target - the restore is missing.'
                    ELSE N'Database intentionally absent on the target per rule exception: ' + x.Reason END,
               CASE WHEN x.ExceptionId IS NULL THEN N'Restore the database on the target (or add a rule exception if it is intentionally left behind).' END,
               x.ExceptionId
        FROM #SrcDb AS s
        OUTER APPLY (SELECT TOP (1) e.ExceptionId, e.Reason FROM #Exception AS e
                     WHERE e.Scope = N'Database' AND e.TreatAs = N'Expected'
                       AND s.DatabaseName LIKE e.NamePattern
                     ORDER BY e.ExceptionId) AS x
        WHERE NOT EXISTS (SELECT 1 FROM #TgtDb AS t WHERE t.DatabaseName = s.DatabaseName);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(*) FROM #Finding f
               WHERE f.ExceptionId = x.ExceptionId AND f.CheckName = N'Existence'
                 AND f.Category = N'Databases')
        FROM #Exception AS x WHERE x.TreatAs = N'Expected' AND x.Scope = N'Database';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation)
        SELECT N'Databases', N'Database', t.DatabaseName, N'Existence',
               N'TARGET ONLY', N'Medium', NULL, t.StateDesc,
               N'Database exists only on the target. Verify it belongs there (it will coexist with the migrated workload).'
        FROM #TgtDb AS t
        WHERE NOT EXISTS (SELECT 1 FROM #SrcDb AS s WHERE s.DatabaseName = t.DatabaseName)
          AND t.DatabaseName <> DB_NAME();   -- DBAdmin itself is expected here

        /* per-database settings via the unpivot pattern */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Databases', N'Database', s.DatabaseName, v.CheckName, v.Status, v.Severity,
               v.Blocker, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM #SrcDb AS s
        JOIN #TgtDb AS t ON t.DatabaseName = s.DatabaseName
        CROSS APPLY (VALUES
            /* v2.4: a database that was deliberately OFFLINE on the SOURCE and
               is OFFLINE on the target is a faithful restore, not a cutover
               blocker. The old rule raised Critical/blocker on any non-ONLINE
               target regardless of the source, so an intentionally offline
               database forced NOT READY on every run with no way to accept it.
               The blocker now requires the target to be WORSE than the source;
               a matching non-ONLINE state is reported, at Medium, for review. */
            (N'State',
             CASE WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE'
                       AND ISNULL(s.StateDesc, N'') = N'ONLINE'          THEN N'FAIL'
                  WHEN ISNULL(s.StateDesc, N'') <> ISNULL(t.StateDesc, N'') THEN N'WARNING'
                  WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE'             THEN N'MANUAL REVIEW' END,
             CASE WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE' AND ISNULL(s.StateDesc, N'') = N'ONLINE'
                  THEN N'Critical' ELSE N'Medium' END,
             CASE WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE' AND ISNULL(s.StateDesc, N'') = N'ONLINE'
                  THEN 1 ELSE 0 END,
             s.StateDesc, t.StateDesc,
             CASE WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE' AND ISNULL(s.StateDesc, N'') = N'ONLINE'
                  THEN N'The database was ONLINE on the source but is not ONLINE on the target. RESTORING/NORECOVERY means the restore chain was never finished.'
                  WHEN ISNULL(s.StateDesc, N'') <> ISNULL(t.StateDesc, N'')
                  THEN N'The database state differs between source and target.'
                  ELSE N'The database is not ONLINE on EITHER side - the restore faithfully reproduced the source state. Confirm it is meant to stay that way after cutover.' END,
             CASE WHEN ISNULL(t.StateDesc, N'') <> N'ONLINE' AND ISNULL(s.StateDesc, N'') = N'ONLINE'
                  THEN N'Complete the restore (WITH RECOVERY) or investigate the state before cutover.'
                  ELSE N'Confirm the non-ONLINE state is intentional; bring the database online if it is needed.' END),
            (N'CollationName',
             CASE WHEN ISNULL(s.CollationName, N'') <> ISNULL(t.CollationName, N'') THEN N'FAIL' END,
             N'High', 0, s.CollationName, t.CollationName,
             N'Database collation differs - a restore preserves collation, so this indicates the wrong database or a rebuilt one.',
             N'Investigate: the target database is probably not the restored source database.'),
            /* v2.4: directional. This tested the TARGET value ONLY and ignored
               the source entirely - a best-practice check wearing a
               comparison's clothes. A database deliberately left in
               RESTRICTED_USER on the source warned at High on every single run
               even though the migration changed nothing about it. A REGRESSION
               (multi-user source, restricted target) is still a real warning. */
            (N'UserAccess',
             /* v2.4.2: only the REGRESSION is a WARNING. A relaxation, or a
                difference between two non-MULTI_USER modes, is a decision to
                confirm - and MANUAL REVIEW is this file's vocabulary for that.
                Leaving it a WARNING contradicted the text below, which now
                says the restriction was relaxed rather than lost. */
             CASE WHEN ISNULL(t.UserAccessDesc, N'') <> N'MULTI_USER'
                       AND ISNULL(s.UserAccessDesc, N'') = N'MULTI_USER' THEN N'WARNING'
                  WHEN ISNULL(s.UserAccessDesc, N'') <> ISNULL(t.UserAccessDesc, N'') THEN N'MANUAL REVIEW' END,
             /* v2.4.2: severity and ACTION are directional too.
                2.4 made the status directional and left these two behind, so
                a target that is BETTER than the source (restricted source,
                MULTI_USER target - an ordinary pre-cutover fix) was reported
                at High with the instruction "SET MULTI_USER before cutover"
                about a database that already was MULTI_USER. */
             CASE WHEN ISNULL(s.UserAccessDesc, N'') = N'MULTI_USER' THEN N'High' ELSE N'Low' END, 0,
             s.UserAccessDesc, t.UserAccessDesc,
             CASE WHEN ISNULL(s.UserAccessDesc, N'') = N'MULTI_USER'
                  THEN N'The database was MULTI_USER on the source but is not on the target; applications cannot connect normally.'
                  WHEN ISNULL(t.UserAccessDesc, N'') = N'MULTI_USER'
                  THEN N'The database was ' + ISNULL(s.UserAccessDesc, N'?')
                     + N' on the source and is MULTI_USER on the target - the access mode was RELAXED by the migration, not lost.'
                  ELSE N'The database access mode differs between source and target (neither side is MULTI_USER).' END,
             CASE WHEN ISNULL(s.UserAccessDesc, N'') = N'MULTI_USER'
                  THEN N'ALTER DATABASE ... SET MULTI_USER before cutover.'
                  WHEN ISNULL(t.UserAccessDesc, N'') = N'MULTI_USER'
                  THEN N'Confirm the relaxation is intended; the source restriction was not carried over.'
                  ELSE N'Decide which access mode the target should run in and set it deliberately.' END),
            (N'ReadOnly',
             CASE WHEN ISNULL(s.IsReadOnly, 0) <> ISNULL(t.IsReadOnly, 0) THEN N'WARNING' END,
             N'High', 0, CONVERT(nvarchar(5), s.IsReadOnly), CONVERT(nvarchar(5), t.IsReadOnly),
             N'Read-only flag differs.', N'Align the read-only setting.'),
            /* v2.4.2b: Owner moved OUT of this per-database block and
               aggregated below. RESTORE DATABASE sets the owner to the
               restoring principal, so on a normal migration EVERY restored
               database reports the same single fact ("restored by
               CORP\dbasvc") - 20 rows on a 20-database estate, 200 on a large
               one, all identical apart from the database name. */
            /* v2.4.2b: only a LOWER target level stays per database. Raising
               the level is the expected outcome of the upgrade and produced
               one EXPECTED DIFFERENCE row per database; those are aggregated
               below with the not-raised case, so the compatibility-level
               story is one or two rows however many databases there are. */
            (N'CompatibilityLevel',
             CASE WHEN t.CompatibilityLevel < s.CompatibilityLevel THEN N'WARNING' END,
             N'Medium', 0,
             CONVERT(nvarchar(10), s.CompatibilityLevel), CONVERT(nvarchar(10), t.CompatibilityLevel),
             N'The target database runs at a LOWER compatibility level than the source. That is the opposite of the upgrade''s intent and is unusual enough to check.',
             N'Confirm this was deliberate; otherwise raise it to at least the source level.'),
            /* v2.4: the case the rule above CANNOT see.

               CompatibilityLevel only fires when the two sides DIFFER, so the
               single most common real post-restore state - source at 130, the
               database restored onto the 2025 target and simply left at 130 -
               produced NO finding whatsoever. The databases match, so nothing
               was "wrong"; but the whole point of the migration was to run at
               the new version's level, and staying at the old one silently
               keeps the old optimizer behaviour. Equality is exactly what
               makes this worth saying. */
            /* v2.4.2b: CompatibilityLevelNotRaised moved OUT of this
               per-database block and aggregated below. Keeping the source
               level after a restore is Microsoft's documented upgrade
               practice - restore, hold the level, enable Query Store,
               regression-test, then raise - so a team doing exactly the right
               thing got one MANUAL REVIEW/Medium per database. That is ONE
               decision ("do we raise compatibility level, and when?"), not N,
               and at Medium it counted N times toward @ManualActionable: the
               measured 20-database run reported "180 manual-review item(s)
               needing a decision" at 200 databases. */
            (N'RecoveryModel',
             CASE WHEN ISNULL(s.RecoveryModelDesc, N'') <> ISNULL(t.RecoveryModelDesc, N'') THEN N'WARNING' END,
             N'Medium', 0, s.RecoveryModelDesc, t.RecoveryModelDesc,
             N'Recovery model differs; log backup chains and RPO change with it.',
             N'Align the recovery model with the backup strategy for the target.'),
            /* v2.4: directional, for the same reason as UserAccess above. A
               restore preserves PAGE_VERIFY exactly, so a source running
               NONE/TORN_PAGE_DETECTION produced an unavoidable Medium warning
               on every run about something the migration did not change. A
               source that HAD checksum and a target that lost it is a genuine
               regression and still warns; a pre-existing non-CHECKSUM setting
               is now advisory (Low) so it informs without steering the verdict. */
            (N'PageVerify',
             /* v2.4.2: a target RAISED to CHECKSUM is an EXPECTED DIFFERENCE,
                the same classification the hardware and compatibility-level
                rules already use when the target is better than the source.
                It was a Medium WARNING, which pushed an improved migration to
                READY WITH WARNINGS. */
             CASE WHEN ISNULL(t.PageVerifyOptionDesc, N'') = N'CHECKSUM'
                       AND ISNULL(s.PageVerifyOptionDesc, N'') <> N'CHECKSUM' THEN N'EXPECTED DIFFERENCE'
                  WHEN ISNULL(t.PageVerifyOptionDesc, N'') <> ISNULL(s.PageVerifyOptionDesc, N'') THEN N'WARNING'
                  WHEN ISNULL(t.PageVerifyOptionDesc, N'') <> N'CHECKSUM' THEN N'MANUAL REVIEW' END,
             /* v2.4.2: severity and ACTION are directional too - same omission
                as UserAccess above. A target already RAISED to CHECKSUM from a
                non-CHECKSUM source was warned at Medium and told to "SET
                PAGE_VERIFY CHECKSUM" on the side that already had it. */
             CASE WHEN ISNULL(t.PageVerifyOptionDesc, N'') = N'CHECKSUM' THEN N'Informational'
                  WHEN ISNULL(t.PageVerifyOptionDesc, N'') <> ISNULL(s.PageVerifyOptionDesc, N'') THEN N'Medium'
                  ELSE N'Informational' END, 0,
             s.PageVerifyOptionDesc, t.PageVerifyOptionDesc,
             CASE WHEN ISNULL(t.PageVerifyOptionDesc, N'') = N'CHECKSUM'
                       AND ISNULL(s.PageVerifyOptionDesc, N'') <> N'CHECKSUM'
                  THEN N'Page verification was ' + ISNULL(NULLIF(s.PageVerifyOptionDesc, N''), N'(none)')
                     + N' on the source and is CHECKSUM on the target - an IMPROVEMENT the migration introduced, not a regression.'
                  WHEN ISNULL(t.PageVerifyOptionDesc, N'') <> ISNULL(s.PageVerifyOptionDesc, N'')
                  THEN N'Page verification differs between source and target.'
                  ELSE N'The database does not use CHECKSUM page verification on EITHER side - unchanged by the migration, but worth fixing while you are here.' END,
             CASE WHEN ISNULL(t.PageVerifyOptionDesc, N'') = N'CHECKSUM'
                       AND ISNULL(s.PageVerifyOptionDesc, N'') <> N'CHECKSUM' THEN NULL
                  ELSE N'ALTER DATABASE ... SET PAGE_VERIFY CHECKSUM.' END),
            /* v2.4.2b: directional. One explanation and one action served both
               directions, so a target that had TRUSTWORTHY switched ON where
               the source had it OFF - a privilege-escalation surface, and the
               more dangerous of the two directions - was described as "the
               source relied on it, those break on the target" and answered
               with "SET TRUSTWORTHY ON". The report was recommending the
               regression. Same omission v2.4.2 fixed for UserAccess and
               PageVerify; these two were missed. */
            (N'Trustworthy',
             CASE WHEN ISNULL(s.IsTrustworthyOn, 0) <> ISNULL(t.IsTrustworthyOn, 0) THEN N'WARNING' END,
             N'High', 0, CONVERT(nvarchar(5), s.IsTrustworthyOn), CONVERT(nvarchar(5), t.IsTrustworthyOn),
             CASE WHEN ISNULL(s.IsTrustworthyOn, 0) = 1
                  THEN N'TRUSTWORTHY was ON at the source and is OFF on the target. A restore always resets it OFF, so this is expected - but if the source relied on it (CLR assemblies, cross-database ownership chaining), those break on the target.'
                  ELSE N'TRUSTWORTHY is ON at the TARGET and was OFF at the source. The migration ADDED this - it is a privilege-escalation surface (code in the database can act with the owner''s server-level rights) and nothing in the source required it.' END,
             CASE WHEN ISNULL(s.IsTrustworthyOn, 0) = 1
                  THEN N'Re-evaluate the need; if genuinely required, ALTER DATABASE ... SET TRUSTWORTHY ON after verifying the database owner is not a sysadmin.'
                  ELSE N'ALTER DATABASE ... SET TRUSTWORTHY OFF unless something on the target specifically requires it.' END),
            (N'ServiceBroker',
             CASE WHEN ISNULL(s.IsBrokerEnabled, 0) <> ISNULL(t.IsBrokerEnabled, 0) THEN N'WARNING' END,
             N'Medium', 0, CONVERT(nvarchar(5), s.IsBrokerEnabled), CONVERT(nvarchar(5), t.IsBrokerEnabled),
             N'Service Broker enablement differs. A restore disables the broker - queues stay silent until ENABLE_BROKER.',
             N'ALTER DATABASE ... SET ENABLE_BROKER (choose the right conversation-handling option).'),
            (N'ChangeDataCapture',
             CASE WHEN ISNULL(s.IsCdcEnabled, 0) = 1 AND ISNULL(t.IsCdcEnabled, 0) = 0 THEN N'WARNING' END,
             N'High', 0, CONVERT(nvarchar(5), s.IsCdcEnabled), CONVERT(nvarchar(5), t.IsCdcEnabled),
             N'CDC is enabled on the source but not the target (restore without KEEP_CDC drops it). Downstream consumers lose their feed.',
             N'Restore WITH KEEP_CDC or re-enable and re-initialize CDC on the target.'),
            (N'Replication',
             CASE WHEN (ISNULL(s.IsPublished, 0) = 1 AND ISNULL(t.IsPublished, 0) = 0)
                    OR (ISNULL(s.IsSubscribed, 0) = 1 AND ISNULL(t.IsSubscribed, 0) = 0) THEN N'MANUAL REVIEW' END,
             N'High', 0,
             N'published=' + CONVERT(nvarchar(5), ISNULL(s.IsPublished, 0)) + N' subscribed=' + CONVERT(nvarchar(5), ISNULL(s.IsSubscribed, 0)),
             N'published=' + CONVERT(nvarchar(5), ISNULL(t.IsPublished, 0)) + N' subscribed=' + CONVERT(nvarchar(5), ISNULL(t.IsSubscribed, 0)),
             N'Replication participation differs - replication must be reconfigured after a restore-based migration.',
             N'Plan publication/subscription re-setup as part of cutover.'),
            (N'TDE',
             CASE WHEN ISNULL(s.IsEncrypted, 0) = 1 AND ISNULL(t.IsEncrypted, 0) = 0 THEN N'FAIL' END,
             N'High', 0, CONVERT(nvarchar(5), s.IsEncrypted), CONVERT(nvarchar(5), t.IsEncrypted),
             N'The source database is TDE-encrypted but the target copy is not.',
             N'Verify the certificate migration and encryption state on the target.'),
            /* NOTE: auto-close/shrink/create-stats/update-stats and containment
               are deliberately NOT compared - a restore preserves them exactly,
               so they can only differ when the target is the wrong database,
               which CollationName and FileCount already catch with less noise. */
            (N'FileCount',
             CASE WHEN ISNULL(s.DataFileCount, 0) <> ISNULL(t.DataFileCount, 0)
                    OR ISNULL(s.LogFileCount, 0) <> ISNULL(t.LogFileCount, 0) THEN N'WARNING' END,
             N'High', 0,
             CONVERT(nvarchar(10), s.DataFileCount) + N' data / ' + CONVERT(nvarchar(10), s.LogFileCount) + N' log',
             CONVERT(nvarchar(10), t.DataFileCount) + N' data / ' + CONVERT(nvarchar(10), t.LogFileCount) + N' log',
             N'File counts differ. A restore preserves the file set exactly - this suggests an old backup or a different database.',
             N'Verify the restore used the intended (latest) source backup.')
        ) AS v (CheckName, Status, Severity, Blocker, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        /* ---- v2.4.2b: USER-DATABASE FILE GEOMETRY ------------------------

           migration.DatabaseFile is captured for EVERY database (02), with
           SizeMB, MaxSizeMB and GrowthDesc per file. Every read of that table
           in this procedure was scoped to tempdb, so the file geometry of the
           migrated databases - the thing the whole migration moves - was
           collected and never compared. It was the largest silent blind spot
           in the tool.

           The scenario it missed: a database restored WITH MOVE onto a smaller
           target volume, its log capped at MAXSIZE = 2GB, or a file that
           inherited FILEGROWTH = 1% where the source used a fixed 512MB. Every
           existing check passes - FileCount matches, collation matches, state
           is ONLINE, recovery model matches - and weeks after cutover the log
           hits its cap and the database stops accepting writes.

           Compared by logical name (stable across a restore, even WITH MOVE,
           because MOVE remaps the PHYSICAL path and keeps the logical name).
           Aggregated: one row per database, not one per file. Physical paths
           are deliberately NOT compared - relocating files is the normal point
           of a lift-and-shift. */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Databases', N'DatabaseFile', f.DatabaseName, f.LogicalName, N'FileGeometry',
               /* a growth cap the source did not have is the dangerous one */
               CASE WHEN f.SrcMaxSizeMB IS NULL AND f.TgtMaxSizeMB IS NOT NULL THEN N'WARNING'
                    WHEN f.TgtMaxSizeMB < f.SrcMaxSizeMB                       THEN N'WARNING'
                    ELSE N'MANUAL REVIEW' END,
               CASE WHEN f.SrcMaxSizeMB IS NULL AND f.TgtMaxSizeMB IS NOT NULL THEN N'High'
                    WHEN f.TgtMaxSizeMB < f.SrcMaxSizeMB                       THEN N'High'
                    ELSE N'Low' END,
               N'max=' + ISNULL(CONVERT(nvarchar(20), f.SrcMaxSizeMB) + N' MB', N'unlimited')
                 + N' growth=' + ISNULL(f.SrcGrowthDesc, N'?')
                 + N' size=' + CONVERT(nvarchar(20), ISNULL(f.SrcSizeMB, 0)) + N' MB',
               N'max=' + ISNULL(CONVERT(nvarchar(20), f.TgtMaxSizeMB) + N' MB', N'unlimited')
                 + N' growth=' + ISNULL(f.TgtGrowthDesc, N'?')
                 + N' size=' + CONVERT(nvarchar(20), ISNULL(f.TgtSizeMB, 0)) + N' MB',
               CASE WHEN f.SrcMaxSizeMB IS NULL AND f.TgtMaxSizeMB IS NOT NULL
                    THEN N'This file grew without limit on the source and is CAPPED on the target. When it reaches the cap, writes to this database fail.'
                    WHEN f.TgtMaxSizeMB < f.SrcMaxSizeMB
                    THEN N'This file''s maximum size is SMALLER on the target than on the source. It will stop growing sooner than the source did.'
                    ELSE N'The file''s autogrowth increment differs between source and target. Percentage growth on a large file causes progressively larger, slower growth events; a small fixed increment causes frequent ones.' END,
               CASE WHEN f.SrcMaxSizeMB IS NULL AND f.TgtMaxSizeMB IS NOT NULL
                       OR f.TgtMaxSizeMB < f.SrcMaxSizeMB
                    THEN N'ALTER DATABASE ' + QUOTENAME(f.DatabaseName) + N' MODIFY FILE (NAME = '
                       + QUOTENAME(f.LogicalName) + N', MAXSIZE = UNLIMITED) - or match the source cap.'
                    ELSE N'Align the autogrowth setting with the source, or record why the target differs.' END
        FROM (SELECT sf.DatabaseName, sf.LogicalName,
                     sf.SizeMB AS SrcSizeMB, sf.MaxSizeMB AS SrcMaxSizeMB, sf.GrowthDesc AS SrcGrowthDesc,
                     tf.SizeMB AS TgtSizeMB, tf.MaxSizeMB AS TgtMaxSizeMB, tf.GrowthDesc AS TgtGrowthDesc
              FROM migration.DatabaseFile AS sf
              JOIN migration.DatabaseFile AS tf
                ON tf.CaptureRunId = @TargetCaptureRunId
               AND tf.DatabaseName = sf.DatabaseName AND tf.LogicalName = sf.LogicalName
              WHERE sf.CaptureRunId = @SourceCaptureRunId
                AND EXISTS (SELECT 1 FROM #SrcDb d WHERE d.DatabaseName = sf.DatabaseName)
                AND EXISTS (SELECT 1 FROM #TgtDb d WHERE d.DatabaseName = sf.DatabaseName)) AS f
        WHERE ISNULL(f.SrcMaxSizeMB, -1) <> ISNULL(f.TgtMaxSizeMB, -1)
           OR ISNULL(f.SrcGrowthDesc, N'') <> ISNULL(f.TgtGrowthDesc, N'');

        /* ---- v2.4.2b: the three per-database facts, aggregated ------------
           Each of these said ONE thing about the migration and said it once
           per database. On the measured 200-database estate they contributed
           380 of 423 rows between them. The per-database detail is still in
           the values (names are listed, truncation disclosed) - it just no
           longer arrives as N separate findings, and no longer votes N times
           in the verdict. */

        /* (a) owner rewritten by RESTORE */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Databases', N'Database', @TgtServer, N'DatabaseOwners', N'WARNING', N'Low',
               LEFT(ISNULL(STUFF((SELECT DISTINCT N', ' + ISNULL(s2.OwnerName, N'(unresolved)')
                                  FROM #SrcDb s2 JOIN #TgtDb t2 ON t2.DatabaseName = s2.DatabaseName
                                  WHERE ISNULL(s2.OwnerName, N'') <> ISNULL(t2.OwnerName, N'')
                                  ORDER BY N', ' + ISNULL(s2.OwnerName, N'(unresolved)')
                                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 500),
               LEFT(ISNULL(STUFF((SELECT DISTINCT N', ' + ISNULL(t2.OwnerName, N'(unresolved)')
                                  FROM #SrcDb s2 JOIN #TgtDb t2 ON t2.DatabaseName = s2.DatabaseName
                                  WHERE ISNULL(s2.OwnerName, N'') <> ISNULL(t2.OwnerName, N'')
                                  ORDER BY N', ' + ISNULL(t2.OwnerName, N'(unresolved)')
                                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 500),
               LEFT(CONVERT(nvarchar(10), COUNT(*))
                 + N' database(s) have a different owner on the target. RESTORE DATABASE sets the owner to the restoring principal, so this is the normal outcome of a restore rather than a defect - but ownership affects TRUSTWORTHY, cross-database chaining, Service Broker and job execution context. Databases: '
                 + ISNULL(STUFF((SELECT N', ' + s3.DatabaseName
                                 FROM #SrcDb s3 JOIN #TgtDb t3 ON t3.DatabaseName = s3.DatabaseName
                                 WHERE ISNULL(s3.OwnerName, N'') <> ISNULL(t3.OwnerName, N'')
                                 ORDER BY s3.DatabaseName
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1900)
                 + N'.',
               N'ALTER AUTHORIZATION ON DATABASE::<name> TO <intended owner> for each, or record that the restoring principal is the intended owner.'
        FROM #SrcDb AS s JOIN #TgtDb AS t ON t.DatabaseName = s.DatabaseName
        WHERE ISNULL(s.OwnerName, N'') <> ISNULL(t.OwnerName, N'')
        HAVING COUNT(*) > 0;

        /* (b) still at the source compatibility level on a newer engine */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'UpgradeBehaviour', N'Database', @TgtServer, N'CompatibilityLevelNotRaised',
               N'MANUAL REVIEW', N'Medium',
               CONVERT(nvarchar(10), MIN(t.CompatibilityLevel))
                 + CASE WHEN MIN(t.CompatibilityLevel) <> MAX(t.CompatibilityLevel)
                        THEN N'-' + CONVERT(nvarchar(10), MAX(t.CompatibilityLevel)) ELSE N'' END,
               N'target native level ' + CONVERT(nvarchar(10), @TgtNativeCompat),
               LEFT(CONVERT(nvarchar(10), COUNT(*))
                 + N' database(s) still run at the SOURCE version''s compatibility level on a newer target engine (native level '
                 + CONVERT(nvarchar(10), @TgtNativeCompat)
                 + N'). Nothing differs between the two sides, so no difference-based check reports it - but those databases are not yet using the target version''s optimizer behaviour. Holding the old level until regression testing is finished is the documented upgrade practice; this is one decision to record, not a defect. Databases: '
                 + ISNULL(STUFF((SELECT N', ' + s2.DatabaseName
                                 FROM #SrcDb s2 JOIN #TgtDb t2 ON t2.DatabaseName = s2.DatabaseName
                                 WHERE s2.CompatibilityLevel = t2.CompatibilityLevel
                                   AND t2.CompatibilityLevel < @TgtNativeCompat
                                 ORDER BY s2.DatabaseName
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1900)
                 + N'.',
               N'Decide once for the estate: raise to ' + CONVERT(nvarchar(10), @TgtNativeCompat)
                 + N' after regression testing, or record why the old level stays.'
        FROM #SrcDb AS s JOIN #TgtDb AS t ON t.DatabaseName = s.DatabaseName
        WHERE s.CompatibilityLevel = t.CompatibilityLevel
          AND @TgtMajor > @SrcMajor
          AND t.CompatibilityLevel < @TgtNativeCompat
        HAVING COUNT(*) > 0;

        /* (c) compatibility level already raised - good news, one row */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation)
        SELECT N'UpgradeBehaviour', N'Database', @TgtServer, N'CompatibilityLevelRaised',
               N'EXPECTED DIFFERENCE', N'Informational',
               CONVERT(nvarchar(10), MIN(s.CompatibilityLevel)),
               CONVERT(nvarchar(10), MIN(t.CompatibilityLevel))
                 + CASE WHEN MIN(t.CompatibilityLevel) <> MAX(t.CompatibilityLevel)
                        THEN N'-' + CONVERT(nvarchar(10), MAX(t.CompatibilityLevel)) ELSE N'' END,
               CONVERT(nvarchar(10), COUNT(*))
                 + N' database(s) were raised to a higher compatibility level on the target. That is the expected outcome of the upgrade.'
        FROM #SrcDb AS s JOIN #TgtDb AS t ON t.DatabaseName = s.DatabaseName
        WHERE t.CompatibilityLevel > s.CompatibilityLevel
        HAVING COUNT(*) > 0;

        /* target user databases with no locally-taken full backup yet.
           GATED on BackupSummary: if that module failed, LastFullBackup is
           NULL for everything and this would fabricate a 'no recovery point'
           claim from missing data. */
        IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'BackupSummary')
            INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
            VALUES (N'Databases', N'ComparisonSection', N'TargetLocalBackups', N'SectionSkipped', N'SKIPPED', N'Medium',
                    N'The BackupSummary module failed on at least one side; the target-local-backup check was skipped (backup dates were not collected).',
                    N'Fix the capture error (msdb read permissions) and re-capture.');
        ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         TargetValue, Explanation, RecommendedAction)
        SELECT N'Databases', N'Database', @TgtServer, N'TargetLocalBackups', N'WARNING', N'Medium',
               /* LEFT: before cutover EVERY database is typically in this list -
                  a long list must truncate, never abort the whole comparison */
               /* v2.4.1: state the COUNT first and disclose the truncation.
                  The list is a single finding with no per-database fallback,
                  so on a consolidation target with hundreds of databases the
                  names were silently cut mid-word and the row read complete. */
               CONVERT(nvarchar(10), (SELECT COUNT(*) FROM #TgtDb AS t3
                                      WHERE t3.LastFullBackup IS NULL AND t3.DatabaseName <> DB_NAME()))
                 + N' database(s): '
                 + LEFT(STUFF((SELECT N', ' + t2.DatabaseName FROM #TgtDb AS t2
                      WHERE t2.LastFullBackup IS NULL AND t2.DatabaseName <> DB_NAME()
                      ORDER BY t2.DatabaseName
                      FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), 3800)
                 + CASE WHEN LEN(ISNULL(STUFF((SELECT N', ' + t4.DatabaseName FROM #TgtDb AS t4
                             WHERE t4.LastFullBackup IS NULL AND t4.DatabaseName <> DB_NAME()
                             ORDER BY t4.DatabaseName
                             FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'')) > 3800
                        THEN N' ... (list truncated - see the count above)' ELSE N'' END,
               N'These target databases have no full backup TAKEN ON THE TARGET yet (restore-imported source history does not count, and copy-only backups are excluded). There is no local recovery point from a scheduled backup.',
               N'Configure and run target backup jobs before or immediately at cutover.'
        WHERE EXISTS (SELECT 1 FROM #TgtDb AS t2
                      WHERE t2.LastFullBackup IS NULL AND t2.DatabaseName <> DB_NAME());

        /* v2.4.2b: LOG-BACKUP POSTURE. DatabaseInfo.LastLogBackup and
           LastDiffBackup are captured on both sides (02, BackupSummary) and
           had ZERO references in this procedure - the only backup check was
           TargetLocalBackups, which fires solely on "no FULL backup at all".

           So: target databases in FULL recovery (matching the source, so the
           RecoveryModel rule is silent), one ad-hoc full backup taken during
           testing (so TargetLocalBackups is silent), and no log-backup job
           migrated. The log grows without bound and the RPO is infinite, and
           the report said nothing - while holding the evidence that the SOURCE
           was taking log backups. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Databases', N'Database', @TgtServer, N'LogBackupPosture', N'WARNING', N'High',
               N'source was taking log backups', N'no log backup on the target',
               LEFT(CONVERT(nvarchar(10), COUNT(*))
                 + N' database(s) are in a log-backup recovery model and had log backups running on the SOURCE, but no log backup has been taken on the target. Until a log-backup schedule exists there the transaction log grows without bound and there is no point-in-time recovery. Databases: '
                 + ISNULL(STUFF((SELECT N', ' + s2.DatabaseName
                                 FROM #SrcDb s2 JOIN #TgtDb t2 ON t2.DatabaseName = s2.DatabaseName
                                 WHERE s2.RecoveryModelDesc <> N'SIMPLE'
                                   AND s2.LastLogBackup IS NOT NULL AND t2.LastLogBackup IS NULL
                                   AND t2.DatabaseName <> DB_NAME()
                                 ORDER BY s2.DatabaseName
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1900)
                 + N'.',
               N'Migrate or recreate the log-backup schedule on the target before cutover.'
        FROM #SrcDb AS s JOIN #TgtDb AS t ON t.DatabaseName = s.DatabaseName
        WHERE s.RecoveryModelDesc <> N'SIMPLE'
          AND s.LastLogBackup IS NOT NULL AND t.LastLogBackup IS NULL
          AND t.DatabaseName <> DB_NAME()
        HAVING COUNT(*) > 0;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Databases', N'Database', @TgtServer, N'DatabasesPresent', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' source user databases are present on the target.'
        FROM #SrcDb AS s
        WHERE EXISTS (SELECT 1 FROM #TgtDb AS t WHERE t.DatabaseName = s.DatabaseName)
        HAVING COUNT(*) > 0;

        /* ------- system databases: tempdb layout + model defaults -------- */
        ;WITH s AS (SELECT * FROM migration.DatabaseInfo WHERE CaptureRunId = @SourceCaptureRunId AND DatabaseName = N'tempdb'),
              t AS (SELECT * FROM migration.DatabaseInfo WHERE CaptureRunId = @TargetCaptureRunId AND DatabaseName = N'tempdb')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDatabases', N'Database', N'tempdb', v.CheckName, v.Status, v.Severity,
               v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM s CROSS JOIN t
        CROSS APPLY (VALUES
            (N'TempdbDataFiles',
             CASE WHEN ISNULL(t.DataFileCount, 0) < ISNULL(s.DataFileCount, 0) THEN N'WARNING'
                  WHEN ISNULL(t.DataFileCount, 0) > ISNULL(s.DataFileCount, 0) THEN N'EXPECTED DIFFERENCE' END,
             CASE WHEN ISNULL(t.DataFileCount, 0) < ISNULL(s.DataFileCount, 0) THEN N'Medium' ELSE N'Informational' END,
             CONVERT(nvarchar(10), s.DataFileCount), CONVERT(nvarchar(10), t.DataFileCount),
             /* v2.4.1: one explanation used to serve both branches, so the
                EXPECTED DIFFERENCE case (target has MORE files) printed
                "tempdb has fewer data files on the target" beside values
                showing the opposite. */
             CASE WHEN ISNULL(t.DataFileCount, 0) < ISNULL(s.DataFileCount, 0)
                  THEN N'tempdb has FEWER data files on the target than the source; allocation contention may return.'
                  ELSE N'tempdb has MORE data files on the target than the source. More files than the source is fine - noted for completeness.' END,
             CASE WHEN ISNULL(t.DataFileCount, 0) < ISNULL(s.DataFileCount, 0)
                  THEN N'Add tempdb data files (usually one per core up to 8, uniformly sized).' END),
            (N'TempdbTotalSize',
             CASE WHEN ISNULL(t.TotalDataMB, 0) < ISNULL(s.TotalDataMB, 0) THEN N'WARNING' END,
             N'Low',
             CONVERT(nvarchar(20), s.TotalDataMB) + N' MB', CONVERT(nvarchar(20), t.TotalDataMB) + N' MB',
             N'tempdb is smaller on the target than the source; it will grow back under load (with growth stalls unless IFI is on).',
             N'Pre-size tempdb at least to the source total.')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        /* target tempdb data files should be uniform */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDatabases', N'Database', N'tempdb', N'TempdbUniformFiles', N'WARNING', N'Low',
               CONVERT(nvarchar(20), MIN(f.SizeMB)) + N'-' + CONVERT(nvarchar(20), MAX(f.SizeMB)) + N' MB',
               N'Target tempdb data files are not uniformly sized; proportional fill skews toward the biggest file.',
               N'Resize tempdb data files to identical sizes.'
        FROM migration.DatabaseFile AS f
        WHERE f.CaptureRunId = @TargetCaptureRunId AND f.DatabaseName = N'tempdb' AND f.TypeDesc = N'ROWS'
        HAVING COUNT(*) > 1 AND MIN(f.SizeMB) <> MAX(f.SizeMB);

        /* tempdb autogrowth settings */
        ;WITH growth AS (
            SELECT CaptureRunId,
                   /* v2.3: ORDER BY - DISTINCT without an order serialized the
                      set in arbitrary order and could false-warn on two
                      identical growth configurations. (Correlation stays in
                      the subquery WHERE - a derived table cannot reference
                      outer columns.) */
                   STUFF((SELECT N',' + g.GrowthDesc
                          FROM (SELECT f2.CaptureRunId, ISNULL(f2.GrowthDesc, N'?') AS GrowthDesc
                                FROM migration.DatabaseFile AS f2
                                WHERE f2.DatabaseName = N'tempdb' AND f2.TypeDesc = N'ROWS'
                                GROUP BY f2.CaptureRunId, ISNULL(f2.GrowthDesc, N'?')) AS g
                          WHERE g.CaptureRunId = f.CaptureRunId
                          ORDER BY g.GrowthDesc
                          FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'') AS GrowthList
            FROM migration.DatabaseFile AS f
            WHERE f.DatabaseName = N'tempdb' AND f.TypeDesc = N'ROWS'
            GROUP BY CaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDatabases', N'Database', N'tempdb', N'TempdbAutogrowth', N'WARNING', N'Low',
               s.GrowthList, t.GrowthList,
               N'tempdb data-file autogrowth settings differ between source and target.',
               N'Align tempdb autogrowth (fixed MB increments, identical across files).'
        FROM (SELECT GrowthList FROM growth WHERE CaptureRunId = @SourceCaptureRunId) AS s
        CROSS JOIN (SELECT GrowthList FROM growth WHERE CaptureRunId = @TargetCaptureRunId) AS t
        WHERE ISNULL(s.GrowthList, N'') <> ISNULL(t.GrowthList, N'');

        ;WITH s AS (SELECT * FROM migration.DatabaseInfo WHERE CaptureRunId = @SourceCaptureRunId AND DatabaseName = N'model'),
              t AS (SELECT * FROM migration.DatabaseInfo WHERE CaptureRunId = @TargetCaptureRunId AND DatabaseName = N'model')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDatabases', N'Database', N'model', N'ModelDefaults',
               N'WARNING', N'Low',
               N'recovery=' + ISNULL(s.RecoveryModelDesc, N'?'),
               N'recovery=' + ISNULL(t.RecoveryModelDesc, N'?'),
               N'model database defaults differ; NEW databases created on the target inherit different settings than on the source.',
               N'Align model settings if new-database defaults matter to your standards.'
        FROM s CROSS JOIN t
        WHERE ISNULL(s.RecoveryModelDesc, N'') <> ISNULL(t.RecoveryModelDesc, N'');
    END

    /* ======================================================================
       Section: RestoreValidation - provenance of every target user database
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName IN (N'Databases', N'RestoreHistory'))
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'RestoreValidation', N'ComparisonSection', N'RestoreValidation', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Databases or RestoreHistory module failed; restore-provenance checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE IF OBJECT_ID(N'tempdb..#TgtDb') IS NOT NULL
    BEGIN
        ;WITH latest AS (
            /* v2.4.2b: re.RestoreTypeDesc dropped - projected here and never
               referenced by the consuming SELECT. */
            SELECT re.DatabaseName, re.RestoreDate, re.RestoredBy,
                   re.SourceServerName, re.SourceDatabaseName, re.BackupFinishDate,
                   ROW_NUMBER() OVER (PARTITION BY re.DatabaseName
                                      ORDER BY re.RestoreDate DESC, re.RestoreHistoryId DESC) AS rn
            FROM migration.RestoreEvent AS re
            WHERE re.CaptureRunId = @TargetCaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'RestoreValidation', N'Database', t.DatabaseName, N'RestoreProvenance',
               /* v2.3: an UNKNOWN origin (backupset row purged from msdb) is
                  "unverifiable", not the positive claim "NOT the source" */
               CASE WHEN l.DatabaseName IS NULL THEN N'WARNING'
                    WHEN l.SourceServerName IS NULL THEN N'MANUAL REVIEW'
                    WHEN l.SourceServerName = @SrcServer THEN N'PASS'
                    /* v2.4: the recorded backup server matches the source
                       MACHINE - a rename/FCI/AG-secondary, not a wrong backup */
                    WHEN l.SourceServerName = @SrcMachine THEN N'MANUAL REVIEW'
                    ELSE N'WARNING' END,
               /* v2.4: a foreign origin is Medium, not High, when it is
                  explainable by a name change rather than a wrong backup.
                  backupset.server_name records @@SERVERNAME AT BACKUP TIME
                  while @SrcServer is SERVERPROPERTY('ServerName') at CAPTURE
                  time; those legitimately differ on a renamed instance, an
                  FCI, an AG secondary that took the final backup, or a
                  two-hop source -> staging -> target restore. Matching the
                  source's MACHINE name is strong corroboration, so treat that
                  as MANUAL REVIEW instead of a High "wrong server" warning. */
               CASE WHEN l.DatabaseName IS NULL THEN N'Medium'
                    WHEN l.SourceServerName IS NULL THEN N'Medium'
                    WHEN l.SourceServerName = @SrcServer THEN N'Informational'
                    WHEN l.SourceServerName = @SrcMachine THEN N'Medium'
                    ELSE N'High' END,
               CASE WHEN l.DatabaseName IS NULL THEN NULL
                    ELSE ISNULL(l.SourceServerName, N'(unknown)') + N'.' + ISNULL(l.SourceDatabaseName, N'?')
                         + N' backup ' + ISNULL(CONVERT(nvarchar(30), l.BackupFinishDate, 120), N'?') END,
               CASE WHEN l.DatabaseName IS NULL THEN N'no restore in captured history'
                    ELSE N'restored ' + ISNULL(CONVERT(nvarchar(30), l.RestoreDate, 120), N'?')
                         + N' by ' + ISNULL(l.RestoredBy, N'?') END,
               CASE WHEN l.DatabaseName IS NULL
                    THEN N'No restore of this target database appears in the captured msdb history - it may have been created rather than restored, or the history window is too short.'
                    WHEN l.SourceServerName IS NULL
                    THEN N'The restore is recorded but its origin server is unknown (the matching backupset row is missing from msdb) - provenance cannot be verified.'
                    WHEN l.SourceServerName = @SrcServer
                    THEN N'Restored from a backup taken on the compared source server.'
                         + CASE WHEN l.SourceDatabaseName <> t.DatabaseName
                                THEN N' NOTE: restored under a different name than the source database ''' + l.SourceDatabaseName + N'''.' ELSE N'' END
                    WHEN l.SourceServerName = @SrcMachine
                    THEN N'The backup records server name ''' + l.SourceServerName + N''', which is not the source''s SQL name ('
                         + @SrcServer + N') but IS its MACHINE name. backupset.server_name is captured at BACKUP time, so this is the normal signature of a renamed instance, a failover-cluster instance, or a backup taken on an Availability Group secondary - most likely correct, but confirm it.'
                    ELSE N'The most recent restore came from server ''' + ISNULL(l.SourceServerName, N'(unknown)')
                         + N''', which is NOT the compared source. The data may not be what this validation assumes. (backupset.server_name is recorded at backup time, so a renamed instance, an FCI, an AG SECONDARY that took the final backup, or a source -> staging -> target restore chain will also show a different name here - check those before assuming the wrong backup was used.)' END,
               CASE WHEN l.DatabaseName IS NULL THEN N'Confirm how this database reached the target.'
                    WHEN l.SourceServerName IS NULL THEN N'Confirm the backup this restore used came from the compared source server.'
                    WHEN l.SourceServerName = @SrcMachine THEN N'Confirm which host/replica took the final backup.'
                    WHEN l.SourceServerName <> @SrcServer THEN N'Verify the restore source; re-restore from the correct server if wrong.' END
        FROM #TgtDb AS t
        LEFT JOIN latest AS l ON l.DatabaseName = t.DatabaseName AND l.rn = 1
        WHERE t.DatabaseName <> DB_NAME()
          /* v2.4.2b: the clean PASS case is aggregated below.

             This was the ONLY multi-object rule in the file that emitted PASS
             per object - the other twelve all roll their passes into a single
             "N of N" summary with HAVING COUNT(*) > 0. On a 200-database
             estate it produced 200 identical green rows saying the restore
             came from the right server, which is exactly the fact a single
             line states better. Anything that is NOT a clean match - unknown
             origin, foreign server, machine-name match, no restore history,
             or a restore under a DIFFERENT database name - still gets its own
             row, because those need per-database attention. */
          AND NOT (l.DatabaseName IS NOT NULL
                   AND l.SourceServerName IS NOT NULL
                   AND l.SourceServerName = @SrcServer
                   AND ISNULL(l.SourceDatabaseName, N'') = t.DatabaseName);

        /* v2.4.2b: one row for every database whose provenance checked out. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation)
        SELECT N'RestoreValidation', N'Database', @TgtServer, N'RestoreProvenance',
               N'PASS', N'Informational',
               ISNULL(@SrcServer, N'?'),
               CONVERT(nvarchar(10), COUNT(*)) + N' database(s) verified',
               CONVERT(nvarchar(10), COUNT(*))
                 + N' target user database(s) were restored from backups taken on the compared source server ('
                 + ISNULL(@SrcServer, N'?') + N'), under the same database name. Provenance verified from the captured msdb restore history.'
        FROM #TgtDb AS t
        JOIN (SELECT re.DatabaseName, re.SourceServerName, re.SourceDatabaseName,
                     ROW_NUMBER() OVER (PARTITION BY re.DatabaseName
                                        ORDER BY re.RestoreDate DESC, re.RestoreHistoryId DESC) AS rn
              FROM migration.RestoreEvent AS re
              WHERE re.CaptureRunId = @TargetCaptureRunId) AS l
          ON l.DatabaseName = t.DatabaseName AND l.rn = 1
        WHERE t.DatabaseName <> DB_NAME()
          AND l.SourceServerName IS NOT NULL
          AND l.SourceServerName = @SrcServer
          AND ISNULL(l.SourceDatabaseName, N'') = t.DatabaseName
        HAVING COUNT(*) > 0;

        /* v2.3 (designed check, previously unimplemented): a user database
           restored BEFORE the source capture was taken means the source kept
           running after that backup - the server-level state validated here
           is NEWER than the migrated data. Same UTC-offset math and 60-minute
           tolerance as the sequencing check. */
        ;WITH latest2 AS (
            SELECT re.DatabaseName, re.RestoreDate,
                   ROW_NUMBER() OVER (PARTITION BY re.DatabaseName
                                      ORDER BY re.RestoreDate DESC, re.RestoreHistoryId DESC) AS rn
            FROM migration.RestoreEvent AS re
            WHERE re.CaptureRunId = @TargetCaptureRunId)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'RestoreValidation', N'Database', t.DatabaseName, N'RestoreOrdering',
               N'WARNING', N'Medium',
               N'source captured ' + CONVERT(nvarchar(30), @SrcDateUtc, 120) + N' UTC',
               N'restored ' + CONVERT(nvarchar(30), DATEADD(MINUTE, -@TgtUtcOffsetMin, l.RestoreDate), 120) + N' UTC (converted from target local time)',
               N'This database was restored BEFORE the source capture was taken (beyond the 60-minute tolerance). The source kept running after this backup, so the server-level state this validation certifies is newer than the migrated data.',
               N'Take a fresh final backup/restore of this database, or deliberately accept the gap and document it.'
        FROM #TgtDb AS t
        JOIN latest2 AS l ON l.DatabaseName = t.DatabaseName AND l.rn = 1
        WHERE t.DatabaseName <> DB_NAME()
          AND DATEADD(MINUTE, -@TgtUtcOffsetMin, l.RestoreDate) < DATEADD(MINUTE, -60, @SrcDateUtc);
    END

    /* ======================================================================
       Section: DatabaseHealth (target focus) + suspect pages + orphans
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DatabaseHealth')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'DatabaseHealth', N'ComparisonSection', N'DatabaseHealth', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The DatabaseHealth module failed on at least one side; health checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* v2.4: #HealthSkip is now TARGET-side only.

           It used to be built from #ItemErr with no Side predicate, so a
           SOURCE-side per-database failure suppressed findings that are read
           purely from the TARGET capture - LastGoodCheckDb, OrphanedSqlUsers
           (FAIL/High), OrphanedWindowsUsers and the per-user orphan detail.
           The source probe skips every non-ONLINE / non-MULTI_USER database
           by design, so this fired routinely and silently dropped genuine
           security findings about the target. Those checks need no source
           measurement at all; only UntrustedConstraints compares the two
           sides, and it already self-guards on s.DatabaseName IS NOT NULL.

           A source-side gap is still reported - as its own SKIPPED marker
           below - rather than silently narrowing the comparison. */
        SELECT ItemName INTO #HealthSkip
        FROM #ItemErr WHERE ModuleName = N'DatabaseHealth' AND Side = N'Target';

        /* databases measured on the target but NOT on the source: the
           target-only checks still run, but the source-vs-target regression
           check cannot. Say so per database instead of quietly not firing. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        SELECT DISTINCT N'DatabaseHealth', N'Database', ie.ItemName, N'HealthComparisonSkipped',
               N'SKIPPED', N'Low',
               N'The source-side health probe did not measure this database, so the source-vs-target constraint-trust comparison could not run. Target-only checks (CHECKDB age, orphaned users) DID run and are reported separately.',
               N'Re-capture the source with the database ONLINE and MULTI_USER if the comparison matters.'
        FROM #ItemErr AS ie
        WHERE ie.ModuleName = N'DatabaseHealth' AND ie.Side = N'Source'
          AND EXISTS (SELECT 1 FROM migration.DatabaseHealth AS t
                      WHERE t.CaptureRunId = @TargetCaptureRunId AND t.DatabaseName = ie.ItemName)
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND ie.ItemName LIKE x.NamePattern);

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'DatabaseHealth', N'Database', t.DatabaseName, v.CheckName, v.Status, v.Severity,
               v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM migration.DatabaseHealth AS t
        LEFT JOIN migration.DatabaseHealth AS s
          ON s.CaptureRunId = @SourceCaptureRunId AND s.DatabaseName = t.DatabaseName
        CROSS APPLY (VALUES
            /* v2.4, two fixes:
               (a) DATABASEPROPERTYEX('LastGoodCheckDbTime') returns the
                   server's LOCAL time, but this compared it against
                   SYSUTCDATETIME(). Every other time comparison in this file
                   normalises via the capture's recorded local/UTC offset;
                   this one did not. Immaterial at a 30-day window, wrong at 1.
               (b) "never ran" and "the engine cannot report it" are different
                   facts and the schema says so (DatabaseHealth.LastGoodCheckDbDate
                   is NULL for both). Reporting an engine limitation as "no
                   recent CHECKDB" is a false accusation, so NULL is now an
                   explicit MANUAL REVIEW that says it cannot tell. */
            (N'LastGoodCheckDb',
             CASE WHEN t.LastGoodCheckDbDate IS NULL THEN N'MANUAL REVIEW'
                  WHEN t.LastGoodCheckDbDate
                       < DATEADD(MINUTE, @TgtUtcOffsetMin, DATEADD(DAY, -@CheckDbDays, SYSUTCDATETIME()))
                  THEN N'WARNING' END,
             N'Medium',
             CASE WHEN s.DatabaseName IS NULL THEN N'(not measured)' ELSE ISNULL(CONVERT(nvarchar(30), s.LastGoodCheckDbDate, 120), N'never/unknown') END,
             ISNULL(CONVERT(nvarchar(30), t.LastGoodCheckDbDate, 120), N'never/unknown'),
             CASE WHEN t.LastGoodCheckDbDate IS NULL
                  THEN N'No successful DBCC CHECKDB is recorded for this database on the target - either one has never run, or the engine cannot report it (both appear as no value). This cannot be distinguished from the captured data.'
                  ELSE N'The target database has no recent successful DBCC CHECKDB. Run one before cutover - a restore faithfully copies corruption too.' END,
             N'Run DBCC CHECKDB (PHYSICAL_ONLY at minimum) on the target in a maintenance window.'),
            (N'OrphanedSqlUsers',
             CASE WHEN ISNULL(t.OrphanedSqlUserCount, 0) > 0 THEN N'FAIL' END,
             N'High',
             CASE WHEN s.DatabaseName IS NULL THEN N'(not measured)' ELSE CONVERT(nvarchar(10), ISNULL(s.OrphanedSqlUserCount, 0)) END,
             CONVERT(nvarchar(10), t.OrphanedSqlUserCount),
             N'SQL-login database users on the target have no matching server login SID - they cannot authenticate.',
             N'Recreate the logins WITH SID from the source, or run ALTER USER ... WITH LOGIN to remap.'),
            (N'OrphanedWindowsUsers',
             CASE WHEN ISNULL(t.OrphanedWindowsUserCount, 0) > 0 THEN N'WARNING' END,
             N'Medium',
             CASE WHEN s.DatabaseName IS NULL THEN N'(not measured)' ELSE CONVERT(nvarchar(10), ISNULL(s.OrphanedWindowsUserCount, 0)) END,
             CONVERT(nvarchar(10), t.OrphanedWindowsUserCount),
             N'Windows users/groups in the target database have no matching server principal. They MAY still authenticate via group membership - with a domain change (lift-and-shift) verify each one.',
             N'Create the logins on the target (new domain accounts where applicable) or confirm group-based access works.'),
            (N'UntrustedConstraints',
             CASE WHEN s.DatabaseName IS NOT NULL
                       AND (ISNULL(t.UntrustedForeignKeyCount, 0) > ISNULL(s.UntrustedForeignKeyCount, 0)
                         OR ISNULL(t.UntrustedCheckConstraintCount, 0) > ISNULL(s.UntrustedCheckConstraintCount, 0))
                  THEN N'WARNING' END,
             N'Low',
             N'FK=' + CONVERT(nvarchar(10), ISNULL(s.UntrustedForeignKeyCount, 0)) + N' CK=' + CONVERT(nvarchar(10), ISNULL(s.UntrustedCheckConstraintCount, 0)),
             N'FK=' + CONVERT(nvarchar(10), ISNULL(t.UntrustedForeignKeyCount, 0)) + N' CK=' + CONVERT(nvarchar(10), ISNULL(t.UntrustedCheckConstraintCount, 0)),
             N'More untrusted constraints on the target than the source - constraints may have been disabled during migration activities.',
             N'ALTER TABLE ... WITH CHECK CHECK CONSTRAINT to revalidate.')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE t.CaptureRunId = @TargetCaptureRunId
          AND v.Status IS NOT NULL
          AND NOT EXISTS (SELECT 1 FROM #HealthSkip AS hs WHERE hs.ItemName = t.DatabaseName)
          -- an excluded database is excluded from its health findings too
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND t.DatabaseName LIKE x.NamePattern);

        /* orphan detail rows (names) for the report */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         TargetValue, Explanation, RecommendedAction)
        SELECT N'DatabaseHealth', N'DatabaseUser', o.DatabaseName, o.UserName, N'OrphanedUserDetail',
               CASE WHEN o.AuthDesc = N'INSTANCE' THEN N'FAIL' ELSE N'WARNING' END,
               CASE WHEN o.AuthDesc = N'INSTANCE' THEN N'High' ELSE N'Medium' END,
               o.TypeDesc + N' / ' + o.AuthDesc,
               CASE WHEN o.AuthDesc = N'INSTANCE'
                    THEN N'Orphaned SQL user: no server login with this SID exists on the target.'
                    ELSE N'Windows user/group with no matching server principal on the target - verify access (domain change).' END,
               CASE WHEN o.AuthDesc = N'INSTANCE'
                    THEN N'CREATE LOGIN ... WITH SID = <source sid> or ALTER USER ' + QUOTENAME(o.UserName) + N' WITH LOGIN = ...'
                    ELSE N'Create the corresponding login or confirm group-based access.' END
        FROM migration.OrphanedUser AS o
        WHERE o.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #HealthSkip AS hs WHERE hs.ItemName = o.DatabaseName)
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND o.DatabaseName LIKE x.NamePattern);

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'DatabaseHealth', N'Database', @TgtServer, N'HealthyDatabases', N'PASS', N'Informational',
               /* v2.4.1: say what was actually tested. The predicate below
                  looks ONLY at the two orphan counts - it never examines
                  LastGoodCheckDbDate or the untrusted-constraint counts, both
                  of which have their own WARNING rules in this same section.
                  A database could appear in this "no health regressions" total
                  and in an UntrustedConstraints warning simultaneously. */
               CONVERT(nvarchar(10), COUNT(*)) + N' target databases have no orphaned users. (CHECKDB age and constraint trust are reported separately.)'
        FROM migration.DatabaseHealth AS t
        WHERE t.CaptureRunId = @TargetCaptureRunId
          AND ISNULL(t.OrphanedSqlUserCount, 0) = 0 AND ISNULL(t.OrphanedWindowsUserCount, 0) = 0
          AND NOT EXISTS (SELECT 1 FROM #HealthSkip AS hs WHERE hs.ItemName = t.DatabaseName)
          /* v2.4: apply the SAME Database exclusions the health rules above use.
             Without this the "N databases are healthy" count included databases
             the operator had excluded from the comparison entirely, so the pass
             total did not reconcile with what was actually checked. */
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND t.DatabaseName LIKE x.NamePattern)
        HAVING COUNT(*) > 0;
    END

    /* suspect pages are their own module (msdb rights) */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'SuspectPages')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'DatabaseHealth', N'ComparisonSection', N'SuspectPages', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The SuspectPages module failed on at least one side; suspect-page checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'DatabaseHealth', N'Database', sp.DatabaseName, N'SuspectPages',
               N'FAIL', N'Critical', 1,
               CASE WHEN sp.CaptureRunId = @SourceCaptureRunId THEN CONVERT(nvarchar(10), sp.PageCount) + N' page(s)' END,
               CASE WHEN sp.CaptureRunId = @TargetCaptureRunId THEN CONVERT(nvarchar(10), sp.PageCount) + N' page(s)' END,
               N'msdb.dbo.suspect_pages reports unresolved damaged pages for this database on the '
                 + CASE WHEN sp.CaptureRunId = @SourceCaptureRunId THEN N'SOURCE (the corruption restores along with the data!)' ELSE N'TARGET' END + N'.',
               N'Run DBCC CHECKDB and repair/restore before cutover.'
        FROM migration.SuspectPage AS sp
        WHERE sp.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND sp.DatabaseName LIKE x.NamePattern);

    /* ======================================================================
       Section: Logins
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Logins')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Logins', N'ComparisonSection', N'Logins', N'SectionSkipped', N'SKIPPED', N'High',
                N'The Logins module failed on at least one side; login checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        SELECT l.* INTO #SrcLogin
        FROM migration.LoginInfo AS l
        WHERE l.CaptureRunId = @SourceCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                            AND l.LoginName LIKE x.NamePattern);
        SELECT l.* INTO #TgtLogin
        FROM migration.LoginInfo AS l
        WHERE l.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                            AND l.LoginName LIKE x.NamePattern);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(DISTINCT l.LoginName) FROM migration.LoginInfo AS l
               WHERE l.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                 AND l.LoginName LIKE x.NamePattern)
        FROM #Exception AS x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude';
        /* v2.3: per-object trace of every excluded login - user-added
           exceptions only (see Databases note) */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, ExceptionId)
        SELECT DISTINCT N'Logins', N'Login', LEFT(l.LoginName, 400), N'ExcludedByException',
               N'EXPECTED DIFFERENCE', N'Informational',
               LEFT(N'Excluded from ALL login comparisons by rule exception ('
                    + x.NamePattern + N'): ' + x.Reason, 2000),
               x.ExceptionId
        FROM migration.LoginInfo AS l
        JOIN #Exception AS x ON x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                            AND l.LoginName LIKE x.NamePattern
        WHERE l.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                      WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId)
        /* v2.4.2b: a MACHINE-LOCAL principal cannot exist on the target under
           the same name, by definition.

           SRCHOST\SQLAdmins and SRCHOST\svc_backup are local-machine SIDs. On
           TGTHOST the equivalent principals are necessarily named TGTHOST\...,
           so a perfectly executed migration produced one FAIL/High/BLOCKER per
           such login and a NOT READY verdict citing them as "cutover
           blocker(s)". The installer already seeds exactly this reasoning for
           NT SERVICE\% and NT AUTHORITY\% - "Machine-local principals differ
           per server by nature" - but a static seed cannot name the source's
           machine, so this case was left to fail. CaptureRun.MachineName is
           captured on both sides and already used by RestoreProvenance, so the
           information to classify it correctly was present and unused.

           Still reported, so nobody loses track of the remapping work - just
           as EXPECTED DIFFERENCE rather than a blocker. A domain account
           (CORP\svc) is untouched by this and still FAILs when missing. */
        SELECT N'Logins', N'Login', s.LoginName, N'Existence',
               CASE WHEN x.ExceptionId IS NOT NULL THEN N'EXPECTED DIFFERENCE'
                    WHEN s.LoginName LIKE @SrcMachinePrefix THEN N'EXPECTED DIFFERENCE'
                    ELSE N'FAIL' END,
               CASE WHEN x.ExceptionId IS NOT NULL THEN N'Informational'
                    WHEN s.LoginName LIKE @SrcMachinePrefix THEN N'Low'
                    ELSE N'High' END,
               /* NULL-safe: @SrcMachinePrefix is NULL when the source capture
                  recorded no MachineName (pre-2.0 captures, and any synthetic
                  pair). `NOT LIKE NULL` is UNKNOWN, not TRUE, so writing this
                  as `AND s.LoginName NOT LIKE @SrcMachinePrefix` silently made
                  IsBlocker 0 for EVERY missing login - turning genuine cutover
                  blockers into ordinary failures. Wrapping the LIKE in its own
                  CASE collapses UNKNOWN to "not machine-local", which is the
                  safe direction: unknown means still a blocker. */
               CASE WHEN x.ExceptionId IS NULL
                         AND (CASE WHEN s.LoginName LIKE @SrcMachinePrefix THEN 1 ELSE 0 END) = 0
                    THEN 1 ELSE 0 END,
               s.TypeDesc, NULL,
               CASE WHEN x.ExceptionId IS NOT NULL
                    THEN N'Login intentionally absent on the target per rule exception: ' + x.Reason
                    WHEN s.LoginName LIKE @SrcMachinePrefix
                    THEN N'This is a MACHINE-LOCAL principal of the source host (' + ISNULL(@SrcMachine, N'?')
                       + N'). It cannot exist on the target under the same name - the equivalent account there is named after the target machine - so its absence is expected, not a defect. It is listed so the remapping is not forgotten.'
                    ELSE N'Login exists on the source but not the target - applications and jobs using it cannot authenticate after cutover.' END,
               CASE WHEN x.ExceptionId IS NOT NULL THEN NULL
                    WHEN s.LoginName LIKE @SrcMachinePrefix
                    THEN N'Create the equivalent local principal on the target host and grant it the same server roles/permissions.'
                    WHEN s.TypeDesc = N'SQL_LOGIN'
                    THEN N'Recreate WITH SID (sp_help_revlogin-style script) so restored users bind automatically.'
                    ELSE N'Create the Windows login (map to the new domain account if the domain changed).' END,
               x.ExceptionId
        FROM #SrcLogin AS s
        OUTER APPLY (SELECT TOP (1) e.ExceptionId, e.Reason FROM #Exception AS e
                     WHERE e.Scope = N'Login' AND e.TreatAs = N'Expected'
                       AND s.LoginName LIKE e.NamePattern
                     ORDER BY e.ExceptionId) AS x
        WHERE NOT EXISTS (SELECT 1 FROM #TgtLogin AS t WHERE t.LoginName = s.LoginName);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(*) FROM #Finding f
               WHERE f.ExceptionId = x.ExceptionId AND f.Category = N'Logins' AND f.CheckName = N'Existence')
        FROM #Exception AS x WHERE x.TreatAs = N'Expected' AND x.Scope = N'Login';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         TargetValue, Explanation)
        SELECT N'Logins', N'Login', t.LoginName, N'Existence', N'TARGET ONLY', N'Low',
               t.TypeDesc,
               N'Login exists only on the target.'
        FROM #TgtLogin AS t
        WHERE NOT EXISTS (SELECT 1 FROM #SrcLogin AS s WHERE s.LoginName = t.LoginName);

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Logins', N'Login', s.LoginName, v.CheckName, v.Status, v.Severity,
               v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM #SrcLogin AS s
        JOIN #TgtLogin AS t ON t.LoginName = s.LoginName
        CROSS APPLY (VALUES
            (N'LoginType',
             CASE WHEN ISNULL(s.TypeDesc, N'') <> ISNULL(t.TypeDesc, N'') THEN N'FAIL' END,
             N'High', s.TypeDesc, t.TypeDesc,
             N'The same login name has a different principal type on the target.',
             N'Recreate the login with the correct type.'),
            (N'LoginSid',
             /* v2.4: NULL-safe. "s.Sid <> t.Sid" is UNKNOWN when either side is
                NULL (a permission-restricted capture, or a login type without
                a SID), so the SID check silently PASSED - the one place this
                file abandoned its own ISNULL convention. A missing SID is now
                itself a difference worth reporting. */
             CASE WHEN s.TypeDesc = N'SQL_LOGIN' AND t.TypeDesc = N'SQL_LOGIN'
                       AND ISNULL(s.Sid, 0x) <> ISNULL(t.Sid, 0x) THEN N'WARNING' END,
             N'High',
             CONVERT(nvarchar(200), s.Sid, 1), CONVERT(nvarchar(200), t.Sid, 1),
             N'The SQL login exists on the target with a DIFFERENT SID. Restored database users mapped by SID are orphaned from it.',
             N'Drop and recreate WITH SID from the source, or ALTER USER ... WITH LOGIN in each database.'),
            /* v2.4.2b: directional, same omission as Trustworthy above. */
            (N'Disabled',
             CASE WHEN ISNULL(s.IsDisabled, 0) <> ISNULL(t.IsDisabled, 0) THEN N'WARNING' END,
             N'Medium', CONVERT(nvarchar(5), s.IsDisabled), CONVERT(nvarchar(5), t.IsDisabled),
             CASE WHEN ISNULL(t.IsDisabled, 0) = 1
                  THEN N'This login is ENABLED on the source and DISABLED on the target - it cannot connect at cutover, so anything authenticating with it fails.'
                  ELSE N'This login is DISABLED on the source and ENABLED on the target. The migration re-activated an account the source had deliberately switched off.' END,
             CASE WHEN ISNULL(t.IsDisabled, 0) = 1
                  THEN N'ALTER LOGIN ... ENABLE before cutover.'
                  ELSE N'Confirm the account is meant to be live; otherwise ALTER LOGIN ... DISABLE.' END),
            (N'DefaultDatabase',
             CASE WHEN ISNULL(s.DefaultDatabase, N'') <> ISNULL(t.DefaultDatabase, N'') THEN N'WARNING' END,
             N'Low', s.DefaultDatabase, t.DefaultDatabase,
             N'Default database differs; logins fail when their default database is missing/offline.',
             N'ALTER LOGIN ... WITH DEFAULT_DATABASE.'),
            (N'DefaultLanguage',
             CASE WHEN ISNULL(s.DefaultLanguage, N'') <> ISNULL(t.DefaultLanguage, N'') THEN N'WARNING' END,
             N'Low', s.DefaultLanguage, t.DefaultLanguage,
             N'Default language differs (date parsing behavior can change).', NULL),
            (N'PasswordPolicy',
             CASE WHEN s.TypeDesc = N'SQL_LOGIN' AND t.TypeDesc = N'SQL_LOGIN'
                       AND (ISNULL(s.IsPolicyChecked, 0) <> ISNULL(t.IsPolicyChecked, 0)
                         OR ISNULL(s.IsExpirationChecked, 0) <> ISNULL(t.IsExpirationChecked, 0)) THEN N'WARNING' END,
             N'Low',
             N'policy=' + CONVERT(nvarchar(5), ISNULL(s.IsPolicyChecked, 0)) + N' expiration=' + CONVERT(nvarchar(5), ISNULL(s.IsExpirationChecked, 0)),
             N'policy=' + CONVERT(nvarchar(5), ISNULL(t.IsPolicyChecked, 0)) + N' expiration=' + CONVERT(nvarchar(5), ISNULL(t.IsExpirationChecked, 0)),
             N'Password policy enforcement differs.', NULL)
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Logins', N'Login', @TgtServer, N'LoginsPresent', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' source logins are present on the target.'
        FROM #SrcLogin AS s
        WHERE EXISTS (SELECT 1 FROM #TgtLogin AS t WHERE t.LoginName = s.LoginName)
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: ServerSecurity - roles, memberships, grants
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'ServerSecurity')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'ServerSecurity', N'ComparisonSection', N'ServerSecurity', N'SectionSkipped', N'SKIPPED', N'High',
                N'The ServerSecurity module failed on at least one side; role and permission checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* user-defined server roles */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ServerSecurity', N'ServerRole', ISNULL(s.RoleName, t.RoleName), N'RoleExistence',
               CASE WHEN t.RoleName IS NULL THEN N'FAIL' ELSE N'TARGET ONLY' END,
               CASE WHEN t.RoleName IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN s.RoleName IS NULL THEN NULL ELSE N'user-defined role' END,
               CASE WHEN t.RoleName IS NULL THEN NULL ELSE N'user-defined role' END,
               CASE WHEN t.RoleName IS NULL
                    THEN N'User-defined server role missing on the target; its permission grants are lost.'
                    ELSE N'User-defined server role exists only on the target.' END,
               CASE WHEN t.RoleName IS NULL THEN N'Recreate the role and its grants on the target.' END
        FROM (SELECT RoleName FROM migration.ServerRoleInfo WHERE CaptureRunId = @SourceCaptureRunId AND IsFixedRole = 0 AND RoleName <> N'public') AS s
        FULL OUTER JOIN
             (SELECT RoleName FROM migration.ServerRoleInfo WHERE CaptureRunId = @TargetCaptureRunId AND IsFixedRole = 0 AND RoleName <> N'public') AS t
          ON t.RoleName = s.RoleName
        WHERE s.RoleName IS NULL OR t.RoleName IS NULL;

        /* memberships - members covered by Login exclusions stay out.
           v2.3: memberships of a role that is itself missing on one side are
           suppressed - the single RoleExistence FAIL covers them; N per-member
           High warnings for one missing role were duplicate noise. */
        ;WITH s AS (SELECT RoleName, MemberName FROM migration.ServerRoleMember
                    WHERE CaptureRunId = @SourceCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND MemberName LIKE x.NamePattern)
                      AND EXISTS (SELECT 1 FROM migration.ServerRoleInfo r
                                  WHERE r.CaptureRunId = @TargetCaptureRunId AND r.RoleName = ServerRoleMember.RoleName)),
              t AS (SELECT RoleName, MemberName FROM migration.ServerRoleMember
                    WHERE CaptureRunId = @TargetCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND MemberName LIKE x.NamePattern)
                      AND EXISTS (SELECT 1 FROM migration.ServerRoleInfo r
                                  WHERE r.CaptureRunId = @SourceCaptureRunId AND r.RoleName = ServerRoleMember.RoleName))
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ServerSecurity', N'RoleMembership', ISNULL(s.RoleName, t.RoleName),
               ISNULL(s.MemberName, t.MemberName), N'RoleMembership',
               /* v2.3: an extra membership on the target is TARGET ONLY, not a
                  second flavor of WARNING */
               CASE WHEN t.RoleName IS NULL THEN N'WARNING' ELSE N'TARGET ONLY' END,
               CASE WHEN t.RoleName IS NULL THEN N'High' ELSE N'Medium' END,
               CASE WHEN s.RoleName IS NULL THEN NULL ELSE N'member' END,
               CASE WHEN t.RoleName IS NULL THEN NULL ELSE N'member' END,
               CASE WHEN t.RoleName IS NULL
                    THEN N'Role membership exists on the source but not the target; the principal loses these rights at cutover.'
                    ELSE N'Role membership exists only on the target - an EXTRA privilege the source never had.' END,
               CASE WHEN t.RoleName IS NULL THEN N'ALTER SERVER ROLE ... ADD MEMBER on the target.'
                    ELSE N'Verify the extra membership is intentional.' END
        FROM s FULL OUTER JOIN t ON t.RoleName = s.RoleName AND t.MemberName = s.MemberName
        WHERE s.RoleName IS NULL OR t.RoleName IS NULL;

        /* explicit server permissions */
        ;WITH s AS (SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
                    FROM migration.ServerPermission
                    WHERE CaptureRunId = @SourceCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND GranteeName LIKE x.NamePattern)),
              t AS (SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
                    FROM migration.ServerPermission
                    WHERE CaptureRunId = @TargetCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND GranteeName LIKE x.NamePattern))
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ServerSecurity', N'ServerPermission', ISNULL(s.GranteeName, t.GranteeName),
               ISNULL(s.PermissionName, t.PermissionName)
                 + CASE WHEN ISNULL(s.MajorObjectName, t.MajorObjectName) <> N''
                        THEN N' ON ' + ISNULL(s.MajorObjectName, t.MajorObjectName) ELSE N'' END,
               N'ServerPermission',
               /* v2.3: extra permission on the target is TARGET ONLY */
               CASE WHEN t.GranteeName IS NULL THEN N'WARNING' ELSE N'TARGET ONLY' END,
               CASE WHEN t.GranteeName IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN s.GranteeName IS NULL THEN NULL ELSE s.StateDesc END,
               CASE WHEN t.GranteeName IS NULL THEN NULL ELSE t.StateDesc END,
               CASE WHEN t.GranteeName IS NULL
                    THEN N'Explicit server permission exists on the source but not the target.'
                    ELSE N'Explicit server permission exists only on the target.' END,
               CASE WHEN t.GranteeName IS NULL THEN N'GRANT the permission on the target.'
                    ELSE N'Verify the extra permission is intentional.' END
        /* v2.4: StateDesc is NO LONGER part of the join key - see the
           PermissionState rule below for why. */
        FROM s FULL OUTER JOIN t
          ON  t.GranteeName = s.GranteeName AND t.ClassDesc = s.ClassDesc
          AND t.PermissionName = s.PermissionName
          AND t.MajorObjectName = s.MajorObjectName
        WHERE s.GranteeName IS NULL OR t.GranteeName IS NULL;

        /* v2.4: a permission whose STATE changed.

           StateDesc used to be part of the join key, so a permission that was
           GRANT on the source and DENY on the target matched nothing on either
           side and came out as TWO unrelated rows - one "exists on the source
           but not the target" WARNING and one "exists only on the target"
           TARGET ONLY/Low. Nothing said the state had CHANGED, and the most
           dangerous direction (a DENY on the source silently becoming a GRANT
           on the target - the principal now HAS access it was explicitly
           denied) was reported at Low severity as an extra permission.

           Now the identity is grantee + class + permission + object, and the
           state is a compared attribute with a direction-aware severity. */
        ;WITH s AS (SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
                    FROM migration.ServerPermission
                    WHERE CaptureRunId = @SourceCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND GranteeName LIKE x.NamePattern)),
              t AS (SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
                    FROM migration.ServerPermission
                    WHERE CaptureRunId = @TargetCaptureRunId
                      AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                        AND GranteeName LIKE x.NamePattern))
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ServerSecurity', N'ServerPermission', s.GranteeName,
               s.PermissionName + CASE WHEN s.MajorObjectName <> N'' THEN N' ON ' + s.MajorObjectName ELSE N'' END,
               N'PermissionState',
               N'FAIL',
               /* DENY -> anything else is a privilege ESCALATION on the target */
               CASE WHEN s.StateDesc LIKE N'DENY%' THEN N'High' ELSE N'Medium' END,
               s.StateDesc, t.StateDesc,
               CASE WHEN s.StateDesc LIKE N'DENY%'
                    THEN N'This permission is DENIED on the source but ' + t.StateDesc
                       + N' on the target - the principal now HAS access that was explicitly denied before the migration. This is a privilege escalation, not a missing grant.'
                    ELSE N'The permission exists on both sides but in a different state (' + s.StateDesc
                       + N' on the source, ' + t.StateDesc + N' on the target).' END,
               N'Reapply the source state on the target: ' + s.StateDesc + N' ' + s.PermissionName
                 + CASE WHEN s.MajorObjectName <> N'' THEN N' ON ' + s.MajorObjectName ELSE N'' END
                 + N' TO ' + QUOTENAME(s.GranteeName) + N'.'
        FROM s
        JOIN t ON  t.GranteeName = s.GranteeName AND t.ClassDesc = s.ClassDesc
               AND t.PermissionName = s.PermissionName
               AND t.MajorObjectName = s.MajorObjectName
        WHERE s.StateDesc <> t.StateDesc;

        /* v2.4: the pass total now applies the SAME Login exclusions as the
           difference rules above. It used to count NT SERVICE\%, NT AUTHORITY\%
           and ##MS_% principals that were deliberately excluded from the
           comparison, so the "N match" figure did not reconcile with what was
           actually compared. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'ServerSecurity', N'ServerPermission', @TgtServer, N'MatchingSecurity', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' role memberships and permissions match.'
        FROM (SELECT RoleName AS a, MemberName AS b, N'' AS c, N'' AS d, N'' AS e
              FROM migration.ServerRoleMember AS rm WHERE CaptureRunId = @SourceCaptureRunId
                AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                  AND rm.MemberName LIKE x.NamePattern)
              UNION ALL
              SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
              FROM migration.ServerPermission AS sp WHERE CaptureRunId = @SourceCaptureRunId
                AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'Login' AND x.TreatAs = N'Exclude'
                                  AND sp.GranteeName LIKE x.NamePattern)) AS s
        WHERE EXISTS (SELECT 1 FROM
              (SELECT RoleName AS a, MemberName AS b, N'' AS c, N'' AS d, N'' AS e
               FROM migration.ServerRoleMember WHERE CaptureRunId = @TargetCaptureRunId
               UNION ALL
               SELECT GranteeName, ClassDesc, PermissionName, StateDesc, MajorObjectName
               FROM migration.ServerPermission WHERE CaptureRunId = @TargetCaptureRunId) AS t
              WHERE t.a = s.a AND t.b = s.b AND t.c = s.c AND t.d = s.d AND t.e = s.e)
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: Agent - jobs, steps, schedules, operators, alerts,
       credentials, proxies
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Agent')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Agent', N'ComparisonSection', N'Agent', N'SectionSkipped', N'SKIPPED', N'High',
                N'The Agent module failed on at least one side; job/operator/alert checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        SELECT j.* INTO #SrcJob
        FROM migration.AgentJob AS j
        WHERE j.CaptureRunId = @SourceCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'AgentJob' AND x.TreatAs = N'Exclude'
                            AND j.JobName LIKE x.NamePattern);
        SELECT j.* INTO #TgtJob
        FROM migration.AgentJob AS j
        WHERE j.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'AgentJob' AND x.TreatAs = N'Exclude'
                            AND j.JobName LIKE x.NamePattern);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(DISTINCT j.JobName) FROM migration.AgentJob AS j
               WHERE j.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                 AND j.JobName LIKE x.NamePattern)
        FROM #Exception AS x WHERE x.Scope = N'AgentJob' AND x.TreatAs = N'Exclude';
        /* v2.3: per-object trace of every excluded job - user-added
           exceptions only (see Databases note) */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, ExceptionId)
        SELECT DISTINCT N'Agent', N'AgentJob', LEFT(j.JobName, 400), N'ExcludedByException',
               N'EXPECTED DIFFERENCE', N'Informational',
               LEFT(N'Excluded from ALL Agent job comparisons by rule exception ('
                    + x.NamePattern + N'): ' + x.Reason, 2000),
               x.ExceptionId
        FROM migration.AgentJob AS j
        JOIN #Exception AS x ON x.Scope = N'AgentJob' AND x.TreatAs = N'Exclude'
                            AND j.JobName LIKE x.NamePattern
        WHERE j.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                      WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, IsBlocker,
                         SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId)
        SELECT N'Agent', N'AgentJob', s.JobName, N'Existence',
               CASE WHEN x.ExceptionId IS NOT NULL THEN N'EXPECTED DIFFERENCE'
                    WHEN s.IsEnabled = 1 THEN N'FAIL' ELSE N'WARNING' END,
               CASE WHEN x.ExceptionId IS NOT NULL THEN N'Informational'
                    WHEN s.IsEnabled = 1 THEN N'High' ELSE N'Medium' END,
               CASE WHEN x.ExceptionId IS NULL AND s.IsEnabled = 1 THEN 1 ELSE 0 END,
               CASE WHEN s.IsEnabled = 1 THEN N'enabled' ELSE N'disabled' END, NULL,
               CASE WHEN x.ExceptionId IS NOT NULL
                    THEN N'Job intentionally absent on the target per rule exception: ' + x.Reason
                    WHEN s.IsEnabled = 1
                    THEN N'ENABLED source job is missing on the target - scheduled work stops at cutover.'
                    ELSE N'Disabled source job is missing on the target.' END,
               CASE WHEN x.ExceptionId IS NULL THEN N'Script the job from the source (or the exported job XML) and create it on the target.' END,
               x.ExceptionId
        FROM #SrcJob AS s
        OUTER APPLY (SELECT TOP (1) e.ExceptionId, e.Reason FROM #Exception AS e
                     WHERE e.Scope = N'AgentJob' AND e.TreatAs = N'Expected'
                       AND s.JobName LIKE e.NamePattern
                     ORDER BY e.ExceptionId) AS x
        WHERE NOT EXISTS (SELECT 1 FROM #TgtJob AS t WHERE t.JobName = s.JobName);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(*) FROM #Finding f
               WHERE f.ExceptionId = x.ExceptionId AND f.Category = N'Agent' AND f.CheckName = N'Existence')
        FROM #Exception AS x WHERE x.TreatAs = N'Expected' AND x.Scope = N'AgentJob';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, TargetValue, Explanation)
        SELECT N'Agent', N'AgentJob', t.JobName, N'Existence', N'TARGET ONLY', N'Low',
               CASE WHEN t.IsEnabled = 1 THEN N'enabled' ELSE N'disabled' END,
               N'Job exists only on the target.'
        FROM #TgtJob AS t
        WHERE NOT EXISTS (SELECT 1 FROM #SrcJob AS s WHERE s.JobName = t.JobName);

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'AgentJob', s.JobName, v.CheckName, v.Status, v.Severity,
               v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM #SrcJob AS s
        JOIN #TgtJob AS t ON t.JobName = s.JobName
        CROSS APPLY (VALUES
            /* v2.4.2b: only the SURPRISING direction stays per job.
               "Enabled on the source, disabled on the target" is the standard
               pre-cutover posture - the rule's own text said so - and it fired
               once per job at High: 40 jobs produced 40 High warnings, making
               a deliberate runbook step look like the largest problem in the
               report. That direction is aggregated below. A job ENABLED on the
               target that was disabled on the source is the unexpected case
               (it will start running work the source was not running) and
               keeps its own row. */
            (N'JobEnabled',
             CASE WHEN s.IsEnabled = 0 AND t.IsEnabled = 1 THEN N'WARNING' END, N'Medium',
             N'disabled', N'enabled',
             N'This job is DISABLED on the source but ENABLED on the target - it will start running work the source was not running.',
             N'Confirm the job is meant to be live on the target.'),
            (N'JobOwner',
             CASE WHEN ISNULL(s.OwnerName, N'') <> ISNULL(t.OwnerName, N'') THEN N'WARNING' END, N'Low',
             s.OwnerName, t.OwnerName,
             N'Job owner differs; ownership affects execution context for non-sysadmin owners.', NULL),
            /* job CATEGORY deliberately not compared - purely cosmetic. */
            (N'JobNotification',
             CASE WHEN ISNULL(s.NotifyOperatorName, N'') <> ISNULL(t.NotifyOperatorName, N'')
                    OR ISNULL(s.NotifyLevelEmail, 0) <> ISNULL(t.NotifyLevelEmail, 0) THEN N'WARNING' END, N'Medium',
             ISNULL(s.NotifyOperatorName, N'(none)') + N' level=' + CONVERT(nvarchar(5), ISNULL(s.NotifyLevelEmail, 0)),
             ISNULL(t.NotifyOperatorName, N'(none)') + N' level=' + CONVERT(nvarchar(5), ISNULL(t.NotifyLevelEmail, 0)),
             N'Job failure-notification configuration differs; failures may go unnoticed on the target.',
             N'Align the notify operator and level.'),
            (N'JobStepCount',
             CASE WHEN s.StepCount <> t.StepCount THEN N'FAIL' END, N'Medium',
             CONVERT(nvarchar(10), s.StepCount), CONVERT(nvarchar(10), t.StepCount),
             N'The job has a different number of steps on the target - it is not the same job definition.',
             N'Re-script the job from the source.'),
            (N'JobScheduleCount',
             CASE WHEN s.ScheduleCount <> t.ScheduleCount THEN N'WARNING' END, N'Medium',
             CONVERT(nvarchar(10), s.ScheduleCount), CONVERT(nvarchar(10), t.ScheduleCount),
             N'The job has a different number of schedules on the target.',
             N'Attach the missing schedule(s).')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        /* v2.4.2b: the standard pre-cutover posture, as ONE runbook item. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'AgentJob', @TgtServer, N'JobsDisabledOnTarget', N'WARNING', N'High',
               N'enabled', CONVERT(nvarchar(10), COUNT(*)) + N' job(s) disabled',
               LEFT(CONVERT(nvarchar(10), COUNT(*))
                 + N' job(s) are ENABLED on the source and DISABLED on the target. Leaving them disabled until cutover is the normal, deliberate posture - but they will not run until someone enables them, so this belongs in the cutover runbook as a single step. Jobs: '
                 + ISNULL(STUFF((SELECT N', ' + s2.JobName
                                 FROM #SrcJob s2 JOIN #TgtJob t2 ON t2.JobName = s2.JobName
                                 WHERE s2.IsEnabled = 1 AND t2.IsEnabled = 0
                                 ORDER BY s2.JobName
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1900)
                 + N'.',
               N'Enable these jobs AT cutover (sp_update_job @enabled = 1), as one runbook step.'
        FROM #SrcJob AS s JOIN #TgtJob AS t ON t.JobName = s.JobName
        WHERE s.IsEnabled = 1 AND t.IsEnabled = 0
        HAVING COUNT(*) > 0;

        /* steps of jobs present on both sides */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'AgentJobStep', ISNULL(ss.JobName, ts.JobName),
               N'step ' + CONVERT(nvarchar(10), ISNULL(ss.StepId, ts.StepId)) + N': ' + ISNULL(ss.StepName, ts.StepName),
               v.CheckName, v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM (SELECT st.* FROM migration.AgentJobStep AS st
              WHERE st.CaptureRunId = @SourceCaptureRunId
                AND EXISTS (SELECT 1 FROM #SrcJob j WHERE j.JobName = st.JobName)
                AND EXISTS (SELECT 1 FROM #TgtJob j WHERE j.JobName = st.JobName)) AS ss
        FULL OUTER JOIN
             (SELECT st.* FROM migration.AgentJobStep AS st
              WHERE st.CaptureRunId = @TargetCaptureRunId
                AND EXISTS (SELECT 1 FROM #SrcJob j WHERE j.JobName = st.JobName)
                AND EXISTS (SELECT 1 FROM #TgtJob j WHERE j.JobName = st.JobName)) AS ts
          /* v2.4: steps are matched by NAME, not by position.
             msdb enforces a unique step name per job, so StepName is a stable
             key - whereas StepId is an ordinal. Matching on StepId meant that
             inserting one step at position 2 on the target shifted every later
             step by one, producing a cascade of false StepCommand/StepContext/
             StepFlow warnings plus a spurious StepPresence FAIL for the last
             step, all describing steps that were actually identical. Position
             changes are still reported - by the StepOrder rule below. */
          ON ts.JobName = ss.JobName AND ts.StepName = ss.StepName
        CROSS APPLY (VALUES
            (N'StepPresence',
             CASE WHEN ss.JobName IS NULL THEN N'TARGET ONLY'
                  WHEN ts.JobName IS NULL THEN N'FAIL' END,
             N'Medium',
             CASE WHEN ss.JobName IS NULL THEN NULL ELSE ss.SubsystemDesc END,
             CASE WHEN ts.JobName IS NULL THEN NULL ELSE ts.SubsystemDesc END,
             N'This job step exists on only one side.',
             N'Re-script the job so the step sets match.'),
            (N'StepOrder',
             CASE WHEN ss.JobName IS NOT NULL AND ts.JobName IS NOT NULL
                       AND ss.StepId <> ts.StepId THEN N'WARNING' END,
             N'Medium',
             N'step ' + CONVERT(nvarchar(10), ss.StepId),
             N'step ' + CONVERT(nvarchar(10), ts.StepId),
             N'The step exists on both sides but at a DIFFERENT position in the job. Execution order and on-success/on-failure flow depend on position.',
             N'Reorder the target job steps to match the source.'),
            /* v2.4.2: render the hash the comparison ACTUALLY used.

               This rule fires on a CommandHash mismatch but rendered only
               CommandExcerpt, which 02 replaces with a FIXED LITERAL whenever
               the command contains a credential keyword - so two genuinely
               different commands that both mention a password printed the
               identical string "[excerpt masked: ...]" in both value columns,
               beside a finding asserting that they differ. Commands diverging
               only past the excerpt's 256-character cut did the same.

               Exactly the defect 2.4.1 fixed for SystemDbObject ("render the
               hash the comparison ACTUALLY used") and for OperatorConfig; the
               job-step rule was missed. Hash first, excerpt after it. */
            (N'StepCommand',
             CASE WHEN ss.JobName IS NOT NULL AND ts.JobName IS NOT NULL
                       AND ISNULL(ss.CommandHash, 0x0) <> ISNULL(ts.CommandHash, 0x0) THEN N'WARNING' END,
             N'High',
             N'sha256 ' + ISNULL(CONVERT(nvarchar(70), ss.CommandHash, 1), N'(no command)')
               + ISNULL(N' | ' + ss.CommandExcerpt, N''),
             N'sha256 ' + ISNULL(CONVERT(nvarchar(70), ts.CommandHash, 1), N'(no command)')
               + ISNULL(N' | ' + ts.CommandExcerpt, N''),
             N'The step command TEXT differs between source and target. The comparison is on the SHA-256 shown first; the excerpt after it is truncated at 256 characters and is replaced wholesale when the command contains a credential keyword, so two excerpts can read alike while the commands differ.',
             N'Diff the step commands and align (server-name references often need editing after migration).'),
            (N'StepContext',
             CASE WHEN ss.JobName IS NOT NULL AND ts.JobName IS NOT NULL
                       AND (ISNULL(ss.SubsystemDesc, N'') <> ISNULL(ts.SubsystemDesc, N'')
                         OR ISNULL(ss.DatabaseName, N'') <> ISNULL(ts.DatabaseName, N'')
                         OR ISNULL(ss.ProxyName, N'') <> ISNULL(ts.ProxyName, N'')) THEN N'WARNING' END,
             N'Medium',
             ISNULL(ss.SubsystemDesc, N'?') + N' / db=' + ISNULL(ss.DatabaseName, N'-') + N' / proxy=' + ISNULL(ss.ProxyName, N'-'),
             ISNULL(ts.SubsystemDesc, N'?') + N' / db=' + ISNULL(ts.DatabaseName, N'-') + N' / proxy=' + ISNULL(ts.ProxyName, N'-'),
             N'The step subsystem, database context or proxy differs.',
             N'Align the step definition.'),
            (N'StepFlow',
             CASE WHEN ss.JobName IS NOT NULL AND ts.JobName IS NOT NULL
                       AND (ISNULL(ss.OnSuccessAction, 0) <> ISNULL(ts.OnSuccessAction, 0)
                         OR ISNULL(ss.OnFailAction, 0) <> ISNULL(ts.OnFailAction, 0)
                         OR ISNULL(ss.RetryAttempts, 0) <> ISNULL(ts.RetryAttempts, 0)) THEN N'WARNING' END,
             N'Low',
             N'success=' + CONVERT(nvarchar(5), ISNULL(ss.OnSuccessAction, 0)) + N' fail=' + CONVERT(nvarchar(5), ISNULL(ss.OnFailAction, 0)) + N' retry=' + CONVERT(nvarchar(5), ISNULL(ss.RetryAttempts, 0)),
             N'success=' + CONVERT(nvarchar(5), ISNULL(ts.OnSuccessAction, 0)) + N' fail=' + CONVERT(nvarchar(5), ISNULL(ts.OnFailAction, 0)) + N' retry=' + CONVERT(nvarchar(5), ISNULL(ts.RetryAttempts, 0)),
             N'Step success/failure flow or retry settings differ.', NULL)
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        /* schedules: msdb allows DUPLICATE schedule names, so aggregate the
           frequency signatures per name first - one compare row per name,
           never a multiplied join. */
        ;WITH sig AS (
            SELECT CaptureRunId, ScheduleName,
                   N'type=' + CONVERT(nvarchar(10), ISNULL(FreqType, 0))
                 + N' interval=' + CONVERT(nvarchar(10), ISNULL(FreqInterval, 0))
                 + N' subday=' + CONVERT(nvarchar(10), ISNULL(FreqSubdayType, 0)) + N'/' + CONVERT(nvarchar(10), ISNULL(FreqSubdayInterval, 0))
                 + N' rel=' + CONVERT(nvarchar(10), ISNULL(FreqRelativeInterval, 0))
                 + N' recur=' + CONVERT(nvarchar(10), ISNULL(FreqRecurrenceFactor, 0))
                 /* v2.4.2b: ActiveStartDATE removed from the signature.
                    sp_add_schedule defaults @active_start_date to TODAY, so a
                    schedule recreated on the target by any route that does not
                    carry the original date explicitly gets a different value
                    while being functionally identical - and this rule then
                    reported "Schedule timing or enabled state differs", which
                    was untrue: neither the recurrence nor the enabled state
                    had changed. ActiveStartTIME is the daily start and IS
                    meaningful, so it stays. */
                 + N' at=' + CONVERT(nvarchar(10), ISNULL(ActiveStartTime, 0))
                 + CASE WHEN IsEnabled = 0 THEN N' (disabled)' ELSE N'' END AS Signature
            FROM migration.AgentSchedule AS sch
            /* v2.4, two fixes:
               (a) CaptureRunId filter. This CTE had NO run predicate, so it
                   materialised signatures for EVERY capture ever retained (up
                   to 10 per role per server) before the outer query narrowed
                   to two - the only CTE in the file that did. Correct, but
                   roughly ten times the work.
               (b) AgentJob exclusions now reach here. A schedule attached only
                   to jobs the operator excluded via an AgentJob/Exclude
                   exception still produced Schedule findings, so the exception
                   mechanism leaked: you could exclude the job and still be
                   told about its schedule. A schedule attached to no job at
                   all is kept - it is genuinely unaccounted for. */
            WHERE sch.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
              AND (NOT EXISTS (SELECT 1 FROM migration.AgentJobSchedule js
                               WHERE js.CaptureRunId = sch.CaptureRunId
                                 AND js.ScheduleName = sch.ScheduleName)
                OR EXISTS (SELECT 1 FROM migration.AgentJobSchedule js
                           WHERE js.CaptureRunId = sch.CaptureRunId
                             AND js.ScheduleName = sch.ScheduleName
                             AND NOT EXISTS (SELECT 1 FROM #Exception x
                                             WHERE x.Scope = N'AgentJob' AND x.TreatAs = N'Exclude'
                                               AND js.JobName LIKE x.NamePattern)
                             /* v2.4.2b: ...and the owning job exists on BOTH
                                sides. A job missing on the target already has
                                its own Existence FAIL; this rule then added
                                one WARNING per schedule attached to it, all
                                describing that same absence. Job STEPS,
                                job-schedule ATTACHMENTS and alert
                                NOTIFICATIONS were each narrowed this way in
                                v2.3/v2.4 for exactly this reason - schedules
                                were the one child collection left out. A
                                schedule attached to no job at all is still
                                compared (the branch above), because nothing
                                else accounts for it. */
                             AND EXISTS (SELECT 1 FROM #SrcJob sj WHERE sj.JobName = js.JobName)
                             AND EXISTS (SELECT 1 FROM #TgtJob tj WHERE tj.JobName = js.JobName)))),
        sigagg AS (
            SELECT CaptureRunId, ScheduleName,
                   LEFT(STUFF((SELECT N' | ' + s2.Signature FROM sig AS s2
                               WHERE s2.CaptureRunId = sig.CaptureRunId AND s2.ScheduleName = sig.ScheduleName
                               ORDER BY s2.Signature
                               FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 3, N''), 3900) AS SignatureList
            FROM sig
            GROUP BY CaptureRunId, ScheduleName)
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'AgentSchedule', ISNULL(s.ScheduleName, t.ScheduleName), N'Schedule',
               CASE WHEN t.ScheduleName IS NULL THEN N'WARNING'
                    WHEN s.ScheduleName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.ScheduleName IS NULL THEN N'Medium' ELSE N'Low' END,
               s.SignatureList, t.SignatureList,
               CASE WHEN t.ScheduleName IS NULL THEN N'Schedule missing on the target.'
                    WHEN s.ScheduleName IS NULL THEN N'Schedule exists only on the target.'
                    ELSE N'Schedule timing or enabled state differs (all same-named schedule definitions shown).' END,
               CASE WHEN s.ScheduleName IS NULL AND t.ScheduleName IS NOT NULL THEN NULL
                    ELSE N'Align the schedule definition on the target.' END
        FROM (SELECT * FROM sigagg WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM sigagg WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.ScheduleName = s.ScheduleName
        WHERE s.ScheduleName IS NULL OR t.ScheduleName IS NULL
           OR s.SignatureList <> t.SignatureList;

        /* job-to-schedule attachments */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        SELECT N'Agent', N'AgentJobSchedule', ISNULL(s.JobName, t.JobName),
               ISNULL(s.ScheduleName, t.ScheduleName), N'JobScheduleAttachment',
               CASE WHEN t.JobName IS NULL THEN N'WARNING'
                    WHEN s.JobName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN s.JobName IS NULL THEN N'Low' ELSE N'Medium' END,
               CASE WHEN t.JobName IS NULL
                    THEN N'The job is attached to this schedule on the source but not on the target - it will not run on time.'
                    WHEN s.JobName IS NULL
                    THEN N'Job-schedule attachment exists only on the target.'
                    ELSE N'The job is attached to ' + CONVERT(nvarchar(10), s.Attachments)
                       + N' schedule(s) of this name on the source but ' + CONVERT(nvarchar(10), t.Attachments)
                       + N' on the target (msdb permits duplicate schedule names, so one of them was not recreated).' END,
               CASE WHEN t.JobName IS NULL THEN N'Attach the schedule to the job on the target.'
                    WHEN s.JobName IS NOT NULL THEN N'Compare the job''s schedule attachments on both sides and recreate the missing one.' END
        /* v2.3: only jobs present on BOTH sides - a job that is missing
           entirely already has its Existence finding; repeating one row per
           attached schedule was duplicate noise (the steps compare already
           does it this way). */
        /* v2.4: attachments are now keyed by ScheduleId in the capture, because
           msdb allows duplicate schedule names. ScheduleId is an msdb-local
           identity and is meaningless across two servers, so the compare
           aggregates to (JobName, ScheduleName, count) and compares the COUNT.
           That way a job attached to two identically-named schedules on the
           source but only one on the target is a real, reportable difference
           instead of silently matching. */
        FROM (SELECT js.JobName, js.ScheduleName, COUNT(*) AS Attachments
              FROM migration.AgentJobSchedule js
              WHERE js.CaptureRunId = @SourceCaptureRunId
                AND EXISTS (SELECT 1 FROM #SrcJob j WHERE j.JobName = js.JobName)
                AND EXISTS (SELECT 1 FROM #TgtJob j WHERE j.JobName = js.JobName)
              GROUP BY js.JobName, js.ScheduleName) AS s
        FULL OUTER JOIN
             (SELECT js.JobName, js.ScheduleName, COUNT(*) AS Attachments
              FROM migration.AgentJobSchedule js
              WHERE js.CaptureRunId = @TargetCaptureRunId
                AND EXISTS (SELECT 1 FROM #SrcJob j WHERE j.JobName = js.JobName)
                AND EXISTS (SELECT 1 FROM #TgtJob j WHERE j.JobName = js.JobName)
              GROUP BY js.JobName, js.ScheduleName) AS t
          ON t.JobName = s.JobName AND t.ScheduleName = s.ScheduleName
        WHERE s.JobName IS NULL OR t.JobName IS NULL
           OR s.Attachments <> t.Attachments;

        /* operators */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'Operator', ISNULL(s.OperatorName, t.OperatorName), v.CheckName,
               v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM (SELECT * FROM migration.OperatorInfo WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.OperatorInfo WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.OperatorName = s.OperatorName
        CROSS APPLY (VALUES
            (N'OperatorPresence',
             CASE WHEN t.OperatorName IS NULL THEN N'FAIL'
                  WHEN s.OperatorName IS NULL THEN N'TARGET ONLY' END,
             CASE WHEN t.OperatorName IS NULL THEN N'Medium' ELSE N'Low' END,
             CASE WHEN s.OperatorName IS NULL THEN NULL ELSE N'defined' END,
             CASE WHEN t.OperatorName IS NULL THEN NULL ELSE N'defined' END,
             N'Operator exists on only one side; alert and job notifications depending on it break.',
             N'Create the operator on the target.'),
            (N'OperatorConfig',
             CASE WHEN s.OperatorName IS NOT NULL AND t.OperatorName IS NOT NULL
                       AND (ISNULL(s.EmailAddress, N'') <> ISNULL(t.EmailAddress, N'')
                         OR ISNULL(s.PagerAddress, N'') <> ISNULL(t.PagerAddress, N'')
                         OR s.IsEnabled <> t.IsEnabled) THEN N'WARNING' END,
             N'Medium',
             /* v2.4: the rule fires on PagerAddress too, but the rendered
                values showed only EmailAddress - so a pager-only difference
                produced a warning whose two displayed values were byte for
                byte identical, the classic "it says they differ but they look
                the same" report bug. Render every field the rule tests. */
             ISNULL(s.EmailAddress, N'(none)') + N' / pager=' + ISNULL(NULLIF(s.PagerAddress, N''), N'(none)')
               + CASE WHEN s.IsEnabled = 0 THEN N' (disabled)' ELSE N'' END,
             ISNULL(t.EmailAddress, N'(none)') + N' / pager=' + ISNULL(NULLIF(t.PagerAddress, N''), N'(none)')
               + CASE WHEN t.IsEnabled = 0 THEN N' (disabled)' ELSE N'' END,
             N'Operator address or enabled state differs; notifications may go to the wrong place or nowhere.',
             N'Align the operator definition.')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        /* alerts + their notification wiring */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'Alert', ISNULL(s.AlertName, t.AlertName), v.CheckName,
               v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM (SELECT * FROM migration.AlertInfo WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.AlertInfo WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.AlertName = s.AlertName
        CROSS APPLY (VALUES
            (N'AlertPresence',
             CASE WHEN t.AlertName IS NULL THEN N'WARNING'
                  WHEN s.AlertName IS NULL THEN N'TARGET ONLY' END,
             CASE WHEN t.AlertName IS NULL THEN N'High' ELSE N'Low' END,
             CASE WHEN s.AlertName IS NULL THEN NULL
                  ELSE N'msg=' + CONVERT(nvarchar(10), ISNULL(s.MessageId, 0)) + N' sev=' + CONVERT(nvarchar(10), ISNULL(s.Severity, 0)) END,
             CASE WHEN t.AlertName IS NULL THEN NULL
                  ELSE N'msg=' + CONVERT(nvarchar(10), ISNULL(t.MessageId, 0)) + N' sev=' + CONVERT(nvarchar(10), ISNULL(t.Severity, 0)) END,
             N'Alert exists on only one side; error-condition monitoring differs at cutover.',
             N'Recreate the alert on the target.'),
            (N'AlertConfig',
             CASE WHEN s.AlertName IS NOT NULL AND t.AlertName IS NOT NULL
                       AND (s.IsEnabled <> t.IsEnabled
                         OR ISNULL(s.MessageId, 0) <> ISNULL(t.MessageId, 0)
                         OR ISNULL(s.Severity, 0) <> ISNULL(t.Severity, 0)
                         OR ISNULL(s.DatabaseName, N'') <> ISNULL(t.DatabaseName, N'')
                         OR ISNULL(s.JobName, N'') <> ISNULL(t.JobName, N'')
                         /* v2.5: the alert's actual payload. For a performance
                            condition alert every field above is 0/NULL, so two
                            alerts monitoring entirely different counters
                            compared EQUAL and were reported as migrated. */
                         OR ISNULL(s.PerformanceCondition, N'') <> ISNULL(t.PerformanceCondition, N'')) THEN N'WARNING' END,
             N'Medium',
             /* v2.4.2: msg/sev are rendered, because the rule above compares
                them. An alert differing only in its message id or severity
                threshold - a very ordinary mis-scripting - rendered two
                identical values beside "Alert definition differs". The sibling
                AlertPresence check already showed msg/sev; this one did not. */
             N'enabled=' + CONVERT(nvarchar(5), s.IsEnabled)
               + N' msg=' + CONVERT(nvarchar(10), ISNULL(s.MessageId, 0))
               + N' sev=' + CONVERT(nvarchar(10), ISNULL(s.Severity, 0))
               + N' db=' + ISNULL(s.DatabaseName, N'(all)') + N' job=' + ISNULL(s.JobName, N'(none)')
               + ISNULL(N' perf=' + s.PerformanceCondition, N''),
             N'enabled=' + CONVERT(nvarchar(5), t.IsEnabled)
               + N' msg=' + CONVERT(nvarchar(10), ISNULL(t.MessageId, 0))
               + N' sev=' + CONVERT(nvarchar(10), ISNULL(t.Severity, 0))
               + N' db=' + ISNULL(t.DatabaseName, N'(all)') + N' job=' + ISNULL(t.JobName, N'(none)')
               + ISNULL(N' perf=' + t.PerformanceCondition, N''),
             N'Alert definition differs.', N'Align the alert definition.')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        SELECT N'Agent', N'AlertNotification', ISNULL(s.AlertName, t.AlertName),
               ISNULL(s.OperatorName, t.OperatorName), N'AlertNotification',
               CASE WHEN t.AlertName IS NULL THEN N'WARNING' ELSE N'TARGET ONLY' END,
               CASE WHEN t.AlertName IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN t.AlertName IS NULL
                    THEN N'The alert notifies this operator on the source but not on the target.'
                    ELSE N'Alert notification exists only on the target.' END,
               CASE WHEN t.AlertName IS NULL THEN N'Add the notification on the target.' END
        /* v2.4: restricted to alerts present on BOTH sides.
           Job steps and job-schedule attachments were narrowed this way in
           2.3 precisely to stop one missing parent producing a storm of child
           rows; alert notifications were missed. A single alert absent on the
           target emitted its own AlertPresence WARNING and then one further
           WARNING per wired operator, all describing the same fact. */
        FROM (SELECT an.* FROM migration.AlertNotification AS an
              WHERE an.CaptureRunId = @SourceCaptureRunId
                AND EXISTS (SELECT 1 FROM migration.AlertInfo a
                            WHERE a.CaptureRunId = @SourceCaptureRunId AND a.AlertName = an.AlertName)
                AND EXISTS (SELECT 1 FROM migration.AlertInfo a
                            WHERE a.CaptureRunId = @TargetCaptureRunId AND a.AlertName = an.AlertName)) AS s
        FULL OUTER JOIN
             (SELECT an.* FROM migration.AlertNotification AS an
              WHERE an.CaptureRunId = @TargetCaptureRunId
                AND EXISTS (SELECT 1 FROM migration.AlertInfo a
                            WHERE a.CaptureRunId = @SourceCaptureRunId AND a.AlertName = an.AlertName)
                AND EXISTS (SELECT 1 FROM migration.AlertInfo a
                            WHERE a.CaptureRunId = @TargetCaptureRunId AND a.AlertName = an.AlertName)) AS t
          ON t.AlertName = s.AlertName AND t.OperatorName = s.OperatorName
        WHERE s.AlertName IS NULL OR t.AlertName IS NULL;

        /* v2.4.2b: the notification METHOD. AlertNotification.UseEmail and
           UsePager are captured (02) and had zero references here - the rule
           above only reports a one-sided (alert, operator) pair. So a target
           whose alert-to-operator wiring exists but was rebuilt with
           notification_method = 2 (pager) instead of 1 (email) passed by
           silence: the alerts fire and nobody is emailed. */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'AlertNotification', s.AlertName, s.OperatorName, N'AlertNotificationMethod',
               N'WARNING', N'Medium',
               N'email=' + CONVERT(nvarchar(5), ISNULL(s.UseEmail, 0)) + N' pager=' + CONVERT(nvarchar(5), ISNULL(s.UsePager, 0)),
               N'email=' + CONVERT(nvarchar(5), ISNULL(t.UseEmail, 0)) + N' pager=' + CONVERT(nvarchar(5), ISNULL(t.UsePager, 0)),
               CASE WHEN ISNULL(s.UseEmail, 0) = 1 AND ISNULL(t.UseEmail, 0) = 0
                    THEN N'This alert notified the operator by EMAIL on the source and no longer does on the target. The alert still fires - nobody is told.'
                    ELSE N'The notification method for this alert/operator pair differs between source and target.' END,
               N'Re-add the notification with the source''s method (sp_add_notification @notification_method).'
        FROM migration.AlertNotification AS s
        JOIN migration.AlertNotification AS t
          ON t.CaptureRunId = @TargetCaptureRunId
         AND t.AlertName = s.AlertName AND t.OperatorName = s.OperatorName
        WHERE s.CaptureRunId = @SourceCaptureRunId
          AND (ISNULL(s.UseEmail, 0) <> ISNULL(t.UseEmail, 0)
            OR ISNULL(s.UsePager, 0) <> ISNULL(t.UsePager, 0));

        /* credentials + proxies */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'Credential', ISNULL(s.CredentialName, t.CredentialName), N'Credential',
               CASE WHEN t.CredentialName IS NULL THEN N'FAIL'
                    WHEN s.CredentialName IS NULL THEN N'TARGET ONLY'
                    WHEN ISNULL(s.CredentialIdentity, N'') <> ISNULL(t.CredentialIdentity, N'') THEN N'WARNING' END,
               CASE WHEN t.CredentialName IS NULL THEN N'Medium' ELSE N'Low' END,
               s.CredentialIdentity, t.CredentialIdentity,
               CASE WHEN t.CredentialName IS NULL
                    THEN N'Credential missing on the target (its secret cannot be exported - it must be recreated by hand).'
                    WHEN s.CredentialName IS NULL THEN N'Credential exists only on the target.'
                    ELSE N'Credential identity differs (may be intentional after a domain change - verify).' END,
               CASE WHEN t.CredentialName IS NULL THEN N'CREATE CREDENTIAL on the target with the correct identity and secret.' END
        FROM (SELECT * FROM migration.CredentialInfo WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.CredentialInfo WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.CredentialName = s.CredentialName
        WHERE s.CredentialName IS NULL OR t.CredentialName IS NULL
           OR ISNULL(s.CredentialIdentity, N'') <> ISNULL(t.CredentialIdentity, N'');

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Agent', N'Proxy', ISNULL(s.ProxyName, t.ProxyName), N'Proxy',
               CASE WHEN t.ProxyName IS NULL THEN N'FAIL'
                    WHEN s.ProxyName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.ProxyName IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN s.ProxyName IS NULL THEN NULL
                    ELSE N'cred=' + ISNULL(s.CredentialName, N'?') + N' subsystems=' + ISNULL(s.SubsystemList, N'-')
                         + N' principals=' + ISNULL(s.PrincipalList, N'-') + CASE WHEN s.IsEnabled = 0 THEN N' (disabled)' ELSE N'' END END,
               CASE WHEN t.ProxyName IS NULL THEN NULL
                    ELSE N'cred=' + ISNULL(t.CredentialName, N'?') + N' subsystems=' + ISNULL(t.SubsystemList, N'-')
                         + N' principals=' + ISNULL(t.PrincipalList, N'-') + CASE WHEN t.IsEnabled = 0 THEN N' (disabled)' ELSE N'' END END,
               CASE WHEN t.ProxyName IS NULL
                    THEN N'Agent proxy missing on the target; job steps that run under it fail.'
                    WHEN s.ProxyName IS NULL THEN N'Proxy exists only on the target.'
                    ELSE N'Proxy configuration differs.' END,
               CASE WHEN t.ProxyName IS NULL THEN N'Recreate the credential and proxy, then re-grant the subsystems/principals.'
                    WHEN s.ProxyName IS NOT NULL THEN N'Align the proxy configuration.' END
        FROM (SELECT * FROM migration.ProxyInfo WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.ProxyInfo WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.ProxyName = s.ProxyName
        WHERE s.ProxyName IS NULL OR t.ProxyName IS NULL
           OR ISNULL(s.CredentialName, N'') <> ISNULL(t.CredentialName, N'')
           OR ISNULL(s.SubsystemList, N'') <> ISNULL(t.SubsystemList, N'')
           OR ISNULL(s.PrincipalList, N'') <> ISNULL(t.PrincipalList, N'')
           OR s.IsEnabled <> t.IsEnabled;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Agent', N'AgentJob', @TgtServer, N'JobsPresent', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' source jobs are present on the target.'
        FROM #SrcJob AS s
        WHERE EXISTS (SELECT 1 FROM #TgtJob AS t WHERE t.JobName = s.JobName)
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: LinkedServers
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'LinkedServers')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'LinkedServers', N'ComparisonSection', N'LinkedServers', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The LinkedServers module failed on at least one side; linked-server checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        SELECT l.* INTO #SrcLs
        FROM migration.LinkedServerInfo AS l
        WHERE l.CaptureRunId = @SourceCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'LinkedServer' AND x.TreatAs = N'Exclude'
                            AND l.LinkedServerName LIKE x.NamePattern);
        SELECT l.* INTO #TgtLs
        FROM migration.LinkedServerInfo AS l
        WHERE l.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM #Exception x WHERE x.Scope = N'LinkedServer' AND x.TreatAs = N'Exclude'
                            AND l.LinkedServerName LIKE x.NamePattern);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(DISTINCT l.LinkedServerName) FROM migration.LinkedServerInfo AS l
               WHERE l.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                 AND l.LinkedServerName LIKE x.NamePattern)
        FROM #Exception AS x WHERE x.Scope = N'LinkedServer' AND x.TreatAs = N'Exclude';
        /* v2.3: per-object trace of every excluded linked server - user-added
           exceptions only (see Databases note) */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, ExceptionId)
        SELECT DISTINCT N'LinkedServers', N'LinkedServer', LEFT(l.LinkedServerName, 400), N'ExcludedByException',
               N'EXPECTED DIFFERENCE', N'Informational',
               LEFT(N'Excluded from ALL linked-server comparisons by rule exception ('
                    + x.NamePattern + N'): ' + x.Reason, 2000),
               x.ExceptionId
        FROM migration.LinkedServerInfo AS l
        JOIN #Exception AS x ON x.Scope = N'LinkedServer' AND x.TreatAs = N'Exclude'
                            AND l.LinkedServerName LIKE x.NamePattern
        WHERE l.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                      WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId)
        SELECT N'LinkedServers', N'LinkedServer', ISNULL(s.LinkedServerName, t.LinkedServerName), v.CheckName,
               v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action, v.ExcId
        FROM #SrcLs AS s
        FULL OUTER JOIN #TgtLs AS t ON t.LinkedServerName = s.LinkedServerName
        OUTER APPLY (SELECT TOP (1) e.ExceptionId, e.Reason FROM #Exception AS e
                     WHERE e.Scope = N'LinkedServer' AND e.TreatAs = N'Expected'
                       AND ISNULL(s.LinkedServerName, t.LinkedServerName) LIKE e.NamePattern
                     ORDER BY e.ExceptionId) AS x
        CROSS APPLY (VALUES
            (N'Existence',
             CASE WHEN t.LinkedServerName IS NULL THEN
                       CASE WHEN x.ExceptionId IS NULL THEN N'FAIL' ELSE N'EXPECTED DIFFERENCE' END
                  WHEN s.LinkedServerName IS NULL THEN N'TARGET ONLY' END,
             CASE WHEN t.LinkedServerName IS NULL AND x.ExceptionId IS NULL THEN N'High' ELSE N'Low' END,
             CASE WHEN s.LinkedServerName IS NULL THEN NULL ELSE ISNULL(s.ProviderName, N'?') + N' -> ' + ISNULL(s.DataSource, N'?') END,
             CASE WHEN t.LinkedServerName IS NULL THEN NULL ELSE ISNULL(t.ProviderName, N'?') + N' -> ' + ISNULL(t.DataSource, N'?') END,
             CASE WHEN t.LinkedServerName IS NULL AND x.ExceptionId IS NOT NULL
                       THEN N'Linked server intentionally absent per rule exception: ' + x.Reason
                  WHEN t.LinkedServerName IS NULL
                       THEN N'Linked server missing on the target; queries and jobs using it fail. Login secrets never migrate - it must be recreated by hand.'
                  ELSE N'Linked server exists only on the target.' END,
             CASE WHEN t.LinkedServerName IS NULL AND x.ExceptionId IS NULL
                  THEN N'Recreate the linked server with provider, data source and login mappings.' END,
             CASE WHEN t.LinkedServerName IS NULL THEN x.ExceptionId END),
            (N'Provider',
             CASE WHEN s.LinkedServerName IS NOT NULL AND t.LinkedServerName IS NOT NULL
                       AND ISNULL(s.ProviderName, N'') <> ISNULL(t.ProviderName, N'') THEN N'WARNING' END,
             N'High', s.ProviderName, t.ProviderName,
             N'The OLE DB provider differs - the source provider may not be installed on the target.',
             N'Install/align the provider (note: some old providers do not exist for SQL 2025-era hosts).', NULL),
            (N'DataSource',
             CASE WHEN s.LinkedServerName IS NOT NULL AND t.LinkedServerName IS NOT NULL
                       AND ISNULL(s.DataSource, N'') <> ISNULL(t.DataSource, N'') THEN N'MANUAL REVIEW' END,
             N'Medium', s.DataSource, t.DataSource,
             N'The data source differs - often intentional after a migration (repointed server). Confirm.',
             NULL, NULL),
            (N'Options',
             CASE WHEN s.LinkedServerName IS NOT NULL AND t.LinkedServerName IS NOT NULL
                       AND (ISNULL(s.IsRpcOutEnabled, 0) <> ISNULL(t.IsRpcOutEnabled, 0)
                         OR ISNULL(s.IsDataAccessEnabled, 0) <> ISNULL(t.IsDataAccessEnabled, 0)) THEN N'WARNING' END,
             N'Medium',
             N'rpcout=' + CONVERT(nvarchar(5), ISNULL(s.IsRpcOutEnabled, 0)) + N' dataaccess=' + CONVERT(nvarchar(5), ISNULL(s.IsDataAccessEnabled, 0)),
             N'rpcout=' + CONVERT(nvarchar(5), ISNULL(t.IsRpcOutEnabled, 0)) + N' dataaccess=' + CONVERT(nvarchar(5), ISNULL(t.IsDataAccessEnabled, 0)),
             N'Linked-server options differ.', N'Align RPC Out / Data Access options.', NULL),
            (N'LoginMappings',
             CASE WHEN s.LinkedServerName IS NOT NULL AND t.LinkedServerName IS NOT NULL
                       AND (ISNULL(s.LoginMappingCount, 0) <> ISNULL(t.LoginMappingCount, 0)
                         OR ISNULL(s.MappedLoginList, N'') <> ISNULL(t.MappedLoginList, N'')) THEN N'WARNING' END,
             N'Medium', s.MappedLoginList, t.MappedLoginList,
             N'Linked-server login mappings differ; remote authentication will behave differently.',
             N'Recreate the login mappings (passwords must be re-entered by hand).', NULL)
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action, ExcId)
        WHERE v.Status IS NOT NULL;
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(*) FROM #Finding f
               WHERE f.ExceptionId = x.ExceptionId AND f.Category = N'LinkedServers')
        FROM #Exception AS x WHERE x.TreatAs = N'Expected' AND x.Scope = N'LinkedServer';
    END

    /* ======================================================================
       Section: DatabaseMail
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DatabaseMail')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'DatabaseMail', N'ComparisonSection', N'DatabaseMail', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The DatabaseMail module failed on at least one side; mail checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'DatabaseMail', N'MailProfile', ISNULL(s.ProfileName, t.ProfileName), N'MailProfile',
               CASE WHEN t.ProfileName IS NULL THEN N'FAIL'
                    WHEN s.ProfileName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.ProfileName IS NULL THEN N'Medium' ELSE N'Low' END,
               s.AccountList, t.AccountList,
               CASE WHEN t.ProfileName IS NULL THEN N'Database Mail profile missing on the target; alert/job mail via it fails.'
                    WHEN s.ProfileName IS NULL THEN N'Mail profile exists only on the target.'
                    ELSE N'The profile''s account list differs.' END,
               CASE WHEN t.ProfileName IS NULL THEN N'Recreate the profile and account bindings.'
                    WHEN s.ProfileName IS NOT NULL THEN N'Align the profile-account bindings.' END
        FROM (SELECT * FROM migration.DatabaseMailProfile WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.DatabaseMailProfile WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.ProfileName = s.ProfileName
        WHERE s.ProfileName IS NULL OR t.ProfileName IS NULL
           OR ISNULL(s.AccountList, N'') <> ISNULL(t.AccountList, N'');

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'DatabaseMail', N'MailAccount', ISNULL(s.AccountName, t.AccountName), N'MailAccount',
               CASE WHEN t.AccountName IS NULL THEN N'FAIL'
                    WHEN s.AccountName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.AccountName IS NULL THEN N'Medium' ELSE N'Low' END,
               CASE WHEN s.AccountName IS NULL THEN NULL
                    ELSE ISNULL(s.EmailAddress, N'?') + N' via ' + ISNULL(s.MailServerName, N'?') + N':' + CONVERT(nvarchar(10), ISNULL(s.Port, 0)) END,
               CASE WHEN t.AccountName IS NULL THEN NULL
                    ELSE ISNULL(t.EmailAddress, N'?') + N' via ' + ISNULL(t.MailServerName, N'?') + N':' + CONVERT(nvarchar(10), ISNULL(t.Port, 0)) END,
               CASE WHEN t.AccountName IS NULL THEN N'Mail account missing on the target.'
                    WHEN s.AccountName IS NULL THEN N'Mail account exists only on the target.'
                    ELSE N'Mail account settings differ (address, SMTP server or port).' END,
               CASE WHEN t.AccountName IS NULL THEN N'Recreate the account (SMTP credentials must be re-entered).'
                    WHEN s.AccountName IS NOT NULL THEN N'Verify the SMTP relay works from the target network.' END
        FROM (SELECT * FROM migration.DatabaseMailAccount WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.DatabaseMailAccount WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.AccountName = s.AccountName
        WHERE s.AccountName IS NULL OR t.AccountName IS NULL
           OR ISNULL(s.EmailAddress, N'') <> ISNULL(t.EmailAddress, N'')
           OR ISNULL(s.MailServerName, N'') <> ISNULL(t.MailServerName, N'')
           OR ISNULL(s.Port, 0) <> ISNULL(t.Port, 0);
    END

    /* ======================================================================
       Section: Endpoints (non-system)
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Endpoints')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Endpoints', N'ComparisonSection', N'Endpoints', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Endpoints module failed on at least one side; endpoint checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Endpoints', N'Endpoint', ISNULL(s.EndpointName, t.EndpointName), N'Endpoint',
               CASE WHEN t.EndpointName IS NULL THEN N'FAIL'
                    WHEN s.EndpointName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.EndpointName IS NULL THEN N'High'
                    WHEN s.EndpointName IS NULL THEN N'Low' ELSE N'Medium' END,
               CASE WHEN s.EndpointName IS NULL THEN NULL
                    ELSE ISNULL(s.TypeDesc, N'?') + N'/' + ISNULL(s.ProtocolDesc, N'?')
                         + ISNULL(N':' + CONVERT(nvarchar(10), s.Port), N'') + N' ' + ISNULL(s.StateDesc, N'?') END,
               CASE WHEN t.EndpointName IS NULL THEN NULL
                    ELSE ISNULL(t.TypeDesc, N'?') + N'/' + ISNULL(t.ProtocolDesc, N'?')
                         + ISNULL(N':' + CONVERT(nvarchar(10), t.Port), N'') + N' ' + ISNULL(t.StateDesc, N'?') END,
               CASE WHEN t.EndpointName IS NULL THEN N'User endpoint (mirroring/AG/Service Broker) missing on the target.'
                    WHEN s.EndpointName IS NULL THEN N'User endpoint exists only on the target.'
                    ELSE N'Endpoint configuration (type, protocol, port or state) differs.' END,
               CASE WHEN t.EndpointName IS NULL THEN N'CREATE ENDPOINT on the target with matching settings.'
                    WHEN s.EndpointName IS NOT NULL THEN N'Align the endpoint (a STOPPED endpoint blocks its feature).' END
        FROM (SELECT * FROM migration.EndpointInfo WHERE CaptureRunId = @SourceCaptureRunId AND IsSystem = 0) AS s
        FULL OUTER JOIN (SELECT * FROM migration.EndpointInfo WHERE CaptureRunId = @TargetCaptureRunId AND IsSystem = 0) AS t
          ON t.EndpointName = s.EndpointName
        WHERE s.EndpointName IS NULL OR t.EndpointName IS NULL
           OR ISNULL(s.TypeDesc, N'') <> ISNULL(t.TypeDesc, N'')
           OR ISNULL(s.ProtocolDesc, N'') <> ISNULL(t.ProtocolDesc, N'')
           OR ISNULL(s.Port, 0) <> ISNULL(t.Port, 0)
           OR ISNULL(s.StateDesc, N'') <> ISNULL(t.StateDesc, N'');

    /* ======================================================================
       Section: ServerTriggers
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'ServerTriggers')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'ServerTriggers', N'ComparisonSection', N'ServerTriggers', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The ServerTriggers module failed on at least one side; server-trigger checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ServerTriggers', N'ServerTrigger', ISNULL(s.TriggerName, t.TriggerName), N'ServerTrigger',
               CASE WHEN t.TriggerName IS NULL THEN N'FAIL'
                    WHEN s.TriggerName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.TriggerName IS NULL THEN N'High'
                    WHEN s.TriggerName IS NULL THEN N'Low'
                    WHEN ISNULL(s.DefinitionHash, 0x0) <> ISNULL(t.DefinitionHash, 0x0) THEN N'High'
                    ELSE N'Medium' END,
               /* v2.4.2: the DEFINITION hash is rendered, because the WHERE
                  below compares it. Without it, a trigger whose BODY was
                  edited on the target - the common case, since editing a
                  logon trigger rarely changes its event list - printed the
                  same "LOGON" on both sides next to "Server trigger
                  DEFINITION differs (compared by hash)". EventList is
                  nvarchar(2000) at capture, so the composed value cannot
                  reach the 4000-character column limit. */
               CASE WHEN s.TriggerName IS NULL THEN NULL
                    ELSE ISNULL(s.EventList, N'?') + CASE WHEN s.IsDisabled = 1 THEN N' (disabled)' ELSE N'' END
                       + N' | definition sha256 ' + ISNULL(CONVERT(nvarchar(70), s.DefinitionHash, 1), N'(none)') END,
               CASE WHEN t.TriggerName IS NULL THEN NULL
                    ELSE ISNULL(t.EventList, N'?') + CASE WHEN t.IsDisabled = 1 THEN N' (disabled)' ELSE N'' END
                       + N' | definition sha256 ' + ISNULL(CONVERT(nvarchar(70), t.DefinitionHash, 1), N'(none)') END,
               CASE WHEN t.TriggerName IS NULL THEN N'Server trigger missing on the target (often security/audit relevant - server triggers do not travel in user-database restores).'
                    WHEN s.TriggerName IS NULL THEN N'Server trigger exists only on the target.'
                    WHEN s.DefinitionHash IS NULL OR t.DefinitionHash IS NULL
                         THEN N'This server trigger exists on both sides but its definition could not be read on at least one of them (created WITH ENCRYPTION, or the capturing login lacked VIEW DEFINITION). Its body was NOT compared - two entirely different bodies would look identical here.'
                    WHEN ISNULL(s.DefinitionHash, 0x0) <> ISNULL(t.DefinitionHash, 0x0) THEN N'Server trigger DEFINITION differs (compared by hash).'
                    ELSE N'Server trigger events or disabled state differ.' END,
               CASE WHEN t.TriggerName IS NULL THEN N'Script the trigger from the source and create it on the target.'
                    WHEN s.TriggerName IS NOT NULL THEN N'Diff and align the trigger.' END
        FROM (SELECT * FROM migration.ServerTrigger WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.ServerTrigger WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.TriggerName = s.TriggerName
        WHERE s.TriggerName IS NULL OR t.TriggerName IS NULL
           OR ISNULL(s.DefinitionHash, 0x0) <> ISNULL(t.DefinitionHash, 0x0)
           OR ISNULL(s.EventList, N'') <> ISNULL(t.EventList, N'')
           OR s.IsDisabled <> t.IsDisabled
           /* v2.4.2b: a trigger created WITH ENCRYPTION, or read without VIEW
              DEFINITION, has a NULL DefinitionHash on both sides and compared
              EQUAL however different the two bodies were. Report it as
              unverified rather than passing it by silence. */
           OR (s.DefinitionHash IS NULL OR t.DefinitionHash IS NULL);

    /* ======================================================================
       Section: SystemDbObjects - user objects in master/msdb do not travel
       with user-database restores; they must be recreated by hand.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'SystemDbObjects')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'SystemDbObjects', N'ComparisonSection', N'SystemDbObjects', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The SystemDbObjects module failed on at least one side; master/msdb object checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* v2.4: ShapeHash joins DefinitionHash here. Tables have no
           sys.sql_modules definition, so DefinitionHash is NULL for them and
           the ISNULL(hash, 0x0) equality below made two tables with the same
           name and COMPLETELY DIFFERENT columns compare as matching - and
           counted them in the MatchingObjects pass total. ShapeHash carries a
           hash of the ordered column signature, so a table's shape is now
           compared the same way a procedure's body is. */
        ;WITH s AS (SELECT DatabaseName + N'.' + SchemaName + N'.' + ObjectName AS FullName,
                           TypeDesc, DefinitionHash, ShapeHash
                    FROM migration.SystemDbObject WHERE CaptureRunId = @SourceCaptureRunId),
              t AS (SELECT DatabaseName + N'.' + SchemaName + N'.' + ObjectName AS FullName,
                           TypeDesc, DefinitionHash, ShapeHash
                    FROM migration.SystemDbObject WHERE CaptureRunId = @TargetCaptureRunId)
        SELECT ISNULL(s.FullName, t.FullName) AS FullName,
               s.TypeDesc AS SrcType, t.TypeDesc AS TgtType,
               s.DefinitionHash AS SrcHash, t.DefinitionHash AS TgtHash,
               s.ShapeHash AS SrcShape, t.ShapeHash AS TgtShape,
               CASE WHEN s.FullName IS NULL THEN 0 ELSE 1 END AS OnSource,
               CASE WHEN t.FullName IS NULL THEN 0 ELSE 1 END AS OnTarget
        INTO #SysObj
        FROM s FULL OUTER JOIN t ON t.FullName = s.FullName;

        /* v2.3: per-object trace - but ONLY for excluded objects that were
           ONE-SIDED, i.e. where the exclusion actually suppressed a would-be
           finding. (Objects matched on both sides are omitted: the seeded
           version-noise exclusions legitimately match hundreds of objects.) */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, ExceptionId)
        SELECT DISTINCT N'SystemDbObjects', ISNULL(so.SrcType, so.TgtType), LEFT(so.FullName, 400),
               N'ExcludedByException', N'EXPECTED DIFFERENCE', N'Informational',
               LEFT(N'One-sided system-database object suppressed by rule exception ('
                    + x.NamePattern + N'): ' + x.Reason, 2000),
               x.ExceptionId
        FROM #SysObj AS so
        JOIN #Exception AS x ON x.Scope = N'SystemDbObject' AND x.TreatAs = N'Exclude'
                            AND so.FullName LIKE x.NamePattern
        WHERE so.OnSource <> so.OnTarget
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                      WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

        DELETE so FROM #SysObj AS so
        WHERE EXISTS (SELECT 1 FROM #Exception x
                      WHERE x.Scope = N'SystemDbObject' AND x.TreatAs = N'Exclude'
                        AND so.FullName LIKE x.NamePattern);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(DISTINCT o.DatabaseName + N'.' + o.SchemaName + N'.' + o.ObjectName)
               FROM migration.SystemDbObject AS o
               WHERE o.CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId)
                 AND o.DatabaseName + N'.' + o.SchemaName + N'.' + o.ObjectName LIKE x.NamePattern)
        FROM #Exception AS x WHERE x.Scope = N'SystemDbObject' AND x.TreatAs = N'Exclude';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId)
        SELECT N'SystemDbObjects', ISNULL(so.SrcType, so.TgtType), so.FullName, N'SystemDbObject',
               CASE WHEN so.OnTarget = 0 THEN
                         CASE WHEN x.ExceptionId IS NULL THEN N'FAIL' ELSE N'EXPECTED DIFFERENCE' END
                    WHEN so.OnSource = 0 THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN so.OnTarget = 0 AND x.ExceptionId IS NULL THEN N'Medium' ELSE N'Low' END,
               /* v2.4.1: render the hash the comparison ACTUALLY used.
                  Tables have no sys.sql_modules body, so DefinitionHash is
                  NULL for them - which meant a table whose COLUMNS differed
                  printed "(no definition)" on both sides beside a claim that
                  the column signature did not match. Show ShapeHash for
                  tables, DefinitionHash for modules, and label which. */
               CASE WHEN so.OnSource = 1 THEN
                    ISNULL(N'definition ' + CONVERT(nvarchar(70), so.SrcHash, 1),
                    ISNULL(N'columns ' + CONVERT(nvarchar(70), so.SrcShape, 1), N'(no definition or column data)')) END,
               CASE WHEN so.OnTarget = 1 THEN
                    ISNULL(N'definition ' + CONVERT(nvarchar(70), so.TgtHash, 1),
                    ISNULL(N'columns ' + CONVERT(nvarchar(70), so.TgtShape, 1), N'(no definition or column data)')) END,
               CASE WHEN so.OnTarget = 0 AND x.ExceptionId IS NOT NULL
                         THEN N'Intentionally absent per rule exception: ' + x.Reason
                    WHEN so.OnTarget = 0
                         THEN N'User object in master/msdb is missing on the target. These objects do NOT travel with user-database restores.'
                    WHEN so.OnSource = 0 THEN N'User object in master/msdb exists only on the target.'
                    WHEN ISNULL(so.SrcShape, 0x0) <> ISNULL(so.TgtShape, 0x0)
                         THEN N'The TABLE definition differs between source and target: the column signature (names, types, lengths, nullability, order) does not match.'
                    ELSE N'The object definition differs between source and target (compared by hash).' END,
               CASE WHEN so.OnTarget = 0 AND x.ExceptionId IS NULL
                    THEN N'Script the object from the source and create it on the target.'
                    WHEN so.OnSource = 1 AND so.OnTarget = 1 THEN N'Diff and align the definitions.' END,
               CASE WHEN so.OnTarget = 0 THEN x.ExceptionId END
        FROM #SysObj AS so
        OUTER APPLY (SELECT TOP (1) e.ExceptionId, e.Reason FROM #Exception AS e
                     WHERE e.Scope = N'SystemDbObject' AND e.TreatAs = N'Expected'
                       AND so.FullName LIKE e.NamePattern
                     ORDER BY e.ExceptionId) AS x
        WHERE so.OnTarget = 0 OR so.OnSource = 0
           OR ISNULL(so.SrcHash, 0x0)  <> ISNULL(so.TgtHash, 0x0)
           OR ISNULL(so.SrcShape, 0x0) <> ISNULL(so.TgtShape, 0x0);
        UPDATE x SET Hits = Hits +
              (SELECT COUNT(*) FROM #Finding f
               WHERE f.ExceptionId = x.ExceptionId AND f.Category = N'SystemDbObjects')
        FROM #Exception AS x WHERE x.TreatAs = N'Expected' AND x.Scope = N'SystemDbObject';

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'SystemDbObjects', N'SystemDbObject', @TgtServer, N'MatchingObjects', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' master/msdb user objects match.'
        FROM #SysObj AS so
        WHERE so.OnSource = 1 AND so.OnTarget = 1
          AND ISNULL(so.SrcHash, 0x0)  = ISNULL(so.TgtHash, 0x0)
          AND ISNULL(so.SrcShape, 0x0) = ISNULL(so.TgtShape, 0x0)
          /* v2.4.2b: an object with NO readable definition on either side must
             not be counted as "matching". See UnreadableDefinition below. */
          AND (so.SrcHash IS NOT NULL OR so.SrcShape IS NOT NULL)
          AND (so.TgtHash IS NOT NULL OR so.TgtShape IS NOT NULL)
        HAVING COUNT(*) > 0;

        /* v2.4.2b: objects whose DEFINITION could not be read.

           The comparison is ISNULL(hash, 0x0) <> ISNULL(hash, 0x0).
           sys.sql_modules.definition is NULL for anything created WITH
           ENCRYPTION, and the row is invisible to a principal without VIEW
           DEFINITION - so the hash is NULL. ShapeHash (added in v2.4) closed
           this for TABLES but is NULL for every other type by construction, so
           two completely different encrypted procedures - or the same object
           read under a lower-privileged capture on one side - hashed NULL
           against NULL, compared EQUAL, and were counted in the
           "N master/msdb user objects match" PASS total above.

           Absence of a readable definition is not evidence of a matching one. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDbObjects', ISNULL(so.SrcType, so.TgtType), so.FullName,
               N'UnreadableDefinition', N'MANUAL REVIEW', N'Medium',
               CASE WHEN so.SrcHash IS NULL AND so.SrcShape IS NULL THEN N'(no readable definition)' ELSE N'readable' END,
               CASE WHEN so.TgtHash IS NULL AND so.TgtShape IS NULL THEN N'(no readable definition)' ELSE N'readable' END,
               N'This object exists on both sides but its definition could not be read on at least one of them - it is either created WITH ENCRYPTION, or the capturing login lacked VIEW DEFINITION there. Its body was therefore NOT compared, and it is excluded from the matching-objects total. Two entirely different definitions would look identical to this comparison.',
               N'Compare this object by hand, or re-capture with VIEW DEFINITION on both sides.'
        FROM #SysObj AS so
        WHERE so.OnSource = 1 AND so.OnTarget = 1
          AND ((so.SrcHash IS NULL AND so.SrcShape IS NULL)
            OR (so.TgtHash IS NULL AND so.TgtShape IS NULL));
    END

    /* ======================================================================
       Section: Encryption - master certificates and symmetric keys.
       Instance-internal ##...## objects legitimately differ per instance.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Encryption')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Encryption', N'ComparisonSection', N'Encryption', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Encryption module failed on at least one side; certificate/key checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Encryption', N'Certificate', ISNULL(s.CertificateName, t.CertificateName), N'MasterCertificate',
               CASE WHEN ISNULL(s.CertificateName, t.CertificateName) LIKE N'##%' THEN
                         CASE WHEN s.CertificateName IS NULL OR t.CertificateName IS NULL
                                OR ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0)
                              THEN N'EXPECTED DIFFERENCE' END
                    WHEN t.CertificateName IS NULL THEN N'FAIL'
                    WHEN s.CertificateName IS NULL THEN N'TARGET ONLY'
                    WHEN ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0) THEN N'FAIL' END,
               CASE WHEN ISNULL(s.CertificateName, t.CertificateName) LIKE N'##%' THEN N'Informational'
                    WHEN t.CertificateName IS NULL OR (s.CertificateName IS NOT NULL AND ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0)) THEN N'High'
                    ELSE N'Low' END,
               CASE WHEN s.CertificateName IS NULL THEN NULL ELSE CONVERT(nvarchar(140), s.Thumbprint, 1) END,
               CASE WHEN t.CertificateName IS NULL THEN NULL ELSE CONVERT(nvarchar(140), t.Thumbprint, 1) END,
               CASE WHEN ISNULL(s.CertificateName, t.CertificateName) LIKE N'##%'
                         THEN N'Instance-internal certificate differs per instance by design.'
                    WHEN t.CertificateName IS NULL
                         THEN N'Certificate in master is missing on the target. TDE restores and encrypted-backup restores depending on it FAIL.'
                    WHEN s.CertificateName IS NULL THEN N'Certificate exists only on the target.'
                    ELSE N'The certificate exists on both sides with a DIFFERENT thumbprint - it is not the same certificate; anything encrypted under the source one cannot be opened.' END,
               CASE WHEN ISNULL(s.CertificateName, t.CertificateName) LIKE N'##%' THEN NULL
                    WHEN t.CertificateName IS NULL OR (s.CertificateName IS NOT NULL AND ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0))
                         THEN N'Restore the certificate FROM the source backup (private key file + password) - do not create a new one.' END
        FROM (SELECT * FROM migration.MasterCertificate WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.MasterCertificate WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.CertificateName = s.CertificateName
        WHERE (s.CertificateName IS NULL OR t.CertificateName IS NULL
               OR ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0));

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         TargetValue, Explanation, RecommendedAction)
        /* v2.4: an ALREADY-EXPIRED certificate is not "expiring soon".
           The predicate below (ExpiryDate < now + N days) also matches every
           certificate that expired in the PAST, and the old message reported
           those as "expires within 90 days" at Medium.

           v2.4.2b, THREE defects fixed together:

           (1) It was a FAIL, so it forced NOT READY - for a condition the
               migration did not create. The rule reads the TARGET capture
               only; there is no source comparison in it at all. That is the
               "best-practice check wearing a comparison's clothes" shape that
               v2.4 removed from UserAccess and PageVerify, which survived here
               at the harshest status in the vocabulary.

           (2) It CONTRADICTED the rule immediately above it. MasterCertificate
               instructs "Restore the certificate FROM the source backup
               (private key file + password) - do not create a new one." A TDE
               certificate created more than a year ago is already past its
               expiry date, because CREATE CERTIFICATE defaults EXPIRY_DATE to
               start + 1 year. Following the instruction therefore GUARANTEED
               this FAIL. No target state satisfied both rules.

           (3) The text was false. SQL Server does NOT enforce certificate
               expiry for TDE, backup encryption or Service Broker - expiry is
               advisory metadata for those consumers. "Dependent operations
               fail" is not true, and it was the sentence driving the verdict.

           Now directional: a certificate that arrived already-expired FROM the
           source is a pre-existing condition the migration faithfully
           reproduced (MANUAL REVIEW / Low). One that expired only on the
           target, or is expiring soon, still warns. */
        SELECT N'Encryption', N'Certificate', c.CertificateName,
               CASE WHEN c.ExpiryDate >= SYSUTCDATETIME()            THEN N'CertificateExpiry'
                    WHEN sc.CertificateName IS NOT NULL              THEN N'CertificateExpiredOnBothSides'
                    ELSE N'CertificateExpired' END,
               CASE WHEN c.ExpiryDate >= SYSUTCDATETIME()            THEN N'WARNING'
                    WHEN sc.CertificateName IS NOT NULL              THEN N'MANUAL REVIEW'
                    ELSE N'WARNING' END,
               CASE WHEN c.ExpiryDate >= SYSUTCDATETIME()            THEN N'Medium'
                    WHEN sc.CertificateName IS NOT NULL              THEN N'Low'
                    ELSE N'High' END,
               CONVERT(nvarchar(30), c.ExpiryDate, 120),
               CASE WHEN c.ExpiryDate >= SYSUTCDATETIME()
                    THEN N'This certificate on the target expires within ' + CONVERT(nvarchar(10), @CertWarnDays) + N' days.'
                    WHEN sc.CertificateName IS NOT NULL
                    THEN N'This certificate expired on ' + CONVERT(nvarchar(30), c.ExpiryDate, 120)
                       + N' and was ALREADY past that date on the source - the migration reproduced it faithfully and changed nothing about it. SQL Server does not enforce certificate expiry for TDE, backup encryption or Service Broker, so nothing breaks at cutover; this is housekeeping, not a cutover gate.'
                    ELSE N'This certificate on the target has expired ('
                       + CONVERT(nvarchar(30), c.ExpiryDate, 120)
                       + N') and was NOT expired on the source, so something changed during the migration. SQL Server does not enforce expiry for TDE or backup encryption, but any consumer that DOES check it (client connection validation, Service Broker dialog security) will reject it.' END,
               CASE WHEN c.ExpiryDate >= SYSUTCDATETIME()
                    THEN N'Plan certificate rotation before expiry.'
                    WHEN sc.CertificateName IS NOT NULL
                    THEN N'Rotate it on your normal schedule; do NOT create a new certificate as part of this cutover, or anything encrypted under the old one becomes unreadable.'
                    ELSE N'Confirm the target certificate is the one restored from the source backup, not a newly created one.' END
        FROM migration.MasterCertificate AS c
        LEFT JOIN migration.MasterCertificate AS sc
          ON sc.CaptureRunId = @SourceCaptureRunId
         AND sc.CertificateName = c.CertificateName
         AND sc.ExpiryDate IS NOT NULL
         AND sc.ExpiryDate < SYSUTCDATETIME()      -- already expired on the source too
        WHERE c.CaptureRunId = @TargetCaptureRunId
          AND c.CertificateName NOT LIKE N'##%'
          AND c.ExpiryDate IS NOT NULL
          AND c.ExpiryDate < DATEADD(DAY, @CertWarnDays, SYSUTCDATETIME());

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Encryption', N'SymmetricKey', ISNULL(s.KeyName, t.KeyName), N'MasterSymmetricKey',
               CASE WHEN ISNULL(s.KeyName, t.KeyName) LIKE N'##%' THEN N'EXPECTED DIFFERENCE'
                    WHEN t.KeyName IS NULL THEN N'FAIL'
                    WHEN s.KeyName IS NULL THEN N'TARGET ONLY'
                    ELSE N'FAIL' END,
               CASE WHEN ISNULL(s.KeyName, t.KeyName) LIKE N'##%' THEN N'Informational'
                    WHEN s.KeyName IS NULL THEN N'Low' ELSE N'High' END,
               CASE WHEN s.KeyName IS NULL THEN NULL ELSE ISNULL(CONVERT(nvarchar(140), s.Thumbprint, 1), N'?') END,
               CASE WHEN t.KeyName IS NULL THEN NULL ELSE ISNULL(CONVERT(nvarchar(140), t.Thumbprint, 1), N'?') END,
               CASE WHEN ISNULL(s.KeyName, t.KeyName) LIKE N'##%'
                         THEN N'Instance-internal key (service/database master key) differs per instance by design.'
                    WHEN t.KeyName IS NULL THEN N'User symmetric key in master is missing on the target.'
                    WHEN s.KeyName IS NULL THEN N'Symmetric key exists only on the target.'
                    ELSE N'The user symmetric key differs (thumbprint mismatch) - data encrypted under the source key cannot be decrypted.' END,
               CASE WHEN ISNULL(s.KeyName, t.KeyName) NOT LIKE N'##%' AND (t.KeyName IS NULL OR s.KeyName IS NOT NULL)
                    THEN N'Recreate the key with the same KEY_SOURCE/IDENTITY_VALUE as the source.' END
        FROM (SELECT * FROM migration.MasterSymmetricKey WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.MasterSymmetricKey WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.KeyName = s.KeyName
        WHERE s.KeyName IS NULL OR t.KeyName IS NULL
           OR ISNULL(s.Thumbprint, 0x0) <> ISNULL(t.Thumbprint, 0x0);
    END

    /* ======================================================================
       Section: Audits - the audit GUID matters: database audit specs inside
       restored databases bind to server audits BY GUID.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Audits')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Audits', N'ComparisonSection', N'Audits', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Audits module failed on at least one side; audit checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Audits', N'ServerAudit', ISNULL(s.AuditName, t.AuditName), v.CheckName,
               v.Status, v.Severity, v.SrcVal, v.TgtVal, v.Explanation, v.Action
        FROM (SELECT * FROM migration.ServerAudit WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.ServerAudit WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.AuditName = s.AuditName
        CROSS APPLY (VALUES
            (N'AuditPresence',
             CASE WHEN t.AuditName IS NULL THEN N'FAIL'
                  WHEN s.AuditName IS NULL THEN N'TARGET ONLY' END,
             CASE WHEN t.AuditName IS NULL AND s.IsEnabled = 1 THEN N'High'
                  WHEN t.AuditName IS NULL THEN N'Medium' ELSE N'Low' END,
             CASE WHEN s.AuditName IS NULL THEN NULL
                  ELSE ISNULL(s.TypeDesc, N'?') + CASE WHEN s.IsEnabled = 1 THEN N' (enabled)' ELSE N' (disabled)' END END,
             CASE WHEN t.AuditName IS NULL THEN NULL
                  ELSE ISNULL(t.TypeDesc, N'?') + CASE WHEN t.IsEnabled = 1 THEN N' (enabled)' ELSE N' (disabled)' END END,
             N'Server audit exists on only one side; compliance logging differs at cutover.',
             N'Recreate the audit on the target (compliance requirement on most estates).'),
            (N'AuditGuid',
             CASE WHEN s.AuditName IS NOT NULL AND t.AuditName IS NOT NULL
                       AND ISNULL(s.AuditGuid, CONVERT(uniqueidentifier, 0x0)) <> ISNULL(t.AuditGuid, CONVERT(uniqueidentifier, 0x0)) THEN N'WARNING' END,
             N'High',
             CONVERT(nvarchar(40), s.AuditGuid), CONVERT(nvarchar(40), t.AuditGuid),
             N'The audit exists on both sides with a DIFFERENT GUID. Database audit specifications inside RESTORED databases bind by GUID - they are orphaned on the target.',
             N'Recreate the target audit WITH (AUDIT_GUID = ''<source guid>'') or recreate the database audit specifications.'),
            (N'AuditState',
             CASE WHEN s.AuditName IS NOT NULL AND t.AuditName IS NOT NULL
                       AND s.IsEnabled = 1 AND ISNULL(t.IsEnabled, 0) = 0 THEN N'WARNING' END,
             N'High',
             N'enabled', N'disabled',
             N'The audit is enabled on the source but disabled on the target - no events are being recorded.',
             N'ALTER SERVER AUDIT ... WITH (STATE = ON) on the target.')
        ) AS v (CheckName, Status, Severity, SrcVal, TgtVal, Explanation, Action)
        WHERE v.Status IS NOT NULL;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Audits', N'ServerAuditSpec', ISNULL(s.SpecName, t.SpecName), N'AuditSpecification',
               CASE WHEN t.SpecName IS NULL THEN N'FAIL'
                    WHEN s.SpecName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.SpecName IS NULL THEN N'Medium' ELSE N'Low' END,
               /* v2.4.2: the enabled STATE is rendered, because the WHERE
                  below compares it. A specification with an identical action
                  list that is enabled on the source and disabled on the
                  target printed two identical values beside "actions or state
                  differ", and the reader could not tell which of the two it
                  was. LEFT(): ActionList is already nvarchar(4000) at capture,
                  so the suffix must not push the value past the column. */
               CASE WHEN s.SpecName IS NULL THEN NULL
                    ELSE LEFT(ISNULL(s.ActionList, N'?'), 3960)
                       + CASE WHEN ISNULL(s.IsEnabled, 0) = 1 THEN N' (enabled)' ELSE N' (disabled)' END END,
               CASE WHEN t.SpecName IS NULL THEN NULL
                    ELSE LEFT(ISNULL(t.ActionList, N'?'), 3960)
                       + CASE WHEN ISNULL(t.IsEnabled, 0) = 1 THEN N' (enabled)' ELSE N' (disabled)' END END,
               CASE WHEN t.SpecName IS NULL THEN N'Server audit specification missing on the target.'
                    WHEN s.SpecName IS NULL THEN N'Audit specification exists only on the target.'
                    WHEN ISNULL(s.ActionList, N'') <> ISNULL(t.ActionList, N'')
                         THEN N'The audited ACTION LIST differs between source and target.'
                    WHEN ISNULL(s.IsEnabled, 0) = 1
                         THEN N'The audited action list is identical, but the specification is ENABLED on the source and DISABLED on the target - it is recording nothing there.'
                    ELSE N'The audited action list is identical, but the specification is DISABLED on the source and ENABLED on the target - the target audits more than the source did.' END,
               CASE WHEN t.SpecName IS NULL THEN N'Recreate the specification bound to the matching audit.'
                    WHEN s.SpecName IS NULL THEN NULL
                    WHEN ISNULL(s.ActionList, N'') <> ISNULL(t.ActionList, N'')
                         THEN N'Align the audited action list.'
                    WHEN ISNULL(s.IsEnabled, 0) = 1
                         THEN N'ALTER SERVER AUDIT SPECIFICATION ... WITH (STATE = ON) on the target.'
                    ELSE N'Confirm the target specification is meant to be enabled when the source''s was not.' END
        FROM (SELECT * FROM migration.ServerAuditSpec WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.ServerAuditSpec WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.SpecName = s.SpecName
        WHERE s.SpecName IS NULL OR t.SpecName IS NULL
           OR ISNULL(s.ActionList, N'') <> ISNULL(t.ActionList, N'')
           OR ISNULL(s.IsEnabled, 0) <> ISNULL(t.IsEnabled, 0);

        /* v2.4: the specification's GUID BINDING.
           ServerAuditSpec.AuditGuid is captured precisely because database and
           server audit specifications bind to an audit by GUID, and a GUID
           survives a restore where an audit_id does not. But the compare above
           only looked at ActionList and IsEnabled - a target specification
           bound to a DIFFERENT audit than the source's passed silently, which
           is exactly the orphaning the GUID exists to detect. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        /* v2.4.2b: MANUAL REVIEW, not FAIL - and the text no longer asserts
           something that is usually false.

           CREATE SERVER AUDIT mints a NEW audit_guid unless the operator knows
           to pass WITH (AUDIT_GUID = ...). Server audits do not travel with a
           user-database restore, so hand-recreating the audit and its
           specification on the target - the correct, expected action - changes
           this GUID on both objects together. The specification is then bound
           to the right audit; only the GUID VALUE differs. The old text said
           it was "attached to the wrong audit - or to nothing at all, silently
           recording no events", which was false in that case, and at FAIL it
           forced NOT READY on a correctly rebuilt audit.

           The GUID does matter, but for a different object: DATABASE audit
           specifications inside the RESTORED databases bind to a server audit
           by GUID, and this tool does not inventory those. That is the real
           risk and the text now says so. Note the sibling AuditGuid rule
           (above) detects the very same GUID change on the audit itself and
           has always rated it WARNING - one fact must not carry two verdicts,
           and the harsher one was winning. */
        SELECT N'Audits', N'ServerAuditSpec', s.SpecName, N'AuditSpecificationBinding',
               N'MANUAL REVIEW', N'Medium',
               CONVERT(nvarchar(40), s.AuditGuid), CONVERT(nvarchar(40), t.AuditGuid),
               N'The audit specification exists on both sides but names a different audit GUID. If the audit and this specification were recreated together on the target, this is expected and the specification is correctly bound - CREATE SERVER AUDIT mints a new GUID unless AUDIT_GUID is supplied. What it DOES break is any DATABASE audit specification inside a restored database, because those bind to a server audit by GUID and this tool does not inventory them.',
               N'If any restored database contains a database audit specification, recreate the target audit WITH (AUDIT_GUID = ''' + ISNULL(CONVERT(nvarchar(40), s.AuditGuid), N'<source guid>') + N''') so those bindings survive; otherwise confirm this specification points at the intended audit.'
        FROM migration.ServerAuditSpec AS s
        JOIN migration.ServerAuditSpec AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.SpecName = s.SpecName
        WHERE s.CaptureRunId = @SourceCaptureRunId
          AND ISNULL(s.AuditGuid, CONVERT(uniqueidentifier, 0x0))
           <> ISNULL(t.AuditGuid, CONVERT(uniqueidentifier, 0x0));
    END

    /* ======================================================================
       Section: XeSessions
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'XeSessions')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'XeSessions', N'ComparisonSection', N'XeSessions', N'SectionSkipped', N'SKIPPED', N'Low',
                N'The XeSessions module failed on at least one side; Extended Events checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'XeSessions', N'XeSession', ISNULL(s.SessionName, t.SessionName), N'XeSession',
               CASE WHEN t.SessionName IS NULL THEN N'WARNING'
                    WHEN s.SessionName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               N'Low',
               /* v2.4.2: the TARGET count is rendered, because the WHERE below
                  compares it - and the explanation literally says
                  "events/targets/startup". A session re-created against a
                  different target (ring_buffer instead of event_file) kept the
                  same event count and printed two identical values. */
               CASE WHEN s.SessionName IS NULL THEN NULL
                    ELSE CONVERT(nvarchar(10), ISNULL(s.EventCount, 0)) + N' events, '
                       + CONVERT(nvarchar(10), ISNULL(s.TargetCount, 0)) + N' targets, startup='
                       + CONVERT(nvarchar(5), ISNULL(s.StartupState, 0))
                       + CASE WHEN ISNULL(s.IsRunning, 0) = 1 THEN N', running' ELSE N', stopped' END END,
               CASE WHEN t.SessionName IS NULL THEN NULL
                    ELSE CONVERT(nvarchar(10), ISNULL(t.EventCount, 0)) + N' events, '
                       + CONVERT(nvarchar(10), ISNULL(t.TargetCount, 0)) + N' targets, startup='
                       + CONVERT(nvarchar(5), ISNULL(t.StartupState, 0))
                       + CASE WHEN ISNULL(t.IsRunning, 0) = 1 THEN N', running' ELSE N', stopped' END END,
               CASE WHEN t.SessionName IS NULL THEN N'Custom Extended Events session missing on the target; monitoring coverage differs.'
                    WHEN s.SessionName IS NULL THEN N'Extended Events session exists only on the target.'
                    WHEN ISNULL(s.IsRunning, 0) = 1 AND ISNULL(t.IsRunning, 0) = 0
                         AND ISNULL(s.EventCount, 0) = ISNULL(t.EventCount, 0)
                         AND ISNULL(s.TargetCount, 0) = ISNULL(t.TargetCount, 0)
                         AND ISNULL(s.StartupState, 0) = ISNULL(t.StartupState, 0)
                    THEN N'This Extended Events session is defined identically on both sides but is RUNNING on the source and STOPPED on the target - it is collecting nothing there.'
                    ELSE N'Extended Events session definition (events/targets/startup/running state) differs.' END,
               CASE WHEN t.SessionName IS NULL THEN N'Script the session from the source and create it on the target.' END
        FROM (SELECT * FROM migration.XeSession WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.XeSession WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.SessionName = s.SessionName
        WHERE s.SessionName IS NULL OR t.SessionName IS NULL
           OR ISNULL(s.EventCount, 0) <> ISNULL(t.EventCount, 0)
           OR ISNULL(s.TargetCount, 0) <> ISNULL(t.TargetCount, 0)
           OR ISNULL(s.StartupState, 0) <> ISNULL(t.StartupState, 0)
           /* v2.4.2b: IsRunning was captured (02) and never referenced here.
              A custom blocked-process or deadlock session that exists on both
              sides with startup_state = 0, started by hand on the source and
              never started on the target, compared EQUAL - monitoring coverage
              silently gone. */
           OR ISNULL(s.IsRunning, 0) <> ISNULL(t.IsRunning, 0);

    /* ======================================================================
       Section: ResourceGovernor pools/groups
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'ResourceGovernor')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'ResourceGovernor', N'ComparisonSection', N'ResourceGovernor', N'SectionSkipped', N'SKIPPED', N'Low',
                N'The ResourceGovernor module failed on at least one side; RG checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ResourceGovernor', N'ResourcePool', ISNULL(s.PoolName, t.PoolName), N'ResourcePool',
               CASE WHEN t.PoolName IS NULL THEN N'FAIL'
                    WHEN s.PoolName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.PoolName IS NULL THEN N'Medium' ELSE N'Low' END,
               /* v2.4.2: cap= rendered - CapCpuPercent is in the WHERE below,
                  so a pool differing only in its hard CPU cap showed two
                  identical values beside "Resource pool limits differ". */
               CASE WHEN s.PoolName IS NULL THEN NULL
                    ELSE N'cpu=' + CONVERT(nvarchar(5), ISNULL(s.MinCpuPercent, 0)) + N'-' + CONVERT(nvarchar(5), ISNULL(s.MaxCpuPercent, 0))
                         + N' cap=' + CONVERT(nvarchar(5), ISNULL(s.CapCpuPercent, 0))
                         + N' mem=' + CONVERT(nvarchar(5), ISNULL(s.MinMemoryPercent, 0)) + N'-' + CONVERT(nvarchar(5), ISNULL(s.MaxMemoryPercent, 0)) END,
               CASE WHEN t.PoolName IS NULL THEN NULL
                    ELSE N'cpu=' + CONVERT(nvarchar(5), ISNULL(t.MinCpuPercent, 0)) + N'-' + CONVERT(nvarchar(5), ISNULL(t.MaxCpuPercent, 0))
                         + N' cap=' + CONVERT(nvarchar(5), ISNULL(t.CapCpuPercent, 0))
                         + N' mem=' + CONVERT(nvarchar(5), ISNULL(t.MinMemoryPercent, 0)) + N'-' + CONVERT(nvarchar(5), ISNULL(t.MaxMemoryPercent, 0)) END,
               CASE WHEN t.PoolName IS NULL THEN N'Resource Governor pool missing on the target.'
                    WHEN s.PoolName IS NULL THEN N'Resource pool exists only on the target.'
                    ELSE N'Resource pool limits differ.' END,
               CASE WHEN t.PoolName IS NULL THEN N'Recreate the pool on the target.' END
        FROM (SELECT * FROM migration.RgPool WHERE CaptureRunId = @SourceCaptureRunId AND PoolName NOT IN (N'default', N'internal')) AS s
        FULL OUTER JOIN (SELECT * FROM migration.RgPool WHERE CaptureRunId = @TargetCaptureRunId AND PoolName NOT IN (N'default', N'internal')) AS t
          ON t.PoolName = s.PoolName
        WHERE s.PoolName IS NULL OR t.PoolName IS NULL
           OR ISNULL(s.MinCpuPercent, 0) <> ISNULL(t.MinCpuPercent, 0)
           OR ISNULL(s.MaxCpuPercent, 0) <> ISNULL(t.MaxCpuPercent, 0)
           OR ISNULL(s.CapCpuPercent, 0) <> ISNULL(t.CapCpuPercent, 0)
           OR ISNULL(s.MinMemoryPercent, 0) <> ISNULL(t.MinMemoryPercent, 0)
           OR ISNULL(s.MaxMemoryPercent, 0) <> ISNULL(t.MaxMemoryPercent, 0);

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'ResourceGovernor', N'WorkloadGroup', ISNULL(s.GroupName, t.GroupName), N'WorkloadGroup',
               CASE WHEN t.GroupName IS NULL THEN N'FAIL'
                    WHEN s.GroupName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.GroupName IS NULL THEN N'Medium' ELSE N'Low' END,
               /* v2.4.2: the four request limits are rendered - all of them are
                  in the WHERE below, and none of them was shown, so a group
                  differing only in its memory-grant percentage or request cap
                  rendered two identical values beside "Workload group
                  configuration differs". */
               CASE WHEN s.GroupName IS NULL THEN NULL
                    ELSE N'pool=' + ISNULL(s.PoolName, N'?') + N' importance=' + ISNULL(s.Importance, N'?')
                         + N' maxdop=' + CONVERT(nvarchar(5), ISNULL(s.MaxDop, 0))
                         + N' grant%=' + CONVERT(nvarchar(10), ISNULL(s.RequestMaxMemoryGrantPercent, 0))
                         + N' cpusec=' + CONVERT(nvarchar(10), ISNULL(s.RequestMaxCpuTimeSec, 0))
                         + N' grantwait=' + CONVERT(nvarchar(10), ISNULL(s.RequestMemoryGrantTimeoutSec, 0))
                         + N' maxreq=' + CONVERT(nvarchar(10), ISNULL(s.GroupMaxRequests, 0)) END,
               CASE WHEN t.GroupName IS NULL THEN NULL
                    ELSE N'pool=' + ISNULL(t.PoolName, N'?') + N' importance=' + ISNULL(t.Importance, N'?')
                         + N' maxdop=' + CONVERT(nvarchar(5), ISNULL(t.MaxDop, 0))
                         + N' grant%=' + CONVERT(nvarchar(10), ISNULL(t.RequestMaxMemoryGrantPercent, 0))
                         + N' cpusec=' + CONVERT(nvarchar(10), ISNULL(t.RequestMaxCpuTimeSec, 0))
                         + N' grantwait=' + CONVERT(nvarchar(10), ISNULL(t.RequestMemoryGrantTimeoutSec, 0))
                         + N' maxreq=' + CONVERT(nvarchar(10), ISNULL(t.GroupMaxRequests, 0)) END,
               CASE WHEN t.GroupName IS NULL THEN N'Workload group missing on the target.'
                    WHEN s.GroupName IS NULL THEN N'Workload group exists only on the target.'
                    ELSE N'Workload group configuration differs.' END,
               CASE WHEN t.GroupName IS NULL THEN N'Recreate the workload group on the target.' END
        FROM (SELECT * FROM migration.RgGroup WHERE CaptureRunId = @SourceCaptureRunId AND GroupName NOT IN (N'default', N'internal')) AS s
        FULL OUTER JOIN (SELECT * FROM migration.RgGroup WHERE CaptureRunId = @TargetCaptureRunId AND GroupName NOT IN (N'default', N'internal')) AS t
          ON t.GroupName = s.GroupName
        WHERE s.GroupName IS NULL OR t.GroupName IS NULL
           OR ISNULL(s.PoolName, N'') <> ISNULL(t.PoolName, N'')
           OR ISNULL(s.Importance, N'') <> ISNULL(t.Importance, N'')
           OR ISNULL(s.RequestMaxMemoryGrantPercent, 0) <> ISNULL(t.RequestMaxMemoryGrantPercent, 0)
           OR ISNULL(s.RequestMaxCpuTimeSec, 0) <> ISNULL(t.RequestMaxCpuTimeSec, 0)
           OR ISNULL(s.RequestMemoryGrantTimeoutSec, 0) <> ISNULL(t.RequestMemoryGrantTimeoutSec, 0)
           OR ISNULL(s.GroupMaxRequests, 0) <> ISNULL(t.GroupMaxRequests, 0)
           OR ISNULL(s.MaxDop, 0) <> ISNULL(t.MaxDop, 0);
    END

    /* ======================================================================
       Section: Features + DeprecatedFeatures
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Features')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Features', N'ComparisonSection', N'Features', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The Features module failed on at least one side; feature-usage checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'Features', N'Feature', s.FeatureName, N'FeatureUsage',
               N'MANUAL REVIEW',
               /* detail-only drift is advisory: Informational keeps it out of
                  @ManualActionable so it cannot demote an otherwise clean run */
               CASE WHEN t.FeatureName IS NULL OR t.IsInUse = 0 THEN N'Medium' ELSE N'Informational' END,
               ISNULL(s.Detail, N'in use'),
               CASE WHEN t.FeatureName IS NULL THEN N'(not captured)'
                    WHEN t.IsInUse = 0 THEN N'not in use' ELSE ISNULL(t.Detail, N'in use') END,
               /* v2.4: the explanation used to say "the source uses this
                  feature but the target does not" unconditionally, even though
                  the rule ALSO fires when both sides use it and only Detail
                  differs. Service Broker detail differs after every restore
                  (the restore disables the broker) and Detail lists database
                  names, so any extra database on the target changed it too -
                  producing a Medium MANUAL REVIEW, which counts toward the
                  verdict, carrying a message that was simply false. */
               CASE WHEN t.FeatureName IS NULL OR t.IsInUse = 0
                    THEN N'The source uses this feature but the target does not (yet). Features like replication, mirroring and log shipping never travel with restores - they are reconfigured at/after cutover.'
                    ELSE N'The feature is in use on BOTH sides, but its detail differs (the list of databases or the configuration behind it is not the same).' END,
               CASE WHEN t.FeatureName IS NULL OR t.IsInUse = 0
                    THEN N'Confirm the cutover runbook covers re-enabling this feature, or record that it is being retired.'
                    ELSE N'Compare the listed databases on each side and confirm the difference is intended.' END
        FROM (SELECT * FROM migration.FeatureUsage WHERE CaptureRunId = @SourceCaptureRunId AND IsInUse = 1) AS s
        LEFT JOIN (SELECT * FROM migration.FeatureUsage WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.FeatureName = s.FeatureName
        WHERE t.FeatureName IS NULL OR t.IsInUse = 0 OR ISNULL(s.Detail, N'') <> ISNULL(t.Detail, N'');

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'Features', N'Feature', @TgtServer, N'FeaturesAligned', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' features in use on the source are equally present on the target.'
        FROM migration.FeatureUsage AS s
        JOIN migration.FeatureUsage AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.FeatureName = s.FeatureName
        WHERE s.CaptureRunId = @SourceCaptureRunId AND s.IsInUse = 1
          AND t.IsInUse = 1 AND ISNULL(s.Detail, N'') = ISNULL(t.Detail, N'')
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: DatabaseScopedConfig (v2.4) - the upgrade-behaviour section.

       This is the gap that mattered most for a 2016 -> 2025 validator: the
       cardinality estimator, parameter sniffing, optimizer hotfixes and the
       per-database MAXDOP are all controlled here, none of them are visible at
       server level, and none of them were captured or compared before 2.4.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DatabaseScopedConfig')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'UpgradeBehaviour', N'ComparisonSection', N'DatabaseScopedConfig', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The DatabaseScopedConfig module failed on at least one side; cardinality-estimator and query-optimizer settings were NOT compared.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        /* v2.4.2b: settings the TARGET engine exposes and the source did not -
           i.e. knobs introduced between the two versions. Materialised once
           here so the per-object rule can exclude them and the aggregate below
           can count them. Same both-sides-exist and Database/Exclude guards as
           the comparison itself, so the two always describe the same set. */
        SELECT t.DatabaseName, t.ConfigName
        INTO #NewScopedCfg
        FROM migration.DatabaseScopedConfig AS t
        WHERE t.CaptureRunId = @TargetCaptureRunId
          AND NOT EXISTS (SELECT 1 FROM migration.DatabaseScopedConfig s2
                          WHERE s2.CaptureRunId = @SourceCaptureRunId
                            AND s2.DatabaseName = t.DatabaseName AND s2.ConfigName = t.ConfigName)
          AND EXISTS (SELECT 1 FROM migration.DatabaseScopedConfig d2
                      WHERE d2.CaptureRunId = @SourceCaptureRunId AND d2.DatabaseName = t.DatabaseName)
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND t.DatabaseName LIKE x.NamePattern);

        /* v2.4.2b: per-database probe failures get their own marker.

           02 records a scoped-config failure for ONE database with ItemName
           set, so it lands in #ItemErr, not #ModErr - and this section's gate
           tests #ModErr only and never referenced #ItemErr at all. The EXISTS
           guards below then quietly dropped every scoped-configuration row for
           that database, so the LEGACY_CARDINALITY_ESTIMATION comparison that
           this whole section exists to perform did not happen, and the
           UpgradeBehaviour category said nothing about it.

           DatabaseHealth already emits HealthComparisonSkipped per database
           for exactly this case; this section had no equivalent. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         Explanation, RecommendedAction)
        SELECT DISTINCT N'UpgradeBehaviour', N'Database', ie.ItemName, N'ScopedConfigComparisonSkipped',
               N'SKIPPED', N'Medium',
               N'The database-scoped configuration probe did not read this database on the ' + ie.Side
                 + N' side, so its cardinality-estimator, parameter-sniffing, optimizer-hotfix and MAXDOP settings were NOT compared. This is the single most common cause of a correctly-migrated database performing badly on a newer version, and for this database it was not checked.',
               N'Make the database ONLINE and MULTI_USER, ensure the capturing login has access, and re-capture that side.'
        FROM #ItemErr AS ie
        WHERE ie.ModuleName = N'DatabaseScopedConfig'
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND ie.ItemName LIKE x.NamePattern);

        /* per-database scoped configuration, both sides, excluding databases
           the operator excluded and databases whose probe failed on one side */
        INSERT #Finding (Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'UpgradeBehaviour', N'DatabaseScopedConfig',
               ISNULL(s.DatabaseName, t.DatabaseName), ISNULL(s.ConfigName, t.ConfigName),
               N'ScopedConfiguration',
               CASE WHEN s.ConfigName IS NULL THEN N'TARGET ONLY'
                    WHEN t.ConfigName IS NULL THEN N'SOURCE ONLY'
                    /* LEGACY_CARDINALITY_ESTIMATION is the one that most often
                       turns a correct migration into a slow one, in BOTH
                       directions - losing it exposes the new CE, gaining it
                       silently pins the old one. */
                    /* v2.4.2b: the LEGACY_CARDINALITY_ESTIMATION WHEN was
                       removed - it produced 'WARNING', and so did the ELSE, so
                       the branch decided nothing. The intent (the comment
                       above argues LCE deserves special treatment) was carried
                       out in the SEVERITY expression below, which does single
                       it out at High; the status arm was left half-written. */
                    ELSE N'WARNING' END,
               CASE WHEN s.ConfigName IS NULL OR t.ConfigName IS NULL THEN N'Low'
                    WHEN s.ConfigName IN (N'LEGACY_CARDINALITY_ESTIMATION', N'PARAMETER_SNIFFING',
                                          N'QUERY_OPTIMIZER_HOTFIXES') THEN N'High'
                    WHEN s.ConfigName = N'MAXDOP' THEN N'Medium'
                    ELSE N'Low' END,
               s.Value, t.Value,
               CASE WHEN s.ConfigName IS NULL
                    THEN N'This database-scoped setting exists only on the target - it is new in the target version and is running at its default.'
                    WHEN t.ConfigName IS NULL
                    THEN N'This database-scoped setting existed on the source but the target version does not expose it.'
                    WHEN s.ConfigName = N'LEGACY_CARDINALITY_ESTIMATION'
                    THEN N'LEGACY_CARDINALITY_ESTIMATION differs. This directly selects which cardinality estimator the optimizer uses and is the most common cause of a correctly-migrated database performing badly on a newer version.'
                    WHEN s.ConfigName = N'PARAMETER_SNIFFING'
                    THEN N'PARAMETER_SNIFFING differs; plan reuse behaviour will not match the source.'
                    WHEN s.ConfigName = N'QUERY_OPTIMIZER_HOTFIXES'
                    THEN N'QUERY_OPTIMIZER_HOTFIXES differs; the target optimizer applies a different set of post-RTM fixes than the source did.'
                    WHEN s.ConfigName = N'MAXDOP'
                    THEN N'The database-scoped MAXDOP differs; this OVERRIDES the server-level setting for this database.'
                    ELSE N'The database-scoped configuration differs between source and target.' END,
               CASE WHEN s.ConfigName IS NULL OR t.ConfigName IS NULL
                    THEN N'Review the setting at the target version default and set it deliberately if it matters.'
                    ELSE N'ALTER DATABASE SCOPED CONFIGURATION SET ' + s.ConfigName + N' = ' + ISNULL(s.Value, N'<source value>')
                       + N'; on the target, or record why the new value is intended.' END
        FROM (SELECT DatabaseName, ConfigName, Value FROM migration.DatabaseScopedConfig
              WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN
             (SELECT DatabaseName, ConfigName, Value FROM migration.DatabaseScopedConfig
              WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.DatabaseName = s.DatabaseName AND t.ConfigName = s.ConfigName
        WHERE (t.ConfigName IS NULL
               OR (s.ConfigName IS NOT NULL AND ISNULL(s.Value, N'') <> ISNULL(t.Value, N'')))
          /* v2.4.2b: TARGET ONLY rows (s.ConfigName IS NULL) are NO LONGER
             emitted per object here - they are aggregated into a single
             EXPECTED DIFFERENCE row by the rule immediately below.

             Measured on a realistic clean migration: SQL 2016 exposes 4 rows
             in sys.database_scoped_configurations, SQL 2025 exposes ~40, and
             this FULL OUTER JOIN is per (database, setting) - so 20 restored
             databases produced 720 TARGET ONLY findings, 84% of an 855-row
             report, every one of them saying "new in the target version and
             running at its default". They also all landed in @TgtOnly, so the
             assessment sentence read "730 object(s) present only on the
             target to work through" and READY became unreachable by
             construction. The engine having more knobs than it used to is not
             something a cutover board works through.

             Value DIFFERENCES and SOURCE ONLY rows - the actual signal, and
             where LEGACY_CARDINALITY_ESTIMATION lives - stay per object at
             their existing severities. */
          /* only for databases that exist on both sides - a missing database
             already has its own Critical blocker */
          AND EXISTS (SELECT 1 FROM migration.DatabaseScopedConfig d2
                      WHERE d2.CaptureRunId = @SourceCaptureRunId AND d2.DatabaseName = ISNULL(s.DatabaseName, t.DatabaseName))
          AND EXISTS (SELECT 1 FROM migration.DatabaseScopedConfig d3
                      WHERE d3.CaptureRunId = @TargetCaptureRunId AND d3.DatabaseName = ISNULL(s.DatabaseName, t.DatabaseName))
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND ISNULL(s.DatabaseName, t.DatabaseName) LIKE x.NamePattern);

        /* v2.4.2b: the aggregate that replaces those 720 rows. ONE row, and
           EXPECTED DIFFERENCE rather than TARGET ONLY so a version artefact
           stops steering the verdict - the same classification this file
           already uses for "the target has more than the source" everywhere
           else (hardware sizing, compatibility level, tempdb files). */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'UpgradeBehaviour', N'DatabaseScopedConfig', @TgtServer,
               N'ScopedConfigurationsNewInTargetVersion',
               N'EXPECTED DIFFERENCE', N'Informational',
               N'not exposed by SQL ' + ISNULL(@SrcVersion, N'?'),
               CONVERT(nvarchar(10), COUNT(DISTINCT n.ConfigName)) + N' setting(s) x '
                 + CONVERT(nvarchar(10), COUNT(DISTINCT n.DatabaseName)) + N' database(s)',
               N'The target engine exposes ' + CONVERT(nvarchar(10), COUNT(DISTINCT n.ConfigName))
                 + N' database-scoped configuration setting(s) that the source version did not have, across '
                 + CONVERT(nvarchar(10), COUNT(DISTINCT n.DatabaseName))
                 + N' database(s). They are running at the target version''s defaults. This is the newer engine having more knobs, not a difference the migration introduced: '
                 + LEFT(ISNULL(STUFF((SELECT DISTINCT N', ' + n2.ConfigName FROM #NewScopedCfg AS n2
                                      ORDER BY N', ' + n2.ConfigName
                                      FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1200) + N'.',
               N'No cutover action. Review the new defaults at your leisure and set any that matter for your workload.'
        FROM #NewScopedCfg AS n
        HAVING COUNT(*) > 0;

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'UpgradeBehaviour', N'DatabaseScopedConfig', @TgtServer, N'ScopedConfigurationsMatch',
               N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' database-scoped configuration values match between source and target.'
        FROM migration.DatabaseScopedConfig AS s
        JOIN migration.DatabaseScopedConfig AS t
          ON t.CaptureRunId = @TargetCaptureRunId AND t.DatabaseName = s.DatabaseName AND t.ConfigName = s.ConfigName
        WHERE s.CaptureRunId = @SourceCaptureRunId
          AND ISNULL(s.Value, N'') = ISNULL(t.Value, N'')
          /* v2.4.1: apply the SAME Database/Exclude filter as the difference
             rule above. Without it this PASS counted scoped-configuration
             values for databases the report elsewhere states were excluded
             from all comparisons - inflating the reassuring number with rows
             that were never compared. */
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND s.DatabaseName LIKE x.NamePattern)
        HAVING COUNT(*) > 0;

        /* Query Store: on by default from SQL 2022, so a 2016 -> 2025 move
           legitimately changes it - but the change is material and belongs in
           front of a human rather than being discovered in production. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'UpgradeBehaviour', N'Database', ISNULL(s.DatabaseName, t.DatabaseName), N'QueryStore',
               N'MANUAL REVIEW',
               /* v2.4.2b: when the ONLY change is Query Store coming on at the
                  target - the SQL 2022+ default, which this rule's own text
                  calls "expected on upgrade" - it is Informational and does
                  not vote. An ERROR state, or any other divergence, keeps its
                  original weight. */
               CASE WHEN ISNULL(t.ActualStateDesc, N'OFF') = N'ERROR' THEN N'High'
                    WHEN ISNULL(s.ActualStateDesc, N'OFF') <> N'READ_WRITE'
                         AND ISNULL(t.ActualStateDesc, N'OFF') = N'READ_WRITE' THEN N'Informational'
                    ELSE N'Medium' END,
               ISNULL(s.ActualStateDesc, N'(not reported)')
                 + N' / capture=' + ISNULL(s.QueryCaptureMode, N'-')
                 + N' / maxstorage=' + CONVERT(nvarchar(20), ISNULL(s.MaxStorageMB, 0)) + N' MB',
               ISNULL(t.ActualStateDesc, N'(not reported)')
                 + N' / capture=' + ISNULL(t.QueryCaptureMode, N'-')
                 + N' / maxstorage=' + CONVERT(nvarchar(20), ISNULL(t.MaxStorageMB, 0)) + N' MB',
               CASE WHEN ISNULL(t.ActualStateDesc, N'OFF') = N'ERROR'
                    THEN N'Query Store on the target is in the ERROR state - it is collecting nothing and needs to be repaired.'
                    WHEN ISNULL(s.ActualStateDesc, N'OFF') <> N'READ_WRITE' AND ISNULL(t.ActualStateDesc, N'OFF') = N'READ_WRITE'
                    THEN N'Query Store is now ON for this database (default from SQL 2022) where it was not on the source. This is expected on upgrade, but it changes plan capture and storage behaviour - confirm the capture mode and storage cap suit this workload.'
                    ELSE N'The Query Store configuration differs between source and target.' END,
               CASE WHEN ISNULL(t.ActualStateDesc, N'OFF') = N'ERROR'
                    THEN N'ALTER DATABASE ... SET QUERY_STORE CLEAR; then re-enable, and investigate the cause.'
                    ELSE N'Confirm QUERY_CAPTURE_MODE and MAX_STORAGE_SIZE_MB are deliberate for this database.' END
        FROM (SELECT * FROM migration.DatabaseQueryStore WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN
             (SELECT * FROM migration.DatabaseQueryStore WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.DatabaseName = s.DatabaseName
        WHERE s.DatabaseName IS NOT NULL AND t.DatabaseName IS NOT NULL
          AND (ISNULL(s.ActualStateDesc, N'') <> ISNULL(t.ActualStateDesc, N'')
            OR ISNULL(s.QueryCaptureMode, N'') <> ISNULL(t.QueryCaptureMode, N'')
            /* v2.4.2b: MaxStorageMB was captured and never compared - while
               this rule's own RecommendedAction says "Confirm QUERY_CAPTURE_MODE
               and MAX_STORAGE_SIZE_MB are deliberate". A target left at the
               100 MB default against a source using 10 GB fills, flips itself
               to READ_ONLY weeks later, and the plan-regression history the
               upgrade depends on is gone. */
            OR ISNULL(s.MaxStorageMB, 0) <> ISNULL(t.MaxStorageMB, 0))
          AND NOT EXISTS (SELECT 1 FROM #Exception AS x
                          WHERE x.Scope = N'Database' AND x.TreatAs = N'Exclude'
                            AND s.DatabaseName LIKE x.NamePattern);
    END

    /* v2.4: this was the ONLY section in the file with no SectionSkipped
       marker - a bare "IF NOT EXISTS" that produced nothing at all when the
       module had failed, a hole in the "never skip silently" invariant every
       other section enforces. Severity Low, because the module is optional and
       must not force INCOMPLETE VALIDATION. */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DeprecatedFeatures')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'DeprecatedFeatures', N'ComparisonSection', N'DeprecatedFeatures', N'SectionSkipped', N'SKIPPED', N'Low',
                N'The DeprecatedFeatures module failed on at least one side; deprecated-feature usage was NOT assessed.',
                N'Fix the capture error (VIEW SERVER STATE) and re-capture.');

    /* one aggregated row (top 15 by use) - dozens of per-counter rows would
       clutter the report for what is a single review task */
    IF NOT EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DeprecatedFeatures')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, Explanation, RecommendedAction)
        SELECT N'DeprecatedFeatures', N'DeprecatedFeature', @SrcServer, N'DeprecatedFeatureUse',
               N'MANUAL REVIEW', N'Informational',
               /* v2.4: LEFT()-guarded like every other composed list in this
                  file - it was the one site that was not, and under
                  XACT_ABORT a string-truncation error here would abort the
                  entire comparison rather than shortening one message. */
               LEFT(STUFF((SELECT TOP (15) N', ' + df.FeatureName + N' (' + CONVERT(nvarchar(20), df.UsageCount) + N')'
                      FROM migration.DeprecatedFeature AS df
                      WHERE df.CaptureRunId = @SourceCaptureRunId
                      ORDER BY df.UsageCount DESC
                      FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), 4000),
               N'The SOURCE instance recorded use of ' + CONVERT(nvarchar(10),
                   (SELECT COUNT(*) FROM migration.DeprecatedFeature WHERE CaptureRunId = @SourceCaptureRunId))
                 + N' deprecated feature(s) since its last start-up (top 15 shown with use counts). They may behave differently or be removed on the newer target version.',
               N'Check the SQL Server deprecated-features list for the target version and remediate calling code where needed.'
        WHERE EXISTS (SELECT 1 FROM migration.DeprecatedFeature WHERE CaptureRunId = @SourceCaptureRunId);

    /* v2.4: deprecated features the TARGET no longer counts at all.

       The rule above reads the source only, so a feature the source used and
       the newer engine has REMOVED looked identical to one that still works -
       which is backwards, because removal is the case that breaks code. The
       counter is reset at start-up and reflects usage since then, so a target
       that has served no workload legitimately reports nothing; this therefore
       only fires when the target recorded SOME deprecated usage (proving the
       counters are live) and specific source features are missing from them. */
    IF NOT EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'DeprecatedFeatures')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'DeprecatedFeatures', N'DeprecatedFeature', @TgtServer, N'DeprecatedFeatureRemoved',
               /* v2.4.2b: Informational, not Medium. @ManualActionable counts
                  every non-Informational MANUAL REVIEW, so this rule demoted
                  the verdict - while its own explanation (rewritten in v2.4.1
                  to stop asserting the feature had been removed) says "this
                  comparison cannot tell you either way". A check that states
                  it cannot draw a conclusion must not hold a migration at
                  READY WITH WARNINGS, and measurably it was one of only two
                  items standing between a clean estate and a plain READY.
                  Still reported - just no longer voting. */
               N'MANUAL REVIEW', N'Informational',
               /* v2.4.1: disclose the cap. This list was TOP(15) with no total
                  and no marker, so it read as the complete set. */
               LEFT(STUFF((SELECT TOP (15) N', ' + s.FeatureName
                           FROM migration.DeprecatedFeature AS s
                           WHERE s.CaptureRunId = @SourceCaptureRunId
                             AND NOT EXISTS (SELECT 1 FROM migration.DeprecatedFeature AS t2
                                             WHERE t2.CaptureRunId = @TargetCaptureRunId
                                               AND t2.FeatureName = s.FeatureName)
                           ORDER BY s.UsageCount DESC
                           FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), 3800)
                 + CASE WHEN (SELECT COUNT(*) FROM migration.DeprecatedFeature AS s2
                              WHERE s2.CaptureRunId = @SourceCaptureRunId
                                AND NOT EXISTS (SELECT 1 FROM migration.DeprecatedFeature AS t3
                                                WHERE t3.CaptureRunId = @TargetCaptureRunId
                                                  AND t3.FeatureName = s2.FeatureName)) > 15
                        THEN N' ... (top 15 by usage shown of '
                           + CONVERT(nvarchar(10), (SELECT COUNT(*) FROM migration.DeprecatedFeature AS s3
                                                    WHERE s3.CaptureRunId = @SourceCaptureRunId
                                                      AND NOT EXISTS (SELECT 1 FROM migration.DeprecatedFeature AS t4
                                                                      WHERE t4.CaptureRunId = @TargetCaptureRunId
                                                                        AND t4.FeatureName = s3.FeatureName)))
                           + N' total)' ELSE N'' END,
               N'no usage recorded on the target since it last started',
               /* v2.4.1: this text used to assert the feature had been REMOVED
                  from the target engine and that "code depending on it will
                  fail, not warn". That was FALSE, and it fired on virtually
                  every pre-cutover run.

                  The capture stores only counters with cntr_value > 0 (02),
                  so a feature absent from the target's rows means only "the
                  target has not exercised it since it last started" - the
                  normal state of a freshly restored server carrying no
                  application traffic. Nothing here can distinguish a removed
                  counter from an unused one, so the finding must not claim to. */
               N'The SOURCE used this deprecated feature, and the TARGET has recorded no use of it since it last started. That is expected if the target is not yet serving traffic, so this is NOT evidence the feature was removed - it simply means this comparison cannot tell you either way. Deprecated features are removed on a published schedule; check the list for the target version.',
               N'Confirm against the target version''s deprecated/discontinued-features list whether the calling code needs remediation before cutover.'
        WHERE EXISTS (SELECT 1 FROM migration.DeprecatedFeature WHERE CaptureRunId = @TargetCaptureRunId)
          AND EXISTS (SELECT 1 FROM migration.DeprecatedFeature AS s
                      WHERE s.CaptureRunId = @SourceCaptureRunId
                        AND NOT EXISTS (SELECT 1 FROM migration.DeprecatedFeature AS t2
                                        WHERE t2.CaptureRunId = @TargetCaptureRunId
                                          AND t2.FeatureName = s.FeatureName));

    /* ======================================================================
       Section: UserMessages (v2.5) - user-defined messages live in master and
       do NOT travel with a user-database restore.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'UserMessages')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'SystemDbObjects', N'ComparisonSection', N'UserMessages', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The UserMessages module failed on at least one side; user-defined message checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
    BEGIN
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDbObjects', N'UserMessage', @TgtServer, N'UserMessagesMissing',
               N'FAIL', N'High',
               CONVERT(nvarchar(10), COUNT(*)) + N' message(s) on the source',
               N'absent on the target',
               LEFT(CONVERT(nvarchar(10), COUNT(*))
                 + N' user-defined message(s) (sp_addmessage, id >= 50000) exist on the source and NOT on the target. sys.messages lives in master and does not travel with a user-database restore, so any RAISERROR against these ids fails on the target with error 2758, and any Agent alert watching one never fires. Message ids: '
                 + ISNULL(STUFF((SELECT N', ' + CONVERT(nvarchar(12), sm2.MessageId)
                                 FROM (SELECT DISTINCT sm3.MessageId FROM migration.UserMessage AS sm3
                                       WHERE sm3.CaptureRunId = @SourceCaptureRunId
                                         AND NOT EXISTS (SELECT 1 FROM migration.UserMessage tm3
                                                         WHERE tm3.CaptureRunId = @TargetCaptureRunId
                                                           AND tm3.MessageId = sm3.MessageId)) AS sm2
                                 ORDER BY sm2.MessageId
                                 FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'?'), 1900)
                 + N'.',
               N'Script them from the source (sp_addmessage) and run it on the target.'
        FROM (SELECT DISTINCT sm.MessageId FROM migration.UserMessage AS sm
              WHERE sm.CaptureRunId = @SourceCaptureRunId
                AND NOT EXISTS (SELECT 1 FROM migration.UserMessage tm
                                WHERE tm.CaptureRunId = @TargetCaptureRunId
                                  AND tm.MessageId = sm.MessageId)) AS miss
        HAVING COUNT(*) > 0;

        /* text / severity drift on messages that DO exist on both sides */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDbObjects', N'UserMessage',
               CONVERT(nvarchar(12), s.MessageId), N'UserMessageDefinition',
               N'WARNING', N'Medium',
               N'sev=' + CONVERT(nvarchar(5), ISNULL(s.Severity, 0)) + N' logged=' + CONVERT(nvarchar(5), ISNULL(s.IsEventLogged, 0))
                 + N': ' + LEFT(ISNULL(s.MessageText, N''), 500),
               N'sev=' + CONVERT(nvarchar(5), ISNULL(t.Severity, 0)) + N' logged=' + CONVERT(nvarchar(5), ISNULL(t.IsEventLogged, 0))
                 + N': ' + LEFT(ISNULL(t.MessageText, N''), 500),
               N'This user-defined message exists on both sides but its text, severity or event-logging flag differs. Code that raises it behaves differently on the target.',
               N'Re-run sp_addmessage with @replace = ''replace'' using the source definition.'
        FROM migration.UserMessage AS s
        JOIN migration.UserMessage AS t
          ON t.CaptureRunId = @TargetCaptureRunId
         AND t.MessageId = s.MessageId AND t.LanguageId = s.LanguageId
        WHERE s.CaptureRunId = @SourceCaptureRunId
          AND (ISNULL(s.MessageText, N'') <> ISNULL(t.MessageText, N'')
            OR ISNULL(s.Severity, 0) <> ISNULL(t.Severity, 0)
            OR ISNULL(s.IsEventLogged, 0) <> ISNULL(t.IsEventLogged, 0));

        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation)
        SELECT N'SystemDbObjects', N'UserMessage', @TgtServer, N'UserMessagesPresent', N'PASS', N'Informational',
               CONVERT(nvarchar(10), COUNT(*)) + N' user-defined message(s) are present on the target.'
        FROM (SELECT DISTINCT sm.MessageId FROM migration.UserMessage AS sm
              WHERE sm.CaptureRunId = @SourceCaptureRunId
                AND EXISTS (SELECT 1 FROM migration.UserMessage tm
                            WHERE tm.CaptureRunId = @TargetCaptureRunId AND tm.MessageId = sm.MessageId)) AS ok
        HAVING COUNT(*) > 0;
    END

    /* ======================================================================
       Section: BackupDevices (v2.5) - master-resident, do not travel.
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'BackupDevices')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'SystemDbObjects', N'ComparisonSection', N'BackupDevices', N'SectionSkipped', N'SKIPPED', N'Medium',
                N'The BackupDevices module failed on at least one side; backup-device checks were skipped.',
                N'Fix the capture error and re-capture.');
    ELSE
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation, RecommendedAction)
        SELECT N'SystemDbObjects', N'BackupDevice', ISNULL(s.DeviceName, t.DeviceName), N'BackupDevice',
               CASE WHEN t.DeviceName IS NULL THEN N'FAIL'
                    WHEN s.DeviceName IS NULL THEN N'TARGET ONLY'
                    ELSE N'WARNING' END,
               CASE WHEN t.DeviceName IS NULL THEN N'High'
                    WHEN s.DeviceName IS NULL THEN N'Low' ELSE N'Medium' END,
               CASE WHEN s.DeviceName IS NULL THEN NULL
                    ELSE ISNULL(s.DeviceTypeDesc, N'?') + N' -> ' + ISNULL(s.PhysicalName, N'?') END,
               CASE WHEN t.DeviceName IS NULL THEN NULL
                    ELSE ISNULL(t.DeviceTypeDesc, N'?') + N' -> ' + ISNULL(t.PhysicalName, N'?') END,
               CASE WHEN t.DeviceName IS NULL
                    THEN N'This named backup device exists on the source and not on the target. sys.backup_devices lives in master and does not travel with a user-database restore, so any job written as BACKUP ... TO [' + ISNULL(s.DeviceName, N'?') + N'] fails on the target - and because the step command text is byte-identical on both sides, the job-step comparison cannot see it.'
                    WHEN s.DeviceName IS NULL THEN N'This backup device exists only on the target.'
                    ELSE N'This backup device points at a different physical path or device type on the target.' END,
               CASE WHEN t.DeviceName IS NULL THEN N'sp_addumpdevice on the target using the same logical name.'
                    WHEN s.DeviceName IS NOT NULL THEN N'Confirm the target path is intended.' END
        FROM (SELECT * FROM migration.BackupDevice WHERE CaptureRunId = @SourceCaptureRunId) AS s
        FULL OUTER JOIN (SELECT * FROM migration.BackupDevice WHERE CaptureRunId = @TargetCaptureRunId) AS t
          ON t.DeviceName = s.DeviceName
        WHERE s.DeviceName IS NULL OR t.DeviceName IS NULL
           OR ISNULL(s.PhysicalName, N'') <> ISNULL(t.PhysicalName, N'')
           OR ISNULL(s.DeviceTypeDesc, N'') <> ISNULL(t.DeviceTypeDesc, N'');

    /* ======================================================================
       Section: Baselines - before/after performance snapshot (informational;
       target values are only meaningful once it runs the real workload)
       ====================================================================== */
    IF EXISTS (SELECT 1 FROM #ModErr WHERE ModuleName = N'Baselines')
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity, Explanation, RecommendedAction)
        VALUES (N'Baselines', N'ComparisonSection', N'Baselines', N'SectionSkipped', N'SKIPPED', N'Low',
                N'The Baselines module failed on at least one side; performance-baseline snapshots were skipped.',
                N'Fix the capture error (VIEW SERVER STATE) and re-capture.');
    ELSE
        /* v2.4.2b: ONE row, not one per metric.
           This rule had no WHERE at all, so every captured metric produced a
           finding whether or not the two values differed - and the IoLatencyMs
           metric NAME embeds the drive letter, so a source on E:\ and a target
           on D:\ never joined and each appeared as its own half-empty row. The
           explanation itself says the target numbers are not yet interpretable
           (an idle, pre-cutover instance), so this is reference material for
           the DBA to revisit after go-live, not N items on a cutover
           checklist. All pairs are now rendered inside a single row. */
        INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                         SourceValue, TargetValue, Explanation)
        SELECT N'Baselines', N'BaselineMetric', @TgtServer, N'Baseline',
               N'MANUAL REVIEW', N'Informational',
               LEFT(ISNULL(STUFF((SELECT N' | ' + b.MetricName + N'=' + ISNULL(b.MetricValue, N'?')
                                  FROM migration.BaselineMetric AS b
                                  WHERE b.CaptureRunId = @SourceCaptureRunId
                                  ORDER BY b.MetricName
                                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 3, N''), N'(none captured)'), 3900),
               LEFT(ISNULL(STUFF((SELECT N' | ' + b.MetricName + N'=' + ISNULL(b.MetricValue, N'?')
                                  FROM migration.BaselineMetric AS b
                                  WHERE b.CaptureRunId = @TargetCaptureRunId
                                  ORDER BY b.MetricName
                                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 3, N''), N'(none captured)'), 3900),
               N'Point-in-time performance baseline, captured on both sides for before/after comparison. The target values reflect its CURRENT state, which before cutover is usually an idle instance, so they are NOT yet comparable - re-capture on the target after go-live to make this meaningful. Nothing here is a cutover decision.'
        WHERE EXISTS (SELECT 1 FROM migration.BaselineMetric
                      WHERE CaptureRunId IN (@SourceCaptureRunId, @TargetCaptureRunId));

    /* ======================================================================
       Rule-exception audit trail: every exception that fired is VISIBLE.
       Nothing is ever suppressed silently.
       ====================================================================== */
    INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                     SourceValue, Explanation, ExceptionId)
    SELECT N'RuleExceptions', N'RuleException',
           LEFT(x.Scope + N': ' + x.NamePattern, 400), N'ExceptionApplied',
           N'EXPECTED DIFFERENCE', N'Informational',
           CONVERT(nvarchar(10), x.Hits) + N' object(s) matched',
           LEFT(N'Rule exception applied (' + x.TreatAs + N'): ' + x.Reason
             + N' - added by ' + ISNULL((SELECT AddedBy FROM migration.RuleException re WHERE re.ExceptionId = x.ExceptionId), N'?') + N'.', 2000),
           x.ExceptionId
    FROM #Exception AS x
    WHERE x.Hits > 0
      /* v2.4.2b: the only one of the seven exception rules that lacked this.
         The installer seeds 13 prophylactic exceptions (NT SERVICE, ##MS_,
         msdb.dbo.syspolicy%, spt_%, ...); on a stock install where the
         operator had authored nothing, those still matched objects and this
         rule emitted a row for each, filling the RuleExceptions category with
         "exception applied" entries about decisions nobody made. Every sibling
         - Databases, Logins, Agent, LinkedServers, SystemDbObjects and
         ExceptionMatchedNothing - already excludes install-seed, as does
         @ExcUserApplied in the verdict. */
      AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re
                  WHERE re.ExceptionId = x.ExceptionId), N'') <> N'install-seed';

    /* v2.3: an enabled, supported-scope exception that matched NOTHING is
       probably stale or mistyped - say so instead of staying silent.

       v2.4 corrects WHICH counter decides that. It used to test Hits = 0, but
       for a TreatAs='Expected' exception Hits counts the FINDINGS IT
       DOWNGRADED, not the objects its pattern matched. So an "Expected"
       exception covering a database that was correctly present on the target
       downgraded nothing, ended at zero hits, and was reported as stale or
       mistyped - i.e. the tool told you your exception was broken precisely
       BECAUSE the migration had succeeded. Exactly backwards.

       It also fired for every exception in a section whose module had failed,
       because the hit accounting lives inside each section's ELSE branch.

       Matched (does the pattern hit any object?) and SectionRan (did the
       owning section execute?) are computed up front and answer both
       questions properly. */
    INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                     SourceValue, Explanation, RecommendedAction, ExceptionId)
    SELECT N'RuleExceptions', N'RuleException',
           LEFT(x.Scope + N': ' + x.NamePattern, 400), N'ExceptionMatchedNothing',
           N'MANUAL REVIEW', N'Informational',
           N'0 objects matched',
           LEFT(N'This enabled rule exception (' + x.TreatAs + N') matched no object on either side. It may be stale, or the pattern may be mistyped (remember: _ and [ are LIKE wildcards - escape them as [_] and [[]).', 2000),
           N'Fix or remove the exception.',
           x.ExceptionId
    FROM #Exception AS x
    WHERE x.Matched = 0
      AND x.SectionRan = 1
      AND x.Scope IN (N'Database', N'Login', N'AgentJob', N'LinkedServer', N'SystemDbObject')
      /* seeded exceptions are prophylactic - matching nothing is their normal state */
      AND ISNULL((SELECT AddedBy FROM migration.RuleException re WHERE re.ExceptionId = x.ExceptionId),
                 N'') <> N'install-seed';

    /* v2.4: an exception whose pattern DOES match objects but whose owning
       section never ran is neither "applied" nor "stale" - it is unevaluated,
       and saying nothing at all would repeat the silence this whole mechanism
       exists to prevent. */
    INSERT #Finding (Category, ObjectType, ObjectName, CheckName, Status, Severity,
                     SourceValue, Explanation, RecommendedAction, ExceptionId)
    SELECT N'RuleExceptions', N'RuleException',
           LEFT(x.Scope + N': ' + x.NamePattern, 400), N'ExceptionNotEvaluated',
           N'SKIPPED', N'Low',
           CONVERT(nvarchar(10), x.Matched) + N' object(s) matched',
           LEFT(N'This rule exception applies to a section whose capture module failed, so it was never evaluated. Whatever it would have excluded or reclassified is unknown for this comparison.', 2000),
           N'Fix the capture error and re-compare.',
           x.ExceptionId
    FROM #Exception AS x
    WHERE x.SectionRan = 0
      AND x.Scope IN (N'Database', N'Login', N'AgentJob', N'LinkedServer', N'SystemDbObject');

    /* ======================================================================
       v2.6: re-label section skips that are engine-version gaps, not failures

       Twenty-seven sections each write their own "SectionSkipped" finding when
       their module is in #ModErr. Editing all twenty-seven to ask WHY would be
       twenty-seven chances to get it wrong and to drift apart later; this does
       it once, centrally, from the same #ModErr the sections themselves gate
       on, so a section added tomorrow inherits the behaviour for free.

       The condition is deliberately strict. A section is re-labelled only when
       EVERY #ModErr row for that module, on EITHER side, says not-applicable.
       If the source lacks the feature and the target genuinely failed to
       collect it, the row stays SKIPPED - there is a real problem there, and
       softening it is exactly the kind of quiet downgrade this tool exists to
       prevent.

       Severity matters as much as status here: @Incomplete is driven by
       SKIPPED findings at High or Medium, so without the severity change a
       clean SQL 2014 source would report INCOMPLETE VALIDATION rather than
       READY - a verdict that reads as "we could not check" when the truth is
       "there was nothing there to check".
       ====================================================================== */
    UPDATE f
    SET f.Status      = N'NOT APPLICABLE',
        f.Severity    = N'Informational',
        f.Explanation = LEFT(N'Not applicable on this engine version, rather than skipped: '
                           + N'the capture recorded that the feature does not exist on the '
                           + N'source or target engine, so there is nothing to compare. '
                           + N'See the CaptureErrors finding for ''' + f.ObjectName
                           + N''' for what that version offers instead. Original note: '
                           + f.Explanation, 2000),
        f.RecommendedAction = N'No action: this is a difference in engine capability, not a gap in the validation.'
    FROM #Finding AS f
    WHERE f.ObjectType = N'ComparisonSection'
      AND f.CheckName  = N'SectionSkipped'
      AND f.Status     = N'SKIPPED'
      AND EXISTS (SELECT 1 FROM #ModErr AS me WHERE me.ModuleName = f.ObjectName)
      AND NOT EXISTS (SELECT 1 FROM #ModErr AS me
                      WHERE me.ModuleName = f.ObjectName AND me.IsNotApplicable = 0);

    /* ======================================================================
       Verdict
       ====================================================================== */
    DECLARE @Blockers int, @Fails int, @Warns int, @Manual int, @SrcOnly int,
            @TgtOnly int, @Skipped int, @CollErr int, @Expected int, @Passed int,
            @Total int, @ExcApplied int, @NotApplicable int;
    SELECT @Total    = COUNT(*),
           @Passed   = SUM(CASE WHEN Status = N'PASS' THEN 1 ELSE 0 END),
           @Fails    = SUM(CASE WHEN Status = N'FAIL' THEN 1 ELSE 0 END),
           @Warns    = SUM(CASE WHEN Status = N'WARNING' THEN 1 ELSE 0 END),
           @Manual   = SUM(CASE WHEN Status = N'MANUAL REVIEW' THEN 1 ELSE 0 END),
           @SrcOnly  = SUM(CASE WHEN Status = N'SOURCE ONLY' THEN 1 ELSE 0 END),
           @TgtOnly  = SUM(CASE WHEN Status = N'TARGET ONLY' THEN 1 ELSE 0 END),
           @Skipped  = SUM(CASE WHEN Status = N'SKIPPED' THEN 1 ELSE 0 END),
           @CollErr  = SUM(CASE WHEN Status = N'COLLECTION ERROR' THEN 1 ELSE 0 END),
           @Expected = SUM(CASE WHEN Status = N'EXPECTED DIFFERENCE' THEN 1 ELSE 0 END),
           /* v2.6: counted so the breakdown still reconciles with TotalChecks.
              Deliberately absent from the verdict expression below - an
              absence the engine cannot have is not a warning. */
           @NotApplicable = SUM(CASE WHEN Status = N'NOT APPLICABLE' THEN 1 ELSE 0 END),
           @Blockers = SUM(CASE WHEN Status = N'FAIL' AND IsBlocker = 1 THEN 1 ELSE 0 END)
    FROM #Finding;
    /* Informational manual-review rows (performance baselines, deprecated
       feature counters) are advisory context - they must not stop a clean
       migration from being assessed plain READY. */
    DECLARE @ManualActionable int =
        (SELECT COUNT(*) FROM #Finding
         WHERE Status = N'MANUAL REVIEW' AND Severity <> N'Informational');
    /* v2.4.1: count OPERATOR-authored exceptions separately from shipped ones.

       @ExcApplied summed Hits across all exceptions including the 13 seeded by
       the installer (NT SERVICE\%, ##MS_%, msdb.dbo.syspolicy%, ...). On a
       stock install where the operator had added NOTHING, the report stated
       "N object(s) were reclassified/excluded by rule exceptions" with N in the
       dozens - which reads as "someone suppressed N findings" and invites an
       audit of a decision nobody made. Those seeded patterns match objects that
       are identical on both sides and would have passed anyway. */
    SELECT @ExcApplied = ISNULL(SUM(Hits), 0) FROM #Exception;
    DECLARE @ExcUserApplied int = ISNULL((
        SELECT SUM(x.Hits) FROM #Exception AS x
        WHERE ISNULL((SELECT re.AddedBy FROM migration.RuleException re WHERE re.ExceptionId = x.ExceptionId), N'')
              <> N'install-seed'), 0);
    DECLARE @ExcUserRules int = ISNULL((
        SELECT COUNT(*) FROM #Exception AS x
        WHERE x.Hits > 0
          AND ISNULL((SELECT re.AddedBy FROM migration.RuleException re WHERE re.ExceptionId = x.ExceptionId), N'')
              <> N'install-seed'), 0);

    DECLARE @Incomplete bit =
        CASE WHEN @SrcComplete = 0 OR @TgtComplete = 0
               OR EXISTS (SELECT 1 FROM #Finding WHERE Status = N'SKIPPED'
                          AND Severity IN (N'High', N'Medium'))
             THEN 1 ELSE 0 END;

    DECLARE @Assessment nvarchar(30) =
        CASE WHEN @Blockers > 0 OR @Fails > 0 THEN N'NOT READY'
             WHEN @Incomplete = 1             THEN N'INCOMPLETE VALIDATION'
             WHEN @Warns + @ManualActionable + @SrcOnly + @TgtOnly + @CollErr > 0 THEN N'READY WITH WARNINGS'
             ELSE N'READY' END;

    DECLARE @Reasons nvarchar(4000) = N'';
    /* v2.4.1: disclose the cap, and account for non-blocking failures.
       This sentence used to print "N cutover blocker(s):" followed by exactly
       five names with no ellipsis and no "first 5 of N" - a reader working the
       list from the summary silently lost the rest. It also omitted @Fails
       entirely, so 3 blockers alongside 40 other failures read as 3 items. */
    IF @Blockers > 0
        SET @Reasons = CONVERT(nvarchar(10), @Blockers) + N' cutover blocker(s)'
            + CASE WHEN @Blockers > 5 THEN N' (first 5 of ' + CONVERT(nvarchar(10), @Blockers) + N' shown)' ELSE N'' END
            + N': '
            + ISNULL(STUFF((SELECT TOP (5) N'; ' + f.Category + N'/' + f.ObjectName + N' (' + f.CheckName + N')'
                            FROM #Finding AS f WHERE f.Status = N'FAIL' AND f.IsBlocker = 1
                            ORDER BY f.Category, f.ObjectName
                            FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'')
            + CASE WHEN @Fails > @Blockers
                   THEN N'. There are also ' + CONVERT(nvarchar(10), @Fails - @Blockers)
                      + N' other failed check(s) that are not cutover blockers.' ELSE N'.' END;
    ELSE IF @Fails > 0
        SET @Reasons = CONVERT(nvarchar(10), @Fails) + N' failed check(s) must be resolved before cutover.';
    ELSE IF @Incomplete = 1
        SET @Reasons = N'Capture modules failed or sections were skipped - the validation is incomplete and cannot certify readiness.';
    /* v2.4.1: the reason must name EVERY term that produced the verdict.

       This sentence used to list only warnings and actionable manual reviews,
       but the verdict is driven by five terms. A 2016 -> 2025 migration
       reliably produces TARGET ONLY rows (every sp_configure option new in the
       target version), so the report routinely read:

           VERDICT: READY WITH WARNINGS
           REASON : 0 warning(s) and 0 actionable manual-review item(s).

       An executive asking "which warnings?" was answered "none". */
    ELSE IF @Assessment = N'READY WITH WARNINGS'
    BEGIN
        SET @Reasons = N'';
        IF @Warns > 0            SET @Reasons = @Reasons + CONVERT(nvarchar(10), @Warns) + N' warning(s), ';
        IF @ManualActionable > 0 SET @Reasons = @Reasons + CONVERT(nvarchar(10), @ManualActionable) + N' manual-review item(s) needing a decision, ';
        IF @SrcOnly > 0          SET @Reasons = @Reasons + CONVERT(nvarchar(10), @SrcOnly) + N' object(s) present only on the source, ';
        IF @TgtOnly > 0          SET @Reasons = @Reasons + CONVERT(nvarchar(10), @TgtOnly) + N' object(s) present only on the target, ';
        IF @CollErr > 0          SET @Reasons = @Reasons + CONVERT(nvarchar(10), @CollErr) + N' collection error(s), ';
        /* Trim the trailing ", ". NOTE: LEN() ignores trailing spaces in T-SQL
           while LEFT() counts them, so LEN(@Reasons) - 2 cuts one character too
           many and eats the last letter of the sentence. Appending a sentinel
           inside LEN() makes the trailing space significant again. */
        SET @Reasons = LEFT(@Reasons, LEN(@Reasons + N'|') - 3)
                     + N' to work through. Nothing failed and no cutover blocker was found.';
    END
    ELSE
    BEGIN
        /* v2.4.1: "All compared checks passed." was asserted while rows that
           did NOT pass were on the page. READY tolerates Informational
           manual-review rows, Low-severity SKIPPED sections and any number of
           EXPECTED DIFFERENCE rows - none of which passed, and the skipped
           ones were never compared at all. State what is actually true. */
        SET @Reasons = N'No failed checks, no cutover blockers, and nothing needing a decision.';
        IF @Expected > 0
            SET @Reasons = @Reasons + N' ' + CONVERT(nvarchar(10), @Expected)
                         + N' difference(s) were classified as expected for this migration.';
        IF @Manual - @ManualActionable > 0
            SET @Reasons = @Reasons + N' ' + CONVERT(nvarchar(10), @Manual - @ManualActionable)
                         + N' informational item(s) are listed for reference only.';
        IF @Skipped > 0
            SET @Reasons = @Reasons + N' NOTE: ' + CONVERT(nvarchar(10), @Skipped)
                         + N' optional check(s) were SKIPPED and therefore not verified - see the Skipped rows.';
    END

    /* v2.4: NOT READY used to hide incompleteness completely.

       Verdict precedence puts failures first, so a run that both failed checks
       AND had capture modules fail reported "N failed check(s) must be
       resolved" and said nothing about the gaps. Someone fixes the listed
       failures, re-runs, and gets a DIFFERENT verdict out of data that was
       never fully collected in the first place. The precedence is right - a
       blocker is still the headline - but the incompleteness has to travel
       with it. */
    IF @Assessment = N'NOT READY' AND @Incomplete = 1
        SET @Reasons = @Reasons
            + N' WARNING: this comparison is ALSO incomplete - capture modules failed or sections were skipped, '
            + N'so the checks listed above are not the full picture. Fix the capture errors and re-compare as well.';
    /* v2.4.1: only OPERATOR-added exceptions are worth an executive's
       attention - those are the deliberate waivers. The shipped defaults are
       part of the tool's normal operation and saying "N objects were
       reclassified" about them reads as a suppression nobody authorised. */
    IF @ExcUserApplied > 0
        SET @Reasons = @Reasons + N' NOTE: ' + CONVERT(nvarchar(10), @ExcUserRules)
                     + N' operator-added rule exception(s) reclassified or excluded '
                     + CONVERT(nvarchar(10), @ExcUserApplied)
                     + N' object(s) from this comparison (see the RuleExceptions category).';

    /* ======================================================================
       Persist + return
       ====================================================================== */
    /* SET XACT_ABORT ON (proc top) + TRY/CATCH: a mid-persist error (lock
       timeout, truncation, ...) must roll BOTH inserts back and surface -
       never commit a ComparisonRun with missing findings. */
    BEGIN TRY
        BEGIN TRANSACTION;
        INSERT migration.ComparisonRun (SourceCaptureRunId, TargetCaptureRunId, CompareDateUtc,
            ToolVersion, Assessment, AssessmentReasons, TotalChecks, Passed, Failed, Warnings,
            ExpectedDiffs, SourceOnly, TargetOnly, ManualReview, Skipped, CollectionErrors,
            NotApplicable, Blockers, ExceptionsApplied)
        VALUES (@SourceCaptureRunId, @TargetCaptureRunId, SYSUTCDATETIME(),
            @ToolVersion, @Assessment, @Reasons, @Total, @Passed, @Fails, @Warns,
            @Expected, @SrcOnly, @TgtOnly, @Manual, @Skipped, @CollErr,
            @NotApplicable, @Blockers, @ExcApplied);
        SET @ComparisonRunId = SCOPE_IDENTITY();

        INSERT migration.Finding (ComparisonRunId, Category, ObjectType, ObjectName, SubObjectName,
            CheckName, Status, Severity, IsBlocker, SourceValue, TargetValue, Explanation,
            RecommendedAction, ExceptionId)
        SELECT @ComparisonRunId, Category, ObjectType, ObjectName, SubObjectName,
            CheckName, Status, Severity, IsBlocker, SourceValue, TargetValue, Explanation,
            RecommendedAction, ExceptionId
        FROM #Finding;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SET @ComparisonRunId = NULL;
        DECLARE @PersistError nvarchar(2000) = ERROR_MESSAGE();
        RAISERROR(N'The comparison ran but its results could NOT be persisted (nothing was saved): %s', 16, 1, @PersistError);
        RETURN 1;
    END CATCH;

    /* result set 1: the verdict */
    SELECT @ComparisonRunId AS ComparisonRunId, @Assessment AS Assessment, @Reasons AS AssessmentReasons,
           @SrcServer AS SourceServer, @SrcVersion AS SourceVersion,
           @TgtServer AS TargetServer, @TgtVersion AS TargetVersion,
           @Total AS TotalChecks, @Passed AS Passed, @Fails AS Failed, @Blockers AS CutoverBlockers,
           @Warns AS Warnings, @Manual AS ManualReview, @Expected AS ExpectedDifferences,
           @SrcOnly AS SourceOnly, @TgtOnly AS TargetOnly, @Skipped AS Skipped,
           @CollErr AS CollectionErrors, @ExcApplied AS ExceptionsApplied;

    /* result set 2: findings, most severe first */
    SELECT Category, ObjectType, ObjectName, SubObjectName, CheckName, Status, Severity,
           IsBlocker, SourceValue, TargetValue, Explanation, RecommendedAction, ExceptionId
    FROM #Finding
    ORDER BY CASE Status WHEN N'FAIL' THEN 0 WHEN N'COLLECTION ERROR' THEN 1 WHEN N'WARNING' THEN 2
                         WHEN N'MANUAL REVIEW' THEN 3 WHEN N'TARGET ONLY' THEN 4 WHEN N'SOURCE ONLY' THEN 5
                         WHEN N'EXPECTED DIFFERENCE' THEN 6 WHEN N'SKIPPED' THEN 7 ELSE 8 END,
             CASE Severity WHEN N'Critical' THEN 0 WHEN N'High' THEN 1 WHEN N'Medium' THEN 2
                           WHEN N'Low' THEN 3 ELSE 4 END,
             Category, ObjectName;

    RETURN 0;
END

