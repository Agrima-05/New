SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF



CREATE PROCEDURE [dbo].[AutoBilling_Process_NEW]
as 
BEGIN

-------DELETE ARCHIVED JOBS------

	DELETE A
	--Select A.* --, B.*
	FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	inner join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	A.TicketNumber = B.TicketNumber
	and 
	A.BillingDate = B.BillingDate
	and 
	ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	and
	ISNULL(A.TotalBillableUnits,'') = ISNULL(B.TotalBillableUnits,'')
	and A.createdate = B.createdate
	--where A.CreateDate < '2021-05-24'
    WHERE A.BillingDate IS NOT NULL --AND BillingOption != 'N/A - Non-billable'



-----------------Everything in the queue ---------------

--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
--where BillingDate is not null


Select A.ID,A.TicketNumber,A.CustomerName, A.CreateDate,A.BatchType,B.Title,CUrrent_x0020_Status as Status
, A.TotalRecords, A.BillingOption,A.TotalWithEventsFound,A.TotalMatched,A.TotalBillableUnits, A.AccountNumber
,A.[CMASProductName]
,A.CMASProductCOde, 
Replace(Product,';#','') as Product
,A.OracleProductCode, A.ContractExecuted
,A.DocImageCounts
,Billing_x0020_Type as Billing_Type
,Billing_x0020_Number as CustomerNumber
,A.BillingDate
,A.NUM_PRODUCTS
,A.Product1
,A.Product2
,A.Product3
,B.SOW
,B.WO
,A.BillingDate
,Replace(Assigned_x0020_f,';#',' ') as Assignee
From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
on A.ticketNumber = B.ID
where 
(A.BillingDate is  null or (A.BillingDate > Getdate()-1.25 and A.BillingOption  not like 'Monthly Fee' and A.BillingOption  not like 'N/A - Non-billable'))
and B.CUrrent_x0020_Status not like '18-Request Cancelled'
order by Client_X0020_Name,B.Title, A.TicketNumber,A.CreateDate, A.BatchType




---------------------PROMARKETING DETAILS----------------------------
Select A.[CustomerName],	A.[TicketNumber],	A.[CreateDate],	A.[WO],	A.[TotalRecords],	A.[TotalWithEventsFound],	A.[Per Record],	A.[Per File Min]
,convert(money,A.[TOTAL]) as [TOTAL]
,convert(money,A.[TOTAL PER FILE]) as [TOTAL PER FILE]
,convert(money,A.[TOTAL With MIN]) as [TOTAL With MIN]
,A.[TYPE] FROM (
Select A.[CustomerName],	A.[TicketNumber],	A.[CreateDate],	A.[WO],	A.[TotalRecords],	A.[TotalWithEventsFound],	A.[Per Record],	A.[Per File Min],	A.[TOTAL],A.[TOTAL PER FILE],	A.[Type]
,case when A.ROWNUM = 1 and A.[WO] like '%4A%' and 	convert(bigint,A.[TotalRecords]) <= 550000 AND convert(money,A.[TOTAL PER FILE]) < 1500 then '1500.00'
	  when A.ROWNUM = 1 and A.[WO] like '%4A%' and 	convert(bigint,A.[TotalRecords]) <= 550000 AND convert(money,A.[TOTAL PER FILE]) >= 1500 then convert(money,A.[TOTAL PER FILE])
	  when  A.ROWNUM = 1 and A.[WO] like '%4A%' and 	convert(bigint,A.[TotalRecords]) > 550000 AND convert(money,A.[TOTAL PER FILE]) <  3000 then '3000.00'
	  when  A.ROWNUM = 1 and A.[WO] like '%4A%' and 	convert(bigint,A.[TotalRecords]) > 550000 AND convert(money,A.[TOTAL PER FILE]) >=  3000 then convert(money,A.[TOTAL PER FILE])
	  when  A.ROWNUM = 1 and (A.[WO] like '%6%' OR A.[WO] like '%7%') AND convert(money,A.[TOTAL PER FILE]) < 500 then '500.00'
	  when  A.ROWNUM = 1 and (A.[WO] like '%6%' OR A.[WO] like '%7%') AND convert(money,A.[TOTAL PER FILE]) >= 500 then convert(money,A.[TOTAL PER FILE])
	 when A.ROWNUM = 2 then NULL  else 'LOOK_AT_THESE!!!' end as [TOTAL With MIN]
from (
		Select A.[CustomerName],	A.[TicketNumber],	A.[CreateDate],	A.[WO],	A.[TotalRecords],	A.[TotalWithEventsFound],	A.[Per Record],	A.[Per File Min],	A.[TOTAL],	A.[Type]
		,A.ROWNUM
		,case when A.ROWNUM = 1 then sum(A.[TOTAL] + ISNULL(B.[TOTAL],'0')) else NULL end as [TOTAL PER FILE]
		from 
		(Select A.CustomerName,A.TicketNumber, A.CreateDate,B.WO, A.TotalRecords,A.TotalWithEventsFound
		,case when B.WO like '%4A%' then '$0.005'
				when B.WO like '%4B%' then '$0.003'
				when B.WO like '%6%' or B.WO like '%7%' then '$0.02'
				else 'LOOK_AT_THESE!!!' END as 'Per Record' 
		,case when B.WO like '%4A%' or B.WO like '%4B%' then '1-550K records = $1500, >550K = $3000'
				when B.WO like '%6%' or B.WO like '%7%' then '$500'
				else 'LOOK_AT_THESE!!!' END as 'Per File Min' 
		,case when B.WO like '%4A%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .005)
				when B.WO like '%4B%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .003)
				when B.WO like '%6%' or B.WO like '%7%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .02)
				else 'LOOK_AT_THESE!!!' END as 'TOTAL' 
		,ROW_NUMBER() OVER(Partition by convert(date,A.CreateDate), A.TotalRecords Order by A.CreateDate,A.TotalRecords,B.WO) as ROWNUM
		,case when B.WO like '%4A%' or B.WO like '%4B%' then 'Match&Append'
			when B.WO like '%6%' or B.WO like '%7%' then 'LIST'
			else 'LOOK_AT_THESE!!!' END as 'Type' 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(A.BillingDate is  null or (A.BillingDate > Getdate()-1.25 and A.BillingOption  not like 'Monthly Fee' and A.BillingOption  not like 'N/A - Non-billable'))
		and B.CUrrent_x0020_Status not like '18-Request Cancelled'
		and A.CustomerName like 'Pro%Marketing%' 
		--order by A.CreateDate,A.TotalRecords,B.WO
		)A
		--order by A.CreateDate,A.TotalRecords,A.WO

		left outer join 

		(Select [CustomerName],	[TicketNumber],	[CreateDate],	[WO],	[TotalRecords],	[TotalWithEventsFound],	[Per Record],	[Per File Min],	[TOTAL],	[Type]
		,ROWNUM
		from 
		(Select A.CustomerName,A.TicketNumber, A.CreateDate,B.WO, A.TotalRecords,A.TotalWithEventsFound
		,case when B.WO like '%4A%' then '$0.005'
				when B.WO like '%4B%' then '$0.003'
				when B.WO like '%6%' or B.WO like '%7%' then '$0.02'
				else 'LOOK_AT_THESE!!!' END as 'Per Record' 
		,case when B.WO like '%4A%' or B.WO like '%4B%' then '1-550K records = $1500, >550K = $3000'
				when B.WO like '%6%' or B.WO like '%7%' then '$500'
				else 'LOOK_AT_THESE!!!' END as 'Per File Min' 
		,case when B.WO like '%4A%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .005)
				when B.WO like '%4B%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .003)
				when B.WO like '%6%' or B.WO like '%7%' then convert(money,convert(bigint,A.TotalWithEventsFound) * .02)
				else 'LOOK_AT_THESE!!!' END as 'TOTAL' 
		,ROW_NUMBER() OVER(Partition by convert(date,A.CreateDate), A.TotalRecords Order by A.CreateDate,A.TotalRecords,B.WO) as ROWNUM
		,case when B.WO like '%4A%' or B.WO like '%4B%' then 'Match&Append'
			when B.WO like '%6%' or B.WO like '%7%' then 'LIST'
			else 'LOOK_AT_THESE!!!' END as 'Type' 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(A.BillingDate is  null or (A.BillingDate > Getdate()-1.25 and A.BillingOption  not like 'Monthly Fee' and A.BillingOption  not like 'N/A - Non-billable'))
		and B.CUrrent_x0020_Status not like '18-Request Cancelled'
		and A.CustomerName like 'Pro%Marketing%' 
		--order by A.CreateDate,A.TotalRecords,B.WO
		)A
		where ROWNUM = 2
		--order by A.CreateDate,A.TotalRecords,A.WO
		) B 
		on convert(date,A.[CreateDate]) = convert(date,B.[CreateDate]) and A.TotalREcords = B.TotalRecords
		Group by A.[CustomerName],	A.[TicketNumber],	A.[CreateDate],	A.[WO],	A.[TotalRecords],	A.[TotalWithEventsFound],	A.[Per Record],	A.[Per File Min],	A.[TOTAL],	A.[Type]
		,A.ROWNUM
		--Order by  A.CreateDate,A.TotalRecords,A.WO
)A
)A
Order by  A.CreateDate,A.TotalRecords,A.WO






------Added 20210421 for one time push of records that had to be written elsewhere as CMAS db was put in read only---

INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling(AppSource, BatchId, BatchType, CreateDate, ImportDate, TotalRecords, TotalMatched, TotalUnMatched, TotalDuplicate, TotalExpired, TotalInCoverage, TotalNotInCoverage, TotalPropertiesFound, 
                  TotalPropertiesNotFound, IsBillable, TotalMultiplePropertiesFound, TotalAddressStandardized, TotalAddressNotStandardized, TotalWithEventsFound, TotalWithoutEventsFound, TicketNumber, BillingDate, 
                  ExtractionDate, BillingOption, AccountNumber, DaysToMonitor, CustomerName, ClientName, CMASProductCode, CMASProductName, OracleProductCode, OracleProductName, Title, DocImageCounts, 
                  MonitorEndDate, TotalBillableUnits, ContractExecuted, PRODUCT1, PRODUCT2, PRODUCT3, PROCESSED_YN, NUM_PRODUCTS, CMAS_PRODUCT_SHAREPOINT, STATUS, SOW, WO, STATE, PRODUCT4, 
                  PRODUCT5, PRODUCT6, PRODUCT7, PRODUCT8, PRODUCT9)
SELECT  A.AppSource, A.BatchId, A.BatchType, A.CreateDate, A.ImportDate, A.TotalRecords, A.TotalMatched, A.TotalUnMatched, A.TotalDuplicate, A.TotalExpired, A.TotalInCoverage, A.TotalNotInCoverage, A.TotalPropertiesFound, 
                  A.TotalPropertiesNotFound, A.IsBillable, A.TotalMultiplePropertiesFound, A.TotalAddressStandardized, A.TotalAddressNotStandardized, A.TotalWithEventsFound, A.TotalWithoutEventsFound, A.TicketNumber, A.BillingDate, 
                  A.ExtractionDate, A.BillingOption, A.AccountNumber, A.DaysToMonitor, A.CustomerName, A.ClientName, A.CMASProductCode, A.CMASProductName, A.OracleProductCode, A.OracleProductName, A.Title, A.DocImageCounts, 
                  A.MonitorEndDate, A.TotalBillableUnits, A.ContractExecuted, A.PRODUCT1, A.PRODUCT2, A.PRODUCT3, A.PROCESSED_YN, A.NUM_PRODUCTS, A.CMAS_PRODUCT_SHAREPOINT, A.STATUS, A.SOW, A.WO, A.STATE, A.PRODUCT4, 
                  A.PRODUCT5, A.PRODUCT6, A.PRODUCT7, A.PRODUCT8, A.PRODUCT9
FROM     Data.dbo.AutomatedBilling AS A LEFT OUTER JOIN
                  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling AS B ON A.CustomerName = B.CustomerName AND A.TotalRecords = B.TotalRecords AND A.CreateDate = B.CreateDate
				  left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK)
				  ON A.CustomerName = C.CustomerName AND A.TotalRecords = C.TotalRecords AND A.CreateDate = C.CreateDate
WHERE  (B.TotalREcords IS NULL and C.TotalREcords IS NULL)
Order by CustomerName, CreateDate

--Select * From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where CustomerName like 'Computershare%'
--Order by CreateDate desc


--Select * From  Data.dbo.AutomatedBilling
--where CustomerName like 'Prime Lending%'
--Order by CreateDate desc

--Select * From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling with(NOLOCK)
--where customername like 'Wolter%'


--Delete From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ID = 345121


Select * From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ID = 345121
--Order by CreateDate



--INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling(AppSource, BatchId, BatchType, CreateDate, ImportDate, TotalRecords, TotalMatched, TotalUnMatched, TotalDuplicate, TotalExpired, TotalInCoverage, TotalNotInCoverage, TotalPropertiesFound, 
--                  TotalPropertiesNotFound, IsBillable, TotalMultiplePropertiesFound, TotalAddressStandardized, TotalAddressNotStandardized, TotalWithEventsFound, TotalWithoutEventsFound, TicketNumber, BillingDate, 
--                  ExtractionDate, BillingOption, AccountNumber, DaysToMonitor, CustomerName, ClientName, CMASProductCode, CMASProductName, OracleProductCode, OracleProductName, Title, DocImageCounts, 
--                  MonitorEndDate, TotalBillableUnits, ContractExecuted, PRODUCT1, PRODUCT2, PRODUCT3, PROCESSED_YN, NUM_PRODUCTS, CMAS_PRODUCT_SHAREPOINT, STATUS, SOW, WO, STATE, PRODUCT4, 
--                  PRODUCT5, PRODUCT6, PRODUCT7, PRODUCT8, PRODUCT9)
--SELECT  A.AppSource, A.BatchId, A.BatchType, A.CreateDate, A.ImportDate, A.TotalRecords, A.TotalMatched, A.TotalUnMatched, A.TotalDuplicate, A.TotalExpired, A.TotalInCoverage, A.TotalNotInCoverage, A.TotalPropertiesFound, 
--                  A.TotalPropertiesNotFound, A.IsBillable, A.TotalMultiplePropertiesFound, A.TotalAddressStandardized, A.TotalAddressNotStandardized, A.TotalWithEventsFound, A.TotalWithoutEventsFound, A.TicketNumber, A.BillingDate, 
--                  A.ExtractionDate, A.BillingOption, A.AccountNumber, A.DaysToMonitor, A.CustomerName, A.ClientName, A.CMASProductCode, A.CMASProductName, A.OracleProductCode, A.OracleProductName, A.Title, A.DocImageCounts, 
--                  A.MonitorEndDate, A.TotalBillableUnits, A.ContractExecuted, A.PRODUCT1, A.PRODUCT2, A.PRODUCT3, A.PROCESSED_YN, A.NUM_PRODUCTS, A.CMAS_PRODUCT_SHAREPOINT, A.STATUS, A.SOW, A.WO, A.STATE, A.PRODUCT4, 
--                  A.PRODUCT5, A.PRODUCT6, A.PRODUCT7, A.PRODUCT8, A.PRODUCT9
--FROM     [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling AS A LEFT OUTER JOIN
--                  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling AS B ON A.CustomerName = B.CustomerName AND A.TotalRecords = B.TotalRecords AND A.CreateDate = B.CreateDate
--WHERE  (B.TotalREcords IS NULL)
--Order by CreateDate desc

--Select * From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where CustomerName like 'House Buyers of America, Inc'

--------------------Added 20190522 to include FLAT FEE records per MD-----
----------------------------------------------------

	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,A.Created----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL----TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,A.ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,A.[Billing_x0020_Type]----BillingOption
			,A.Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,A.Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate
			--Select top 100 *
			FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as A 
			left outer join [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling as B on 
			A.ID = B.TicketNumber
			left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
			where A.[Billing_x0020_Type] like 'Flat Fee'
			and CUrrent_x0020_Status like '15-Closed'
			--and A.Modified >= Getdate()-60
			AND (B.TicketNumber is null) --or A.Modified > B.CreateDate
			AND (C.TicketNumber is null) --or A.Modified > C.CreateDate
			--AND Billing_x0020_Number not like ''

				INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,A.Created----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL----TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,A.ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,A.[Billing_x0020_Type]----BillingOption
			,A.Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,A.Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate
			--Select top 100 *
			FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as A 
			left outer join [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling as B on 
			A.ID = B.TicketNumber
			left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
			where A.[Billing_x0020_Type] like 'Flat Fee'
			and CUrrent_x0020_Status like '15-Closed'
			--and A.Modified >= Getdate()-60
			AND (B.TicketNumber is null) --or A.Modified > B.CreateDate
			AND (C.TicketNumber is null) --or A.Modified > C.CreateDate
			


			--Select ID, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
			--where [Billing_x0020_Type] like 'Flat Fee'

			--Select TicketNumber,* From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
			--where TicketNumber in (Select ID From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
			--where [Billing_x0020_Type] like 'Flat Fee')




---------------ADDED 20230927 for MARKET APPROACH - WEEKLY RUN THROUGH TOOL THAT IS BILLABLE ON PER RECORD BASES B/C OF CHARLIE
------20231121 - COMMENTED OUT as I discovered this is being billed based on the customers reported usage - NOT what we sent to them.....

		--------GET SHIPPED RECORD COUNT---
		--Insert into  [AutoBilling].[dbo].[MARKET_APPROACH_BILLING_RPT] ([TICKETNUMBER]
		--	  ,[WorkOrderId]
		--	  ,[FAWorkordernumber]
		--	  ,[DATE_RUN]
		--	  ,[RECORDS])
		--Select '6777' as TICKETNUMBER,E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) as DATE_RUN
		--,sum(F.RecordsExtracted ) as RECORDS
		--From   
		--jobs.[dbo].[ShipmentHistory] as E with(NOLOCK) 
		--join jobs.[dbo].[ShipmentHistoryDetail] as F with(NOLOCK) on E.Id = F.ShipHistoryId
		--join jobs.dbo.workorder as D with(NOLOCK) on E.WorkOrderId = D.ID
		--where E.workorderid in (103102)
		--and convert(date,ShipmentDate) >= '2023-09-22'
		--Group by E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) 
		--Order by E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) 

		--Select * From [AutoBilling].[dbo].[MARKET_APPROACH_BILLING_RPT] 

		


			--	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			--  ,[BatchId]
			--  ,[BatchType]
			--  ,[CreateDate]
			--  ,[ImportDate]
			--  ,[TotalRecords]
			--  ,[TotalMatched]
			--  ,[TotalUnMatched]
			--  ,[TotalDuplicate]
			--  ,[TotalExpired]
			--  ,[TotalInCoverage]
			--  ,[TotalNotInCoverage]
			--  ,[TotalPropertiesFound]
			--  ,[TotalPropertiesNotFound]
			--  ,[IsBillable]
			--  ,[TotalMultiplePropertiesFound]
			--  ,[TotalAddressStandardized]
			--  ,[TotalAddressNotStandardized]
			--  ,[TotalWithEventsFound]
			--  ,[TotalWithoutEventsFound]
			--  ,[TicketNumber]
			--  ,[BillingDate]
			--  ,[ExtractionDate]
			--  ,[BillingOption]
			--  ,[AccountNumber]
			--  ,[DaysToMonitor]
			--  ,[CustomerName]
			--  ,[ClientName]
			--  ,[CMASProductCode]
			--  ,[CMASProductName]
			--  ,[OracleProductCode]
			--  ,[OracleProductName]
			--  ,[Title]
			--  ,[DocImageCounts]
			--  ,[MonitorEndDate])
			--Select distinct 'SQL ADS'----AppSource
			--,NULL----BatchId
			--,'BATCH'----BatchType
			--,DATE_RUN----CreateDate
			--,NULL----ImportDate
			--,RECORDS ----TotalRecords
			--,NULL----TotalMatched
			--,NULL----TotalUnMatched
			--,NULL----TotalDuplicate
			--,NULL----TotalExpired
			--,NULL----TotalInCoverage
			--,NULL----TotalNotInCoverage
			--,NULL----TotalPropertiesFound
			--,NULL----TotalPropertiesNotFound
			--,'YES'----IsBillable
			--,NULL----TotalMultiplePropertiesFound
			--,NULL----TotalAddressStandardized
			--,NULL----TotalAddressNotStandardized
			--,NULL----TotalWithEventsFound
			--,NULL----TotalWithoutEventsFound
			--,A.ID----TicketNumber
			--,NULL----BillingDate
			--,NULL----ExtractionDate
			--,A.[Billing_x0020_Type]----BillingOption
			--,A.Billing_x0020_Number----AccountNumber
			--,NULL----DaysToMonitor
			--,A.Client_x0020_Name----CustomerName
			--,NULL----ClientName
			--,NULL----(No column name)
			--,NULL----CMASProductName
			--,NULL----OracleProductCode
			--,NULL----OracleProductName
			--,NULL----Title
			--,NULL----DocImageCounts
			--,NULL----MonitorEndDate
			--from (
			--Select D.DATE_RUN, A.ID, A.[Billing_x0020_Type],A.Billing_x0020_Number,A.Client_x0020_Name
			--,sum(convert(bigint,D.RECORDS)) as RECORDS
			--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as A 
			--left outer join [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling as B on 
			--A.ID = B.TicketNumber
			--join [MARKET_APPROACH_BILLING_RPT] as D with(NOLOCK) on A.ID = D.TicketNumber
			--where A.ID = '6777'
			--and CUrrent_x0020_Status like '15-Closed'
			--and D.DATE_BILLED is null
			--Group by D.DATE_RUN, A.ID, A.[Billing_x0020_Type],A.Billing_x0020_Number,A.Client_x0020_Name
			----Order by D.DATE_RUN
			--)A


			--Update [MARKET_APPROACH_BILLING_RPT]
			--set DATE_BILLED = convert(date,Getdate())
			--where DATE_BILLED is null
			

------------20240805 - Added for Richards & Assoc bulk tool extract that is billable per record per EC

-------------Get count below & enter in following query to add to billing!!!
------20250221 - This customer has been cancelled per Jeff

--Select E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) as DATE_SHIPPED
--,sum(F.RecordsExtracted ) as RECORDS
--From   
--jobs.[dbo].[ShipmentHistory] as E with(NOLOCK) 
--join jobs.[dbo].[ShipmentHistoryDetail] as F with(NOLOCK) on E.Id = F.ShipHistoryId
--join jobs.dbo.workorder as D with(NOLOCK) on E.WorkOrderId = D.ID
--where 
--convert(date,ShipmentDate) >=  getdate()-30
--and D.ID =  103916
--Group by E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) 
--Order by E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) 



-----------------------------RICHARDS & ASSOC-------------------------
--DECLARE @TICKETNUMBER2 varchar(20)
--DECLARE @TOTAL bigint

--Set @TICKETNUMBER2 = '7326'
--Set @TOTAL = '2095'

--EXEC('
--	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--			  ,[BatchId]
--			  ,[BatchType]
--			  ,[CreateDate]
--			  ,[ImportDate]
--			  ,[TotalRecords]
--			  ,[TotalMatched]
--			  ,[TotalUnMatched]
--			  ,[TotalDuplicate]
--			  ,[TotalExpired]
--			  ,[TotalInCoverage]
--			  ,[TotalNotInCoverage]
--			  ,[TotalPropertiesFound]
--			  ,[TotalPropertiesNotFound]
--			  ,[IsBillable]
--			  ,[TotalMultiplePropertiesFound]
--			  ,[TotalAddressStandardized]
--			  ,[TotalAddressNotStandardized]
--			  ,[TotalWithEventsFound]
--			  ,[TotalWithoutEventsFound]
--			  ,[TicketNumber]
--			  ,[BillingDate]
--			  ,[ExtractionDate]
--			  ,[BillingOption]
--			  ,[AccountNumber]
--			  ,[DaysToMonitor]
--			  ,[CustomerName]
--			  ,[ClientName]
--			  ,[CMASProductCode]
--			  ,[CMASProductName]
--			  ,[OracleProductCode]
--			  ,[OracleProductName]
--			  ,[Title]
--			  ,[DocImageCounts]
--			  ,[MonitorEndDate])
--			Select ''SQL ADS''----AppSource
--			,NULL----BatchId
--			,''BATCH''----BatchType
--			,Getdate()----CreateDate
--			,NULL----ImportDate
--			,''' + @TOTAL + '''----TotalRecords
--			,''' + @TOTAL + '''----TotalMatched
--			,''0''----TotalUnMatched
--			,''0''----TotalDuplicate
--			,''0''----TotalExpired
--			,''' + @TOTAL + '''----TotalInCoverage
--			,''0''----TotalNotInCoverage
--			,''' + @TOTAL + '''----TotalPropertiesFound
--			,''0''----TotalPropertiesNotFound
--			,''YES''----IsBillable
--			,''0''----TotalMultiplePropertiesFound
--			,''0''----TotalAddressStandardized
--			,''0''----TotalAddressNotStandardized
--			,''' + @TOTAL + '''----TotalWithEventsFound
--			,''0''----TotalWithoutEventsFound
--			,ID----TicketNumber
--			,NULL----BillingDate
--			,NULL----ExtractionDate
--			,Billing_x0020_Type----BillingOption
--			,Billing_x0020_Number----AccountNumber
--			,NULL----DaysToMonitor
--			,Client_x0020_Name----CustomerName
--			,NULL----ClientName
--			,NULL----(No column name)
--			,NULL----CMASProductName
--			,NULL----OracleProductCode
--			,NULL----OracleProductName
--			,NULL----Title
--			,''0''----DocImageCounts
--			,NULL----MonitorEndDate

--			FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] 
--			where ID = ''' + @TICKETNUMBER2 + '''


--			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--			where TicketNumber = ''' + @TICKETNUMBER2 + '''

--			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--			where TicketNumber = ''' + @TICKETNUMBER2 + '''

--			')

--			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--			where TicketNumber = 7326




			

------------20250107 - Added for CITRACADO bulk tool extract that is billable per record per WL

-------------Get count below & enter in following query to add to billing!!!

------20250123 - Per EC - Report all counts (Aaron Poling didn't want the Jan counts reported???)----

--Select --E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) as DATE_SHIPPED
--convert(date,ShipmentDate) as DATE_SHIPPED
--,sum(F.RecordsExtracted ) as RECORDS
--From   
--jobs.[dbo].[ShipmentHistory] as E with(NOLOCK) 
--join jobs.[dbo].[ShipmentHistoryDetail] as F with(NOLOCK) on E.Id = F.ShipHistoryId
--join jobs.dbo.workorder as D with(NOLOCK) on E.WorkOrderId = D.ID
--where 
--convert(date,ShipmentDate) >=  getdate()-365
--and D.ID in  (103918,103919)
--Group by convert(date,ShipmentDate) 
--Order by convert(date,ShipmentDate) 


--Select --E.WorkOrderId, D.FAWorkordernumber,convert(date,ShipmentDate) as DATE_SHIPPED
--left(convert(date,ShipmentDate),7) as DATE_SHIPPED
--,sum(F.RecordsExtracted ) as RECORDS
--From   
--jobs.[dbo].[ShipmentHistory] as E with(NOLOCK) 
--join jobs.[dbo].[ShipmentHistoryDetail] as F with(NOLOCK) on E.Id = F.ShipHistoryId
--join jobs.dbo.workorder as D with(NOLOCK) on E.WorkOrderId = D.ID
--where 
--convert(date,ShipmentDate) >=  getdate()-365
--and D.ID in  (103918,103919)
--Group by left(convert(date,ShipmentDate),7)
--Order by left(convert(date,ShipmentDate),7)



-----------------------------CITRACADO PER WL 20250107-------------------------
--DECLARE @TICKETNUMBER4 varchar(20)
--DECLARE @TOTAL2 bigint

--Set @TICKETNUMBER4 = '7358'
--Set @TOTAL2 = '5254'

--EXEC('
--	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--			  ,[BatchId]
--			  ,[BatchType]
--			  ,[CreateDate]
--			  ,[ImportDate]
--			  ,[TotalRecords]
--			  ,[TotalMatched]
--			  ,[TotalUnMatched]
--			  ,[TotalDuplicate]
--			  ,[TotalExpired]
--			  ,[TotalInCoverage]
--			  ,[TotalNotInCoverage]
--			  ,[TotalPropertiesFound]
--			  ,[TotalPropertiesNotFound]
--			  ,[IsBillable]
--			  ,[TotalMultiplePropertiesFound]
--			  ,[TotalAddressStandardized]
--			  ,[TotalAddressNotStandardized]
--			  ,[TotalWithEventsFound]
--			  ,[TotalWithoutEventsFound]
--			  ,[TicketNumber]
--			  ,[BillingDate]
--			  ,[ExtractionDate]
--			  ,[BillingOption]
--			  ,[AccountNumber]
--			  ,[DaysToMonitor]
--			  ,[CustomerName]
--			  ,[ClientName]
--			  ,[CMASProductCode]
--			  ,[CMASProductName]
--			  ,[OracleProductCode]
--			  ,[OracleProductName]
--			  ,[Title]
--			  ,[DocImageCounts]
--			  ,[MonitorEndDate])
--			Select ''SQL ADS''----AppSource
--			,NULL----BatchId
--			,''BATCH''----BatchType
--			,''2025-01-01''----CreateDate
--			,NULL----ImportDate
--			,''' + @TOTAL2 + '''----TotalRecords
--			,''' + @TOTAL2 + '''----TotalMatched
--			,''0''----TotalUnMatched
--			,''0''----TotalDuplicate
--			,''0''----TotalExpired
--			,''' + @TOTAL2 + '''----TotalInCoverage
--			,''0''----TotalNotInCoverage
--			,''' + @TOTAL2 + '''----TotalPropertiesFound
--			,''0''----TotalPropertiesNotFound
--			,''YES''----IsBillable
--			,''0''----TotalMultiplePropertiesFound
--			,''0''----TotalAddressStandardized
--			,''0''----TotalAddressNotStandardized
--			,''' + @TOTAL2 + '''----TotalWithEventsFound
--			,''0''----TotalWithoutEventsFound
--			,ID----TicketNumber
--			,NULL----BillingDate
--			,NULL----ExtractionDate
--			,Billing_x0020_Type----BillingOption
--			,Billing_x0020_Number----AccountNumber
--			,NULL----DaysToMonitor
--			,Client_x0020_Name----CustomerName
--			,NULL----ClientName
--			,NULL----(No column name)
--			,NULL----CMASProductName
--			,NULL----OracleProductCode
--			,NULL----OracleProductName
--			,NULL----Title
--			,''0''----DocImageCounts
--			,NULL----MonitorEndDate

--			FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] 
--			where ID = ''' + @TICKETNUMBER4 + '''


--			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--			where TicketNumber = ''' + @TICKETNUMBER4 + '''

			

--			')

--			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--			where TicketNumber = 7358



-------------Added 20260126 for Western Alliance---------------
-----------------Up to 200K records per mo & after 200K FLat fee increases & must report count to billing!!-------

IF (Select count(*) From [zCust_WesternAlliance].dbo.[INPUT_RAW_CUST_FOR_BILLING]
where [DATE_BILLED] is null) > 200000

BEGIN

PRINT 'RECORD COUNT > 200000!!!  STOP & ESCALATE TO EMILY - MUST LET FINANCE KNOW RECORD COUNT!!!!!'

END

ELSE 

PRINT 'RECORD COUNT OK - KEEP GOING'



Update [zCust_WesternAlliance].dbo.[INPUT_RAW_CUST_FOR_BILLING]
set [DATE_BILLED] = convert(Date,getdate())
where [DATE_BILLED] is null


Insert into [zCust_WesternAlliance].dbo.[INPUT_RAW_CUST_FOR_BILLING_HIST](
				[INPUT_FILENAME] ,
				[DATE_RECEIVED],
				[PropertyId] ,
				[LoanId] ,
				[PropertyStreet],
				[PropertyCity] ,
				[PropertyState] ,
				[PropertyZipCode],
				[AssessorParcelNumber],
				[County] ,
				[IssuanceDate] ,
				[DATE_BILLED])
Select [INPUT_FILENAME] ,
				[DATE_RECEIVED],
				[PropertyId] ,
				[LoanId] ,
				[PropertyStreet],
				[PropertyCity] ,
				[PropertyState] ,
				[PropertyZipCode],
				[AssessorParcelNumber],
				[County] ,
				[IssuanceDate] ,
				[DATE_BILLED]
FROM [zCust_WesternAlliance].dbo.[INPUT_RAW_CUST_FOR_BILLING]
where [DATE_BILLED] is not null


Delete FROM [zCust_WesternAlliance].dbo.[INPUT_RAW_CUST_FOR_BILLING]
where [DATE_BILLED] is not null





-------------Added 20261001 for DEFAULT ANALYTICS---------------
----Month 1 = $10K
----NO billing Months 2-7
----Starting Month 8
----1-50K records = $5K
----50,001-100K records = $6K
----100,001-500K records = $7K
----500,001-1MM records = $8K
----1MM-2MM records = $9K
----> 2MM records = $0.0045 per record


----Month 1 = OCT 2026

	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'MONITOR'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,(Select count(*) From zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING where [DATE_BILLED] is null)----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,(Select count(*) From zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING where [DATE_BILLED] is null)---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'8563'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'Flat Fee'----BillingOption
			,'5005672'----AccountNumber
			,NULL----DaysToMonitor
			,'Default Analytics'----CustomerName
			,NULL----ClientName
			,'S60'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate



Update zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING
set [DATE_BILLED] = convert(Date,getdate())
where [DATE_BILLED] is null


Insert into zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING_HIST
Select * From zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING
where [DATE_BILLED] is not null


Delete FROM zCust_DefaultAnalytics.dbo.INPUT_MONITOR_BILLING
where [DATE_BILLED] is not null







-------------Added 20260828 for FIDELIS--------------
-----------------$ 1,500.00 per month for up to 5,000 records, PLUS $2.00 per transaction event found per output file.
----If input file exceeds 5,000 records, next tier for monitoring is 5,001 to 10,000 records at $2,500.00 per month.-------

Select count(*) From zCust_Fidelis.dbo.INPUT_MONITOR_BILLING
where [DATE_BILLED] is null

	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'MONITOR'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,(Select count(*) From zCust_Fidelis.dbo.INPUT_MONITOR_BILLING where [DATE_BILLED] is null)----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,(Select count(*) From zCust_Fidelis.dbo.INPUT_MONITOR_BILLING where [DATE_BILLED] is null)---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'8412'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'Flat Fee'----BillingOption
			,'5005308'----AccountNumber
			,NULL----DaysToMonitor
			,'Fidelis'----CustomerName
			,NULL----ClientName
			,'S60'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate



Update zCust_Fidelis.dbo.INPUT_MONITOR_BILLING
set [DATE_BILLED] = convert(Date,getdate())
where [DATE_BILLED] is null


Insert into zCust_Fidelis.dbo.INPUT_MONITOR_BILLING_HIST
Select * From zCust_Fidelis.dbo.INPUT_MONITOR_BILLING
where [DATE_BILLED] is not null


Delete FROM zCust_Fidelis.dbo.INPUT_MONITOR_BILLING
where [DATE_BILLED] is not null




-------------Added 20201229 for PennyMac Billing----------------

	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,(Select count(*) From (
			Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
			where  [Legal Event Status] like 'Found'
			AND DATE_BILLED is null)A)---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'4922'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'3 - Bill for every record that had an event'----BillingOption
			,'133759'----AccountNumber
			,NULL----DaysToMonitor
			,'PennyMac'----CustomerName
			,NULL----ClientName
			,'S20'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


		
Select count(*) From (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null)A

Select [Loan Number], count(*)  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null
Group by [Loan Number]
having count(*) > 1

Select [Loan Number], DATE_RECEIVED,DATE_SENT_TO_PNMAC From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where [Loan Number] in (
Select [Loan Number] from (
Select [Loan Number], count(*)  as TOTAl From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
AND DATE_BILLED is null
Group by [Loan Number]
having count(*) > 1)A)
Order by [Loan Number]


Update zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null



Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where TicketNumber = '4922'

Select count(*) From (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
and  DATE_BILLED not like 'N/A' and
convert(date,DATE_BILLED) = convert(date,Getdate())
)A


Select DATE_BILLED, count(*) From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
Group by DATE_BILLED
Order by DATE_BILLED desc



Select  [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
and  DATE_BILLED not like 'N/A' and
convert(date,DATE_BILLED) = convert(date,Getdate())



-----Query for PNMAC Detail file---
Select [Loan Number],1 as 'UNITS',convert(money,'6') as 	'Cost/Unit',convert(money,'6') as	'Total'
from (
Select distinct [Loan Number], DATE_SENT_TO_PNMAC  From zCust_PennyMac.dbo.[INPUT_MONITOR_COMPLETE]
where  [Legal Event Status] like 'Found'
and  convert(date,DATE_BILLED) = convert(date,Getdate())
)A
Order by DATE_SENT_TO_PNMAC



---------------20241008 - Added for BK ICE - $0.03 per UNIQUE PARCEL PER BILLING CYCLE-------


	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,(Select count(*) from (
			SELECT distinct [PROPERTYID] FROM [zCust_BK_ICE].[dbo].[INPUT_MONITOR_BILLING]
			where PROPERTYID is not null and PROPERTYID not like '' and PROPERTYID not like '0'
			and DATE_BILLED is null)A)----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'7432'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'2 - Bill for every record that was matched to a property'----BillingOption
			,'5000312'----AccountNumber
			,NULL----DaysToMonitor
			,'Black Knight - ICE'----CustomerName
			,NULL----ClientName
			,'S20'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


			Update 
			[zCust_BK_ICE].[dbo].[INPUT_MONITOR_BILLING]
			set DATE_BILLED = convert(date,getdate())
			where PROPERTYID is not null and PROPERTYID not like '' and PROPERTYID not like '0'
			and DATE_BILLED is null

			Insert into [zCust_BK_ICE].[dbo].[INPUT_MONITOR_BILLING_HIST]
			Select * From [zCust_BK_ICE].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null

			Delete from [zCust_BK_ICE].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null



			
---------------20250915 - Added for LAND GORILLA - $1K per month for up to 20000 matched input records PLUS per event fees (these are in the solutions)-------


	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,NULL----TotalRecords
			,(Select count(*) from  [zCust_LandGorilla].[dbo].[INPUT_MONITOR_BILLING]
			where PROPERTYID is not null and PROPERTYID not like '' and PROPERTYID not like '0'
			and DATE_BILLED is null)----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'7887'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'2 - Bill for every record that was matched to a property'----BillingOption
			,'5001298'----AccountNumber
			,NULL----DaysToMonitor
			,'Land Gorilla'----CustomerName
			,NULL----ClientName
			,'S60'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


			Update 
			[zCust_LandGorilla].[dbo].[INPUT_MONITOR_BILLING]
			set DATE_BILLED = convert(date,getdate())
			where PROPERTYID is not null and PROPERTYID not like '' and PROPERTYID not like '0'
			and DATE_BILLED is null

			Insert into [zCust_LandGorilla].[dbo].[INPUT_MONITOR_BILLING_HIST]
			Select * From [zCust_LandGorilla].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null

			Delete from [zCust_LandGorilla].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null




						
---------------20260616 - Added for BUILD CHECK PRO:
----$1500/month for 1-20K records
----$2500/month for 20,001-40K records
----$3500/month for 40,001-60K records
----PER RECORD IN PORTFOLIO (regardless of match or data output)
----PLUS per event fees (these are in the solutions)-------


	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,(Select count(*) from  [zCust_BuildCheckPro].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is null)----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'8327'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'Flat Fee'----BillingOption
			,'5005132'----AccountNumber
			,NULL----DaysToMonitor
			,'Build Check Pro'----CustomerName
			,NULL----ClientName
			,'S60'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


			Update 
			[zCust_BuildCheckPro].[dbo].[INPUT_MONITOR_BILLING]
			set DATE_BILLED = convert(date,getdate())
			where DATE_BILLED is null

			Insert into [zCust_BuildCheckPro].[dbo].[INPUT_MONITOR_BILLING_HIST]
			Select * From [zCust_BuildCheckPro].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null

			Delete from [zCust_BuildCheckPro].[dbo].[INPUT_MONITOR_BILLING]
			where DATE_BILLED is not null



			
---------------20241029 - Added for SHARONVIEW - $0.75 per RECORD ADDED TO THEIR PORTFOLIO - BILLED ONLY ONCE  - THE FIRST TIME THE RECORD IS ADDED per EC-------
----Per EC 20250703 THis customer Cancelled

	--INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
	--		  ,[BatchId]
	--		  ,[BatchType]
	--		  ,[CreateDate]
	--		  ,[ImportDate]
	--		  ,[TotalRecords]
	--		  ,[TotalMatched]
	--		  ,[TotalUnMatched]
	--		  ,[TotalDuplicate]
	--		  ,[TotalExpired]
	--		  ,[TotalInCoverage]
	--		  ,[TotalNotInCoverage]
	--		  ,[TotalPropertiesFound]
	--		  ,[TotalPropertiesNotFound]
	--		  ,[IsBillable]
	--		  ,[TotalMultiplePropertiesFound]
	--		  ,[TotalAddressStandardized]
	--		  ,[TotalAddressNotStandardized]
	--		  ,[TotalWithEventsFound]
	--		  ,[TotalWithoutEventsFound]
	--		  ,[TicketNumber]
	--		  ,[BillingDate]
	--		  ,[ExtractionDate]
	--		  ,[BillingOption]
	--		  ,[AccountNumber]
	--		  ,[DaysToMonitor]
	--		  ,[CustomerName]
	--		  ,[ClientName]
	--		  ,[CMASProductCode]
	--		  ,[CMASProductName]
	--		  ,[OracleProductCode]
	--		  ,[OracleProductName]
	--		  ,[Title]
	--		  ,[DocImageCounts]
	--		  ,[MonitorEndDate])
	--		Select distinct 'SQL ADS'----AppSource
	--		,NULL----BatchId
	--		,'BATCH'----BatchType
	--		,Getdate()----CreateDate
	--		,NULL----ImportDate
	--		,(SELECT count(*) FROM [zCust_Sharonview].[dbo].[INPUT_MONITOR_BILLING]
	--		where DATE_BILLED is null)----TotalRecords
	--		,NULL----TotalMatched
	--		,NULL----TotalUnMatched
	--		,NULL----TotalDuplicate
	--		,NULL----TotalExpired
	--		,NULL----TotalInCoverage
	--		,NULL----TotalNotInCoverage
	--		,NULL----TotalPropertiesFound
	--		,NULL----TotalPropertiesNotFound
	--		,'YES'----IsBillable
	--		,NULL----TotalMultiplePropertiesFound
	--		,NULL----TotalAddressStandardized
	--		,NULL----TotalAddressNotStandardized
	--		,NULL---TotalWithEventsFound
	--		,NULL----TotalWithoutEventsFound
	--		,'7458'---TicketNumber
	--		,NULL----BillingDate
	--		,NULL----ExtractionDate
	--		,'1 - Bill for every record in the Input file'----BillingOption
	--		,'5000303'----AccountNumber
	--		,NULL----DaysToMonitor
	--		,'Sharonview'----CustomerName
	--		,NULL----ClientName
	--		,'S60'----CMAS Product Code
	--		,NULL----CMASProductName
	--		,NULL----OracleProductCode
	--		,NULL----OracleProductName
	--		,NULL----Title
	--		,NULL----DocImageCounts
	--		,NULL----MonitorEndDate


	--		Update 
	--		[zCust_Sharonview].[dbo].[INPUT_MONITOR_BILLING]
	--		set DATE_BILLED = convert(date,getdate())
	--		where  DATE_BILLED is null

		
				
---------------20250520 - Added for AAM - $0.05 per RECORD ADDED TO THEIR PORTFOLIO - BILLED ONLY ONCE  - THE FIRST TIME THE RECORD IS ADDED per Jonathan-------


	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select distinct 'SQL ADS'----AppSource
			,NULL----BatchId
			,'BATCH'----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,(SELECT count(*) FROM zCust_ADS_AAM_S20.dbo.INPUT_IN_MONITOR with(NOLOCK)
			where [DATE_BILLED] is null)----TotalRecords
			,NULL----TotalMatched
			,NULL----TotalUnMatched
			,NULL----TotalDuplicate
			,NULL----TotalExpired
			,NULL----TotalInCoverage
			,NULL----TotalNotInCoverage
			,NULL----TotalPropertiesFound
			,NULL----TotalPropertiesNotFound
			,'YES'----IsBillable
			,NULL----TotalMultiplePropertiesFound
			,NULL----TotalAddressStandardized
			,NULL----TotalAddressNotStandardized
			,NULL---TotalWithEventsFound
			,NULL----TotalWithoutEventsFound
			,'7716'---TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,'1 - Bill for every record in the Input file'----BillingOption
			,'120464'----AccountNumber
			,NULL----DaysToMonitor
			,'AAM'----CustomerName
			,NULL----ClientName
			,'S60'----CMAS Product Code
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,NULL----DocImageCounts
			,NULL----MonitorEndDate


			Update 
			[zCust_ADS_AAM_S20].[dbo].[INPUT_IN_MONITOR] 
			set [DATE_BILLED] = convert(date,getdate())
			where  [DATE_BILLED] is null

		



--------20240731 - CATALYZE - Added just to mark records as "billed" so we can track the number of input records they submit each month
---------------------------They have a 75K monthly batch limit------------
-----------20250901 - Contract Cancelled


		--UPDATE zCust_Catalyze.dbo.ADS_COUNTS
		--SET [BillingDate] = convert(date,getdate())
		--WHERE [BillingDate] is NULL 

		--Select * from zCust_Catalyze.dbo.ADS_COUNTS
		--WHERE [BillingDate] = convert(date,getdate())

		--Select * from zCust_Catalyze.dbo.ADS_COUNTS
		--WHERE [BillingDate] is NULL 
		

--------20240925 - PINNACLE - Added just to mark records as "billed" so we can track the number of input records they submit each month
---------------------------They have a 5K monthly batch limit------------

		UPDATE zCust_Pinnacle.dbo.ADS_COUNTS
		SET [BillingDate] = convert(date,getdate())
		WHERE [BillingDate] is NULL 
		

		Select * from zCust_Pinnacle.dbo.ADS_COUNTS
		WHERE [BillingDate] is NULL 
		

--------------*******--------20210428 - Added for METASOURCE Billing Report per NH-----******------------------

------Check Order Date Range to be sure it is within billing cycle---
--Select [Order Date], count(*) as TOTAL From zCust_Metasource.dbo.Billing_Report
--where DATE_BILLED is null
--Group by [Order Date]
--Order by [Order Date]

-------Make sure NO NULL VALUES!!!!!-----
--Select [Billable Event], count(*) as TOTAL From zCust_Metasource.dbo.Billing_Report
--where DATE_BILLED is null
--Group by [Billable Event]
--Order by [Billable Event]


--Update zCust_Metasource.dbo.Billing_Report
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null





--------------------Added 20200824 for COVIUS MANUAL DOC IMAGE CREDITS PER NH---
-----------------20220915 - Covius is now inactive per NH----------------
------------------------------------------------------

--	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--			  ,[BatchId]
--			  ,[BatchType]
--			  ,[CreateDate]
--			  ,[ImportDate]
--			  ,[TotalRecords]
--			  ,[TotalMatched]
--			  ,[TotalUnMatched]
--			  ,[TotalDuplicate]
--			  ,[TotalExpired]
--			  ,[TotalInCoverage]
--			  ,[TotalNotInCoverage]
--			  ,[TotalPropertiesFound]
--			  ,[TotalPropertiesNotFound]
--			  ,[IsBillable]
--			  ,[TotalMultiplePropertiesFound]
--			  ,[TotalAddressStandardized]
--			  ,[TotalAddressNotStandardized]
--			  ,[TotalWithEventsFound]
--			  ,[TotalWithoutEventsFound]
--			  ,[TicketNumber]
--			  ,[BillingDate]
--			  ,[ExtractionDate]
--			  ,[BillingOption]
--			  ,[AccountNumber]
--			  ,[DaysToMonitor]
--			  ,[CustomerName]
--			  ,[ClientName]
--			  ,[CMASProductCode]
--			  ,[CMASProductName]
--			  ,[OracleProductCode]
--			  ,[OracleProductName]
--			  ,[Title]
--			  ,[DocImageCounts]
--			  ,[MonitorEndDate])
--			Select distinct 'SQL ADS'----AppSource
--			,NULL----BatchId
--			,'BATCH'----BatchType
--			,Getdate()----CreateDate
--			,NULL----ImportDate
--			,NULL----TotalRecords
--			,NULL----TotalMatched
--			,NULL----TotalUnMatched
--			,NULL----TotalDuplicate
--			,NULL----TotalExpired
--			,NULL----TotalInCoverage
--			,NULL----TotalNotInCoverage
--			,NULL----TotalPropertiesFound
--			,NULL----TotalPropertiesNotFound
--			,'YES'----IsBillable
--			,NULL----TotalMultiplePropertiesFound
--			,NULL----TotalAddressStandardized
--			,NULL----TotalAddressNotStandardized
--			,NULL----TotalWithEventsFound
--			,NULL----TotalWithoutEventsFound
--			,'4463'---TicketNumber
--			,NULL----BillingDate
--			,NULL----ExtractionDate
--			,'3 - Bill for every record that had an event'----BillingOption
--			,'132941'----AccountNumber
--			,NULL----DaysToMonitor
--			,'Covius'----CustomerName
--			,NULL----ClientName
--			,'S50'----CMAS Product Code
--			,NULL----CMASProductName
--			,NULL----OracleProductCode
--			,NULL----OracleProductName
--			,NULL----Title
--			,'-1'----DocImageCounts
--			,NULL----MonitorEndDate
			



---------Added 20180419 KL - For USA Home Listings-----
--Insert into [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING_HIST]
--Select * From [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING]

--Truncate table [zCust_ADS_S10_USA_Home_Listings].dbo.[INPUT_IN_BILLING]

--Select ID,CreateDate, DocImageCOunts, * From  [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling A
--where customerName like 'Covius'
--ORder by A.DocImageCOunts

--Delete from [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where customerName like 'Covius'


--------Added 20190503 - KL  for AUCTION 10 X Monitor Job------------------------------------------------------------------


--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'BATCH'               --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,COUNT(DISTINCT [Reference Number])   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'3469'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'131949'    --[AccountNumber]
--      ,'Auction.com' --[CustomerName]
--      ,'S20'                      --[CMASProductCode]
--      ,'S20 - Custom Solution'  --[CMASProductName]
--	from  zCust_Auction.dbo.[AUCTION_BILLING] --Where RecordFlag = 'A'





--INSERT INTO zCust_Auction.dbo.[AUCTION_BILLING_HIST]([Order Date]
--      ,[UserID]
--      ,[Product]
--      ,[Reference Number]
--      ,[Group Name]
--      ,[Search Criteria]
--      ,[Pricing]
--      ,[DATE_BILLED])
--SELECT       [Order Date]
--      ,[UserID]
--      ,[Product]
--      ,[Reference Number]
--      ,[Group Name]
--      ,[Search Criteria]
--      ,[Pricing]
--       ,convert(date,Getdate())
--FROM       zCust_Auction.dbo.[AUCTION_BILLING]



--Truncate table zCust_Auction.dbo.[AUCTION_BILLING]


--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where Ticketnumber in (3788,3712)

--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] 
--where Ticketnumber in (3788,3712)


-----------Added 20200114 KL for Green River per customer wants all billed records included with invoice each month----
Select count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is null

--Select * From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
--where DATE_BILLED is null
--order by [Report Date]

Select [Report Date], count(*)
From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is null
Group by [Report Date]
Order by [Report Date]




Update zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Select count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT

Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Report Date]
Order by [Report Date]


-----Check for DUPS----
Select [Client Name],[INPUT KEY], count(*)  From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Client Name],[INPUT KEY]
having count(*) > 1


-----Look at DUPS----
Select A.[Client Name], A.[INPUT KEY], A.[INPUT ADDRESS], A.[REPORT DATE], A.DATE_RUN, A.DATE_BILLED From  zCust_ADS_GreenRiver.dbo.BILLING_REPORT A join (
Select [Client Name],[INPUT KEY], count(*) T  From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Client Name],[INPUT KEY]
having count(*) > 1) B on A.[Client Name] = B.[Client Name] and A.[INPUT KEY] = B.[INPUT KEY]
Order by A.[Client Name],A.[INPUT KEY]

--Select A.[Client Name], A.[INPUT KEY], A.[INPUT ADDRESS], A.[REPORT DATE], A.DATE_RUN, A.DATE_BILLED From  zCust_ADS_GreenRiver.dbo.BILLING_REPORT A join (
--Select [Client Name],[INPUT KEY], A.[REPORT DATE], count(*) T  From zCust_ADS_GreenRiver.dbo.BILLING_REPORT A
--Group by [Client Name],[INPUT KEY], A.[REPORT DATE]
--having count(*) > 1) B on A.[Client Name] = B.[Client Name] and A.[INPUT KEY] = B.[INPUT KEY]
--Order by A.[Client Name],A.[INPUT KEY]



Select [Report Date],DATE_RUN, count(*) From  zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Report Date],DATE_RUN
Order by [Report Date],DATE_RUN



Select  A.* From zCust_ADS_GreenRiver.dbo.BILLING_REPORT as A 
join 
(Select [Client Name],[INPUT KEY], count(*) as TOTAL From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
Group by [Client Name],[INPUT KEY]
having count(*) > 1) B on 
A.[Client Name] = B.[Client Name]
and A.[INPUT KEY] = B.[INPUT KEY]
Order by [Client Name],[INPUT KEY]




Insert into zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Select * From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]

Truncate table zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]



Insert into zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Select distinct  * From zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is not null

Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Group by [Report Date]
Order by [Report Date]

Select * From zCust_ADS_GreenRiver.dbo.ADS_COUNTS
ORder by CreateDate desc


Delete from zCust_ADS_GreenRiver.dbo.BILLING_REPORT
where DATE_BILLED is not null

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
where DATE_BILLED = convert(date,Getdate())


Select Status, count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Group by Status

Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]
Group by [Report Date]
Order by [Report Date] desc


Select [Report Date], count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST_SENT]
Group by [Report Date]
Order by [Report Date]

Select count(*) From zCust_ADS_GreenRiver.dbo.[BILLING_REPORT_HIST]

--Select sum(TotalMatched) From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'
--and BillingDate is null
--and BatchType not like 'MONITOR_RIBBON'

--Select sum(TotalMatched) as GREENRIVER From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] with(NOLOCK) 
--where AccountNumber = '118751'
--and BatchType not like 'MONITOR_RIBBON'


--Select sum(TotalMatched) From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'

--Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'


Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where AccountNumber = '118751'
and BatchType not like 'MONITOR_RIBBON'


-----------------------------ADDED 20221121 for GREEN RIVER RIBBON------------------------------------------------------

--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--where DATE_BILLED is null

--Update zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST_SENT]
--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT

--Select [Report Date], count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Group by [Report Date]
--Order by [Report Date]


-------Check for DUPS----
--Select [Client Name],[INPUT KEY], count(*)  From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Group by [Client Name],[INPUT KEY]
--having count(*) > 1


-------Look at DUPS----
--Select A.[Client Name], A.[INPUT KEY], A.[INPUT ADDRESS], A.[REPORT DATE], A.DATE_RUN, A.DATE_BILLED From  zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT A join (
--Select [Client Name],[INPUT KEY], count(*) T  From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Group by [Client Name],[INPUT KEY]
--having count(*) > 1) B on A.[Client Name] = B.[Client Name] and A.[INPUT KEY] = B.[INPUT KEY]
--Order by A.[Client Name],A.[INPUT KEY],A.[REPORT DATE]



--Select [Report Date],DATE_RUN, count(*) From  zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Group by [Report Date],DATE_RUN
--Order by [Report Date],DATE_RUN



--Select  A.* From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT as A 
--join 
--(Select [Client Name],[INPUT KEY], count(*) as TOTAL From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--Group by [Client Name],[INPUT KEY]
--having count(*) > 1) B on 
--A.[Client Name] = B.[Client Name]
--and A.[INPUT KEY] = B.[INPUT KEY]
--Order by [Client Name],[INPUT KEY]




--Insert into zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST_SENT]
--Select * From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]

--Truncate table zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]



--Insert into zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--Select distinct  * From zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--where DATE_BILLED is not null

--Select [Report Date], count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--Group by [Report Date]
--Order by [Report Date]

--Select * From zCust_ADS_GreenRiver_Ribbon.dbo.ADS_COUNTS
--ORder by CreateDate desc


--Delete from zCust_ADS_GreenRiver_Ribbon.dbo.BILLING_REPORT
--where DATE_BILLED is not null

--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--where DATE_BILLED = convert(date,Getdate())


--Select Status, count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--Group by Status

--Select [Report Date], count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]
--Group by [Report Date]
--Order by [Report Date] desc


--Select [Report Date], count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST_SENT]
--Group by [Report Date]
--Order by [Report Date]

--Select count(*) From zCust_ADS_GreenRiver_Ribbon.dbo.[BILLING_REPORT_HIST]

--Select sum(TotalMatched) From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'
--and BillingDate is null
--and BatchType like 'MONITOR_RIBBON'


--Select sum(TotalMatched) as GREENRIVER From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] with(NOLOCK) 
--where AccountNumber = '118751'
--and BatchType like 'MONITOR_RIBBON'

--Select CustomerName,TotalMatched, CreateDate, BillingDate, BillingOption, Status, BatchType From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where AccountNumber = '118751'
--and BatchType like 'MONITOR_RIBBON'




------Added 20191105 - KL  for Finance of America Monitor Job-----------------------------------------------------------
----------------Billing - $5.00 for ANY record in REVERSE OR COMMERCIAL that had Event Found in ANY Solution---
-----------********Changed 20200805 per EC & Juston Backs to bill for EVERY EVENT FOUND PER SOLUTION****---
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,A.MAXEVENTFOUND   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,A.MAXEVENTFOUND         --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'4024'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'131666'    --[AccountNumber]
--      ,'Finance of America' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]

--from  
--(Select max(MAXCOUNT) as MAXEVENTFOUND From 
--(
--	(Select max(Event_Found) as MAXCOUNT From zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING 
--	where DATE_BILLED is null)
--	UNION ALL
--	(Select max(Event_Found) as MAXCOUNT From zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING 
--	where DATE_BILLED is null)
		
--	--(Select max(TotalWithEventsFound) as MAXCOUNT From zCust_FinanceOfAmerica_REVERSE.dbo.ADS_COUNTS 
--	--where DATE_BILLED is null)
--	--UNION ALL
--	--(Select max(TotalWithEventsFound) as MAXCOUNT From zCust_FinanceOfAmerica_COMM.dbo.ADS_COUNTS 
--	--where DATE_BILLED is null)
--)A)A where MAXEVENTFOUND > 0

----------------Testing-----------


--Select * From zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING 
--where DATE_BILLED is null Order by EVENT_FOUND desc
--Select * From zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING 
--where DATE_BILLED is null Order by EVENT_FOUND desc

--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '4024'  


--Update zCust_FinanceOfAmerica_REVERSE.dbo.ADS_COUNTS
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Update zCust_FinanceOfAmerica_COMM.dbo.ADS_COUNTS
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null


--Update zCust_FinanceOfAmerica_REVERSE.dbo.REVERSE_BILLING
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Update zCust_FinanceOfAmerica_COMM.dbo.COMM_BILLING
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null

--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where TicketNumber = 4024



------Added 20210129 - KL  for SITUS AMC  - Per EC _ Their billing is based on the solution(s) chosen 
------& can be per event OR Input record & there can be add ons!!1-----------------------------------------------
Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where CustomerName = 'Situs AMC'
Order by CreateDate desc

Select sum(TotalREcords) From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where CustomerName = 'Situs AMC'
and billingdate is null

Select count(*) From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]

Select convert(Date,CreateDate) as DATE_CREATED, sum(TotalRecords) as TOTAL, Sum(TotalMatched) as MATCHED  From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where CustomerName = 'Situs AMC'
and billingdate is null
Group by convert(Date,CreateDate) 
Order by convert(Date,CreateDate) 


Select [Order Date], count(*) From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
Group by [Order Date]
order by [Order Date]


Select [Order Date], count(*) From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT_HIST]
Group by [Order Date]
order by  [Order Date] desc

--------------Set Date Billed-----------

Select * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where [Loan ID] like ''

Delete From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where [Loan ID] like ''

Select * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where DATE_BILLED is null 



Select [Loan ID], count(*) From 
(Select distinct * from zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT])A
where DATE_BILLED is null 
Group by [Loan ID]
having count(*) > 1

--Delete From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
--where [DEAL ID] = '403805VND'
--and [Order Date] = '2024-01-03'


Update zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into  zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT_HIST]
Select  * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]
where DATE_BILLED = convert(date,Getdate())

Truncate table zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT]

Select distinct * From zCust_SITUS_AMC.dbo.[SITUS_AMC_BILLING_RPT_HIST]
where DATE_BILLED = convert(date,Getdate())





--------Added 20200601 - KL  for APEX WO6 Monitor Job - Per NH they are only billed once for two extracts per month-----------------------------------------------
------------------Billing - Per MATCHED Record so taking the Max Number of Matched records per month---
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'WO6'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,(Select max(TOTALRECORDS) from  zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS with(NOLOCK)	where [DATE_BILLED] is null)   --[TotalRecords]
--      ,(Select max(TOTALMatched) from  zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS with(NOLOCK)	where [DATE_BILLED] is null)                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0        --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'4410'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'119863'    --[AccountNumber]
--      ,'Apex Lien Solutions ' --[CustomerName]
--      ,'S20'                      --[CMASProductCode]
--      ,'S20 - Custom Solution'  --[CMASProductName]

----from  zCust_ADS_S20_APEX.dbo.ADS_COUNTS	where [DATE_BILLED] is null

--Select * From zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS Order by CreateDate desc


--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '4410'  Order by CreateDate desc


----------------Set Date Billed-----------


--Select * From zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS
--where DATE_BILLED is null 

--Update zCust_ADS_S20_APEX_WO6.dbo.ADS_COUNTS
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null 







------Added 20210811 - KL  for NEXTLEVEL Monitor Job - Per CR they are only billed once per month for all records monitored that month-------------------------
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select count(*) from  [zCust_NextLevel].dbo.[BILLING_REPORT] with(NOLOCK)	where [DATE_BILLED] is null)   --[TotalRecords]
      ,0					   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                   --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0					   --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'5567'                  --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'134587'    --[AccountNumber]
      ,'NextLevel Association Solutions' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



Select count(*) From [zCust_NextLevel].dbo.[BILLING_REPORT]


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '5567'  Order by CreateDate desc


--------------Set Date Billed-----------


Select * From [zCust_NextLevel].dbo.[BILLING_REPORT]
where DATE_BILLED is null 

Update [zCust_NextLevel].dbo.[BILLING_REPORT]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into [zCust_NextLevel].dbo.[BILLING_REPORT_HIST]([Unique ID] ,[DATE_ADDED] ,	[DATE_BILLED])
Select [Unique ID] ,[DATE_ADDED] ,	[DATE_BILLED] from [zCust_NextLevel].dbo.[BILLING_REPORT]
where DATE_BILLED is not null

Delete from [zCust_NextLevel].dbo.[BILLING_REPORT]
where DATE_BILLED is not null


-----------------Start Here




------Added 20250529 - KL  for NASA FCU Monitor Job - Quarterly Monitor job - Billed once per Quarter (each run...)----------------------
---------------$0.25 per Matched record
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,0   --[TotalRecords]
      ,(Select count(*) from  [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING] with(NOLOCK)	where [DATE_BILLED] is null)   --[TotalRecords]					   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                   --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0					   --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'7723'                  --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'5001115'    --[AccountNumber]
      ,'NASA FCU' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



Select count(*) From [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING]


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '7723'  Order by CreateDate desc


--------------Set Date Billed-----------


Select * From [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is null 

Update [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING_HIST]
Select * from [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null

Delete from [zCust_NASA_FCU].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null






------Added 20250529 - KL  for PALMETTO SOLAR Monitor Job - Twice per week Monitor job 
------ Billed once per Month for every matched input record that was in their portfolio that month---------------------
------ -----------------BILLING COUNTS-------------

	 ----20250529 - Per WO = Charge Per input record standardized & matched:
	 ----1-20K = $0.10 per 
	 ----20,001-60K = $0.075 per 
	 ----60,001-120K = $0.067 per 
	 ----120,001 - 250K  = $0.06 per 
	 ----No more than 250K
	 
	 ------$2000 Monthly Min per SOW
	  ---PLUS $3.00 PER EVENT


	  ----Ticket 7739 is S20 For Event Counts
	  ----Ticket 7741 is for S60 - Portfolio Monitor Counts


insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,0 --(Select count(*) from  [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING] with(NOLOCK)	where [DATE_BILLED] is null)   --[TotalRecords]
      ,(Select count(*) from  [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING] with(NOLOCK)	where [DATE_BILLED] is null)					   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                   --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0					   --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'7741'                  --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'XXXX'    --[AccountNumber]
      ,'Palmetto Solar' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



Select count(*) From [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING]


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '7741'  Order by CreateDate desc





--------------Set Date Billed-----------


Select count(*) From [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is null 

Update [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING_HIST]
Select * from [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null

Delete from [zCust_PalmettoSolar].[dbo].[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null




------Added 20220922 - KL  for TOWERPOINT Monitor Job - ------------------------
--------------------------20220922------------per CL ---------------
	-----Ticket 6085 is for NEWLY ADDED MATCHED RECORDS to the portfolio since the last portfolio update
	-----Ticket 6276 is for all Event Found count 

insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select count(*) from  zCust_Towerpoint.dbo.[INPUT_MONITOR_NEW]	)   --[TotalRecords]
      ,(Select count(*) from  zCust_Towerpoint.dbo.[INPUT_MONITOR_NEW]	where [BILLING_DATE] is null and ISNULL(PROPERTYID,'0') not like '0' and PROPERTYID is not null 
		and PROPERTYID not like '')					   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                   --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0					   --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'6085'                  --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'135898'    --[AccountNumber]
      ,'Towerpoint Capital, LLC' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]



	-----Ticket 6085 is for NEWLY ADDED MATCHED RECORDS to the portfolio since the last portfolio update
	-----Ticket 6276 is for all Event Found count 

Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '6085'  Order by CreateDate desc

Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '6276'  Order by CreateDate desc


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '6276'  Order by CreateDate desc



--------------Set Date Billed for MATCH properties!!!-----------

UPdate zCust_Towerpoint.dbo.[INPUT_MONITOR_NEW]
		Set [BILLING_DATE]	= convert(date,Getdate()) 
		where [BILLING_DATE] is null 
		and ISNULL(PROPERTYID,'0') not like '0'
		and PROPERTYID is not null 
		and PROPERTYID not like ''








--------Added 20210923 - KL  for SECURETITLELOCK Monitor Job - Per CR they are only billed once per month for all records monitored that month-------------------------
----Stopped Job 20220325 per CL----
-------Reinstated per CL
------20220922 - Stopped again per finance
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,0   --[TotalRecords]
--      ,(Select count(*)  from  [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING] with(NOLOCK) where ISNULL(PROPERTYID,'') not like '0')   --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                   --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0					   --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'5646'                  --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'134329'    --[AccountNumber]
--      ,'Secure Title Lock, LLC' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



--Select count(*) From [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING]


------Ticket 5646 is for newly added & matched input records
--------$0.015 per Matched record
--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '5646'  Order by CreateDate desc


-----Ticket 5256 is per Event Found
--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '5256'  Order by CreateDate desc


----------------PUSHED BILLED RECORDS TO HIST-----------

--Insert into [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING_HIST]
--Select *, convert(DATE,Getdate()) from [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING]

--Truncate table [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING]

--Insert into [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING]
--Select * From [zCust_SecureTitleLock].dbo.[INPUT_MONITOR]

--Select DATE_BILLED, count(*)  from [zCust_SecureTitleLock].dbo.[INPUT_MONITOR_BILLING_HIST]
--Group by DATE_BILLED
--Order by DATE_BILLED desc



------Added 20220325 - KL  for DIVIDEND FINANCE as is nNOW Monitor Job - Per CL they are only billed once per month for all MATCHED record that month-------------------------
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,0   --[TotalRecords]
      ,(Select count(*)  from  [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT] with(NOLOCK) where DATE_BILLED is null)   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                   --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0					   --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'5684'                  --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'130353'    --[AccountNumber]
      ,'Dividend Finance, LLC' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]



Select count(*) From    [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]

------ per Matched record
Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '5684'  Order by CreateDate desc




--------------PUSHED BILLED RECORDS TO HIST-----------

Update [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null


Insert into [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT_HIST]
Select * from [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]


Truncate table [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]

Insert into [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]([INPUTUNIQUE ID],[DATE_ADDED])
Select [INPUTUNIQUE ID],[DATE_ADDED] 
From [zCust_ADS_S20_DividendFinancial].dbo.INPUT_MONITOR
where PropertyID is not null and PropertyID not like '0' and PropertyID not like ''



Select DATE_BILLED, count(*)  from [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT_HIST]
Group by DATE_BILLED
Order by DATE_BILLED desc

Select count(*) From [zCust_ADS_S20_DividendFinancial].dbo.[BILLING_REPORT]

Select DATE_DELETED, count(*) From [zCust_ADS_S20_DividendFinancial].dbo.INPUT_MONITOR_DELETED
Group by DATE_DELETED
Order by DATE_DELETED desc

Select DATE_ADDED, count(*) From [zCust_ADS_S20_DividendFinancial].dbo.INPUT_MONITOR
Group by DATE_ADDED
Order by DATE_ADDED desc




------Added 20201111 - KL  for DOMIDOCS Monitor Job - Per CR they are only billed once per month-----------------------------------------------
----------------Billing - Billed once per month for the MAX number of records in the portfolio during the billing cycle ---
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'Monitor'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,(Select max(TOTALRECORDS) from  zCust_DomiDocs.dbo.ADS_COUNTS with(NOLOCK)	where BILLINGDATE is null
	  and BatchType like 'Portfolio')   --[TotalRecords]
      ,0
	  --(Select max(TotalPropertiesFound) from  zCust_DomiDocs.dbo.ADS_COUNTS with(NOLOCK)	where BILLINGDATE is null)   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0        --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'4987'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'133789'    --[AccountNumber]
      ,'DomiDocs, Inc' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]



Select * From zCust_DomiDocs.dbo.ADS_COUNTS where batchType like 'BATCH' and CreateDate > Getdate()-35 Order by CreateDate Desc

Select count(*) from zCust_DomiDocs.dbo.INPUT_MONITOR with(NOLOCK)


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '4987'  and Billingdate is null 


--------------Set Date Billed-----------


Select * From zCust_DomiDocs.dbo.ADS_COUNTS
where BILLINGDATE is null 

Update zCust_DomiDocs.dbo.ADS_COUNTS
Set BILLINGDATE = convert(date,Getdate())
where BILLINGDATE is null 

 


 
------Added 20240220 - KL  for OSNational Monitor Job - Per NH they are only billed once per month-----------------------------------------------
----------------Billing - Billed once per month for the MAX number of MATCHED records in the portfolio during the billing cycle ---

---------------Per EC 20250824 - TURNED OFF AS EVERYTHING GOING THROUGH MAINSTAY LABS
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'Monitor'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,0					   --[TotalRecords]
--       , (Select count(*) from  zCust_OS_National.dbo.[INPUT_MONITOR_BILLING] with(NOLOCK)	where DATE_BILLED is null)   --[TotalMatched]   --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0        --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'6826'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'5000109'    --[AccountNumber]
--      ,'OS National' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



----Select * From zCust_OS_National.dbo.ADS_COUNTS where batchType like 'S12' and CreateDate > Getdate()-35 Order by CreateDate Desc

----Select count(*) from zCust_OS_National.dbo.INPUT_MONITOR with(NOLOCK)


--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ticketnumber = '6826'  and Billingdate is null 

--Select * From zCust_OS_National.dbo.[INPUT_MONITOR_BILLING]
--where DATE_BILLED is null 

--Update zCust_OS_National.dbo.[INPUT_MONITOR_BILLING]
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null 

--Insert into  zCust_OS_National.dbo.[INPUT_MONITOR_BILLING_HIST]
--Select * From zCust_OS_National.dbo.[INPUT_MONITOR_BILLING]
--where DATE_BILLED is not null 

--Delete From zCust_OS_National.dbo.[INPUT_MONITOR_BILLING]
--where DATE_BILLED is not null 

--Select count(*) from zCust_OS_National.dbo.[INPUT_MONITOR_BILLING]




--------------------Set Date Billed in ADS COUNTS-----------


--Select * From zCust_OS_National.dbo.ADS_COUNTS
--where BILLINGDATE is null 

--Update zCust_OS_National.dbo.ADS_COUNTS
--Set BILLINGDATE = convert(date,Getdate())
--where BILLINGDATE is null 




 
------Added 20250321 - KL  for MAINSTAY Monitor Job - Per EC they are the SAME AS OS NATIONAL - only billed once per month-----------------------------------------------
----------------Billing - Billed once per month for the MAX number of MATCHED records in the portfolio during the billing cycle ---
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'Monitor'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,0					   --[TotalRecords]
       ,(Select count(*) from  [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING] with(NOLOCK)	where DATE_BILLED is null)   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0        --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'7617'                 --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'5000824'    --[AccountNumber]
      ,'Mainstay Labs' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



--Select * From [zCust_MainstayLabs].dbo.ADS_COUNTS where batchType like 'S12' and CreateDate > Getdate()-35 Order by CreateDate Desc

--Select top 100 *  from [zCust_MainstayLabs].dbo.INPUT_MONITOR with(NOLOCK)



Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '7617'  and Billingdate is null 



--------------Set Date Billed-----------


Select count(*) From [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is null 

Update [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into  [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING_HIST]
Select * From [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null 

Delete From [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null 

Select count(*) from [zCust_MainstayLabs].dbo.[INPUT_MONITOR_BILLING]

------------------Set Date Billed in ADS COUNTS-----------


Select * From [zCust_MainstayLabs].dbo.ADS_COUNTS
where BILLINGDATE is null 

Update [zCust_MainstayLabs].dbo.ADS_COUNTS
Set BILLINGDATE = convert(date,Getdate())
where BILLINGDATE is null 






 
------Added 20250402 - KL  for VALON MORTGAGE Monitor Job - -----------------------------------------------
----------------Billing - Billed once per month for the MAX number of MATCHED records in the portfolio during the billing cycle ---
----------****ALSO billed $2.00 Per TRANCACTION fee for each of the solutions
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'Monitor'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,0					   --[TotalRecords]
       ,(Select count(*) from  [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING] with(NOLOCK)	where DATE_BILLED is null)   --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0        --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'7659'                 --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'5000909'    --[AccountNumber]
      ,'Valon Mortgage' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]



	  


Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
where ticketnumber = '7659'  and Billingdate is null 





--------------Set Date Billed-----------


Select count(*) From [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is null 

Update [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING]
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null 

Insert into  [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING_HIST]
Select * From [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null 

Delete From [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING]
where DATE_BILLED is not null 

Select count(*) from [zCust_ValonMortgage].dbo.[INPUT_MONITOR_BILLING]

------------------Set Date Billed in ADS COUNTS-----------
-----Do not do this for Valon as they are charged per event fees as well!!!

----Select * From [zCust_ValonMortgage].dbo.ADS_COUNTS
----where BILLINGDATE is null 

----Update [zCust_ValonMortgage].dbo.ADS_COUNTS
----Set BILLINGDATE = convert(date,Getdate())
----where BILLINGDATE is null 




------Added 20200407 - KL  for Computershare Daily Batch job Job-----------------------------------------------------------
----------------Billing - $2.00 per Doc Image Returned---
---------Ticket 4457 is for the  $2.00 per image
-----20200424 - The job pushes the counts - no need to push them separately any longer
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--	   ,[DocImageCounts])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'BATCH'             --[BatchType]
--      ,DATE_RUN             --[CreateDate]
--      ,DATE_RUN              --[ImportDate]
--      ,0					   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,Sum(convert(int,[Images Delivered]))                      --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'4457'                 --[TicketNumber]
--      ,'3 - Bill for every record that had an event'   --[BillingOption]
--      ,'133084'    --[AccountNumber]
--      ,'ComputerShare' --[CustomerName]
--      ,'S50'                      --[CMASProductCode]
--      ,'S50 - Doc Images'  --[CMASProductName]
--	  ,Sum(convert(int,[Images Delivered]))  ----[DocImageCount]
	  
--from  zcust_Computershare_REL.dbo.[REL_BILLING]  A
--where DATE_BILLED is null --and DATE_RUN < '2020-04-01'
--Group by DATE_RUN
--Order by A.DATE_RUN


--Select ID, CustomerName,BatchType,CreateDate, TotalREcords, TotalWithEventsFound,
--CMASPRoductCOde, DocImageCounts, TicketNUmber
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where (Ticketnumber in ( '4457','5092')
--OR CustomerName like 'Computershare') and billingdate is null
--Order by CreateDate



------Covius----
--Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where TicketNumber = '4463'
--Order by Createdate desc


--Delete from [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where ID in (216374,216373,216375,216376,215201,216377,215214,216378,216379,216380,216381,216382,216383,216384,216385,216386,216387,216388,216389)

---------Testing----
--Select BatchType, sum( DocImageCounts)
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where (Ticketnumber in ( '4457','5092')
--OR CustomerName like 'Computershare') and billingdate is null
--Group by BatchType


--Select sum(	convert(int,[Images Delivered]	))
--From zcust_Computershare_REL.dbo.[REL_BILLING] 
--where  DATE_BILLED is null

----Select * From zcust_Computershare_REL.dbo.[REL_BILLING]
----where DATE_BILLED is null
------Order by DATE_RUN 
----Order by [Total Fee] 

--Select sum(	convert(int,[Images Delivered]	))
--From zcust_Computershare_ASN.dbo.[ASN_BILLING] 
--where  DATE_BILLED is null


--Select CreateDate, DocImageCounts, TicketNumber
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where (Ticketnumber in ( '4457','5092')
--OR CustomerName like 'COmputershare') and billingdate is null
--ORder by CreateDate,DocImageCounts

--Select TicketNumber, sum(DocImageCounts)
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where (Ticketnumber in ( '4457','5092')
--OR CustomerName like 'COmputershare') and billingdate is null
--Group by TicketNumber

--Select * From zcust_Computershare_REL.dbo.[REL_BILLING]
--where DATE_BILLED is null 
 
--Update zcust_Computershare_REL.dbo.[REL_BILLING] 
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null 


-------REL------
--Select BatchType, sum( DocImageCounts)
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where Ticketnumber in ( '4457')
--and billingdate IS NULL
--Group by BatchType


------Total records below should match total records in query above
--Select [Order Number],	[Loan Number]	,[Investor Code],	[Borrower Name]	,[County]	
--,[State],	[Fee Type],[Fee Description],	[Images Delivered]	,[Total Fee]
--,DATE_RUN
--From zcust_Computershare_REL.dbo.[REL_BILLING] 
--where  DATE_BILLED like convert(date,Getdate())
----Order by [Total Fee]
-- Order by DATE_RUN 



 

--Update zcust_Computershare_ASN.dbo.[ASN_BILLING] 
--Set DATE_BILLED = convert(date,Getdate())
--where DATE_BILLED is null 


 
-------ASN------
--Select BatchType, sum( DocImageCounts)
--From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where Ticketnumber in ( '5092')
--and billingdate IS NULL
--Group by BatchType


------Total records below should match total records in query above
--Select [Order Number],	[Loan Number]	,[Investor Code],	[Borrower Name]	,[County]	
--,[State],	[Fee Type],[Fee Description],	[Images Delivered]	,[Total Fee]
--,DATE_RUN
--From zcust_Computershare_ASN.dbo.[ASN_BILLING]  
--where  DATE_BILLED like convert(date,Getdate())
----Order by [Total Fee]
-- Order by DATE_RUN 


 



------Added 20190722 - KL  for GENESIS CAPITAL Monitor Job-----------------------------------------------------------
----------------Billing - $7.50 for initial run - $2.00 per month for ongoing runs---
---------Ticket 3788 is for the  $7.50 for the initial run per input record
---------Ticket 3712 is for the  $2.00 for the ongoing runs per input record
insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,COUNT(DISTINCT [INPUTKey])   --[TotalRecords]
      ,0                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0                       --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3788'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'132113'    --[AccountNumber]
      ,'Genesis Capital' --[CustomerName]
      ,'S60'                      --[CMASProductCode]
      ,'S60 - Portfolio Monitoring'  --[CMASProductName]

from  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN --Where RecordFlag = 'A'
where DATE_BILLED is null



Update zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null


--Select * From  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_INITIAL_RUN  as A 
--Where DATE_BILLED = convert(date,Getdate())


insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
      ,COUNT(DISTINCT [INPUTKey])   --[TotalRecords]
      ,0                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
      ,0                       --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3712'                 --[TicketNumber]
      ,'1 - Bill for every record in the Input file'   --[BillingOption]
      ,'132113'    --[AccountNumber]
      ,'Genesis Capital' --[CustomerName]
      ,NULL                    --[CMASProductCode]
      ,NULL --[CMASProductName]
	 --Select * 
	 from  zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING 
	  where DATE_BILLED  is null


Update zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING
Set DATE_BILLED = convert(date,Getdate())
where DATE_BILLED is null

Select DATE_BILLED, count(*) From zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING
Group by DATE_BILLED
Order by DATE_BILLED desc

----Truncate table zCust_GenesisCapital.dbo.INPUT_IN_MONITOR_BILLING_ONGOING 


-----Commented out 20191219 as no longer customer-----
------Added 20170104 - KL  for HTL Monitor Job-----------------------------------------------------------
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,COUNT(DISTINCT UNIQUEID)   --[TotalRecords]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'542'                 --[TicketNumber]
--      ,'1 - Bill for every record in the Input file'   --[BillingOption]
--      ,'119840'    --[AccountNumber]
--           ,'Home Title Lock' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'S60 - Portfolio Monitoring'  --[CMASProductName]
--from  zCust_ADS_HomeTitleLock.dbo.Input_Raw_Billing --Where RecordFlag = 'A'


--INSERT INTO zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_BillingHistory([UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]
--      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]      ,[OwnerName]      ,[RecordFlag]      ,[ProcessDate]      ,APN,[BillingDate])
--SELECT        [UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]      ,[ProcessDate]      ,[APN],Getdate()
--FROM            zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing



--Truncate table zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing

--Insert into zCust_ADS_HomeTitleLock.dbo.INPUT_RAW_Billing([UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]  ,[APN],[ProcessDate])
--Select [UniqueID]      ,[ClientName]      ,[CountyFIPS]      ,[Address]      ,[Unit]      ,[City]      ,[State]      ,[Zip]      ,[SubscriberStartDate]      ,[PreviousMaxDate]
--      ,[OwnerName]      ,[RecordFlag]      ,[APN],Getdate() 
--	  From zCust_ADS_HomeTitleLock.dbo.INPUT_IN_Monitor







------Added 20190501 - KL  for EVOLVE_VACA_RENTALS Monitor Job-----------------------------
------Job Cancelled 20231024 per Nick

---------20200320 - Per CR changed to billing type 2 - bill for every MATCHED record....

--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,(Select COUNT(DISTINCT INPUTKey) from  zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_IN_MONITOR)   --[TotalRecords]
--      ,(Select COUNT(DISTINCT [UNIQUE ID]) from  zCust_ADS_S15_EvolveVacaRentals.dbo.Input_Raw_Billing)   --[TotalMatched]
--	  ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'3465'                 --[TicketNumber]
--	  ,'2 - Bill for every record that was matched to a property'
--      --,'1 - Bill for every record in the Input file'   --[BillingOption]
--      ,'119840'    --[AccountNumber]
--           ,'Evolve Vacation Rental' --[CustomerName]
--      ,'S15'                      --[CMASProductCode]
--      ,'S15 - Sales Listings'  --[CMASProductName]
	  
--		--from  zCust_ADS_S15_EvolveVacaRentals.dbo.Input_Raw_Billing --Where RecordFlag = 'A'
	
--		Select * from zCust_ADS_S15_EvolveVacaRentals.dbo.ADS_COUNTS 
--		Order by CreateDate desc


--INSERT INTO zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_BillingHistory([Unique ID]
--      ,[Geocode: Street (clean)]
--      ,[Geocode: City (clean)]
--      ,[Apt#/Unit #]
--      ,[Zip]
--      ,[Geocode: State/Province (clean)]
--      ,[RECORD_TYPE]
--      ,[DATE_ADDED]
--      ,[DATE_DELETED]
--	  ,[BillingDate])
--SELECT       [Unique ID]
--      ,[Geocode: Street (clean)]
--      ,[Geocode: City (clean)]
--      ,[Apt#/Unit #]
--      ,[Zip]
--      ,[Geocode: State/Province (clean)]
--      ,[RECORD_TYPE]
--      ,[DATE_ADDED]
--      ,[DATE_DELETED]
--	  ,convert(date,Getdate())
--FROM            zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing



--Truncate table zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing

--Insert into zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_RAW_Billing([Unique ID]
--      ,[Geocode: Street (clean)]
--      ,[Geocode: City (clean)]
--      ,[Apt#/Unit #]
--      ,[Zip]
--      ,[Geocode: State/Province (clean)]
--      ,[RECORD_TYPE]
--      ,[DATE_ADDED]
--      ,[DATE_DELETED])
--Select [INPUTKey]
--      ,[INPUTAddress]
--	   ,[INPUTCity]
--      ,[INPUTUnit]
--	   ,[INPUTZip]
--      ,[INPUTState]
--      ,[INPUTRecordType]
--      ,[DATE_ADDED]
--      ,[DATE_DELETED]
--	  From zCust_ADS_S15_EvolveVacaRentals.dbo.INPUT_IN_Monitor
--	  where REF_ID is not null




------Added 20170105 - KL  for 1Tract Monitor Job Doc Image Counts-----
----20210125 - Commented out as job is no longer running

--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--	  ,[DocImageCounts]
--	  ,STATE)
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--      ,0                       --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,0                       --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'1096'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'120268 '    --[AccountNumber]
--           ,'1Tract ' --[CustomerName]
--      ,'S50'                      --[CMASProductCode]
--      ,'Doc Images'  --[CMASProductName]
--	  ,sum([DocImageCounts])
--	  ,STATE
--	  FROM zCust_ADS_S20_1Track.dbo.ADS_COUNTS 
--		Where 
--		DATE_BILLED is null and
--		DocImageCounts > 0
--		and CmasProductCOde = 'S50 - Doc Images'
--		Group by STATE


-------Added 20170105 for 1Tract Matched Record Count---


-- Update A
--	  Set  A.[INPUTMonitorStartDate] = B.[INPUTMonitorStartDate]
--	  ,A.[PropertyAddress] = B.[PropertyAddress]
--      ,A.[City] = B.[City]
--      ,A.[State] = B.[State]
--      ,A.[ZipCode] = B.[ZipCode]
--      ,A.[CoverageStatus] = B.[CoverageStatus]
--      ,A.[AddressStandardization] = B.[AddressStandardization]
--      ,A.[PropertyStatus] = B.[PropertyStatus]
--	  --Select * 
--	  From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING] as A join zCust_ADS_S20_1Track.dbo.[x_Custom_OUTPUT] as B on 
--	   A.Inputkey = B.Inputkey



--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--	  ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--	  ,Count(*)
--      ,Count(*)                --[TotalMatched]
--      ,0                       --[TotalUnMatched]
--      ,0                       --[TotalDuplicate]
--      ,0                       --[TotalExpired]
--      ,0                       --[TotalInCoverage]
--      ,0                       --[TotalNotInCoverage]
--      ,Count(*)                --[TotalPropertiesFound]
--      ,0                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,0                       --[TotalMultiplePropertiesFound]
--      ,0                       --[TotalAddressStandardized]
--      ,0                       --[TotalAddressNotStandardized]
--      ,0                       --[TotalWithEventsFound]
--      ,0                       --[TotalWithoutEventsFound]
--      ,'1096'                 --[TicketNumber]
--      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
--      ,'120268 '    --[AccountNumber]
--           ,'1Tract ' --[CustomerName]
--      ,'S60'                      --[CMASProductCode]
--      ,'Portfolio Monitoring'  --[CMASProductName]
----Select count(*)
--from  
--zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]
--  where [PropertyStatus] like 'Property Found'
--  and [CoverageStatus] like 'In Coverage'
  



----Select * From zCust_ADS_S20_1Track.dbo.ADS_COUNTS

--	Select * From zCust_ADS_S20_1Track.dbo.ADS_COUNTS
--	where DATE_BILLED is null

--  UPdate zCust_ADS_S20_1Track.dbo.ADS_COUNTS
--  Set DATE_BILLED = convert(varchar(10),Getdate(),112)
--  where DATE_BILLED is null

--  Insert into zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST]
--  Select *, convert(varchar(10),Getdate(),112) From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]

  
--  --Select * From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST]

--  -- Select * From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING_HIST] 
--  --where DATE_BILLED = '20181126' and [PropertyStatus] like 'Property Found'
--  --and [CoverageStatus] like 'In Coverage'
--  --order by DATE_BILLED desc

--  Truncate table zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]

--  Insert into zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR_BILLING]([INPUTKey],[ClientName],[INPUTAddress],[INPUTUnitNbr],[INPUTCity],[INPUTState],[INPUTZip],[INPUTAPN],[AgencyID],[FileID],[FileNbr])
--  Select [INPUTKey],[ClientName],[INPUTAddress],[INPUTUnitNbr],[INPUTCity],[INPUTState],[INPUTZip],[INPUTAPN],[AgencyID],[FileID],[FileNbr]
--  From zCust_ADS_S20_1Track.dbo.[INPUT_IN_MONITOR] where RecordFlag not like 'D'




  -------------------------Pitch Point Listing S15 Monitor--------------------
  ----------------------Cancelled 8/22/2019-------------------------
----  --Select * from  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
----  --where CMASProductName like '%NMLS%' 

----  --Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode,CMASProductName,OracleProductCode,OracleProductName)
----  --Values('Bulk - PACE','Bulk - PACE','18719','Bulk - PACE')

----  -- Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode,CMASProductName,OracleProductCode,OracleProductName)
----  --Values('S86','PACE','16647','ADS - PACE')

----  Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
----  where CustomerName like 'Pitch%'

  
----insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
----      ,[BatchType]
----      ,[CreateDate]
----      ,[ImportDate]
----	  ,[TotalRecords]
----      ,[TotalMatched]
----      ,[TotalUnMatched]
----      ,[TotalDuplicate]
----      ,[TotalExpired]
----      ,[TotalInCoverage]
----      ,[TotalNotInCoverage]
----      ,[TotalPropertiesFound]
----      ,[TotalPropertiesNotFound]
----      ,[IsBillable]
----      ,[TotalMultiplePropertiesFound]
----      ,[TotalAddressStandardized]
----      ,[TotalAddressNotStandardized]
----      ,[TotalWithEventsFound]
----      ,[TotalWithoutEventsFound]
----      ,[TicketNumber]
----      ,[BillingOption]
----      ,[AccountNumber]
----      ,[CustomerName]
----      ,[CMASProductCode]
----      ,[CMASProductName])
----       SELECT 'SQL ADS'      --[AppSource]
----      ,'MONITOR'             --[BatchType]
----      ,GetDate()               --[CreateDate]
----      ,GetDate()               --[ImportDate]
----	  ,Count(*)				   --[TotalRecords]
----      ,NULL                   --[TotalMatched]
----      ,NULL                       --[TotalUnMatched]
----      ,NULL                       --[TotalDuplicate]
----      ,NULL                       --[TotalExpired]
----      ,NULL                       --[TotalInCoverage]
----      ,NULL                       --[TotalNotInCoverage]
----      ,NULL                --[TotalPropertiesFound]
----      ,NULL                       --[TotalPropertiesNotFound]
----      ,'YES'                 --[IsBillable]
----      ,NULL                       --[TotalMultiplePropertiesFound]
----      ,NULL                       --[TotalAddressStandardized]
----      ,NULL                       --[TotalAddressNotStandardized]
----      ,NULL                       --[TotalWithEventsFound]
----      ,NULL                       --[TotalWithoutEventsFound]
----      --,'1714'                 --[TicketNumber]
----	  ,'2818'                 --[TicketNumber] - Changed 20181212 for new profile
----	  ,'1 - Bill for every record in the Input file'   --[BillingOption]
----      ,'120141 '    --[AccountNumber]
----      ,'Pitch Point ' --[CustomerName]
----      ,'S15'                      --[CMASProductCode]
----      ,'Sales Listings'  --[CMASProductName]

---- FROM [zCust_ADS_S15_PitchPoint].[dbo].[INPUT_IN_MONITOR_BILLING]


---- Insert into [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING_HIST
---- Select * From [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING

---- TRUNCATE TABLE [zCust_ADS_S15_PitchPoint].[dbo].INPUT_IN_MONITOR_BILLING




 
  -------------------------Reed Smith S20 Monitor----CANCELLED 20180725 PER MD----------------
--  Select * from  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] 
  
--insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--	  ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[CustomerName]
--      ,[CMASProductCode]
--      ,[CMASProductName])
--       SELECT 'SQL ADS'      --[AppSource]
--      ,'MONITOR'             --[BatchType]
--      ,GetDate()               --[CreateDate]
--      ,GetDate()               --[ImportDate]
--	  ,Count(*)				   --[TotalRecords]
--      ,NULL                   --[TotalMatched]
--      ,NULL                       --[TotalUnMatched]
--      ,NULL                       --[TotalDuplicate]
--      ,NULL                       --[TotalExpired]
--      ,NULL                       --[TotalInCoverage]
--      ,NULL                       --[TotalNotInCoverage]
--      ,NULL                --[TotalPropertiesFound]
--      ,NULL                       --[TotalPropertiesNotFound]
--      ,'YES'                 --[IsBillable]
--      ,NULL                       --[TotalMultiplePropertiesFound]
--      ,NULL                       --[TotalAddressStandardized]
--      ,NULL                       --[TotalAddressNotStandardized]
--      ,NULL                       --[TotalWithEventsFound]
--      ,NULL                       --[TotalWithoutEventsFound]
--      ,'1851'                 --[TicketNumber]
--      ,'1 - Bill for every record in the Input file'   --[BillingOption]
--      ,'130253 '    --[AccountNumber]
--      ,'Reed Smith ' --[CustomerName]
--      ,'S20'                      --[CMASProductCode]
--      ,'Custom Solution'  --[CMASProductName]

-- FROM [zCust_ADS_S20_ReedSmith].[dbo].[INPUT_IN_MONITOR_BILLING]


-- Insert into [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING_HIST
-- Select * From [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING

-- TRUNCATE TABLE [zCust_ADS_S20_ReedSmith].[dbo].INPUT_IN_MONITOR_BILLING


------------------------------BANK OF AMERICA HOA LIENS-----SUBMIT MAX NUMBER OF MATCHED RECORDS EACH MONTH PER NH 20180824-------


insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
	  ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT distinct 'SQL ADS'      --[AppSource]
      ,'MONITOR'             --[BatchType]
      ,GetDate()               --[CreateDate]
      ,GetDate()               --[ImportDate]
	  ,NULL    		  --[TotalRecords]
      ,(Select MAX(TotalMatched) as PropertiesMatched 	FROM zcust_boa.dbo.ADS_COUNTS	
				WHERE 	Convert(date,CreateDate) >= convert(date,Getdate()-31)  )                --[TotalMatched]
      ,NULL                       --[TotalUnMatched]
      ,NULL                       --[TotalDuplicate]
      ,NULL                       --[TotalExpired]
      ,NULL                       --[TotalInCoverage]
      ,NULL                       --[TotalNotInCoverage]
      ,NULL                --[TotalPropertiesFound]
      ,NULL                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,NULL                       --[TotalMultiplePropertiesFound]
      ,NULL                       --[TotalAddressStandardized]
      ,NULL                       --[TotalAddressNotStandardized]
      ,NULL                       --[TotalWithEventsFound]
      ,NULL                       --[TotalWithoutEventsFound]
      ,'2134'                 --[TicketNumber]
      ,'2 - Bill for every record that was matched to a property'   --[BillingOption]
      ,'130667 '    --[AccountNumber]
      ,'Bank of America ' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'Custom Solution'  --[CMASProductName]
	  
 FROM [zCust_BOA].[dbo].[ADS_COUNTS]


Select MAX(TotalMatched) as PropertiesMatched 	FROM zcust_boa.dbo.ADS_COUNTS	
WHERE 	Convert(date,CreateDate) >= convert(date,Getdate()-31)  

  Select * From zcust_boa.dbo.ADS_COUNTS
 where Convert(date,CreateDate) >= convert(date,Getdate()-31)  
 Order by TotalMatched desc


 Select *  From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where TicketNumber = 2134

 --Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 --where ID = 248196
-------------------------------------------------------------------------

	-- Rerun step
-- UPDATE CMAS.dbo.AutomatedBilling SET BillingDate = NULL
-- DELETE CMAS.dbo.AutomatedBilling WHERE CMASProductName = 'S50 - Doc Images'

--Drop table dbo.TEST
--Select * into dbo.TEST
--from [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]

-----------------Everything in the queue ---------------

Select A.ID,A.TicketNumber,A.CustomerName, A.CreateDate,A.BatchType,B.Title,CUrrent_x0020_Status as Status
, A.TotalRecords, A.BillingOption,A.TotalWithEventsFound,A.TotalMatched,A.TotalBillableUnits, A.AccountNumber
,A.[CMASProductName]
,A.CMASProductCOde, 
Replace(Product,';#','') as Product
,A.OracleProductCode, A.ContractExecuted
,A.DocImageCounts
,Billing_x0020_Type as Billing_Type
,Billing_x0020_Number as CustomerNumber
,A.BillingDate
,A.NUM_PRODUCTS
,A.Product1
,A.Product2
,A.Product3
,B.SOW
,B.WO
,A.BillingDate
,Replace(Assigned_x0020_f,';#',' ') as Assignee
From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
on A.ticketNumber = B.ID
where 
(A.BillingDate is  null or (A.BillingDate > Getdate()-1.25 and A.BillingOption  not like 'Monthly Fee' and A.BillingOption  not like 'N/A - Non-billable'))
and B.CUrrent_x0020_Status not like '18-Request Cancelled'
order by Client_X0020_Name,B.Title, A.TicketNumber,A.CreateDate, A.BatchType


--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
--where CustomerName like 'OS%National'
----or Billingdate is not null


--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--where ID in (317010)



--Delete 
----Select ID, CustomerName, CMASProductCOde, BillingDate, BillingOption, Ticketnumber, Status  
--from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--where ID in (250402,251890,251891,250592,250945,250946,255326,255354,255355,259348,259349,259350,259351,259352,259353,259354,259355,254794,254622,261372,
--261373,261374,261375,261376,261377,261378,261379,261380,261381,261382,261383,261384,261385,261386,261387,261388,261389,261390,261391,261392,261393,261394,
--261395,261396,261397,261398,261399,261400,261401,261402,261403,259885,259886,259887,259888,259889,259890,259891,259892,259893,259894,259895,259896,259897,
--259898,259899,259900,255820,255821,255822,255823)
----Order by CustomerName




--Select ID,CustomerName, BatchType, CReateDate, TotalRecords,TotalWithEventsFound,BillingDate,BillingOption, AccountNumber, DocImageCounts 
--into xklowe.dbo.ALREDAY_BILLED_20210623
--From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
--where 
----convert(date,BillingDate) = '2021-05-22'
----and 
--CreateDate < '2021-05-24'
--Order by A.CustomerName,A.CReateDate

--Delete from  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--where 
--CreateDate < '2021-05-24'

--Delete  From A
----Select A.CustomerName, A.BatchType, A.CReateDate, A.TotalRecords,A.TotalWithEventsFound,A.BillingDate,A.BillingOption, A.AccountNumber, A.DocImageCounts 
--From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
--join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory B on 
--A.CustomerName = B.CustomerName
--and A.CReateDate = B.CReateDate
--and A.TotalRecords = B.TotalRecords
----and A.DocImageCounts = B.DocImageCounts
--where convert(date,A.BillingDate) = '2021-05-22'
--and A.CreateDate < '2021-04-23'
--and A.CustomerName like 'Dividend Finance'
----Order by A.CustomerName,A.CReateDate

Select A.CustomerName, A.BatchType, A.CReateDate, A.TotalRecords,A.TotalMatched,A.BillingDate,A.BillingOption, A.AccountNumber, A.DocImageCounts 
From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBilling A
where CustomerName like 'Dividend Finance%'
Order by CreateDate desc


Select A.CustomerName, A.BatchType, A.CReateDate, A.TotalRecords,A.TotalWithEventsFound,A.BillingDate,A.BillingOption, A.AccountNumber, A.DocImageCounts 
From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory A
where CustomerName like 'Dividend Finance%'
Order by CreateDate desc






--INSERT INTO [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] (
--       [Id]
--      ,[AppSource]
--      ,[BatchId]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingDate]
--      ,[ExtractionDate]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[DaysToMonitor]
--      ,[CustomerName]
--      ,[ClientName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--      ,[OracleProductCode]
--      ,[OracleProductName]
--      ,[Title]
--      ,[DocImageCounts]
--      ,[MonitorEndDate]
--      ,[TotalBillableUnits]
--      ,[ContractExecuted]
--	  ,SOW
--	  ,WO)
--SELECT [Id]
--      ,[AppSource]
--      ,[BatchId]
--      ,[BatchType]
--      ,[CreateDate]
--      ,[ImportDate]
--      ,[TotalRecords]
--      ,[TotalMatched]
--      ,[TotalUnMatched]
--      ,[TotalDuplicate]
--      ,[TotalExpired]
--      ,[TotalInCoverage]
--      ,[TotalNotInCoverage]
--      ,[TotalPropertiesFound]
--      ,[TotalPropertiesNotFound]
--      ,[IsBillable]
--      ,[TotalMultiplePropertiesFound]
--      ,[TotalAddressStandardized]
--      ,[TotalAddressNotStandardized]
--      ,[TotalWithEventsFound]
--      ,[TotalWithoutEventsFound]
--      ,[TicketNumber]
--      ,[BillingDate]
--      ,GETDATE() -- [ExtractionDate]
--      ,[BillingOption]
--      ,[AccountNumber]
--      ,[DaysToMonitor]
--      ,[CustomerName]
--      ,[ClientName]
--      ,[CMASProductCode]
--      ,[CMASProductName]
--      ,[OracleProductCode]
--      ,[OracleProductName]
--      ,[Title]
--      ,[DocImageCounts]
--      ,[MonitorEndDate]
--      ,[TotalBillableUnits]
--      ,[ContractExecuted]
--	  ,SOW
--	  ,WO
-- FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--WHERE 
--((BillingDate IS NOT NULL and PROCESSED_YN = 'Y')
-- or ([BillingOption] like 'N/A - Non-billable' and BillingDate IS NOT NULL))
--AND convert(date,BillingDate) = '2021-05-22'
--and CreateDate < '2021-04-23'


--Select CustomerName, BatchType, CReateDate, TotalRecords,TotalWithEventsFound,BillingDate,BillingOption, AccountNumber, DocImageCounts 
--From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory A
--where 
----convert(date,BillingDate) = '2021-05-22'
----and 
--CreateDate < '2021-04-23'
--and CustomerName like 'Covius'
--Order by A.CustomerName,A.CReateDate desc




--Select CustomerName, BatchType, CReateDate, TotalRecords, BillingDate, AccountNumber, DocImageCounts From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where Ticketnumber = 5092
--Order by CreateDate 

Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] as A 
join  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHISTORY] as B 
on A.TicketNumber = B.TicketNumber
and A.CreateDate = B.CreateDate
and A.TotalRecords = B.TotalRecords


--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--Set TotalWithEventsFound = NULL
--where ID in (234038,234045,234055)

--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
--where ID in (248948,247713,247727,247736,248553)

Select ID,TicketNumber,CustomerName, BatchType, CreateDate, TotalRecords, TotalMatched, TotalWithEventsFound 
,CMASProductCode
From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ( '3465','4393','4388','4895')
and BillingDate is null
Order by BatchType,CreateDate

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
where ID in ( '3465','4393','4388','4895')



Select ID, Ticketnumber, CreateDate, TotalRecords, CustomerName, TotalMatched, BillingOption From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where CustomerName like 'Computersh%'
Order by A.Ticketnumber, A.CreateDate

Select ID, Ticketnumber, CreateDate, TotalRecords, CustomerName, TotalMatched From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
where CustomerName like 'Situs AMC%'
Order by A.CreateDate

-------------------------------CHECK FOR TICKETS NOT PUSHED TO BILLING-----------------------
Select A.ID as Sharepoint_Ticket, Client_X0020_Name as Customer_Name,A.Title, Requested_x0020_Data_x0020_Type as RequestType,
Request_x0020_Type as PROD_EVAL,Actual_x0020__x002d__x0020_Scopi as ExpirationDate,
CUrrent_x0020_Status as Status,
Replace(Product,';#','') as Product, Replace(Assigned_x0020_f,';#',' ') as Assignee,Billing_x0020_Type as Billing_Type
, Billing_x0020_Number as CustomerNumber,Created,Modified,Due_X0020_Date as Due_Date, 
Date_x0020_Delivered_x0020_to_x0 as Delivered_Date
,Replace(Replace(Replace(Replace(Right(SME_x0020_Notes_x0020_to_x0020_d,len(SME_x0020_Notes_x0020_to_x0020_d)-Charindex('>\\corp.',SME_x0020_Notes_x0020_to_x0020_d)),'</a>',''),'</p>',''),'</div>',''),'<p>','')
as Workorder_Loc
,Sales_x0020_Rep0 as SalesRep
,Author as Author

 --From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
 FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] as B with(NOLOCK) on A.ID = B.TicketNumber
left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].AutomatedBillingHistory as C with(NOLOCK) on A.ID = C.TicketNumber
where A.CUrrent_x0020_Status like '%Closed%' 
and B.TicketNumber is null
and C.TicketNumber is null
AND Modified >= Getdate()-30
and left(Billing_x0020_Type,1)  in ('1','2','3','4','5')





Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]
where Client_X0020_Name like 'Loan Depot%'




---------------------------INSERT MISSING TICKETS-------------------------
DECLARE @TICKETNUMBER3 varchar(20)
DECLARE @TOTAL3 bigint

Set @TICKETNUMBER3 = '8054'
Set @TOTAL3 = '733'

EXEC('
	INSERT INTO [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
			  ,[BatchId]
			  ,[BatchType]
			  ,[CreateDate]
			  ,[ImportDate]
			  ,[TotalRecords]
			  ,[TotalMatched]
			  ,[TotalUnMatched]
			  ,[TotalDuplicate]
			  ,[TotalExpired]
			  ,[TotalInCoverage]
			  ,[TotalNotInCoverage]
			  ,[TotalPropertiesFound]
			  ,[TotalPropertiesNotFound]
			  ,[IsBillable]
			  ,[TotalMultiplePropertiesFound]
			  ,[TotalAddressStandardized]
			  ,[TotalAddressNotStandardized]
			  ,[TotalWithEventsFound]
			  ,[TotalWithoutEventsFound]
			  ,[TicketNumber]
			  ,[BillingDate]
			  ,[ExtractionDate]
			  ,[BillingOption]
			  ,[AccountNumber]
			  ,[DaysToMonitor]
			  ,[CustomerName]
			  ,[ClientName]
			  ,[CMASProductCode]
			  ,[CMASProductName]
			  ,[OracleProductCode]
			  ,[OracleProductName]
			  ,[Title]
			  ,[DocImageCounts]
			  ,[MonitorEndDate])
			Select ''SQL ADS''----AppSource
			,NULL----BatchId
			,''BATCH''----BatchType
			,Getdate()----CreateDate
			,NULL----ImportDate
			,''' + @TOTAL3 + '''----TotalRecords
			,''' + @TOTAL3 + '''----TotalMatched
			,''0''----TotalUnMatched
			,''0''----TotalDuplicate
			,''0''----TotalExpired
			,''' + @TOTAL3 + '''----TotalInCoverage
			,''0''----TotalNotInCoverage
			,''' + @TOTAL3 + '''----TotalPropertiesFound
			,''0''----TotalPropertiesNotFound
			,''YES''----IsBillable
			,''0''----TotalMultiplePropertiesFound
			,''0''----TotalAddressStandardized
			,''0''----TotalAddressNotStandardized
			,''' + @TOTAL3 + '''----TotalWithEventsFound
			,''0''----TotalWithoutEventsFound
			,ID----TicketNumber
			,NULL----BillingDate
			,NULL----ExtractionDate
			,Billing_x0020_Type----BillingOption
			,Billing_x0020_Number----AccountNumber
			,NULL----DaysToMonitor
			,Client_x0020_Name----CustomerName
			,NULL----ClientName
			,NULL----(No column name)
			,NULL----CMASProductName
			,NULL----OracleProductCode
			,NULL----OracleProductName
			,NULL----Title
			,''0''----DocImageCounts
			,NULL----MonitorEndDate

			FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] 
			where ID = ''' + @TICKETNUMBER3 + '''


			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
			where TicketNumber = ''' + @TICKETNUMBER3 + '''

			Select * From [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
			where TicketNumber = ''' + @TICKETNUMBER3 + '''

			')



--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where ID in (70517,70609)

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ( '6280','5400')



----------------------------Nicoles query to check for closed tickets------------------------------------------------------
Select  A.ID as Sharepoint_Ticket, Client_X0020_Name as Customer_Name,A.Title, Requested_x0020_Data_x0020_Type as RequestType,
Request_x0020_Type as PROD_EVAL,Actual_x0020__x002d__x0020_Scopi as ExpirationDate,
CUrrent_x0020_Status as Status,
Replace(Product,';#','') as Product, Replace(Assigned_x0020_f,';#',' ') as Assignee,Billing_x0020_Type as Billing_Type
, Billing_x0020_Number as CustomerNumber,Created,Modified,Due_X0020_Date as Due_Date, 
Date_x0020_Delivered_x0020_to_x0 as Delivered_Date
,Replace(Replace(Replace(Replace(Right(SME_x0020_Notes_x0020_to_x0020_d,len(SME_x0020_Notes_x0020_to_x0020_d)-Charindex('>\\corp.',SME_x0020_Notes_x0020_to_x0020_d)),'</a>',''),'</p>',''),'</div>',''),'<p>','')
as Workorder_Loc
,Sales_x0020_Rep0 as SalesRep
,Author as Author

,Record_x0020_Count as RecordCount
,Priority

--from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] as B with(NOLOCK) on A.ID = B.TicketNumber
left outer join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as C on A.ID = C.TicketNumber 
Where A.Date_x0020_Delivered_x0020_to_x0 >= '2019-11-19' and A.Modified > '2021-04-23' and 
A.Billing_x0020_Type not in ('N/A - Non-billable','Monthly Fee','Self-Reported Usage')
And A.CUrrent_x0020_Status not like '18-Request Cancelled'
and B.TicketNumber is null
and C.TicketNumber is null
Order by Client_X0020_Name
--------------------------------------------------------------------------------------------------------------------------------------------------
--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--Set BillingOption = 'N/A - Non-billable'
--where Ticketnumber in (1884,1857,1660,1700,1754,1808)


Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ('6136')

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where TicketNumber in ('5399','5333','5365','5346','5339')


Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] as A with(NOLOCK)
where ID = '4895'

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
where CustomerName like 'Alliance%'

Select *  From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where CustomerName like 'Green%'

--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--where ID in (70580,70583)


Select TicketNumber, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A where ticketnumber in ('1724','1691','1697','1684')
Order by A.ticketnumber,Createdate desc


Select TicketNumber, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
where CustomerName like 'AAM%'
Order by Createdate desc

Select TicketNumber, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] 
where CustomerName like 'AAM%'
Order by Createdate desc

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend] where ID = '454'






-- Delete last months processed ARCHIVE jobs

	Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate, B.BillingDate,A.DocImageCounts, B.DocImageCounts FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	inner join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	A.TicketNumber = B.TicketNumber
	and 
	A.BillingDate = B.BillingDate
	and 
	ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	and A.CreateDate = B.Createdate
	and
	A.TotalBillableUnits = B.TotalBillableUnits
    WHERE A.BillingDate IS NOT NULL
	--and A.CustomerName like '1Tract'
	order by A.CustomerName, A.TicketNumber,A.CreateDate


	Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	where BillingDate is not null
	Order by BillingDate

	Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	where Ticketnumber in ('2994')

	Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
	where Ticketnumber in ('2994')




	--Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate, A.BillingDate,A.TotalRecords,A.TotalBillableUnits FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	--WHERE A.BillingDate IS NOT NULL
	--order by A.CustomerName, A.TicketNumber,A.CreateDate

	--Select A.CustomerName, A.ticketNumber, A.TotalRecords, A.CreateDate,A.BillingDate,A.TotalRecords,A.TotalBillableUnits FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]  AS A
	--WHERE A.BillingDate IS NOT NULL and A.TicketNumber = '1096' and A.CreateDate = '2017-06-23 11:44:11.263'
	--order by A.CustomerName, A.TicketNumber,A.CreateDate



	--DELETE A
	----Select A.* 
	--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	--inner join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	--A.TicketNumber = B.TicketNumber
	--and 
	--A.BillingDate = B.BillingDate
	--and 
	--ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	--and
	--ISNULL(A.TotalBillableUnits,'') = ISNULL(B.TotalBillableUnits,'')
	--and A.createdate = B.createdate
	----where A.CreateDate < '2021-05-24'
 --   WHERE A.BillingDate IS NOT NULL --AND BillingOption != 'N/A - Non-billable'

	--Delete 
	----Select * 
	--from [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	--where BillingDate < '2017-12-25 06:43:16.017'

---------------------------------------------------------PROCESS BILLING FILE----------------------------------------------------------------------------------------
-- Update the automated billing table where Share Point ID equals automated billing ticket number.
		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO =  cast(cast(left(MA.WO,3) as money) as int)  
		--Select MA.WO,ISNUMERIC(MA.WO) 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		--JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		and ISNUMERIC(MA.WO) = 1
		--WHERE MA.Current_x0020_Status = '15-Closed'
--        WHERE MA.Date_x0020_Delivered_x0020_to_x0 > DATEADD(month, -1, GETDATE()) AND MA.Current_x0020_Status = '15-Closed'
		--AND
		--AB.TicketNumber   in (6842)

		--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where TicketNumber   in (3466,4537)
		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO =  MA.WO 
		--Select MA.WO,ISNUMERIC(MA.WO) 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		--JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		and ISNUMERIC(MA.WO) = 0

		

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where ticketnumber in (3788,3712)

		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.Billing_X0020_Type,MA.Client_x0020_Name,MA.Billing_x0020_Number,REPLACE(MA.Product,';#',''),MA.Title,MA.Contract_x0020_Executed,MA.CUrrent_x0020_Status
		--,cast(cast(left(MA.SOW,3) as money) as int) ,cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.*
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		--JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE 
		AB.BillingDate IS  NULL 
		and ISNUMERIC(MA.WO) = 1
		--and 
		--AB.ticketnumber = '6842'

		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		--AB.CMASProductName = REPLACE(MA.Product,';#',''),
		--AB.CMASProductCode = REPLACE(MA.Product,';#',''),
		--AB.CMASProductName = null,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = MA.WO
		--Select MA.Billing_X0020_Type,MA.Client_x0020_Name,MA.Billing_x0020_Number,REPLACE(MA.Product,';#',''),MA.Title,MA.Contract_x0020_Executed,MA.CUrrent_x0020_Status
		--,cast(cast(left(MA.SOW,3) as money) as int) ,cast(cast(left(MA.WO,3) as money) as int) 
		--Select MA.*
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		--JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE 
		AB.BillingDate IS  NULL 
		and ISNUMERIC(MA.WO) = 0
		

	-------Update CreateDate where null
		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null

		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null

	-----------------Determine number of products & split them out------------------
		
		--Update A
		--Set 
		--A.NUM_PRODUCTS = (Select case when product not like ';#%' then 1  else ((len(product) - Len(Replace(Product,';#','')))/2)-1 end ) 
	
		--,A.PRODUCT1 = case when product not like ';#%' then left(Product,3) else left((Replace(Product,';#','')),charindex(';#',Product,3)-3)  end
		--,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
		--	left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
		--,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
		--	left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

		--,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
		--	left((Replace(Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),';#','')),charindex(';#',Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),3)-3)  END

		--,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
		--	left((Replace(Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),';#','')),charindex(';#',Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),3)-3))
		--	)
		--		-5),';#','')),charindex(';#',Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),';#','')),charindex(';#',Right(Product,len(product)-(
		--		len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
		--	+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
		--	,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
		--	Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
		--	,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
		--	)
		--		-3),3)-3))
		--	)
		--		-5),3)-3) END
	
		
		----Select * 
		--From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		--join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		--on A.ticketNumber = B.ID
		--where 
		--A.NUM_PRODUCTS is null
		--AND 
		--LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		----AND 
		----A.TicketNumber   in (5380,5400)


		------Revised above 20221004 as sharepoint appears to no longer be using ;# - just using commas....
		Update A
		Set 
		A.NUM_PRODUCTS = (Select case when product not like ';#%' and product not like '%,%'  then 1  else ((len(product) - Len(Replace(Product,';#','')))/2)-1 end ) 
	
		,A.PRODUCT1 = case when product not like ';#%' and product not like '%,%'  then left(Product,3) else left((Replace(Product,';#','')),charindex(';#',Product,3)-3)  end
		,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
			left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
		,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
			left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

		,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3)  END

		,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),3)-3) END
	
		
		--Select Product 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		--A.TicketNumber   in (6332)
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		AND  product  like ';#%'
		--AND
		--A.TicketNumber   in (6842)




		
		------Revised above 20221004 as sharepoint appears to no longer be using ;# - just using commas....
		Update A
		Set 
		A.NUM_PRODUCTS = (Select ((len(product) - Len(Replace(Product,',','')))+1) ) 
	
		,A.PRODUCT1 =  left((Replace(Product,',','')),charindex(',',Product,3)-3)  
		,A.PRODUCT2 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 2 then '' else 
			left(right(Product,len(product)-charindex(',',Product)),3) END
		,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 3 then '' else 
			left(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))),3) END

		,A.PRODUCT4 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 4 then '' else 
			left(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))),3) END

		,A.PRODUCT5 = case when ((len(product) - Len(Replace(Product,',','')))+1) < 5 then '' else 
			left(right(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))))
		,len(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))))
		-charindex(',',right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))))),3) END
	
		
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		--A.TicketNumber   in (6332)
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		AND  product  not like ';#%' and Product like '%,%'
		--AND
		--A.TicketNumber   in (6842)


			
		------20221121 - Updated for just one S50 product....
		Update A
		Set 
		A.NUM_PRODUCTS = 1
	
		,A.PRODUCT1 =  LTRIM(RTRIM(Product))
	
		--Select TicketNumber ,Product,NUM_PRODUCTS,A.PRODUCT1,A.PRODUCT2,LTRIM(RTRIM(Product))
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		--A.TicketNumber   in (7198)
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		AND  product  not like ';#%' and Product not like '%,%' and Product like '% - %'
		--AND
		--A.TicketNumber   in (6842)


		------20241122 - Updated for Taxsource....
		Update A
		Set 
		A.NUM_PRODUCTS = 1
	
		,A.PRODUCT1 =  LTRIM(RTRIM(Product))
	
		--Select TicketNumber ,Product,NUM_PRODUCTS,A.PRODUCT1,A.PRODUCT2,LTRIM(RTRIM(Product))
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		A.TicketNumber   in (7352)
		AND A.NUM_PRODUCTS is null
		
		

		----------------------TEST PRODUCT NUM!!!!!-----------------
		Select ticketnumber, CustomerName, BillingOption, CMAS_PRODUCT_SHAREPOINT
		,Product
		,Num_Products
		,PRODUCT1	,PRODUCT2	,PRODUCT3, PRODUCT4, PRODUCT5, A.CreateDate
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		Num_Products is null
		Order by A.Num_Products


		Select ticketnumber, CustomerName, BillingOption--, CMAS_PRODUCT_SHAREPOINT
		,Product
		,Num_Products
		,PRODUCT1	,PRODUCT2	,PRODUCT3, PRODUCT4, PRODUCT5
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(Product like '%,%'
		or ticketnumber = '7198')
		and (Num_Products <> ((len(product) - Len(Replace(Product,',','')))+1)
		OR Num_Products is null)
		and Product like '%,%'
		Order by Num_Products

		
		Select ticketnumber, CustomerName, BillingOption--, CMAS_PRODUCT_SHAREPOINT
		,Product
		,Num_Products
		,((len(product) - Len(Replace(Product,'#','')))-1)
		,PRODUCT1	,PRODUCT2	,PRODUCT3, PRODUCT4, PRODUCT5
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(Product like '%#%')
		and (Num_Products <> ((len(product) - Len(Replace(Product,'#','')))-1)
		OR Num_Products is null)
		Order by Num_Products



			--Update A
			--Set 
			--A.NUM_PRODUCTS = (Select case when product not like ';#%' then 1 else ((len(product) - Len(Replace(Product,';#','')))/2)-1 end)
		
			--,A.PRODUCT1 = case when product not like ';#%' then left(product,3)  else left((Replace(Product,';#','')),charindex(';#',Product,3)-3) end
			--,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
			--left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
			--,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
			--left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

			--,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
			--left((Replace(Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),';#','')),charindex(';#',Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),3)-3)  END

			--,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
			--left((Replace(Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),';#','')),charindex(';#',Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),3)-3))
			--)
			--	-5),';#','')),charindex(';#',Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),';#','')),charindex(';#',Right(Product,len(product)-(
			--	len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			--+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			--,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			--Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			--,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			--)
			--	-3),3)-3))
			--)
			--	-5),3)-3) END
		
			----Select Product
			--From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
			--join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
			--on A.ticketNumber = B.ID
			--where 
			--A.NUM_PRODUCTS is null
			--AND 
			--LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
			----Order by Product
	



		Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		where TicketNumber   in (7198)

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		--Set 
		--Product1 = 'S10 - Property Info'
		--,Product2 = 'S11 - Foreclosure Status'
		--,Product3 = 'S12 - Open Lien Search'
		--,Product4 = 'S13 - Mortgages & Deeds'
		--,Product5 = 'S15 - Sales Listings'
		--,Product6 = 'S17 - Estimate of Market Value'
		--,Product7 = 'S29 - Voluntary Lien'
		--,Product8 = 'S33 - Owner Association'
		--,Product9 = 'S32 - Address Verification'
		--where Ticketnumber = 3304


		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		where Ticketnumber = 3304


	


		--Select CustomerName, Title, Product1, Product2, Product3 From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where BillingDate is null
		--and NUM_PRODUCTS > 1
		--Order by CustomerName


		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where TicketNumber = '8551'

	

		Update A
		Set 
		[CMASProductName] = [PRODUCT1]
		,[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		--where CMAS_PRODUCT_SHAREPOINT  like '%S50%'
		--WHERE A.TicketNumber   in (1096)
		where 
		[CMASProductName] is null
		--and	 A.TicketNumber   in (8551)

			--Select * FRom [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] 
			--where TicketNumber   in (7741)


		

		--Update A
		--Set 
		--[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		----where CMAS_PRODUCT_SHAREPOINT  like '%S50%'
		--WHERE A.TicketNumber   in (1096)
		
		
		

		----------------------TWO products on one ticket - ADD NEW RECORD-------------
		Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT2,3)
	  ,PRODUCT2
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT2 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  FROm [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 2
	  ISNULL(PRODUCT2,'') NOT LIKE ''
	  and Status = '15-Closed'
	  and CustomerName not like '1Tract '
	  AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT2 not like 'Counts'
	   AND PRODUCT2 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
	  --and CMAS_PRODUCT_SHAREPOINT like '%S50%'
	  --and TicketNumber  in (4950)
	  And BillingDate is null
	  
	  


	  Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'
	    Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
	  where ticketnumber = '3712'
	  Order by BillingDate Desc

	

	  --------------------------------3 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT3,3)
	  ,PRODUCT3
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT3 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 3
	  ISNULL(PRODUCT3,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT3 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT3 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
		  --And BillingDate is null


	  --------------------------------4 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT4,3)
	  ,PRODUCT4
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT4 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 4
	  ISNULL(PRODUCT4,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT4 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT4 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'


	--------------------------------5 products on one ticket - ADD NEW RECORD----------------------------------
	  Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT5,3)
	  ,PRODUCT5
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT4 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  --,PRODUCT1,PRODUCT2,PRODUCT3,PRODUCT4,PRODUCT5
	    FROm [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where 
	  --[NUM_PRODUCTS] = 5
	  ISNULL(PRODUCT5,'') NOT LIKE ''
	   and Status = '15-Closed'
	   and CustomerName not like '1Tract '
	     AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT5 not like 'Counts'
	   --and TicketNumber in ('3712')
	   AND PRODUCT5 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
	    
	    

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'



		--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		--where CustomerName like '%texas%'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'DMP Parcel Boundaries'
		--where Id = 117480

		--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where CustomerName like '%texas%'

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		where CMASProductCode is null

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		Order by CMASProductName

		

		--Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct](CMASProductCode, CMASProductName,OracleProductCode, OracleProductName)
		--Values('DMP Parcel Boundaries','DMP Parcel Boundaries','18712','Bulk - Points & Polygons')

		
		
		Update A
		Set 
		[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where ([CMASProductName] like 'S50%' or PRODUCT1 like 'S50%')
		and [TotalBillableUnits] is null
			--AND TicketNumber  in (7741)
		

	

	  -- Update CMASProductCode with from CMASProductName
		UPDATE AB
		SET AB.CMASProductCode = case when LEFT([CMASProductName],6) like 'S__ - ' and [CMASProductName] not like '%Bulk%'	then substring([CMASProductName],1,3)
		when [CMASProductName] like 'Home Junction Parcel Bounda%' then 'HJ Parcel Boundaries'
		else [CMASProductName] end
		--Select [CMASProductName],CMASProductCode
		--,case when LEFT([CMASProductName],6) like 'S__ - ' and [CMASProductName] not like '%Bulk%'	then substring([CMASProductName],1,3)
		--else [CMASProductName] end
		--Select * 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE 
		(AB.CMASProductCode IS NULL or AB.CMASProductCode = '')
		 and Status = '15-Closed'
		  --and    AB.TicketNumber  in (5092,4457)
		AND AB.BillingDate is null


		UPDATE AB
		SET AB.CMASProductCode = [CMASProductName] 
		--Select AB.CMASProductCode ,[CMASProductName], len([CMASProductName])
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE CMASProductCode like 'Bul' 
		and CMASProductCode  <> [CMASProductName]
		 and Status = '15-Closed'
		 AND AB.BillingDate is null

	
		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		where CMASProductCode is null
		--or CMASProductCode like 'S10'
		

		

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] 
		--Set CMASProductCode = 'S10'
		--,CMASProductName = 'S10 - Property Info'
		--where ticketnumber = '6304'
		--and CMASProductCode is null

		
		


		 --Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		 --where customername like 'Baupost%'

		 Select * FRom [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		 where CMASProductName like '%bound%'

		 
		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber = '3712'

	   
		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where ticketnumber in ('4388','4393')


	 -- 	UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--SET CMASProductCode = 'S17'
		--,CMASProductName = 'S17 - Estimate of Market Value'
		----Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where ID = 278648
		


		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET CMASProductCode = CMASProductName
		--Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CMASProductCode like 'Bul%'
		and CMASProductCode <> CMASProductName
		AND BillingDate is null
		
		
	-- Update the automated billing table with the Oracle product code and name based on the lookup table.
		UPDATE AB
		SET AB.OracleProductCode = AP.OracleProductCode,
		AB.OracleProductName = AP.OracleProductName
		 --SELECT AB.OracleProductCode,AP.OracleProductCode
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		ON AB.CMASProductCode = AP.CMASProductCode
		where AB.Status = '15-Closed'
		--and AB.TicketNumber in (5092,4457)
		AND AB.BillingDate is null


		--SELECT AB.TicketNumber,AB.CMASProductCode,AB.OracleProductCode--,AP.OracleProductCode
		--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		----JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		----ON AB.CMASProductCode = AP.CMASProductCode
		--where AB.Status = '15-Closed'
		--and AB.TicketNumber  in (6088,6110,6136,6175,6178)
		--AND AB.BillingDate is null



	------------------Check for NULL CMAS/Oracle Codes---------------
	
		Select TicketNumber,CustomerName,CreateDate,CMASProductCode, CMASProductName, OracleProductCode, BillingDate, Status, BillingOption
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where OracleProductName is null and Status = '15-Closed'
		Order by TicketNumber

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		where CMASProductName like '%assign%'
		Order by CMASProductCode

		
		
		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Assessor'
		,CMASProductname = 'Bulk - Assessor'
		where ticketnumber in( '2622','6583','6571','6649','6701','6779','6790','6862','7075','7037','7283','7312','8099','8230')
		and (CMASProductCode like 'Bulk - Assess'
		or CMASProductCode in ('Bul','Bulk - Assessor Open Li','Bulk - Assessor Open Lien'))

			
		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Assign & Rel'
		,CMASProductname = 'Bulk - Assign & Rel'
		where ticketnumber in( '8500')
		and (CMASProductCode like 'Bulk - Assign & Relea')


		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'TaxSource'
		,CMASProductname = 'TaxSource'
		,OracleProductName = 'TaxSource'
		,OracleProductCode = '18950'
		where ticketnumber in ( '7352','5795')

		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'S50'
		,CMASProductname = 'Doc Images'
		,OracleProductName = 'Doc Images'
		,OracleProductCode = '16620'
		where ticketnumber in ( '8261')

		
		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - AVM Direct'
		,CMASProductname = 'Bulk - AVM Direct'
		,OracleProductName = 'Bulk - AVM Direct'
		,OracleProductCode = '18735'
		where ticketnumber in ( '8272')



		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Market Share'
		--,CMASProductname = 'Bulk - Market Share'
		--where ticketnumber in ( '7941','7977','7991')
		--and CMASPRODUCTCODE like 'Bulk - Market Share w/NMLS'
		
		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Involuntary Lien'
		,CMASProductname = 'Bulk - Involuntary Lien'
		where ticketnumber in ( '8046','8054','8261')
		and CMASPRODUCTCODE in ( 'Bulk - Involuntary Liens','Bul')

		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Commercial Tenant File'
		,CMASProductname = 'Bulk - Commercial Tenant File'
		where ticketnumber in ( '7878')
		and CMASPRODUCTCODE like 'Bulk - Commercial Tenant File'

			
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'S17'
		--,CMASProductname = 'Estimate of Market Value'
		--where ticketnumber in ( '7388')
		--and CMASPRODUCTCODE like 'S18'


		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Address Master'
		,CMASProductname = 'Bulk - Address Master'
		where ticketnumber in ( '7356','7965','8085')
		and CMASPRODUCTCODE like 'Bulk - Address Mast'

		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Assessor'
		,CMASProductname = 'Bulk - Assessor'
		where ticketnumber in ( '7356','7993')
		and CMASPRODUCTCODE in ( 'Bul','Bulk - Assess')
		--and ID = 294021
		
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Parcel Boundaries'
		--,CMASProductname = 'Bulk - Parcel Boundaries'
		--where ticketnumber in ( '7356')
		--and CMASPRODUCTCODE like 'Bul'
		--and ID = 294023
		

		Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		Set 
		CMASProductCode = 'Bulk - Other'
		,CMASProductname = 'Bulk - Other'
		where ticketnumber in ( '8020','8084')
		and CMASPRODUCTCODE in ( 'Bulk - Building Footpri','Bulk - Address & Geocoordina')
		

		
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Parcel Boundaries'
		--,CMASProductname = 'Bulk - Parcel Boundaries'
		--where ticketnumber = '6521'

	

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Listing'
		--,CMASProductname = 'Bulk - Listing'
		--where ticketnumber in('6649','6701','6790','6862')
		--and CMASProductCode like 'Bul'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'NMLS'
		--,CMASProductname = 'NMLS'
		--where ticketnumber in('6649')
		--and CMASProductCode like 'NML'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'S20'
		--,CMASProductname = 'Custom Solution'
		--where ticketnumber = '6094'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Involuntary Lien'
		--,CMASProductname = 'Bulk - Involuntary Lien'
		--where ticketnumber in ( '4949','6848')

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'S20'
		--,CMASProductname = 'Custom Solution'
		--where ticketnumber = '6327'

		
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'HJ Parcel Boundary'
		--,CMASProductname = 'HJ Parcel Boundary'
		--where ticketnumber = '6509'

			
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Regrid Parcel Boundary'
		--,CMASProductname = 'Regrid Parcel Boundary'
		--where ticketnumber = '6521'

				
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Assign & Rel'
		--,CMASProductname = 'Bulk - Assign & Rel'
		--where ticketnumber = '6559'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - HOA'
		--,CMASProductname = 'Bulk - HOA'
		--where ticketnumber = '6406'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - AVM Power'
		--,CMASProductname = 'Bulk - AVM Power'
		--where ticketnumber = '6605'
		--and CMASPRODUCTCODE like 'Bulk - AVM Pow'
		

		
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'S17'
		--,CMASProductname = 'S17 - Estimate of Market Value'
		--where ticketnumber = '6842'

		
		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Flipper'
		--,CMASProductname = 'Bulk - Flipper'
		--where ticketnumber = '7326'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--CMASProductCode = 'Bulk - Propensity Scores'
		--,CMASProductname = 'Bulk - Propensity Scores'
		--where ticketnumber = '8079'
		


		
		-- Update the automated billing table with the Oracle product code and name based on the lookup table.
		UPDATE AB
		SET AB.OracleProductCode = AP.OracleProductCode,
		AB.OracleProductName = AP.OracleProductName
		 --SELECT AB.OracleProductCode,AP.OracleProductCode,AB.TicketNumber
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		ON AB.CMASProductCode = AP.CMASProductCode
		where AB.Status = '15-Closed'
		--and AB.TicketNumber in (6737,2622,6779,6790,6842,6848,6862,7037,7075,7283,7326,7312,7352,7356,7374,7388,7820,7941,7965,7993,7977,7991,8020
		--						,8046,8054,8079,8084,8085,8099)
		--AND AB.BillingDate is null
		and AB.OracleProductCode is null
		

	
	
		Select TicketNumber,CustomerName,CreateDate,CMASProductCode, CMASProductName, OracleProductCode, BillingDate, Status, BillingOption
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where OracleProductName is null and Status = '15-Closed'
		Order by TicketNumber



		--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where CustomerName like 'Managed%' and Billingdate is null


		


		--UPDATE AB
		--SET AB.OracleProductCode = '18720',
		--AB.OracleProductName = 'Bulk â€“ Other'
		-- --SELECT *
		--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		--where AB.TicketNumber   in (2784)
		

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		where --CMASProductCode = 'Bulk - Other'  
		CMASProductCode = 'Bulk â€“ Other'
						  --'Bulk - Other'
		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where ticketnumber in (2784)


		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'Bulk - List'
		--where ticketnumber in (1937,1946)
		
		  --and AB.TicketNumber in ('1558','1548','1526','1547','1559')

		  Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		  Order by CMASProductName

		--Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBillingHistory]
		--where CustomerName like 'Managed%'

		--Select *  FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--where CustomerName like 'Managed%'
		  
	
	Select CustomerName, CreateDate, BillingOption ,* From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] A
	Order by  A.CustomerName, A.CreateDate

	--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	--set STATUS = '15-Closed'
	--where ID = 345704
	

	-- Update TotalBillableUnits based on BillingOption
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.automatedbilling
		SET TotalBillableUnits = case
		when substring(BillingOption,1,1) = '1' then TotalRecords
		when substring(BillingOption,1,1) = '2' then TotalMatched
		when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		else 0 end 
		where CMASProductCode != 'S50'
		and Status = '15-Closed'
		  --and TicketNumber in (8520)
		AND BillingDate is null
		--AND BillingDate  >= Getdate()-.05 and TotalBillableUnits = 0

		
		--Select Ticketnumber, CustomerName,TotalBillableUnits,TotalWithEventsFound
		--,case
		--when substring(BillingOption,1,1) = '1' then TotalRecords
		--when substring(BillingOption,1,1) = '2' then TotalMatched
		--when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		--when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		--when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		--when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		--else 0 end 
		--From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.automatedbilling
		--where Ticketnumber = 4024


		-- Update Billing date to getdate()
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE 
		[AccountNumber] IS NOT NULL 
		AND [BillingOption] IS NOT NULL 
		AND [CMASProductCode] IS NOT NULL 
		AND [ContractExecuted] = 'Yes' 
		AND OracleProductCode is not NULL
		AND [BatchType] is not null
		AND STATUS like '15-Closed'
		and BillingDate is null
		  --and TicketNumber in (7741)
		  
		Select  CMASProductName, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		where TicketNumber = '5227'
		or Customername like 'Experian%'
		Order by CreateDate, TotalRecords,A.CMASProductName


		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--set BatchType = 'BATCH'
		--where ID in (345911,345672)

		--update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--set accountnumber = '136384'
		--where TicketNumber = '5227'
		--and accountnumber is null

				
		----------------Per Nicole 20191025 - Push the Fams post Close & FAPC records to Finance even though there is not account number!!!---
		---------------Changed FAMS is no longer billable oer Nicole ----
		Select  CMASProductName, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		where TicketNumber = '1940'
		Order by CreateDate, TotalRecords,A.CMASProductName


		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE TicketNumber = '1940'
		and BillingDate is null


		----FAPC---
		Select  CMASProductName, * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		where TicketNumber = '4029'
		Order by CreateDate, TotalRecords,A.CMASProductName

		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE TicketNumber = '4029'
		and BillingDate is null

		

		----------------------------Start here------------------

		---------------------------------------------------------------------------------
		Select ID,TicketNumber, CustomerName,BillingDate,PROCESSED_YN,[AccountNumber],[BillingOption],[CMASProductCode],[ContractExecuted]
		,OracleProductCode, [BatchType], STATUS, NUM_PRODUCTS, CreateDate,[CMASProductName],*
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] A
		--where Ticketnumber = 5227
		where BillingDate is null and BillingOption not like 'N/A - Non-billable' and isnull(Status,'') not in ( '18-Request Cancelled')
		Order by A.CustomerName,A.TicketNumber


		--Select   ID as Sharepoint_Ticket, Client_X0020_Name as Customer_Name
		--,Title,Request_x0020_Type as PROD_EVAL,CUrrent_x0020_Status as Status,
		--Replace(Product,';#','') as Product, Replace(Assigned_x0020_f,';#',' ') as Assignee,Billing_x0020_Type as Billing_Type
		--, Billing_x0020_Number as CustomerNumber,Author as Author
		--From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SPMatchAndAppend] with(NOLOCK)
		--where ID in (6088,6110,6136,6175,6178)

		  Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		  where CMASProductName like '%cus%'
		  Order by CMASProductName


		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set [CMASProductCode] = 'S20'
		--,[CMASProductName] = 'Custom Solution'
		--,OracleProductCode = '16602'
		--,OracleProductName = 'Custom Solution'
		--where ID = 345704

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set [CMASProductCode] = 'Bulk - Listing'
		--,[CMASProductName] = 'Bulk - Listing'
		--where ID in ( 277200)

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set [CMASProductCode] = 'Bulk - Listing'
		--, [CMASProductName] = 'Bulk - Listing'
		--where ID = 274742

	
	----------------------------------********************----MANUAL FORCE RERUN---**********************************--------------------------------------------------------
	
		Truncate table dbo.TICKET_LIST_TO_FORCE

		Insert into  dbo.TICKET_LIST_TO_FORCE 
		Select * From (
		Select 
		Stuff(
        (
        --Select Distinct ', ' +   B.TicketNumber + ''
		 Select Distinct ', ''' +  convert(varchar(50),B.TicketNumber) + ''''
		--Select Distinct TicketNumber 
		From[AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] B
		where TicketNumber in ('6280')
		 For Xml Path('')
        ), 1, 2, '') As Columns)A

		Select * From dbo.TICKET_LIST_TO_FORCE

		DECLARE @TICKETS varchar(500)
		Set @TICKETS = (Select * From dbo.TICKET_LIST_TO_FORCE)


		UPDATE AB
		SET 
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		AND  AB.TicketNumber   in ('6280')

		
		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where convert(varchar(50),TicketNumber)   in ('6280')

		UPDATE AB
		SET 
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL 
		AND  AB.TicketNumber   in ('6280')
		

	-------Update CreateDate where null
		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null
		AND  AB.TicketNumber   in ('6280')

		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		--Select * 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null
		AND  AB.TicketNumber   in ('6280')
	
	
	
	
		------Revised above 20221004 as sharepoint appears to no longer be using ;# - just using commas....
		Update A
		Set 
		A.NUM_PRODUCTS = (Select case when product not like ';#%' and product not like '%,%'  then 1  else ((len(product) - Len(Replace(Product,';#','')))/2)-1 end ) 
	
		,A.PRODUCT1 = case when product not like ';#%' and product not like '%,%'  then left(Product,3) else left((Replace(Product,';#','')),charindex(';#',Product,3)-3)  end
		,A.PRODUCT2 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 2 then '' else 
			left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3) END
		,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,';#','')))/2)-1 < 3 then '' else 
			left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3) END

		,A.PRODUCT4 =  case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 4 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3)  END

		,A.PRODUCT5 = case when (((len(product) - Len(Replace(Product,';#','')))/2)-1) < 5 then '' else 
			left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),';#','')),charindex(';#',Right(Product,len(product)-(
				len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3))
			+ len(left((Replace(Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),';#',''))
			,charindex(';#',Right(Product,len(product)-(len(left((Replace(Product,';#','')),charindex(';#',Product,3))) + 
			Len(left((Replace(Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),';#',''))
			,charindex(';#',Right(Product,len(Product)-len(left(Product,charindex(';#',Product,3)-1))),3)-3)))-1),3)-3))
			)
				-3),3)-3))
			)
				-5),3)-3) END
	
		
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		AND  product  like ';#%'
		AND
		A.TicketNumber    in ('6280')




		
		------Revised above 20221004 as sharepoint appears to no longer be using ;# - just using commas....
		Update A
		Set 
		A.NUM_PRODUCTS = (Select ((len(product) - Len(Replace(Product,',','')))+1) ) 
	
		,A.PRODUCT1 =  left((Replace(Product,',','')),charindex(',',Product,3)-3)  
		,A.PRODUCT2 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 2 then '' else 
			left(right(Product,len(product)-charindex(',',Product)),3) END
		,A.PRODUCT3 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 3 then '' else 
			left(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))),3) END

		,A.PRODUCT4 =  case when ((len(product) - Len(Replace(Product,',','')))+1) < 4 then '' else 
			left(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))),3) END

		,A.PRODUCT5 = case when ((len(product) - Len(Replace(Product,',','')))+1) < 5 then '' else 
			left(right(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))))
		,len(right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))))
		-charindex(',',right(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product))))
		,len(right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))
		-charindex(',',right(right(Product,len(product)-charindex(',',Product)),len(right(Product,len(product)
		-charindex(',',Product)))-charindex(',',right(Product,len(product)-charindex(',',Product)))))))),3) END
	
		
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		A.NUM_PRODUCTS is null
		AND 
		LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 5
		AND  product  not like ';#%' and Product like '%,%'
		AND
		A.TicketNumber   in ('6280')


		----------------------TEST PRODUCT NUM!!!!!-----------------

		Select ticketnumber, CustomerName, BillingOption--, CMAS_PRODUCT_SHAREPOINT
		,Product
		,Num_Products
		,PRODUCT1	,PRODUCT2	,PRODUCT3, PRODUCT4, PRODUCT5
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(Product like '%,%'
		or ticketnumber = '6280')
		and (Num_Products <> ((len(product) - Len(Replace(Product,',','')))+1)
		OR Num_Products is null)
		--and Product like '%,%'
		Order by Num_Products


		--UPdate [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set 
		--Num_Products = 1
		--,PRODUCT1 = 'Bul'
		--where ticketnumber = '6280'

		
		Select ticketnumber, CustomerName, BillingOption--, CMAS_PRODUCT_SHAREPOINT
		,Product
		,Num_Products
		,((len(product) - Len(Replace(Product,'#','')))-1)
		,PRODUCT1	,PRODUCT2	,PRODUCT3, PRODUCT4, PRODUCT5
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where 
		(Product like '%#%')
		and (Num_Products <> ((len(product) - Len(Replace(Product,'#','')))-1)
		OR Num_Products is null)
		Order by Num_Products

	





		Update A
		Set 
		[CMASProductName] = [PRODUCT1]
		,[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where 
		[CMASProductName] is null
		AND  A.TicketNumber   in ('6280')

			
		
		
		Update A
		Set 
		[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where ([CMASProductName] like 'S50%' or PRODUCT1 like 'S50%')
		and [TotalBillableUnits] is null
		AND  A.TicketNumber   in ('6280')
		

	

	  -- Update CMASProductCode with from CMASProductName
		UPDATE AB
		SET AB.CMASProductCode = case when LEFT([CMASProductName],6) like 'S__ - ' and [CMASProductName] not like '%Bulk%'	then substring([CMASProductName],1,3)
		else [CMASProductName] end
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE 
		(AB.CMASProductCode IS NULL or AB.CMASProductCode = '')
		 and Status = '15-Closed'
		AND  AB.TicketNumber   in ('6280')
		AND AB.BillingDate is null


		UPDATE AB
		SET AB.CMASProductCode = [CMASProductName] 
		--Select AB.CMASProductCode ,[CMASProductName]
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE CMASProductCode like 'Bul' 
		and CMASProductCode  <> [CMASProductName]
		 and Status = '15-Closed'
		 AND AB.BillingDate is null
		 AND  AB.TicketNumber   in ('6280')


	
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET CMASProductCode = CMASProductName
		--Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		where CMASProductCode like 'Bul%'
		--and CMASProductCode <> CMASProductName
		AND BillingDate is null
		AND  TicketNumber   in ('6280')


		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--set
		--CMASProductCode = 'Bulk - List'
		--where TicketNumber   in ('6280')
		
		
	-- Update the automated billing table with the Oracle product code and name based on the lookup table.
		UPDATE AB
		SET AB.OracleProductCode = AP.OracleProductCode,
		AB.OracleProductName = AP.OracleProductName
		 --SELECT AB.OracleProductCode,AP.OracleProductCode
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		ON AB.CMASProductCode = AP.CMASProductCode
		where AB.Status = '15-Closed'
		AND  AB.TicketNumber   in ('6280')
		AND AB.BillingDate is null


	

	-- Update TotalBillableUnits based on BillingOption
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.automatedbilling
		SET TotalBillableUnits = case
		when substring(BillingOption,1,1) = '1' then TotalRecords
		when substring(BillingOption,1,1) = '2' then TotalMatched
		when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		else 0 end 
		where CMASProductCode != 'S50'
		and Status = '15-Closed'
		AND  TicketNumber  in (8477,8440)
		AND BillingDate is null
		

	


		-- Update Billing date to getdate()
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE 
		[AccountNumber] IS NOT NULL 
		AND [BillingOption] IS NOT NULL 
		AND [CMASProductCode] IS NOT NULL 
		AND [ContractExecuted] = 'Yes' 
		AND OracleProductCode is not NULL
		AND [BatchType] is not null
		AND STATUS like '15-Closed'
		and BillingDate is null
		AND  TicketNumber  in ('6280')
		  







	--------------------******************************************STOP HERE *****************************************************----------------------------------------------
	

		Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct]
		Order by CMASProductName
		--Bulk - Involuntary Liens
		
		--Select *  From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] where CustomerName like 'ReportAll%'
		--and BillingDate is null
		--Order by CreateDate

		--Select *  From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] where Ticketnumber = '6280'
		--and BillingDate is null
		--Order by CreateDate


		--UPdate [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		--Set CMASProductCode = 'S20'
		--where TicketNumber = '1234'
		--and CMASProductCode = 'Cou'
		

		------Email any bad records------
		
		--DECLARE @xml NVARCHAR(MAX)
		--DECLARE @body NVARCHAR(MAX)
		--DECLARE @Subject NVARCHAR(MAX)
		--DECLARE @DATE varchar(10)

		--Set @Date = convert(varchar(10),Getdate(),112)
		--Set @Subject = 'ADS AutoBilling - POTENTIAL BAD RECORDS_' + @Date

		--SET @xml = 
		--CAST(( SELECT 
		--CUSTOMERNAME as 'td',''
		--,TicketNumber as 'td',''
		--,Processed_YN as 'td',''
		--,TotalWithEventsFound as 'td',''
		--,BillingOption as 'td',''
		--,Status as 'td',''
		--,case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end  as 'td','',
		--[CMAS_PRODUCT_SHAREPOINT] as 'td',''
		--,[TotalRecords] as 'td',''
		--, case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end  as 'td','',
		--case when [BatchType] IS NULL then 'empty' else [BatchType] end  as 'td','',
		--case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as 'td','',
		--case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end  as 'td',''
		--,DocImageCounts as 'td'
		--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--WHERE 
		--[CMASProductCode] IS NULL or [CMASProductCode] like ''
		--OR
		--([TotalRecords] < 1 AND [CMASProductCode] NOT LIKE 'S50') 
		--OR
		--[AccountNumber] IS NULL or [AccountNumber] like ''
		--OR
		--[BatchType] IS NULL or [BatchType] like ''
		--OR
		--([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%') 
		--OR
		--([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		--OR
		--[ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null
		--OR TotalBillableUnits = 0 or TotalBillableUnits is null
		--or STatus != '15-Closed'
		--order by CUSTOMERNAME
		--FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


		--SET @body =
		--'<html><body><H3>ADS AutoBilling - POTENTIAL BAD RECORDS_' + @Date + '</H3>
		--<table border = 1> 
		--<tr><th> CUSTOMERNAME  </th> <th> TicketNumber </th> <th> Processed_YN </th> <th> TotalWithEventsFound </th> <th> BillingOption  </th> <th> Status  </th> <th> CMASProductCode   </th> <th> CMAS_PRODUCT_SHAREPOINT 
		--  </th> <th> TotalRecords   </th> <th> AccountNumber   </th> <th> BatchType   </th> <th> ContractExecuted   </th> <th> TotalBillableUnits 
		--    </th> <th> DocImageCounts   </th></tr>'   

		--SET @body = 
		--case when (Select count(*) FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--WHERE 
		--[CMASProductCode] IS NULL or [CMASProductCode] like ''
		--OR
		--([TotalRecords] < 1 AND [CMASProductCode] NOT LIKE 'S50') 
		--OR
		--[AccountNumber] IS NULL or [AccountNumber] like ''
		--OR
		--[BatchType] IS NULL or [BatchType] like ''
		--OR
		--([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%') 
		--OR
		--([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		--OR
		--[ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null
		--OR TotalBillableUnits = 0 or TotalBillableUnits is null
		--or STatus != '15-Closed') = 0 then 'All records OK' 
		-- else
		--@body + @xml +'</table></body></html>' 
		--END

		-------------sp_send_dbmail example-------------
		--EXEC msdb.dbo.sp_send_dbmail
		--@profile_name = 'FAOH-DL-DBS_Fulfillment', -- replace with your SQL Database Mail Profile 
		--@body = @body,
		--@body_format ='HTML',
		--@recipients = 'klowe@firstam.com',
		--@subject = @subject;

	


	--------CHECK FOR GREEN RIVER-------------------------------------------------------------------------

	
	Select CustomerName,TotalMatched, CreateDate, BatchType,BillingDate, BillingOption, Status From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
	where AccountNumber in ('118751')


	

	-- Check field validation. If key fields are NULL or zero send alert email
		SELECT ID,
		CUSTOMERNAME, TicketNumber,Processed_YN,TotalWithEventsFound,TotalMatched,BillingOption,Status,
		case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end as [CMASProductCode],CMASPRODUCTNAME,[ORACLEProductCode],
		[CMAS_PRODUCT_SHAREPOINT],
		[TotalRecords], 
		case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end as [AccountNumber],
		case when [BatchType] IS NULL then 'empty' else [BatchType] end as [BatchType],
		case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as [ContractExecuted],
		case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end as TotalBillableUnits
		,DocImageCounts, CreateDate,BillingDate
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE 
		((([CMASProductCode] IS NULL or [CMASProductCode] like ''
		OR
		[ORACLEProductCode] IS NULL or [ORACLEProductCode] like '') AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([TotalRecords] < 1 AND   [CMASProductCode] NOT LIKE 'S50' AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee' and BillingOption not like '2 - Bill for every record that was matched to a property'))  
		OR
		(([AccountNumber] IS NULL or [AccountNumber] like '' or AccountNumber like 'N/A' or AccountNumber like 'empty') AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([BatchType] IS NULL or [BatchType] like '')
		OR
		([DocImageCounts] > 0 and [CMAS_PRODUCT_SHAREPOINT] not like '%S50%' and 
				(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR
		([DocImageCounts] = 0 and [CMASProductName] like '%S50%') 
		OR
		(([ContractExecuted] != 'Yes' or [ContractExecuted] like '' or [ContractExecuted] is null) AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		OR 
		((TotalBillableUnits = 0 or TotalBillableUnits is null) AND 
			(BillingOption not like 'N/A - Non-billable' and BillingOption not like 'Monthly Fee' and BillingOption not like 'Flat Fee')) 
		or (STatus != '15-Closed')
		)
		AND  STatus != '18-Request Cancelled'
		order by CUSTOMERNAME


		--UPdate [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--set
		--TotalWithEventsFound = TotalRecords
		--where Ticketnumber = '8520'
		

		Select * FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE CUSTOMERNAME like 'NASA FCU'
		order by CreateDate, BatchTYpe


		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--Set TotalWithEventsFound = TotalREcords
		--where ticketnumber in (8477,8440)
		--and DocImageCounts = '27'
		--and ID = 259603
		

		Select * FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE CustomerName like 'Just%'
		or TicketNumber in ( '6064','6064')

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--Set BILLINGDATE = NULL
		--where TicketNumber = '6064'

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--Set DocImageCounts = NULL
		--where ticketnumber = '6065'
		--and DocImageCounts = '4067'
		--and ID = 260125

		Select * FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		where customername like 'Apex%'


		SELECT 
		CUSTOMERNAME, TicketNumber,Processed_YN,TotalWithEventsFound,TotalMatched,BillingOption,Status,
		case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end as [CMASProductCode],CMASPRODUCTNAME,[ORACLEProductCode],
		[CMAS_PRODUCT_SHAREPOINT],
		[TotalRecords], 
		case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end as [AccountNumber],
		case when [BatchType] IS NULL then 'empty' else [BatchType] end as [BatchType],
		case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as [ContractExecuted],
		case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end as TotalBillableUnits
		,DocImageCounts, CreateDate,BillingDate
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE BillingDate is null
		and BillingOption not like 'N/A - Non-billable' 
		and ([CMASProductCode] IS NULL or [AccountNumber] IS NULL or [ContractExecuted] != 'Yes')
		Order by CUSTOMERNAME


		------ALL TO SEND------
		SELECT 
		CUSTOMERNAME, TicketNumber, [WO],TotalWithEventsFound,TotalMatched,BillingOption,Status,
		case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end as [CMASProductCode],CMASPRODUCTNAME,[ORACLEProductCode],
		[CMAS_PRODUCT_SHAREPOINT],
		[TotalRecords], 
		case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end as [AccountNumber],
		case when [BatchType] IS NULL then 'empty' else [BatchType] end as [BatchType],
		case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as [ContractExecuted],
		case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end as TotalBillableUnits
		,DocImageCounts, CreateDate,BillingDate
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE BillingDate is not null
		Order by CUSTOMERNAME


		Select * From  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		where ticketnumber in ( '8238','8435')
		Order by CreateDate

		--Update  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--set
		--Ticketnumber = '8435'
		--,[WO] = '4'
		--where ID in (348609,348723,349802,349929,349963)


	

		---------BILLING DATE IS NULL-----
		SELECT 
		CUSTOMERNAME, TicketNumber,Processed_YN,TotalWithEventsFound,TotalMatched,BillingOption,Status,
		case when [CMASProductCode] IS NULL then 'empty' else [CMASProductCode] end as [CMASProductCode],CMASPRODUCTNAME,[ORACLEProductCode],
		[CMAS_PRODUCT_SHAREPOINT],
		[TotalRecords], 
		case when [AccountNumber] IS NULL then 'empty' else [AccountNumber] end as [AccountNumber],
		case when [BatchType] IS NULL then 'empty' else [BatchType] end as [BatchType],
		case when [ContractExecuted] != 'Yes' then 'not yes' else [ContractExecuted] end as [ContractExecuted],
		case when TotalBillableUnits = 0 or TotalBillableUnits is null then 0 else TotalBillableUnits end as TotalBillableUnits
		,DocImageCounts, CreateDate,BillingDate
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		WHERE BillingDate is null
		Order by CUSTOMERNAME
		

		--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--where TicketNumber = '3844'

		Select ID, BatchType,CustomerName, TicketNUmber,CreateDate, TotalMatched,TotalREcords, TotalWithEventsFound, BillingDate, CMASProductCode , DocimageCounts
		,TotalBillableUnits
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		where CustomerName like 'Experian%'
		Order by CreateDate


		Select ID, BatchType,CustomerName, TicketNUmber,CreateDate, TotalMatched,TotalREcords, TotalWithEventsFound, BillingDate, CMASProductCode , DocimageCounts
		,TotalBillableUnits
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		where ticketnumber in (4457,5092) 
		--AND CMASProductCode like 'S50'
		Order by CreateDate

		
		
		--Delete from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--where ID in (202148,202355,202364,202376,202377,202371,202365,202356,202350,202361,202367,202373,202139,202374,202368,202362,202354,202369,202375,202141)

		--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		--Set TotalwithEventsFound = TotalRecords
		--where ticketnumber in (4024)


	--Delete from  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
	--where ID in (70607,70608)

----Update BillingDate for non-billable tickets

Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
SET BillingDate = Getdate() 
WHERE (BillingDate IS NULL and [BillingOption] like 'N/A - Non-billable'
and Status like '15-Closed')
OR
(BillingDate IS NULL and CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization'
and AccountNumber = '118108')
OR
([BillingOption] like  'Monthly Fee' and BillingDate is null
and Status like '15-Closed')
OR
([BillingOption] like  'Flat Fee' and BillingDate is null
and Status like '15-Closed' and AccountNumber is not null)




--Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
--Set PROCESSED_YN = 'Y'
--where Ticketnumber = '1838'

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
where customername like 'Towerpoint%'
Order by CreateDate desc

Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
where customername like 'Towerpoint%'
Order by CreateDate desc





--------------------Archive Billed records-----------------------
INSERT INTO [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] (
       [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,[ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO)
SELECT [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,GETDATE() -- [ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO
 FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
WHERE 
(BillingDate IS NOT NULL and PROCESSED_YN = 'Y')
 or ([BillingOption] like 'N/A - Non-billable' and BillingDate IS NOT NULL)
-- and Createdate < Getdate() - 30 )
-- OR (CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
-- and BillingDate IS NOT NULL)
-- --OR ID in (2452,2718,2733,2610,2881)
 --CustomerName like 'States Title' and BillingDate IS NOT NULL


  Select CustomerName, CMASProductCOde,ID, * from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
  where TicketNUmber = '2994'
Order by A.CMASProductCOde

 Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 where [AccountNumber] = '130372'


 --Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 --where BillingDate = '2019-03-25 08:33:08.157'
 --and BillingOption not in ('Monthly Fee','N/A - Non-billable')



 -----------------------REMOVE WELLS FARGO-------------
 --Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
 --where 
 --CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
 --and BillingDate IS NOT NULL


 --Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
 --where 
 --Title like 'WF Monthly Lien Monitoring - Old & New (soft close) ' and AccountNumber = '118108'
 --and BillingDate IS NOT NULL
 --Order by CreateDate desc


--Select * from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] as A join 
--[AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
--A.TicketNumber = B.TicketNumber and A.CMASProductCode = B.CMASProductCode
--and A.BillingDate = B.BillingDate
--where 
----A.CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and 
--A.AccountNumber = '118108'
--and A.BillingDate IS NOT NULL

--Select * 
-- --Delete 
-- from [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
-- where 
-- CMAS_PRODUCT_SHAREPOINT = 'Lien MonitoringAdd Customization' and AccountNumber = '118108'
-- and BillingDate IS NOT NULL
 


 ------------------------------------------------------------------------------------------
 --Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory]
 --where TicketNumber = '812'



--		Select *, 
--((len(product) - Len(Replace(Product,';#','')))/2)-1 as NUM_PRODUCTS,
--left((Replace(Product,';#','')),charindex(';#',Product,3)-3) as Product1,

--case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then '' else 
--Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END as Product2,

--case when (Case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then 0 else 
--charindex(';#',Product,(charindex(';#',Product,charindex(';#',Product,3)+3))+3) END) = 0 then '' else 
--Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END as Product3

--From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
--join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
--on A.ticketNumber = B.ID
--where A.BillingDate is null
--order by Client_X0020_Name, A.TicketNumber



--Select A.AccountNumber,A.ID,A.TicketNumber,A.CustomerName, A.CreateDate,A.BatchType,B.Title,A.CMASProductCOde,CUrrent_x0020_Status as Status, A.TotalRecords,A.TotalBillableUnits, A.BillingOption 
--,A.[CMASProductName]
--,Replace(Product,';#','') as Product
--,A.OracleProductCode, A.ContractExecuted
--,A.DocImageCounts
--,Billing_x0020_Type as Billing_Type
--,Billing_x0020_Number as CustomerNumber
--,A.BillingDate
--,A.NUM_PRODUCTS
--,A.Product1
--,A.Product2
--,A.Product3
--,B.SOW
--,B.WO
--,A.BillingDate
--From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]  as A with(NOLOCK)
--join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
--on A.ticketNumber = B.ID
--where A.BillingOption not like 'N/A - Non-billable'
----and CUrrent_x0020_Status like '15-Closed'
--order by A.AccountNumber, B.Title,A.CMASProductCOde


--Select TicketNumber,CmasProductCode,* From  [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] A
--where CustomerName like 'Gateway%'
--Order by A.TicketNumber



END








