SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- Update Lic from DTDB Assr
-- =============================================
CREATE PROCEDURE [dbo].[x900_UpdateLicFromDTDBAssr] @FipsCode varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

		

			UPDATE b
			SET [AssdLandValue] = [ASSD_LAND_VALUE]
			,[AssdImprovementValue] = [ASSD_IMPROVEMENT_VALUE]
			,[AssdTotalValue] = [ASSD_TOTAL_VALUE]
			,[AssdYear] = [ASSESSED_YEAR]
			,[MarketValueLand] = [MKT_LAND_VALUE]
			,[MarketValueImprovement] = [MKT_IMPROVEMENT_VALUE]
			,[MarketTotalValue] = [MKT_TOTAL_VALUE]
			,[MarketValueYear] = NULL
			,[ApprLandValue] = [APPR_LAND_VALUE]
			,[ApprImprovementValue] = [APPR_IMPROVEMENT_VALUE]
			,[ApprTotalValue] = [APPR_TOTAL_VALUE]
			,[ApprYear] =  NULL
			,[TaxValueLand] = [TAXABLE_LAND_VALUE]
			,[TaxValueImprovement] = [TAXABLE_IMPROVEMENT_VALUE]
			,[TaxTotalValue] = [TAXABLE_TOTAL_VALUE]
			,[TaxableYear] =  NULL
			,FATimestamp = '2021-10-02'
			,FAUserID = '20211002 Dragon Value Update'
			From DragonAssr.dbo.Dragon_FLANK a JOIN Data.dbo.Property b with(NOLOCK)
			on a.REF_ID = b.DTDB_Ref_ID
			Where a.fips = @FipsCode 
			and b.FIPS = @FipsCode
			and ASSESSED_YEAR > AssdYear
			--and a.TAX_AMOUNT is not null


			UPDATE b
			SET b.TaxAmount = Tax_Amount*100
			,b.TaxYear = Tax_Year
			,b.FATimestamp = GetDate()
			,b.FAUserID = '20191106 VAT'
			From DragonAssr.dbo.Dragon_Flank a JOIN Data.dbo.Property b 
			on a.fips = b.fips and a.PropertyID = b.PropertyID
			Where a.fips = @FipsCode 
			and b.FIPS = @FipsCode
			and TAX_YEAR > TaxYear
			and a.TAX_AMOUNT is not null


END

