SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create procedure [dbo].[RemoveLeadingZerosFromUnit--] (@fips int)
as
update dbo.CL_Address_Base
set STD_Unit = SUBSTRING(STD_Unit, PATINDEX('%[^0]%', STD_Unit+'.'), LEN(STD_Unit))
where Fips = @fips 
and LEN(STD_Unit) > 0 
and LEFT(ltrim(STD_Unit),1) = '0'


