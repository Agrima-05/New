SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Instructions in case you see the DBS Flag
--  Set to 'Y' but its not running
--  OR if Sunil says the process failed
-- =============================================
CREATE PROCEDURE [dbo].[a_INSTRUCTIONS]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

---- So in case of a runaway bus…LOL

---- If the DBS running Flag is still set to ‘Y’ and you don’t see the process running….

---- Run this to see if the Load finished and if the process even kicked off:

----  SELECT * FROM [Dbs_Tax_Lic].[dbo].[sp_Tracking]

---- If you see where all the dates are from yesterday that means the load to the data completed but but for some reason didn’t update the flag to you can update the flag and you can run the jobs.  
----- If all dates are from previous date, their data load never finished so reach out to Sunil.  
------ Lastly if you see that some have day before and some have yesterday then the error happened in below stored Procedure so I just go into it, find the section that it errored on and run from there on.

---- [dbo].[usp_Post_Update_PropIDRefID]

---- If they reach out and say their process failed will you please find the issue and manually run it….
---- Again check the above, if the dates are all good and the flag was set to ‘N’ then you need to just run this stored procedure to load to the property table.  [dbo].[Roll_DBS_Tax_To_Property_PickUP]

---- Then let Sunil know its complete.

Select top 1 * from dbo.Licensing_Deliverable


END

