SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.InsertOrUpdateStateItemLarge(
	@SessionId nvarchar(88) NOT NULL,
	@NewItem bit NOT NULL,
	@LockCookie int NOT NULL,
	@Timeout int NOT NULL,
	@ItemSize bigint NOT NULL,
	@Items dbo.SessionItemsTable READONLY
) WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()
	DECLARE @Expires AS datetime2 NOT NULL = DATEADD(minute, @Timeout, @Now)
			
	IF @NewItem = 1
	BEGIN
		INSERT dbo.Sessions
			(SessionId,
			Created,
			Expires,
			Initialized,
			Locked, 
			LockDate,
			LockCookie,
			Timeout,
			ItemSize,
			Item)
		VALUES 
			(@SessionId,
			@Now,
			@Expires,
			1, -- Initialized
			0, -- Locked
			@Now, -- LockDate
			@LockCookie,
			@Timeout,
			@ItemSize,
			NULL)

		INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
		SELECT @SessionId, SessionItemId, Item
		FROM @Items
	END
	ELSE
	BEGIN
		DECLARE @OldItemSize bigint = 0

		UPDATE dbo.Sessions
		SET
			@OldItemSize = ItemSize,
			Expires = @Expires,
			Locked = 0,
			Timeout = @Timeout,
			ItemSize = @ItemSize,
			Item = NULL
		WHERE SessionId = @SessionId AND LockCookie = @LockCookie

		IF @@ROWCOUNT = 0 RETURN;

		IF (@OldItemSize > 7000)
		BEGIN
			DELETE dbo.SessionItems WHERE SessionId = @SessionId
		END

		INSERT dbo.SessionItems(SessionId, SessionItemId, Item)
		SELECT @SessionId, SessionItemId, Item
		FROM @Items
	END
END

