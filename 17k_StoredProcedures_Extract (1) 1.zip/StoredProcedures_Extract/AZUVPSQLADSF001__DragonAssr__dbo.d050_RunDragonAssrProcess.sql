SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Run Dragon Assessor Proc
-- =============================================
CREATE PROCEDURE [dbo].[d050_RunDragonAssrProcess] @FipsCode varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

		DECLARE @New varchar(25) 
		SET @New = 'PropertyWork_' + @FipsCode

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd100 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d100_AppendDragonAssrToPropertyWORK] @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'd100 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd200 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d200_PullForwardData] @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'd200 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd300 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d300_NameParsing]

		INSERT INTO DragonProcessingTracker
		Select 'd300 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd400 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d400_last_and_prior_sale_rollup] @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'd400 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd500 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d500_Ownership_Update] @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'd500 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd530 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d530_Update_Foreign_Addr_Flag]

		INSERT INTO DragonProcessingTracker
		Select 'd530 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd540 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d540_RunASP]

		INSERT INTO DragonProcessingTracker
		Select 'd540 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd545 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d545_RunASP]

		INSERT INTO DragonProcessingTracker
		Select 'd545 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @FipsCode varchar(5) = '06037'
		INSERT INTO DragonProcessingTracker
		Select 'd550 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d550_VacancyBankOwned]

		INSERT INTO DragonProcessingTracker
		Select 'd550 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		INSERT INTO DragonProcessingTracker
		Select 'd600 Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		EXEC [Data].[dbo].[zAdmin_OpenLien_Dragon_NoNameCheck_CountySpecific] @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'd600 Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--DECLARE @Fipscode varchar(5) = '53073'
		--DECLARE @New varchar(25) 
		--SET @New = 'PropertyWork_' + @FipsCode

		INSERT INTO DragonProcessingTracker
		Select 'Rename Start ' + @FipsCode,GETDATE() as ProcessingStartTime 

		update DragonAssr.dbo.PropertyWork
		SET OwnerStd1LastName = NULL 
		where OwnerStd1LastName = OwnerStd1CorpName

		update DragonAssr.dbo.PropertyWork
		SET OwnerStd2LastName = NULL 
		where OwnerStd2LastName = OwnerStd2CorpName

		UPDATE DragonAssr.dbo.PropertyWork
		SET [FIPS] = Ltrim(Rtrim([FIPS]))
      ,[PropertyID] = Ltrim(Rtrim([PropertyID]))
      ,[FormattedAPN] = Ltrim(Rtrim([FormattedAPN]))
      ,[APNSeqNbr] = Ltrim(Rtrim([APNSeqNbr]))
      ,[UnformattedAPN] = Ltrim(Rtrim([UnformattedAPN]))
      ,[OldAPN] = Ltrim(Rtrim([OldAPN]))
      ,[OLDAPNSeqNbr] = Ltrim(Rtrim([OLDAPNSeqNbr]))
      ,[TaxAccountNumber] = Ltrim(Rtrim([TaxAccountNumber]))
      ,[RecordType] = Ltrim(Rtrim([RecordType]))
      ,[VendorPID] = Ltrim(Rtrim([VendorPID]))
      ,[SitusStdFullStreetAddress] = Ltrim(Rtrim([SitusStdFullStreetAddress]))
      ,[SitusStdHouseNbr] = Ltrim(Rtrim([SitusStdHouseNbr]))
      ,[SitusStdHouseNbr2] = Ltrim(Rtrim([SitusStdHouseNbr2]))
      ,[SitusStdHouseNbrSuffix] = Ltrim(Rtrim([SitusStdHouseNbrSuffix]))
      ,[SitusStdDirectionLeft] = Ltrim(Rtrim([SitusStdDirectionLeft]))
      ,[SitusStdStreet] = Ltrim(Rtrim([SitusStdStreet]))
      ,[SitusStdMode] = Ltrim(Rtrim([SitusStdMode]))
      ,[SitusStdDirectionRight] = Ltrim(Rtrim([SitusStdDirectionRight]))
      ,[SitusStdUnitNbr] = Ltrim(Rtrim([SitusStdUnitNbr]))
      ,[SitusStdCity] = Ltrim(Rtrim([SitusStdCity]))
      ,[SitusStdState] = Ltrim(Rtrim([SitusStdState]))
      ,[SitusStdZIP5] = Ltrim(Rtrim([SitusStdZIP5]))
      ,[SitusStdZIP4] = Ltrim(Rtrim([SitusStdZIP4]))
      ,[SitusStdCarrierCode] = Ltrim(Rtrim([SitusStdCarrierCode]))
      ,[SitusCensusTract] = Ltrim(Rtrim([SitusCensusTract]))
      ,[SitusCensusTractBlock] = Ltrim(Rtrim([SitusCensusTractBlock]))
      ,[SitusStdUnitType] = Ltrim(Rtrim([SitusStdUnitType]))
      ,[SitusStdMatchCode] = Ltrim(Rtrim([SitusStdMatchCode]))
      ,[LotSizeSqFt] = Ltrim(Rtrim([LotSizeSqFt]))
      ,[LotSizeAcres] = Ltrim(Rtrim([LotSizeAcres]))
      ,[LotSizeFrontageFeet] = Ltrim(Rtrim([LotSizeFrontageFeet]))
      ,[LotSizeDepthFeet] = Ltrim(Rtrim([LotSizeDepthFeet]))
      ,[LotIrregularInd] = Ltrim(Rtrim([LotIrregularInd]))
      ,[LotUsableSize] = Ltrim(Rtrim([LotUsableSize]))
      ,[PropertyClassID] = Ltrim(Rtrim([PropertyClassID]))
      ,[StdLandUseCode] = Ltrim(Rtrim([StdLandUseCode]))
      ,[StateLandUseCode] = Ltrim(Rtrim([StateLandUseCode]))
      ,[CountyLandUseCode] = Ltrim(Rtrim([CountyLandUseCode]))
      ,[CountyLandUseDescription] = Ltrim(Rtrim([CountyLandUseDescription]))
      ,[TimeshareCode] = Ltrim(Rtrim([TimeshareCode]))
      ,[Zoning] = Ltrim(Rtrim([Zoning]))
      ,[SiteInfluenceCode] = Ltrim(Rtrim([SiteInfluenceCode]))
      ,[NeighborhoodCode] = Ltrim(Rtrim([NeighborhoodCode]))
      ,[TopographyCode] = Ltrim(Rtrim([TopographyCode]))
      ,[MobileHomeInd] = Ltrim(Rtrim([MobileHomeInd]))
      ,[LotCode] = Ltrim(Rtrim([LotCode]))
      ,[LotNumber] = Ltrim(Rtrim([LotNumber]))
      ,[LandLot] = Ltrim(Rtrim([LandLot]))
      ,[Block] = Ltrim(Rtrim([Block]))
      ,[Section] = Ltrim(Rtrim([Section]))
      ,[District] = Ltrim(Rtrim([District]))
      ,[LegalUnit] = Ltrim(Rtrim([LegalUnit]))
      ,[Municipality] = Ltrim(Rtrim([Municipality]))
      ,[LegalSection] = Ltrim(Rtrim([LegalSection]))
      ,[LegalTownship] = Ltrim(Rtrim([LegalTownship]))
      ,[LegalRange] = Ltrim(Rtrim([LegalRange]))
      ,[Meridian] = Ltrim(Rtrim([Meridian]))
      ,[LegalQuarter] = Ltrim(Rtrim([LegalQuarter]))
      ,[LegalQuarterQuarter] = Ltrim(Rtrim([LegalQuarterQuarter]))
      ,[LegalDescription] = Ltrim(Rtrim([LegalDescription]))
      ,[AssessorsMapRef1] = Ltrim(Rtrim([AssessorsMapRef1]))
      ,[AssessorsMapRef2] = Ltrim(Rtrim([AssessorsMapRef2]))
      ,[SubdivisionName] = Ltrim(Rtrim([SubdivisionName]))
      ,[SubdivisionPhaseNbr] = Ltrim(Rtrim([SubdivisionPhaseNbr]))
      ,[SubdivisionTractNbr] = Ltrim(Rtrim([SubdivisionTractNbr]))
      ,[SubdivisionPlatBook] = Ltrim(Rtrim([SubdivisionPlatBook]))
      ,[SubdivisionPlatPage] = Ltrim(Rtrim([SubdivisionPlatPage]))
      ,[NewRecordType] = Ltrim(Rtrim([NewRecordType]))
      ,[SwiSCodeNY] = Ltrim(Rtrim([SwiSCodeNY]))
      ,[MailingCareOfName] = Ltrim(Rtrim([MailingCareOfName]))
      ,[MailingStdFullStreetAddress] = Ltrim(Rtrim([MailingStdFullStreetAddress]))
      ,[MailingStdHouseNbr] = Ltrim(Rtrim([MailingStdHouseNbr]))
      ,[MailingStdHouseNbr2] = Ltrim(Rtrim([MailingStdHouseNbr2]))
      ,[MailingStdHouseNbrSuffix] = Ltrim(Rtrim([MailingStdHouseNbrSuffix]))
      ,[MailingStdDirectionLeft] = Ltrim(Rtrim([MailingStdDirectionLeft]))
      ,[MailingStdStreet] = Ltrim(Rtrim([MailingStdStreet]))
      ,[MailingStdMode] = Ltrim(Rtrim([MailingStdMode]))
      ,[MailingStdDirectionRight] = Ltrim(Rtrim([MailingStdDirectionRight]))
      ,[MailingStdUnitNbr] = Ltrim(Rtrim([MailingStdUnitNbr]))
      ,[MailingStdCity] = Ltrim(Rtrim([MailingStdCity]))
      ,[MailingStdState] = Ltrim(Rtrim([MailingStdState]))
      ,[MailingStdZIP5] = Ltrim(Rtrim([MailingStdZIP5]))
      ,[MailingStdZIP4] = Ltrim(Rtrim([MailingStdZIP4]))
      ,[MailingStdCarrierCode] = Ltrim(Rtrim([MailingStdCarrierCode]))
      ,[MailingStdUnitType] = Ltrim(Rtrim([MailingStdUnitType]))
      ,[MailingStdMatchCode] = Ltrim(Rtrim([MailingStdMatchCode]))
      ,[MailingOptOut] = Ltrim(Rtrim([MailingOptOut]))
      ,[MailingOptOutDate] = Ltrim(Rtrim([MailingOptOutDate]))
      ,[OwnerOccupied] = Ltrim(Rtrim([OwnerOccupied]))
      ,[AbsenteeOwner] = Ltrim(Rtrim([AbsenteeOwner]))
      ,[OwnerStdNAME1FULL] = Ltrim(Rtrim([OwnerStdNAME1FULL]))
      ,[OwnerStdNAME2FULL] = Ltrim(Rtrim([OwnerStdNAME2FULL]))
      ,[OwnerStdNAME3FULL] = Ltrim(Rtrim([OwnerStdNAME3FULL]))
      ,[OwnerStdNAME4FULL] = Ltrim(Rtrim([OwnerStdNAME4FULL]))
      ,[OwnerEtALIndicator] = Ltrim(Rtrim([OwnerEtALIndicator]))
      ,[OwnerStd1CorpInd] = Ltrim(Rtrim([OwnerStd1CorpInd]))
      ,[OwnerStd1LastName] = Ltrim(Rtrim([OwnerStd1LastName]))
      ,[OwnerStd1FirstName] = Ltrim(Rtrim([OwnerStd1FirstName]))
      ,[OwnerStd1MiddleName] = Ltrim(Rtrim([OwnerStd1MiddleName]))
      ,[OwnerStd1Suffix] = Ltrim(Rtrim([OwnerStd1Suffix]))
      ,[OwnerStd1CorpName] = Ltrim(Rtrim([OwnerStd1CorpName]))
      ,[OwnerStd1OwnershipRights] = Ltrim(Rtrim([OwnerStd1OwnershipRights]))
      ,[OwnerStd1RelationshipType] = Ltrim(Rtrim([OwnerStd1RelationshipType]))
      ,[Owner1DoNotParse] = Ltrim(Rtrim([Owner1DoNotParse]))
      ,[OwnerStd2CorpInd] = Ltrim(Rtrim([OwnerStd2CorpInd]))
      ,[OwnerStd2LastName] = Ltrim(Rtrim([OwnerStd2LastName]))
      ,[OwnerStd2FirstName] = Ltrim(Rtrim([OwnerStd2FirstName]))
      ,[OwnerStd2MiddleName] = Ltrim(Rtrim([OwnerStd2MiddleName]))
      ,[OwnerStd2Suffix] = Ltrim(Rtrim([OwnerStd2Suffix]))
      ,[OwnerStd2CorpName] = Ltrim(Rtrim([OwnerStd2CorpName]))
      ,[OwnerStd2OwnershipRights] = Ltrim(Rtrim([OwnerStd2OwnershipRights]))
      ,[OwnerStd2RelationshipType] = Ltrim(Rtrim([OwnerStd2RelationshipType]))
      ,[Owner2DoNotParse] = Ltrim(Rtrim([Owner2DoNotParse]))
      ,[OwnerStd3CorpInd] = Ltrim(Rtrim([OwnerStd3CorpInd]))
      ,[OwnerStd3LastName] = Ltrim(Rtrim([OwnerStd3LastName]))
      ,[OwnerStd3FirstName] = Ltrim(Rtrim([OwnerStd3FirstName]))
      ,[OwnerStd3MiddleName] = Ltrim(Rtrim([OwnerStd3MiddleName]))
      ,[OwnerStd3Suffix] = Ltrim(Rtrim([OwnerStd3Suffix]))
      ,[OwnerStd3CorpName] = Ltrim(Rtrim([OwnerStd3CorpName]))
      ,[OwnerStd3OwnershipRights] = Ltrim(Rtrim([OwnerStd3OwnershipRights]))
      ,[OwnerStd3RelationshipType] = Ltrim(Rtrim([OwnerStd3RelationshipType]))
      ,[Owner3DoNotParse] = Ltrim(Rtrim([Owner3DoNotParse]))
      ,[OwnerStd4CorpInd] = Ltrim(Rtrim([OwnerStd4CorpInd]))
      ,[OwnerStd4LastName] = Ltrim(Rtrim([OwnerStd4LastName]))
      ,[OwnerStd4FirstName] = Ltrim(Rtrim([OwnerStd4FirstName]))
      ,[OwnerStd4MiddleName] = Ltrim(Rtrim([OwnerStd4MiddleName]))
      ,[OwnerStd4Suffix] = Ltrim(Rtrim([OwnerStd4Suffix]))
      ,[OwnerStd4CorpName] = Ltrim(Rtrim([OwnerStd4CorpName]))
      ,[OwnerStd4OwnershipRights] = Ltrim(Rtrim([OwnerStd4OwnershipRights]))
      ,[OwnerStd4RelationshipType] = Ltrim(Rtrim([OwnerStd4RelationshipType]))
      ,[Owner4DoNotParse] = Ltrim(Rtrim([Owner4DoNotParse]))
      ,[AssesseeStd1Name] = Ltrim(Rtrim([AssesseeStd1Name]))
      ,[AssesseeStd2Name] = Ltrim(Rtrim([AssesseeStd2Name]))
      ,[AssesseeNameIndicator] = Ltrim(Rtrim([AssesseeNameIndicator]))
      ,[AssesseeNameIndicator2] = Ltrim(Rtrim([AssesseeNameIndicator2]))
      ,[Amenities] = Ltrim(Rtrim([Amenities]))
      ,[DrivewayCode] = Ltrim(Rtrim([DrivewayCode]))
      ,[EasementInd] = Ltrim(Rtrim([EasementInd]))
      ,[QualityCode] = Ltrim(Rtrim([QualityCode]))
      ,[ViewInd] = Ltrim(Rtrim([ViewInd]))
      ,[ViewCode] = Ltrim(Rtrim([ViewCode]))
      ,[ViewQualityCode] = Ltrim(Rtrim([ViewQualityCode]))
      ,[WaterAccessableInd] = Ltrim(Rtrim([WaterAccessableInd]))
      ,[WaterFeatureInd] = Ltrim(Rtrim([WaterFeatureInd]))
      ,[WaterfrontCode] = Ltrim(Rtrim([WaterfrontCode]))
      ,[WaterfrontFeet] = Ltrim(Rtrim([WaterfrontFeet]))
      ,[WaterfrontQualityCode] = Ltrim(Rtrim([WaterfrontQualityCode]))
      ,[BuildingArea] = Ltrim(Rtrim([BuildingArea]))
      ,[BuildingAreaInd] = Ltrim(Rtrim([BuildingAreaInd]))
      ,[TotalRooms] = Ltrim(Rtrim([TotalRooms]))
      ,[Bedrooms] = Ltrim(Rtrim([Bedrooms]))
      ,[BathTotalCalc] = Ltrim(Rtrim([BathTotalCalc]))
      ,[BathFull] = Ltrim(Rtrim([BathFull]))
      ,[BathsParcialNbr] = Ltrim(Rtrim([BathsParcialNbr]))
      ,[BathHalf] = Ltrim(Rtrim([BathHalf]))
      ,[Bath1QTR] = Ltrim(Rtrim([Bath1QTR]))
      ,[Bath3QTR] = Ltrim(Rtrim([Bath3QTR]))
      ,[BathFixturesNbr] = Ltrim(Rtrim([BathFixturesNbr]))
      ,[OtherRooms] = Ltrim(Rtrim([OtherRooms]))
      ,[AirConditioningCode] = Ltrim(Rtrim([AirConditioningCode]))
      ,[AirConditioningTypeCode] = Ltrim(Rtrim([AirConditioningTypeCode]))
      ,[BasementCode] = Ltrim(Rtrim([BasementCode]))
      ,[BasementFinishedCode] = Ltrim(Rtrim([BasementFinishedCode]))
      ,[BuildingClassCode] = Ltrim(Rtrim([BuildingClassCode]))
      ,[BuildingConditionCode] = Ltrim(Rtrim([BuildingConditionCode]))
      ,[BuildingQualityCode] = Ltrim(Rtrim([BuildingQualityCode]))
      ,[ConstructionTypeCode] = Ltrim(Rtrim([ConstructionTypeCode]))
      ,[DeckCode] = Ltrim(Rtrim([DeckCode]))
      ,[ElectricityCode] = Ltrim(Rtrim([ElectricityCode]))
      ,[ExteriorWallsCode] = Ltrim(Rtrim([ExteriorWallsCode]))
      ,[FireplaceCode] = Ltrim(Rtrim([FireplaceCode]))
      ,[FloorCoverCode] = Ltrim(Rtrim([FloorCoverCode]))
      ,[FloorTypeCode] = Ltrim(Rtrim([FloorTypeCode]))
      ,[FoundationInd] = Ltrim(Rtrim([FoundationInd]))
      ,[FrameCode] = Ltrim(Rtrim([FrameCode]))
      ,[Garage] = Ltrim(Rtrim([Garage]))
      ,[GarageParkingNbr] = Ltrim(Rtrim([GarageParkingNbr]))
      ,[HeatCode] = Ltrim(Rtrim([HeatCode]))
      ,[HeatingFuelTypeCode] = Ltrim(Rtrim([HeatingFuelTypeCode]))
      ,[InteriorWallsCode] = Ltrim(Rtrim([InteriorWallsCode]))
      ,[PavingCode] = Ltrim(Rtrim([PavingCode]))
      ,[PatioCode] = Ltrim(Rtrim([PatioCode]))
      ,[PoolCode] = Ltrim(Rtrim([PoolCode]))
      ,[PorchCode] = Ltrim(Rtrim([PorchCode]))
      ,[RoofCoverCode] = Ltrim(Rtrim([RoofCoverCode]))
      ,[RoofTypeCode] = Ltrim(Rtrim([RoofTypeCode]))
      ,[SewerCode] = Ltrim(Rtrim([SewerCode]))
      ,[ShapeCode] = Ltrim(Rtrim([ShapeCode]))
      ,[StoriesCode_OLD] = Ltrim(Rtrim([StoriesCode_OLD]))
      ,[StoriesNbrCode_OLD] = Ltrim(Rtrim([StoriesNbrCode_OLD]))
      ,[StyleCode] = Ltrim(Rtrim([StyleCode]))
      ,[WallExteriorCode] = Ltrim(Rtrim([WallExteriorCode]))
      ,[WallheightCode] = Ltrim(Rtrim([WallheightCode]))
      ,[WaterCode] = Ltrim(Rtrim([WaterCode]))
      ,[YearBuilt] = Ltrim(Rtrim([YearBuilt]))
      ,[EffectiveYearBuilt] = Ltrim(Rtrim([EffectiveYearBuilt]))
      ,[AssdYear] = Ltrim(Rtrim([AssdYear]))
      ,[TaxRateCodeArea] = Ltrim(Rtrim([TaxRateCodeArea]))
      ,[TaxYear] = Ltrim(Rtrim([TaxYear]))
      ,[TaxAmount] = Ltrim(Rtrim([TaxAmount]))
      ,[TaxDeliquentYear1] = Ltrim(Rtrim([TaxDeliquentYear1]))
      ,[TaxDeliquentValue1] = Ltrim(Rtrim([TaxDeliquentValue1]))
      ,[TaxExemptionCode] = Ltrim(Rtrim([TaxExemptionCode]))
      ,[SchoolTaxDistrict1Code] = Ltrim(Rtrim([SchoolTaxDistrict1Code]))
      ,[SchoolTaxDistrict1Ind] = Ltrim(Rtrim([SchoolTaxDistrict1Ind]))
      ,[SchoolTaxDistrict2Code] = Ltrim(Rtrim([SchoolTaxDistrict2Code]))
      ,[SchoolTaxDistrict2Ind] = Ltrim(Rtrim([SchoolTaxDistrict2Ind]))
      ,[SchoolTaxDistrict3Code] = Ltrim(Rtrim([SchoolTaxDistrict3Code]))
      ,[SchoolTaxDistrict3Ind] = Ltrim(Rtrim([SchoolTaxDistrict3Ind]))
      ,[FADeleteFlag] = Ltrim(Rtrim([FADeleteFlag]))
      ,[FADeleteFlagDate] = Ltrim(Rtrim([FADeleteFlagDate]))

 
		DECLARE @NewFULL varchar(50) = '[DragonAssr].[dbo].[' + @New + ']'

		IF object_id(@NewFULL) IS NOT NULL
             EXEC('DROP TABLE IF Exists ' + @NewFULL + '');

		EXEC sp_RENAME 'PropertyWork',@New

		--Drop table if exists [DragonAssr].[dbo].[PropertyWork]
		CREATE TABLE [DragonAssr].[dbo].[PropertyWork](
			[FIPS] [char](5) NULL,
			[PropertyID] [bigint] NULL,
			[FormattedAPN] [varchar](45) NULL,
			[APNSeqNbr] [char](2) NULL,
			[UnformattedAPN] [varchar](45) NULL,
			[OldAPN] [varchar](31) NULL,
			[OLDAPNSeqNbr] [varchar](31) NULL,
			[TaxAccountNumber] [varchar](30) NULL,
			[RecordType] [varchar](2) NULL,
			[VendorPID] [bigint] NULL,
			[SitusStdFullStreetAddress] [varchar](116) NULL,
			[SitusStdHouseNbr] [varchar](30) NULL,
			[SitusStdHouseNbr2] [varchar](10) NULL,
			[SitusStdHouseNbrSuffix] [varchar](10) NULL,
			[SitusStdDirectionLeft] [varchar](2) NULL,
			[SitusStdStreet] [varchar](60) NULL,
			[SitusStdMode] [varchar](10) NULL,
			[SitusStdDirectionRight] [varchar](2) NULL,
			[SitusStdUnitNbr] [varchar](15) NULL,
			[SitusStdCity] [varchar](55) NULL,
			[SitusStdState] [varchar](2) NULL,
			[SitusStdZIP5] [varchar](9) NULL,
			[SitusStdZIP4] [varchar](4) NULL,
			[SitusLatitude] [float] NULL,
			[SitusLongitude] [float] NULL,
			[SitusStdCarrierCode] [varchar](4) NULL,
			[SitusCensusTract] [varchar](6) NULL,
			[SitusCensusTractBlock] [varchar](20) NULL,
			[SitusStdUnitType] [varchar](20) NULL,
			[SitusStdMatchCode] [varchar](30) NULL,
			[LotSizeSqFt] [varchar](15) NULL,
			[LotSizeAcres] [varchar](10) NULL,
			[LotSizeFrontageFeet] [varchar](10) NULL,
			[LotSizeDepthFeet] [varchar](10) NULL,
			[LotIrregularInd] [varchar](15) NULL,
			[LotUsableSize] [varchar](10) NULL,
			[PropertyClassID] [varchar](2) NULL,
			[StdLandUseCode] [char](5) NULL,
			[StateLandUseCode] [char](10) NULL,
			[CountyLandUseCode] [char](10) NULL,
			[CountyLandUseDescription] [varchar](45) NULL,
			[TimeshareCode] [char](1) NULL,
			[Zoning] [varchar](25) NULL,
			[SiteInfluenceCode] [varchar](10) NULL,
			[NeighborhoodCode] [varchar](10) NULL,
			[TopographyCode] [varchar](10) NULL,
			[MobileHomeInd] [varchar](15) NULL,
			[LotCode] [char](2) NULL,
			[LotNumber] [char](7) NULL,
			[LandLot] [char](10) NULL,
			[Block] [char](7) NULL,
			[Section] [char](7) NULL,
			[District] [varchar](12) NULL,
			[LegalUnit] [char](6) NULL,
			[Municipality] [varchar](30) NULL,
			[LegalSection] [varchar](30) NULL,
			[LegalTownship] [varchar](30) NULL,
			[LegalRange] [varchar](30) NULL,
			[Meridian] [varchar](30) NULL,
			[LegalQuarter] [varchar](30) NULL,
			[LegalQuarterQuarter] [varchar](30) NULL,
			[LegalDescription] [varchar](2000) NULL,
			[AssessorsMapRef1] [varchar](15) NULL,
			[AssessorsMapRef2] [varchar](15) NULL,
			[SubdivisionName] [varchar](40) NULL,
			[SubdivisionPhaseNbr] [char](7) NULL,
			[SubdivisionTractNbr] [char](10) NULL,
			[SubdivisionPlatBook] [char](10) NULL,
			[SubdivisionPlatPage] [char](10) NULL,
			[NewRecordType] [char](2) NULL,
			[SwiSCodeNY] [varchar](10) NULL,
			[MailingCareOfName] [varchar](80) NULL,
			[MailingStdFullStreetAddress] [varchar](116) NULL,
			[MailingStdHouseNbr] [varchar](30) NULL,
			[MailingStdHouseNbr2] [varchar](10) NULL,
			[MailingStdHouseNbrSuffix] [varchar](10) NULL,
			[MailingStdDirectionLeft] [varchar](2) NULL,
			[MailingStdStreet] [varchar](60) NULL,
			[MailingStdMode] [varchar](10) NULL,
			[MailingStdDirectionRight] [varchar](2) NULL,
			[MailingStdUnitNbr] [varchar](15) NULL,
			[MailingStdCity] [varchar](55) NULL,
			[MailingStdState] [varchar](2) NULL,
			[MailingStdZIP5] [varchar](9) NULL,
			[MailingStdZIP4] [varchar](9) NULL,
			[MailingStdCarrierCode] [varchar](4) NULL,
			[MailingStdUnitType] [varchar](20) NULL,
			[MailingStdMatchCode] [varchar](30) NULL,
			[MailingOptOut] [varchar](15) NULL,
			[MailingOptOutDate] [varchar](8) NULL,
			[OwnerOccupied] [char](1) NULL,
			[AbsenteeOwner] [char](1) NULL,
			[OwnerStdNAME1FULL] [varchar](80) NULL,
			[OwnerStdNAME2FULL] [varchar](80) NULL,
			[OwnerStdNAME3FULL] [varchar](80) NULL,
			[OwnerStdNAME4FULL] [varchar](80) NULL,
			[OwnerEtALIndicator] [varchar](5) NULL,
			[OwnerStd1CorpInd] [varchar](15) NULL,
			[OwnerStd1LastName] [varchar](30) NULL,
			[OwnerStd1FirstName] [varchar](30) NULL,
			[OwnerStd1MiddleName] [varchar](20) NULL,
			[OwnerStd1Suffix] [varchar](5) NULL,
			[OwnerStd1CorpName] [varchar](45) NULL,
			[OwnerStd1OwnershipRights] [varchar](5) NULL,
			[OwnerStd1RelationshipType] [varchar](5) NULL,
			[Owner1DoNotParse] [varchar](15) NULL,
			[OwnerStd2CorpInd] [varchar](15) NULL,
			[OwnerStd2LastName] [varchar](30) NULL,
			[OwnerStd2FirstName] [varchar](30) NULL,
			[OwnerStd2MiddleName] [varchar](20) NULL,
			[OwnerStd2Suffix] [varchar](5) NULL,
			[OwnerStd2CorpName] [varchar](45) NULL,
			[OwnerStd2OwnershipRights] [varchar](5) NULL,
			[OwnerStd2RelationshipType] [varchar](5) NULL,
			[Owner2DoNotParse] [varchar](15) NULL,
			[OwnerStd3CorpInd] [varchar](15) NULL,
			[OwnerStd3LastName] [varchar](30) NULL,
			[OwnerStd3FirstName] [varchar](30) NULL,
			[OwnerStd3MiddleName] [varchar](20) NULL,
			[OwnerStd3Suffix] [varchar](5) NULL,
			[OwnerStd3CorpName] [varchar](45) NULL,
			[OwnerStd3OwnershipRights] [varchar](5) NULL,
			[OwnerStd3RelationshipType] [varchar](5) NULL,
			[Owner3DoNotParse] [varchar](15) NULL,
			[OwnerStd4CorpInd] [varchar](15) NULL,
			[OwnerStd4LastName] [varchar](30) NULL,
			[OwnerStd4FirstName] [varchar](30) NULL,
			[OwnerStd4MiddleName] [varchar](20) NULL,
			[OwnerStd4Suffix] [varchar](5) NULL,
			[OwnerStd4CorpName] [varchar](45) NULL,
			[OwnerStd4OwnershipRights] [varchar](5) NULL,
			[OwnerStd4RelationshipType] [varchar](5) NULL,
			[Owner4DoNotParse] [varchar](15) NULL,
			[AssesseeStd1Name] [varchar](80) NULL,
			[AssesseeStd2Name] [varchar](80) NULL,
			[AssesseeNameIndicator] [varchar](1) NULL,
			[AssesseeNameIndicator2] [varchar](1) NULL,
			[Amenities] [varchar](10) NULL,
			[DrivewayCode] [varchar](10) NULL,
			[EasementInd] [varchar](15) NULL,
			[QualityCode] [varchar](10) NULL,
			[ViewInd] [varchar](15) NULL,
			[ViewCode] [varchar](10) NULL,
			[ViewQualityCode] [varchar](10) NULL,
			[WaterAccessableInd] [varchar](15) NULL,
			[WaterFeatureInd] [varchar](15) NULL,
			[WaterfrontCode] [varchar](10) NULL,
			[WaterfrontFeet] [varchar](15) NULL,
			[WaterfrontQualityCode] [varchar](10) NULL,
			[BuildingArea] [varchar](15) NULL,
			[BuildingAreaInd] [varchar](2) NULL,
			[TotalRooms] [varchar](15) NULL,
			[Bedrooms] [varchar](15) NULL,
			[BathTotalCalc] [numeric](5, 2) NULL,
			[BathFull] [varchar](15) NULL,
			[BathsParcialNbr] [varchar](15) NULL,
			[BathHalf] [varchar](15) NULL,
			[Bath1QTR] [varchar](15) NULL,
			[Bath3QTR] [varchar](15) NULL,
			[BathFixturesNbr] [varchar](15) NULL,
			[OtherRooms] [varchar](5) NULL,
			[AirConditioningCode] [varchar](15) NULL,
			[AirConditioningTypeCode] [varchar](15) NULL,
			[BasementCode] [varchar](15) NULL,
			[BasementFinishedCode] [varchar](15) NULL,
			[BuildingClassCode] [varchar](15) NULL,
			[BuildingConditionCode] [varchar](15) NULL,
			[BuildingQualityCode] [varchar](15) NULL,
			[ConstructionTypeCode] [varchar](15) NULL,
			[DeckCode] [varchar](15) NULL,
			[ElectricityCode] [varchar](15) NULL,
			[ExteriorWallsCode] [varchar](15) NULL,
			[FireplaceCode] [varchar](15) NULL,
			[FloorCoverCode] [varchar](15) NULL,
			[FloorTypeCode] [varchar](15) NULL,
			[FoundationInd] [varchar](15) NULL,
			[FrameCode] [varchar](15) NULL,
			[Garage] [varchar](15) NULL,
			[GarageParkingNbr] [varchar](15) NULL,
			[HeatCode] [varchar](15) NULL,
			[HeatingFuelTypeCode] [varchar](15) NULL,
			[InteriorWallsCode] [varchar](15) NULL,
			[PavingCode] [varchar](15) NULL,
			[PatioCode] [varchar](15) NULL,
			[PoolCode] [varchar](15) NULL,
			[PorchCode] [varchar](15) NULL,
			[RoofCoverCode] [varchar](15) NULL,
			[RoofTypeCode] [varchar](15) NULL,
			[SewerCode] [varchar](15) NULL,
			[ShapeCode] [varchar](15) NULL,
			[StoriesCode_OLD] [varchar](15) NULL,
			[StoriesNbrCode_OLD] [varchar](15) NULL,
			[StyleCode] [varchar](15) NULL,
			[WallExteriorCode] [varchar](15) NULL,
			[WallheightCode] [varchar](15) NULL,
			[WaterCode] [varchar](15) NULL,
			[YearBuilt] [varchar](4) NULL,
			[EffectiveYearBuilt] [varchar](4) NULL,
			[SumBuildingsNbr] [varchar](15) NULL,
			[SumAboveGradeLivingSqFt] [varchar](15) NULL,
			[SumAdjAreaSqFt] [varchar](15) NULL,
			[SumBasementSqFt] [varchar](15) NULL,
			[SumBuildingSqFt] [varchar](15) NULL,
			[SumGarageSqFt] [varchar](15) NULL,
			[SumGrossAreaSqFt] [varchar](15) NULL,
			[SumGroundFloorSqFt] [varchar](15) NULL,
			[SumLivingAreaSqFt] [varchar](15) NULL,
			[SumResidentialUnits] [varchar](15) NULL,
			[AssdLandValue] [varchar](15) NULL,
			[AssdImprovementValue] [varchar](15) NULL,
			[AssdTotalValue] [varchar](15) NULL,
			[AssdYear] [char](4) NULL,
			[MarketValueLand] [varchar](15) NULL,
			[MarketValueImprovement] [varchar](15) NULL,
			[MarketTotalValue] [varchar](15) NULL,
			[MarketValueYear] [char](4) NULL,
			[ApprLandValue] [varchar](15) NULL,
			[ApprImprovementValue] [varchar](15) NULL,
			[ApprTotalValue] [varchar](15) NULL,
			[ApprYear] [char](4) NULL,
			[TaxValueLand] [varchar](15) NULL,
			[TaxValueImprovement] [varchar](15) NULL,
			[TaxTotalValue] [varchar](15) NULL,
			[TaxableYear] [char](4) NULL,
			[UNVLandValue] [varchar](15) NULL,
			[UNVImprovementValue] [varchar](15) NULL,
			[UNVTotalValue] [varchar](15) NULL,
			[UNVValueYear] [char](4) NULL,
			[TaxRateCodeArea] [varchar](20) NULL,
			[TaxYear] [char](4) NULL,
			[TaxAmount] [bigint] NULL,
			[TaxDeliquentYear1] [char](4) NULL,
			[TaxDeliquentValue1] [varchar](15) NULL,
			[TaxExemptionCode] [varchar](10) NULL,
			[TaxexemptInd] [varchar](15) NULL,
			[CalifHomeownerInd] [varchar](15) NULL,
			[CemeteryInd] [varchar](15) NULL,
			[DisabledInd] [varchar](15) NULL,
			[HomesteadInd] [varchar](15) NULL,
			[HospitalInd] [varchar](15) NULL,
			[LibraryInd] [varchar](15) NULL,
			[PublicUtilityInd] [varchar](15) NULL,
			[ReligiousInd] [varchar](15) NULL,
			[SchoolCollegeInd] [varchar](15) NULL,
			[SeniorInd] [varchar](15) NULL,
			[VeteranInd] [varchar](15) NULL,
			[WelfareInd] [varchar](15) NULL,
			[WidowInd] [varchar](15) NULL,
			[SchoolTaxDistrict1Code] [varchar](15) NULL,
			[SchoolTaxDistrict1Ind] [char](1) NULL,
			[SchoolTaxDistrict2Code] [varchar](15) NULL,
			[SchoolTaxDistrict2Ind] [char](1) NULL,
			[SchoolTaxDistrict3Code] [varchar](15) NULL,
			[SchoolTaxDistrict3Ind] [char](1) NULL,
			[FADeleteFlag] [varchar](15) NULL,
			[FADeleteFlagDate] [datetime] NULL,
			[CurrentSaleTransactionId] [bigint] NULL,
			[CurrentSaleChronoKey] [varchar](31) NULL,
			[CurrSaleInputDocNbr] [varchar](20) NULL,
			[CurrSaleInputBook] [varchar](10) NULL,
			[CurrSaleInputPage] [varchar](10) NULL,
			[CurrSaleFormatDocNbr] [varchar](20) NULL,
			[CurrSaleFormatBook] [varchar](10) NULL,
			[CurrSaleFormatPage] [varchar](10) NULL,
			[CurrSaleRecordingDate] [varchar](8) NULL,
			[CurrSaleDocumentType] [varchar](30) NULL,
			[CurrSalesPrice] [varchar](15) NULL,
			[CurrSalesPriceCode] [varchar](5) NULL,
			[CurrSaleContractDate] [varchar](8) NULL,
			[CurrSaleBuyer1FullName] [varchar](60) NULL,
			[CurrSaleBuyer2FullName] [varchar](60) NULL,
			[CurrSaleBuyer3FullName] [varchar](60) NULL,
			[CurrSaleBuyer4FullName] [varchar](60) NULL,
			[CurrSaleSeller1FullName] [varchar](60) NULL,
			[CurrSaleSeller2FullName] [varchar](60) NULL,
			[ConCurrMtg1InputDocNbr] [varchar](20) NULL,
			[ConCurrMtg1InputBook] [varchar](10) NULL,
			[ConCurrMtg1InputPage] [varchar](10) NULL,
			[ConCurrMtg1FormatDocNbr] [varchar](20) NULL,
			[ConCurrMtg1FormatBook] [varchar](10) NULL,
			[ConCurrMtg1FormatPage] [varchar](10) NULL,
			[ConCurrMtg1RecordingDt] [varchar](10) NULL,
			[ConCurrMtg1LoanAmt] [varchar](15) NULL,
			[ConCurrMtg1Lender] [varchar](30) NULL,
			[ConCurrMtg1LenderCode] [varchar](10) NULL,
			[ConCurrMtg1LenderType] [varchar](5) NULL,
			[ConCurrMtg1PrivateLender] [varchar](15) NULL,
			[ConCurrMtg1Term] [varchar](3) NULL,
			[ConCurrMtg1LoanDueDt] [varchar](10) NULL,
			[ConCurrMtg1AdjOrFix] [varchar](1) NULL,
			[ConCurrMtg1LoanType] [varchar](10) NULL,
			[ConCurrMtg1Typefinancing] [varchar](10) NULL,
			[ConCurrMtg1LienPosition] [varchar](15) NULL,
			[ConCurrMtg2InputDocNbr] [varchar](20) NULL,
			[ConCurrMtg2InputBook] [varchar](10) NULL,
			[ConCurrMtg2InputPage] [varchar](10) NULL,
			[ConCurrMtg2FormatDocNbr] [varchar](20) NULL,
			[ConCurrMtg2FormatBook] [varchar](10) NULL,
			[ConCurrMtg2FormatPage] [varchar](10) NULL,
			[ConCurrMtg2RecordingDt] [varchar](10) NULL,
			[ConCurrMtg2LoanAmt] [varchar](15) NULL,
			[ConCurrMtg2Lender] [varchar](30) NULL,
			[ConCurrMtg2LenderCode] [varchar](10) NULL,
			[ConCurrMtg2LenderType] [varchar](5) NULL,
			[ConCurrMtg2PrivateLender] [varchar](15) NULL,
			[ConCurrMtg2LoanDueDt] [varchar](10) NULL,
			[ConCurrMtg2AdjOrFix] [varchar](1) NULL,
			[ConCurrMtg2LoanType] [varchar](10) NULL,
			[ConCurrMtg2Typefinancing] [varchar](10) NULL,
			[ConCurrMtg2LienPosition] [varchar](15) NULL,
			[Mtg1TransactionId] [bigint] NULL,
			[Mtg1ChronoKey] [varchar](31) NULL,
			[Mtg1LoanAmt] [int] NULL,
			[Mtg1Lender] [varchar](30) NULL,
			[Mtg1LenderCode] [varchar](10) NULL,
			[Mtg1LenderType] [varchar](10) NULL,
			[Mtg1PrivateLender] [varchar](15) NULL,
			[Mtg1LoanDueDt] [varchar](10) NULL,
			[Mtg1AdjRider] [varchar](1) NULL,
			[Mtg1LoanType] [varchar](10) NULL,
			[Mtg1Typefinancing] [varchar](10) NULL,
			[Mtg1LienPosition] [varchar](15) NULL,
			[Mtg2TransactionId] [bigint] NULL,
			[Mtg2ChronoKey] [varchar](31) NULL,
			[Mtg2InputDocNbr] [varchar](20) NULL,
			[Mtg2InputBook] [varchar](10) NULL,
			[Mtg2InputPage] [varchar](10) NULL,
			[Mtg2FormatDocNbr] [varchar](20) NULL,
			[Mtg2FormatBook] [varchar](10) NULL,
			[Mtg2FormatPage] [varchar](10) NULL,
			[Mtg2RecordingDt] [varchar](10) NULL,
			[Mtg2LoanAmt] [int] NULL,
			[Mtg2Lender] [varchar](30) NULL,
			[Mtg2LenderCode] [varchar](10) NULL,
			[Mtg2LenderType] [varchar](10) NULL,
			[Mtg2PrivateLender] [varchar](15) NULL,
			[Mtg2LoanDueDt] [varchar](10) NULL,
			[Mtg2AdjRider] [varchar](1) NULL,
			[Mtg2LoanType] [varchar](10) NULL,
			[Mtg2Typefinancing] [varchar](10) NULL,
			[Mtg2LienPosition] [varchar](15) NULL,
			[Mtg3TransactionId] [bigint] NULL,
			[Mtg3ChronoKey] [varchar](31) NULL,
			[Mtg3InputDocNbr] [varchar](20) NULL,
			[Mtg3InputBook] [varchar](10) NULL,
			[Mtg3InputPage] [varchar](10) NULL,
			[Mtg3FormatDocNbr] [varchar](20) NULL,
			[Mtg3FormatBook] [varchar](10) NULL,
			[Mtg3FormatPage] [varchar](10) NULL,
			[Mtg3RecordingDt] [varchar](10) NULL,
			[Mtg3LoanAmt] [int] NULL,
			[Mtg3Lender] [varchar](30) NULL,
			[Mtg3LenderCode] [varchar](10) NULL,
			[Mtg3LenderType] [varchar](10) NULL,
			[Mtg3PrivateLender] [varchar](15) NULL,
			[Mtg3LoanDueDt] [varchar](10) NULL,
			[Mtg3AdjRider] [varchar](1) NULL,
			[Mtg3LoanType] [varchar](10) NULL,
			[Mtg3Typefinancing] [varchar](10) NULL,
			[Mtg3LienPosition] [varchar](15) NULL,
			[Mtg4TransactionId] [bigint] NULL,
			[Mtg4ChronoKey] [varchar](31) NULL,
			[Mtg4InputDocNbr] [varchar](20) NULL,
			[Mtg4InputBook] [varchar](10) NULL,
			[Mtg4InputPage] [varchar](10) NULL,
			[Mtg4FormatDocNbr] [varchar](20) NULL,
			[Mtg4FormatBook] [varchar](10) NULL,
			[Mtg4FormatPage] [varchar](10) NULL,
			[Mtg4RecordingDt] [varchar](10) NULL,
			[Mtg4LoanAmt] [int] NULL,
			[Mtg4Lender] [varchar](30) NULL,
			[Mtg4LenderCode] [varchar](10) NULL,
			[Mtg4LenderType] [varchar](10) NULL,
			[Mtg4PrivateLender] [varchar](15) NULL,
			[Mtg4LoanDueDt] [varchar](10) NULL,
			[Mtg4AdjRider] [varchar](1) NULL,
			[Mtg4LoanType] [varchar](10) NULL,
			[Mtg4Typefinancing] [varchar](10) NULL,
			[Mtg4LienPosition] [varchar](15) NULL,
			[PrevSaleTransactionId] [bigint] NULL,
			[PrevSaleChronoKey] [varchar](31) NULL,
			[PrevSaleInputDocNbr] [varchar](20) NULL,
			[PrevSaleInputBook] [varchar](10) NULL,
			[PrevSaleInputPage] [varchar](10) NULL,
			[PrevSaleFormatDocNbr] [varchar](20) NULL,
			[PrevSaleFormatBook] [varchar](10) NULL,
			[PrevSaleFormatPage] [varchar](10) NULL,
			[PrevSaleRecordingDate] [varchar](8) NULL,
			[PrevSalesPrice] [int] NULL,
			[PrevSalesPriceCode] [varchar](5) NULL,
			[PrevSaleContractDate] [varchar](8) NULL,
			[PrevSaleBuyer1FullName] [varchar](60) NULL,
			[PrevSaleBuyer2FullName] [varchar](60) NULL,
			[PrevSaleBuyer3FullName] [varchar](60) NULL,
			[PrevSaleBuyer4FullName] [varchar](60) NULL,
			[PrevSaleSeller1FullName] [varchar](60) NULL,
			[PrevSaleSeller2FullName] [varchar](60) NULL,
			[PrevMtg1InputDocNbr] [varchar](20) NULL,
			[PrevMtg1InputBook] [varchar](10) NULL,
			[PrevMtg1InputPage] [varchar](10) NULL,
			[PrevMtg1FormatDocNbr] [varchar](20) NULL,
			[PrevMtg1FormatBook] [varchar](10) NULL,
			[PrevMtg1FormatPage] [varchar](10) NULL,
			[PrevMtg1RecordingDt] [varchar](10) NULL,
			[PrevMtg1LoanAmt] [int] NULL,
			[PrevMtg1Lender] [varchar](30) NULL,
			[PrevMtg1LenderCode] [varchar](10) NULL,
			[PrevMtg1LenderType] [varchar](5) NULL,
			[PrevMtg1PrivateLender] [varchar](15) NULL,
			[PrevMtg1LoanDueDt] [varchar](10) NULL,
			[PrevMtg1AdjRider] [varchar](1) NULL,
			[PrevMtg1LoanType] [varchar](10) NULL,
			[PrevMtg1Typefinancing] [varchar](10) NULL,
			[EditionNumber] [char](2) NULL,
			[VersionId] [numeric](9, 0) NULL,
			[VendorLoadDate] [varchar](8) NULL,
			[FASourceInd] [varchar](2) NULL,
			[FATimestamp] [datetime2](7) NULL,
			[FAUserId] [varchar](50) NULL,
			[FACreateDt] [datetime2](7) NULL,
			[FADeriveProcessDt] [datetime2](7) NULL,
			[FAEnhanceprocessDt] [datetime2](7) NULL,
			[FAOwnershipUpdateDt] [datetime2](7) NULL,
			[FAActiveDt] [datetime2](7) NULL,
			[SitusDPVCount] [char](5) NULL,
			[SitusDPVFootnote] [char](4) NULL,
			[SitusLACS] [char](1) NULL,
			[SitusLACSLinkInd] [char](1) NULL,
			[SitusDPCheckDigit] [char](1) NULL,
			[SitusDPCheckCode] [char](2) NULL,
			[SitusCensusBlock] [char](4) NULL,
			[SitusGeoErrorCode] [char](1) NULL,
			[SitusGeoStatusCode] [char](1) NULL,
			[MailingDPVCount] [char](5) NULL,
			[MailingDPVFootnote] [char](4) NULL,
			[MailingLACS] [char](1) NULL,
			[MailingLACSLinkInd] [char](1) NULL,
			[MailingDPCheckDigit] [char](1) NULL,
			[MailingDPCheckCode] [char](2) NULL,
			[MailingCensusBlock] [char](4) NULL,
			[MailingCensusTract] [char](6) NULL,
			[MailingGeoErrorCode] [char](1) NULL,
			[MailingGeoStatusCode] [char](1) NULL,
			[CheckOwnership] [varchar](1) NULL,
			[Mtg1InputDocNbr] [varchar](20) NULL,
			[Mtg1InputBook] [varchar](10) NULL,
			[Mtg1FormatDocNbr] [varchar](20) NULL,
			[Mtg1FormatBook] [varchar](10) NULL,
			[Mtg1FormatPage] [varchar](10) NULL,
			[Mtg1RecordingDt] [varchar](10) NULL,
			[Mtg1InputPage] [varchar](10) NULL,
			[FAUCIDFlag] [char](1) NULL,
			[FADateReceived] [varchar](8) NULL,
			[FAAddressParsedSitus] [datetime] NULL,
			[FAAddressParsedMailing] [datetime] NULL,
			[FACLTV] [decimal](10, 2) NULL,
			[FAOLTV] [decimal](10, 2) NULL,
			[FALatitude] [float] NULL,
			[FALongitude] [float] NULL,
			[FAEstLotSqFt] [bigint] NULL,
			[FAOwnerTransactionId] [bigint] NULL,
			[MailForeignAddrInd] [varchar](1) NULL,
			[FAIsListedFlag] [char](1) NULL,
			[FAIsListedFlagDt] [varchar](8) NULL,
			[FAIsListedPriceRange] [varchar](25) NULL,
			[TPLatitude] [float] NULL,
			[TPLongitude] [float] NULL,
			[TPGeoStatusCode] [varchar](20) NULL,
			[FAGeoStatusCode] [varchar](20) NULL,
			[SumCommercialUnits] [varchar](15) NULL,
			[SitusGeoCodeResults] [varchar](30) NULL,
			[MailingGeoCodeResults] [varchar](30) NULL,
			[LienPosUpdateFlag] [varchar](1) NULL,
			[LienPosUpdateDate] [datetime] NULL,
			[TotalOpenLienAmt] [varchar](15) NULL,
			[TotalOpenLienNbr] [varchar](15) NULL,
			[VacantFlag] [varchar](1) NULL,
			[VacantFlagDate] [datetime] NULL,
			[AssessorLkupToken0] [varchar](50) NULL,
			[AssessorLkupToken1] [varchar](50) NULL,
			[SchoolDistrictName] [varchar](80) NULL,
			[AssessorLkupToken2] [varchar](50) NULL,
			[FADataArchiveDate] [datetime] NULL,
			[ConCurrMtg2Term] [varchar](3) NULL,
			[Mtg1Term] [varchar](3) NULL,
			[Mtg2Term] [varchar](3) NULL,
			[Mtg3Term] [varchar](3) NULL,
			[Mtg4Term] [varchar](3) NULL,
			[PrevMtg1Term] [varchar](3) NULL,
			[BankOwned] [varchar](1) NULL,
			[StoriesCode] [varchar](10) NULL,
			[StoriesNbrCode] [varchar](10) NULL,
			[BasementFinishSqFt] [varchar](11) NULL,
			[BasementUnfinSqFt] [varchar](11) NULL,
			[GarageFinishSqFt] [varchar](11) NULL,
			[GarageUnFinSqFt] [varchar](11) NULL,
			[AtticSqFt] [varchar](11) NULL,
			[AtticFinishSqFt] [varchar](11) NULL,
			[AtticUnfinSqFt] [varchar](11) NULL,
			[Mtg1EstPaymentAmt] [varchar](15) NULL,
			[Mtg1InterestRate] [varchar](6) NULL,
			[Mtg2EstPaymentAmt] [varchar](15) NULL,
			[Mtg2InterestRate] [varchar](6) NULL,
			[Mtg3EstPaymentAmt] [varchar](15) NULL,
			[Mtg3InterestRate] [varchar](6) NULL,
			[Mtg4EstPaymentAmt] [varchar](15) NULL,
			[Mtg4InterestRate] [varchar](6) NULL,
			[ConCurrMtg1InterestRate] [varchar](6) NULL,
			[ConCurrMtg2InterestRate] [varchar](6) NULL,
			[PrevMtg1InterestRate] [varchar](6) NULL,
			[MailingFIPS] [varchar](5) NULL,
			[DBSTaxAmount] [bigint] NULL,
			[DBSTaxYear] [varchar](4) NULL,
			[Mtg1EstLoanBalance] [int] NULL,
			[Mtg2EstLoanBalance] [int] NULL,
			[Mtg3EstLoanBalance] [int] NULL,
			[Mtg4EstLoanBalance] [int] NULL,
			[OldApnIndicator] [varchar](1) NULL,
			[PrevSaleDocumentType] [varchar](2) NULL,
			[SecondPrevSaleTransactionId] [bigint] NULL,
			[SecondPrevSaleRecordingDate] [varchar](8) NULL,
			[SecondPrevSalesPrice] [varchar](15) NULL,
			[ThirdPrevSaleTransactionId] [bigint] NULL,
			[ThirdPrevSaleRecordingDate] [varchar](8) NULL,
			[ThirdPrevSalesPrice] [varchar](15) NULL,
			[HouseFacingDirection] [varchar](2) NULL,
			[FARooftopLatitude] [float] NULL,
			[FARooftopLongitude] [float] NULL,
			[BuildingEstFootprintSqFt] [varchar](15) NULL,
			[BathTotalCalcEst] [numeric](5, 2) NULL,
			[DQOZ_TractType] [varchar](50) NULL,
			[DQOZ_ACSDataSource] [varchar](10) NULL,
			[VacantScore] [varchar](3) NULL,
			[BedroomsEst] [varchar](15) NULL,
			[DTDB_Ref_ID] [bigint] NULL,
			[DTDB_FORMATTED_APN] [varchar](60) NULL,
			[MailingLabelName] [varchar](100) NULL,
			[Name1TypeInd] [varchar](15) NULL,
			[Name2TypeInd] [varchar](15) NULL,
			[TaxSourceInd] [varchar](2) NULL,
			[FASubdivisionName] [varchar](40) NULL,
			[FAComplexNbrUnits] [varchar](15) NULL,
			[FASubdivisionNameID] [varchar](15) NULL,
			[FASubdivisionPhase] [varchar](5) NULL,
			[ElevatorCode] [varchar](3) NULL,
			[FAEstimatedMultiPolygonFlag] [varchar](1) NULL,
			[FAEstimatedNumberofBuildings] [varchar](15) NULL,
			[Poverty] [varchar](1) NULL,
			[UnEmployment] [varchar](1) NULL,
			[PopulationLoss] [varchar](1) NULL,
			[RemoteRural] [varchar](1) NULL,
			[Distressed] [varchar](1) NULL,
			[UnderServed] [varchar](1) NULL,
			[DTDB_UNFORMATTED_APN] [varchar](60) NULL,
			[ConformingLoanLimitYear] [varchar](4) NULL,
			[ConformingLoanLimit] [int] NULL,
			[PriorConformingLoanLimitYear] [varchar](4) NULL,
			[PriorConformingLoanLimit] [int] NULL,
			[MTG1InterestRateSrce] varchar(2) NULL,
			[MTG2InterestRateSrce] varchar(2) NULL,
			[MTG3InterestRateSrce] varchar(2) NULL,
			[MTG4InterestRateSrce] varchar(2) NULL,
			[CS_FORMATTED_APN] varchar(60) NULL,
			[CS_UNFORMATTED_APN] varchar(60) NULL,
			[SPOT_ID] bigint NULL,
			[Certification_Date] date NULL
		) ON [PRIMARY]

		/****** Object:  Index [ix_FipsAPN]    Script Date: 12/30/2020 7:30:18 AM ******/
		CREATE NONCLUSTERED INDEX [ix_FipsAPN] ON [dbo].[PropertyWork]
		([FIPS] ASC,	[FormattedAPN] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsDTDB_Ref_ID] ON [dbo].[PropertyWork]
		([FIPS] ASC,[DTDB_Ref_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[PropertyWork]
		([FIPS] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


			EXEC('Delete from a
			FROM [DragonAssr].[dbo].[PropertyWork_' + @Fipscode + '] a 
			JOIN (Select propertyID,Min(VendorPID) MinVendorID from [DragonAssr].[dbo].[PropertyWork_' + @Fipscode + '] where propertyid is not null group by propertyid having count(*) > 1 ) c
			on a.PropertyID = c.PropertyID
				and a.VendorPID = c.MinVendorID
			')


		INSERT INTO DragonProcessingTracker
		Select 'Rename Finish ' + @FipsCode,GETDATE() as ProcessingStartTime 



END

