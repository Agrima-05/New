SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[usp_CityOfOakland] 
AS
BEGIN

update [AddressMaster].[dbo].[Address_Master_06001] set GeoCityofOakland = null
--SELECT *
update s set s.GeoCityofOakland = 'Y'  
  FROM [AddressMaster].[dbo].[Address_Master_06001] s 
    inner join xGtrang.dbo.Oakland_CA_Streets_CityLimits c  on c.[GEOM].STContains((geometry::STGeomFromText( 'POINT('+cast(cast([ConsdtLongitude] as decimal(13,6)) as varchar(20)) +' ' +cast(cast([ConsdtLatitude] as decimal(13,6)) as varchar(20)) + ')'  ,4269))) = 1
	where s.PropertyId is not null or (s.addressmatchresults like '%as01%' or s.addressmatchresults like '%as03%')

END



