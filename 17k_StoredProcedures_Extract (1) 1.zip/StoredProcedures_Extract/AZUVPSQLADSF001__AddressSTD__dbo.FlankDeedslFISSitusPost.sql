SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankDeedslFISSitusPost] (@tableName varchar(40)) 
as  
declare @sql varchar(max)

    set @sql = '
	   UPDATE Deed_sl_FIS_Situs_STD
       set [SitusStdFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdHouseNbr])) + '' '' + Deed_sl_FIS_Situs_STD.[SitusStdDirectionLeft]) + '' '' + ltrim(rtrim(UPPER(Deed_sl_FIS_Situs_STD.[SitusStdStreet])))) + '' '' + ltrim(rtrim(UPPER(Deed_sl_FIS_Situs_STD.[SitusStdMode])))) + '' '' + ltrim(rtrim(UPPER(Deed_sl_FIS_Situs_STD.[SitusStdDirectionRight])))) + '' '' + ltrim(rtrim(UPPER(Deed_sl_FIS_Situs_STD.[SitusStdUnitType])))) + '' '' + ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdUnitNbr]))))
	   ,[SitusStdHouseNbr]  = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdHouseNbr]))
       ,[SitusStdDirectionLeft] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdDirectionLeft]))
       ,[SitusStdStreet] = UPPER(ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdStreet])))
       ,[SitusStdMode] = UPPER(ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdMode])))
       ,[SitusStdDirectionRight] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdDirectionRight]))
       ,[SitusStdUnitNbr] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdUnitNbr]))
       ,[SitusStdCity] = UPPER(ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdCity])))
       ,[SitusStdState] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdState]))
       ,[SitusStdZIP5] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdZIP5]))
       ,[SitusStdZIP4] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdZIP4]))
       ,[SitusLatitude] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusLatitude]))
       ,[SitusLongitude] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusLongitude]))
       ,[SitusStdCarrierCode] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdCarrierCode]))
	   ,[SitusCensusTract] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusCensusTract]))
       ,[SitusCensusTractBlock] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusCensusTract])) + ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusCensusBlock]))
       ,[SitusStdUnitType] = UPPER(ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdUnitType])))
       ,[SitusStdMatchCode] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusStdMatchCode]))
       ,[SitusDPVCount] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusDPVCount]))
       ,[SitusDPVFootnote] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusDPVFootnote]))
       ,[SitusLACS] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusLACS]))
       ,[SitusLACSLinkInd] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusLACSLinkInd]))
       ,[SitusDPCheckDigit] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusDPCheckDigit]))
       ,[SitusDPCheckCode] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusDPCheckCode]))
       ,[SitusCensusBlock] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusCensusBlock]))
       ,[SitusGeoErrorCode] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusGeoErrorCode]))
       ,[SitusGeoStatusCode] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusGeoStatusCode]))
       ,[SitusGeoCodeResults] = ltrim(rtrim(Deed_sl_FIS_Situs_STD.[SitusGeoCodeResults]))
     From Deed_sl_FIS_Situs_STD
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Deed_sl_FIS_Situs_to_Licensing

