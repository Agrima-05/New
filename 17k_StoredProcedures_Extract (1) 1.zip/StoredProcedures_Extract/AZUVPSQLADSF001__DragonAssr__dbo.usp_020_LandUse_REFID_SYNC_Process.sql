SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[usp_020_LandUse_REFID_SYNC_Process]
AS
BEGIN
SET NOCOUNT ON;

DECLARE @FipsCode varchar(5)
DECLARE @Dt varchar(10) = convert(varchar(10),Getdate()+1,120)

DECLARE FmtDocPost CURSOR FOR  
SELECT [FIPSCode] 
FROM [Global].dbo.[County]
WHERE SrcProperty = 'DRG'
ORDER BY [FIPSCode]


OPEN FmtDocPost   
FETCH NEXT FROM FmtDocPost INTO @FipsCode

WHILE @@FETCH_STATUS = 0   
BEGIN   
  
PRINT @FipsCode

EXEC('UPDATE a
SET StdLandUseCode = c.FlankCode
,[PropertyClassID] = c.[PropClassID]
,FATimestamp = ''' + @Dt + '''
,FAUserID = ''StdLandUse Update''
from (Select FIPS,DTDB_REF_ID,StdLandUseCode,PropertyClassID,FATimestamp,FAUSERID FROM data.dbo.Property WHERE FIPS = '''+@FipsCode+''') a 
JOIN (Select FIPS,REF_ID,LAND_USE FROM [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR with(NOLOCK) WHERE FIPS = '+@FipsCode+') b
ON DTDB_Ref_ID = REF_ID
JOIN DragonAssr.dbo.LandUseLookup c on b.LAND_USE = c.Value
where (StdLandUseCode is NULL or (StdLandUseCode != FlankCode and StdLandUseCode not in(''1104'',''1105'')))')

		EXEC('UPDATE a
			SET a.[CountyLandUseDescription] = LEFT(replace(b.[COUNTY_LAND_USE_CODE_DISCRIPTION],''|'',''''),45)
			,a.FAUserID = ''Update CountyLandUseDesc''
			,FATimestamp = ''' + @Dt + '''
			  from data.dbo.Property a with(NOLOCK) JOIN [DWS-ETL02].[DRAGON_Wrk].[dbo].[Assr_Land_Use] b with(NOLOCK)
				ON a.Fips = b.fips
				and a.UnformattedAPN = b.Unformatted_APN
			WHERE a.FIPS = ''' + @FipsCode + '''
				and b.FIPS = ''' + @FipsCode + '''
					and a.CountyLandUseDescription <> COUNTY_LAND_USE_CODE_DISCRIPTION
			')

EXEC('UPDATE A
SET a.FAUserId = ''REFID Update''
,a.FATimestamp = ''' + @Dt + '''
,a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,''|'','''')
,a.DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,''|'','''')
From (Select FIPS,PropertyID,FormattedAPN,DTDB_UNFORMATTED_APN,DTDB_Ref_ID,DTDB_FORMATTED_APN,FADateReceived,FAUserId,FAUCIDFlag,FATimestamp 
from data.dbo.Property with(NOLOCK) WHERE FIPS = '''+@FipsCode+''' and FAUCIDFlag not like ''D''
) as A
join  (Select FIPS,REF_ID,FORMATTED_APN,CREATED,UPDATED,UNFORMATTED_APN FROM [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] with(NOLOCK) 
WHERE FIPS = '+@FipsCode+') as B
on A.FIPS = B.FIPS and A.FormattedAPN = B.FORMATTED_APN
where A.DTDB_Ref_ID <> B.REF_ID
')


		EXEC('UPDATE data.dbo.Property
		SET StdLandUseCode = ''1104''
		Where FIPS = '''+@FipsCode+''' and StdLandUseCode = ''1110'' and [SumResidentialUnits] >= 5
		')


FETCH NEXT FROM FmtDocPost INTO @FipsCode   
END   

CLOSE FmtDocPost   
DEALLOCATE FmtDocPost 
END
