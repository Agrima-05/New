SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_UpdateCurrentRecord]

AS
BEGIN
	SET NOCOUNT ON;

		
		DECLARE @FipsCode varchar(5)
		
		DECLARE ResetCurrRec CURSOR FOR  
			SELECT Fipscode 
			FROM Global.dbo.County
			Where FIPSCode in('48085','48121','48167','48251','48257','48259','48339','48473')
			ORDER BY FIPSCode


		OPEN ResetCurrRec   
		FETCH NEXT FROM ResetCurrRec INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
		PRINT @FipsCode

---- RESET Current Record

		SELECT FIPS
		,COUNT(*) as TotalRecCount
		,SUM(CASE WHEN CurrentRecord = 'Y' THEN 1 ELSE 0 END ) as HasCurrRec_OLD
		,SUM(0) as HasCurrRec_NEW
		INTO #Updated
		FROM Dbs_Tax_Lic.dbo.Licensing_Deliverable
		WHERE Lic_FIPS = @FipsCode
		GROUP BY FIPS
		
		UPDATE a
		SET CurrentRecord = NULL
		FROM DBS_Tax_Lic.dbo.licensing_Deliverable a 
		WHERE Lic_FIPS = @FipsCode

		Drop table DBS_Tax_Lic.dbo.CurrentRecord

		Select FIPS,FAPropertyID,Max(Tax_Year_Begin) MaxYr
		INTO DBS_Tax_Lic.dbo.CurrentRecord
		From DBS_Tax_Lic.dbo.Licensing_Deliverable a 
		WHERE Lic_FIPS = @FipsCode
		Group by FIPS,FAPropertyID

		CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsPropIDMaxYr] ON DBS_Tax_Lic.dbo.[CurrentRecord]
		([FIPS] ASC,[FAPropertyID] ASC,	[MaxYr] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		UPDATE a
		SET CurrentRecord = 'Y'
		,UPDATED = CURRENT_TIMESTAMP 
		FROM DBS_Tax_Lic.dbo.licensing_Deliverable a JOIN DBS_Tax_Lic.dbo.CurrentRecord b
		on a.fips = b.fips
		and a.FAPropertyID = b.FAPropertyID
		and a.Tax_Year_Begin = b.MaxYr


		UPDATE #Updated
		SET HasCurrRec_NEW = (Select SUM(CASE WHEN CurrentRecord = 'Y' THEN 1 ELSE 0 END)
		FROM Dbs_Tax_Lic.dbo.Licensing_Deliverable
		WHERE Lic_FIPS = @FipsCode)
		WHERE FIPS = @FipsCode

		--Select * from #Updated
		DROP TABLE #Updated

		PRINT @FipsCode

			FETCH NEXT FROM ResetCurrRec INTO @FipsCode   
		
		END   

		CLOSE ResetCurrRec   
		DEALLOCATE ResetCurrRec 
END

