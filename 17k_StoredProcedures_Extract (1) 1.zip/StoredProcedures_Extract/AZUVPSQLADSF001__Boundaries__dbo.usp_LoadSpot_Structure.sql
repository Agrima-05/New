SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_LoadSpot_Structure]
AS
BEGIN

	SET NOCOUNT ON;

		DROP TABLE IF EXISTS dlvry.Structure_BATCH
		DROP TABLE IF EXISTS dlvry.Structure_BATCH_FIPS
		DECLARE @SQL nvarchar(1000)
		DECLARE @Date as varchar(10)
		Select @Date = convert(varchar(10),max([UpdatedDate]),120) from dbo.FASPOT_Structures with(NOLOCK)

		SET @SQL = 'SELECT FIPS INTO dlvry.Structure_BATCH_FIPS 
		FROM OPENQUERY([AZUVPSQLDTDB034],''Select DISTINCT FIPS from [Spot].[dlvry].[Structure] WHERE [UpdatedDate] > ''''' + @Date + ''''';'')
		'

		EXEC (@SQL);

		DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT FIPS 
			FROM dlvry.Structure_BATCH_FIPS
			Group by Fips
			order by Fips


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

				DROP TABLE IF EXISTS dlvry.Structure_BATCH
				--DECLARE @SQL nvarchar(1000)
				Select @Date = convert(varchar(10),GETDATE()+1,20)

				SET @SQL = 'SELECT * INTO dlvry.Structure_BATCH 
				FROM OPENQUERY([AZUVPSQLDTDB034],''Select * from [Spot].[dlvry].[Structure] WHERE [Fips] IN(''''' + @FipsCode + ''''');'')
				'
				EXEC (@SQL);

				--Select * From dlvry.Structure_BATCH 
				EXEC('CREATE INDEX IX_FIPSREFID on dlvry.Structure_BATCH(FIPS,[RefId])

				TRUNCATE TABLE dbo.[FASPOT_Structures_Batch]

				INSERT INTO dbo.[FASPOT_Structures_Batch]([Fips]
				  ,[MasterAssrId]
				  ,[RefId]
				  ,[Geom]
				  ,[MasterStructureId]
				  ,[Uuid]
				  ,[Height]
				  ,[ImageDate]
				  ,[UpdatedDate]
				  ,[StructureWKT]
				  ,[StructureCentroidLatitude]
				  ,[StructureCentroidLongitude]
				  ,[PropertyID]
				  ,[StructureCalcSqFt]
				  ,[FATimestamp]
				  ,[BldgSeq])
				Select a.[Fips]
					,[MasterAssrId]
					,[RefId]
					,[Geom]
					,[MasterStructureId]
					,[Uuid]
					,[Height]
					,[ImageDate]
					,[UpdatedDate]
					,[Geom].MakeValid().STUnion([Geom].STStartPoint()).STAsText()
					,[Geom].MakeValid().STCentroid().STY 
					,[Geom].MakeValid().STCentroid().STX
					,PropertyID
					,geography::STGeomFromText([Geom].MakeValid().STUnion([Geom].STStartPoint()).STAsText(), 4269).MakeValid().STArea() * 10.7639
					,''' + @Date + ''' as [FATimestamp]
					,ROW_NUMBER() OVER(PARTITION BY a.FIPS,REFID ORDER BY [MasterStructureId]) AS BldgSeq
					FROM [dlvry].[Structure_BATCH] a with(NOLOCK) JOIN Data.dbo.property b with(NOLOCK)
					on a.fips = b.fips
						and a.refid = b.DTDB_Ref_ID
					WHERE b.FIPS = ''' + @FipsCode + '''


				DROP INDEX IF EXISTS [ix_FipsREFID] ON [dbo].[FASPOT_Structures]
				DROP INDEX IF EXISTS [ix_FipsPropID] ON [dbo].[FASPOT_Structures]

				DELETE FROM a
				FROM dbo.FASPOT_Structures a 
				WHERE FIPS = ''' + @FipsCode + '''
				
				INSERT INTO dbo.FASPOT_Structures([Fips]
					  ,[MasterAssrId]
					  ,[RefId]
					  ,[Geom]
					  ,[MasterStructureId]
					  ,[Uuid]
					  ,[Height]
					  ,[ImageDate]
					  ,[UpdatedDate]
					  ,[StructureWKT]
					  ,[StructureCentroidLatitude]
					  ,[StructureCentroidLongitude]
					  ,[PropertyID]
					  ,[StructureCalcSqFt]
					  ,[NbrStructuresOnProperty]
					  ,[FATimestamp]
					  ,[FAUCIDFlag]
					  ,BldgSeq) 
				SELECT [Fips]
					  ,[MasterAssrId]
					  ,[RefId]
					  ,[Geom]
					  ,[MasterStructureId]
					  ,[Uuid]
					  ,[Height]
					  ,[ImageDate]
					  ,[UpdatedDate]
					  ,[StructureWKT]
					  ,[StructureCentroidLatitude]
					  ,[StructureCentroidLongitude]
					  ,[PropertyID]
					  ,[StructureCalcSqFt]
					  ,[NbrStructuresOnProperty]
					  ,''' + @Date + '''
					  ,''I''
					  ,BldgSeq
				FROM dbo.[FASPOT_Structures_Batch]

				DROP TABLE IF EXISTS #bldgNbr

				Select FIPS,RefId,COUNT(*) as BldgNbr into #bldgNbr from dbo.FASPOT_Structures WHERE FIPS = ''' + @FipsCode + ''' group by FIPS,REFID

				create unique index ix_bldg on #bldgnbr(FIPS,REFID) 

				UPDATE a
				SET [NbrStructuresOnProperty] = b.BldgNbr
				FROM dbo.FASPOT_Structures a 
				JOIN #bldgNbr b
				ON a.Fips = b.Fips
				and a.RefId = b.RefId
				WHERE a.FIPS = ''' + @FipsCode + '''


				DROP TABLE IF EXISTS #bldgNbr

				Truncate table dlvry.Structure_BATCH
				Truncate table dbo.FASPOT_Structures_Batch
				')

			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 

				DROP INDEX IF EXISTS [ix_FipsPropIDBldgID] ON [dbo].[FASPOT_Structures]

				CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsPropIDBldgID] ON [dbo].[FASPOT_Structures]
				([Fips] ASC,[PropertyID] ASC,[BldgSeq] ASC
				)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

				DROP INDEX IF EXISTS [ix_FipsREFID] ON [dbo].[FASPOT_Structures]

				CREATE NONCLUSTERED INDEX [ix_FipsREFID] ON [dbo].[FASPOT_Structures]
				([Fips] ASC,[RefId] ASC
				)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

				DROP INDEX IF EXISTS [ix_FipsPropID] ON [dbo].[FASPOT_Structures]

				CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[FASPOT_Structures]
				([Fips] ASC,	[PropertyID] ASC
				)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


		DROP TABLE IF EXISTS dlvry.Structure_BATCH
		DROP TABLE IF EXISTS dlvry.Structure_BATCH_FIPS


END
