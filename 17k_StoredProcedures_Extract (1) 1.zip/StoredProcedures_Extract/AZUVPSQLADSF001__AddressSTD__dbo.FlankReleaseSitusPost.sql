SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankReleaseSitusPost] (@tableName varchar(40)) -- @tableName = 'Release_Situs' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild SitusFullStreetAddress and SitusCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Release_Situs_STD]
	   --set [SitusFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusHouseNbr])) + '' '' + [AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusMode]))) + '' '' + [AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitNbr])))))))
       set [SitusFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusHouseNbr])) + '' '' + [AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitNbr]))))
	   ,[SitusHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusHouseNbr]))
       ,[SitusDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionLeft]))
       ,[SitusStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusStreet])))
       ,[SitusMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusMode])))
       ,[SitusDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDirectionRight]))
       ,[SitusUnitNbr] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitNbr]))
       ,[SitusCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCity])))
       ,[SitusState] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusState]))
       ,[SitusZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusZIP5]))
       ,[SitusZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusZIP4]))
       ,[SitusLatitude] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusLatitude]))
       ,[SitusLongitude] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusLongitude]))
       ,[SitusCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCarrierCode]))
	   ,[SitusCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCensusTract]))
       ,[SitusCensusTractBlock] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCensusTract])) + ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCensusBlock]))
       ,[SitusUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusUnitType])))
       ,[SitusMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusMatchCode]))
       ,[SitusDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDPVCount]))
       ,[SitusDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDPVFootnote]))
       ,[SitusLACS] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusLACS]))
       ,[SitusLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusLACSLinkInd]))
       ,[SitusDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDPCheckDigit]))
       ,[SitusDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusDPCheckCode]))
       ,[SitusCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusCensusBlock]))
       ,[SitusGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusGeoErrorCode]))
       ,[SitusGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusGeoStatusCode]))
       ,[SitusGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Release_Situs_STD].[SitusGeoCodeResults]))
     From [AddressSTD].[dbo].[Release_Situs_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Release_Situs_to_Licensing
