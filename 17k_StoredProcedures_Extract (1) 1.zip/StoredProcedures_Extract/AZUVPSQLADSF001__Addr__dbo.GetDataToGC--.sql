SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[GetDataToGC--] @fips int
as 
insert ClAddrGC ( 
		[AddrID]
      ,[STD_Zip]
      ,[STD_Plus4]
      ,[DeliveryPointCode])
SELECT  [AddrID]
      ,[STD_Zip]
      ,[STD_Plus4]
      ,[DeliveryPointCode]
  FROM [Addr].[dbo].[CL_Address_Base] with (nolock)
  where fips = @fips and DeliveryPointCode is not null and len(RTRIM(DeliveryPointCode)) > 0


