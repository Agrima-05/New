SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[Match_Prop_Address]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @Zip varchar(5)

truncate table [xBRice].[dbo].[addrs_20250613]


INSERT INTO [xBRice].[dbo].[addrs_20250613]
           ([pid]
           ,[house_number]
           ,[street_direction]
           ,[street_name]
           ,[street_type]
           ,[street_post_direction]
           ,[unit_type]
           ,[unit_number]
           ,[city]
           ,[state]
           ,[zip]
           ,[zip4]
           ,[is_deliverable]
           ,[first_reported]
           ,[last_reported]
           ,[rank]
           ,[FullAddress]
           ,[AddressID]
           ,[addresskey]
           ,[AddressKeyNoUnitType]
           ,[AddressKeyNoUnitTypeNoPlus4])
Select      [pid]
           ,[house_number]
           ,[street_direction]
           ,[street_name]
           ,[street_type]
           ,[street_post_direction]
           ,[unit_type]
           ,[unit_number]
           ,[city]
           ,[state]
           ,[zip]
           ,[zip4]
           ,[is_deliverable]
           ,[first_reported]
           ,[last_reported]
           ,[rank]
           ,[FullAddress]
           ,[AddressID]
           ,Replicate('0',5-len(ltrim(rtrim([zip])))) + [zip] +
	        Replicate('0',4-len(ltrim(rtrim([zip4])))) + [zip4] +
	        Replicate('0',2-len(ltrim(rtrim([street_direction])))) + [street_direction] +
	        Replicate('0',30-len(ltrim(rtrim([street_name])))) + [street_name] +
	        Replicate('0',2-len(ltrim(rtrim([street_post_direction])))) + [street_post_direction] +
	        Replicate('0',4-len(ltrim(rtrim([street_type])))) + [street_type] +
	        Replicate('0',10-len(ltrim(rtrim([house_number])))) + [house_number] +
	        Replicate('0',6-len(ltrim(rtrim([unit_type])))) + [unit_type] +
	        Replicate('0',8-len(ltrim(rtrim([unit_number])))) + [unit_number] as [addresskey]
           ,Replicate('0',5-len(ltrim(rtrim([zip])))) + [zip] +
	        Replicate('0',4-len(ltrim(rtrim([zip4])))) + [zip4] +
	        Replicate('0',2-len(ltrim(rtrim([street_direction])))) + [street_direction] +
	        Replicate('0',30-len(ltrim(rtrim([street_name])))) + [street_name] +
	        Replicate('0',2-len(ltrim(rtrim([street_post_direction])))) + [street_post_direction] +
	        Replicate('0',4-len(ltrim(rtrim([street_type])))) + [street_type] +
	        Replicate('0',10-len(ltrim(rtrim([house_number])))) + [house_number] +
	        Replicate('0',8-len(ltrim(rtrim([unit_number])))) + [unit_number] as [AddressKeyNoUnitType]
           ,Replicate('0',5-len(ltrim(rtrim([zip])))) + [zip] +
	        Replicate('0',2-len(ltrim(rtrim([street_direction])))) + [street_direction] +
	        Replicate('0',30-len(ltrim(rtrim([street_name])))) + [street_name] +
	        Replicate('0',2-len(ltrim(rtrim([street_post_direction])))) + [street_post_direction] +
	        Replicate('0',4-len(ltrim(rtrim([street_type])))) + [street_type] +
	        Replicate('0',10-len(ltrim(rtrim([house_number])))) + [house_number] +
	        Replicate('0',8-len(ltrim(rtrim([unit_number])))) + [unit_number] as [AddressKeyNoUnitTypeNoPlus4]
from [Enformion].[dbo].[addrs_20250613]
where zip = @zip

-----  Match Address
 update xBRice..[addrs_20250613]
  Set Propertyid = b.propertyid
  from xBRice..[addrs_20250613] a
  join xBRice..Prop_Address b
  on a.[addresskey] = b.[addresskey]
  where a.propertyid is null

  update xBRice..[addrs_20250613]
  Set Propertyid = b.propertyid
  from xBRice..[addrs_20250613] a
  join xBRice..Prop_Address b
  on a.[AddressKeyNoUnitType] = b.[AddressKeyNoUnitType]
  where a.propertyid is null

  update xBRice..[addrs_20250613]
  Set Propertyid = b.propertyid
  from xBRice..[addrs_20250613] a
  join xBRice..Prop_Address b
  on a.[AddressKeyNoUnitTypeNoPlus4] = b.[AddressKeyNoUnitTypeNoPlus4]
  where a.propertyid is null

  -----  Get Name for PID
  	update [xBRice].[dbo].[addrs_20250613]
	set [firstname] = b.[firstname]
	,[middlename] = b.[middlename]
	,[lastname] = b.[lastname]
	,[suffix] = b.[suffix]
	,[deceased] = b.[deceased]
	,[age] = b.[age]
from [xBRice].[dbo].[addrs_20250613] a
join [Enformion].[dbo].[person] b
on b.pid = a.pid
where a.[lastname] is null

-----  Match Names
----  Owner 1
Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME1FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME1FULLPID] is null
  and ((substring(replace(OwnerStd1LastName,' ',''),1,4) + substring(replace(OwnerStd1MiddleName,' ',''),1,1) + substring(replace(OwnerStd1FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd1FirstName,' ',''),1,4) + substring(replace(OwnerStd1MiddleName,' ',''),1,1) + substring(replace(OwnerStd1LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4)))

Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME1FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME1FULLPID] is null
  and ((substring(replace(OwnerStd1LastName,' ',''),1,4) + substring(replace(OwnerStd1FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd1FirstName,' ',''),1,4) + substring(replace(OwnerStd1LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4)))

---  Owner 2
Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME2FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME2FULLPID] is null
  and ((substring(replace(OwnerStd2LastName,' ',''),1,4) + substring(replace(OwnerStd2MiddleName,' ',''),1,1) + substring(replace(OwnerStd2FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd2FirstName,' ',''),1,4) + substring(replace(OwnerStd2MiddleName,' ',''),1,1) + substring(replace(OwnerStd2LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4)))

Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME2FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME2FULLPID] is null
  and ((substring(replace(OwnerStd2LastName,' ',''),1,4) + substring(replace(OwnerStd2FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd2FirstName,' ',''),1,4) + substring(replace(OwnerStd2LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4)))

---  Owner 3
Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME3FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME3FULLPID] is null
  and ((substring(replace(OwnerStd3LastName,' ',''),1,4) + substring(replace(OwnerStd3MiddleName,' ',''),1,1) + substring(replace(OwnerStd3FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd3FirstName,' ',''),1,4) + substring(replace(OwnerStd3MiddleName,' ',''),1,1) + substring(replace(OwnerStd3LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4)))

Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME3FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME3FULLPID] is null
  and ((substring(replace(OwnerStd3LastName,' ',''),1,4) + substring(replace(OwnerStd3FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd3FirstName,' ',''),1,4) + substring(replace(OwnerStd3LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4)))		

---  Owner 4
Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME4FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME4FULLPID] is null
  and ((substring(replace(OwnerStd4LastName,' ',''),1,4) + substring(replace(OwnerStd4MiddleName,' ',''),1,1) + substring(replace(OwnerStd4FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd4FirstName,' ',''),1,4) + substring(replace(OwnerStd4MiddleName,' ',''),1,1) + substring(replace(OwnerStd4LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([middlename],' ',''),1,1) + substring(replace([firstname],' ',''),1,4)))

Update [xBRice].[dbo].[Prop_Address]
  Set [OwnerStdNAME4FULLPID] = [PID]
  from [xBRice].[dbo].[Prop_Address] a
  join [xBRice].[dbo].[addrs_20250613] b
  on b.propertyid = a.propertyid
  where [OwnerStdNAME4FULLPID] is null
  and ((substring(replace(OwnerStd4LastName,' ',''),1,4) + substring(replace(OwnerStd4FirstName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4))
     or (substring(replace(OwnerStd4FirstName,' ',''),1,4) + substring(replace(OwnerStd4LastName,' ',''),1,4)
        = substring(replace([lastname],' ',''),1,4) + substring(replace([firstname],' ',''),1,4)))

 
END

