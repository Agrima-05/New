SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON







--   exec [dbo].[p_util_dba_GetFreeDiskSpace_each_server]






CREATE  PROCEDURE   [dbo].[p_util_dba_GetFreeDiskSpace_each_server]

AS
/*******************************************************************************************
Author:              Thomas Lee 
Modified by:         Arun Agunuru                                            

Description:
Used to get disk and MountPoint available free disk space and to send a DAILY ALERT e-mail starting at
85% full: only 15% free disk space remaining.  

       Modified By:  Date          Description


********************************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON

declare @svrName varchar(255)
declare @sql varchar(400)


exec sp_configure 'xp_cmdshell',1
reconfigure with override

--creating a temporary tables
Truncate table  DBA_StorageMonitor.dbo.t_util_DbFileStats ;
CREATE TABLE #t_util_DbFileStats(
[Servername] Varchar (150) Null,
       [Drive] [varchar](50) NULL,
	   [LabelName] [varchar](50) NULL,
       [Free Disk Space (GB)] [int] NULL,
       [TotalDisk Space (GB)] [int] NULL,
       [PercentUsed] decimal (10,2) NULL,
       [PercentFree] decimal (10,2) NULL,
       [LoadDateandTime] [datetime] NOT NULL
) 

CREATE TABLE #output

(line varchar(255))


--by default it will take the current server name, we can the set the server name as well
set @svrName = @@SERVERNAME

set @sql = 'powershell.exe -c "Get-WmiObject -Class Win32_Volume -Filter ''DriveType = 3'' | select name,Label,capacity,freespace | foreach{$_.name+''|''+$_.Label+''~''+$_.capacity/1048576+''@''+$_.freespace/1048576+''*''}"'

 

--inserting disk name, total space and free space value in to temporary table

 

insert #output
EXEC xp_cmdshell @sql

 

--select * from #output
--drop table #output
--drop table #t_util_DbFileStats
--script to retrieve the values in GB from PS Script output

 

select *, CAST([Free Disk Space (GB)]/[TotalDisk Space (GB)] * 100.0 as decimal(10,2)) as PercentFreeSpace  INTO #DiskStats
from(
select LEFT(@@SERVERNAME,15) as Servername
,rtrim(ltrim(SUBSTRING(line,1,CHARINDEX('|',line) -1))) as drive
,rtrim(ltrim(SUBSTRING(line,CHARINDEX('|',line)+1,CHARINDEX('~',line)-CHARINDEX('|',line)-1))) as Label
,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('~',line)+1,CHARINDEX('@',line)-CHARINDEX('~',line)-1))) as float)/1024,0) as 'TotalDisk Space (GB)'
,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('@',line)+1,CHARINDEX('*',line)-CHARINDEX('@',line)-1))) as float)/1024,0)  as 'Free Disk Space (GB)'

from #output
where line like '[A-Z][:]%') a
order by drive

DELETE #DiskStats
where [TotalDisk Space (GB)] = 0

INSERT #t_util_DbFileStats
( [Servername]
      ,[drive]
	  ,[LabelName]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,[LoadDateandTime]
)
SELECT @svrName,  drive ,Label,  [Free Disk Space (GB)],[TotalDisk Space (GB)]
,( 1 - [Free Disk Space (GB)]/[TotalDisk Space (GB)]) * 100 as 'PercentUsed'
,([Free Disk Space (GB)]/[TotalDisk Space (GB)]) * 100 as 'PercentFree'
, GETDATE() as LoadDateandTime
FROM #DiskStats
order by drive

INSERT DBA_StorageMonitor.dbo.t_util_DbFileStats
(      [ServerName]
      ,[drive]
	  ,[LabelName]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,[LoadDateandTime]
)
SELECT [ServerName]
      ,[drive]
	  ,[LabelName]
      ,[Free Disk Space (GB)]
      ,[TotalDisk Space (GB)]
      ,[PercentUsed]
      ,[PercentFree]
      ,convert (date, [LoadDateandTime] , 107) as [LoadDateandTime]

FROM #t_util_DbFileStats
where 
( [TotalDisk Space (GB)] <= 1024 and [PercentFree] < 10) or 
( [TotalDisk Space (GB)] between 1024  and 2048 and PercentFree <= 20 and [Free Disk Space (GB)] <= 300) or
( [TotalDisk Space (GB)] between 2048  and 4096 and PercentFree <= 20 and [Free Disk Space (GB)] <= 750) or
( [TotalDisk Space (GB)] between 4097  and 10240 and PercentFree <= 20 and [Free Disk Space (GB)] <= 1024) or
( [TotalDisk Space (GB)] between 10240  and 51200 and PercentFree <= 10 and [Free Disk Space (GB)] <= 1024)

--select * from DBA_StorageMonitor.dbo.t_util_DbFileStats 

--Truncate table  DBA_StorageMonitor.dbo.t_util_DbFileStats 
drop table #output
drop table #DiskStats

THEEND:
RETURN 0


