SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[usp_010_Tax_Update_Process]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @TimeStamp as varchar(10) = Convert(varchar(10),Getdate()+1,120)
	Declare @DateRun as Date
		Select @DateRun = LastDateRun From dbo.LastDateRun

	--PRINT @DateRun

			--Select a.FIPS,a.PropertyID,b.REF_ID,FALoadDate,a.TaxAmount,DBSTaxAmount, Convert(bigint,(b.TAX_AMOUNT*100))
			--,a.TaxYear,DBSTaxYear, b.TAX_YEAR,FALoadDate
			-- from data.dbo.Property a with(NOLOCK) JOIN DragonAssr.dbo.Dragon_Flank b
			--on a.Fips = b.FipsCode
			--and a.DTDB_REF_ID = b.REF_ID
			--Where  ((TaxYear < TAX_YEAR and isNULL(Tax_Amount,0)>0)
			--		or (TaxAmount is NULL and isNULL(Tax_Amount,0)>0))
			--	and FALoadDate >= @DateRun

			--Select b.FAUserID 
			--,[TaxDeliquentYear1], [DELINQUENT_TAX_YEAR]
			--,[TaxDeliquentValue1], Convert(int,([DELINQUENT_TAX_VALUE]*100))
			--From DragonAssr.dbo.Dragon_Flank a JOIN Data.dbo.Property b 
			--on a.FipsCode = b.fips and a.PropertyID = b.PropertyID
			--Where ([DELINQUENT_TAX_YEAR] is not null and [DELINQUENT_TAX_VALUE] is not null)
			--and ([TaxDeliquentYear1] is NULL 
			--	or [TaxDeliquentYear1] < [DELINQUENT_TAX_YEAR] 
			--		or ([TaxDeliquentValue1] is NULL and [DELINQUENT_TAX_VALUE] is not null) 
			--			OR ([TaxDeliquentValue1]<>[DELINQUENT_TAX_VALUE]))
			--	and FALoadDate >= @DateRun


			UPDATE b
			SET b.FAUserID = 'DRAGON DelTax Update'
			,[TaxDeliquentYear1] = [DELINQUENT_TAX_YEAR]
			,[TaxDeliquentValue1] = ([DELINQUENT_TAX_VALUE]*100)
			,FATimestamp = @TimeStamp
			From DragonAssr.dbo.Dragon_Flank a JOIN Data.dbo.Property b 
			on a.FipsCode = b.fips and a.PropertyID = b.PropertyID
			Where ([DELINQUENT_TAX_YEAR] is not null and [DELINQUENT_TAX_VALUE] is not null)
			and ([TaxDeliquentYear1] is NULL 
				or [TaxDeliquentYear1] < [DELINQUENT_TAX_YEAR] 
					or ([TaxDeliquentValue1] is NULL and [DELINQUENT_TAX_VALUE] is not null) 
						OR ([TaxDeliquentValue1]<>[DELINQUENT_TAX_VALUE]))
				and FALoadDate >= @DateRun
				--and ([DELINQUENT_TAX_VALUE]*100) > 100000000
			


			UPDATE a
			SET a.TaxAmount = Convert(bigint,(b.TAX_AMOUNT*100))
			,a.TaxYear = b.TAX_YEAR
			,FATimestamp = @TimeStamp
			,FAUserID = 'Dragon Tax Update'
			,a.[TaxSourceInd] = 'D'
			--Select Count(*)
			 from data.dbo.Property a with(NOLOCK) JOIN DragonAssr.dbo.Dragon_Flank b
			on a.Fips = b.FipsCode
			and a.DTDB_REF_ID = b.REF_ID
			Where ((TaxYear < TAX_YEAR and isNULL(Tax_Amount,0)>0)
					or (TaxAmount is NULL and isNULL(Tax_Amount,0)>0))
				and FALoadDate >= @DateRun


				DROP TABLE DragonAssr.dbo.LastDateRun
				Select Convert(DATE,GETDATE(),120) as LastDateRun INTO DragonAssr.dbo.LastDateRun 


END

