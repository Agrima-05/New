SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[999_DigitalMap_zLoadData] @fips varchar(5)
AS
BEGIN
	SET NOCOUNT OFF;

INSERT INTO [DigitalMap].[dbo].[FADigitalMap]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InHJ2])
 
 Select    [FADigitalMapMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InHJ2]
from [DigitalMap].[dbo].[FADigitalMap_Update_20220531]
where fips = @fips
and propertyid is not null
and isdup is null

-----

INSERT INTO [DigitalMap].[dbo].[FADigitalMap_Update_20220531_FipsRun]
           ([FIPS],[Run])
 Select @Fips, '1'




END


