SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[ImportMatchListings_20190602] @PartitionCount INT
AS
--SSMSBOOST UNBLOCK
SET XACT_ABORT ON
SET NOCOUNT ON

DECLARE @Timestamp VARCHAR(25)

SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Set Rental_Ind'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT


---- we can remove this since we dont test againt this anymore
--SELECT DISTINCT Row_Id
--INTO #HasRentalType
--FROM tmp.Features
--WHERE FeatureValueId IN (
--		SELECT Id
--		FROM FeatureValues v
--		WHERE FeatureValueGroupId IN (
--				6
--				,7
--				)
--			AND Value NOT IN (
--				'MOBILE HOME PARK'
--				,'TIME SHARE'
--				)
		
--		UNION
		
--		SELECT Id
--		FROM FeatureValues
--		WHERE FeatureTypeId = 27
--			AND (
--				--Value LIKE '%RENTAL%'
--				--OR 
--				Value LIKE '%INCOME%'
--				OR Value LIKE '%INVESTMENT%'
--				)
--		)

--ALTER TABLE #HasRentalType ADD PRIMARY KEY (Row_Id)

--SELECT DISTINCT Row_Id
--INTO #HasLotType
--FROM tmp.Features
--WHERE FeatureValueId IN (
--		SELECT Id
--		FROM FeatureValues
--		WHERE FeatureValueGroupId = 9
--		)

--ALTER TABLE #HasLotType ADD PRIMARY KEY (Row_Id)

--SELECT DISTINCT Row_Id
--INTO #HasAssrLandUse
--FROM tmp.Features
--WHERE FeatureValueId IN (
--		SELECT fv.Id
--		--,fv.FeatureTypeId 	,fv.Value	,fv.Code	,fv.DoNotDisplay	,fv.NullValue	,fv.FeatureValueGroupId
--		FROM FA_Listing.dbo.FeatureValues fv
--		WHERE FeatureTypeId IN (
--				27
--				,28
--				)
--			AND code IN (
--				400 --  	VACANT LAND (NEC) 
--				,401 -- 	MARSHLAND 
--				,420 -- 	COMMERCIAL LOT 
--				,430 -- 	AGRICULTURAL LAND 
--				,456 -- 	RESIDENTIAL LOT 
--				,480 -- 	WASTE LAND 
--				)
--		)

--ALTER TABLE #HasAssrLandUse ADD PRIMARY KEY (Row_Id)

--UPDATE m
--SET Rental_Ind = CASE 
--		WHEN f.Row_id IS NOT NULL --- we found a Rental feature for the property
--			OR (
--				lt.Row_Id IS NULL
--				AND lu.Row_id IS NULL --HasAssrLandUse IS NULL
--				AND (
--					(
--						MLS_STATUS LIKE '%RENTED-LEASED%'
--						OR MLS_STATUS LIKE '%FOR RENT%'
--						)
--					OR (
--						CASE 
--							WHEN MLS_STATUS_STD = 'SOLD'
--								THEN SOLD_PRICE_STD
--							ELSE MLS_LIST_PRICE_STD
--							END BETWEEN 1
--							AND 5000
--						AND (
--							HasRentalHoa IS NOT NULL
--							OR rt.Row_Id IS NOT NULL ---- we should remove this since it is take care of the other side of the or statement
--							)
--						)
--					)
--				)
--			THEN 1
--		ELSE 0
--		END
--FROM tmp.FA_MLS m
--LEFT JOIN tmp.Features f WITH (FORCESEEK) ON m.Row_id = f.row_id
--	AND f.value LIKE '%Rental%'
--	AND f.FeatureTypeId IN (
--		27
--		,28
--		) -- I see we have an index on these values  -- should we do a forceseek
--LEFT JOIN #HasRentalType rt WITH (FORCESEEK) ON m.Row_Id = rt.Row_Id -- not needed anymore 
--LEFT JOIN #HasLotType lt WITH (FORCESEEK) ON m.Row_Id = lt.Row_Id
--LEFT JOIN #HasAssrLandUse lu WITH (FORCESEEK) ON m.Row_Id = lu.Row_Id


------ New rental logic --- 11/2/2018



SELECT Row_id
  into #HasRental  
FROM [FA_Listing].[tmp].[FA_MLS]f
LEFT JOIN    FA_Listing.dbo.[MedianSalePrice_Rolling6Month] z ON left(f.zip, 5) = z.situszip
      WHERE  z.rolling_6_months = '2018-05' and
( MLS_STATUS_STD in ('active','pending','contingent') or  MLS_STATUS_STD LIKE '%RENT%'  or MLS_STATUS_STD like'%active%') AND ---- change to use MLS_Status_STD 11/9/2018
left(f.zip, 5) not in ( '35133', '65360', '65265', '27932') and
	   ( f.PROPERTY_SUB_TYPE NOT IN (
              'Vacant Land'
              ,'Lots And Land'
              ,'Lot'
              ,'Residential - Vacant Land'
              ,'Industrial - Vacant Land'
              ,'Commercial - Vacant Land'
              ) or f.PROPERTY_SUB_TYPE is null)
			AND 
			((f.property_type  not like 'lot%'
			and f.property_type not like 'vacant%'
			and f.property_type not like 'Mobile%'
			and f.Property_type not like 'Manufactured%'
			and f.Property_type not like 'Boat%'
			and  f.property_type not like '40 - Res-Less%'
			and  f.property_type not like '(Manufactured%'
			and  f.property_type not like '(Lot%'
			and  f.property_type not like '1 - 10 Acres%'
			and  f.property_type not like 'Land%'
			and  f.property_type not like 'Residential Lot%'
			and  f.property_type not like 'Residential Mobile%'
			and  f.property_type not like 'Residential (Manufactured%'
			and  f.property_type not like '%Time%'
			and  f.property_type not like '%Share%'
			and  f.property_type not like 'undeveloped land%'
			and  f.Property_type not like 'share%'
			and  f.Property_type not like 'Residential - Mobile Home%'
			and  f.property_type not like 'Parking%'
			and  f.property_type not like 'other Residential land%'
			and  f.property_type not like 'MFD'
			and  f.property_type not like 'LND%'
			and  f.property_type not like 'Farm%'
			and  f.property_type not like 'Agricultural%'
			and  f.property_type not like 'Acreage%'
			and  f.property_type not like '21 - %'
			and  f.property_type not like 'Garage%') or f.property_type is null)
    
          AND (
              (
                     --fa.MLS_STATUS LIKE '%RENTED-LEASED%' or
                      MLS_STATUS_STD LIKE '%RENT%'
                     )
             
    
	  
				or (
				      CASE 
			             WHEN MLS_STATUS_STD = 'SOLD'
                           THEN (
                                         NULLIF(CASE 
                                                       WHEN ISNUMERIC(f.SOLD_PRICE_STD) = 1
                                                              THEN ROUND(CAST(f.SOLD_PRICE_STD AS DECIMAL(15, 2)), 0)
                                                       END, 0)
                                         )
                     ELSE (
                                  NULLIF(CASE 
                                                WHEN ISNUMERIC(f.MLS_LIST_PRICE_STD) = 1
                                                       THEN ROUND(CAST(f.MLS_LIST_PRICE_STD AS DECIMAL(15, 2)), 0)
                                                END, 0)
                                  )
                     END < ( case when  z.medSalePrice >= 500000 then (z.medSalePrice* 0.05) else z.medSalePrice*0.01 end)
              )
)



UPDATE m
SET Rental_Ind = CASE 
		WHEN rt.Row_id is not null
			THEN 1
		ELSE 0
		END

FROM tmp.FA_MLS m
LEFT JOIN #HasRental rt  ON m.Row_Id = rt.Row_Id 


---------------------------------



SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Target Match'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 1
FROM tmp.FA_MLS a
INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID
	AND (a.MLS_Listing_Number = b.MLS_Listing_Number
	or (len(a.MLS_Listing_Number)<20 and len(b.MLS_Listing_Number)<20 and
	SPDB.dbo.RemoveSpecialChars(SPDB.dbo.RemoveAlphaChars(a.MLS_Listing_Number))=
	SPDB.dbo.RemoveSpecialChars(SPDB.dbo.RemoveAlphaChars(b.MLS_Listing_Number))))
	AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 2
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.[State] = b.[State]
		AND a.MLS_Listing_Number = b.MLS_Listing_Number
		AND a.Rental_Ind = b.Rental_Ind
		AND (
			a.REF_ID IS NULL
			OR b.REF_ID IS NULL
			)
		AND (
			a.Fips = b.Fips
			OR a.ZIP = b.ZIP
			OR a.MLS_AREA = (
				SELECT MLS_AREA
				FROM ListingFeaturesPivot lfp
				WHERE lfp.Listing_ID = b.Listing_ID
				)
			OR a.COUNTY_NAME = b.COUNTY_NAME
			)
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON
--	a.[State] = b.[State]
--	AND a.MLS_Listing_Number = b.MLS_Listing_Number
--	AND a.Rental_Ind = b.Rental_Ind
--	AND (a.REF_ID IS NULL OR b.REF_ID IS NULL)
--	AND (
--		a.Fips = b.Fips
--		OR a.ZIP = b.ZIP
--		OR a.MLS_AREA = (SELECT MLS_AREA FROM ListingFeaturesPivot lfp WHERE lfp.Listing_ID = b.Listing_ID)
--		OR a.COUNTY_NAME = b.COUNTY_NAME
--	)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 3
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD = 'Sold'
		AND b.MLS_STATUS_STD = 'Sold'
		AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
		AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 180
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD))
		,ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD = 'Sold' AND b.MLS_STATUS_STD = 'Sold' AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 180 AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL) AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 4
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_LIST_DATE_STD = b.MLS_LIST_DATE_STD
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_LIST_DATE_STD = b.MLS_LIST_DATE_STD AND a.Rental_Ind = b.Rental_Ind AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 5
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.SOLD_DATE_STD = b.SOLD_DATE_STD
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.SOLD_DATE_STD = b.SOLD_DATE_STD AND a.Rental_Ind = b.Rental_Ind AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 6
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD = 'Sold'
		AND b.MLS_STATUS_STD <> 'Sold'
		AND DATEDIFF(DAY, b.MLS_LIST_DATE_STD, a.SOLD_DATE_STD) BETWEEN 0
			AND 365
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY DATEDIFF(DAY, b.MLS_LIST_DATE_STD, a.SOLD_DATE_STD)
		,ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD = 'Sold' AND b.MLS_STATUS_STD <> 'Sold' AND DATEDIFF(DAY, b.MLS_LIST_DATE_STD, a.SOLD_DATE_STD) BETWEEN 0 AND 365 AND a.Rental_Ind = b.Rental_Ind AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 7
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD <> 'Sold'
		AND b.MLS_STATUS_STD = 'Sold'
		AND DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.SOLD_DATE_STD) BETWEEN 0
			AND 365
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.SOLD_DATE_STD)
		,ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD <> 'Sold' AND b.MLS_STATUS_STD = 'Sold' AND DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.SOLD_DATE_STD) BETWEEN 0 AND 365 AND a.Rental_Ind = b.Rental_Ind AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 8
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD <> 'Sold'
		AND b.MLS_STATUS_STD <> 'Sold'
		AND (
			a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
			OR (
				a.MLS_LIST_PRICE_STD IS NULL
				AND b.MLS_LIST_PRICE_STD IS NULL
				)
			)
		AND ABS(DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.MLS_LIST_DATE_STD)) <= 90
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.MLS_LIST_DATE_STD))
		,ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD <> 'Sold' AND b.MLS_STATUS_STD <> 'Sold' AND (a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD OR (a.MLS_LIST_PRICE_STD IS NULL AND b.MLS_LIST_PRICE_STD IS NULL)) AND ABS(DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.MLS_LIST_DATE_STD)) <= 90 AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL) AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 9
FROM tmp.FA_MLS a
INNER JOIN PropertyToListing p ON a.Property_ID = p.Property_ID
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE p.Listing_ID = b.Listing_ID
		AND (
			a.REF_ID IS NULL
			AND b.REF_ID IS NULL
			)
		AND (
			a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON p.Listing_ID = b.Listing_ID AND a.Rental_Ind = b.Rental_Ind AND (a.MLS_Listing_Number IS NULL AND b.MLS_Listing_Number IS NULL) AND (a.REF_ID IS NULL AND b.REF_ID IS NULL)
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 10
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	LEFT JOIN ListingChange h WITH (FORCESEEK) ON b.Listing_ID = h.Listing_ID
		AND h.FieldId = 2
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD <> 'Sold'
		AND b.MLS_STATUS_STD <> 'Sold'
		AND (
			a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
			OR a.MLS_LIST_PRICE_STD = CONVERT(NUMERIC(15, 2), h.Value)
			)
		AND (
			a.MLS_LIST_DATE_STD IS NULL
			OR b.MLS_LIST_DATE_STD IS NULL
			)
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD <> 'Sold' AND b.MLS_STATUS_STD <> 'Sold' AND a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD AND a.MLS_LIST_DATE_STD IS NULL AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL) AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 11
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	LEFT JOIN ListingChange h WITH (FORCESEEK) ON b.Listing_ID = h.Listing_ID
		AND h.FieldId = 3
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD = 'Sold'
		AND b.MLS_STATUS_STD = 'Sold'
		AND (
			a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
			OR a.SOLD_PRICE_STD = CONVERT(NUMERIC(15, 2), h.Value)
			)
		AND (
			a.SOLD_DATE_STD IS NULL
			OR b.SOLD_DATE_STD IS NULL
			)
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD = 'Sold' AND b.MLS_STATUS_STD = 'Sold' AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD AND (a.SOLD_DATE_STD IS NULL OR b.SOLD_DATE_STD IS NULL) AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL) AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

UPDATE a
SET TargetMatchId = b.Listing_ID
	,MatchTypeId = 12
FROM tmp.FA_MLS a
CROSS APPLY (
	SELECT TOP 1 b.Listing_ID
	FROM Listing b
	WHERE a.REF_ID = b.REF_ID
		AND a.MLS_STATUS_STD = 'Sold'
		AND b.MLS_STATUS_STD = 'Sold'
		AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 45
		AND (
			a.MLS_Listing_Number IS NULL
			OR b.MLS_Listing_Number IS NULL
			)
		AND a.Rental_Ind = b.Rental_Ind
	ORDER BY ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD))
		,ABS(DATEDIFF(DAY, a.UPDATE_FLAG_DATE_STD, b.UPDATE_FLAG_DATE_STD))
		,b.LastRow_Id DESC
	) b
--INNER JOIN Listing b WITH (FORCESEEK) ON a.REF_ID = b.REF_ID AND a.MLS_STATUS_STD = 'Sold' AND b.MLS_STATUS_STD = 'Sold' AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 45 AND (a.MLS_Listing_Number IS NULL OR b.MLS_Listing_Number IS NULL) AND a.Rental_Ind = b.Rental_Ind
WHERE TargetMatchId IS NULL

--MERGE tmp.TargetMatch a
--USING (
--	SELECT Row_Id, TargetMatchId, MatchTypeId
--	FROM tmp.FA_MLS
--	WHERE TargetMatchId IS NOT NULL
--) b
--ON (a.Row_Id = b.Row_Id)
--WHEN NOT MATCHED BY TARGET
--	THEN INSERT(
--		Row_Id
--		,TargetMatchId
--		,MatchTypeId
--	)
--	VALUES (
--		Row_Id
--		,TargetMatchId
--		,MatchTypeId
--	)
--WHEN MATCHED
--	THEN UPDATE SET
--		a.TargetMatchId = b.TargetMatchId
--		,a.MatchTypeId = b.MatchTypeId
--;
SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Self Match'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

CREATE TABLE #SelfMatchFull (
	Id INT IDENTITY(1, 1) PRIMARY KEY
	,Parent INT
	,Child INT
	,MatchTypeId TINYINT
	)

INSERT INTO #SelfMatchFull
SELECT a.Row_Id
	,b.Row_Id
	,30
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.TargetMatchId = b.TargetMatchId
	AND a.Rental_Ind = b.Rental_Ind

UNION

SELECT a.Row_Id
	,b.Row_Id
	,31
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_Listing_Number = b.MLS_Listing_Number
	AND a.Rental_Ind = b.Rental_Ind

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,32 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.[State] = b.[State]
	AND a.MLS_Listing_Number = b.MLS_Listing_Number
	AND a.REF_ID IS NULL
	AND b.REF_ID IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL
	AND (
		a.Fips = b.Fips
		OR a.ZIP = b.ZIP
		OR a.MLS_AREA = b.MLS_AREA
		OR a.COUNTY_NAME = b.COUNTY_NAME
		)

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,33 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD = 'Sold'
	AND b.MLS_STATUS_STD = 'Sold'
	AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
	AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 180
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,34 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_LIST_DATE_STD = b.MLS_LIST_DATE_STD
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,35 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.SOLD_DATE_STD = b.SOLD_DATE_STD
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,36 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD = 'Sold'
	AND b.MLS_STATUS_STD <> 'Sold'
	AND DATEDIFF(DAY, b.MLS_LIST_DATE_STD, a.SOLD_DATE_STD) BETWEEN 0
		AND 365
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,37 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD <> 'Sold'
	AND b.MLS_STATUS_STD = 'Sold'
	AND DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.SOLD_DATE_STD) BETWEEN 0
		AND 365
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,38 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD <> 'Sold'
	AND b.MLS_STATUS_STD <> 'Sold'
	AND (
		a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
		OR (
			a.MLS_LIST_PRICE_STD IS NULL
			AND b.MLS_LIST_PRICE_STD IS NULL
			)
		)
	AND ABS(DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.MLS_LIST_DATE_STD)) <= 90
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id
	,b.Row_Id
	,39
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.Property_ID = b.Property_ID
	AND a.Rental_Ind = b.Rental_Ind
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.REF_ID IS NULL
	AND b.REF_ID IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,40 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD <> 'Sold'
	AND b.MLS_STATUS_STD <> 'Sold'
	AND a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
	AND a.MLS_LIST_DATE_STD IS NULL
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,41 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD = 'Sold'
	AND b.MLS_STATUS_STD = 'Sold'
	AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
	AND a.SOLD_DATE_STD IS NULL
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT a.Row_Id AS Parent
	,b.Row_Id AS Child
	,42 AS MatchTypeId
FROM tmp.FA_MLS a
INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
	AND a.REF_ID = b.REF_ID
	AND a.MLS_STATUS_STD = 'Sold'
	AND b.MLS_STATUS_STD = 'Sold'
	AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 45
	AND a.MLS_Listing_Number IS NULL
	AND b.MLS_Listing_Number IS NULL
	AND a.Rental_Ind = b.Rental_Ind
	AND a.TargetMatchId IS NULL

UNION

SELECT Parent
	,Child
	,MatchTypeId
FROM (
	SELECT *
		,ROW_NUMBER() OVER (
			PARTITION BY Parent ORDER BY ABS(DATEDIFF(DAY, SOLD_DATE_STD_From, SOLD_DATE_STD_To))
				,ABS(DATEDIFF(DAY, MLS_LIST_DATE_STD_From, MLS_LIST_DATE_STD_To))
				,ABS(DATEDIFF(DAY, MLS_LIST_DATE_STD_From, SOLD_DATE_STD_To))
				,ABS(DATEDIFF(DAY, MLS_LIST_DATE_STD_To, SOLD_DATE_STD_From))
				,ABS(DATEDIFF(DAY, UPDATE_FLAG_DATE_STD_From, UPDATE_FLAG_DATE_STD_To))
				,MatchTypeId
				,Child
			) AS RowNum
	FROM (
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD AS UPDATE_FLAG_DATE_STD_From
			,b.UPDATE_FLAG_DATE_STD AS UPDATE_FLAG_DATE_STD_To
			,a.MLS_LIST_DATE_STD AS MLS_LIST_DATE_STD_From
			,b.MLS_LIST_DATE_STD AS MLS_LIST_DATE_STD_To
			,a.SOLD_DATE_STD AS SOLD_DATE_STD_From
			,b.SOLD_DATE_STD AS SOLD_DATE_STD_To
			,32 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.[State] = b.[State]
			AND a.MLS_Listing_Number = b.MLS_Listing_Number
			AND a.REF_ID IS NULL
			AND b.REF_ID IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
			AND (
				a.Fips = b.Fips
				OR a.ZIP = b.ZIP
				OR a.MLS_AREA = b.MLS_AREA
				OR a.COUNTY_NAME = b.COUNTY_NAME
				)
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,33 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD = 'Sold'
			AND b.MLS_STATUS_STD = 'Sold'
			AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
			AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 180
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,34 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_LIST_DATE_STD = b.MLS_LIST_DATE_STD
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,35 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.SOLD_DATE_STD = b.SOLD_DATE_STD
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,36 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD = 'Sold'
			AND b.MLS_STATUS_STD <> 'Sold'
			AND DATEDIFF(DAY, b.MLS_LIST_DATE_STD, a.SOLD_DATE_STD) BETWEEN 0
				AND 365
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,37 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD <> 'Sold'
			AND b.MLS_STATUS_STD = 'Sold'
			AND DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.SOLD_DATE_STD) BETWEEN 0
				AND 365
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,38 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD <> 'Sold'
			AND b.MLS_STATUS_STD <> 'Sold'
			AND (
				a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
				OR (
					a.MLS_LIST_PRICE_STD IS NULL
					AND b.MLS_LIST_PRICE_STD IS NULL
					)
				)
			AND ABS(DATEDIFF(DAY, a.MLS_LIST_DATE_STD, b.MLS_LIST_DATE_STD)) <= 90
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,40 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD <> 'Sold'
			AND b.MLS_STATUS_STD <> 'Sold'
			AND a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
			AND a.MLS_LIST_DATE_STD IS NULL
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,41 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD = 'Sold'
			AND b.MLS_STATUS_STD = 'Sold'
			AND a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
			AND a.SOLD_DATE_STD IS NULL
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		
		UNION
		
		SELECT a.Row_Id AS Parent
			,b.Row_Id AS Child
			,a.UPDATE_FLAG_DATE_STD
			,b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD
			,b.MLS_LIST_DATE_STD
			,a.SOLD_DATE_STD
			,b.SOLD_DATE_STD
			,42 AS MatchTypeId
		FROM tmp.FA_MLS a
		INNER LOOP JOIN tmp.FA_MLS b ON a.Row_Id <> b.Row_Id
			AND a.REF_ID = b.REF_ID
			AND a.MLS_STATUS_STD = 'Sold'
			AND b.MLS_STATUS_STD = 'Sold'
			AND ABS(DATEDIFF(DAY, a.SOLD_DATE_STD, b.SOLD_DATE_STD)) <= 45
			AND a.MLS_Listing_Number IS NULL
			AND b.MLS_Listing_Number IS NOT NULL
			AND a.Rental_Ind = b.Rental_Ind
			AND a.TargetMatchId IS NULL
		) b
	) a
WHERE a.RowNum = 1

--MERGE tmp.SelfMatchFull a
--USING #SelfMatchFull b
--ON (a.Parent = b.Parent AND a.Child = b.Child AND a.MatchTypeId = b.MatchTypeId)
--WHEN NOT MATCHED BY TARGET
--	THEN INSERT(
--		Parent
--		,Child
--		,MatchTypeId
--	)
--	VALUES (
--		Parent
--		,Child
--		,MatchTypeId
--	)
--;
CREATE TABLE #SelfMatch (
	Parent INT NOT NULL
	,Child INT NOT NULL
	,MatchTypeId TINYINT PRIMARY KEY (
		Parent
		,Child
		)
	)

INSERT INTO #SelfMatch
SELECT Parent
	,Child
	,MIN(MatchTypeId)
FROM (
	SELECT Parent
		,Child
		,MatchTypeId
	FROM #SelfMatchFull
	
	UNION
	
	SELECT Child
		,Parent
		,MatchTypeId
	FROM #SelfMatchFull
	) t
GROUP BY Parent
	,Child

UPDATE tmp.FA_MLS
SET SelfMatchId = NULL
WHERE SelfMatchId IS NOT NULL

WHILE 1 = 1
BEGIN
	UPDATE a
	SET SelfMatchId = COALESCE(b.SelfMatchId, m.Child)
		,MatchTypeId = m.MatchTypeId
	FROM tmp.FA_MLS a
	INNER JOIN #SelfMatch m ON a.Row_Id = m.Parent
	LEFT JOIN tmp.FA_MLS b ON m.Child = b.Row_Id
		AND b.SelfMatchId < m.Child
	WHERE COALESCE(b.SelfMatchId, m.Child) < a.SelfMatchId
		OR a.SelfMatchId IS NULL

	IF @@ROWCOUNT = 0
		BREAK
END

UPDATE tmp.FA_MLS
SET SelfMatchId = Row_Id
WHERE SelfMatchId IS NULL

UPDATE a
SET TargetMatchId = b.TargetMatchId
FROM tmp.FA_MLS a
INNER JOIN (
	SELECT SelfMatchId
		,MIN(TargetMatchId) AS TargetMatchId
	FROM tmp.FA_MLS
	WHERE TargetMatchId IS NOT NULL
	GROUP BY SelfMatchId
	) b ON a.SelfMatchId = b.SelfMatchId
WHERE a.TargetMatchId IS NULL
	OR a.TargetMatchId <> b.TargetMatchId

SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)

RAISERROR (
		'%s Set RowSeq'
		,0
		,1
		,@Timestamp
		)
WITH NOWAIT

-- Set RowSeq
UPDATE m
SET RowSeq = t.RowSeq
FROM tmp.FA_MLS m
INNER JOIN (
	SELECT Row_Id
		,ROW_NUMBER() OVER (
			PARTITION BY SelfMatchId ORDER BY UPDATE_FLAG_DATE_STD
				,MLS_LIST_DATE_STD
				,SOLD_DATE_STD
				,Row_Id
			) AS RowSeq
	FROM tmp.FA_MLS
	) t ON m.Row_Id = t.Row_Id

-- Set Match Partitions
TRUNCATE TABLE ImportMatchPartition

DECLARE @PartitionSize INT = (
		SELECT COUNT(*)
		FROM tmp.FA_MLS
		) / @PartitionCount + 1

INSERT INTO ImportMatchPartition
SELECT RowNum / @PartitionSize + 1
	,MIN(SelfMatchId)
	,MAX(SelfMatchId)
	,COUNT(*)
FROM (
	SELECT SelfMatchId
		,ROW_NUMBER() OVER (
			PARTITION BY 1 ORDER BY SelfMatchId
			) AS RowNum
	FROM tmp.FA_MLS
	) t
GROUP BY RowNum / @PartitionSize

UPDATE a
SET a.BeginRow = b.EndRow + 1
FROM ImportMatchPartition a
INNER JOIN ImportMatchPartition b ON a.Id = b.Id + 1

-- Set next identity value for tmp.Listing
TRUNCATE TABLE tmp.Listing

DECLARE @MaxListingID INT = (
		SELECT MAX(Listing_ID)
		FROM Listing
		)

IF @MaxListingID IS NOT NULL
BEGIN
	SET IDENTITY_INSERT tmp.Listing ON

	INSERT INTO tmp.Listing (
		Listing_ID
		,Created
		,Current_Listing_Ind
		,Current_Rental_Ind
		,LastRow_Id
		,UpdateSeq
		)
	VALUES (
		@MaxListingID
		,GETDATE()
		,0
		,0
		,0
		,0
		)

	SET IDENTITY_INSERT tmp.Listing OFF

	DELETE
	FROM tmp.Listing
	WHERE Listing_ID = @MaxListingID

	SET IDENTITY_INSERT tmp.Listing ON

	INSERT INTO tmp.Listing (
		Listing_ID
		,UPDATE_FLAG_DATE_STD
		,MLS_LIST_DATE_STD
		,MLS_STATUS_STD
		,MLS_Listing_Number
		,MLS_Listing_Agent_CODE
		,MLS_OFFICE_CODE
		,Created
		,Updated
		,Fips
		,REF_ID
		,STATE
		,Current_Listing_Ind
		,Current_Rental_Ind
		,Concurrent_Listed_Ind
		,SOLD_DATE_STD
		,AddrId
		,MLS_LISTING_AGENT2_CODE
		,SEL_AGENT_CODE
		,SEL_AGENT2_CODE
		,LISTING_OFFICE2_CODE
		,SEL_OFFICE_CODE
		,SEL_OFFICE2_CODE
		,Rental_Ind
		,LastRow_Id
		,NBR_BEDRMS_STD
		,MLS_LIST_PRICE_STD
		,SOLD_PRICE_STD
		,BSMT_FIN_SQFT_STD
		,HOME_SIZE_STD
		,LOT_SIZE_STD
		,PRICE_PER_SQFT_STD
		,YEAR_BUILT_STD
		,REO_IND
		,SHORT_SALE_IND
		,MLS_STATUS_SUB_TYPE_STD
		,NBR_BATH_STD
		,NBR_GRG_STD
		,NBR_FIREPLACE_STD
		,NBR_STORIES_STD
		,FIREPLACE_DESC_STD
		,UpdateSeq
		,APX_LOT_DIMENSIONS
		,PROPERTY_DETAILS
		,APN
		,APX_LOT_IS_L85
		,COUNTY_NAME
		,HOUSE_NBR
		,STREET
		,CITY
		,ZIP
		,OTHER_FTRS
		,PROVIDER_TYPE
		,Point
		,Land_Use
		,Original_UPDATE_FLAG_DATE_STD
		)
	SELECT Listing_ID
		,UPDATE_FLAG_DATE_STD
		,MLS_LIST_DATE_STD
		,MLS_STATUS_STD
		,MLS_Listing_Number
		,MLS_Listing_Agent_CODE
		,MLS_OFFICE_CODE
		,Created
		,Updated
		,Fips
		,REF_ID
		,STATE
		,Current_Listing_Ind
		,Current_Rental_Ind
		,Concurrent_Listed_Ind
		,SOLD_DATE_STD
		,AddrId
		,MLS_LISTING_AGENT2_CODE
		,SEL_AGENT_CODE
		,SEL_AGENT2_CODE
		,LISTING_OFFICE2_CODE
		,SEL_OFFICE_CODE
		,SEL_OFFICE2_CODE
		,Rental_Ind
		,LastRow_Id
		,NBR_BEDRMS_STD
		,MLS_LIST_PRICE_STD
		,SOLD_PRICE_STD
		,BSMT_FIN_SQFT_STD
		,HOME_SIZE_STD
		,LOT_SIZE_STD
		,PRICE_PER_SQFT_STD
		,YEAR_BUILT_STD
		,REO_IND
		,SHORT_SALE_IND
		,MLS_STATUS_SUB_TYPE_STD
		,NBR_BATH_STD
		,NBR_GRG_STD
		,NBR_FIREPLACE_STD
		,NBR_STORIES_STD
		,FIREPLACE_DESC_STD
		,UpdateSeq
		,APX_LOT_DIMENSIONS
		,PROPERTY_DETAILS
		,APN
		,APX_LOT_IS_L85
		,COUNTY_NAME
		,HOUSE_NBR
		,STREET
		,CITY
		,ZIP
		,OTHER_FTRS
		,PROVIDER_TYPE
		,Point
		,Land_Use
		,Original_UPDATE_FLAG_DATE_STD
	FROM Listing
	WHERE Listing_ID IN (
			SELECT TargetMatchId
			FROM tmp.FA_MLS
			)

	SET IDENTITY_INSERT tmp.Listing OFF
END

