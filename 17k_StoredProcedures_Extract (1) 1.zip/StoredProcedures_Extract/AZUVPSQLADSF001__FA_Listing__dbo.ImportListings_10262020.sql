SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[ImportListings_10262020]
	@PartitionId INT
AS
	--SSMSBOOST UNBLOCK

	SET XACT_ABORT ON
	SET NOCOUNT ON

	DECLARE @Timestamp VARCHAR(25)
	DECLARE @ErrorMessage NVARCHAR(MAX), @ErrorSeverity INT, @ErrorState INT

	SELECT TOP 0 *
	INTO #FA_MLS
	FROM tmp.FA_MLS

	CREATE UNIQUE CLUSTERED INDEX IX_Row_Id ON #FA_MLS (Row_Id)
	CREATE INDEX IX_RowSeq ON #FA_MLS (RowSeq)
	CREATE INDEX IX_TargetMatchId ON #FA_MLS (TargetMatchId)
	CREATE INDEX IX_SelfMatchId ON #FA_MLS (SelfMatchId)

	SELECT TOP 0 *
	INTO #ListingChange
	FROM ListingChange

	CREATE UNIQUE CLUSTERED INDEX IX_ChangeId ON #ListingChange (ChangeId)
	CREATE INDEX IX_Listing_ID ON #ListingChange (Listing_ID)
	CREATE INDEX IX_Listing_ID_FieldId ON #ListingChange (Listing_ID, FieldId)

	SELECT TOP 0 *
	INTO #ListingFeatures
	FROM ListingFeatures

	CREATE UNIQUE CLUSTERED INDEX IX_Listing_ID_FeatureValueId ON #ListingFeatures (Listing_ID, FeatureValueId)

	SELECT TOP 0 *
	INTO #ListingSubFeatures
	FROM ListingSubFeatures

	CREATE UNIQUE CLUSTERED INDEX IX_Listing_ID_FeatureValueId_SubFeatureValueId ON #ListingSubFeatures (Listing_ID, FeatureValueId, SubFeatureValueId)

	SELECT TOP 0 *
	INTO #ListingFeaturesPivot
	FROM ListingFeaturesPivot

	CREATE UNIQUE CLUSTERED INDEX IX_Listing_ID ON #ListingFeaturesPivot (Listing_ID)

	CREATE TABLE #ListingInserted (
		Row_Id BIGINT NOT NULL PRIMARY KEY
		,Listing_ID INT NOT NULL
	)

	CREATE TABLE #ListingChangeInserted (
		ChangeId INT PRIMARY KEY,
		Listing_ID INT
	)

	SELECT TOP 0 *
	INTO #ListingFeaturesPivotInserted
	FROM ListingFeaturesPivot

	CREATE UNIQUE CLUSTERED INDEX IX_Listing_ID ON #ListingFeaturesPivotInserted (Listing_ID)

	DECLARE @BeginRow BIGINT, @EndRow BIGINT, @Count INT
	SELECT @BeginRow = BeginRow, @EndRow = EndRow, @Count = [Count] FROM ImportMatchPartition WHERE Id = @PartitionId

	INSERT INTO #FA_MLS
	SELECT *
	FROM tmp.FA_MLS
	WHERE SelfMatchId BETWEEN @BeginRow AND @EndRow

	INSERT INTO #ListingFeatures
	SELECT lf.*
	FROM ListingFeatures lf
	WHERE Listing_ID IN (
		SELECT TargetMatchId
		FROM #FA_MLS
	)

	INSERT INTO #ListingSubFeatures
	SELECT lsf.*
	FROM ListingSubFeatures lsf
	WHERE Listing_ID IN (
		SELECT TargetMatchId
		FROM #FA_MLS
	)

	INSERT INTO #ListingFeaturesPivot
	SELECT lfp.*
	FROM ListingFeaturesPivot lfp
	WHERE Listing_ID IN (
		SELECT TargetMatchId
		FROM #FA_MLS
	)

	SELECT Listing_ID, FieldId, MAX(ChangeDate) AS ChangeDate
	INTO #LastChangeDate
	FROM ListingChange
	WHERE Listing_ID IN (
		SELECT TargetMatchId
		FROM #FA_MLS
	)
	GROUP BY Listing_ID, FieldId

	CREATE UNIQUE CLUSTERED INDEX IX_Listing_ID_FieldId ON #LastChangeDate (Listing_ID, FieldId)

	/* Compare against record already on DB */
-- prevent a bad address overlaying a good address
	UPDATE m
	SET m.Addrid = L.AddrId
		,m.COUNTY_NAME = l.COUNTY_NAME
		,m.HOUSE_NBR = l.HOUSE_NBR
		,m.STREET = l.STREET
		,m.CITY = l.CITY
		,m.ZIP = l.ZIP
	FROM #FA_MLS m
	INNER JOIN tmp.Listing l
		ON m.TargetMatchId = l.Listing_ID
	LEFT JOIN dbo.FA_MLS_Raw_Std_Address ma
		ON ma.row_id = m.Addrid
	LEFT JOIN dbo.FA_MLS_Raw_Std_Address la
		ON la.row_id = l.Addrid
	WHERE isnull(ma.AddressMatchResults, '') LIKE '%AE%'
		AND isnull(la.AddressMatchResults, '') NOT LIKE '%AE%'


	-- Prevent Non-Sold -> Sold matches from updating Status, Sold Price, or Sold Date
	UPDATE m
	SET MLS_STATUS_STD = 'Sold', MLS_STATUS_SUB_TYPE_STD = l.MLS_STATUS_SUB_TYPE_STD, SOLD_PRICE_STD = NULL, SOLD_DATE_STD = NULL
	FROM #FA_MLS m
	INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
	WHERE m.MLS_STATUS_STD <> 'Sold' AND l.MLS_STATUS_STD = 'Sold' 

	-- Prevent Sold -> Sold matches from changing existing Sold Price or Sold Date
	UPDATE m
	SET SOLD_PRICE_STD = ISNULL(l.SOLD_PRICE_STD, m.SOLD_PRICE_STD), SOLD_DATE_STD = ISNULL(l.SOLD_DATE_STD, m.SOLD_DATE_STD)
	FROM #FA_MLS m
	INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
	WHERE m.MLS_STATUS_STD = 'Sold' AND l.MLS_STATUS_STD = 'Sold'

	-- Prevent List Date from updating in specific situations
	UPDATE m
	SET MLS_LIST_DATE_STD = NULL
	FROM #FA_MLS m
	INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
	WHERE
		l.MLS_LIST_DATE_STD is not null ---------------------------------------------------------------bug 173331 
/* according to bug 173331
		or m.MLS_LIST_DATE_STD < l.MLS_LIST_DATE_STD
		OR (m.MLS_STATUS_STD = 'Sold' AND l.MLS_LIST_DATE_STD IS NOT NULL)
		OR (m.MLS_STATUS_STD <> 'Sold' AND l.MLS_STATUS_STD = 'Sold' AND l.MLS_LIST_DATE_STD IS NOT NULL)
*/
	--prevent this fips from being updated if ref_id is null
	UPDATE m
	SET m.FIPS = NULL
		,m.COUNTY_NAME = NULL
		,m.HOUSE_NBR = NULL
		,m.STREET = NULL
		,m.CITY = NULL
		,m.ZIP = NULL
		,m.AddrId = NULL
	FROM #FA_MLS m
	INNER JOIN tmp.Listing l WITH (ROWLOCK)
		ON m.TargetMatchId = l.Listing_ID
	WHERE (
			m.Ref_id IS NULL
			AND l.Ref_id IS NOT NULL
			)

    /* Compare against record captured the same day */
	-- Prevent badd address - update
	UPDATE m
	SET m.Addrid = l.AddrId
		,m.COUNTY_NAME = l.COUNTY_NAME
		,m.HOUSE_NBR = l.HOUSE_NBR
		,m.STREET = l.STREET
		,m.CITY = l.CITY
		,m.ZIP = l.ZIP
	FROM #FA_MLS m
	LEFT JOIN dbo.FA_MLS_Raw_Std_Address ma
		ON ma.row_id = m.Addrid
	cross APPLY (
		SELECT TOP 1 l.*
			--l.SelfMatchId
			--,l.Row_Id
			--,l.RowSeq
			--,l.Addrid
			,la.AddressMatchResults
		FROM #FA_MLS l
		LEFT JOIN dbo.FA_MLS_Raw_Std_Address la
			ON la.row_id = l.Addrid
		WHERE l.SelfMatchId = m.SelfMatchId
			AND la.AddressMatchResults NOT LIKE '%AE%'
		ORDER BY l.RowSeq DESC
		) l
	WHERE isnull(m.AddrId, 0) <> isnull(l.Addrid, 0)
	and ma.AddressMatchResults LIKE '%AE%'

	-- Prevent Non-Sold -> Sold matches from updating Status, Sold Price, or Sold Date
	UPDATE m
	SET MLS_STATUS_STD = 'Sold', MLS_STATUS_SUB_TYPE_STD = l.MLS_STATUS_SUB_TYPE_STD, SOLD_PRICE_STD = NULL, SOLD_DATE_STD = NULL
	FROM #FA_MLS m
	INNER JOIN #FA_MLS l ON m.SelfMatchId = l.SelfMatchId AND m.RowSeq > l.RowSeq
	WHERE m.MLS_STATUS_STD <> 'Sold' AND l.MLS_STATUS_STD = 'Sold'

	-- Prevent Sold -> Sold matches from changing existing Sold Price or Sold Date
	UPDATE m
	SET SOLD_PRICE_STD = ISNULL(l.SOLD_PRICE_STD, m.SOLD_PRICE_STD), SOLD_DATE_STD = ISNULL(l.SOLD_DATE_STD, m.SOLD_DATE_STD)
	FROM #FA_MLS m
	INNER JOIN #FA_MLS l ON m.SelfMatchId = l.SelfMatchId AND m.RowSeq > l.RowSeq
	WHERE m.MLS_STATUS_STD = 'Sold' AND l.MLS_STATUS_STD = 'Sold'

	-- Prevent List Date from updating in specific situations
	UPDATE m
	SET MLS_LIST_DATE_STD = NULL
	FROM #FA_MLS m
	INNER JOIN #FA_MLS l ON m.SelfMatchId = l.SelfMatchId AND m.RowSeq > l.RowSeq
	WHERE
	      l.MLS_LIST_DATE_STD is not null -----------------------------------------------------bug 173331
/*  bug 173331
	 ( 
			m.MLS_LIST_DATE_STD < l.MLS_LIST_DATE_STD
			OR (m.MLS_STATUS_STD = 'Sold' AND l.MLS_LIST_DATE_STD IS NOT NULL)
			OR (m.MLS_STATUS_STD <> 'Sold' AND l.MLS_STATUS_STD = 'Sold' AND l.MLS_LIST_DATE_STD IS NOT NULL)
		)
*/
	--prevent this fips from being updated if ref_id is null
	UPDATE m
	SET m.FIPS = NULL
		,m.COUNTY_NAME = NULL
		,m.HOUSE_NBR = NULL
		,m.STREET = NULL
		,m.CITY = NULL
		,m.ZIP = NULL
		,m.AddrId = NULL
	FROM #FA_MLS m
	INNER JOIN #FA_MLS l ON m.SelfMatchId = l.SelfMatchId AND m.RowSeq > l.RowSeq
	where ( m.Ref_id is null 
			and l.Ref_id is not null
		  )

	-- Insert/Update to Listing table
	DECLARE @CurRowSeq INT = 1
	DECLARE @MaxRowSeq INT = (SELECT MAX(RowSeq) FROM #FA_MLS)
	DECLARE @RowCount INT

	WHILE @CurRowSeq <= @MaxRowSeq
	BEGIN
		SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
		RAISERROR('%s Listing Import, CurRowSeq = %d', 0, 1, @Timestamp, @CurRowSeq) WITH NOWAIT

		-- Determine whether to replace or merge features
		UPDATE m
		SET FeaturesMerged = CASE WHEN (ExistingCount > IncomingCount AND (ExistingCount - IncomingCount) * 100 / ExistingCount >= 30) OR m.UPDATE_FLAG_DATE_STD < l.UPDATE_FLAG_DATE_STD THEN 1 ELSE 0 END
		FROM #FA_MLS m
		INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
		CROSS APPLY (
			SELECT COUNT(*) AS ExistingCount
			FROM #ListingFeatures lf
			WHERE lf.Listing_ID = m.TargetMatchId
		) a
		CROSS APPLY (
			SELECT COUNT(*) AS IncomingCount
			FROM tmp.Features f
			WHERE f.Row_Id = m.Row_Id
		) b
		WHERE m.RowSeq = @CurRowSeq

		-- Delete existing feature data when FeaturesMerged = 0
		DELETE lf
		FROM #FA_MLS m
		INNER JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID
		WHERE m.RowSeq = @CurRowSeq AND m.FeaturesMerged = 0

		-- Also delete sub-feature data when FeaturesMerged = 0
		DELETE lsf
		FROM #FA_MLS m
		INNER JOIN #ListingSubFeatures lsf ON m.TargetMatchId = lsf.Listing_ID
		WHERE m.RowSeq = @CurRowSeq AND m.FeaturesMerged = 0

		INSERT INTO #ListingFeatures
		SELECT DISTINCT m.TargetMatchId, f.FeatureValueId
		FROM #FA_MLS m
		INNER JOIN tmp.Features f ON m.Row_Id = f.Row_Id
		LEFT JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID AND f.FeatureValueId = lf.FeatureValueId
		WHERE m.TargetMatchId IS NOT NULL AND m.RowSeq = @CurRowSeq AND lf.Listing_ID IS NULL

		INSERT INTO #ListingSubFeatures
		SELECT DISTINCT m.TargetMatchId, f.FeatureValueId, rv.SubFeatureValueId
		FROM #FA_MLS m
		INNER JOIN tmp.Features f ON m.Row_Id = f.Row_Id
		INNER JOIN FeatureRuleSubFeatureValues rv ON f.FeatureRuleId = rv.FeatureRuleId
		LEFT JOIN #ListingSubFeatures lsf ON m.TargetMatchId = lsf.Listing_ID AND f.FeatureValueId = lsf.FeatureValueId AND rv.SubFeatureValueId = lsf.SubFeatureValueId
		WHERE m.TargetMatchId IS NOT NULL AND m.RowSeq = @CurRowSeq AND lsf.Listing_ID IS NULL

		-- Cross-populate numeric feature values
		UPDATE m
		SET NBR_GRG_STD = NumericValue
		FROM #FA_MLS m
		INNER JOIN (
			SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
			FROM #FA_MLS m
			INNER JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID
			INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
			WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId IN (SELECT Id FROM FeatureTypes WHERE Name IN ('NBR_GRG', 'PARKING_FTRS')))
			GROUP BY m.Row_Id
		) t ON m.Row_Id = t.Row_Id

		UPDATE m
		SET NBR_FIREPLACE_STD = NumericValue
		FROM #FA_MLS m
		INNER JOIN (
			SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
			FROM #FA_MLS m
			INNER JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID
			INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
			WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'FIREPLACE_NBR'))
			GROUP BY m.Row_Id
		) t ON m.Row_Id = t.Row_Id

		UPDATE m
		SET NBR_STORIES_STD = NumericValue
		FROM #FA_MLS m
		INNER JOIN (
			SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
			FROM #FA_MLS m
			INNER JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID
			INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
			WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'NBR_STORIES'))
			GROUP BY m.Row_Id
		) t ON m.Row_Id = t.Row_Id

		UPDATE m
		SET FIREPLACE_DESC_STD = t.FIREPLACE_DESC_STD
		FROM #FA_MLS m
		INNER JOIN (
			SELECT m.Row_Id, dbo.GROUP_CONCAT_DS(Value, ', ', 1) AS FIREPLACE_DESC_STD
			FROM #FA_MLS m
			INNER JOIN #ListingFeatures lf ON m.TargetMatchId = lf.Listing_ID
			INNER JOIN FeatureValues v ON lf.FeatureValueId = v.Id AND FeatureTypeId IN (11, 60, 61) AND DoNotDisplay = 0
			WHERE m.RowSeq = @CurRowSeq
			GROUP BY m.Row_Id
		) t ON m.Row_Id = t.Row_Id

		TRUNCATE TABLE #ListingFeaturesPivotInserted

		INSERT INTO #ListingFeaturesPivotInserted
		SELECT
			lf.Listing_ID
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 1 THEN v.Value END, ', ', 1) AS [APPLIANCES]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 2 THEN v.Value END, ', ', 1) AS [COMMUNITY_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 3 THEN v.Value END, ', ', 1) AS [COMPLEX_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 4 THEN v.Value END, ', ', 1) AS [COOLING_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 5 THEN v.Value END, ', ', 1) AS [ELEMENTARY_SCHOOL]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 6 THEN v.Value END, ', ', 1) AS [ENERGY_INFO]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 7 THEN v.Value END, ', ', 1) AS [EXISTING_STRUCTURES]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 8 THEN v.Value END, ', ', 1) AS [EXTERIOR_CONSTRUCTION]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 9 THEN v.Value END, ', ', 1) AS [EXTERIOR_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 10 THEN v.Value END, ', ', 1) AS [FARM_IMPROVEMENT]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 11 THEN v.Value END, ', ', 1) AS [FIREPLACE_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 60 THEN v.Value END, ', ', 1) AS [FIREPLACE_FUEL_SOURCE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 61 THEN v.Value END, ', ', 1) AS [FIREPLACE_LOCATION]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 62 THEN v.Value END, ', ', 1) AS [FIREPLACE_NBR]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 63 THEN v.Value END, ', ', 1) AS [FIREPLACE_PRESENT]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 64 THEN v.Value END, ', ', 1) AS [Garage Sq Ft]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 46 THEN v.Value END, ', ', 1) AS [Heating Availability]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 12 THEN v.Value END, ', ', 1) AS [HEATING_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 13 THEN v.Value END, ', ', 1) AS [HIGH_SCHOOL]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 65 THEN v.Value END, ', ', 1) AS [HOME_SIZE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 14 THEN v.Value END, ', ', 1) AS [INTERIOR_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 15 THEN v.Value END, ', ', 1) AS [LOT_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 16 THEN v.Value END, ', ', 1) AS [MASTER_BEDROOM]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 17 THEN v.Value END, ', ', 1) AS [MIDDLE_SCHOOL]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 18 THEN v.Value END, ', ', 1) AS [MLS_AREA]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 19 THEN v.Value END, ', ', 1) AS [MLS_INCLUSIONS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 20 THEN v.Value END, ', ', 1) AS [NBR_GRG]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 21 THEN v.Value END, ', ', 1) AS [NBR_STORIES]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 22 THEN v.Value END, ', ', 1) AS [NEIGHBORHOOD]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 23 THEN v.Value END, ', ', 1) AS [PARCEL_ACCESS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 24 THEN v.Value END, ', ', 1) AS [PARKING_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 50 THEN v.Value END, ', ', 1) AS [Pool Accessories]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 51 THEN v.Value END, ', ', 1) AS [Pool Amenities]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 52 THEN v.Value END, ', ', 1) AS [Pool Fuel Source]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 53 THEN v.Value END, ', ', 1) AS [Pool Heating Features]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 54 THEN v.Value END, ', ', 1) AS [Pool Location]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 55 THEN v.Value END, ', ', 1) AS [Pool Presence]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 56 THEN v.Value END, ', ', 1) AS [Pool Size]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 57 THEN v.Value END, ', ', 1) AS [Pool Type]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 25 THEN v.Value END, ', ', 1) AS [POOL_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 26 THEN v.Value END, ', ', 1) AS [PRESENT_USE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 27 THEN v.Value END, ', ', 1) AS [PROPERTY_SUB_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 28 THEN v.Value END, ', ', 1) AS [PROPERTY_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 29 THEN v.Value END, ', ', 1) AS [RANGE_AIRCONDITIONERS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 30 THEN v.Value END, ', ', 1) AS [ROOFING]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 31 THEN v.Value END, ', ', 1) AS [SCHOOL_DISTRICT]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 32 THEN v.Value END, ', ', 1) AS [SEWER]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 33 THEN v.Value END, ', ', 1) AS [STYLE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 34 THEN v.Value END, ', ', 1) AS [SUBDIVISION]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 58 THEN v.Value END, ', ', 1) AS [TOPOGRAPHY]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 35 THEN v.Value END, ', ', 1) AS [UTILITY_PRESENT]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 36 THEN v.Value END, ', ', 1) AS [VIEW_1]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 37 THEN v.Value END, ', ', 1) AS [WATER]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 47 THEN v.Value END, ', ', 1) AS [Water Heater Availability]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 48 THEN v.Value END, ', ', 1) AS [Water Heater Fuel Source]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 49 THEN v.Value END, ', ', 1) AS [Water Heater Type]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 41 THEN v.Value END, ', ', 1) AS [WATER_ACCESS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 44 THEN v.Value END, ', ', 1) AS [WATER_AMMENITIES]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 38 THEN v.Value END, ', ', 1) AS [WATER_FRONT_FTRS]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 39 THEN v.Value END, ', ', 1) AS [WATER_HEATER]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 43 THEN v.Value END, ', ', 1) AS [WATER_METER]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 45 THEN v.Value END, ', ', 1) AS [WATER_PRESENCE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 42 THEN v.Value END, ', ', 1) AS [WATER_SOURCE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 59 THEN v.Value END, ', ', 1) AS [ZONING]
			,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 1 THEN sv.Value END, ', ', 1) AS [HEAT_FUEL_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 2 THEN sv.Value END, ', ', 1) AS [COOL_FUEL_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 3 THEN sv.Value END, ', ', 1) AS [APPLIANCES_FUEL_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 4 THEN sv.Value END, ', ', 1) AS [NBR_GRG_TYPE]
			,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 5 THEN sv.Value END, ', ', 1) AS [FIREPLACE_FUEL_TYPE]
		FROM #ListingFeatures lf
		INNER JOIN FeatureValues v ON lf.FeatureValueId = v.Id AND v.DoNotDisplay = 0
		LEFT JOIN #ListingSubFeatures lsf ON lf.Listing_ID = lsf.Listing_ID AND lf.FeatureValueId = lsf.FeatureValueId
		LEFT JOIN SubFeatureValues sv ON lsf.SubFeatureValueId = sv.Id
		WHERE lf.Listing_ID IN (
			SELECT TargetMatchId
			FROM #FA_MLS
			WHERE RowSeq = @CurRowSeq
		)
		GROUP BY lf.Listing_ID

		-- Run special update for historical records
		UPDATE m
		SET
			UPDATE_FLAG_DATE_STD = l.UPDATE_FLAG_DATE_STD
			,MLS_LIST_DATE_STD = CASE WHEN l.MLS_LIST_DATE_STD IS NULL THEN m.MLS_LIST_DATE_STD END
			,MLS_Listing_Number = CASE WHEN l.MLS_Listing_Number IS NULL THEN m.MLS_Listing_Number END
			,MLS_Listing_Agent_CODE = CASE WHEN l.MLS_Listing_Agent_CODE IS NULL THEN m.MLS_Listing_Agent_CODE END
			,MLS_OFFICE_CODE = CASE WHEN l.MLS_OFFICE_CODE IS NULL THEN m.MLS_OFFICE_CODE END
			,Fips = CASE WHEN l.Fips IS NULL THEN m.Fips END
			,REF_ID = CASE WHEN l.REF_ID IS NULL THEN m.REF_ID END
			,AddrId = CASE WHEN l.AddrId IS NULL THEN m.AddrId END
			,[State] = CASE WHEN l.[State] IS NULL THEN m.[State] END
			,SOLD_DATE_STD = CASE WHEN l.SOLD_DATE_STD IS NULL THEN m.SOLD_DATE_STD END
			,MLS_LISTING_AGENT2_CODE = CASE WHEN l.MLS_LISTING_AGENT2_CODE IS NULL THEN m.MLS_LISTING_AGENT2_CODE END
			,SEL_AGENT_CODE = CASE WHEN l.SEL_AGENT_CODE IS NULL THEN m.SEL_AGENT_CODE END
			,SEL_AGENT2_CODE = CASE WHEN l.SEL_AGENT2_CODE IS NULL THEN m.SEL_AGENT2_CODE END
			,LISTING_OFFICE2_CODE = CASE WHEN l.LISTING_OFFICE2_CODE IS NULL THEN m.LISTING_OFFICE2_CODE END
			,SEL_OFFICE_CODE = CASE WHEN l.SEL_OFFICE_CODE IS NULL THEN m.SEL_OFFICE_CODE END
			,SEL_OFFICE2_CODE = CASE WHEN l.SEL_OFFICE2_CODE IS NULL THEN m.SEL_OFFICE2_CODE END
			,NBR_BEDRMS_STD = CASE WHEN l.NBR_BEDRMS_STD IS NULL THEN m.NBR_BEDRMS_STD END
			,MLS_LIST_PRICE_STD = CASE WHEN l.MLS_LIST_PRICE_STD IS NULL THEN m.MLS_LIST_PRICE_STD END
			,SOLD_PRICE_STD = CASE WHEN l.SOLD_PRICE_STD IS NULL THEN m.SOLD_PRICE_STD END
			,BSMT_FIN_SQFT_STD = CASE WHEN l.BSMT_FIN_SQFT_STD IS NULL THEN m.BSMT_FIN_SQFT_STD END
			,HOME_SIZE_STD = CASE WHEN l.HOME_SIZE_STD IS NULL THEN m.HOME_SIZE_STD END
			,LOT_SIZE_STD = CASE WHEN l.LOT_SIZE_STD IS NULL THEN m.LOT_SIZE_STD END
			,PRICE_PER_SQFT_STD = CASE WHEN l.PRICE_PER_SQFT_STD IS NULL THEN m.PRICE_PER_SQFT_STD END
			,YEAR_BUILT_STD = CASE WHEN l.YEAR_BUILT_STD IS NULL THEN m.YEAR_BUILT_STD END
			,REO_IND = CASE WHEN l.REO_IND = 1 THEN 1 ELSE m.REO_IND END
			,SHORT_SALE_IND = CASE WHEN l.SHORT_SALE_IND = 1 THEN 1 ELSE m.SHORT_SALE_IND END
			,NBR_BATH_STD = CASE WHEN l.NBR_BATH_STD IS NULL THEN m.NBR_BATH_STD END
			,NBR_GRG_STD = CASE WHEN l.NBR_GRG_STD IS NULL THEN m.NBR_GRG_STD END
			,NBR_FIREPLACE_STD = CASE WHEN l.NBR_FIREPLACE_STD IS NULL THEN m.NBR_FIREPLACE_STD END
			,NBR_STORIES_STD = CASE WHEN l.NBR_STORIES_STD IS NULL THEN m.NBR_STORIES_STD END
			,FIREPLACE_DESC_STD = CASE WHEN l.FIREPLACE_DESC_STD IS NULL THEN m.FIREPLACE_DESC_STD END
			,APX_LOT_DIMENSIONS = CASE WHEN l.APX_LOT_DIMENSIONS IS NULL THEN m.APX_LOT_DIMENSIONS END
			,PROPERTY_DETAILS = CASE WHEN l.PROPERTY_DETAILS IS NULL THEN m.PROPERTY_DETAILS END
			,APN = CASE WHEN l.APN IS NULL THEN m.APN END
			,APX_LOT_IS_L85 = CASE WHEN l.APX_LOT_IS_L85 IS NULL THEN m.APX_LOT_IS_L85 END
			,COUNTY_NAME = CASE WHEN l.COUNTY_NAME IS NULL THEN m.COUNTY_NAME END
			,HOUSE_NBR = CASE WHEN l.HOUSE_NBR IS NULL THEN m.HOUSE_NBR END
			,STREET = CASE WHEN l.STREET IS NULL THEN m.STREET END
			,CITY = CASE WHEN l.CITY IS NULL THEN m.CITY END
			,ZIP = CASE WHEN l.ZIP IS NULL THEN m.ZIP END
			,OTHER_FTRS = CASE WHEN l.OTHER_FTRS IS NULL THEN m.OTHER_FTRS END -- paul
			,PROVIDER_TYPE = CASE WHEN l.PROVIDER_TYPE IS NULL THEN m.PROVIDER_TYPE END -- paul
			
		FROM #FA_MLS m
		INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
		WHERE RowSeq = @CurRowSeq AND m.UPDATE_FLAG_DATE_STD < l.UPDATE_FLAG_DATE_STD

		SET @RowCount = @@ROWCOUNT

		SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
		RAISERROR('%s Importing %d History Records', 0, 1, @Timestamp, @RowCount) WITH NOWAIT

		TRUNCATE TABLE #ListingChangeInserted

		INSERT INTO #ListingChange (Listing_ID, FieldId, ValueDate, ChangeDate, Value, UpdateSeq)
		OUTPUT inserted.ChangeId, inserted.Listing_ID INTO #ListingChangeInserted
		SELECT lc.Listing_ID, lc.FieldId, ISNULL(t.ChangeDate, lc.Created), lc.ChangeDate, SUBSTRING(lc.Value, 1, 8000) AS Value, lc.UpdateSeq
		FROM (
			SELECT l.Listing_ID, 1 AS FieldId, l.Created, m.UPDATE_FLAG_DATE_STD AS ChangeDate, l.MLS_STATUS_STD AS Value, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND l.MLS_STATUS_STD <> m.MLS_STATUS_STD
			UNION
			SELECT l.Listing_ID, 2, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.MLS_LIST_PRICE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_LIST_PRICE_STD <> m.MLS_LIST_PRICE_STD OR (l.MLS_LIST_PRICE_STD IS NULL AND m.MLS_LIST_PRICE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 3, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SOLD_PRICE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SOLD_PRICE_STD <> m.SOLD_PRICE_STD OR (l.SOLD_PRICE_STD IS NULL AND m.SOLD_PRICE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 4, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR(10), l.MLS_LIST_DATE_STD, 121), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_LIST_DATE_STD <> m.MLS_LIST_DATE_STD OR (l.MLS_LIST_DATE_STD IS NULL AND m.MLS_LIST_DATE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 5, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR(10), l.SOLD_DATE_STD, 121), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SOLD_DATE_STD <> m.SOLD_DATE_STD OR (l.SOLD_DATE_STD IS NULL AND m.SOLD_DATE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 6, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.Fips), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.Fips <> m.Fips OR (l.Fips IS NULL AND m.Fips IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 7, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.REF_ID), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.REF_ID <> m.REF_ID OR (l.REF_ID IS NULL AND m.REF_ID IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 8, l.Created, m.UPDATE_FLAG_DATE_STD, l.[State], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.[State] <> m.[State] OR (l.[State] IS NULL AND m.[State] IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 9, l.Created, m.UPDATE_FLAG_DATE_STD, l.MLS_Listing_Number, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_Listing_Number <> m.MLS_Listing_Number OR (l.MLS_Listing_Number IS NULL AND m.MLS_Listing_Number IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 10, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.MLS_Listing_Agent_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_Listing_Agent_CODE <> m.MLS_Listing_Agent_CODE OR (l.MLS_Listing_Agent_CODE IS NULL AND m.MLS_Listing_Agent_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 11, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.MLS_OFFICE_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_OFFICE_CODE <> m.MLS_OFFICE_CODE OR (l.MLS_OFFICE_CODE IS NULL AND m.MLS_OFFICE_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 12, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.MLS_LISTING_AGENT2_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.MLS_LISTING_AGENT2_CODE <> m.MLS_LISTING_AGENT2_CODE OR (l.MLS_LISTING_AGENT2_CODE IS NULL AND m.MLS_LISTING_AGENT2_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 13, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SEL_AGENT_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SEL_AGENT_CODE <> m.SEL_AGENT_CODE OR (l.SEL_AGENT_CODE IS NULL AND m.SEL_AGENT_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 14, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SEL_AGENT2_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SEL_AGENT2_CODE <> m.SEL_AGENT2_CODE OR (l.SEL_AGENT2_CODE IS NULL AND m.SEL_AGENT2_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 15, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.LISTING_OFFICE2_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.LISTING_OFFICE2_CODE <> m.LISTING_OFFICE2_CODE OR (l.LISTING_OFFICE2_CODE IS NULL AND m.LISTING_OFFICE2_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 16, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SEL_OFFICE_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SEL_OFFICE_CODE <> m.SEL_OFFICE_CODE OR (l.SEL_OFFICE_CODE IS NULL AND m.SEL_OFFICE_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 17, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SEL_OFFICE2_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.SEL_OFFICE2_CODE <> m.SEL_OFFICE2_CODE OR (l.SEL_OFFICE2_CODE IS NULL AND m.SEL_OFFICE2_CODE IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 18, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.NBR_BEDRMS_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.NBR_BEDRMS_STD <> m.NBR_BEDRMS_STD OR (l.NBR_BEDRMS_STD IS NULL AND m.NBR_BEDRMS_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 19, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.BSMT_FIN_SQFT_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.BSMT_FIN_SQFT_STD <> CAST(m.BSMT_FIN_SQFT_STD AS DECIMAL(15, 2)) OR (l.BSMT_FIN_SQFT_STD IS NULL AND m.BSMT_FIN_SQFT_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 20, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.HOME_SIZE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.HOME_SIZE_STD <> m.HOME_SIZE_STD OR (l.HOME_SIZE_STD IS NULL AND m.HOME_SIZE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 21, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.LOT_SIZE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.LOT_SIZE_STD <> CAST(m.LOT_SIZE_STD AS DECIMAL(18, 2)) OR (l.LOT_SIZE_STD IS NULL AND m.LOT_SIZE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 22, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.PRICE_PER_SQFT_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.PRICE_PER_SQFT_STD <> m.PRICE_PER_SQFT_STD OR (l.PRICE_PER_SQFT_STD IS NULL AND m.PRICE_PER_SQFT_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 23, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.YEAR_BUILT_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.YEAR_BUILT_STD <> m.YEAR_BUILT_STD OR (l.YEAR_BUILT_STD IS NULL AND m.YEAR_BUILT_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 24, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.REO_IND), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND l.REO_IND <> m.REO_IND
			UNION
			SELECT l.Listing_ID, 25, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.SHORT_SALE_IND), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND l.SHORT_SALE_IND <> m.SHORT_SALE_IND
			UNION
			SELECT l.Listing_ID, 26, l.Created, m.UPDATE_FLAG_DATE_STD, l.MLS_STATUS_SUB_TYPE_STD, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(l.MLS_STATUS_SUB_TYPE_STD, '') <> ISNULL(m.MLS_STATUS_SUB_TYPE_STD, '')
			UNION
			SELECT l.Listing_ID, 27, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.NBR_BATH_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.NBR_BATH_STD <> CAST(m.NBR_BATH_STD AS DECIMAL(18, 2)) OR (l.NBR_BATH_STD IS NULL AND m.NBR_BATH_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 28, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.NBR_GRG_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.NBR_GRG_STD <> m.NBR_GRG_STD OR (l.NBR_GRG_STD IS NULL AND m.NBR_GRG_STD IS NOT NULL) OR (l.NBR_GRG_STD IS NOT NULL AND m.NBR_GRG_STD IS NULL))
			UNION
			SELECT l.Listing_ID, 29, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.NBR_FIREPLACE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.NBR_FIREPLACE_STD <> m.NBR_FIREPLACE_STD OR (l.NBR_FIREPLACE_STD IS NULL AND m.NBR_FIREPLACE_STD IS NOT NULL) OR (l.NBR_FIREPLACE_STD IS NOT NULL AND m.NBR_FIREPLACE_STD IS NULL))
			UNION
			SELECT l.Listing_ID, 30, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, l.NBR_STORIES_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.NBR_STORIES_STD <> m.NBR_STORIES_STD OR (l.NBR_STORIES_STD IS NULL AND m.NBR_STORIES_STD IS NOT NULL) OR (l.NBR_STORIES_STD IS NOT NULL AND m.NBR_STORIES_STD IS NULL))
			UNION
			SELECT l.Listing_ID, 31, l.Created, m.UPDATE_FLAG_DATE_STD, l.FIREPLACE_DESC_STD, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(l.FIREPLACE_DESC_STD, '') <> ISNULL(m.FIREPLACE_DESC_STD, '')
			UNION
			SELECT l.Listing_ID, 32, l.Created, m.UPDATE_FLAG_DATE_STD, a.APPLIANCES, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.APPLIANCES, '') <> ISNULL(b.APPLIANCES, '')
			UNION
			SELECT l.Listing_ID, 33, l.Created, m.UPDATE_FLAG_DATE_STD, a.COMMUNITY_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.COMMUNITY_FTRS, '') <> ISNULL(b.COMMUNITY_FTRS, '')
			UNION
			SELECT l.Listing_ID, 34, l.Created, m.UPDATE_FLAG_DATE_STD, a.COMPLEX_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.COMPLEX_FTRS, '') <> ISNULL(b.COMPLEX_FTRS, '')
			UNION
			SELECT l.Listing_ID, 35, l.Created, m.UPDATE_FLAG_DATE_STD, a.COOLING_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.COOLING_FTRS, '') <> ISNULL(b.COOLING_FTRS, '')
			UNION
			SELECT l.Listing_ID, 36, l.Created, m.UPDATE_FLAG_DATE_STD, a.ELEMENTARY_SCHOOL, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.ELEMENTARY_SCHOOL, '') <> ISNULL(b.ELEMENTARY_SCHOOL, '')
			UNION
			SELECT l.Listing_ID, 37, l.Created, m.UPDATE_FLAG_DATE_STD, a.ENERGY_INFO, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.ENERGY_INFO, '') <> ISNULL(b.ENERGY_INFO, '')
			UNION
			SELECT l.Listing_ID, 38, l.Created, m.UPDATE_FLAG_DATE_STD, a.EXISTING_STRUCTURES, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.EXISTING_STRUCTURES, '') <> ISNULL(b.EXISTING_STRUCTURES, '')
			UNION
			SELECT l.Listing_ID, 39, l.Created, m.UPDATE_FLAG_DATE_STD, a.EXTERIOR_CONSTRUCTION, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.EXTERIOR_CONSTRUCTION, '') <> ISNULL(b.EXTERIOR_CONSTRUCTION, '')
			UNION
			SELECT l.Listing_ID, 40, l.Created, m.UPDATE_FLAG_DATE_STD, a.EXTERIOR_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.EXTERIOR_FTRS, '') <> ISNULL(b.EXTERIOR_FTRS, '')
			UNION
			SELECT l.Listing_ID, 41, l.Created, m.UPDATE_FLAG_DATE_STD, a.FARM_IMPROVEMENT, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FARM_IMPROVEMENT, '') <> ISNULL(b.FARM_IMPROVEMENT, '')
			UNION
			SELECT l.Listing_ID, 42, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_FTRS, '') <> ISNULL(b.FIREPLACE_FTRS, '')
			UNION
			SELECT l.Listing_ID, 43, l.Created, m.UPDATE_FLAG_DATE_STD, a.HEATING_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.HEATING_FTRS, '') <> ISNULL(b.HEATING_FTRS, '')
			UNION
			SELECT l.Listing_ID, 44, l.Created, m.UPDATE_FLAG_DATE_STD, a.HIGH_SCHOOL, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.HIGH_SCHOOL, '') <> ISNULL(b.HIGH_SCHOOL, '')
			UNION
			SELECT l.Listing_ID, 45, l.Created, m.UPDATE_FLAG_DATE_STD, a.INTERIOR_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.INTERIOR_FTRS, '') <> ISNULL(b.INTERIOR_FTRS, '')
			UNION
			SELECT l.Listing_ID, 46, l.Created, m.UPDATE_FLAG_DATE_STD, a.LOT_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.LOT_FTRS, '') <> ISNULL(b.LOT_FTRS, '')
			UNION
			SELECT l.Listing_ID, 47, l.Created, m.UPDATE_FLAG_DATE_STD, a.MASTER_BEDROOM, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.MASTER_BEDROOM, '') <> ISNULL(b.MASTER_BEDROOM, '')
			UNION
			SELECT l.Listing_ID, 48, l.Created, m.UPDATE_FLAG_DATE_STD, a.MIDDLE_SCHOOL, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.MIDDLE_SCHOOL, '') <> ISNULL(b.MIDDLE_SCHOOL, '')
			UNION
			SELECT l.Listing_ID, 49, l.Created, m.UPDATE_FLAG_DATE_STD, a.MLS_AREA, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.MLS_AREA, '') <> ISNULL(b.MLS_AREA, '')
			UNION
			SELECT l.Listing_ID, 50, l.Created, m.UPDATE_FLAG_DATE_STD, a.MLS_INCLUSIONS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.MLS_INCLUSIONS, '') <> ISNULL(b.MLS_INCLUSIONS, '')
			UNION
			SELECT l.Listing_ID, 51, l.Created, m.UPDATE_FLAG_DATE_STD, a.NBR_GRG, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.NBR_GRG, '') <> ISNULL(b.NBR_GRG, '')
			UNION
			SELECT l.Listing_ID, 52, l.Created, m.UPDATE_FLAG_DATE_STD, a.NBR_STORIES, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.NBR_STORIES, '') <> ISNULL(b.NBR_STORIES, '')
			UNION
			SELECT l.Listing_ID, 53, l.Created, m.UPDATE_FLAG_DATE_STD, a.NEIGHBORHOOD, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.NEIGHBORHOOD, '') <> ISNULL(b.NEIGHBORHOOD, '')
			UNION
			SELECT l.Listing_ID, 54, l.Created, m.UPDATE_FLAG_DATE_STD, a.PARCEL_ACCESS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.PARCEL_ACCESS, '') <> ISNULL(b.PARCEL_ACCESS, '')
			UNION
			SELECT l.Listing_ID, 55, l.Created, m.UPDATE_FLAG_DATE_STD, a.PARKING_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.PARKING_FTRS, '') <> ISNULL(b.PARKING_FTRS, '')
			UNION
			SELECT l.Listing_ID, 56, l.Created, m.UPDATE_FLAG_DATE_STD, a.POOL_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.POOL_FTRS, '') <> ISNULL(b.POOL_FTRS, '')
			UNION
			SELECT l.Listing_ID, 57, l.Created, m.UPDATE_FLAG_DATE_STD, a.PRESENT_USE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.PRESENT_USE, '') <> ISNULL(b.PRESENT_USE, '')
			UNION
			SELECT l.Listing_ID, 58, l.Created, m.UPDATE_FLAG_DATE_STD, a.PROPERTY_SUB_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.PROPERTY_SUB_TYPE, '') <> ISNULL(b.PROPERTY_SUB_TYPE, '')
			UNION
			SELECT l.Listing_ID, 59, l.Created, m.UPDATE_FLAG_DATE_STD, a.PROPERTY_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.PROPERTY_TYPE, '') <> ISNULL(b.PROPERTY_TYPE, '')
			UNION
			SELECT l.Listing_ID, 60, l.Created, m.UPDATE_FLAG_DATE_STD, a.RANGE_AIRCONDITIONERS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.RANGE_AIRCONDITIONERS, '') <> ISNULL(b.RANGE_AIRCONDITIONERS, '')
			UNION
			SELECT l.Listing_ID, 61, l.Created, m.UPDATE_FLAG_DATE_STD, a.ROOFING, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.ROOFING, '') <> ISNULL(b.ROOFING, '')
			UNION
			SELECT l.Listing_ID, 62, l.Created, m.UPDATE_FLAG_DATE_STD, a.SCHOOL_DISTRICT, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.SCHOOL_DISTRICT, '') <> ISNULL(b.SCHOOL_DISTRICT, '')
			UNION
			SELECT l.Listing_ID, 63, l.Created, m.UPDATE_FLAG_DATE_STD, a.SEWER, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.SEWER, '') <> ISNULL(b.SEWER, '')
			UNION
			SELECT l.Listing_ID, 64, l.Created, m.UPDATE_FLAG_DATE_STD, a.STYLE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.STYLE, '') <> ISNULL(b.STYLE, '')
			UNION
			SELECT l.Listing_ID, 65, l.Created, m.UPDATE_FLAG_DATE_STD, a.SUBDIVISION, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.SUBDIVISION, '') <> ISNULL(b.SUBDIVISION, '')
			UNION
			SELECT l.Listing_ID, 66, l.Created, m.UPDATE_FLAG_DATE_STD, a.UTILITY_PRESENT, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.UTILITY_PRESENT, '') <> ISNULL(b.UTILITY_PRESENT, '')
			UNION
			SELECT l.Listing_ID, 67, l.Created, m.UPDATE_FLAG_DATE_STD, a.VIEW_1, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.VIEW_1, '') <> ISNULL(b.VIEW_1, '')
			UNION
			SELECT l.Listing_ID, 68, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER, '') <> ISNULL(b.WATER, '')
			UNION
			SELECT l.Listing_ID, 69, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_FRONT_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_FRONT_FTRS, '') <> ISNULL(b.WATER_FRONT_FTRS, '')
			UNION
			SELECT l.Listing_ID, 70, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_HEATER, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_HEATER, '') <> ISNULL(b.WATER_HEATER, '')
			UNION
			SELECT l.Listing_ID, 71, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_ACCESS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_ACCESS, '') <> ISNULL(b.WATER_ACCESS, '')
			UNION
			SELECT l.Listing_ID, 72, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_SOURCE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_SOURCE, '') <> ISNULL(b.WATER_SOURCE, '')
			UNION
			SELECT l.Listing_ID, 73, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_METER, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_METER, '') <> ISNULL(b.WATER_METER, '')
			UNION
			SELECT l.Listing_ID, 74, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_AMMENITIES, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_AMMENITIES, '') <> ISNULL(b.WATER_AMMENITIES, '')
			UNION
			SELECT l.Listing_ID, 75, l.Created, m.UPDATE_FLAG_DATE_STD, a.WATER_PRESENCE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.WATER_PRESENCE, '') <> ISNULL(b.WATER_PRESENCE, '')
			UNION
			SELECT l.Listing_ID, 76, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Heating Availability], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Heating Availability], '') <> ISNULL(b.[Heating Availability], '')
			UNION
			SELECT l.Listing_ID, 77, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Water Heater Availability], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Water Heater Availability], '') <> ISNULL(b.[Water Heater Availability], '')
			UNION
			SELECT l.Listing_ID, 78, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Water Heater Fuel Source], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Water Heater Fuel Source], '') <> ISNULL(b.[Water Heater Fuel Source], '')
			UNION
			SELECT l.Listing_ID, 79, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Water Heater Type], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Water Heater Type], '') <> ISNULL(b.[Water Heater Type], '')
			UNION
			SELECT l.Listing_ID, 80, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Accessories], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Accessories], '') <> ISNULL(b.[Pool Accessories], '')
			UNION
			SELECT l.Listing_ID, 81, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Amenities], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Amenities], '') <> ISNULL(b.[Pool Amenities], '')
			UNION
			SELECT l.Listing_ID, 82, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Fuel Source], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Fuel Source], '') <> ISNULL(b.[Pool Fuel Source], '')
			UNION
			SELECT l.Listing_ID, 83, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Heating Features], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Heating Features], '') <> ISNULL(b.[Pool Heating Features], '')
			UNION
			SELECT l.Listing_ID, 84, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Location], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Location], '') <> ISNULL(b.[Pool Location], '')
			UNION
			SELECT l.Listing_ID, 85, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Presence], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Presence], '') <> ISNULL(b.[Pool Presence], '')
			UNION
			SELECT l.Listing_ID, 86, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Size], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Size], '') <> ISNULL(b.[Pool Size], '')
			UNION
			SELECT l.Listing_ID, 87, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Pool Type], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Pool Type], '') <> ISNULL(b.[Pool Type], '')
			UNION
			SELECT l.Listing_ID, 88, l.Created, m.UPDATE_FLAG_DATE_STD, a.TOPOGRAPHY, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.TOPOGRAPHY, '') <> ISNULL(b.TOPOGRAPHY, '')
			UNION
			SELECT l.Listing_ID, 89, l.Created, m.UPDATE_FLAG_DATE_STD, a.ZONING, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.ZONING, '') <> ISNULL(b.ZONING, '')
			UNION
			SELECT l.Listing_ID, 90, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_FUEL_SOURCE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_FUEL_SOURCE, '') <> ISNULL(b.FIREPLACE_FUEL_SOURCE, '')
			UNION
			SELECT l.Listing_ID, 91, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_LOCATION, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_LOCATION, '') <> ISNULL(b.FIREPLACE_LOCATION, '')
			UNION
			SELECT l.Listing_ID, 92, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_NBR, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_NBR, '') <> ISNULL(b.FIREPLACE_NBR, '')
			UNION
			SELECT l.Listing_ID, 93, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_PRESENT, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_PRESENT, '') <> ISNULL(b.FIREPLACE_PRESENT, '')
			UNION
			SELECT l.Listing_ID, 94, l.Created, m.UPDATE_FLAG_DATE_STD, a.[Garage Sq Ft], l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.[Garage Sq Ft], '') <> ISNULL(b.[Garage Sq Ft], '')
			UNION
			SELECT l.Listing_ID, 95, l.Created, m.UPDATE_FLAG_DATE_STD, a.HOME_SIZE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.HOME_SIZE, '') <> ISNULL(b.HOME_SIZE, '')
			UNION
			SELECT l.Listing_ID, 96, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, a1.MLS_Listing_Agent_CODE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Listing_Agent a1 ON l.MLS_Listing_Agent_CODE = a1.MLS_Listing_Agent_CODE
			LEFT JOIN MLS_Listing_Agent a2 ON m.MLS_Listing_Agent_CODE = a2.MLS_Listing_Agent_CODE
			WHERE RowSeq = @CurRowSeq AND (a1.MLS_Listing_Agent_CODE_STD <> a2.MLS_Listing_Agent_CODE_STD OR (a1.MLS_Listing_Agent_CODE_STD IS NULL AND a2.MLS_Listing_Agent_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 97, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, o1.MLS_OFFICE_CODE_STD), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Office o1 ON l.MLS_OFFICE_CODE = o1.MLS_OFFICE_CODE
			LEFT JOIN MLS_Office o2 ON m.MLS_OFFICE_CODE = o2.MLS_OFFICE_CODE
			WHERE RowSeq = @CurRowSeq AND (o1.MLS_OFFICE_CODE_STD <> o2.MLS_OFFICE_CODE_STD OR (o1.MLS_OFFICE_CODE_STD IS NULL AND o2.MLS_OFFICE_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 98, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, a1.MLS_Listing_Agent_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Listing_Agent a1 ON l.MLS_LISTING_AGENT2_CODE = a1.MLS_Listing_Agent_CODE
			LEFT JOIN MLS_Listing_Agent a2 ON m.MLS_LISTING_AGENT2_CODE = a2.MLS_Listing_Agent_CODE
			WHERE RowSeq = @CurRowSeq AND (a1.MLS_Listing_Agent_CODE_STD <> a2.MLS_Listing_Agent_CODE_STD OR (a1.MLS_Listing_Agent_CODE_STD IS NULL AND a2.MLS_Listing_Agent_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 99, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, a1.MLS_Listing_Agent_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Listing_Agent a1 ON l.SEL_AGENT_CODE = a1.MLS_Listing_Agent_CODE
			LEFT JOIN MLS_Listing_Agent a2 ON m.SEL_AGENT_CODE = a2.MLS_Listing_Agent_CODE
			WHERE RowSeq = @CurRowSeq AND (a1.MLS_Listing_Agent_CODE_STD <> a2.MLS_Listing_Agent_CODE_STD OR (a1.MLS_Listing_Agent_CODE_STD IS NULL AND a2.MLS_Listing_Agent_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 100, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, a1.MLS_Listing_Agent_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Listing_Agent a1 ON l.SEL_AGENT2_CODE = a1.MLS_Listing_Agent_CODE
			LEFT JOIN MLS_Listing_Agent a2 ON m.SEL_AGENT2_CODE = a2.MLS_Listing_Agent_CODE
			WHERE RowSeq = @CurRowSeq AND (a1.MLS_Listing_Agent_CODE_STD <> a2.MLS_Listing_Agent_CODE_STD OR (a1.MLS_Listing_Agent_CODE_STD IS NULL AND a2.MLS_Listing_Agent_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 101, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, o1.MLS_OFFICE_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Office o1 ON l.LISTING_OFFICE2_CODE = o1.MLS_OFFICE_CODE
			LEFT JOIN MLS_Office o2 ON m.LISTING_OFFICE2_CODE = o2.MLS_OFFICE_CODE
			WHERE RowSeq = @CurRowSeq AND (o1.MLS_OFFICE_CODE_STD <> o2.MLS_OFFICE_CODE_STD OR (o1.MLS_OFFICE_CODE_STD IS NULL AND o2.MLS_OFFICE_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 102, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, o1.MLS_OFFICE_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Office o1 ON l.SEL_OFFICE_CODE = o1.MLS_OFFICE_CODE
			LEFT JOIN MLS_Office o2 ON m.SEL_OFFICE_CODE = o2.MLS_OFFICE_CODE
			WHERE RowSeq = @CurRowSeq AND (o1.MLS_OFFICE_CODE_STD <> o2.MLS_OFFICE_CODE_STD OR (o1.MLS_OFFICE_CODE_STD IS NULL AND o2.MLS_OFFICE_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 103, l.Created, m.UPDATE_FLAG_DATE_STD, CONVERT(VARCHAR, o1.MLS_OFFICE_CODE), l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			LEFT JOIN MLS_Office o1 ON l.SEL_OFFICE2_CODE = o1.MLS_OFFICE_CODE
			LEFT JOIN MLS_Office o2 ON m.SEL_OFFICE2_CODE = o2.MLS_OFFICE_CODE
			WHERE RowSeq = @CurRowSeq AND (o1.MLS_OFFICE_CODE_STD <> o2.MLS_OFFICE_CODE_STD OR (o1.MLS_OFFICE_CODE_STD IS NULL AND o2.MLS_OFFICE_CODE_STD IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 104, l.Created, m.UPDATE_FLAG_DATE_STD, l.APX_LOT_DIMENSIONS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.APX_LOT_DIMENSIONS <> m.APX_LOT_DIMENSIONS OR (l.APX_LOT_DIMENSIONS IS NULL AND m.APX_LOT_DIMENSIONS IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 105, l.Created, m.UPDATE_FLAG_DATE_STD, l.PROPERTY_DETAILS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.PROPERTY_DETAILS <> m.PROPERTY_DETAILS OR (l.PROPERTY_DETAILS IS NULL AND m.PROPERTY_DETAILS IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 106, l.Created, m.UPDATE_FLAG_DATE_STD, a.HEAT_FUEL_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.HEAT_FUEL_TYPE, '') <> ISNULL(b.HEAT_FUEL_TYPE, '')
			UNION
			SELECT l.Listing_ID, 107, l.Created, m.UPDATE_FLAG_DATE_STD, a.COOL_FUEL_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.COOL_FUEL_TYPE, '') <> ISNULL(b.COOL_FUEL_TYPE, '')
			UNION
			SELECT l.Listing_ID, 108, l.Created, m.UPDATE_FLAG_DATE_STD, a.APPLIANCES_FUEL_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.APPLIANCES_FUEL_TYPE, '') <> ISNULL(b.APPLIANCES_FUEL_TYPE, '')
			UNION
			SELECT l.Listing_ID, 109, l.Created, m.UPDATE_FLAG_DATE_STD, a.NBR_GRG_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.NBR_GRG_TYPE, '') <> ISNULL(b.NBR_GRG_TYPE, '')
			UNION
			SELECT l.Listing_ID, 110, l.Created, m.UPDATE_FLAG_DATE_STD, a.FIREPLACE_FUEL_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			INNER JOIN #ListingFeaturesPivot a ON l.Listing_ID = a.Listing_ID
			INNER JOIN #ListingFeaturesPivotInserted b ON l.Listing_ID = b.Listing_ID
			WHERE RowSeq = @CurRowSeq AND ISNULL(a.FIREPLACE_FUEL_TYPE, '') <> ISNULL(b.FIREPLACE_FUEL_TYPE, '')
			UNION
			SELECT l.Listing_ID, 111, l.Created, m.UPDATE_FLAG_DATE_STD, l.APN, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.APN <> m.APN OR (l.APN IS NULL AND m.APN IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 112, l.Created, m.UPDATE_FLAG_DATE_STD, l.APX_LOT_IS_L85, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.APX_LOT_IS_L85 <> m.APX_LOT_IS_L85 OR (l.APX_LOT_IS_L85 IS NULL AND m.APX_LOT_IS_L85 IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 113, l.Created, m.UPDATE_FLAG_DATE_STD, l.COUNTY_NAME, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.COUNTY_NAME <> m.COUNTY_NAME OR (l.COUNTY_NAME IS NULL AND m.COUNTY_NAME IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 114, l.Created, m.UPDATE_FLAG_DATE_STD, l.HOUSE_NBR, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.HOUSE_NBR <> m.HOUSE_NBR OR (l.HOUSE_NBR IS NULL AND m.HOUSE_NBR IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 115, l.Created, m.UPDATE_FLAG_DATE_STD, l.STREET, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.STREET <> m.STREET OR (l.STREET IS NULL AND m.STREET IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 116, l.Created, m.UPDATE_FLAG_DATE_STD, l.CITY, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.CITY <> m.CITY OR (l.CITY IS NULL AND m.CITY IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 117, l.Created, m.UPDATE_FLAG_DATE_STD, l.ZIP, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.ZIP <> m.ZIP OR (l.ZIP IS NULL AND m.ZIP IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 118, l.Created, m.UPDATE_FLAG_DATE_STD, l.OTHER_FTRS, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.OTHER_FTRS <> m.OTHER_FTRS OR (l.OTHER_FTRS IS NULL AND m.OTHER_FTRS IS NOT NULL))
			UNION
			SELECT l.Listing_ID, 119, l.Created, m.UPDATE_FLAG_DATE_STD, l.PROVIDER_TYPE, l.UpdateSeq
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq AND (l.PROVIDER_TYPE <> m.PROVIDER_TYPE OR (l.PROVIDER_TYPE IS NULL AND m.PROVIDER_TYPE IS NOT NULL))
		) lc
		LEFT JOIN #LastChangeDate t ON lc.Listing_ID = t.Listing_ID AND lc.FieldId = t.FieldId

		-- Keep #LastChangeDate updated
		MERGE #LastChangeDate a
		USING (
			SELECT lc.Listing_ID, lc.FieldId, MAX(lc.ChangeDate) AS ChangeDate
			FROM #ListingChangeInserted i
			INNER JOIN #ListingChange lc ON i.ChangeId = lc.ChangeId
			GROUP BY lc.Listing_ID, lc.FieldId
		) b
		ON (a.Listing_ID = b.Listing_ID AND a.FieldId = b.FieldId)
		WHEN MATCHED THEN
			UPDATE SET ChangeDate = b.ChangeDate
		WHEN NOT MATCHED BY TARGET THEN
			INSERT(Listing_ID, FieldId, ChangeDate) VALUES (b.Listing_ID, b.FieldId, b.ChangeDate);

		WHILE 1 = 1
		BEGIN
			BEGIN TRY
			BEGIN TRANSACTION
			UPDATE l
			SET
				MLS_LIST_DATE_STD = ISNULL(m.MLS_LIST_DATE_STD, l.MLS_LIST_DATE_STD)
				,MLS_STATUS_STD = m.MLS_STATUS_STD
				,MLS_Listing_Number = ISNULL(m.MLS_Listing_Number, l.MLS_Listing_Number)
				,MLS_Listing_Agent_CODE = ISNULL(m.MLS_Listing_Agent_CODE, l.MLS_Listing_Agent_CODE)
				,MLS_OFFICE_CODE = ISNULL(m.MLS_OFFICE_CODE, l.MLS_OFFICE_CODE)
				,Fips = ISNULL(m.Fips, l.Fips)
				,REF_ID = ISNULL(m.REF_ID, l.REF_ID)
				,AddrId = ISNULL(m.AddrId, l.AddrId)
				,[State] = ISNULL(m.[State], l.[State])
				,SOLD_DATE_STD = ISNULL(m.SOLD_DATE_STD, l.SOLD_DATE_STD)
				,MLS_LISTING_AGENT2_CODE = ISNULL(m.MLS_LISTING_AGENT2_CODE, l.MLS_LISTING_AGENT2_CODE)
				,SEL_AGENT_CODE = ISNULL(m.SEL_AGENT_CODE, l.SEL_AGENT_CODE)
				,SEL_AGENT2_CODE = ISNULL(m.SEL_AGENT2_CODE, l.SEL_AGENT2_CODE)
				,LISTING_OFFICE2_CODE = ISNULL(m.LISTING_OFFICE2_CODE, l.LISTING_OFFICE2_CODE)
				,SEL_OFFICE_CODE = ISNULL(m.SEL_OFFICE_CODE, l.SEL_OFFICE_CODE)
				,SEL_OFFICE2_CODE = ISNULL(m.SEL_OFFICE2_CODE, l.SEL_OFFICE2_CODE)
				,NBR_BEDRMS_STD = ISNULL(m.NBR_BEDRMS_STD, l.NBR_BEDRMS_STD)
				,MLS_LIST_PRICE_STD = ISNULL(m.MLS_LIST_PRICE_STD, l.MLS_LIST_PRICE_STD)
				,SOLD_PRICE_STD = ISNULL(m.SOLD_PRICE_STD, l.SOLD_PRICE_STD)
				,BSMT_FIN_SQFT_STD = ISNULL(m.BSMT_FIN_SQFT_STD, l.BSMT_FIN_SQFT_STD)
				,HOME_SIZE_STD = ISNULL(m.HOME_SIZE_STD, l.HOME_SIZE_STD)
				,LOT_SIZE_STD = ISNULL(m.LOT_SIZE_STD, l.LOT_SIZE_STD)
				,PRICE_PER_SQFT_STD = ISNULL(m.PRICE_PER_SQFT_STD, l.PRICE_PER_SQFT_STD)
				,YEAR_BUILT_STD = ISNULL(m.YEAR_BUILT_STD, l.YEAR_BUILT_STD)
				,REO_IND = m.REO_IND
				,SHORT_SALE_IND = m.SHORT_SALE_IND
				,MLS_STATUS_SUB_TYPE_STD = m.MLS_STATUS_SUB_TYPE_STD
				,NBR_BATH_STD = ISNULL(m.NBR_BATH_STD, l.NBR_BATH_STD)
				,NBR_GRG_STD = m.NBR_GRG_STD
				,NBR_FIREPLACE_STD = m.NBR_FIREPLACE_STD
				,NBR_STORIES_STD = m.NBR_STORIES_STD
				,FIREPLACE_DESC_STD = m.FIREPLACE_DESC_STD
				,APX_LOT_DIMENSIONS = ISNULL(m.APX_LOT_DIMENSIONS, l.APX_LOT_DIMENSIONS)
				,PROPERTY_DETAILS = ISNULL(m.PROPERTY_DETAILS, l.PROPERTY_DETAILS)
				,APN = ISNULL(m.APN, l.APN)
				,APX_LOT_IS_L85 = ISNULL(m.APX_LOT_IS_L85, l.APX_LOT_IS_L85)
				,COUNTY_NAME = ISNULL(m.COUNTY_NAME, l.COUNTY_NAME)
				,HOUSE_NBR = ISNULL(m.HOUSE_NBR, l.HOUSE_NBR)
				,STREET = ISNULL(m.STREET, l.STREET)
				,CITY = ISNULL(m.CITY, l.CITY)
				,ZIP = ISNULL(m.ZIP, l.ZIP)
				,OTHER_FTRS = ISNULL(m.OTHER_FTRS, l.OTHER_FTRS)
				,PROVIDER_TYPE = ISNULL(m.PROVIDER_TYPE, l.PROVIDER_TYPE)
				,LastRow_Id = m.Row_Id
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE RowSeq = @CurRowSeq

			SET @RowCount = @@ROWCOUNT

			-- Update UpdateSeq and Updated columns if there was an actual change
			UPDATE l
			SET
				UPDATE_FLAG_DATE_STD = m.UPDATE_FLAG_DATE_STD
				--,Original_UPDATE_FLAG_DATE_STD = Isnull(l.Original_UPDATE_FLAG_DATE_STD,m.Original_UPDATE_FLAG_DATE_STD)
				,Original_UPDATE_FLAG_DATE_STD = case when l.mls_status_std = 'Fail' and m.mls_status_std = 'FAIL' then l.Original_UPDATE_FLAG_DATE_STD else m.Original_UPDATE_FLAG_DATE_STD end 
				,UpdateSeq = l.UpdateSeq + 1
				,Updated = GETDATE()
			FROM #FA_MLS m
			INNER JOIN tmp.Listing l WITH (ROWLOCK) ON m.TargetMatchId = l.Listing_ID
			WHERE m.RowSeq = @CurRowSeq AND m.TargetMatchId IN (
				SELECT Listing_ID
				FROM #ListingChangeInserted
			)
			COMMIT TRANSACTION
			BREAK
			END TRY
			BEGIN CATCH
				IF @@TRANCOUNT > 0
					ROLLBACK
				IF ERROR_NUMBER() = 1205
					CONTINUE
				SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
				RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
				RETURN
			END CATCH
		END

		UPDATE a
		SET
			APPLIANCES = b.APPLIANCES
			,COMMUNITY_FTRS = b.COMMUNITY_FTRS
			,COMPLEX_FTRS = b.COMPLEX_FTRS
			,COOLING_FTRS = b.COOLING_FTRS
			,ELEMENTARY_SCHOOL = b.ELEMENTARY_SCHOOL
			,ENERGY_INFO = b.ENERGY_INFO
			,EXISTING_STRUCTURES = b.EXISTING_STRUCTURES
			,EXTERIOR_CONSTRUCTION = b.EXTERIOR_CONSTRUCTION
			,EXTERIOR_FTRS = b.EXTERIOR_FTRS
			,FARM_IMPROVEMENT = b.FARM_IMPROVEMENT
			,FIREPLACE_FTRS = b.FIREPLACE_FTRS
			,HEATING_FTRS = b.HEATING_FTRS
			,HIGH_SCHOOL = b.HIGH_SCHOOL
			,INTERIOR_FTRS = b.INTERIOR_FTRS
			,LOT_FTRS = b.LOT_FTRS
			,MASTER_BEDROOM = b.MASTER_BEDROOM
			,MIDDLE_SCHOOL = b.MIDDLE_SCHOOL
			,MLS_AREA = b.MLS_AREA
			,MLS_INCLUSIONS = b.MLS_INCLUSIONS
			,NBR_GRG = b.NBR_GRG
			,NBR_STORIES = b.NBR_STORIES
			,NEIGHBORHOOD = b.NEIGHBORHOOD
			,PARCEL_ACCESS = b.PARCEL_ACCESS
			,PARKING_FTRS = b.PARKING_FTRS
			,POOL_FTRS = b.POOL_FTRS
			,PRESENT_USE = b.PRESENT_USE
			,PROPERTY_SUB_TYPE = b.PROPERTY_SUB_TYPE
			,PROPERTY_TYPE = b.PROPERTY_TYPE
			,RANGE_AIRCONDITIONERS = b.RANGE_AIRCONDITIONERS
			,ROOFING = b.ROOFING
			,SCHOOL_DISTRICT = b.SCHOOL_DISTRICT
			,SEWER = b.SEWER
			,STYLE = b.STYLE
			,SUBDIVISION = b.SUBDIVISION
			,UTILITY_PRESENT = b.UTILITY_PRESENT
			,VIEW_1 = b.VIEW_1
			,WATER = b.WATER
			,WATER_FRONT_FTRS = b.WATER_FRONT_FTRS
			,WATER_HEATER = b.WATER_HEATER
			,WATER_ACCESS = b.WATER_ACCESS
			,WATER_SOURCE = b.WATER_SOURCE
			,WATER_METER = b.WATER_METER
			,WATER_AMMENITIES = b.WATER_AMMENITIES
			,WATER_PRESENCE = b.WATER_PRESENCE
			,[Heating Availability] = b.[Heating Availability]
			,[Water Heater Availability] = b.[Water Heater Availability]
			,[Water Heater Fuel Source] = b.[Water Heater Fuel Source]
			,[Water Heater Type] = b.[Water Heater Type]
			,[Pool Accessories] = b.[Pool Accessories]
			,[Pool Amenities] = b.[Pool Amenities]
			,[Pool Fuel Source] = b.[Pool Fuel Source]
			,[Pool Heating Features] = b.[Pool Heating Features]
			,[Pool Location] = b.[Pool Location]
			,[Pool Presence] = b.[Pool Presence]
			,[Pool Size] = b.[Pool Size]
			,[Pool Type] = b.[Pool Type]
			,TOPOGRAPHY = b.TOPOGRAPHY
			,ZONING = b.ZONING
			,FIREPLACE_FUEL_SOURCE = b.FIREPLACE_FUEL_SOURCE
			,FIREPLACE_LOCATION = b.FIREPLACE_LOCATION
			,FIREPLACE_NBR = b.FIREPLACE_NBR
			,FIREPLACE_PRESENT = b.FIREPLACE_PRESENT
			,[Garage Sq Ft] = b.[Garage Sq Ft]
			,HOME_SIZE = b.HOME_SIZE
			,HEAT_FUEL_TYPE = b.HEAT_FUEL_TYPE
			,COOL_FUEL_TYPE = b.COOL_FUEL_TYPE
			,APPLIANCES_FUEL_TYPE = b.APPLIANCES_FUEL_TYPE
			,NBR_GRG_TYPE = b.NBR_GRG_TYPE
			,FIREPLACE_FUEL_TYPE = b.FIREPLACE_FUEL_TYPE
		FROM #ListingFeaturesPivot a
		INNER JOIN #ListingFeaturesPivotInserted b ON a.Listing_ID = b.Listing_ID

		SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
		RAISERROR('%s Updated %d', 0, 1, @Timestamp, @RowCount) WITH NOWAIT

		IF @CurRowSeq = 1
		BEGIN
			-- Cross-populate numeric feature values
			UPDATE m
			SET NBR_GRG_STD = NumericValue
			FROM #FA_MLS m
			INNER JOIN (
				SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
				FROM #FA_MLS m
				INNER JOIN tmp.Features lf ON m.Row_Id = lf.Row_Id
				INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
				WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId IN (SELECT Id FROM FeatureTypes WHERE Name IN ('NBR_GRG', 'PARKING_FTRS')))
				GROUP BY m.Row_Id
			) t ON m.Row_Id = t.Row_Id

			UPDATE m
			SET NBR_FIREPLACE_STD = NumericValue
			FROM #FA_MLS m
			INNER JOIN (
				SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
				FROM #FA_MLS m
				INNER JOIN tmp.Features lf ON m.Row_Id = lf.Row_Id
				INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
				WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'FIREPLACE_NBR'))
				GROUP BY m.Row_Id
			) t ON m.Row_Id = t.Row_Id

			UPDATE m
			SET NBR_STORIES_STD = NumericValue
			FROM #FA_MLS m
			INNER JOIN (
				SELECT m.Row_Id, MAX(v.NumericValue) AS NumericValue
				FROM #FA_MLS m
				INNER JOIN tmp.Features lf ON m.Row_Id = lf.Row_Id
				INNER JOIN FeatureValuesNumeric v ON lf.FeatureValueId = v.FeatureValueId
				WHERE m.RowSeq = @CurRowSeq AND v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'NBR_STORIES'))
				GROUP BY m.Row_Id
			) t ON m.Row_Id = t.Row_Id

			UPDATE m
			SET FIREPLACE_DESC_STD = t.FIREPLACE_DESC_STD
			FROM #FA_MLS m
			INNER JOIN (
				SELECT m.Row_Id, dbo.GROUP_CONCAT_DS(v.Value, ', ', 1) AS FIREPLACE_DESC_STD
				FROM #FA_MLS m
				INNER JOIN tmp.Features lf ON m.Row_Id = lf.Row_Id
				INNER JOIN FeatureValues v ON lf.FeatureValueId = v.Id AND v.FeatureTypeId IN (11, 60, 61) AND DoNotDisplay = 0
				WHERE m.RowSeq = @CurRowSeq
				GROUP BY m.Row_Id
			) t ON m.Row_Id = t.Row_Id

			TRUNCATE TABLE #ListingInserted

			WHILE 1 = 1
			BEGIN
				BEGIN TRY
				BEGIN TRANSACTION
				INSERT INTO tmp.Listing WITH (ROWLOCK) (
					UPDATE_FLAG_DATE_STD
					,MLS_LIST_DATE_STD
					,MLS_STATUS_STD
					,MLS_Listing_Number
					,MLS_Listing_Agent_CODE
					,MLS_OFFICE_CODE
					,Fips
					,REF_ID
					,AddrId
					,[State]
					,SOLD_DATE_STD
					,MLS_LISTING_AGENT2_CODE
					,SEL_AGENT_CODE
					,SEL_AGENT2_CODE
					,LISTING_OFFICE2_CODE
					,SEL_OFFICE_CODE
					,SEL_OFFICE2_CODE
					,NBR_BEDRMS_STD
					,MLS_LIST_PRICE_STD
					,SOLD_PRICE_STD
					,BSMT_FIN_SQFT_STD
					,HOME_SIZE_STD
					,LOT_SIZE_STD
					,PRICE_PER_SQFT_STD
					,YEAR_BUILT_STD
					,REO_IND
					,SHORT_SALE_IND
					,MLS_STATUS_SUB_TYPE_STD
					,NBR_BATH_STD
					,NBR_GRG_STD
					,NBR_FIREPLACE_STD
					,NBR_STORIES_STD
					,FIREPLACE_DESC_STD
					,APX_LOT_DIMENSIONS
					,PROPERTY_DETAILS
					,APN
					,APX_LOT_IS_L85
					,COUNTY_NAME
					,HOUSE_NBR
					,STREET
					,CITY
					,ZIP
					,OTHER_FTRS
					,PROVIDER_TYPE
					,Rental_Ind
					,LastRow_Id
					,Created
					,UpdateSeq
					,Current_Listing_Ind
					,Current_Rental_Ind
					,Original_UPDATE_FLAG_DATE_STD
				)
				OUTPUT inserted.LastRow_Id, inserted.Listing_ID INTO #ListingInserted
				SELECT
					UPDATE_FLAG_DATE_STD
					,MLS_LIST_DATE_STD
					,MLS_STATUS_STD
					,MLS_Listing_Number
					,MLS_Listing_Agent_CODE
					,MLS_OFFICE_CODE
					,Fips
					,REF_ID
					,AddrId
					,[State]
					,SOLD_DATE_STD
					,MLS_LISTING_AGENT2_CODE
					,SEL_AGENT_CODE
					,SEL_AGENT2_CODE
					,LISTING_OFFICE2_CODE
					,SEL_OFFICE_CODE
					,SEL_OFFICE2_CODE
					,NBR_BEDRMS_STD
					,MLS_LIST_PRICE_STD
					,SOLD_PRICE_STD
					,BSMT_FIN_SQFT_STD
					,HOME_SIZE_STD
					,LOT_SIZE_STD
					,PRICE_PER_SQFT_STD
					,YEAR_BUILT_STD
					,REO_IND
					,SHORT_SALE_IND
					,MLS_STATUS_SUB_TYPE_STD
					,NBR_BATH_STD
					,NBR_GRG_STD
					,NBR_FIREPLACE_STD
					,NBR_STORIES_STD
					,FIREPLACE_DESC_STD
					,APX_LOT_DIMENSIONS
					,PROPERTY_DETAILS
					,APN
					,APX_LOT_IS_L85
					,COUNTY_NAME
					,HOUSE_NBR
					,STREET
					,CITY
					,ZIP
					,OTHER_FTRS
					,PROVIDER_TYPE
					,Rental_Ind
					,SelfMatchId
					,UPDATE_FLAG_DATE_STD AS Created
					,1 AS UpdateSeq
					,0 AS Current_Listing_Ind
					,0 AS Current_Rental_Ind
					,Original_UPDATE_FLAG_DATE_STD
				FROM #FA_MLS
				WHERE TargetMatchId IS NULL AND RowSeq = 1
				ORDER BY UPDATE_FLAG_DATE_STD, Row_Id

				SET @RowCount = @@ROWCOUNT

				COMMIT TRANSACTION
				BREAK
				END TRY
				BEGIN CATCH
					IF @@TRANCOUNT > 0
						ROLLBACK
					IF ERROR_NUMBER() = 1205
						CONTINUE
					SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
					RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
					RETURN
				END CATCH
			END

			UPDATE m
			SET TargetMatchId = i.Listing_ID
			FROM #FA_MLS m
			INNER JOIN #ListingInserted i ON m.SelfMatchId = i.Row_Id

			-- Insert Features & Subfeatures
			INSERT INTO #ListingFeatures
			SELECT DISTINCT i.Listing_ID, FeatureValueId
			FROM #FA_MLS m
			INNER JOIN #ListingInserted i ON m.Row_Id = i.Row_Id
			INNER JOIN tmp.Features f ON m.Row_Id = f.Row_Id

			INSERT INTO #ListingSubFeatures
			SELECT DISTINCT i.Listing_ID, FeatureValueId, SubFeatureValueId
			FROM #FA_MLS m
			INNER JOIN #ListingInserted i ON m.Row_Id = i.Row_Id
			INNER JOIN tmp.Features f ON m.Row_Id = f.Row_Id
			INNER JOIN FeatureRuleSubFeatureValues rv ON f.FeatureRuleId = rv.FeatureRuleId

			INSERT INTO #ListingFeaturesPivot
			SELECT
				lf.Listing_ID
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 1 THEN v.Value END, ', ', 1) AS [APPLIANCES]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 2 THEN v.Value END, ', ', 1) AS [COMMUNITY_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 3 THEN v.Value END, ', ', 1) AS [COMPLEX_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 4 THEN v.Value END, ', ', 1) AS [COOLING_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 5 THEN v.Value END, ', ', 1) AS [ELEMENTARY_SCHOOL]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 6 THEN v.Value END, ', ', 1) AS [ENERGY_INFO]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 7 THEN v.Value END, ', ', 1) AS [EXISTING_STRUCTURES]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 8 THEN v.Value END, ', ', 1) AS [EXTERIOR_CONSTRUCTION]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 9 THEN v.Value END, ', ', 1) AS [EXTERIOR_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 10 THEN v.Value END, ', ', 1) AS [FARM_IMPROVEMENT]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 11 THEN v.Value END, ', ', 1) AS [FIREPLACE_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 60 THEN v.Value END, ', ', 1) AS [FIREPLACE_FUEL_SOURCE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 61 THEN v.Value END, ', ', 1) AS [FIREPLACE_LOCATION]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 62 THEN v.Value END, ', ', 1) AS [FIREPLACE_NBR]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 63 THEN v.Value END, ', ', 1) AS [FIREPLACE_PRESENT]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 64 THEN v.Value END, ', ', 1) AS [Garage Sq Ft]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 46 THEN v.Value END, ', ', 1) AS [Heating Availability]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 12 THEN v.Value END, ', ', 1) AS [HEATING_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 13 THEN v.Value END, ', ', 1) AS [HIGH_SCHOOL]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 65 THEN v.Value END, ', ', 1) AS [HOME_SIZE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 14 THEN v.Value END, ', ', 1) AS [INTERIOR_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 15 THEN v.Value END, ', ', 1) AS [LOT_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 16 THEN v.Value END, ', ', 1) AS [MASTER_BEDROOM]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 17 THEN v.Value END, ', ', 1) AS [MIDDLE_SCHOOL]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 18 THEN v.Value END, ', ', 1) AS [MLS_AREA]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 19 THEN v.Value END, ', ', 1) AS [MLS_INCLUSIONS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 20 THEN v.Value END, ', ', 1) AS [NBR_GRG]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 21 THEN v.Value END, ', ', 1) AS [NBR_STORIES]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 22 THEN v.Value END, ', ', 1) AS [NEIGHBORHOOD]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 23 THEN v.Value END, ', ', 1) AS [PARCEL_ACCESS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 24 THEN v.Value END, ', ', 1) AS [PARKING_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 50 THEN v.Value END, ', ', 1) AS [Pool Accessories]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 51 THEN v.Value END, ', ', 1) AS [Pool Amenities]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 52 THEN v.Value END, ', ', 1) AS [Pool Fuel Source]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 53 THEN v.Value END, ', ', 1) AS [Pool Heating Features]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 54 THEN v.Value END, ', ', 1) AS [Pool Location]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 55 THEN v.Value END, ', ', 1) AS [Pool Presence]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 56 THEN v.Value END, ', ', 1) AS [Pool Size]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 57 THEN v.Value END, ', ', 1) AS [Pool Type]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 25 THEN v.Value END, ', ', 1) AS [POOL_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 26 THEN v.Value END, ', ', 1) AS [PRESENT_USE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 27 THEN v.Value END, ', ', 1) AS [PROPERTY_SUB_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 28 THEN v.Value END, ', ', 1) AS [PROPERTY_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 29 THEN v.Value END, ', ', 1) AS [RANGE_AIRCONDITIONERS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 30 THEN v.Value END, ', ', 1) AS [ROOFING]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 31 THEN v.Value END, ', ', 1) AS [SCHOOL_DISTRICT]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 32 THEN v.Value END, ', ', 1) AS [SEWER]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 33 THEN v.Value END, ', ', 1) AS [STYLE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 34 THEN v.Value END, ', ', 1) AS [SUBDIVISION]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 58 THEN v.Value END, ', ', 1) AS [TOPOGRAPHY]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 35 THEN v.Value END, ', ', 1) AS [UTILITY_PRESENT]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 36 THEN v.Value END, ', ', 1) AS [VIEW_1]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 37 THEN v.Value END, ', ', 1) AS [WATER]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 47 THEN v.Value END, ', ', 1) AS [Water Heater Availability]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 48 THEN v.Value END, ', ', 1) AS [Water Heater Fuel Source]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 49 THEN v.Value END, ', ', 1) AS [Water Heater Type]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 41 THEN v.Value END, ', ', 1) AS [WATER_ACCESS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 44 THEN v.Value END, ', ', 1) AS [WATER_AMMENITIES]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 38 THEN v.Value END, ', ', 1) AS [WATER_FRONT_FTRS]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 39 THEN v.Value END, ', ', 1) AS [WATER_HEATER]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 43 THEN v.Value END, ', ', 1) AS [WATER_METER]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 45 THEN v.Value END, ', ', 1) AS [WATER_PRESENCE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 42 THEN v.Value END, ', ', 1) AS [WATER_SOURCE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN FeatureTypeId = 59 THEN v.Value END, ', ', 1) AS [ZONING]
				,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 1 THEN sv.Value END, ', ', 1) AS [HEAT_FUEL_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 2 THEN sv.Value END, ', ', 1) AS [COOL_FUEL_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 3 THEN sv.Value END, ', ', 1) AS [APPLIANCES_FUEL_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 4 THEN sv.Value END, ', ', 1) AS [NBR_GRG_TYPE]
				,dbo.GROUP_CONCAT_DS(CASE WHEN SubFeatureTypeId = 5 THEN sv.Value END, ', ', 1) AS [FIREPLACE_FUEL_TYPE]
			FROM #ListingInserted i
			INNER JOIN #ListingFeatures lf ON i.Listing_ID = lf.Listing_ID
			INNER JOIN FeatureValues v ON lf.FeatureValueId = v.Id AND v.DoNotDisplay = 0
			LEFT JOIN #ListingSubFeatures lsf ON lf.Listing_ID = lsf.Listing_ID AND lf.FeatureValueId = lsf.FeatureValueId
			LEFT JOIN SubFeatureValues sv ON lsf.SubFeatureValueId = sv.Id
			GROUP BY lf.Listing_ID

			SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
			RAISERROR('%s Inserted %d', 0, 1, @Timestamp, @RowCount) WITH NOWAIT
		END

		SET @CurRowSeq = @CurRowSeq + 1
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.ListingChange WITH (TABLOCK) (Listing_ID, FieldId, ValueDate, UpdateSeq, ChangeDate, Value)
			SELECT Listing_ID, FieldId, ValueDate, UpdateSeq, ChangeDate, Value
			FROM #ListingChange

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.ListingFeatures WITH (TABLOCK)
			SELECT *
			FROM #ListingFeatures

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.ListingSubFeatures WITH (TABLOCK)
			SELECT *
			FROM #ListingSubFeatures

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.ListingFeaturesPivot WITH (TABLOCK)
			SELECT *
			FROM #ListingFeaturesPivot

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.PropertyToListing WITH (TABLOCK) (Property_ID, Listing_ID)
			SELECT DISTINCT m.Property_ID, m.TargetMatchId
			FROM #FA_MLS m
			WHERE Property_id IS NOT NULL --- gapfill

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO tmp.ListingRow WITH (TABLOCK) (Row_Id, Listing_ID, MatchTypeId, FeaturesMerged)
			SELECT m.Row_Id, m.TargetMatchId, m.MatchTypeId, m.FeaturesMerged
			FROM #FA_MLS m

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

	WHILE 1 = 1
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			UPDATE a
			SET TargetMatchId = b.TargetMatchId
			FROM tmp.FA_MLS a WITH (ROWLOCK)
			INNER JOIN #FA_MLS b ON a.Row_Id = b.Row_Id

			COMMIT TRANSACTION
			BREAK
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK
			IF ERROR_NUMBER() = 1205
				CONTINUE
			SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState)
			RETURN
		END CATCH
	END

