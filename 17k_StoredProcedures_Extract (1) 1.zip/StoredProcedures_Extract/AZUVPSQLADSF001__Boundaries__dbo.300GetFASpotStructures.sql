SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[300GetFASpotStructures] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

-----------STEP 1

INSERT INTO [GISService_ETL].[gis].[FASPOT_Structures]
           ([Fips]
           ,[MasterAssrId]
           ,[PropertyID]
           ,[RefId]
           ,[Geom]
           ,[MasterStructureId]
           ,[Height]
           ,[StructureCalcSqFt]
           ,[NbrStructuresOnProperty]
           ,[BldgSeq]
           ,[FATimestamp]
           ,[FAUCIDFlag])
Select      [Fips]
           ,[MasterAssrId]
           ,[PropertyID]
           ,[RefId]
           ,[Geom3857]
           ,[MasterStructureId]
           ,[Height]
           ,[StructureCalcSqFt]
           ,[NbrStructuresOnProperty]
           ,[BldgSeq]
           ,GetDate()  --[FATimestamp]
           ,'U'  --[FAUCIDFlag]
from [Boundaries].[dlvry].[Structure_BATCH_REFRESH_ALL]
where fips = @fips

INSERT INTO [Boundaries].[dbo].[zz_300GetStructure_Run]
           ([Fips],[DateTime])
 Select @fips,GetDate()

END

