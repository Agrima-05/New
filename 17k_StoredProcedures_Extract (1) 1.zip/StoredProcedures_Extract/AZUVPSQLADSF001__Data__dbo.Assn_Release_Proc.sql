SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Assn_Release_Proc] @fips varchar(5) 

AS
BEGIN

	SET NOCOUNT ON;

----  100 Get Transaction Master Temp

Truncate Table [Global].[dbo].[Transaction_Master_Work]

INSERT INTO [Global].[dbo].[Transaction_Master_Work]
           ([FIPS]
           ,[TransactionId]
           ,[TransUniqueID]
           ,[FileType]
           ,[DocNbrSrce]
           ,[DocYear]
           ,[RecordingDt]
           ,[BookSrce]
           ,[PageSrce]
           ,[YearDocNbrFrmt]
           ,[DocNbrFrmt]
           ,[BkPgFrmt]
           ,[YearBkPgFrmt]
           ,[VendorPID]
           ,[VendorDeedPID]
           ,[VendorSAMPID]
           ,[FADeedId]
           ,[FASAMId]
           ,[FAForeclosureId]
           ,[FASourceInd]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FAUCIDFlag]
           ,[FADateReceived]
           ,[FA_DocNbrFmt]
           ,[FA_YearDocNbrFmt]
           ,[FA_YearDayDocNumFmt]
           ,[FA_DocNbrFmtCode]
           ,[FA_BookPageFmt]
           ,[FA_YearBookPageFmt]
           ,[FA_BookPageFmtCode]
           ,[DIM_MatchCode]
           ,[Dim_CMTID]
           ,[DIM_DocNbr]
           ,[DIM_DocType]
           ,[DIM_LoanAmt]
           ,[DIM_SaleAmt]
           ,[DIM_RecordingDate]
           ,[Dim_LienPos]
           ,[FADataUpdateDate]
           ,[Dim_RefID]
           ,[FAPropertyID]
           ,[VendorDataEntryDate]
           ,[DiffRectoSale]
           ,[DiffRectoEntry]
           ,[DiffEntrytoFA]
           ,[DiffRectoFA]
           ,[FA_CMTID_DocNum]
           ,[FA_CMTID_YearDocNum]
           ,[FA_CMTID_YearDateDocNum]
           ,[FA_CMTID_BookPage]
           ,[FA_CMTID_YearBookPage]
           ,[FA_ContractDate]
           ,[FA_Amount]
           ,[Verification]
           ,[CMTID_USE]
           ,[DocNbr_USE]
           ,[FA_BookFmt]
           ,[FA_PageFmt]
           ,[DocNbrSrce_II]
           ,[RecordingDt_II]
           ,[BookSrce_II]
           ,[PageSrce_II]
           ,[FA_DocNbrFmt_II]
           ,[FA_YearDocNbrFmt_II]
           ,[FA_YearDayDocNumFmt_II]
           ,[FA_DocNbrFmtCode_II]
           ,[FA_BookPageFmt_II]
           ,[FA_BookFmt_II]
           ,[FA_PageFmt_II]
           ,[FA_YearBookPageFmt_II]
           ,[FA_BookPageFmtCode_II]
           ,[FA_CMTID_DocNum_II]
           ,[FA_CMTID_YearDocNum_II]
           ,[FA_CMTID_YearDateDocNum_II]
           ,[FA_CMTID_BookPage_II]
           ,[FA_CMTID_YearBookPage_II]
           ,[CMTID_USE_II]
           ,[DocNbr_USE_II]
           ,[DocNbrSrce_III]
           ,[RecordingDt_III]
           ,[BookSrce_III]
           ,[PageSrce_III]
           ,[FA_DocNbrFmt_III]
           ,[FA_YearDocNbrFmt_III]
           ,[FA_YearDayDocNumFmt_III]
           ,[FA_DocNbrFmtCode_III]
           ,[FA_BookPageFmt_III]
           ,[FA_BookFmt_III]
           ,[FA_PageFmt_III]
           ,[FA_YearBookPageFmt_III]
           ,[FA_BookPageFmtCode_III]
           ,[FA_CMTID_DocNum_III]
           ,[FA_CMTID_YearDocNum_III]
           ,[FA_CMTID_YearDateDocNum_III]
           ,[FA_CMTID_BookPage_III]
           ,[FA_CMTID_YearBookPage_III]
           ,[CMTID_USE_III]
           ,[DocNbr_USE_III]
           ,[InData])
 Select     [FIPS]
           ,[TransactionId]
           ,[TransUniqueID]
           ,[FileType]
           ,[DocNbrSrce]
           ,[DocYear]
           ,[RecordingDt]
           ,[BookSrce]
           ,[PageSrce]
           ,[YearDocNbrFrmt]
           ,[DocNbrFrmt]
           ,[BkPgFrmt]
           ,[YearBkPgFrmt]
           ,[VendorPID]
           ,[VendorDeedPID]
           ,[VendorSAMPID]
           ,[FADeedId]
           ,[FASAMId]
           ,[FAForeclosureId]
           ,[FASourceInd]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FAUCIDFlag]
           ,[FADateReceived]
           ,[FA_DocNbrFmt]
           ,[FA_YearDocNbrFmt]
           ,[FA_YearDayDocNumFmt]
           ,[FA_DocNbrFmtCode]
           ,[FA_BookPageFmt]
           ,[FA_YearBookPageFmt]
           ,[FA_BookPageFmtCode]
           ,[DIM_MatchCode]
           ,[Dim_CMTID]
           ,[DIM_DocNbr]
           ,[DIM_DocType]
           ,[DIM_LoanAmt]
           ,[DIM_SaleAmt]
           ,[DIM_RecordingDate]
           ,[Dim_LienPos]
           ,[FADataUpdateDate]
           ,[Dim_RefID]
           ,[FAPropertyID]
           ,[VendorDataEntryDate]
           ,[DiffRectoSale]
           ,[DiffRectoEntry]
           ,[DiffEntrytoFA]
           ,[DiffRectoFA]
           ,[FA_CMTID_DocNum]
           ,[FA_CMTID_YearDocNum]
           ,[FA_CMTID_YearDateDocNum]
           ,[FA_CMTID_BookPage]
           ,[FA_CMTID_YearBookPage]
           ,[FA_ContractDate]
           ,[FA_Amount]
           ,[Verification]
           ,[CMTID_USE]
           ,[DocNbr_USE]
           ,[FA_BookFmt]
           ,[FA_PageFmt]
           ,[DocNbrSrce_II]
           ,[RecordingDt_II]
           ,[BookSrce_II]
           ,[PageSrce_II]
           ,[FA_DocNbrFmt_II]
           ,[FA_YearDocNbrFmt_II]
           ,[FA_YearDayDocNumFmt_II]
           ,[FA_DocNbrFmtCode_II]
           ,[FA_BookPageFmt_II]
           ,[FA_BookFmt_II]
           ,[FA_PageFmt_II]
           ,[FA_YearBookPageFmt_II]
           ,[FA_BookPageFmtCode_II]
           ,[FA_CMTID_DocNum_II]
           ,[FA_CMTID_YearDocNum_II]
           ,[FA_CMTID_YearDateDocNum_II]
           ,[FA_CMTID_BookPage_II]
           ,[FA_CMTID_YearBookPage_II]
           ,[CMTID_USE_II]
           ,[DocNbr_USE_II]
           ,[DocNbrSrce_III]
           ,[RecordingDt_III]
           ,[BookSrce_III]
           ,[PageSrce_III]
           ,[FA_DocNbrFmt_III]
           ,[FA_YearDocNbrFmt_III]
           ,[FA_YearDayDocNumFmt_III]
           ,[FA_DocNbrFmtCode_III]
           ,[FA_BookPageFmt_III]
           ,[FA_BookFmt_III]
           ,[FA_PageFmt_III]
           ,[FA_YearBookPageFmt_III]
           ,[FA_BookPageFmtCode_III]
           ,[FA_CMTID_DocNum_III]
           ,[FA_CMTID_YearDocNum_III]
           ,[FA_CMTID_YearDateDocNum_III]
           ,[FA_CMTID_BookPage_III]
           ,[FA_CMTID_YearBookPage_III]
           ,[CMTID_USE_III]
           ,[DocNbr_USE_III]
           ,[InData]
From [Global].[dbo].[Transaction_Master] with (nolock)
where fips = @fips  --between '01001' and '01999'
and filetype in ('m','d')

----  150 Get Property Address Temp

drop table [src_InfoTR].[dbo].[Prop_Address_ASSN_Work]

SELECT [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[APNSeqNbr]
      ,[UnformattedAPN]
      ,[OldAPN]
      ,[OLDAPNSeqNbr]
      ,[TaxAccountNumber]
      ,[RecordType]
      ,[VendorPID]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdHouseNbr2]
      ,[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusStdCarrierCode]
      ,[SitusCensusTract]
      ,[SitusCensusTractBlock]
      ,[SitusStdUnitType]
      ,[addresskey]
      ,[AddressKeyNoUnitType]
      ,[AddressKeyNoUnitTypeNoPlus4]
into [src_InfoTR].[dbo].[Prop_Address_ASSN_Work]
  FROM [src_InfoTR].[dbo].[Prop_Address]
  where fips = @fips

----  200 Get Release Data

Truncate Table [Data].[dbo].[Transaction_Release_Skinny]

INSERT INTO [dbo].[Transaction_Release_Skinny]
           ([FIPS]
           ,[ReleaseTransactionID]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[Recordingdt]
           ,[OrigDeedRecordingDt]
           ,[OrigDeedContractDt]
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[CurrentLenderBeneficiary]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
           ,[BorrowerFullName]
           ,[Borrower1CompanyName]
           ,[Borrower1CorpType]
           ,[Borrower1FirstName]
           ,[Borrower1LastName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1NoParsInd]
           ,[Borrower2CompanyName]
           ,[Borrower2CorpType]
           ,[Borrower2FirstName]
           ,[Borrower2LastName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2NoParsInd]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusFullStreetAddress]
           ,[SitusHouseNbr]
           ,[SitusHouseNbr2]
           ,[SitusHouseNbrSuffix]
           ,[SitusDirectionLeft]
           ,[SitusStreet]
           ,[SitusMode]
           ,[SitusDirectionRight]
           ,[SitusUnitNbr]
           ,[SitusCity]
           ,[SitusState]
           ,[SitusZIP5]
           ,[SitusZIP4]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FADeleteFlag]
		   ,[addresskey]
		   ,[addresskeyNoUnitType]
		   ,[addresskeyNoUnitTypeNoPlus4])
 Select 
            [FIPS]
           ,[TransactionID]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[Recordingdt]
           ,[OrigDeedRecordingDt]
           ,replace([OrigDeedContractDt],'PROVNOT','')
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[CurrentLenderBeneficiary]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
           ,[BorrowerFullName]
           ,[Borrower1CompanyName]
           ,[Borrower1CorpType]
           ,[Borrower1FirstName]
           ,[Borrower1LastName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1NoParsInd]
           ,[Borrower2CompanyName]
           ,[Borrower2CorpType]
           ,[Borrower2FirstName]
           ,[Borrower2LastName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2NoParsInd]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusFullStreetAddress]
           ,[SitusHouseNbr]
           ,[SitusHouseNbr2]
           ,[SitusHouseNbrSuffix]
           ,[SitusDirectionLeft]
           ,[SitusStreet]
           ,[SitusMode]
           ,[SitusDirectionRight]
           ,[SitusUnitNbr]
           ,[SitusCity]
           ,[SitusState]
           ,[SitusZIP5]
           ,[SitusZIP4]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FADeleteFlag]
		   ,Replicate('0',5-len(ltrim(rtrim([SitusZIP5])))) + [SitusZIP5] +
			Replicate('0',4-len(ltrim(rtrim([SitusZIP4])))) + [SitusZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionLeft])))) + [SitusDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusStreet])))) + [SitusStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionRight])))) + [SitusDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusMode])))) + [SitusMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusHouseNbr])))) + [SitusHouseNbr] +
			Replicate('0',6-len(ltrim(rtrim([SitusUnitType])))) + [SitusUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusUnitNbr])))) + [SitusUnitNbr]		   
		   ,Replicate('0',5-len(ltrim(rtrim([SitusZIP5])))) + [SitusZIP5] +
			Replicate('0',4-len(ltrim(rtrim([SitusZIP4])))) + [SitusZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionLeft])))) + [SitusDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusStreet])))) + [SitusStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionRight])))) + [SitusDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusMode])))) + [SitusMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusHouseNbr])))) + [SitusHouseNbr] +
			--Replicate('0',6-len(ltrim(rtrim([SitusUnitType])))) + [SitusUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusUnitNbr])))) + [SitusUnitNbr]
			,Replicate('0',5-len(ltrim(rtrim([SitusZIP5])))) + [SitusZIP5] +
			 --Replicate('0',4-len(ltrim(rtrim([SitusZIP4])))) + [SitusZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionLeft])))) + [SitusDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusStreet])))) + [SitusStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusDirectionRight])))) + [SitusDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusMode])))) + [SitusMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusHouseNbr])))) + [SitusHouseNbr] +
			--Replicate('0',6-len(ltrim(rtrim([SitusUnitType])))) + [SitusUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusUnitNbr])))) + [SitusUnitNbr] 
  FROM [Data].[dbo].[Release] with (Nolock)
  where fips = @fips
  --(len(ltrim(rtrim([OrigDeedRecordingDt]))) > 1 or Len(ltrim(rtrim([OrigDeedContractDt]))) > 1)
  --and
  --(len(ltrim(rtrim([OrigDeedDocNbr]))) > 1 or len(ltrim(rtrim([OrigDeedBook]))) > 1)
  --and RecordingDt between '20181001' and '20181031'
  --and (FAPropertyId is null
  --or (FADeedId is null
  --and FASAMId is null))

---   205 Match on APN

--  Match to Property
--  Direct Match
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With Dash and ending Zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-0000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-00'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-0'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With No Dash and ending Zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '0000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '00'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '0'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN Add Trailing Zeros 
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN ADD Trailing zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

---  205 Match on APN 2
--  Match to Property
--  Direct Match
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With Dash and ending Zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-0000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-00' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-0' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With No Dash and ending Zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '0000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '00' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '0' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN Add Trailing Zeros 
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN ADD Trailing zeros
UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '0000',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '000',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '00',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '0',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Release_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Release_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN] + '0',',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

---  206 Match Release on Address

  update [Data].[dbo].[Transaction_Release_Skinny]
  Set NewPropertyID = p.propertyid
  from [Data].[dbo].[Transaction_Release_Skinny] s
  join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] p
  on p.[addresskey] = s.[addresskey]
  where s.fapropertyid is null and s.newpropertyid is null
  and (s.SitusFullStreetAddress not like '' or  s.SitusFullStreetAddress is null)

---  207 Process Release Names

truncate table[DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc]

INSERT INTO [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc]
           ([ID]
           ,[Fips]
           ,[NameFormatType]
           ,[Name1])
Select
[ReleaseTransactionID]
,[FIPS]
,'1'
,Replace(Replace(ltrim(rtrim(substring([BorrowerFullName],1,100))),'.',''),',','')
from [Data].[dbo].[Transaction_Release_Skinny]

exec [DragonNameTest].dbo.[usp_name_parser_unifiedV8_1_Assn_Release] [NameWork_V8_1_Release_Proc]

update [Data].[dbo].[Transaction_Release_Skinny]
Set
       [Borrower1FirstName] = substring(p.[Name1First],1,40)
      ,[Borrower1LastName] = substring(p.[Name1Last],1,60)
      ,[Borrower1MiddleInitial] = substring(p.[Name1Middle],1,40)
      ,[Borrower1NoParsInd] = case when p.[Name1CorpInd] = 'Y' then '1' else null end
      ,[Borrower2FirstName] = p.[Name2First]
      ,[Borrower2LastName] = p.[Name2Last]
      ,[Borrower2MiddleInitial] = p.[Name2Middle]
      ,[Borrower2NoParsInd] = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then '1' else null end
	  ,Borrower1FullNameStd = case when p.[Name1CorpInd] = 'Y' then substring(p.[Name1],1,80) when [Name1fmt] like '' then null else [Name1fmt] end
	  ,Borrower2FullNameStd = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then substring([Name2],1,80) when [Name2fmt] like '' then null else [Name2fmt] end
from [Data].[dbo].[Transaction_Release_Skinny] s
join [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc] p
on p.id = s.ReleaseTransactionID

---  210 Process Release Document Numbers

Truncate table [Global].[dbo].[Transaction_Master_Temp2]

INSERT INTO [Global].[dbo].[Transaction_Master_Temp2]
           ([FIPS]
           ,[TransactionId]
           ,[DocNbrSrce]
           ,[RecordingDt]
		   ,FA_ContractDate
           ,[BookSrce]
           ,[PageSrce]
		   ,[FileType]
		   ,FAPropertyID)
Select 
			[FIPS]
           ,[ReleaseTransactionID]
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace(Replace([OrigDeedDocNbr],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'.',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-z]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace(case when len(ltrim(rtrim([OrigDeedRecordingDt]))) > 1 then [OrigDeedRecordingDt] else [OrigDeedContractDt] end,'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-z]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace([OrigDeedContractDt],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'.',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-z]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace([OrigDeedBook],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-z]',''),';','')
           ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(replace(Replace(Replace([OrigDeedPage],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-z]',''),';','')
		   ,'R'
		   ,FAPropertyID
From [data].[dbo].[Transaction_Release_Skinny]

Exec [global].dbo.[usp_DocumentNumberFormatting_Temp2]

Exec [global].dbo.[usp_DocumentNumberFormatting_MatchtoLoan_Temp2]

--  215 Update Release Document Numbers

UPDATE [Data].[dbo].[Transaction_Release_Skinny]
   SET 
       [Loan_FA_DocNbrFmt] = t.FA_DocNbrFmt
      ,[Loan_FA_YearDocNbrFmt] = t.FA_YearDocNbrFmt
      ,[Loan_FA_YearDayDocNumFmt] = t.FA_YearDayDocNumFmt
      ,[Loan_FA_DocNbrFmtCode] = t.FA_DocNbrFmtCode
      ,[Loan_FA_BookPageFmt] = t.FA_BookPageFmt
      ,[Loan_FA_YearBookPageFmt] = t.FA_YearBookPageFmt
      ,[Loan_FA_BookPageFmtCode] = t.FA_BookPageFmtCode
      ,[NewPropertyID] = case when [NewPropertyID] is null then t.[LinkPropertyID] else [NewPropertyID] end
      ,[NewDeedPID] = case when t.LinkFileType = 'd' then t.[LinkTransactionID] else null end
      ,[NewSAMPID] = case when t.LinkFileType = 'm' then t.[LinkTransactionID] else null end
      ,[NewLoanAmt] = t.[LinkAmount]
      ,[NewAssnLink] = case when t.LinkFileType = 'a' then t.[LinkTransactionID] else null end
      ,[NewReleaseLink] = case when t.LinkFileType = 'r' then t.[LinkTransactionID] else null end
from [Data].[dbo].[Transaction_Release_Skinny] s
Join [Global].[dbo].[Transaction_Master_Temp2] t
on t.fips = s.fips
and t.transactionid = s.ReleaseTransactionID

---  225 Match Release to Deed and Mortgage

Update [Data].[dbo].[Transaction_Release_Skinny]   --1
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --2
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan2Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --3
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --4
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan2Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

----  Mortgage
Update [Data].[dbo].[Transaction_Release_Skinny]  --5
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewSAMPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)	
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --6
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewSAMPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.ContractDate = s.[OrigDeedContractDt]
  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.ContractDate is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loose Matches
Update [Data].[dbo].[Transaction_Release_Skinny]  --7
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --8
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --9
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --10
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

----  Mortgage
Update [Data].[dbo].[Transaction_Release_Skinny]  --11
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --12
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --13
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --14
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.Contractdate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.Contractdate is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loose Matches
Update [Data].[dbo].[Transaction_Release_Skinny]  --15
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --16
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --17
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedContractDt] is not null)

Update [Data].[dbo].[Transaction_Release_Skinny]  --18
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loan Amounts
Update [Data].[dbo].[Transaction_Release_Skinny]  --19
set [NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FASAMId]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

Update [Data].[dbo].[Transaction_Release_Skinny]  --20
set [NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.NewSAMPID
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

---  Deed
Update [Data].[dbo].[Transaction_Release_Skinny]  --21
set [NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.Deed m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FADeedId]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

Update [Data].[dbo].[Transaction_Release_Skinny]  --22
set [NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Release_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[NewDeedPID]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

-----------------------------------------------
---  300 Get ASSN Data
-----------------------------------------------

Truncate Table [Data].[dbo].[Transaction_Assn_Skinny]

INSERT INTO [Data].[dbo].[Transaction_Assn_Skinny]
           ([FIPS]
           ,[AssnTransactionID]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[Recordingdt]
           ,[OrigDeedRecordingDt]
           ,[OrigDeedContractDt]
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[AssignorName]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
           ,[BorrowerFullName]
           ,[Borrower1CompanyName]
           ,[Borrower1CorpType]
           ,[Borrower1FirstName]
           ,[Borrower1LastName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1NoParsInd]
           ,[Borrower2CompanyName]
           ,[Borrower2CorpType]
           ,[Borrower2FirstName]
           ,[Borrower2LastName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2NoParsInd]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusSTDFullStreetAddress]
           ,[SitusSTDHouseNbr]
           ,[SitusSTDHouseNbr2]
           ,[SitusSTDHouseNbrSuffix]
           ,[SitusSTDDirectionLeft]
           ,[SitusSTDStreet]
           ,[SitusSTDMode]
           ,[SitusSTDDirectionRight]
           ,[SitusSTDUnitNbr]
           ,[SitusSTDCity]
           ,[SitusSTDState]
           ,[SitusSTDZIP5]
           ,[SitusSTDZIP4]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FADeleteFlag]
		    ,[addresskey]
           ,[addresskeyNoUnitType]
           ,[addresskeyNoUnitTypeNoPlus4])
 Select 
            [FIPS]
           ,[TransactionID]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[Recordingdt]
           ,[OrigDeedRecordingDt]
           ,[OrigDeedContractDt]
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[AssignorName]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
           ,[BorrowerFullName]
           ,[Borrower1CompanyName]
           ,[Borrower1CorpType]
           ,[Borrower1FirstName]
           ,[Borrower1LastName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1NoParsInd]
           ,[Borrower2CompanyName]
           ,[Borrower2CorpType]
           ,[Borrower2FirstName]
           ,[Borrower2LastName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2NoParsInd]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusSTDFullStreetAddress]
           ,[SitusSTDHouseNbr]
           ,[SitusSTDHouseNbr2]
           ,[SitusSTDHouseNbrSuffix]
           ,[SitusSTDDirectionLeft]
           ,[SitusSTDStreet]
           ,[SitusSTDMode]
           ,[SitusSTDDirectionRight]
           ,[SitusSTDUnitNbr]
           ,[SitusSTDCity]
           ,[SitusSTDState]
           ,[SitusSTDZIP5]
           ,[SitusSTDZIP4]
           ,[FATimestamp]
           ,[FAUserId]
           ,[FADeleteFlag]
		   ,Replicate('0',5-len(ltrim(rtrim([SitusSTDZIP5])))) + [SitusSTDZIP5] +
			Replicate('0',4-len(ltrim(rtrim([SitusSTDZIP4])))) + [SitusSTDZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionLeft])))) + [SitusSTDDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusSTDStreet])))) + [SitusSTDStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionRight])))) + [SitusSTDDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusSTDMode])))) + [SitusSTDMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusSTDHouseNbr])))) + [SitusSTDHouseNbr] +
			Replicate('0',6-len(ltrim(rtrim([SitusSTDUnitType])))) + [SitusSTDUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusSTDUnitNbr])))) + [SitusSTDUnitNbr]
			,Replicate('0',5-len(ltrim(rtrim([SitusSTDZIP5])))) + [SitusSTDZIP5] +
			Replicate('0',4-len(ltrim(rtrim([SitusSTDZIP4])))) + [SitusSTDZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionLeft])))) + [SitusSTDDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusSTDStreet])))) + [SitusSTDStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionRight])))) + [SitusSTDDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusSTDMode])))) + [SitusSTDMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusSTDHouseNbr])))) + [SitusSTDHouseNbr] +
			--Replicate('0',6-len(ltrim(rtrim([SitusSTDUnitType])))) + [SitusSTDUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusSTDUnitNbr])))) + [SitusSTDUnitNbr]
			,Replicate('0',5-len(ltrim(rtrim([SitusSTDZIP5])))) + [SitusSTDZIP5] +
			--Replicate('0',4-len(ltrim(rtrim([SitusSTDZIP4])))) + [SitusSTDZIP4] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionLeft])))) + [SitusSTDDirectionLeft] +
			Replicate('0',30-len(ltrim(rtrim([SitusSTDStreet])))) + [SitusSTDStreet] +
			Replicate('0',2-len(ltrim(rtrim([SitusSTDDirectionRight])))) + [SitusSTDDirectionRight] +
			Replicate('0',4-len(ltrim(rtrim([SitusSTDMode])))) + [SitusSTDMode] +
			Replicate('0',10-len(ltrim(rtrim([SitusSTDHouseNbr])))) + [SitusSTDHouseNbr] +
			--Replicate('0',6-len(ltrim(rtrim([SitusSTDUnitType])))) + [SitusSTDUnitType] +
			Replicate('0',8-len(ltrim(rtrim([SitusSTDUnitNbr])))) + [SitusSTDUnitNbr] 
  FROM [Data].[dbo].[Assignment] with (Nolock)
  where fips = @fips
  --and ((len(ltrim(rtrim([OrigDeedRecordingDt]))) > 1 or Len(ltrim(rtrim([OrigDeedContractDt]))) > 1)
  --and
  --(len(ltrim(rtrim([OrigDeedDocNbr]))) > 1 or len(ltrim(rtrim([OrigDeedBook]))) > 1)
  ----and RecordingDt between '20181001' and '20181031'
  --or (FAPropertyId is null
  --or (FADeedId is null
  --and FASAMId is null)))

---   305 Match on APN

--  Match to Property
--  Direct Match
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With Dash and ending Zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-0000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-00'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '-0'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With No Dash and ending Zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '0000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '000'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '00'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN] + '0'
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN Add Trailing Zeros 
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN ADD Trailing zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

---  305 Match on APN 2
--  Match to Property
--  Direct Match
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With Dash and ending Zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-0000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-00' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '-0' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  With No Dash and ending Zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '0000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '000' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '00' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] + '0' = o.[formattedAPN]
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from Property APN Add Trailing Zeros 
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '000',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '00',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and n.[APN] = Replace(replace(replace(o.[formattedAPN] + '0',',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN],',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN],',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

--  Remove Special Characters from both Prop APN and Property APN ADD Trailing zeros
UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '0000',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '000',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '00',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(replace(replace(n.[APN] + '0',',',''),'.',''),'-','') = Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)

UPDATE data.dbo.Transaction_Assn_Skinny
   SET 
      [NewPropertyID] = o.[PropertyID]
from data.dbo.Transaction_Assn_Skinny n
join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] o with (nolock)
on n.[Fips] = o.[Fips]
and Replace(Replace(replace(replace(n.[APN] + '0',',',''),'.',''),'-',''),' ','') = Replace(Replace(replace(replace(o.[formattedAPN],',',''),'.',''),'-',''),' ','')
where (n.[FAPropertyID] is null or n.[FAPropertyID] is not null)
and (o.[PropertyID] is not null and n.[NewPropertyID] is null)


--  306 Match Assn on Address

  update [Data].[dbo].[Transaction_Assn_Skinny]
  Set NewPropertyID = p.propertyid
  from [Data].[dbo].[Transaction_Assn_Skinny] s
  join [src_InfoTR].[dbo].[Prop_Address_ASSN_Work] p
  on p.[addresskey] = s.[addresskey]
  where s.fapropertyid is null and s.newpropertyid is null
  and (s.SitusStdFullStreetAddress not like '' or  s.SitusStdFullStreetAddress is null)

---  307 Process Release Names

truncate table[DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc]

INSERT INTO [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc]
           ([ID]
           ,[Fips]
           ,[NameFormatType]
           ,[Name1])
Select
[AssnTransactionID]
,[FIPS]
,'1'
,Replace(Replace(ltrim(rtrim(substring([BorrowerFullName],1,100))),'.',''),',','')
from [Data].[dbo].[Transaction_Assn_Skinny]

exec [DragonNameTest].dbo.[usp_name_parser_unifiedV8_1_Assn_Release] [NameWork_V8_1_Release_Proc]

update [Data].[dbo].[Transaction_Assn_Skinny]
Set
       [Borrower1FirstName] = substring(p.[Name1First],1,40)
      ,[Borrower1LastName] = substring(p.[Name1Last],1,60)
      ,[Borrower1MiddleInitial] = substring(p.[Name1Middle],1,40)
      ,[Borrower1NoParsInd] = case when p.[Name1CorpInd] = 'Y' then '1' else null end
      ,[Borrower2FirstName] = p.[Name2First]
      ,[Borrower2LastName] = p.[Name2Last]
      ,[Borrower2MiddleInitial] = p.[Name2Middle]
      ,[Borrower2NoParsInd] = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then '1' else null end
	  ,Borrower1FullNameStd = case when p.[Name1CorpInd] = 'Y' then substring(p.[Name1],1,80) when [Name1fmt] like '' then null else [Name1fmt] end
	  ,Borrower2FullNameStd = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then substring([Name2],1,80) when [Name2fmt] like '' then null else [Name2fmt] end
from [Data].[dbo].[Transaction_Assn_Skinny] s
join [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc] p
on p.id = s.AssnTransactionID

---  310 Process Release Document Numbers

Truncate table [Global].[dbo].[Transaction_Master_Temp2]

INSERT INTO [Global].[dbo].[Transaction_Master_Temp2]
           ([FIPS]
           ,[TransactionId]
           ,[DocNbrSrce]
           ,[RecordingDt]
		   ,FA_ContractDate
           ,[BookSrce]
           ,[PageSrce]
		   ,[FileType]
		   ,FAPropertyID)
Select 
			[FIPS]
           ,[AssnTransactionID]
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace(Replace([OrigDeedDocNbr],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'.',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-b]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace(case when len(ltrim(rtrim([OrigDeedRecordingDt]))) > 1 then [OrigDeedRecordingDt] else [OrigDeedContractDt] end,'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-b]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace([OrigDeedContractDt],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'.',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-b]',''),';','')
		   ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(Replace(Replace(Replace([OrigDeedBook],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-b]',''),';','')
           ,Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(replace(Replace(replace(Replace(Replace([OrigDeedPage],'&',''),'\',''),'-',''),'''',''),'<',''),'>',''),'?',''),'~',''),'*',''),'[a-z]',''),'=',''),'_',''),'[',''),'/',''),'[a-b]',''),';','')
		   ,'R'
		   ,FAPropertyID
From [Data].[dbo].[Transaction_Assn_Skinny]

Exec [global].dbo.[usp_DocumentNumberFormatting_Temp2]

Exec [global].dbo.[usp_DocumentNumberFormatting_MatchtoLoan_Temp2]

--  315 Update Release Document Numbers

UPDATE [Data].[dbo].[Transaction_Assn_Skinny]
   SET 
       [Loan_FA_DocNbrFmt] = t.FA_DocNbrFmt
      ,[Loan_FA_YearDocNbrFmt] = t.FA_YearDocNbrFmt
      ,[Loan_FA_YearDayDocNumFmt] = t.FA_YearDayDocNumFmt
      ,[Loan_FA_DocNbrFmtCode] = t.FA_DocNbrFmtCode
      ,[Loan_FA_BookPageFmt] = t.FA_BookPageFmt
      ,[Loan_FA_YearBookPageFmt] = t.FA_YearBookPageFmt
      ,[Loan_FA_BookPageFmtCode] = t.FA_BookPageFmtCode
      ,[NewPropertyID] = case when [NewPropertyID] is null then t.[LinkPropertyID] else [NewPropertyID] end
      ,[NewDeedPID] = case when t.LinkFileType = 'd' then t.[LinkTransactionID] else null end
      ,[NewSAMPID] = case when t.LinkFileType = 'm' then t.[LinkTransactionID] else null end
      ,[NewLoanAmt] = t.[LinkAmount]
      ,[NewAssnLink] = case when t.LinkFileType = 'a' then t.[LinkTransactionID] else null end
      ,[NewReleaseLink] = case when t.LinkFileType = 'r' then t.[LinkTransactionID] else null end
from [Data].[dbo].[Transaction_Assn_Skinny] s
Join [Global].[dbo].[Transaction_Master_Temp2] t
on t.fips = s.fips
and t.transactionid = s.AssnTransactionID

---  325 Match Release to Deed and Mortgage

Update [Data].[dbo].[Transaction_Assn_Skinny]   --1
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --2
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan2Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --3
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --4
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan2Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

----  Mortgage
Update [Data].[dbo].[Transaction_Assn_Skinny]  --5
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewSAMPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)	
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --6
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewSAMPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.ContractDate = s.[OrigDeedContractDt]
  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and m.fips = @fips
	  and (m.ContractDate is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loose Matches
Update [Data].[dbo].[Transaction_Assn_Skinny]  --7
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --8
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --9
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --10
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.Saledate is not null and s.[OrigDeedContractDt] is not null)

----  Mortgage
Update [Data].[dbo].[Transaction_Assn_Skinny]  --11
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --12
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --13
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --14
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.Contractdate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and ([NewPropertyID] = m.fapropertyID or s.[FAPropertyID] = m.fapropertyID)
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.Contractdate is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loose Matches
Update [Data].[dbo].[Transaction_Assn_Skinny]  --15
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --16
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedRecordingDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --17
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
	  and (m.recordingdt is not null and s.[OrigDeedContractDt] is not null)

Update [Data].[dbo].[Transaction_Assn_Skinny]  --18
Set 
       [NewPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else [NewPropertyID] end
      ,[NewDeedPID] = m.TransactionId
      ,[NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      and [NewDeedPID] is null
      and [NewSAMPID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips
	  and(m.recordingdt is not null and s.[OrigDeedContractDt] is not null)

-----  Get Loan Amounts
Update [Data].[dbo].[Transaction_Assn_Skinny]  --19
set [NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FASAMId]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

Update [Data].[dbo].[Transaction_Assn_Skinny]  --20
set [NewLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.NewSAMPID
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

---  Deed
Update [Data].[dbo].[Transaction_Assn_Skinny]  --21
set [NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.Deed m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FADeedId]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

Update [Data].[dbo].[Transaction_Assn_Skinny]  --22
set [NewLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[NewDeedPID]
    where m.fips = @fips
	and ([NewLoanAmt] is null or [NewLoanAmt] = '0')

------------  End of Processing before Data Update
------------  Need to Add Data Update below this line

--  Update Data Tables
--  Release
  update data.dbo.Release
  Set FAPropertyId = [NewPropertyID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing PropID'
  from data.dbo.Release a
  join [Data].[dbo].[Transaction_Release_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.ReleaseTransactionID
    where s.fapropertyid is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewPropertyID] is not null

  update data.dbo.Release
  Set [FADeedId] = [NewDeedPID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing DeedID'
  from data.dbo.Release a
  join [Data].[dbo].[Transaction_Release_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.ReleaseTransactionID
    where s.[FADeedId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewDeedPID] is not null

  update data.dbo.Release
  Set [FASAMId] = [NewSAMPID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing SAMID'
  from data.dbo.Release a
  join [Data].[dbo].[Transaction_Release_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.ReleaseTransactionID
    where s.[FASAMId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewSAMPID] is not null

  update data.dbo.Release
  Set [OrigLoanAmt] = [NewLoanAmt]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing LoanAmt'
  from data.dbo.Release a
  join [Data].[dbo].[Transaction_Release_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.ReleaseTransactionID
    where s.[FASAMId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and (a.[OrigLoanAmt] is null or a.[OrigLoanAmt] = '0') 
  and cast([NewLoanAmt] as bigint) between 1 and 99999999

update data.dbo.Release
 Set   [Loan_FA_DocNbrFmt] =s.[Loan_FA_DocNbrFmt]
      ,[Loan_FA_YearDocNbrFmt] = s.[Loan_FA_YearDocNbrFmt]
      ,[Loan_FA_YearDayDocNumFmt] = s.[Loan_FA_YearDayDocNumFmt]
      ,[Loan_FA_DocNbrFmtCode] = s.[Loan_FA_DocNbrFmtCode]
      ,[Loan_FA_BookPageFmt] = s.[Loan_FA_BookPageFmt]
      ,[Loan_FA_YearBookPageFmt] = s.[Loan_FA_YearBookPageFmt]
      ,[Loan_FA_BookPageFmtCode] = s.[Loan_FA_BookPageFmtCode]
      ,[Loan_TransactionId] = case when [NewDeedPID] is not null then [NewDeedPID] when [NewSAMPID] is not null then [NewSAMPID] else null end
      ,[Loan_PropertyID] = [NewPropertyID]
      ,[Borrower1FullNameStd] = s.[Borrower1FullNameStd]
      ,[Borrower2FullNameStd] = s.[Borrower2FullNameStd]
      ,[Borrower1FirstName] = s.[Borrower1FirstName]
      ,[Borrower1LastName] = s.[Borrower1LastName]
      ,[Borrower1MiddleInitial] = s.[Borrower1MiddleInitial]
      ,[Borrower1NoParsInd] = s.[Borrower1NoParsInd]
      ,[Borrower2FirstName] = s.[Borrower2FirstName]
      ,[Borrower2LastName] = s.[Borrower2LastName]
      ,[Borrower2MiddleInitial] = s.[Borrower2MiddleInitial]
      ,[Borrower2NoParsInd] = s.[Borrower2NoParsInd]
  from data.dbo.Release a
  join [Data].[dbo].[Transaction_Release_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.ReleaseTransactionID

--  Assn

  update data.dbo.Assignment
  Set FAPropertyId = [NewPropertyID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing PropID'
  from data.dbo.Assignment a
  join [Data].[dbo].[Transaction_Assn_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.AssnTransactionID
    where s.fapropertyid is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewPropertyID] is not null

  update data.dbo.Assignment
  Set [FADeedId] = [NewDeedPID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing DeedID'
  from data.dbo.Assignment a
  join [Data].[dbo].[Transaction_assn_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.assnTransactionID
    where s.[FADeedId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewDeedPID] is not null

  update data.dbo.Assignment
  Set [FASAMId] = [NewSAMPID]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing SAMID'
  from data.dbo.Assignment a
  join [Data].[dbo].[Transaction_assn_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.assnTransactionID
    where s.[FASAMId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and [NewSAMPID] is not null

  update data.dbo.Assignment
  Set [OrigLoanAmt] = [NewLoanAmt]
  ,FATimestamp = GetDate() +1
  ,FAUserID = 'Assn and Release Update Processing LoanAmt'
  from data.dbo.Assignment a
  join [Data].[dbo].[Transaction_assn_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.assnTransactionID
    where s.[FASAMId] is null
  --and a.RecordingDt between '20181001' and '20181031'
  and (a.[OrigLoanAmt] is null or a.[OrigLoanAmt] = '0') 
  and cast([NewLoanAmt] as bigint) between 1 and 99999999

update data.dbo.Assignment
 Set   [Loan_FA_DocNbrFmt] =s.[Loan_FA_DocNbrFmt]
      ,[Loan_FA_YearDocNbrFmt] = s.[Loan_FA_YearDocNbrFmt]
      ,[Loan_FA_YearDayDocNumFmt] = s.[Loan_FA_YearDayDocNumFmt]
      ,[Loan_FA_DocNbrFmtCode] = s.[Loan_FA_DocNbrFmtCode]
      ,[Loan_FA_BookPageFmt] = s.[Loan_FA_BookPageFmt]
      ,[Loan_FA_YearBookPageFmt] = s.[Loan_FA_YearBookPageFmt]
      ,[Loan_FA_BookPageFmtCode] = s.[Loan_FA_BookPageFmtCode]
      ,[Loan_TransactionId] = case when [NewDeedPID] is not null then [NewDeedPID] when [NewSAMPID] is not null then [NewSAMPID] else null end
      ,[Loan_PropertyID] = [NewPropertyID]
      ,[Borrower1FullNameStd] = s.[Borrower1FullNameStd]
      ,[Borrower2FullNameStd] = s.[Borrower2FullNameStd]
      ,[Borrower1FirstName] = s.[Borrower1FirstName]
      ,[Borrower1LastName] = s.[Borrower1LastName]
      ,[Borrower1MiddleInitial] = s.[Borrower1MiddleInitial]
      ,[Borrower1NoParsInd] = s.[Borrower1NoParsInd]
      ,[Borrower2FirstName] = s.[Borrower2FirstName]
      ,[Borrower2LastName] = s.[Borrower2LastName]
      ,[Borrower2MiddleInitial] = s.[Borrower2MiddleInitial]
      ,[Borrower2NoParsInd] = s.[Borrower2NoParsInd]
  from data.dbo.Assignment a
  join [Data].[dbo].[Transaction_Assn_Skinny] s
  on a.fips = s.fips
  and a.TransactionId = s.AssnTransactionID

---  Append Property ID's to Process
--- Release
----  Get PropertyID for New Matched Data
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'R'
FROM [Data].[dbo].[Transaction_Release_Skinny]
where (fapropertyid is null and [NewPropertyID] is not null) 

----  Get PropertyID's for New Matched Deed TransactionID
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'R'
FROM [Data].[dbo].[Transaction_Release_Skinny]
where (fadeedid is null and NewDeedPID is not null)
      and (fapropertyid is not null or [NewPropertyID] is not null)

----  Get PropertyID's for New Matched SAM TransactionID
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'R'
FROM [Data].[dbo].[Transaction_Release_Skinny]
where (faSamid is null and [NewSAMPID] is not null)
       and (fapropertyid is not null or [NewPropertyID] is not null)

---  Assn
----  Get PropertyID for New Matched Data
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'A'
FROM [Data].[dbo].[Transaction_Assn_Skinny]
where (fapropertyid is null and [NewPropertyID] is not null) 

----  Get PropertyID's for New Matched Deed TransactionID
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'A'
FROM [Data].[dbo].[Transaction_Assn_Skinny]
where (fadeedid is null and NewDeedPID is not null)
      and (fapropertyid is not null or [NewPropertyID] is not null)

----  Get PropertyID's for New Matched SAM TransactionID
INSERT INTO [Data].[dbo].[DailyPropID_II]
           ([FIPS]
           ,[PropertyID]
           ,[FADateReceived]
           ,[SrcID])
Select 
 Fips
,Coalesce(FAPropertyID,NewPropertyID)
,Convert( varchar (8),GetDate(),112)
,'A'
FROM [Data].[dbo].[Transaction_Assn_Skinny]
where (faSamid is null and [NewSAMPID] is not null)
       and (fapropertyid is not null or [NewPropertyID] is not null)

---  Get Skinny Mortgage Records
---  Release
INSERT INTO [Data].[dbo].[Transaction_Mtg_Skinny]
           ([FIPS]
           ,[PropertyID]
           ,[formattedAPN]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusFullStreetAddress]
           ,[SitusHouseNbr]
           ,[SitusHouseNbr2]
           ,[SitusHouseNbrSuffix]
           ,[SitusDirectionLeft]
           ,[SitusStreet]
           ,[SitusMode]
           ,[SitusDirectionRight]
           ,[SitusUnitNbr]
           ,[SitusCity]
           ,[SitusState]
           ,[SitusZIP5]
           ,[SitusZIP4]
           ,[BestDate]
           ,[RecordingDt]
           ,[ContractDt]
           ,[LoanType]
           ,[DocType]
           ,[Loan_FA_DocNbrFmt]
           ,[Loan_FA_YearDocNbrFmt]
           ,[Loan_FA_YearDayDocNumFmt]
           ,[Loan_FA_DocNbrFmtCode]
           ,[Loan_FA_BookPageFmt]
           ,[Loan_FA_YearBookPageFmt]
           ,[Loan_FA_BookPageFmtCode]
           ,[DocNbrSrce]
           ,[BookSrce]
           ,[PageSrce]
           ,[LoanAmount]
           ,[LenderName]
           ,[CurrentLenderName]
           ,[LoanNbr]
           ,[MERNumber]
           ,[BorrowerFullName]
           ,[Borrower1FullNameStd]
           ,[Borrower1FirstName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1LastName]
           ,[Borrower1NoParsInd]
           ,[Borrower2FullNameStd]
           ,[Borrower2FirstName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2LastName]
           ,[Borrower2NoParsInd]
           ,[NewReleaseLink]
           ,[NewAssnLink]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[NewPropertyID]
           ,[NewDeedPID]
           ,[NewSAMPID]
           ,[NewLoanAmt]
           ,[Assn_ReleaseRecordingDt]
           ,[OrigDeedRecordingDt]
           ,[OrigDeedContractDt]
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[CurrentLenderBeneficiary]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
		   ,FASourceIND
           ,[addresskey]
           ,[addresskeyNoUnitType]
           ,[addresskeyNoUnitTypeNoPlus4])
SELECT s.[FIPS]
      ,coalesce([FAPropertyId],[NewPropertyID]) as PropertyID
      --,case when [APN] like '' or [APN] is null then formattedAPN else [APN] end as APN
	  ,formattedAPN
	  ,[APN]
      ,[APNSrce]
      ,[MultiAPNCode]
	  ,case when s.[SitusFullStreetAddress] like '' then p.[SitusStdFullStreetAddress] else [SitusFullStreetAddress] end as [SitusFullStreetAddress]
      ,case when [SitusHouseNbr] like '' then p.[SitusStdHouseNbr] else [SitusHouseNbr] end as [SitusHouseNbr]
      ,case when [SitusHouseNbr2] like '' then p.[SitusStdHouseNbr2] else [SitusHouseNbr2] end as [SitusHouseNbr2]
      ,case when [SitusHouseNbrSuffix] like '' then [SitusStdHouseNbrSuffix] else [SitusHouseNbrSuffix] end as [SitusHouseNbrSuffix]
      ,case when [SitusDirectionLeft] like '' then [SitusStdDirectionLeft] else [SitusDirectionLeft] end as [SitusDirectionLeft]
      ,case when [SitusStreet] like '' then [SitusStdStreet] else [SitusStreet] end as [SitusStreet]
      ,case when [SitusMode] like '' then [SitusStdMode] else [SitusMode] end as [SitusMode]
      ,case when [SitusDirectionRight] like '' then [SitusStdDirectionRight] else [SitusDirectionRight] end as [SitusDirectionRight]
      ,case when [SitusUnitNbr] like '' then [SitusStdUnitNbr] else [SitusUnitNbr] end as [SitusUnitNbr]
      ,case when [SitusCity] like '' then [SitusStdCity] else [SitusCity] end as [SitusCity]
      ,case when [SitusState] like '' then [SitusStdState] else [SitusState] end as [SitusState]
      ,case when [SitusZIP5] like '' then [SitusStdZIP5] else [SitusZIP5] end as [SitusZIP5]
      ,case when [SitusZIP4] like '' then [SitusStdZIP4] else [SitusZIP4] end as [SitusZIP4]
	  ,coalesce([OrigDeedRecordingDt],[OrigDeedContractDt]) as BestDate
      ,[OrigDeedRecordingDt] as RecordingDt
	  ,[OrigDeedContractDt] as ContractDt
	  ,'27' as LoanType
	  ,'H' as DocType
	  ,[Loan_FA_DocNbrFmt]
      ,[Loan_FA_YearDocNbrFmt]
      ,[Loan_FA_YearDayDocNumFmt]
      ,[Loan_FA_DocNbrFmtCode]
      ,[Loan_FA_BookPageFmt]
      ,[Loan_FA_YearBookPageFmt]
      ,[Loan_FA_BookPageFmtCode]
      ,[OrigDeedDocNbr] as DocNbrSrce
      ,[OrigDeedBook] as BookSrce
      ,[OrigDeedPage] as PageSrce
      ,[OrigLoanAmt] as LoanAmount
      ,[OrigLenderBen] as LenderName
      ,[CurrentLenderBeneficiary] as CurrentLenderName
	  ,[LoanNumber] as LoanNbr
      ,[MERS] as MERNumber
	  ,[BorrowerFullName]
      ,[Borrower1FullNameStd]
	  ,[Borrower1FirstName]
	  ,[Borrower1MiddleInitial]
      ,[Borrower1LastName]
      ,[Borrower1NoParsInd]
      ,[Borrower2FullNameStd]
      ,[Borrower2FirstName]
	  ,[Borrower2MiddleInitial]
      ,[Borrower2LastName]
      ,[Borrower2NoParsInd]

----  Assignment and Release Data
	  ,[ReleaseTransactionID] as [NewReleaseLink]
	  ,cast(null as bigint) as [NewAssnLink]
	  ,[FAPropertyId]
	  ,[FADeedId]
      ,[FASAMId]
	  ,[NewPropertyID]
      ,[NewDeedPID]
      ,[NewSAMPID]
      ,[NewLoanAmt]
      ,[Recordingdt] as Assn_ReleaseRecordingDt
      ,[OrigDeedRecordingDt]
      ,[OrigDeedContractDt]
      ,[OrigDeedDocNbr]
      ,[OrigDeedBook]
      ,[OrigDeedPage]
      ,[OrigLoanAmt]
      ,[OrigLenderBen]
      ,[CurrentLenderBeneficiary]
      ,[LoanNumber]
      ,[MERS]
      ,[MERSValidation]
      ,[MSPSvcrLoan]
	  ,'R' as FASourceIND

----  Address Link Fields
      ,[addresskey]
      ,[addresskeyNoUnitType]
      ,[addresskeyNoUnitTypeNoPlus4]
--Into data.dbo.Transaction_Mtg_Skinny
  FROM [Data].[dbo].[Transaction_Release_Skinny] s with (nolock)
  join data.dbo.property p with (nolock)
  on p.fips = s.fips
  and p.propertyid = coalesce([FAPropertyId],[NewPropertyID])
  where 
      fadeedid is null
  and FASamID is null
  and [NewDeedPID] is null
  and [NewSAMPID] is null
  and (FApropertyid is not null or NewPropertyid is not null)
  and ([OrigDeedRecordingDt] is not null or [OrigDeedContractDt] is not null)

---  Assn
INSERT INTO [Data].[dbo].[Transaction_Mtg_Skinny]
           ([FIPS]
           ,[PropertyID]
           ,[formattedAPN]
           ,[APN]
           ,[APNSrce]
           ,[MultiAPNCode]
           ,[SitusFullStreetAddress]
           ,[SitusHouseNbr]
           ,[SitusHouseNbr2]
           ,[SitusHouseNbrSuffix]
           ,[SitusDirectionLeft]
           ,[SitusStreet]
           ,[SitusMode]
           ,[SitusDirectionRight]
           ,[SitusUnitNbr]
           ,[SitusCity]
           ,[SitusState]
           ,[SitusZIP5]
           ,[SitusZIP4]
           ,[BestDate]
           ,[RecordingDt]
           ,[ContractDt]
           ,[LoanType]
           ,[DocType]
           ,[Loan_FA_DocNbrFmt]
           ,[Loan_FA_YearDocNbrFmt]
           ,[Loan_FA_YearDayDocNumFmt]
           ,[Loan_FA_DocNbrFmtCode]
           ,[Loan_FA_BookPageFmt]
           ,[Loan_FA_YearBookPageFmt]
           ,[Loan_FA_BookPageFmtCode]
           ,[DocNbrSrce]
           ,[BookSrce]
           ,[PageSrce]
           ,[LoanAmount]
           ,[LenderName]
           ,[CurrentLenderName]
           ,[LoanNbr]
           ,[MERNumber]
           ,[BorrowerFullName]
           ,[Borrower1FullNameStd]
           ,[Borrower1FirstName]
           ,[Borrower1MiddleInitial]
           ,[Borrower1LastName]
           ,[Borrower1NoParsInd]
           ,[Borrower2FullNameStd]
           ,[Borrower2FirstName]
           ,[Borrower2MiddleInitial]
           ,[Borrower2LastName]
           ,[Borrower2NoParsInd]
           ,[NewReleaseLink]
           ,[NewAssnLink]
           ,[FAPropertyId]
           ,[FADeedId]
           ,[FASAMId]
           ,[NewPropertyID]
           ,[NewDeedPID]
           ,[NewSAMPID]
           ,[NewLoanAmt]
           ,[Assn_ReleaseRecordingDt]
           ,[OrigDeedRecordingDt]
           ,[OrigDeedContractDt]
           ,[OrigDeedDocNbr]
           ,[OrigDeedBook]
           ,[OrigDeedPage]
           ,[OrigLoanAmt]
           ,[OrigLenderBen]
           ,[CurrentLenderBeneficiary]
           ,[LoanNumber]
           ,[MERS]
           ,[MERSValidation]
           ,[MSPSvcrLoan]
		   ,FASourceIND
           ,[addresskey]
           ,[addresskeyNoUnitType]
           ,[addresskeyNoUnitTypeNoPlus4])
SELECT s.[FIPS]
      ,coalesce([FAPropertyId],[NewPropertyID]) as PropertyID
      --,case when [APN] like '' or [APN] is null then formattedAPN else [APN] end as APN
	  ,formattedAPN
	  ,[APN]
      ,[APNSrce]
      ,[MultiAPNCode]
	  ,case when s.[SitusStdFullStreetAddress] like '' then p.[SitusStdFullStreetAddress] else s.[SitusStdFullStreetAddress] end as [SitusFullStreetAddress]
      ,case when s.[SitusStdHouseNbr] like '' then p.[SitusStdHouseNbr] else s.[SitusStdHouseNbr] end as [SitusHouseNbr]
      ,case when s.[SitusStdHouseNbr2] like '' then p.[SitusStdHouseNbr2] else s.[SitusStdHouseNbr2] end as [SitusHouseNbr2]
      ,case when s.[SitusStdHouseNbrSuffix] like '' then p.[SitusStdHouseNbrSuffix] else s.[SitusStdHouseNbrSuffix] end as [SitusHouseNbrSuffix]
      ,case when s.[SitusStdDirectionLeft] like '' then p.[SitusStdDirectionLeft] else s.[SitusStdDirectionLeft]  end as [SitusDirectionLeft]
      ,case when s.[SitusStdStreet] like '' then p.[SitusStdStreet] else s.[SitusStdStreet] end as [SitusStreet]
      ,case when s.[SitusStdMode] like '' then p.[SitusStdMode] else s.[SitusStdMode] end as [SitusMode]
      ,case when s.[SitusStdDirectionRight] like '' then p.[SitusStdDirectionRight] else s.[SitusStdDirectionRight] end as [SitusDirectionRight]
      ,case when s.[SitusStdUnitNbr] like '' then p.[SitusStdUnitNbr] else s.[SitusStdUnitNbr] end as [SitusUnitNbr]
      ,case when s.[SitusStdCity] like '' then p.[SitusStdCity] else s.[SitusStdCity] end as [SitusCity]
      ,case when s.[SitusStdState] like '' then p.[SitusStdState] else s.[SitusStdState] end as [SitusState]
      ,case when s.[SitusStdZIP5] like '' then p.[SitusStdZIP5] else s.[SitusStdZIP5] end as [SitusZIP5]
      ,case when s.[SitusStdZIP4] like '' then p.[SitusStdZIP4] else s.[SitusStdZIP4] end as [SitusZIP4]
	  ,coalesce([OrigDeedRecordingDt],[OrigDeedContractDt]) as BestDate
      ,[OrigDeedRecordingDt] as RecordingDt
	  ,[OrigDeedContractDt] as ContractDt
	  ,'27' as LoanType
	  ,'H' as DocType
	  ,[Loan_FA_DocNbrFmt]
      ,[Loan_FA_YearDocNbrFmt]
      ,[Loan_FA_YearDayDocNumFmt]
      ,[Loan_FA_DocNbrFmtCode]
      ,[Loan_FA_BookPageFmt]
      ,[Loan_FA_YearBookPageFmt]
      ,[Loan_FA_BookPageFmtCode]
      ,[OrigDeedDocNbr] as DocNbrSrce
      ,[OrigDeedBook] as BookSrce
      ,[OrigDeedPage] as PageSrce
      ,[OrigLoanAmt] as LoanAmount
      ,[OrigLenderBen] as LenderName
      ,[AssignorName] as CurrentLenderName
	  ,[LoanNumber] as LoanNbr
      ,[MERS] as MERNumber
	  ,[BorrowerFullName]
      ,[Borrower1FullNameStd]
	  ,[Borrower1FirstName]
	  ,[Borrower1MiddleInitial]
      ,[Borrower1LastName]
      ,[Borrower1NoParsInd]
      ,[Borrower2FullNameStd]
      ,[Borrower2FirstName]
	  ,[Borrower2MiddleInitial]
      ,[Borrower2LastName]
      ,[Borrower2NoParsInd]

----  Assignment and Release Data
	  ,cast(null as bigint)as [NewReleaseLink]
	  ,[AssnTransactionID] as [NewAssnLink]
	  --,cast(null as bigint) as [NewAssnLink]
	  ,[FAPropertyId]
	  ,[FADeedId]
      ,[FASAMId]
	  ,[NewPropertyID]
      ,[NewDeedPID]
      ,[NewSAMPID]
      ,[NewLoanAmt]
      ,[Recordingdt] as Assn_ReleaseRecordingDt
      ,[OrigDeedRecordingDt]
      ,[OrigDeedContractDt]
      ,[OrigDeedDocNbr]
      ,[OrigDeedBook]
      ,[OrigDeedPage]
      ,[OrigLoanAmt]
      ,[OrigLenderBen]
      ,[AssignorName]
      ,[LoanNumber]
      ,[MERS]
      ,[MERSValidation]
      ,[MSPSvcrLoan]
	  ,'A' as FASourceIND
----  Address Link Fields
      ,[addresskey]
      ,[addresskeyNoUnitType]
      ,[addresskeyNoUnitTypeNoPlus4]
--Into data.dbo.Transaction_Mtg_Skinny
  FROM [Data].[dbo].[Transaction_Assn_Skinny] s with (nolock)
  join data.dbo.property p with (nolock)
  on p.fips = s.fips
  and p.propertyid = coalesce([FAPropertyId],[NewPropertyID])
  where 
      fadeedid is null
  and FASamID is null
  and [NewDeedPID] is null
  and [NewSAMPID] is null
  and (FApropertyid is not null or NewPropertyid is not null)
  and ([OrigDeedRecordingDt] is not null or [OrigDeedContractDt] is not null)

---  This is the End of Processing

END

