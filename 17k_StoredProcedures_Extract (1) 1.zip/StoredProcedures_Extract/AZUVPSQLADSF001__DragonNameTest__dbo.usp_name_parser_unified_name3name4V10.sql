SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20181022
-- =============================================
CREATE PROCEDURE [dbo].[usp_name_parser_unified_name3name4V10] @tableName varchar(255), @RowCounts varchar(1) = 'Y'

AS
BEGIN

SET CONCAT_NULL_YIELDS_NULL OFF

IF @RowCounts = 'N'
    BEGIN
    -- added for v7 to suppress count results
	SET NOCOUNT ON
	END
ELSE
    BEGIN
    -- added for v7 to not suppress count results
    SET NOCOUNT OFF
	END

   declare @sql varchar(max) = ''
   

   --------------------------------------------------------------------- Section pull out Name3 and Name4 names v10.2 --------------------------------------------
   /*
   -- name3 -- no '&' nor ' and ' in name1 and '&' in name2 -------------------------------
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, LTRIM(SUBSTRING(AssesseeName2,CHARINDEX('&',AssesseeName2)+1,len(AssesseeName2))) as name3 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and AssesseeName not like '%&%' and AssesseeName not like '% and %' and AssesseeName2 like '%&%'
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = LTRIM(SUBSTRING(Name2,CHARINDEX(''&'',Name2)+1,len(Name2)))
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and Name1 not like ''%&%'' and Name1 not like ''% and %'' and Name2 like ''%&%'''
   --print (@sql)
   exec(@sql)

   /*
   -- name3 -- no '&' nor ' and ' in name1 and ' and ' in name2 -------------------------------
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, LTRIM(SUBSTRING(AssesseeName2,CHARINDEX(' and ',AssesseeName2)+5,len(AssesseeName2))) as name3 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and AssesseeName not like '%&%' and AssesseeName not like '% and %' and AssesseeName2 like '% and %'
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = LTRIM(SUBSTRING(Name2,CHARINDEX('' and '',Name2)+5,len(Name2)))
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and Name1 not like ''%&%'' and Name1 not like ''% and %'' and Name2 like ''% and %'''
  --print (@sql)
   exec(@sql)

   /*
   -- name3 -- '&' or ' and ' in name1 and no '&' nor ' and ' in name2 -------------------------------
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, RTRIM(SUBSTRING(AssesseeName2,1,CHARINDEX('&',AssesseeName2)-1)) as name3 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and (AssesseeName like '% and %' or AssesseeName like '%&%') and AssesseeName2 like '%&%'
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = RTRIM(SUBSTRING(Name2,1,CHARINDEX(''&'',Name2)-1))
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and (Name1 like ''% and %'' or Name1 like ''%&%'') and Name2 like ''%&%'''
  --print (@sql)
   exec(@sql)

   /*
   -- name3 -- '&' or ' and ' in name1 and no '&' nor ' and ' in name2 -------------------------------
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, RTRIM(SUBSTRING(AssesseeName2,1,CHARINDEX(' and ',AssesseeName2)-1)) as name3 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and (AssesseeName like '% and %' or AssesseeName like '%&%') and AssesseeName2 like '% and %'
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = RTRIM(SUBSTRING(Name2,1,CHARINDEX('' and '',Name2)-1))
   where Name1 is not null and Name2 is not null and Name1 != '' and Name2 != '' and (Name1 like ''% and %'' or Name1 like ''%&%'') and Name2 like ''% and %'''
  --print (@sql)
   exec(@sql)

   /*
   -- name3 -- '&' and ' and ' in name1 and '&' and ' and ' in name2 -------------------------------
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, AssesseeName2 as name3 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and (AssesseeName like '%&%' or AssesseeName like '% and %') and AssesseeName2 not like '%&%' and AssesseeName2 not like '% and %' 
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = Name2
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and (Name1 like ''%&%'' or Name1 like ''% and %'') and Name2 not like ''%&%'' and Name2 not like ''% and %''' 
   --print (@sql)
   exec(@sql)

   /*
   -- name4 -- '&' and ' and ' in name1 and '&' and ' and ' in name2
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, RTRIM(SUBSTRING(AssesseeName2,CHARINDEX('&',AssesseeName2)+1,len(AssesseeName2))) as name4 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and (AssesseeName like '%&%' or AssesseeName like '% and %') and AssesseeName2 like '%&%'
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name4 = RTRIM(SUBSTRING(Name2,CHARINDEX(''&'',Name2)+1,len(Name2)))
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and (Name1 like ''%&%'' or Name1 like ''% and %'') and Name2 like ''%&%'''
   --print (@sql)
   exec(@sql)

   /*
   -- name4 -- '&' and ' and ' in name1 and '&' and ' and ' in name2
   select top 1000 PID,FIPS,AssesseeName, AssesseeName2, RTRIM(SUBSTRING(AssesseeName2,CHARINDEX(' and ',AssesseeName2)+5,len(AssesseeName2))) as name4 from Staging_Archive.dbo.md_ref_assessments with (nolock)
   where AssesseeName is not null and AssesseeName2 is not null and AssesseeName != '' and AssesseeName2 != '' and (AssesseeName like '%&%' or AssesseeName like '% and %') and AssesseeName2 like '% and %' 
   */
   set @sql = 'update [dbo].['+@tableName+']
   set Name4 = RTRIM(SUBSTRING(Name2,CHARINDEX('' and '',Name2)+5,len(Name2)))
   where Name1 is not null and Name2 is not null and Name1 != '''' and Name2 != '''' and (Name1 like ''%&%'' or Name1 like ''% and %'') and Name2 like ''% and %''' 
   --print (@sql)
   exec(@sql)


--------------------------------------------------------------------- Section Processing corporate Name3 and Name4 ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = ltrim(rtrim([Name3])), Name4 = ltrim(rtrim([Name4]))--, COName = ltrim(rtrim([COName]))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = substring(Replace(Replace(ltrim(rtrim([Name3])),'';'','' & ''),''  '','' ''),1,100)
   where Name3 like ''%;%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4 = substring(Replace(Replace(ltrim(rtrim([Name4])),'';'','' & ''),''  '','' ''),1,100)
   where Name4 like ''%;%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3 = substring(Replace([Name3],'' SURV'',''''),1,100)
   where Name3 like ''% SURV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4 = substring(Replace([Name4],'' SURV'',''''),1,100)
   where Name4 like ''% SURV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   where [Name3] Like ''%See ACCT%'' or [Name3] Like ''%See-ACCT%'''
   exec(@sql)

   --set @sql = 'update [dbo].['+@tableName+']
   --set Name3CorpInd = ''Y'', [Name3TrustInd] = ''Y''
   --where [NameIDCode] in (''TR'',''TS'',''RT'',''RL'',''LV'',''LE'',''LT'',''IR'',''IL'',''FL'',''FM'',''FR'',''ES'')'
   --exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name3],1,(charindex('' '',[Name3])))
   where [BeginsWith] is not null and Name3CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name3]),1,(charindex('' '',reverse([Name3])))))
   where [EndsWith] is not null	and Name3CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on [Name3] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name3CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name3]))
   where [Only] is not null and Name3CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Name3])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and Name3CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name4],1,(charindex('' '',[Name4])))
   where [BeginsWith] is not null and ([Name4] is not null and [Name4] not like '''') and Name4CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name4]),1,(charindex('' '',reverse([Name4])))))
   where [EndsWith] is not null and ([Name4] is not null and [Name4] not like '''') and Name4CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on [Name4] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name4CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name4]))
   where [Only] is not null and ([Name4] is not null and [Name4] not like '''') and Name4CorpInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name4CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Name4])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and ([Name4] is not null and [Name4] not like '''') and Name4CorpInd is NULL'
   exec(@sql)

   -- Added v8.6 Name3 change ' or ' to ' & ' to fix the ' or ' format issue. This skips the 9 sections below for ' or '.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name3] = REPLACE([Name3],'' or '','' & '')
   where [Name3] like ''% or %'' and Name3corpind is null'
   exec(@sql)

   -- Added v8.6 Name4 change ' or ' to ' & ' to fix the ' or ' format issue. This skips the 9 sections below for ' or '.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name4] = REPLACE([Name4],'' or '','' & '')
   where [Name4] like ''% or %'' and Name4corpind is null'
   exec(@sql)

   -- Added v8.6 Name3 change ' and ' to ' & ' to fix the ' and ' format issue.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name3] = REPLACE([Name3],'' and '','' & '')
   where [Name3] like ''% and %'' and Name3corpind is null'
   exec(@sql)

   -- Added v8.6 Name4 change ' and ' to ' & ' to fix the ' and ' format issue.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name4] = REPLACE([Name4],'' and '','' & '')
   where [Name4] like ''% and %'' and Name4corpind is null'
   exec(@sql)



--------------------------------------------------------------------- Section process trusts ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name3TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name3],1,(charindex('' '',[Name3])))
   where [BeginsWith] is not null and Name3TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name3TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name3]),1,(charindex('' '',reverse([Name3])))))
   where [EndsWith] is not null and Name3TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name3TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on [Name3] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name3TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name3TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name3]))
   where [Only] is not null and Name3TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name3TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Name3])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and Name3TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name4TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name4],1,(charindex('' '',[Name4])))
   where [BeginsWith] is not null and ([Name4] is not null and [Name4] not like '''') and Name4TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name4]),1,(charindex('' '',reverse([Name4])))))
   where [EndsWith] is not null and ([Name4] is not null and [Name4] not like '''') and Name4TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on [Name4] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name4TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name4TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name4]))
   where [Only] is not null and ([Name4] is not null and [Name4] not like '''') and Name4TrustInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name4TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Name4])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and ([Name4] is not null and [Name4] not like '''') and Name4TrustInd is NULL'
   exec(@sql)

   --  Added 20180608 to handle instances of Assessee name 1 and Assessee Name 2 in Assessee Name 1 field
   set @sql = 'update [dbo].['+@tableName+']
   set [Name3] = ltrim(rtrim(substring([Name3],1,(charindex(''&'',[Name3])-1)))), [Name4] = ltrim(rtrim(substring([Name3],(charindex(''&'',[Name3])+1),80)))
   where [Name3TrustInd] is null and [Name3CorpInd] is null and ([Name3] like ''%&%'') and Name4 is NULL'
   exec(@sql)

   --ADDED 20170928 Same Last Name Twice FIX
   --EXEC('update [dbo].['+@tableName+']
   --SET [Name3] = CASE WHEN dbo.Before1stCharacter([Name3],'' '') + Replace(dbo.After1stCharacter([Name3],'' ''), dbo.Before1stCharacter([Name3],'' ''), ''&'') like ''%&%&%''
   --   THEN [dbo].[Before2ndCharacter](dbo.Before1stCharacter([Name3],'' '') + Replace(dbo.After1stCharacter([Name3],'' ''), dbo.Before1stCharacter([Name3],'' ''), ''&''),''&'')
   --   ELSE dbo.Before1stCharacter([Name3],'' '') + Replace(dbo.After1stCharacter([Name3],'' ''), dbo.Before1stCharacter([Name3],'' ''), ''&'') END
   --WHERE [Name3] Like ''% %'' and [Name3CorpInd] is null and Name3 like ''%,%'' 
   --   AND SUBSTRING([Name3],CharIndex('' '',[Name3])+1,LEN([Name3])) Like ''% '' + ltrim(rtrim(replace(Substring([Name3],1,CharIndex('' '',[Name3])),'','',''''))) + ''%''')


SET CONCAT_NULL_YIELDS_NULL ON
  
END



