SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create Proc [dbo].[GetAddrTriggerByAppName]
(
	@AppName varchar(50)
	, @ProcessTypeCode Char(1) = NULL
)
AS
/*
--Start Tesing
Declare @AppName Varchar(50), @ProcessTypeCode Char(1)
Select @AppName = 'MLS_Weekly', @ProcessTypeCode = 'A'
--End Testing
*/
Begin
	Select A.AppId
		, A.AppName
		, A.ServerName
		, A.ConnectionString
		--, T.TableName
		--, T.ProcessTypeCode
		--, T.Process_Flag
		--, T.CreatedDateTime
		--, T.LastUpdatedDateTime
		--, T.CompletedDateTime
	From AddrApplication as A
	Where A.AppName = @AppName

	Select ASP.AppSpId
		, SP.SpName
		, SP.SpType
		--, T.ProcessTypeCode
	from AddrAppSps as ASP
		Inner Join AddrStoredProcs as SP
			On ASP.SpId = SP.SpID
		Inner Join AddrProcessType as PT
			On PT.ProcessTypeId = ASP.ProcessTypeId
		Inner Join AddrApplication as A
			On A.AppId = ASP.AppId
	Where A.AppName = @AppName
		And PT.Code = @ProcessTypeCode

	Select M.ColumnMappingId
		, M.AppID
		, A.AppName
		, M.ProcessTypeId
		, PT.Code
		, M.SourceColumnName
		, M.DestColumnName
	From AddrColumnMapping as M
		Inner Join AddrProcessType as PT
			On PT.ProcessTypeId = M.ProcessTypeID
		Inner Join AddrApplication as A
			On A.AppId = M.AppId
	Where A.AppName = @AppName
		And PT.Code = @ProcessTypeCode
End


