SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[usp_001_CrapCleaner_By_Table] @table varchar(100)
AS
BEGIN

-- EXEC Data.[dbo].[usp_001_CrapCleaner_By_Table] @table = 'PACELien'
-- Entity -- pipe
-- FormattedAPN
-- Own1Last
-- ProgramName
-- RequestedPreparedByLastNameCoName -- pipe

	DECLARE @colName VARCHAR(255)
	DECLARE @prec VARCHAR(255)
	DECLARE @sqlCmd VARCHAR(max)
	--DECLARE @table varchar(100)
	--SET @table = N'Deed'

	DECLARE db_cursor CURSOR FOR  

	SELECT c.name ColumnName
	FROM sys.columns c INNER JOIN
		 sys.tables t ON c.object_id = t.object_id INNER JOIN
		 sys.schemas s ON t.schema_id = s.schema_id
	where t.name = @table 
	and c.System_type_id not in(40,42,48,52,56,61,62,104,106,108,127)
	--and c.Name in('Buyer3LastNameOrCorpName','Buyer4FirstNameMiddleInitial','Buyer4LastNameOrCorpName','Buyer4IDCode')
	order by ColumnName

	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @colName   

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		BEGIN
				PRINT @colName

				EXEC('UPDATE '+@table+' set ['+@colName+'] = [dbo].[RemoveNonASCII](['+@colName+'])
				WHERE isNULL(['+@colName+'], '''') not like '''' AND
				((patindex(''%['' + char(0) + ''-'' + char(31) + '']%'', cast(['+@colName+'] as varchar(max)) COLLATE Latin1_General_BIN2) > 0)
				OR (patindex(''%['' + char(127) + ''-'' + char(255) + '']%'', cast(['+@colName+'] as varchar(max)) COLLATE Latin1_General_BIN2) > 0))')
				--((patindex(''%['' + char(0) + ''-'' + char(31) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0)
				--OR (patindex(''%['' + char(127) + ''-'' + char(255) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0))')

				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],''|'','''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%|%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],''{'','''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%{%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],''}'','''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%}%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],char(34),'''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%'' + char(34) + ''%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],char(39),'''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%'' + char(39) + ''%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],char(13),'''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%'' + char(13) + ''%''')
				
				EXEC('update '+@table+' set ['+@colName+'] = replace(['+@colName+'],char(10),'''')
				WHERE isNULL(['+@colName+'], '''') not like '''' AND ['+@colName+'] LIKE ''%'' + char(10) + ''%''')

				EXEC('update '+@table+' set ['+@colName+'] = NULL 
				where isNULL(['+@colName+'], '''') not like '''' and cast(['+@colName+'] as varchar(max)) = ''*''')

		END
		FETCH NEXT FROM db_cursor INTO @colName
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

END

