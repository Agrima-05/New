SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[usp_LoadSpot_REF_V4_reStart_DataLoad_a_JustFixedOnes]
AS
BEGIN

	SET NOCOUNT ON;

----------START DATA LOAD
		DECLARE @FipsCode varchar(5)
		DECLARE @StateAbbrev varchar(2)

		DECLARE curLoadSpotUpdate CURSOR FOR  
			SELECT [FIPSCode],[State] 
			FROM dbo.UpdateRecords
			WHERE [STATE] NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
				AND Complete is NULL
			ORDER BY [FIPSCode]

		OPEN curLoadSpotUpdate   
		FETCH NEXT FROM curLoadSpotUpdate INTO @FipsCode,@StateAbbrev

		WHILE @@FETCH_STATUS = 0   
		BEGIN   

			PRINT @FipsCode + ' In FASpot_a'

			DROP INDEX IF EXISTS [UniqueFipsPropID] ON [dbo].[FASpot_a_Batch] 

			Truncate table [Boundaries].[dbo].[FASpot_a_Batch]

			CREATE UNIQUE NONCLUSTERED INDEX [UniqueFipsPropID] ON [dbo].[FASpot_a_Batch]
			([FIPS] ASC,[PropertyID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


				EXEC('DELETE FROM [Boundaries].[dbo].[FASpot_a] WHERE FIPS = '''+ @FipsCode +'''')
				EXEC('DELETE FROM [Boundaries].[dbo].[FASpot_Generated_a] WHERE FIPS = '''+ @FipsCode +'''')

				EXEC('INSERT INTO [Boundaries].[dbo].[FASpot_a_Batch]
					   ([FADigitalMapMasterId]
					   ,[PropertyID]
					   ,[APN]
					   ,[FIPS]
					   ,[Longitude]
					   ,[Latitude]
					   ,[ParcelGeography]
					   ,[ParcelGeometry]
					   ,[ParcelPointGeography]
					   ,[ParcelPointGeometry]
					   ,[EstLotSizeSqFt]
					   ,[AddressScore]
					   ,[GeoSource]
					   ,[PARCELAPN]
					   ,[FAGeoStatusCode]
					   ,[LatLonGeometry]
					   ,[DmDate]
					   ,[MatchCode]
					   ,[UpdateFlag]
					   ,[RefId]
					   ,[PRCLDMPID]
					   ,[PROPDMPID]
					   ,[ParcelGeometry4269]
					   ,[ParcelPointGeometry4269]
					   ,[FATimestamp]
					   ,[GeomWKT]
					   ,[UCIDFlag]
					   ,[PointWKT]
					   ,[UniqueGuid]
					   ,[LoadDate]
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,[GeoAccuracy]
					   ,[FeatureType])
			Select  
						CASE WHEN r.[Id] is NULL THEN b.[MasterAssrId] ELSE r.[Id] END 		-- ID
					   ,CASE WHEN b.Propertyid IS NULL THEN r.[PropertyID] ELSE b.propertyID END	--PropertyID
					   ,CASE WHEN SUBSTRING(b.UnformattedAPN,1,45) IS NULL THEN substring(r.APN,1,45) ELSE SUBSTRING(b.UnformattedAPN,1,45) END				--APN
					   ,case when b.[fips] is NULL then r.Fips else b.Fips end				--FIPS
					   ,b.[Longitude]														--Longitude
					   ,b.[Latitude]														--Latitude
					   ,NULL																--ParcelGeography
					   ,Coalesce(b.[GeomParcel].MakeValid(),r.[Geom].MakeValid())			--ParcelGeometry
					   ,NULL																--ParcelPointGeography
					   ,b.[Geom].MakeValid()															--ParcelPointGeometry
					   ,CAST(CASE WHEN CASE WHEN b.[Sqft] is NULL THEN r.[Sqft] ELSE b.[Sqft] END > 2000000000 then NULL ELSE CASE WHEN b.[Sqft] is NULL THEN r.[Sqft] ELSE b.[Sqft] END END as int)	--EstLotSizeSqFt
					   ,NULL																--AddressScore
					   ,CASE WHEN (r.REF_ID = b.RefId or b.[GeomParcel] is not null or b.RefId is NULL) THEN ''Parcels'' ELSE ''Points'' END  		--GeoSource
					   ,CASE WHEN SUBSTRING(b.UnformattedAPN,1,45) IS NULL THEN substring(r.APN,1,45) ELSE SUBSTRING(b.UnformattedAPN,1,45) END					--PARCELAPN
					   ,''P''																--FAGeoStatusCode
					   ,NULL																--LatLonGeometry
					   ,convert(varchar(8),Getdate()-1,112)									--DmDate
					   ,NULL																--MatchCode
					   ,''I''																--UpdateFlag
					   ,CASE WHEN b.[RefID] is NULL THEN r.[Ref_Id] ELSE b.[REFID] end  			--RefId
					   ,NULL																--PRCLDMPID
					   ,NULL																--PROPDMPID
					   ,geometry::STGeomFromText(r.[Geom].MakeValid().STAsText(),4269)		--ParcelGeometry4269
					   ,geometry::STGeomFromText(b.[Geom].MakeValid().STAsText(),4269)		--ParcelPointGeometry4269
					   ,GetDAte()															--FATimestamp
					   ,r.[Geom].MakeValid().STUnion(r.[Geom].STStartPoint()).STAsText()	--GeomWKT
					   ,''I''																--UCIDFlag
					   ,b.[Geom].MakeValid().STUnion(b.[Geom].STStartPoint()).STAsText()	--PointWKT
					   ,CASE WHEN [ParcelUniqueGuid] is NULL THEN [UniqueGuid] ELSE [ParcelUniqueGuid] END
					   ,GetDAte()															--LoadDate
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,b.[GeoAccuracy]
					   ,[FeatureType]
			FROM [dlvry].[Parcel_REF] r  with(NOLOCK)
			LEFT OUTER JOIN (Select * from [dlvry].[Point_REF] with(NOLOCK) WHERE FIPS = ''' + @FipsCode + ''') b
			on r.UniqueGuid = b.ParcelUniqueGuid
			WHERE r.Fips = '''+ @FipsCode +'''
			')
			

				EXEC('INSERT INTO [Boundaries].[dbo].[FASpot_a_Batch]
					   ([FADigitalMapMasterId]
					   ,[PropertyID]
					   ,[APN]
					   ,[FIPS]
					   ,[Longitude]
					   ,[Latitude]
					   ,[ParcelGeography]
					   ,[ParcelGeometry]
					   ,[ParcelPointGeography]
					   ,[ParcelPointGeometry]
					   ,[EstLotSizeSqFt]
					   ,[AddressScore]
					   ,[GeoSource]
					   ,[PARCELAPN]
					   ,[FAGeoStatusCode]
					   ,[LatLonGeometry]
					   ,[DmDate]
					   ,[MatchCode]
					   ,[UpdateFlag]
					   ,[RefId]
					   ,[PRCLDMPID]
					   ,[PROPDMPID]
					   ,[ParcelGeometry4269]
					   ,[ParcelPointGeometry4269]
					   ,[FATimestamp]
					   ,[GeomWKT]
					   ,[UCIDFlag]
					   ,[PointWKT]
					   ,[UniqueGuid]
					   ,[LoadDate]
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,[GeoAccuracy])
				Select  
						b.[MasterAssrId] 													-- ID
					   ,b.[PropertyID]														--PropertyID
					   ,substring(b.UnformattedAPN,1,45)									--APN
					   ,b.Fips																--FIPS
					   ,b.[Longitude]														--Longitude
					   ,b.[Latitude]														--Latitude
					   ,NULL																--ParcelGeography
					   ,[GeomParcel].MakeValid()											--ParcelGeometry
					   ,NULL																--ParcelPointGeography
					   ,b.[Geom].MakeValid()															--ParcelPointGeometry
					   ,case when b.sqft < 2000000000 then cast(b.Sqft as int) else null end	--EstLotSizeSqFt
					   ,NULL																--AddressScore
					   ,''Parcels''															--GeoSource
					   ,substring(b.UnformattedAPN,1,45)									--PARCELAPN
					   ,''P''																--FAGeoStatusCode
					   ,NULL																--LatLonGeometry
					   ,convert(varchar(8),Getdate()-1,112)									--DmDate
					   ,NULL																--MatchCode
					   ,''I''																--UpdateFlag
					   ,[RefId]																--RefId
					   ,NULL																--PRCLDMPID
					   ,NULL																--PROPDMPID
					   ,NULL																--ParcelGeometry4269
					   ,geometry::STGeomFromText(b.[Geom].MakeValid().STAsText(),4269)		--ParcelPointGeometry4269
					   ,GetDAte()															--FATimestamp
					   ,[GeomParcel].MakeValid().STAsText()									--GeomWKT
					   ,''I''																--UCIDFlag
					   ,b.[Geom].MakeValid().STUnion(b.[Geom].STStartPoint()).STAsText()	--PointWKT
					   ,[ParcelUniqueGuid]
					   ,GetDAte()															--LoadDate
					   ,NULL
					   ,NULL
					   ,NULL
					   ,b.[GeoAccuracy]
				FROM [dlvry].[Point_REF] b with(NOLOCK)
				WHERE b.FIPS = ''' + @FipsCode + ''' and b.Refid NOT in(Select [REFID] from dbo.vFASpot_FULL with(NOLOCK) where FIPS = '''+ @FipsCode +''')
				AND GeomParcel is not NULL
				')
			

				EXEC('INSERT INTO [Boundaries].[dbo].[FASpot_a_Batch]
					   ([FADigitalMapMasterId]
					   ,[PropertyID]
					   ,[APN]
					   ,[FIPS]
					   ,[Longitude]
					   ,[Latitude]
					   ,[ParcelGeography]
					   ,[ParcelGeometry]
					   ,[ParcelPointGeography]
					   ,[ParcelPointGeometry]
					   ,[EstLotSizeSqFt]
					   ,[AddressScore]
					   ,[GeoSource]
					   ,[PARCELAPN]
					   ,[FAGeoStatusCode]
					   ,[LatLonGeometry]
					   ,[DmDate]
					   ,[MatchCode]
					   ,[UpdateFlag]
					   ,[RefId]
					   ,[PRCLDMPID]
					   ,[PROPDMPID]
					   ,[ParcelGeometry4269]
					   ,[ParcelPointGeometry4269]
					   ,[FATimestamp]
					   ,[GeomWKT]
					   ,[UCIDFlag]
					   ,[PointWKT]
					   ,[UniqueGuid]
					   ,[LoadDate]
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,[GeoAccuracy])
				Select  
						b.[MasterAssrId] 													-- ID
					   ,b.[PropertyID]														--PropertyID
					   ,substring(b.UnformattedAPN,1,45)									--APN
					   ,b.Fips																--FIPS
					   ,b.[Longitude]														--Longitude
					   ,b.[Latitude]														--Latitude
					   ,NULL																--ParcelGeography
					   ,b.[Geom].MakeValid()												--ParcelGeometry
					   ,NULL																--ParcelPointGeography
					   ,b.[Geom].MakeValid()															--ParcelPointGeometry
					   ,case when b.sqft < 2000000000 then cast(b.Sqft as int) else null end	--EstLotSizeSqFt
					   ,NULL																--AddressScore
					   ,''Points''															--GeoSource
					   ,substring(b.UnformattedAPN,1,45)									--PARCELAPN
					   ,''P''																--FAGeoStatusCode
					   ,NULL																--LatLonGeometry
					   ,convert(varchar(8),Getdate()-1,112)									--DmDate
					   ,NULL																--MatchCode
					   ,''I''																--UpdateFlag
					   ,[RefId]																--RefId
					   ,NULL																--PRCLDMPID
					   ,NULL																--PROPDMPID
					   ,NULL																--ParcelGeometry4269
					   ,geometry::STGeomFromText(b.[Geom].MakeValid().STAsText(),4269)		--ParcelPointGeometry4269
					   ,GetDAte()															--FATimestamp
					   ,b.[GEOM].MakeValid().STAsText()										--GeomWKT
					   ,''I''																--UCIDFlag
					   ,b.[Geom].MakeValid().STUnion(b.[Geom].STStartPoint()).STAsText()	--PointWKT
					   ,[ParcelUniqueGuid]
					   ,GetDAte()															--LoadDate
					   ,NULL
					   ,NULL
					   ,NULL
					   ,b.[GeoAccuracy]
				FROM [dlvry].[Point_REF] b with(NOLOCK)
				WHERE b.FIPS = ''' + @FipsCode + ''' and b.Refid in(
					Select b.REF_ID from (Select [RefId] from dbo.FASpot_a_Batch with(NOLOCK) group by [REFID])  a 
							Right outer JOIN (Select REF_ID from [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR with(NOLOCK) where fips = '+ @FipsCode +') b
					on a.[REFID] = b.[REF_ID]
					where a.[REFID] is NULL)
				')



			/***** ADDED TO PULL IN NON LINKED PARCELS *****/

			DROP INDEX IF EXISTS [UniqueFipsPropID] ON [dbo].[FASpot_a_Batch]	

				EXEC('INSERT INTO [Boundaries].[dbo].[FASpot_a_Batch]
					   ([FADigitalMapMasterId]
					   ,[PropertyID]
					   ,[APN]
					   ,[FIPS]
					   ,[Longitude]
					   ,[Latitude]
					   ,[ParcelGeography]
					   ,[ParcelGeometry]
					   ,[ParcelPointGeography]
					   ,[ParcelPointGeometry]
					   ,[EstLotSizeSqFt]
					   ,[AddressScore]
					   ,[GeoSource]
					   ,[PARCELAPN]
					   ,[FAGeoStatusCode]
					   ,[LatLonGeometry]
					   ,[DmDate]
					   ,[MatchCode]
					   ,[UpdateFlag]
					   ,[RefId]
					   ,[PRCLDMPID]
					   ,[PROPDMPID]
					   ,[ParcelGeometry4269]
					   ,[ParcelPointGeometry4269]
					   ,[FATimestamp]
					   ,[GeomWKT]
					   ,[UCIDFlag]
					   ,[PointWKT]
					   ,[UniqueGuid]
					   ,[LoadDate]
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,[GeoAccuracy]
					   ,[FeatureType])
			Select  
						CASE WHEN r.[Id] is NULL THEN b.[MasterAssrId] ELSE r.[Id] END 		-- ID
					   ,CASE WHEN b.Propertyid IS NULL THEN r.[PropertyID] ELSE b.propertyID END	--PropertyID
					   ,CASE WHEN SUBSTRING(b.UnformattedAPN,1,45) IS NULL THEN substring(r.APN,1,45) ELSE SUBSTRING(b.UnformattedAPN,1,45) END				--APN
					   ,case when b.[fips] is NULL then r.Fips else b.Fips end				--FIPS
					   ,b.[Longitude]														--Longitude
					   ,b.[Latitude]														--Latitude
					   ,NULL																--ParcelGeography
					   ,Coalesce(b.[GeomParcel].MakeValid(),r.[Geom].MakeValid())			--ParcelGeometry
					   ,NULL																--ParcelPointGeography
					   ,b.[Geom].MakeValid()															--ParcelPointGeometry
					   ,CAST(CASE WHEN CASE WHEN b.[Sqft] is NULL THEN r.[Sqft] ELSE b.[Sqft] END > 2000000000 then NULL ELSE CASE WHEN b.[Sqft] is NULL THEN r.[Sqft] ELSE b.[Sqft] END END as int)	--EstLotSizeSqFt
					   ,NULL																--AddressScore
					   ,CASE WHEN (r.REF_ID = b.RefId or b.[GeomParcel] is not null or b.RefId is NULL) THEN ''Parcels'' ELSE ''Points'' END  		--GeoSource
					   ,CASE WHEN SUBSTRING(b.UnformattedAPN,1,45) IS NULL THEN substring(r.APN,1,45) ELSE SUBSTRING(b.UnformattedAPN,1,45) END					--PARCELAPN
					   ,''P''																--FAGeoStatusCode
					   ,NULL																--LatLonGeometry
					   ,convert(varchar(8),Getdate()-1,112)									--DmDate
					   ,NULL																--MatchCode
					   ,''I''																--UpdateFlag
					   ,CASE WHEN b.[RefID] is NULL THEN r.[Ref_Id] ELSE b.[REFID] end  			--RefId
					   ,NULL																--PRCLDMPID
					   ,NULL																--PROPDMPID
					   ,geometry::STGeomFromText(r.[Geom].MakeValid().STAsText(),4269)		--ParcelGeometry4269
					   ,geometry::STGeomFromText(b.[Geom].MakeValid().STAsText(),4269)		--ParcelPointGeometry4269
					   ,GetDAte()															--FATimestamp
					   ,r.[Geom].MakeValid().STUnion(r.[Geom].STStartPoint()).STAsText()	--GeomWKT
					   ,''I''																--UCIDFlag
					   ,b.[Geom].MakeValid().STUnion(b.[Geom].STStartPoint()).STAsText()	--PointWKT
					   ,CASE WHEN [ParcelUniqueGuid] is NULL THEN [UniqueGuid] ELSE [ParcelUniqueGuid] END
					   ,GetDAte()															--LoadDate
					   ,[CreatedDate]
					   ,[UpdatedDate]
					   ,[Area]
					   ,b.[GeoAccuracy]
					   ,[FeatureType]
			FROM [dlvry].[Parcel_REF] r  with(NOLOCK)
			LEFT OUTER JOIN (Select * from [dlvry].[Point_REF] with(NOLOCK) WHERE FIPS = ''' + @FipsCode + ''') b
			on r.UniqueGuid = b.ParcelUniqueGuid
			WHERE r.Fips = ''' + @FipsCode + ''' and isNULL(CASE WHEN b.Propertyid IS NULL THEN r.[PropertyID] ELSE b.propertyID END,'''') LIKE ''''
			')

				DELETE From dbo.FASpot_a_Batch where PropertyID in(			
				Select PropertyID from dbo.FASpot_a_Batch with(NOLOCK) where propertyid is not null group by PropertyID having COUNT(*) > 1)
				AND ParcelGeometry4269 is NULL

			/**^^^^^ ADDED TO PULL IN NON LINKED PARCELS ^^^^^**/



		
				EXEC('UPDATE dbo.FASpot_a_Batch
				SET Latitude = [ParcelGeometry4269].MakeValid().STCentroid().STY 
				,Longitude = [ParcelGeometry4269].MakeValid().STCentroid().STX
				WHERE Fips = '''+ @FipsCode +''' and Latitude is NULL
				')

				EXEC('update a
					SET [EstLotSizeSqFt] = cast(b.Sqft as int)
					FROM dbo.FASpot_a_Batch a join dlvry.Point_REF b with(NOLOCK)
					on a.[RefId] = b.[RefId]
					Where a.FIPS = '''+ @FipsCode +''' and b.Fips = '''+ @FipsCode +''' 
					and [EstLotSizeSqFt] is null
					and cast(b.Sqft as Bigint) < 2000000000
				')

					  EXEC('update [dbo].[FASpot_a_Batch]
					  SET [CentroidLatitude] = [ParcelGeometry].STCentroid().STY
					  ,[CentroidLongitude] = [ParcelGeometry].STCentroid().STX
					  WHERE FIPS = ''' + @FipsCode + '''
						')
			  
					  EXEC('update [dbo].[FASpot_a_Batch]
					  SET [CentroidPointGeom] = geography::Point([CentroidLatitude],[CentroidLongitude],  4269)
					  WHERE FIPS = ''' + @FipsCode + '''
							and [CentroidLatitude] is not null and [CentroidLongitude] is not null
					  ')


					EXEC('UPDATE a
					SET a.[FALongitude] = b.[CentroidLongitude]
					,a.[FALatitude] = b.[CentroidLatitude]
					,a.[FAEstLotSqFt] = b.[EstLotSizeSqFt]
					,a.[FAGeoStatusCode] = ''P''
					from data.[dbo].Property a
					join [Boundaries].[dbo].[FASpot_a_Batch] b with(nolock) 
					on a.PropertyID = b.PropertyID
					where a.[FIPS] = ''' + @FipsCode + '''
					and b.[FIPS] = ''' + @FipsCode + '''
					')


				INSERT INTO FASpot_a([FADigitalMapMasterId]
					  ,[PropertyID]
					  ,[APN]
					  ,[FIPS]
					  ,[Longitude]
					  ,[Latitude]
					  ,[ParcelGeography]
					  ,[ParcelGeometry]
					  ,[ParcelPointGeography]
					  ,[ParcelPointGeometry]
					  ,[EstLotSizeSqFt]
					  ,[AddressScore]
					  ,[GeoSource]
					  ,[PARCELAPN]
					  ,[FAGeoStatusCode]
					  ,[LatLonGeometry]
					  ,[DmDate]
					  ,[MatchCode]
					  ,[UpdateFlag]
					  ,[RefId]
					  ,[PRCLDMPID]
					  ,[PROPDMPID]
					  ,[ParcelGeometry4269]
					  ,[ParcelPointGeometry4269]
					  ,[FATimestamp]
					  ,[GeomWKT]
					  ,[UCIDFlag]
					  ,[PointWKT]
					  ,[IsCondo]
					  ,[InHJ]
					  ,[InUpdate]
					  ,[NumberofPolygons]
					  ,[InDM]
					  ,[LoadDate]
					  ,[UniqueGuid]
					  ,[CreatedDate]
					  ,[UpdatedDate]
					  ,[Area]
					  ,[SqFt]
					  ,[InSpot]
					  ,[GeoAccuracy]
					  ,[ParcelGeometry3857]
					  ,[PointGeometry3857]
					  ,[FeatureType]
					  ,[CentroidLatitude]
					  ,[CentroidLongitude]
					  ,[CentroidPointGeom])
				Select [FADigitalMapMasterId]
					  ,[PropertyID]
					  ,[APN]
					  ,[FIPS]
					  ,[Longitude]
					  ,[Latitude]
					  ,[ParcelGeography]
					  ,[ParcelGeometry]
					  ,[ParcelPointGeography]
					  ,[ParcelPointGeometry]
					  ,[EstLotSizeSqFt]
					  ,[AddressScore]
					  ,[GeoSource]
					  ,[PARCELAPN]
					  ,[FAGeoStatusCode]
					  ,[LatLonGeometry]
					  ,[DmDate]
					  ,[MatchCode]
					  ,[UpdateFlag]
					  ,[RefId]
					  ,[PRCLDMPID]
					  ,[PROPDMPID]
					  ,[ParcelGeometry4269]
					  ,[ParcelPointGeometry4269]
					  ,[FATimestamp]
					  ,[GeomWKT]
					  ,[UCIDFlag]
					  ,[PointWKT]
					  ,[IsCondo]
					  ,[InHJ]
					  ,[InUpdate]
					  ,[NumberofPolygons]
					  ,[InDM]
					  ,[LoadDate]
					  ,[UniqueGuid]
					  ,[CreatedDate]
					  ,[UpdatedDate]
					  ,[Area]
					  ,[SqFt]
					  ,[InSpot]
					  ,[GeoAccuracy]
					  ,[ParcelGeometry3857]
					  ,[PointGeometry3857]
					  ,[FeatureType]
					  ,[CentroidLatitude]
					  ,[CentroidLongitude]
					  ,[CentroidPointGeom]
					FROM (Select *,ROW_NUMBER() OVER(PARTITION BY p.PropertyID ORDER BY p.PropertyID) AS RowNum
					FROM FASpot_a_Batch p) d	
						WHERE RowNum = 1
				
				
				EXEC [Boundaries].[dbo].[CreateFASpotGenerated_a_FAST] @FipsCode

				EXEC('DELETE FROM FASpot_a
				WHERE UCIDFlag = ''D''
				and FIPS = ''' + @FipsCode + '''
				')

				  EXEC('update [dbo].[FASpot_Generated_a]
				  SET [CentroidLatitude] = [ParcelGeometry].STCentroid().STY
				  ,[CentroidLongitude] = [ParcelGeometry].STCentroid().STX
				  WHERE FIPS = ''' + @FipsCode + '''
					')
			  
				  EXEC('update [dbo].[FASpot_Generated_a]
				  SET [CentroidPointGeom] = geography::Point([CentroidLatitude],[CentroidLongitude],  4269)
				  WHERE FIPS = ''' + @FipsCode + '''
						and [CentroidLatitude] is not null and [CentroidLongitude] is not null
				  ')


			EXEC('UPDATE Boundaries.dbo.UpdateRecords
			SET COMPLETE = ''1''
			WHERE FIPSCode = ''' + @FipsCode + '''
			')


			FETCH NEXT FROM curLoadSpotUpdate INTO @FipsCode,@StateAbbrev
		END   

		CLOSE curLoadSpotUpdate   
		DEALLOCATE curLoadSpotUpdate 		


		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_FipsMastID')
		CREATE NONCLUSTERED INDEX [ix_FipsMastID] ON [dbo].[FASpot_a]
		([FIPS] ASC,[FADigitalMapMasterId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_FipsPropID')
		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[FASpot_a]
		([FIPS] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_UCID')
		CREATE NONCLUSTERED INDEX [ix_UCID] ON [dbo].[FASpot_a]
		([UCIDFlag] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_FIPS')
		CREATE NONCLUSTERED INDEX [ix_FIPS] ON [dbo].[FASpot_a]
		([FIPS] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_FipsFATimestamp')
		CREATE NONCLUSTERED INDEX [ix_FipsFATimestamp] ON [dbo].[FASpot_a]
		([FIPS] ASC,[FATimestamp] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_FipsLoadDate')
		CREATE NONCLUSTERED INDEX [ix_FipsLoadDate] ON [dbo].[FASpot_a]
		([FIPS] ASC,[LoadDate] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_GeoSource')
		CREATE NONCLUSTERED INDEX [ix_GeoSource] ON [dbo].[FASpot_a]
		([GeoSource] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_LatLong')
		CREATE NONCLUSTERED INDEX [ix_LatLong] ON [dbo].[FASpot_a]
		([Latitude] ASC,[Longitude] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_a]') AND name = N'ix_PropertyID')
		CREATE NONCLUSTERED INDEX [ix_PropertyID] ON [dbo].[FASpot_a]
		([PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_Generated_a]') AND name = N'ix_FipsPropID')
		CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[FASpot_Generated_a]
		([FIPS] ASC,[PropertyID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FASpot_Generated_a]') AND name = N'ix_UCID')
		CREATE NONCLUSTERED INDEX [ix_UCID] ON [dbo].[FASpot_Generated_a]
		([UCIDFlag] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		

END



