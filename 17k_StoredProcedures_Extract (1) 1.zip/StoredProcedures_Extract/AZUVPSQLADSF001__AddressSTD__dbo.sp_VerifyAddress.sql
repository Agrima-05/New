SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

--DROP PROCEDURE sp_VerifyAddress
--GO


CREATE PROCEDURE [dbo].[sp_VerifyAddress] AS

-- exec [AddressSTD].[dbo].[sp_VerifyAddress]
-- select * FROM [AddressSTD].[dbo].[list]
/*
truncate table AddressStd.dbo.list
insert into AddressStd.dbo.list  ([Company],[Address],[City],[State],[Zip]) values (1,'423 WILD IRISHMAN RD # 2-13203','Dillon','CO','80435')
insert into AddressStd.dbo.list  ([Company],[Address],[City],[State],[Zip]) values (2,'423 WILD IRISHMAN RD # 13203','Dillon','CO','80435')
INSERT INTO AddressStd.dbo.list ([Company],[Address],[City],[State],[Zip])
    Select apn, 
	--PropertyFullStreetAddress, 
	Case when (isNULL([PropertyUnitNumber],'') Not Like '' and [PropertyFullStreetAddress] not like '%' + [PropertyUnitNumber]) then rtrim(rtrim([PropertyFullStreetAddress] + ' ' + isNULL([PropertyAddressUnitDesignator],'#')) + ' ' + ltrim([PropertyUnitNumber])) else [PropertyFullStreetAddress] end as [PropertyFullStreetAddress],
	PropertyCityName, PropertyState, PropertyZipCode
    from staging_archive.dbo.md_ref_assessments with (nolock) 
    where fips = '08117' and PropertyStreetName like '%WILD IRISHMAN%' and PropertyHouseNumber like  '%423%' 
*/

-- DECLARE variables.
	DECLARE @DataPath  char(100)
	DECLARE @License varchar(256)
	DECLARE @RecCnt float
	DECLARE @Company char (40)
	DECLARE @Address char (50)
	DECLARE @Address2 char (50)
	DECLARE @Suite char (10)
	DECLARE @City char (28)
	DECLARE @State char (2)
	DECLARE @Zip char (10)
    DECLARE @Plus4 char (4)	
	DECLARE @Address_Output char (50)
	DECLARE @DeliveryPointCode char(2)
	DECLARE @DeliveryPointCheckDigit char (1)
	DECLARE @Results char(25)
	DECLARE @PrivateMailbox char(10)


-- DECLARE a cursor from table name LIST
DECLARE AddCursor cursor for select company, address, city, state, zip from LIST

-- ********************** DATA FILES  *****************************
--  Set Path to Data Files and License String Here
--  The Data Files Directory must contain the following files: 
--  mdAddr.dat, mdAddr.lic, mdAddr.nat, and mdAddr.str.
-- ****************************************************************
 SET  @DataPath = 'D:\Program Files\Melissa DATA\DQT\Data'	--Path of Address object data files

-- ********************** LICENSE STRINGS *************************
--       To unlock the full functionality of Address Object,      
--   please call a sales representative at 1-800-MELISSA ext. 3    
--           (1-800-635-4772 x3) for a license string.            
--       Without a valid license string, Address Object will      
--                  only verify Nevada addresses.                 
--   SetLicenseString also checks for a valid license in the 
--   MDADDR_LICENSE environment variable. 
--   This allows you to modify the license without recompilation.
-- **************************************************************** 
SET  @License = 'Demo'


SET  @RecCnt = 0	-- Record count
SET  nocount on		

-- Create Address Object.
declare @mdAddr BIGINT
declare @RetVal BIGINT
declare @Build varchar(100)

--Create and initalize the API
set @mdAddr = master.dbo.mdAddrCreate() --master.dbo.mdAddrCreate()
set @RetVal = master.dbo.mdAddrSetLicenseString(@mdAddr, @License) --master.dbo.mdAddrSetLicenseString(@mdAddr, @License)

--Set Path to US Data Files
set @RetVal = master.dbo.mdAddrSetPathToUSFiles(@mdAddr, @DataPath) --master.dbo.mdAddrSetPathToUSFiles(@mdAddr, @DataPath)

-- DPV and LACSLink, CASS required add-ons for highest level of validation.
set @RetVal = master.dbo.mdAddrSetPathToDPVDataFiles(@mdAddr, @DataPath) --master.dbo.mdAddrSetPathToDPVDataFiles(@mdAddr, @DataPath)
set @RetVal = master.dbo.mdAddrSetPathToLACSLinkDataFiles(@mdAddr, @DataPath) --master.dbo.mdAddrSetPathToLACSLinkDataFiles(@mdAddr, @DataPath)

-- Suite Link 
--set @RetVal = master.dbo.mdAddrSetPathToSuiteLinkDataFiles(@mdAddr, @DataPath)

-- AddressPlus
--set @RetVal = master.dbo.mdAddrSetPathToSuiteFinderDataFiles(@mdAddr, @DataPath)

-- Canadian - Canadian Address Validation Add-on
--set @RetVal = master.dbo.mdAddrSetPathToCanadaFiles(@mdAddr, @DataPath)

-- RDBI - Delivery Indicator Add-on (Residence or Business) 
--set @RetVal = master.dbo.mdAddrSetPathToRBDIFiles(@mdAddr, @DataPath)



--Get Build Number
set @Build = master.dbo.mdAddrGetBuildNumber(@mdAddr); --master.dbo.mdAddrGetBuildNumber(@mdAddr);
Print 'Build # ' + @Build

if @RetVal = 0 begin
	raiserror('Invalid License String.',1,2)
	raiserror('Please contact a Melissa Data sales representative at 1-800-800-6245 x3 for a valid license string.',1,2)
	return
end
if master.dbo.mdAddrInitializeDataFiles(@mdAddr) != 0 begin --master.dbo.mdAddrInitializeDataFiles(@mdAddr) != 0 begin
	declare @Error varchar(256)
	set @Error = master.dbo.mdAddrGetInitializeErrorString(@mdAddr) --master.dbo.mdAddrGetInitializeErrorString(@mdAddr)
	raiserror('Error initializing mdAddr API: "%s"', 16, 1, @Error)
	return
end


OPEN AddCursor

-- Perform the first fetch.
FETCH NEXT FROM AddCursor INTO @Company, @Address, @City, @State, @Zip

-- Check FETCH_STATUS to see if there are any more rows to fetch.
WHILE @@FETCH_STATUS = 0
BEGIN	
	SET @RecCnt = @RecCnt + 1	

	--Clear and Set Properities the Address
	set @RetVal = master.dbo.mdAddrClearProperties(@mdAddr) --master.dbo.mdAddrClearProperties(@mdAddr)
	set @RetVal = master.dbo.mdAddrSetCompany(@mdAddr, @Company) --master.dbo.mdAddrSetCompany(@mdAddr, @Company)
	set @RetVal = master.dbo.mdAddrSetAddress(@mdAddr, @Address) --master.dbo.mdAddrSetAddress(@mdAddr, @Address)
	set @RetVal = master.dbo.mdAddrSetCity(@mdAddr, @City) --master.dbo.mdAddrSetCity(@mdAddr, @City)
	set @RetVal = master.dbo.mdAddrSetState(@mdAddr, @State) --master.dbo.mdAddrSetState(@mdAddr, @State)
	set @RetVal = master.dbo.mdAddrSetZip(@mdAddr, @Zip) --master.dbo.mdAddrSetZip(@mdAddr, @Zip)
	set @RetVal = master.dbo.mdAddrVerifyAddress(@mdAddr) --master.dbo.mdAddrVerifyAddress(@mdAddr)
	
	
	set @City					= master.dbo.mdAddrGetCity(@mdAddr)  --master.dbo.mdAddrGetCity(@mdAddr) 
    set @State					= master.dbo.mdAddrGetState(@mdAddr)  --master.dbo.mdAddrGetState(@mdAddr) 
    set @Zip					= master.dbo.mdAddrGetZip(@mdAddr) --master.dbo.mdAddrGetZip(@mdAddr)
    set @Plus4					= master.dbo.mdAddrGetPlus4(@mdAddr)  --master.dbo.mdAddrGetPlus4(@mdAddr) 
	set @Suite					= master.dbo.mdAddrGetSuite(@mdAddr) --master.dbo.mdAddrGetSuite(@mdAddr)
	set @Results				= master.dbo.mdAddrGetResults(@mdAddr)  --master.dbo.mdAddrGetResults(@mdAddr) 
	set @DeliveryPointCheckDigit= master.dbo.mdAddrGetDeliveryPointCheckDigit(@mdAddr) --master.dbo.mdAddrGetDeliveryPointCheckDigit(@mdAddr)
	set @DeliveryPointCode		= master.dbo.mdAddrGetDeliveryPointCode(@mdAddr) --master.dbo.mdAddrGetDeliveryPointCode(@mdAddr)
	set @PrivateMailbox			= master.dbo.mdAddrGetPrivateMailbox(@mdAddr) --master.dbo.mdAddrGetPrivateMailbox(@mdAddr)
    
		 
	-- Update the table with new information
	UPDATE LIST SET Address_Output	= rtrim( master.dbo.mdAddrGetAddress (@mdAddr)), --master.dbo.mdAddrGetAddress (@mdAddr)), 
                    City			= @City, 
                    State			= @State, 
                    Zip				= @Zip,
                    Plus4			= @Plus4, 
					DPC				= @DeliveryPointCode + @DeliveryPointCheckDigit, 
                    Suite			= @Suite,
					PrivateMailbox  = @PrivateMailbox,
					Results			= @Results  where current of AddCursor
	
	
	
	
		-- Get next record	
	FETCH NEXT FROM AddCursor into @Company, @Address, @City, @State, @Zip
END


--Close and de-allocate cursor
CLOSE AddCursor
DEALLOCATE AddCursor

-- Destroy Address Object.
set @RetVal = master.dbo.mdAddrDestroy(@mdAddr) --master.dbo.mdAddrDestroy(@mdAddr)
