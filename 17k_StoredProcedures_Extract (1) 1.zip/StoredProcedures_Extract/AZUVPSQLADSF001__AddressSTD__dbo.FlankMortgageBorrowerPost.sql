SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankMortgageBorrowerPost] (@tableName varchar(40)) -- @tableName = 'Mortgage_Borrower' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild BorrowerFullMailAddress and BorrowerCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Mortgage_Borrower_STD]
	   --set [BorrowerFullMailAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailLeftDirection])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailStreetName]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailMode]))) + '' '' + [AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailRightDirection]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitNumber])))))))
       set [BorrowerFullMailAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailLeftDirection]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailStreetName])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailRightDirection])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitNumber]))))
	   ,[BorrowerMailHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailHouseNbr]))
	   ,[BorrowerMailLeftDirection] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailLeftDirection]))
       ,[BorrowerMailStreetName] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailStreetName])))
       ,[BorrowerMailMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailMode])))
       ,[BorrowerMailRightDirection] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailRightDirection]))
       ,[BorrowerMailUnitNumber] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitNumber]))
       ,[BorrowerMailCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailCity])))
       ,[BorrowerMailState] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailState]))
       ,[BorrowerMailZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailZIP5]))
       ,[BorrowerMailZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailZIP4]))
       ,[BorrowerMailCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailCarrierCode]))
	   ,[BorrowerMailCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailCensusTract]))
       ,[BorrowerMailUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailUnitType])))
       ,[BorrowerMailDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailDPVCount]))
       ,[BorrowerMailDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailDPVFootnote]))
       ,[BorrowerMailLACS] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailLACS]))
       ,[BorrowerMailLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailLACSLinkInd]))
       ,[BorrowerMailDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailDPCheckDigit]))
       ,[BorrowerMailDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailDPCheckCode]))
       ,[BorrowerMailCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailCensusBlock]))
       ,[BorrowerMailGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailGeoErrorCode]))
       ,[BorrowerMailGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailGeoStatusCode]))
	   ,[BorrowerMailGeoCodeResults]  = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailGeoCodeResults]))
	   ,[BorrowerMailMatchCode]  = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[BorrowerMailMatchCode]))
	   ,[FIPS] = CASE WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[FIPS]))) = 1 THEN NULL 
	             WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[FIPS]))) = 4 THEN ''0'' + ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[FIPS])) 
				 ELSE ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Borrower_STD].[FIPS])) END
	   From [AddressSTD].[dbo].[Mortgage_Borrower_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Mortgage_Borrower_to_Licensing

