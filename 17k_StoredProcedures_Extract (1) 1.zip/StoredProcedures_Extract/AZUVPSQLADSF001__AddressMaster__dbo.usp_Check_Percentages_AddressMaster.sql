SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author: Gary Mathes
-- Create date: 20220830
-- Description:	Check Percentage report (ETA duration 10 minutes)
-- =============================================
CREATE PROCEDURE [dbo].[usp_Check_Percentages_AddressMaster]
AS
BEGIN
	SET NOCOUNT ON;

-- EXEC AddressMaster.[dbo].[usp_Check_Percentages_AddressMaster]

-- Requirement: select countyfips,percentage_of_deletes from addressMaster.dbo.addressmaster with (nolock) having < 80% Is

-- step 0
--CREATE TABLE [dbo].[Address_Master_FIPS_Counts](
--	CountyFips [varchar](5) NULL,
--	DeleteRec int NULL,
--	InsertRec int NULL,
--	FIPSTotal int NULL,
--	CountDate datetime2(7),
--	PercentCalc float,
--	State varchar(2),
--	CountyName varchar(60)) 

-- select * from [AddressMaster].[dbo].[Address_Master_FIPS_Counts] order by CountyFips
-- select * from [AddressMaster].[dbo].[Address_Master] with (nolock) where FAUCIDFlag not in ('D','I') -- should be 0

/*
truncate table [AddressMaster].[dbo].[Address_Master_FIPS_Counts]
insert into [AddressMaster].[dbo].[Address_Master_FIPS_Counts] (CountyFips) 
    select CountyFips from [AddressMaster].[dbo].[Address_Master] with (nolock) group by CountyFips order by CountyFips
*/

-- step 1
select CountyFips,count(CountyFips) RecCnt, CountyName, State
    INTO #GetDataD
    from [AddressMaster].[dbo].[Address_Master] with (nolock)
    where FAUCIDFlag = 'D'
    GROUP BY CountyFips, CountyName, State
    -- select * from #GetDataD
update a
    SET a.DeleteRec = b.RecCnt, a.CountyName = b.CountyName, a.State = b.State
    FROM [AddressMaster].[dbo].[Address_Master_FIPS_Counts] a JOIN #GetDataD b
    on a.CountyFips = b.CountyFips
Drop table #GetDataD
/* slower process
	BEGIN 
		DECLARE @CountyFips varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [CountyFips] FROM [AddressMaster].[dbo].[Address_Master_FIPS_Counts] ORDER BY [CountyFips] 
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @CountyFips
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT 'update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] 
                  set DeleteRec = (select count(CountyFips) 
				  from [AddressMaster].[dbo].[Address_Master] with (nolock) 
				  where FAUCIDFlag = ''D'' and CountyFips = ' + @CountyFips + ')
				  where CountyFips = ' + @CountyFips + '' 
			EXEC('update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] 
                  set DeleteRec = (select count(CountyFips) 
				  from [AddressMaster].[dbo].[Address_Master] with (nolock) 
				  where FAUCIDFlag = ''D'' and CountyFips = ' + @CountyFips + ')
				  where CountyFips = ' + @CountyFips + '')
			FETCH NEXT FROM CurLoopProc INTO @CountyFips  
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
*/


-- step 2
select CountyFips,count(CountyFips) RecCnt
    INTO #GetDataI
    from [AddressMaster].[dbo].[Address_Master] with (nolock)
    where FAUCIDFlag = 'I'
    GROUP BY CountyFips
    -- select * from #GetDataI
update a
    SET a.InsertRec = b.RecCnt
    FROM [AddressMaster].[dbo].[Address_Master_FIPS_Counts] a JOIN #GetDataI b
    on a.CountyFips = b.CountyFips
Drop table #GetDataI
/* slower process
	BEGIN 
		DECLARE @CountyFips varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [CountyFips] FROM [AddressMaster].[dbo].[Address_Master_FIPS_Counts] ORDER BY [CountyFips] 
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @CountyFips
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT 'update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] 
                  set InsertRec = (select count(CountyFips) 
				  from [AddressMaster].[dbo].[Address_Master] with (nolock) 
				  where FAUCIDFlag = ''I'' and CountyFips = ' + @CountyFips + ')
				  where CountyFips = ' + @CountyFips + '' 
			EXEC('update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] 
                  set InsertRec = (select count(CountyFips) 
				  from [AddressMaster].[dbo].[Address_Master] with (nolock) 
				  where FAUCIDFlag = ''I'' and CountyFips = ' + @CountyFips + ')
				  where CountyFips = ' + @CountyFips + '')
			FETCH NEXT FROM CurLoopProc INTO @CountyFips  
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
*/


-- step 3
update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] set FIPSTotal = DeleteRec + InsertRec, CountDate = getdate()


-- step 4
update [AddressMaster].[dbo].[Address_Master_FIPS_Counts] set PercentCalc = round(cast(DeleteRec as float) / cast(FIPSTotal as float),4) * 100


-- step 5
select CountyFips, 
       convert(varchar,DeleteRec) as DeleteRec, 
	   convert(varchar,InsertRec) as InsertRec,
	   convert(varchar,FIPSTotal) as FIPSTotal,
	   convert(varchar, CountDate, 120) as CountDate, 
	   convert(varchar, PercentCalc) as PercentCalc,
	   state, 
	   CountyName 
	from [AddressMaster].[dbo].[Address_Master_FIPS_Counts] where PercentCalc > 20 order by CountyFips

/*
select a.CountyFips, b.[County Name], b.[state], round(cast(DeleteRec as float) / cast(FIPSTotal as float),4) * 100 AS PercentCalc, DeleteRec, InsertRec, FIPSTotal
    from [AddressMaster].[dbo].[Address_Master_FIPS_Counts] a
    join global.dbo.county b
	on a.CountyFips = b.FIPSCode
    where cast(DeleteRec as float) / cast(FIPSTotal as float) * 100 > 20.0 
	order by CountyFips
*/


END

