SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[zAdminLienPosition] (@fips as varchar(5))
AS

BEGIN
------
-----
--- Process Release Names
truncate table[DragonNameTest]. [dbo].[NameWork_V8_1_Release_Proc]

INSERT INTO [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc]
           ([ID]
           ,[Fips]
           ,[NameFormatType]
           ,[Name1])
Select
[ReleaseTransactionID]
,[FIPS]
,'1'
,Replace(Replace(ltrim(rtrim(substring([BorrowerFullName],1,100))),'.',''),',','')
from [Data].[dbo].[Transaction_Release_Skinny]
where fips = @fips
and Borrower1FullNameStd is null and ([BorrowerFullName] is not null and [BorrowerFullName] not like '')

exec [usp_name_parser_unifiedV8_1_Assn_Release] [NameWork_V8_1_Release_Proc]

update [Data].[dbo].[Transaction_Release_Skinny]
Set
       [Borrower1FirstName] = substring(p.[Name1First],1,40)
      ,[Borrower1LastName] = substring(p.[Name1Last],1,60)
      ,[Borrower1MiddleInitial] = substring(p.[Name1Middle],1,40)
      ,[Borrower1NoParsInd] = case when p.[Name1CorpInd] = 'Y' then '1' else null end
      ,[Borrower2FirstName] = p.[Name2First]
      ,[Borrower2LastName] = p.[Name2Last]
      ,[Borrower2MiddleInitial] = p.[Name2Middle]
      ,[Borrower2NoParsInd] = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then '1' else null end
	  ,Borrower1FullNameStd = case when p.[Name1CorpInd] = 'Y' then substring(p.[Name1],1,80) when [Name1fmt] like '' then null else [Name1fmt] end
	  ,Borrower2FullNameStd = case when p.[Name2CorpInd] = 'Y' and p.[Name2] is not null then substring([Name2],1,80) when [Name2fmt] like '' then null else [Name2fmt] end
from [Data].[dbo].[Transaction_Release_Skinny] s
join [DragonNameTest].[dbo].[NameWork_V8_1_Release_Proc] p
on p.id = s.ReleaseTransactionID

--- Process Release
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
      --and s.[faDeedID] is null
      --and s.[faSAMID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

-----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan2Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan2CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan2CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
    where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
    where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips
----
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan2Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan2CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan2CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Buyer1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.Loan2Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----  Mortgage
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)	
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
   where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.ContractDate = s.[OrigDeedContractDt]
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and [FASAMId] is null
	  and (m.Borrower1FullName  like '%' + substring(s.BorrowerFullName,1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

-----  Get Loose Matches
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

---
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (s.fapropertyID = m.fapropertyID)
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FADeedID] = m.TransactionId
      ,[OrigLoanAmt] = m.Loan1Amount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.Loan1CMTID
	  ,OrigLoanCMTIDInstNbr = m.Loan1CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Deed Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.deed m with (nolock)
  on m.fips = s.fips
  and m.Saledate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (s.[FAPropertyID] = m.fapropertyID)
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----  Mortgage
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (s.[FAPropertyID] = m.fapropertyID)
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.Contractdate = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  and (s.[FAPropertyID] = m.fapropertyID)
	  --and (m.Buyer1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

-----  Get Loose Matches
----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedRecordingDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and cast(m.LoanAmount as varchar) = cast(s.[OrigLoanAmt] as varchar)
	  and m.fips = @fips

----
Update [Data].[dbo].[Release]
Set 
       [FAPropertyID] = case when m.fapropertyid is not null then m.fapropertyid else s.[FAPropertyID] end
      ,[FASAMID] = m.TransactionId
      ,[OrigLoanAmt] = m.LoanAmount
	  ,Loan_PropertyID = m.[FAPropertyID]
	  ,OrigLoanCMTID = m.CMTID
	  ,OrigLoanCMTIDInstNbr = m.CMTIDInstNbr
	  ,FATimestamp = getdate() +1
	  ,FAUCIDFlag = 'U'
	  ,FAUserID = 'Release to Mortgage Supplemental Match'
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.recordingdt = s.[OrigDeedContractDt]
  --and cast(m.Loan1Amount as varchar) = cast(s.[OrigLoanAmt] as varchar)
  where --  FASAMId is null and NewSAMPID is not null
          s.[FADeedId] is null
      and s.[FASAMId] is null
	  --and [NewPropertyID] is null
	  and (m.Borrower1FullName  like '%' + substring(s.[Borrower1LastName],1,5) + '%')
	  and (s.[OrigLoanAmt] = '0' or s.[OrigLoanAmt] is null)
	  and m.fips = @fips

-----  Get Loan Amounts
Update [Data].[dbo].[Release]
set [OrigLoanAmt] = m.LoanAmount
  FROM [Data].[dbo].[Release] s
  join data.dbo.Mortgage m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FASAMId]
    where m.fips = @fips and
	([OrigLoanAmt] is null or [OrigLoanAmt] = '0')
	and m.LoanAmount > 0

---  Deed
Update [Data].[dbo].[Release]
set [OrigLoanAmt] = m.Loan1Amount
  FROM [Data].[dbo].[Release] s
  join data.dbo.Deed m with (nolock)
  on m.fips = s.fips
  and m.transactionID = s.[FADeedId]
    where m.fips = @fips and
	([OrigLoanAmt] is null or [OrigLoanAmt] = '0')
	and m.Loan1Amount > 0

----------------------
--000
truncate table data..Transaction_Mtg_LienPOS_Work_2

--001
Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--002
DROP INDEX [PropertyID] ON [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]

--003
DROP INDEX [FipsTransactionID] ON [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]

--099
--Declare @fipsBegin as varchar (5) = '01001'
--       ,@fipsEnd as varchar (5) = '56999'

Update Property
set 
       [Mtg1TransactionId] = Null
      ,[Mtg1ChronoKey] = Null
	  ,[Mtg1InputDocNbr] = Null
      ,[Mtg1InputBook] = Null
      ,[Mtg1InputPage] = Null
	  ,[Mtg1FormatDocNbr] = null
	  ,[Mtg1FormatBook] = Null
	  ,[Mtg1FormatPage] = null
	  ,[Mtg1RecordingDt] = Null
      ,[Mtg1LoanAmt] = Null
      ,[Mtg1Lender] = Null
      ,[Mtg1LenderCode] = Null
      ,[Mtg1LenderType] = Null
      ,[Mtg1PrivateLender] = Null
      ,[Mtg1Term] = Null
      ,[Mtg1LoanDueDt] = Null
      ,[Mtg1AdjRider] = Null
      ,[Mtg1LoanType] = Null
      ,[Mtg1Typefinancing] = Null
      ,[Mtg1LienPosition] = Null
      ,[Mtg2TransactionId] = Null
      ,[Mtg2ChronoKey] = Null
	  ,[Mtg2InputDocNbr] = Null
      ,[Mtg2InputBook] = Null
      ,[Mtg2InputPage] = Null
	  ,[Mtg2FormatDocNbr] = null
	  ,[Mtg2FormatBook] = Null
	  ,[Mtg2FormatPage] = null
	  ,[Mtg2RecordingDt] = Null
      ,[Mtg2LoanAmt] = Null
      ,[Mtg2Lender] = Null
      ,[Mtg2LenderCode] = Null
      ,[Mtg2LenderType] = Null
      ,[Mtg2PrivateLender] = Null
      ,[Mtg2Term] = Null
      ,[Mtg2LoanDueDt] = Null
      ,[Mtg2AdjRider] = Null
      ,[Mtg2LoanType] = Null
      ,[Mtg2Typefinancing] = Null
      ,[Mtg2LienPosition] = Null
      ,[Mtg3TransactionId] = Null
      ,[Mtg3ChronoKey] = Null
	  ,[Mtg3InputDocNbr] = Null
      ,[Mtg3InputBook] = Null
      ,[Mtg3InputPage] = Null
	  ,[Mtg3FormatDocNbr] = null
	  ,[Mtg3FormatBook] = Null
	  ,[Mtg3FormatPage] = null
	  ,[Mtg3RecordingDt] = Null
      ,[Mtg3LoanAmt] = Null
      ,[Mtg3Lender] = Null
      ,[Mtg3LenderCode] = Null
      ,[Mtg3LenderType] = Null
      ,[Mtg3PrivateLender] = Null
      ,[Mtg3Term] = Null
      ,[Mtg3LoanDueDt] = Null
      ,[Mtg3AdjRider] = Null
      ,[Mtg3LoanType] = Null
      ,[Mtg3Typefinancing] = Null
      ,[Mtg3LienPosition] = Null
      ,[Mtg4TransactionId] = Null
      ,[Mtg4ChronoKey] = Null
	  ,[Mtg4InputDocNbr] = Null
      ,[Mtg4InputBook] = Null
      ,[Mtg4InputPage] = Null
	  ,[Mtg4FormatDocNbr] = null
	  ,[Mtg4FormatBook] = Null
	  ,[Mtg4FormatPage] = null
	  ,[Mtg4RecordingDt] = Null
      ,[Mtg4LoanAmt] = Null
      ,[Mtg4Lender] = Null
      ,[Mtg4LenderCode] = Null
      ,[Mtg4LenderType] = Null
      ,[Mtg4PrivateLender] = Null
      ,[Mtg4Term] = Null
      ,[Mtg4LoanDueDt] = Null
      ,[Mtg4AdjRider] = Null
      ,[Mtg4LoanType] = Null
      ,[Mtg4Typefinancing] = Null
      ,[Mtg4LienPosition] = Null
	  ,[TotalOpenLienAmt] = Null
	  ,[TotalOpenLienNbr] = Null
	  ,[LienPosUpdateFlag] = 'Y'
	  ,[FAEnhanceprocessDt] = Getdate() + 1
	  ,[Mtg1EstLoanBalance] = Null
      ,[Mtg1EstPaymentAmt] = Null
      ,[Mtg1InterestRate] = Null
      ,[Mtg2EstLoanBalance] = Null
      ,[Mtg2EstPaymentAmt] = Null
      ,[Mtg2InterestRate] = Null
      ,[Mtg3EstLoanBalance] = Null
      ,[Mtg3EstPaymentAmt] = Null
      ,[Mtg3InterestRate] = Null
      ,[Mtg4EstLoanBalance] = Null
      ,[Mtg4EstPaymentAmt] = Null
      ,[Mtg4InterestRate] = Null
from Property p
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PropMatch_WORK_FLANK dd
  --  on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
  where p.fips = @fips  --between @fipsBegin and @fipsEnd
  and ([Mtg1TransactionId] is not null or [Mtg2TransactionId] is not null or [Mtg3TransactionId] is not null)
  --and p.fips in ('04013','06037','06059','06073','06065','06075')
--p.fips in ('18043','41051','06065','13223','42071','06037','36081','36047','11001','06033','18089')  --between '54001' and '56999' --and --= '09001'
--and PropertyID  = 5428713
--[TotalOpenLienNbr] > 0

--100
--Declare @fipsBegin as varchar (5) = '01001'
--       ,@fipsEnd as varchar (5) = '56999'

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(d.ChronoKey,1,31)
           ,Substring(d.Loan1Document,1,20)
           ,Substring(d.Loan1Book,1,10)
           ,Substring(d.Loan1Page,1,10)
           ,[Loan1YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],1,(charindex('.',[Loan1BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],(charindex('.',[Loan1BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan1Amount as int)
           ,Substring(d.Loan1LenderName,1,30)
           ,Substring(d.Loan1LenderCode,1,10)
           ,Substring(d.Loan1LenderTypeCode,1,5)
           ,case when d.Loan1PrivatePartyLender = 1 then 1 else null end
           ,Ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan1AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan1Type,1,10)
           ,Substring(d.Loan1TypeFinance,1,10)
           ,case when DeedTransactionType = '2' then 1 when DeedTransactionType = '1' then null end  --1 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan1InterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Deed d with (Nolock) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer2FullName,1,4))
(((
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer1FullName,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer2FullName,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer1FullName,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer2FullName,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or
((difference(d.Buyer1FullName,p.OwnerStdNAME1FULL)>2)
or
(difference(d.Buyer2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(d.Buyer1FullName,p.OwnerStdNAME2FULL) >2) 
--or
--(difference(d.Buyer2FullName,p.OwnerStdNAME2FULL) >2)
)
or
(substring(replace(d.Buyer1firstName,' ',''),1,3) = substring(replace(p.OwnerStd1FirstName,' ',''),1,3))
or
(substring(replace(d.Buyer1firstName,' ',''),1,3) = substring(replace(p.OwnerStd1MiddleName,' ',''),1,3))
or
(p.OwnerStdNAME1FULL like '%trust%')
or
(p.OwnerStdNAME2FULL like '%trust%')
or
(p.OwnerStdNAME1FULL like '%owner record%')
or
(p.OwnerStdNAME1FULL like '%not avail%')
)
and d.Loan1Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44')
--and d.recordingdt < '20190301'
--and p.fips between @fipsBegin and @fipsEnd)  --  between '54001' and '56999'  --= '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID = 5428713 )
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and d.Loan1Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(d.ChronoKey,1,31)
           ,Substring(d.Loan2Document,1,20)
           ,Substring(d.Loan2Book,1,10)
           ,Substring(d.Loan2Page,1,10)
           ,[Loan2YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],1,(charindex('.',[Loan2BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],(charindex('.',[Loan2BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan2Amount as int)
           ,Substring(d.Loan2LenderName,1,30)
           ,Substring(d.Loan2LenderCode,1,10)
           ,Substring(d.Loan2LenderTypeCode,1,5)
           ,case when d.Loan2PrivatePartyLender = 1 then 1 else null end
           ,ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan2AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan2Type,1,10)
           ,Substring(d.Loan2TypeFinance,1,10)
           ,case when DeedTransactionType = '2' then 2 when DeedTransactionType = '1' then null end  -- 2 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan2InterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Deed d with (Nolock) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer2FullName,1,4))
(((
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer1FullName,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer2FullName,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer1FullName,1,3) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer2FullName,1,3) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or
((difference(d.Buyer1FullName,p.OwnerStdNAME1FULL)>2)
or
(difference(d.Buyer2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(d.Buyer1FullName,p.OwnerStdNAME2FULL) >2) 
--or
--(difference(d.Buyer2FullName,p.OwnerStdNAME2FULL) >2)
)
or
(substring(replace(d.Buyer1firstName,' ',''),1,3) = substring(replace(p.OwnerStd1FirstName,' ',''),1,3))
or
(substring(replace(d.Buyer1firstName,' ',''),1,3) = substring(replace(p.OwnerStd1MiddleName,' ',''),1,3))
or
(p.OwnerStdNAME1FULL like '%trust%')
or
(p.OwnerStdNAME2FULL like '%trust%')
or
(p.OwnerStdNAME1FULL like '%owner record%')
or
(p.OwnerStdNAME1FULL like '%not avail%')
)
and d.Loan2Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'  --  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
--and d.recordingdt < '20190301'
and DocumentTypeCode not in ('22','44')
--and p.fips between @fipsBegin and @fipsEnd)  --  between '54001' and '56999'  --= '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID  = 5428713)
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and d.Loan2Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))


----  Use Sup Tables

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(d.ChronoKey,1,31)
           ,Substring(d.Loan1Document,1,20)
           ,Substring(d.Loan1Book,1,10)
           ,Substring(d.Loan1Page,1,10)
           ,[Loan1YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],1,(charindex('.',[Loan1BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],(charindex('.',[Loan1BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan1Amount as int)
           ,Substring(d.Loan1LenderName,1,30)
           ,Substring(d.Loan1LenderCode,1,10)
           ,Substring(d.Loan1LenderTypeCode,1,5)
           ,case when d.Loan1PrivatePartyLender = 1 then 1 else null end
           ,Ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan1AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan1Type,1,10)
           ,Substring(d.Loan1TypeFinance,1,10)
           ,1 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan1InterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Deed_Sup d with (Nolock) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer2FullName,1,4))
(((
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer1FullName,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer2FullName,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer1FullName,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer2FullName,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or
((difference(d.Buyer1FullName,p.OwnerStdNAME1FULL)>2)
or
(difference(d.Buyer2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(d.Buyer1FullName,p.OwnerStdNAME2FULL) >2) 
--or
--(difference(d.Buyer2FullName,p.OwnerStdNAME2FULL) >2)
))
and d.Loan1Amount > 0
and d.FAUCIDFlag <> 'D'
and DocumentTypeCode not in ('22','44')
--and d.recordingdt < '20190301'
--and p.fips between @fipsBegin and @fipsEnd)  --  between '54001' and '56999'  --= '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID = 5428713)
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and d.Loan1Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(d.ChronoKey,1,31)
           ,Substring(d.Loan2Document,1,20)
           ,Substring(d.Loan2Book,1,10)
           ,Substring(d.Loan2Page,1,10)
           ,[Loan2YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],1,(charindex('.',[Loan2BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],(charindex('.',[Loan2BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan2Amount as int)
           ,Substring(d.Loan2LenderName,1,30)
           ,Substring(d.Loan2LenderCode,1,10)
           ,Substring(d.Loan2LenderTypeCode,1,5)
           ,case when d.Loan2PrivatePartyLender = 1 then 1 else null end
           ,ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan2AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan2Type,1,10)
           ,Substring(d.Loan2TypeFinance,1,10)
           ,2 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan2InterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Deed_Sup d with (Nolock) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer2FullName,1,4))
(((
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer1FullName,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(d.Buyer2FullName,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((d.Buyer1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer1FullName,1,4) + '%') and (d.Buyer1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((d.Buyer2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(d.Buyer2FullName,1,4) + '%') and (d.Buyer2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or
((difference(d.Buyer1FullName,p.OwnerStdNAME1FULL)>2)
or
(difference(d.Buyer2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(d.Buyer1FullName,p.OwnerStdNAME2FULL) >2) 
--or
--(difference(d.Buyer2FullName,p.OwnerStdNAME2FULL) >2)
))
and d.Loan2Amount > 0
and d.FAUCIDFlag <> 'D'
--and d.recordingdt < '20190301'
and DocumentTypeCode not in ('22','44')
--and p.fips between @fipsBegin and @fipsEnd)  --  between '54001' and '56999'  --= '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID  = 5428713)
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and d.Loan1Amount > 0
and d.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))

--101

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,[RefiFlag]
		   ,[EquityFlag]
		   ,[HELCOCFlag]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(m.Borrower1FullName,1,80)
           ,m.TransactionId
           ,substring(m.ChronoKey,1,31)
           ,Substring(m.DocNbrSrce,1,20)
           ,Substring(m.BookSrce,1,10)
           ,Substring(m.PageSrce,1,10)
           ,[YearDocNbrFrmt] --Docnumberformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],1,(charindex('.',[BkPgFrmt])-1)))) else null end --Bookformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],(charindex('.',[BkPgFrmt])+1),9))) else null end --PageFormatted
           ,Substring(m.RecordingDt,1,10)
           ,cast(m.LoanAmount as int)
           ,Substring(m.lendername,1,30)
           ,Substring(m.LenderCode,1,10)
           ,Substring(m.LenderTypeCode,1,5)
           ,case when m.LenderPrivateInd is not null then 1 else null end
           ,Ltrim(rtrim(m.LoanTermMonths))
           ,Substring(m.LoanDueDate,1,10)
           ,case when m.LoanAdjRateIndex is not null then 'Y' else null end
           ,Substring(m.LoanType,1,10)
           ,Substring(m.TypeFinance,1,10)
           ,null --LienPosition
           ,Substring(m.FADateReceived,1,8)
		   ,m.LoanRefiLoanInd
		   ,m.LoanEquityLoanInd
		   ,m.LoanHELOCLoanInd
		   ,m.LoanInterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Mortgage m with (Nolock) on m.Fips = p.FIPS and 
m.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower2FullName,1,4))
(((
((m.Borrower1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(m.Borrower1FullName,1,3) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((m.Borrower2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,3) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(m.Borrower2FullName,1,3) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((m.Borrower1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(m.Borrower1FullName,1,3) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((m.Borrower2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,3) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(m.Borrower2FullName,1,3) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or 
((difference(m.Borrower1FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(m.Borrower2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(m.Borrower1FullName,p.OwnerStdNAME2FULL) >2)
--or
--(difference(m.Borrower2FullName,p.OwnerStdNAME2FULL) >2)
)
or
(substring(replace(m.Borrower1FirstName,' ',''),1,3) = substring(replace(p.OwnerStd1FirstName,' ',''),1,3))
or
(substring(replace(m.Borrower1FirstName,' ',''),1,3) = substring(replace(p.OwnerStd1MiddleName,' ',''),1,3))
or
(p.OwnerStdNAME1FULL like '%trust%')
or
(p.OwnerStdNAME2FULL like '%trust%')
or
(p.OwnerStdNAME1FULL like '%owner record%')
or
(p.OwnerStdNAME1FULL like '%not avail%')
)
and m.LoanAmount > 0
and m.FAUCIDFlag <> 'D'
--and m.recordingdt < '20190301'
--and p.fips between @fipsBegin and @fipsEnd)  -- between '54001' and '56999'  -- = '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID  = 5428713)
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and m.LoanAmount > 0
and m.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))

---  Use Sup Tables

INSERT INTO [dbo].[Transaction_Mtg_LienPOS_Work_2]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,[RefiFlag]
		   ,[EquityFlag]
		   ,[HELCOCFlag]
		   ,InterestRate)
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(m.Borrower1FullName,1,80)
           ,m.TransactionId
           ,substring(m.ChronoKey,1,31)
           ,Substring(m.DocNbrSrce,1,20)
           ,Substring(m.BookSrce,1,10)
           ,Substring(m.PageSrce,1,10)
           ,[YearDocNbrFrmt] --Docnumberformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],1,(charindex('.',[BkPgFrmt])-1)))) else null end --Bookformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],(charindex('.',[BkPgFrmt])+1),9))) else null end --PageFormatted
           ,Substring(m.RecordingDt,1,10)
           ,cast(m.LoanAmount as int)
           ,Substring(m.lendername,1,30)
           ,Substring(m.LenderCode,1,10)
           ,Substring(m.LenderTypeCode,1,5)
           ,case when m.LenderPrivateInd is not null then 1 else null end
           ,Ltrim(rtrim(m.LoanTermMonths))
           ,Substring(m.LoanDueDate,1,10)
           ,case when m.LoanAdjRateIndex is not null then 'Y' else null end
           ,Substring(m.LoanType,1,10)
           ,Substring(m.TypeFinance,1,10)
           ,null --LienPosition
           ,Substring(m.FADateReceived,1,8)
		   ,m.LoanRefiLoanInd
		   ,m.LoanEquityLoanInd
		   ,m.LoanHELOCLoanInd
		   ,m.LoanInterestRate
from data..Property p with (Nolock)
--join [Data].[dbo].[zSchoolsfirst_Transaction_PropID] s
--on s.fips = p.FIPS
--and s.FAPropertyID = p.propertyid
--join zCust_ADS__S12_OpenLien.dbo.a_propmatch_work_FLANK_SCHOOL s
--on s.propertyid = p.propertyid
--join [Data].[dbo].[zzFreedomInput] f
--on f.PROPERTYID = p.PropertyID
--join DailyPropID s on s.fips = p.fips and s.propertyid = p.PropertyID
  --join zCust_ADS__S12_OpenLien.dbo.a_PRopmatch_WORK_FLANK dd
  --on dd.fips = p.fips
  --and dd.PropertyID = p.propertyid
join data..Mortgage_Sup m with (Nolock) on m.Fips = p.FIPS and 
m.FAPropertyId = p.PropertyID
where --(substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower2FullName,1,4))
(((
((m.Borrower1FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(m.Borrower1FullName,1,4) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((m.Borrower2FullName like '%' + substring(p.OwnerStdNAME1FULL,1,4) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((p.OwnerStdNAME1FULL like '%' + substring(m.Borrower2FullName,1,4) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME1FULL not like ''))
or
((m.Borrower1FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(m.Borrower1FullName,1,4) + '%') and (m.Borrower1FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((m.Borrower2FullName like '%' + substring(p.OwnerStdNAME2FULL,1,4) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
or
((p.OwnerStdNAME2FULL like '%' + substring(m.Borrower2FullName,1,4) + '%') and (m.Borrower2FullName not like '' and p.OwnerStdNAME2FULL not like ''))
)
or 
((difference(m.Borrower1FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(m.Borrower2FullName,p.OwnerStdNAME1FULL) >2)
or
(difference(m.Borrower1FullName,p.OwnerStdNAME2FULL) >2)
--or
--(difference(m.Borrower2FullName,p.OwnerStdNAME2FULL) >2)
)
or 
(substring(replace(m.Borrower1FirstName,' ',''),1,4) = substring(replace(p.OwnerStd1FirstName,' ',''),1,4))
or
(substring(replace(m.Borrower1FirstName,' ',''),1,4) = substring(replace(p.OwnerStd1MiddleName,' ',''),1,4))
or
(p.OwnerStdNAME1FULL like '%trust%')
or
(p.OwnerStdNAME2FULL like '%trust%')
or
(p.OwnerStdNAME1FULL like '%owner record%')
or
(p.OwnerStdNAME1FULL like '%not avail%')
)
and m.LoanAmount > 0
and m.FAUCIDFlag <> 'D'
--and m.recordingdt < '20190301'
--and p.fips between @fipsBegin and @fipsEnd)  -- between '54001' and '56999'  -- = '09001'
--and p.fips in ('04013','06037','06059','06073','06065','06075'))
--and PropertyID  = 5428713)
)
or 
((p.fips between '04001' and '04999' or p.fips between '12001' and '12999')
and m.LoanAmount > 0
and m.FAUCIDFlag <> 'D'
--and DeedTransactionType = '2'--  20231027 BR Added to differentiate ARMS's length and non ARMS's Length
and DocumentTypeCode not in ('22','44'))

--102

UPDATE data.dbo.[Transaction_Mtg_LienPOS_Work_2]
 SET Term =  CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) > 999 THEN '999' 
					   When (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) < 0 then '0'
                       ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) 
                       END
                       WHERE LoanDueDt is not null
                             and (Term is NULL or Term like '' or Term like '000')
                             and RecordingDt is not null and RecordingDt not like ''

 UPDATE data.dbo.[Transaction_Mtg_LienPOS_Work_2]
 SET Term = '360'
 ----  20230419 BR Added to roll out extremely old mortgages
 ,LoanDueDt = convert(varchar(8),DATEADD(YY,30,Convert(datetime,RecordingDt)),112) 
  WHERE LoanDueDt is NULL
  AND RecordingDt > convert(varchar(8),DateAdd(YY,-30,GETDATE()),112)

 UPDATE data.dbo.[Transaction_Mtg_LienPOS_Work_2]
 SET Term = '360'
 ----  20230419 BR Added to roll out extremely old mortgages
 ,LoanDueDt = convert(varchar(8),DATEADD(YY,30,Convert(datetime,RecordingDt)),112) 
  WHERE LoanDueDt is NULL
  AND RecordingDt > LoanDueDt

 UPDATE data.dbo.[Transaction_Mtg_LienPOS_Work_2]
 SET Term = Null
  WHERE Term Like '%-%' or Term like '%[a-z]%'

---- ADDED 20221222 MAS
Update data.dbo.[Transaction_Mtg_LienPOS_Work_2]
 SET Term = 999
  WHERE LoanType = '32'

--151
SET ANSI_PADDING ON

CREATE NONCLUSTERED INDEX [FipsTransactionID] ON data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
(
	[FIPS] ASC,
	[TransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


--200
Update data..Transaction_Mtg_LienPOS_Work_2
Set AssgnFlag = 'Y'
,AssgnDate = a.RecordingDt
from Transaction_Mtg_LienPOS_Work w
join data..Assignment a with (noLock)
on a.fips = w.fips and w.transactionid = a.FADeedId

Update data..Transaction_Mtg_LienPOS_Work_2
Set AssgnFlag = 'Y'
,AssgnDate = a.RecordingDt
from data..Transaction_Mtg_LienPOS_Work_2 w
join data..Assignment a with (noLock)
on a.fips = w.fips and w.transactionid = a.FASamId

----  BR Added to Handle Modifications  20231129 BR Commented out Second Section for Freedom 
Update data..Transaction_Mtg_LienPOS_Work_2
Set ModDate = a.RecordingDt
,ModAmount = case when convert(bigint,a.UnpaidBalance) <2300000000 then convert(int,a.UnpaidBalance) else null end
,modduedate = case when isdate(a.LoanDueDate) = 1 then a.LoanDueDate else null end 
from data..Transaction_Mtg_LienPOS_Work_2 w
join data..Mortgage_Mods a with (noLock)
on a.fips = w.fips and w.transactionid = a.[LoanTransactionId]
where convert(money,a.UnpaidBalance) <2300000000

----Update Transaction_Mtg_LienPOS_Work
----Set LoanAmt = case when ModAmount is not null then ModAmount else LoanAmt end
----,LoanDueDt = case when isdate(modduedate) = 1 then modduedate else LoanDueDt end
----from Transaction_Mtg_LienPOS_Work
----where moddate is not null 

--  Term
UPDATE data..Transaction_Mtg_LienPOS_Work_2
 SET Term =  CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) > 999 THEN '999' 
					   WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) < 0 THEN '0' 
                       ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) 
                       END
                       WHERE LoanDueDt is not null
                             --and (Term is NULL or Term like '' or Term like '000')
                             and RecordingDt is not null and RecordingDt not like ''
							 and moddate is not null

 UPDATE data..Transaction_Mtg_LienPOS_Work_2
 SET Term = '360'
  WHERE LoanDueDt is NULL
  AND RecordingDt > convert(varchar(8),DateAdd(YY,-30,GETDATE()),112)
  and  moddate is not null

 UPDATE data..Transaction_Mtg_LienPOS_Work_2
 SET Term = Null
  WHERE Term Like '%-%' or Term like '%[a-z]%'
  and moddate is not null

------
--201

Update data..Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from data..Transaction_Mtg_LienPOS_Work_2 w
join data..release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FADeedId --and w.PropertyID = r.faPropertyID
where substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)

Update data..Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from data..Transaction_Mtg_LienPOS_Work_2 w
join data..release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FASAMID --and w.PropertyID = r.faPropertyID
where substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)

Update data..Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = null
,ReleaseDate = null
,ReleaseTransactionID = null
from data..Transaction_Mtg_LienPOS_Work_2
where recordingdt > Releasedate

----  Dedup Process

drop table [Data].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups_2]

select fips, propertyid, coalesce(([FormatBook] + [FormatPage]),[FormatDocNbr],[InputDocNbr]) as DocNum, count(propertyid) as cnt, min(transactionid) as MinTID
  into [Data].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups_2]
    FROM data..Transaction_Mtg_LienPOS_Work_2
	where coalesce([FormatDocNbr],([FormatBook] + [FormatPage]),[InputDocNbr]) is not null
	group by fips, propertyid, coalesce(([FormatBook] + [FormatPage]),[FormatDocNbr],[InputDocNbr])
	having count(propertyid) > 1

Update [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Set DeleteFlag = 'D'
from [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2] w
join [Data].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups_2] d
on d.fips = w.fips
and d.propertyid = w.propertyid
and d.docNum = coalesce(([FormatBook] + [FormatPage]),[FormatDocNbr],[InputDocNbr])
where w.TransactionId <> MinTID

Delete from [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where DeleteFlag = 'D'

--202

Update data.dbo.Transaction_Mtg_LienPOS_Work_2
SET CurrentAVM = coalesce(v.[PREMIER_FINAL_VALUE],v.[POWER_FINAL_VALUE],v.[DIRECT_FINAL_VALUE]) 
From data.dbo.Transaction_Mtg_LienPOS_Work_2 w
	JOIN Holocron.dbo.Holocron v with (noLock)
ON v.Fipscode = w.FIPS
and v.PropertyID = w.PropertyID

Update data.dbo.Transaction_Mtg_LienPOS_Work_2
SET CurrentAVM = FINAL_VALUE
From data.dbo.Transaction_Mtg_LienPOS_Work_2 w
	JOIN data.dbo.avm v with (noLock)
ON v.Fips = w.FIPS
and v.PropertyID = w.PropertyID
where CurrentAVM is null

---  Added 20180816 to use MArket Value and Assessed Value

Update Data.dbo.[Transaction_Mtg_LienPOS_Work_2]
set currentAVM = Coalesce(Case WHEN MarketTotalValue = 0 THEN NULL ELSE MarketTotalValue END,AssdTotalValue)
From Data.dbo.[Transaction_Mtg_LienPOS_Work_2] w
Join Data.dbo.Property v with (nolock)
on v.fips = w.fips and v.PropertyID = w.PropertyID
WHERE isNULL(currentAVM,'0') like '0'


---- Added 2023113 to add 0 to current AVM
Update Data.dbo.[Transaction_Mtg_LienPOS_Work_2]
set currentAVM = 0
From Data.dbo.[Transaction_Mtg_LienPOS_Work_2] w
Join Data.dbo.Property v with (nolock)
on v.fips = w.fips and v.PropertyID = w.PropertyID
WHERE currentAVM is null


---  Calc Refi and Equity

---- Commented OUT next 2 queries They are in the next Query 20221222 MAS

--update [Transaction_Mtg_LienPOS_Work]
--set CalcRefi = 'Y'
--from [Transaction_Mtg_LienPOS_Work]
--where 
--(Recordingdt between '20170101' and '21991231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.50)
--or
--(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.45)
--or
--(Recordingdt between '19900101' and '20091231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.35)

--update [Transaction_Mtg_LienPOS_Work]
--set CalcEquity = 'Y'
--from [Transaction_Mtg_LienPOS_Work]
--where 
--(Recordingdt between '20100101' and '21991231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.50)
--or
--(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.45)
--or
--(Recordingdt between '19900101' and '20091231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.35)


--update Transaction_Mtg_LienPOS_Work
--set
--CalcRefi = null
--,CalcEquity = null
--from Transaction_Mtg_LienPOS_Work

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcRefi = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and RefiFlag is not null and CalcRefi is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and (LienPosition =2 or EquityFlag is not null) and CalcEquity is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcRefi = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and RefiFlag is null and CalcRefi is null and LoanAmt > 99999  and CalcEquity is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and LoanAmt < 100000  and CalcRefi is null 

-----  Added 20231113 to have all Mtgs with Calc Equity
update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and CalcRefi is null

--203

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcRefi = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where 
(Recordingdt between '20210101' and '21991231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.50)
or
(Recordingdt between '20170101' and '20201231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.42)
or
(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.33)
or
(Recordingdt between '20070101' and '20091231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.25)
or
(Recordingdt between '19900101' and '20061231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.18)

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where 
(Recordingdt between '20210101' and '21991231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.50)
or
(Recordingdt between '20170101' and '20201231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.42)
or
(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.33)
or
(Recordingdt between '20070101' and '20091231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.25)
or
(Recordingdt between '19900101' and '20061231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.18)
and CalcRefi is null

--update Transaction_Mtg_LienPOS_Work
--set
--CalcRefi = null
--,CalcEquity = null
--from Transaction_Mtg_LienPOS_Work

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcRefi = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and RefiFlag is not null and CalcRefi is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and (LienPosition =2 or EquityFlag is not null) and CalcEquity is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcRefi = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM = 0 and RefiFlag is null and CalcRefi is null and LoanAmt > 39999  and CalcEquity is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
set CalcEquity = 'Y'
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and LoanAmt < 40000  and CalcRefi is null 

--211

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [LienPosition] = 1
order by [ChronoKey] desc

--212

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set LastPurchase = t.RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.PropertyID = t.PropertyID

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set PropLastPurchase = p.CurrSaleRecordingDate
,Seller = p.CurrSaleSeller1FullName
from data..[Transaction_Mtg_LienPOS_Work_2] t
join data..property p with (nolock)
on p.fips = t.fips and p.propertyid = t.PropertyID

--213

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--221

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where [LienPosition] is null and CalcRefi = 'Y'
order by [ChronoKey] desc

--222

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set LastRefi = t.RecordingDt
,LastRefiAmt = t.LoanAmt
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.PropertyID = t.PropertyID

--223

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--231

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,Loanamt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where [LienPosition] is null and CalcEquity = 'Y'
order by [ChronoKey] desc

--232

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set LastEquity = t.RecordingDt
,LastEquityAmt = t.LoanAmt
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.PropertyID = t.PropertyID

--233

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--301

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CalcMtgOrder is null and ([LienPosition] is null or [LienPosition] = 1)
order by [ChronoKey] desc
--RecordingDt desc, 

--302

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 1
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 2
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

--303

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--311

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 

--312

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 2
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
and CalcMtgOrder is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 3
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

--313

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--321

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 

--322

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 3
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 4
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

--323

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--331

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 

--332

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 4
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcMtgOrder = 5
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

-----  Number 5
Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
-----
INSERT INTO [Data].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 
------
update [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Set CalcMtgOrder = 5
from [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2] w
join [Data].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Set CalcMtgOrder = 6
from [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2] w
join [Data].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

--333

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--USE [Data]

--INSERT INTO [dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
--           ([FIPS]
--           ,[PropertyID]
--           ,[TransactionId]
--           ,[ChronoKey]
--           ,[LienPosition]
--		   ,RecordingDt)
--Select
--            [FIPS]
--           ,[PropertyID]
--           ,[TransactionId]
--           ,[ChronoKey]
--           ,[LienPosition]
--		   ,RecordingDt
--from [dbo].[Transaction_Mtg_LienPOS_Work]
--where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
--order by [ChronoKey] desc
----RecordingDt desc, 

----
--use data

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcMtgOrder = 5
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.TransactionId = t.TransactionId
--where CalcMtgOrder is null

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcMtgOrder = 6
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.TransactionId = t.TransactionId
--where t.TransactionId = 1 and w.TransactionId = 2

----
--Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]

--400

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'W'
FROM data.dbo.Transaction_Mtg_LienPOS_Work_2
where [ReleaseFlag] is null and LoanDueDt <  Cast(format(GetDate()-1,'yyyyMMdd') as varchar)

--update [Transaction_Mtg_LienPOS_Work]
--Set ReleaseFlag = 'P'
--FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work]
--where [ReleaseFlag] is null and [LastPurchase] is not null and [LastPurchase] > [RecordingDt] and LienPosition is not null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'Q'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [LastPurchase] is not null and [LastPurchase] > convert(varchar(8), convert(datetime,[RecordingDt])+7,112) and LienPosition is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'R'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [PropLastPurchase] is not null and [PropLastPurchase] > convert(varchar(8), convert(datetime,[RecordingDt])+7,112) --and LienPosition is null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'S'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [LastPurchase] is not null and [LastRefi] > [LastPurchase] and LienPosition is not null

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'T'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [LastRefi] > [RecordingDt] and CalcRefi ='Y'
and Cast((cast(LoanAmt as float) + cast(LastEquityAmt as float)) as float) > CurrentAVM * .9

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'U'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [LastRefi] > [RecordingDt] and CalcEquity = 'Y'
and Cast((cast(LoanAmt as float) + cast(LastRefiAmt as float)) as float) > CurrentAVM *1.1  --*.9

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'V'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and [LastEquity] > [RecordingDt] and CalcEquity ='Y' --and Cast((cast(LoanAmt as float)/cast(LastEquityAmt as float)) as float) <.65
and Cast((cast(LoanAmt as float) + cast(LastEquityAmt as float)) as float) > CurrentAVM * .9

update data.dbo.Transaction_Mtg_LienPOS_Work_2      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'X'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where Releaseflag is null and Calcrefi is null and Calcequity is null
and lastequity > recordingdt
and cast(lastequityamt as float) > cast(cast(loanamt as float) * .50 as float)
and recordingdt <'20121231'

----   20230419  BR added to close old mortgages not closed before
update data.dbo.Transaction_Mtg_LienPOS_Work_2      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'Z'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where Releaseflag is null 
and convert(varchar(8),DateAdd(YY,+15,RecordingDT),112) < convert(varchar(8),GETDATE(),112)
and CalcMtgOrder is null

--update [Transaction_Mtg_LienPOS_Work]      ---   20180318  BR Added due to last equity not closing old original Mortgage
--Set ReleaseFlag = 'z'
--FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work]
--where Releaseflag is null 
--and convert(varchar(8),DateAdd(YY,+15,RecordingDT),112) < convert(varchar(8),GETDATE(),112)
--and substring(OwnerStdNAME1FULL,1,4) <> substring(TransNAME1FULL,1,4)
--and OwnerStdNAME1FULL not like '%trust%'

update data.dbo.Transaction_Mtg_LienPOS_Work_2      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'z'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where Releaseflag is null 
and convert(varchar(8),DateAdd(YY,+21,RecordingDT),112) < convert(varchar(8),GETDATE(),112)

update data.dbo.Transaction_Mtg_LienPOS_Work_2    ---   20180320  BR Added to keep Mtgs that have a more recent Assignment
Set ReleaseFlag = null
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Where [AssgnDate] is not null
and ([AssgnDate] > isnull(lastrefi,0) and [AssgnDate] > isnull(lastequity,0) and [AssgnDate] > isnull(lastpurchase,0) and [AssgnDate] > [recordingdt])
and (releaseflag is not null and releaseflag != 'Y')

update data.dbo.Transaction_Mtg_LienPOS_Work_2    ---   20200108  BR Added to keep Mtgs that have a more recent Modification
Set ReleaseFlag = null
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Where [ModDate] is not null
and ([ModDate] > isnull(lastrefi,0) and [ModDate] > isnull(lastequity,0) and [ModDate] > isnull(lastpurchase,0) and [ModDate] > [recordingdt])
and (releaseflag is not null and releaseflag != 'Y')
and [PropLastPurchase] < [recordingdt]

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set ReleaseFlag = 'W'
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
where [ReleaseFlag] is null and LoanDueDt <  Cast(format(GetDate()-1,'yyyyMMdd') as varchar) 

-----  BR Added to account for certain lenders

update data.dbo.Transaction_Mtg_LienPOS_Work_2    ---   20200108  BR Added to keep Mtgs that have a more recent Modification
Set ReleaseFlag = null
FROM [Data].[dbo].[Transaction_Mtg_LienPOS_Work_2]
Where 
([Lender] like 'NATIONAL HOMEBUYERS FUND%' 
or
[Lender] like 'CRHMFA HOMEBUYERS FUND%')
and ReleaseFlag = 'S'

--501

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where ((CalcLienPos is null and ReleaseFlag is null and CalcRefi = 'Y')
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 1))
and CalcMtgOrder is not null
order by [ChronoKey] desc

--502

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 1
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where w.LienPosition = 1 or t.LienPosition is null

--503

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--511

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where ((CalcLienPos is null and ReleaseFlag is null and CalcRefi = 'Y')
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 1)
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 2)  --  Added during Accurate Mtg QC
or
(CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))   --  this is the original
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages

order by [ChronoKey] asc

--512

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 2
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where ((w.LienPosition = 2 or t.LienPosition is null)
or (w.LienPosition = 1 or t.LienPosition is null))
and w.CalcLienPos is null

--513

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--521

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
order by [ChronoKey] asc

--522 --Filename is 522 bit labeled as 502****

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 3
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where (w.LienPosition = 2 or t.LienPosition is null)
and w.CalcLienPos is null

--523

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--531

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
order by [ChronoKey] asc

--532

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 4
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where w.LienPosition = 2 or t.LienPosition is null

--533

Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

----- Number 5
INSERT INTO [Data].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from data.dbo.Transaction_Mtg_LienPOS_Work_2
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
order by [ChronoKey] asc
---
update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 5
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.TransactionId = t.TransactionId
where w.LienPosition = 2 or t.LienPosition is null
-----
Truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

--551

truncate table data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]

INSERT INTO data.[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder_2]
           ([FIPS]
           ,[PropertyID]
           ,MinLienPos
		   ,MaxLienPos
		   ,OpenLiens
           )
 Select
            [FIPS]
           ,[PropertyID]
           ,Min(CalcLienPos)
		   ,Max(CalcLienPos)
		   ,Count([PropertyID])
from data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
where ReleaseFlag is null
and CalcLienPos is null
Group by fips, [PropertyID]
order by fips, [PropertyID]

--552

--  Min 2
update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 1
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 2 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 1
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 2 and t.MinLienPos = 2
and t.MaxLienPos = t.OpenLiens

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 2
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 3 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens

update data.dbo.Transaction_Mtg_LienPOS_Work_2
Set CalcLienPos = 3
from data.dbo.Transaction_Mtg_LienPOS_Work_2 w
join data..[Transaction_Mtg_LienPOS_Work_MtgOrder_2] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 4 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens



--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 2
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 3 and t.MinLienPos = 1
--and t.MaxLienPos > t.OpenLiens

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 3
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 4 and t.MinLienPos = 2
--and t.MaxLienPos > t.OpenLiens

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 3
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 4 and t.MinLienPos = 3

--600

CREATE NONCLUSTERED INDEX [PropertyID] ON data.[dbo].[Transaction_Mtg_LienPOS_Work_2]
(	[FIPS] ASC,
	[PropertyID] ASC)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--600-2

update property
set
       [LienPosUpdateFlag] = 'Y'
      ,[FAEnhanceprocessDt] = GetDate() +1
      ,[TotalOpenLienAmt] = null
      ,[TotalOpenLienNbr] = null
      ,[Mtg1TransactionId] = Null
      ,[Mtg1ChronoKey] = Null
	  ,[Mtg1InputDocNbr] = Null
      ,[Mtg1InputBook] = Null
      ,[Mtg1InputPage] = Null
	  ,[Mtg1FormatDocNbr] = null
	  ,[Mtg1FormatBook] = Null
	  ,[Mtg1FormatPage] = null
	  ,[Mtg1RecordingDt] = Null
      ,[Mtg1LoanAmt] = Null
      ,[Mtg1Lender] = Null
      ,[Mtg1LenderCode] = Null
      ,[Mtg1LenderType] = Null
      ,[Mtg1PrivateLender] = Null
      ,[Mtg1Term] = Null
      ,[Mtg1LoanDueDt] = Null
      ,[Mtg1AdjRider] = Null
      ,[Mtg1LoanType] = Null
      ,[Mtg1Typefinancing] = Null
      ,[Mtg1LienPosition] = Null
      ,[Mtg2TransactionId] = Null
      ,[Mtg2ChronoKey] = Null
	  ,[Mtg2InputDocNbr] = Null
      ,[Mtg2InputBook] = Null
      ,[Mtg2InputPage] = Null
	  ,[Mtg2FormatDocNbr] = null
	  ,[Mtg2FormatBook] = Null
	  ,[Mtg2FormatPage] = null
	  ,[Mtg2RecordingDt] = Null
      ,[Mtg2LoanAmt] = Null
      ,[Mtg2Lender] = Null
      ,[Mtg2LenderCode] = Null
      ,[Mtg2LenderType] = Null
      ,[Mtg2PrivateLender] = Null
      ,[Mtg2Term] = Null
      ,[Mtg2LoanDueDt] = Null
      ,[Mtg2AdjRider] = Null
      ,[Mtg2LoanType] = Null
      ,[Mtg2Typefinancing] = Null
      ,[Mtg2LienPosition] = Null
      ,[Mtg3TransactionId] = Null
      ,[Mtg3ChronoKey] = Null
	  ,[Mtg3InputDocNbr] = Null
      ,[Mtg3InputBook] = Null
      ,[Mtg3InputPage] = Null
	  ,[Mtg3FormatDocNbr] = null
	  ,[Mtg3FormatBook] = Null
	  ,[Mtg3FormatPage] = null
	  ,[Mtg3RecordingDt] = Null
      ,[Mtg3LoanAmt] = Null
      ,[Mtg3Lender] = Null
      ,[Mtg3LenderCode] = Null
      ,[Mtg3LenderType] = Null
      ,[Mtg3PrivateLender] = Null
      ,[Mtg3Term] = Null
      ,[Mtg3LoanDueDt] = Null
      ,[Mtg3AdjRider] = Null
      ,[Mtg3LoanType] = Null
      ,[Mtg3Typefinancing] = Null
      ,[Mtg3LienPosition] = Null
      ,[Mtg4TransactionId] = Null
      ,[Mtg4ChronoKey] = Null
	  ,[Mtg4InputDocNbr] = Null
      ,[Mtg4InputBook] = Null
      ,[Mtg4InputPage] = Null
	  ,[Mtg4FormatDocNbr] = null
	  ,[Mtg4FormatBook] = Null
	  ,[Mtg4FormatPage] = null
	  ,[Mtg4RecordingDt] = Null
      ,[Mtg4LoanAmt] = Null
      ,[Mtg4Lender] = Null
      ,[Mtg4LenderCode] = Null
      ,[Mtg4LenderType] = Null
      ,[Mtg4PrivateLender] = Null
      ,[Mtg4Term] = Null
      ,[Mtg4LoanDueDt] = Null
      ,[Mtg4AdjRider] = Null
      ,[Mtg4LoanType] = Null
      ,[Mtg4Typefinancing] = Null
      ,[Mtg4LienPosition] = Null
	  ,[Mtg1EstLoanBalance] = Null
      ,[Mtg1EstPaymentAmt] = Null
      ,[Mtg1InterestRate] = Null
	  ,[Mtg2EstLoanBalance] = Null
      ,[Mtg2EstPaymentAmt] = Null
      ,[Mtg2InterestRate] = Null
      ,[Mtg3EstLoanBalance] = Null
      ,[Mtg3EstPaymentAmt] = Null
      ,[Mtg3InterestRate] = Null
      ,[Mtg4EstLoanBalance] = Null
      ,[Mtg4EstPaymentAmt] = Null
      ,[Mtg4InterestRate] = Null
from data..property p
join (Select fips,PropertyID from DATA.dbo.[Transaction_Mtg_LienPOS_Work_2] with(NOLOCK)
group by fips,propertyid) w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
----- Update join to remove multi join 20221222 MAS

--601

Update data..Property
set 
       [Mtg1TransactionId] = w.TransactionId
      ,[Mtg1ChronoKey] = w.ChronoKey
	  ,[Mtg1InputDocNbr] = w.InputDocNbr
      ,[Mtg1InputBook] = w.InputBook
      ,[Mtg1InputPage] = w.InputPage
	  ,[Mtg1FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg1FormatBook] = w.[FormatBook]
	  ,[Mtg1FormatPage] = w.[FormatPage]
	  ,[Mtg1RecordingDt] = w.RecordingDt
      ,[Mtg1LoanAmt] = w.LoanAmt
      ,[Mtg1Lender] = w.Lender
      ,[Mtg1LenderCode] = w.LenderCode
      ,[Mtg1LenderType] = w.LenderType
      ,[Mtg1PrivateLender] = w.PrivateLender
      ,[Mtg1Term] = w.Term
      ,[Mtg1LoanDueDt] = w.LoanDueDt
      ,[Mtg1AdjRider] = w.AdjRider
      ,[Mtg1LoanType] = w.LoanType
      ,[Mtg1Typefinancing] = w.Typefinancing
      ,[Mtg1LienPosition] = w.CalcLienPos
	  ,[Mtg1InterestRate] = w.[InterestRate]
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 1

--602

Update data..Property
set 
       [Mtg2TransactionId] = w.TransactionId
      ,[Mtg2ChronoKey] = w.ChronoKey
	  ,[Mtg2InputDocNbr] = w.InputDocNbr
      ,[Mtg2InputBook] = w.InputBook
      ,[Mtg2InputPage] = w.InputPage
	  ,[Mtg2FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg2FormatBook] = w.[FormatBook]
	  ,[Mtg2FormatPage] = w.[FormatPage]
	  ,[Mtg2RecordingDt] = w.RecordingDt
      ,[Mtg2LoanAmt] = w.LoanAmt
      ,[Mtg2Lender] = w.Lender
      ,[Mtg2LenderCode] = w.LenderCode
      ,[Mtg2LenderType] = w.LenderType
      ,[Mtg2PrivateLender] = w.PrivateLender
      ,[Mtg2Term] = w.Term
      ,[Mtg2LoanDueDt] = w.LoanDueDt
      ,[Mtg2AdjRider] = w.AdjRider
      ,[Mtg2LoanType] = w.LoanType
      ,[Mtg2Typefinancing] = w.Typefinancing
      ,[Mtg2LienPosition] = w.CalcLienPos
	  ,[Mtg2InterestRate] = w.[InterestRate]
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 2

--603

Update data..Property
set 
       [Mtg3TransactionId] = w.TransactionId
      ,[Mtg3ChronoKey] = w.ChronoKey
	  ,[Mtg3InputDocNbr] = w.InputDocNbr
      ,[Mtg3InputBook] = w.InputBook
      ,[Mtg3InputPage] = w.InputPage
	  ,[Mtg3FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg3FormatBook] = w.[FormatBook]
	  ,[Mtg3FormatPage] = w.[FormatPage]
	  ,[Mtg3RecordingDt] = w.RecordingDt
      ,[Mtg3LoanAmt] = w.LoanAmt
      ,[Mtg3Lender] = w.Lender
      ,[Mtg3LenderCode] = w.LenderCode
      ,[Mtg3LenderType] = w.LenderType
      ,[Mtg3PrivateLender] = w.PrivateLender
      ,[Mtg3Term] = w.Term
      ,[Mtg3LoanDueDt] = w.LoanDueDt
      ,[Mtg3AdjRider] = w.AdjRider
      ,[Mtg3LoanType] = w.LoanType
      ,[Mtg3Typefinancing] = w.Typefinancing
      ,[Mtg3LienPosition] = w.CalcLienPos
	  ,[Mtg3InterestRate] = w.[InterestRate]
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 3

--604

Update data..Property
set 
       [Mtg4TransactionId] = w.TransactionId
      ,[Mtg4ChronoKey] = w.ChronoKey
	  ,[Mtg4InputDocNbr] = w.InputDocNbr
      ,[Mtg4InputBook] = w.InputBook
      ,[Mtg4InputPage] = w.InputPage
	  ,[Mtg4FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg4FormatBook] = w.[FormatBook]
	  ,[Mtg4FormatPage] = w.[FormatPage]
	  ,[Mtg4RecordingDt] = w.RecordingDt
      ,[Mtg4LoanAmt] = w.LoanAmt
      ,[Mtg4Lender] = w.Lender
      ,[Mtg4LenderCode] = w.LenderCode
      ,[Mtg4LenderType] = w.LenderType
      ,[Mtg4PrivateLender] = w.PrivateLender
      ,[Mtg4Term] = w.Term
      ,[Mtg4LoanDueDt] = w.LoanDueDt
      ,[Mtg4AdjRider] = w.AdjRider
      ,[Mtg4LoanType] = w.LoanType
      ,[Mtg4Typefinancing] = w.Typefinancing
      ,[Mtg4LienPosition] = w.CalcLienPos
	  ,[Mtg4InterestRate] = w.[InterestRate]
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 4

--610

---  Moved Query
--Update Property
--set [TotalOpenLienAmt]  = case when convert(bigint, isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)) < 100000000 then isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0) else 0 end
--,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
--,[LienPosUpdateFlag] = 'Y'
--,[LienPosUpdateDate] = GetDate() + 1
--from property p
--join [Transaction_Mtg_LienPOS_Work] w
--on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
--where ([Mtg1TransactionId] is not null or [Mtg2TransactionId] is not null) and (Mtg1LoanAmt < 1000000000 or Mtg2LoanAmt < 1000000000)

---  Correct Lien Position
----  Lien Pos 2 to 1
Update data..Property
Set
 [Mtg1TransactionId] = [Mtg2TransactionId]
,[Mtg1ChronoKey] = [Mtg2ChronoKey]
,[Mtg1InputDocNbr] = [Mtg2InputDocNbr]
,[Mtg1InputBook] = [Mtg2InputBook]
,[Mtg1InputPage] = [Mtg2InputPage]
,[Mtg1FormatDocNbr] = [Mtg2FormatDocNbr]
,[Mtg1FormatBook] = [Mtg2FormatBook]
,[Mtg1FormatPage] = [Mtg2FormatPage]
,[Mtg1RecordingDt] = [Mtg2RecordingDt]
,[Mtg1LoanAmt] = [Mtg2LoanAmt]
,[Mtg1Lender] = [Mtg2Lender]
,[Mtg1LenderCode] = [Mtg2LenderCode]
,[Mtg1LenderType] = [Mtg2LenderType]
,[Mtg1PrivateLender] = [Mtg2PrivateLender]
,[Mtg1LoanDueDt] = [Mtg2LoanDueDt]
,[Mtg1AdjRider] = [Mtg2AdjRider]
,[Mtg1LoanType] = [Mtg2LoanType]
,[Mtg1Typefinancing] = [Mtg2Typefinancing]
,[Mtg1LienPosition] = Case when [Mtg2TransactionId] is not null then 2 else Null end
,[Mtg1Term] = [Mtg2Term]
,[Mtg1EstPaymentAmt] = [Mtg2EstPaymentAmt]
,[Mtg1InterestRate] = [Mtg2InterestRate]
,[Mtg1EstLoanBalance] = [Mtg2EstLoanBalance]

,[Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when Mtg1LienPosition is null then 0 else 1 end + Case when Mtg2LienPosition is null then 0 else 1 end + Case when Mtg3LienPosition is null then 0 else 1 end + Case when Mtg4LienPosition is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FAEnhanceprocessDt] = GetDate() + 1

From data..Property
Where [FAEnhanceprocessDt] > GETDATE()-1 AND [Mtg1TransactionId] is null and [Mtg2TransactionId] is not null

---- Lien Pos 3 to 2
Update data..Property
Set
 [Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FAEnhanceprocessDt] = GetDate() + 1

From data..Property
Where [FAEnhanceprocessDt] > GETDATE()-1 AND [Mtg2TransactionId] is null and [Mtg3TransactionId] is not null

---- Lien Pos 4 to 3
Update data..Property
Set
 [Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FAEnhanceprocessDt] = GetDate() + 1

From data..Property
Where [FAEnhanceprocessDt] > GETDATE()-1 AND [Mtg3TransactionId] is null and [Mtg4TransactionId] is not null

-----20231113 added for instance of rolled up 4 leaving 4 null
Update data..Property
set 
       [Mtg4TransactionId] = w.TransactionId
      ,[Mtg4ChronoKey] = w.ChronoKey
	  ,[Mtg4InputDocNbr] = w.InputDocNbr
      ,[Mtg4InputBook] = w.InputBook
      ,[Mtg4InputPage] = w.InputPage
	  ,[Mtg4FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg4FormatBook] = w.[FormatBook]
	  ,[Mtg4FormatPage] = w.[FormatPage]
	  ,[Mtg4RecordingDt] = w.RecordingDt
      ,[Mtg4LoanAmt] = w.LoanAmt
      ,[Mtg4Lender] = w.Lender
      ,[Mtg4LenderCode] = w.LenderCode
      ,[Mtg4LenderType] = w.LenderType
      ,[Mtg4PrivateLender] = w.PrivateLender
      ,[Mtg4Term] = w.Term
      ,[Mtg4LoanDueDt] = w.LoanDueDt
      ,[Mtg4AdjRider] = w.AdjRider
      ,[Mtg4LoanType] = w.LoanType
      ,[Mtg4Typefinancing] = w.Typefinancing
      ,[Mtg4LienPosition] = w.CalcLienPos
	  ,[Mtg4InterestRate] = w.[InterestRate]
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 5 and [Mtg4TransactionId] is null

----  Move from top
Update data..Property
set [TotalOpenLienAmt]  = case when convert(bigint, isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)) < 100000000 then isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0) else 0 end
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FAEnhanceprocessDt] = GetDate() + 1
from data..property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where ([Mtg1TransactionId] is not null or [Mtg2TransactionId] is not null) and (Mtg1LoanAmt < 1000000000 or Mtg2LoanAmt < 1000000000)

----  Shift Lien POSition

update data..property
Set [TotalOpenLienNbr] = (Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
,[FAEnhanceprocessDt] = Getdate() + 1
from data..property
where [FAEnhanceprocessDt] > GETDATE()-1 AND  
(Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
<> [TotalOpenLienNbr]

update data..property
Set [Mtg1LienPosition] = 1
,[FAEnhanceprocessDt] = Getdate() + 1
from data..property
where [FAEnhanceprocessDt] > GETDATE()-1 AND 
[Mtg1TransactionId] is not null 
and [Mtg1LienPosition] <> 1

update data..property
Set [Mtg2LienPosition] = 2
,[FAEnhanceprocessDt] = Getdate() + 1
from data..property
where [FAEnhanceprocessDt] > GETDATE()-1 AND 
[Mtg2TransactionId] is not null 
and [Mtg2LienPosition] <> 2

update data..property
Set [Mtg3LienPosition] = 3
,[FAEnhanceprocessDt] = Getdate() + 1
from data..property
where [FAEnhanceprocessDt] > GETDATE()-1 AND 
[Mtg3TransactionId] is not null 
and [Mtg3LienPosition] <> 3

update data..property
Set [Mtg4LienPosition] = 4
,[FAEnhanceprocessDt] = Getdate() + 1
from data..property
where [FAEnhanceprocessDt] > GETDATE()-1 AND 
[Mtg4TransactionId] is not null 
and [Mtg4LienPosition] <> 4

--611

-- Estimated Fields
--  Payment Amount
update data..Property
set [Mtg1EstPaymentAmt] = round(cast(round([mtg1loanamt]/(((power(cast((1+(([Mtg1InterestRate]/10000.0) / 12.0)) as float),Mtg1Term)-1))/(((([Mtg1InterestRate]/10000.0) / 12.0))*(power(cast((1+(([Mtg1InterestRate]/10000.0) / 12.0)) as float),Mtg1Term)))),2) as money),2)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg1loanamt] is not null and [Mtg1InterestRate] is not null and [Mtg1InterestRate] != '0' and Mtg1Term is not null and Mtg1Term > 0
--and fips = '39165'

update data..Property
set [mtg2EstPaymentAmt] = round(cast(round([mtg2loanamt]/(((power(cast((1+(([mtg2InterestRate]/10000.0) / 12.0)) as float),mtg2Term)-1))/(((([mtg2InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg2InterestRate]/10000.0) / 12.0)) as float),mtg2Term)))),2) as money),2)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg2loanamt] is not null and [mtg2InterestRate] is not null and [mtg2InterestRate] != '0' and Mtg2Term is not null and Mtg2Term > 0
--and fips = '39165'

update data..Property
set [mtg3EstPaymentAmt] = round(cast(round([mtg3loanamt]/(((power(cast((1+(([mtg3InterestRate]/10000.0) / 12.0)) as float),mtg3Term)-1))/(((([mtg3InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg3InterestRate]/10000.0) / 12.0)) as float),mtg3Term)))),2) as money),2)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg3loanamt] is not null and [mtg3InterestRate] is not null and [mtg3InterestRate] != '0' and Mtg3Term is not null and Mtg3Term > 0
--and fips = '39165'

update data..Property
set [mtg4EstPaymentAmt] = round(cast(round([mtg4loanamt]/(((power(cast((1+(([mtg4InterestRate]/10000.0) / 12.0)) as float),mtg4Term)-1))/(((([mtg4InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg4InterestRate]/10000.0) / 12.0)) as float),mtg4Term)))),2) as money),2)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg4loanamt] is not null and [mtg4InterestRate] is not null and [mtg4InterestRate] != '0' and Mtg4Term is not null and Mtg4Term > 0
--and fips = '39165'

---  Estimated Loan Balance
Update data..Property
Set Mtg1EstLoanBalance = round(round(([mtg1loanamt] * (power((1+((cast([Mtg1InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([Mtg1EstPaymentAmt] * ((power((1+(cast([Mtg1InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([Mtg1InterestRate] as float)/10000.0)/12.0))),2),0)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg1loanamt] is not null and [Mtg1InterestRate] is not null and [Mtg1InterestRate] != '0' and Mtg1Term is not null and Mtg1Term > 0 and Mtg1Term < 481
--and round(round(([mtg1loanamt] * (power((1+((cast([Mtg1InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
--         -([Mtg1EstPaymentAmt] * ((power((1+(cast([Mtg1InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([Mtg1InterestRate] as float)/10000.0)/12.0))),2),0) > 0
--and fips = '39165'

Update data..Property
Set mtg2EstLoanBalance = round(round(([mtg2loanamt] * (power((1+((cast([mtg2InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg2Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg2EstPaymentAmt] * ((power((1+(cast([mtg2InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg2Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg2InterestRate] as float)/10000.0)/12.0))),2),0)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg2loanamt] is not null and [mtg2InterestRate] is not null and [mtg2InterestRate] != '0' and Mtg2Term is not null and Mtg2Term > 0
--and fips = '39165'

Update data..Property
Set mtg3EstLoanBalance = round(round(([mtg3loanamt] * (power((1+((cast([mtg3InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg3Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg3EstPaymentAmt] * ((power((1+(cast([mtg3InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg3Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg3InterestRate] as float)/10000.0)/12.0))),2),0)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg3loanamt] is not null and [mtg3InterestRate] is not null and [mtg3InterestRate] != '0' and Mtg3Term is not null and Mtg3Term > 0
--and fips = '39165'

Update data..Property
Set mtg4EstLoanBalance = round(round(([mtg4loanamt] * (power((1+((cast([mtg4InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg4Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg4EstPaymentAmt] * ((power((1+(cast([mtg4InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg4Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg4InterestRate] as float)/10000.0)/12.0))),2),0)
from data..Property p
join data.[dbo].[Transaction_Mtg_LienPOS_Work_2] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg4loanamt] is not null and [mtg4InterestRate] is not null and [mtg4InterestRate] != '0' and Mtg4Term is not null and Mtg4Term > 0
--and fips = '39165'
------
  Select @fips as Fips
  into [zAdminLienPosition_run]

 end
