SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON











CREATE  procedure [dbo].[Lereta_Balancing_Report_Sunil] as 
begin
--- queries with max join -----

select distinct fips, count(*) as LicDel_Y_Count, TAX_YEAR_BEGIN 
  into #t1 
from Dbs_Tax_lic..licensing_deliverable with (nolock)
where 
--fips in (04005, 04013, 04019, 04021, 04025, 06001, 06003, 06005, 06007, 06011, 06013, 06015, 06017, 06019, 06025, 06027, 06029, 06031, 06033, 06037, 06039, 06041, 06047, 06053, 06055, 06057, 06059, 06061, 06063, 06065, 06067, 06069, 06071, 06073, 06075, 06077, 06079, 06081, 06083, 06085, 06087, 06089, 06093, 06095, 06097, 06099, 06103, 06107, 06109, 06111, 06113, 06115, 08001, 08005, 08013, 08014, 08019, 08031, 08035, 08037, 08039, 08041, 08059, 08067, 08069, 08077, 08101, 08123, 10003, 11001, 12001, 12003, 12005, 12007, 12009, 12011, 12013, 12015, 12017, 12019, 12021, 12023, 12027, 12029, 12031, 12033, 12035, 12037, 12039, 12041, 12043, 12045, 12047, 12049, 12051, 12053, 12055, 12057, 12059, 12061, 12063, 12065, 12067, 12069, 12071, 12073, 12075, 12077, 12079, 12081, 12083, 12085, 12086, 12087, 12089, 12091, 12093, 12095, 12097, 12099, 12101, 12103, 12105, 12107, 12109, 12111, 12113, 12115, 12117, 12119, 12121, 12123, 12125, 12127, 12129, 12131, 12133, 15001, 15003, 15007, 15009, 16001, 17097, 18003, 18017, 18039, 18057, 18067, 18089, 18091, 18097, 18099, 18127, 18141, 18157, 20091, 20103, 20173, 20177, 20209, 29037, 29043, 29091, 29095, 29097, 29099, 29141, 29145, 29165, 29183, 29189, 29209, 29213, 29510, 30111, 31055, 32003, 32005, 32031, 32510, 35013, 39017, 39035, 39041, 39045, 39049, 39085, 39093, 39095, 39133, 39153, 39173, 40017, 40027, 40109, 40125, 40143, 41003, 41005, 41009, 41015, 41017, 41019, 41029, 41033, 41035, 41039, 41041, 41043, 41047, 41051, 41053, 41057, 41067, 41071, 42017, 42029, 42045, 47157, 47187, 48021, 48027, 48029, 48039, 48041, 48053, 48061, 48085, 48091, 48099, 48113, 48121, 48139, 48141, 48157, 48167, 48181, 48187, 48201, 48215, 48231, 48245, 48251, 48257, 48259, 48291, 48309, 48339, 48355, 48397, 48409, 48439, 48441, 48453, 48469, 48473, 48479, 48485, 48491, 48493, 49021, 49035, 49053, 51059, 53001, 53003, 53005, 53007, 53009, 53011, 53013, 53015, 53017, 53019, 53021, 53023, 53025, 53027, 53029, 53031, 53033, 53035, 53037, 53039, 53041, 53043, 53045, 53047, 53049, 53051, 53053, 53055, 53057, 53059, 53061, 53063, 53065, 53067, 53069, 53071, 53073, 53075, 53077, 55025, 55087, 56021)
--and 
currentrecord='Y'
group by fips , TAX_YEAR_BEGIN
order by fips,TAX_YEAR_BEGIN asc


---  (1363 rows affected)  2 mins

       ---select * from #t1 order by fips

select distinct fips, max(tax_year_begin) as LicDel_MaxYear into #t2 from #t1 
group by fips 


--- (272 rows affected)

       --select * from #t2

select a.fips, a.LicDel_Y_Count, b.LicDel_MaxYear 
into #t3
from #t1 a join #t2 b
on a.fips = b.fips and a.tax_year_begin = b.LicDel_MaxYear
order by a.fips


--- (272 rows affected)

       --select * from #t3

--drop table #t1
--drop table #t2
--drop table #t3

select distinct fips, count(*) as LicDel_NoY_Count, TAX_YEAR_BEGIN 
  into #t7 
from Dbs_Tax_lic..licensing_deliverable with (nolock)
--where fips in (04005, 04013, 04019, 04021, 04025, 06001, 06003, 06005, 06007, 06011, 06013, 06015, 06017, 06019, 06025, 06027, 
--06029, 06031, 06033, 06037, 06039, 06041, 06047, 06053, 06055, 06057, 06059, 06061, 06063, 06065, 06067, 06069, 06071, 
--06073, 06075, 06077, 06079, 06081, 06083, 06085, 06087, 06089, 06093, 06095, 06097, 06099, 06103, 06107, 06109, 06111,
--06113, 06115, 08001, 08005, 08013, 08014, 08019, 08031, 08035, 08037, 08039, 08041, 08059, 08067, 08069, 08077, 08101, 
--08123, 10003, 11001, 12001, 12003, 12005, 12007, 12009, 12011, 12013, 12015, 12017, 12019, 12021, 12023, 12027, 12029, 
--12031, 12033, 12035, 12037, 12039, 12041, 12043, 12045, 12047, 12049, 12051, 12053, 12055, 12057, 12059, 12061, 12063,
--12065, 12067, 12069, 12071, 12073, 12075, 12077, 12079, 12081, 12083, 12085, 12086, 12087, 12089, 12091, 12093, 12095, 
--12097, 12099, 12101, 12103, 12105, 12107, 12109, 12111, 12113, 12115, 12117, 12119, 12121, 12123, 12125, 12127, 12129, 
--12131, 12133, 15001, 15003, 15007, 15009, 16001, 17097, 18003, 18017, 18039, 18057, 18067, 18089, 18091, 18097, 18099, 18127, 
--18141, 18157, 20091, 20103, 20173, 20177, 20209, 29037, 29043, 29091, 29095, 29097, 29099, 29141, 29145, 29165, 29183, 29189, 29209, 29213, 29510, 30111, 31055, 32003, 32005, 32031, 32510, 35013, 39017, 39035, 39041, 39045, 39049, 39085, 39093, 39095, 39133, 39153, 39173, 40017, 40027, 40109, 40125, 40143, 41003, 41005, 41009, 41015, 41017, 41019, 41029, 41033, 41035, 41039, 41041, 41043, 41047, 41051, 41053, 41057, 41067, 41071, 42017, 42029, 42045, 47157, 47187, 48021, 48027, 48029, 48039, 48041, 48053, 48061, 48085, 48091, 48099, 48113, 48121, 48139, 48141, 48157, 48167, 48181, 48187, 48201, 48215, 48231, 48245, 48251, 48257, 48259, 48291, 48309, 48339, 48355, 48397, 48409, 48439, 48441, 48453, 48469, 48473, 48479, 48485, 48491, 48493, 49021, 49035, 49053, 51059, 53001, 53003, 53005, 53007, 53009, 53011, 53013, 53015, 53017, 53019, 53021, 53023, 53025, 53027, 53029, 53031, 53033, 53035, 53037, 53039, 53041, 53043, 53045, 53047, 53049, 53051, 53053, 53055, 53057, 53059, 53061, 53063, 53065, 53067, 53069, 53071, 53073, 53075, 53077, 55025, 55087, 56021)
group by fips, TAX_YEAR_BEGIN
order by fips, TAX_YEAR_BEGIN asc


---  (1434 rows affected)  2 mins

       --select * from #t7 order by fips

select distinct fips, max(tax_year_begin) as LicDel_MaxYear into #t8 from #t7
group by fips 


--- (286 rows affected)

       --select * from #t8

select a.fips, a.LicDel_NoY_Count, b.LicDel_MaxYear 
into #t9
from #t7 a join #t8 b
on a.fips = b.fips and a.tax_year_begin = b.LicDel_MaxYear


--- (286 rows affected)

       --select * from #t9 order by fips

--drop table #t7
--drop table #t8
--drop table #t9


select distinct fips, count(distinct Payee_Parcel_Number) as Billing_Count, TAX_YEAR_BEGIN 
  into #t4 
from [DWS-ETL01].dbs_tax.dbo.Billing with (nolock)
--where fips in (04005, 04013, 04019, 04021, 04025, 06001, 06003, 06005, 06007, 06011, 06013, 06015, 06017, 06019, 06025, 06027, 06029, 06031, 06033, 06037, 06039, 06041, 06047, 06053, 06055, 06057, 06059, 06061, 06063, 06065, 06067, 06069, 06071, 06073, 06075, 06077, 06079, 06081, 06083, 06085, 06087, 06089, 06093, 06095, 06097, 06099, 06103, 06107, 06109, 06111, 06113, 06115, 08001, 08005, 08013, 08014, 08019, 08031, 08035, 08037, 08039, 08041, 08059, 08067, 08069, 08077, 08101, 08123, 10003, 11001, 12001, 12003, 12005, 12007, 12009, 12011, 12013, 12015, 12017, 12019, 12021, 12023, 12027, 12029, 12031, 12033, 12035, 12037, 12039, 12041, 12043, 12045, 12047, 12049, 12051, 12053, 12055, 12057, 12059, 12061, 12063, 12065, 12067, 12069, 12071, 12073, 12075, 12077, 12079, 12081, 12083, 12085, 12086, 12087, 12089, 12091, 12093, 12095, 12097, 12099, 12101, 12103, 12105, 12107, 12109, 12111, 12113, 12115, 12117, 12119, 12121, 12123, 12125, 12127, 12129, 12131, 12133, 15001, 15003, 15007, 15009, 16001, 17097, 18003, 18017, 18039, 18057, 18067, 18089, 18091, 18097, 18099, 18127, 18141, 18157, 20091, 20103, 20173, 20177, 20209, 29037, 29043, 29091, 29095, 29097, 29099, 29141, 29145, 29165, 29183, 29189, 29209, 29213, 29510, 30111, 31055, 32003, 32005, 32031, 32510, 35013, 39017, 39035, 39041, 39045, 39049, 39085, 39093, 39095, 39133, 39153, 39173, 40017, 40027, 40109, 40125, 40143, 41003, 41005, 41009, 41015, 41017, 41019, 41029, 41033, 41035, 41039, 41041, 41043, 41047, 41051, 41053, 41057, 41067, 41071, 42017, 42029, 42045, 47157, 47187, 48021, 48027, 48029, 48039, 48041, 48053, 48061, 48085, 48091, 48099, 48113, 48121, 48139, 48141, 48157, 48167, 48181, 48187, 48201, 48215, 48231, 48245, 48251, 48257, 48259, 48291, 48309, 48339, 48355, 48397, 48409, 48439, 48441, 48453, 48469, 48473, 48479, 48485, 48491, 48493, 49021, 49035, 49053, 51059, 53001, 53003, 53005, 53007, 53009, 53011, 53013, 53015, 53017, 53019, 53021, 53023, 53025, 53027, 53029, 53031, 53033, 53035, 53037, 53039, 53041, 53043, 53045, 53047, 53049, 53051, 53053, 53055, 53057, 53059, 53061, 53063, 53065, 53067, 53069, 53071, 53073, 53075, 53077, 55025, 55087, 56021)
group by fips, TAX_YEAR_BEGIN
order by fips, TAX_YEAR_BEGIN asc


--- (359 rows affected)   27 secs

       --select * from #t4

select distinct fips, max(tax_year_begin) as max_year into #t5 from #t4
group by fips 


--- (284 rows affected)

       --select * from #t5 order by fips

select c.fips, c.Billing_Count, c.TAX_YEAR_BEGIN 
into #t6
from #t4 c join #t5 d
on c.fips = d.fips and c.TAX_YEAR_BEGIN  = d.max_year
order by fips asc


--- (283 rows affected)

       --select * from #t6

--drop table #t4
--drop table #t5
--drop table #t6

select distinct fips 
into #SnglPay
from Dbs_Tax_Lic..Licensing_Deliverable with (nolock)
where PAYEE_CODE<>'Multijuris'
--and fips in (04005, 04013, 04019, 04021, 04025, 06001, 06003, 06005, 06007, 06011, 06013, 06015, 06017, 06019, 06025, 06027, 06029, 06031, 06033, 06037, 06039, 06041, 06047, 06053, 06055, 06057, 06059, 06061, 06063, 06065, 06067, 06069, 06071, 06073, 06075, 06077, 06079, 06081, 06083, 06085, 06087, 06089, 06093, 06095, 06097, 06099, 06103, 06107, 06109, 06111, 06113, 06115, 08001, 08005, 08013, 08014, 08019, 08031, 08035, 08037, 08039, 08041, 08059, 08067, 08069, 08077, 08101, 08123, 10003, 11001, 12001, 12003, 12005, 12007, 12009, 12011, 12013, 12015, 12017, 12019, 12021, 12023, 12027, 12029, 12031, 12033, 12035, 12037, 12039, 12041, 12043, 12045, 12047, 12049, 12051, 12053, 12055, 12057, 12059, 12061, 12063, 12065, 12067, 12069, 12071, 12073, 12075, 12077, 12079, 12081, 12083, 12085, 12086, 12087, 12089, 12091, 12093, 12095, 12097, 12099, 12101, 12103, 12105, 12107, 12109, 12111, 12113, 12115, 12117, 12119, 12121, 12123, 12125, 12127, 12129, 12131, 12133, 15001, 15003, 15007, 15009, 16001, 17097, 18003, 18017, 18039, 18057, 18067, 18089, 18091, 18097, 18099, 18127, 18141, 18157, 20091, 20103, 20173, 20177, 20209, 29037, 29043, 29091, 29095, 29097, 29099, 29141, 29145, 29165, 29183, 29189, 29209, 29213, 29510, 30111, 31055, 32003, 32005, 32031, 32510, 35013, 39017, 39035, 39041, 39045, 39049, 39085, 39093, 39095, 39133, 39153, 39173, 40017, 40027, 40109, 40125, 40143, 41003, 41005, 41009, 41015, 41017, 41019, 41029, 41033, 41035, 41039, 41041, 41043, 41047, 41051, 41053, 41057, 41067, 41071, 42017, 42029, 42045, 47157, 47187, 48021, 48027, 48029, 48039, 48041, 48053, 48061, 48085, 48091, 48099, 48113, 48121, 48139, 48141, 48157, 48167, 48181, 48187, 48201, 48215, 48231, 48245, 48251, 48257, 48259, 48291, 48309, 48339, 48355, 48397, 48409, 48439, 48441, 48453, 48469, 48473, 48479, 48485, 48491, 48493, 49021, 49035, 49053, 51059, 53001, 53003, 53005, 53007, 53009, 53011, 53013, 53015, 53017, 53019, 53021, 53023, 53025, 53027, 53029, 53031, 53033, 53035, 53037, 53039, 53041, 53043, 53045, 53047, 53049, 53051, 53053, 53055, 53057, 53059, 53061, 53063, 53065, 53067, 53069, 53071, 53073, 53075, 53077, 55025, 55087, 56021)
group by fips 
order by fips asc


-- (286 rows affected)

--- FINAL JOIN OF ALL OUTPUTS INTO 1 TABLE, THEN LOGIC TO DETERMINE ISSUES IS NEEDED NEXT

select BL.FIPS, BL.Billing_Count, BL.TAX_YEAR_BEGIN as Billing_MaxYrBegin, 
       LDY.FIPS as LDY_FIPS, LDY.LicDel_Y_Count, LDY.LicDel_MaxYear
       , LDnoY.FIPS as LDnoY_FIPS, LDnoY.LicDel_NoY_Count, LDnoY.LicDel_MaxYear as LicDelnoY_MaxYear 
from #t6 BL
full outer join #t3 LDY on BL.fips = LDY.fips --and BL.TAX_YEAR_BEGIN  = LDY.max_year
full outer join #t9 LDnoY on BL.fips = LDnoY.fips --and BL.TAX_YEAR_BEGIN  = LDnoY.LicDel_MaxYear
where BL.FIPS in (select * from #SnglPay) 
order by BL.FIPS, LDY.FIPS




select BL.FIPS, BL.Billing_Count, BL.TAX_YEAR_BEGIN as Billing_MaxYrBegin, 
       LDY.FIPS as LDY_FIPS, LDY.LicDel_Y_Count, LDY.LicDel_MaxYear
       , LDnoY.FIPS as LDnoY_FIPS, LDnoY.LicDel_NoY_Count, LDnoY.LicDel_MaxYear as LicDelnoY_MaxYear
       ,  ((convert(decimal(10,2),LDY.LicDel_Y_Count )/ convert(decimal(10,2),BL.Billing_Count )) * 100)  as Lic_Y_per
       
       ,case when   (( convert(decimal(10,2),BL.Billing_Count ) - convert(decimal(10,2),LDY.LicDel_Y_Count ))*100)
       / convert(decimal(10,2),BL.Billing_Count ) >= 5 then 1 end  as Lic_Y_drop
       
       ,  ((convert(decimal(10,2),LicDel_NoY_Count)/ convert(decimal(10,2),BL.Billing_Count )) * 100)  as Lic_NoY_per

              ,case when   (( convert(decimal(10,2),BL.Billing_Count ) - convert(decimal(10,2),LicDel_NoY_Count ))*100)
       / convert(decimal(10,2),BL.Billing_Count ) >= 5 then 1 end  as Lic_NoY_drop

from #t6 BL
full outer join #t3 LDY on BL.fips = LDY.fips --and BL.TAX_YEAR_BEGIN  = LDY.max_year
full outer join #t9 LDnoY on BL.fips = LDnoY.fips --and BL.TAX_YEAR_BEGIN  = LDnoY.LicDel_MaxYear
where BL.FIPS in (select * from #SnglPay) 
order by BL.FIPS, LDY.FIPS
                   


----select BL.FIPS, BL.Billing_Count, BL.TAX_YEAR_BEGIN as Billing_MaxYrBegin 
----     --  ,LDY.FIPS as LDY_FIPS
----	   , LDY.LicDel_Y_Count, LDY.LicDel_MaxYear
----      -- , LDnoY.FIPS as LDnoY_FIPS
----	   --, LDnoY.LicDel_NoY_Count, LDnoY.LicDel_MaxYear as LicDelnoY_MaxYear
----       ,  ((convert(decimal(10,2),LDY.LicDel_Y_Count )/ convert(decimal(10,2),BL.Billing_Count )) * 100)  as Lic_Y_pct
       
----       ,case when   (( convert(decimal(10,2),BL.Billing_Count ) - convert(decimal(10,2),LDY.LicDel_Y_Count ))*100)
----       / convert(decimal(10,2),BL.Billing_Count ) >= 5 then 1 end  as Lic_Y_drop
       
----       ,  ((convert(decimal(10,2),LicDel_NoY_Count)/ convert(decimal(10,2),BL.Billing_Count )) * 100)  as Lic_NoY_pct
	
----,case when BL.TAX_YEAR_BEGIN <> LDY.LicDel_MaxYear or LDY.LicDel_MaxYear is null then '1' else '' end as LicDel_Y_Year_Diff



----       --       ,case when   (( convert(decimal(10,2),BL.Billing_Count ) - convert(decimal(10,2),LicDel_NoY_Count ))*100)
----       --/ convert(decimal(10,2),BL.Billing_Count ) >= 5 then 1 end  as Lic_NoY_drop
----       --, case when TAX_YEAR_BEGIN <>LDY.LicDel_MaxYear then 1 end as Lic_y_year_mismatch
----         , case when TAX_YEAR_BEGIN <>LDnoY.LicDel_MaxYear then 1 end as Lic_noy_year_mismatch
----       into    DBS_TAX_Lic..Final_report
----from #t6 BL
----full outer join #t3 LDY on BL.fips = LDY.fips --and BL.TAX_YEAR_BEGIN  = LDY.max_year
----full outer join #t9 LDnoY on BL.fips = LDnoY.fips --and BL.TAX_YEAR_BEGIN  = LDnoY.LicDel_MaxYear
----where BL.FIPS in (select * from #SnglPay) 
----order by BL.FIPS--, LDY.FIPS
     
	-- 
	TRuncate  table DBS_TAX_Lic..Final_report 


	INSERT INTO DBS_TAX_Lic.[dbo].[Final_report]
           ([FIPS]
           ,[LicDel_Y_Year_Diff]
           ,[Billing_MaxYrBegin]
           ,[LicDel_Y_MaxYear]
           ,[LicDel_Y_Drop]
           ,[LicDel_Y_Drop_Pct]
           ,[Billing_Count]
           ,[LicDel_Y_Count]
           ,[LicDel_Y_Pct]
           ,[LicDel_NoY_Count]
           ,[LicDel_NoY_Pct])
select [FIPS]
           ,[LicDel_Y_Year_Diff]
           ,[Billing_MaxYrBegin]
           ,[LicDel_Y_MaxYear]
           ,[LicDel_Y_Drop]
           ,[LicDel_Y_Drop_Pct]
           ,[Billing_Count]
           ,[LicDel_Y_Count]
           ,[LicDel_Y_Pct]
           ,[LicDel_NoY_Count]
           ,[LicDel_NoY_Pct]  	from
--into    DBS_TAX_Lic..Final_report from 
(
select BL.FIPS, 
       case when BL.TAX_YEAR_BEGIN <> LDY.LicDel_MaxYear then '1' else '' end as LicDel_Y_Year_Diff,
       BL.TAX_YEAR_BEGIN as Billing_MaxYrBegin, 
       LDY.LicDel_MaxYear as LicDel_Y_MaxYear, 
       case when BL.TAX_YEAR_BEGIN = LDY.LicDel_MaxYear and ((convert(decimal(10,2),BL.Billing_Count) - convert(decimal(10,2),LDY.LicDel_Y_Count)) *100)
       / convert(decimal(10,2),BL.Billing_Count) >= 5 then '1' else '' end as LicDel_Y_Drop,
       case when BL.TAX_YEAR_BEGIN = LDY.LicDel_MaxYear then Format((convert(decimal(10,2),LDY.LicDel_Y_Count) 
       / convert(decimal(10,2),BL.Billing_Count) - 1),'P2') else '' end as LicDel_Y_Drop_Pct,
       BL.Billing_Count, 
       LDY.LicDel_Y_Count, 
       Format((convert(decimal(10,2),LDY.LicDel_Y_Count) / convert(decimal(10,2),BL.Billing_Count)),'P2') as LicDel_Y_Pct,
       LDnoY.LicDel_NoY_Count, 
    Format((convert(decimal(10,2),LDnoY.LicDel_NoY_Count) / convert(decimal(10,2),BL.Billing_Count)),'P2') as LicDel_NoY_Pct

from #t6 BL
full outer join #t3 LDY on BL.fips = LDY.fips
full outer join #t9 LDnoY on BL.fips = LDnoY.fips
where BL.FIPS in (select * from #SnglPay) 
) as test
where (LicDel_Y_Drop = '1' or LicDel_Y_Year_Diff = '1')
order by FIPS


--begin



--DECLARE @T NVARCHAR(50)
--DECLARE @D VARCHAR(20)
--DECLARE @TD NVARCHAR(100)
--DECLARE @html NVARCHAR(MAX)
--DECLARE @query NVARCHAR(MAX)

--SET @D = CONVERT(VARCHAR(20), GETDATE(), 110)
--SET @T = ' Lereta Balancing Report :   '
--SET @TD = @T + @D

----EXEC spQueryToHtmlTable @html = @html OUTPUT, 
--set @query = 
--  --    ' select [FIPS] 
--  --    ,[LicDel_Y_Year_Diff] 
--  --    ,[Billing_MaxYrBegin] 
--  --    ,[LicDel_Y_MaxYear] 
--  --    ,[LicDel_Y_Drop] 
--  --    ,[LicDel_Y_Drop_Pct] 
--  --    ,[Billing_Count] 
--  --    ,[LicDel_Y_Count] 
--  --    ,[LicDel_Y_Pct] 
--  --    ,[LicDel_NoY_Count] 
--  --    ,[LicDel_NoY_Pct] 
--	 -- from DBS_TAX_Lic..Final_report
--	 --'

--	 ( SELECT    td = Fips, '',
--                        td = [LicDel_Y_Year_Diff] , '',
--                        td = [Billing_MaxYrBegin]  , '',
--                         td = [LicDel_Y_MaxYear]  , '',
--                         td = [LicDel_Y_Drop]  , '',
--                       td = [LicDel_Y_Drop_Pct]  , '',
--                         td = [Billing_Count]  , '',
--                         td = [LicDel_Y_Count]  , '',
--                         td = [LicDel_Y_Pct]  , '',
--                         td = [LicDel_NoY_Count]  , '',
--                         td = [LicDel_NoY_Pct] , '' 
-- FROM     DBS_TAX_Lic..Final_report order by fips
--            FOR   XML RAW('tr'),
--                  ELEMENTS)
   

--EXEC msdb.dbo.sp_send_dbmail @profile_name =--'Tree_Trace_DBA_team' 
--'FAOH-DL-DBS_Fulfillment'
--      ,@recipients= N'SReddy@firstam.com;smonkman@firstam.com'
--      , @subject = @TD
--      , @body =  @query-- @html--'Lereta Balancing Report Data Refreshed in Spreadsheet'
--      , @body_format = 'HTML'
--      , @query_no_truncate = 1
--     , @attach_query_result_as_file = 0

--end


DECLARE
	@Email_To		varchar(800) = Null,
	@Email_CC		varchar(800) = Null,
	@Email_Bcc		varchar(800) = Null,
	 @T NVARCHAR(50),
 @D VARCHAR(20),
 @TD NVARCHAR(100),
 

	@Body		 varchar(MAX),
	@Format		 varchar(200) = 'html',
	@Subject	 varchar(200),
	@BodyContent varchar(max),
	@TableHeader varchar(max),
	@TableFooter varchar(max),
	@Server		  varchar(10)
	SET @D = CONVERT(VARCHAR(20), GETDATE(), 110)
SET @T = ' Lereta Balancing Report :   '
SET @TD = @T + @D


BEGIN
	

	Set @TableFooter = '</table></body></html>';
	Set @TableHeader = '<html><head>' +
					  '<style>' +
					  'td {padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;font-family: Arial, Helvetica, sans-serif; font-size: 10pt;} ' +
					  '</style>' +
					  '</head>' +
					  '<body><table cellpadding="5" cellspacing="0" border="1" bordercolor="#000000" style="font-family: Arial, Helvetica, sans-serif; font-size: 10pt; border-collapse:collapse;border-bottom-style:solid black;">' +
					  '<tr bgcolor=#FFEFD8>
					   <td align=Left style="background-color: #359AFF; color: black"><b>Fips </b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_Year_Diff</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>Billing_MaxYrBegin</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_MaxYear</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_Drop</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_Drop_Pct</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>Billing_Count</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_Count</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_Y_Pct</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_NoY_Count</b></td>' +
					  '<td align=Left style="background-color: #359AFF; color: black"><b>LicDel_NoY_Pct</b></td>'  ;
	Select @BodyContent = 			  
	 ( SELECT    td = Fips, '',
                        td = [LicDel_Y_Year_Diff] , '',
                        td = [Billing_MaxYrBegin]  , '',
                         td = [LicDel_Y_MaxYear]  , '',
                         td = [LicDel_Y_Drop]  , '',
                       td = [LicDel_Y_Drop_Pct]  , '',
                         td = [Billing_Count]  , '',
                         td = [LicDel_Y_Count]  , '',
                         td = [LicDel_Y_Pct]  , '',
                         td = [LicDel_NoY_Count]  , '',
                         td = [LicDel_NoY_Pct] , '' 
 FROM     DBS_TAX_Lic..Final_report order by fips
            FOR   XML RAW('tr'),
                  ELEMENTS);
   
	
	Set @BodyContent = Replace(@BodyContent, '_x0020_', space(1))
	Set @BodyContent = Replace(@BodyContent, '_x003D_', '=')
	Set @BodyContent = Replace(@BodyContent, '<tr><ALTCOLOR>1</ALTCOLOR>', '<tr bgcolor=#DFFFDF>')
	Set @BodyContent = Replace(@BodyContent, '<ALTCOLOR>0</ALTCOLOR>', '')


	Select @BodyContent = @TableHeader + @BodyContent + @TableFooter

	--exec  msdb.dbo.sp_send_dbmail
	EXEC msdb.dbo.sp_send_dbmail @profile_name =--'Tree_Trace_DBA_team' 
'FAOH-DL-DBS_Fulfillment'
      ,@recipients= N'SReddy@firstam.com;smonkman@firstam.com'
	  -- @recipients				= @Email_To
	   ,@copy_recipients		= @Email_Cc
	   ,@blind_copy_recipients	= @Email_Bcc
	   ,@subject				= @Subject
	   ,@body					= @BodyContent
	   ,@body_format			= @Format
 END


begin
DECLARE @T1 NVARCHAR(50)
DECLARE @D1 VARCHAR(20)
DECLARE @TD1 NVARCHAR(100)
DECLARE @html1 NVARCHAR(MAX)

SET @D1 = CONVERT(VARCHAR(20), GETDATE(), 110)
SET @T1 = ' Lereta Balancing Report :   '
SET @TD1 = @T1 + @D1

EXEC msdb.dbo.sp_send_dbmail @profile_name ='FAOH-DL-DBS_Fulfillment'
      ,@recipients= N'SReddy@firstam.com;smonkman@firstam.com'
      , @subject = @TD1
      , @body = 'Lereta Balancing Report Data Refreshed in Spreadsheet'
     

end

-- select * from #tfinal

--Drop table #tfinal
-- or lic_noy_drop=1

--begin



--DECLARE @T NVARCHAR(50)
--DECLARE @D VARCHAR(20)
--DECLARE @TD NVARCHAR(100)
--DECLARE @html NVARCHAR(MAX)
--DECLARE @query_attachment_filename VARCHAR(50)
--DECLARE @qry VARCHAR(8000)
----DECLARE @qry VARCHAR(8000)
-- DECLARE @Column1Name VARCHAR(255)
-- SET @Column1Name = '[sep=,' + CHAR(13) + CHAR(10) + 'FIPS]'

--SET @D = CONVERT(VARCHAR(20), GETDATE(), 110)
--SET @T = ' Lereta Balancing Report :     '
--SET @TD = @T + @D
--SET @query_attachment_filename  = 'Lereta_Balancing_Report.csv'

--EXEC spQueryToHtmlTable @html = @html OUTPUT
--      SELECT @qry = N' set nocount on
--       select  FIPS AS ' +@Column1Name+',Billing_Count,Billing_MaxYrBegin,LDY_FIPS,LicDel_Y_Count,LicDel_MaxYear,LDnoY_FIPS,LicDel_NoY_Count,LicDelnoY_MaxYear,Lic_Y_per,Lic_Y_drop,Lic_NoY_per,Lic_NoY_drop,Lic_y_year_mismatch,Lic_noy_year_mismatch 
--	  from #tfinal report
--         where (Lic_y_drop =1)
--		 order by fips
		
--          '
--      --, @orderBy = N'fips'

--EXEC msdb.dbo.sp_send_dbmail @profile_name =--'Tree_Trace_DBA_team' 
--'FAOH-DL-DBS_Fulfillment'
--      ,@recipients= N'SReddy@firstam.com;smonkman@firstam.com'
--      , @subject = @TD
--      , @body = @html
--      , @body_format = 'HTML'
--	   ,@qry = @qry
--      , @query_no_truncate = 0
--      --, @attach_query_result_as_file = 1
--	--  ,@query_result_no_padding = 1
-- --,@query_attachment_filename = @query_attachment_filename
-- ,@Query_result_header=1
-- ,@execute_query_database = 'DBS_Tax_Lic' 
---- ,@query_result_separator = ',' 
-- --,@query_result_width = 32767

--end

end



