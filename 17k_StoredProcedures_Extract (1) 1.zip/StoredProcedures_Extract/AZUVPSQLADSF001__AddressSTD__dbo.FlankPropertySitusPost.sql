SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankPropertySitusPost] (@tableName varchar(40)) -- @tableName = 'Property_Situs' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild SitusStdFullStreetAddress and SitusCensusTractBlock fields
-- ,[SitusStdStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdStreet]))) -- changed GM 20240716
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Property_Situs_STD]
	   --set [SitusStdFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdMode]))) + '' '' + [AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitNbr])))))))
       set [SitusStdFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitNbr]))))
	   ,[SitusStdHouseNbr]  = ltrim(rtrim(left([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdHouseNbr],30)))
       ,[SitusStdDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionLeft]))
       ,[SitusStdStreet] = substring(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdStreet]))),1,60)
       ,[SitusStdMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdMode])))
       ,[SitusStdDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdDirectionRight]))
       ,[SitusStdUnitNbr] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitNbr]))
       ,[SitusStdCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdCity])))
       ,[SitusStdState] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdState]))
       ,[SitusStdZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdZIP5]))
       ,[SitusStdZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdZIP4]))
       ,[SitusLatitude] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusLatitude]))
       ,[SitusLongitude] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusLongitude]))
       ,[SitusStdCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdCarrierCode]))
	   ,[SitusCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusCensusTract]))
       ,[SitusCensusTractBlock] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusCensusTract])) + ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusCensusBlock]))
       ,[SitusStdUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdUnitType])))
       ,[SitusStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusStdMatchCode]))
       ,[SitusDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusDPVCount]))
       ,[SitusDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusDPVFootnote]))
       ,[SitusLACS] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusLACS]))
       ,[SitusLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusLACSLinkInd]))
       ,[SitusDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusDPCheckDigit]))
       ,[SitusDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusDPCheckCode]))
       ,[SitusCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusCensusBlock]))
       ,[SitusGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusGeoErrorCode]))
       ,[SitusGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusGeoStatusCode]))
       ,[SitusGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Property_Situs_STD].[SitusGeoCodeResults]))
     From [AddressSTD].[dbo].[Property_Situs_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Property_Situs_to_Licensing

