SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE sp_GenerateScriptForStoredProcedure (
 @storedprocedure_name sysname
)
AS
DECLARE @sphelptext TABLE(script NVARCHAR(MAX));
INSERT INTO @sphelptext EXEC sp_helptext @storedprocedure_name;
SELECT script FROM @sphelptext;

