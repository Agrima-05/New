SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[sp_PerformSearch_By_DefId_DefName] (
	@DefendantId CHAR(4) = NULL,
	@DefendantName CHAR(32) = NULL
)
AS

BEGIN
	SET NOCOUNT ON

	DECLARE
		@v_DefendantId CHAR(4) = LTRIM(RTRIM(@DefendantId)),
		@v_DefendantName CHAR(32) = LTRIM(RTRIM(@DefendantName)),
		@v_paddedDefendantID CHAR(9),
		@DefendantNameSearch VARCHAR(50)

	IF (@v_DefendantId IS NOT NULL)
		SET @v_paddedDefendantID = @v_DefendantId

	IF (@v_DefendantName IS NOT NULL)
		SET @DefendantNameSearch = '"' + @v_DefendantName + '"'
	ELSE
		SET @DefendantNameSearch = '*'

	SELECT
			[BKY_ROW_ID]															AS RowId
			,[BKY_INS_DEL]															AS BKY_INS_DEL
			,[BKY_DEF_TYPE]															AS DefinitionType
			,[BKY_ALIAS_TYPE]														AS AliasType
			,[BKY_ASOC_CODE]														AS AsocCode
			,[BKY_COURT_ID]															AS CourtId
			,[BKY_FILLER1]															AS BKY_FILLER1
			,[BKY_CASE_NBR]															AS CaseNumber
			,[BKY_FILING_TYPE]														AS FilingType
			,[BKY_ORIG_CHAP]														AS OriginalChapter
			,dbo.fn_IsValidDateThenReturnDateChar(LTRIM(RTRIM([BKY_FILING_DATE])))	AS FilingDate
			,dbo.fn_IsValidDateThenReturnDateChar(LTRIM(RTRIM([BKY_RLSE_DATE])))	AS ReleaseDate
			,[BKY_FILLER2]															AS BKY_FILLER2
			,[BKY_ASSETS]															AS BKY_ASSETS
			,[BKY_TRSTE_NAME]														AS TrusteeName
			,[BKY_ATRNY_NAME]														AS AttorneyName
			,[BKY_ATRNY_PHONE]														AS AttorneyPhone
			,dbo.fn_IsValidDateThenReturnDateChar(LTRIM(RTRIM([BKY_SCH341_DATE])))	AS Sch341Date
			,[BKY_JUDGE_INIT]														AS JudgeInit
			,[BKY_OTHER_CASE_NBR]													AS CaseNumberOther
			,[BKY_DEF_ID]															AS DefendantId
			,[BKY_DEF_NAME]															AS DefendantName
			,[BKY_DEF_NAME_GENCD]													AS DefendantNameGencd
			,[BKY_DEF_ST_ADD]														AS DefendantAddressStreet
			,[BKY_DEF_CITY]															AS DefendantAddressCity
			,[BKY_DEF_STATE]														AS DefendantAddressState
			,[BKY_DEF_ZIP]															AS DefendantAddressZip
			,dbo.fn_IsValidDateThenReturnDateChar(LTRIM(RTRIM([BKY_RECORD_DATE])))	AS RecordDate
			,[BKY_CASE_TYPE]														AS CaseType
			,[BKY_UNQ_CASE_ID]														AS CaseNumberUnique
			,[BKY_CURR_CHAP]														AS CurrentChapter
			,[BKY_PREV_CHAP]														AS PreviousChapter
			,[BKY_ATRNY_ADD]														AS AttorneyAddressStreet
			,[BKY_ATRNY_CITY]														AS AttorneyAddressCity
			,[BKY_ATRNY_STATE]														AS AttorneyAddressState
			,[BKY_ATRNY_ZIP]														AS AttorneyAddressZip
			,[BKY_ASSETS_IND]														AS AssetsInd
			,[BKY_ACTION_TYPE]														AS ActionType
			,[BKY_SCH341_TIME]														AS Sch341Time
			,dbo.fn_IsValidDateThenReturnDateChar(LTRIM(RTRIM([BKY_POC_DATE])))		AS PocDate
			,[BKY_RMS_ID]															AS RMSId
			,[BKY_VALID_FLAG]														AS IsBKYValid
			,dbo.fn_IsValidDateThenReturnDateChar([BKY_UPDATE_DATE])				AS UpdatedDate
			,[BKY_INPUT_FILE_NAME]													AS InputFileName
		FROM TR00.BKY_HISTORY (NOLOCK) AS BH
		WHERE
			(@v_paddedDefendantID IS NULL OR RIGHT(BH.BKY_DEF_ID, 4) = @v_paddedDefendantID) AND
			(@v_DefendantName IS NULL OR CONTAINS(BKY_DEF_NAME, @DefendantNameSearch))
		OPTION (RECOMPILE)
END


