SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_100b_sp_ASP_Cust_to_ASP_UPDATE]
AS
BEGIN

		truncate table [dbo].[a_ASP_IN_UPDATE]
		truncate table [dbo].[a_ASP_IN_UPDATE_STD]

		truncate table [dbo].DragonAssr_UPDATE
		truncate table [dbo].DragonAssr_UPDATE_STD

		EXEC('INSERT INTO [dbo].[a_ASP_IN_UPDATE]
		(
			   [RAW_ID]
			  ,[FullStreetAddress]
			  ,[City]
			  ,[State]
			  ,[ZIP5]
		)
		SELECT [DTDB_Ref_ID]
			  ,[SitusStdFullStreetAddress]
			  ,[SitusStdCity]
			  ,[SitusStdState]
			  ,[SitusStdZIP5]
		FROM [dbo].[PropertyWorkUpdate] 
		WHERE DTDB_REF_ID is not NULL')


		update a_ASP_IN_UPDATE SET State = NULL Where len(STATE)>2


		IF (Select COUNT(*) FROM dbo.a_ASP_IN_UPDATE with(NOLOCK) WHERE Processed = 'N') > 0 
			BEGIN

				WHILE (Select COUNT(*) FROM a_ASP_IN_UPDATE with(NOLOCK) WHERE Processed = 'N') > 0
					BEGIN
				
						truncate table dbo.DragonAssr_UPDATE
						truncate table dbo.DragonAssr_UPDATE_STD

						INSERT INTO dbo.DragonAssr_UPDATE(RecordId,[FullStreetAddress],[City],[State],[Zip],[raw_id])
						SELECT TOP 200000 ASP_ID,LEFT([FullStreetAddress],255),LEFT([City],55),[State],[ZIP5],[RAW_ID]
						FROM a_ASP_IN_UPDATE 
						WHERE PROCESSED = 'N'

						EXEC('INSERT INTO  [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
						 (''DragonAssr_Update'',''DragonAssr_Update'',''B'',''R'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
						 ')

					---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 1 MIN INTERVALS FOR COMPLETION

							IF (SELECT COUNT(*) FROM [dbo].DragonAssr_UPDATE with(NOLOCK)) = 0
								BEGIN
									RETURN;
								END
							ELSE
								BEGIN
									---- 1 min wait periods until ASP is complete
									DECLARE @CheckASP as int
				
										SET @CheckASP = 0

									WHILE @CheckASP = 0
										BEGIN
											WAITFOR DELAY '00:01'
							
										---- Checks for completion ** If not wait again
										SET @CheckASP = (Select COUNT(*) from dbo.DragonAssr_UPDATE_STD with(NOLOCK))
										PRINT @CheckASP
										END
								END

						EXEC dbo.usp_100c_sp_ASP_Cust_STD_UPDATE

						UPDATE a_ASP_IN_UPDATE SET Processed = 'Y'
						WHERE ASP_ID in(Select ASP_ID from [a_ASP_IN_Update_STD])

					END
		END



END



