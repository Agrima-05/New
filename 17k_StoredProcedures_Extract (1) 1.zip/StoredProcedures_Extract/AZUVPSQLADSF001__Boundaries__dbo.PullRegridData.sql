SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[PullRegridData](@fips as varchar(5))
AS

BEGIN

EXEC('INSERT INTO [Boundaries].[dbo].[FARegrid]
           ([FAMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
		   ,[ID]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT])

Select      [FAMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
		   ,[ID]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
from OPENQUERY([AZUVNSQLDTDB016],''Select * from [Regrid].[dbo].[zFARegrid] where fips = ''''' + @Fips + ''''''')
')

-----  
--INSERT INTO [Regrid].[dbo].[zRegridParcel_LicMatch_Run]
--           ([Fips]
--           ,[cnt]
--           ,[Matched]
--           ,[zcolumn])
--Select 
--  Fips
--  ,Count(fips) as cnt
--  ,sum(case when [alt_parcelnumb3PropertyID] is not null then 1 else 0 end) as Matched
--  ,'PN3_Verify' as zcolumn
--  from [Regrid].[dbo].[zRegridParcel_LicMatch]
--  where fips = @fips
--  group by fips



 end
