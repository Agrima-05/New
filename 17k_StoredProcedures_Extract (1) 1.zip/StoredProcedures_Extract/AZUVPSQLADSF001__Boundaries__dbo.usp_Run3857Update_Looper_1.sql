SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_Run3857Update_Looper_1]
AS
BEGIN
	SET NOCOUNT ON;

Declare @Fipscode1 varchar(5)

			DECLARE curPostgresql1 CURSOR FOR  
				SELECT [FIPSCode] 
				FROM dbo.[Run3857]
				--WHERE [FIPSCode] = '37179'
				WHERE [Session] = 1 AND COMPLETE = 'N'
				ORDER BY [FIPSCode]


			OPEN curPostgresql1   
			FETCH NEXT FROM curPostgresql1 INTO @Fipscode1

			WHILE @@FETCH_STATUS = 0   
			BEGIN   
			PRINT @Fipscode1
 
				UPDATE [dbo].[PostgreSQL_PROC] SET [Complete] = NULL Where thread = 1


				UPDATE [dbo].[Move_to_postgres_auto]
				SET fips = @Fipscode1
				WHERE thread = 1

				DECLARE @var0 smallint = 1
				Declare @execution_id bigint
				EXEC [SSISDB].[catalog].[create_execution] @package_name='Package1.dtsx', @execution_id=@execution_id OUTPUT, @folder_name='spot_data_move', @project_name='Spot_data_move', @use32bitruntime=False, @reference_id=Null
				EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=50, @parameter_name=N'LOGGING_LEVEL', @parameter_value=@var0
				EXEC [SSISDB].[catalog].[start_execution] @execution_id


				WHILE (Select Complete from dbo.PostgreSQL_PROC Where thread = 1) is NULL
					BEGIN
						WAITFOR DELAY '00:00:30';
					END
				  		
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode1) in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN

					--EXEC('update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot a 
					--where a.FIPS = '''+@Fipscode1+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated a 
					--where a.FIPS = '''+@Fipscode1+'''

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					')
					
					EXEC('UPDATE dbo.FASpot 
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode1+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode1+''' and ParcelGeometry3857 is NULL
					')
					
					END	
					
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode1) NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN
					 	
					--update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_a a 
					--where a.FIPS = '''+@Fipscode1+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated_a a 
					--where a.FIPS = '''+@Fipscode1+'''
					--')

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

				-------------------------
					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL


				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+'''

				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_1] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode1+''' and b.FIPS = '''+@Fipscode1+''' and Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END as UniqueIdentifier) is NULL

					UPDATE dbo.FASpot_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode1+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode1+''' and ParcelGeometry3857 is NULL
					')

					END

					EXEC('UPDATE dbo.[Run3857]
							SET Complete = ''Y''
							WHERE FIPSCode = '''+@Fipscode1+'''
							')

					FETCH NEXT FROM curPostgresql1 INTO @Fipscode1 
			END   

				CLOSE curPostgresql1   
				DEALLOCATE curPostgresql1 		


END
