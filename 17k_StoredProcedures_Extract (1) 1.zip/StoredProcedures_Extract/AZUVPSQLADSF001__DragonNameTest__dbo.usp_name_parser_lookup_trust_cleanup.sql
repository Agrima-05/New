SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_name_parser_lookup_trust_cleanup] -- @tableName varchar(255)

AS
BEGIN

-------------------------------- sp 
-- select count(*) from [DragonNameTest].[dbo].[lkup_Trust_Name] A with (nolock) where BeginsWith is not null -- 33
-- select count(*) from [DragonNameTest].[dbo].[lkup_Trust_Name] A with (nolock) where ContainsIn is not null -- 33 
-- select count(*) from [DragonNameTest].[dbo].[lkup_Trust_Name] A with (nolock) where EndsWith is not null -- 37 -- highest count is used as the first insert other are updates
-- select count(*) from [DragonNameTest].[dbo].[lkup_Trust_Name] A with (nolock) where Only is not null -- 33

DROP TABLE [DragonNameTest].[dbo].[tt_lkup_Trust_Name]
CREATE TABLE [DragonNameTest].[dbo].[tt_lkup_Trust_Name](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[BeginsWith] [varchar](50) NULL,
	[ContainsIn] [varchar](50) NULL,
	[EndsWith] [varchar](50) NULL,
	[Only] [varchar](50) NULL) 
DROP TABLE [DragonNameTest].[dbo].[tt_BeginsWith]
CREATE TABLE [DragonNameTest].[dbo].[tt_BeginsWith] ([ID] [int] IDENTITY(1,1) NOT NULL, [BeginsWith] [varchar](50) NULL, CONSTRAINT UCt_BeginsWith UNIQUE (BeginsWith) WITH (IGNORE_DUP_KEY = ON)) 
DROP TABLE [DragonNameTest].[dbo].[tt_ContainsIn]
CREATE TABLE [DragonNameTest].[dbo].[tt_ContainsIn] ([ID] [int] IDENTITY(1,1) NOT NULL, [ContainsIn] [varchar](50) NULL, CONSTRAINT UCt_ContainsIn UNIQUE (ContainsIn) WITH (IGNORE_DUP_KEY = ON))
DROP TABLE [DragonNameTest].[dbo].[tt_EndsWith]
CREATE TABLE [DragonNameTest].[dbo].[tt_EndsWith] ([ID] [int] IDENTITY(1,1) NOT NULL, [EndsWith] [varchar](50) NULL, CONSTRAINT UCt_EndsWith UNIQUE (EndsWith) WITH (IGNORE_DUP_KEY = ON))
DROP TABLE [DragonNameTest].[dbo].[tt_Only]
CREATE TABLE [DragonNameTest].[dbo].[tt_Only] ([ID] [int] IDENTITY(1,1) NOT NULL, [Only] [varchar](50) NULL, CONSTRAINT UCt_Only UNIQUE (Only) WITH (IGNORE_DUP_KEY = ON))

-- load tt_tables
insert [DragonNameTest].[dbo].[tt_BeginsWith] (BeginsWith) select BeginsWith from [DragonNameTest].[dbo].[lkup_Trust_Name] where BeginsWith is not null order by BeginsWith 
insert [DragonNameTest].[dbo].[tt_ContainsIn] (ContainsIn) select ContainsIn from [DragonNameTest].[dbo].[lkup_Trust_Name] where ContainsIn is not null order by ContainsIn 
insert [DragonNameTest].[dbo].[tt_EndsWith] (EndsWith) select EndsWith from [DragonNameTest].[dbo].[lkup_Trust_Name] where EndsWith is not null order by EndsWith 
insert [DragonNameTest].[dbo].[tt_Only] (Only) select Only from [DragonNameTest].[dbo].[lkup_Trust_Name] where Only is not null order by Only
 
-- load highest count of lookup column count (EndsWith)
insert [DragonNameTest].[dbo].[tt_lkup_Trust_Name] (EndsWith) select EndsWith from [DragonNameTest].[dbo].[tt_EndsWith]

-- update BeginsWith
set nocount on
declare @t_cnt_b int
set @t_cnt_b = 1
declare @t_BeginWith varchar(50)

declare c_update_b cursor scroll keyset for

select BeginsWith from [DragonNameTest].[dbo].[tt_BeginsWith] 

open c_update_b
fetch next from c_update_b into @t_BeginWith

while (@@fetch_status = 0)
Begin
update a set a.BeginsWith = @t_BeginWith 
    from [DragonNameTest].[dbo].[tt_lkup_Trust_Name] a
    where a.ID = @t_cnt_b

set @t_cnt_b = @t_cnt_b + 1

fetch next from c_update_b into @t_BeginWith
end

close c_update_b
deallocate c_update_b

-- update ContainsIn
set nocount on
declare @t_cnt_c int
set @t_cnt_c = 1
declare @t_ContainsIn varchar(50)

declare c_update_c cursor scroll keyset for

select ContainsIn from [DragonNameTest].[dbo].[tt_ContainsIn] 

open c_update_c
fetch next from c_update_c into @t_ContainsIn

while (@@fetch_status = 0)
Begin
update a set a.ContainsIn = @t_ContainsIn 
    from [DragonNameTest].[dbo].[tt_lkup_Trust_Name] a
    where a.ID = @t_cnt_c

set @t_cnt_c = @t_cnt_c + 1

fetch next from c_update_c into @t_ContainsIn
end

close c_update_c
deallocate c_update_c

-- update Only
set nocount on
declare @t_cnt_o int
set @t_cnt_o = 1
declare @t_Only varchar(50)

declare c_update_o cursor scroll keyset for

select Only from [DragonNameTest].[dbo].[tt_Only] 

open c_update_o
fetch next from c_update_o into @t_Only

while (@@fetch_status = 0)
Begin
update a set a.Only = @t_Only 
    from [DragonNameTest].[dbo].[tt_lkup_Trust_Name] a
    where a.ID = @t_cnt_o

set @t_cnt_o = @t_cnt_o + 1

fetch next from c_update_o into @t_Only
end

close c_update_o
deallocate c_update_o

-- create indexes
CREATE NONCLUSTERED INDEX [IDX_lkup_Trust_Name_BeginsWith] ON [DragonNameTest].[dbo].[tt_lkup_Trust_Name] ([BeginsWith])
CREATE NONCLUSTERED INDEX [IDX_lkup_Trust_Name_ContainsIn] ON [DragonNameTest].[dbo].[tt_lkup_Trust_Name] ([ContainsIn])
CREATE NONCLUSTERED INDEX [IDX_lkup_Trust_Name_EndsWith] ON [DragonNameTest].[dbo].[tt_lkup_Trust_Name] ([EndsWith])
CREATE NONCLUSTERED INDEX [IDX_lkup_Trust_Name_Only] ON [DragonNameTest].[dbo].[tt_lkup_Trust_Name] ([Only])

-- rename tables
select 'Rename tables NOT COMPLETED'
select 'exec sp_rename ''dbo.lkup_Trust_Name'', ''lkup_Trust_Name_old'''
select 'exec sp_rename ''dbo.tt_lkup_Trust_Name'', ''lkup_Trust_Name'''

END

