SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[usp_LoadSpot_REF_V4_RestartPostingData]
AS
BEGIN

	SET NOCOUNT ON;

EXEC msdb.dbo.sp_update_job 
    @job_name = N'Spot Data Load', -- Disables sql agent while process runs
    @enabled = 0; 

----------START DATA LOAD
		DECLARE @FipsCode varchar(5)
		DECLARE @StateAbbrev varchar(2)

			EXEC [dbo].[usp_LoadSpot_REF_V4_reStart_DataLoad]

			EXEC [dbo].[usp_LoadSpot_REF_V4_reStart_DataLoad_a]


		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 5'

/*****STEP 6 STARTS HERE*****/

		INSERT into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 6','Rerunning Stats and Cleaning', GETDATE(), NULL,'If STEP 6 Errors run [dbo].[usp_LoadSpot_REF_V4_RestartFinishing]'


		DROP TABLE IF EXISTS dbo.FASpotStacked
		DROP TABLE IF EXISTS  dbo.FASpotMulti

			Select FIPS,Latitude,Longitude,Count(*) NumberStacked 
			INTO dbo.FASpotStacked
			from [dbo].[vFASpot_FULL]
			GROUP BY FIPS,Latitude,Longitude
			having Count(*) > 1

			Select FIPS,RefId,Count(*) NumberStacked 
			INTO dbo.FASpotMulti
			from [dbo].[vFASpot_FULL]
			GROUP BY FIPS,RefId
			having Count(*) > 1

			CREATE INDEX ix_LatLong on dbo.FASpotStacked(Latitude,Longitude)
			CREATE INDEX ix_RefId on dbo.FASpotMulti(Fips,RefId)

			UPDATE a
			 SET RunRefresh = convert(varchar(8),Getdate(),112)
			 from [AZUVPSQLDTDB034].[NG911].dbo.Spt_Delivery a JOIN dbo.FASpotStats b
			 on a.FIPS = b.FIPS
			 where RefreshMe = 'Y'


		DROP TABLE IF EXISTS [Boundaries].dbo.UpdateRecords

		Select Max(LoadDate) MaxDt INTO #FASpotLoadDate FROM dbo.FASpot 
		Select Max(LoadDate) MaxDt INTO #FASpotALoadDate FROM dbo.FASpot_a
		Select Max(LoadDate) MaxDt INTO #FASpotGLoadDate FROM dbo.FASpot_Generated
		Select Max(LoadDate) MaxDt INTO #FASpotGALoadDate FROM dbo.FASpot_Generated_a

			update FASpot
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			--Select COUNT(*) 
			FROM FASpot
			WHERE LoadDate = (Select MaxDt FROM #FASpotLoadDate) and LEN(GeomWKT)>10000000

			update FASpot_a
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_a
			WHERE LoadDate = (Select MaxDt FROM #FASpotALoadDate) and LEN(GeomWKT)>10000000

			update FASpot_Generated
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_Generated
			WHERE LoadDate = (Select MaxDt FROM #FASpotGLoadDate) and LEN(GeomWKT)>10000000

			update FASpot_Generated_a
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_Generated_a
			WHERE LoadDate = (Select MaxDt FROM #FASpotGALoadDate) and LEN(GeomWKT)>10000000

		Drop table if exists #FASpotLoadDate
		Drop table if exists #FASpotALoadDate
		Drop table if exists #FASpotGLoadDate
		Drop table if exists #FASpotGALoadDate



		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 6'

/***** SET SO JOBS RUN *****/
	UPDATE jobs.dbo.SystemProperty
	SET [Value] = 'N'
	,UpdateDate = GETDATE()
	WHERE Name = 'IsSpotRunning'

EXEC msdb.dbo.sp_update_job 
    @job_name = N'Spot Data Load', -- Disables sql agent while process runs
    @enabled = 1; 


END


