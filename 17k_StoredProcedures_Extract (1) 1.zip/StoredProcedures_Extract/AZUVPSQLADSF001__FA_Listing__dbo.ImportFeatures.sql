SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[ImportFeatures]
	@PartitionId INT
AS
	SET NOCOUNT ON

	DECLARE @Timestamp VARCHAR(25)

	SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
	RAISERROR('%s Insert into tmp.Features', 0, 1, @Timestamp) WITH NOWAIT

	DECLARE @BatchSize INT = 2000
	DECLARE @BeginRow INT
	DECLARE @EndRow INT
	DECLARE @RowCount INT
	SELECT @BeginRow = BeginRow, @EndRow = EndRow FROM ImportPartition WITH (NOLOCK) WHERE Id = @PartitionId
	WHILE @BeginRow <= @EndRow
	BEGIN
		BEGIN TRY
		BEGIN TRANSACTION
		INSERT INTO tmp.Features WITH (ROWLOCK) (
			Row_Id
			,FeatureTypeId
			,Value
			,FeatureValueId
			,FeatureRuleId
		)
		SELECT DISTINCT
			Row_Id
			,f.FeatureTypeId
			,UPPER(LTRIM(f.Value)) AS Value
			,ISNULL(r.FeatureValueId, v.Id)
			,r.Id
		FROM (
			SELECT TOP (@BatchSize) *
			FROM tmp.FA_MLS WITH (NOLOCK)
			WHERE Row_Id BETWEEN @BeginRow AND @EndRow
			ORDER BY Row_Id
		) m
		CROSS APPLY (
			SELECT DISTINCT 1, Item FROM dbo.DelimitedSplit8K([APPLIANCES], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 2, Item FROM dbo.DelimitedSplit8K([COMMUNITY_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 3, Item FROM dbo.DelimitedSplit8K([COMPLEX_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 4, Item FROM dbo.DelimitedSplit8K([COOLING_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 5, Item FROM dbo.DelimitedSplit8K([ELEMENTARY_SCHOOL], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 6, Item FROM dbo.DelimitedSplit8K([ENERGY_INFO], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 7, Item FROM dbo.DelimitedSplit8K([EXISTING_STRUCTURES], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 8, Item FROM dbo.DelimitedSplit8K([EXTERIOR_CONSTRUCTION], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 9, Item FROM dbo.DelimitedSplit8K([EXTERIOR_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 10, Item FROM dbo.DelimitedSplit8K([FARM_IMPROVEMENT], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 11, Item FROM dbo.DelimitedSplit8K([FIREPLACE_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 12, Item FROM dbo.DelimitedSplit8K([HEATING_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 13, Item FROM dbo.DelimitedSplit8K([HIGH_SCHOOL], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 14, Item FROM dbo.DelimitedSplit8K([INTERIOR_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 15, Item FROM dbo.DelimitedSplit8K([LOT_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 16, Item FROM dbo.DelimitedSplit8K([MASTER_BEDROOM], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 17, Item FROM dbo.DelimitedSplit8K([MIDDLE_SCHOOL], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 18, Item FROM dbo.DelimitedSplit8K([MLS_AREA], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 19, Item FROM dbo.DelimitedSplit8K([MLS_INCLUSIONS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 20, Item FROM dbo.DelimitedSplit8K([NBR_GRG], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 21, Item FROM dbo.DelimitedSplit8K([NBR_STORIES], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 22, Item FROM dbo.DelimitedSplit8K([NEIGHBORHOOD], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 23, Item FROM dbo.DelimitedSplit8K([PARCEL_ACCESS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 24, Item FROM dbo.DelimitedSplit8K([PARKING_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 25, Item FROM dbo.DelimitedSplit8K([POOL_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 26, Item FROM dbo.DelimitedSplit8K([PRESENT_USE], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 27, Item FROM dbo.DelimitedSplit8K([PROPERTY_SUB_TYPE], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 28, Item FROM dbo.DelimitedSplit8K([PROPERTY_TYPE], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 29, Item FROM dbo.DelimitedSplit8K([RANGE_AIRCONDITIONERS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 30, Item FROM dbo.DelimitedSplit8K([ROOFING], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 31, Item FROM dbo.DelimitedSplit8K([SCHOOL_DISTRICT], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 32, Item FROM dbo.DelimitedSplit8K([SEWER], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 33, Item FROM dbo.DelimitedSplit8K([STYLE], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 34, Item FROM dbo.DelimitedSplit8K([SUBDIVISION], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 35, Item FROM dbo.DelimitedSplit8K([UTILITY_PRESENT], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 36, Item FROM dbo.DelimitedSplit8K([VIEW_1], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 37, Item FROM dbo.DelimitedSplit8K([WATER], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 38, Item FROM dbo.DelimitedSplit8K([WATER_FRONT_FTRS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 39, Item FROM dbo.DelimitedSplit8K([WATER_HEATER], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 41, Item FROM dbo.DelimitedSplit8K([WATER_ACCESS], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 58, Item FROM dbo.DelimitedSplit8K([TOPOGRAPHY], ',') WHERE Item > '' UNION ALL
			SELECT DISTINCT 59, Item FROM dbo.DelimitedSplit8K([ZONING], ',') WHERE Item > ''
		) f (FeatureTypeId, Value)
		LEFT JOIN FeatureValues v WITH (NOLOCK) ON f.FeatureTypeId = v.FeatureTypeId AND UPPER(LTRIM(f.Value)) = v.Value
		LEFT JOIN FeatureRules r WITH (NOLOCK) ON f.FeatureTypeId = r.FeatureTypeId AND UPPER(LTRIM(f.Value)) = r.OriginalValue

		SET @RowCount = @@ROWCOUNT

		COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			IF XACT_STATE() <> 0
				ROLLBACK TRANSACTION
			CONTINUE
		END CATCH

		SELECT @BeginRow = MAX(Row_Id) + 1
		FROM (
			SELECT TOP (@BatchSize) Row_Id
			FROM tmp.FA_MLS WITH (NOLOCK)
			WHERE Row_Id BETWEEN @BeginRow AND @EndRow
			ORDER BY Row_Id
		) t

		SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
		RAISERROR('%s %d %d %d', 0, 1, @Timestamp, @RowCount, @EndRow, @BeginRow) WITH NOWAIT
	END

