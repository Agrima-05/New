SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[UpdateDMAddrDMCL--] (@fips int) as

update a set a.Ref_Id = b.refid
from DMaddr a, DMCL b
where a.fips = b.fips and a.PARCEL_APN = b.apn
and a.fips = @fips
return @@rowcount


