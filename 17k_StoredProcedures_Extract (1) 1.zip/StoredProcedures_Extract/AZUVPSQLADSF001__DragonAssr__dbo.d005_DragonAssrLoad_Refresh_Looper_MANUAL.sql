SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d005_DragonAssrLoad_Refresh_Looper_MANUAL]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @FipsCode varchar(5)

		--Select fipscode from  [dbo].[Dragon_Flank_Batch_ASSR]

		DECLARE FmtDocPost CURSOR FOR  
			SELECT Fips
			FROM Dragon_Refresh_Tracker
			WHERE RunRefresh = 'Y' 
				and FIPS > '34025'
			ORDER BY Fips


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC [dbo].[d050_RunDragonAssrProcess] @FipsCode

			DELETE FROM [dbo].[Dragon_Flank_Refreshes] WHERE Fips = @FipsCode

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 


END
