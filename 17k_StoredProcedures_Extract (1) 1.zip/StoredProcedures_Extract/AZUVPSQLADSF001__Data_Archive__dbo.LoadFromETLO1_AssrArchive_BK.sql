SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- EXEC [dbo].[LoadFromETLO1_AssrArchive_CL] 6037
CREATE PROCEDURE [dbo].[LoadFromETLO1_AssrArchive_BK](@fips as varchar(5))
AS
BEGIN
	declare @fipsInt int = cast(@fips as int)
	delete from AssrArchive_BK where fips = @fipsInt
	insert into AssrArchive_BK SELECT [AssrID]
      ,[FIPS]
      ,[REF_ID]
      ,[UNFORMATTED_APN]
      ,[APN_SEQUENCE_NBR]
      ,[FORMATTED_APN]
      ,[TAX_AMOUNT]
      ,[TAX_YEAR]
      ,[CERTIFICATION_DATE]
      ,[Source_Type]
  FROM [DWS-ETL01].[Assr_Archive].[dbo].[AssrArchive_BK] with(nolock) where fips =@fipsInt
END

