SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

			CREATE procedure [dbo].[usp_102_sp_allAddresses_MIPost] (@tableName varchar(40)) 
			as  
			declare @sql varchar(max) = ''

				set @sql = '
				   UPDATE AddressSTD.[dbo].[allAddresses_MI_STD]
				   set [FullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetNumber])) + '' '' + AddressSTD.[dbo].[allAddresses_MI_STD].[PreDir])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetName]))))) + '' '' + ltrim(rtrim(UPPER(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetType]))) + '' '' + AddressSTD.[dbo].[allAddresses_MI_STD].[PostDir]))))  + '' '' + ltrim(rtrim(ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[SuiteType])) + '' '' + (ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Suite])))))))
					,[CountyFips]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CountyFips]))
					,[StreetNumber]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetNumber]))
					,[PreDir]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[PreDir]))
					,[StreetName]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetName]))
					,[StreetType]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[StreetType]))
					,[PostDir]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[PostDir]))
					,[SuiteType]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[SuiteType]))
					,[Suite]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Suite]))
					,[City]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[City]))
					,[State]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[State]))
					,[Zip]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Zip]))
					,[Plus4]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Plus4]))
					,[CarrierRoute]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CarrierRoute]))
					,[CountyName]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CountyName]))
					,[PrivateMailbox]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[PrivateMailbox]))
					,[Pmsa]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Pmsa]))
					,[Msa]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Msa]))
					,[ZipType]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[ZipType]))
					,[Urbanization]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Urbanization]))
					,[CongressionalDistrict]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CongressionalDistrict]))
					,[CityAbbreviation]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CityAbbreviation]))
					,[AddressTypeCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[AddressTypeCode]))
					,[AddressTypeString]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[AddressTypeString]))
					,[DPVCount]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[DPVCount]))
					,[DPVFootnotes]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[DPVFootnotes]))
					,[CMRA]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CMRA]))
					,[ELotNumber]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[ELotNumber]))
					,[ELotOrder]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[ELotOrder]))
					,[Lacs]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Lacs]))
					,[LACSLinkIndicator]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[LACSLinkIndicator]))
					,[EWSFlag]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[EWSFlag]))
					,[RBDI]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[RBDI]))
					,[SuiteLinkReturnCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[SuiteLinkReturnCode]))
					,[DeliveryPointCheckDigit]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[DeliveryPointCheckDigit]))
					,[DeliveryPointCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[DeliveryPointCode]))
					,[Verified]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Verified]))
					,[AddressMatchResults]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[AddressMatchResults]))
					,[CensusBlock]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CensusBlock]))
					,[CensusTract]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CensusTract]))
					,[PlaceCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[PlaceCode]))
					,[PlaceName]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[PlaceName]))
					,[CBSACode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSACode]))
					,[CBSALevel]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSALevel]))
					,[CBSATitle]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSATitle]))
					,[CBSADivisionCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSADivisionCode]))
					,[CBSADivisionLevel]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSADivisionLevel]))
					,[CBSADivisionTitle]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CBSADivisionTitle]))
					,[Latitude]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Latitude]))
					,[Longitude]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Longitude]))
					,[Geocoded]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[Geocoded]))
					,[GeoErrorCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[GeoErrorCode]))
					,[GeoStatusCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[GeoStatusCode]))
					,[GeoCodeResults]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[GeoCodeResults]))
					,[CountryCode]  = ltrim(rtrim(AddressSTD.[dbo].[allAddresses_MI_STD].[CountryCode]))


				 From AddressSTD.[dbo].[allAddresses_MI_STD]

				 	UPDATE
						Table_A
					SET
						Table_A.raw_id = Table_B.raw_id
					FROM
						AddressSTD.[dbo].[allAddresses_MI_STD] Table_A
					INNER JOIN
						AddressSTD.[dbo].[allAddresses_MI] Table_B
					ON
						Table_A.RecordId = Table_B.RecordId

				'
			print @sql
			exec (@sql)
