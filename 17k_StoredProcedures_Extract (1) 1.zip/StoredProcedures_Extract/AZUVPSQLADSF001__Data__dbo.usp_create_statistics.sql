SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[usp_create_statistics] 
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @FipsCode varchar(5)

		DECLARE CurPropStats CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
						ORDER BY [FIPSCode]
		OPEN CurPropStats   
		FETCH NEXT FROM CurPropStats INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode 
			
			exec('DROP STATISTICS dbo.Property.st_Property_FIPS_' + @FipsCode + ';
			
			CREATE statistics st_Property_FIPS_' + @FipsCode + '
				on Data.dbo.Property(FIPS)
				where [FIPS] = ''' + @FipsCode + '''
				with fullscan;
				')

			
			FETCH NEXT FROM CurPropStats INTO @FipsCode   
		END   

		CLOSE CurPropStats   
		DEALLOCATE CurPropStats 


END

