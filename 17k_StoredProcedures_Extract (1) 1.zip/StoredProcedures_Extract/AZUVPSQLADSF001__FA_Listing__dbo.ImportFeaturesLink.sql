SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[ImportFeaturesLink]
AS
	SET NOCOUNT ON

	DECLARE @Timestamp VARCHAR(25)

	CREATE TABLE #FeatureValuesInserted (
		Id INT PRIMARY KEY,
		FeatureTypeId SMALLINT NOT NULL,
		Value VARCHAR(800) NOT NULL
	)

	-- Populate FeatureValues table with any new possible values
	SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
	RAISERROR('%s Populate FeatureValues table with any new possible values', 0, 18, @Timestamp) WITH NOWAIT
	INSERT INTO FeatureValues (FeatureTypeId, Value)
	OUTPUT inserted.Id, inserted.FeatureTypeId, inserted.Value INTO #FeatureValuesInserted
	SELECT DISTINCT f.FeatureTypeId, f.Value
	FROM tmp.Features f
	WHERE f.FeatureValueId IS NULL

	CREATE INDEX IX_FeatureTypeId_Value ON #FeatureValuesInserted (FeatureTypeId, Value)

	-- Perform second link to match new possible values
	SET @Timestamp = CONVERT(VARCHAR, GETDATE(), 121)
	RAISERROR('%s Perform second link to match new possible values', 0, 18, @Timestamp) WITH NOWAIT
	UPDATE f
	SET FeatureValueId = v.Id
	FROM tmp.Features f
	INNER JOIN #FeatureValuesInserted v ON f.FeatureTypeId = v.FeatureTypeId AND f.Value = v.Value
	WHERE f.FeatureValueId IS NULL

