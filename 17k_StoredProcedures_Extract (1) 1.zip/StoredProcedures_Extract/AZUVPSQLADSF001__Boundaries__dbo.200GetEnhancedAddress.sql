SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[200GetEnhancedAddress] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

-----------STEP 1

INSERT INTO [GISService_ETL].[gis].[FASpot_a_2_EnhancedAddress]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[APN]
           ,[FIPS]
           ,[DTDB_Ref_ID]
           ,[SitusStdFullStreetAddress]
           ,[SitusStdCity]
           ,[SitusStdState]
           ,[SitusStdZIP5]
           ,[FACascadeLatitude]
           ,[FACascadeLongitude]
           ,[FACascadeGeoStatusCode]
           ,[Geom])
select [PropertyID]  as [FADigitalMapMasterId]
      ,[PropertyID]
      ,[FormattedAPN]
      ,FormattedAPN as [APN]
      ,[FIPS]
      ,[DTDB_Ref_ID]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[FACascadeLatitude]
      ,[FACascadeLongitude]
      ,[FACascadeGeoStatusCode]
      ,case when [FACascadeLatitude] is null then null else 
	  geometry::Point([xGtrang].[dbo].[LongToMercatorX]([FACascadeLongitude]), [xGtrang].[dbo].[LatToMercatorY]([FACascadeLatitude]), 3857) end
from [Boundaries].[dbo].[FASpot_GeoCoordinates] with (nolock)
where fips = @fips

INSERT INTO [Boundaries].[dbo].[zz_200GetEnhancedAddress_Run]
           ([Fips],[DateTime])
 Select @fips,GetDate()

END

