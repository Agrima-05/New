SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- See 
-- =============================================
CREATE PROCEDURE [dbo].[usp_Get_Listing_Trends_2021] 

AS
BEGIN

----- GET Daily Breakdown

Select c.CBSAName as CBSA,[Current_Original_Listing_Date] + '--' + DATENAME(WEEKDAY,[Current_Original_Listing_Date]) ListDate, COUNT(*) RecordCount, SUM(CASE WHEN isNULL(Internal_FA_Property_Ref_ID,'') NOT like '' THEN 1 ELSE 0 END) as RecordsLinked
 from Listing.[dbo].[_LISTINGS_ALL_CURRENT] a with(NOLOCK) JOIN [Global].[dbo].[County] b with(NOLOCK) on a.[County_Fips] = b.FipsCode JOIN (Select Top 25 * from [Global].[dbo].[County_Top100] with(NOLOCK) ORDER BY Population100 desc) c on b.[cbsaname] = c.[cbsaname]
Where [Current_Original_Listing_Date] >= '2021-01-01' 
GROUP BY c.CBSAName ,[Current_Original_Listing_Date] + '--' + DATENAME(WEEKDAY,[Current_Original_Listing_Date])
order by 1,[Current_Original_Listing_Date] + '--' + DATENAME(WEEKDAY,[Current_Original_Listing_Date])


----- GET Weekly Overall 

Select convert(varchar(4),WeekYear) + ' WEEK - ' + RIGHT('0' + Convert(varchar(2),[Week]),2) + ' - ' + WeekBeginDt + ' - ' + WeekEndDt as WeekDateRange, CountListDates
FROM (
Select YEAR([Current_Original_Listing_Date]) as WeekYear, DATEPART(wk, [Current_Original_Listing_Date]) AS Week,Min([Current_Original_Listing_Date]) WeekBeginDt,Max([Current_Original_Listing_Date]) WeekEndDt,

COUNT(*) AS COUNTListDates

FROM  Listing.[dbo].[_LISTINGS_ALL_CURRENT] with(NOLOCK)
Where [Current_Original_Listing_Date] >= '2021-01-01' 

Group By YEAR([Current_Original_Listing_Date]),DATEPART (wk, [Current_Original_Listing_Date])) info
order By 1


----- GET Weekly CBSA Breakdown

Select c.CBSAName as CBSA,convert(varchar(4),Year([Current_Original_Listing_Date])) + '-' + RIGHT('0' + convert(varchar(2),DATEPART(wk, [Current_Original_Listing_Date])),2) WeekNbr, COUNT(*) RecordCount, SUM(CASE WHEN isNULL(Internal_FA_Property_Ref_ID,'') NOT like '' THEN 1 ELSE 0 END) as RecordsLinked
 from Listing.[dbo].[_LISTINGS_ALL_CURRENT] a with(NOLOCK) JOIN [Global].[dbo].[County] b with(NOLOCK) on a.[County_Fips] = b.FipsCode JOIN (Select Top 25 * from [Global].[dbo].[County_Top100] with(NOLOCK) ORDER BY Population100 desc) c on b.[cbsaname] = c.[cbsaname]
Where [Current_Original_Listing_Date] >= '2021-01-01' 
GROUP BY c.CBSAName ,convert(varchar(4),Year([Current_Original_Listing_Date])) + '-' + RIGHT('0' + convert(varchar(2),DATEPART(wk, [Current_Original_Listing_Date])),2)
order by 1,2

----- GET 6 month MEDIAN DaysOnMarket  -- Added 20210610

--Select Convert(varchar(10),GETDATE(),120) as RunDate
--,c.CBSAcode,c.CBSAName
--,convert(money,SUM(AvgDaysOnMarket))/convert(money,COUNT(*)) as AvgDaysOnMarketOverLast6MoByCBSA 
--FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
--	SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
--JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
--  where CBSACode in(12060	 -- 	Atlanta-GA
--,12580	 -- 	Baltimore-MD
--,14460	 -- 	Boston-MA
--,16740	 -- 	Charlotte-NC
--,16980	 -- 	Chicago-IL
--,19100	 -- 	Dallas-TX
--,19820	 -- 	Detroit-MI
--,26420	 -- 	Houston-TX
--,31080	 -- 	Los Angeles-CA
--,33100	 -- 	Miami-FL
--,35620	 -- 	New York-NY
--,35420	 -- 	Philadelphia-PA
--,38060	 -- 	Phoenix-AZ
--,40140	 -- 	Riverside-CA
--,41740	 -- 	San Diego-CA
--,41860	 -- 	San Francisco-CA
--,41940	 -- 	San Jose-CA
--,42660	 -- 	Seattle-WA
--,45300	 -- 	Tampa-FL
--,47900	 -- 	Washington-DC
--)
--GROUP BY c.CBSAcode,c.CBSAName
-- ORDER BY CBSACode


SELECT * FROM
	(Select Convert(varchar(10),GETDATE(),120) as RunDate,'12060' as CBSACode,'Atlanta-Sandy Springs-Roswell, GA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(12060)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(12060)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'12580' as CBSACode,'Baltimore-Columbia-Towson, MD' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(12580)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(12580)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'14460' as CBSACode,'Boston-Cambridge-Newton, MA-NH' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(14460)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(14460)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'16740' as CBSACode,'Charlotte-Concord-Gastonia, NC-SC' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(16740)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(16740)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'16980' as CBSACode,'Chicago-Naperville-Elgin, IL-IN-WI' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(16980)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(16980)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'19100' as CBSACode,'Dallas-Fort Worth-Arlington, TX' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(19100)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(19100)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'19820' as CBSACode,'Detroit-Warren-Dearborn, MI' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(19820)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(19820)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'26420' as CBSACode,'Houston-The Woodlands-Sugar Land, TX' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(26420)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(26420)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'31080' as CBSACode,'Los Angeles-Long Beach-Anaheim, CA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(31080)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(31080)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'33100' as CBSACode,'Miami-Fort Lauderdale-West Palm Beach, FL' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(33100)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(33100)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'35420' as CBSACode,'New Philadelphia-Dover, OH' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(35420)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(35420)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'35620' as CBSACode,'New York-Newark-Jersey City, NY-NJ-PA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(35620)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(35620)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'38060' as CBSACode,'Phoenix-Mesa-Scottsdale, AZ' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(38060)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(38060)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'40140' as CBSACode,'Riverside-San Bernardino-Ontario, CA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(40140)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(40140)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'41740' as CBSACode,'San Diego-Carlsbad, CA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41740)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41740)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'41860' as CBSACode,'San Francisco-Oakland-Hayward, CA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41860)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41860)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'41940' as CBSACode,'San Jose-Sunnyvale-Santa Clara, CA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41940)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(41940)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'42660' as CBSACode,'Seattle-Tacoma-Bellevue, WA' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(42660)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(42660)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'45300' as CBSACode,'Tampa-St. Petersburg-Clearwater, FL' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(45300)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(45300)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA
UNION ALL
	Select Convert(varchar(10),GETDATE(),120) as RunDate,'47900' as CBSACode,'Washington-Arlington-Alexandria, DC-VA-MD-WV' as CBSAName,
	convert(int,((Select Max(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(47900)	 
	ORDER BY MedDaysOnMarket) BottomHalf)
	+
	(Select MIN(MedDaysOnMarket) FROM (Select TOP 50 Percent MedDaysOnMarket
	FROM [AZUVPSQLDTDB029.datatree.local].[TRENDS].[dbo].[tv_5751_6MonListing_Recap] a JOIN (
		SELECT Distinct [ZIPCode],[Fips] FROM [USPS].[dbo].[CITYSTATEDETAIL]) b on a.[Std_Zip] = b.[ZIPCode]
	JOIN [Global].dbo.[County] c on c.FIPScode = b.[Fips]
	  where CBSACode in(47900)	 
	ORDER BY MedDaysOnMarket DESC) TOPHalf))/2) as MedianDaysOnMarketOverLast6MoByCBSA

	) info





END

