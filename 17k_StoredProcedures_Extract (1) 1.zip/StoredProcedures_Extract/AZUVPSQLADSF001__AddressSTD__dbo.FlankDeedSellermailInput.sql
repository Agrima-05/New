SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankDeedSellermailInput](@tableName varchar(40)) -- @tableName = 'Deed_Sellermail' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + ' 
    [DeedUniqueID] [bigint] NOT NULL,
	[SellerMailFullAddress] [varchar](116) NULL,
	[SellerMailHouseNbr] [varchar](30) NULL,
	[SellerMailLeftDirection] [varchar](2) NULL,
	[SellerMailStreetName] [varchar](60) NULL,
	[SellerMailRightDirection] [varchar](2) NULL,
	[SellerMailMode] [varchar](5) NULL,
	[SellerMailUnitType] [varchar](20) NULL,
	[SellerMailUnitNumber] [varchar](15) NULL,
	[SellerMailCity] [varchar](55) NULL,
	[SellerMailState] [varchar](2) NULL,
	[SellerMailZip4] [varchar](4) NULL,
	[SellerMailZip5] [varchar](9) NULL,
	[SellerMailCarrierCode] [varchar](4) NULL,
	[SellerMailDPVCount] [varchar](5) NULL,
	[SellerMailDPVFootnote] [varchar](4) NULL,
	[SellerMailLACS] [varchar](1) NULL,
	[SellerMailLACSLinkInd] [varchar](1) NULL,
	[SellerMailDPCheckDigit] [varchar](1) NULL,
	[SellerMailDPCheckCode] [varchar](2) NULL,
	[SellerMailCensusBlock] [varchar](4) NULL,
	[SellerMailCensusTract] [varchar](6) NULL,
	[SellerMailStdMatchCode] [varchar] (30) NULL,
	[SellerMailGeoCodeResults] [varchar](30) NULL,
	[SellerMailGeoErrorCode] [varchar](1) NULL,
	[SellerMailGeoStatusCode] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT DeedUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([SellerMailFullAddress], '''') addressLine ,isnull(SellerMailCity, '''') as city  ,isnull(SellerMailState, '''') as state  ,
isnull(SellerMailZip5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY SellerMailZip5 desc'  

exec (@sql)  

