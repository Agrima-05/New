SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_100b_sp_ASP_Cust_to_ASP_Mail]
AS
BEGIN

		truncate table [dbo].[a_ASP_IN]
		truncate table [dbo].[a_ASP_IN_STD]

		truncate table [dbo].DragonAssr
		truncate table [dbo].DragonAssr_STD

		INSERT INTO [dbo].[a_ASP_IN]([RAW_ID]
			  ,[FullStreetAddress]
			  ,[City]
			  ,[State]
			  ,[ZIP5])
		SELECT [DTDB_Ref_ID]
			  ,[MailingStdFullStreetAddress]
			  ,[MailingStdCity]
			  ,[MailingStdState]
			  ,LEFT([MailingStdZIP5],5)
		FROM [dbo].[PropertyWork]
		WHERE DTDB_REF_ID is not NULL
		and isnull(MailingStdFullStreetAddress,'') not like ''
		and isNULL([MailForeignAddrInd],'') Like ''
		and isNULL([MailingStdZIP5],'') Not like '% %'
		and isNULL([MailingStdZIP5],'') not like '00000'
		and ((LEN(MailingStdCity) > 0 and LEN(MailingStdState)>0) OR LEN(MailingStdZip5)>0)
		
		UPDATE [dbo].[a_ASP_IN]
		SET [State] = [ZIP5]
		,[ZIP5] = NULL
		WHERE [ZIP5] like '[A-Z][A-Z]'

		DELETE FROM [dbo].[a_ASP_IN]
		WHERE ([State] like 'XX' and ISNULL([ZIP5],'') Like '' )
		OR ZIP5 like '%[A-z]%'


		update a_ASP_IN SET State = NULL Where len(STATE)>2


		IF (Select COUNT(*) FROM dbo.a_ASP_IN with(NOLOCK) WHERE Processed = 'N') > 0 
			BEGIN

				WHILE (Select COUNT(*) FROM a_ASP_IN with(NOLOCK) WHERE Processed = 'N') > 0
					BEGIN
				
						truncate table dbo.DragonAssr
						truncate table dbo.DragonAssr_STD

						INSERT INTO dbo.DragonAssr(RecordId,[FullStreetAddress],[City],[State],[Zip],[raw_id])
						SELECT TOP 200000 ASP_ID,LEFT([FullStreetAddress],255),LEFT([City],55),[State],[ZIP5],[RAW_ID]
						FROM a_ASP_IN 
						WHERE PROCESSED = 'N'

						EXEC('INSERT INTO [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
						 (''DragonAssr'',''DragonAssr'',''B'',''R'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
						 ')

					---- CHECKS TO SEE IF ASP TABLE IS FILLED THEN WAITS IN 5 MIN INTERVALS FOR COMPLETION

							IF (SELECT COUNT(*) FROM [dbo].DragonAssr with(NOLOCK)) = 0
								BEGIN
									RETURN;
								END
							ELSE
								BEGIN
									---- 1 min wait periods until ASP is complete
									DECLARE @CheckASP as int
				
										SET @CheckASP = 0

									WHILE @CheckASP = 0
										BEGIN
											WAITFOR DELAY '00:04'
							
										---- Checks for completion ** If not wait again
										SET @CheckASP = (Select COUNT(*) from dbo.DragonAssr_STD with(NOLOCK))
										END
								END

						EXEC dbo.usp_100c_sp_ASP_Cust_STD

						UPDATE a_ASP_IN SET Processed = 'Y'
						WHERE ASP_ID in(Select ASP_ID from a_ASP_IN_STD)

					END
		END



END



