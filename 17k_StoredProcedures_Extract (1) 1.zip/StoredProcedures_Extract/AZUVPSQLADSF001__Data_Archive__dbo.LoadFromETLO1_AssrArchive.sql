SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- EXEC [dbo].[LoadFromETLO1_AssrArchive_CL] 6037
CREATE PROCEDURE [dbo].[LoadFromETLO1_AssrArchive](@fips as varchar(5))
AS
BEGIN
	declare @fipsInt int = cast(@fips as int)
	delete from AssrArchive_CL where fips = @fipsInt
	insert into AssrArchive_CL SELECT [AssrID]
      ,[FIPS]
      ,[REF_ID]
      ,[UNFORMATTED_APN]
      ,[APN_SEQUENCE_NBR]
      ,[FORMATTED_APN]
      ,[TAX_AMOUNT]
      ,[TAX_YEAR]
      ,[CERTIFICATION_DATE]
      ,[Source_Type]
  FROM [DWS-ETL01].[Assr_Archive].[dbo].[AssrArchive_CL] with(nolock) where fips =@fipsInt

	delete from AssrArchive where fips = @fipsInt
	insert into AssrArchive SELECT [AssrID]
      ,[FIPS]
      ,[REF_ID]
      ,[UNFORMATTED_APN]
      ,[APN_SEQUENCE_NBR]
      ,[FORMATTED_APN]
      ,[TAX_AMOUNT]
      ,[TAX_YEAR]
      ,[CERTIFICATION_DATE]
      ,[Source_Type]
  FROM [DWS-ETL01].[Assr_Archive].[dbo].[AssrArchive] with(nolock) where fips =@fipsInt
END

