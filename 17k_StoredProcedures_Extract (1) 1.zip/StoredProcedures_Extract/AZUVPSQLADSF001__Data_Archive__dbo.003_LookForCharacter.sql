SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[003_LookForCharacter] @table varchar(100),@Character varchar(1),@PropIdTranID varchar(15), @RestartAtField varchar(50) = ''
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @colName VARCHAR(255)
	DECLARE @tblName VARCHAR(255)
	DECLARE @prec VARCHAR(255)
	DECLARE @sqlCmd VARCHAR(max)

	DECLARE db_cursor CURSOR FOR  

	SELECT c.name ColumnName,t.name as TableName
	FROM data.sys.columns c with(NOLOCK) INNER JOIN
		 data.sys.tables t with(NOLOCK) ON c.object_id = t.object_id INNER JOIN
		 data.sys.schemas s with(NOLOCK) ON t.schema_id = s.schema_id
	where t.name = @table and c.System_type_id not in(40,42,48,52,56,61,62,104,106,108,127)
	and c.name not like 'LegalDescription'
	and c.name >= @RestartAtField
	order by TableName,ColumnName

	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @colName,@tblName  

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		BEGIN

			Print @colName

				EXEC('INSERT INTO Data_Archive.[dbo].[CharacterCheck] 
				SELECT FIPS,' + @PropIdTranID + ','''+@table+''', '''+@colName+'''
				FROM Data.dbo.' + @tblName + ' with(NOLOCK)
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%' + @Character + '%''')
				
		END
		FETCH NEXT FROM db_cursor INTO @colName,@tblName
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

END

