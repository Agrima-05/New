SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE migration.usp_CaptureInventory
    @Role nvarchar(10) = N'Auto'   -- 'Auto' | 'Source' | 'Target'
AS
BEGIN
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   -- never block, never be blocked
SET LOCK_TIMEOUT 5000;

DECLARE @ToolVersion   nvarchar(20) = N'2.6.0',
        @SchemaVersion nvarchar(10) = N'2.6',
        @StartTime     datetime2(0) = SYSUTCDATETIME(),
        @ServerName    sysname      = CONVERT(sysname, SERVERPROPERTY('ServerName')),
        @AdminDb       sysname      = DB_NAME(),
        @CaptureRunId  int,
        /* v2.4.2b: @Msg removed - declared here and never assigned or read.
           Every RAISERROR in this procedure uses an inline literal. */
        @ModuleCount   int          = 0,
        /* v2.6: the engine's major version, used to skip features that do not
           exist on an older source rather than discovering their absence as a
           runtime error. Assigned below, not here - see the note there. */
        @MajorVersion  int          = NULL;

/* v2.6: derive the major version defensively.

   PARSENAME, not SERVERPROPERTY('ProductMajorVersion'): that property was
   itself only added in SQL 2014 SP2, so on 2014 RTM/SP1 - exactly where this
   guard matters most - it returns NULL and every guard built on it would
   silently evaluate false. ProductVersion has been there since SQL 2000, and
   '12.0.6449.1' parses to 12.

   TRY_CONVERT is deliberately NOT used: it needs database compatibility level
   110+, and this procedure runs in whatever admin database it was installed
   into - which on an older instance may well sit at compat 100, where
   TRY_CONVERT fails with error 195. That is the same trap already documented
   in the DatabaseHealth module below. A CATCH costs nothing and cannot be
   wrong. A NULL @MajorVersion simply means "unknown", and every guard below
   is written so that unknown behaves like "modern": attempt the read and let
   the module's own error handling deal with it, exactly as before 2.6. */
BEGIN TRY
    SET @MajorVersion = CONVERT(int, PARSENAME(CONVERT(nvarchar(30), SERVERPROPERTY('ProductVersion')), 4));
END TRY
BEGIN CATCH
    SET @MajorVersion = NULL;
END CATCH;

/* ---- preconditions ---------------------------------------------------- */
/* v2.4: the whole design is "one TRY/CATCH per module, record the error and
   carry on". That collapses inside a caller's transaction: the first module
   error dooms it (XACT_STATE() = -1) and the CATCH's own INSERT into
   migration.CaptureError then fails with error 3930, losing the ENTIRE
   capture - the exact opposite of the intent. Refuse up front. */
IF @@TRANCOUNT > 0
BEGIN
    RAISERROR(N'migration.usp_CaptureInventory cannot run inside an open transaction (@@TRANCOUNT = %d). Each module records its own errors and must be able to commit them independently; a caller transaction turns the first module failure into a total capture loss. COMMIT or ROLLBACK first, then EXEC the procedure on its own.',
              16, 1, @@TRANCOUNT);
    RETURN 1;
END

DECLARE @InstalledSchemaVersion nvarchar(10) =
    ISNULL((SELECT ConfigValue FROM migration.ConfigValue WHERE ConfigName = N'SchemaVersion'), N'(missing)');
IF @InstalledSchemaVersion <> @SchemaVersion
BEGIN
    -- a MISSING SchemaVersion row is a mismatch too, never a silent pass
    RAISERROR(N'Installed migration schema version %s does not match this procedure (%s). Re-run 01_Install-MigrationSchema.sql and 02/03 from ONE tool version.', 16, 1, @InstalledSchemaVersion, @SchemaVersion);
    RETURN 1;
END

/* v2.6: minimum supported engine version.

   Until now there was NO version precondition at all. The procedure recorded
   ProductVersion and then ran regardless, so an unsupported engine was
   discovered module by module as "Invalid object name" and "Invalid column
   name" - eighteen seconds of work ending in a capture that could not be used,
   with nothing anywhere naming the actual cause.

   The floor is SQL Server 2014 (major version 12). It is not arbitrary: below
   it the REQUIRED Databases module reads sys.databases.containment_desc and
   the ResourceGovernor module reads cap_cpu_percent, both SQL 2012 additions,
   and 2008 R2 and earlier have been neither audited nor tested here. Refusing
   is the honest answer - far better than a capture that looks complete and is
   not.

   @MajorVersion IS NULL means the version string could not be parsed. That is
   not evidence of an old engine, so it does not refuse; the modules' own error
   handling covers it. */
IF @MajorVersion IS NOT NULL AND @MajorVersion < 12
BEGIN
    RAISERROR(N'This instance reports SQL Server major version %d. SqlMigrationValidator V2 supports SQL Server 2014 (12.0) and later as the capture source; earlier engines are missing catalog columns that REQUIRED modules depend on, so a capture taken here would be incomplete in ways the comparison could not report honestly. Nothing was written.',
              16, 1, @MajorVersion);
    RETURN 1;
END

/* v2.6: the ADMIN database's compatibility level, which is a different thing
   from the engine version and bites hardest on exactly the older instances
   this release adds support for.

   TRY_CONVERT requires compatibility level 110+. This procedure and 03 both
   use it to read integer settings out of migration.ConfigValue, and below 110
   it does not return NULL - it raises error 195, '"TRY_CONVERT" is not a
   recognized built-in function name'. A DBAdmin created by 01 inherits model
   (120 on a 2014 instance) and is fine; a DBAdmin that was RESTORED from an
   older server can easily still be sitting at 100, and then the failure lands
   mid-capture as a module error, or - in 03, where the reads are not inside a
   module TRY - kills the comparison outright with a message that names a
   T-SQL function rather than the fix.

   Checked once, up front, with the remedy stated. The tool deliberately does
   not raise the level itself: that is a change to the operator's database and
   theirs alone to make. */
DECLARE @AdminCompat int = CONVERT(int, DATABASEPROPERTYEX(DB_NAME(), N'Compatibility'));
IF @AdminCompat IS NOT NULL AND @AdminCompat < 110
BEGIN
    RAISERROR(N'The administration database [%s] is at compatibility level %d. This tool needs 110 or higher there (it is unrelated to your USER databases'' levels, which are captured and compared as they are, and unrelated to the engine version). Below 110 TRY_CONVERT raises error 195 instead of returning NULL, which breaks reading the tool''s own settings. Fix with: ALTER DATABASE [%s] SET COMPATIBILITY_LEVEL = 110;  (or higher). Nothing was written.',
              16, 1, @AdminDb, @AdminCompat, @AdminDb);
    RETURN 1;
END

/* ---- role resolution --------------------------------------------------- */
DECLARE @HasForeignSourceCapture bit =
    CASE WHEN EXISTS (SELECT 1 FROM migration.CaptureRun
                      WHERE CaptureRole = N'Source' AND ServerName <> @ServerName)
         THEN 1 ELSE 0 END;

IF @Role = N'Auto'
    SET @Role = CASE WHEN @HasForeignSourceCapture = 1 THEN N'Target' ELSE N'Source' END;

IF @Role NOT IN (N'Source', N'Target')
BEGIN
    RAISERROR(N'@Role must be Auto, Source or Target.', 16, 1);
    RETURN 1;
END
/* v2.3: corroborate the name-based role detection with the machine name.
   ServerName alone cannot tell a restored capture from a renamed server:
   (a) a target deliberately given the source's old server name would silently
       capture as Source and poison the compare;
   (b) a renamed source would see its own old captures as "foreign" and
       silently flip to Target.
   These fire FIRST - they are the sharper diagnosis when both apply. */
DECLARE @MachineName sysname = CONVERT(sysname, SERVERPROPERTY('MachineName'));
IF @Role = N'Source' AND EXISTS (SELECT 1 FROM migration.CaptureRun
                                 WHERE CaptureRole = N'Source' AND ServerName = @ServerName
                                   AND MachineName IS NOT NULL
                                   AND MachineName <> ISNULL(@MachineName, N''))
BEGIN
    RAISERROR(N'A Source capture with this server name exists but was taken on a DIFFERENT machine - this DBAdmin most likely arrived here via restore, and this server reuses the source''s server name. If this server IS the migration target, run with @Role = Target explicitly. If these are stale rows from a cloned DBAdmin, remove them first - see RUNBOOK.md "Removing stale or bad captures".', 16, 1);
    RETURN 1;
END
IF @Role = N'Target' AND EXISTS (SELECT 1 FROM migration.CaptureRun
                                 WHERE CaptureRole = N'Source' AND ServerName <> @ServerName
                                   AND MachineName IS NOT NULL
                                   AND MachineName = ISNULL(@MachineName, N''))
BEGIN
    RAISERROR(N'The Source capture this comparison would use was taken on THIS machine under a different server name - that is a renamed server, not a restored source. Remove the stale captures first - see RUNBOOK.md "Removing stale or bad captures".', 16, 1);
    RETURN 1;
END

DECLARE @ForeignSourceInfo nvarchar(400) =
    (SELECT TOP (1) ServerName + N' (captured ' + CONVERT(nvarchar(30), CaptureDateUtc, 120) + N' UTC)'
     FROM migration.CaptureRun
     WHERE CaptureRole = N'Source' AND ServerName <> @ServerName
     ORDER BY CaptureRunId DESC);
IF @Role = N'Source' AND @HasForeignSourceCapture = 1
BEGIN
    -- This DBAdmin already holds a Source capture from a DIFFERENT server: it
    -- was restored (or cloned) here. Capturing as 'Source' would poison the compare.
    RAISERROR(N'This database contains a Source capture from another server: %s. If this server IS the target of that migration, run with @Role = Target (or Auto). If this DBAdmin was merely CLONED from an old backup and this server is a NEW migration source, first remove the stale captures - see RUNBOOK.md "Removing stale or bad captures".', 16, 1, @ForeignSourceInfo);
    RETURN 1;
END
IF @Role = N'Target' AND @HasForeignSourceCapture = 0
    PRINT N'WARNING: capturing as Target but no Source capture from another server exists in this database. The comparison will fail until the restored source capture is present.';
IF @Role = N'Target' AND @HasForeignSourceCapture = 1
    PRINT N'Capturing as Target; the comparison source will be ' + ISNULL(@ForeignSourceInfo, N'?')
        + N'. If that is NOT the expected source server/date, see RUNBOOK.md "Removing stale or bad captures".';

PRINT N'Capture starting on [' + @ServerName + N'] as ' + @Role + N' into [' + @AdminDb + N'].migration (read-only collection).';

INSERT migration.CaptureRun (CaptureRole, ServerName, MachineName, InstanceName,
    ProductVersion, ProductLevel, Edition, CaptureDateUtc, CaptureDateLocal,
    ToolVersion, SchemaVersion, RunBy)
VALUES (@Role, @ServerName,
    CONVERT(sysname,      SERVERPROPERTY('MachineName')),
    CONVERT(sysname,      SERVERPROPERTY('InstanceName')),
    CONVERT(nvarchar(30), SERVERPROPERTY('ProductVersion')),
    CONVERT(nvarchar(30), SERVERPROPERTY('ProductLevel')),
    CONVERT(nvarchar(60), SERVERPROPERTY('Edition')),
    @StartTime, CONVERT(datetime2(0), GETDATE()),
    @ToolVersion, @SchemaVersion, SUSER_SNAME());
SET @CaptureRunId = SCOPE_IDENTITY();

/* ==========================================================================
   Module: Instance (required)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, v.PropertyName, v.PropertyValue
    FROM (VALUES
        (N'ServerName',              CONVERT(nvarchar(4000), SERVERPROPERTY('ServerName'))),
        (N'MachineName',             CONVERT(nvarchar(4000), SERVERPROPERTY('MachineName'))),
        (N'InstanceName',            CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceName'))),
        (N'ProductVersion',          CONVERT(nvarchar(4000), SERVERPROPERTY('ProductVersion'))),
        (N'ProductLevel',            CONVERT(nvarchar(4000), SERVERPROPERTY('ProductLevel'))),
        (N'Edition',                 CONVERT(nvarchar(4000), SERVERPROPERTY('Edition'))),
        (N'EngineEdition',           CONVERT(nvarchar(4000), SERVERPROPERTY('EngineEdition'))),
        (N'ServerCollation',         CONVERT(nvarchar(4000), SERVERPROPERTY('Collation'))),
        (N'AuthenticationMode',      CASE CONVERT(int, SERVERPROPERTY('IsIntegratedSecurityOnly'))
                                          WHEN 1 THEN N'Windows' ELSE N'Mixed' END),
        (N'IsClustered',             CONVERT(nvarchar(4000), SERVERPROPERTY('IsClustered'))),
        (N'IsHadrEnabled',           CONVERT(nvarchar(4000), ISNULL(SERVERPROPERTY('IsHadrEnabled'), 0))),
        (N'IsFullTextInstalled',     CONVERT(nvarchar(4000), ISNULL(SERVERPROPERTY('IsFullTextInstalled'), 0))),
        (N'FilestreamEffectiveLevel',CONVERT(nvarchar(4000), ISNULL(SERVERPROPERTY('FilestreamEffectiveLevel'), 0))),
        (N'IsPolyBaseInstalled',     CONVERT(nvarchar(4000), ISNULL(SERVERPROPERTY('IsPolyBaseInstalled'), 0))),
        -- host OS parsed from @@VERSION (works on 2016 RTM and on Linux)
        (N'OperatingSystem',
         LEFT(LTRIM(REPLACE(REPLACE(REPLACE(
             CASE WHEN CHARINDEX(N' on Windows', @@VERSION) > 0 THEN SUBSTRING(@@VERSION, CHARINDEX(N' on Windows', @@VERSION) + 4, 200)
                  WHEN CHARINDEX(N' on Linux',   @@VERSION) > 0 THEN SUBSTRING(@@VERSION, CHARINDEX(N' on Linux',   @@VERSION) + 4, 200)
                  ELSE NULL END,
             NCHAR(13), N' '), NCHAR(10), N' '), NCHAR(9), N' ')), 200))
    ) AS v (PropertyName, PropertyValue);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Instance', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Hardware (optional)

   v2.4: these two DMV reads used to sit inside the REQUIRED Instance module.
   sys.dm_os_sys_info and sys.dm_server_services both need VIEW SERVER STATE,
   so a lower-privileged capture failed the whole of Instance, set
   IsComplete = 0, and downgraded the entire validation to INCOMPLETE - even
   though every SERVERPROPERTY row above had been collected successfully.
   Volumes, TraceFlags, SuspectPages and BackupSummary were each split out for
   exactly this reason; hardware was the one that was missed.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    -- hardware: "same or better" checks on the target need these
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, v.PropertyName, v.PropertyValue
    FROM sys.dm_os_sys_info AS i
    CROSS APPLY (VALUES
        (N'CpuLogicalCores',  CONVERT(nvarchar(20), i.cpu_count)),
        (N'HyperthreadRatio', CONVERT(nvarchar(20), i.hyperthread_ratio)),
        (N'MemoryPhysicalMB', CONVERT(nvarchar(20), i.physical_memory_kb / 1024)),
        (N'NumaNodes',        CONVERT(nvarchar(20),
            (SELECT COUNT(*) FROM sys.dm_os_nodes WHERE node_state_desc = N'ONLINE')))
    ) AS v (PropertyName, PropertyValue);

    INSERT migration.ServerService (CaptureRunId, ServiceName, StartupTypeDesc, StatusDesc, ServiceAccount)
    SELECT @CaptureRunId, servicename, startup_type_desc, status_desc, service_account
    FROM sys.dm_server_services;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Hardware', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: CpuInfo - socket count (dm_os_sys_info column is 2016 SP2+, also
   backported to 2014 SP3; dynamic so an engine without it records a note
   instead of dying. v2.6: that note is IsNotApplicable, not a failure.)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @Sockets nvarchar(20);
    EXEC sp_executesql
        N'SELECT @v = CONVERT(nvarchar(20), socket_count) FROM sys.dm_os_sys_info;',
        N'@v nvarchar(20) OUTPUT', @v = @Sockets OUTPUT;
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    VALUES (@CaptureRunId, N'CpuSockets', @Sockets);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    /* v2.6: error 207 ("Invalid column name") from THIS module means the
       column was added to the DMV after this engine shipped - a fact about the
       version, not a collection failure. Marked IsNotApplicable so it gates the
       compare section without pinning an otherwise-clean source to READY WITH
       WARNINGS. This is the SQL 2016 RTM/SP1 case: both columns arrived in SP2,
       and were also backported to 2014 SP3 - so a 2014 SP3 box HAS them while a
       2016 RTM box does not. Any other error number is a real failure and is
       recorded as one. */
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage, IsNotApplicable)
    VALUES (@CaptureRunId, N'CpuInfo', ERROR_NUMBER(),
            CASE WHEN ERROR_NUMBER() = 207
                 THEN N'Not applicable on this engine: socket_count was added to sys.dm_os_sys_info in SQL Server 2016 SP2 (and backported to 2014 SP3); this instance predates it. Nothing failed - the column does not exist here. Original message: ' + ERROR_MESSAGE()
                 ELSE ERROR_MESSAGE() END,
            CASE WHEN ERROR_NUMBER() = 207 THEN 1 ELSE 0 END);
END CATCH;

/* ==========================================================================
   Module: Network - listener TCP port configuration (registry-backed)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId,
           CASE value_name WHEN N'TcpPort' THEN N'TcpPort' ELSE N'TcpDynamicPorts' END,
           CONVERT(nvarchar(4000), value_data)
    FROM sys.dm_server_registry
    WHERE registry_key LIKE N'%SuperSocketNetLib\Tcp\IPAll'
      AND value_name IN (N'TcpPort', N'TcpDynamicPorts');
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Network', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: AlwaysOn - availability groups and listeners (empty when unused)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, v.PropertyName, v.PropertyValue
    FROM (VALUES
        (N'AvailabilityGroups',
         -- LEFT: a huge list must truncate, never abort the whole module
         LEFT(ISNULL(STUFF((SELECT N',' + name FROM sys.availability_groups
                       ORDER BY name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'(none)'), 4000)),
        (N'AgListeners',
         LEFT(ISNULL(STUFF((SELECT N',' + dns_name FROM sys.availability_group_listeners
                       ORDER BY dns_name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'(none)'), 4000))
    ) AS v (PropertyName, PropertyValue);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'AlwaysOn', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Ifi - instant file initialization (SQL 2016 SP2+ column, also
   backported to 2014 SP3; dynamic so an engine without it records a note
   instead of killing the batch. v2.6: that note is IsNotApplicable.)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @Ifi nvarchar(10);
    EXEC sp_executesql
        N'SELECT TOP (1) @v = CASE instant_file_initialization_enabled WHEN N''Y'' THEN N''1'' ELSE N''0'' END
          FROM sys.dm_server_services WHERE servicename LIKE N''SQL Server (%'';',
        N'@v nvarchar(10) OUTPUT', @v = @Ifi OUTPUT;
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    VALUES (@CaptureRunId, N'InstantFileInitializationEnabled', @Ifi);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    /* v2.6: error 207 ("Invalid column name") from THIS module means the
       column was added to the DMV after this engine shipped - a fact about the
       version, not a collection failure. Marked IsNotApplicable so it gates the
       compare section without pinning an otherwise-clean source to READY WITH
       WARNINGS. This is the SQL 2016 RTM/SP1 case: both columns arrived in SP2,
       and were also backported to 2014 SP3 - so a 2014 SP3 box HAS them while a
       2016 RTM box does not. Any other error number is a real failure and is
       recorded as one. */
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage, IsNotApplicable)
    VALUES (@CaptureRunId, N'Ifi', ERROR_NUMBER(),
            CASE WHEN ERROR_NUMBER() = 207
                 THEN N'Not applicable on this engine: instant_file_initialization_enabled was added to sys.dm_server_services in SQL Server 2016 SP2 (and backported to 2014 SP3); this instance predates it. Nothing failed - the column does not exist here. Original message: ' + ERROR_MESSAGE()
                 ELSE ERROR_MESSAGE() END,
            CASE WHEN ERROR_NUMBER() = 207 THEN 1 ELSE 0 END);
END CATCH;

/* ==========================================================================
   Module: AgentMail - SQL Agent alerting mail settings (registry-backed)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    /* v2.4: the old filter was registry_key LIKE '%SQLServerAgent%', which also
       matches SUBKEY paths below the Agent key. dm_server_registry could then
       return more than one row per value_name, the CASE collapsed them all onto
       two fixed PropertyName values, and PK_InstanceProperty rejected the batch
       - failing the module. Anchor on the key itself and aggregate defensively. */
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, p.PropertyName, MAX(p.PropertyValue)
    FROM (SELECT CASE value_name WHEN N'UseDatabaseMail' THEN N'AgentUseDatabaseMail'
                                 ELSE N'AgentDatabaseMailProfile' END AS PropertyName,
                 CONVERT(nvarchar(4000), value_data)                  AS PropertyValue
          FROM sys.dm_server_registry
          WHERE registry_key LIKE N'%\SQLServerAgent'
            AND value_name IN (N'UseDatabaseMail', N'DatabaseMailProfile')) AS p
    GROUP BY p.PropertyName;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'AgentMail', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Configuration (required) - sp_configure with configured vs running
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.ConfigurationSetting (CaptureRunId, SettingName, ConfiguredValue, RunningValue)
    SELECT @CaptureRunId, name, CONVERT(bigint, value), CONVERT(bigint, value_in_use)
    FROM sys.configurations;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Configuration', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: TraceFlags (globally enabled flags; needs sysadmin-ish rights)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @TraceStatus TABLE (TraceFlag int, Status int, Global int, Session int);
    INSERT @TraceStatus EXEC (N'DBCC TRACESTATUS(-1) WITH NO_INFOMSGS');
    INSERT migration.TraceFlag (CaptureRunId, TraceFlag, IsGlobal, IsEnabled)
    SELECT DISTINCT @CaptureRunId, TraceFlag,
           CASE WHEN Global = 1 THEN 1 ELSE 0 END,
           CASE WHEN Status = 1 THEN 1 ELSE 0 END
    FROM @TraceStatus;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'TraceFlags', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Volumes (needs VIEW SERVER STATE)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    /* v2.4: dm_os_volume_stats returns a row with NULL columns for a file on
       an inaccessible/offline volume, and the CROSS APPLY spans master_files
       for EVERY database including offline ones. MountPoint is NOT NULL and
       part of the primary key, so one unavailable drive used to fail the whole
       module - losing free-space data for every volume, and with it the
       target capacity check. Restrict to online databases and drop NULL rows. */
    INSERT migration.Volume (CaptureRunId, MountPoint, TotalMB, AvailableMB)
    SELECT @CaptureRunId, vs.volume_mount_point,
           MAX(vs.total_bytes) / 1048576, MAX(vs.available_bytes) / 1048576
    FROM sys.master_files AS mf
    JOIN sys.databases AS d
      ON d.database_id = mf.database_id AND d.state_desc = N'ONLINE'
    CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
    WHERE vs.volume_mount_point IS NOT NULL
      AND vs.total_bytes IS NOT NULL
    GROUP BY vs.volume_mount_point;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Volumes', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Databases (required) - snapshots are EXCLUDED (they can never be
   restored to the target; inventorying them fabricates cutover blockers)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.DatabaseInfo (CaptureRunId, DatabaseName, IsSystem, OwnerName,
        CollationName, CompatibilityLevel, RecoveryModelDesc, StateDesc, UserAccessDesc,
        IsReadOnly, IsAutoCloseOn, IsAutoShrinkOn, PageVerifyOptionDesc,
        IsAutoCreateStatsOn, IsAutoUpdateStatsOn, IsTrustworthyOn, IsBrokerEnabled,
        IsCdcEnabled, IsPublished, IsSubscribed, IsEncrypted, ContainmentDesc,
        DataFileCount, LogFileCount, TotalDataMB, TotalLogMB)
    SELECT @CaptureRunId, d.name,
           CASE WHEN d.database_id <= 4 THEN 1 ELSE 0 END,
           SUSER_SNAME(d.owner_sid), d.collation_name, d.compatibility_level,
           d.recovery_model_desc, d.state_desc, d.user_access_desc,
           d.is_read_only, d.is_auto_close_on, d.is_auto_shrink_on, d.page_verify_option_desc,
           d.is_auto_create_stats_on, d.is_auto_update_stats_on, d.is_trustworthy_on, d.is_broker_enabled,
           d.is_cdc_enabled, d.is_published, d.is_subscribed, d.is_encrypted, d.containment_desc,
           f.DataFileCount, f.LogFileCount, f.TotalDataMB, f.TotalLogMB
    FROM sys.databases AS d
    OUTER APPLY (SELECT
                     SUM(CASE WHEN mf.type = 0 THEN 1 ELSE 0 END)                          AS DataFileCount,
                     SUM(CASE WHEN mf.type = 1 THEN 1 ELSE 0 END)                          AS LogFileCount,
                     SUM(CASE WHEN mf.type = 0 THEN CONVERT(bigint, mf.size) * 8 / 1024 ELSE 0 END) AS TotalDataMB,
                     SUM(CASE WHEN mf.type = 1 THEN CONVERT(bigint, mf.size) * 8 / 1024 ELSE 0 END) AS TotalLogMB
                 FROM sys.master_files AS mf WHERE mf.database_id = d.database_id) AS f
    WHERE d.source_database_id IS NULL;   -- no database snapshots

    INSERT migration.DatabaseFile (CaptureRunId, DatabaseName, LogicalName, TypeDesc,
        SizeMB, MaxSizeMB, GrowthDesc, PhysicalName)
    SELECT @CaptureRunId, d.name, mf.name, mf.type_desc,
           CONVERT(bigint, mf.size) * 8 / 1024,
           CASE WHEN mf.max_size IN (-1, 268435456) THEN NULL
                ELSE CONVERT(bigint, mf.max_size) * 8 / 1024 END,
           CASE WHEN mf.growth = 0 THEN N'none'
                WHEN mf.is_percent_growth = 1 THEN CONVERT(nvarchar(20), mf.growth) + N'%'
                ELSE CONVERT(nvarchar(20), CONVERT(bigint, mf.growth) * 8 / 1024) + N' MB' END,
           mf.physical_name
    FROM sys.master_files AS mf
    JOIN sys.databases AS d ON d.database_id = mf.database_id
    WHERE d.source_database_id IS NULL;

    /* ---- drive roles: which volumes hold data, log and tempdb files -------
       v2.4, three fixes in one block:

       (1) The old code took UPPER(LEFT(physical_name, 3)) as the "drive". On
           any instance using MOUNT POINTS (C:\SQLData\Vol1\...) every distinct
           volume collapsed into a single "C:\" bucket, so genuinely different
           storage layouts compared EQUAL and the check passed. Resolve the
           real mount point via dm_os_volume_stats, falling back to the
           three-character root only when the DMV has nothing to say.
       (2) SELECT DISTINCT ... FOR XML PATH with no ORDER BY produces an
           order-UNSTABLE string. Every other aggregation in this file orders
           explicitly, because the compare does string equality on the result;
           a hash-aggregate plan would manufacture a false difference.
       (3) The result was not LEFT()-guarded, so an instance with many mount
           roots could overflow nvarchar(4000) and fail the REQUIRED Databases
           module. Truncate instead.

       The DMV needs VIEW SERVER STATE, so this sits in its own TRY/CATCH: a
       lower-privileged capture records a DriveRoles item error and the rest of
       the (required) Databases module still completes. */
    BEGIN TRY
        ;WITH fv AS (
            SELECT mf.database_id, mf.type,
                   UPPER(ISNULL(vs.volume_mount_point, LEFT(mf.physical_name, 3))) AS Mount
            FROM sys.master_files AS mf
            OUTER APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs)
        INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
        SELECT @CaptureRunId, v.PropertyName, LEFT(v.PropertyValue, 4000)
        FROM (VALUES
            (N'DataDrives',
             ISNULL(STUFF((SELECT DISTINCT N',' + fv.Mount FROM fv
                           WHERE fv.type = 0 AND fv.database_id <> 2
                           ORDER BY N',' + fv.Mount
                           FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'?')),
            (N'LogDrives',
             ISNULL(STUFF((SELECT DISTINCT N',' + fv.Mount FROM fv
                           WHERE fv.type = 1 AND fv.database_id <> 2
                           ORDER BY N',' + fv.Mount
                           FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'?')),
            (N'TempdbDrives',
             ISNULL(STUFF((SELECT DISTINCT N',' + fv.Mount FROM fv
                           WHERE fv.database_id = 2
                           ORDER BY N',' + fv.Mount
                           FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'?'))
        ) AS v (PropertyName, PropertyValue);
    END TRY
    BEGIN CATCH
        IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
        INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber, ErrorMessage)
        VALUES (@CaptureRunId, N'Databases', N'DriveRoles', ERROR_NUMBER(), ERROR_MESSAGE());
    END CATCH;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Databases', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: BackupSummary - last backup dates per database. Separate module:
   msdb reads are permission-sensitive and must not fail 'Databases'.
   Only backups taken ON THIS SERVER count - restore-imported history from
   the source would otherwise pose as local backup posture on the target.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    UPDATE di
    SET LastFullBackup = b.LastFull, LastDiffBackup = b.LastDiff, LastLogBackup = b.LastLog
    FROM migration.DatabaseInfo AS di
    CROSS APPLY (SELECT
                     MAX(CASE WHEN bs.type = 'D' THEN bs.backup_finish_date END) AS LastFull,
                     MAX(CASE WHEN bs.type = 'I' THEN bs.backup_finish_date END) AS LastDiff,
                     MAX(CASE WHEN bs.type = 'L' THEN bs.backup_finish_date END) AS LastLog
                 FROM msdb.dbo.backupset AS bs
                 -- COLLATE: msdb and the admin database may use different collations
                 WHERE bs.database_name COLLATE DATABASE_DEFAULT = di.DatabaseName
                   -- backupset records @@SERVERNAME at backup time; accept the
                   -- SERVERPROPERTY name too in case the two ever diverged
                   AND bs.server_name COLLATE DATABASE_DEFAULT
                       IN (@ServerName, CONVERT(sysname, @@SERVERNAME))
                   AND bs.is_copy_only = 0
                   AND bs.is_snapshot = 0) AS b
    WHERE di.CaptureRunId = @CaptureRunId;

    -- where the last 30 days of local backups were written (drive or UNC host)
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, N'BackupDrives',
           -- LEFT: a huge list must truncate, never abort the whole module
           /* v2.4: ORDER BY added - DISTINCT does not contractually imply a
              sort order, and the compare does string equality on this value. */
           LEFT(ISNULL(STUFF((SELECT DISTINCT N',' +
                             CASE WHEN mf.physical_device_name LIKE N'\\%'
                                  THEN LEFT(mf.physical_device_name,
                                            ISNULL(NULLIF(CHARINDEX(N'\', mf.physical_device_name, 3), 0) - 1, 60))
                                  ELSE UPPER(LEFT(mf.physical_device_name, 3)) END
                         FROM msdb.dbo.backupset AS bs
                         JOIN msdb.dbo.backupmediafamily AS mf ON mf.media_set_id = bs.media_set_id
                         WHERE bs.server_name COLLATE DATABASE_DEFAULT
                               IN (@ServerName, CONVERT(sysname, @@SERVERNAME))
                           AND bs.backup_finish_date >= DATEADD(DAY, -30, GETDATE())
                           AND mf.physical_device_name IS NOT NULL
                         ORDER BY N',' +
                             CASE WHEN mf.physical_device_name LIKE N'\\%'
                                  THEN LEFT(mf.physical_device_name,
                                            ISNULL(NULLIF(CHARINDEX(N'\', mf.physical_device_name, 3), 0) - 1, 60))
                                  ELSE UPPER(LEFT(mf.physical_device_name, 3)) END
                         FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'(no recent backups)'), 4000);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'BackupSummary', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: SuspectPages - separate module: reading msdb.dbo.suspect_pages
   needs elevated msdb rights and must not fail 'Databases'.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.SuspectPage (CaptureRunId, DatabaseName, PageCount, LastUpdateDate)
    SELECT @CaptureRunId, DB_NAME(database_id), COUNT(*), CONVERT(datetime2(0), MAX(last_update_date))
    FROM msdb.dbo.suspect_pages
    WHERE event_type IN (1, 2, 3)   -- active suspect/bad pages only, not restored/repaired
      AND DB_NAME(database_id) IS NOT NULL
    GROUP BY DB_NAME(database_id);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'SuspectPages', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: RestoreHistory - restores INTO this instance (provenance on the
   target; the backupset metadata carries the ORIGINAL server name).
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @RestoreHistoryDays int =
        ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue
                                 WHERE ConfigName = N'RestoreHistoryDays')), 90);
    INSERT migration.RestoreEvent (CaptureRunId, RestoreHistoryId, DatabaseName,
        RestoreDate, RestoreTypeDesc, RestoredBy, SourceServerName, SourceDatabaseName,
        BackupStartDate, BackupFinishDate)
    SELECT @CaptureRunId, rh.restore_history_id, rh.destination_database_name,
           CONVERT(datetime2(0), rh.restore_date),
           CASE rh.restore_type WHEN 'D' THEN N'Database' WHEN 'I' THEN N'Differential'
                                WHEN 'L' THEN N'Log'      WHEN 'F' THEN N'File'
                                WHEN 'G' THEN N'Filegroup' WHEN 'V' THEN N'Verify'
                                ELSE CONVERT(nvarchar(30), rh.restore_type) END,
           rh.user_name, bs.server_name, bs.database_name,
           CONVERT(datetime2(0), bs.backup_start_date), CONVERT(datetime2(0), bs.backup_finish_date)
    FROM msdb.dbo.restorehistory AS rh
    LEFT JOIN msdb.dbo.backupset AS bs ON bs.backup_set_id = rh.backup_set_id
    WHERE rh.restore_date >= DATEADD(DAY, -@RestoreHistoryDays, GETDATE());
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'RestoreHistory', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Logins (required). All windows/SQL logins and groups; noise such
   as NT SERVICE\* is excluded at COMPARE time via migration.RuleException.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.LoginInfo (CaptureRunId, LoginName, Sid, TypeDesc, IsDisabled,
        DefaultDatabase, DefaultLanguage, IsPolicyChecked, IsExpirationChecked)
    SELECT @CaptureRunId, p.name, p.sid, p.type_desc, p.is_disabled,
           p.default_database_name, p.default_language_name,
           sl.is_policy_checked, sl.is_expiration_checked
    FROM sys.server_principals AS p
    LEFT JOIN sys.sql_logins AS sl ON sl.principal_id = p.principal_id
    /* v2.5: types 'C' (certificate-mapped) and 'K' (asymmetric-key-mapped)
       added. They were excluded, so a signed-module login such as
       SigningLogin_AuditWrite - the standard vehicle for module signing and
       cross-database elevation, and one that does NOT travel with a restore -
       could not produce an Existence finding because it was never inventoried.
       Its server-level GRANTS were still captured (ServerPermission joins all
       principals), so the report could list a permission for a login it never
       said was missing. The ##-prefixed internal ones stay excluded. */
    WHERE p.type IN ('S', 'U', 'G', 'C', 'K')
      AND p.name NOT LIKE N'##%';
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Logins', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: ServerSecurity (required) - roles, memberships, permissions
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.ServerRoleInfo (CaptureRunId, RoleName, IsFixedRole)
    SELECT @CaptureRunId, name, is_fixed_role
    FROM sys.server_principals
    WHERE type = 'R';

    INSERT migration.ServerRoleMember (CaptureRunId, RoleName, MemberName)
    SELECT DISTINCT @CaptureRunId, r.name, m.name
    FROM sys.server_role_members AS rm
    JOIN sys.server_principals AS r ON r.principal_id = rm.role_principal_id
    JOIN sys.server_principals AS m ON m.principal_id = rm.member_principal_id;

    INSERT migration.ServerPermission (CaptureRunId, GranteeName, ClassDesc,
        PermissionName, StateDesc, MajorObjectName)
    SELECT DISTINCT @CaptureRunId, g.name, pe.class_desc, pe.permission_name, pe.state_desc,
           ISNULL(CASE pe.class
                      WHEN 105 THEN (SELECT e.name FROM sys.endpoints AS e WHERE e.endpoint_id = pe.major_id)
                      WHEN 101 THEN (SELECT t.name FROM sys.server_principals AS t WHERE t.principal_id = pe.major_id)
                  END, N'')
    FROM sys.server_permissions AS pe
    JOIN sys.server_principals AS g ON g.principal_id = pe.grantee_principal_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'ServerSecurity', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Agent (required) - jobs, steps, schedules, operators, alerts,
   credentials and proxies. Step commands are stored as SHA-256 hashes of
   the CRLF-normalized text plus a masked excerpt - never the raw command.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.AgentJob (CaptureRunId, JobName, IsEnabled, OwnerName, CategoryName,
        NotifyLevelEmail, NotifyOperatorName, StepCount, ScheduleCount)
    SELECT @CaptureRunId, j.name, j.enabled, SUSER_SNAME(j.owner_sid), c.name,
           j.notify_level_email, o.name,
           (SELECT COUNT(*) FROM msdb.dbo.sysjobsteps     AS s  WHERE s.job_id  = j.job_id),
           (SELECT COUNT(*) FROM msdb.dbo.sysjobschedules AS js WHERE js.job_id = j.job_id)
    FROM msdb.dbo.sysjobs AS j
    LEFT JOIN msdb.dbo.syscategories AS c ON c.category_id = j.category_id
    LEFT JOIN msdb.dbo.sysoperators  AS o ON o.id = j.notify_email_operator_id;

    INSERT migration.AgentJobStep (CaptureRunId, JobName, StepId, StepName, SubsystemDesc,
        DatabaseName, ProxyName, OnSuccessAction, OnFailAction, RetryAttempts,
        CommandHash, CommandExcerpt)
    SELECT @CaptureRunId, j.name, s.step_id, s.step_name, s.subsystem,
           s.database_name, px.name, s.on_success_action, s.on_fail_action, s.retry_attempts,
           CASE WHEN s.command IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), s.command), NCHAR(13) + NCHAR(10), NCHAR(10))) END,
           /* v2.4: widened. "No secrets, ever" is a stated safety contract, and
              the old keyword list let several very common credential-bearing
              forms through into a 256-character excerpt: ADO.NET/ODBC style
              "User Id=" / "Uid=", PowerShell -Credential and
              ConvertTo-SecureString, API keys and bearer tokens, and sqlcmd -Z
              (change password). Masking is still best-effort pattern matching -
              the command TEXT is never stored, only its SHA-256 hash, so an
              excerpt is the entire exposure surface and it errs to masking. */
           CASE WHEN s.command IS NULL THEN NULL
                WHEN UPPER(s.command) LIKE N'%PASSWORD%' OR UPPER(s.command) LIKE N'%/DECRYPT%'
                  OR UPPER(s.command) LIKE N'%PWD%'      OR UPPER(s.command) LIKE N'%SECRET%'
                  OR UPPER(s.command) LIKE N'%USER ID%'  OR UPPER(s.command) LIKE N'%USERID=%'
                  OR UPPER(s.command) LIKE N'%UID=%'
                  OR UPPER(s.command) LIKE N'%CREDENTIAL%'
                  OR UPPER(s.command) LIKE N'%SECURESTRING%'
                  OR UPPER(s.command) LIKE N'%APIKEY%'   OR UPPER(s.command) LIKE N'%API[_]KEY%'
                  OR UPPER(s.command) LIKE N'%ACCESS[_]KEY%'
                  OR UPPER(s.command) LIKE N'%BEARER %'  OR UPPER(s.command) LIKE N'%TOKEN%'
                  OR UPPER(s.command) LIKE N'%SAS=%'     OR UPPER(s.command) LIKE N'%SIGNATURE=%'
                  OR UPPER(s.command) LIKE N'%CONNECTIONSTRING%'
                  -- sqlcmd/bcp style: -U login -P password (with or without a
                  -- space before the password); -Z is "change password"
                  OR (UPPER(s.command) LIKE N'% -U %' AND UPPER(s.command) LIKE N'% -P%')
                  OR UPPER(s.command) LIKE N'% -Z %'
                  -- dtexec /De abbreviation of /Decrypt
                  OR UPPER(s.command) LIKE N'%/DE %'
                     THEN N'[excerpt masked: command contains a credential keyword]'
                ELSE LEFT(s.command, 256) END
    FROM msdb.dbo.sysjobsteps AS s
    JOIN msdb.dbo.sysjobs AS j ON j.job_id = s.job_id
    LEFT JOIN msdb.dbo.sysproxies AS px ON px.proxy_id = s.proxy_id;

    -- keyed by schedule_id: msdb does NOT keep schedule names unique
    INSERT migration.AgentSchedule (CaptureRunId, ScheduleId, ScheduleName, IsEnabled, FreqType,
        FreqInterval, FreqSubdayType, FreqSubdayInterval, FreqRelativeInterval,
        FreqRecurrenceFactor, ActiveStartDate, ActiveStartTime)
    SELECT @CaptureRunId, schedule_id, name, enabled, freq_type, freq_interval, freq_subday_type,
           freq_subday_interval, freq_relative_interval, freq_recurrence_factor,
           active_start_date, active_start_time
    FROM msdb.dbo.sysschedules;

    /* v2.4: keyed by schedule_id, not name. msdb allows duplicate schedule
       names (the same reason AgentSchedule was re-keyed in 2.2), so the old
       "SELECT DISTINCT job name, schedule name" silently collapsed a job
       attached to two identically-named schedules into ONE row - a lost
       attachment no compare rule could ever see. */
    INSERT migration.AgentJobSchedule (CaptureRunId, JobName, ScheduleId, ScheduleName)
    SELECT DISTINCT @CaptureRunId, j.name, sc.schedule_id, sc.name
    FROM msdb.dbo.sysjobschedules AS js
    JOIN msdb.dbo.sysjobs      AS j  ON j.job_id = js.job_id
    JOIN msdb.dbo.sysschedules AS sc ON sc.schedule_id = js.schedule_id;

    INSERT migration.OperatorInfo (CaptureRunId, OperatorName, IsEnabled, EmailAddress, PagerAddress)
    SELECT @CaptureRunId, name, enabled, email_address, pager_address
    FROM msdb.dbo.sysoperators;

    /* v2.5: performance_condition is now captured. For a PERFORMANCE CONDITION
       alert, message_id/severity/database_name are all 0 or NULL, so without
       it an alert watching "Percent Log Used > 90" and one watching a
       completely different counter were indistinguishable to the compare - it
       reported them as matching.

       sysalerts has no wmi_namespace/wmi_query column (checked against
       sys.columns), so WMI alert payloads are not available to capture. */
    INSERT migration.AlertInfo (CaptureRunId, AlertName, IsEnabled, MessageId, Severity,
        DatabaseName, DelayBetweenResponses, JobName, PerformanceCondition)
    SELECT @CaptureRunId, a.name, a.enabled, a.message_id, a.severity,
           NULLIF(a.database_name, N''), a.delay_between_responses, j.name,
           NULLIF(CONVERT(nvarchar(512), a.performance_condition), N'')
    FROM msdb.dbo.sysalerts AS a
    LEFT JOIN msdb.dbo.sysjobs AS j ON j.job_id = a.job_id;

    INSERT migration.AlertNotification (CaptureRunId, AlertName, OperatorName, UseEmail, UsePager)
    SELECT @CaptureRunId, a.name, o.name,
           CASE WHEN n.notification_method & 1 = 1 THEN 1 ELSE 0 END,
           CASE WHEN n.notification_method & 2 = 2 THEN 1 ELSE 0 END
    FROM msdb.dbo.sysnotifications AS n
    JOIN msdb.dbo.sysalerts    AS a ON a.id = n.alert_id
    JOIN msdb.dbo.sysoperators AS o ON o.id = n.operator_id;

    INSERT migration.CredentialInfo (CaptureRunId, CredentialName, CredentialIdentity)
    SELECT @CaptureRunId, name, credential_identity
    FROM sys.credentials;

    INSERT migration.ProxyInfo (CaptureRunId, ProxyName, CredentialName, IsEnabled,
        SubsystemList, PrincipalList)
    SELECT @CaptureRunId, px.name, c.name, px.enabled,
           -- LEFT: a huge list must truncate, never abort the whole module
           LEFT(STUFF((SELECT N',' + ss.subsystem
                  FROM msdb.dbo.sysproxysubsystem AS pss
                  JOIN msdb.dbo.syssubsystems AS ss ON ss.subsystem_id = pss.subsystem_id
                  WHERE pss.proxy_id = px.proxy_id
                  ORDER BY ss.subsystem
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 1000),
           LEFT(STUFF((SELECT N',' + ISNULL(SUSER_SNAME(pl.sid), N'(unresolved-sid)')
                  FROM msdb.dbo.sysproxylogin AS pl
                  WHERE pl.proxy_id = px.proxy_id
                  ORDER BY ISNULL(SUSER_SNAME(pl.sid), N'(unresolved-sid)')
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 4000)
    FROM msdb.dbo.sysproxies AS px
    LEFT JOIN sys.credentials AS c ON c.credential_id = px.credential_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Agent', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: LinkedServers (provider connection secrets are never captured)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.LinkedServerInfo (CaptureRunId, LinkedServerName, ProductName,
        ProviderName, DataSource, CatalogName, IsRpcOutEnabled, IsDataAccessEnabled,
        LoginMappingCount, MappedLoginList)
    SELECT @CaptureRunId, s.name, s.product, s.provider,
           /* MSDASQL data sources can be full ODBC connection strings carrying
              credentials - mask those; sys.servers.provider_string is never read.

              v2.4.2: the mask now CARRIES A HASH of the original value.

              Until now the masked form was a fixed literal, and the compare
              (03, LinkedServer/DataSource) does string equality on this very
              column - so two DIFFERENT credential-bearing data sources both
              collapsed to the same literal and compared EQUAL. A linked server
              repointed from prod to another host was reported as matching, with
              no finding and no marker: a silent wrong answer, not merely a
              confusing one.

              Every other secret in this tool is stored as a SHA-256 alongside
              a masked preview precisely so the COMPARISON stays exact while the
              value stays unreadable (AgentJobStep.CommandHash,
              ServerTrigger.DefinitionHash, SystemDbObject.DefinitionHash). This
              was the one masking site that dropped the hash. Embedding it in
              the existing nvarchar(4000) column keeps the schema at 2.4 - no
              rebuild - and equal data sources still mask to equal strings. */
           CASE WHEN UPPER(s.data_source) LIKE N'%PWD%'
                  OR UPPER(s.data_source) LIKE N'%PASSWORD%'
                THEN N'[masked: data source contains a credential keyword; sha256='
                   + CONVERT(nvarchar(70), migration.fn_HashLongText(s.data_source), 1) + N']'
                ELSE s.data_source END,
           s.catalog,
           s.is_rpc_out_enabled, s.is_data_access_enabled,
           (SELECT COUNT(*) FROM sys.linked_logins AS ll WHERE ll.server_id = s.server_id),
           /* v2.4.2b: resolve the local principal PROPERLY.

              This was SUSER_SNAME(ll.local_principal_id). sys.linked_logins
              .local_principal_id is an INT principal_id, but SUSER_SNAME takes
              a varbinary(85) SID - the int silently converts to a 4-byte
              binary that matches no login, so the call returned NULL for EVERY
              row and every element of this list rendered as '(all)'. Verified
              on a live instance: SUSER_SNAME(261) IS NULL while
              SUSER_SNAME(0x01) = 'sa'.

              Two defects came out of that one call:
                * FALSE POSITIVE - the ORDER BY key was a constant, so the
                  concatenation order was whatever the scan produced. Two
                  servers whose linked logins were created in a different
                  sequence yielded different strings for identical mappings,
                  and 03's LoginMappings rule compares this value with <>.
                * FALSE NEGATIVE - the local principal was erased from the
                  compared value, so 'AppUser->remote_svc' and
                  'ReportUser->remote_svc' compared EQUAL. A linked server
                  remapped to a different local login reported nothing, in a
                  security-relevant check.

              local_principal_id = 0 means "all logins not otherwise mapped";
              no principal has id 0, so the LEFT JOIN yields NULL and '(all)'
              remains correct for exactly that case. The secondary ORDER BY key
              keeps the list stable when several mappings share '(all)'. */
           LEFT(STUFF((SELECT N',' + ISNULL(lp.name, N'(all)')
                         + N'->' + CASE WHEN ll.uses_self_credential = 1 THEN N'(self)'
                                        ELSE ISNULL(ll.remote_name, N'(none)') END
                  FROM sys.linked_logins AS ll
                  LEFT JOIN sys.server_principals AS lp ON lp.principal_id = ll.local_principal_id
                  WHERE ll.server_id = s.server_id
                  ORDER BY ISNULL(lp.name, N'(all)'), ISNULL(ll.remote_name, N'')
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 4000)
    FROM sys.servers AS s
    WHERE s.is_linked = 1;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'LinkedServers', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: DatabaseMail
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.DatabaseMailProfile (CaptureRunId, ProfileName, AccountList)
    SELECT @CaptureRunId, p.name,
           LEFT(STUFF((SELECT N',' + a.name
                  FROM msdb.dbo.sysmail_profileaccount AS pa
                  JOIN msdb.dbo.sysmail_account AS a ON a.account_id = pa.account_id
                  WHERE pa.profile_id = p.profile_id
                  ORDER BY pa.sequence_number, a.name
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 2000)
    FROM msdb.dbo.sysmail_profile AS p;

    INSERT migration.DatabaseMailAccount (CaptureRunId, AccountName, EmailAddress,
        DisplayName, MailServerName, Port)
    SELECT @CaptureRunId, a.name, a.email_address, a.display_name, s.servername, s.port
    FROM msdb.dbo.sysmail_account AS a
    LEFT JOIN msdb.dbo.sysmail_server AS s ON s.account_id = a.account_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'DatabaseMail', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Endpoints
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.EndpointInfo (CaptureRunId, EndpointName, ProtocolDesc, TypeDesc,
        StateDesc, Port, IsSystem)
    SELECT @CaptureRunId, e.name, e.protocol_desc, e.type_desc, e.state_desc,
           te.port, CASE WHEN e.endpoint_id <= 5 THEN 1 ELSE 0 END
    FROM sys.endpoints AS e
    LEFT JOIN sys.tcp_endpoints AS te ON te.endpoint_id = e.endpoint_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Endpoints', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: ServerTriggers (definitions hashed, never stored)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.ServerTrigger (CaptureRunId, TriggerName, IsDisabled, EventList, DefinitionHash)
    SELECT @CaptureRunId, t.name, t.is_disabled,
           LEFT(STUFF((SELECT N',' + te.type_desc
                  FROM sys.server_trigger_events AS te
                  WHERE te.object_id = t.object_id
                  ORDER BY te.type_desc
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 2000),
           CASE WHEN m.definition IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), m.definition), NCHAR(13) + NCHAR(10), NCHAR(10))) END
    FROM sys.server_triggers AS t
    LEFT JOIN sys.server_sql_modules AS m ON m.object_id = t.object_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'ServerTriggers', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: SystemDbObjects - user objects living in master/msdb (they do NOT
   travel with the user-database restores). Database-scoped DDL triggers are
   in sys.triggers with parent_class = 0, never in sys.objects.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    /* v2.4: ShapeHash. Tables have no sys.sql_modules row, so DefinitionHash
       is NULL for them - and the compare's ISNULL(hash, 0x0) equality made two
       tables with the SAME name and COMPLETELY DIFFERENT columns compare as
       "matching", and counted them in the MatchingObjects pass total. For a
       module whose whole purpose is "user objects in master/msdb do not travel
       with a restore", silently certifying a mismatched table is exactly the
       failure it exists to catch. Hash the ordered column signature instead.
       Ordered by column_id so the hash is stable across servers. */
    INSERT migration.SystemDbObject (CaptureRunId, DatabaseName, SchemaName, ObjectName,
        TypeDesc, DefinitionHash, ShapeHash)
    SELECT @CaptureRunId, N'master', s.name, o.name, o.type_desc,
           CASE WHEN m.definition IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), m.definition), NCHAR(13) + NCHAR(10), NCHAR(10))) END,
           CASE WHEN o.type <> 'U' THEN NULL
                ELSE migration.fn_HashLongText(ISNULL(STUFF((
                        SELECT N'|' + c.name + N' ' + ty.name
                             + N'(' + CONVERT(nvarchar(12), c.max_length) + N','
                             + CONVERT(nvarchar(12), c.precision) + N','
                             + CONVERT(nvarchar(12), c.scale) + N')'
                             + CASE WHEN c.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
                        FROM master.sys.columns AS c
                        JOIN master.sys.types AS ty ON ty.user_type_id = c.user_type_id
                        WHERE c.object_id = o.object_id
                        ORDER BY c.column_id
                        FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'')) END
    FROM master.sys.objects AS o
    JOIN master.sys.schemas AS s ON s.schema_id = o.schema_id
    LEFT JOIN master.sys.sql_modules AS m ON m.object_id = o.object_id
    WHERE o.is_ms_shipped = 0
      AND o.type IN ('U', 'V', 'P', 'FN', 'IF', 'TF', 'TR')
    UNION ALL
    SELECT @CaptureRunId, N'msdb', s.name, o.name, o.type_desc,
           CASE WHEN m.definition IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), m.definition), NCHAR(13) + NCHAR(10), NCHAR(10))) END,
           CASE WHEN o.type <> 'U' THEN NULL
                ELSE migration.fn_HashLongText(ISNULL(STUFF((
                        SELECT N'|' + c.name + N' ' + ty.name
                             + N'(' + CONVERT(nvarchar(12), c.max_length) + N','
                             + CONVERT(nvarchar(12), c.precision) + N','
                             + CONVERT(nvarchar(12), c.scale) + N')'
                             + CASE WHEN c.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
                        FROM msdb.sys.columns AS c
                        JOIN msdb.sys.types AS ty ON ty.user_type_id = c.user_type_id
                        WHERE c.object_id = o.object_id
                        ORDER BY c.column_id
                        FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), N'')) END
    FROM msdb.sys.objects AS o
    JOIN msdb.sys.schemas AS s ON s.schema_id = o.schema_id
    LEFT JOIN msdb.sys.sql_modules AS m ON m.object_id = o.object_id
    WHERE o.is_ms_shipped = 0
      AND o.type IN ('U', 'V', 'P', 'FN', 'IF', 'TF', 'TR')
    UNION ALL
    SELECT @CaptureRunId, N'master', N'(database-trigger)', t.name, N'DATABASE_DDL_TRIGGER',
           CASE WHEN m.definition IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), m.definition), NCHAR(13) + NCHAR(10), NCHAR(10))) END,
           NULL   -- v2.4: triggers are modules, not tables - no column shape
    FROM master.sys.triggers AS t
    LEFT JOIN master.sys.sql_modules AS m ON m.object_id = t.object_id
    WHERE t.parent_class = 0 AND t.is_ms_shipped = 0
    UNION ALL
    SELECT @CaptureRunId, N'msdb', N'(database-trigger)', t.name, N'DATABASE_DDL_TRIGGER',
           CASE WHEN m.definition IS NULL THEN NULL
                ELSE migration.fn_HashLongText(
                         REPLACE(CONVERT(nvarchar(max), m.definition), NCHAR(13) + NCHAR(10), NCHAR(10))) END,
           NULL   -- v2.4: triggers are modules, not tables - no column shape
    FROM msdb.sys.triggers AS t
    LEFT JOIN msdb.sys.sql_modules AS m ON m.object_id = t.object_id
    WHERE t.parent_class = 0 AND t.is_ms_shipped = 0;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'SystemDbObjects', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: DatabaseScopedConfig (v2.4)

   The single most common SQL 2016 -> 2025 regression is the cardinality
   estimator, and it is controlled per database here - together with
   PARAMETER_SNIFFING, QUERY_OPTIMIZER_HOTFIXES and the per-database MAXDOP.
   None of it is visible at server level and none of it was captured before
   2.4, so the validator was blind to the thing most likely to make a
   correctly-migrated database perform badly.

   sys.database_scoped_configurations is SQL 2016+, but the row set grows with
   every version - we store whatever the instance reports rather than a fixed
   list, so a 2025 target contributing new knobs is data, not an error. The
   read is per-database dynamic SQL for the same reason as DatabaseHealth: it
   must run under each user database's own compatibility level, so plain
   CONVERT only, never TRY_CONVERT (compat < 110 dies with error 195).
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @DscDb sysname, @DscSql nvarchar(max), @DscSkip nvarchar(400);

/* v2.6: guard the whole module on the engine version.

   The comment above has said "sys.database_scoped_configurations is SQL 2016+"
   since 2.4, but nothing acted on it: the dynamic SQL ran against every user
   database regardless, so a SQL 2014 source produced one "Invalid object name"
   per database - eleven identical errors on a real instance - for a feature
   that simply does not exist there. sys.database_query_store_options is in the
   same batch and equally 2016+, so Query Store went with it.

   Recorded ONCE, as IsNotApplicable, which is a different thing from an error:
   it still gates the compare section (there genuinely is nothing to compare,
   and the comparison must never guess) but it no longer drags a healthy source
   down to READY WITH WARNINGS for an absence no one can act on.

   The message points at where the equivalent information actually lives on a
   pre-2016 source, because it does exist - at a different scope. The knobs
   that matter most here are the cardinality estimator and the optimizer
   hotfixes, and on 2014 those are database COMPATIBILITY LEVEL plus global
   trace flags 9481/2312/4136/4199 - all of which the Databases, Configuration
   and TraceFlags modules already capture, and which 03 already annotates with
   their post-2016 scoped-configuration equivalents. */
    IF @MajorVersion IS NOT NULL AND @MajorVersion < 13
    BEGIN
        INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber,
                                       ErrorMessage, IsNotApplicable)
        VALUES (@CaptureRunId, N'DatabaseScopedConfig', NULL, NULL,
                N'Not applicable on this engine: database-scoped configuration (sys.database_scoped_configurations) '
              + N'and Query Store (sys.database_query_store_options) were both introduced in SQL Server 2016, and this '
              + N'source reports major version ' + CONVERT(nvarchar(10), @MajorVersion) + N'. Nothing failed and nothing '
              + N'is missing - the feature does not exist here. The settings these control before 2016 are database '
              + N'COMPATIBILITY LEVEL and global trace flags (9481/2312 cardinality estimator, 4199 optimizer hotfixes, '
              + N'4136 parameter sniffing); those ARE captured, by the Databases and TraceFlags modules, and the '
              + N'comparison maps each one to its post-2016 scoped-configuration equivalent.',
                1);
    END
    ELSE
    BEGIN
    DECLARE DscCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name,
               CASE WHEN state_desc <> N'ONLINE'           THEN N'database state is ' + state_desc
                    WHEN user_access_desc <> N'MULTI_USER' THEN N'database is ' + user_access_desc
                    WHEN HAS_DBACCESS(name) = 0            THEN N'no access for the capturing login'
               END
        FROM sys.databases
        WHERE source_database_id IS NULL AND database_id > 4;
    OPEN DscCursor;
    FETCH NEXT FROM DscCursor INTO @DscDb, @DscSkip;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @DscSkip IS NOT NULL
        BEGIN
            INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber, ErrorMessage)
            VALUES (@CaptureRunId, N'DatabaseScopedConfig', @DscDb, NULL,
                    N'Database-scoped configuration not read: ' + @DscSkip + N'. Make the database ONLINE/MULTI_USER/accessible and re-capture.');
            FETCH NEXT FROM DscCursor INTO @DscDb, @DscSkip;
            CONTINUE;
        END
        BEGIN TRY
            SET @DscSql = N'USE ' + QUOTENAME(@DscDb) + N';
                INSERT ' + QUOTENAME(@AdminDb) + N'.migration.DatabaseScopedConfig
                    (CaptureRunId, DatabaseName, ConfigName, Value, ValueForSecondary)
                SELECT @rid, @db, name,
                       LEFT(CONVERT(nvarchar(400), value), 400),
                       LEFT(CONVERT(nvarchar(400), value_for_secondary), 400)
                FROM sys.database_scoped_configurations;

                INSERT ' + QUOTENAME(@AdminDb) + N'.migration.DatabaseQueryStore
                    (CaptureRunId, DatabaseName, DesiredStateDesc, ActualStateDesc,
                     QueryCaptureMode, MaxStorageMB, StaleThresholdDays)
                SELECT @rid, @db, desired_state_desc, actual_state_desc,
                       query_capture_mode_desc,
                       max_storage_size_mb, stale_query_threshold_days
                FROM sys.database_query_store_options;';
            EXEC sp_executesql @DscSql, N'@rid int, @db sysname', @rid = @CaptureRunId, @db = @DscDb;
        END TRY
        BEGIN CATCH
            IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
            INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber, ErrorMessage)
            VALUES (@CaptureRunId, N'DatabaseScopedConfig', @DscDb, ERROR_NUMBER(), ERROR_MESSAGE());
        END CATCH;
        FETCH NEXT FROM DscCursor INTO @DscDb, @DscSkip;
    END
    CLOSE DscCursor;
    DEALLOCATE DscCursor;
    END   -- v2.6: end of the ELSE branch opened by the engine-version guard
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    IF CURSOR_STATUS('local', 'DscCursor') >= -1
    BEGIN
        BEGIN TRY CLOSE DscCursor; DEALLOCATE DscCursor; END TRY BEGIN CATCH END CATCH;
    END
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'DatabaseScopedConfig', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Encryption - certificates and symmetric keys in master.
   key_thumbprint is sql_variant: the CONVERT is mandatory, not cosmetic.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.MasterCertificate (CaptureRunId, CertificateName, Thumbprint,
        SubjectText, ExpiryDate, PvtKeyEncryptionTypeDesc)
    SELECT @CaptureRunId, name, CONVERT(varbinary(64), thumbprint),
           CONVERT(nvarchar(800), subject), CONVERT(datetime2(0), expiry_date),
           pvt_key_encryption_type_desc
    FROM master.sys.certificates;

    INSERT migration.MasterSymmetricKey (CaptureRunId, KeyName, Thumbprint, AlgorithmDesc)
    SELECT @CaptureRunId, name, CONVERT(varbinary(64), key_thumbprint), algorithm_desc
    FROM master.sys.symmetric_keys;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Encryption', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Audits - specs join audits by GUID: audit_id does not survive a
   restore, the GUID does.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.ServerAudit (CaptureRunId, AuditName, AuditGuid, TypeDesc,
        OnFailureDesc, IsEnabled, FilePath)
    SELECT @CaptureRunId, a.name, a.audit_guid, a.type_desc, a.on_failure_desc,
           a.is_state_enabled, fa.log_file_path
    FROM sys.server_audits AS a
    LEFT JOIN sys.server_file_audits AS fa ON fa.audit_id = a.audit_id;

    INSERT migration.ServerAuditSpec (CaptureRunId, SpecName, AuditGuid, IsEnabled, ActionList)
    SELECT @CaptureRunId, sp.name, a.audit_guid, sp.is_state_enabled,
           LEFT(STUFF((SELECT N',' + d.audit_action_name
                  FROM sys.server_audit_specification_details AS d
                  WHERE d.server_specification_id = sp.server_specification_id
                  ORDER BY d.audit_action_name
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N''), 4000)
    FROM sys.server_audit_specifications AS sp
    LEFT JOIN sys.server_audits AS a ON a.audit_guid = sp.audit_guid;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Audits', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: XeSessions - defined Extended Events sessions. SSMS XEvent
   Profiler's QuickSession* leftovers are excluded on BOTH sides by design.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.XeSession (CaptureRunId, SessionName, StartupState, IsRunning,
        EventCount, TargetCount)
    SELECT @CaptureRunId, es.name, es.startup_state,
           CASE WHEN EXISTS (SELECT 1 FROM sys.dm_xe_sessions AS r WHERE r.name = es.name)
                THEN 1 ELSE 0 END,
           (SELECT COUNT(*) FROM sys.server_event_session_events  AS ev WHERE ev.event_session_id = es.event_session_id),
           (SELECT COUNT(*) FROM sys.server_event_session_targets AS tg WHERE tg.event_session_id = es.event_session_id)
    FROM sys.server_event_sessions AS es
    WHERE es.name NOT LIKE N'QuickSession%'
      -- Microsoft-shipped sessions: their event/target sets are defined by the
      -- engine VERSION, so comparing them across an upgrade is pure noise
      AND es.name NOT IN (N'system_health', N'AlwaysOn_health', N'telemetry_xevents');
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'XeSessions', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: ResourceGovernor
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, N'ResourceGovernorEnabled', CONVERT(nvarchar(10), is_enabled)
    FROM sys.resource_governor_configuration;

    INSERT migration.InstanceProperty (CaptureRunId, PropertyName, PropertyValue)
    SELECT @CaptureRunId, N'ResourceGovernorClassifier',
           ISNULL(OBJECT_NAME(classifier_function_id, 1), N'')
    FROM sys.resource_governor_configuration;

    INSERT migration.RgPool (CaptureRunId, PoolName, MinCpuPercent, MaxCpuPercent,
        CapCpuPercent, MinMemoryPercent, MaxMemoryPercent)
    SELECT @CaptureRunId, name, min_cpu_percent, max_cpu_percent, cap_cpu_percent,
           min_memory_percent, max_memory_percent
    FROM sys.resource_governor_resource_pools;

    INSERT migration.RgGroup (CaptureRunId, GroupName, PoolName, Importance,
        RequestMaxMemoryGrantPercent, RequestMaxCpuTimeSec, RequestMemoryGrantTimeoutSec,
        GroupMaxRequests, MaxDop)
    SELECT @CaptureRunId, g.name, p.name, g.importance,
           g.request_max_memory_grant_percent, g.request_max_cpu_time_sec,
           g.request_memory_grant_timeout_sec, g.group_max_requests, g.max_dop
    FROM sys.resource_governor_workload_groups AS g
    LEFT JOIN sys.resource_governor_resource_pools AS p ON p.pool_id = g.pool_id;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'ResourceGovernor', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: DatabaseHealth - per accessible ONLINE user database. A failure
   in ONE database records an item-scoped CaptureError and the loop
   continues; the compare skips exactly that database, never the module.
   Orphan detection: SQL users (INSTANCE) with no matching server SID are
   hard orphans; WINDOWS users/groups with no matching server principal may
   still authenticate via group membership and are flagged for review.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    DECLARE @HealthDb sysname, @HealthSql nvarchar(max), @HealthSkipReason nvarchar(200),
            @QualifiedAdmin nvarchar(300) = QUOTENAME(@AdminDb);
    /* EVERY user database is either measured or gets an item-scoped
       CaptureError - an unmeasured database must never look healthy. */
    DECLARE HealthCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name,
               CASE WHEN state_desc <> N'ONLINE' THEN N'database state is ' + state_desc
                    WHEN user_access_desc <> N'MULTI_USER' THEN N'database is ' + user_access_desc
                    WHEN HAS_DBACCESS(name) = 0 THEN N'no access for the capturing login'
               END AS SkipReason
        FROM sys.databases
        WHERE source_database_id IS NULL AND database_id > 4
        ORDER BY name;
    OPEN HealthCursor;
    FETCH NEXT FROM HealthCursor INTO @HealthDb, @HealthSkipReason;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @HealthSkipReason IS NOT NULL
        BEGIN
            INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber, ErrorMessage)
            VALUES (@CaptureRunId, N'DatabaseHealth', @HealthDb, NULL,
                    N'Health/orphan checks skipped: ' + @HealthSkipReason + N'. Make the database ONLINE/MULTI_USER/accessible and re-capture to validate it.');
            FETCH NEXT FROM HealthCursor INTO @HealthDb, @HealthSkipReason;
            CONTINUE;
        END
        BEGIN TRY
            SET @HealthSql = N'USE ' + QUOTENAME(@HealthDb) + N';
INSERT ' + @QualifiedAdmin + N'.migration.DatabaseHealth (CaptureRunId, DatabaseName,
    LastGoodCheckDbDate, UntrustedForeignKeyCount, UntrustedCheckConstraintCount,
    OrphanedSqlUserCount, OrphanedWindowsUserCount, UserCount)
SELECT @rid, @db,
    /* CONVERT, not TRY_CONVERT: this runs under the USER database''s
       compatibility level, and TRY_CONVERT needs compat 110+ - on a
       compat-100 database it dies with error 195 (''datetime2'' is not a
       recognized built-in function name). A bad variant still fails safely
       into the per-item CATCH. */
    NULLIF(CONVERT(datetime2(0), DATABASEPROPERTYEX(@db, ''LastGoodCheckDbTime'')), CONVERT(datetime2(0), ''1900-01-01'')),
    (SELECT COUNT(*) FROM sys.foreign_keys       WHERE is_not_trusted = 1 AND is_disabled = 0 AND is_not_for_replication = 0),
    (SELECT COUNT(*) FROM sys.check_constraints  WHERE is_not_trusted = 1 AND is_disabled = 0 AND is_not_for_replication = 0),
    (SELECT COUNT(*) FROM sys.database_principals AS dp
     WHERE dp.type = ''S'' AND dp.principal_id > 4 AND dp.sid IS NOT NULL
       AND dp.authentication_type_desc = N''INSTANCE''
       AND NOT EXISTS (SELECT 1 FROM sys.server_principals AS sp WHERE sp.sid = dp.sid)),
    (SELECT COUNT(*) FROM sys.database_principals AS dp
     WHERE dp.type IN (''U'', ''G'') AND dp.principal_id > 4 AND dp.sid IS NOT NULL
       AND dp.authentication_type_desc = N''WINDOWS''
       AND NOT EXISTS (SELECT 1 FROM sys.server_principals AS sp WHERE sp.sid = dp.sid)),
    (SELECT COUNT(*) FROM sys.database_principals
     WHERE type IN (''S'', ''U'', ''G'') AND principal_id > 4);

INSERT ' + @QualifiedAdmin + N'.migration.OrphanedUser (CaptureRunId, DatabaseName, UserName, TypeDesc, AuthDesc)
SELECT @rid, @db, dp.name, dp.type_desc, dp.authentication_type_desc
FROM sys.database_principals AS dp
WHERE dp.principal_id > 4 AND dp.sid IS NOT NULL
  AND ((dp.type = ''S'' AND dp.authentication_type_desc = N''INSTANCE'')
    OR (dp.type IN (''U'', ''G'') AND dp.authentication_type_desc = N''WINDOWS''))
  AND NOT EXISTS (SELECT 1 FROM sys.server_principals AS sp WHERE sp.sid = dp.sid);';
            EXEC sp_executesql @HealthSql, N'@rid int, @db sysname',
                 @rid = @CaptureRunId, @db = @HealthDb;
        END TRY
        BEGIN CATCH
            IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
            INSERT migration.CaptureError (CaptureRunId, ModuleName, ItemName, ErrorNumber, ErrorMessage)
            VALUES (@CaptureRunId, N'DatabaseHealth', @HealthDb, ERROR_NUMBER(), ERROR_MESSAGE());
        END CATCH;
        FETCH NEXT FROM HealthCursor INTO @HealthDb, @HealthSkipReason;
    END
    CLOSE HealthCursor;
    DEALLOCATE HealthCursor;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    IF CURSOR_STATUS('local', 'HealthCursor') >= -1
    BEGIN
        BEGIN TRY CLOSE HealthCursor; DEALLOCATE HealthCursor; END TRY BEGIN CATCH END CATCH;
    END
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'DatabaseHealth', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Features - server-level feature usage that must exist (or be
   consciously dropped) on the target
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.FeatureUsage (CaptureRunId, FeatureName, IsInUse, Detail)
    SELECT @CaptureRunId, f.FeatureName,
           CASE WHEN f.Detail IS NULL OR f.Detail = N'' THEN 0 ELSE 1 END,
           LEFT(NULLIF(f.Detail, N''), 4000)   -- truncate huge database lists, never fail
    FROM (VALUES
        (N'Replication',
         STUFF((SELECT N',' + name FROM sys.databases
                WHERE (is_published = 1 OR is_subscribed = 1 OR is_merge_published = 1)
                  AND source_database_id IS NULL
                ORDER BY name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'DatabaseMirroring',
         STUFF((SELECT N',' + DB_NAME(database_id) FROM sys.database_mirroring
                WHERE mirroring_guid IS NOT NULL
                ORDER BY DB_NAME(database_id) FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'ChangeDataCapture',
         STUFF((SELECT N',' + name FROM sys.databases
                WHERE is_cdc_enabled = 1 AND source_database_id IS NULL
                ORDER BY name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'ChangeTracking',
         STUFF((SELECT N',' + DB_NAME(database_id) FROM sys.change_tracking_databases
                ORDER BY DB_NAME(database_id) FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'TransparentDataEncryption',
         STUFF((SELECT N',' + name FROM sys.databases
                WHERE is_encrypted = 1 AND source_database_id IS NULL
                ORDER BY name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'ServiceBroker',
         STUFF((SELECT N',' + name FROM sys.databases
                WHERE is_broker_enabled = 1 AND database_id > 4 AND source_database_id IS NULL
                ORDER BY name FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'')),
        (N'Filestream',
         CASE WHEN CONVERT(int, ISNULL(SERVERPROPERTY('FilestreamEffectiveLevel'), 0)) > 0
              THEN N'EffectiveLevel=' + CONVERT(nvarchar(10), SERVERPROPERTY('FilestreamEffectiveLevel')) ELSE N'' END),
        (N'AlwaysOnAvailabilityGroups',
         CASE WHEN CONVERT(int, ISNULL(SERVERPROPERTY('IsHadrEnabled'), 0)) = 1 THEN N'HadrEnabled' ELSE N'' END),
        (N'FailoverClustering',
         CASE WHEN CONVERT(int, ISNULL(SERVERPROPERTY('IsClustered'), 0)) = 1 THEN N'Clustered' ELSE N'' END)
    ) AS f (FeatureName, Detail);

    -- Log shipping lives in msdb; separate statement so its tables' absence
    -- of rows is cheap and its permission profile matches the msdb reads.
    INSERT migration.FeatureUsage (CaptureRunId, FeatureName, IsInUse, Detail)
    SELECT @CaptureRunId, N'LogShipping',
           CASE WHEN p.PrimaryCount + s.SecondaryCount > 0 THEN 1 ELSE 0 END,
           NULLIF(N'primary=' + CONVERT(nvarchar(10), p.PrimaryCount)
                + N',secondary=' + CONVERT(nvarchar(10), s.SecondaryCount),
                  N'primary=0,secondary=0')
    FROM (SELECT COUNT(*) AS PrimaryCount   FROM msdb.dbo.log_shipping_primary_databases)   AS p
    CROSS JOIN (SELECT COUNT(*) AS SecondaryCount FROM msdb.dbo.log_shipping_secondary_databases) AS s;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Features', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: DeprecatedFeatures - engine counters of deprecated feature use
   (interesting on the SOURCE: what must change before/after the upgrade)
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.DeprecatedFeature (CaptureRunId, FeatureName, UsageCount)
    SELECT @CaptureRunId, RTRIM(instance_name), MAX(cntr_value)
    FROM sys.dm_os_performance_counters
    WHERE object_name LIKE N'%Deprecated Features%' AND cntr_value > 0
    GROUP BY RTRIM(instance_name);
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'DeprecatedFeatures', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: UserMessages (v2.5) - user-defined messages in master.
   sys.messages rows >= 50000 do NOT travel with a user-database restore.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.UserMessage (CaptureRunId, MessageId, LanguageId, Severity,
        IsEventLogged, MessageText)
    SELECT @CaptureRunId, m.message_id, m.language_id, m.severity,
           m.is_event_logged, LEFT(m.text, 2048)
    FROM sys.messages AS m
    WHERE m.message_id >= 50000;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'UserMessages', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: BackupDevices (v2.5) - named backup devices in master.
   A job that backs up TO [DeviceName] has identical command text on both
   sides, so the step-command hash matches and nothing else looked.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    INSERT migration.BackupDevice (CaptureRunId, DeviceName, DeviceTypeDesc, PhysicalName)
    SELECT @CaptureRunId, name, type_desc, LEFT(physical_name, 520)
    FROM sys.backup_devices;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'BackupDevices', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Module: Baselines - point-in-time performance snapshot for before/after
   comparison (informational; needs VIEW SERVER STATE). Values are only
   meaningful when the instance is under its normal workload.
   ========================================================================== */
SET @ModuleCount += 1;
BEGIN TRY
    -- buffer pool pressure
    INSERT migration.BaselineMetric (CaptureRunId, MetricName, MetricValue)
    SELECT @CaptureRunId, N'PageLifeExpectancy', CONVERT(nvarchar(40), MIN(cntr_value))
    FROM sys.dm_os_performance_counters
    WHERE counter_name = N'Page life expectancy' AND object_name LIKE N'%Buffer Manager%';

    -- recent SQL CPU utilization (scheduler-monitor ring buffer, ~last 30 min)
    INSERT migration.BaselineMetric (CaptureRunId, MetricName, MetricValue)
    SELECT @CaptureRunId, N'RecentAvgSqlCpuPercent', CONVERT(nvarchar(40), AVG(y.SqlCpu))
    FROM (SELECT record.value(N'(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', N'int') AS SqlCpu
          FROM (SELECT TOP (30) CONVERT(xml, record) AS record
                FROM sys.dm_os_ring_buffers
                WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
                  AND record LIKE N'%<SystemHealth>%'
                ORDER BY timestamp DESC) AS x) AS y
    HAVING COUNT(*) > 0;

    -- top waits since instance start (benign waits excluded), as percentages
    INSERT migration.BaselineMetric (CaptureRunId, MetricName, MetricValue)
    SELECT @CaptureRunId, N'TopWaits',
           -- LEFT: 8 long wait names can exceed the 400-char column
           LEFT(STUFF((SELECT TOP (8) N', ' + w.wait_type + N'='
                      + CONVERT(nvarchar(10), CONVERT(decimal(5, 1),
                            w.wait_time_ms * 100.0 / NULLIF(SUM(w.wait_time_ms) OVER (), 0))) + N'%'
                  FROM sys.dm_os_wait_stats AS w
                  WHERE w.wait_time_ms > 0
                    AND w.wait_type NOT LIKE N'SLEEP[_]%'      AND w.wait_type NOT LIKE N'BROKER%'
                    AND w.wait_type NOT LIKE N'XE%'            AND w.wait_type NOT LIKE N'SQLTRACE%'
                    AND w.wait_type NOT LIKE N'FT[_]%'         AND w.wait_type NOT LIKE N'QDS%'
                    AND w.wait_type NOT LIKE N'HADR%'          AND w.wait_type NOT LIKE N'PREEMPTIVE[_]XE%'
                    AND w.wait_type NOT LIKE N'WAIT[_]XTP%'    AND w.wait_type NOT LIKE N'PARALLEL[_]REDO%'
                    AND w.wait_type NOT LIKE N'DBMIRROR%'      AND w.wait_type NOT LIKE N'CLR[_]AUTO%'
                    AND w.wait_type NOT IN (N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', N'CHECKPOINT_QUEUE',
                        N'REQUEST_FOR_DEADLOCK_SEARCH', N'WAITFOR', N'DIRTY_PAGE_POLL',
                        N'SP_SERVER_DIAGNOSTICS_SLEEP', N'TRACEWRITE', N'KSOURCE_WAKEUP',
                        N'ONDEMAND_TASK_QUEUE', N'SERVER_IDLE_CHECK', N'SOS_WORK_DISPATCHER',
                        N'DISPATCHER_QUEUE_SEMAPHORE', N'AZURE_STORAGE_QUEUE_SEMAPHORE',
                        N'PRINT_ROLLBACK_PROGRESS', N'PWAIT_ALL_COMPONENTS_INITIALIZED')
                  ORDER BY w.wait_time_ms DESC
                  FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N''), 400);

    -- cumulative IO latency per drive since instance start
    INSERT migration.BaselineMetric (CaptureRunId, MetricName, MetricValue)
    SELECT @CaptureRunId,
           N'IoLatencyMs ' + drv.Drive,
           N'read=' + CONVERT(nvarchar(20), drv.ReadMs) + N'ms write=' + CONVERT(nvarchar(20), drv.WriteMs) + N'ms'
    FROM (SELECT UPPER(LEFT(mf.physical_name, 3)) AS Drive,
                 SUM(vf.io_stall_read_ms)  / NULLIF(SUM(vf.num_of_reads), 0)  AS ReadMs,
                 SUM(vf.io_stall_write_ms) / NULLIF(SUM(vf.num_of_writes), 0) AS WriteMs
          FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vf
          JOIN sys.master_files AS mf
            ON mf.database_id = vf.database_id AND mf.file_id = vf.file_id
          GROUP BY UPPER(LEFT(mf.physical_name, 3))) AS drv
    WHERE drv.ReadMs IS NOT NULL OR drv.WriteMs IS NOT NULL;
END TRY
BEGIN CATCH
    IF XACT_STATE() = -1 ROLLBACK TRANSACTION;
    INSERT migration.CaptureError (CaptureRunId, ModuleName, ErrorNumber, ErrorMessage)
    VALUES (@CaptureRunId, N'Baselines', ERROR_NUMBER(), ERROR_MESSAGE());
END CATCH;

/* ==========================================================================
   Finalize run + retention cleanup
   ========================================================================== */
DECLARE @RequiredModules TABLE (ModuleName sysname PRIMARY KEY);
INSERT @RequiredModules VALUES (N'Instance'), (N'Configuration'), (N'Databases'),
                               (N'Logins'), (N'ServerSecurity'), (N'Agent');

/* v2.6: IsNotApplicable = 0 on both counts. A module that reported "this
   engine version does not have the feature" has not FAILED, and counting it as
   a failure would put "1 failed" in the operator's summary for a source that is
   entirely healthy - and, on a required module, would falsely mark the whole
   capture INCOMPLETE. */
DECLARE @FailedModules int =
    (SELECT COUNT(DISTINCT ModuleName) FROM migration.CaptureError
     WHERE CaptureRunId = @CaptureRunId AND ItemName IS NULL AND IsNotApplicable = 0);
DECLARE @FailedRequired int =
    (SELECT COUNT(DISTINCT e.ModuleName) FROM migration.CaptureError AS e
     JOIN @RequiredModules AS r ON r.ModuleName = e.ModuleName
     WHERE e.CaptureRunId = @CaptureRunId AND e.ItemName IS NULL AND e.IsNotApplicable = 0);

UPDATE migration.CaptureRun
SET IsComplete       = CASE WHEN @FailedRequired = 0 THEN 1 ELSE 0 END,
    ModulesAttempted = @ModuleCount,
    ModulesFailed    = @FailedModules,
    DurationSeconds  = DATEDIFF(SECOND, @StartTime, SYSUTCDATETIME())
WHERE CaptureRunId = @CaptureRunId;

/* Retention: keep the newest N runs OF THIS ROLE ONLY. A target capture must
   never delete the restored source capture (different role, untouched). */
BEGIN TRY
    DECLARE @KeepRuns int =
        ISNULL(TRY_CONVERT(int, (SELECT ConfigValue FROM migration.ConfigValue
                                 WHERE ConfigName = N'RetentionRunsPerRole')), 10);
    DECLARE @ExpiredRuns TABLE (CaptureRunId int PRIMARY KEY);
    /* Never expire a capture referenced by a persisted comparison: the
       ComparisonRun + Finding rows are the sign-off evidence for the
       migration and must survive routine re-capturing. Remove them
       deliberately (see RUNBOOK "Removing stale or bad captures"), never
       as a retention side effect. */
    INSERT @ExpiredRuns
    SELECT CaptureRunId
    FROM (SELECT CaptureRunId,
                 ROW_NUMBER() OVER (ORDER BY CaptureRunId DESC) AS rn
          FROM migration.CaptureRun
          WHERE CaptureRole = @Role AND ServerName = @ServerName) AS ranked
    WHERE rn > @KeepRuns
      AND CaptureRunId NOT IN (SELECT SourceCaptureRunId FROM migration.ComparisonRun
                               UNION SELECT TargetCaptureRunId FROM migration.ComparisonRun);

    IF EXISTS (SELECT 1 FROM @ExpiredRuns)
        DELETE FROM migration.CaptureRun        -- entity rows cascade
        WHERE CaptureRunId IN (SELECT CaptureRunId FROM @ExpiredRuns);
END TRY
BEGIN CATCH
    PRINT N'Retention cleanup failed (capture itself is unaffected): ' + ERROR_MESSAGE();
END CATCH;

/* ---- summary ----------------------------------------------------------- */
SELECT r.CaptureRunId, r.CaptureRole, r.ServerName, r.ProductVersion, r.Edition,
       r.CaptureDateUtc, r.IsComplete, r.ModulesAttempted, r.ModulesFailed, r.DurationSeconds
FROM migration.CaptureRun AS r
WHERE r.CaptureRunId = @CaptureRunId;

/* v2.6: IsNotApplicable travels with the row so the caller can separate "this
   engine has no such feature" from "this failed", and ORDER BY puts the real
   errors first - the operator should not have to read past a version note to
   find something actionable. */
SELECT ModuleName, ItemName, ErrorNumber, ErrorMessage, IsNotApplicable
FROM migration.CaptureError
WHERE CaptureRunId = @CaptureRunId
ORDER BY IsNotApplicable, CaptureErrorId;

IF @FailedRequired > 0
    PRINT N'WARNING: a REQUIRED module failed - this capture is INCOMPLETE and the comparison will refuse to report READY.';
ELSE IF @FailedModules > 0
    PRINT N'Capture completed with ' + CONVERT(nvarchar(10), @FailedModules) + N' optional module failure(s) - see the error result set.';
ELSE
    PRINT N'Capture completed successfully (CaptureRunId = ' + CONVERT(nvarchar(10), @CaptureRunId) + N').';

RETURN 0;
END

