SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankBuildingSitusPost] (@tableName varchar(40)) -- @tableName = 'Building_Situs' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild SitusStdFullStreetAddress and SitusCensusTractBlock fields
-- ,[SitusStdHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdHouseNbr])) -- changed 20240708 GM
-- ,[SitusStdStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdStreet]))) -- changed 20240716 GM
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Building_Situs_STD]
	   --set [SitusStdFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdMode]))) + '' '' + [AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitNbr])))))))
       set [SitusStdFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitNbr]))))
	   ,[SitusStdHouseNbr]  = substring(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdHouseNbr])),1,30)
       ,[SitusStdDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionLeft]))
       ,[SitusStdStreet] = substring(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdStreet]))),1,60)
       ,[SitusStdMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdMode])))
       ,[SitusStdDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdDirectionRight]))
       ,[SitusStdUnitNbr] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitNbr]))
       ,[SitusStdCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdCity])))
       ,[SitusStdState] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdState]))
       ,[SitusStdZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdZIP5]))
       ,[SitusStdZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdZIP4]))
       ,[SitusLatitude] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusLatitude]))
       ,[SitusLongitude] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusLongitude]))
       ,[SitusStdCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdCarrierCode]))
       ,[SitusCensusTractBlock] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusCensusTract])) + ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusCensusBlock]))
       ,[SitusStdUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdUnitType])))
       ,[SitusStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusStdMatchCode]))
       ,[SitusDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusDPVCount]))
       ,[SitusDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusDPVFootnote]))
       ,[SitusLACS] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusLACS]))
       ,[SitusLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusLACSLinkInd]))
       ,[SitusDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusDPCheckDigit]))
       ,[SitusDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusDPCheckCode]))
       ,[SitusCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusCensusBlock]))
	   ,[SitusCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusCensusTract]))
	   ,[SitusGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusGeoCodeResults]))
       ,[SitusGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusGeoErrorCode]))
       ,[SitusGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Building_Situs_STD].[SitusGeoStatusCode]))
     From [AddressSTD].[dbo].[Building_Situs_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Building_Situs_to_Licensing


