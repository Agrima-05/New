SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20220404
-- Description:	Address Standardization
-- =============================================

CREATE PROCEDURE [dbo].[d545_RunASP_UPDATE] 
	
AS
BEGIN

	SET NOCOUNT ON;

    EXEC [dbo].[usp_100b_sp_ASP_Cust_to_ASP_Mail_UPDATE]

	EXEC [dbo].[usp_100d_ASP_Property_Mailing_to_Licensing_UPDATE]
 
 	UPDATE LIC
	SET LIC.MailingFIPS = FZ.FIPS
		FROM 
			[DragonAssr].[dbo].[PropertyWorkUpdate] LIC
		INNER JOIN
			[USPS].[dbo].[FIPS_ZIP] FZ
		ON 
			LIC.MailingStdZIP5 = FZ.ZIPCode

END



