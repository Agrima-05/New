﻿/* Source: AZUVNSQLDTDB003.datatree.local | SPDB | dbo.usp_PEt_Apn_Creation_1_sql03 | type=P */

-- ====================================================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   <Description,,>
-- [dbo].[GetDynamicFormat] 'TITLE_SERVICES','INSTRUMENT','K'
-- MP - 2022-07-25 - Add missing Entries to PEt.dbo.PET_FIPS_APN_Type
-- ====================================================================
CREATE PROCEDURE [dbo].[usp_PEt_Apn_Creation_1_sql03] @fips INT = NULL
	,@Apn_type VARCHAR(10) = NULL
	,@list_Sql INT = 0
AS
DECLARE @sql_cmd VARCHAR(max)
DECLARE @Source_apn VARCHAR(50) = NULL -- 'formatted_APN'
	,@Rule VARCHAR(max) = NULL --
	--'			
	--when SUBSTRING(a.APN,1,2) = ''1-'' then ''DC'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''2-'' then ''ED'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''3-'' then ''kh'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''4-'' then ''LC'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''5-'' then ''MD'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''6-'' then ''MN'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''7-'' then ''NM'' + substring(a.apn, 2,60)			
	--when SUBSTRING(a.APN,1,2) = ''8-'' then ''SM'' + substring(a.apn, 2,60)
	--when SUBSTRING(a.APN,1,2) = ''9-'' then ''WD'' + substring(a.apn, 2,60)
	--'
	,@Status VARCHAR(20) = NULL --'To_Be_Processed'
	,@node_delimeter VARCHAR(10) = NULL --'-'
	-- select top 100 * from Lien.dbo.PET_APN_Additional_Formats a
DECLARE @mess VARCHAR(200) = 'Fips:' + try_cast(@fips AS VARCHAR) + ' Type: ' + @apn_type

--EXEC ntp.Stage.[AddNtpLog] N'info'
--	,N'usp_PEt_Apn_Creation_1 begin'
--	,@mess
-- Select top 100 * from ntp.Stage.ntp_log where logger = 'Paul_ssis_TEST'
--update a set a.Status = 'To_Be_Processed'
--from Lien.dbo.PET_APN_Additional_Formats a
--where a.fips =  @fips and a.apn_type =  @apn_type

/*----------------------------------
  Add Missing APN_Types
  ----------------------------------*/
--  INSERT INTO PEt.dbo.PET_FIPS_APN_Type (
--	FIPS
--	,APN_TYPE
--	,NEO_APN
--	,UNQ_Match
--	,CREATED
--	)
--SELECT a.Fips
--	,a.Apn_type
--	,CASE WHEN a.Apn_Type like 'n_%' Then 1 ELSE 0 end AS Neo_APn
--	,CASE WHEN a.Apn_Type Not like 'n_%' Then 1 ELSE 0 end AS UNQ_Match
--	,GETDATE() AS Created
--FROM PEt.dbo.PET_APN_Additional_Formats a
--WHERE a.fips = 06029
--	AND NOT EXISTS (
--		SELECT *
--		FROM PEt.dbo.PET_FIPS_APN_Type a
--		WHERE fips = a.fips
--			AND apn_type = a.Apn_type
--		)



SELECT @Source_Apn = a.Source_Apn
	,@Rule = a.[Rule]
	,@node_delimeter = a.Node_delimeter
--select top 10 * 
FROM PEt.dbo.PET_APN_Additional_Formats a
WHERE a.fips = @fips
	AND a.APN_Type = @apn_type

SET @node_delimeter = CASE when @node_delimeter is null then ' ' else @node_delimeter end 

SET @sql_cmd = N'
DROP TABLE if exists Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source1

SELECT  A.[FIPS]
	,a.[REF_ID]
	,a.' + @Source_apn + ' as apn
	,a.Unformatted_apn
	,a.original_apn
	,a.Alternate_apn
	,a.MUNICIPALITY_CODE
	,a.MUNICIPALITY_NAME
	
into Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source1
FROM [Assr].[dbo].[Assr] a with (nolock) 

WHERE fips = ' + try_cast(@fips AS VARCHAR) + '


DROP TABLE if exists Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source

SELECT  a.*
	,ROW_NUMBER( ) OVER ( PARTITION BY a.apn  ORDER BY ( SELECT 0 ) ) AS ROW4
	,aa.*

into Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source
FROM Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source1 a
outer apply (SELECT node1,node2,node3,node4,node5,node6,node7,node8,node9,node10  FROM  spdb.[dbo].[fn_get_apn_nodes] (a.apn,''' + @node_delimeter + 
	''')
) aa

create clustered index ixa on Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source (REf_id)

Delete from Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source where ref_id in (
Select distinct Ref_id from Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source where row4 > 1
)

DROP TABLE if exists pet.dbo.Pet_apn_additions

CREATE TABLE [PET].[dbo].[Pet_apn_additions](
	[REF_ID] [numeric](12, 0) NOT NULL,
	[FIPS] [int] NOT NULL,
	[APN_Type] [varchar](10) NULL,
	[APN_ID] [numeric](12, 0) NULL,
	[APN] [varchar](60) NULL,
	[created] [datetime] NULL,
	[updated] [datetime] NULL
) ON [PRIMARY]


create index ixa on pet.dbo.Pet_apn_additions (APN)



INSERT INTO pet.dbo.Pet_apn_additions
           ([REF_ID]
           ,[FIPS]
           ,[APN_Type]
           ,[APN_ID]
           ,[APN]
           ,[created]
           ,[updated]
           )
SELECT a.[REF_ID]
      ,a.[FIPS]
      ,''' + @APN_Type + 
	''' as [APN_Type]
      ,0 as [APN_ID]
      ,b._new_apn as [APN]
      ,getdate() as [created]
      ,getdate() as [updated]
  FROM Pet.Pet_tmp.usp_PEt_Apn_Creation_1_sql03_Source a
  OUTER APPLY (
	SELECT CASE 
			' + @Rule + '
			ELSE NULL
			END AS _new_apn
	) b
  where b._new_apn is not null



'

IF @list_Sql = 1
BEGIN
	SELECT @sql_cmd
END

IF @list_Sql = 0
BEGIN
	EXEC (@sql_cmd)
END
		--EXEC ntp.Stage.[AddNtpLog] N'info'
		--	,N'usp_PEt_Apn_Creation_1 END'
		--	,@mess


