SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[999_DigitalMap_Update] @fips varchar(5)
AS
BEGIN
	SET NOCOUNT OFF;

INSERT INTO [DigitalMap].[dbo].[FADigitalMap_Update_20220801_Special]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InHJ2]
		   ,TAXAPN)
Select
            null  --<FADigitalMapMasterId, int,>
           ,[PropertyDI2]  --<PropertyID, bigint,>
           ,null  --<APN, varchar(45),>
           ,p.[FIPS]  --<FIPS, varchar(5),>
           ,[XCOORD]  --<Longitude, float,>
           ,[YCOORD]  --<Latitude, float,>
           ,p.[GEOG]  --<ParcelGeography, geography,>
           ,p.[GEOM4269]  --<ParcelGeometry, geometry,>
           ,pp.[GEOG]  --<ParcelPointGeography, geography,>
           ,pp.[GEOM4269]   --<ParcelPointGeometry, geometry,>
           ,geography::STGeomFromText(((geometry::STGeomFromText(p.[GEOM4269].STAsText(),4269)).MakeValid().STUnion((geometry::STGeomFromText(p.[GEOM4269].STAsText(),4269)).STStartPoint()).STAsText()), 4269).MakeValid().STArea() * 10.7639  --<EstLotSizeSqFt, bigint,>
           ,[ADDRSCORE]  --<AddressScore, varchar(1),>
           ,[GEOSOURCE]  --<GeoSource, varchar(30),>
           ,p.[PARCELAPN]  --<PARCELAPN, varchar(50),>
           ,'Parcels'  --<FAGeoStatusCode, varchar(20),>
           ,null  --<LatLonGeometry, geometry,>
           ,'20220531'  --<DmDate, varchar(8),>
           ,[Match2]  --<MatchCode, varchar(20),>
           ,null  --<UpdateFlag, varchar(16),>
           ,null  --<RefId, bigint,>
           ,PRCLDMPID  --<PRCLDMPID, varchar(50),>
           ,PROPDMPID  --<PROPDMPID, varchar(50),>
           ,geometry::STGeomFromText(p.[GEOM4269].STAsText(),4269)  --<ParcelGeometry4269, geometry,>
           ,geometry::STGeomFromText(pp.[GEOM4269].STAsText(),4269)  --<ParcelPointGeometry4269, geometry,>
           ,GetDate()  --<FATimestamp, datetime,>
           ,(geometry::STGeomFromText(p.[GEOM4269].STAsText(),4269)).MakeValid().STUnion((geometry::STGeomFromText(p.[GEOM4269].STAsText(),4269)).STStartPoint()).STAsText()  --<GeomWKT, varchar(max),>
           ,null  --<UCIDFlag, char(1),>4269
           ,(geometry::STGeomFromText(pp.[GEOM4269].STAsText(),4269)).MakeValid().STUnion((geometry::STGeomFromText(pp.[GEOM4269].STAsText(),4269)).STStartPoint()).STAsText()  --<PointWKT, varchar(max),>
           ,null  --<IsCondo, varchar(5),>
           ,null  --<InHJ, varchar(5),>
           ,null  --<InHJ2, varchar(5),>)
		   ,TAXAPN
  FROM [DigitalMap].[dbo].[Parcel_20220801_Special] p
  left join [DigitalMap].[dbo].[ParcelPoint_20220801_Special] pp
  on pp.fips = p.fips
  and pp.PARCELAPN = p.PARCELAPN
  where p.fips = @Fips
  and [GEOSOURCE] = 'parcels'

  ----   

INSERT INTO [DigitalMap].[dbo].[FADigitalMap_Update_20220801_Special_FipsRun]
           ([FIPS],[Run])
 Select @Fips, '1'



END


