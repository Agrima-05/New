SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[zPropertyRollup] 
AS
BEGIN

	SET NOCOUNT ON;


-----------STEP 1

		DECLARE @Fips varchar(5)

		DECLARE curPropPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM Global.dbo.County
			WHERE [STATE] in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
			--and FIPSCode >= '26155'
			ORDER BY [FIPSCode]


		OPEN curPropPost   
		FETCH NEXT FROM curPropPost INTO @Fips

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @Fips

			EXEC('update p
			  set [SPOT_ID] = [FADigitalMapMasterId]
			  ,p.FALatitude = s.[CentroidLatitude]
			  ,p.FALongitude = s.[CentroidLongitude]
			  ,p.FAGeoStatusCode = ''P''
			  ,p.FAUserid = ''FAGeoStatusUpdate''
			  from data.dbo.property p
			  join [Boundaries].[dbo].[FASpot] s
				on s.fips = p.fips
					and s.propertyid = p.propertyid
			  where (p.FAGeoStatusCode is NULL OR p.FALongitude != s.CentroidLongitude)
				and s.UCIDFlag <> ''D''
					and p.fips = ' + @Fips + '
						and s.Fips = ' + @Fips + '
			  ')


			  EXEC('update p
			  set [SPOT_ID] = [FADigitalMapMasterId]
			  ,p.FALatitude = s.[CentroidLatitude]
			  ,p.FALongitude = s.[CentroidLongitude]
			  ,p.FAGeoStatusCode = ''P''
			  ,p.FAUserid = ''FAGeoStatusUpdate''
			from data..property p
			  join [Boundaries].[dbo].[FASpot_Generated] s
				on s.fips = p.fips
					and s.propertyid = p.propertyid
			  where (p.FAGeoStatusCode is NULL OR p.FALongitude != s.CentroidLongitude)
				and s.UCIDFlag <> ''D''
					and p.fips = ' + @Fips + '
						and s.Fips = ' + @Fips + '
			  ')


			FETCH NEXT FROM curPropPost INTO @Fips 
		END   

		CLOSE curPropPost   
		DEALLOCATE curPropPost 

END

