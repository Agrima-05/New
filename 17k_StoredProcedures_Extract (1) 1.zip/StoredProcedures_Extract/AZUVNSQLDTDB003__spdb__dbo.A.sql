﻿/* Source: AZUVNSQLDTDB003.datatree.local | SPDB | dbo.A | type=P */
CREATE procedure A
AS
BEGIN
SELECT TOP 1             [ProjectID]     
                                                          ,   A.[TaskID]  
                                                          , A.[DocumentRecordID]
                                        FROM (SELECT PR.[ProjectID],5 [TaskID],(SELECT TOP 1 [DocumentRecordID] FROM (
                                                                                                          SELECT  [DocumentRecordID] FROM [EPR_NDE].[dbo].[ProjectDocuments] PD 
                                                                                                          WHERE PD.[ProjectID] = PR.[ProjectID] AND PD.[StatusID] =11 AND PD.[IsSequence]=0 AND PD.[IsChildSequence]=0 AND (PD.[IsFinalEditKickOut]=1 OR PD.[IsPreTransmissionQC]=1)
                                                                                                          AND ((PR.[IsVendorPool]=1 AND PD.[VendorID]=VP.[VendorID]) OR (PR.[IsVendorPool]=0))
                                                                                                          AND NOT EXISTS (
                                                                                                                   SELECT JA.[DocumentRecordID] FROM [EPR_NDE].[dbo].[JobAssignmentQueue] JA WITH(NOLOCK)               
                                                                                                                   WHERE  JA.[DocumentRecordID]=PD.[DocumentRecordID] AND JA.[StatusID]=3 --AND JA.[AssignedTo]=@UserID
																												   )
                                                                                                          ) B ORDER BY [DocumentRecordID]) [DocumentRecordID],PR.[DateReceived],[CALICORW].[svfRemoveNonNumericCharacter](PR.[StartRange])  [StartRange] 
                                                     FROM          [EPR_NDE].[dbo].[Project]              PR 
                                                     INNER JOIN  [EPR_NDE].[dbo].[VendorProject]      VP  WITH(NOLOCK) ON  PR.[ProjectID]=VP.[ProjectID]
                                                     WHERE PR.[StatusID] IN (10,30) --AND VP.[VendorID]=@VendorID 
													 AND PR.[KeyingProcessID]=1 AND PR.[IsActive]=1 --AND (@IsPreQC=1)
                                                     UNION ALL
                                                     SELECT PR.[ProjectID],3 [TaskId],(SELECT TOP 1 [DocumentRecordID] FROM(   
                                                                                                SELECT [DocumentRecordID],SUM([QRequiredCount]) [QCount],SUM([AWRequiredCount]) [AWCount]              
                                                                                                FROM              
                                                                                                ( SELECT  PQ.[DocumentRecordID],COUNT(PQ.[ElementGroupID]) [QRequiredCount],0           [AWRequiredCount]              
                                                                                                     FROM       [EPR_NDE].[dbo].[ProjectDocuments]  PD        
                                                                                                     INNER JOIN [EPR_NDE].[dbo].[JobAssignmentQueue] PQ       ON PD.[DocumentRecordID]=PQ.[DocumentRecordID] AND PQ.[TaskId]=3 AND PQ.[StatusID]=6 AND PQ.[AssignedTo] IS NULL
                                                                                                    WHERE PD.[ProjectID]=PR.[ProjectID] AND (PD.[StatusID]=9-- OR (@IsSD=1 AND PD.[StatusID]=28)
																									) 
																									AND ((PR.[IsVendorPool]=1 AND PD.[VendorID]=VP.[VendorID]) OR (PR.[IsVendorPool]=0))
                                                                                                    GROUP BY PQ.[DocumentRecordID]              
                                                                                                     UNION ALL                
                                                                                                     SELECT  PQ.[DocumentRecordID],0 [QRequiredCount],COUNT(PQ1.[ElementGroupID]) [AWRequiredCount]              
                                                                                                     FROM       [EPR_NDE].[dbo].[ProjectDocuments]    PD           
                                                                                                     INNER JOIN [EPR_NDE].[dbo].[JobAssignmentQueue]  PQ  ON  PD.[DocumentRecordID]=PQ.[DocumentRecordID] AND PQ.[TaskId]=3 AND PQ.[StatusID]=6 AND PQ.[AssignedTo] IS NULL            
                                                                                                     INNER JOIN [EPR_NDE].[dbo].[JobAssignmentQueue]  PQ1 ON  PQ.[DocumentRecordID]=PQ1.[DocumentRecordID] AND PQ1.[TaskId]=2 AND PQ.[ElementGroupID]=PQ1.[ElementGroupID] AND PQ.[SequenceID]=PQ1.[SequenceID] AND PQ1.[StatusID]=3 --AND PQ1.[AssignedTo]<>@UserID          
                                                                                                     WHERE PD.[ProjectID]=PR.[ProjectID] AND (PD.[StatusID]=9 --OR (@IsSD=1 AND PD.[StatusID]=28)
																									 ) AND ((PR.[IsVendorPool]=1 AND PD.[VendorID]=VP.[VendorID]) OR (PR.[IsVendorPool]=0))         
                                                                                                     AND NOT EXISTS (SELECT 1 FROM [EPR_NDE].[dbo].[JobAssignmentQueue]  PQ2               
                                                                                                      WHERE  PQ2.[DocumentRecordID]=PQ1.[DocumentRecordID] AND PQ2.[TaskId]=1 AND PQ1.[ElementGroupID]=PQ2.[ElementGroupID] AND PQ2.[StatusID]=3-- AND PQ2.[AssignedTo]=@UserID
																									  )              
                                                                                                    GROUP BY PQ.[DocumentRecordID]            
                                                                                               )A GROUP BY [DocumentRecordID])B              
                                                                                                WHERE  B.[QCount]=B.[AWCount] ORDER BY NEWID())[DocumentRecordID]
                                                                                                ,PR.[DateReceived],[CALICORW].[svfRemoveNonNumericCharacter](PR.[StartRange]) 
                                                 FROM         [EPR_NDE].[dbo].[Project]                PR 
                                                 INNER JOIN  [EPR_NDE].[dbo].[VendorProject]      VP  WITH(NOLOCK) ON  PR.[ProjectID]=VP.[ProjectID]
                                                 WHERE PR.[StatusID] IN (10,30)-- AND VP.[VendorID]=@VendorID 
												 AND PR.[KeyingProcessID]=1 AND PR.[IsActive]=1 --AND (@IsRC=1)
                                                 UNION ALL
                                                 SELECT PR.[ProjectID],2 [TaskId],(SELECT TOP 1 A.[DocumentRecordID] FROM               
                                                                                                          (  SELECT PQ.[DocumentRecordID],COUNT(PQ.[ElementGroupID]) RequiredCount,COUNT(CASE WHEN PQ1.[DocumentRecordID] IS NOT NULL THEN 1 END) AvailableCount              
                                                                                                             FROM  [EPR_NDE].[dbo].[ProjectDocuments] PD         
                                                                                                             INNER JOIN [EPR_NDE].[dbo].[JobAssignmentQueue] PQ   ON PD.[DocumentRecordID]=PQ.[DocumentRecordID]   AND  PQ.[TaskId]=1 
                                                                                                             INNER JOIN [EPR_NDE].[dbo].[JobAssignmentQueue] PQ2  ON PQ.[DocumentRecordID]=PQ2.[DocumentRecordID]  AND PQ2.[TaskID]=2 AND PQ2.[ElementGroupID]=0 AND PQ2.[StatusID]=6 AND PQ2.[AssignedTo] IS NULL 
                                                                                                             LEFT  JOIN [EPR_NDE].[dbo].[JobAssignmentQueue] PQ1  ON PQ.[DocumentRecordID]=PQ1.[DocumentRecordID]  AND  PQ1.[TaskId]=PQ.[TaskID] AND PQ1.[ElementGroupID]=PQ.[ElementGroupID] AND PQ1.[SequenceID]=PQ.[SequenceID] AND PQ1.[StatusID]=3 --AND PQ1.[AssignedTo]<>@UserID
                                                                                                             WHERE PD.[ProjectID]=PR.[ProjectID] AND        PD.[StatusID]=9 AND ((PR.[IsVendorPool]=1 AND PD.[VendorID]=VP.[VendorID]) OR (PR.[IsVendorPool]=0))
                                                                                                             GROUP BY PQ.[DocumentRecordID] 
                                                                                                           ) A              
                                                                                                          WHERE A.[RequiredCount]=A.[AvailableCount]              
                                                                                                          ORDER BY NEWID()) [DocumentRecordID],PR.[DateReceived],[CALICORW].[svfRemoveNonNumericCharacter](PR.[StartRange])  [StartRange]
                                               FROM          [EPR_NDE].[dbo].[Project]              PR 
                                               INNER JOIN  [EPR_NDE].[dbo].[VendorProject]      VP  WITH(NOLOCK) ON  PR.[ProjectID]=VP.[ProjectID]
                                               WHERE PR.[StatusID]=10 --AND VP.[VendorID]=@VendorID 
											   AND PR.[KeyingProcessID]=1  AND PR.[IsActive]=1 --AND @IsDV=1
                                               UNION ALL
                                               SELECT PR.[ProjectID],1 [TaskId],(SELECT TOP 1 PD.[DocumentRecordID]         
                                                                                                      FROM         [EPR_NDE].[dbo].[ProjectDocuments]   PD         
                                                                                                      INNER JOIN  [EPR_NDE].[dbo].[JobAssignmentQueue] PQ ON PD.[DocumentRecordID]=PQ.[DocumentRecordID] AND  PQ.[TaskId]=1 AND PQ.[ElementGroupID]=0
                                                                                                      WHERE PD.[ProjectID]=PR.[ProjectID] AND PD.[StatusID] IN (9,10)  AND PQ.[StatusID]=6 AND PQ.[AssignedTo] IS NULL
                                                                                                      ORDER BY NEWID()) [DocumentRecordID],PR.[DateReceived],[CALICORW].[svfRemoveNonNumericCharacter](PR.[StartRange]) [StartRange]
                                               FROM          [EPR_NDE].[dbo].[Project]              PR 
                                               INNER JOIN  [EPR_NDE].[dbo].[VendorProject]      VP  WITH(NOLOCK) ON  PR.[ProjectID]=VP.[ProjectID]
                                               WHERE PR.[StatusID]=10-- AND VP.[VendorID]=@VendorID 
											   AND PR.[KeyingProcessID]=1 AND PR.[IsActive]=1 --AND (@IsDE=1)
                                               )A
                                               WHERE    A.[DocumentRecordID] IS NOT NULL
                                               ORDER BY   A.[DateReceived],A.[TaskID],[CALICORW].[svfRemoveNonNumericCharacter](A.[StartRange])
											   END

