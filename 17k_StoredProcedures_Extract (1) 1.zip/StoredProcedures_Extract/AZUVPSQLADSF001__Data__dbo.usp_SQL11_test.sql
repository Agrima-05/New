SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

CREATE PROCEDURE [dbo].[usp_SQL11_test] 
AS
BEGIN

--use @T_DATABASE;

SET NOCOUNT ON

select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (both tables)
--select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (no table on SQL11)
--select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (no table on DTDB010)

--select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (both tables)
--select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (no table on SQL11)
--select count(*) from [SNAPNSQLDTDB010.datatree.local].[WRice].[dbo].[FloorCover] -- 21373356 (no table on DTDB010)

SET NOCOUNT OFF

END

