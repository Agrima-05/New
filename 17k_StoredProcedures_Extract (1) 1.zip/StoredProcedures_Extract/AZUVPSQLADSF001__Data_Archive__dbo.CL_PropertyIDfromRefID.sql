SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create PROCEDURE [dbo].[CL_PropertyIDfromRefID](@fips as varchar(5))
AS
BEGIN

  update [Data_Archive].[dbo].[AssrArchive_CL]
  Set [PropertyID] = p.propertyid
  from [Data_Archive].[dbo].[AssrArchive_CL] a
  join data..property p with (nolock)
  on p.fips = a.fipscode
  and p.dtdb_ref_id = a.ref_id
  where FipsCode = @fips
  and a.propertyid is null
--v.AssdYear = '2016'

INSERT INTO [Data_Archive].[dbo].[CLPropertyID]
           ([FIPS]
           ,[cnt])
 Select @fips, 1

END

