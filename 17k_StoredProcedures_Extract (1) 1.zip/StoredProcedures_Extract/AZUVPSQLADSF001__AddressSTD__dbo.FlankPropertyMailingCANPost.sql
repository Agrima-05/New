SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankPropertyMailingCANPost] (@tableName varchar(40)) -- @tableName = 'Property_Mailing' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild MailingStdFullStreetAddress and MailingCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Property_MailingCAN_STD]
	   --set [MailingStdFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdMode]))) + '' '' + [AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitNbr])))))))
       set [MailingStdFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitNbr]))))
	   ,[MailingStdHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdHouseNbr]))
       ,[MailingStdDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionLeft]))
       ,[MailingStdStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdStreet])))
       ,[MailingStdMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdMode])))
       ,[MailingStdDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdDirectionRight]))
       ,[MailingStdUnitNbr] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitNbr]))
       ,[MailingStdCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdCity])))
       ,[MailingStdState] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdState]))
       ,[MailingStdZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdZIP5]))
       --,[MailingStdZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdZIP4]))
       ,[MailingStdCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdCarrierCode]))
	   ,[MailingCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingCensusTract]))
       ,[MailingStdUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdUnitType])))
       ,[MailingStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingStdMatchCode]))
       ,[MailingDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingDPVCount]))
       ,[MailingDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingDPVFootnote]))
       ,[MailingLACS] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingLACS]))
       ,[MailingLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingLACSLinkInd]))
       ,[MailingDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingDPCheckDigit]))
       ,[MailingDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingDPCheckCode]))
       ,[MailingCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingCensusBlock]))
       ,[MailingGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingGeoErrorCode]))
       ,[MailingGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingGeoStatusCode]))
       ,[MailingGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Property_MailingCAN_STD].[MailingGeoCodeResults]))
     From [AddressSTD].[dbo].[Property_MailingCAN_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Property_MailingCAN_to_Licensing
