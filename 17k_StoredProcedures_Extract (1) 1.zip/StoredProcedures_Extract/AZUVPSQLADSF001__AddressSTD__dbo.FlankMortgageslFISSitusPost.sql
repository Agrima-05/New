SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankMortgageslFISSitusPost] (@tableName varchar(40)) 
as  
declare @sql varchar(max) 

-- Trim all fields, make some fields uppdercase, rebuild SitusFullStreetAddress and SitusCensusTractBlock fields
    set @sql = 'UPDATE [AddressSTD].[dbo].[Mortgage_sl_FIS_Situs_STD]
       set [SitusFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([SitusHouseNbr])) + '' '' + [SitusDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([SitusStreet])))) + '' '' + ltrim(rtrim(UPPER([SitusMode])))) + '' '' + ltrim(rtrim(UPPER([SitusDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([SitusUnitType])))) + '' '' + ltrim(rtrim([SitusUnitNbr]))))
	   ,[SitusHouseNbr]  = ltrim(rtrim([SitusHouseNbr]))
       ,[SitusDirectionLeft] = ltrim(rtrim([SitusDirectionLeft]))
       ,[SitusStreet] = UPPER(ltrim(rtrim([SitusStreet])))
       ,[SitusMode] = UPPER(ltrim(rtrim([SitusMode])))
       ,[SitusDirectionRight] = ltrim(rtrim([SitusDirectionRight]))
       ,[SitusUnitNbr] = ltrim(rtrim([SitusUnitNbr]))
       ,[SitusCity] = UPPER(ltrim(rtrim([SitusCity])))
       ,[SitusState] = ltrim(rtrim([SitusState]))
       ,[SitusZIP5] = ltrim(rtrim([SitusZIP5]))
       ,[SitusZIP4] = ltrim(rtrim([SitusZIP4]))
       ,[SitusLatitude] = ltrim(rtrim([SitusLatitude]))
       ,[SitusLongitude] = ltrim(rtrim([SitusLongitude]))
       ,[SitusCarrierCode] = ltrim(rtrim([SitusCarrierCode]))
	   ,[SitusCensusTract] = ltrim(rtrim([SitusCensusTract]))
       ,[SitusCensusTractBlock] = ltrim(rtrim([SitusCensusTract])) + ltrim(rtrim([SitusCensusBlock]))
       ,[SitusUnitType] = UPPER(ltrim(rtrim([SitusUnitType])))
       ,[SitusMatchCode] = ltrim(rtrim([SitusMatchCode]))
       ,[SitusDPVCount] = ltrim(rtrim([SitusDPVCount]))
       ,[SitusDPVFootnote] = ltrim(rtrim([SitusDPVFootnote]))
       ,[SitusLACS] = ltrim(rtrim([SitusLACS]))
       ,[SitusLACSLinkInd] = ltrim(rtrim([SitusLACSLinkInd]))
       ,[SitusDPCheckDigit] = ltrim(rtrim([SitusDPCheckDigit]))
       ,[SitusDPCheckCode] = ltrim(rtrim([SitusDPCheckCode]))
       ,[SitusCensusBlock] = ltrim(rtrim([SitusCensusBlock]))
       ,[SitusGeoErrorCode] = ltrim(rtrim([SitusGeoErrorCode]))
       ,[SitusGeoStatusCode] = ltrim(rtrim([SitusGeoStatusCode]))
       ,[SitusGeoCodeResults] = ltrim(rtrim([SitusGeoCodeResults]))
    '
--print @sql
exec (@sql)
exec global.dbo.usp_ASP_Mortgage_sl_FIS_Situs_to_Licensing
