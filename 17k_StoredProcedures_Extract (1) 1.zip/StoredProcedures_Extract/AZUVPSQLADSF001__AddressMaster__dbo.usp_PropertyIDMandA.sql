SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- PropertyID MandA
-- =============================================
CREATE PROCEDURE dbo.usp_PropertyIDMandA

AS
BEGIN

	SET NOCOUNT ON;

  EXEC [zCust_ADS__00_SharedProcs].[dbo].[usp_100d_PropID_Match_Work_V8_FLANK_AddrMaster] 

END

