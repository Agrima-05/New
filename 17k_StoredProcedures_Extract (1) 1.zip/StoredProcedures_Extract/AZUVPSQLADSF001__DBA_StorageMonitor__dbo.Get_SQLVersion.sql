SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE  PROCEDURE   [dbo].[Get_SQLVersion]

AS

TRUNCATE TABLE DBA_StorageMonitor.dbo.SQL_Version;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON

BEGIN

Insert into DBA_StorageMonitor.dbo.SQL_Version(
 ServerName,SQLserver,SQLVersion,[SQLProductUpdate],SQLProductBuildType,Edition,ProductVersion,KBversion,OSVersion,Record_InsertedOn)


SELECT left(@@servername,15) AS ServerName,
  CASE 
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '8%' THEN 'SQL2000'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '9%' THEN 'SQL2005'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '10.0%' THEN 'SQL2008'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '10.5%' THEN 'SQL2008 R2'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '11%' THEN 'SQL2012'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '12%' THEN 'SQL2014'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '13%' THEN 'SQL2016'    
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '14%' THEN 'SQL2017'
     WHEN CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) like '15%' THEN 'SQL2019'
     ELSE 'unknown'
  END AS SQLserver,
   convert(varchar(50),SERVERPROPERTY('ProductLevel')) AS SQLVersion,
   convert(varchar(50),SERVERPROPERTY('ProductUpdateLevel')) AS [SQLProductUpdate],
   convert(varchar(50),SERVERPROPERTY('ProductBuildType')) as SQLProductBuildType,
  convert(varchar(50),SERVERPROPERTY('Edition')) AS Edition,
  convert(varchar(50),SERVERPROPERTY('productversion')) AS ProductVersion,
   convert(varchar(50),  SERVERPROPERTY('ProductUpdateReference')) AS KBversion,
  SUBSTRING(@@VERSION,CHARINDEX('Windows',@@VERSION,0),100) AS OSVersion,
  convert(varchar, getdate(), 110) as Record_InsertedOn 

END





