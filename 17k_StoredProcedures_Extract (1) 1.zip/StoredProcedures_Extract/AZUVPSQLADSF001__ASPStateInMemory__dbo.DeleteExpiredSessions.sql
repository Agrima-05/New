SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

--
-- A job must be created to delete expired sessions.
--
CREATE PROCEDURE dbo.DeleteExpiredSessions
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()
	DECLARE @SessionId AS nvarchar(88)
	DECLARE @ExpiredSessions AS dbo.SessionIdTable

	INSERT INTO @ExpiredSessions(SessionId)
	SELECT SessionId
	FROM dbo.Sessions
	WHERE Expires < @Now

	SELECT TOP 1
		@SessionId = SessionId
	FROM @ExpiredSessions

	WHILE @@ROWCOUNT > 0
	BEGIN
		DELETE dbo.Sessions WHERE SessionId = @SessionId
		DELETE dbo.SessionItems WHERE SessionId = @SessionId
		
		-- Get the next expired session.

		DELETE @ExpiredSessions WHERE SessionId = @SessionId

		SELECT TOP 1
			@SessionId = SessionId
		FROM @ExpiredSessions
	END
END

