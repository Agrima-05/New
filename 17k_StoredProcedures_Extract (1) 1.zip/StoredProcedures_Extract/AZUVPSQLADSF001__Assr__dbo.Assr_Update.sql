SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[Assr_Update]

AS
BEGIN

	SET NOCOUNT ON;

--UPDATE a
--SET  a.[Lic_PropertyID] = NULL
--      ,a.[Lic_StreetNum] = NULL
--      ,a.[Lic_StreetName] = NULL
--      ,a.[Lic_APN] = NULL
--      ,a.[Lic_OwnerLastName] = NULL
--      ,a.[Lic_Zip5] = NULL
--      ,a.[Lic_AccountNbr] = NULL
--      ,a.[Lic_Fips] = NULL
--      ,a.[Lic_DTDB_Match_Flag] = NULL
----Select Count(*) 
--FROM Assr.dbo.ASSR a LEFT OUTER JOIN Data.dbo.Property b with(NOLOCK)
--on a.Lic_PropertyID = b.PropertyID
--WHERE b.PropertyID is NULL 


INSERT INTO [ASSR].[dbo].[Assr]
           ([FIPS]
           ,[REF_ID]
           ,[UNFORMATTED_APN]
           ,[APN_SEQUENCE_NBR]
           ,[FORMATTED_APN]
           ,[ORIGINAL_APN]
           ,[PREVIOUS_PARCEL_NBR]
           ,[P_ID_IRIS_FRMTD]
           ,[ALTERNATE_APN]
           ,[ACCOUNT_NBR]
           ,[SITUS_HOUSE_NBR]
           ,[SITUS_HOUSE_NBR_#2]
           ,[SITUS_HOUSE_NBR_SUFFIX]
           ,[SITUS_DIRECTION]
           ,[SITUS_STREET_NAME]
           ,[SITUS_MODE]
           ,[SITUS_QUADRANT]
           ,[SITUS_UNIT_NBR]
           ,[SITUS_CITY]
           ,[SITUS_STATE]
           ,[SITUS_ZIP_CODE]
           ,[SITUS_CARRIER_CODE]
           ,[OWN1_LAST_NAME]
           ,[OWN1_FIRST_NAME_M_I]
           ,[OWN1_SUFFIX]
           ,[Situs_Street_Num_Fmt]
           ,[Situs_Zip_5])
 
 select 
            [FIPS]
           ,[REF_ID]
           ,[UNFORMATTED_APN]
           ,[APN_SEQUENCE_NBR]
           ,[FORMATTED_APN]
           ,[ORIGINAL_APN]
           ,[PREVIOUS_PARCEL_NBR]
           ,[P_ID_IRIS_FRMTD]
           ,[ALTERNATE_APN]
           ,[ACCOUNT_NBR]
           ,[SITUS_HOUSE_NBR]
           ,[SITUS_HOUSE_NBR_#2]
           ,[SITUS_HOUSE_NBR_SUFFIX]
           ,[SITUS_DIRECTION]
           ,[SITUS_STREET_NAME]
           ,[SITUS_MODE]
           ,[SITUS_QUADRANT]
           ,[SITUS_UNIT_NBR]
           ,[SITUS_CITY]
           ,[SITUS_STATE]
           ,[SITUS_ZIP_CODE]
           ,[SITUS_CARRIER_CODE]
           ,[OWN1_LAST_NAME]
           ,[OWN1_FIRST_NAME_M_I]
           ,[OWN1_SUFFIX]
           ,ltrim(rtrim(SUBSTRING(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20), PATINDEX('%[^0]%', Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20)+'.'), LEN(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20)))))
           ,substring(d.[SITUS_ZIP_CODE],1,5)
 from [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] d
 where d.[REF_ID] > (select max(ref_id) FROM [Assr].[dbo].[Assr])


Update [Assr]
set    [SITUS_HOUSE_NBR] = d.[SITUS_HOUSE_NBR]
      ,[SITUS_HOUSE_NBR_#2] = d.[SITUS_HOUSE_NBR_#2]
      ,[SITUS_HOUSE_NBR_SUFFIX] = d.[SITUS_HOUSE_NBR_SUFFIX]
      ,[SITUS_DIRECTION] = d.[SITUS_DIRECTION]
      ,[SITUS_STREET_NAME] = d.[SITUS_STREET_NAME]
      ,[SITUS_MODE] = d.[SITUS_MODE]
      ,[SITUS_QUADRANT] = d.[SITUS_QUADRANT]
      ,[SITUS_UNIT_NBR] = d.[SITUS_UNIT_NBR]
      ,[SITUS_CITY] = d.[SITUS_CITY]
      ,[SITUS_STATE] = d.[SITUS_STATE]
      ,[SITUS_ZIP_CODE] = d.[SITUS_ZIP_CODE]
      ,[SITUS_CARRIER_CODE] = d.[SITUS_CARRIER_CODE]
      ,[OWN1_LAST_NAME] = d.[OWN1_LAST_NAME]
      ,[OWN1_FIRST_NAME_M_I] = d.[OWN1_FIRST_NAME_M_I]
      ,[OWN1_SUFFIX] = d.[OWN1_SUFFIX]
      ,[Situs_Street_Num_Fmt]  = ltrim(rtrim(SUBSTRING(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20), PATINDEX('%[^0]%', Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20)+'.'), LEN(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20)))))
      ,[Situs_Zip_5] = substring(d.[SITUS_ZIP_CODE],1,5)
from  assr a
join [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] d
on d.REF_ID = a.REF_ID
where d.[UPDATED] > CONVERT(date, GETDATE()-30)

update assr
set [SITUS_HOUSE_NBR] = ltrim(rtrim(SUBSTRING(Substring(ltrim(rtrim([SITUS_HOUSE_NBR])),1,20), PATINDEX('%[^0]%', Substring(ltrim(rtrim([SITUS_HOUSE_NBR])),1,20)+'.'), LEN(Substring(ltrim(rtrim([SITUS_HOUSE_NBR])),1,20)))))
from [assr]

update assr
set [SITUS_STREET_NAME] = ltrim(rtrim(SUBSTRING(Substring(ltrim(rtrim([SITUS_STREET_NAME])),1,30), PATINDEX('%[^0]%', Substring(ltrim(rtrim([SITUS_STREET_NAME])),1,30)+'.'), LEN(Substring(ltrim(rtrim([SITUS_STREET_NAME])),1,30)))))
from [assr]


INSERT INTO [dbo].[Property_Match]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[APNSeqNbr]
           ,[UnformattedAPN]
           ,[OldAPN]
           ,[OLDAPNSeqNbr]
           ,[TaxAccountNumber]
           ,[VendorPID]
           ,[SitusStdFullStreetAddress]
           ,[SitusStdHouseNbr]
           ,[SitusStdHouseNbr2]
           ,[SitusStdHouseNbrSuffix]
           ,[SitusStdDirectionLeft]
           ,[SitusStdStreet]
           ,[SitusStdMode]
           ,[SitusStdDirectionRight]
           ,[SitusStdUnitNbr]
           ,[SitusStdCity]
           ,[SitusStdState]
           ,[SitusStdZIP5]
           ,[SitusStdZIP4]
           ,[SitusLatitude]
           ,[SitusLongitude]
           ,[OwnerStdNAME1FULL]
           ,[OwnerStdNAME2FULL]
           ,[FipsInt])
 
 Select     [FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[APNSeqNbr]
           ,[UnformattedAPN]
           ,[OldAPN]
           ,[OLDAPNSeqNbr]
           ,[TaxAccountNumber]
           ,[VendorPID]
           ,[SitusStdFullStreetAddress]
           ,[SitusStdHouseNbr]
           ,[SitusStdHouseNbr2]
           ,[SitusStdHouseNbrSuffix]
           ,[SitusStdDirectionLeft]
           ,[SitusStdStreet]
           ,[SitusStdMode]
           ,[SitusStdDirectionRight]
           ,[SitusStdUnitNbr]
           ,[SitusStdCity]
           ,[SitusStdState]
           ,[SitusStdZIP5]
           ,[SitusStdZIP4]
           ,[SitusLatitude]
           ,[SitusLongitude]
           ,[OwnerStdNAME1FULL]
           ,[OwnerStdNAME2FULL]
           ,[Fips]
From [data].[dbo].[Property] p
where p.[PropertyID] > (select max(PropertyID) FROM [Assr].[dbo].[Property_Match])

UPDATE [dbo].[Property_Match]
   SET [FormattedAPN] = p.[FormattedAPN]
      ,[APNSeqNbr] = p.[APNSeqNbr]
      ,[UnformattedAPN] = p.[UnformattedAPN]
      ,[OldAPN] = p.[OldAPN]
      ,[OLDAPNSeqNbr] = p.[OLDAPNSeqNbr]
      ,[TaxAccountNumber] = p.[TaxAccountNumber]
      ,[VendorPID] = p.[VendorPID]
      ,[SitusStdFullStreetAddress] = p.[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr] = p.[SitusStdHouseNbr]
      ,[SitusStdHouseNbr2] = p.[SitusStdHouseNbr2]
      ,[SitusStdHouseNbrSuffix] = p.[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft] = p.[SitusStdDirectionLeft]
      ,[SitusStdStreet] = p.[SitusStdStreet]
      ,[SitusStdMode] = p.[SitusStdMode]
      ,[SitusStdDirectionRight] = p.[SitusStdDirectionRight]
      ,[SitusStdUnitNbr] = p.[SitusStdUnitNbr]
      ,[SitusStdCity] = p.[SitusStdCity]
      ,[SitusStdState] = p.[SitusStdState]
      ,[SitusStdZIP5] = p.[SitusStdZIP5]
      ,[SitusStdZIP4] = p.[SitusStdZIP4]
      ,[SitusLatitude] = p.[SitusLatitude]
      ,[SitusLongitude] = p.[SitusLongitude]
      ,[OwnerStdNAME1FULL] = p.[OwnerStdNAME1FULL]
      ,[OwnerStdNAME2FULL] = p.[OwnerStdNAME2FULL]
      ,[FipsInt] = p.fips
 
 from [Property_Match] a
 join [Data].[dbo].[Property] p on p.fips = a.fips
 and p.propertyid = a.propertyid
 Where p.FATimeStamp > CONVERT(Date, GETDATE()-40)

	Update Assr
	Set [Match_StreetNumber] = 'Y'
	from [assr]
	Where [SITUS_HOUSE_NBR] = [Lic_StreetNum] and Match_Score = 0

	Update Assr
	Set [Match_StreetName] = 'Y'
	from [assr]
	Where Substring([SITUS_STREET_NAME],1,5) = Substring([Lic_StreetName],1,5)  and Match_Score = 0

	Update Assr
	Set [Match_Zip5] = 'Y'
	from [assr]
	Where [Situs_Zip_5] = [Lic_Zip5] and Match_Score = 0

	Update Assr
	Set [Match_Owner] = 'Y'
	from [assr]
	Where substring([OWN1_LAST_NAME],1,5) = Substring([Lic_OwnerLastName],1,5)  and Match_Score = 0

	Update Assr
	Set [Match_APN] = '1'
	from [assr]
	Where [UNFORMATTED_APN] = [Lic_APN] and Match_Score = 0

	Update Assr
	Set [Match_APN] = '2'
	from [assr]
	Where [FORMATTED_APN] = [Lic_APN] and Match_Score = 0

	Update Assr
	Set [Match_APN] = '3'
	from [assr]
	Where [ORIGINAL_APN] = [Lic_APN]  and Match_Score = 0

	Update Assr
	Set [Match_APN] = '4'
	from [assr]
	Where [PREVIOUS_PARCEL_NBR] = [Lic_APN]  and Match_Score = 0

	Update Assr
	Set [Match_APN] = '5'
	from [assr]
	Where [P_ID_IRIS_FRMTD] = [Lic_APN] and Match_Score = 0

	Update Assr
	Set [Match_APN] = '6'
	from [assr]
	Where [ALTERNATE_APN] = [Lic_APN] and Match_Score = 0

	Update Assr
	Set [Match_APN] = '7'
	from [assr]
	Where [ACCOUNT_NBR] = [Lic_APN] and Match_Score = 0

	Update Assr
	Set [Match_AccountNbr] = 'Y'
	from [assr]
	Where [ACCOUNT_NBR] = [Lic_AccountNbr] and Match_Score = 0

	Update Assr
	Set [Match_Score] = Len(ltrim(rtrim(Case when [Match_StreetNumber] is null then '' else [Match_StreetNumber] end +
						Case when [Match_StreetName] is null then '' else [Match_StreetName] end +
						Case when [Match_Zip5] is null then '' else [Match_Zip5] end +
						Case when [Match_APN] is null then '' else [Match_APN] end +
						Case when [Match_Owner] is null then '' else [Match_Owner] end +
						Case when [Match_AccountNbr] is null then '' else [Match_AccountNbr] end)))
	from [assr]
	where  Match_Score = 0


	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'U'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[UNFORMATTED_APN] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'F'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[FORMATTED_APN] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'O'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[ORIGINAL_APN] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'P'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[PREVIOUS_PARCEL_NBR] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'L'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[ALTERNATE_APN] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'T'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips= p.[fips] and a.[ACCOUNT_NBR] = p.[FormattedAPN]
	Where a.Lic_PropertyID is null

	update [assr]
	set [Lic_PropertyID] = p.[PropertyID]
	, [Lic_Fips] = p.[FIPS]
	, [Lic_DTDB_Match_Flag] = 'U'
	,Lic_OwnerLastName = [OwnerStdNAME1FULL]
	,Lic_StreetNum = p.SitusStdHouseNbr
	,Lic_StreetName = p.SitusStdStreet
	,Lic_APN = p.FormattedAPN
	,Lic_Zip5 = SitusStdZIP5
	,Lic_AccountNbr = p.TaxAccountNumber
	from [Data].[dbo].[Property] p with (NoLock)
	join [assr] a on a.fips = p.[fips] and a.[UNFORMATTED_APN] = p.[TaxAccountNumber]
	Where p.FIPS = '48439' and a.Lic_PropertyID is null



----  Formatted APN
    update [Assr].[dbo].[Property_Match] 
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '2'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.FORMATTED_APN = p.Proc_APN
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '8'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.FORMATTED_APN = p.Proc_APN + '-0000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '82'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.FORMATTED_APN = p.Proc_APN + '-000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '83'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.FORMATTED_APN = p.Proc_APN + '-00'
  where p.DTDB_Ref_ID is null

------ Unformatted APN
    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '1'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.Proc_APN
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '18'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.Proc_APN + '0000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '18'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.Proc_APN + '000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '18'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.Proc_APN + '00'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = '18'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.Proc_APN + '0'
  where p.DTDB_Ref_ID is null

----  Unformatted APN to [Proc_APN_NoDashNoDotNoSpace] 

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.[Proc_APN_NoDashNoDotNoSpace]
  where p.DTDB_Ref_ID is null
    
    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O1'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.[Proc_APN_NoDashNoDotNoSpace] + '0000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O2'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.[Proc_APN_NoDashNoDotNoSpace] + '000'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O3'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.[Proc_APN_NoDashNoDotNoSpace] + '00'
  where p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O4'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = p.[Proc_APN_NoDashNoDotNoSpace] + '0'
  where p.DTDB_Ref_ID is null


   update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],3,20)))	                   
  where p.DTDB_Ref_ID is null
  and substring(p.FIPS,1,2) = '01'

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],3,20))) + '0'	                   
  where p.DTDB_Ref_ID is null
  and p.FIPS between '01001' and '01999'

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],3,20))) + '00'	                   
  where p.DTDB_Ref_ID is null
  and p.FIPS between '01001' and '01999'

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],3,20))) + '000'	                   
  where p.DTDB_Ref_ID is null
  and p.FIPS between '01001' and '01999'

  -------------------------------------

    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoSpace],3,20)))	                   
  where p.DTDB_Ref_ID is null
  and p.FIPS = '01119'

-----------------------------------------
    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],4,20)))                
  where p.DTDB_Ref_ID is null
  and p.FIPS = '05051'
-------------------------------------
    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace])) + '0'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06003','06091')

-------------------------------------
    update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace])) + '00'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06045','06105','06109')

---------------------------------
      update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace])) + '000'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06007','06011','06025','06031','06063','06087','06115')

  ---------------------------------
      update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],1,6))) + '0' + ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],7,3))) + '000'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06023')

  ---------------------------------
      update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = '0' + ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],1,20)))
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06027')

---------------------------------
      update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace])) + '11'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06035')

---------------------------------
update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],1,6)))  + ltrim(rtrim(substring([Proc_APN_NoDashNoDotNoSpace],8,2))) + '1'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06103')

update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on format(a.[Fips],'00000') = p.[fips]
  and a.FORMATTED_APN = ltrim(rtrim([FormattedAPN])) + '-1'
  where p.DTDB_Ref_ID is null
  and p.FIPS in ('06103')

-------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = ltrim(rtrim(substring([TaxAccountNumber],2,10)))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('08035', '08039')
   and p.DTDB_Ref_ID is null

update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UnFORMATTED_APN = Proc_APN_FmtWork
  where p.DTDB_Ref_ID is null and FormattedAPN like '%-%'
  and p.FIPS in ('08035', '08039')

-------------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = ltrim(rtrim([TaxAccountNumber]))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('08037','08083')
   and p.DTDB_Ref_ID is null

update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UnFORMATTED_APN = Proc_APN_FmtWork
  where p.DTDB_Ref_ID is null 
  and p.FIPS in ('08037','08083')

----------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = ltrim(rtrim([TaxAccountNumber]))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('08095')
   and p.DTDB_Ref_ID is null

update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.ALTERNATE_APN = Proc_APN_FmtWork
  where p.DTDB_Ref_ID is null 
  and p.FIPS in ('08095')

----------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace(ltrim(rtrim([TaxAccountNumber])), ' ', '')
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('12021')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  where p.FIPS in ('12021')
  and p.DTDB_Ref_ID is null 
  and replace(a.ALTERNATE_APN,' ', '') = Proc_APN_FmtWork

----------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = 'R' + ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace]))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('12093')
   and p.DTDB_Ref_ID is null

update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UnFORMATTED_APN =  Proc_APN_FmtWork
  where p.FIPS in ('12093')
  and  p.DTDB_Ref_ID is null 

----------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace]))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('12093','12101')
   and p.DTDB_Ref_ID is null
   
update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.ALTERNATE_APN = Proc_APN_FmtWork
  where p.FIPS in ('12093','12101')
  and p.DTDB_Ref_ID is null 
  
---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Format(cast(ltrim(rtrim([Proc_APN_NoDashNoDotNoSpace])) as bigint),'000000000000000000')
   ,FipsInt = 12133
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('12133')
   and p.DTDB_Ref_ID is null

   update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UNFORMATTED_APN = Proc_APN_FmtWork
  where p.FIPS in ('12133')
    and p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN_NoDashNoDotNoSpace],1,5) + '00000' + ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],6,20)))
   ,FipsInt = Fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13007','13205')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UNFORMATTED_APN = Proc_APN_FmtWork
  where 
  p.FIPS in ('13007','13205')
  and p.DTDB_Ref_ID is null

 ---------------------------------
    update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN], '-0','-')
   ,FipsInt = 13007
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13015')
   and p.DTDB_Ref_ID is null

     update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.FORMATTED_APN = Proc_APN_FmtWork
  where p.FIPS = '13015'
   and  p.DTDB_Ref_ID is null


    update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN], ' -0','-')
   ,FipsInt = 13015
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13015')
   and p.DTDB_Ref_ID is null

     update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.FORMATTED_APN = Proc_APN_FmtWork
  where p.FIPS = '13015'
    and p.DTDB_Ref_ID is null

    update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN], ' -0','-')
   ,FipsInt = 13015
   from [Assr].[dbo].[Property_Match] p
   where   p.FIPS = '13015'
  and p.DTDB_Ref_ID is null
  and [Proc_APN] like '%[a-z]%'

     update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.FORMATTED_APN = Proc_APN_FmtWork
  where 
  p.FIPS = '13015'
  and p.DTDB_Ref_ID is null
  and [Proc_APN] like '%[a-z]%'

--------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN_NoDashNoDotNoSpace],1,5) + '000' + ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],6,20)))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13031')
   and p.DTDB_Ref_ID is null
   and Proc_APN like '[a-z][a-z]%'

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UnFORMATTED_APN = Proc_APN_FmtWork
  where p.FIPS = '13031'
   and  p.DTDB_Ref_ID is null
   and Proc_APN like '[a-z][a-z]%'

   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN_NoDashNoDotNoSpace],1,4) + '000' + ltrim(rtrim(Substring([Proc_APN_NoDashNoDotNoSpace],5,20)))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13031')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.UnFORMATTED_APN = Proc_APN_FmtWork
  where p.FIPS = '13031'
   and  p.DTDB_Ref_ID is null

-----------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN],' -', ' ')
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13039','13159','13199')
   and p.DTDB_Ref_ID is null

   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN_FmtWork],'-', ' ')
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13039','13159','13199')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13039','13159','13199')
   and  p.DTDB_Ref_ID is null

   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN_FmtWork],1,3) + ' ' + rtrim(Substring([Proc_APN_FmtWork],4,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13039','13159','13199')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13039','13159','13199')
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,4) + ' ' + rtrim(Substring([Proc_APN],5,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13049')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Unformatted_APN = Proc_APN_FmtWork
  where p.FIPS = '13049'
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,4) + '  ' + rtrim(Substring([Proc_APN],5,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13053','13141')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13053','13141')
   and  p.DTDB_Ref_ID is null

--------------------------------------------
  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.ACCOUNT_NBR = TaxAccountNumber
  where p.FIPS = '13057'
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,4) + '   ' + rtrim(Substring([Proc_APN],5,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13085','13111','13183')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Unformatted_APN = Proc_APN_FmtWork
  where p.FIPS in ('13085','13111','13183')
   and  p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.ALTERNATE_APN = Proc_APN_FmtWork
  where p.FIPS in ('13183')
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,5) + '-00000' + rtrim(Substring([Proc_APN],6,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13087')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.formatted_APN = Proc_APN_FmtWork
  where p.FIPS = '13087'
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,4) + '   ' + rtrim(Substring([Proc_APN],5,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13091','13187')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13091','13187')
   and  p.DTDB_Ref_ID is null

   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN],' ','  ')
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13091','13187')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13091','13187')
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,4) + ' ' + rtrim(Substring([Proc_APN],5,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13117')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Unformatted_APN = Proc_APN_FmtWork
  where p.FIPS in ('13117')
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,5) + ' ' + rtrim(Substring([Proc_APN],6,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13123')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Unformatted_APN = Proc_APN_FmtWork
  where p.FIPS in ('13123')
   and  p.DTDB_Ref_ID is null

-----------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Replace([Proc_APN],' -', '')
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13129')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Unformatted_APN = Proc_APN_FmtWork
  where p.FIPS in ('13129')
   and  p.DTDB_Ref_ID is null

---------------------------------
   update [Assr].[dbo].[Property_Match]
   set Proc_APN_FmtWork = Substring([Proc_APN],1,5) + '  ' + rtrim(Substring([Proc_APN],6,20))
   ,FipsInt = fips
   from [Assr].[dbo].[Property_Match] p
   where p.FIPS in ('13155','13213')
   and p.DTDB_Ref_ID is null

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fipsInt]
  and a.Original_APN = Proc_APN_FmtWork
  where p.FIPS in ('13155','13213')
   and  p.DTDB_Ref_ID is null

-----------------------------
  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.ALTERNATE_APN = Proc_APN_NoDashNoDotNoSpace
  where p.FIPS in ('13189')
   and  p.DTDB_Ref_ID is null


   update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'O9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]
  and a.UNFORMATTED_APN = ltrim(rtrim(substring([FormattedAPN],(CHARINDEX('w:',[FormattedAPN],1)+2),3))) +
	                      ltrim(rtrim(substring([FormattedAPN],(CHARINDEX('p:',[FormattedAPN],1)+2),5))) +
	                      ltrim(rtrim(substring([FormattedAPN],(CHARINDEX('s:',[FormattedAPN],1)+2),3)))
  where p.DTDB_Ref_ID is null
  and p.FIPS = '25025'

----------------------

  update [Assr].[dbo].[Property_Match]
  set [DTDB_Ref_ID] = [REF_ID]
     ,[MatchFlag] = 'M9'  --  
  FROM [Assr].[dbo].[Property_Match] p
  join [Assr].[dbo].[ASSR] a
  on a.[Fips] = p.[fips]

  where p.DTDB_Ref_ID is null
  and a.Situs_Street_Num_Fmt = p .SitusStdHouseNbr
  and substring(a.SITUS_STREET_NAME,1,5) = substring(p.SitusStdStreet,1,5)
  and substring(OWN1_LAST_NAME,1,4) = substring(p.OwnerStdNAME1FULL,1,4)
  --and p.FIPS between '25001' and '25999'


  Update Assr
Set [Match_StreetNumber] = 'Y'
from [assr]
Where [SITUS_HOUSE_NBR] = [Lic_StreetNum] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_StreetName] = 'Y'
from [assr]
Where Substring([SITUS_STREET_NAME],1,5) = Substring([Lic_StreetName],1,5) and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_Zip5] = 'Y'
from [assr]
Where [Situs_Zip_5] = [Lic_Zip5] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_Owner] = 'Y'
from [assr]
Where substring([OWN1_LAST_NAME],1,5) = Substring([Lic_OwnerLastName],1,5) and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '1'
from [assr]
Where [UNFORMATTED_APN] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '2'
from [assr]
Where [FORMATTED_APN] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '3'
from [assr]
Where [ORIGINAL_APN] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '4'
from [assr]
Where [PREVIOUS_PARCEL_NBR] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '5'
from [assr]
Where [P_ID_IRIS_FRMTD] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '6'
from [assr]
Where [ALTERNATE_APN] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_APN] = '7'
from [assr]
Where [ACCOUNT_NBR] = [Lic_APN] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_AccountNbr] = 'Y'
from [assr]
Where [ACCOUNT_NBR] = [Lic_AccountNbr] and Lic_DTDB_Match_Flag = 'z'

Update Assr
Set [Match_Score] = Len(ltrim(rtrim(Case when [Match_StreetNumber] is null then '' else [Match_StreetNumber] end +
	                Case when [Match_StreetName] is null then '' else [Match_StreetName] end +
	                Case when [Match_Zip5] is null then '' else [Match_Zip5] end +
	                Case when [Match_APN] is null then '' else [Match_APN] end +
	                Case when [Match_Owner] is null then '' else [Match_Owner] end +
					Case when [Match_AccountNbr] is null then '' else [Match_AccountNbr] end)))
from [assr]
where Lic_DTDB_Match_Flag = 'z'


END

