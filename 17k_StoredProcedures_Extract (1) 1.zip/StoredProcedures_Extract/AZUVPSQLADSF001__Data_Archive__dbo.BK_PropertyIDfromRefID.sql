SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create PROCEDURE [dbo].[BK_PropertyIDfromRefID](@fips as varchar(5))
AS
BEGIN

  update [Data_Archive].[dbo].[AssrArchive_BK]
  Set [PropertyID] = p.propertyid
  from [Data_Archive].[dbo].[AssrArchive_BK] a
  join data..property p with (nolock)
  on p.fips = a.fipscode
  and p.dtdb_ref_id = a.ref_id
  where FipsCode = @fips
  and a.propertyid is null
--v.AssdYear = '2016'

INSERT INTO [Data_Archive].[dbo].[BKPropertyID]
           ([FIPS]
           ,[cnt])
 Select @fips, 1

END

