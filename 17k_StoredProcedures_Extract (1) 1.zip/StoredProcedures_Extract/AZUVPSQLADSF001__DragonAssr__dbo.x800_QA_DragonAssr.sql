SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[x800_QA_DragonAssr] 
AS
BEGIN

--	SET NOCOUNT ON;

			DECLARE @TableName varchar(25)
			DECLARE @Fips varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [name],RIGHT([name],5) as FIPS
			FROM sys.tables
			WHERE [name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]'
			ORDER BY [name]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @TableName,@Fips

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
		PRINT @TableName

		EXEC('Select Count(*) as RefreshRecordCount_' + @TableName + ' from dbo.' + @TableName + ' with(NOLOCK)
		')

		EXEC('Select Count(*) as PropertyRecordCount_' + @TableName + ' from Data.dbo.Property with(NOLOCK) Where FIPS = ''' + @Fips + ''' and FAUCIDFlag != ''D''
		')

		-----If this is most or all of the county STOP
		EXEC('Select Count(*) as NoPropID_' + @TableName + ' from dbo.' + @TableName + ' with(NOLOCK)
		WHERE PROPERTYID is NULL or PROPERTYID = 0
		')

		-----if this number is larger than 1000, Look at the [dbo].[LandUseLookup] table for mapping issues
		EXEC('Select count(*) as NullUseCodes_' + @TableName + '  from dbo.' + @TableName + ' with(NOLOCK) WHERE StdLandUseCode is NULL
		')

		-----If any STOP and look at APNs for issues...might be due to more than 1 seqnbr
		EXEC('Select count(*) as Dups_STOP_CHECK_' + @TableName + ' from dbo.' + @TableName + ' with(NOLOCK)
		WHERE PropertyID in(Select PropertyID from dbo.' + @TableName + ' with(NOLOCK)
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)
		')

		--EXEC('Select Count(*) as NewPropertyIDs_' + @TableName + ' from dbo.' + @TableName + ' with(NOLOCK)
		--WHERE PropertyID in(Select PropertyID FROM dbo.' + @TableName + ' z LEFT OUTER JOIN Data.dbo.Property x ON z.PropertyID = x.PropertyID where x.propertyID is null WHERE x.FIPS = ''' + @Fips + ''')
		--')
		
			FETCH NEXT FROM FmtDocPost INTO @TableName,@Fips   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 



END

