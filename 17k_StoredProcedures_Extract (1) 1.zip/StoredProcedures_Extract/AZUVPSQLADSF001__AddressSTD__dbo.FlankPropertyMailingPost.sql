SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankPropertyMailingPost] (@tableName varchar(40)) -- @tableName = 'Property_Mailing' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''
--exec global.dbo.emaildone 'gmathes@firstam.com;afowler@firstam.com', @t_subject = 'Running [AddressSTD].[FlankPropertyMailingPost]';
SET CONCAT_NULL_YIELDS_NULL  OFF--For concat PMB

-- Trim all fields, make some fields uppdercase, rebuild MailingStdFullStreetAddress and MailingCensusTractBlock fields
-- ,[MailingStdHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdHouseNbr])) -- changed 20240708 GM
-- [MailingStdFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitNbr])))) -- GM 20240716
-- ,[MailingStdStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdStreet]))) -- changed 20240716 GM
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Property_Mailing_STD]
	   --set [MailingStdFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdHouseNbr])) + '' '' + [AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdMode]))) + '' '' + [AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitNbr])))))))
       set [MailingStdFullStreetAddress] = LEFT(ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdHouseNbr])) + '' '' + 
	       [AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionLeft]) + '' '' + 
		   ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdStreet])))) + '' '' + 
		   ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdMode])))) + '' '' + 
		   ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionRight])))) + '' '' + 
		   ltrim(rtrim(UPPER([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitType])))) + '' '' + 
		   ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitNbr]))))+ '' '' + 
		   ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[PMB])),116)
	   ,[MailingStdHouseNbr] = substring(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdHouseNbr])),1,30)
       ,[MailingStdDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionLeft]))
       ,[MailingStdStreet] = substring(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdStreet]))),1,60)
       ,[MailingStdMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdMode])))
       ,[MailingStdDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdDirectionRight]))
       ,[MailingStdUnitNbr] = LEFT(case when len([Property_Mailing_STD].[PMB]) > 0 
								and ISNULL([Property_Mailing_STD].[PMB],'''') not like ''''
								and [Property_Mailing_STD].[PMB] is not null then 
								ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[PMB]))
								else ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitNbr])) 
								end,15)
								
								
       ,[MailingStdCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdCity])))
       ,[MailingStdState] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdState]))
       ,[MailingStdZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdZIP5]))
       ,[MailingStdZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdZIP4]))
       ,[MailingStdCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdCarrierCode]))
	   ,[MailingCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingCensusTract]))
       ,[MailingStdUnitType] = case when len([Property_Mailing_STD].[PMB]) > 0 
								and ISNULL([Property_Mailing_STD].[PMB],'''') not like ''''
								and [Property_Mailing_STD].[PMB] is not null then 
								''PMB''
								else UPPER(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdUnitType])))
								end
       ,[MailingStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingStdMatchCode]))
       ,[MailingDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingDPVCount]))
       ,[MailingDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingDPVFootnote]))
       ,[MailingLACS] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingLACS]))
       ,[MailingLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingLACSLinkInd]))
       ,[MailingDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingDPCheckDigit]))
       ,[MailingDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingDPCheckCode]))
       ,[MailingCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingCensusBlock]))
       ,[MailingGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingGeoErrorCode]))
       ,[MailingGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingGeoStatusCode]))
       ,[MailingGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[MailingGeoCodeResults]))
       ,[FIPS] = CASE WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[FIPS]))) = 1 THEN NULL 
	             WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[FIPS]))) = 4 THEN ''0'' + ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[FIPS])) 
				 ELSE ltrim(rtrim([AddressSTD].[dbo].[Property_Mailing_STD].[FIPS])) END
     From [AddressSTD].[dbo].[Property_Mailing_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Property_Mailing_to_Licensing
