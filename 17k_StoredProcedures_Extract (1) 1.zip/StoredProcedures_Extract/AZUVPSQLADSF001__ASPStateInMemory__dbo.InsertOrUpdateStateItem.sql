SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.InsertOrUpdateStateItem(
	@SessionId nvarchar(88) NOT NULL,
	@NewItem bit NOT NULL,
	@Initialized bit NOT NULL,
	@LockCookie int NOT NULL,
	@Timeout int NOT NULL,
	@ItemSize bigint NOT NULL,
	@Item varbinary(7000) NOT NULL
) WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()
	DECLARE @Expires AS datetime2 NOT NULL = DATEADD(minute, @Timeout, @Now)
			
	IF @NewItem = 1
	BEGIN
		INSERT dbo.Sessions
			(SessionId,
			Created,
			Expires,
			Initialized,
			Locked,
			LockDate,
			LockCookie,
			Timeout,
			ItemSize,
			Item)
		VALUES 
			(@SessionId,
			@Now,
			@Expires,
			@Initialized,
			0, -- Locked
			@Now, -- LockDate
			@LockCookie,
			@Timeout,
			@ItemSize,
			@Item)
		END
	ELSE
	BEGIN
		DECLARE @OldItemSize bigint = 0

		UPDATE dbo.Sessions
		SET
			@OldItemSize = ItemSize,
			Expires = @Expires,
			Locked = 0,
			Timeout = @Timeout,
			ItemSize = @ItemSize,
			Item = @Item
		WHERE SessionId = @SessionId AND LockCookie = @LockCookie

		IF @@ROWCOUNT = 0 RETURN;

		IF @OldItemSize > 7000
		BEGIN
			DELETE dbo.SessionItems WHERE SessionId = @SessionId
		END
	END
END 

