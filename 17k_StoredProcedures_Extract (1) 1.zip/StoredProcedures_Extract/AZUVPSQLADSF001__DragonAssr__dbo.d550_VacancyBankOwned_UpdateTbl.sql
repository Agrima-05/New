SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================

CREATE PROCEDURE [dbo].[d550_VacancyBankOwned_UpdateTbl]
AS
BEGIN

	Declare @FATimeStamp Varchar(10)
	SET @FATimeStamp = convert(varchar(10),GETDATE(),120)

---------- BANK OWNED

			UPDATE dbo.PropertyWorkUpdateTbl
			set BankOwned = 'Y'
			WHERE (OwnerStdName1Full Like '% Bank'
					or OwnerStdName1Full Like '% Bank %'
						or OwnerStdName1Full Like 'Bank %')
					and [OwnerStd1CorpInd] = 1

			UPDATE a 
			SET BankOwned = 'Y'
			From dbo.PropertyWorkUpdateTbl a JOIN [Global].[dbo].[Trans_Lender] b
			on a.OwnerStdName1Full = b.[LenderName]
			Where BankOwned is null
					and isNULL(b.LenderTypeCode,'') not in('G','P','S','N','I','E')

			UPDATE dbo.PropertyWorkUpdateTbl
			SET BankOwned = 'Y'
			Where BankOwned is null
					and (OwnerStdNAME1FULL Like 'ALBANY BANK%'
						OR OwnerStdNAME1FULL Like 'AURORA LOAN%'
						OR OwnerStdNAME1FULL Like 'ARCHER BANK%'
						OR OwnerStdNAME1FULL Like 'ASTORIA FEDERAL SAVINGS%'
						OR OwnerStdNAME1FULL Like 'BERKELEY FEDERAL BANK%'
						OR OwnerStdNAME1FULL Like 'BANK FINANCIAL%'
						OR OwnerStdNAME1FULL Like 'BANK OF AMERICA'
						OR OwnerStdNAME1FULL Like 'BANK OF AMERICA%'
						OR OwnerStdNAME1FULL Like 'BANK OF AMERICA N A'
						OR OwnerStdNAME1FULL Like 'BANK OF AMERICA NA%'
						OR OwnerStdNAME1FULL Like 'BANK OF NEW YORK%'
						OR OwnerStdNAME1FULL Like 'BANK ONE%'
						OR OwnerStdNAME1FULL Like 'BANKFINANCIAL%'
						OR OwnerStdNAME1FULL Like 'BAYVIEW LOAN%'
						OR OwnerStdNAME1FULL Like 'BK OF AMER%'
						OR OwnerStdNAME1FULL Like 'BMO HARRIS BANK$'
						OR OwnerStdNAME1FULL Like 'BRIDGEVIEW BANK'
						OR OwnerStdNAME1FULL Like 'BRIDGEVIEW BANK$'
						OR OwnerStdNAME1FULL Like 'BYLINE BANK$'
						OR OwnerStdNAME1FULL Like 'CARRINGTON MORTGAGE$'
						OR OwnerStdNAME1FULL Like 'CARDUNAL SAVINGS%'
						OR OwnerStdNAME1FULL Like 'CHAMPION MORTGAGE$'
						OR OwnerStdNAME1FULL Like 'CITIBANK$'
						OR OwnerStdNAME1FULL Like 'CITI BANK$'
						OR OwnerStdNAME1FULL Like 'CITIMORTGAGE%'
						OR OwnerStdNAME1FULL Like 'CITIZENS BANK NA'
						OR OwnerStdNAME1FULL Like 'CITYWIDE BANKS'
						OR OwnerStdNAME1FULL Like 'COLE TAYLOR BANK'
						OR OwnerStdNAME1FULL Like 'COLE TAYLOR BANK%'
						OR OwnerStdNAME1FULL Like 'COLE TAYLOR BK%'
						OR OwnerStdNAME1FULL Like 'COMMUNITY SAVINGS BANK%'
						OR OwnerStdNAME1FULL Like 'COUNTRYSIDE BANK%'
						OR OwnerStdNAME1FULL Like 'DELAWARE PLACE BANK%'
						OR OwnerStdNAME1FULL Like 'DEUTSCHE BANK NATIONAL%'
						OR OwnerStdNAME1FULL Like 'DEUTSCHE BANK%'
						OR OwnerStdNAME1FULL Like 'DEUTSCHE BANK NATIONAL%'
						OR OwnerStdNAME1FULL Like 'DEVON BANK%'
						OR OwnerStdNAME1FULL Like 'FANNIE MAE%'
						OR OwnerStdNAME1FULL Like 'FARM CREDIT BANK%'
						OR OwnerStdNAME1FULL Like 'FEDERAL HOME LOAN%'
						OR OwnerStdNAME1FULL Like 'FEDERAL HOME LOAN%'
						OR OwnerStdNAME1FULL Like 'FEDERAL NATIONAL MORTG%'
						OR OwnerStdNAME1FULL Like 'FEDERAL NATIONAL MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'FEDERAL NATL MTG%'
						OR OwnerStdNAME1FULL Like 'FIFTH THIRD BANK%'
						OR OwnerStdNAME1FULL Like 'FIFTH THIRD MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'FIRST AMERICAN BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST BANK OF MANHATTAN%'
						OR OwnerStdNAME1FULL Like 'FIRST COMMUNITY BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST COMMUNITY BANK AND TRUST'
						OR OwnerStdNAME1FULL Like 'FIRST MIDWEST BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST MIDWEST BANK (TR 8621)'
						OR OwnerStdNAME1FULL Like 'FIRST MIDWEST BANK TRUST 5800'
						OR OwnerStdNAME1FULL Like 'FIRST NATIONAL BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST NATIONS BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST PERSONAL BANK%'
						OR OwnerStdNAME1FULL Like 'FIRSTMERIT BANK'
						OR OwnerStdNAME1FULL Like 'FIRSTMERIT BANK%'
						OR OwnerStdNAME1FULL Like 'FLAGSTAR BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST NATIONAL BANK%'
						OR OwnerStdNAME1FULL Like 'FIRST STATE BK & TR%'
						OR OwnerStdNAME1FULL Like 'FIRST UNITED BANK%'
						OR OwnerStdNAME1FULL Like 'GRUNDY BANK%'
						OR OwnerStdNAME1FULL Like 'HARRIS BANK NA%'
						OR OwnerStdNAME1FULL Like 'HARRIS BANK%'
						OR OwnerStdNAME1FULL Like 'HARRIS TRUST%'
						OR OwnerStdNAME1FULL Like 'HOME STATE BANK%'
						OR OwnerStdNAME1FULL Like 'HOMESTAR BANK%'
						OR OwnerStdNAME1FULL Like 'HOMESTAR BANK & FINANCIAL%'
						OR OwnerStdNAME1FULL Like 'HOME STATE BANK%'
						OR OwnerStdNAME1FULL Like 'HSBC%'
						OR OwnerStdNAME1FULL Like 'HSBC BANK USA NATIONAL%'
						OR OwnerStdNAME1FULL Like 'HOUSEHOLD FINANCE%'
						OR OwnerStdNAME1FULL Like 'INTEGRA BANK%'
						OR OwnerStdNAME1FULL Like 'INTERNATIONAL BANK%'
						OR OwnerStdNAME1FULL Like 'ITASCA BANK & TRUST%'
						OR OwnerStdNAME1FULL Like 'JEFFERSON BANK AND TRUST%'
						OR OwnerStdNAME1FULL Like 'JP MORGAN CHASE BANK%'
						OR OwnerStdNAME1FULL Like 'JPMORGAN CHASE BANK%'
						OR OwnerStdNAME1FULL Like 'JPMORGAN CHASE BANK NATIONAL%'
						OR OwnerStdNAME1FULL Like 'LAKESIDE BANK%'
						OR OwnerStdNAME1FULL Like 'MARQUETTE BANK%'
						OR OwnerStdNAME1FULL Like 'MARQUETTE BANK FINANCE%'
						OR OwnerStdNAME1FULL Like 'MB FINANCIAL BANK%'
						OR OwnerStdNAME1FULL Like 'MCHENRY SVGS BANK%'
						OR OwnerStdNAME1FULL Like 'MIDFIRST BANK%'
						OR OwnerStdNAME1FULL Like 'MIDLAND FEDERAL SAVINGS%'
						OR OwnerStdNAME1FULL Like 'MORTON ARBORETUM'
						OR OwnerStdNAME1FULL Like 'MTGLQ INVESTORS%'
						OR OwnerStdNAME1FULL Like 'MUNICIPAL TRUST & SAVINGS%'
						OR OwnerStdNAME1FULL Like 'NATIONAL MORTGAGE INVESTORS%'
						OR OwnerStdNAME1FULL Like 'NATIONSTAR MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'NATIONSTAR MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'NEW LENOX STATE BANK%'
						OR OwnerStdNAME1FULL Like 'NORSTATES BANK%'
						OR OwnerStdNAME1FULL Like 'NORTH COMMUNITY BANK%'
						OR OwnerStdNAME1FULL Like 'NORTH VALLEY BANK%'
						OR OwnerStdNAME1FULL Like 'NORWEST BANK%'
						OR OwnerStdNAME1FULL Like 'OCWEN LOAN SERVICING%'
						OR OwnerStdNAME1FULL Like 'OLD SECOND NATIONAL BANK%'
						OR OwnerStdNAME1FULL Like 'OXFORD BANK & %'
						OR OwnerStdNAME1FULL Like 'PARKWAY BANK %'
						OR OwnerStdNAME1FULL Like 'PNC BANK%'
						OR OwnerStdNAME1FULL Like 'REALTY & MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'REGIONS BANK%'
						OR OwnerStdNAME1FULL Like 'SEAWAY BANK %'
						OR OwnerStdNAME1FULL Like 'SECRETARY OF HOUSING%'
						OR OwnerStdNAME1FULL Like 'SECRETARY OF HUD%'
						OR OwnerStdNAME1FULL Like 'SLOANS ROW LLC'
						OR OwnerStdNAME1FULL Like 'SOUTH SUBURBAN LAND BANK%'
						OR OwnerStdNAME1FULL Like 'STANDARD BANK & TRUST%'
						OR OwnerStdNAME1FULL Like 'STATE BANK%'
						OR OwnerStdNAME1FULL Like 'TCF BANK %T'
						OR OwnerStdNAME1FULL Like 'TCF NATIONAL BANK%'
						OR OwnerStdNAME1FULL Like 'THE BANK OF NEW YORK MELLON%'
						OR OwnerStdNAME1FULL Like 'THE HARVARD STATE BANK%'
						OR OwnerStdNAME1FULL Like 'THE PRIVATEBANK'
						OR OwnerStdNAME1FULL Like 'U S BANK%'
						OR OwnerStdNAME1FULL Like 'US BANK%'
						OR OwnerStdNAME1FULL Like 'UNITED TRUST BANK%'
						OR OwnerStdNAME1FULL Like 'URBAN PARTNERSHIP BANK%'
						OR OwnerStdNAME1FULL Like 'VALLEY BANK%'
						OR OwnerStdNAME1FULL Like 'WACHOVIA%'
						OR OwnerStdNAME1FULL Like 'WELLS FARGO%'
						OR OwnerStdNAME1FULL Like 'WELLTON MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'WEST SUBURBAN BANK%'
						OR OwnerStdNAME1FULL Like 'WILMINGTON SAVINGS %'
						OR OwnerStdNAME1FULL Like 'WILMINGTON TRUST%'
						OR OwnerStdNAME1FULL Like 'TRUST BANK%'
						OR OwnerStdNAME1FULL Like 'STANDARD BANK%'
						OR OwnerStdNAME1FULL Like 'US BANK NATIONAL ASSOCIATION'
						OR OwnerStdNAME1FULL Like 'WEST SUBURBAN BANK%'
						OR OwnerStdNAME1FULL Like 'STC CAPITAL BANK%'
						OR OwnerStdNAME1FULL Like 'FEDERAL NATIONAL MORTGAGE%'
						OR OwnerStdNAME1FULL Like 'THE BANK OF NEW YORK MELLON%'
						OR OwnerStdNAME1FULL Like 'BANK OF AMERICA%'
						OR OwnerStdNAME1FULL Like 'COUNTRYWIDE HOME LOANS%'
				)

			UPDATE a 
			set BankOwned = 'Y'
			From dbo.PropertyWorkUpdateTbl a JOIN [Data].dbo.[Deed] b with(NOLOCK)
			on a.fips = b.fips
			and a.FAOwnerTransactionID = b.TransactionID
			Where BankOwned is null 
					and b.Reo = 1
						and isNULL(a.[OwnerStd1LastName],'') like ''


--------- VACANCY

		UPDATE dbo.PropertyWorkUpdateTbl
		SET VacantFlag = 'M'
		,VacantFlagDate = @FATimeStamp
		WHERE VacantFlag is null
			and (SitusStdMatchCode like '%AS16%')
				and isNULL([CurrSaleRecordingDate],'2020-01-01') < convert(varchar(8),GetDate()-90,112)

		---- Clear Vacancy Flag on Recent Sales

		UPDATE dbo.PropertyWorkUpdateTbl
		SET VacantFlag = NULL
		,VacantFlagDate = @FATimeStamp
		WHERE vacantFlag is not NULL and [CurrSaleRecordingDate] > convert(varchar(8),GETDATE()-30)
		

	--- SET Vacancy Based on Bank Owned Property

		UPDATE dbo.PropertyWorkUpdateTbl
		SET VacantFlag = 'B'
		,VacantFlagDate = @FATimeStamp
		where (OwnerStdNAME1FULL like '% bank' or OwnerStdNAME1FULL like '% bank %' or OwnerStdNAME1FULL like 'bank %')
			and Owner1DoNotParse = 1
				and VacantFlag is null

		UPDATE dbo.PropertyWorkUpdateTbl
		SET VacantFlag = 'B'
		,VacantFlagDate = @FATimeStamp
		where BankOwned = 'Y'
			and Owner1DoNotParse = 1
				and VacantFlag is null

		---- Clear Vacancy Flag on recent ASP


		UPDATE dbo.PropertyWorkUpdateTbl 
		SET [MailingStdFullStreetAddress] = [SitusStdFullStreetAddress]
			  ,[MailingStdHouseNbr] = [SitusStdHouseNbr]
			  ,[MailingStdHouseNbr2] = [SitusStdHouseNbr2]
			  ,[MailingStdHouseNbrSuffix] = [SitusStdHouseNbrSuffix]
			  ,[MailingStdDirectionLeft] = [SitusStdDirectionLeft]
			  ,[MailingStdStreet] = [SitusStdStreet]
			  ,[MailingStdMode] = [SitusStdMode]
			  ,[MailingStdDirectionRight] = [SitusStdDirectionRight]
			  ,[MailingStdUnitNbr] = [SitusStdUnitNbr]
			  ,[MailingStdCity] = [SitusStdCity]
			  ,[MailingStdState] = [SitusStdState]
			  ,[MailingStdZIP5] = [SitusStdZIP5]
			  ,[MailingStdZIP4] = [SitusStdZIP4]
			  ,[MailingStdCarrierCode] = [SitusStdCarrierCode]
			  ,[MailingStdUnitType] = [SitusStdUnitType]
			  ,[MailingStdMatchCode] = [SitusStdMatchCode]
			  ,OwnerOccupied = CASE WHEN Owner1DoNotParse is null then  'Y' Else NULL END
			  ,FAAddressParsedMailing = NULL
			  ,FAUserID = 'Fix Mailing Addr From Situs'
		 from dbo.PropertyWorkUpdateTbl
		where SitusStdFullStreetAddress Like '% %' 
		and MailingStdFullStreetAddress Like '% %'
		and LEN(isNULL(SitusStdCity,''))>0
		and SitusStdFullStreetAddress = MailingStdFullStreetAddress
		and SitusStdCity = SitusStdCity
		and LEN(MailingStdZip5) between 1 and 4
		and LEN(SitusStdZIP5) = 5

END





