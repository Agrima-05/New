SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[Roll_DBS_Tax_To_Property]
AS
BEGIN
	SET NOCOUNT ON;

		--UPDATE [Jobs].[dbo].[SystemProperty] set Value = 'Y', UpdateDate = Getdate() WHERE Name = 'IsDBSTaxRunning'

		DECLARE @FipsCode varchar(5)
		DECLARE @DT varchar(8) = Convert(varchar(8),GETDATE(),112)
		DECLARE @Updated varchar(10) = (Select convert(varchar(10),MAX(UPDATED),120) From DBS_Tax_Lic.dbo.Licensing_Deliverable)
		
		TRUNCATE TABLE [DBS_Tax_Lic].dbo.AvailableFIPS

		UPDATE DBS_Tax_Lic.dbo.Licensing_Deliverable
		SET LIC_FIPS = Right('0' + convert(varchar(5),FIPS),5)
		WHERE LIC_FIPS is null

		INSERT INTO  [DBS_Tax_Lic].dbo.AvailableFIPS(LIC_FIPS)
		SELECT LIC_FIPS FROM Licensing_Deliverable with(NOLOCK)
		WHERE UPDATED >= @Updated
			and TOTAL_BASE_TAX_AMOUNT is not null
		GROUP BY LIC_FIPS
		ORDER BY LIC_FIPS


		DECLARE RollUpToProp CURSOR FOR  
			SELECT LIC_FIPS 
			FROM [DBS_Tax_Lic].dbo.AvailableFIPS
			ORDER BY LIC_FIPS


		OPEN RollUpToProp   
		FETCH NEXT FROM RollUpToProp INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   

		--PRINT @FipsCode
		--PRINT @DT
		--PRINT @Updated
	----- RUN THIS FOR DAILY UPDATE 

			EXEC('update data.dbo.Property 
				SET taxyear = NULL 
				where FIPS = '''+@FipsCode+'''
				and  Taxyear like ''    ''
				')


			EXEC('UPDATE a
			SET DBSTaxAmount = TOTAL_BASE_TAX_AMOUNT*100
			,DBSTaxYear = TAX_YEAR_BEGIN
			--,FATimeStamp = CASE WHEN (TAX_YEAR_BEGIN > TaxYear or TaxYear is NULL) THEN 
			--	CASE WHEN DATENAME(dw,GETDATE()) = ''Friday'' THEN convert(varchar(10),GETDATE()+3,120) ELSE convert(varchar(10),GETDATE()+1,120) END
			--		ELSE FATimeStamp END
			--,FAUserID = ''DBS Tax Update_' + @DT + '''
			FROM Data.dbo.Property a JOIN DBS_Tax_Lic.dbo.Licensing_Deliverable b
			ON a.FIPS = b.LIC_FIPS
			and a.PropertyID = b.FAPropertyID
			Where b.Lic_FIPS = '''+@FipsCode+'''
					AND a.FIPS = '''+@FipsCode+'''
						AND b.UPDATED >= '''+@Updated+'''
							AND [CurrentRecord] = ''Y''
								AND ((DBSTaxYear < TAX_YEAR_BEGIN OR (DBSTaxYear is NULL))
									OR DBSTaxAmount != TOTAL_BASE_TAX_AMOUNT*100)
										AND TOTAL_BASE_TAX_AMOUNT is NOT NULL
			')


			EXEC('UPDATE a
				SET TaxDeliquentYear1 = [EARLIEST_DELINQUENT_YEAR]
				,TaxDeliquentValue1 = [TOTAL_DELINQ_AMOUNT]
				,FATimeStamp = CASE WHEN DATENAME(dw,GETDATE()) = ''Friday'' THEN convert(varchar(10),GETDATE()+3,120) ELSE convert(varchar(10),GETDATE()+1,120) END
				,FAUserID = ''DBS Del Tax Update_' + @DT + '''
				FROM Data.dbo.Property a JOIN DBS_Tax_Lic.dbo.Licensing_Deliverable b
					ON b.Lic_FIPS = a.FIPS
						AND b.FAPropertyID = a.PropertyID
				WHERE b.LIC_FIPS = '''+@FipsCode+'''
					AND a.FIPS = '''+@FipsCode+'''
						AND b.UPDATED >= '''+@Updated+'''
							and IsNULL([EARLIEST_DELINQUENT_YEAR],0) <> 0
			')



		PRINT @FipsCode

			FETCH NEXT FROM RollUpToProp INTO @FipsCode   
		
		END   

		CLOSE RollUpToProp   
		DEALLOCATE RollUpToProp 
END
