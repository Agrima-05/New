SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_Pre_Update]

AS
BEGIN
	SET NOCOUNT ON;

UPDATE [Jobs].[dbo].[SystemProperty] set Value = 'Y' WHERE Name = 'IsDBSTaxRunning'
--UPDATE [Jobs].[dbo].[SystemProperty] set Value = 'N' WHERE Name = 'IsDBSTaxRunning'

END

