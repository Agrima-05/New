SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[zAdmin_OpenLien_Dragon_NoNameCheck_CountySpecific] @Fips varchar(5)
AS
BEGIN
	SET NOCOUNT ON;
------------

--INSERT INTO [DragonAssr].[dbo].OLSteps_Daily(STEP,WhatItsDoing,StartTime,OnErrorDoThis)
--SELECT 'STEP 1','Getting Data',GETDATE(),'Manually Run queries 000 Thru 151 include 151'


---000
truncate table [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work

---001

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------

---002
/****** Object:  Index [PropertyID]    Script Date: 05/11/2016 11:20:38 PM ******/
DROP INDEX IF EXISTS [PropertyID] ON [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]

---003

/****** Object:  Index [PropertyID]    Script Date: 05/11/2016 11:20:38 PM ******/
DROP INDEX IF EXISTS [FipsTransactionID] ON [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]

------------
---009

------------
---100

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate
		   ,[InterestRateSrce]
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(d.ChronoKey,1,31)
           ,Substring(d.Loan1Document,1,20)
           ,Substring(d.Loan1Book,1,10)
           ,Substring(d.Loan1Page,1,10)
           ,[Loan1YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],1,(charindex('.',[Loan1BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],(charindex('.',[Loan1BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan1Amount as int)
           ,Substring(d.Loan1LenderName,1,30)
           ,Substring(d.Loan1LenderCode,1,10)
           ,Substring(d.Loan1LenderTypeCode,1,5)
           ,case when d.Loan1PrivatePartyLender = 1 then 1 else null end
           ,Ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan1AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan1Type,1,10)
           ,Substring(d.Loan1TypeFinance,1,10)
           ,case when DeedTransactionType = '2' then 1 when DeedTransactionType = '1' then null end  --1 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan1InterestRate
		   ,d.[Loan1InterestRateSrce]
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Deed] d with(NOLOCK) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where d.fips = @Fips and 
 (d.Loan1Amount > 0 or (d.Loan1Amount = 0 and len(d.Loan1LenderName) > 0))
and d.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'
and DocumentTypeCode not in ('22','44','61')


INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate
		   ,InterestRateSrce
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,substring(ltrim(rtrim(substring(d.ChronoKey,1,31))) + 'xz',1,38)
           ,Substring(d.Loan2Document,1,20)
           ,Substring(d.Loan2Book,1,10)
           ,Substring(d.Loan2Page,1,10)
           ,[Loan2YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],1,(charindex('.',[Loan2BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],(charindex('.',[Loan2BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan2Amount as int)
           ,Substring(d.Loan2LenderName,1,30)
           ,Substring(d.Loan2LenderCode,1,10)
           ,Substring(d.Loan2LenderTypeCode,1,5)
           ,case when d.Loan2PrivatePartyLender = 1 then 1 else null end
           ,ltrim(rtrim(d.Loan2TermMonths))
           ,Substring(d.Loan2DueDate,1,10)
           ,case when d.Loan2AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan2Type,1,10)
           ,Substring(d.Loan2TypeFinance,1,10)
           ,case when DeedTransactionType in ('2','3') then 2 when DeedTransactionType = '1' then null end  -- 2 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan2InterestRate
		   ,d.[Loan2InterestRateSrce]
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Deed] d with(NOLOCK) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where d.fips = @Fips and 
(d.Loan2Amount > 0  or (d.Loan2Amount = 0 and len(d.Loan2LenderName) > 0))
and d.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'
and DocumentTypeCode not in ('22','44','61')


----  Use Sup Tables

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,Substring(((REPLICATE('0', 5 - LEN(d.[FIPS]) ) + Cast (ltrim(rtrim(d.[FIPS])) as varchar))  +
					(Case when d.FAPropertyId is not null  
						then REPLICATE('0', 10 - LEN(d.[FAPropertyId])) + Cast (ltrim(rtrim(d.[FAPropertyId])) as varchar)
						else Cast('0000000000' as varchar)  end )  +
					(Case when d.[RecordingDt] is not null then  Cast (ltrim(rtrim(d.[RecordingDt])) as varchar)
						 when d.[RecordingDt] is null and [Saledate] is not null then Cast (ltrim(rtrim([Saledate])) as varchar)
						 else Cast ('00000000' as varchar) End) + 
					(Case when DocNbrSrce is not null 
						  then Case 
							   when LEN(DocNbrSrce) < 8 then Substring(REPLICATE('0', 8 - LEN([DocNbrSrce]) ) + Cast (LTRIM(RTRIM([DocNbrSrce])) as varchar),1,8) 
							   else Substring(LTRIM(RTRIM(DocNbrSrce)), (LEN(DocNbrSrce) - 7),8) 
							   end 
					      Else   
						      Case when BookSrce is not null and PageSrce is not null 
					   	           then Case
										when LEN(BookSrce) < 5 and LEN(PageSrce) < 5
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
										     Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4)  
										
										when LEN(BookSrce) > 4 and LEN(PageSrce) > 4 
										then Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) +  Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)
										
										when  LEN(BookSrce) > 4 and LEN(PageSrce) < 5 
										then  Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) + 
											  Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4) 
										
										when LEN(BookSrce) < 5 and LEN(PageSrce) > 4 										 
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
											 Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)

								        else '00000000' 
								        end
									else '00000000'
									end
						   End ) ),1,38)
           ,Substring(d.Loan1Document,1,20)
           ,Substring(d.Loan1Book,1,10)
           ,Substring(d.Loan1Page,1,10)
           ,[Loan1YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],1,(charindex('.',[Loan1BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan1BookPageFmt] is not null and [Loan1BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan1BookPageFmt],(charindex('.',[Loan1BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan1Amount as int)
           ,Substring(d.Loan1LenderName,1,30)
           ,Substring(d.Loan1LenderCode,1,10)
           ,Substring(d.Loan1LenderTypeCode,1,5)
           ,case when d.Loan1PrivatePartyLender = 'Y' then 1 else null end
           ,Ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan1AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan1Type,1,10)
           ,Substring(d.Loan1TypeFinance,1,10)
           ,1 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan1InterestRate
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Deed_Sup] d with(NOLOCK) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where d.fips = @Fips and --(substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(d.Buyer2FullName,1,4))
(d.Loan1Amount > 0  or (d.Loan1Amount = 0 and len(d.Loan1LenderName) > 0))
and d.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'
and DocumentTypeCode not in ('22','44','61')


INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,InterestRate
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(d.Buyer1FullName,1,80)
           ,d.TransactionId
           ,Substring(((REPLICATE('0', 5 - LEN(d.[FIPS]) ) + Cast (ltrim(rtrim(d.[FIPS])) as varchar))  +
					(Case when d.FAPropertyId is not null  
						then REPLICATE('0', 10 - LEN(d.[FAPropertyId])) + Cast (ltrim(rtrim(d.[FAPropertyId])) as varchar)
						else Cast('0000000000' as varchar)  end )  +
					(Case when d.[RecordingDt] is not null then  Cast (ltrim(rtrim(d.[RecordingDt])) as varchar)
						 when d.[RecordingDt] is null and d.[Saledate] is not null then Cast (ltrim(rtrim([Saledate])) as varchar)
						 else Cast ('00000000' as varchar) End) + 
					(Case when DocNbrSrce is not null 
						  then Case 
							   when LEN(DocNbrSrce) < 8 then Substring(REPLICATE('0', 8 - LEN([DocNbrSrce]) ) + Cast (LTRIM(RTRIM([DocNbrSrce])) as varchar),1,8) 
							   else Substring(LTRIM(RTRIM(DocNbrSrce)), (LEN(DocNbrSrce) - 7),8) 
							   end 
					      Else   
						      Case when BookSrce is not null and PageSrce is not null 
					   	           then Case
										when LEN(BookSrce) < 5 and LEN(PageSrce) < 5
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
										     Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4)  
										
										when LEN(BookSrce) > 4 and LEN(PageSrce) > 4 
										then Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) +  Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)
										
										when  LEN(BookSrce) > 4 and LEN(PageSrce) < 5 
										then  Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) + 
											  Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4) 
										
										when LEN(BookSrce) < 5 and LEN(PageSrce) > 4 										 
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
											 Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)

								        else '00000000' 
								        end
									else '00000000'
									end
						   End ) ) + 'xz',1,38)
           ,Substring(d.Loan2Document,1,20)
           ,Substring(d.Loan2Book,1,10)
           ,Substring(d.Loan2Page,1,10)
           ,[Loan2YearDocNbrFmt] --Docnumberformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],1,(charindex('.',[Loan2BookPageFmt])-1)))) else null end --Bookformatted
           ,case when [Loan2BookPageFmt] is not null and [Loan2BookPageFmt] not like  '' then ltrim(rtrim(substring([Loan2BookPageFmt],(charindex('.',[Loan2BookPageFmt])+1),9))) else null end --PageFormatted
           ,Substring(d.RecordingDt,1,10)
           ,cast(d.Loan2Amount as int)
           ,Substring(d.Loan2LenderName,1,30)
           ,Substring(d.Loan2LenderCode,1,10)
           ,Substring(d.Loan2LenderTypeCode,1,5)
           ,case when d.Loan2PrivatePartyLender = 'Y' then 1 else null end
           ,ltrim(rtrim(d.Loan1TermMonths))
           ,Substring(d.Loan1DueDate,1,10)
           ,case when d.Loan2AdjRateIndex is not null then 'Y' else null end
           ,Substring(d.Loan2Type,1,10)
           ,Substring(d.Loan2TypeFinance,1,10)
           ,2 --LienPosition
           ,Substring(d.FADateReceived,1,8)
		   ,d.Loan2InterestRate
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Deed_Sup] d with(NOLOCK) on d.Fips = p.FIPS and 
d.FAPropertyId = p.PropertyID
where d.fips = @Fips and 
(d.Loan2Amount > 0  or (d.Loan2Amount = 0 and len(d.Loan1LenderName) > 0))
and d.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'
and DocumentTypeCode not in ('22','44','61')

------------
---101


INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,[RefiFlag]
		   ,[EquityFlag]
		   ,[HELCOCFlag]
		   ,InterestRate
		   ,InterestRateSrce
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(m.Borrower1FullName,1,80)
           ,m.TransactionId
           ,substring(m.ChronoKey,1,31)
           ,Substring(m.DocNbrSrce,1,20)
           ,Substring(m.BookSrce,1,10)
           ,Substring(m.PageSrce,1,10)
           ,[YearDocNbrFrmt] --Docnumberformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],1,(charindex('.',[BkPgFrmt])-1)))) else null end --Bookformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],(charindex('.',[BkPgFrmt])+1),9))) else null end --PageFormatted
           ,Substring(m.RecordingDt,1,10)
           ,cast(m.LoanAmount as int)
           ,Substring(m.lendername,1,30)
           ,Substring(m.LenderCode,1,10)
           ,Substring(m.LenderTypeCode,1,5)
           ,case when m.LenderPrivateInd is not null then 1 else null end
           ,Ltrim(rtrim(m.LoanTermMonths))
           ,Substring(m.LoanDueDate,1,10)
           ,case when m.LoanAdjRateIndex is not null then 'Y' else null end
           ,Substring(m.LoanType,1,10)
           ,Substring(m.TypeFinance,1,10)
           ,null --LienPosition
           ,Substring(m.FADateReceived,1,8)
		   ,m.LoanRefiLoanInd
		   ,m.LoanEquityLoanInd
		   ,m.LoanHELOCLoanInd
		   ,m.LoanInterestRate
		   ,m.LoanInterestRateSrce
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Mortgage] m with(NOLOCK) on m.Fips = p.FIPS and 
m.FAPropertyId = p.PropertyID
where m.fips = @Fips and 
(m.LoanAmount > 0 or (m.LoanAmount = 0 and len(m.LenderName) > 0))
and m.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'


---  Use Sup Tables

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LenderCode]
           ,[LenderType]
           ,[PrivateLender]
           ,[Term]
           ,[LoanDueDt]
           ,[AdjRider]
           ,[LoanType]
           ,[Typefinancing]
           ,[LienPosition]
           ,[FADateReceived]
		   ,[RefiFlag]
		   ,[EquityFlag]
		   ,[HELCOCFlag]
		   ,InterestRate
		   ,[PropLastPurchase])
 Select
            p.FIPS
           ,p.PropertyID
           ,substring(p.FormattedAPN,1,45)
           ,substring(p.OwnerStdNAME1FULL,1,80)
           ,substring(m.Borrower1FullName,1,80)
           ,m.TransactionId
           ,Substring(((REPLICATE('0', 5 - LEN(m.[FIPS]) ) + Cast (ltrim(rtrim(m.[FIPS])) as varchar))  +
					(Case when m.FAPropertyId is not null  
						then REPLICATE('0', 10 - LEN(m.[FAPropertyId])) + Cast (ltrim(rtrim(m.[FAPropertyId])) as varchar)
						else Cast('0000000000' as varchar)  end )  +
					(Case when m.[RecordingDt] is not null then  Cast (ltrim(rtrim(m.[RecordingDt])) as varchar)
						 when m.[RecordingDt] is null and [contractdate] is not null then Cast (ltrim(rtrim([contractdate])) as varchar)
						 else Cast ('00000000' as varchar) End) + 
					(Case when DocNbrSrce is not null 
						  then Case 
							   when LEN(DocNbrSrce) < 8 then Substring(REPLICATE('0', 8 - LEN([DocNbrSrce]) ) + Cast (LTRIM(RTRIM([DocNbrSrce])) as varchar),1,8) 
							   else Substring(LTRIM(RTRIM(DocNbrSrce)), (LEN(DocNbrSrce) - 7),8) 
							   end 
					      Else   
						      Case when BookSrce is not null and PageSrce is not null 
					   	           then Case
										when LEN(BookSrce) < 5 and LEN(PageSrce) < 5
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
										     Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4)  
										
										when LEN(BookSrce) > 4 and LEN(PageSrce) > 4 
										then Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) +  Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)
										
										when  LEN(BookSrce) > 4 and LEN(PageSrce) < 5 
										then  Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) + 
											  Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4) 
										
										when LEN(BookSrce) < 5 and LEN(PageSrce) > 4 										 
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
											 Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)

								        else '00000000' 
								        end
									else '00000000'
									end
						   End ) ),1,38)
           ,Substring(m.DocNbrSrce,1,20)
           ,Substring(m.BookSrce,1,10)
           ,Substring(m.PageSrce,1,10)
           ,[YearDocNbrFrmt] --Docnumberformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],1,(charindex('.',[BkPgFrmt])-1)))) else null end --Bookformatted
           ,case when [BkPgFrmt] is not null and [BkPgFrmt] not like  '' then ltrim(rtrim(substring([BkPgFrmt],(charindex('.',[BkPgFrmt])+1),9))) else null end --PageFormatted
           ,Substring(m.RecordingDt,1,10)
           ,cast(m.LoanAmount as int)
           ,Substring(m.lendername,1,30)
           ,Substring(m.LenderCode,1,10)
           ,Substring(m.LenderTypeCode,1,5)
           ,case when m.LenderPrivateInd is not null then 1 else null end
           ,Ltrim(rtrim(m.LoanTermMonths))
           ,Substring(m.LoanDueDate,1,10)
           ,case when m.LoanAdjRateIndex is not null then 'Y' else null end
           ,Substring(m.LoanType,1,10)
           ,Substring(m.TypeFinance,1,10)
           ,null --LienPosition
           ,Substring(m.FADateReceived,1,8)
		   ,m.LoanRefiLoanInd
		   ,m.LoanEquityLoanInd
		   ,m.LoanHELOCLoanInd
		   ,m.LoanInterestRate
		   ,p.[CurrSaleRecordingDate]
from [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
join [Data].[dbo].[Mortgage_Sup] m with(NOLOCK) on m.Fips = p.FIPS and 
m.FAPropertyId = p.PropertyID
where m.fips = @Fips and --(substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower1FullName,1,4) or substring(p.OwnerStdNAME1FULL,1,4) = substring(m.Borrower2FullName,1,4))
(m.LoanAmount > 0 or (m.LoanAmount = 0 and len(m.LenderName) > 0))
and m.FAUCIDFlag <> 'D'
and p.FAUCIDFlag <> 'D'




-----  Add Mortgage MODS as stand alone MTG  --  20250305
INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
           ([FIPS]
           ,[PropertyID]
           ,[FormattedAPN]
           ,[OwnerStdNAME1FULL]
           ,[TransNAME1FULL]
           ,[TransactionId]
           ,[ChronoKey]
           ,[InputDocNbr]
           ,[InputBook]
           ,[InputPage]
           ,[FormatDocNbr]
           ,[FormatBook]
           ,[FormatPage]
           ,[RecordingDt]
           ,[LoanAmt]
           ,[Lender]
           ,[LoanDueDt]
           ,[LoanType]
           ,[FADateReceived]
           ,[ModDate]
           ,[ModAmount]
           ,[ModDueDate]
		   ,[PropLastPurchase])
Select
           m.fips  --<FIPS, char(5),>
           ,m.[FAPropertyID]  --<PropertyID, bigint,>
           ,p.formattedapn  --<FormattedAPN, varchar(45),>
           ,p.OwnerStdNAME1FULL  --<OwnerStdNAME1FULL, varchar(80),>
           ,m.[Borrower1FullName]  --<TransNAME1FULL, varchar(80),>
           ,m.[MtgModID]  --<TransactionId, bigint,>
           ,Substring(((REPLICATE('0', 5 - LEN(m.[FIPS]) ) + Cast (ltrim(rtrim(m.[FIPS])) as varchar))  +
					(Case when m.FAPropertyId is not null  
						then REPLICATE('0', 10 - LEN(m.[FAPropertyId])) + Cast (ltrim(rtrim(m.[FAPropertyId])) as varchar)
						else Cast('0000000000' as varchar)  end )  +
					(Case when m.[RecordingDt] is not null then  Cast (ltrim(rtrim(m.[RecordingDt])) as varchar)
						 when m.[RecordingDt] is null and [ContractDt] is not null then Cast (ltrim(rtrim([ContractDt])) as varchar)
						 else Cast ('00000000' as varchar) End) + 
					(Case when DocNbrSrce is not null 
						  then Case 
							   when LEN(DocNbrSrce) < 8 then Substring(REPLICATE('0', 8 - LEN([DocNbrSrce]) ) + Cast (LTRIM(RTRIM([DocNbrSrce])) as varchar),1,8) 
							   else Substring(LTRIM(RTRIM(DocNbrSrce)), (LEN(DocNbrSrce) - 7),8) 
							   end 
					      Else   
						      Case when BookSrce is not null and PageSrce is not null 
					   	           then Case
										when LEN(BookSrce) < 5 and LEN(PageSrce) < 5
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
										     Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4)  
										
										when LEN(BookSrce) > 4 and LEN(PageSrce) > 4 
										then Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) +  Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)
										
										when  LEN(BookSrce) > 4 and LEN(PageSrce) < 5 
										then  Substring(LTRIM(RTRIM(BookSrce)), (LEN(BookSrce) - 4),4) + 
											  Substring(REPLICATE('0', 4 - LEN([PageSrce]) ) + Cast (LTRIM(RTRIM([PageSrce])) as varchar),1,4) 
										
										when LEN(BookSrce) < 5 and LEN(PageSrce) > 4 										 
										then Substring(REPLICATE('0', 4 - LEN([BookSrce]) ) + Cast (LTRIM(RTRIM([BookSrce])) as varchar),1,4) +
											 Substring(LTRIM(RTRIM(PageSrce)), (LEN(PageSrce) - 4),4)

								        else '00000000' 
								        end
									else '00000000'
									end
						   End ) ),1,38)  --<ChronoKey, varchar(38),>
           ,[DocNbrSrce]  --<InputDocNbr, varchar(20),>
           ,[BookSrce]  --<InputBook, varchar(10),>
           ,[PageSrce]  --<InputPage, varchar(10),>
           ,[FA_YearDocNbrFmt]  --<FormatDocNbr, varchar(20),>
           ,[BookSrce]  --<FormatBook, varchar(10),>
           ,[PageSrce]  --<FormatPage, varchar(10),>
           ,[RecordingDt]  --<RecordingDt, varchar(10),>
           ,convert(bigint,(coalesce([UnpaidBalance],OriginalLoanAmount)))  --<LoanAmt, int,>
           ,Substring([LenderCompanyName],1,30)  --<Lender, varchar(30),>
           ,[LoanDueDate]  --<LoanDueDt, varchar(10),>
           ,'19'  --<LoanType, varchar(10),>
           ,m.[FATimeStamp]  --<FADateReceived, varchar(8),>
           ,[RecordingDt]  --<ModDate, varchar(8),>
           ,convert(bigint,(coalesce([UnpaidBalance],OriginalLoanAmount)))   --<ModAmount, int,>
           ,[LoanDueDate]  --<ModDueDate, varchar(8),>
           ,p.[CurrSaleRecordingDate]
  FROM [Data].[dbo].[Mortgage_Mods] m with(NOLOCK)
  join [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
  on p.fips = m.fips
  and p.propertyid = m.FApropertyid
  --join [DragonAssr].[dbo].[zzFreedomInput_3] f
  --on f.PropertyID = m.fapropertyid
  where m.FIPS = @Fips 
  and convert(bigint,(coalesce([UnpaidBalance],OriginalLoanAmount))) < 2000000000
  and p.FAUCIDFlag <> 'D'
  order by m.recordingdt desc

-----
---102

  delete from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where isdate([RecordingDt]) = 0

  delete from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where isdate(LoanDueDt) = 0  and LoanDueDt is not null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set LoanDueDt = null
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where LoanDueDt < RecordingDt and (datediff(dd, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) < 48


UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term =  CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) > 999 THEN '999' 
					   When (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) < 0 then '0'
                       ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) 
                       END
                       WHERE LoanDueDt is not null
                             and (Term is NULL or Term like '' or Term like '000')
                             and RecordingDt is not null and RecordingDt not like ''
							 and LoanDueDt is not null and LoanDueDt not like ''

 UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = '360'
 ----  20230419 BR Added to roll out extremely old mortgages
 ,LoanDueDt = convert(varchar(8),DATEADD(YY,30,Convert(datetime,RecordingDt)),112) 
  WHERE LoanDueDt is NULL
  AND RecordingDt > convert(varchar(8),DateAdd(YY,-30,GETDATE()),112)

 UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = '360'
 ----  20230419 BR Added to roll out extremely old mortgages
 ,LoanDueDt = convert(varchar(8),DATEADD(YY,30,Convert(datetime,RecordingDt)),112) 
  WHERE LoanDueDt is NULL
  AND RecordingDt > LoanDueDt

 UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = Null
  WHERE Term Like '%-%' or Term like '%[a-z]%'

---- ADDED 20221222 MAS
Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = 999
  WHERE LoanType = '32'

  Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  Set interestrate = Substring(convert(varchar,interestrate),1,4)
  from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where len(convert(varchar,interestrate)) >4



---151

SET ANSI_PADDING ON

CREATE NONCLUSTERED INDEX [FipsTransactionID] ON [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
(
	[FIPS] ASC,
	[TransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


--UPDATE [DragonAssr].[dbo].OLSteps_Daily
--SET FinishTime = Getdate()

--INSERT INTO [DragonAssr].[dbo].OLSteps_Daily(STEP,WhatItsDoing,StartTime,OnErrorDoThis)
--SELECT 'STEP 2','Running 200 Set Queries',GETDATE(),'Manually Run queries 000 Thru 151 include 151'




------------
---200

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set AssgnFlag = 'Y'
,AssgnDate = a.RecordingDt
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Assignment] a with(NOLOCK)
on a.fips = w.fips and w.transactionid = a.FADeedId
Where a.FIPS = @Fips and w.TransactionId <> 888888888

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set AssgnFlag = 'Y'
,AssgnDate = a.RecordingDt
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Assignment] a with(NOLOCK)
on a.fips = w.fips and w.transactionid = a.FASamId
Where a.FIPS = @Fips and w.TransactionId <> 888888888

----  BR Added to Handle Modifications  20231129 BR Commented out Second Section for Freedom 
Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ModDate = a.RecordingDt
,ModAmount = case when convert(bigint,a.UnpaidBalance) <2000000000 then convert(int,a.UnpaidBalance) else null end
,modduedate = case when isdate(a.LoanDueDate) = 1 then a.LoanDueDate else null end 
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Mortgage_Mods] a with(NOLOCK)
on a.fips = w.fips and w.transactionid = a.[LoanTransactionId]
where a.FIPS = @Fips and convert(money,a.UnpaidBalance) <2000000000
and w.TransactionId <> 888888888


--  Term
UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term =  CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
                       WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) > 999 THEN '999' 
					   WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) < 0 THEN '0' 
                       ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDt AS date)) - 1) 
                       END
                       WHERE LoanDueDt is not null
                             --and (Term is NULL or Term like '' or Term like '000')
                             and RecordingDt is not null and RecordingDt not like ''
							 and moddate is not null

 UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = '360'
  WHERE LoanDueDt is NULL
  AND RecordingDt > convert(varchar(8),DateAdd(YY,-30,GETDATE()),112)
  and  moddate is not null

 UPDATE [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
 SET Term = Null
  WHERE Term Like '%-%' or Term like '%[a-z]%'
  and moddate is not null

------
------------
---201
Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and (substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower1fullNamestd,1,3) + '%'
or r.Borrower1fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.BorrowerFullName,1,3) + '%'
or r.BorrowerFullName like '%' + substring(w.TransName1Full,1,3) + '%'
or substring(r.Borrower2LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%')
and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or right(OrigDeedPage,3) = right([InputPage],3))
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and
((substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower1fullNamestd,1,3) + '%'
or r.Borrower1fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.BorrowerFullName,1,3) + '%'
or r.BorrowerFullName like '%' + substring(w.TransName1Full,1,3) + '%'
or substring(r.Borrower2LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'))
and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

--  Added to accomodate UR data without Names

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.BorrowerFullName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.BorrowerFullName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

----  Added to Fix the release of 2nd mtg with no document number/book page  --20251111 BR
Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and Cast(LoanAmt as varchar) = OrigLoanAmt
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and Cast(LoanAmt as varchar) = OrigLoanAmt
and r.FAUCIDFlag <> 'D'

-----
----
DROP TABLE IF EXISTS #RAS_TEMP

Select r.* INTO #RAS_TEMP FROM [src_Title].[dbo].[RAS_Temp] r with (nolock) WHERE FIPS = @Fips

CREATE INDEX IX_LINKER ON #RAS_TEMP(fipscode,FADeedID,FAPropertyID)

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.FADeedId
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join #RAS_TEMP r with (nolock)
on r.fipscode = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where w.ReleaseFlag is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(Original_Recording_Instrument_Nbr,3) = right([InputDocNbr],3) or (right(Original_Recording_Page,3) = right([InputPage],3) or right(Original_Recording_Page,3) = right([FormatPage],3)))

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.FASAMID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join #RAS_TEMP r with (nolock)
on r.fipscode = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where w.ReleaseFlag is null
and w.TransactionId <> 888888888
and w.ChronoKey not like '%xz' and (right(Original_Recording_Instrument_Nbr,3) = right([InputDocNbr],3) or (right(Original_Recording_Page,3) = right([InputPage],3) or right(Original_Recording_Page,3) = right([FormatPage],3)))

DROP TABLE IF EXISTS #RAS_TEMP


---  Added for _2  Changed to xz
Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and (substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower1fullNamestd,1,3) + '%'
or r.Borrower1fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.BorrowerFullName,1,3) + '%'
or r.BorrowerFullName like '%' + substring(w.TransName1Full,1,3) + '%'
or substring(r.Borrower2LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%')
and w.ReleaseDate is null
and w.TransactionId <> 888888888
and ([Loan_FA_DocNbrFmt] like [FormatDocNbr] or [Loan_FA_YearDocNbrFmt] like [FormatDocNbr] or [Loan_FA_YearDayDocNumFmt] like [FormatDocNbr]
     or [Loan_FA_YearBookPageFmt] like [FormatBook] + '.' + [FormatPage] or [Loan_FA_YearBookPageFmt] like Substring(w.RecordingDt,1,4) + [FormatBook] + '.' + [FormatPage])
and w.ChronoKey like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].[Release] r with(NOLOCK)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and (substring(r.BorrowerFullName,1,3) = substring(w.TransNAME1FULL,1,3) 
or substring(r.Borrower1LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower1fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower1fullNamestd,1,3) + '%'
or r.Borrower1fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.BorrowerFullName,1,3) + '%'
or r.BorrowerFullName like '%' + substring(w.TransName1Full,1,3) + '%'
or substring(r.Borrower2LastName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2FirstName,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2MiddleInitial,1,3) = substring(w.TransNAME1FULL,1,3)
or substring(r.Borrower2fullNamestd,1,3) = substring(w.TransNAME1FULL,1,3)
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%'
or w.TransName1Full like '%' + substring(r.Borrower2fullNamestd,1,3) + '%'
or r.Borrower2fullNamestd like '%' + substring(w.TransName1Full,1,3) + '%')
and w.ReleaseDate is null
and w.TransactionId <> 888888888
and ([Loan_FA_DocNbrFmt] like [FormatDocNbr] or [Loan_FA_YearDocNbrFmt] like [FormatDocNbr] or [Loan_FA_YearDayDocNumFmt] like [FormatDocNbr]
     or [Loan_FA_YearBookPageFmt] like [FormatBook] + '.' + [FormatPage] or [Loan_FA_YearBookPageFmt] like Substring(w.RecordingDt,1,4) + [FormatBook] + '.' + [FormatPage])
and w.ChronoKey like '%xz' and (right(OrigDeedDocNbr,3) = right([InputDocNbr],3) or (right(OrigDeedPage,3) = right([InputPage],3) or right(OrigDeedPage,3) = right([FormatPage],3)))
and r.FAUCIDFlag <> 'D'

----  Added to Fix the release of 2nd mtg with no document number/book page  --20251113 BR
Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FADeedId and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey like '%xz' and cast(LoanAmt as varchar) = OrigLoanAmt
and r.FAUCIDFlag <> 'D'

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = 'Y'
,ReleaseDate = r.RecordingDt
,ReleaseTransactionID = r.transactionID
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
join [Data].[dbo].release r with (nolock)
on r.fips = w.fips and w.transactionid = r.FASAMID and w.PropertyID = r.faPropertyID
where r.FIPS = @Fips and r.Borrower1LastName is null and w.ReleaseDate is null
and w.TransactionId <> 888888888
and w.ChronoKey like '%xz' and cast(LoanAmt as varchar) = OrigLoanAmt
and r.FAUCIDFlag <> 'D'

-----

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
Set ReleaseFlag = null
,ReleaseDate = null
,ReleaseTransactionID = null
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where recordingdt > Releasedate

----  Dedup Process

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups]

Insert into [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups] (fips, propertyid,DocNum, cnt, MinTID)
select fips, propertyid, coalesce([FormatDocNbr],[InputDocNbr],([FormatBook] + [FormatPage])) as DocNum, count(propertyid) as cnt, min(transactionid) as MinTID
  --into [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups]
    FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
	where coalesce([FormatDocNbr],[InputDocNbr],([FormatBook] + [FormatPage])) is not null and TransactionId <> 888888888
	group by fips, propertyid, coalesce([FormatDocNbr],[InputDocNbr],([FormatBook] + [FormatPage]))
	having count(propertyid) > 1

Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set DeleteFlag = 'D'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups] d
on d.fips = w.fips
and d.propertyid = w.propertyid
and d.docNum = coalesce([FormatDocNbr],[InputDocNbr],([FormatBook] + [FormatPage]))
where w.TransactionId <> MinTID

Delete from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where DeleteFlag = 'D'

----  Dedup Process 2

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups3]

Insert into [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups3] (fips, propertyid ,DocYear, LoanAmt, Lender, cnt, MaxTID, MaxChrono)

select fips, propertyid, Substring(recordingdt,1,4) as DocYear, LoanAmt, substring(replace(Lender,' ',''),1,8),  count(propertyid) as cnt, max(transactionid) as MaxTID, max(chronokey) as MaxChrono
  --into [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups3]
    FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
	where Substring(recordingdt,1,4) is not null and ReleaseFlag is null
	group by fips, propertyid, Substring(recordingdt,1,4), substring(replace(Lender,' ',''),1,8), LoanAmt
	having count(propertyid) > 1

Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set DeleteFlag = 'D'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_CleanDups3] d
on d.fips = w.fips
and d.propertyid = w.propertyid
and MaxChrono = chronokey

Delete from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where DeleteFlag = 'D'




------------
---202

--Update [Transaction_Mtg_LienPOS_Work]
--set currentAVM = v.final_value
--From [Transaction_Mtg_LienPOS_Work] w
--Join AVM v with(NOLOCK)
--on v.Fips = w. fips and v.PropertyID = w.PropertyID

---- Added 20221222 Bring in New AVM MAS

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
SET CurrentAVM = coalesce(v.[PREMIER_FINAL_VALUE],v.[POWER_FINAL_VALUE],v.[DIRECT_FINAL_VALUE]) 
From Transaction_Mtg_LienPOS_Work w
	JOIN Holocron.dbo.Holocron v with(NOLOCK)
ON v.Fipscode = w.FIPS
and v.PropertyID = w.PropertyID
WHERE v.FIPS = @Fips

Update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
SET CurrentAVM = FINAL_VALUE
From [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work w
	JOIN [Data].[dbo].[AVM] v with(NOLOCK)
ON v.Fips = w.FIPS
and v.PropertyID = w.PropertyID
WHERE v.FIPS = @Fips and CurrentAVM is null

---  Added 20180816 to use MArket Value and Assessed Value

Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set currentAVM = Coalesce(Case WHEN MarketTotalValue = 0 THEN NULL ELSE MarketTotalValue END,AssdTotalValue)
From [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
Join [DragonAssr].[dbo].[PropertyWork] v with(NOLOCK)
on v.fips = w.fips and v.PropertyID = w.PropertyID
WHERE isNULL(currentAVM,'0') like '0'


---- Added 2023113 to add 0 to current AVM
Update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set currentAVM = 0
From [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
Join [DragonAssr].[dbo].[PropertyWork] v with(NOLOCK)
on v.fips = w.fips and v.PropertyID = w.PropertyID
WHERE currentAVM is null


---  Calc Refi and Equity

---- Commented OUT next 2 queries They are in the next Query 20221222 MAS

--update [Transaction_Mtg_LienPOS_Work]
--set CalcRefi = 'Y'
--from [Transaction_Mtg_LienPOS_Work]
--where 
--(Recordingdt between '20170101' and '21991231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.50)
--or
--(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.45)
--or
--(Recordingdt between '19900101' and '20091231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.35)

--update [Transaction_Mtg_LienPOS_Work]
--set CalcEquity = 'Y'
--from [Transaction_Mtg_LienPOS_Work]
--where 
--(Recordingdt between '20100101' and '21991231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.50)
--or
--(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.45)
--or
--(Recordingdt between '19900101' and '20091231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.35)


--update Transaction_Mtg_LienPOS_Work
--set
--CalcRefi = null
--,CalcEquity = null
--from Transaction_Mtg_LienPOS_Work

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set CalcRefi = 'Y'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CurrentAVM = 0 and RefiFlag is not null and CalcRefi is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set CalcEquity = 'Y'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CurrentAVM = 0 and (LienPosition =2 or EquityFlag is not null) and CalcEquity is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set CalcRefi = 'Y'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CurrentAVM = 0 and RefiFlag is null and CalcRefi is null and LoanAmt > 99999  and CalcEquity is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set CalcEquity = 'Y'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and LoanAmt < 100000  and CalcRefi is null 

-----  Added 20231113 to have all Mtgs with Calc Equity
update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
set CalcEquity = 'Y'
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and CalcRefi is null


------------
---203

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcRefi = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where 
(Recordingdt between '20210101' and '21991231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.50)
or
(Recordingdt between '20170101' and '20201231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.42)
or
(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.33)
or
(Recordingdt between '20070101' and '20091231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.25)
or
(Recordingdt between '19900101' and '20061231' and CurrentAVM > 0 and (LienPosition =1 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) >=.18)

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcEquity = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where 
(Recordingdt between '20210101' and '21991231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.50)
or
(Recordingdt between '20170101' and '20201231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.42)
or
(Recordingdt between '20100101' and '20161231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.33)
or
(Recordingdt between '20070101' and '20091231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.25)
or
(Recordingdt between '19900101' and '20061231' and CurrentAVM > 0 and (LienPosition =2 or LienPosition is null) and Cast((cast(LoanAmt as float)/cast(Currentavm as float)) as float) <.18)
and CalcRefi is null

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set
CalcRefi = 'Y'
,CalcEquity = Null
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where RefiFlag = 'Y' and RecordingDt > '20210101' and CalcRefi is null and LoanAmt > 125000

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcRefi = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where CurrentAVM = 0 and RefiFlag is not null and CalcRefi is null

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcEquity = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where CurrentAVM = 0 and (LienPosition =2 or EquityFlag is not null) and CalcEquity is null

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcRefi = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where CurrentAVM = 0 and RefiFlag is null and CalcRefi is null and LoanAmt > 39999  and CalcEquity is null

update [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
set CalcEquity = 'Y'
from [DragonAssr].[dbo].Transaction_Mtg_LienPOS_Work
where CurrentAVM  = 0 and (LienPosition =2 or EquityFlag is null) and CalcEquity is null and LoanAmt < 40000  and CalcRefi is null 

------------
---211

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [LienPosition] = 1
order by [ChronoKey] desc



------------
---212

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set LastPurchase = t.RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.PropertyID = t.PropertyID

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set PropLastPurchase = p.CurrSaleRecordingDate
,Seller = p.CurrSaleSeller1FullName
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] t
join [DragonAssr].[dbo].[PropertyWork] p with(NOLOCK)
on p.fips = t.fips and p.propertyid = t.PropertyID
and substring(p.CurrSaleSeller1FullName,1,4) <> substring(p.CurrSaleBuyer1FullName,1,4) and CurrSalesPrice > 125000 and CurrSalesPriceCode not in ('55','68','O','61','14')
--Where p.FIPS = @Fips

------------
---213

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---221

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [LienPosition] is null and CalcRefi = 'Y'
order by [ChronoKey] desc

------------
---222

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set LastRefi = t.RecordingDt
,LastRefiAmt = t.LoanAmt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.PropertyID = t.PropertyID

------------
---223

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---231

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,LoanAmt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
		   ,Loanamt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [LienPosition] is null and CalcEquity = 'Y'
order by [ChronoKey] desc



------------
---232

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set LastEquity = t.RecordingDt
,LastEquityAmt = t.LoanAmt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.PropertyID = t.PropertyID



------------
---233

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---301

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CalcMtgOrder is null and ([LienPosition] is null or [LienPosition] = 1)
order by [ChronoKey] desc
--RecordingDt desc, 




------------
---302

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 1
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 2
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

------------
---303

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---311

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 



------------
---312

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 2
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
and CalcMtgOrder is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 3
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

------------
---313

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---321

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 



------------
---322

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 3
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 4
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

------------
---323

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---331

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 



------------
---332

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 4
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 5
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2

-----  Number 5
Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
-----
INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt)
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
		   ,RecordingDt
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
order by [ChronoKey] desc
--RecordingDt desc, 
------
update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 5
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where CalcMtgOrder is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcMtgOrder = 6
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.TransactionId = t.TransactionId
where t.TransactionId = 1 and w.TransactionId = 2


------------
---333

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]

--USE [Data]

--INSERT INTO [dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
--           ([FIPS]
--           ,[PropertyID]
--           ,[TransactionId]
--           ,[ChronoKey]
--           ,[LienPosition]
--		   ,RecordingDt)
--Select
--            [FIPS]
--           ,[PropertyID]
--           ,[TransactionId]
--           ,[ChronoKey]
--           ,[LienPosition]
--		   ,RecordingDt
--from [dbo].[Transaction_Mtg_LienPOS_Work]
--where CalcMtgOrder is null and (([LienPosition] is null or [LienPosition] = 1) or ([LienPosition] is null or [LienPosition] = 2))
--order by [ChronoKey] desc
----RecordingDt desc, 

----
--use data

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcMtgOrder = 5
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.TransactionId = t.TransactionId
--where CalcMtgOrder is null

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcMtgOrder = 6
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.TransactionId = t.TransactionId
--where t.TransactionId = 1 and w.TransactionId = 2

----
--Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---400

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'W'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and LoanDueDt <  Cast(format(GetDate()-1,'yyyyMMdd') as varchar) and ModDueDate is null

--update [Transaction_Mtg_LienPOS_Work]
--Set ReleaseFlag = 'P'
--FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
--where [ReleaseFlag] is null and [LastPurchase] is not null and [LastPurchase] > [RecordingDt] and LienPosition is not null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'Q'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastPurchase] is not null and [LastPurchase] > convert(varchar(8), convert(datetime,[RecordingDt])+7,112) and LienPosition is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'R'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [PropLastPurchase] is not null and [PropLastPurchase] > convert(varchar(8), convert(datetime,[RecordingDt])+7,112) --and LienPosition is null
and substring(OwnerStdNAME1FULL,1,4) <> substring(TransNAME1FULL,1,4)

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'S'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastPurchase] is not null and [LastRefi] > [LastPurchase] and LienPosition is not null and [RecordingDt] < [LastRefi]

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'T'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastRefi] > [RecordingDt] and CalcRefi ='Y'
and Cast((cast(LoanAmt as float) + cast(LastEquityAmt as float)) as float) > CurrentAVM * .9

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 't'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastRefi] > [RecordingDt] and CalcRefi ='Y'

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'U'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastRefi] > [RecordingDt] and CalcEquity = 'Y'
and Cast((cast(LoanAmt as float) + cast(LastRefiAmt as float)) as float) > CurrentAVM *1.1  --*.9

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'V'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastEquity] > [RecordingDt] and CalcEquity ='Y' --and Cast((cast(LoanAmt as float)/cast(LastEquityAmt as float)) as float) <.65
and Cast((cast(LoanAmt as float) + cast(LastEquityAmt as float)) as float) > CurrentAVM * .9

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'v'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and [LastEquity] > [RecordingDt] and CalcEquity ='Y' --and Cast((cast(LoanAmt as float)/cast(LastEquityAmt as float)) as float) <.65
and Cast((cast(LoanAmt as float) + cast(LastEquityAmt as float) + cast(LastRefiAmt as float)) as float) > CurrentAVM * 1.2

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'X'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where Releaseflag is null and Calcrefi is null and Calcequity is null
and lastequity > recordingdt
and cast(lastequityamt as float) > cast(cast(loanamt as float) * .50 as float)
and recordingdt <'20121231'

----   20230419  BR added to close old mortgages not closed before
update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'Z'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where Releaseflag is null 
and convert(varchar(8),DateAdd(YY,+18,RecordingDT),112) < convert(varchar(8),GETDATE(),112)
and CalcMtgOrder is null

--update [Transaction_Mtg_LienPOS_Work]      ---   20180318  BR Added due to last equity not closing old original Mortgage
--Set ReleaseFlag = 'z'
--FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
--where Releaseflag is null 
--and convert(varchar(8),DateAdd(YY,+15,RecordingDT),112) < convert(varchar(8),GETDATE(),112)
--and substring(OwnerStdNAME1FULL,1,4) <> substring(TransNAME1FULL,1,4)
--and OwnerStdNAME1FULL not like '%trust%'

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]      ---   20180318  BR Added due to last equity not closing old original Mortgage
Set ReleaseFlag = 'z'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where Releaseflag is null 
and convert(varchar(8),DateAdd(YY,+24,RecordingDT),112) < convert(varchar(8),GETDATE(),112)
and CalcMtgOrder > 2

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]    ---   20180320  BR Added to keep Mtgs that have a more recent Assignment
Set ReleaseFlag = null
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Where [AssgnDate] is not null
and ([AssgnDate] > isnull(lastrefi,0) and [AssgnDate] > isnull(lastequity,0) and [AssgnDate] > isnull(lastpurchase,0) and [AssgnDate] > [recordingdt])
and (releaseflag is not null and releaseflag != 'Y')

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]    ---   20200108  BR Added to keep Mtgs that have a more recent Modification
Set ReleaseFlag = null
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Where [ModDate] is not null
and ([ModDate] > isnull(lastrefi,0) and [ModDate] > isnull(lastequity,0) and [ModDate] > isnull(lastpurchase,0) and [ModDate] > [recordingdt])
and (releaseflag is not null and releaseflag != 'Y')
and [PropLastPurchase] < [recordingdt]

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = 'W'
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where [ReleaseFlag] is null and LoanDueDt <  Cast(format(GetDate()-1,'yyyyMMdd') as varchar)  and ModDueDate is null

-----  BR Added to account for certain lenders

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]    ---   20200108  BR Added to keep Mtgs that have a more recent Modification
Set ReleaseFlag = null
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Where 
([Lender] like 'NATIONAL HOMEBUYERS FUND%' 
or
[Lender] like 'CRHMFA HOMEBUYERS FUND%')
and ReleaseFlag in ('S','V')

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = null
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where [SubDate] is not null and [ReleaseFlag] is not null
  and ReleaseFlag <> 'y'
  and SubOrgRecordDt = Recordingdt

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = null
FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where [ModDate] is not null and [ReleaseFlag] is not null
  --and ReleaseFlag <> 'y'
  and ReleaseFlag = 'W'
  and ModDueDate > LoanDueDt

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set ReleaseFlag = null
  FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
  where [ModDate] is not null and [ReleaseFlag] is not null
  and ReleaseFlag <> 'y'



------------
---501

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ((CalcLienPos is null and ReleaseFlag is null and CalcRefi = 'Y')
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 1))
and CalcMtgOrder is not null
and ReleaseFlag is null
order by recordingdt desc, [ChronoKey] desc




------------
---502

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 1
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and w.TransactionId = t.TransactionId
and w.ChronoKey = t.ChronoKey
where (w.LienPosition = 1 or t.LienPosition is null)
and t.transactionid <> 888888888
and w.CalcLienPos is null
and ReleaseFlag is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 1
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and t.ChronoKey = w.ChronoKey
where (w.LienPosition = 1 or t.LienPosition is null)
and t.transactionid = 888888888
and w.CalcLienPos is null
and ReleaseFlag is null



------------
---503

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---511

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ((CalcLienPos is null and ReleaseFlag is null and CalcRefi = 'Y')
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 1)
or
(CalcLienPos is null and ReleaseFlag is null and [LienPosition] = 2)  --  Added during Accurate Mtg QC
or
(CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))   --  this is the original
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
and ReleaseFlag is null
order by recordingdt , [ChronoKey] asc




------------
---512

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 2
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and w.TransactionId = t.TransactionId
and w.ChronoKey = t.ChronoKey
where ((w.LienPosition = 2 or t.LienPosition is null)
or (w.LienPosition = 1 or t.LienPosition is null))
and w.CalcLienPos is null
and ReleaseFlag is null
and t.transactionid <> 888888888

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 2
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.ChronoKey = t.ChronoKey
where ((w.LienPosition = 2 or t.LienPosition is null)
or (w.LienPosition = 1 or t.LienPosition is null))
and w.CalcLienPos is null
and ReleaseFlag is null
and t.transactionid = 888888888



------------
---513

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---521

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
and ReleaseFlag is null
order by recordingdt , [ChronoKey] asc



------------
---522

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 3
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and w.TransactionId = t.TransactionId
and w.ChronoKey = t.ChronoKey
where (w.LienPosition = 2 or t.LienPosition is null)
and w.CalcLienPos is null
and ReleaseFlag is null
and t.transactionid <> 888888888


update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 3
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.ChronoKey = t.ChronoKey
where (w.LienPosition = 2 or t.LienPosition is null)
and w.CalcLienPos is null
and ReleaseFlag is null
and t.transactionid = 888888888



------------
---523

Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
------------
---531

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
and ReleaseFlag is null
order by recordingdt, [ChronoKey] asc




------------
--532

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 4
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and w.TransactionId = t.TransactionId
and w.ChronoKey = t.ChronoKey
where (w.LienPosition = 2 or t.LienPosition is null)
and t.transactionid <> 888888888
and ReleaseFlag is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 4
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.ChronoKey = t.ChronoKey
where (w.LienPosition = 2 or t.LienPosition is null)
and t.transactionid = 888888888
and ReleaseFlag is null


------------
---533
Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]

----- Number 5
INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition])
Select
            [FIPS]
           ,[PropertyID]
           ,[TransactionId]
           ,[ChronoKey]
           ,[LienPosition]
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ((CalcLienPos is null and ReleaseFlag is null and CalcEquity = 'Y'))
and CalcMtgOrder is not null  --  Added to only evaluate last 5 Mortgages
order by recordingdt , [ChronoKey] asc
---
update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 5
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on t.fips = w.fips
and w.TransactionId = t.TransactionId
and w.ChronoKey = t.ChronoKey
where (w.LienPosition = 2 or t.LienPosition is null)
and t.transactionid <> 888888888
and CalcLienPos is null
and ReleaseFlag is null

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 5
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.ChronoKey = t.ChronoKey
where w.LienPosition = 2 or t.LienPosition is null
and t.transactionid = 888888888
and CalcLienPos is null
and ReleaseFlag is null
-----
Truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]


------------
---551

truncate table [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]

INSERT INTO [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder]
           ([FIPS]
           ,[PropertyID]
           ,MinLienPos
		   ,MaxLienPos
		   ,OpenLiens
           )
 Select
            [FIPS]
           ,[PropertyID]
           ,Min(CalcLienPos)
		   ,Max(CalcLienPos)
		   ,Count([PropertyID])
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
where ReleaseFlag is null
and CalcLienPos is not null
Group by fips, [PropertyID]
order by fips, [PropertyID]


------------
---552

--  Min 2
update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 1
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 2 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 1
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 2 and t.MinLienPos = 2
and t.MaxLienPos = t.OpenLiens

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 2
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 3 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens

update [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
Set CalcLienPos = 3
from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work_MtgOrder] t
on w.Propertyid = t.Propertyid
where w.CalcLienPos = 4 and t.MinLienPos = 2
and t.MaxLienPos > t.OpenLiens



--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 2
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 3 and t.MinLienPos = 1
--and t.MaxLienPos > t.OpenLiens

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 3
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 4 and t.MinLienPos = 2
--and t.MaxLienPos > t.OpenLiens

--update [Transaction_Mtg_LienPOS_Work]
--Set CalcLienPos = 3
--from [Transaction_Mtg_LienPOS_Work] w
--join [Transaction_Mtg_LienPOS_Work_MtgOrder] t
--on w.Propertyid = t.Propertyid
--where w.CalcLienPos = 4 and t.MinLienPos = 3



------------
---600

CREATE NONCLUSTERED INDEX [PropertyID] ON [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
(	[FIPS] ASC,
	[PropertyID] ASC)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)





------------
---600

update [DragonAssr].[dbo].[PropertyWork]
set
       [LienPosUpdateFlag] = 'Y'
      ,[FADeriveProcessDt] = GetDate()
      ,[TotalOpenLienAmt] = null
      ,[TotalOpenLienNbr] = null
      ,[Mtg1TransactionId] = Null
      ,[Mtg1ChronoKey] = Null
	  ,[Mtg1InputDocNbr] = Null
      ,[Mtg1InputBook] = Null
      ,[Mtg1InputPage] = Null
	  ,[Mtg1FormatDocNbr] = null
	  ,[Mtg1FormatBook] = Null
	  ,[Mtg1FormatPage] = null
	  ,[Mtg1RecordingDt] = Null
      ,[Mtg1LoanAmt] = Null
      ,[Mtg1Lender] = Null
      ,[Mtg1LenderCode] = Null
      ,[Mtg1LenderType] = Null
      ,[Mtg1PrivateLender] = Null
      ,[Mtg1Term] = Null
      ,[Mtg1LoanDueDt] = Null
      ,[Mtg1AdjRider] = Null
      ,[Mtg1LoanType] = Null
      ,[Mtg1Typefinancing] = Null
      ,[Mtg1LienPosition] = Null
      ,[Mtg2TransactionId] = Null
      ,[Mtg2ChronoKey] = Null
	  ,[Mtg2InputDocNbr] = Null
      ,[Mtg2InputBook] = Null
      ,[Mtg2InputPage] = Null
	  ,[Mtg2FormatDocNbr] = null
	  ,[Mtg2FormatBook] = Null
	  ,[Mtg2FormatPage] = null
	  ,[Mtg2RecordingDt] = Null
      ,[Mtg2LoanAmt] = Null
      ,[Mtg2Lender] = Null
      ,[Mtg2LenderCode] = Null
      ,[Mtg2LenderType] = Null
      ,[Mtg2PrivateLender] = Null
      ,[Mtg2Term] = Null
      ,[Mtg2LoanDueDt] = Null
      ,[Mtg2AdjRider] = Null
      ,[Mtg2LoanType] = Null
      ,[Mtg2Typefinancing] = Null
      ,[Mtg2LienPosition] = Null
      ,[Mtg3TransactionId] = Null
      ,[Mtg3ChronoKey] = Null
	  ,[Mtg3InputDocNbr] = Null
      ,[Mtg3InputBook] = Null
      ,[Mtg3InputPage] = Null
	  ,[Mtg3FormatDocNbr] = null
	  ,[Mtg3FormatBook] = Null
	  ,[Mtg3FormatPage] = null
	  ,[Mtg3RecordingDt] = Null
      ,[Mtg3LoanAmt] = Null
      ,[Mtg3Lender] = Null
      ,[Mtg3LenderCode] = Null
      ,[Mtg3LenderType] = Null
      ,[Mtg3PrivateLender] = Null
      ,[Mtg3Term] = Null
      ,[Mtg3LoanDueDt] = Null
      ,[Mtg3AdjRider] = Null
      ,[Mtg3LoanType] = Null
      ,[Mtg3Typefinancing] = Null
      ,[Mtg3LienPosition] = Null
      ,[Mtg4TransactionId] = Null
      ,[Mtg4ChronoKey] = Null
	  ,[Mtg4InputDocNbr] = Null
      ,[Mtg4InputBook] = Null
      ,[Mtg4InputPage] = Null
	  ,[Mtg4FormatDocNbr] = null
	  ,[Mtg4FormatBook] = Null
	  ,[Mtg4FormatPage] = null
	  ,[Mtg4RecordingDt] = Null
      ,[Mtg4LoanAmt] = Null
      ,[Mtg4Lender] = Null
      ,[Mtg4LenderCode] = Null
      ,[Mtg4LenderType] = Null
      ,[Mtg4PrivateLender] = Null
      ,[Mtg4Term] = Null
      ,[Mtg4LoanDueDt] = Null
      ,[Mtg4AdjRider] = Null
      ,[Mtg4LoanType] = Null
      ,[Mtg4Typefinancing] = Null
      ,[Mtg4LienPosition] = Null
	  ,[Mtg1EstLoanBalance] = Null
      ,[Mtg1EstPaymentAmt] = Null
      ,[Mtg1InterestRate] = Null
	  ,[Mtg2EstLoanBalance] = Null
      ,[Mtg2EstPaymentAmt] = Null
      ,[Mtg2InterestRate] = Null
      ,[Mtg3EstLoanBalance] = Null
      ,[Mtg3EstPaymentAmt] = Null
      ,[Mtg3InterestRate] = Null
      ,[Mtg4EstLoanBalance] = Null
      ,[Mtg4EstPaymentAmt] = Null
      ,[Mtg4InterestRate] = Null
	  ,MTG1InterestRateSrce = Null
	  ,MTG2InterestRateSrce = Null
	  ,MTG3InterestRateSrce = Null
	  ,MTG4InterestRateSrce = Null
from [DragonAssr].[dbo].[PropertyWork] p
join (Select fips,PropertyID from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] with(NOLOCK) group by fips,propertyid) w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
--WHERE p.FIPS = @Fips
----- Update join to remove multi join 20221222 MAS

--Select count(*)
--from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]
------------
---601

Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg1TransactionId] = w.TransactionId
      ,[Mtg1ChronoKey] = Substring(w.ChronoKey,1,31)
	  ,[Mtg1InputDocNbr] = w.InputDocNbr
      ,[Mtg1InputBook] = w.InputBook
      ,[Mtg1InputPage] = w.InputPage
	  ,[Mtg1FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg1FormatBook] = w.[FormatBook]
	  ,[Mtg1FormatPage] = w.[FormatPage]
	  ,[Mtg1RecordingDt] = w.RecordingDt
      ,[Mtg1LoanAmt] = w.LoanAmt
      ,[Mtg1Lender] = w.Lender
      ,[Mtg1LenderCode] = w.LenderCode
      ,[Mtg1LenderType] = w.LenderType
      ,[Mtg1PrivateLender] = w.PrivateLender
      ,[Mtg1Term] = w.Term
      ,[Mtg1LoanDueDt] = w.LoanDueDt
      ,[Mtg1AdjRider] = w.AdjRider
      ,[Mtg1LoanType] = w.LoanType
      ,[Mtg1Typefinancing] = w.Typefinancing
      ,[Mtg1LienPosition] = w.CalcLienPos
	  ,[Mtg1InterestRate] = w.[InterestRate]
	  ,MTG1InterestRateSrce = w.InterestRateSrce
from [DragonAssr].[dbo].[PropertyWork] p
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 1


------------
---602

Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg2TransactionId] = w.TransactionId
      ,[Mtg2ChronoKey] = Substring(w.ChronoKey,1,31)
	  ,[Mtg2InputDocNbr] = w.InputDocNbr
      ,[Mtg2InputBook] = w.InputBook
      ,[Mtg2InputPage] = w.InputPage
	  ,[Mtg2FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg2FormatBook] = w.[FormatBook]
	  ,[Mtg2FormatPage] = w.[FormatPage]
	  ,[Mtg2RecordingDt] = w.RecordingDt
      ,[Mtg2LoanAmt] = w.LoanAmt
      ,[Mtg2Lender] = w.Lender
      ,[Mtg2LenderCode] = w.LenderCode
      ,[Mtg2LenderType] = w.LenderType
      ,[Mtg2PrivateLender] = w.PrivateLender
      ,[Mtg2Term] = w.Term
      ,[Mtg2LoanDueDt] = w.LoanDueDt
      ,[Mtg2AdjRider] = w.AdjRider
      ,[Mtg2LoanType] = w.LoanType
      ,[Mtg2Typefinancing] = w.Typefinancing
      ,[Mtg2LienPosition] = w.CalcLienPos
	  ,[Mtg2InterestRate] = w.[InterestRate]
	  ,MTG2InterestRateSrce = w.InterestRateSrce
from [DragonAssr].[dbo].[PropertyWork] p
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 2

------------
---603

Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg3TransactionId] = w.TransactionId
      ,[Mtg3ChronoKey] = Substring(w.ChronoKey,1,31)
	  ,[Mtg3InputDocNbr] = w.InputDocNbr
      ,[Mtg3InputBook] = w.InputBook
      ,[Mtg3InputPage] = w.InputPage
	  ,[Mtg3FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg3FormatBook] = w.[FormatBook]
	  ,[Mtg3FormatPage] = w.[FormatPage]
	  ,[Mtg3RecordingDt] = w.RecordingDt
      ,[Mtg3LoanAmt] = w.LoanAmt
      ,[Mtg3Lender] = w.Lender
      ,[Mtg3LenderCode] = w.LenderCode
      ,[Mtg3LenderType] = w.LenderType
      ,[Mtg3PrivateLender] = w.PrivateLender
      ,[Mtg3Term] = w.Term
      ,[Mtg3LoanDueDt] = w.LoanDueDt
      ,[Mtg3AdjRider] = w.AdjRider
      ,[Mtg3LoanType] = w.LoanType
      ,[Mtg3Typefinancing] = w.Typefinancing
      ,[Mtg3LienPosition] = w.CalcLienPos
	  ,[Mtg3InterestRate] = w.[InterestRate]
	  ,MTG3InterestRateSrce = w.InterestRateSrce
from [DragonAssr].[dbo].[PropertyWork] p
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 3

------------
---604

Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg4TransactionId] = w.TransactionId
      ,[Mtg4ChronoKey] = Substring(w.ChronoKey,1,31)
	  ,[Mtg4InputDocNbr] = w.InputDocNbr
      ,[Mtg4InputBook] = w.InputBook
      ,[Mtg4InputPage] = w.InputPage
	  ,[Mtg4FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg4FormatBook] = w.[FormatBook]
	  ,[Mtg4FormatPage] = w.[FormatPage]
	  ,[Mtg4RecordingDt] = w.RecordingDt
      ,[Mtg4LoanAmt] = w.LoanAmt
      ,[Mtg4Lender] = w.Lender
      ,[Mtg4LenderCode] = w.LenderCode
      ,[Mtg4LenderType] = w.LenderType
      ,[Mtg4PrivateLender] = w.PrivateLender
      ,[Mtg4Term] = w.Term
      ,[Mtg4LoanDueDt] = w.LoanDueDt
      ,[Mtg4AdjRider] = w.AdjRider
      ,[Mtg4LoanType] = w.LoanType
      ,[Mtg4Typefinancing] = w.Typefinancing
      ,[Mtg4LienPosition] = w.CalcLienPos
	  ,[Mtg4InterestRate] = w.[InterestRate]
	  ,MTG4InterestRateSrce = w.InterestRateSrce
from [DragonAssr].[dbo].[PropertyWork] p
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 4

------------
---610

---  Moved Query
--Update Property
--set [TotalOpenLienAmt]  = case when convert(bigint, isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)) < 100000000 then isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0) else 0 end
--,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
--,[LienPosUpdateFlag] = 'Y'
--,[LienPosUpdateDate] = GetDate()
--from property p
--join [Transaction_Mtg_LienPOS_Work] w
--on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
--where ([Mtg1TransactionId] is not null or [Mtg2TransactionId] is not null) and (Mtg1LoanAmt < 1000000000 or Mtg2LoanAmt < 1000000000)

---  Correct Lien Position
----  Lien Pos 2 to 1
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg1TransactionId] = [Mtg2TransactionId]
,[Mtg1ChronoKey] = [Mtg2ChronoKey]
,[Mtg1InputDocNbr] = [Mtg2InputDocNbr]
,[Mtg1InputBook] = [Mtg2InputBook]
,[Mtg1InputPage] = [Mtg2InputPage]
,[Mtg1FormatDocNbr] = [Mtg2FormatDocNbr]
,[Mtg1FormatBook] = [Mtg2FormatBook]
,[Mtg1FormatPage] = [Mtg2FormatPage]
,[Mtg1RecordingDt] = [Mtg2RecordingDt]
,[Mtg1LoanAmt] = [Mtg2LoanAmt]
,[Mtg1Lender] = [Mtg2Lender]
,[Mtg1LenderCode] = [Mtg2LenderCode]
,[Mtg1LenderType] = [Mtg2LenderType]
,[Mtg1PrivateLender] = [Mtg2PrivateLender]
,[Mtg1LoanDueDt] = [Mtg2LoanDueDt]
,[Mtg1AdjRider] = [Mtg2AdjRider]
,[Mtg1LoanType] = [Mtg2LoanType]
,[Mtg1Typefinancing] = [Mtg2Typefinancing]
,[Mtg1LienPosition] = Case when [Mtg2TransactionId] is not null then 1 else Null end
,[Mtg1Term] = [Mtg2Term]
,[Mtg1EstPaymentAmt] = [Mtg2EstPaymentAmt]
,[Mtg1InterestRate] = [Mtg2InterestRate]
,[Mtg1EstLoanBalance] = [Mtg2EstLoanBalance]
,MTG1InterestRateSrce = MTG2InterestRateSrce

,[Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]
,MTG2InterestRateSrce = MTG3InterestRateSrce

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]
,MTG3InterestRateSrce = MTG4InterestRateSrce

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null
,MTG4InterestRateSrce = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when Mtg1LienPosition is null then 0 else 1 end + Case when Mtg2LienPosition is null then 0 else 1 end + Case when Mtg3LienPosition is null then 0 else 1 end + Case when Mtg4LienPosition is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FADeriveProcessDt] = GetDate()

From [DragonAssr].[dbo].[PropertyWork]
Where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND [Mtg1TransactionId] is null and [Mtg2TransactionId] is not null

---- Lien Pos 3 to 2
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]
,MTG2InterestRateSrce = MTG3InterestRateSrce

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]
,MTG3InterestRateSrce = MTG4InterestRateSrce

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null
,MTG4InterestRateSrce = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FADeriveProcessDt] = GetDate()

From [DragonAssr].[dbo].[PropertyWork]
Where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND [Mtg2TransactionId] is null and [Mtg3TransactionId] is not null

---- Lien Pos 4 to 3
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]
,MTG3InterestRateSrce = MTG4InterestRateSrce

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null
,MTG4InterestRateSrce = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'
,[FADeriveProcessDt] = GetDate()

From [DragonAssr].[dbo].[PropertyWork]
Where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND [Mtg3TransactionId] is null and [Mtg4TransactionId] is not null

-----20231113 added for instance of rolled up 4 leaving 4 null
Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg4TransactionId] = w.TransactionId
      ,[Mtg4ChronoKey] = Substring(w.ChronoKey,1,31)
	  ,[Mtg4InputDocNbr] = w.InputDocNbr
      ,[Mtg4InputBook] = w.InputBook
      ,[Mtg4InputPage] = w.InputPage
	  ,[Mtg4FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg4FormatBook] = w.[FormatBook]
	  ,[Mtg4FormatPage] = w.[FormatPage]
	  ,[Mtg4RecordingDt] = w.RecordingDt
      ,[Mtg4LoanAmt] = w.LoanAmt
      ,[Mtg4Lender] = w.Lender
      ,[Mtg4LenderCode] = w.LenderCode
      ,[Mtg4LenderType] = w.LenderType
      ,[Mtg4PrivateLender] = w.PrivateLender
      ,[Mtg4Term] = w.Term
      ,[Mtg4LoanDueDt] = w.LoanDueDt
      ,[Mtg4AdjRider] = w.AdjRider
      ,[Mtg4LoanType] = w.LoanType
      ,[Mtg4Typefinancing] = w.Typefinancing
      ,[Mtg4LienPosition] = w.CalcLienPos
	  ,[Mtg4InterestRate] = w.[InterestRate]
	  ,MTG4InterestRateSrce = InterestRateSrce
from [DragonAssr].[dbo].[PropertyWork] p
join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 5 and [Mtg4TransactionId] is null


/************  ADDED TO CLEAN LARGE DUPLICATE OPEN LIENS ******************/
----- FIX Duplicate in 1st and 2nd  by Amount, Date, InstNbrs

	DROP TABLE IF EXISTS [DragonAssr].[dbo].CheckThese 

	Select Distinct FIPS,PropertyID INTO [DragonAssr].[dbo].CheckThese from [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]

	CREATE INDEX ixFipsPropID on [DragonAssr].[dbo].CheckThese(FIPS,PropertyID)

----- Link DocNBR
		Update [DragonAssr].[dbo].[PropertyWork]
		set [Mtg2TransactionId] = Null
			  ,[Mtg2ChronoKey] = Null
			  ,[Mtg2InputDocNbr] = Null
			  ,[Mtg2InputBook] = Null
			  ,[Mtg2InputPage] = Null
			  ,[Mtg2RecordingDt] = Null
			  ,[Mtg2LoanAmt] = Null
			  ,[Mtg2Lender] = Null
			  ,[Mtg2LenderCode] = Null
			  ,[Mtg2LenderType] = Null
			  ,[Mtg2PrivateLender] = Null
			  ,[Mtg2Term] = Null
			  ,[Mtg2LoanDueDt] = Null
			  ,[Mtg2AdjRider] = Null
			  ,[Mtg2LoanType] = Null
			  ,[Mtg2Typefinancing] = Null
			  ,[Mtg2LienPosition] = Null
			  ,[Mtg3TransactionId] = Null
			  ,[Mtg3ChronoKey] = Null
			  ,[Mtg3InputDocNbr] = Null
			  ,[Mtg3InputBook] = Null
			  ,[Mtg3InputPage] = Null
			  ,[Mtg3RecordingDt] = Null
			  ,[Mtg3LoanAmt] = Null
			  ,[Mtg3Lender] = Null
			  ,[Mtg3LenderCode] = Null
			  ,[Mtg3LenderType] = Null
			  ,[Mtg3PrivateLender] = Null
			  ,[Mtg3Term] = Null
			  ,[Mtg3LoanDueDt] = Null
			  ,[Mtg3AdjRider] = Null
			  ,[Mtg3LoanType] = Null
			  ,[Mtg3Typefinancing] = Null
			  ,[Mtg3LienPosition] = Null
			  ,[Mtg4TransactionId] = Null
			  ,[Mtg4ChronoKey] = Null
			  ,[Mtg4InputDocNbr] = Null
			  ,[Mtg4InputBook] = Null
			  ,[Mtg4InputPage] = Null
			  ,[Mtg4RecordingDt] = Null
			  ,[Mtg4LoanAmt] = Null
			  ,[Mtg4Lender] = Null
			  ,[Mtg4LenderCode] = Null
			  ,[Mtg4LenderType] = Null
			  ,[Mtg4PrivateLender] = Null
			  ,[Mtg4Term] = Null
			  ,[Mtg4LoanDueDt] = Null
			  ,[Mtg4AdjRider] = Null
			  ,[Mtg4LoanType] = Null
			  ,[Mtg4Typefinancing] = Null
			  ,[Mtg4LienPosition] = Null
			  ,[LienPosUpdateFlag] = 'Y'
			  ,[FADeriveProcessDt] = GETDATE()
			  ,[Mtg1EstLoanBalance] = Null
			  ,[Mtg1EstPaymentAmt] = Null
			  ,[Mtg2EstLoanBalance] = Null
			  ,[Mtg2EstPaymentAmt] = Null
			  ,[Mtg2InterestRate] = Null
			  ,[Mtg3EstLoanBalance] = Null
			  ,[Mtg3EstPaymentAmt] = Null
			  ,[Mtg3InterestRate] = Null
			  ,[Mtg4EstLoanBalance] = Null
			  ,[Mtg4EstPaymentAmt] = Null
			  ,[Mtg4InterestRate] = Null
			  ,TotalOpenLienAmt = Mtg1LoanAmt
			  ,TotalOpenLienNbr = 1
		from [DragonAssr].[dbo].[PropertyWork] p 
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
		Where Mtg1LoanAmt = Mtg2LoanAmt
		AND Mtg1RecordingDt = Mtg2RecordingDt
		AND (Mtg1FormatDocNbr = Mtg2FormatDocNbr)
		AND isNULL(Mtg1FormatDocNbr,'') not like ''
		and Mtg1LoanAmt > 0
		and [Mtg3TransactionId] is null


----- LINK BKPG
		Update [DragonAssr].[dbo].[PropertyWork]
		set [Mtg2TransactionId] = Null
			  ,[Mtg2ChronoKey] = Null
			  ,[Mtg2InputDocNbr] = Null
			  ,[Mtg2InputBook] = Null
			  ,[Mtg2InputPage] = Null
			  ,[Mtg2RecordingDt] = Null
			  ,[Mtg2LoanAmt] = Null
			  ,[Mtg2Lender] = Null
			  ,[Mtg2LenderCode] = Null
			  ,[Mtg2LenderType] = Null
			  ,[Mtg2PrivateLender] = Null
			  ,[Mtg2Term] = Null
			  ,[Mtg2LoanDueDt] = Null
			  ,[Mtg2AdjRider] = Null
			  ,[Mtg2LoanType] = Null
			  ,[Mtg2Typefinancing] = Null
			  ,[Mtg2LienPosition] = Null
			  ,[Mtg3TransactionId] = Null
			  ,[Mtg3ChronoKey] = Null
			  ,[Mtg3InputDocNbr] = Null
			  ,[Mtg3InputBook] = Null
			  ,[Mtg3InputPage] = Null
			  ,[Mtg3RecordingDt] = Null
			  ,[Mtg3LoanAmt] = Null
			  ,[Mtg3Lender] = Null
			  ,[Mtg3LenderCode] = Null
			  ,[Mtg3LenderType] = Null
			  ,[Mtg3PrivateLender] = Null
			  ,[Mtg3Term] = Null
			  ,[Mtg3LoanDueDt] = Null
			  ,[Mtg3AdjRider] = Null
			  ,[Mtg3LoanType] = Null
			  ,[Mtg3Typefinancing] = Null
			  ,[Mtg3LienPosition] = Null
			  ,[Mtg4TransactionId] = Null
			  ,[Mtg4ChronoKey] = Null
			  ,[Mtg4InputDocNbr] = Null
			  ,[Mtg4InputBook] = Null
			  ,[Mtg4InputPage] = Null
			  ,[Mtg4RecordingDt] = Null
			  ,[Mtg4LoanAmt] = Null
			  ,[Mtg4Lender] = Null
			  ,[Mtg4LenderCode] = Null
			  ,[Mtg4LenderType] = Null
			  ,[Mtg4PrivateLender] = Null
			  ,[Mtg4Term] = Null
			  ,[Mtg4LoanDueDt] = Null
			  ,[Mtg4AdjRider] = Null
			  ,[Mtg4LoanType] = Null
			  ,[Mtg4Typefinancing] = Null
			  ,[Mtg4LienPosition] = Null
			  ,[LienPosUpdateFlag] = 'Y'
			  ,[FADeriveProcessDt] = GETDATE()
			  ,[Mtg1EstLoanBalance] = Null
			  ,[Mtg1EstPaymentAmt] = Null
			  ,[Mtg2EstLoanBalance] = Null
			  ,[Mtg2EstPaymentAmt] = Null
			  ,[Mtg2InterestRate] = Null
			  ,[Mtg3EstLoanBalance] = Null
			  ,[Mtg3EstPaymentAmt] = Null
			  ,[Mtg3InterestRate] = Null
			  ,[Mtg4EstLoanBalance] = Null
			  ,[Mtg4EstPaymentAmt] = Null
			  ,[Mtg4InterestRate] = Null
			  ,TotalOpenLienAmt = Mtg1LoanAmt
			  ,TotalOpenLienNbr = 1
		from [DragonAssr].[dbo].[PropertyWork] p 
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
		Where Mtg1LoanAmt = Mtg2LoanAmt
		AND Mtg1RecordingDt = Mtg2RecordingDt
		AND ([Mtg1FormatBook] = [Mtg2FormatBook])
		AND ([Mtg1FormatPage] = [Mtg2FormatPage])
		AND isNULL([Mtg1FormatBook],'') not like ''
		and Mtg1LoanAmt > 0
		and [Mtg3TransactionId] is null

---  Correct Lien Position
----  Lien Pos 2 to 1
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg1TransactionId] = [Mtg2TransactionId]
,[Mtg1ChronoKey] = [Mtg2ChronoKey]
,[Mtg1InputDocNbr] = [Mtg2InputDocNbr]
,[Mtg1InputBook] = [Mtg2InputBook]
,[Mtg1InputPage] = [Mtg2InputPage]
,[Mtg1FormatDocNbr] = [Mtg2FormatDocNbr]
,[Mtg1FormatBook] = [Mtg2FormatBook]
,[Mtg1FormatPage] = [Mtg2FormatPage]
,[Mtg1RecordingDt] = [Mtg2RecordingDt]
,[Mtg1LoanAmt] = [Mtg2LoanAmt]
,[Mtg1Lender] = [Mtg2Lender]
,[Mtg1LenderCode] = [Mtg2LenderCode]
,[Mtg1LenderType] = [Mtg2LenderType]
,[Mtg1PrivateLender] = [Mtg2PrivateLender]
,[Mtg1LoanDueDt] = [Mtg2LoanDueDt]
,[Mtg1AdjRider] = [Mtg2AdjRider]
,[Mtg1LoanType] = [Mtg2LoanType]
,[Mtg1Typefinancing] = [Mtg2Typefinancing]
,[Mtg1LienPosition] = Case when [Mtg2TransactionId] is not null then 2 else Null end
,[Mtg1Term] = [Mtg2Term]
,[Mtg1EstPaymentAmt] = [Mtg2EstPaymentAmt]
,[Mtg1InterestRate] = [Mtg2InterestRate]
,[Mtg1EstLoanBalance] = [Mtg2EstLoanBalance]

,[Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when Mtg1LienPosition is null then 0 else 1 end + Case when Mtg2LienPosition is null then 0 else 1 end + Case when Mtg3LienPosition is null then 0 else 1 end + Case when Mtg4LienPosition is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'

From [DragonAssr].[dbo].[PropertyWork]	p	join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
Where [Mtg1TransactionId] is null and [Mtg2TransactionId] is not null and ((convert(bigint,Mtg1LoanAmt) + convert(bigint,Mtg2LoanAmt) + convert(bigint,Mtg3LoanAmt) + convert(bigint,Mtg4LoanAmt)) < 200000000)

---- Lien Pos 3 to 2
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg2TransactionId] = [Mtg3TransactionId]
,[Mtg2ChronoKey] = [Mtg3ChronoKey]
,[Mtg2InputDocNbr] = [Mtg3InputDocNbr]
,[Mtg2InputBook] = [Mtg3InputBook]
,[Mtg2InputPage] = [Mtg3InputPage]
,[Mtg2FormatDocNbr] = [Mtg3FormatDocNbr]
,[Mtg2FormatBook] = [Mtg3FormatBook]
,[Mtg2FormatPage] = [Mtg3FormatPage]
,[Mtg2RecordingDt] = [Mtg3RecordingDt]
,[Mtg2LoanAmt] = [Mtg3LoanAmt]
,[Mtg2Lender] = [Mtg3Lender]
,[Mtg2LenderCode] = [Mtg3LenderCode]
,[Mtg2LenderType] = [Mtg3LenderType]
,[Mtg2PrivateLender] = [Mtg3PrivateLender]
,[Mtg2LoanDueDt] = [Mtg3LoanDueDt]
,[Mtg2AdjRider] = [Mtg3AdjRider]
,[Mtg2LoanType] = [Mtg3LoanType]
,[Mtg2Typefinancing] = [Mtg3Typefinancing]
,[Mtg2LienPosition] = Case when [Mtg3TransactionId] is not null then 2 else Null end
,[Mtg2Term] = [Mtg3Term]
,[Mtg2EstPaymentAmt] = [Mtg3EstPaymentAmt]
,[Mtg2InterestRate] = [Mtg3InterestRate]
,[Mtg2EstLoanBalance] = [Mtg3EstLoanBalance]

,[Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'

From [DragonAssr].[dbo].[PropertyWork]	p	join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
Where [Mtg2TransactionId] is null and [Mtg3TransactionId] is not null  and ((convert(bigint,Mtg1LoanAmt) + convert(bigint,Mtg2LoanAmt) + convert(bigint,Mtg3LoanAmt) + convert(bigint,Mtg4LoanAmt)) < 200000000)

---- Lien Pos 4 to 3
Update [DragonAssr].[dbo].[PropertyWork]
Set
 [Mtg3TransactionId] = [Mtg4TransactionId]
,[Mtg3ChronoKey] = [Mtg4ChronoKey]
,[Mtg3InputDocNbr] = [Mtg4InputDocNbr]
,[Mtg3InputBook] = [Mtg4InputBook]
,[Mtg3InputPage] = [Mtg4InputPage]
,[Mtg3FormatDocNbr] = [Mtg4FormatDocNbr]
,[Mtg3FormatBook] = [Mtg4FormatBook]
,[Mtg3FormatPage] = [Mtg4FormatPage]
,[Mtg3RecordingDt] = [Mtg4RecordingDt]
,[Mtg3LoanAmt] = [Mtg4LoanAmt]
,[Mtg3Lender] = [Mtg4Lender]
,[Mtg3LenderCode] = [Mtg4LenderCode]
,[Mtg3LenderType] = [Mtg4LenderType]
,[Mtg3PrivateLender] = [Mtg4PrivateLender]
,[Mtg3LoanDueDt] = [Mtg4LoanDueDt]
,[Mtg3AdjRider] = [Mtg4AdjRider]
,[Mtg3LoanType] = [Mtg4LoanType]
,[Mtg3Typefinancing] = [Mtg4Typefinancing]
,[Mtg3LienPosition] = Case when [Mtg4TransactionId] is not null then 3 else Null end
,[Mtg3Term] = [Mtg4Term]
,[Mtg3EstPaymentAmt] = [Mtg4EstPaymentAmt]
,[Mtg3InterestRate] = [Mtg4InterestRate]
,[Mtg3EstLoanBalance] = [Mtg4EstLoanBalance]

,[Mtg4TransactionId] = null
,[Mtg4ChronoKey] = null
,[Mtg4InputDocNbr] = null
,[Mtg4InputBook] = null
,[Mtg4InputPage] = null
,[Mtg4FormatDocNbr] = null
,[Mtg4FormatBook] = null
,[Mtg4FormatPage] = null
,[Mtg4RecordingDt] = null
,[Mtg4LoanAmt] = null
,[Mtg4Lender] = null
,[Mtg4LenderCode] = null
,[Mtg4LenderType] = null
,[Mtg4PrivateLender] = null
,[Mtg4LoanDueDt] = null
,[Mtg4AdjRider] = null
,[Mtg4LoanType] = null
,[Mtg4Typefinancing] = null
,[Mtg4LienPosition] = null
,[Mtg4Term] = null
,[Mtg4EstPaymentAmt] = null
,[Mtg4InterestRate] = null
,[Mtg4EstLoanBalance] = null

,[TotalOpenLienAmt]  = isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)
,[TotalOpenLienNbr]  = Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end
,[LienPosUpdateFlag] = 'Y'

From [DragonAssr].[dbo].[PropertyWork]	p	join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
Where [Mtg3TransactionId] is null and [Mtg4TransactionId] is not null  and ((convert(bigint,Mtg1LoanAmt) + convert(bigint,Mtg2LoanAmt) + convert(bigint,Mtg3LoanAmt) + convert(bigint,Mtg4LoanAmt)) < 200000000)

-----20231113 added for instance of rolled up 4 leaving 4 null
Update [DragonAssr].[dbo].[PropertyWork]
set 
       [Mtg4TransactionId] = w.TransactionId
      ,[Mtg4ChronoKey] = substring(w.ChronoKey,1,31)
	  ,[Mtg4InputDocNbr] = w.InputDocNbr
      ,[Mtg4InputBook] = w.InputBook
      ,[Mtg4InputPage] = w.InputPage
	  ,[Mtg4FormatDocNbr] = w.[FormatDocNbr]
	  ,[Mtg4FormatBook] = w.[FormatBook]
	  ,[Mtg4FormatPage] = w.[FormatPage]
	  ,[Mtg4RecordingDt] = w.RecordingDt
      ,[Mtg4LoanAmt] = w.LoanAmt
      ,[Mtg4Lender] = w.Lender
      ,[Mtg4LenderCode] = w.LenderCode
      ,[Mtg4LenderType] = w.LenderType
      ,[Mtg4PrivateLender] = w.PrivateLender
      ,[Mtg4Term] = w.Term
      ,[Mtg4LoanDueDt] = w.LoanDueDt
      ,[Mtg4AdjRider] = w.AdjRider
      ,[Mtg4LoanType] = w.LoanType
      ,[Mtg4Typefinancing] = w.Typefinancing
      ,[Mtg4LienPosition] = w.CalcLienPos
	  ,[Mtg4InterestRate] = w.[InterestRate]
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where w.CalcLienPos = 5 and [Mtg4TransactionId] is null

----  Shift Lien POSition

update [DragonAssr].[dbo].[PropertyWork]
Set [TotalOpenLienNbr] = (Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [FADeriveProcessDt] > GETDATE()-1 AND  
(Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
<> isNULL([TotalOpenLienNbr],0)

update p
Set [Mtg1LienPosition] = 1
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [Mtg1TransactionId] is not null 
and [Mtg1LienPosition] <> 1

update p
Set [Mtg2LienPosition] = 2
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where  [Mtg2TransactionId] is not null 
and [Mtg2LienPosition] <> 2

update p
Set [Mtg3LienPosition] = 3
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [Mtg3TransactionId] is not null 
and [Mtg3LienPosition] <> 3

update p
Set [Mtg4LienPosition] = 4
from [DragonAssr].[dbo].[PropertyWork] p
		join [DragonAssr].[dbo].CheckThese w
			on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [Mtg4TransactionId] is not null 
and [Mtg4LienPosition] <> 4


	DROP TABLE IF EXISTS [DragonAssr].[dbo].CheckThese

/************  ADDED TO CLEAN LARGE DUPLICATE OPEN LIENS ******************/




----  Move from top
Update [DragonAssr].[dbo].[PropertyWork]
set [TotalOpenLienAmt]  = case when convert(bigint, isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)) < 200000000 then isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0) else 0 end
,[TotalOpenLienNbr]  = CASE WHEN (Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end) = 0 THEN NULL ELSE Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end END
,[LienPosUpdateFlag] = 'Y'
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork] p
--join [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work] w
--on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where ((convert(bigint,isnull(Mtg1LoanAmt,0)) + convert(bigint,isnull(Mtg2LoanAmt,0)) + convert(bigint,isnull(Mtg3LoanAmt,0)) + convert(bigint,isnull(Mtg4LoanAmt,0))) < 200000000)


----  Shift Lien POSition

update [DragonAssr].[dbo].[PropertyWork]
Set [TotalOpenLienNbr] = (Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork]
where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND  
(Case when [Mtg1TransactionId] is not null then 1 else 0 end +
Case when [Mtg2TransactionId] is not null then 1 else 0 end +
Case when [Mtg3TransactionId] is not null then 1 else 0 end +
Case when [Mtg4TransactionId] is not null then 1 else 0 end)
<> [TotalOpenLienNbr]

update [DragonAssr].[dbo].[PropertyWork]
Set [Mtg1LienPosition] = 1
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork]
where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND 
[Mtg1TransactionId] is not null 
and [Mtg1LienPosition] <> 1

update [DragonAssr].[dbo].[PropertyWork]
Set [Mtg2LienPosition] = 2
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork]
where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND 
[Mtg2TransactionId] is not null 
and [Mtg2LienPosition] <> 2

update [DragonAssr].[dbo].[PropertyWork]
Set [Mtg3LienPosition] = 3
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork]
where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND 
[Mtg3TransactionId] is not null 
and [Mtg3LienPosition] <> 3

update [DragonAssr].[dbo].[PropertyWork]
Set [Mtg4LienPosition] = 4
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork]
where FIPS = @Fips and [FADeriveProcessDt] > GETDATE()-1 AND 
[Mtg4TransactionId] is not null 
and [Mtg4LienPosition] <> 4


------------
---611

DROP TABLE IF EXISTS #LienPosFipsPropID

Select Distinct FIPS,PropertyID into #LienPosFipsPropID FROM [DragonAssr].[dbo].[Transaction_Mtg_LienPOS_Work]

create UNIQUE index ix_fipspropid on #LienPosFipsPropID(FIPS,PropertyID)


	UPDATE [DragonAssr].[dbo].[PropertyWork]
	SET Mtg1Term = CASE WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
		WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) > 999 THEN '999'
	ELSE CASE WHEN (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) Like '-%' THEN NULL ELSE  (datediff(mm, cast(Mtg1RecordingDt AS date), cast(Mtg1LoanDueDt AS date)) - 1) END
	END 
	WHERE FIPS = @Fips and PropertyID in(Select PropertyID from #LienPosFipsPropID)
	and Mtg1Term < 10
	and isNULL(Mtg1LoanDueDt,'') not like ''

	UPDATE [DragonAssr].[dbo].[PropertyWork]
	SET Mtg2Term = CASE WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 350 AND 365 THEN '360' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 230 AND 250 THEN '240' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 118 AND 122 THEN '120' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 175 AND 185 THEN '180' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 10 AND 13 THEN '12' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 22 AND 26 THEN '24' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 32 AND 39 THEN '36' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) BETWEEN 57 AND 62 THEN '60' 
		WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) > 999 THEN '999'
	ELSE CASE WHEN (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) Like '-%' 
		THEN NULL ELSE  (datediff(mm, cast(Mtg2RecordingDt AS date), cast(Mtg2LoanDueDt AS date)) - 1) END
	END 
	FROM [DragonAssr].[dbo].[PropertyWork]
	WHERE FIPS = @Fips and PropertyID in(Select PropertyID from #LienPosFipsPropID)
	and Mtg2Term < 10
	and isNULL(Mtg2LoanDueDt,'') not like ''


	UPDATE [DragonAssr].[dbo].[PropertyWork]
	SET Mtg1InterestRate = LEFT(Mtg1InterestRate,3)
	WHERE PropertyID in(Select PropertyID from #LienPosFipsPropID)
	AND LEN(Mtg1InterestRate) > 3



-- Estimated Fields
--  Payment Amount
update [DragonAssr].[dbo].[PropertyWork]
set [Mtg1EstPaymentAmt] = round(cast(round([mtg1loanamt]/(((power(cast((1+(([Mtg1InterestRate]/10000.0) / 12.0)) as float),Mtg1Term)-1))/(((([Mtg1InterestRate]/10000.0) / 12.0))*(power(cast((1+(([Mtg1InterestRate]/10000.0) / 12.0)) as float),Mtg1Term)))),2) as money),2)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg1loanamt] is not null and [Mtg1InterestRate] is not null and [Mtg1InterestRate] != '0' and Mtg1Term is not null and Mtg1Term > 0
and isNULL(Mtg1LoanType,'') not like '32'


update [DragonAssr].[dbo].[PropertyWork]
set [mtg2EstPaymentAmt] = round(cast(round([mtg2loanamt]/(((power(cast((1+(([mtg2InterestRate]/10000.0) / 12.0)) as float),mtg2Term)-1))/(((([mtg2InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg2InterestRate]/10000.0) / 12.0)) as float),mtg2Term)))),2) as money),2)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg2loanamt] is not null and [mtg2InterestRate] is not null and [mtg2InterestRate] != '0' and Mtg2Term is not null and Mtg2Term > 0
and isNULL(Mtg2LoanType,'') not like '32'


update [DragonAssr].[dbo].[PropertyWork]
set [mtg3EstPaymentAmt] = round(cast(round([mtg3loanamt]/(((power(cast((1+(([mtg3InterestRate]/10000.0) / 12.0)) as float),mtg3Term)-1))/(((([mtg3InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg3InterestRate]/10000.0) / 12.0)) as float),mtg3Term)))),2) as money),2)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg3loanamt] is not null and [mtg3InterestRate] is not null and [mtg3InterestRate] != '0' and Mtg3Term is not null and Mtg3Term > 0
and isNULL(Mtg3LoanType,'') not like '32'


update [DragonAssr].[dbo].[PropertyWork]
set [mtg4EstPaymentAmt] = round(cast(round([mtg4loanamt]/(((power(cast((1+(([mtg4InterestRate]/10000.0) / 12.0)) as float),mtg4Term)-1))/(((([mtg4InterestRate]/10000.0) / 12.0))*(power(cast((1+(([mtg4InterestRate]/10000.0) / 12.0)) as float),mtg4Term)))),2) as money),2)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg4loanamt] is not null and [mtg4InterestRate] is not null and [mtg4InterestRate] != '0' and Mtg4Term is not null and Mtg4Term > 0
and isNULL(Mtg4LoanType,'') not like '32'


---  Estimated Loan Balance
Update [DragonAssr].[dbo].[PropertyWork]
Set Mtg1EstLoanBalance = round(round(([mtg1loanamt] * (power((1+((cast([Mtg1InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([Mtg1EstPaymentAmt] * ((power((1+(cast([Mtg1InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([Mtg1InterestRate] as float)/10000.0)/12.0))),2),0)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg1loanamt] is not null and [Mtg1InterestRate] is not null and [Mtg1InterestRate] != '0' and Mtg1Term is not null and Mtg1Term > 0 and Mtg1Term < 481
and round(round(([mtg1loanamt] * (power((1+((cast([Mtg1InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
        -([Mtg1EstPaymentAmt] * ((power((1+(cast([Mtg1InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg1Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([Mtg1InterestRate] as float)/10000.0)/12.0))),2),0) > 0
and isNULL(Mtg1LoanType,'') not like '32'

Update [DragonAssr].[dbo].[PropertyWork]
Set mtg2EstLoanBalance = round(round(([mtg2loanamt] * (power((1+((cast([mtg2InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg2Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg2EstPaymentAmt] * ((power((1+(cast([mtg2InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg2Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg2InterestRate] as float)/10000.0)/12.0))),2),0)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg2loanamt] is not null and [mtg2InterestRate] is not null and [mtg2InterestRate] != '0' and Mtg2Term is not null and Mtg2Term > 0
and isNULL(Mtg2LoanType,'') not like '32'


Update [DragonAssr].[dbo].[PropertyWork]
Set mtg3EstLoanBalance = round(round(([mtg3loanamt] * (power((1+((cast([mtg3InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg3Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg3EstPaymentAmt] * ((power((1+(cast([mtg3InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg3Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg3InterestRate] as float)/10000.0)/12.0))),2),0)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg3loanamt] is not null and [mtg3InterestRate] is not null and [mtg3InterestRate] != '0' and Mtg3Term is not null and Mtg3Term > 0
and isNULL(Mtg3LoanType,'') not like '32'


Update [DragonAssr].[dbo].[PropertyWork]
Set mtg4EstLoanBalance = round(round(([mtg4loanamt] * (power((1+((cast([mtg4InterestRate] as float)/10000.0)/12.0)),(SELECT global.dbo.FullMonthsSeparation([mtg4Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))))
         -([mtg4EstPaymentAmt] * ((power((1+(cast([mtg4InterestRate] as float)/10000.0)/12.0),(SELECT global.dbo.FullMonthsSeparation([mtg4Recordingdt], (SELECT CONVERT(VARCHAR(10), getdate(), 112)))))-1)/((cast([mtg4InterestRate] as float)/10000.0)/12.0))),2),0)
from [DragonAssr].[dbo].[PropertyWork] p
Join #LienPosFipsPropID w
on w.FIPS = p.FIPS and w.PropertyID = p.propertyid
where [mtg4loanamt] is not null and [mtg4InterestRate] is not null and [mtg4InterestRate] != '0' and Mtg4Term is not null and Mtg4Term > 0
and isNULL(Mtg4LoanType,'') not like '32'


DROP TABLE IF EXISTS #LienPosFipsPropID

----  Move from top
Update [DragonAssr].[dbo].[PropertyWork]
set [TotalOpenLienAmt]  = case when convert(bigint, isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0)) < 200000000 then isNULL(Mtg1LoanAmt,0) + isNULL(Mtg2LoanAmt,0) + isNULL(Mtg3LoanAmt,0) + isNULL(Mtg4LoanAmt,0) else 0 end
,[TotalOpenLienNbr]  = CASE WHEN (Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end) = 0 THEN NULL ELSE Case when [Mtg1TransactionId] is null then 0 else 1 end + Case when [Mtg2TransactionId] is null then 0 else 1 end + Case when [Mtg3TransactionId] is null then 0 else 1 end + Case when [Mtg4TransactionId] is null then 0 else 1 end END
,[LienPosUpdateFlag] = 'Y'
,[FADeriveProcessDt] = GetDate()
from [DragonAssr].[dbo].[PropertyWork] p
where ((convert(bigint,isnull(Mtg1LoanAmt,0)) + convert(bigint,isnull(Mtg2LoanAmt,0)) + convert(bigint,isnull(Mtg3LoanAmt,0)) + convert(bigint,isnull(Mtg4LoanAmt,0))) < 200000000)


END


