SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankForeclosureMailingPost] (@tableName varchar(40)) -- @tableName = 'Foreclosure_Mailing' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild MailingStdFullStreetAddress and MailingCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Foreclosure_Mailing_STD]
	   --set [MailingFullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingHouseNbr])) + '' '' + [AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingMode]))) + '' '' + [AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitNbr])))))))
       set [MailingFullStreetAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingHouseNbr])) + '' '' + [AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitNbr]))))
	   ,[MailingHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingHouseNbr]))
       ,[MailingDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionLeft]))
       ,[MailingStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingStreet])))
       ,[MailingMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingMode])))
       ,[MailingDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDirectionRight]))
       ,[MailingUnitNbr] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitNbr]))
       ,[MailingCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingCity])))
       ,[MailingState] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingState]))
       ,[MailingZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingZIP5]))
       ,[MailingZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingZIP4]))
       ,[MailingCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingCarrierCode]))
       ,[MailingUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingUnitType])))
       ,[MailingMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingMatchCode]))
       ,[MailingCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingCensusBlock]))
       ,[MailingCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingCensusTract]))
       ,[MailingDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDPCheckCode]))
       ,[MailingDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDPCheckDigit])) 
       ,[MailingDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDPVCount])) 
       ,[MailingDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingDPVFootnote])) 
       ,[MailingGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingGeoErrorCode]))
       ,[MailingGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingGeoStatusCode]))
       ,[MailingGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingGeoCodeResults]))
       ,[MailingLACS] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingLACS])) 
       ,[MailingLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Mailing_STD].[MailingLACSLinkInd]))	
    From [AddressSTD].[dbo].[Foreclosure_Mailing_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Foreclosure_Mailing_to_Licensing
