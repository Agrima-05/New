SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[Load_DTDB_REFID_to_Assr]
AS
BEGIN
	
	SET NOCOUNT ON;

			DROP INDEX [LicFipsUnformattedAPN] ON [dbo].[Assr]
			DROP INDEX [ix_LicPropID] ON [dbo].[Assr]
			--DROP INDEX [ix_LicFips_LicPropID] ON [dbo].[Assr]
			DROP INDEX [ix_LicFips] ON [dbo].[Assr]
			--DROP INDEX [ix_FipsRefID] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS_UnformatedAPN] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS_OriginalAPN] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS_FormattedAPN] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS_AltAPN] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS] ON [dbo].[Assr]
			DROP INDEX [ix_Archived_REFID] ON [dbo].[Assr]
			DROP INDEX [Assr_Lic_APN] ON [dbo].[Assr]
			DROP INDEX [ix_FIPS_PID_IRIS_FRMTD] ON [dbo].[Assr]


	
					INSERT INTO [ASSR].[dbo].[Assr]
						   ([FIPS]
						   ,[REF_ID]
						   ,[UNFORMATTED_APN]
						   ,[APN_SEQUENCE_NBR]
						   ,[FORMATTED_APN]
						   ,[ORIGINAL_APN]
						   ,[PREVIOUS_PARCEL_NBR]
						   ,[P_ID_IRIS_FRMTD]
						   ,[ALTERNATE_APN]
						   ,[ACCOUNT_NBR]
						   ,[SITUS_HOUSE_NBR]
						   ,[SITUS_HOUSE_NBR_#2]
						   ,[SITUS_HOUSE_NBR_SUFFIX]
						   ,[SITUS_DIRECTION]
						   ,[SITUS_STREET_NAME]
						   ,[SITUS_MODE]
						   ,[SITUS_QUADRANT]
						   ,[SITUS_UNIT_NBR]
						   ,[SITUS_CITY]
						   ,[SITUS_STATE]
						   ,[SITUS_ZIP_CODE]
						   ,[SITUS_CARRIER_CODE]
						   ,[OWN1_LAST_NAME]
						   --,[OWN1_FIRST_NAME_M_I]
						   --,[OWN1_SUFFIX]
						   ,[Situs_Street_Num_Fmt]
						   ,[Situs_Zip_5])
 
				 select 
							[FIPS]
						   ,[REF_ID]
						   ,[UNFORMATTED_APN]
						   ,[APN_SEQUENCE_NBR]
						   ,[FORMATTED_APN]
						   ,[ORIGINAL_APN]
						   ,[PREVIOUS_PARCEL_NBR]
						   ,[P_ID_IRIS_FRMTD]
						   ,[ALTERNATE_APN]
						   ,[ACCOUNT_NBR]
						   ,[SITUS_HOUSE_NBR]
						   ,[SITUS_HOUSE_NBR_#2]
						   ,[SITUS_HOUSE_NBR_SUFFIX]
						   ,[SITUS_DIRECTION]
						   ,LEFT([SITUS_STREET_NAME],30)
						   ,[SITUS_MODE]
						   ,[SITUS_QUADRANT]
						   ,[SITUS_UNIT_NBR]
						   ,[SITUS_CITY]
						   ,[SITUS_STATE]
						   ,[SITUS_ZIP_CODE]
						   ,[SITUS_CARRIER_CODE]
						   ,Left([OWN1_LAST_NAME],60)
						   --,[OWN1_FIRST_NAME_M_I]
						   --,[OWN1_SUFFIX]
						   ,Global.dbo.DeleteLeadZeros(ltrim(rtrim(d.[SITUS_HOUSE_NBR])))
						   ,substring(d.[SITUS_ZIP_CODE],1,5)
				 from [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] d with(NOLOCK)
				 where d.[REF_ID] > (select max(ref_id) FROM [Assr].[dbo].[Assr] with(NOLOCK))

					INSERT INTO [ASSR].[dbo].[Assr]
						   ([FIPS]
						   ,[REF_ID]
						   ,[UNFORMATTED_APN]
						   ,[APN_SEQUENCE_NBR]
						   ,[FORMATTED_APN]
						   ,[ORIGINAL_APN]
						   ,[PREVIOUS_PARCEL_NBR]
						   ,[P_ID_IRIS_FRMTD]
						   ,[ALTERNATE_APN]
						   ,[ACCOUNT_NBR]
						   ,[SITUS_HOUSE_NBR]
						   ,[SITUS_HOUSE_NBR_#2]
						   ,[SITUS_HOUSE_NBR_SUFFIX]
						   ,[SITUS_DIRECTION]
						   ,[SITUS_STREET_NAME]
						   ,[SITUS_MODE]
						   ,[SITUS_QUADRANT]
						   ,[SITUS_UNIT_NBR]
						   ,[SITUS_CITY]
						   ,[SITUS_STATE]
						   ,[SITUS_ZIP_CODE]
						   ,[SITUS_CARRIER_CODE]
						   ,[OWN1_LAST_NAME]
						   --,[OWN1_FIRST_NAME_M_I]
						   --,[OWN1_SUFFIX]
						   ,[Situs_Street_Num_Fmt]
						   ,[Situs_Zip_5])
 
				 select 
							d.[FIPS]
						   ,d.[REF_ID]
						   ,d.[UNFORMATTED_APN]
						   ,d.[APN_SEQUENCE_NBR]
						   ,d.[FORMATTED_APN]
						   ,d.[ORIGINAL_APN]
						   ,d.[PREVIOUS_PARCEL_NBR]
						   ,d.[P_ID_IRIS_FRMTD]
						   ,d.[ALTERNATE_APN]
						   ,d.[ACCOUNT_NBR]
						   ,LEFT(d.[SITUS_HOUSE_NBR],10)
						   ,LEFT(d.[SITUS_HOUSE_NBR_#2],10)
						   ,LEFT(d.[SITUS_HOUSE_NBR_SUFFIX],10)
						   ,LEFT(d.[SITUS_DIRECTION],2)
						   ,LEFT(d.[SITUS_STREET_NAME],30)
						   ,LEFT(d.[SITUS_MODE],5)
						   ,LEFT(d.[SITUS_QUADRANT],2)
						   ,LEFT(d.[SITUS_UNIT_NBR],6)
						   ,LEFT(d.[SITUS_CITY],40)
						   ,d.[SITUS_STATE]
						   ,d.[SITUS_ZIP_CODE]
						   ,d.[SITUS_CARRIER_CODE]
						   ,LEFT(d.[OWN1_LAST_NAME],60)
						   --,[OWN1_FIRST_NAME_M_I]
						   --,[OWN1_SUFFIX]
						   ,left(ltrim(rtrim(SUBSTRING(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20), PATINDEX('%[^0]%', Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20)+'.'), LEN(Substring(ltrim(rtrim(d.[SITUS_HOUSE_NBR])),1,20))))),20)
						   ,substring(d.[SITUS_ZIP_CODE],1,5)
				 from [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] d with(NOLOCK) LEFT OUTER JOIN [Assr].[dbo].[Assr] a with(NOLOCK)
				 ON d.REF_ID = a.REF_ID
				 WHERE a.REF_ID is NULL




			 CREATE NONCLUSTERED INDEX [Assr_Lic_APN] ON [dbo].[Assr]
			([Lic_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_Archived_REFID] ON [dbo].[Assr]
			([Archived_REF_ID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS] ON [dbo].[Assr]
			([FIPS] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS_AltAPN] ON [dbo].[Assr]
			([FIPS] ASC,[ALTERNATE_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS_FormattedAPN] ON [dbo].[Assr]
			([FIPS] ASC,[FORMATTED_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS_OriginalAPN] ON [dbo].[Assr]
			([FIPS] ASC,[ORIGINAL_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS_UnformatedAPN] ON [dbo].[Assr]
			([FIPS] ASC,[UNFORMATTED_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			--CREATE NONCLUSTERED INDEX [ix_FipsRefID] ON [dbo].[Assr]
			--([FIPS] ASC,[REF_ID] ASC
			--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_LicFips] ON [dbo].[Assr]
			([Lic_Fips] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			--CREATE NONCLUSTERED INDEX [ix_LicFips_LicPropID] ON [dbo].[Assr]
			--([Lic_Fips] ASC,[Lic_PropertyID] ASC
			--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_LicPropID] ON [dbo].[Assr]
			([Lic_PropertyID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [LicFipsUnformattedAPN] ON [dbo].[Assr]
			([Lic_Fips] ASC,[UNFORMATTED_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]

			CREATE NONCLUSTERED INDEX [ix_FIPS_PID_IRIS_FRMTD] ON [dbo].[Assr]
			([FIPS] ASC,[P_ID_IRIS_FRMTD] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [AssrData]


			UPDATE a
			SET Archived_REF_ID = NULL
			FROM [Assr].dbo.[assr] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
			on a.REF_ID = b.REF_ID
			where a.Archived_REF_ID = 'Y'



				UPDATE a
				SET Archived_REF_ID = 'Y'
				FROM ASSR.dbo.Assr a LEFT OUTER JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
				on a.REF_ID = b.REF_ID
				where b.REF_ID is NULL
					AND (a.Archived_REF_ID is null or a.Archived_REF_ID = 'N')

				INSERT INTO [dbo].[ASSR_ArchivedREFID]
				Select * from [Assr].dbo.[assr]
				WHERE Archived_REF_ID = 'Y'

				DELETE from [Assr].dbo.[assr]
				WHERE Archived_REF_ID = 'Y' 

				update a
				set a.[Lic_PropertyID] = p.[PropertyID]
				, a.[Lic_Fips] = p.[FIPS]
				, a.[Lic_DTDB_Match_Flag] = 'U'
				, a.[Lic_APN] = p.[FormattedAPN]
				, a.[Lic_AccountNbr] = p.[TaxAccountNumber]
				--SELECT COUNT(*)
				FROM [Assr].dbo.[assr] a JOIN [Assr].[dbo].[ASSRPropertyLINK] b with(NOLOCK)
					ON a.[Fips] = b.[Fips] and a.[Ref_id] = b.[Ref_ID]
				JOIN [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
					ON b.fipsCode = p.[fips] and b.[Propertyid] = p.[PropertyID]
				WHERE a.[Lic_PropertyID] is NULL
					--OR a.[Lic_PropertyID] <> p.[PropertyID]


				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'U'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[UNFORMATTED_APN] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'F'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[FORMATTED_APN] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'O'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[ORIGINAL_APN] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'P'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[PREVIOUS_PARCEL_NBR] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'L'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[ALTERNATE_APN] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'T'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips]= p.[fips] and a.[ACCOUNT_NBR] = p.[FormattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update a
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'U'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[UNFORMATTED_APN] = p.[UnformattedAPN]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID

				update [Assr].dbo.[Assr]
				set [Lic_PropertyID] = p.[PropertyID]
				, [Lic_Fips] = p.[FIPS]
				, [Lic_DTDB_Match_Flag] = 'U'
				,Lic_APN = p.FormattedAPN
				,Lic_AccountNbr = p.TaxAccountNumber
				from [Data_Archive].[dbo].[APN_Index] p  with(NOLOCK)
				join [Assr].dbo.[Assr] a on a.[Lic_Fips] = p.[fips] and a.[UNFORMATTED_APN] = p.[TaxAccountNumber]
				Where a.Lic_PropertyID is null
					or a.Lic_PropertyID <> p.PropertyID


				UPDATE a
				SET a.[Lic_StreetNum] = b.SitusStdHouseNbr
				,a.[Lic_StreetName] = b.SitusStdStreet
				,a.[Lic_OwnerLastName] = b.OwnerStdNAME1FULL
				,a.[Lic_Zip5] = b.SitusStdZIP5
				From Assr.dbo.Assr a JOIN data.dbo.Property b with(NOLOCK)
				on a.[Lic_PropertyID] = b.PropertyID
				WHERE a.[Lic_StreetName] != b.SitusStdStreet
				OR a.[Lic_OwnerLastName] != b.OwnerStdNAME1FULL


				UPDATE ASSR.dbo.Assr
				SET [Lic_PropertyID] = NULL
				, [Lic_Fips] = NULL
				, [Lic_DTDB_Match_Flag] = NULL
				,Lic_OwnerLastName = NULL
				,Lic_StreetNum = NULL
				,Lic_StreetName = NULL
				,Lic_APN = NULL
				,Lic_Zip5 = NULL
				,Lic_AccountNbr = NULL
				where Lic_PropertyID in(
				Select Lic_PropertyID from assr.dbo.assr with(NOLOCK)
				where Archived_REF_ID is NULL or Archived_REF_ID like '' or Archived_REF_ID = 'N'
				group by Lic_PropertyID 
				having count(*) > 1)


				UPDATE ASSR.dbo.Assr
				SET [Lic_PropertyID] = NULL
				, [Lic_Fips] = NULL
				, [Lic_DTDB_Match_Flag] = NULL
				,Lic_OwnerLastName = NULL
				,Lic_StreetNum = NULL
				,Lic_StreetName = NULL
				,Lic_APN = NULL
				,Lic_Zip5 = NULL
				,Lic_AccountNbr = NULL
				where Archived_REF_ID ='Y'
				and LIC_PropertyID is not null





END

