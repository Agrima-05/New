SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.usp_Subdivision_unifiedV02
    @tableName sysname
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @qualifiedTable nvarchar(517) = QUOTENAME(N'dbo') + N'.' + QUOTENAME(@tableName);
    DECLARE @sql nvarchar(max);

    IF OBJECT_ID(@qualifiedTable, 'U') IS NULL
    BEGIN
        RAISERROR('Table %s was not found in dbo schema.', 16, 1, @tableName);
        RETURN;
    END;

    /* Ensure NameClass exists on the target work table */
    IF NOT EXISTS (
        SELECT 1
        FROM sys.columns AS c
        WHERE c.object_id = OBJECT_ID(@qualifiedTable)
          AND c.name = N'NameClass'
    )
    BEGIN
        SET @sql = N'ALTER TABLE ' + @qualifiedTable + N' ADD NameClass varchar(20) NULL;';
        EXEC sys.sp_executesql @sql;
    END;

    /* -------------------------------------------------------------------------
       Reset work columns
       ------------------------------------------------------------------------- */
    SET @sql = N'
    UPDATE t
    SET
        N1 = NULL,  N2 = NULL,  N3 = NULL,  N4 = NULL,
        N5 = NULL,  N6 = NULL,  N7 = NULL,  N8 = NULL,
        N9 = NULL,  N10 = NULL, N11 = NULL, N12 = NULL,
        CalcPhase = NULL,
        CalcSection = NULL,
        CalcPart = NULL,
        NameClass = NULL
    FROM ' + @qualifiedTable + N' AS t;';
    EXEC sys.sp_executesql @sql;

    /* -------------------------------------------------------------------------
       Initial normalize (preserve periods/hyphens until after phrase stripping)
       ------------------------------------------------------------------------- */
    SET @sql = N'
    UPDATE t
    SET Name1 = UPPER(LTRIM(RTRIM(
        REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
            Name1,
            '''''''', ''''),
            ''#'',     ''''),
            ''  '',    '' ''),
            ''/'',     '' ''),
            ''  '',    '' ''),
            ''  '',    '' '')
    )))
    FROM ' + @qualifiedTable + N' AS t;';
    EXEC sys.sp_executesql @sql;

    /* Leading phrase cleanup (ported from V01, without substring Section hacks) */
    SET @sql = N'
    UPDATE t
    SET Name1 = CASE
        WHEN Name1 LIKE ''PLAT OF %''      THEN LTRIM(RTRIM(SUBSTRING(Name1, 9, 100)))
        WHEN Name1 LIKE ''REPLAT OF %''    THEN LTRIM(RTRIM(SUBSTRING(Name1, 11, 100)))
        WHEN Name1 LIKE ''EXTENSION OF %'' THEN LTRIM(RTRIM(SUBSTRING(Name1, 14, 100)))
        WHEN Name1 LIKE ''EXTN OF %''       THEN LTRIM(RTRIM(SUBSTRING(Name1, 9, 100)))
        ELSE Name1
    END
    FROM ' + @qualifiedTable + N' AS t;

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 14, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''SUBDIVISION OF %'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 12, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''SUBDIVISION%'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 4, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''SUB %'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 10, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''A PART OF %'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 8, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''PART OF %'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 9, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''SECTION %'';

    UPDATE t
    SET Name1 = LTRIM(RTRIM(SUBSTRING(Name1, 5, 100)))
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''SEC %'';';
    EXEC sys.sp_executesql @sql;

    /* Split glued condo / estate section markers before punctuation becomes spaces */
    DECLARE @n int = 1;
    DECLARE @num nvarchar(2);
    WHILE @n <= 12
    BEGIN
        SET @num = CAST(@n AS nvarchar(2));

        SET @sql = N'UPDATE t SET Name1 = REPLACE(Name1, ''CON' + @num + N''', ''CON ' + @num + N''')
            FROM ' + @qualifiedTable + N' AS t
            WHERE Name1 LIKE ''%CON' + @num + N'%'';';
        EXEC sys.sp_executesql @sql;

        SET @sql = N'UPDATE t SET Name1 = REPLACE(Name1, ''EST' + @num + N''', ''EST ' + @num + N''')
            FROM ' + @qualifiedTable + N' AS t
            WHERE Name1 LIKE ''%EST' + @num + N'%'';';
        EXEC sys.sp_executesql @sql;

        SET @n += 1;
    END;

    /* Now convert punctuation to token boundaries */
    SET @sql = N'
    UPDATE t
    SET Name1 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
        Name1,
        ''.'', '' ''),
        ''-'', '' ''),
        ''  '', '' ''),
        ''  '', '' ''),
        ''  '', '' '')))
    FROM ' + @qualifiedTable + N' AS t;';
    EXEC sys.sp_executesql @sql;

    /* Townhome / estate phrase normalization */
    SET @sql = N'
    UPDATE t
    SET Name1 = REPLACE(REPLACE(REPLACE(REPLACE(
        Name1,
        ''TOWN HOME'', ''TOWNHOMES''),
        ''TOWN HOMES'', ''TOWNHOMES''),
        '' ESTATE '', '' ESTATES ''),
        '' ESTATE'', '' ESTATES'')
    FROM ' + @qualifiedTable + N' AS t
    WHERE Name1 LIKE ''%TOWN HOME%''
       OR Name1 LIKE ''% ESTATE%''
       OR Name1 LIKE ''% ESTATE '';';
    EXEC sys.sp_executesql @sql;

    /* -------------------------------------------------------------------------
       Tokenize into #NameSplit, then peel modifiers from the right
       ------------------------------------------------------------------------- */
    SET @sql = N'
    IF OBJECT_ID(''tempdb..#NameSplit'') IS NOT NULL DROP TABLE #NameSplit;

    SELECT
        CONVERT(bigint, t.ID) AS ID,
        t.Name1,
        CAST(
            ''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                t.Name1,
                ''>'', '' ''), ''<'', '' ''), ''&'', '' AND ''), ''+'', '' AND ''),
                ''  '', '' ''), ''/'', '' ''), ''-'', '' ''), ''  '', '' ''), '' '', ''</M><M>'')
            + ''</M>'' AS xml
        ) AS NameXml
    INTO #NameSplit
    FROM ' + @qualifiedTable + N' AS t
    WHERE t.Name1 IS NOT NULL
      AND LTRIM(RTRIM(t.Name1)) <> '''';

    IF OBJECT_ID(''tempdb..#Tokens'') IS NOT NULL DROP TABLE #Tokens;

    SELECT
        s.ID,
        s.Name1 AS SourceName,
        LTRIM(RTRIM(x.n.value(''.'', ''varchar(50)''))) AS token,
        ROW_NUMBER() OVER (PARTITION BY s.ID ORDER BY (SELECT NULL)) AS pos
    INTO #Tokens
    FROM #NameSplit AS s
    CROSS APPLY s.NameXml.nodes(''/M'') AS x(n)
    WHERE LTRIM(RTRIM(x.n.value(''.'', ''varchar(50)''))) <> '''';

    ALTER TABLE #Tokens ADD cnt int NULL;
    UPDATE tk
    SET cnt = c.cnt
    FROM #Tokens AS tk
    JOIN (
        SELECT ID, COUNT(*) AS cnt
        FROM #Tokens
        GROUP BY ID
    ) AS c ON c.ID = tk.ID;

    IF OBJECT_ID(''tempdb..#TokenFlags'') IS NOT NULL DROP TABLE #TokenFlags;

    SELECT
        tk.*,
        CASE
            WHEN tk.token IN (
                SELECT ModifierToken FROM dbo.lkup_SubdivisionModifier
            ) THEN 1
            WHEN tk.token LIKE ''[0-9]%'' THEN 1
            WHEN tk.token LIKE ''P[0-9]%'' THEN 1
            WHEN tk.token LIKE ''REV[0-9]%'' OR tk.token = ''REV'' THEN 1
            WHEN tk.token LIKE ''PH[0-9]%'' THEN 1
            WHEN tk.token LIKE ''RP[0-9]%'' THEN 1
            WHEN tk.token LIKE ''AMD[0-9]%'' THEN 1
            WHEN tk.token IN (
                ''1ST'',''2ND'',''3RD'',''4TH'',''5TH'',''6TH'',''7TH'',
                ''FIRST'',''SECOND'',''THIRD'',''FOURTH'',''FIFTH'',''SIXTH'',''SEVENTH'',
                ''I'',''II'',''III'',''IV'',''V'',''VI'',''VII'',''VIII'',''X''
            ) THEN 1
            WHEN tk.token IN (
                ''CONDO'',''CONDOMINIUM'',''CONDOMINIUMS'',''CONDOS'',''TOWNHOMES'',''TOWNHOME''
            ) THEN 1
            WHEN LEN(tk.token) = 1
                 AND tk.token LIKE ''[A-Z]''
                 AND (
                     prev.token IN (''PH'',''PHASE'',''P'',''SEC'',''SECTION'',''UNIT'',''LOT'',''BLK'',''BLOCK'')
                     OR prev.token LIKE ''[0-9]%''
                 ) THEN 1
            ELSE 0
        END AS is_suffix_token,
        CASE
            WHEN LEN(tk.token) = 1
                 AND tk.token LIKE ''[A-Z]''
                 AND (
                     prev.token IN (''PH'',''PHASE'',''P'',''SEC'',''SECTION'',''UNIT'',''LOT'',''BLK'',''BLOCK'')
                     OR prev.token LIKE ''[0-9]%''
                 ) THEN 1
            ELSE 0
        END AS is_suffix_letter
    INTO #TokenFlags
    FROM #Tokens AS tk
    LEFT JOIN #Tokens AS prev
        ON prev.ID = tk.ID
       AND prev.pos = tk.pos - 1;

    IF OBJECT_ID(''tempdb..#TailStart'') IS NOT NULL DROP TABLE #TailStart;

    /* Peel contiguous suffix tokens from the right (handles P2, REV1, 10 B, 6 PH A, etc.) */
    ;WITH walk AS (
        SELECT
            tf.ID,
            tf.pos,
            tf.cnt,
            SUM(CASE WHEN tf.is_suffix_token = 0 THEN 1 ELSE 0 END)
                OVER (PARTITION BY tf.ID ORDER BY tf.pos DESC ROWS UNBOUNDED PRECEDING) AS stop_grp
        FROM #TokenFlags AS tf
    ),
    first_base AS (
        SELECT w.ID, MIN(w.pos) AS last_base_pos
        FROM walk AS w
        WHERE w.stop_grp = 1
        GROUP BY w.ID
    )
    SELECT
        c.ID,
        COALESCE(fb.last_base_pos + 1, c.cnt + 1) AS tail_start_pos
    INTO #TailStart
    FROM (
        SELECT ID, MAX(cnt) AS cnt
        FROM #TokenFlags
        GROUP BY ID
    ) AS c
    LEFT JOIN first_base AS fb ON fb.ID = c.ID;

    IF OBJECT_ID(''tempdb..#BaseNames'') IS NOT NULL DROP TABLE #BaseNames;

    SELECT
        ids.ID,
        STUFF((
            SELECT '' '' + b.token
            FROM #TokenFlags AS b
            JOIN #TailStart AS ts ON ts.ID = b.ID
            WHERE b.ID = ids.ID
              AND b.pos < ts.tail_start_pos
            ORDER BY b.pos
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''varchar(100)''), 1, 1, '''') AS BaseName
    INTO #BaseNames
    FROM (SELECT DISTINCT ID FROM #TokenFlags) AS ids;

    IF OBJECT_ID(''tempdb..#TokenCalc'') IS NOT NULL DROP TABLE #TokenCalc;

    SELECT
        tf.ID,
        CASE
            WHEN tf.pos >= ts.tail_start_pos
                 AND tf.token LIKE ''[0-9]%''
                 AND tf.token NOT LIKE ''P[0-9]%'' THEN tf.token
            WHEN tf.token IN (''PHASE'',''PH'',''P'') AND nxt.token IS NOT NULL THEN nxt.token
            WHEN tf.token LIKE ''PH[0-9]%'' THEN SUBSTRING(tf.token, 3, 20)
            ELSE NULL
        END AS CalcPhaseVal,
        CASE
            WHEN tf.pos >= ts.tail_start_pos AND tf.is_suffix_letter = 1 THEN tf.token
            WHEN tf.token IN (''SECTION'',''SEC'',''SECS'') AND nxt.token IS NOT NULL THEN nxt.token
            ELSE NULL
        END AS CalcSectionVal,
        CASE
            WHEN tf.pos >= ts.tail_start_pos
                 AND (
                     tf.token LIKE ''P[0-9]%''
                     OR tf.token LIKE ''REV[0-9]%''
                     OR tf.token = ''REV''
                     OR tf.token LIKE ''RP[0-9]%''
                     OR tf.token LIKE ''AMD[0-9]%''
                 ) THEN tf.token
            WHEN tf.token IN (''UNIT'',''LOT'',''LOTS'',''BLOCK'',''BLK'',''BLKS'',
                               ''ADDITION'',''ADD'',''ADDN'',''EXTENSION'',''EXT'',''ANNEX'',
                               ''RESUB'',''REPLAT'',''REPL'',''RPLT'',''RP'')
                 AND tf.pos >= ts.tail_start_pos THEN COALESCE(nxt.token, tf.token)
            ELSE NULL
        END AS CalcPartVal,
        CASE
            WHEN tf.token IN (''CONDO'',''CONDOMINIUM'',''CONDOMINIUMS'',''CONDOS'',''TOWNHOMES'',''TOWNHOME'')
                 OR tf.token IN (''CON'',''COND'',''CND'',''CN'')
            THEN 1 ELSE 0
        END AS HasCondoTokenVal
    INTO #TokenCalc
    FROM #TokenFlags AS tf
    JOIN #TailStart AS ts ON ts.ID = tf.ID
    LEFT JOIN #TokenFlags AS nxt ON nxt.ID = tf.ID AND nxt.pos = tf.pos + 1;

    IF OBJECT_ID(''tempdb..#Parsed'') IS NOT NULL DROP TABLE #Parsed;

    SELECT
        tc.ID,
        MAX(tc.CalcPhaseVal)    AS CalcPhase,
        MAX(tc.CalcSectionVal)  AS CalcSection,
        MAX(tc.CalcPartVal)     AS CalcPart,
        MAX(tc.HasCondoTokenVal) AS HasCondoToken
    INTO #Parsed
    FROM #TokenCalc AS tc
    GROUP BY tc.ID;

    ALTER TABLE #Parsed ADD BaseName varchar(100) NULL;

    UPDATE p
    SET p.BaseName = b.BaseName
    FROM #Parsed AS p
    JOIN #BaseNames AS b ON b.ID = p.ID;

    /* Leading EST/ESTATE + number peel (e.g. EST 2 SETT WALK) */
    UPDATE p
    SET
        BaseName = STUFF((
            SELECT '' '' + b.token
            FROM #TokenFlags AS b
            WHERE b.ID = p.ID
              AND b.pos >= 3
            ORDER BY b.pos
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''varchar(100)''), 1, 1, ''''),
        CalcPart = COALESCE(p.CalcPart, t2.token)
    FROM #Parsed AS p
    JOIN #TokenFlags AS t1 ON t1.ID = p.ID AND t1.pos = 1
    JOIN #TokenFlags AS t2 ON t2.ID = p.ID AND t2.pos = 2
    WHERE t1.token IN (''EST'', ''ESTATE'')
      AND t2.token LIKE ''[0-9]%'';

    UPDATE tgt
    SET
        tgt.Name1       = COALESCE(NULLIF(LTRIM(RTRIM(p.BaseName)), ''''), tgt.Name1),
        tgt.CalcPhase   = COALESCE(p.CalcPhase, tgt.CalcPhase),
        tgt.CalcSection = COALESCE(p.CalcSection, tgt.CalcSection),
        tgt.CalcPart    = COALESCE(p.CalcPart, tgt.CalcPart),
        tgt.NameClass   = CASE WHEN p.HasCondoToken = 1 THEN ''CONDO'' ELSE tgt.NameClass END
    FROM ' + @qualifiedTable + N' AS tgt
    JOIN #Parsed AS p ON p.ID = tgt.ID;

    /* Single-token rows that never entered #Parsed */
    UPDATE tgt
    SET Name1 = LTRIM(RTRIM(tgt.Name1))
    FROM ' + @qualifiedTable + N' AS tgt
    WHERE NOT EXISTS (SELECT 1 FROM #Parsed AS p WHERE p.ID = tgt.ID);

    /* -------------------------------------------------------------------------
       Whole-token abbreviation expansion
       ------------------------------------------------------------------------- */
    IF OBJECT_ID(''tempdb..#NameSplit2'') IS NOT NULL DROP TABLE #NameSplit2;

    SELECT
        CONVERT(bigint, t.ID) AS ID,
        t.Name1,
        CAST(
            ''<M>'' + REPLACE(REPLACE(REPLACE(
                t.Name1, ''  '', '' ''), ''-'', '' ''), '' '', ''</M><M>'')
            + ''</M>'' AS xml
        ) AS NameXml
    INTO #NameSplit2
    FROM ' + @qualifiedTable + N' AS t
    WHERE t.Name1 LIKE ''% %'';

    IF OBJECT_ID(''tempdb..#ExpandTokens'') IS NOT NULL DROP TABLE #ExpandTokens;

    SELECT
        s.ID,
        LTRIM(RTRIM(x.n.value(''.'', ''varchar(50)''))) AS token,
        ROW_NUMBER() OVER (PARTITION BY s.ID ORDER BY (SELECT NULL)) AS pos
    INTO #ExpandTokens
    FROM #NameSplit2 AS s
    CROSS APPLY s.NameXml.nodes(''/M'') AS x(n)
    WHERE LTRIM(RTRIM(x.n.value(''.'', ''varchar(50)''))) <> '''';

    IF OBJECT_ID(''tempdb..#Expanded'') IS NOT NULL DROP TABLE #Expanded;

    SELECT
        et.ID,
        STUFF((
            SELECT '' '' + COALESCE(a.Expanded, et2.token)
            FROM #ExpandTokens AS et2
            LEFT JOIN dbo.lkup_SubdivisionAbbrev AS a ON a.Abbrev = et2.token
            WHERE et2.ID = et.ID
            ORDER BY et2.pos
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''varchar(100)''), 1, 1, '''') AS ExpandedName
    INTO #Expanded
    FROM (SELECT DISTINCT ID FROM #ExpandTokens) AS et;

    UPDATE tgt
    SET Name1 = e.ExpandedName
    FROM ' + @qualifiedTable + N' AS tgt
    JOIN #Expanded AS e ON e.ID = tgt.ID;

    UPDATE tgt
    SET Name1 = COALESCE(a.Expanded, tgt.Name1)
    FROM ' + @qualifiedTable + N' AS tgt
    LEFT JOIN dbo.lkup_SubdivisionAbbrev AS a ON a.Abbrev = tgt.Name1
    WHERE tgt.Name1 NOT LIKE ''% %'';

    /* -------------------------------------------------------------------------
       Condo classification (do not append CONDO to Name1)
       ------------------------------------------------------------------------- */
    UPDATE tgt
    SET NameClass = ''CONDO''
    FROM ' + @qualifiedTable + N' AS tgt
    WHERE NameClass IS NULL
      AND (
            RTRIM(tgt.LandUse) = ''1004''
         OR tgt.Name1 LIKE ''%CONDO%''
         OR tgt.Name1 LIKE ''%CONDOMINIUM%''
      );

    UPDATE tgt
    SET Name1 = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
        Name1,
        '' CONDOMINIUMS'', ''''),
        '' CONDOMINIUM'', ''''),
        '' CONDOS'', ''''),
        '' CONDO'', ''''),
        ''  '', '' ''),
        ''  '', '' '')))
    FROM ' + @qualifiedTable + N' AS tgt
    WHERE NameClass = ''CONDO'';

    /* -------------------------------------------------------------------------
       Label classification
       ------------------------------------------------------------------------- */
    UPDATE tgt
    SET NameClass = lbl.LabelClass
    FROM ' + @qualifiedTable + N' AS tgt
    JOIN dbo.lkup_SubdivisionLabel AS lbl ON tgt.Name1 LIKE lbl.LabelPattern
    WHERE tgt.NameClass IS NULL;

    UPDATE tgt
    SET NameClass = ''ROAD''
    FROM ' + @qualifiedTable + N' AS tgt
    WHERE tgt.NameClass IS NULL
      AND (
            tgt.Name2 LIKE ''%-%''
         OR tgt.Name1 LIKE ''%-%''
      );

    UPDATE tgt
    SET NameClass = ''PLAT''
    FROM ' + @qualifiedTable + N' AS tgt
    WHERE tgt.NameClass IS NULL;

    /* -------------------------------------------------------------------------
       Final cleanup + repopulate N1..N12 for QA
       ------------------------------------------------------------------------- */
    UPDATE tgt
    SET Name1 = LTRIM(RTRIM(REPLACE(REPLACE(Name1, ''  '', '' ''), ''  '', '' '')))
    FROM ' + @qualifiedTable + N' AS tgt;

    UPDATE tgt
    SET
        N1 = NULL, N2 = NULL, N3 = NULL, N4 = NULL, N5 = NULL, N6 = NULL,
        N7 = NULL, N8 = NULL, N9 = NULL, N10 = NULL, N11 = NULL, N12 = NULL
    FROM ' + @qualifiedTable + N' AS tgt;

    SELECT
        CONVERT(bigint, t.ID) AS ID,
        t.Name1,
        CAST(
            ''<M>'' + REPLACE(REPLACE(REPLACE(
                t.Name1, ''  '', '' ''), ''-'', '' ''), '' '', ''</M><M>'')
            + ''</M>'' AS xml
        ) AS NameXml
    INTO #NameSplitFinal
    FROM ' + @qualifiedTable + N' AS t
    WHERE t.Name1 LIKE ''% %'';

    UPDATE d
    SET
        d.N1  = x.N1,  d.N2  = x.N2,  d.N3  = x.N3,  d.N4  = x.N4,
        d.N5  = x.N5,  d.N6  = x.N6,  d.N7  = x.N7,  d.N8  = x.N8,
        d.N9  = x.N9,  d.N10 = x.N10, d.N11 = x.N11, d.N12 = x.N12
    FROM ' + @qualifiedTable + N' AS d
    JOIN (
        SELECT
            s.ID,
            s.NameXml.value(''/M[1]'',  ''varchar(50)'') AS N1,
            s.NameXml.value(''/M[2]'',  ''varchar(50)'') AS N2,
            s.NameXml.value(''/M[3]'',  ''varchar(50)'') AS N3,
            s.NameXml.value(''/M[4]'',  ''varchar(50)'') AS N4,
            s.NameXml.value(''/M[5]'',  ''varchar(50)'') AS N5,
            s.NameXml.value(''/M[6]'',  ''varchar(50)'') AS N6,
            s.NameXml.value(''/M[7]'',  ''varchar(50)'') AS N7,
            s.NameXml.value(''/M[8]'',  ''varchar(50)'') AS N8,
            s.NameXml.value(''/M[9]'',  ''varchar(50)'') AS N9,
            s.NameXml.value(''/M[10]'', ''varchar(50)'') AS N10,
            s.NameXml.value(''/M[11]'', ''varchar(50)'') AS N11,
            s.NameXml.value(''/M[12]'', ''varchar(50)'') AS N12
        FROM #NameSplitFinal AS s
    ) AS x ON x.ID = d.ID;

    UPDATE d
    SET d.N1 = d.Name1
    FROM ' + @qualifiedTable + N' AS d
    WHERE d.Name1 IS NOT NULL
      AND d.Name1 NOT LIKE ''% %''
      AND d.N1 IS NULL;';
    EXEC sys.sp_executesql @sql;
END;

