SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE  PROCEDURE   [dbo].[GetDatabaseSize_eachServer]

AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
IF OBJECT_ID('tempdb.dbo.#space') IS NOT NULL
    DROP TABLE #space

CREATE TABLE #space (
      database_id INT PRIMARY KEY
    , data_used_size DECIMAL(38,6)
    , log_used_size DECIMAL(38,6)
)

 

 

 

DECLARE @SQL NVARCHAR(MAX)

 

 

 

SELECT @SQL = STUFF((
    SELECT '
    USE [' + d.name + ']
    INSERT INTO #space (database_id, data_used_size, log_used_size)
    SELECT
          DB_ID()
        , SUM(CASE WHEN [type] = 0 THEN space_used END)
        , SUM(CASE WHEN [type] = 1 THEN space_used END)
    FROM (
        SELECT s.[type], space_used = SUM(FILEPROPERTY(s.name, ''SpaceUsed'') * 8. / 1024)
        FROM sys.database_files s
        GROUP BY s.[type]
    ) t;'
    FROM sys.databases d
    WHERE d.[state] = 0 and d.state_desc = 'online' and d.name in (
    
    select DISTINCT sd.name
    /*, 
(
case 
 when
  hdrs.is_primary_replica IS NULL then  'NOT REPLICATED'
 when exists ( select * from sys.dm_hadr_database_replica_states as irs where sd.database_id = irs.database_id and is_primary_replica = 1 ) then
    'PRIMARY'
 else
    'SECONDARY'
 end
) as  AGType,
COALESCE(grp.ag_name,'N/A') as AGName
*/
 from sys.databases as sd
 left outer join sys.dm_hadr_database_replica_states  as hdrs on hdrs.database_id = sd.database_id
 left outer join sys.dm_hadr_name_id_map as grp on grp.ag_id = hdrs.group_id
 where hdrs.is_primary_replica IS NULL or is_primary_replica = 1)
    FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '')

EXEC sys.sp_executesql @SQL

TRUNCATE TABLE [DBA_StorageMonitor].[dbo].[Databases_Size];

Insert into [DBA_StorageMonitor].[dbo].[Databases_Size]
([Servername]
      ,[DatabaseName]
      ,[DB_size_GB]
      ,[DataFiles_Size_GB]
      ,[DataFiles_used_GB]
      ,[LogSize_GB]
      ,[LogFiles_used_GB]
      ,[FullBackupSize_GB]
      ,[FullBackupDate]
      ,[DiffBackupSize_GB]
      ,[DiffBackupDate]
      ,[Record_Inseted_DATE])
SELECT
   LEFT(@@SERVERNAME,15) as Servername
     -- d.database_id,
     ,d.name as DatabaseName
	, t.total_size as DB_size_GB
    --, d.state_desc
    --, d.recovery_model_desc
    
    , t.data_size as DataFiles_Size_GB
    , CAST(s.data_used_size/1024 AS DECIMAL(18,2)) as DataFiles_used_GB
    , t.log_size as LogSize_GB
    , CAST(s.log_used_size/1024 AS DECIMAL(18,2)) as LogFiles_used_GB
    
    , bu.full_size as FullBackupSize_GB
	, bu.full_last_date as FullBackupDate
	, bu.Diff_size as DiffBackupSize_GB
	, bu.Diff_last_date as DiffBackupDate
    --, bu.log_last_date
    --, bu.log_size
	,convert (date, getdate() , 107) as  [Record_Inseted_DATE]


--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE TABLE [dbo].[Databases_Size](
--	[Servername] [varchar](50) NOT NULL,
--	[DatabaseName] [varchar](250) NOT NULL,
--	[DB_size_GB] DECIMAL(18,2) NULL,
--	[DataFiles_Size_GB] DECIMAL(18,2) NULL,
--	[DataFiles_used_GB] DECIMAL(18,2) NULL,
--	[LogSize_GB] DECIMAL(18,2) NULL,
--	[LogFiles_used_GB] DECIMAL(18,2) NULL,
--	[FullBackupSize_GB] DECIMAL(18,2) NULL,
-- [FullBackupDate] DATETIME Null,
--	[DiffBackupSize_GB] DECIMAL(18,2) NULL,
-- [DiffBackupDate] DATETIME Null,
-- [Record_Inseted_DATE] DATETIME NOT Null,
-- CONSTRAINT [PK_Databases_Size] PRIMARY KEY CLUSTERED 
--(
--	[Servername] ASC,
--[DatabaseName]  ASC,
--[Record_Inseted_DATE] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--) ON [PRIMARY]
--GO





FROM (
    SELECT
          a.database_id
        , log_size = CAST(SUM(CASE WHEN [type] = 1 THEN size END) * 8. / 1024/1024 AS DECIMAL(18,2))
        , data_size = CAST(SUM(CASE WHEN [type] = 0 THEN size END) * 8. / 1024/1024 AS DECIMAL(18,2))
        , total_size = CAST(SUM(size) * 8. / 1024/1024 AS DECIMAL(18,2))
    FROM sys.master_files a
	inner join sys.databases d
	on a.database_id = d.database_id
	--where d.name in ('epr_VDB','epr_NDE','NEO')
    GROUP BY a.database_id
) t
JOIN sys.databases d ON d.database_id = t.database_id
LEFT JOIN #space s ON d.database_id = s.database_id
LEFT JOIN (
    SELECT
          database_name
        , full_last_date = MAX(CASE WHEN [type] = 'D' THEN backup_finish_date END)
        , full_size = MAX(CASE WHEN [type] = 'D' THEN backup_size END)
		, Diff_last_date = MAX(CASE WHEN [type] = 'I' THEN backup_finish_date END)
        , Diff_size = MAX(CASE WHEN [type] = 'I' THEN backup_size  END)
        , log_last_date = MAX(CASE WHEN [type] = 'L' THEN backup_finish_date END)
        , log_size = MAX(CASE WHEN [type] = 'L' THEN backup_size END)
    FROM (
        SELECT
              s.database_name
            , s.[type]
            , s.backup_finish_date
            , backup_size =
                        CAST(CASE WHEN s.backup_size = s.compressed_backup_size
                                    THEN s.backup_size
                                    ELSE s.compressed_backup_size/1024.0
                        END/1048576 AS DECIMAL(18,2))
            , RowNum = ROW_NUMBER() OVER (PARTITION BY s.database_name, s.[type] ORDER BY s.backup_finish_date DESC)
        FROM msdb.dbo.backupset s JOIN msdb.dbo.backupmediafamily bmf 

ON s.media_set_id = bmf.media_set_id
        WHERE s.[type] IN ('D', 'I','L')  and bmf.physical_device_name not like '{%'
    ) f
    WHERE f.RowNum = 1 
    GROUP BY f.database_name
) bu ON d.name = bu.database_name --and d.name in ('epr_VDB','epr_NDE','NEO')
ORDER BY d.name -- DESC

--sp_fixeddrives
