SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Description: Load DTDB_REF_ID to Property
-- =============================================
CREATE PROCEDURE [dbo].[Load_DTDB_REFID_To_Property] 

AS
BEGIN

	Truncate Table [ASSR].[dbo].[ASSRPropertyLINK_Batch]

		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_FipsREFID' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_FipsREFID] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		END

		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_Fips' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_Fips] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		End

		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_FipscodePropID' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_FipscodePropID] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		End

		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_FipsAddrZip' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_FipsAddrZip] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		End

		DECLARE @FIPS int

		DECLARE AssrData CURSOR FOR   
			SELECT FIPScodenum FROM [Global].dbo.COUNTY	order by FIPScodenum 
  
		OPEN AssrData  
  
		FETCH NEXT FROM AssrData   
		INTO @FIPS 
  
		WHILE @@FETCH_STATUS = 0  
			BEGIN  

			--Print @FIPS

			EXEC('INSERT INTO [ASSR].[dbo].[ASSRPropertyLINK_Batch]([FIPS]
				  ,[REF_ID]
				  ,[UNFORMATTED_APN]
				  ,[APN_SEQUENCE_NBR]
				  ,[FORMATTED_APN]
				  ,[ORIGINAL_APN]
				  ,[PREVIOUS_PARCEL_NBR]
				  ,[P_ID_IRIS_FRMTD]
				  ,[ALTERNATE_APN]
				  ,[ACCOUNT_NBR]
				  ,[Source_Type]
				  ,[SRC_TBL]
				  ,[FLANK_RULES_APN]
				  ,[FLANK_RULES_APN_Rule2]
				  ,[FLANK_RULES_APN_rule3]
				  ,[Vendor_Original_Apn]
				  ,[FIPSCode]
				  ,[PropertyID]
				  --,[DTDB_Address]
				  --,[DTDB_Zip]
				  )
			SELECT a.[FIPS]
				  ,a.[REF_ID]
				  ,a.[UNFORMATTED_APN]
				  ,a.[APN_SEQUENCE_NBR]
				  ,a.[FORMATTED_APN]
				  ,a.[ORIGINAL_APN]
				  ,a.[PREVIOUS_PARCEL_NBR]
				  ,a.[P_ID_IRIS_FRMTD]
				  ,a.[ALTERNATE_APN]
				  ,a.[ACCOUNT_NBR]
				  ,a.[Source_Type]
				  ,a.[SRC_TBL]
				  ,a.[FLANK_RULES_APN]
				  ,a.[FLANK_RULES_APN_Rule2]
				  ,a.[FLANK_RULES_APN_rule3]
				  ,a.[Vendor_Original_Apn]
				  ,RIGHT(''0'' + convert(varchar(5),a.[FIPS]),5)
				  ,NULL as [PropertyID]
				  --,Rtrim(Rtrim(Rtrim(Rtrim(Ltrim(Rtrim(isNULL(Ltrim(Rtrim(STD_StreetNumber)),'''') + '' '' + isNULL(Ltrim(Rtrim(STD_PreDirection)),'''')) + '' '' + isNULL(Ltrim(Rtrim(STD_StreetName)),'''')) + '' '' + isNULL(Ltrim(Rtrim(STD_Suffix)),'''')) + '' '' + isNULL(Ltrim(Rtrim(STD_PostDirection)),'''')) + '' '' + isNULL(Ltrim(Rtrim(STD_UnitType)),'''')) + '' '' + isNULL(Ltrim(Rtrim(STD_Unit)),'''')) as [DTDB_Address]
				  --,STD_ZIP as [DTDB_Zip]
			  FROM [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR a with(NOLOCK)
				--LEFT OUTER JOIN (Select Fips,REF_ID,STD_StreetNumber,STD_PreDirection,STD_StreetName,STD_Suffix,STD_PostDirection,STD_UnitType,STD_Unit,STD_ZIP 
				--			from [AZUVPSQLDTDB029.DATATREE.LOCAL].Addr.dbo.CL_Address_Base with(NOLOCK) WHERE FIPS = ' + @FIPS + ' and Address_Type = ''S'') b
			 -- ON a.Fips = b.Fips
				--and a.REF_ID = b.REF_ID
			  WHERE a.FIPS = ' + @FIPS + '
				and APN_SEQUENCE_NBR = 1
			 ')


				FETCH NEXT FROM AssrData   
				INTO @FIPS   
			END 
  
		CLOSE AssrData;  
		DEALLOCATE AssrData;  


		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_FipsREFID' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_FipsREFID] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		END

		IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_Fips' and b.name = 'ASSRPropertyLINK_Batch')
		BEGIN
		DROP INDEX [ix_Fips] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		End

		--IF EXISTS(Select * from assr.sys.indexes a JOIN assr.sys.tables b on a.object_id = b.object_id where a.name like 'ix_FipsAddrZip' and b.name = 'ASSRPropertyLINK_Batch')
		--BEGIN
		--DROP INDEX [ix_FipsAddrZip] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		--End

		--CREATE NONCLUSTERED INDEX [ix_FipsAddrZip] ON [dbo].[ASSRPropertyLINK_Batch]
		--([FIPS] ASC,[DTDB_Address] ASC,[DTDB_Zip] ASC
		--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


		CREATE NONCLUSTERED INDEX [ix_FipsREFID] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		([FIPS] ASC,[REF_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


		CREATE NONCLUSTERED INDEX [ix_Fips] ON ASSR.[dbo].[ASSRPropertyLINK_Batch]
		([FIPS] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		--select count(*) from ASSR.[dbo].[ASSRPropertyLINK_Batch]

		--DECLARE @Fips int;
		DECLARE @FipsCode varchar(5);
	


			DECLARE AssrLink CURSOR FOR   
				SELECT FIPScodenum,FIPSCode FROM [Global].dbo.COUNTY order by FIPScodenum
  
			OPEN AssrLink  
  
			FETCH NEXT FROM AssrLink   
			INTO @FIPS,@FipsCode 
  
			WHILE @@FETCH_STATUS = 0  
				BEGIN  

				--PRINT @FIPS

				EXEC('UPDATE a
					SET PropertyID = b.PropertyID 
					FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN Data_Archive.[dbo].[APN_Index] b with(NOLOCK)
					on a.FIPS = b.FIPS
					and a.REF_ID = b.DTDB_Ref_ID
					WHERE a.FIPS = ' + @FIPS + '
					and b.FIPS = ' + @FipsCode + '
				 ')

				EXEC('UPDATE a
					SET PropertyID = b.PropertyID 
					FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN [ASSR].[dbo].[ASSRPropertyLINK] b
					on a.FIPS = b.FIPS
					and a.REF_ID = b.REF_ID
					WHERE a.FIPS = ' + @FIPS + '
					and b.FIPS = ' + @FIPS + '
					and a.PropertyID is NULL
				 ')

				EXEC('UPDATE a
					SET a.Source_Type = ''x''
					FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
					on a.FIPSCode = b.fips
					and a.REF_ID = b.DTDB_Ref_ID
					and a.PropertyID = b.PropertyID
					WHERE a.FIPS = ' + @FIPS + '
					and b.FIPS = ' + @FIPS + '
				')

				
				EXEC('Delete from [ASSR].[dbo].[ASSRPropertyLINK_Batch]
					Where FIPS = ' + @FIPS + '
					and Source_Type = ''x''
				')

					FETCH NEXT FROM AssrLink   
					INTO @FIPS,@FipsCode  
				END 
  
			CLOSE AssrLink;  
			DEALLOCATE AssrLink;  

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.REF_ID = b.DTDB_Ref_ID
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.Vendor_Original_Apn = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.FORMATTED_APN = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.UNFORMATTED_APN = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.P_ID_IRIS_FRMTD = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.ACCOUNT_NBR = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.ALTERNATE_APN = b.FormattedAPN
Where a.PropertyID is NULL

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN Data_Archive.dbo.APN_Index b with(NOLOCK)
on a.FIPSCode = b.fips
and a.UNFORMATTED_APN = b.UnformattedAPN
Where a.PropertyID is NULL 

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN Data_Archive.dbo.APN_Index b with(NOLOCK)
on a.FIPSCode = b.fips
and a.ACCOUNT_NBR = b.TaxAccountNumber
Where a.PropertyID is NULL
and isNULL(b.TaxAccountNumber,'') not like ''


--Select Count(*) from [ASSR].[dbo].[ASSRPropertyLINK_Batch] where PropertyID is null
--Select Count(*) from [ASSR].[dbo].[ASSRPropertyLINK_Batch] where PropertyID is NOT null

CREATE NONCLUSTERED INDEX [ix_FipscodePropID] ON Assr.[dbo].[ASSRPropertyLINK_Batch]
(
	[FIPSCode] ASC,
	[PropertyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


UPDATE Assr.dbo.[ASSRPropertyLINK_Batch]
SET PropertyID = NULL
WHERE PropertyID in(
	Select PropertyID from Assr.dbo.[ASSRPropertyLINK_Batch] with(NOLOCK)
	where propertyid is not null
	group by Fipscode,PropertyID
	having Count(*) > 1
) 
AND APN_SEQUENCE_NBR Not like '1'

UPDATE Assr.dbo.[ASSRPropertyLINK_Batch]
SET PropertyID = NULL
WHERE PropertyID in(Select PropertyID from Assr.dbo.[ASSRPropertyLINK_Batch] with(NOLOCK)
where propertyid is not null
group by Fipscode,PropertyID
having Count(*) > 1)

UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK_Batch] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.FORMATTED_APN = b.FormattedAPN
Where a.PropertyID is NULL
and a.APN_SEQUENCE_NBR = '1'

UPDATE Assr.dbo.[ASSRPropertyLINK_Batch]
SET PropertyID = NULL
WHERE PropertyID in(Select PropertyID from Assr.dbo.[ASSRPropertyLINK_Batch] with(NOLOCK)
where propertyid is not null
group by PropertyID
having Count(*) > 1)

EXEC sp_rename 'ASSRPropertyLINK','ASSRPropertyLINK_OLD'
EXEC sp_rename 'ASSRPropertyLINK_Batch','ASSRPropertyLINK'

DROP Table dbo.ASSRPropertyLINK_OLD

CREATE TABLE [dbo].[ASSRPropertyLINK_Batch](
	[FIPS] [int] NOT NULL,
	[REF_ID] [numeric](12, 0) NOT NULL,
	[UNFORMATTED_APN] [varchar](45) NULL,
	[APN_SEQUENCE_NBR] [char](3) NULL,
	[FORMATTED_APN] [varchar](60) NULL,
	[ORIGINAL_APN] [varchar](45) NULL,
	[PREVIOUS_PARCEL_NBR] [varchar](45) NULL,
	[P_ID_IRIS_FRMTD] [varchar](60) NULL,
	[ALTERNATE_APN] [varchar](60) NULL,
	[ACCOUNT_NBR] [varchar](15) NULL,
	[Source_Type] [char](1) NULL,
	[SRC_TBL] [char](2) NULL,
	[FLANK_RULES_APN] [varchar](60) NULL,
	[FLANK_RULES_APN_Rule2] [varchar](60) NULL,
	[FLANK_RULES_APN_rule3] [varchar](60) NULL,
	[Vendor_Original_Apn] [varchar](60) NULL,
	[FIPSCode] [varchar](5) NULL,
	[PropertyID] [bigint] NULL,
	[DTDB_Address] [varchar](200) NULL,
	[DTDB_Zip] [varchar](10) NULL
) ON [AssrData]


--UPDATE a
--SET a.PropertyID = b.PropertyID
--FROM [ASSR].[dbo].[ASSRPropertyLINK] a JOIN DATA.dbo.Property b with(NOLOCK)
--on a.FIPSCode = b.fips
--and a.DTDB_Address = b.SitusStdFullStreetAddress
--and a.DTDB_Zip = b.SitusStdZIP5
--Where a.PropertyID is NULL
--and a.APN_SEQUENCE_NBR = '1'
 


UPDATE Assr.dbo.[ASSRPropertyLINK]
SET PropertyID = NULL
WHERE PropertyID in(Select PropertyID from Assr.dbo.[ASSRPropertyLINK] with(NOLOCK)
where propertyid is not null
group by PropertyID
having Count(*) > 1)



UPDATE a
SET a.PropertyID = b.PropertyID
FROM [ASSR].[dbo].[ASSRPropertyLINK] a JOIN DATA.dbo.Property b with(NOLOCK)
on a.FIPSCode = b.fips
and a.FORMATTED_APN = b.FormattedAPN
Where a.PropertyID is NULL
and a.APN_SEQUENCE_NBR = '1'


UPDATE Assr.dbo.[ASSRPropertyLINK]
SET PropertyID = NULL
WHERE PropertyID in(Select PropertyID from Assr.dbo.[ASSRPropertyLINK] with(NOLOCK)
where propertyid is not null
group by PropertyID
having Count(*) > 1)


--update b 
--SET b.PropertyID = a.PropertyID
--FROM data.dbo.Property a with(NOLOCK) JOIN Assr.dbo.ASSRPropertyLINK b
--on a.fips = b.FIPSCode
--and a.situsStdfullstreetAddress = b.DTDB_Address
--and a.SitusStdZip5+SitusStdZip4 = DTDB_ZIP
--where b.propertyid is null
--and isNULL(ltrim(rtrim(DTDB_Address)),'') not like ''


update a 
SET DTDB_REF_ID = REF_ID
,DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
--Select Count(*)
FROM data.dbo.Property a JOIN Assr.dbo.ASSRPropertyLINK b
on a.fips = b.FIPSCode
and a.PropertyID = b.PropertyID
where b.propertyid is not null
and (a.DTDB_REF_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)

update a 
SET DTDB_REF_ID = REF_ID
,DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM data.dbo.Property a JOIN Assr.dbo.ASSRPropertyLINK b
on a.fips = b.FIPSCode
and a.taxAccountNumber = b.Account_Nbr
where a.fips = '25009' 
and a.TaxAccountNumber is not null
and b.ACCOUNT_NBR is not null
and (a.DTDB_REF_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)



UPDATE a
SET a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,a.DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM Data.dbo.Property a with(NOLOCK) JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
on a.FIPS = RIGHT('0' + b.FIPS,5)
and LEFT(FormattedAPN,4) + '-' 
+ RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,':'),' '),6)
+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%' and FormattedAPN NOT LIKE '%M%L%S%') THEN '-000000-' 
	WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%S%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6)
ELSE '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) END

+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) 
	WHEN (FormattedAPN LIKE '%M%B%L:[A-Z]%') THEN '-' + LEFT(Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' ')+'0000000',7)
	WHEN (FormattedAPN LIKE '%M%B%L:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
	WHEN (FormattedAPN LIKE '%M%L%S:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
		END
+ CASE WHEN FormattedAPN LIKE '%M%U%' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st4Characters(FormattedAPN,':'),' '),6) ELSE '' END 
+ CASE WHEN FormattedAPN like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),' '),6)
	WHEN FormattedAPN like '%X:%' and FormattedAPN not like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.After1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),':'),6)
	ELSE '' END = b.FORMATTED_APN
WHERE a.FIPS Like '09%' and RIGHT('0' + b.FIPS,5) Like '09%'
and (a.DTDB_Ref_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)
and OwnerStdNAME1FULL like '%' + OWN1_LAST_NAME + '%'

UPDATE a
SET a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM Data.dbo.Property a with(NOLOCK) JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
on a.FIPS = RIGHT('0' + b.FIPS,5)
and LEFT(FormattedAPN,4) + '-' 
+ RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,':'),' '),6)
+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%' and FormattedAPN NOT LIKE '%M%L%S%') THEN '-000000-' 
	WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%S%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6)
ELSE '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) END

+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) 
	WHEN (FormattedAPN LIKE '%M%B%L:[A-Z]%') THEN '-' + LEFT(Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' ')+'0000000',7)
	WHEN (FormattedAPN LIKE '%M%B%L:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
	WHEN (FormattedAPN LIKE '%M%L%S:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
		END
+ CASE WHEN FormattedAPN LIKE '%M%U%' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st4Characters(FormattedAPN,':'),' '),6) ELSE '' END 
+ CASE WHEN FormattedAPN like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),' '),6)
	WHEN FormattedAPN like '%X:%' and FormattedAPN not like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.After1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),':'),6)
	ELSE '' END = b.FORMATTED_APN
WHERE a.FIPS Like '23%' and RIGHT('0' + b.FIPS,5) Like '23%'
and (a.DTDB_Ref_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)
and OwnerStdNAME1FULL like '%' + OWN1_LAST_NAME + '%'

UPDATE a
SET a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM Data.dbo.Property a with(NOLOCK) JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
on a.FIPS = RIGHT('0' + b.FIPS,5)
and LEFT(FormattedAPN,4) + '-' 
+ RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,':'),' '),6)
+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%' and FormattedAPN NOT LIKE '%M%L%S%') THEN '-000000-' 
	WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%S%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6)
ELSE '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) END

+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) 
	WHEN (FormattedAPN LIKE '%M%B%L:[A-Z]%') THEN '-' + LEFT(Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' ')+'0000000',7)
	WHEN (FormattedAPN LIKE '%M%B%L:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
	WHEN (FormattedAPN LIKE '%M%L%S:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
		END
+ CASE WHEN FormattedAPN LIKE '%M%U%' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st4Characters(FormattedAPN,':'),' '),6) ELSE '' END 
+ CASE WHEN FormattedAPN like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),' '),6)
	WHEN FormattedAPN like '%X:%' and FormattedAPN not like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.After1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),':'),6)
	ELSE '' END = b.FORMATTED_APN
WHERE a.FIPS Like '25%' and RIGHT('0' + b.FIPS,5) Like '25%'
and (a.DTDB_Ref_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)
and OwnerStdNAME1FULL like '%' + OWN1_LAST_NAME + '%'

UPDATE a
SET a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM Data.dbo.Property a with(NOLOCK) JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
on a.FIPS = RIGHT('0' + b.FIPS,5)
and LEFT(FormattedAPN,4) + '-' 
+ RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,':'),' '),6)
+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%' and FormattedAPN NOT LIKE '%M%L%S%') THEN '-000000-' 
	WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%S%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6)
ELSE '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) END

+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) 
	WHEN (FormattedAPN LIKE '%M%B%L:[A-Z]%') THEN '-' + LEFT(Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' ')+'0000000',7)
	WHEN (FormattedAPN LIKE '%M%B%L:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
	WHEN (FormattedAPN LIKE '%M%L%S:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
		END
+ CASE WHEN FormattedAPN LIKE '%M%U%' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st4Characters(FormattedAPN,':'),' '),6) ELSE '' END 
+ CASE WHEN FormattedAPN like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),' '),6)
	WHEN FormattedAPN like '%X:%' and FormattedAPN not like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.After1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),':'),6)
	ELSE '' END = b.FORMATTED_APN
WHERE a.FIPS Like '33%' and RIGHT('0' + b.FIPS,5) Like '33%'
and (a.DTDB_Ref_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)
and OwnerStdNAME1FULL like '%' + OWN1_LAST_NAME + '%'

UPDATE a
SET a.DTDB_Ref_ID = b.REF_ID
,a.DTDB_FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
FROM Data.dbo.Property a with(NOLOCK) JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b with(NOLOCK)
on a.FIPS = RIGHT('0' + b.FIPS,5)
and LEFT(FormattedAPN,4) + '-' 
+ RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,':'),' '),6)
+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%' and FormattedAPN NOT LIKE '%M%L%S%') THEN '-000000-' 
	WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%S%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6)
ELSE '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) END

+ CASE WHEN (FormattedAPN NOT LIKE '%B%' and FormattedAPN LIKE '%M%L%') THEN RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st2Characters(FormattedAPN,':'),' '),6) 
	WHEN (FormattedAPN LIKE '%M%B%L:[A-Z]%') THEN '-' + LEFT(Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' ')+'0000000',7)
	WHEN (FormattedAPN LIKE '%M%B%L:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
	WHEN (FormattedAPN LIKE '%M%L%S:[0-9]%') THEN '-' + RIGHT ('000000'+Global.dbo.Before1stCharacter(Global.dbo.After1st3Characters(FormattedAPN,':'),' '),6)
		END
+ CASE WHEN FormattedAPN LIKE '%M%U%' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1st4Characters(FormattedAPN,':'),' '),6) ELSE '' END 
+ CASE WHEN FormattedAPN like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.Before1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),' '),6)
	WHEN FormattedAPN like '%X:%' and FormattedAPN not like '%X:% %' THEN '-' + RIGHT('000000' + Global.dbo.After1stCharacter(Global.dbo.After1stCharacter(FormattedAPN,'X'),':'),6)
	ELSE '' END = b.FORMATTED_APN
WHERE a.FIPS Like '44%' and RIGHT('0' + b.FIPS,5) Like '44%'
and (a.DTDB_Ref_ID is NULL or a.DTDB_Ref_ID <> b.REF_ID)
and OwnerStdNAME1FULL like '%' + OWN1_LAST_NAME + '%'

Update a
SET a.DTDB_REF_ID = REF_ID
,a.DTDB_FORMATTED_APN = FORMATTED_APN
,a.DTDB_UNFORMATTED_APN = UNFORMATTED_APN 
from data.dbo.Property a JOIN zCust_ADS__00_SharedProcs.dbo.MandA_DTDB b
on a.FIPS = b.FIPS
and a.UnformattedAPN = b.ORIGINAL_APN
WHERE a.DTDB_Ref_ID is NULL

Select FIPS,DTDB_REF_ID into #DupRefId
from data.dbo.Property with(NOLOCK) 
where DTDB_Ref_ID is NOT NULL and FAUCIDFlag != 'D'
group by FIPS,DTDB_REF_ID 
Having Count(*) > 1

CREATE INDEX [ix_fipsRefID] on #DupRefId(Fips,DTDB_REF_ID)

UPDATE a
SET DTDB_Ref_ID = NULL
,DTDB_FORMATTED_APN = NULL
,DTDB_UNFORMATTED_APN = NULL
FROM data.dbo.Property a JOIN #DupRefId b
on a.FIPS = b.FIPs
and a.DTDB_Ref_ID = b.DTDB_Ref_ID

DROP TABLE #DupRefId

update Data.dbo.property 
SET DTDB_FORMATTED_APN = REPLACE(DTDB_FORMATTED_APN,'|','')
,DTDB_UNFORMATTED_APN = REPLACE(DTDB_UNFORMATTED_APN,'|','')
from data.dbo.Property with(NOLOCK) 
WHERE DTDB_FORMATTED_APN like '%|%'

update Data.dbo.property 
SET DTDB_UNFORMATTED_APN = REPLACE(REPLACE(REPLACE(REPLACE(DTDB_UNFORMATTED_APN,'|',''),'.',''),'-',''),' ','')
from data.dbo.Property with(NOLOCK) 
WHERE isNULL(DTDB_UNFORMATTED_APN,'') = ''

UPDATE [Data].dbo.Property
SET CS_FORMATTED_APN = DTDB_FORMATTED_APN
,CS_UNFORMATTED_APN = DTDB_UNFORMATTED_APN
WHERE isNULL(DTDB_FORMATTED_APN,'') not like ''
and isNULL(CS_FORMATTED_APN,'') like ''

DROP TABLE src_FHA.dbo.RefID_PropID

Select FIPS,PropertyID,DTDB_REF_ID 
INTO src_FHA.dbo.RefID_PropID
FROM DATA.dbo.Property with(NOLOCK)
where DTDB_REF_ID is not null


Select FIPS,PropertyID,FormattedAPN,UnformattedAPN,DTDB_FORMATTED_APN,DTDB_UNFORMATTED_APN,DTDB_Ref_ID,cast('' as varchar(60)) FORMATTED_APN,cast('' as varchar(60)) UNFORMATTED_APN
INTO #UpdtDTDB
from data.dbo.Property a with(nolock)
where DTDB_FORMATTED_APN is NULL
and DTDB_Ref_ID is not null


CREATE UNIQUE INDEX [IX_REF_ID] ON #UpdtDTDB(DTDB_REF_ID)
CREATE UNIQUE INDEX [IX_PROPID] ON #UpdtDTDB(PropertyID)

		UPDATE a
		SET a.FORMATTED_APN = replace(b.FORMATTED_APN,'|','')
		,a.UNFORMATTED_APN = replace(b.UNFORMATTED_APN,'|','')
		from #UpdtDTDB a
			join [AZUVPSQLDTDB029.datatree.local].assr.dbo.assr b with (nolock) 
		on a.DTDB_Ref_ID = b.ref_id

UPDATE a
SET a.DTDB_FORMATTED_APN = b.FORMATTED_APN
,a.DTDB_UNFORMATTED_APN = b.UNFORMATTED_APN
FROM [Data].dbo.Property a JOIN #UpdtDTDB b
on a.PropertyID = b.PropertyID


UPDATE [Data].dbo.Property
SET DTDB_FORMATTED_APN = FormattedAPN
,DTDB_UNFORMATTED_APN = UnformattedAPN
,FAUserId = 'DTDB APN UPDATE'
,FATimestamp = '2024-09-25'
WHERE FAUCIDFlag != 'D'
and isNULL(DTDB_FORMATTED_APN,'') like ''

UPDATE [Data].dbo.Property
SET DTDB_UNFORMATTED_APN = replace(replace(replace(DTDB_FORMATTED_APN,'-',''),'.',''),' ','')
,FATimestamp = '2024-09-25'
,FAUserId = 'DTDB UNFORMATTED APN UPDATE'
WHERE FAUCIDFlag != 'D'
and isNULL(DTDB_FORMATTED_APN,'') not like ''
and isNULL(DTDB_UNFORMATTED_APN,'') like ''

UPDATE [Data].dbo.Property
SET CS_FORMATTED_APN = DTDB_FORMATTED_APN
,CS_UNFORMATTED_APN = DTDB_UNFORMATTED_APN
,FATimestamp = '2024-09-25'
,FAUserId = 'CS APN UPDATE'
WHERE FAUCIDFlag != 'D'
and isNULL(DTDB_FORMATTED_APN,'') not like ''
and isNULL(CS_FORMATTED_APN,'') like ''

UPDATE [Data].dbo.Property
SET CS_UNFORMATTED_APN = replace(replace(replace(CS_FORMATTED_APN,'-',''),'.',''),' ','')
,FATimestamp = '2024-09-25'
,FAUserId = 'CS APN UPDATE'
WHERE FAUCIDFlag != 'D'
and isNULL(CS_FORMATTED_APN,'') not like ''
and isNULL(CS_UNFORMATTED_APN,'') like ''

UPDATE p
SET CS_FORMATTED_APN = PROP_APN
,CS_UNFORMATTED_APN = REPLACE(REPLACE(REPLACE(PROP_APN,'-',''),'.',''),' ','')
,FATimestamp = '2024-09-25'
,FAUserId = 'CS APN Fix'
from data.dbo.property p with (nolock)
join [src_InfoTR].[dbo].[Assessment] i with (nolock)
on i.prop_fipscd = p.fips
and i.propertyid = p.propertyid
WHERE p.CS_FORMATTED_APN is NULL
	or p.CS_FORMATTED_APN != i.PROP_APN


Select FIPS,CS_FORMATTED_APN into #DupAPNCS
from data.dbo.Property with(NOLOCK) 
where CS_FORMATTED_APN is NOT NULL 
group by FIPS,CS_FORMATTED_APN 
Having Count(*) > 1

CREATE INDEX [ix_fipsAPN] on #DupAPNCS(Fips,CS_FORMATTED_APN)

UPDATE a
SET CS_FORMATTED_APN = NULL
,CS_UNFORMATTED_APN = NULL
,FAUserId = 'NULL DUP CS APNs'
FROM data.dbo.Property a JOIN #DupAPNCS b
on a.FIPS = b.FIPs
and a.DTDB_FORMATTED_APN = b.CS_FORMATTED_APN

DROP TABLE #DupAPNCS


Select FIPS,DTDB_FORMATTED_APN into #DupAPN
from data.dbo.Property with(NOLOCK) 
where DTDB_FORMATTED_APN is NOT NULL 
group by FIPS,DTDB_FORMATTED_APN 
Having Count(*) > 1

CREATE INDEX [ix_fipsAPN] on #DupAPN(Fips,DTDB_FORMATTED_APN)

UPDATE a
SET DTDB_Ref_ID = NULL
,DTDB_FORMATTED_APN = NULL
,DTDB_UNFORMATTED_APN = NULL
FROM data.dbo.Property a JOIN #DupAPN b
on a.FIPS = b.FIPs
and a.DTDB_FORMATTED_APN = b.DTDB_FORMATTED_APN

DROP TABLE #DupAPN

DROP TABLE #UpdtDTDB

	Truncate Table [ASSR].[dbo].[ASSRPropertyLINK_Batch]


UPDATE A 
SET a.StdLandUseCode = d.FlankCode
,a.FATimestamp = GETDATE()
,a.FAUserID = 'StdLandUseUpdate'
From data.dbo.Property as A with(NOLOCK)
join [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] C with(NOLOCK) on A.FIPS = C.FIPS and A.DTDB_REF_ID = C.REF_ID
join [DragonAssr].[dbo].[LandUseLookup] as D with(NOLOCK) on C.Land_Use = D.Value
where C.[Source_Type] = 'G'
and A.FAUCIDFLAG not like 'D'
AND ISNULL(A.STDLandUseCode,'') <> ISNULL(D.FlankCode,'')


UPDATE a
SET a.REF_ID = b.DTDB_REF_ID
,a.FATimestamp = GetDate()
,a.FAUserID = 'REF ID Change'
,a.FAUCIDFlag = 'U'
--Select Count(*)
FROM AddressMaster.dbo.Address_Master a with(NOLOCK) JOIN Data.dbo.Property b with(NOLOCK)
on a.[CountyFips] = b.FIPS
and a.[PropertyID] = b.PropertyID
WHERE a.[Ref_ID] != b.DTDB_REF_ID



END


