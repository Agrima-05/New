SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankDeedBuyermailPost] (@tableName varchar(40)) -- @tableName = 'Deed_Buyermail' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

SET CONCAT_NULL_YIELDS_NULL  OFF--For concat PMB

---- MAS REMOVED exec the sql and just put in a query

--insert into [AddressSTD].[dbo].[Deed_Buyermail_STD_AF_20261012] select * from [AddressSTD].[dbo].[Deed_Buyermail_STD]


	   UPDATE [AddressSTD].[dbo].[Deed_Buyermail_STD]
	   set [BuyerMailFullAddress] = LEFT(ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim(ISNULL([BuyerMailHouseNbr],''))) + ' ' + 
                             ltrim(rtrim(ISNULL([BuyerMailLeftDirection],'')))) + ' ' + 
							 ltrim(rtrim(ISNULL(UPPER([BuyerMailStreetName]),'')))) + ' ' + 
							 ltrim(rtrim(ISNULL(UPPER([BuyerMailMode]),'')))) + ' ' + 
							 ltrim(rtrim(ISNULL(UPPER([BuyerMailRightDirection]),'')))) + ' ' + 
							 ltrim(rtrim(ISNULL(UPPER([BuyerMailUnitType]),'')))) + ' ' + 
							 ltrim(rtrim(ISNULL([BuyerMailUnitNumber],''))))) + ' ' + 
							 ltrim(rtrim(ISNULL([PMB],''))),116)
  
       ,[BuyerMailHouseNbr]  = LEFT(ltrim(rtrim([BuyerMailHouseNbr])),32)
       ,[BuyerMailLeftDirection] = LEFT(ltrim(rtrim([BuyerMailLeftDirection])),2)
       ,[BuyerMailStreetName] = LEFT(UPPER(ltrim(rtrim([BuyerMailStreetName]))),60)
       ,[BuyerMailMode] = LEFT(UPPER(ltrim(rtrim([BuyerMailMode]))),10)
       ,[BuyerMailRightDirection] = LEFT(ltrim(rtrim([BuyerMailRightDirection])),2)

       ,[BuyerMailUnitNumber] = LEFT(case when len(ISNULL([PMB],'')) > 0 
								and ISNULL([PMB],'') not like ''
								THEN ltrim(rtrim(ISNULL([PMB],'')))
								ELSE ltrim(rtrim([BuyerMailUnitNumber])) 
								END,15)

       ,[BuyerMailCity] = LEFT(UPPER(ltrim(rtrim([BuyerMailCity]))),55)
       ,[BuyerMailState] = ltrim(rtrim([BuyerMailState]))
       ,[BuyerMailZIP5] = ltrim(rtrim([BuyerMailZIP5]))
       ,[BuyerMailZIP4] = ltrim(rtrim([BuyerMailZIP4]))
       ,[BuyerMailCarrierCode] = ltrim(rtrim([BuyerMailCarrierCode]))
	   ,[BuyerMailCensusTract] = ltrim(rtrim([BuyerMailCensusTract]))
 
       ,[BuyerMailUnitType] = LEFT(case when len(ISNULL([PMB],'')) > 0 
								THEN 'PMB'
								ELSE UPPER(ltrim(rtrim([BuyerMailUnitType])))
								END,20)

       ,[BuyerMailDPVCount] = ltrim(rtrim([BuyerMailDPVCount]))
       ,[BuyerMailDPVFootnote] = ltrim(rtrim([BuyerMailDPVFootnote]))
       ,[BuyerMailLACS] = ltrim(rtrim([BuyerMailLACS]))
       ,[BuyerMailLACSLinkInd] = ltrim(rtrim([BuyerMailLACSLinkInd]))
       ,[BuyerMailDPCheckDigit] = ltrim(rtrim([BuyerMailDPCheckDigit]))
       ,[BuyerMailDPCheckCode] = ltrim(rtrim([BuyerMailDPCheckCode]))
       ,[BuyerMailCensusBlock] = ltrim(rtrim([BuyerMailCensusBlock]))
	   ,[BuyerMailStdMatchCode] = ltrim(rtrim([BuyerMailStdMatchCode]))
       ,[BuyerMailGeoErrorCode] = ltrim(rtrim([BuyerMailGeoErrorCode]))
       ,[BuyerMailGeoStatusCode] = ltrim(rtrim([BuyerMailGeoStatusCode]))
       ,[BuyerMailGeoCodeResults] = ltrim(rtrim([BuyerMailGeoCodeResults]))
	   ,[FIPS] = CASE WHEN len(ltrim(rtrim([FIPS]))) = 1 THEN NULL 
	             WHEN len(ltrim(rtrim([FIPS]))) = 4 THEN '0' + ltrim(rtrim([FIPS])) 
				 ELSE ltrim(rtrim([FIPS])) END


------ Trim all fields, make some fields uppdercase, rebuild BuyermailFullStreetAddress and BuyermailCensusTractBlock fields
----    set @sql = '
----	   UPDATE [AddressSTD].[dbo].[Deed_Buyermail_STD]
----	   set [BuyerMailFullAddress] = LEFT(ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim(ISNULL([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailHouseNbr],''''))) + '' '' + 
----                             ltrim(rtrim(ISNULL([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailLeftDirection],'''')))) + '' '' + 
----							 ltrim(rtrim(ISNULL(UPPER([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailStreetName]),'''')))) + '' '' + 
----							 ltrim(rtrim(ISNULL(UPPER([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailMode]),'''')))) + '' '' + 
----							 ltrim(rtrim(ISNULL(UPPER([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailRightDirection]),'''')))) + '' '' + 
----							 ltrim(rtrim(ISNULL(UPPER([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailUnitType]),'''')))) + '' '' + 
----							 ltrim(rtrim(ISNULL([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailUnitNumber],''''))))) + '' '' + 
----							 ltrim(rtrim(ISNULL([AddressSTD].[dbo].[Deed_Buyermail_STD].[PMB],''''))),116)
----       ,[BuyerMailHouseNbr]  = LEFT(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailHouseNbr])),32)
----       ,[BuyerMailLeftDirection] = LEFT(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailLeftDirection])),2)
----       ,[BuyerMailStreetName] = LEFT(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailStreetName]))),60)
----       ,[BuyerMailMode] = LEFT(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailMode]))),10)
----       ,[BuyerMailRightDirection] = LEFT(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailRightDirection])),2)
----       ,[BuyerMailUnitNumber] = LEFT(case when len(ISNULL([Deed_Buyermail_STD].[PMB],'''')) > 0 
----								and ISNULL([Deed_Buyermail_STD].[PMB],'''') not like ''''
----								THEN ltrim(rtrim(ISNULL([AddressSTD].[dbo].[Deed_Buyermail_STD].[PMB],'''')))
----								ELSE ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailUnitNumber])) 
----								END,15)

----       ,[BuyerMailCity] = LEFT(UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailCity]))),55)
----       ,[BuyerMailState] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailState]))
----       ,[BuyerMailZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailZIP5]))
----       ,[BuyerMailZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailZIP4]))
----       ,[BuyerMailCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailCarrierCode]))
----	   ,[BuyerMailCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailCensusTract]))
----       ,[BuyerMailUnitType] = LEFT(case when len(ISNULL([Deed_Buyermail_STD].[PMB],'''')) > 0 
----								and ISNULL([Deed_Buyermail_STD].[PMB],'''') not like ''''
----								THEN ''PMB''
----								ELSE UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailUnitType])))
----								END,20)

----       ,[BuyerMailDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailDPVCount]))
----       ,[BuyerMailDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailDPVFootnote]))
----       ,[BuyerMailLACS] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailLACS]))
----       ,[BuyerMailLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailLACSLinkInd]))
----       ,[BuyerMailDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailDPCheckDigit]))
----       ,[BuyerMailDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailDPCheckCode]))
----       ,[BuyerMailCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailCensusBlock]))
----	   ,[BuyerMailStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailStdMatchCode]))
----       ,[BuyerMailGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailGeoErrorCode]))
----       ,[BuyerMailGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailGeoStatusCode]))
----       ,[BuyerMailGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[BuyerMailGeoCodeResults]))
----	   ,[FIPS] = CASE WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[FIPS]))) = 1 THEN NULL 
----	             WHEN len(ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[FIPS]))) = 4 THEN ''0'' + ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[FIPS])) 
----				 ELSE ltrim(rtrim([AddressSTD].[dbo].[Deed_Buyermail_STD].[FIPS])) END
----	 From [AddressSTD].[dbo].[Deed_Buyermail_STD]
----    '
------print @sql
----exec (@sql) 


exec Global.dbo.[usp_ASP_Deed_Buyermail_to_Licensing]

--exec Staging.dbo.[01953_ASP_Deed_Buyermail_to_Licensing]

