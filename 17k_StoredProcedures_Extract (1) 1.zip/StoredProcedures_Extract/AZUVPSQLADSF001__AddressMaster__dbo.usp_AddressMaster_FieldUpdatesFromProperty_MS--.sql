SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_FieldUpdatesFromProperty_MS--]
AS

BEGIN
	SET NOCOUNT ON;

	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Started.'

	DECLARE @FipsCode varchar(5)
    -- Fix an issue with FIPS having 4 characters during quarterly process -- added 20200116 ------------------------------------------------------ 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
	    UPDATE AM 
        SET CountyFips = '0' + CountyFips 
	    from addressmaster.dbo.Address_Master AM 
	    where len(CountyFips) = 4 
	END

    -- CommunityName ------------------------------------------------------------------------------------------------------------------------------ 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   

			PRINT @FipsCode
			EXEC('UPDATE A set A.CommunityName = F.communityname, FATimestamp = getdate()  
	                  from AddressMaster.dbo.Address_Master A 
					  join fema.dbo.faflood F with (nolock) 
					  on A.CountyFips = F.FIPS and A.propertyid = F.propertyid 
					  where A.CountyFips = '''+@FipsCode+''' and F.FIPS = '''+@FipsCode+''' and 
					  (A.CommunityName is null  or A.CommunityName <> F.CommunityName)
					  and ISNULL(F.CommunityName,'''') NOT LIKE ''''
				      ')

			EXEC('UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					and (A.Municipality is null or A.Municipality <> P.Municipality)
						and ISNULL(P.Municipality, '''') NOT LIKE ''''
				  ')			

			EXEC('UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					and (A.SubdivisionName is null OR A.SubdivisionName <> P.SubdivisionName)
						and ISNULL(P.SubdivisionName, '''') NOT LIKE ''''
				  ')

			EXEC('UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					and (A.PropertyClassID is null OR a.[PropertyClassID] <> p.[PropertyClassID])
						and ISNULL(P.PropertyClassID, '''') NOT LIKE ''''
				  ')

			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

    -- send completed email -----------------------------------------------------------------------------------------------------------------------------
	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Successfully Completed.'

END
