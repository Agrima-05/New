SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








--[dbo].[GetMelissaInput] 'claddr_00'
CREATE procedure [dbo].[GetFlankInput](@tableName varchar(30))
as
declare @sql varchar(max) = ''
set @sql = '
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))
DROP TABLE ' + rtrim(@tableName) + '_STD'
exec (@sql)

	set @sql = '
	create table ' + rtrim(@tableName) + '_STD (' + '
	[ID] [int] NULL,
	[FIPS] [int] NULL,
	StreetNumber [char](20) NULL,
	PreDirection [char](2) NULL,
	StreetName [char](50) NULL,
	Suffix [char](4) NULL,
	PostDirection [char](2) NULL,
	UnitType [char](10) NULL,
	[Unit] [char](6) NULL,
	[City] [char](55) NULL,
	[State] [char](2) NULL,
	[Zip] [char](5) NULL,
	[Plus4] [char](4) NULL,
	[CRRT] [char](4) NULL,
	[CountyName] [char](35) NULL,
	[PMB] [varchar](30) NULL,
	[PMSA] [char](2) NULL,
	[MSA] [char](70) NULL,
	[ZipType] [char](2) NULL,
	[Urbanization] [char](6) NULL,
	[CongressionalDistrict] [char](2) NULL,
	[CountryCode] [char](10) NULL,
	[CityAbbreviation] [char](13) NULL,
	[AddressTypeCode] [char](1) NULL,
	[AddressTypeString] [char](60) NULL,
	[DPV_Count] [char](5) NULL,
	[DPV_Footnotes] [char](4) NULL,
	[CMRA] [char](1) NULL,
	[ELOT_Number] [char](5) NULL,
	[ELOT_Order] [char](2) NULL,
	[LACS] [char](1) NULL,
	[LACS_LinkIndicator] [char](1) NULL,
	[EWS_Flag] [char](1) NULL,
	[RBDI] [char](1) NULL,
	[SuiteLinkReturnCode] [char](1) NULL,
	[DeliveryPointCheckDigit] [char](1) NULL,
	[DeliveryPointCode] [char](2) NULL,
	[CensusBlock] [char](4) NULL,
	[CensusTract] [char](6) NULL,
	[PlaceCode] [char](7) NULL,
	[PlaceName] [char](60) NULL,
	[CBSA_Code] [char](5) NULL,
	[CBSA_Level] [char](30) NULL,
	[CBSA_Title] [char](50) NULL,
	[CBSA_DivisionCode] [char](5) NULL,
	[CBSA_DivisionLevel] [char](30) NULL,
	[CBSA_DivisionTitle] [char](50) NULL,
	[Latitude] [numeric](10, 6) NULL,
	[Longitude] [numeric](10, 6) NULL,
	[Verified] [bit] NULL,
	[Geocoded] [bit] NULL,
	[AddressMatchResults] [char](30) NULL,
	[GeoCodeResults] [char](30) NULL,
	[GeoErrorCode] [char](1) NULL,
	[GeoStatusCode] [char](1) NULL
 )
	'
  	--print @sql
  	exec (@sql)


set @sql = '
SELECT addrid as id
	  --,HouseNumber
	  , HouseNumber = dbo.fnGetHouseNumber(HOUSENBR, HOUSENBR2, HOUSENBRSUFFIX)
	  ,FIPS
	  ,rtrim(rtrim(rtrim(rtrim(rtrim(
		ISNULL(SUBSTRING(rtrim(isnull(dbo.fnGetHouseNumber(HOUSENBR, HOUSENBR2, HOUSENBRSUFFIX), ''''))
						, PATINDEX(''%[^0]%'', ISNULL(dbo.fnGetHouseNumber(HOUSENBR, HOUSENBR2, HOUSENBRSUFFIX), ''''))
						, LEN(dbo.fnGetHouseNumber(HOUSENBR, HOUSENBR2, HOUSENBRSUFFIX))), '''') + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(LeftDIRECTION, ''''))) + ' + '''' + ' ' +  '''' + '+
	  ISNULL(SUBSTRING(rtrim(isnull(STREETNAME, '''')) 
	  					, PATINDEX(''%[^0]%'', ISNULL(STREETNAME, ''''))
						, LEN(STREETNAME)), '''') ) + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(MODE, ''''))) + ' + '''' + ' ' +  '''' + '+
	  rtrim(isnull(RightDirection, ''''))) + ' + '''' + ' ' +  '''' + '+
	  CASE WHEN LEN(ISNULL(SUBSTRING(rtrim(isnull(UnitNumber, ''''))
						, PATINDEX(''%[^0]%'', ISNULL(UnitNumber, ''''))
						, LEN(UnitNumber)), '''')) > 0 THEN
				 ''#'' + ISNULL(SUBSTRING(rtrim(isnull(UnitNumber, ''''))
							, PATINDEX(''%[^0]%'', ISNULL(UnitNumber, ''''))
							, LEN(UnitNumber)), '''')
			ELSE '''' END) as addressLine
	  ,isnull(CITY, '''') as city
	  ,isnull(STATE, '''') as state
	  ,isnull(ZIP5 + '''' + ZIP4, '''') as zip  FROM ' + @tableName + 
	  ' ORDER BY ZIP5 ASC'
--SELECT addrid as id
--	  ,HouseNumber
--	  ,FIPS
--	  ,rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(isnull(HouseNumber, '''')) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(DIRECTION, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(STREET_NAME, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(MODE, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(QUADRANT, ''''))) + ' + '''' + ' ' +  '''' + '+
--	  rtrim(isnull(UNIT_NBR, ''''))) as addressLine
--	  ,isnull(CITY, '''') as city
--	  ,isnull(STATE, '''') as state
--	  ,isnull(ZIP_CODE, '''') as zip  FROM ' + @tableName + 
--	  ' ORDER BY ZIP_CODE ASC'
exec (@sql)








