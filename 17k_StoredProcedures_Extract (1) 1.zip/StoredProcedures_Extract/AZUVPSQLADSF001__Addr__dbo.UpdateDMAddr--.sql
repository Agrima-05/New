SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create procedure [dbo].[UpdateDMAddr--] (@fips int) as

update DMaddr set Ref_Id = 0 where FIPS = @fips


