SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[usp_load_FADigitalMap--] 
AS
BEGIN
	SET NOCOUNT ON;

-- Step 1) load FADigitalMap
    -- TRUNCATE TABLE [DigitalMap].[dbo].[FADigitalMap]
    INSERT INTO [DigitalMap].[dbo].[FADigitalMap] -- 143,621,789 rows
       ([APN]
       ,[FIPS]
       ,[Latitude]
       ,[Longitude]
       ,[ParcelPointGeography]
       ,[ParcelPointGeometry]
       ,[AddressScore]
       ,[GeoSource]
	   ,[PARCELAPN])
    SELECT [TAXAPN]
       ,[FIPS]
	   ,[YCOORD]
	   ,[XCOORD]
	   ,[GEOG]
	   ,[GEOM]
	   ,[ADDRSCORE]
	   ,[GEOSOURCE]
	   ,[PARCELAPN]
    FROM [DigitalMap].[dbo].[ParcelPoint] (nolock)

-- Step 2) load PropertyID
    UPDATE FADM -- 143,378,386 rows
	    SET FADM.PropertyID = PM.FAPropertyParent
	    FROM DigitalMap.dbo.FADigitalMap FADM (nolock)
	    INNER JOIN Global.dbo.Property_Master PM (nolock)
	    ON FADM.FIPS = PM.FIPS and FADM.APN = PM.FormattedAPN
		WHERE FADM.PropertyID IS NULL

-- Step 3) load CustomSearch..DM_Data.point and CustomSearch..DM_Data.Parcel
    UPDATE FADM -- 136,980,682 rows 17 hours
	    SET FADM.ParcelGeography = P.GEOG,
		    FADM.ParcelGeometry = P.GEOM
	    FROM DigitalMap.dbo.FADigitalMap FADM (nolock)
	    INNER JOIN DigitalMap.dbo.Parcel P (nolock)
	    ON FADM.FIPS = P.FIPS and FADM.PARCELAPN = P.PARCELAPN and FADM.PARCELAPN  <> ''

-- Step 4) load DigitalMap..EstLotSizeSqFt
    UPDATE FADM --  136,980,682 rows 3:15 hours
	    SET FADM.EstLotSizeSqFt = cast(FADM.ParcelGeography.STArea() * 10.7639104 as bigint)
		-- SELECT top 10 FADM.ParcelGeography, FADM.EstLotSizeSqFt
	    FROM DigitalMap.dbo.FADigitalMap FADM
		WHERE FADM.ParcelGeography IS NOT NULL

-- Step 5) load Parcel data where PARCELAPN is null
    INSERT INTO [DigitalMap].[dbo].[FADigitalMap] (PARCELAPN, FIPS, ParcelGeography, ParcelGeometry) -- 7,634,540 2:09 hours
        SELECT p1.PARCELAPN,  p1.FIPS, p1.GEOG,  p1.GEOM
        FROM [DigitalMap].[dbo].Parcel p1 
        LEFT JOIN  [DigitalMap].[dbo].ParcelPoint p2 
        ON p1.Fips = p2.Fips and p1.PARCELAPN = p2.PARCELAPN and P1.PARCELAPN  <> ''
        WHERE p2.PARCELAPN is null

-- Step 6) load DigitalMap..EstLotSizeSqFt (part 2)
    UPDATE FADM -- 144,615,222 -- 1:09 hour
	    SET FADM.EstLotSizeSqFt = cast(FADM.ParcelGeography.STArea() * 10.7639104 as bigint)
		-- SELECT top 10 FADM.ParcelGeography, FADM.EstLotSizeSqFt
	    FROM DigitalMap.dbo.FADigitalMap FADM
		WHERE FADM.ParcelGeography IS NOT NULL AND FADM.EstLotSizeSqFt IS NULL 
/*
-- SELECT count(*) from [DigitalMap].[dbo].[FADigitalMap] WHERE PARCELAPN is null -- 0 -- 2/9/2016

--    SELECT count(*) -- 7634540 -- 2 hours -- 2/9/2016
--        FROM [DigitalMap].[dbo].Parcel p1 
--        LEFT JOIN  [DigitalMap].[dbo].ParcelPoint p2 
--        ON p1.Fips = p2.Fips and p1.PARCELAPN = p2.PARCELAPN
--        WHERE p2.PARCELAPN is null

-- Step 7) load PropertyID (part 2)
    UPDATE FADM -- 
	    SET FADM.PropertyID = PM.FAPropertyParent
	    FROM DigitalMap.dbo.FADigitalMap FADM (nolock)
	    INNER JOIN Global.dbo.Property_Master PM (nolock)
	    ON FADM.FIPS = PM.FIPS and FADM.PARCELAPN = PM.FormattedAPN
		WHERE FADM.PropertyID IS NULL
*/

/*
--CREATE NONCLUSTERED INDEX [IX_FADigitalMap_FIPS_PARCELAPN] ON [dbo].[FADigitalMap] ([FIPS],[PARCELAPN])
--CREATE NONCLUSTERED INDEX [IX_FADigitalMap_FIPS_APN] ON [dbo].[FADigitalMap] ([FIPS],[APN])
--CREATE NONCLUSTERED INDEX [IX_Parcel_FIPS_PARCELAPN] ON [dbo].[Parcel] ([FIPS],[PARCELAPN])
*/

END

