SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================

CREATE PROCEDURE [dbo].[d001_LoadDragonBatch_Updates_V2_Missing]
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)

		BEGIN
	
				DECLARE @2 varchar(255) = 'micsmith@firstam.com', 
				@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject2 varchar(50) = 'Dragon Assr Load Started Missing',
				@t_body2 varchar(2000) = 'The Dragon Assr Data Load process has started for Missing REF_IDs.'


				SET NOCOUNT ON;
				DECLARE @t_getdate2 datetime = GETDATE()
				SET @t_body2 = @t_body2 + ' : ' + cast(@t_getdate2 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					-- @recipients = @t_recipients,
					@recipients = @2,
					@profile_name = @t_profile_name2,
					@subject = @t_subject2,
					@body = @t_body2
---------------------------------------------------------------------------------------------------------------------
		TRUNCATE TABLE DragonProcessingTracker

		INSERT INTO DragonProcessingTracker
		Select 'STEP 1 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		DROP TABLE IF EXISTS dbo.Dragon_Flank_Batch_ASSR_Updt

		Select RIGHT([name],5) as FipsToIgnore INTO #FipsToIgnore from DragonAssr.sys.tables where [name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]'

		SELECT a.*,0 as MatchCode,convert(varchar(5),'') as FipsCode,convert(bigint,0) as PropertyID
		INTO dbo.Dragon_Flank_Batch_ASSR_Updt
		  From  [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] A with(NOLOCK)
			left outer join data.dbo.Property as B with(NOLOCK) on A.FIPS = cast(B.FIPS as int) and A.FORMATTED_APN = B.FormattedAPN
			WHERE B.DTDB_REF_ID is null 
			and A.Source_Type = 'G'
			and A.FIPS <> 10003
			and A.FIPS not in(Select FipsToIgnore from #FipsToIgnore)

		DROP TABLE #FipsToIgnore

		CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsRefID] ON [dbo].[Dragon_Flank_Batch_ASSR_Updt]
		(
			[FIPS] ASC,
			[REF_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		UPDATE dbo.Dragon_Flank_Batch_ASSR_Updt SET PropertyID = NULL WHERE PropertyID = 0

		INSERT INTO DragonProcessingTracker
		Select 'STEP 1 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------
		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

			EXEC [dbo].[002_remove_Extra_Ascii_from_table] 'Dragon_Flank_Batch_ASSR_Updt'


	----- CLEAN LEAD ZEROS
		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_HOUSE_NBR = Global.dbo.DeleteLeadZeros(SITUS_HOUSE_NBR)
		WHERE SITUS_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_STREET_NAME = Global.dbo.DeleteLeadZeros(SITUS_STREET_NAME)
		WHERE SITUS_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_UNIT_NBR = Global.dbo.DeleteLeadZeros(SITUS_UNIT_NBR)
		WHERE SITUS_UNIT_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_HOUSE_NBR = Global.dbo.DeleteLeadZeros(MAIL_HOUSE_NBR)
		WHERE MAIL_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_STREET_NAME = Global.dbo.DeleteLeadZeros(MAIL_STREET_NAME)
		WHERE MAIL_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_UNIT_NBR = Global.dbo.DeleteLeadZeros(MAIL_UNIT_NBR)
		WHERE MAIL_UNIT_NBR like '00%'

		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

	----- FILL IN FIPSCODE AND PROPERTYID

		UPDATE a
		SET Fipscode = RIGHT('0' + convert(varchar(5),FIPS),5)
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a
		WHERE isNULL(Fipscode,'') like ''

		UPDATE a
		SET PropertyID = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	
		--DROP TABLE dbo.Dragon_CertDates

		--SELECT Fipscode,convert(DATE,Max(CASE WHEN isNULL(TAX_YEAR,'') like '' THEN ASSESSED_YEAR ELSE TAX_YEAR END ) + '0101') as CERTIFICATION_DATE
		--INTO dbo.Dragon_CertDates
		--  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR_Updt]
		--  WHERE isNULL(TAX_YEAR,'') NOT like '' or isNULL(ASSESSED_YEAR,'') NOT like ''
		--  GROUP BY Fipscode
		--  ORDER BY Fipscode
  	

		update dbo.Dragon_Flank_Batch_ASSR_Updt
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR_Updt] with(NOLOCK)
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)

		DROP TABLE IF EXISTS dbo.DragonAssrCounts

		DECLARE @CertDt Varchar(8) = Convert(varchar(8),GETDATE()-90,112)
		
		EXEC('Select x.FIPSCode,x.RecCount,x.RecordsInTaxroll,x.CERTIFICATION_DATE,CASE WHEN x.RecCount between x.RecordsInTaxroll -(x.RecordsinTaxroll * .10) and x.RecordsInTaxroll +(x.RecordsinTaxroll * .10) THEN ''REFRESH'' ELSE ''UPDATE'' END as RefreshUpdate
		INTO DragonAssrCounts
		FROM(
			SELECT a.FipsCode,COUNT(*) as RecCount,RecordsinTaxroll,'''+@CertDt+''' as CERTIFICATION_DATE
			FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN Global.dbo.County b
			on a.FipsCode = b.FIPSCode
			GROUP BY a.FipsCode,RecordsinTaxroll
			) X
			ORDER BY x.FipsCode
		')

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d005_DragonAssrLoad_Update_Looper]

		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		--Truncate Table dbo.Dragon_Update_Tracker

		UPDATE a
		SET [MaxCreated] = b.MaxCreated
		,[MaxUpdated] = b.MaxUpdated
		,[DateLastUpdate] = GETDATE()
		FROM dbo.Dragon_Update_Tracker a JOIN (
		SELECT [FIPS],Max([CREATED]) as MaxCreated,Max([UPDATED]) as MaxUpdated
		  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR_Updt]
		  GROUP BY FIPS
		  ) b
		ON a.FIPS = b.[FIPS]

		EXEC [dbo].[d700_Post_Dragon_To_Licensing_UPDATE]
		
		--DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)
		DECLARE @DFB as varchar(50) = 'Dragon_Flank_Batch_ASSR_Updt_' + @PULLDT
		DECLARE @DAC as varchar(50) = 'DragonAssrCounts_' + @PULLDT

		EXEC sp_rename Dragon_Flank_Batch_ASSR_Updt,@DFB

		EXEC sp_rename DragonAssrCounts,@DAC

			DECLARE @3 varchar(355) = 'micsmith@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon Assr Load Finished Missing',
				@t_body3 varchar(2000) = 'The Dragon Assr Data Load process has finished for Missing REF_IDs.'

				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + ' : ' + cast(@t_getdate3 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3

	END


END

