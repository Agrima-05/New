SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_400_MatchByPattern] 
AS
BEGIN
	


--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[m_MatchWork](
--	[Id] [int] IDENTITY(1,1) NOT NULL,
--	[Fips] [varchar](5) NULL,
--	[Stage] [int] NULL,
--	[Updated] [datetime] NULL,
-- CONSTRAINT [PK_MatchWork] PRIMARY KEY CLUSTERED 
--(
--	[Id] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--) ON [PRIMARY]

--GO

--SET ANSI_PADDING OFF
--GO


DECLARE @fips VARCHAR(5) --   
DECLARE @MatchRule VARCHAR(256) --   
DECLARE @sourcePattern VARCHAR(256) -- 
DECLARE @destPattern VARCHAR(256) -- 
DECLARE @destColumnName VARCHAR(50) --
DECLARE @ruleNumber int
DECLARE @runningSumOfRatio float
DECLARE @ApproveFlag int

DECLARE @OccurrenceRatio float 

/*Load work table*/
IF OBJECT_ID('tempdb..#work') IS NOT NULL
	DROP TABLE #work

select * into #work from dbo.m_MatchWork  with(nolock) ORDER BY Fips


DECLARE db_cursor CURSOR FOR  
	SELECT Fips  
		FROM #work 
		WHERE Updated is null --and  Fips = '01001'

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @fips   


/*Loop thru work table*/
WHILE @@FETCH_STATUS = 0   
BEGIN   
    set @ruleNumber = 0

	RAISERROR (@fips, 10, 1) WITH NOWAIT
   
   /*Load candidates from Proerty master*/
	IF OBJECT_ID('tempdb..#property_master') IS NOT NULL
		DROP TABLE #property_master

	select FAPropertyId,FormattedAPNMask, TaxAccountNumberMask, FormattedAPN, TaxAccountNumber  into #property_master from [dbo].property_master  with(nolock) where Fips  = @fips 
	
	alter table #property_master add  ApnComponents varchar(50)
	create nonclustered index  f on #property_master (FormattedAPN)
    create nonclustered index  fd on #property_master (ApnComponents)
	
	RAISERROR ('created propertymaster', 10, 1) WITH NOWAIT




	/*Load apn to be matched*/
	IF OBJECT_ID('tempdb..#m_FADMNoMatched') IS NOT NULL
		DROP TABLE #m_FADMNoMatched

	select PropertyId, PARCELAPN, PARCELAPNMask, MatchedBy, MatchRule  into #m_FADMNoMatched from [dbo].m_FADMNoMatched  with(nolock) where Fips  = @fips and PARCELAPN <> ''
	
	alter table #m_FADMNoMatched add  ApnComponents varchar(50)

	create nonclustered index  f on #m_FADMNoMatched (PARCELAPN)
	create nonclustered index  fs on #m_FADMNoMatched (ApnComponents)
	RAISERROR ('created m_FADMNoMatched', 10, 1) WITH NOWAIT



	/*Load patterns*/
	IF OBJECT_ID('tempdb..#PatternCount') IS NOT NULL
		DROP TABLE #PatternCount

	--Pattern Count 
	select * into #PatternCount from dbo.m_PatternCount where Fips  = @fips 
	and( MatchRule like '%:{%' 
	and OccurrenceRatio > 0.05 
	and [Pattern] is not null
	and Count > 100
	or ApproveFlag = 1)
	order by OccurrenceRatio desc


	DECLARE pc_cursor CURSOR FOR  
		SELECT MatchRule, SourcePattern, DestPattern, DestColumnName, OccurrenceRatio, ApproveFlag 
		FROM #PatternCount 	
	
	OPEN pc_cursor   
	FETCH NEXT FROM pc_cursor INTO @MatchRule,   @SourcePattern, @DestPattern, @DestColumnName, @OccurrenceRatio, @ApproveFlag
	
	set @runningSumOfRatio =   @OccurrenceRatio

	/*Loop through each patter*/
	BEGIN TRANSACTION
	WHILE @@FETCH_STATUS = 0 and  ( @runningSumOfRatio < 1.9 and @ruleNumber < 4 or @approveFlag = 1)
	BEGIN   
		RAISERROR ('Begin pattern loop', 10, 1) WITH NOWAIT
		set @ruleNumber = @ruleNumber + 1
		
		DROP INDEX fs ON #m_FADMNoMatched
		DROP INDEX fd ON #property_master
		
		

		--Create ApnComponents on Source Apn
		update #m_FADMNoMatched set ApnComponents = DigitalMap.dbo.GetMatchableComponents(PARCELAPN, @MatchRule, 1)
		create nonclustered index  fs on #m_FADMNoMatched (ApnComponents)		
		RAISERROR ('created m_FADMNoMatched.ApnComponents', 10, 1) WITH NOWAIT

		--select * from #m_FADMNoMatched

		--Create ApnComponents 

		--RAISERROR (@MatchRule, 10, 1) WITH NOWAIT
		--RAISERROR (@DestColumnName, 10, 1) WITH NOWAIT
		
		update #property_master set ApnComponents = DigitalMap.dbo.GetMatchableComponents(CASE @DestColumnName WHEN 'FormattedAPN' THEN FormattedAPN ELSE TaxAccountNumber END, @MatchRule, 0)
		--select * from #property_master
		create nonclustered index  fd on #property_master (ApnComponents)
		RAISERROR ('created #property_master.ApnComponents', 10, 1) WITH NOWAIT		
		RAISERROR (@MatchRule, 10, 1) WITH NOWAIT
		
		RAISERROR ('Updating #m_FADMNoMatched................', 10, 1) WITH NOWAIT
		
		
		--select * from #property_master
		--select * from #m_FADMNoMatched

		--select * from #property_master
		--Compare
		Update d set d.PropertyId = p.FAPropertyId, MatchedBy = 'Rule '+ cast(@ruleNumber as varchar(5)),
			d.MatchRule = @MatchRule
		  from #m_FADMNoMatched d
		  inner join #property_master p with(nolock)
		  on 		
			 @sourcePattern = d.PARCELAPNMask --Pre-qualification for matching

			and
			(
				(@destPattern = p.FormattedAPNMask and  @DestColumnName = 'FormattedAPN')
			
				or
				(@destPattern = p.TaxAccountNumberMask and  @DestColumnName <> 'FormattedAPN')
			
			)--Pre-qualification for matching
			
			and  d.ApnComponents = p.ApnComponents 
			and d.ApnComponents <> ''
		  where PropertyId is null





		RAISERROR ('Updating #m_FADMNoMatched....................................done', 10, 1) WITH NOWAIT
		
		--Update work table
		update dbo.m_MatchWork set Stage = @ruleNumber where Fips = @fips


		FETCH NEXT FROM pc_cursor INTO @MatchRule ,   @SourcePattern, @DestPattern , @DestColumnName, @OccurrenceRatio, @ApproveFlag
		set @runningSumOfRatio = @runningSumOfRatio + @OccurrenceRatio
	END --End Patther loop 
	CLOSE pc_cursor   
	DEALLOCATE pc_cursor
	
	RAISERROR ('Updating m_FADMNoMatched..........', 10, 1) WITH NOWAIT
	--Update the actual Table with new PropertyIds
	update p set p.PropertyId = t.PropertyId, p.MatchedBy = t.MatchedBy, p.MatchRule = t.MatchRule from Digitalmap.dbo.m_FADMNoMatched p inner join #m_FADMNoMatched t on p.PARCELAPN = t.PARCELAPN and t.PARCELAPN <> '' and t.PropertyID is not null
	where p.Fips = @fips and p.PropertyID is null 

	RAISERROR ('Updating m_FADMNoMatched.......... Done', 10, 1) WITH NOWAIT
	RAISERROR ('Updating m_MatchWork', 10, 1) WITH NOWAIT
	update Digitalmap.dbo.m_MatchWork set Updated = getdate()  where Fips = @fips
	RAISERROR ('Updating m_MatchWork  Done', 10, 1) WITH NOWAIT
	COMMIT;
	FETCH NEXT FROM db_cursor INTO @fips   
END   --End Patther loop

CLOSE db_cursor   
DEALLOCATE db_cursor
END


