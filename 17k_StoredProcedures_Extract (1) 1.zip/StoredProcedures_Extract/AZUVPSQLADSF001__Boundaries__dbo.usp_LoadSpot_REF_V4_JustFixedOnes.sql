SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[usp_LoadSpot_REF_V4_JustFixedOnes]
AS
BEGIN

	SET NOCOUNT ON;


	TRUNCATE TABLE dbo.SpotSteps

/*****STEP 1 STARTS HERE*****/

		insert into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 1','Getting Counties That Need To Pull', GETDATE(), NULL,'If STEP 1 Errors Just Restart the entire procedure'

			DROP TABLE IF EXISTS dbo.FASpotStats

			Select FIPS,Max([LoadDate]) as [LoadDate],Count(*) as RecordCount,SUM(CASE WHEN PropertyID is not null then 1 ELSE 0 END) as HasPropertyID,'Y' as RefreshMe
			INTO dbo.FASpotStats
			 from [dbo].[vFASpot_FULL]
			 WHERE FIPS in('16083')
			 group by fips order by FIPS

			 CREATE UNIQUE INDEX [ix_FIPS] on dbo.FASpotStats(FIPS)

		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 1'

/*****STEP 2 STARTS HERE*****/

		insert into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 2','Pulling Spot data from DTDB034.Spot database', GETDATE(), NULL,'If STEP 2 Errors run this query  Select Max(FIPS) as startFips from dlvry.POINT_REF  then run and plug that startFips into [dbo].[usp_LoadSpot_REF_V4_RestartDuringDataPull]'

			 
		DECLARE @FipsCode varchar(5)
		DECLARE @StateAbbrev varchar(2)

		------- PULL New Spot data

		TRUNCATE TABLE dlvry.Parcel_REF
		TRUNCATE TABLE dlvry.POINT_REF

		--DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE FIPSCode in(SELECT FIPS FROM dbo.FASpotStats where RefreshMe = 'Y')
			--and FIPSCode > '05057'
			ORDER BY [FIPSCode]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			--PRINT @FipsCode

			EXEC('
			DROP table if Exists dlvry.Parcel_REF_TEMP

			--UPDATE [AZUVPSQLDTDB034].[NG911].dbo.Spt_Delivery 
			--SET RunRefresh = getdate()
			--WHERE Fips = ''' + @Fipscode + '''

			Select * 
			INTO dlvry.Parcel_REF_TEMP
			from Openquery([AZUVPSQLDTDB034],''Select * FROM [Spot].[dlvry].[Parcel] with(NOLOCK) where Fips = ''''' + @Fipscode + ''''' '')

			alter table dlvry.Parcel_REF_TEMP add PropertyID bigint,REF_ID bigint
			
			--CREATE INDEX ix_FIPS ON dlvry.Parcel_REF_TEMP(FIPS)

			DELETE FROM dlvry.Parcel_REF WHERE FIPS = ' + @Fipscode + '

			INSERT INTO dlvry.Parcel_REF([Id]
				  ,[UniqueGuid]
				  ,[Fips]
				  ,[Geom]
				  ,[CreatedDate]
				  ,[UpdatedDate]
				  ,[Area]
				  ,[Sqft]
				  ,[Apn]
				  ,[Apn1]
				  ,[Apn2]
				  ,[FeatureType]
				  ,[Geom3857]
				  ,[PropertyID]
				  ,[REF_ID])
			SELECT [Id]
				  ,[UniqueGuid]
				  ,[Fips]
				  ,[Geom]
				  ,[CreatedDate]
				  ,[UpdatedDate]
				  ,[Area]
				  ,[Sqft]
				  ,[Apn]
				  ,[Apn1]
				  ,[Apn2]
				  ,[FeatureType]
				  ,[Geom3857]
				  ,[PropertyID]
				  ,[REF_ID] 
			FROM dlvry.Parcel_REF_TEMP

			DROP table if Exists dlvry.Point_REF_TEMP

			Select * 
			INTO dlvry.Point_REF_TEMP
			from Openquery([AZUVPSQLDTDB034],''Select * FROM [Spot].[dlvry].[Point] with(NOLOCK) where Fips = ''''' + @Fipscode + ''''' '')

			alter table dlvry.Point_REF_TEMP add PropertyID bigint

			--CREATE INDEX ix_FIPS ON dlvry.Point_REF_TEMP(FIPS)

			DELETE FROM dlvry.Point_REF WHERE FIPS = ' + @Fipscode + '

			INSERT INTO dlvry.Point_REF([Fips]
					  ,[MasterAssrId]
					  ,[UnformattedApn]
					  ,[FormattedApn]
					  ,[RefId]
					  ,[AddressLine]
					  ,[City]
					  ,[State]
					  ,[Zip]
					  ,[GeomParcel]
					  ,[ParcelUniqueGuid]
					  ,[SharedParcel]
					  ,[Geom]
					  ,[Latitude]
					  ,[Longitude]
					  ,[GeoAccuracy]
					  ,[Sqft]
					  ,[MatchedBy]
					  ,[GeoStatusCode]
					  ,[GeomParcel3857]
					  ,[Geom3857]
					  ,[PropertyID])
			SELECT [Fips]
					  ,[MasterAssrId]
					  ,[UnformattedApn]
					  ,[FormattedApn]
					  ,[RefId]
					  ,[AddressLine]
					  ,[City]
					  ,[State]
					  ,[Zip]
					  ,[GeomParcel]
					  ,[ParcelUniqueGuid]
					  ,[SharedParcel]
					  ,[Geom]
					  ,[Latitude]
					  ,[Longitude]
					  ,[GeoAccuracy]
					  ,[Sqft]
					  ,[MatchedBy]
					  ,[GeoStatusCode]
					  ,[GeomParcel3857]
					  ,[Geom3857]
					  ,[PropertyID] 
			FROM dlvry.Point_REF_TEMP

			')

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 


		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 2'

/*****STEP 3 STARTS HERE*****/

		insert into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 3','Linking Spot data to PropertyIDs', GETDATE(), NULL,'If STEP 3 Errors run [dbo].[usp_LoadSpot_REF_V4_RestartAfterDataPull]'

	-----------LINK DATA
	BEGIN
	-------- LINK PARCEL

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Parcel_REF]') AND name = N'ix_FipsAPN')
		CREATE NONCLUSTERED INDEX [ix_FipsAPN] ON [dlvry].[Parcel_REF]
		([Fips] ASC,[Apn] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Parcel_REF]') AND name = N'ix_FipsAPN1')
		CREATE NONCLUSTERED INDEX [ix_FipsAPN1] ON [dlvry].[Parcel_REF]
		([Fips] ASC,[Apn1] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Parcel_REF]') AND name = N'ix_FipsAPN2')
		CREATE NONCLUSTERED INDEX [ix_FipsAPN2] ON [dlvry].[Parcel_REF]
		([Fips] ASC,[Apn2] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Parcel_REF]') AND name = N'ix_GUID')
		CREATE NONCLUSTERED INDEX [ix_GUID] ON [dlvry].[Parcel_REF]
		([UniqueGuid] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		---- APN
		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.FormattedAPN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(FormattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.UNFormattedAPN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(UNFormattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.TaxAccountNumber
		Where a.PropertyID is NULL and a.APN is not null and isNULL(TaxAccountNumber,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.OldAPN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(OldAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = replace(OldAPN,'-','')
		Where a.PropertyID is NULL and a.APN is not null and isNULL(OldAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.DTDB_FORMATTED_APN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(DTDB_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.DTDB_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(DTDB_UNFORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.CS_FORMATTED_APN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(CS_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn = b.CS_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.APN is not null and isNULL(CS_UNFORMATTED_APN,'') not like ''

		---- APN1
		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.FormattedAPN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(FormattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.UnformattedAPN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(UnformattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.TaxAccountNumber
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(TaxAccountNumber,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.OldAPN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(OldAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.DTDB_FORMATTED_APN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(DTDB_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.DTDB_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(DTDB_UNFORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.CS_FORMATTED_APN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(CS_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn1 = b.CS_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.Apn1 is not null and isNULL(CS_UNFORMATTED_APN,'') not like ''

		---- APN2
		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.FormattedAPN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(FormattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.UnformattedAPN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(UnformattedAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.TaxAccountNumber
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(TaxAccountNumber,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.OldAPN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(OldAPN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.DTDB_FORMATTED_APN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(DTDB_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.DTDB_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(DTDB_UNFORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.CS_FORMATTED_APN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(CS_FORMATTED_APN,'') not like ''

		update a
		SET a.PropertyID = b.PropertyID
		,a.REF_ID = b.DTDB_REF_ID
		From [dlvry].Parcel_REF a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.Apn2 = b.CS_UNFORMATTED_APN
		Where a.PropertyID is NULL and a.Apn2 is not null and isNULL(CS_UNFORMATTED_APN,'') not like ''

	-------- LINK POINT
			IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Point_REF]') AND name = N'ix_FipsFormatted')
			CREATE NONCLUSTERED INDEX [ix_FipsFormatted] ON [dlvry].[Point_REF]
			([Fips] ASC,[FormattedApn] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Point_REF]') AND name = N'ix_FipsREFID')
			CREATE NONCLUSTERED INDEX [ix_FipsREFID] ON [dlvry].[Point_REF]
			([Fips] ASC,[RefId] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Point_REF]') AND name = N'ix_FipsUnFormatted')
			CREATE NONCLUSTERED INDEX [ix_FipsUnFormatted] ON [dlvry].[Point_REF]
			([Fips] ASC,[UnformattedApn] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dlvry].[Point_REF]') AND name = N'ix_GUID')
			CREATE NONCLUSTERED INDEX [ix_GUID] ON [dlvry].[Point_REF]
			([ParcelUniqueGuid] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.refid = b.dtdb_ref_id 
			Where a.PropertyID is NULL and DTDB_Ref_ID is not null

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.FormattedAPN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.UNFormattedAPN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.FormattedAPN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.UNFormattedAPN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.DTDB_FORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.DTDB_UNFORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.DTDB_FORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.DTDB_UNFORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.CS_FORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.FormattedApn = b.CS_UNFORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.FormattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.CS_FORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 

			update a
			SET a.PropertyID = b.PropertyID
			From [dlvry].Point_REF a JOIN data.dbo.Property b with(NOLOCK)
			on a.fips = b.fips
			and a.UnformattedApn = b.CS_UNFORMATTED_APN
			Where a.PropertyID is NULL and ISNULL(a.UnformattedApn,'') NOT LIKE '' 
	END

	
		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 3'

/*****STEP 4 STARTS HERE*****/

		INSERT into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 4','Running CRAP Cleaner', GETDATE(), NULL,'If STEP 4 Errors run [dbo].[usp_LoadSpot_REF_V4_RestartAfterLinking]'

	
	----------CLEAN DATA

			EXEC [dbo].[usp_remove_Extra_Ascii_from_table] 'Parcel_REF'
			EXEC [dbo].[usp_remove_Extra_Ascii_from_table] 'Point_REF'

	
		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 4'

/***** SET SO JOBS DONT RUN *****/
	UPDATE jobs.dbo.SystemProperty
	SET [Value] = 'Y'
	,UpdateDate = GETDATE()
	WHERE Name = 'IsSpotRunning'

/*****STEP 5 STARTS HERE*****/

		INSERT into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 5','Loading Data into FASpot tables', GETDATE(), NULL,'If STEP 5 Errors run [dbo].[usp_LoadSpot_REF_V4_RestartPostingData]'

	----------START DATA LOAD

		DROP TABLE IF EXISTS dbo.UpdateRecords
		
		SELECT [FIPSCode],[State],NULL as COMPLETE
		INTO dbo.UpdateRecords 
			FROM [Global].dbo.[County] with(NOLOCK)
			WHERE [FIPSCode] in(Select FIPS FROM dlvry.Point_REF group by fips)
				--and [FIPSCode] >= '06065'
			ORDER BY [FIPSCode] 

			EXEC [dbo].[usp_LoadSpot_REF_V4_reStart_DataLoad_JustFixedOnes]

			EXEC [dbo].[usp_LoadSpot_REF_V4_reStart_DataLoad_a_JustFixedOnes]


		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 5'

/*****STEP 6 STARTS HERE*****/

		INSERT into dbo.SpotSteps([STEP],[WhatItsDoing],[StartTime],[FinishTime],[OnErrorDoThis])
		Select 'STEP 6','Rerunning Stats and Cleaning', GETDATE(), NULL,'If STEP 6 Errors run [dbo].[usp_LoadSpot_REF_V4_RestartFinishing]'

			UPDATE a
			 SET RunRefresh = convert(varchar(8),Getdate(),112)
			 from [AZUVPSQLDTDB034].[NG911].dbo.Spt_Delivery a JOIN dbo.FASpotStats b
			 on a.FIPS = b.FIPS
			 where RefreshMe = 'Y'


		DROP TABLE IF EXISTS [Boundaries].dbo.UpdateRecords

			update FASpot
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot
			WHERE LoadDate > GETDATE()-1 and LEN(GeomWKT)>10000000

			update FASpot_a
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_a
			WHERE LoadDate > GETDATE()-1 and LEN(GeomWKT)>10000000

			update FASpot_Generated
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_Generated
			WHERE LoadDate > GETDATE()-1 and LEN(GeomWKT)>10000000

			update FASpot_Generated_a
			SET GeomWKT = [ParcelGeometry4269].Reduce(0.000001).MakeValid().STAsText()
			,FATimestamp = GETDATE()
			FROM FASpot_Generated_a
			WHERE LoadDate > GETDATE()-1 and LEN(GeomWKT)>10000000

		UPDATE dbo.SpotSteps
		SET FinishTime = GETDATE()
		WHERE [STEP] = 'STEP 6'

/***** SET SO JOBS RUN *****/
	UPDATE jobs.dbo.SystemProperty
	SET [Value] = 'N'
	,UpdateDate = GETDATE()
	WHERE Name = 'IsSpotRunning'


END



