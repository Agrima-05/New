SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[UpdateParcel--](@fips int) as
                              update d
                              set d.parcel = p.parcel
                              from addr.dbo.DMaddr1231 d, Parcels_20121231.dbo.Parcels p
                              where d.fips =  @fips
                              and d.PARCEL_APN = p.apn
                              
                            
--declare @id int = 1 
--declare @max int 
--declare @fips int 
--declare @flag smallint 

--update addr.dbo.Deletefips  set flag = 0
--select @max = MAX(id) from addr.dbo.Deletefips  where flag = 0 
--while @id <= @max 
--begin 
--        select @fips = fips, @flag = flag from addr.dbo.Deletefips  where id = @id 
--        if @flag = 0 begin 
--                        begin try 
--                                --select @completed  = getdate()
--                                execute addr.dbo.[UpdateParcel] @fips = @fips 
--                                update addr.dbo.Deletefips set flag = 1  where id = @id 
--                        end try 
--                        begin catch 
--                                update addr.dbo.Deletefips  set flag = 2 where id = @id 
--                        end catch 
--                     end 
--        set @id += 1 
       
--end


