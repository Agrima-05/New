SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankMortgageSupLenderPost] (@tableName varchar(40)) -- @tableName = 'Mortgage_Sup_Lender' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild LenderFullStreetAddress and LenderCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Mortgage_Sup_Lender_STD]
	   --set [LenderFullMailAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailLeftDirection])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailStreetName]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailMode]))) + '' '' + [AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailRightDirection]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitNumber])))))))
       set [LenderFullMailAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailLeftDirection]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailStreetName])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailRightDirection])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitNumber]))))
	   ,[LenderMailHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailHouseNbr]))
 	   ,[LenderMailLeftDirection] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailLeftDirection]))
       ,[LenderMailStreetName] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailStreetName])))
       ,[LenderMailMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailMode])))
       ,[LenderMailRightDirection] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailRightDirection]))
       ,[LenderMailUnitNumber] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitNumber]))
       ,[LenderMailCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailCity])))
       ,[LenderMailState] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailState]))
       ,[LenderMailZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailZIP5]))
       ,[LenderMailZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailZIP4]))
  	   ,[LenderMailCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailCensusTract]))
       ,[LenderMailUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailUnitType])))
       ,[LenderMailDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailDPVCount]))
       ,[LenderMailDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailDPVFootnote]))
       ,[LenderMailLACS] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailLACS]))
       ,[LenderMailLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailLACSLinkInd]))
       ,[LenderMailDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailDPCheckDigit]))
       ,[LenderMailDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailDPCheckCode]))
       ,[LenderMailCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailCensusBlock]))
       ,[LenderMailGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailGeoErrorCode]))
       ,[LenderMailGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailGeoStatusCode]))
	   ,[LenderMailGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailGeoCodeResults]))
	   ,[LenderMailMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailMatchCode]))
	   ,[LenderMailCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Mortgage_Sup_Lender_STD].[LenderMailCarrierCode]))
     From [AddressSTD].[dbo].[Mortgage_Sup_Lender_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Mortgage_Sup_Lender_to_Licensing


