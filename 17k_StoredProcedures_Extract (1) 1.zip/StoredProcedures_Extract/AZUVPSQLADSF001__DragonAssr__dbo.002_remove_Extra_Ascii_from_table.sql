SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[002_remove_Extra_Ascii_from_table] @table varchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @colName VARCHAR(255)
	DECLARE @prec VARCHAR(255)
	DECLARE @sqlCmd VARCHAR(max)
	--DECLARE @Table varchar(100) = 'Dragon_Flank_Batch_ASSR'

	DECLARE db_cursor CURSOR FOR  

	SELECT c.name ColumnName
	FROM sys.columns c with(NOLOCK) INNER JOIN
		 sys.tables t with(NOLOCK) ON c.object_id = t.object_id INNER JOIN
		 sys.schemas s with(NOLOCK) ON t.schema_id = s.schema_id
	where t.name = @table 
	and c.System_type_id not in(40,42,48,52,56,61,62,104,106,108,127)
	--and c.Name >= 'Party3_Name1_last_Company_Name'
	order by ColumnName

	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @colName   

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		BEGIN
				EXEC('UPDATE DragonAssr.dbo.'+@table+' set ['+@colName+'] = data.dbo.RemoveNonASCII(['+@colName+'])
				WHERE ['+@colName+'] is not null AND
				((patindex(''%['' + char(0) + ''-'' + char(31) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0)
				OR (patindex(''%['' + char(127) + ''-'' + char(255) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0))')

				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''|'','''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%|%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''{'','''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%{%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''}'','''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%}%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(34),'''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%'' + char(34) + ''%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(39),'''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%'' + char(39) + ''%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(13),'''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%'' + char(13) + ''%''')
				
				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(10),'''')
				WHERE ['+@colName+'] is NOT NULL AND ['+@colName+'] LIKE ''%'' + char(10) + ''%''')

				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = NULL 
				WHERE ['+@colName+'] = ''*''')

				EXEC('update DragonAssr.dbo.'+@table+' set ['+@colName+'] = NULL 
				WHERE ['+@colName+'] is NOT NULL AND LTRIM(RTRIM(['+@colName+'])) LIKE ''NULL''')

		END
		FETCH NEXT FROM db_cursor INTO @colName
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

END

