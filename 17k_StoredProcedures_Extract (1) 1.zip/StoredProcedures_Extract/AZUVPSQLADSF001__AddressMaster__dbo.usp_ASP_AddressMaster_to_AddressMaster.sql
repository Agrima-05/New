SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_ASP_AddressMaster_to_AddressMaster]
AS
BEGIN

	DECLARE @Timestamp as datetime = CURRENT_TIMESTAMP
	SET CONCAT_NULL_YIELDS_NULL off

	UPDATE LIC
	SET 
	------LIC.[AddressLine] = SL.[AddressLine],
	------LIC.[CityStateZip] = SL.[CityStateZip],
	------LIC.[PreDir] = SL.[PreDir],
	------LIC.[StreetNumber] = SL.[StreetNumber],
	------LIC.[StreetName] = SL.[StreetName],
	------LIC.[PostDir] = SL.[PostDir],
	------LIC.[StreetType] = SL.[StreetType],
	------LIC.[SuiteType] = SL.[SuiteType],
	------LIC.[Suite] = SL.[Suite],
	------LIC.[City] = SL.[City],
	------LIC.[State] = SL.[State],
	------LIC.[Zip] = SL.[Zip],
	------LIC.[Plus4] = SL.[Plus4],
	------LIC.[PrivateMailbox] = SL.[PrivateMailbox],
	------LIC.[Pmsa] = SL.[Pmsa],
	------LIC.[Msa] = SL.[Msa],
	------LIC.[ZipType] = SL.[ZipType],
	------LIC.[Urbanization] = SL.[Urbanization],
	------LIC.[TimeZoneCode] = SL.[TimeZoneCode],
	------LIC.[TimeZone] = SL.[TimeZone],
	------LIC.[CongressionalDistrict] = SL.[CongressionalDistrict],
	------LIC.[CountryCode] = SL.[CountryCode],
	------LIC.[CountyFips] = SL.[CountyFips],
	------LIC.[CountyName] = SL.[CountyName],
	------LIC.[CityAbbreviation] = SL.[CityAbbreviation],
	------LIC.[AddressTypeString] = SL.[AddressTypeString],
	------LIC.[AddressTypeCode] = SL.[AddressTypeCode],
	------LIC.[DPVFootnotes] = SL.[DPVFootnotes],
	------------LIC.[CarrierRoute] = SL.[CarrierRoute],
	--LIC.[ELotOrder] = SL.[ELotOrder],
	--LIC.[ELotNumber] = SL.[ELotNumber],
	------LIC.[Lacs] = SL.[Lacs],
	------LIC.[LACSLinkIndicator] = SL.[LACSLinkIndicator],
	------LIC.[LACSLinkReturnCode] = SL.[LACSLinkReturnCode],
	------LIC.[EWSFlag] = SL.[EWSFlag],
	------LIC.[RBDI] = SL.[RBDI],
	------LIC.[SuiteLinkReturnCode] = SL.[SuiteLinkReturnCode],
	------LIC.[AddressMatchResults] = SL.[AddressMatchResults],
	--------LIC.[AddressMatchResultString] = SL.[AddressMatchResultString], -- Not in Melissa, see below.
	------LIC.[DeliveryPointCheckDigit] = SL.[DeliveryPointCheckDigit],
	------LIC.[DeliveryPointCode] = SL.[DeliveryPointCode],
	LIC.[Latitude] = SL.[Latitude], -- Don't over write the coalesce process
	LIC.[Longitude] = SL.[Longitude], -- Don't over write the coalesce process
	------LIC.[GeoErrorCode] = SL.[GeoErrorCode],
	------LIC.[GeoStatusCode] = SL.[GeoStatusCode],
	------LIC.[GeoCodeResults] = SL.[GeoCodeResults],
	------LIC.[CensusTract] = SL.[CensusTract],
	------LIC.[CensusBlock] = SL.[CensusBlock],
	------LIC.[PlaceCode] = SL.[PlaceCode],
	------LIC.[PlaceName] = SL.[PlaceName],
	------LIC.[CBSACode] = SL.[CBSACode],
	------LIC.[CBSALevel] = SL.[CBSALevel],
	------LIC.[CBSATitle] = SL.[CBSATitle],
	------LIC.[CBSADivisionCode] = SL.[CBSADivisionCode],
	------LIC.[CBSADivisionTitle] = SL.[CBSADivisionTitle],
	------LIC.[CBSADivisionLevel] = SL.[CBSADivisionLevel],
	------LIC.[CMRA] = SL.[CMRA],
	------LIC.[Verified] = SL.[Verified],
	------LIC.[Geocoded] = SL.[Geocoded],
	--------LIC.[DsfNoStats] = SL.[DsfNoStats], -- Not in Melissa and not needed for AM
	--------LIC.[DsfDNA] = SL.[DsfDNA], -- Not in Melissa and discontinued
	------LIC.[DPVCount] = SL.[DPVCount],
	LIC.[FAAddressParsed] = @Timestamp,
	LIC.[FATimestamp] = @Timestamp -- temporarly added to list
	------LIC.AddressMatchResultString = 
	-- select LIC.[AddressMasterID], SL.[RecordID], LIC.[AddressLine], SL.[AddressLine], LIC.[CityStateZip], SL.[CityStateZip], LIC.AddressMatchResultString, LIC.AddressMatchResults, SL.AddressMatchResults, LIC.[FAAddressParsed],
	 ------   LTRIM(CONCAT (CASE WHEN SL.AddressMatchResults like '%AC01%' THEN ' AC01:Postal Code Change. The postal code was changed or added.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC02%' THEN ' AC02:Administrative Area Change. The administrative area (state, province) was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC03%' THEN ' AC03:Locality Change. The locality (city, municipality) name was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC04%' THEN ' AC04:Alternate to Base Change. US Only. The address was found to be an alternate record and changed to the base (preferred) version.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC05%' THEN ' AC05:Alias Name Change. US Only. An alias is a common abbreviation for a long street name, such as “MLK Blvd” for “Martin Luther King Blvd.” This change code indicates that the full street name (preferred) has been substituted for the alias.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC06%' THEN ' AC06:Address1/Address2 Swap. Address1 was swapped with Address2 because Address1 could not be verified and Address2 could be verified.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC07%' THEN ' AC07:Address1 & Company Swapped. Address1 was swapped with Company because only Company had a valid address.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC08%' THEN ' AC08:Plus4 Change. US Only. A non-empty plus4 was changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC09%' THEN ' AC09:Dependent Locality Change. The dependent locality (urbanization) was changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC10%' THEN ' AC10:Thoroughfare Name Change. The thoroughfare (street) name was added or changed due to a spelling correction.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC11%' THEN ' AC11:Thoroughfare Type Change. The thoroughfare (street) leading or trailing type was added or changed, such as from "St" to "Rd.";' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC12%' THEN ' AC12:Thoroughfare Directional Change. The thoroughfare (street) pre-directional or post-directional was added or changed, such as from "N" to "NW.";' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC13%' THEN ' AC13:Sub Premise Type Change. The sub premise (suite) type was added or changed, such as from “STE” to “APT.”;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC14%' THEN ' AC14:Sub Premise Number Change. The sub premise (suite) unit number was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC15%' THEN ' AC15:Double Dependent Locality Change. The double dependent locality was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC16%' THEN ' AC16:SubAdministrative Area Change. The subadministrative area was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC17%' THEN ' AC17:SubNational Area Change. The subnational area was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC18%' THEN ' AC18:PO Box Change. The PO Box was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC19%' THEN ' AC19:Premise Type Change. The premise type was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC20%' THEN ' AC20:House Number Change. The house number was changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AC22%' THEN ' AC22:Organization Change. The organization was added or changed.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE01%' THEN ' AE01:Postal Code Error/General Error. The address could not be verified at least up to the postal code level.;' END  
  ------      , CASE WHEN SL.AddressMatchResults like '%AE02%' THEN ' AE02:Unknown Street. Could not match the input street to a unique street name. Either no matches or too many matches found.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE03%' THEN ' AE03:Component Mismatch Error. The combination of directionals (N, E, SW, etc) and the suffix (AVE, ST, BLVD) is not correct and produced multiple possible matches.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE04%' THEN ' AE04:Non-Deliverable Address. US Only. A physical plot exists but is not a deliverable addresses. One example might be a railroad track or river running alongside this street, as they would prevent construction of homes in that location.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE05%' THEN ' AE05:Multiple Matc. The address was matched to multiple records. There is not enough information available in the address to break the tie between multiple records.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE06%' THEN ' AE06:Early Warning System. US Only. This address currently cannot be verified but was identified by the Early Warning System (EWS) as belonging to a upcoming area and will likely be included in a future update.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE07%' THEN ' AE07:Missing Minimum Address. Minimum requirements for the address to be verified is not met. Address must have at least one address line and also the postal code or the locality/administrative area.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE08%' THEN ' AE08:Sub Premise Number Invalid. The thoroughfare (street address) was found but the sub premise (suite) was not valid.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE09%' THEN ' AE09:Sub Premise Number Missing. The thoroughfare (street address) was found but the sub premise (suite) was missing.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE10%' THEN ' AE10:Premise Number Invalid. The premise (house or building) number for the address is not valid.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE11%' THEN ' AE11:Premise Number Missing. The premise (house or building) number for the address is missing.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE12%' THEN ' AE12:Box Number Invalid. The PO (Post Office Box), RR (Rural Route), or HC (Highway Contract) Box number is invalid.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE13%' THEN ' AE13:Box Number Missing. The PO (Post Office Box), RR (Rural Route), or HC (Highway Contract) Box number is missing.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE14%' THEN ' AE14:PMB Number Missing. US Only. The address is a Commercial Mail Receiving Agency (CMRA) and the Private Mail Box (PMB or #) number is missing.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE15%' THEN ' AE15:Demo Mode. Limited to Demo Mode operation. Please contact a Melissa Data CSR at 1-800-800-6245 x4.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE16%' THEN ' AE16:Expired Database. The Database has expired. Please contact a Melissa Data CSR at 1-800-800-6245 x4.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE17%' THEN ' AE17:Sub Premise Not Required (Deprecated - See AS23). A sub premise (suite) number was entered but the address does not have secondaries. (Deprecated - See AS23);' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE19%' THEN ' AE19:Find Suggestion Timeout. The FindSuggestion function has exceeded the time limit.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE20%' THEN ' AE20:Find Suggestion Disabled. The FindSuggestion function is disabled. See the manual for further details.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AE21%' THEN ' AE21:Invalid MAK. The input MAK was invalid. This can be caused by: 1) MAK input requires Append Action Enabled. 2) Too many or too few digits. 3) Non-Numeric Characters detected. 4) MAK not found' END
		------, CASE WHEN SL.AddressMatchResults like '%AS01%' THEN ' AS01:Address Fully Verified. The address is valid and deliverable according to official postal agencies.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS02%' THEN ' AS02:Street Only Match. The street address was verified but the suite/apartment number is missing or invalid.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS03%' THEN ' AS03:Non USPS Address Match. US Only. This US address is not serviced by the USPS but does exist and may receive mail through third party carriers like UPS.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS09%' THEN ' AS09:Foreign Address. The address is in a non-supported country.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS10%' THEN ' AS10:CMRA Address. US Only. The address is a Commercial Mail Receiving Agency (CMRA) like a Mailboxes Etc. These addresses include a Private Mail Box (PMB or #) number.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS11%' THEN ' AS11:PBSA Address. A Post Office Box address with a street style address instead of the normal PO Box # address format.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS12%' THEN ' AS12:Record Move. The record moved to a new address.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS13%' THEN ' AS13:Address Updated By LACS. US Only. The address has been converted by LACSLink® from a rural-style address to a city-style address.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS14%' THEN ' AS14:Suite Appended. US Only. A suite was appended by SuiteLink™ using the address and company name.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS15%' THEN ' AS15:Apartment Appended. An apartment number was appended by AddressPlus using the address and last name.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS16%' THEN ' AS16:Vacant Address. US Only. The address has been unoccupied for more than 90 days.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS17%' THEN ' AS17:No Mail Delivery. US Only. The address does not currently receive mail but will likely in the near future.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS18%' THEN ' AS18:DPV Locked Out. US Only. DPV processing was terminated due to the detection of what is determined to be an artificially created address.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS20%' THEN ' AS20:Deliverable only by USPS. US Only. This address can only receive mail delivered through the USPS (i.e. PO Box or a military address).;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS22%' THEN ' AS22:No Alternate Address Suggestion Found. No alternate address suggestion was found for this address.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS23%' THEN ' AS23:Extraneous Information. Extraneous information not used in verifying the address was found. This includes unnecessary sub premises and other unrecognized data. Additional information will either be parsed into the Suite or Parsed Garbage/AddressExtras output.;' END
  ------      , CASE WHEN SL.AddressMatchResults like '%AS24%' THEN ' AS24:USPS Door Not Accessible. Address identified by the USPS where carriers cannot physically access a building or door for mail delivery.;' END))
	FROM [AddressMaster].[dbo].[Address_Master] LIC with (nolock) INNER JOIN [AddressMaster].[dbo].[AddressMaster_ASP_STD] SL with (nolock)
	ON LIC.[AddressMasterID] = SL.[RecordID]
	--where LIC.[AddressMasterID] = '106895326'	and SL.[RecordID]= '106895326'	
	
	SET CONCAT_NULL_YIELDS_NULL on
					
END
