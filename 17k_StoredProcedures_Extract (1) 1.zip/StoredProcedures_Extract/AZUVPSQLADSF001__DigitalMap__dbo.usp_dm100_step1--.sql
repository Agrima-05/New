SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		<Author, Gary Mathes>
-- Create date: <Create Date, 20170718>
-- Description:	<Description, DigitalMap ,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_dm100_step1--] @YYYYMMDD varchar(8)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	SET NOCOUNT ON;

	declare @sql varchar(max) = ''
	declare @tableName varchar(50)
	set @tableName = 'FADigitalMap_' + @YYYYMMDD
	
	--test with variables
    --declare @YYYYMMDD varchar(8) = '20170718'
	--declare @sql varchar(max) = ''
	--declare @tableName varchar(50) = 'FADigitalMap_' + @YYYYMMDD
	-- EXEC DigitalMap.dbo.usp_dm100_step1 '20170718'

	PRINT '0) ' + @YYYYMMDD + '.' + ' Initial setup steps'
    --USE DigitalMap
	--GO
	EXEC sp_rename 'Work', 'Work_20170913'
	EXEC sp_rename 'Parcel', 'Parcel_20170913'
	EXEC sp_rename 'ParcelPoint', 'ParcelPoint_20170913'
 	CREATE TABLE [dbo].[Work](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FileName] [nvarchar](250) NULL,
		[Fips] [nvarchar](50) NULL,
		[Ran] [bit] NULL,
		[ErrorCount] [int] NULL,
		[Count] [int] NULL,
		[Updated] [datetime] NULL,
		PRIMARY KEY (ID)
	) ON [PRIMARY]
	CREATE TABLE [dbo].[Parcel](
	    [PARCELAPN] [varchar](50) NULL,
	    [FIPS] [varchar](50) NULL,
	    [PRCLDMPID] [varchar](50) NOT NULL,
	    [GEOG] [geography] NULL,
	    [GEOM] [geometry] NULL,
	    [ID] [int] IDENTITY(1,1) NOT NULL,
		PRIMARY KEY (ID)
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	CREATE TABLE [dbo].[ParcelPoint](
		[PARCELAPN] [varchar](50) NULL,
		[FIPS] [varchar](50) NULL,
		[TAXAPN] [varchar](50) NULL,
		[STHSNUM] [varchar](50) NULL,
		[STDIR] [varchar](50) NULL,
		[STSTNAME] [varchar](50) NULL,
		[STSUFFIX] [varchar](50) NULL,
		[STQUADRANT] [varchar](50) NULL,
		[STUNITPRFX] [varchar](50) NULL,
		[STUNITNUM] [varchar](50) NULL,
		[STCITY] [varchar](50) NULL,
		[STSTATE] [varchar](50) NULL,
		[STZIP] [varchar](50) NULL,
		[STZIP4] [varchar](50) NULL,
		[XCOORD] [varchar](50) NULL,
		[YCOORD] [varchar](50) NULL,
		[GEOSOURCE] [varchar](50) NULL,
		[ADDRSCORE] [varchar](50) NULL,
		[PROPDMPID] [varchar](50) NULL,
		[GEOG] [geography] NULL,
		[GEOM] [geometry] NULL,
		[PropertyID] [bigint] NULL,
		[Match] [varchar](1) NULL
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	alter table DigitalMap.dbo.Work REBUILD WITH (DATA_COMPRESSION = PAGE);   
    alter table DigitalMap.dbo.Parcel REBUILD WITH (DATA_COMPRESSION = PAGE);   
    alter table DigitalMap.dbo.ParcelPoint REBUILD WITH (DATA_COMPRESSION = PAGE);   

/*
-- Step Run) 10.36.68.54
From this location: F:\Applications\DigitalMapLoaderPid\
DMImporter.exe \\snavpappadsf001.datatree.local\DriveF\DigitalMapFiles\DMP_DELIVERY_YYYYMMDD\ZIPS
*/

-- ALTER TABLE Work ADD CONSTRAINT pk_Work_ID PRIMARY KEY(ID) -- done
-- ALTER TABLE Parcel ADD CONSTRAINT pk_Parcel_ID PRIMARY KEY(ID)

	PRINT '1) ' + @YYYYMMDD + '.'
	-- drop and populate list of FIPS for this quarter's load
	IF EXISTS(SELECT * FROM DigitalMap.dbo.FIPS) DROP TABLE DigitalMap.dbo.FIPS 
	SELECT FIPS INTO DigitalMap.dbo.FIPS FROM DigitalMap.dbo.Work group by FIPS order by FIPS


	PRINT '2) Archiving Property data.'
	-- archive property data that will be replaced.
	/* temp commented out
	INSERT Data_Archive.dbo.Property_DM (
		FIPS,
		PropertyID,
		FormattedAPN,
		FADateReceived,
		FALatitude,
		FALongitude,
		FAEstLotSqFt,
		FAGeoStatusCode,
		FADM_Data_Archive)
	SELECT 
		P.FIPS,
		P.PropertyID,
		P.FormattedAPN,
		P.FADateReceived,
		P.FALatitude,
		P.FALongitude,
		P.FAEstLotSqFt,
		P.FAGeoStatusCode,
		CONVERT(VARCHAR(8), getdate(), 112)
	FROM Data.dbo.Property P WITH (NOLOCK)
	JOIN DigitalMap.dbo.FIPS F WITH (NOLOCK)
	ON P.FIPS = F.FIPS -- 60787182
	*/


	PRINT '3) Creating table [DigitalMap].[dbo].['+@tableName+'].'
    -- create FADigitalMap table for this quarterly load
	set @sql = 'select * INTO [DigitalMap].[dbo].['+@tableName+'] FROM DigitalMap.dbo.FADigitalMap where 1 = 2'
	exec(@sql)
	-- select * INTO [DigitalMap].[dbo].FADigitalMap_20170913 FROM DigitalMap.dbo.FADigitalMap where 1 = 2  
	set @sql = 'alter table [DigitalMap].[dbo].['+@tableName+'] rebuild with (DATA_COMPRESSION = PAGE)'
 	exec(@sql) 
	-- alter table [DigitalMap].[dbo].[FADigitalMap_20170913] rebuild with (DATA_COMPRESSION = PAGE)


	PRINT '4) Load ParcelPoint.'
    -- 2.b) Load all data by merging the Parcel and ParcelPoint by Fips and PARCEL_APN together from the Parcel and ParcelPoint table. Table name FAdigitalMap_YYYYMMDD
    set @sql = 'INSERT [DigitalMap].[dbo].['+@tableName+'] ( 
        -- DM.PropertyID
        DM.APN
        ,DM.FIPS
        ,DM.Longitude
        ,DM.Latitude
        ,DM.ParcelGeography
        ,DM.ParcelGeometry
        ,DM.ParcelPointGeography
        ,DM.ParcelPointGeometry
        ,DM.AddressScore
        ,DM.GeoSource
        ,DM.PARCELAPN
        ,DM.FAGeoStatusCode
        ,DM.DmDate
        ,DM.PROPDMPID
        )
        SELECT
        -- DM.PropertyID = PM.FAPropertyParent
        PP.TAXAPN    -- APN
        ,PP.FIPS      -- FIPS
        ,PP.XCOORD    -- Longitude 
        ,PP.YCOORD    -- Latitude
        ,NULL         -- P.GEOG -- ParcelGeography
        ,NULL         -- P.GEOM -- ParcelGeometry
        ,PP.GEOG      -- ParcelPointGeography
        ,PP.GEOM      -- ParcelPointGeometry
        ,PP.ADDRSCORE -- AddressScore
        ,PP.GEOSOURCE -- GeoSource
        ,PP.PARCELAPN -- P.PARCELAPN
        ,''P''          -- FAGeoStatusCode
        ,'''+@YYYYMMDD+'''   -- DmDate
        ,PP.PROPDMPID -- ParcelPoint PID
        FROM DigitalMap.dbo.ParcelPoint PP WITH (NOLOCK)'
    PRINT @sql --exec(@sql) 

	INSERT DigitalMap.dbo.FADigitalMap_20170913 ( 
   -- DM.PropertyID
    DM.APN
   ,DM.FIPS
   ,DM.Longitude
   ,DM.Latitude
   ,DM.ParcelGeography
   ,DM.ParcelGeometry
   ,DM.ParcelPointGeography
   ,DM.ParcelPointGeometry
   ,DM.AddressScore
   ,DM.GeoSource
   ,DM.PARCELAPN
   ,DM.FAGeoStatusCode
   ,DM.DmDate
   ,DM.PROPDMPID
   )
SELECT
   -- DM.PropertyID = PM.FAPropertyParent
    PP.TAXAPN    -- APN
   ,PP.FIPS      -- FIPS
   ,PP.XCOORD    -- Longitude 
   ,PP.YCOORD    -- Latitude
   ,NULL         -- P.GEOG       -- ParcelGeography
   ,NULL         -- P.GEOM       -- ParcelGeometry
   ,PP.GEOG      -- ParcelPointGeography
   ,PP.GEOM      -- ParcelPointGeometry
   ,PP.ADDRSCORE -- AddressScore
   ,PP.GEOSOURCE -- GeoSource
   ,PP.PARCELAPN -- P.PARCELAPN
   ,'P'          -- FAGeoStatusCode
   ,'20170913'   -- DmDate
   ,PP.PROPDMPID -- ParcelPoint PID
FROM DigitalMap.dbo.ParcelPoint PP WITH (NOLOCK) -- 60853755



	PRINT '5) Build Indexes.'
    -- indexes
	set @sql = 'CREATE NONCLUSTERED INDEX IX_FADigitalMap_FIPS ON [DigitalMap].[dbo].['+@tableName+'] (FIPS)'
	PRINT @sql --exec(@sql) 
    set @sql = 'CREATE CLUSTERED INDEX CIX_FADigitalMap_FIPS_APN ON [DigitalMap].[dbo].['+@tableName+'] (FIPS, APN)'
	PRINT @sql --exec(@sql) 
    set @sql = 'CREATE NONCLUSTERED INDEX IX_FADigitalMap_FIPS_PARCELAPN ON [DigitalMap].[dbo].['+@tableName+'] (FIPS, PARCELAPN)'
	PRINT @sql --exec(@sql) 
    set @sql = 'CREATE NONCLUSTERED INDEX IX_FADigitalMap_MatchCode ON [DigitalMap].[dbo].['+@tableName+'] (MatchCode)'
	PRINT @sql --exec(@sql) 
    set @sql = 'CREATE NONCLUSTERED INDEX IX_Parcel_FIPS_PARCELAPN ON [DigitalMap].[dbo].[Parcel] (FIPS, PARCELAPN)'
	PRINT @sql --exec(@sql) 
/*
CREATE NONCLUSTERED INDEX IX_FADigitalMap_FIPS ON DigitalMap.dbo.FADigitalMap_20170913 (FIPS)
CREATE CLUSTERED INDEX CIX_FADigitalMap_FIPS_APN ON DigitalMap.dbo.FADigitalMap_20170913 (FIPS, APN)
CREATE NONCLUSTERED INDEX IX_FADigitalMap_FIPS_PARCELAPN ON DigitalMap.dbo.FADigitalMap_20170913 (FIPS, PARCELAPN)
CREATE NONCLUSTERED INDEX IX_FADigitalMap_MatchCode ON DigitalMap.dbo.FADigitalMap_20170913 (MatchCode)
CREATE NONCLUSTERED INDEX IX_Parcel_FIPS_PARCELAPN ON DigitalMap.dbo.Parcel (FIPS, PARCELAPN)
*/


    PRINT '6) Update/Load Parcel.'
	-- Load Parcel data
	set @sql = 'UPDATE DM set DM.ParcelGeography = P.GEOG, DM.ParcelGeometry = P.GEOM 
	            FROM DigitalMap.dbo.Parcel P WITH (NOLOCK), [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK) 
				WHERE P.FIPS = DM.FIPS and P.PARCELAPN = DM.PARCELAPN AND LEN(rtrim(ltrim(P.PARCELAPN))) > 0 AND LEN(rtrim(ltrim(DM.PARCELAPN))) > 0'
	PRINT @sql --exec(@sql) 

/*
-- Load Parcel data
UPDATE DM set DM.ParcelGeography = P.GEOG, DM.ParcelGeometry = P.GEOM 
FROM DigitalMap.dbo.Parcel P WITH (NOLOCK), DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
WHERE P.FIPS = DM.FIPS and P.PARCELAPN = DM.PARCELAPN AND LEN(rtrim(ltrim(P.PARCELAPN))) > 0 AND LEN(rtrim(ltrim(DM.PARCELAPN))) > 0 -- 55589295
*/

    PRINT '7) Update/Load Parcel.'
    --2.c) Load the left over from both Parcel data.
    set @sql = 'INSERT [DigitalMap].[dbo].['+@tableName+'] (
        PARCELAPN
       ,FIPS
       ,ParcelGeography
       ,ParcelGeometry
       ,FAGeoStatusCode
       ,DmDate
       ,PRCLDMPID         -- Parcel PID
        )
    SELECT
        P.PARCELAPN       -- PARCELAPN
       ,P.FIPS            -- FIPS
       ,P.GEOG            -- GEOG
       ,P.GEOM            -- GEOM
       ,''P''             -- FAGeoStatusCode
       ,'''+@YYYYMMDD+''' -- DmDate
       ,P.PRCLDMPID       -- Parcel PID
    FROM DigitalMap.dbo.Parcel P WITH (NOLOCK)
    WHERE LEN(rtrim(ltrim(P.PARCELAPN))) < 1' 
	PRINT @sql --exec(@sql) 

/*
INSERT DigitalMap.dbo.FADigitalMap_20170913 (
    PARCELAPN
   ,FIPS
   ,ParcelGeography
   ,ParcelGeometry
   ,FAGeoStatusCode
   ,DmDate
   ,PRCLDMPID -- Parcel PID
   )
SELECT
    P.PARCELAPN -- PARCELAPN
   ,P.FIPS      -- FIPS
   ,P.GEOG      -- GEOG
   ,P.GEOM      -- GEOM
   ,'P'         -- FAGeoStatusCode
   ,'20170913'  -- DmDate
   ,P.PRCLDMPID -- Parcel PID
FROM DigitalMap.dbo.Parcel P WITH (NOLOCK)
WHERE LEN(rtrim(ltrim(P.PARCELAPN))) < 1 -- 582023
*/

	PRINT '8) Calculate EstLotSizeSqFt field.'
    set @sql = 'UPDATE DM set DM.EstLotSizeSqFt = cast(ParcelGeography.STArea() * 10.7639104 as bigint)
                FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)'
	PRINT @sql --exec(@sql) 
/*
UPDATE DM set DM.EstLotSizeSqFt = cast(ParcelGeography.STArea() * 10.7639104 as bigint)
FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK) -- 61435778
*/

	PRINT '9) Set MatchCodes 1 through 6.'
    -- 2.d) Match records to get PropertyId from Global.dbo.PropertyMaster.
    set @sql = 'UPDATE DM
    SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''1''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.APN = PM.FormattedAPN 
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
    set @sql = 'UPDATE DM
    SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''2''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.FormattedAPN 
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
    set @sql = 'UPDATE DM
    SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''3''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.APN = PM.APN 
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
    set @sql = 'UPDATE DM
        SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''4''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.APN 
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
    set @sql = 'UPDATE DM
        SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''5''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.APN = PM.OldAPN 
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
    set @sql = 'UPDATE DM
        SET DM.PropertyID = PM.FAPropertyParent,
        DM.MatchCode = ''6''
        -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
        FROM [DigitalMap].[dbo].['+@tableName+'] DM WITH (NOLOCK)
        JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
        ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.OldAPN
        WHERE DM.MatchCode is null'
	    PRINT @sql --exec(@sql) 
/*
UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '1'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.APN = PM.FormattedAPN 
   WHERE DM.MatchCode is null -- 60824309

UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '2'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.FormattedAPN 
   WHERE DM.MatchCode is null -- 0

UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '3'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.APN = PM.APN 
   WHERE DM.MatchCode is null -- 1

UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '4'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.APN 
   WHERE DM.MatchCode is null -- 0

UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '5'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.APN = PM.OldAPN 
   WHERE DM.MatchCode is null -- 27714

UPDATE DM
   SET DM.PropertyID = PM.FAPropertyParent,
       DM.MatchCode = '6'
   -- SELECT top 100 DM.FIPS, PM.FIPS, DM.APN, PM.FormattedAPN, DM.PropertyID, PM.FAPropertyParent
   FROM DigitalMap.dbo.FADigitalMap_20170913 DM WITH (NOLOCK)
   JOIN Global.dbo.Property_Master PM WITH (NOLOCK)
   ON DM.FIPS = PM.FIPS AND DM.PARCELAPN = PM.OldAPN
   WHERE DM.MatchCode is null -- 0
*/


	PRINT '10) Counts.'
	-- Import counts.
    set @sql = 'select count(*) from DigitalMap.dbo.Parcel with (nolock) -- Parcel rows'
	    PRINT @sql --exec(@sql)
    set @sql = 'select count(*) from DigitalMap.dbo.ParcelPoint with (nolock) -- ParcelPoint rows'
	    PRINT @sql --exec(@sql)
    set @sql = 'select count(*) from DigitalMap.dbo.Work with (nolock) -- Work rows'
	    PRINT @sql --exec(@sql)
    set @sql = 'select count(distinct fips) from DigitalMap.dbo.Work with (nolock) -- Counties'
	    PRINT @sql --exec(@sql)
	-- MatchCode counts
    set @sql = 'select count(*) Total_'+@YYYYMMDD+' from [DigitalMap].[dbo].[FADigitalMap] with (nolock) where DmDate = '''+@YYYYMMDD+''''
	    PRINT @sql --exec(@sql) 
    set @sql = 'select count(*) MatchCode_1_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''1'''
	    PRINT @sql --exec(@sql) 
    set @sql = 'select count(*) MatchCode_2_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''2'''
	    PRINT @sql --exec(@sql)     
	set @sql = 'select count(*) MatchCode_3_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''3'''
	    PRINT @sql --exec(@sql) 
	set @sql = 'select count(*) MatchCode_4_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''4'''
	    PRINT @sql --exec(@sql)     
	set @sql = 'select count(*) MatchCode_5_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''5'''
	    PRINT @sql --exec(@sql)     
	set @sql = 'select count(*) MatchCode_6_'+@YYYYMMDD+' from [DigitalMap].[dbo].['+@tableName+'] with (nolock) where DmDate = '''+@YYYYMMDD+''' and MatchCode = ''6'''
	    PRINT @sql --exec(@sql) 
	-- Hazard counts
	SELECT * FROM DigitalMap.dbo.FIPS
	    WHERE FIPS IN ('06011', '06021', '06027', '06035', '06043', '06049', '06063', '06079', '06093', '06103', '06107')
        ORDER BY FIPS


	PRINT '11) First number divided by second number.'
    -- county counts and match rate
    set @sql = 'SELECT count(*)
	    FROM Data.dbo.Property AS P with (nolock)
	    INNER JOIN [DigitalMap].[dbo].['+@tableName+'] DM with (nolock)
	    ON DM.PropertyID = P.PropertyId AND DM.Fips = P.FIPS
	    WHERE DM.Latitude IS NOT NULL AND DM.Longitude IS NOT NULL'
	    PRINT @sql --exec(@sql) 
        -- divided by
    set @sql = 'select count (*) FROM [DigitalMap].[dbo].['+@tableName+']'
	    PRINT @sql --exec(@sql) 
        -- ??.??%


	PRINT '12) Update FADigitalMap with Property data.'
    -- 2.e) Update existing FADigitalMap and Property data. Update records with Tax Apn
    set @sql = 'Update o set 
        o.[PropertyID] = n.[PropertyID]      
        ,o.[Longitude] = n.[Longitude]
        ,o.[Latitude] = n.[Latitude]
        ,o.[ParcelGeography] = n.[ParcelGeography]
        ,o.[ParcelGeometry] = n.[ParcelGeometry]
        ,o.[ParcelPointGeography] = n.[ParcelPointGeography]
        ,o.[ParcelPointGeometry] = n.[ParcelPointGeometry]
        ,o.[EstLotSizeSqFt] = n.[EstLotSizeSqFt]
        ,o.[AddressScore] = n.[AddressScore]
        ,o.[GeoSource] = n.[GeoSource]
        ,o.[PARCELAPN] = n.[PARCELAPN]
        ,o.[FAGeoStatusCode] = n.[FAGeoStatusCode]
        ,o.[LatLonGeometry] = n.[LatLonGeometry]      
        ,o.[DmDate] = n.[DmDate]
        ,o.[PRCLDMPID] = n.[PRCLDMPID]
        ,o.[PROPDMPID] = n.[PROPDMPID]
        from [DigitalMap].[dbo].['+@tableName+'] n 
        inner join [DigitalMap].[dbo].FADigitalMap o 
        on n.Fips = o.Fips and o.APN = n.APN and n.UpdateFlag is null'
	    PRINT @sql --exec(@sql) 

--Update records with Tax Apn
/*
Update o set 
       o.[PropertyID] = n.[PropertyID]      
      ,o.[Longitude] = n.[Longitude]
      ,o.[Latitude] = n.[Latitude]
      ,o.[ParcelGeography] = n.[ParcelGeography]
      ,o.[ParcelGeometry] = n.[ParcelGeometry]
      ,o.[ParcelPointGeography] = n.[ParcelPointGeography]
      ,o.[ParcelPointGeometry] = n.[ParcelPointGeometry]
      ,o.[EstLotSizeSqFt] = n.[EstLotSizeSqFt]
      ,o.[AddressScore] = n.[AddressScore]
      ,o.[GeoSource] = n.[GeoSource]
      ,o.[PARCELAPN] = n.[PARCELAPN]
      ,o.[FAGeoStatusCode] = n.[FAGeoStatusCode]
      ,o.[LatLonGeometry] = n.[LatLonGeometry]      
      ,o.[DmDate] = n.[DmDate]
      ,o.[PRCLDMPID] = n.[PRCLDMPID]
      ,o.[PROPDMPID] = n.[PROPDMPID]
from [DigitalMap].[dbo].FADigitalMap_20170913 n 
inner join [DigitalMap].[dbo].FADigitalMapMaster o 
on n.Fips = o.Fips and o.APN = n.APN and n.UpdateFlag is null
-- 59503821
*/

    set @sql = 'Update n set 
        n.UpdateFlag = ''TAXAPN''
        from [DigitalMap].[dbo].['+@tableName+'] n 
        inner join [DigitalMap].[dbo].FADigitalMap o
        on n.Fips = o.Fips and o.APN = n.APN and n.UpdateFlag is null'
	    PRINT @sql --exec(@sql) 

/*
Update n set 
       n.UpdateFlag = 'TAXAPN'
from [DigitalMap].[dbo].FADigitalMap_20170913 n 
inner join [DigitalMap].[dbo].FADigitalMapMaster o
on n.Fips = o.Fips and o.APN = n.APN and n.UpdateFlag is null
-- 59577991
*/

	PRINT '13) Insert remaining points.'
    --Insert remaining Points
    set @sql = 'insert into [DigitalMap].[dbo].FADigitalMap (
        [PropertyID] 
        ,[APN]
        ,[Fips]          
        ,[Longitude]
        ,[Latitude]
        ,[ParcelGeography]
        ,[ParcelGeometry]
        ,[ParcelPointGeography]
        ,[ParcelPointGeometry]
        ,[EstLotSizeSqFt]
        ,[AddressScore]
        ,[GeoSource]
        ,[PARCELAPN]
        ,[FAGeoStatusCode]
        ,[LatLonGeometry]
        ,[DmDate]
        ,[PRCLDMPID]
        ,[PROPDMPID])
        select
        n.[PropertyID] 
        ,n.[APN]
        ,n.[Fips]          
        ,n.[Longitude]
        ,n.[Latitude]
        ,n.[ParcelGeography]
        ,n.[ParcelGeometry]
        ,n.[ParcelPointGeography]
        ,n.[ParcelPointGeometry]
        ,n.[EstLotSizeSqFt]
        ,n.[AddressScore]
        ,n.[GeoSource]
        ,n.[PARCELAPN]
        ,n.[FAGeoStatusCode]
        ,n.[LatLonGeometry]
        ,n.[DmDate]
        ,n.[PRCLDMPID]
        ,n.[PROPDMPID]
        from [DigitalMap].[dbo].['+@tableName+'] n with(nolock) 
        where n.UpdateFlag is null and APN is not null'
	    PRINT @sql --exec(@sql) 

/*
insert into [DigitalMap].[dbo].FADigitalMapMaster (
       [PropertyID] 
      ,[APN]
      ,[Fips]          
      ,[Longitude]
      ,[Latitude]
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN]
      ,[FAGeoStatusCode]
      ,[LatLonGeometry]
      ,[DmDate]
      ,[PRCLDMPID]
      ,[PROPDMPID])
select
       n.[PropertyID] 
      ,n.[APN]
      ,n.[Fips]          
      ,n.[Longitude]
      ,n.[Latitude]
      ,n.[ParcelGeography]
      ,n.[ParcelGeometry]
      ,n.[ParcelPointGeography]
      ,n.[ParcelPointGeometry]
      ,n.[EstLotSizeSqFt]
      ,n.[AddressScore]
      ,n.[GeoSource]
      ,n.[PARCELAPN]
      ,n.[FAGeoStatusCode]
      ,n.[LatLonGeometry]
      ,n.[DmDate]
      ,n.[PRCLDMPID]
      ,n.[PROPDMPID]
from [DigitalMap].[dbo].FADigitalMap_20170913 n with(nolock) 
where n.UpdateFlag is null and APN is not null
-- 1275764
*/

    set @sql = 'Update n set 
        n.UpdateFlag = ''INSERT_PP''
        from [DigitalMap].[dbo].['+@tableName+'] n 
        where n.UpdateFlag is null and APN is not null'
	    PRINT @sql --exec(@sql) 
/*
Update n set 
       n.UpdateFlag = 'INSERT_PP'
from [DigitalMap].[dbo].FADigitalMap_20170913 n 
where n.UpdateFlag is null and APN is not null
-- 1275764
*/

	PRINT '14) Update records with Parcel APN.'
    --Update records with Parcel Apn (has Parcel but no Point)
    set @sql = 'Update o set 
        o.[PropertyID] = n.[PropertyID]           
        ,o.[Longitude] = n.[Longitude]
        ,o.[Latitude] = n.[Latitude]
        ,o.[ParcelGeography] = n.[ParcelGeography]
        ,o.[ParcelGeometry] = n.[ParcelGeometry]
        ,o.[ParcelPointGeography] = n.[ParcelPointGeography]
        ,o.[ParcelPointGeometry] = n.[ParcelPointGeometry]
        ,o.[EstLotSizeSqFt] = n.[EstLotSizeSqFt]
        ,o.[AddressScore] = n.[AddressScore]
        ,o.[GeoSource] = n.[GeoSource]
        ,o.[PARCELAPN] = n.[PARCELAPN]
        ,o.[FAGeoStatusCode] = n.[FAGeoStatusCode]
        ,o.[LatLonGeometry] = n.[LatLonGeometry]      
        ,o.[DmDate] = n.[DmDate]
        ,o.[PRCLDMPID] = n.[PRCLDMPID]
        ,o.[PROPDMPID] = n.[PROPDMPID]
        from [DigitalMap].[dbo].['+@tableName+'] n with(nolock) 
        inner join [DigitalMap].[dbo].FADigitalMap o 
        on n.Fips = o.Fips and o.PARCELAPN = n.PARCELAPN and o.PARCELAPN <> '' and o.APN is null and n.UpdateFlag is null'
	    PRINT @sql --exec(@sql) 

/*
Update o set 
       o.[PropertyID] = n.[PropertyID]           
      ,o.[Longitude] = n.[Longitude]
      ,o.[Latitude] = n.[Latitude]
      ,o.[ParcelGeography] = n.[ParcelGeography]
      ,o.[ParcelGeometry] = n.[ParcelGeometry]
      ,o.[ParcelPointGeography] = n.[ParcelPointGeography]
      ,o.[ParcelPointGeometry] = n.[ParcelPointGeometry]
      ,o.[EstLotSizeSqFt] = n.[EstLotSizeSqFt]
      ,o.[AddressScore] = n.[AddressScore]
      ,o.[GeoSource] = n.[GeoSource]
      ,o.[PARCELAPN] = n.[PARCELAPN]
      ,o.[FAGeoStatusCode] = n.[FAGeoStatusCode]
      ,o.[LatLonGeometry] = n.[LatLonGeometry]      
      ,o.[DmDate] = n.[DmDate]
      ,o.[PRCLDMPID] = n.[PRCLDMPID]
      ,o.[PROPDMPID] = n.[PROPDMPID]
from [DigitalMap].[dbo].FADigitalMap_20170913 n with(nolock) 
inner join [DigitalMap].[dbo].FADigitalMapMaster o 
on n.Fips = o.Fips and o.PARCELAPN = n.PARCELAPN and o.PARCELAPN <> '' and o.APN is null and n.UpdateFlag is null
-- 0
*/

    set @sql = 'Update n set 
        n.UpdateFlag = ''PARCELAPN''
        from [DigitalMap].[dbo].['+@tableName+'] n with(nolock) 
		inner join [DigitalMap].[dbo].FADigitalMap o 
        on n.Fips = o.Fips and o.PARCELAPN = n.PARCELAPN and o.PARCELAPN <> '' and o.APN is null and n.UpdateFlag is null'
	    PRINT @sql --exec(@sql) 

/*
Update n set 
       n.UpdateFlag = 'PARCELAPN'
from 
  [DigitalMap].[dbo].FADigitalMap_20170913 n with(nolock) inner join 
  [DigitalMap].[dbo].FADigitalMapMaster o 
  on n.Fips = o.Fips and o.PARCELAPN = n.PARCELAPN and o.PARCELAPN <> '' and o.APN is null and n.UpdateFlag is null
  -- 0
*/

    set @sql = 'UPDATE P -- reload DitigalMap county data in Property
	    SET P.FALatitude = DM.Latitude
	    ,P.FALongitude = DM.Longitude
	    ,P.FAGeoStatusCode = DM.FAGeoStatusCode
	    ,P.FAEstLotSqFt = DM.EstLotSizeSqFt
        -- SELECT top 1000 P.PropertyId, DM.PropertyID, P.FIPS, DM.FIPS, P.FALatitude, DM.Latitude, P.FALongitude, DM.Longitude, P.FAEstLotSqFt, DM.EstLotSizeSqFt
	    -- SELECT count(*)
	    FROM Data.dbo.Property AS P (nolock)
	    INNER JOIN [DigitalMap].[dbo].['+@tableName+'] DM (nolock)
	    ON DM.PropertyID = P.PropertyId AND DM.Fips = P.FIPS
	    WHERE DM.Latitude IS NOT NULL AND DM.Longitude IS NOT NULL'
	    PRINT @sql --exec(@sql)

/*
UPDATE P -- reload DitigalMap county data in Property
	SET P.FALatitude = DM.Latitude
	   ,P.FALongitude = DM.Longitude
	   ,P.FAGeoStatusCode = DM.FAGeoStatusCode
	   ,P.FAEstLotSqFt = DM.EstLotSizeSqFt
      -- SELECT top 1000 P.PropertyId, DM.PropertyID, P.FIPS, DM.FIPS, P.FALatitude, DM.Latitude, P.FALongitude, DM.Longitude, P.FAEstLotSqFt, DM.EstLotSizeSqFt
	  -- SELECT count(*)
	FROM Data.dbo.Property AS P (nolock)
	INNER JOIN DigitalMap.dbo.FADigitalMap_20170913 DM (nolock)
	ON DM.PropertyID = P.PropertyId AND DM.Fips = P.FIPS
	WHERE DM.Latitude IS NOT NULL AND DM.Longitude IS NOT NULL
	-- 60354881
*/

END


select count(*) from DigitalMap.dbo.Parcel with (nolock) -- Parcel rows
select count(*) from DigitalMap.dbo.ParcelPoint with (nolock) -- ParcelPoint rows
select count(*) from DigitalMap.dbo.Work with (nolock) -- Work rows
select count(distinct fips) from DigitalMap.dbo.Work with (nolock) -- Counties
select count(*) FROM Data.dbo.Property AS P with (nolock) -- Match Rate
    INNER JOIN DigitalMap.dbo.FADigitalMap_20170913 DM with (nolock)
    ON DM.PropertyID = P.PropertyId AND DM.Fips = P.FIPS
    WHERE DM.Latitude IS NOT NULL AND DM.Longitude IS NOT NULL
    -- divided by
select count (*) FROM DigitalMap.dbo.FADigitalMap_20170913 -- ??.??%

select count(*) Total_YYYYMMDD from DigitalMap.dbo.FADigitalMap with (nolock) where DmDate = '20170913'
select count(*) MatchCode_1_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '1'
select count(*) MatchCode_2_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '2'
select count(*) MatchCode_3_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '3'
select count(*) MatchCode_4_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '4'
select count(*) MatchCode_5_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '5'
select count(*) MatchCode_6_YYYYMMDD from DigitalMap.dbo.FADigitalMap_20170913 with (nolock) where DmDate = '20170913'and MatchCode = '6'

