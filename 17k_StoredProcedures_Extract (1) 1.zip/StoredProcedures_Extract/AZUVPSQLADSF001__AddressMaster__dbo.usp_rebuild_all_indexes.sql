SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_rebuild_all_indexes]

AS
BEGIN
	ALTER INDEX [ix_property_id] ON [Address_Master] REBUILD 
	ALTER INDEX [ix_Zip] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_AddressMatchResults] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_CountyFips_FATimeStamp] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_FAAddressParser_FAUCIDFlag] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_FAUCIDFlag_FATimestamp] ON [Address_Master] REBUILD 
	ALTER INDEX [ix_FipsPropIDwLatLong] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_CountyFips_PropertyID] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_CountyFips_AddressLine] ON [Address_Master] REBUILD 
	ALTER INDEX [ix_Unit] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [ix_StName] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [IDX_CountyFips_LatLong] ON [Address_Master] REBUILD 
	ALTER INDEX [ix_FIPS] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [ix_HseNbr] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [ix_Zip] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [idx_ID] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [ix_Zip9] ON [a_PropMatch_Work_FLANK] REBUILD 
	ALTER INDEX [IDX_AddressMasterID] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_CountyFips_AddressHash] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_CountyFips] ON [Address_Master] REBUILD 
	ALTER INDEX [IDX_FAUCIDFlag] ON [Address_Master] REBUILD 
	ALTER INDEX [NonClusteredUniqueIndex-Address_Master_AddressHash] ON [Address_Master] REBUILD 
	ALTER INDEX [IX_AM_del_PropertyId] ON [Address_Master_del] REBUILD 
	ALTER INDEX [ix_AM_CountyFips] ON [Address_Master_del] REBUILD 
	ALTER INDEX [IDX_Fips_PropertyID] ON [Address_Master_TempFAFlood] REBUILD 
	ALTER INDEX [IDX_Fips] ON [Address_Master_TempFAFlood] REBUILD 
	ALTER INDEX [IDX_FATimeStamp] ON [Address_Master_TempFAFlood] REBUILD 
	ALTER INDEX [IDX_Fips_PropertyID] ON [Address_Master_TempProperty] REBUILD 
	ALTER INDEX [IDX_Fips] ON [Address_Master_TempProperty] REBUILD 
	ALTER INDEX [IDX_FATimestamp] ON [Address_Master_TempProperty] REBUILD 
END

