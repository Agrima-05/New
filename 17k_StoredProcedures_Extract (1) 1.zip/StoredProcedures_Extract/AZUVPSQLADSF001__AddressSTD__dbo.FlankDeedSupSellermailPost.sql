SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankDeedSupSellermailPost] (@tableName varchar(40)) -- @tableName = 'Deed_Sup_Sellermail' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild SellermailFullStreetAddress and SellermailCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Deed_Sup_Sellermail_STD]
	   --set [SellerMailFullAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailLeftDirection])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailStreetName]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailMode]))) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailRightDirection]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitNumber])))))))
       set [SellerMailFullAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailHouseNbr])) + '' '' + [AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailLeftDirection]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailStreetName])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailRightDirection])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitNumber]))))
	   ,[SellerMailHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailHouseNbr]))
       ,[SellerMailLeftDirection] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailLeftDirection]))
       ,[SellerMailStreetName] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailStreetName])))
       ,[SellerMailMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailMode])))
       ,[SellerMailRightDirection] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailRightDirection]))
       ,[SellerMailUnitNumber] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitNumber]))
       ,[SellerMailCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailCity])))
       ,[SellerMailState] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailState]))
       ,[SellerMailZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailZIP5]))
       ,[SellerMailZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailZIP4]))
       ,[SellerMailCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailCarrierCode]))
	   ,[SellerMailCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailCensusTract]))
       ,[SellerMailUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailUnitType])))
       ,[SellerMailDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailDPVCount]))
       ,[SellerMailDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailDPVFootnote]))
       ,[SellerMailLACS] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailLACS]))
       ,[SellerMailLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailLACSLinkInd]))
       ,[SellerMailDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailDPCheckDigit]))
       ,[SellerMailDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailDPCheckCode]))
       ,[SellerMailCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailCensusBlock]))
	   ,[SellerMailStdMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sellermail_STD].[SellerMailStdMatchCode]))
       ,[SellerMailGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailGeoErrorCode]))
       ,[SellerMailGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailGeoStatusCode]))
       ,[SellerMailGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Deed_Sup_Sellermail_STD].[SellerMailGeoCodeResults]))
     From [AddressSTD].[dbo].[Deed_Sup_Sellermail_STD]
     '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Deed_Sup_Sellermail_to_Licensing

