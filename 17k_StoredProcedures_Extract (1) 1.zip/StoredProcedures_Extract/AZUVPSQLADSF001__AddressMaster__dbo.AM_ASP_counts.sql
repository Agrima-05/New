SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[AM_ASP_counts] -- add @table default all tables
as  
BEGIN

-- minimum ASP dates
set nocount on
select min(FAAddressParsed) as FAAddressParsed_min_date from AddressMaster.dbo.Address_Master with (nolock) where FAUCIDFlag != 'D' -- 2019-07-18 13:19:08.497
set nocount off 

-- check lastest updates
select top 100 * from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed > '2019-09-16 07:00:00.000' and FAUCIDFlag != 'D'
	-- and len(AddressLine) > 1 
    -- and FAAddressParsed != '2099-12-31 00:00:00.000' and len(Suite) > 0 order by FAAddressParsed desc 
-- select top 10000 * from AddressMaster.dbo.Address_Master with (nolock) where CityStateZip like'%,%,%' and FAUCIDFlag != 'D' -- 0
-- select count(*) from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed is not null -- 299857
-- select * from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed is not null -- 299857
select count(*) from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed is null and FAUCIDFlag != 'D' -- 301,998,756 -- 99715 -- post first qtr 7,261,177
-- SELECT TOP (1000) * FROM [Addr].[dbo].[STDTrigger] order by triggerid desc 
-- select count(*) from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed is null and CountyFips = '48001' -- 25440
-- select * from AddressMaster.dbo.Address_Master with (nolock) where CountyFips = '48001' -- 49382
-- select FAAddressParsed, count(FAAddressParsed) from AddressMaster.dbo.Address_Master with (nolock) group by FAAddressParsed order by FAAddressParsed -- NULL	0
-- update AddressMaster.dbo.Address_Master set FAAddressParsed = null where FAAddressParsed is not null -- done

--select top 100 * from AddressMaster.dbo.Address_Master with (nolock) where len(PrivateMailbox) > 0
-- select * from global.dbo.county where state = 'ID'
-- select count(*) from AddressMaster.dbo.Address_Master with (nolock) where state = 'TX' and FAAddressParsed is null  -- 30,536,173 -- 10,972,312 -- 1413880
-- SELECT TOP (1000) * FROM [Addr].[dbo].[STDTrigger] order by [TriggerId] desc
-- select * from AddressMaster.dbo.Address_Master with (nolock) where state = 'ID' and FAUCIDFlag = 'D' and FATimestamp > '2019-07-28 00:00:00.0000000'
-- select * from AddressMaster.dbo.Address_Master with (nolock) where state = 'ID' and FAUCIDFlag = 'I' and FAEffectiveDAte > '2019-07-28 00:00:00.0000000'

-- LoadData: Melissa load date on servers 24/25
-- FATimestamp: Date record was last touched
-- FAEffectiveDAte: Date lastly loaded into system
-- FAAdressParsed: Date address was standardized
-- FAExpirationDAte: Date address was deleted in system
------------------------------------------------------------------------
/*
select 'AddressMaster' as tableName, 
    replace(CONVERT(varchar, CAST(count(CountyFips) AS money), 1),'.00','') as done,
    (select replace(CONVERT(varchar, CAST(count(CountyFips) AS money), 1),'.00','') from AddressMaster.dbo.Address_Master) as total 
    from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed > Convert(datetime, '2016-05-31 04:00:00.000' )
*/

--truncate table [AddressMaster].[dbo].[AddressMaster_ASP]
--truncate table [AddressMaster].[dbo].[AddressMaster_ASP_STD]

--select count(*) from AddressMaster.dbo.Address_Master with (nolock) where FAAddressParsed > '2019-07-16 00:00:00.0000000' and FAAddressParsed is not null
--select top 1000 * from AddressMaster.dbo.AddressMaster_ASP with (nolock)
--select top 1000 * from AddressMaster.dbo.AddressMaster_ASP_STD with (nolock)

-- list by state of quarterly timestamp.
select state,substring(cast (FATimestamp as varchar(20)),1,10) as FATimestamp, count(substring(cast (FATimestamp as varchar(20)),1,10)) as FACount from [AddressMaster].[dbo].[Address_Master] with (nolock) 
group by substring(cast (FATimestamp as varchar(20)),1,10), state
order by substring(cast (FATimestamp as varchar(20)),1,10) desc, state asc
--state	FATimestamp	FACount
--HI	2019-07-29	34443
--ID	2019-07-29	20863
--DC	2019-07-15	43083
--MD	2019-07-15	59926
--NJ	2019-07-15	279354
--DE	2019-07-08	25133

END


