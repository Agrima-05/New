SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankForeclosureTrusteeInput](@tableName varchar(40)) -- @tableName = 'Foreclosure_Trustee' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + ' 
	[ForeclosureUniqueID] [bigint] NOT NULL,
	[TrusteeFullAddress] [varchar](164) NULL,
	[TrusteeAptNumber] [varchar](15) NULL,
	[TrusteeCity] [varchar](55) NULL,
	[TrusteeState] [varchar](2) NULL,
	[TrusteeZip5] [varchar](9) NULL,
	[TrusteeZip4] [varchar](4) NULL,
	[TrusteeHouseNbr] [varchar](30) NULL,
	[TrusteeDirectionLeft] [varchar](2) NULL,
	[TrusteeStreet]  [varchar](60) NULL,
	[TrusteeMode] [varchar](10) NULL,
	[TrusteeDirectionRight] [varchar](2) NULL,
	[TrusteeUnitType] [varchar](20) NULL,
	[TrusteeCensusBlock] [varchar](4) NULL,
	[TrusteeCensusTract] [varchar](6) NULL,
	[TrusteeDPCheckCode] [varchar](2) NULL,
	[TrusteeDPCheckDigit] [varchar] (1) NULL,
	[TrusteeDPVCount] [varchar](5) NULL,
	[TrusteeDPVFootnote] [varchar](4) NULL,
	[TrusteeGeoErrorCode] [varchar](1) NULL,
	[TrusteeGeoStatusCode] [varchar](1) NULL,
	[TrusteeGeoCodeResults] [varchar](30) NULL,
	[TrusteeLACS] [varchar](1) NULL,
	[TrusteeLACSLinkInd] [varchar](1) NULL,
	[TrusteeMatchCode] [varchar] (30) NULL,
	[TrusteeCarrierCode] [varchar] (4) NULL)
    '    
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT ForeclosureUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([TrusteeFullAddress], '''') addressLine ,isnull(TrusteeCity, '''') as city  ,isnull(TrusteeState, '''') as state  ,
isnull(TrusteeZip5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY TrusteeZip5 desc'  

exec (@sql)  

