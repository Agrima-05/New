SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_Run3857Update_Looper_4]
AS
BEGIN
	SET NOCOUNT ON;

Declare @Fipscode4 varchar(5)

			DECLARE curPostgresql4 CURSOR FOR  
				SELECT [FIPSCode] 
				FROM dbo.[Run3857]
				WHERE [Session] = 4 AND COMPLETE = 'N'
				ORDER BY [FIPSCode]


			OPEN curPostgresql4   
			FETCH NEXT FROM curPostgresql4 INTO @Fipscode4

			WHILE @@FETCH_STATUS = 0   
			BEGIN   
			PRINT @Fipscode4
 
				UPDATE [dbo].[PostgreSQL_PROC] SET [Complete] = NULL Where thread = 4


				UPDATE [dbo].[Move_to_postgres_auto]
				SET fips = @Fipscode4
				WHERE thread = 4

				DECLARE @var0 smallint = 1
				Declare @execution_id bigint
				EXEC [SSISDB].[catalog].[create_execution] @package_name='Package4.dtsx', @execution_id=@execution_id OUTPUT, @folder_name='spot_data_move', @project_name='Spot_data_move', @use32bitruntime=False, @reference_id=Null
				EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=50, @parameter_name=N'LOGGING_LEVEL', @parameter_value=@var0
				EXEC [SSISDB].[catalog].[start_execution] @execution_id


				WHILE (Select Complete from dbo.PostgreSQL_PROC Where thread = 4) is NULL
					BEGIN
						WAITFOR DELAY '00:00:30';
					END
				  		
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode4) in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN

					--EXEC('update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot a 
					--where a.FIPS = '''+@Fipscode4+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated a 
					--where a.FIPS = '''+@Fipscode4+'''

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					')
					
					EXEC('UPDATE dbo.FASpot 
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode4+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode4+''' and ParcelGeometry3857 is NULL
					')
					
					END	
					
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @Fipscode4) NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN
					 	
					--update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_a a 
					--where a.FIPS = '''+@Fipscode4+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated_a a 
					--where a.FIPS = '''+@Fipscode4+'''
					--')

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

				-------------------------
					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL


				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on a.UniqueGuid = Cast(CASE when b.UniqueGuid like '' then NULL ELSE b.UniqueGuid END)
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+'''

				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL_4] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@Fipscode4+''' and b.FIPS = '''+@Fipscode4+''' and b.UniqueGuid is NULL

					UPDATE dbo.FASpot_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode4+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@Fipscode4+''' and ParcelGeometry3857 is NULL
					')

					END

					EXEC('UPDATE dbo.[Run3857]
							SET Complete = ''Y''
							WHERE FIPSCode = '''+@Fipscode4+'''
							')

					FETCH NEXT FROM curPostgresql4 INTO @Fipscode4 
			END   

				CLOSE curPostgresql4   
				DEALLOCATE curPostgresql4 		


END
