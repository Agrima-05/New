SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Quick PropID REF_ID match
-- =============================================
CREATE PROCEDURE dbo.PropIDRefIDMatching
AS
BEGIN

	SET NOCOUNT ON;

		DECLARE @FipsCode varchar(5)
		DECLARE @FipsNum int

		DECLARE curPropIDRefID CURSOR FOR  
			SELECT [FIPSCode],FipsCodeNum 
			FROM [Global].dbo.[County]
			--where FIPSCode ='36047'
			ORDER BY [FIPSCode]


		OPEN curPropIDRefID   
		FETCH NEXT FROM curPropIDRefID INTO @FipsCode,@FipsNum

		WHILE @@FETCH_STATUS = 0   
		BEGIN  
		 
		-- Print @FipsCode

			EXEC('UPDATE a
			SET a.DTDB_Ref_ID = b.REF_ID
			,a.DTDB_FORMATTED_APN = b.FORMATTED_APN
			,a.DTDB_UNFORMATTED_APN = b.UNFORMATTED_APN
			FROM Data.dbo.Property a
				JOIN [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.Assr b with(NOLOCK)
			ON a.FormattedAPN = b.FORMATTED_APN
			WHERE a.FIPS = ''' + @FipsCode + '''
				and b.FIPS = ' + @FipsNum + '
				and (a.DTDB_Ref_ID <> b.REF_ID OR a.DTDB_Ref_ID is NULL)
			')

			EXEC('UPDATE a
			SET a.DTDB_Ref_ID = b.REF_ID
			,a.DTDB_FORMATTED_APN = b.FORMATTED_APN
			,a.DTDB_UNFORMATTED_APN = b.UNFORMATTED_APN
			FROM Data.dbo.Property a
				JOIN [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.Assr b with(NOLOCK)
			ON a.UnformattedAPN = b.UNFORMATTED_APN
			WHERE a.FIPS = ''' + @FipsCode + '''
				and b.FIPS = ' + @FipsNum + '
				and (a.DTDB_Ref_ID <> b.REF_ID OR a.DTDB_Ref_ID is NULL)
			')


			Select FIPS,DTDB_REF_ID into #DupRefId
			from data.dbo.Property with(NOLOCK) 
			where FIPS = @FipsCode
				and DTDB_Ref_ID is NOT NULL 
			group by FIPS,DTDB_REF_ID 
			Having Count(*) > 1

			CREATE INDEX [ix_fipsRefID] on #DupRefId(Fips,DTDB_REF_ID)

			UPDATE a
			SET DTDB_Ref_ID = NULL
			,DTDB_FORMATTED_APN = NULL
			,DTDB_UNFORMATTED_APN = NULL
			FROM data.dbo.Property a JOIN #DupRefId b
			on a.FIPS = b.FIPs
			and a.DTDB_Ref_ID = b.DTDB_Ref_ID

			DROP TABLE #DupRefId


			FETCH NEXT FROM curPropIDRefID INTO @FipsCode,@FipsNum   
		END   

		CLOSE curPropIDRefID   
		DEALLOCATE curPropIDRefID 


END

