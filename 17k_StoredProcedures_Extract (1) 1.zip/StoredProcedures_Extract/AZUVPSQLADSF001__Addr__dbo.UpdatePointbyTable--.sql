SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create procedure [dbo].[UpdatePointbyTable--](@tablename varchar(25)) as
	                        declare @SQL varchar(max)
                             set @sql ='update d
                              set d.points= p.point
                              from dbo.DMaddr d,Parcels_New..'+@TableName+'p
                              where d.fips = p.fips
                              and d.PARCEL_APN = p.apn'


