SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE proc [dbo].[updateAddrBase--] (@start varchar (20), @end varchar(20)) as
declare @sql varchar(max) = ''
set @sql = '
update a set STD_Flag = 0
from [AddrBase].[dbo].[CL_Address_Base] a, addr06.dbo.CL_Address_Base b  
' + 
	' where 
	a.addrid = b.addrid 
	and (a.STD_FIPS = b.STD_FIPS or (a.STD_FIPS is null and b.STD_FIPS is null))
	and (a.STD_StreetNumber = b.STD_StreetNumber or (a.STD_StreetNumber is null and b.STD_StreetNumber is null))
	and (a.STD_PreDirection = b.STD_PreDirection or (a.STD_PreDirection is null and b.STD_PreDirection is null))
	and (a.STD_StreetName = b.STD_StreetName or (a.STD_StreetName is null and b.STD_StreetName is null))
	and (a.STD_Suffix = b.STD_Suffix or (a.STD_Suffix is null and b.STD_Suffix is null))
	and (a.STD_PostDirection = b.STD_PostDirection or (a.STD_PostDirection is null and b.STD_PostDirection is null))
	and (a.STD_Unit = b.STD_Unit or (a.STD_Unit is null and b.STD_Unit is null))
	and (a.STD_City = b.STD_City or (a.STD_City is null and b.STD_City is null))
	and (a.STD_State = b.STD_State or (a.STD_State is null and b.STD_State is null))
	and (a.STD_Zip = b.STD_Zip or (a.STD_Zip is null and b.STD_Zip is null))
	and	a.addrid >= ' + @start + ' and a.addrid <= ' + @end + '
   '
exec (@sql)  



