SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_FieldUpdatesFromPropertyCounts]
AS

	-- EXEC AddressMaster.dbo.usp_AddressMaster_FieldUpdatesFromPropertyCounts

BEGIN
	SET NOCOUNT ON;

    -- PropertyID -------------------------------------------------------------------------------------------------------------------------------------
    -- select count(*) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyIDMandA is null and PropertySpatial is null
    -- select count(*) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyID is null and (PropertyIDMandA is not null or PropertySpatial is not null) -- 87712513
	--select top 100 PropertyID,[PropertyIDMandA],[PropertySpatial],coalesce([PropertyIDMandA],[PropertySpatial],null) as PropertyID,* from AddressMaster.[dbo].Address_Master with (nolock)

	-- Fix an issue with FIPS having 4 characters during quarterly process -- added 20200116 ------------------------------------------------------ 
	select count(*) AS CountyFips_4char from AddressMaster.dbo.Address_Master A where len(CountyFips) = 4 -- 0


    -- CommunityName ------------------------------------------------------------------------------------------------------------------------------ 
	select count(*) AS NMCommunityName from AddressMaster.dbo.Address_Master A with (nolock) -- 774
	    join fema.dbo.faflood F with (nolock) 
		--on F.fips = a.countyfips and F.propertyid = a.propertyid -- 
		on F.propertyid = A.propertyid -- 
		--where A.CommunityName is null and (F.CommunityName is not null and F.CommunityName != '')
		where (A.CommunityName is null or A.CommunityName <> F.CommunityName) and ISNULL(F.CommunityName,'') NOT LIKE '' 
		-- and (A.FATimestamp > dateadd(day, -10, getdate()) OR F.FATimestamp > dateadd(day, -10, getdate()))
	/*
	select top 1000 A.propertyid, F.propertyid, a.countyfips, F.fips, A.CommunityName, F.communityname, F.FADateReceived, F.FATimestamp, * from AddressMaster.dbo.Address_Master A with (nolock) 
	    join fema.dbo.faflood F with (nolock) on F.propertyid = A.propertyid 
		where (A.CommunityName is null or A.CommunityName <> F.CommunityName) and ISNULL(F.CommunityName,'') NOT LIKE ''  
		-- and (A.FATimestamp > dateadd(day, -10, getdate()) OR F.FATimestamp > dateadd(day, -10, getdate()))
	*/


	-- Municipality -------------------------------------------------------------------------------------------
	SELECT count(*) AS NMMunicipality from AddressMaster.dbo.Address_Master A with (nolock) -- 50076
	    join data.dbo.property P with (nolock) 
	    --on p.fips = a.countyfips and p.propertyid = a.propertyid 
		on p.propertyid = a.propertyid 
		--where A.Municipality is null and (P.Municipality is not null and P.Municipality != '')
		where (A.Municipality is null or A.Municipality <> P.Municipality) and ISNULL(P.Municipality, '') NOT LIKE '' 
		-- and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	/*				 
	SELECT top 1000 A.propertyid, P.propertyid, A.CountyFips, P.FIPS, A.Municipality, P.Municipality, P.FADateReceived, P.FATimestamp, *
	    from AddressMaster.dbo.Address_Master A with (nolock) join data.dbo.property P with (nolock) on p.fips = a.countyfips and p.propertyid = a.propertyid 
		where (A.Municipality is null or A.Municipality <> P.Municipality) and ISNULL(P.Municipality, '') NOT LIKE '' 
		-- and (A.  > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	*/


	-- SubdivisionName ------------------------------------------------------------------------------------------- 
	SELECT count(*) AS NMSubdivisionName from AddressMaster.dbo.Address_Master A with (nolock) -- 532326
	    join data.dbo.property P with (nolock) --
		--on p.fips = a.countyfips and p.propertyid = a.propertyid --
		on P.propertyid = A.propertyid 
		--where A.SubdivisionName is null and (P.SubdivisionName is not null and P.SubdivisionName != '') 
		where (A.SubdivisionName is null OR A.SubdivisionName <> P.SubdivisionName) and ISNULL(P.SubdivisionName, '') NOT LIKE ''
	    --and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	/*			  
	SELECT top 1000 A.propertyid, P.propertyid, A.CountyFips, P.FIPS, A.SubdivisionName, P.SubdivisionName, P.FADateReceived, P.FATimestamp, *
	    from AddressMaster.dbo.Address_Master A with (nolock) join data.dbo.property P with (nolock) on P.propertyid = A.propertyid
		where (A.SubdivisionName is null OR A.SubdivisionName <> P.SubdivisionName) and ISNULL(P.SubdivisionName, '''') NOT LIKE ''''
	    --and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	*/


	-- PropertyClassID -------------------------------------------------------------------------------------------
	SELECT count(*) AS NMPropertyClassID from AddressMaster.dbo.Address_Master A with (nolock) -- 141712
	    join data.dbo.property P with (nolock) 
		--on p.fips = a.countyfips and p.propertyid = a.propertyid
		on P.propertyid = A.propertyid 
		--where A.PropertyClassID is null and (P.PropertyClassID is not null and P.PropertyClassID != '') 
		where (A.PropertyClassID is null OR a.[PropertyClassID] <> p.[PropertyClassID]) and ISNULL(P.PropertyClassID, '') NOT LIKE ''
		--and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	/*	
	SELECT top 1000 A.propertyid, P.propertyid, A.CountyFips, P.FIPS, A.PropertyClassID, P.PropertyClassID, P.FADateReceived, P.FATimestamp, *
		from AddressMaster.dbo.Address_Master A with (nolock) join data.dbo.property P with (nolock) on P.propertyid = A.propertyid
		where (A.PropertyClassID is null OR a.[PropertyClassID] <> p.[PropertyClassID]) and ISNULL(P.PropertyClassID, '''') NOT LIKE ''''
		--and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate())) 
	*/


	-- NonUSPSAddressIndicator ------------------------------------------------------------------------------------------
	SELECT count(*) AS NMAddressMatchResults from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS03%' -- 0
	    and (A.NonUSPSAddressIndicator is null or A.NonUSPSAddressIndicator != 'Y') 
		-- and A.FATimestamp > dateadd(day, -10, getdate()) 
	--SELECT top 1000 A.propertyid, A.NonUSPSAddressIndicator, A.AddressMatchResults from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS03%' and A.NonUSPSAddressIndicator != 'Y' 
    
	
	-- NotCurrentlyDeliverable -------------------------------------------------------------------------------------------
	SELECT count(*) AS NMNotCurrentlyDeliverable from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS17%' -- 0
	    and (A.NotCurrentlyDeliverable is null or NotCurrentlyDeliverable != 'Y')   
		-- and A.FATimestamp > dateadd(day, -10, getdate())
	--SELECT top 100 A.propertyid, A.NotCurrentlyDeliverable, A.AddressMatchResults from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS17%' and A.NotCurrentlyDeliverable != 'Y' 


	-- DsfVacany / VacantIndicator ------------------------------------------------------------------------------------------- 
	SELECT count(*) AS NMDsfVacant from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS16%' -- 0
	    and (A.DsfVacant is null or A.DsfVacant != 'Y') -- 
		-- and A.FATimestamp > dateadd(day, -10, getdate())
	--SELECT top 1000 A.propertyid, A.DsfVacant as VacantIndicator, A.AddressMatchResults from AddressMaster.dbo.Address_Master A with (nolock) where A.AddressMatchResults like '%AS16%' and A.DsfVacant != 'Y' 


	-- Filler Ref_ID ------------------------------------------------------------------------------------------------------------------------------
	SELECT count(*) AS NMRef_ID from AddressMaster.dbo.Address_Master A with (nolock) -- 18280
	    join Assr.dbo.Assr ASSR with (nolock) 
		on A.propertyid = ASSR.Lic_PropertyID and A.CountyFips = ASSR.Lic_Fips 
		where A.Ref_ID is null
		-- and (A.FATimestamp > dateadd(day, -10, getdate()) OR ASSR.FATimestamp > dateadd(day, -10, getdate()))
	--SELECT top 1000 A.Ref_ID, ASSR.REF_ID, ASSR.Lic_PropertyID, A.propertyid, ASSR.Lic_Fips, A.CountyFips from AddressMaster.dbo.Address_Master A with (nolock) 
	--	join Assr.dbo.Assr ASSR with (nolock) on A.propertyid = ASSR.Lic_PropertyID and A.CountyFips = ASSR.Lic_Fips where A.Ref_ID is null


	-- EffectiveDate ------------------------------------------------------------------------------------------------------------------------------
	select count(*) AS NMFAEffectiveDate from AddressMaster.dbo.Address_Master where FAEffectiveDate is null -- 0
	-- select propertyid, FAEffectiveDate from AddressMaster.dbo.Address_Master where FAEffectiveDate is null


	-- Longitude and Latitude -----------------------------------------------------------------------------------------------------------------------------
	-- ,FALongitude = coalesce(d.FARooftopLongitude, p.falongitude, situslongitude, longitude,null) -- This will change when we start using the Roof Top lat/Long
	-- ,FALatitude  = coalesce(d.FARooftopLatitude, p.falatitude,  situslatitude,  latitude,null)  -- This will change when we start using the Roof Top lat/Long
	-- FARooftop=GTmagic, FA=DMP, Situs=Melissa, TP=BK
	SELECT count(*) AS NMLongitudeOrLatitudeNoFIPS from AddressMaster.dbo.Address_Master A -- 0
		join data.dbo.property P with (nolock) 
		on A.propertyid = P.propertyid
		--join DigitalMap.dbo.BuildingFootprint D with (nolock)
		--on A.propertyid = D.propertyid
		where A.ConsdtLatitude != coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL) or
	          A.ConsdtLongitude != coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL)
		--where A.Longitude != coalesce(P.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
		--	  A.Latitude != coalesce(P.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)
			  --and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate()))
	
	--select top 10000 A.CountyFips,P.FIPS,A.propertyid,P.propertyid,P.FADateReceived,P.FATimestamp,
	--			   A.Longitude,P.FALongitude,P.SitusLongitude,P.TPLongitude,coalesce(P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL), 
	--			   A.Latitude,P.FALatitude,P.SitusLatitude,P.TPLatitude,coalesce(P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)
	--	from AddressMaster.dbo.Address_Master A 
	--	join data.dbo.property P with (nolock) 
	--	on A.propertyid = P.propertyid
	--	join DigitalMap.dbo.BuildingFootprint D with (nolock)
	--	on A.propertyid = D.propertyid
	--	where (A.Longitude != coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
	--		  A.Latitude != coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)) -- or
			  --and (A.FATimestamp > dateadd(day, -10, getdate()) OR P.FATimestamp > dateadd(day, -10, getdate())) 
			  --((A.Longitude is null or A.Latitude is null) and (coalesce(P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) is not null or coalesce(P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL) is not null)) -- 0

END
