SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE procedure [dbo].[CLAddressBaseWrk--]
as

 BEGIN
IF OBJECT_ID('tempdb..#temp1') IS NOT NULL
    DROP TABLE #temp1
SELECT 
isnull(ltrim(rtrim(substring(B.SITUS_HOUSE_NBR , patindex('%[^0]%',B.SITUS_HOUSE_NBR ), 10))),' ') as SITUS_HOUSE_NBR
,isnull(ltrim(rtrim(substring(B.MAIL_HOUSE_NBR , patindex('%[^0]%',B.MAIL_HOUSE_NBR ), 10))),' ') as MAIL_HOUSE_NBR
,isnull(ltrim(rtrim(substring(B.SITUS_HOUSE_NBR_#2 , patindex('%[^0]%',B.SITUS_HOUSE_NBR_#2 ), 10))),' ') as SITUS_HOUSE_NBR_#2 
, isnull(ltrim(rtrim(substring(B.MAIL_HOUSE_NBR_2 , patindex('%[^0]%',B.MAIL_HOUSE_NBR_2 ), 10))),' ') as MAIL_HOUSE_NBR_2
,isnull(B.SITUS_HOUSE_NBR_SUFFIX,' ') as SITUS_HOUSE_NBR_SUFFIX
,isnull(B.MAIL_HOUSE_NBR_SUFFIX,' ') as MAIL_HOUSE_NBR_SUFFIX
,isnull(B.SITUS_DIRECTION,' ') AS SITUS_DIRECTION
, isnull(B.MAIL_DIRECTION,' ') AS MAIL_DIRECTION
, isnull(B.SITUS_STREET_NAME,' ')  AS SITUS_STREET_NAME
, isnull(B.MAIL_STREET_NAME,' ') AS MAIL_STREET_NAME
, isnull(B.SITUS_MODE,' ')  AS SITUS_MODE
, isnull(B.MAIL_MODE,' ') AS MAIL_MODE
, isnull(B.SITUS_QUADRANT,' ')  AS SITUS_QUADRANT
, isnull(B.MAIL_QUADRANT,' ') AS MAIL_QUADRANT
, isnull(B.SITUS_UNIT_NBR,' ')  AS SITUS_UNIT_NBR
, isnull(B.MAIL_UNIT_NBR,' ') AS MAIL_UNIT_NBR
, isnull(B.SITUS_CITY,' ')  AS SITUS_CITY
, isnull(B.MAIL_CITY,' ') AS MAIL_CITY
, isnull(B.SITUS_STATE,' ')  AS SITUS_STATE
, isnull(B.MAIL_STATE,' ') AS MAIL_STATE
, isnull(B.SITUS_ZIP_CODE,' ')  AS SITUS_ZIP_CODE
, isnull(B.MAIL_ZIP_CODE,' ') AS MAIL_ZIP_CODE
, isnull(B.SITUS_CARRIER_CODE,' ')  AS SITUS_CARRIER_CODE
, isnull(B.MAIL_CARRIER_CODE,' ') AS MAIL_CARRIER_CODE
--COUNT(*)
,a.AddrID,
a.FIPS,
a.REF_ID,
a.Address_Type,
a.Source_Type into #temp1
FROM
TWG.dbo.TWG_Deployed_Fips x
inner join
TWG.dbo.PropertyRecord_Wrk c   (nolock)
on x.fips = C.fips
INNER JOIN
Assr.dbo.Assr b (nolock)
on b.Fips=c.Fips
and b.REF_Id=c.REF_Id
and c.Modi_Type<>'D'
inner join
addr..cl_address_base a  (nolock)
on a.fips = b.fips
and a.ref_id = b.ref_id
and a.Address_Type='M'

Truncate table Addr.dbo.CL_Address_Base_Wrk

Insert Into Addr.dbo.CL_Address_Base_Wrk 
SELECT 
a.AddrID,
a.FIPS,
a.REF_ID,
a.Address_Type,
a.Source_Type
FROM  #TEMP1 a
where
A.SITUS_HOUSE_NBR  = A. MAIL_HOUSE_NBR
AND A. SITUS_HOUSE_NBR_#2 = A. MAIL_HOUSE_NBR_2
AND A. SITUS_HOUSE_NBR_SUFFIX = A. MAIL_HOUSE_NBR_SUFFIX
AND A. SITUS_DIRECTION = A. MAIL_DIRECTION
AND A. SITUS_STREET_NAME = A. MAIL_STREET_NAME
AND A. SITUS_MODE = A. MAIL_MODE
AND A. SITUS_QUADRANT = A. MAIL_QUADRANT
AND A. SITUS_UNIT_NBR = A. MAIL_UNIT_NBR
AND A. SITUS_CITY = A. MAIL_CITY
AND A. SITUS_STATE = A. MAIL_STATE
AND A. SITUS_ZIP_CODE = A. MAIL_ZIP_CODE
AND A. SITUS_CARRIER_CODE = A. MAIL_CARRIER_CODE 
END





