SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[FinalRollup](@fips as varchar(5))
AS
BEGIN

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2023] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2023] = '2023'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2023] is null and [TAX_YEAR] = '2023'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2022] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2022] = '2022'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2022] is null and [TAX_YEAR] = '2022'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2021] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2021] = '2021'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2021] is null and [TAX_YEAR] = '2021'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2020] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2020] = '2020'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2020] is null and [TAX_YEAR] = '2020'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2019] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2019] = '2019'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2019] is null and [TAX_YEAR] = '2019'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2018] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2018] = '2018'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2018] is null and [TAX_YEAR] = '2018'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2017] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2017] = '2017'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2017] is null and [TAX_YEAR] = '2017'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2016] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2016] = '2016'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2016] is null and [TAX_YEAR] = '2016'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2015] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2015] = '2015'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2015] is null and [TAX_YEAR] = '2015'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2014] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2014] = '2014'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2014] is null and [TAX_YEAR] = '2014'

 update [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax]
  Set [TaxAmount2013] = replace([TAX_AMOUNT],'.','')
     ,[TaxYear2013] = '2013'
  from [zzCust_Costar].[dbo].[zProperty_Template_BK_Tax] b
  Join [Data_Archive].[dbo].[AssrArchive_BK] a
  on a.fipsCode = b.fips
  and a.propertyid = b.propertyid
  where b.fips = @fips and [TaxAmount2014] is null and [TAX_YEAR] = '2013'

INSERT INTO [Data_Archive].[dbo].[BKPropertyID]
           ([FIPS]
           ,[cnt])
 Select @fips, 1

END

