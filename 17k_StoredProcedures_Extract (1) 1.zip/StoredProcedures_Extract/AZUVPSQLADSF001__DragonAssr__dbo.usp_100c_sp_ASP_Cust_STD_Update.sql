SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[usp_100c_sp_ASP_Cust_STD_Update]
as  

-- Trim all fields, make some fields uppdercase, rebuild FullStreetAddress and CensusTractBlock fields
	   INSERT INTO [a_ASP_IN_Update_STD]([DTDB_REF_ID]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusStdCarrierCode]
      ,[SitusCensusTract]
      ,[SitusCensusTractBlock]
      ,[SitusStdUnitType]
      ,[SitusStdMatchCode]
      ,[SitusDPVCount]
      ,[SitusDPVFootnote]
      ,[SitusLACS]
      ,[SitusLACSLinkInd]
      ,[SitusDPCheckDigit]
      ,[SitusDPCheckCode]
      ,[SitusCensusBlock]
      ,[SitusGeoErrorCode]
      ,[SitusGeoStatusCode]
      ,[SitusGeoCodeResults])
	   SELECT b.Raw_id
	   ,Rtrim(Rtrim(Rtrim(Rtrim(Rtrim(Rtrim(Ltrim(Rtrim([StreetNumber])) + ' ' + Ltrim(Rtrim([PreDir]))) + ' ' + Ltrim(Rtrim([StreetName]))) + ' ' + Ltrim(Rtrim([StreetType]))) + ' ' + Ltrim(Rtrim([PostDir])))  + ' ' + Ltrim(Rtrim([SuiteType]))) + ' ' + Ltrim(Rtrim([Suite])))
	   ,ltrim(rtrim([StreetNumber]))
       ,UPPER(ltrim(rtrim([PreDir])))
       ,UPPER(ltrim(rtrim([StreetName])))
       ,UPPER(ltrim(rtrim([StreetType])))
       ,UPPER(ltrim(rtrim([PostDir])))
       ,UPPER(ltrim(rtrim([Suite])))
       ,UPPER(ltrim(rtrim(a.[City])))
       ,UPPER(ltrim(rtrim(a.[State])))
       ,ltrim(rtrim([Zip]))
       ,ltrim(rtrim([Plus4]))
       ,ltrim(rtrim([Latitude]))
       ,ltrim(rtrim([Longitude]))
       ,ltrim(rtrim([CarrierRoute]))
	   ,ltrim(rtrim([CensusTract]))
       ,ltrim(rtrim([CensusTract])) + ltrim(rtrim([CensusBlock]))
       ,UPPER(ltrim(rtrim([SuiteType])))
       ,ltrim(rtrim([AddressTypeCode]))
       ,ltrim(rtrim([DPVCount]))
       ,ltrim(rtrim([DPVFootnotes]))
       ,ltrim(rtrim([LACS]))
       ,ltrim(rtrim([LACSLinkIndicator]))
       ,ltrim(rtrim([DeliveryPointCheckDigit]))
       ,ltrim(rtrim([DeliveryPointCode]))
       ,ltrim(rtrim([CensusBlock]))
       ,ltrim(rtrim([GeoErrorCode]))
       ,ltrim(rtrim([GeoStatusCode]))
       ,ltrim(rtrim([GeoCodeResults]))
     From dbo.DragonAssr_Update_STD a JOIN a_ASP_IN_Update b
	 on a.RecordID = b.ASP_ID





