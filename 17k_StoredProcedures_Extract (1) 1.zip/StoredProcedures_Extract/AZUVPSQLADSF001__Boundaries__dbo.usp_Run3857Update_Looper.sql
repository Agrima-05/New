SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_Run3857Update_Looper]
AS
BEGIN
	SET NOCOUNT ON;

Declare @Fipscode varchar(5)

			DECLARE curPostgresql CURSOR FOR  
				SELECT [FIPSCode] 
				FROM dbo.[Run3857]
				WHERE FIPSCode like '06%'
				ORDER BY [FIPSCode]


			OPEN curPostgresql   
			FETCH NEXT FROM curPostgresql INTO @FipsCode

			WHILE @@FETCH_STATUS = 0   
			BEGIN   
			PRINT @FIPScode
 
				UPDATE [dbo].[PostgreSQL_PROC] SET [Complete] = NULL ,FinishTime = GetDate()

				Truncate table [dbo].[Move_to_postgres_auto]
			
				INSERT INTO [dbo].[Move_to_postgres_auto](fips)
				SELECT @FipsCode

				DECLARE @var0 smallint = 1
				Declare @execution_id bigint
				EXEC [SSISDB].[catalog].[create_execution] @package_name='Package1.dtsx', @execution_id=@execution_id OUTPUT, @folder_name='spot_data_move', @project_name='Spot_data_move', @use32bitruntime=False, @reference_id=Null
				EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=50, @parameter_name=N'LOGGING_LEVEL', @parameter_value=@var0
				EXEC [SSISDB].[catalog].[start_execution] @execution_id


				WHILE (Select Complete from dbo.PostgreSQL_PROC Where thread = 1) is NULL
					BEGIN
						WAITFOR DELAY '00:00:30';
					END
				  		
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @FIPScode) in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN

					--EXEC('update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot a 
					--where a.FIPS = '''+@FipsCode+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated a 
					--where a.FIPS = '''+@FipsCode+'''

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					')
					
					EXEC('UPDATE dbo.FASpot 
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@FipsCode+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@FipsCode+''' and ParcelGeometry3857 is NULL
					')
					
					END	
					
				IF(SELECT distinct [STATE] FROM Global.dbo.County WHERE FIPSCode = @FIPScode) NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
					BEGIN
					 	
					--update a
					--SET a.ParcelGeometry3857 =  NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_a a 
					--where a.FIPS = '''+@FipsCode+'''

					--update a
					--SET a.ParcelGeometry3857 = NULL
					--,a.PointGeometry3857 = NULL
					--FROM [dbo].FASpot_Generated_a a 
					--where a.FIPS = '''+@FipsCode+'''
					--')

					EXEC('update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

				-------------------------
					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					update a
					SET a.ParcelGeometry3857 =  geometry::STGeomFromText([ParcelGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL


				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on a.UniqueGuid = b.UniqueGuid
						and isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+'''

				-------------------------
					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					update a
					SET a.PointGeometry3857 =  geometry::STGeomFromText([PointGeom3857WKT],3857)
					FROM [dbo].FASpot_Generated_a a JOIN [dbo].[FASpot_Return_SQL] b 
					on isnull(a.REFID,0) = isnull(b.PropertyID,0)
					where a.FIPS = '''+@FipsCode+''' and b.FIPS = '''+@FipsCode+''' and b.UniqueGuid is NULL

					UPDATE dbo.FASpot_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@FipsCode+''' and ParcelGeometry3857 is NULL

					UPDATE dbo.FASpot_Generated_a
					SET ParcelGeometry3857 = PointGeometry3857 
					WHERE FIPS = '''+@FipsCode+''' and ParcelGeometry3857 is NULL
					')

					END

					EXEC('UPDATE dbo.[Run3857]
							SET Complete = ''Y''
							WHERE FIPSCode = '''+@FipsCode+'''
							')

					FETCH NEXT FROM curPostgresql INTO @FipsCode 
			END   

				CLOSE curPostgresql   
				DEALLOCATE curPostgresql 		


END
