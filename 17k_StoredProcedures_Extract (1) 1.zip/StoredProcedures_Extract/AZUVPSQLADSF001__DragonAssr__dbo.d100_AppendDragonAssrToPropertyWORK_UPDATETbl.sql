SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d100_AppendDragonAssrToPropertyWORK_UPDATETbl] 

AS
BEGIN

	SET NOCOUNT ON;

		UPDATE [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET [FRONT_FOOTAGE] = NULL
		,[DEPTH_FOOTAGE] = NULL
		WHERE LEN([FRONT_FOOTAGE]) > 8 or LEN([DEPTH_FOOTAGE])> 8

			UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
			SET [FRONT_FOOTAGE] = NULL 
			WHERE FRONT_FOOTAGE like '%.%.%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
			SET [DEPTH_FOOTAGE] = NULL 
			WHERE [DEPTH_FOOTAGE] like '%.%.%'


			DROP INDEX IF EXISTS [ix_FipsPropID] ON [dbo].[PropertyWorkUpdateTbl]
			DROP INDEX IF EXISTS [ix_FipsDTDB_Ref_ID] ON [dbo].[PropertyWorkUpdateTbl]

		TRUNCATE TABLE [dbo].[PropertyWorkUpdateTbl]

		Insert into [dbo].[PropertyWorkUpdateTbl]([FIPS]
			,PropertyID
			,DTDB_REF_ID
			,VendorPID
			,[DTDB_FORMATTED_APN]
			,[DTDB_UNFORMATTED_APN]
			,[APNSeqNbr]
			,[FormattedAPN]
			,[OldAPN]
			,[TaxAccountNumber]
			,[AssessorsMapRef1]
			,[AssessorsMapRef2]
			,[SitusCensusTract]
			,[Block]
			,[LotNumber]
			,[LegalRange]
			,[LegalTownship]
			,[LegalSection]
			,[LegalQuarter]
			,[LegalDescription]
			,[StdLandUseCode]
			,[CountyLandUseCode]
			,[StateLandUseCode]
			,[Zoning]
			,[PropertyClassID]
			,[Municipality]
			,[MobileHomeInd]
			,[SubdivisionTractNbr]
			,[SubdivisionPlatBook]
			,[SubdivisionPlatPage]
			,[SubdivisionName]
			,[SitusLatitude]
			,[SitusLongitude]
			,[TPLatitude]
			,[TPLongitude]
			,[SitusStdFullStreetAddress]
			,[SitusStdHouseNbr]
			,[SitusStdHouseNbr2]
			,[SitusStdHouseNbrSuffix]
			,[SitusStdDirectionLeft]
			,[SitusStdStreet]
			,[SitusStdMode]
			,[SitusStdDirectionRight]
			,[SitusStdUnitNbr]
			,[SitusStdCity]
			,[SitusStdState]
			,[SitusStdZIP5]
			,[SitusStdCarrierCode]
			,[OwnerStd1CorpInd]
			,[OwnerStd2CorpInd]
			,[OwnerStd1LastName]
			,[OwnerStd1FirstName]
			,[OwnerStd1Suffix]
			,[OwnerStd2LastName]
			,[OwnerStd2FirstName]
			,[OwnerStd2Suffix]
			,[OwnerStdNAME1FULL]
			,[OwnerStdNAME2FULL]
			,[OwnerStdNAME3FULL]
			,[OwnerStdNAME4FULL]
			,[OwnerOccupied]
			,[AssesseeStd1Name]
			,[AssesseeStd2Name]
			,[AssesseeNameIndicator]
			,[AssesseeNameIndicator2]
			,[HomesteadInd]
			,[VeteranInd]
			,[DisabledInd]
			,[WidowInd]
			,[SeniorInd]
			,[SchoolCollegeInd]
			,[ReligiousInd]
			,[WelfareInd]
			,[PublicUtilityInd]
			,[CemeteryInd]
			,[HospitalInd]
			,[LibraryInd]
			,[OwnerEtALIndicator]
			,[OwnerStd1OwnershipRights]
			,[OwnerStd1RelationshipType]
			,[MailingStdFullStreetAddress]
			,[MailingStdHouseNbr]
			,[MailingStdHouseNbr2]
			,[MailingStdHouseNbrSuffix]
			,[MailingStdDirectionLeft]
			,[MailingStdStreet]
			,[MailingStdMode]
			,[MailingStdDirectionRight]
			,[MailingStdUnitNbr]
			,[MailingStdCity]
			,[MailingStdState]
			,[MailingStdZIP5]
			,[MailingStdCarrierCode]
			,[MailingOptOut]
			,[AssdTotalValue]
			,[AssdLandValue]
			,[AssdImprovementValue]
			,[MarketTotalValue]
			,[MarketValueLand]
			,[MarketValueImprovement]
			,[ApprTotalValue]
			,[ApprLandValue]
			,[ApprImprovementValue]
			,[TaxTotalValue]
			,[TaxValueLand]
			,[TaxValueImprovement]
			,[UNVTotalValue]
			,[UNVLandValue]
			,[UNVImprovementValue]
			,[UNVValueYear]
			,[MarketValueYear]
			,[ApprYear]
			,[TaxAmount]
			,[TaxYear]
			,[TaxDeliquentValue1]
			,[TaxDeliquentYear1]
			,[AssdYear]
			,[TaxRateCodeArea]
			,[LotSizeFrontageFeet]
			,[LotSizeDepthFeet]
			,[LotSizeAcres]
			,[LotSizeSqFt]
			,[LotIrregularInd]
			,[LotUsableSize]
			,[BuildingArea]
			,[BuildingAreaInd]
			,[SumAboveGradeLivingSqFt]
			,[SumAdjAreaSqFt]
			,[SumBuildingSqFt]
			,[SumLivingAreaSqFt]
			,[SumGroundFloorSqFt]
			,[SumGrossAreaSqFt]
			,[SumBasementSqFt]
			,[SumGarageSqFt]
			,[YearBuilt]
			,[EffectiveYearBuilt]
			,[Bedrooms]
			,[TotalRooms]
			,[BathTotalCalc]
			,[BathFull]
			,[BathsParcialNbr]
			,[BathHalf]
			,[Bath1QTR]
			,[Bath3QTR]
			,[BathFixturesNbr]
			,[AirConditioningCode]
			,[BasementCode]
			,[BuildingClassCode]
			,[BuildingConditionCode]
			,[ConstructionTypeCode]
			,[ElectricityCode]
			,[ExteriorWallsCode]
			,[FireplaceCode]
			,[FloorCoverCode]
			,[FloorTypeCode]
			,[FoundationInd]
			,[FrameCode]
			--,[HeatingFuelTypeCode]
			,[Garage]
			,[HeatCode]
			,[HeatingFuelTypeCode]
			,[SiteInfluenceCode]
			,[GarageParkingNbr]
			,[PatioCode]
			,[PoolCode]
			,[PorchCode]
			,[BuildingQualityCode]
			,[RoofCoverCode]
			,[RoofTypeCode]
			,[SewerCode]
			,[StoriesCode]
			,[StoriesNbrCode]
			,[StyleCode]
			,[SumResidentialUnits]
			,[SumBuildingsNbr]
			,[SumCommercialUnits]
			,[ViewCode]
			,[WaterCode]
			,[TaxSourceInd]
			,[FAUCIDFlag]
			,[FADateReceived]
			,[OldApnIndicator]
			,[FATimestamp]
			,[FASourceInd]
			,[FACreateDt]
			,[VendorLoadDate]
			,Certification_Date)
		SELECT RIGHT('0' + Convert(varchar(5),[FIPS]),5) as [FIPS]
			,[PropertyID] 
			,[REF_ID] as [DTDB_Ref_ID]
			,[REF_ID] as [VendorPID]
			,CASE WHEN FIPS = 55079 THEN [UNFORMATTED_APN] ELSE [FORMATTED_APN] END as [DTDB_FORMATTED_APN]
			,[UNFORMATTED_APN] as [DTDB_UNFORMATTED_APN]
			,[APN_SEQUENCE_NBR] as [APNSeqNbr]
			,LEFT([FORMATTED_APN],45) as [FormattedAPN]
			,CASE WHEN isNULL(ALTERNATE_APN,'') NOT LIKE '' THEN LEFT(Replace(Replace(Replace(Replace(Replace(Replace(Replace(ALTERNATE_APN,'.',''),'-',''),'\',''),' ',''),'_',''),':',''),'/',''),31) 
				WHEN isNULL([PREVIOUS_PARCEL_NBR],'') NOT LIKE '' THEN LEFT(Replace(Replace(Replace(Replace(Replace(Replace(Replace([PREVIOUS_PARCEL_NBR],'.',''),'-',''),'\',''),' ',''),'_',''),':',''),'/',''),31) ELSE '' END as [OldAPN] 
			,LEFT([ACCOUNT_NBR],30) as [TaxAccountNumber]
			,LEFT([MAP_REFERENCE_1],15) as [AssessorsMapRef1]
			,LEFT([MAP_REFERENCE_2],15) as [AssessorsMapRef2]
			,LEFT([CENSUS_TRACT],6) as [SitusCensusTract]
			,LEFT([BLOCK_NBR],7) as [Block]
			,LEFT([LOT_NBR_1],7) as [LotNumber]
			,LEFT([RANGE],30) as [LegalRange]
			,LEFT([TOWNSHIP],30) as [LegalTownship]
			,LEFT([SECTION],30) as [LegalSection]
			,LEFT([QUARTER_SECTION],30) as [LegalQuarter]
			,left([EXTENDED_LEGAL_DESCRIPTION],2000) as [LegalDescription]
			,[Land_Use] as [StdLandUseCode]
			,[COUNTY_USE_CODE] as [CountyLandUseCode]
			,[STATE_USE_CODE] as [StateLandUseCode]
			,LEFT([ZONING],25) as [Zoning]
			,[PROPERTY_INDICATOR] as [PropertyClassID]
			,LEFT([MUNICIPALITY_NAME],30) as [Municipality]
			,CASE WHEN IsNULL([MOBILE_HOME_IND],'') = 'Y' THEN 1 ELSE NULL END as [MobileHomeInd]
			,LEFT([SUBDIV_TRACT_NBR],10) as [SubdivisionTractNbr]
			,LEFT([SUBDIV_PLAT_BOOK],10) as [SubdivisionPlatBook]
			,LEFT([SUBDIV_PLAT_PAGE],10) as [SubdivisionPlatPage]
			,LEFT([SUBDIV_NAME],40) as [SubdivisionName]
			,[BLOCK_LEVEL_LATITUDE] as [SitusLatitude]
			,[BLOCK_LEVEL_LONGITUDE] as [SitusLongitude]
			,[BLOCK_LEVEL_LATITUDE] as [TPLatitude]
			,[BLOCK_LEVEL_LONGITUDE] as [TPLongitude]
			,LEFT(UPPER(RTrim(RTrim(LTrim(RTrim(RTrim(RTrim(RTrim(isNULL([SITUS_HOUSE_NBR],'') + ' ' + isNULL([SITUS_HOUSE_NBR_#2],'')) + ' ' + isNULL([SITUS_HOUSE_NBR_SUFFIX],'')) + ' ' + isNULL([SITUS_DIRECTION],'')) + ' ' + isNULL([SITUS_STREET_NAME],''))) + ' ' + isNULL([SITUS_MODE],'')) + ' ' + isNULL([SITUS_QUADRANT],'')) + CASE WHEN isNULL([SITUS_UNIT_NBR],'') like '' THEN '' ELSE ' # ' + isNULL([SITUS_UNIT_NBR],'') END),116) as [SitusStdFullStreetAddress]
			,LEFT([SITUS_HOUSE_NBR],30) as [SitusStdHouseNbr]
			,NULL as [SitusStdHouseNbr2]
			,LEFT([SITUS_HOUSE_NBR_SUFFIX],10) as [SitusStdHouseNbrSuffix]
			,LEFT(UPPER([SITUS_DIRECTION]),2) as [SitusStdDirectionLeft]
			,LEFT(UPPER([SITUS_STREET_NAME]),60) as [SitusStdStreet]
			,LEFT(UPPER([SITUS_MODE]),10) as [SitusStdMode]
			,LEFT(UPPER([SITUS_QUADRANT]),2) as [SitusStdDirectionRight]
			,LEFT(UPPER([SITUS_UNIT_NBR]),15) as [SitusStdUnitNbr]
			,LEFT(UPPER([SITUS_CITY]),55) as [SitusStdCity]
			,LEFT(UPPER([SITUS_STATE]),2) as [SitusStdState]
			,LEFT([SITUS_ZIP_CODE],5) as [SitusStdZIP5]
			,LEFT([SITUS_CARRIER_CODE],4) as [SitusStdCarrierCode]
			,Case When [OWN_CORP_IND_1] = 'Y' THEN 1 ELSE NULL End as [OwnerStd1CorpInd]
			,Case When [OWN_CORP_IND_2] = 'Y' THEN 1 ELSE NULL End as [OwnerStd2CorpInd]
			,UPPER(LEFT(LTRIM(RTRIM([OWN1_LAST_NAME])),30)) as [OwnerStd1LastName]
			,UPPER(LEFT(LTRIM(RTRIM([OWN1_FIRST_NAME_M_I])),30)) as [OwnerStd1FirstName]
			,UPPER(LEFT(LTRIM(RTRIM([OWN1_SUFFIX])),5)) as [OwnerStd1Suffix]
			,UPPER(LEFT(LTRIM(RTRIM([OWN2_LAST_NAME])),30)) as [OwnerStd2LastName]
			,UPPER(LEFT(LTRIM(RTRIM([OWN2_FIRST_NAME_MI])),30)) as [OwnerStd2FirstName]
			,UPPER(LEFT(LTRIM(RTRIM([OWN2_SUFFIX])),5)) as [OwnerStd2Suffix]
			,UPPER(LEFT(LTRIM(RTRIM([OWN_NAME1_FULL])),80)) as [OwnerStdNAME1FULL]
			,UPPER(LEFT(LTRIM(RTRIM([OWN_NAME2_FULL])),80)) as [OwnerStdNAME2FULL]
			,UPPER(LEFT(LTRIM(RTRIM([OWN_NAME3_FULL])),80)) as [OwnerStdNAME3FULL]
			,UPPER(LEFT(LTRIM(RTRIM([OWN_NAME4_FULL])),80)) as [OwnerStdNAME4FULL]
			,CASE WHEN [ABSENTEE_OWN_STATUS] = 'O' THEN 'Y' ELSE NULL END as [OwnerOccupied]
			,UPPER(LEFT(LTRIM(RTRIM([OWN1_LAST_NAME])) + CASE WHEN (ISNULL([OWN_CORP_IND_1],'') LIKE '' AND ISNULL(LTRIM(RTRIM([OWN1_FIRST_NAME_M_I])),'') NOT LIKE '') THEN ', ' + LTRIM(RTRIM([OWN1_FIRST_NAME_M_I])) ELSE '' END,80)) + CASE WHEN isNULL([OWN1_SUFFIX],'') NOT LIKE '' THEN ' ' + LTRIM(RTRIM([OWN1_SUFFIX])) ELSE '' END as [AssesseeStd1Name]
			,UPPER(LEFT(LTRIM(RTRIM([OWN2_LAST_NAME])) + CASE WHEN (ISNULL([OWN_CORP_IND_2],'') LIKE '' AND ISNULL(LTRIM(RTRIM([OWN2_FIRST_NAME_MI])),'') NOT LIKE '') THEN ', ' + LTRIM(RTRIM([OWN2_FIRST_NAME_MI])) ELSE '' END,80)) + CASE WHEN isNULL([OWN2_SUFFIX],'') NOT LIKE '' THEN ' ' + LTRIM(RTRIM([OWN2_SUFFIX])) ELSE '' END as [AssesseeStd2Name]
			,CASE WHEN ISNULL([OWN_NAME1_FULL],'') LIKE '' THEN NULL ELSE '2' END as [AssesseeNameIndicator]
			,CASE WHEN ISNULL([OWN_NAME2_FULL],'') LIKE '' THEN NULL ELSE '2' END as [AssesseeNameIndicator2]
			,Case When isNULL([HOMESTEAD_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [HomesteadInd]
			,Case When isNULL([VETERAN_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [VeteranInd]
			,Case When isNULL([DISABLED_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [DisabledInd]
			,Case When isNULL([WIDOW_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [WidowInd]
			,Case When isNULL([SENIOR_CITIZEN_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [SeniorInd]
			,Case When isNULL([SCHOOL_COLLEGE_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [SchoolCollegeInd]
			,Case When isNULL([RELIGIOUS_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [ReligiousInd]
			,Case When isNULL([WELFARE_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [WelfareInd]
			,Case When isNULL([UTILITIES_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [PublicUtilityInd]
			,Case When isNULL([CEMETERY_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [CemeteryInd]
			,Case When isNULL([HOSPITAL_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [HospitalInd]
			,Case When isNULL([LIBRARY_EXEMPTION],'') = 'Y' THEN 1 ELSE NULL End as [LibraryInd]
			,[OWN_ETAL_INDICATOR] as [OwnerEtALIndicator]
			,[OWNERSHIP_RIGHTS_CODE] as [OwnerStd1OwnershipRights]
			,[OWNER_RELATIONSHIP_TYPE] as [OwnerStd1RelationshipType]
			,LEFT(UPPER(RTrim(RTrim(LTrim(RTrim(RTrim(RTrim(RTrim(isNULL([MAIL_HOUSE_NBR],'') + ' ' + isNULL([MAIL_HOUSE_NBR_2],'')) + ' ' + isNULL([MAIL_HOUSE_NBR_SUFFIX],'')) + ' ' + isNULL([MAIL_DIRECTION],'')) + ' ' + isNULL([MAIL_STREET_NAME],''))) + ' ' + isNULL([MAIL_MODE],'')) + ' ' + isNULL([MAIL_QUADRANT],'')) + CASE WHEN isNULL([MAIL_UNIT_NBR],'') like '' THEN '' ELSE ' # ' + isNULL([MAIL_UNIT_NBR],'') END),116) as [MailingStdFullStreetAddress]
			,LEFT([MAIL_HOUSE_NBR],30) as [MailingStdHouseNbr]
			,NULL as [MailingStdHouseNbr2]
			,LEFT([MAIL_HOUSE_NBR_SUFFIX],10) as [MailingStdHouseNbrSuffix]
			,LEFT(UPPER([MAIL_DIRECTION]),2) as [MailingStdDirectionLeft]
			,LEFT(UPPER([MAIL_STREET_NAME]),60) as [MailingStdStreet]
			,LEFT(UPPER([MAIL_MODE]),10) as [MailingStdMode]
			,LEFT(UPPER([MAIL_QUADRANT]),2) as [MailingStdDirectionRight]
			,LEFT(UPPER([MAIL_UNIT_NBR]),15) as [MailingStdUnitNbr]
			,LEFT(UPPER([MAIL_CITY]),55) as [MailingStdCity]
			,LEFT(UPPER([MAIL_STATE]),2) as [MailingStdState]
			,LEFT([MAIL_ZIP_CODE],5) as [MailingStdZIP5]
			,LEFT([MAIL_CARRIER_CODE],4) as [MailingStdCarrierCode]
			,Case When [MAILING_OPT_OUT] = 'Y' THEN 1 ELSE 0 End as [MailingOptOut]
			,CASE WHEN CAST(CONVERT(MONEY,[ASSD_TOTAL_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[ASSD_TOTAL_VALUE]) as int) END as [AssdTotalValue]
			,CASE WHEN CAST(CONVERT(MONEY,[ASSD_LAND_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[ASSD_LAND_VALUE]) as int) END as [AssdLandValue]
			,CASE WHEN CAST(CONVERT(MONEY,[ASSD_IMPROVEMENT_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[ASSD_IMPROVEMENT_VALUE]) as int) END as [AssdImprovementValue]
			,CASE WHEN CAST(CONVERT(MONEY,[MKT_TOTAL_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[MKT_TOTAL_VALUE]) as int) END as [MarketTotalValue]
			,CASE WHEN CAST(CONVERT(MONEY,[MKT_LAND_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[MKT_LAND_VALUE]) as int) END as [MarketValueLand]
			,CASE WHEN CAST(CONVERT(MONEY,[MKT_IMPROVEMENT_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[MKT_IMPROVEMENT_VALUE]) as int) END as [MarketValueImprovement]
			,CASE WHEN CAST(CONVERT(MONEY,[APPR_TOTAL_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[APPR_TOTAL_VALUE]) as int) END as [ApprTotalValue]
			,CASE WHEN CAST(CONVERT(MONEY,[APPR_LAND_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[APPR_LAND_VALUE]) as int) END as [ApprLandValue]
			,CASE WHEN CAST(CONVERT(MONEY,[APPR_IMPROVEMENT_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[APPR_IMPROVEMENT_VALUE]) as int) END as [ApprImprovementValue]
			,CASE WHEN CAST(CONVERT(MONEY,[TAXABLE_TOTAL_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[TAXABLE_TOTAL_VALUE]) as int) END as [TaxTotalValue]
			,CASE WHEN CAST(CONVERT(MONEY,[TAXABLE_LAND_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[TAXABLE_LAND_VALUE]) as int) END as [TaxValueLand]
			,CASE WHEN CAST(CONVERT(MONEY,[TAXABLE_IMPROVEMENT_VALUE]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[TAXABLE_IMPROVEMENT_VALUE]) as int) END as [TaxValueImprovement]
			,CASE WHEN CAST(CONVERT(MONEY,[TOTAL_VALUE_CALCULATED]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[TOTAL_VALUE_CALCULATED]) as int) END as [UNVTotalValue]
			,CASE WHEN CAST(CONVERT(MONEY,[LAND_VALUE_CALCULATED]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[LAND_VALUE_CALCULATED]) as int) END as [UNVLandValue]
			,CASE WHEN CAST(CONVERT(MONEY,[IMPROVEMENT_VALUE_CALCULATED]) as bigint) > 2000000000 THEN NULL ELSE CAST(CONVERT(MONEY,[IMPROVEMENT_VALUE_CALCULATED]) as bigint) END as [UNVImprovementValue]
			,[ASSESSED_YEAR] as [UNVValueYear]
			,CASE WHEN isNULL([MKT_TOTAL_VALUE],'0') = '0' THEN NULL ELSE [ASSESSED_YEAR] END as [MarketValueYear]
			,CASE WHEN isNULL([APPR_TOTAL_VALUE],'0') = '0' THEN NULL ELSE [ASSESSED_YEAR] END as [ApprYear]
			,CASE WHEN convert(bigint,Convert(Money,[TAX_AMOUNT])*100) > 20000000000 THEN NULL ELSE [TAX_AMOUNT]*100 END as [TaxAmount]
			,[TAX_YEAR] as [TaxYear]
			,CASE WHEN convert(bigint,Convert(Money,[DELINQUENT_TAX_VALUE])*100) > 200000000 THEN NULL ELSE convert(int,[DELINQUENT_TAX_VALUE]*100) END as [TaxDeliquentValue1]
			,[DELINQUENT_TAX_YEAR] as [TaxDeliquentYear1]
			,[ASSESSED_YEAR] as [AssdYear]
			,[TAX_CODE_AREA] as [TaxRateCodeArea]
			,convert(varchar(10),convert(bigint,Convert(Money,CASE WHEN [FRONT_FOOTAGE] in(NULL,'')THEN '0' ELSE [FRONT_FOOTAGE] END)*10)) as [LotSizeFrontageFeet]
			,convert(varchar(10),convert(bigint,Convert(Money,CASE WHEN [DEPTH_FOOTAGE] in(NULL,'')THEN '0' ELSE [DEPTH_FOOTAGE] END)*10)) as [LotSizeDepthFeet]
			,LEFT([ACRES],10) as [LotSizeAcres]
			,CASE WHEN convert(Money,[LAND_SQUARE_FOOTAGE]) > 2000000000 THEN NULL ELSE cast(convert(money,[LAND_SQUARE_FOOTAGE]) as int) END as [LotSizeSqFt]
			,CASE WHEN [IRREGULAR_LOT_FLAG] = 'Y' Then 1 Else 0 End as [LotIrregularInd]
			,cast(isNULL(CASE WHEN [USABLE_LOT_SIZE] LIKE '' THEN NULL ELSE [USABLE_LOT_SIZE] END,0) as numeric) as [LotUsableSize]
			,[UNIVERSAL_BUILDING_SQUARE_FEET] as [BuildingArea]
			,[BUILDING_SQUARE_FEET_IND] as [BuildingAreaInd]
			,[SUM_OF_ABOVE_LIVING_SQUARE_FOOTAGE] as [SumAboveGradeLivingSqFt]
			,[SUM_OF_ADJUSTED_GROSS_SQUARE_FEET] as [SumAdjAreaSqFt]
			,[SUM_OF_BUILDING_SQUARE_FEET] as [SumBuildingSqFt]
			,[SUM_OF_LIVING_SQUARE_FEET] as [SumLivingAreaSqFt]
			,[SUM_OF_GROUND_FLOOR_SQUARE_FEET] as [SumGroundFloorSqFt]
			,[SUM_OF_GROSS_SQUARE_FEET] as [SumGrossAreaSqFt]
			,[SUM_OF_BASEMENT_SQUARE_FEET] as [SumBasementSqFt]
			,[SUM_OF_GARAGE_PARKING_SQUARE_FEET] as [SumGarageSqFt]
			,[YEAR_BUILT] as [YearBuilt]
			,[EFFECTIVE_YEAR_BUILT] as [EffectiveYearBuilt]
			,cast([SUM_OF_BEDROOMS] as int) as [Bedrooms]
			,cast([SUM_OF_TOTAL_ROOMS] as int) as [TotalRooms]
			,NULL as [BathTotalCalc]
			,[FULL_BATHS] as [BathFull]
			,NULL as [BathsParcialNbr]
			,[HALF_BATHS] as [BathHalf]
			,[1QTR_BATHS] as [Bath1QTR]
			,[3QTR_BATHS] as [Bath3QTR]
			,[BATH_FIXTURES] as [BathFixturesNbr]
			,[AIR_CONDITIONING] as [AirConditioningCode]
			,[BASEMENT_FINISH] as [BasementCode]
			,NULL --[BLDG_CODE] as [BuildingClassCode]
			,REPLACE([CONDITION],'.0','') as [BuildingConditionCode]
			,[CONSTRUCTION_TYPE] as [ConstructionTypeCode]
			,[ELECTRIC_ENERGY] as [ElectricityCode]
			,[EXTERIOR_WALLS] as [ExteriorWallsCode]
			,[FIREPLACE_IND] as [FireplaceCode]
			,CASE WHEN [FLOOR] LIKE '0%' THEN [FLOOR] ELSE NULL END as [FloorCoverCode]
			,CASE WHEN [FLOOR] NOT LIKE '0%' THEN [FLOOR] ELSE NULL END as [FloorTypeCode]
			,[FOUNDATION] as [FoundationInd]
			,[FRAME] as [FrameCode]
			--,[FUEL] as [HeatingFuelTypeCode]
			,[GARAGE] as [Garage]
			,[HEATING] as [HeatCode]
			,[HEATING] as [HeatingFuelTypeCode]
			,[LOCATION_INFLUENCE] as [SiteInfluenceCode]
			,Convert(int,Convert(money,[PARKING_SPACES])) as [GarageParkingNbr]
			,[PATIO_CODE] as [PatioCode]
			,[POOL_CODE] as [PoolCode]
			,[PORCH_CODE] as [PorchCode]
			,[QUALITY] as [BuildingQualityCode]
			,[ROOF_COVER] as [RoofCoverCode]
			,[ROOF_TYPE] as [RoofTypeCode]
			,[SEWER] as [SewerCode]
			,[STORIES_CODE] as [StoriesCode]
			,[STORIES_NBR] as [StoriesNbrCode]
			,[STYLE] as [StyleCode]
			,[NBR_OF_RES_UNITS] as [SumResidentialUnits]
			,[SUM_OF_STRUCTURE_NBR] as [SumBuildingsNbr]
			,[NBR_OF_BUS_COMM_UNITS] as [SumCommercialUnits]
			,[VIEW_ASSR] as [ViewCode]
			,[WATER] as [WaterCode]
			,'D' as [TaxSourceInd]
			,'C' as [FAUCIDFlag]
			,convert(varchar(8),GetDate(),112) as [FADateReceived]
			,CASE WHEN isNULL(ALTERNATE_APN,'') NOT LIKE '' THEN 'A' WHEN isNULL([PREVIOUS_PARCEL_NBR],'') NOT LIKE '' THEN 'O' ELSE '' END as [OldApnIndicator] 
			,cast(GETDATE() as date) FATimestamp
			,'D' FASourceInd
			,[Created]
			,Convert(varchar(8),[CREATED],112)
			,Certification_Date
			FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] with(NOLOCK)

			CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [dbo].[PropertyWorkUpdateTbl]
			(
				[FIPS] ASC,
				[PropertyID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			CREATE NONCLUSTERED INDEX [ix_FipsDTDB_Ref_ID] ON [dbo].[PropertyWorkUpdateTbl]
			(
				[FIPS] ASC,
				[DTDB_Ref_ID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


		UPDATE a
		SET PropertyID = b.PropertyID
		from dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		on a.Fips = b.Fips
		and a.DTDB_REF_ID = b.DTDB_REF_ID
		WHERE isNULL(a.PropertyID,0) = 0

		UPDATE a
		SET PropertyID = b.PropertyID
		from dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		on a.Fips = b.Fips
		and a.TaxAccountNumber = b.TaxAccountNumber
		WHERE isNULL(a.PropertyID,0) = 0

		UPDATE a
		SET PropertyID = b.PropertyID
		from dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		on a.Fips = b.Fips
		and a.OldAPN = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0

		UPDATE a
		SET PropertyID = b.FAPropertyParent
		from dbo.PropertyWorkUpdateTbl a JOIN [Global].dbo.Property_Master b with(NOLOCK)
		on a.Fips = b.Fips
		and a.TaxAccountNumber = b.TaxAccountNumber
		WHERE isNULL(a.PropertyID,0) = 0

		UPDATE a
		SET PropertyID = b.FAPropertyParent
		from dbo.PropertyWorkUpdateTbl a JOIN [Global].dbo.Property_Master b with(NOLOCK)
		on a.Fips = b.Fips
		and a.TaxAccountNumber = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0

		UPDATE a
		SET a.CountyLandUseDescription = b.[Code_Description]
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on a.StdLandUseCode = b.[Value]
		WHERE b.CODE = 'LUSE' 

		UPDATE dbo.PropertyWorkUpdateTbl
		SET StdLandUseCode = '1105'
		Where StdLandUseCode = '131'
		and [SumResidentialUnits] >= 100

		UPDATE dbo.PropertyWorkUpdateTbl
		SET StdLandUseCode = '1104'
		Where StdLandUseCode = '133'
		and [SumResidentialUnits] >= 5

		UPDATE a
		SET [StdLandUseCode] = b.[FlankCode]
		,[PropertyClassID] = b.[PropClassID]
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.LandUseLookup b
		on a.[StdLandUseCode] = b.[Value]

		UPDATE a
		SET LotSizeAcres = Right('0000000000' + convert(varchar(10),Convert(BigInt,Convert(money,LotSizeAcres)*1000)),10)
		FROM dbo.PropertyWorkUpdateTbl a 
		WHERE (LotSizeAcres not like '00%' and Len(Convert(money,LotSizeAcres)*1000) < 10)
		or LotSizeAcres like '%.%'


		UPDATE a
		SET a.Garage = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where ASSR_table_FieldName LIKE '%Garage%') b
		on a.Garage = b.[Value]
		WHERE a.Garage is not null and b.[Value] is NULL
		
		UPDATE a
		SET a.Garage = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on a.Garage = b.[Value]
		Where ASSR_table_FieldName LIKE '%Garage%'

		UPDATE a
		SET a.AirConditioningCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where ASSR_table_FieldName LIKE 'AIR_CONDITIONING') b
		on Ltrim(Rtrim(a.AirConditioningCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.AirConditioningCode)) is not NULL and b.[Value] is NULL
		
		UPDATE a
		SET a.AirConditioningCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.AirConditioningCode)) = b.[Value]
		Where ASSR_table_FieldName LIKE 'AIR_CONDITIONING'


		UPDATE a
		SET a.AirConditioningTypeCode = CASE WHEN AirConditioningCode = 2 THEN 1
		WHEN AirConditioningCode = 9 THEN 5
		WHEN AirConditioningCode = 14 THEN 2
		WHEN AirConditioningCode = 10 THEN 3
		WHEN AirConditioningCode = 11 THEN 4
		ELSE NULL END
		FROM dbo.PropertyWorkUpdateTbl a
		WHERE a.AirConditioningCode is not null

		UPDATE a
		SET a.BasementFinishedCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'BSMTF') b
		on Ltrim(Rtrim(a.BasementFinishedCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.BasementFinishedCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.BasementFinishedCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.BasementCode)) = b.[Value]
		Where Code LIKE 'BSMTF'
		and BasementFinishedCode is NULL

		UPDATE a
		SET a.BasementCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'BSMT') b
		on Ltrim(Rtrim(a.BasementCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.BasementCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.BasementCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.BasementCode)) = b.[Value]
		Where Code LIKE 'BSMT'

		UPDATE a
		SET a.BuildingConditionCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'COND') b
		on Ltrim(Rtrim(a.BuildingConditionCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.BuildingConditionCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.BuildingConditionCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.BuildingConditionCode)) = b.[Value]
		Where Code LIKE 'COND'

		UPDATE a
		SET a.BuildingQualityCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'QUAL') b
		on Ltrim(Rtrim(a.BuildingQualityCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.BuildingQualityCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.BuildingQualityCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.BuildingQualityCode)) = b.[Value]
		Where Code LIKE 'QUAL'


		UPDATE a
		SET a.ConstructionTypeCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'CNSTR') b
		on Ltrim(Rtrim(a.ConstructionTypeCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.ConstructionTypeCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.ConstructionTypeCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.ConstructionTypeCode)) = b.[Value]
		Where Code LIKE 'CNSTR'

		UPDATE a
		SET a.ElectricityCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'ELEC') b
		on Ltrim(Rtrim(a.ElectricityCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.ElectricityCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.ElectricityCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.ElectricityCode)) = b.[Value]
		Where Code LIKE 'ELEC'

		UPDATE a
		SET a.ExteriorWallsCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'EXTNW') b
		on Ltrim(Rtrim(a.ExteriorWallsCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.ExteriorWallsCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.ExteriorWallsCode = b.FLANKCode
		,a.WallExteriorCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.ExteriorWallsCode)) = b.[Value]
		Where Code LIKE 'EXTNW'

		UPDATE a
		SET a.FireplaceCode = 1
		FROM dbo.PropertyWorkUpdateTbl a
		WHERE FireplaceCode = 'Y'

		UPDATE a
		SET a.FloorCoverCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'FLTYP') b
		on Ltrim(Rtrim(a.FloorCoverCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.FloorCoverCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.FloorCoverCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.FloorCoverCode)) = b.[Value]
		Where Code LIKE 'FLTYP'

		UPDATE a
		SET a.FloorTypeCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'FLTYP') b
		on Ltrim(Rtrim(a.FloorTypeCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.FloorTypeCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.FloorTypeCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.FloorTypeCode)) = b.[Value]
		Where Code LIKE 'FLTYP'

		UPDATE a
		SET a.FoundationInd = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'FOUND') b
		on Ltrim(Rtrim(a.FoundationInd)) = b.[Value]
		WHERE Ltrim(Rtrim(a.FoundationInd)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.FoundationInd = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.FoundationInd)) = b.[Value]
		Where Code LIKE 'FOUND'

		UPDATE a
		SET a.FrameCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN [Global].[dbo].[lkup_Frame_Type] b
		on Ltrim(Rtrim(a.FrameCode)) = b.[FACode]
		WHERE Ltrim(Rtrim(a.FrameCode)) is not NULL and b.[FACode] is NULL

		UPDATE a
		SET a.FrameCode = b.FrameTypeID
		FROM dbo.PropertyWorkUpdateTbl a JOIN [Global].[dbo].[lkup_Frame_Type] b
		on Ltrim(Rtrim(a.FrameCode)) = b.[FACode]

		UPDATE a
		SET a.HeatCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'HEAT') b
		on Ltrim(Rtrim(a.HeatCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.HeatCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.HeatCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.HeatCode)) = b.[Value]
		Where Code LIKE 'HEAT'

		UPDATE a
		SET a.HeatingFuelTypeCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'HEAT') b
		on Ltrim(Rtrim(a.HeatingFuelTypeCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.HeatingFuelTypeCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.HeatingFuelTypeCode = b.FLANKCodeII
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.HeatingFuelTypeCode)) = b.[Value]
		Where Code LIKE 'HEAT'

		UPDATE a
		SET a.PorchCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'Porch') b
		on Ltrim(Rtrim(a.PorchCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.PorchCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.PorchCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.PorchCode)) = b.[Value]
		Where Code LIKE 'Porch'

		UPDATE a
		SET a.PoolCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'Pool') b
		on Ltrim(Rtrim(a.PoolCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.PoolCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.PoolCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.PoolCode)) = b.[Value]
		Where Code LIKE 'Pool'

		Update dbo.PropertyWorkUpdateTbl
		SET DeckCode = 1
		WHERE PatioCode in('3A0','30B','30D','30O','30C','80C','30I','3C0','9C0','ZC0','7C0','3CW','300','500'
		,'400','Z00','901','700','800','3D0','3DW','3E0','7E0','7Z0','30R','30M','3O0','3OW','3R0','3RW'
		,'30S','80S','9','30Z','30L','3U0','30W','50W','90W','Z0W')

		UPDATE a
		SET a.PatioCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'PATIO') b
		on Ltrim(Rtrim(a.PatioCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.PatioCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.PatioCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.PatioCode)) = b.[Value]
		Where Code LIKE 'PATIO'

		UPDATE a
		SET a.RoofCoverCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'RFCOV') b
		on Ltrim(Rtrim(a.RoofCoverCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.RoofCoverCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.RoofCoverCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.RoofCoverCode)) = b.[Value]
		Where Code LIKE 'RFCOV'

		UPDATE a
		SET a.RoofCoverCode = '15'
		FROM dbo.PropertyWorkUpdateTbl a
		Where RoofCoverCode LIKE 'A'

		UPDATE a
		SET a.RoofTypeCode = b.FLANKCode
		,a.RoofCoverCode = CASE WHEN a.RoofCoverCode is NULL THEN b.FlankCodeII Else a.RoofCoverCode END
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.RoofTypeCode)) = b.[Value]
		Where Code LIKE 'RFCO'

		UPDATE a
		SET a.SewerCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'SEWER') b
		on Ltrim(Rtrim(a.SewerCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.SewerCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.SewerCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.SewerCode)) = b.[Value]
		Where Code LIKE 'SEWER'

		UPDATE a
		SET a.StyleCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'STYLE') b
		on Ltrim(Rtrim(a.StyleCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.StyleCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.StyleCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.StyleCode)) = b.[Value]
		Where Code LIKE 'STYLE'

		UPDATE a
		SET a.WaterCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'WATER') b
		on Ltrim(Rtrim(a.WaterCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.WaterCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.WaterCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.WaterCode)) = b.[Value]
		Where Code LIKE 'WATER'

		UPDATE a
		SET a.StoriesNbrCode = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where Code LIKE 'STORY') b
		on Ltrim(Rtrim(a.StoriesCode)) = b.[Value]
		WHERE Ltrim(Rtrim(a.StoriesNbrCode)) is not NULL and b.[Value] is NULL

		UPDATE a
		SET a.StoriesNbrCode = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.StoriesCode)) = b.[Value]
		Where Code LIKE 'STORY'

		UPDATE [dbo].[PropertyWorkUpdateTbl]
		SET StoriesNbrCode = NULL,StoriesCode = NULL
		WHERE StoriesNbrCode not in(Select FACode from Global.dbo.lkup_StoriesNbrCode_FA)

		Update [dbo].PropertyWorkUpdateTbl
		SET EffectiveYearBuilt = YearBuilt
		where isNULL(EffectiveYearBuilt,'') like '' and isNULL(YearBuilt,'') not like ''

		UPDATE a
		SET a.OwnerStd1RelationshipType = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.OwnerStd1RelationshipType)) = b.[Value]
		Where ASSR_table_FieldName LIKE '%Relation%'
	
		UPDATE a
		SET a.OwnerStd1RelationshipType = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where ASSR_table_FieldName LIKE '%Relation%') b
		on a.OwnerStd1RelationshipType = b.[Value]
		WHERE a.OwnerStd1RelationshipType is not null and b.[Value] is NULL
		

		UPDATE a
		SET a.OwnerStd1OwnershipRights = b.FLANKCode
		FROM dbo.PropertyWorkUpdateTbl a JOIN dbo.Assr_Codes b
		on Ltrim(Rtrim(a.OwnerStd1OwnershipRights)) = b.[Value]
		Where ASSR_table_FieldName LIKE '%Rights%'
	
		UPDATE a
		SET a.OwnerStd1OwnershipRights = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where ASSR_table_FieldName LIKE '%Rights%') b
		on a.OwnerStd1OwnershipRights = b.[Value]
		WHERE a.OwnerStd1OwnershipRights is not null and b.[Value] is NULL
		

		UPDATE a
		SET a.BuildingAreaInd = [FlankCode]
		FROM dbo.PropertyWorkUpdateTbl a JOIN (Select * from dbo.Assr_Codes Where [Code] = 'BLDSF') b
		on a.BuildingAreaInd = b.[Value]
		WHERE isNULL(a.BuildingAreaInd,'') not like ''

		UPDATE a
		SET a.BuildingAreaInd = NULL
		FROM dbo.PropertyWorkUpdateTbl a LEFT OUTER JOIN (Select * from dbo.Assr_Codes Where [Code] = 'BLDSF') b
		on a.BuildingAreaInd = b.[Value]
		WHERE isNULL(a.BuildingAreaInd,'') not like '' and b.FlankCode is NULL


		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'D'
		WHERE HomesteadInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET CalifHomeownerInd = 1
		WHERE HomesteadInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'C'
		WHERE CemeteryInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'B'
		WHERE DisabledInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'T'
		WHERE HospitalInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'L'
		WHERE LibraryInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'P'
		WHERE PublicUtilityInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'R'
		WHERE ReligiousInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'S'
		WHERE SchoolCollegeInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'F'
		WHERE SeniorInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'V'
		WHERE VeteranInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'W'
		WHERE WelfareInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxExemptionCode = isNULL(TaxExemptionCode,'') + 'Z'
		WHERE WidowInd = 1

		UPDATE dbo.PropertyWorkUpdateTbl
		SET TaxexemptInd = 1
		Where isNULL(TaxExemptionCode,'') not like ''

		UPDATE dbo.PropertyWorkUpdateTbl
		SET BathsParcialNbr = convert(int,Convert(money,isNULL(BathHalf,0)) + convert(money,isNULL(Bath1QTR,0)) + convert(Money,isNULL(Bath3QTR,0)))

		UPDATE dbo.PropertyWorkUpdateTbl
		SET BathTotalCalc = convert(numeric(5,2),convert(money,bathfull) 
			+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
				+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
					+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end)
		WHERE convert(money,convert(money,bathfull) 
			+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
				+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
					+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end) < 500

		UPDATE dbo.PropertyWorkUpdateTbl
		SET BathTotalCalc = CEILING(convert(Money,BathFixturesNbr)/3)
		WHERE isNULL(BathTotalCalc ,0) = 0
		and isNULL(BathFixturesNbr,0) > 0
		and LEN(BathFixturesNbr) < 4


		UPDATE dbo.PropertyWorkUpdateTbl
		SET [AssdLandValue] =  case when convert(money,[AssdLandValue]) > 2000000000 then NULL ELSE convert(int,convert(money,[AssdLandValue])) END
		  ,[AssdImprovementValue] = case when convert(money,[AssdImprovementValue]) > 2000000000 then NULL ELSE  convert(int,convert(money,[AssdImprovementValue])) END
		  ,[AssdTotalValue] = case when convert(money,[AssdTotalValue]) > 2000000000 then NULL ELSE convert(int,convert(money,[AssdTotalValue])) End
		  ,[MarketValueLand] = case when convert(money,[MarketValueLand]) > 2000000000 then NULL ELSE  convert(int,convert(money,[MarketValueLand])) END
		  ,[MarketValueImprovement] = case when convert(money,[MarketValueImprovement]) > 2000000000 then NULL ELSE convert(int,convert(money,[MarketValueImprovement])) END
		  ,[MarketTotalValue] = case when convert(money,[MarketTotalValue]) > 2000000000 then NULL ELSE  convert(int,convert(money,[MarketTotalValue])) END
		  ,[ApprLandValue] = case when convert(money,[ApprLandValue]) > 2000000000 then NULL ELSE  convert(int,convert(money,[ApprLandValue])) END
		  ,[ApprImprovementValue] = case when convert(money,[ApprImprovementValue]) > 2000000000 then NULL ELSE  convert(int,convert(money,[ApprImprovementValue])) END
		  ,[ApprTotalValue] = case when convert(money,[ApprTotalValue]) > 2000000000 then NULL ELSE  convert(int,convert(money,[ApprTotalValue])) END
		  --,[TaxDeliquentValue1] = replace([TaxDeliquentValue1],'.','')


			UPDATE dbo.PropertyWorkUpdateTbl
			SET RoofTypeCode = NULL
			Where RoofTypeCode in('A','NEN','NUL')
		
			update PropertyWorkUpdateTbl
			SET [FireplaceCode] = NULL
			Where [FireplaceCode] like 'N'
			
			
			update p
			SET p.siteInfluenceCode = a.SiteInfluenceId
			FROM dbo.PropertyWorkUpdateTbl p with(NOLOCK) JOIN global.dbo.lkup_Site_Influence a with(NOLOCK)
			on p.SiteInfluenceCode = a.FACode
			WHERE isNULL(SiteInfluenceCode,'') Not like ''

			UPDATE dbo.PropertyWorkUpdateTbl
			SET SiteInfluenceCode = NULL
			where isNULL(SiteInfluenceCode,'') Not in(Select cast(SiteInfluenceId as varchar) from Global.dbo.lkup_Site_Influence)
			and isNULL(SiteInfluenceCode,'') Not like ''

			UPDATE a
			SET a.CountyLandUseDescription = LEFT(b.COUNTY_LAND_USE_CODE_DISCRIPTION,45)
			,a.CountyLandUseCode = LEFT(b.COUNTY_LAND_USE_CODE,10)
			FROM dbo.PropertyWorkUpdateTbl a JOIN [DWS-ETL02].[DRAGON_Wrk].[dbo].[Assr_Land_Use] b with(NOLOCK)
			on a.FIPS = b.FIPS
			and a.UnformattedAPN = b.UNFORMATTED_APN

			UPDATE a
			SET a.LegalDescription = LEFT(b.[LEGAL_DESCRIPTION],2000)
			FROM dbo.PropertyWorkUpdateTbl a JOIN [DWS-ETL02].[DRAGON_Wrk].[dbo].[Assr_Extended_Legal] b with(NOLOCK)
			on a.FIPS = b.FIPS
			and a.UnformattedAPN = b.UNFORMATTED_APN
			WHERE b.[LEGAL_SEQUENCE_NUMBER] = 1

			
		UPDATE [dragonassr].[dbo].PropertyWorkUpdateTbl
			SET LotSizeAcres = RIGHT('0000000000' + cast(cast(ROUND((cast(LotSizeSqFt as money)/43560)*1000,0) as int) as varchar),10)
			where lotsizeacres like '%.'



END

