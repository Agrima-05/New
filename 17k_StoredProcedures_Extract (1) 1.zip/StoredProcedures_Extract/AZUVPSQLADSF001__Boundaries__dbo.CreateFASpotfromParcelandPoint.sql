SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[CreateFASpotfromParcelandPoint]
AS
BEGIN

	SET NOCOUNT ON;

		-------- Find New Spot data

			DROP TABLE IF EXISTS dbo.FASpotStats

			Select FIPS,FATimestamp as LoadDate,Count(*) as RecordCount,SUM(CASE WHEN PropertyID is not null then 1 ELSE 0 END) as HasPropertyID,'N' as RefreshMe
			INTO dbo.FASpotStats
			 from dbo.FASpot with(NOLOCK) 
			 group by fips,FATimestamp order by FIPS

			 CREATE UNIQUE INDEX [ix_FIPS] on dbo.FASpotStats(FIPS)

			 EXEC('UPDATE b
			 SET b.RefreshMe = ''Y''
			 from [AZUVPSQLDTDB034].[NG911].dbo.Spt_Delivery a JOIN dbo.FASpotStats b
			 on a.FIPS = b.FIPS
			 where DeliveryDate > LoadDate
			 ')

		------- PULL New Spot data
		DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE FIPSCode in(SELECT FIPS FROM dbo.FASpotStats where RefreshMe = 'Y')
			ORDER BY [FIPSCode]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC('
			DROP table if Exists dlvry.Parcel_UPD

			Select * 
			INTO dlvry.Parcel_UPD
			from Openquery([AZUVPSQLDTDB034],''Select * FROM [Spot].[dlvry].[Parcel] with(NOLOCK) where Fips = ''' + @Fipscode + ''''')

			alter table dlvry.Parcel_UPD add PropertyID bigint,REF_ID bigint
			
			CREATE INDEX ix_FIPS ON dlvry.Parcel_UPD(FIPS)

			DROP table if Exists dlvry.Point_UPD

			Select * 
			INTO dlvry.Point_UPD
			from Openquery([AZUVPSQLDTDB034],''Select * FROM [Spot].[dlvry].[Point] with(NOLOCK) where Fips = ''' + @Fipscode + ''''')

			alter table dlvry.Point_UPD add PropertyID bigint

			CREATE INDEX ix_FIPS ON dlvry.Point_UPD(FIPS)
			')

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 



		------- LINK PARCEL
		BEGIN
			---- APN
				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.FormattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.UNFormattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.TaxAccountNumber
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.OldAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.DTDB_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.DTDB_UNFORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.CS_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn = b.CS_UNFORMATTED_APN
				Where a.PropertyID is NULL

			---- APN1
				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.FormattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.UnformattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.TaxAccountNumber
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.OldAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.DTDB_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.DTDB_UNFORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.CS_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn1 = b.CS_UNFORMATTED_APN
				Where a.PropertyID is NULL

			---- APN2
				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.FormattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.UnformattedAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.TaxAccountNumber
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.OldAPN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.DTDB_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.DTDB_UNFORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.CS_FORMATTED_APN
				Where a.PropertyID is NULL

				update a
				SET a.PropertyID = b.PropertyID
				,a.REF_ID = b.DTDB_REF_ID
				From dlvry.Parcel_UPD a JOIN data.dbo.Property b with(NOLOCK)
				on a.fips = b.fips
				and a.Apn2 = b.CS_UNFORMATTED_APN
				Where a.PropertyID is NULL

			END

		------- LINK POINT
			BEGIN
					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.refid = b.dtdb_ref_id 
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.FormattedAPN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.UNFormattedAPN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.FormattedAPN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.UNFormattedAPN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.DTDB_FORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.DTDB_UNFORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.DTDB_FORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.DTDB_UNFORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.CS_FORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.FormattedApn = b.CS_UNFORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.CS_FORMATTED_APN
					Where a.PropertyID is NULL

					update a
					SET a.PropertyID = b.PropertyID
					From dlvry.Point_UPD a JOIN data.dbo.Property b with(NOLOCK)
					on a.fips = b.fips
					and a.UnformattedApn = b.CS_UNFORMATTED_APN
					Where a.PropertyID is NULL

			END





		--DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE FIPSCode in(SELECT FIPS FROM dbo.FASpotStats where RefreshMe = 'Y')
			ORDER BY [FIPSCode]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC('DELETE FROM [Boundaries].[dbo].[FASpot] WERE FIPS = '''+ @FipsCode +'''')

			EXEC('INSERT INTO [Boundaries].[dbo].[FASpot]
				   ([FADigitalMapMasterId]
				   ,[PropertyID]
				   ,[APN]
				   ,[FIPS]
				   ,[Longitude]
				   ,[Latitude]
				   ,[ParcelGeography]
				   ,[ParcelGeometry]
				   ,[ParcelPointGeography]
				   ,[ParcelPointGeometry]
				   ,[EstLotSizeSqFt]
				   ,[AddressScore]
				   ,[GeoSource]
				   ,[PARCELAPN]
				   ,[FAGeoStatusCode]
				   ,[LatLonGeometry]
				   ,[DmDate]
				   ,[MatchCode]
				   ,[UpdateFlag]
				   ,[RefId]
				   ,[PRCLDMPID]
				   ,[PROPDMPID]
				   ,[ParcelGeometry4269]
				   ,[ParcelPointGeometry4269]
				   ,[FATimestamp]
				   ,[GeomWKT]
				   ,[UCIDFlag]
				   ,[PointWKT])
		Select 
					[Id]   --<int,>
				   ,r.[PropertyID]  --<PropertyID, bigint,>
				   ,substring(r.[Apn],1,45)  --<APN, varchar(45),>
				   ,substring(r.[fips],1,5)  --<FIPS, varchar(5),>
				   ,b.[Longitude]  --<Longitude, float,>
				   ,b.[Latitude]  --<Latitude, float,>
				   ,null  --<ParcelGeography, geography,>
				   ,r.[GEOM]  --<ParcelGeometry, geometry,>
				   ,NULL --<ParcelPointGeography, geography,>
				   ,b.[GEOM]  --<ParcelPointGeometry, geometry,>
				   ,r.[Sqft]  --<EstLotSizeSqFt, bigint,>
				   ,null  --<AddressScore, varchar(1),>
				   ,''Parcels''  --<GeoSource, varchar(30),>
				   ,substring(r.Apn,1,50)  --,<PARCELAPN, varchar(50),>
				   ,''P''  --<FAGeoStatusCode, varchar(20),>
				   ,null  --<LatLonGeometry, geometry,>
				   ,convert(varchar(8),Getdate()-1,112)  --<DmDate, varchar(8),>
				   ,null  --<MatchCode, varchar(20),>
				   ,''I''  --<UpdateFlag, varchar(16),>
				   ,[Ref_ID]  --<RefId, bigint,>
				   ,null  --<PRCLDMPID, varchar(50),>
				   ,null  --<PROPDMPID, varchar(50),>
				   ,geometry::STGeomFromText(r.[Geom].STAsText(),4269)  --<ParcelGeometry4269, geometry,>
				   ,geometry::STGeomFromText(b.[Geom].STAsText(),4269)  --<ParcelPointGeometry4269, geometry,>
				   ,GetDAte()  --<FATimestamp, datetime,>
				   ,r.[Geom].MakeValid().STUnion(r.[Geom].STStartPoint()).STAsText()  --<GeomWKT, varchar(max),>
				   ,''I''  --<UCIDFlag, char(1),>
				   ,b.[Geom].MakeValid().STUnion(b.[Geom].STStartPoint()).STAsText()  --<PointWKT, varchar(max),>)
		FROM (Select * FROM [dlvry].[Parcel_UPD] with(NOLOCK) WHERE Fips = '''+ @FipsCode +''') r
		Left outer JOIN (Select * FROM [dlvry].[Point_UPD] with(NOLOCK) WHERE Fips = '''+ @FipsCode +''') b
		on r.Fips = b.Fips
		and r.PropertyID = b.PropertyID
		')

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 


		DROP TABLE IF EXISTS dbo.FASpot_MaxDates

		Select *
		INTO dbo.FASpot_MaxDates
		 FROM (Select FIPS,Max(CreatedDate) as MaxCreated,Max(UpdatedDate) as MaxUpdated from FASpot with(NOLOCK) Group by FIPS 
		UNION ALL
		Select FIPS,Max(CreatedDate) as MaxCreated,Max(UpdatedDate) as MaxUpdated from FASpot_a with(NOLOCK) Group by FIPS ) info
		ORDER BY FIPS




END


--Select Fips,Count(*) from FASpot where FIPS like '21%' group by fips order by FIPS
