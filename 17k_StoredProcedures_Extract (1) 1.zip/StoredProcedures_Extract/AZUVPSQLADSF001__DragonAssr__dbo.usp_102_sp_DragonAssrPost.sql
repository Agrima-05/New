SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
			CREATE procedure [dbo].[usp_102_sp_DragonAssrPost] (@tableName varchar(40)) 
			as  
			declare @sql varchar(max) = ''

			
				set @sql = '
				SET CONCAT_NULL_YIELDS_NULL OFF

				   UPDATE [DragonAssr].[dbo].[DragonAssr_STD]
				  set [FullStreetAddress] = LEFT(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(Ltrim(Rtrim([StreetNumber])) + '' '' + 
						  Ltrim(Rtrim(UPPER([PreDir])))) + '' '' + 
						  Ltrim(Rtrim(UPPER([StreetName])))) + '' '' + 
						  Ltrim(Rtrim(UPPER([StreetType])))) + '' '' + 
						  Ltrim(Rtrim(UPPER([PostDir])))) + '' '' + 
						  Ltrim(Rtrim(UPPER(case when (len(PrivateMailbox) > 0 and ISNULL([PrivateMailbox],'''') not like '''') and [PrivateMailbox] is not null then ''PMB''
								else UPPER(Ltrim(Rtrim([SuiteType]))) end)))) + '' '' + 
						  Ltrim(Rtrim(UPPER(case when len([PrivateMailbox]) > 0 and ISNULL([PrivateMailbox],'''') not like '''' and [PrivateMailbox] is not null then Ltrim(Rtrim([PrivateMailbox]))
								else UPPER(Ltrim(Rtrim([Suite]))) end)))),116)
					,[CountyFips] = Ltrim(Rtrim([CountyFips]))
					,[StreetNumber] = Ltrim(Rtrim([StreetNumber]))
					,[PreDir] = Ltrim(Rtrim([PreDir]))
					,[StreetName] = Ltrim(Rtrim([StreetName]))
					,[StreetType] = Ltrim(Rtrim([StreetType]))
					,[PostDir] = Ltrim(Rtrim([PostDir]))
					,[SuiteType] = case when len(PrivateMailbox) > 0 
								and ISNULL([PrivateMailbox],'''') not like ''''
								and [PrivateMailbox] is not null then 
								''PMB''
								else UPPER(Ltrim(Rtrim([SuiteType])))
								end
					,[Suite] = case when len([PrivateMailbox]) > 0 
								and ISNULL([PrivateMailbox],'''') not like ''''
								and [PrivateMailbox] is not null then 
								Ltrim(Rtrim([PrivateMailbox]))
								else Ltrim(Rtrim([Suite])) 
								end
					,[City] = Ltrim(Rtrim([City]))
					,[State] = Ltrim(Rtrim([State]))
					,[Zip] = Ltrim(Rtrim([Zip]))
					,[Plus4] = Ltrim(Rtrim([Plus4]))
					,[CarrierRoute] = Ltrim(Rtrim([CarrierRoute]))
					,[CountyName] = Ltrim(Rtrim([CountyName]))
					,[PrivateMailbox] = Ltrim(Rtrim([PrivateMailbox]))
					,[Pmsa] = Ltrim(Rtrim([Pmsa]))
					,[Msa] = Ltrim(Rtrim([Msa]))
					,[ZipType] = Ltrim(Rtrim([ZipType]))
					,[Urbanization] = Ltrim(Rtrim([Urbanization]))
					,[CongressionalDistrict] = Ltrim(Rtrim([CongressionalDistrict]))
					,[CityAbbreviation] = Ltrim(Rtrim([CityAbbreviation]))
					,[AddressTypeCode] = Ltrim(Rtrim([AddressTypeCode]))
					,[AddressTypeString] = Ltrim(Rtrim([AddressTypeString]))
					,[DPVCount] = Ltrim(Rtrim([DPVCount]))
					,[DPVFootnotes] = Ltrim(Rtrim([DPVFootnotes]))
					,[CMRA] = Ltrim(Rtrim([CMRA]))
					,[ELotNumber] = Ltrim(Rtrim([ELotNumber]))
					,[ELotOrder] = Ltrim(Rtrim([ELotOrder]))
					,[Lacs] = Ltrim(Rtrim([Lacs]))
					,[LACSLinkIndicator] = Ltrim(Rtrim([LACSLinkIndicator]))
					,[EWSFlag] = Ltrim(Rtrim([EWSFlag]))
					,[RBDI] = Ltrim(Rtrim([RBDI]))
					,[SuiteLinkReturnCode] = Ltrim(Rtrim([SuiteLinkReturnCode]))
					,[DeliveryPointCheckDigit] = Ltrim(Rtrim([DeliveryPointCheckDigit]))
					,[DeliveryPointCode] = Ltrim(Rtrim([DeliveryPointCode]))
					,[Verified] = Ltrim(Rtrim([Verified]))
					,[AddressMatchResults] = Ltrim(Rtrim([AddressMatchResults]))
					,[CensusBlock] = Ltrim(Rtrim([CensusBlock]))
					,[CensusTract] = Ltrim(Rtrim([CensusTract]))
					,[PlaceCode] = Ltrim(Rtrim([PlaceCode]))
					,[PlaceName] = Ltrim(Rtrim([PlaceName]))
					,[CBSACode] = Ltrim(Rtrim([CBSACode]))
					,[CBSALevel] = Ltrim(Rtrim([CBSALevel]))
					,[CBSATitle] = Ltrim(Rtrim([CBSATitle]))
					,[CBSADivisionCode] = Ltrim(Rtrim([CBSADivisionCode]))
					,[CBSADivisionLevel] = Ltrim(Rtrim([CBSADivisionLevel]))
					,[CBSADivisionTitle] = Ltrim(Rtrim([CBSADivisionTitle]))
					,[Latitude] = Ltrim(Rtrim([Latitude]))
					,[Longitude] = Ltrim(Rtrim([Longitude]))
					,[Geocoded] = Ltrim(Rtrim([Geocoded]))
					,[GeoErrorCode] = Ltrim(Rtrim([GeoErrorCode]))
					,[GeoStatusCode] = Ltrim(Rtrim([GeoStatusCode]))
					,[GeoCodeResults] = Ltrim(Rtrim([GeoCodeResults]))
					,[CountryCode] = Ltrim(Rtrim([CountryCode]))
				 From [DragonAssr].[dbo].[DragonAssr_STD]

				 	UPDATE
						Table_A
					SET	Table_A.raw_id = Table_B.raw_id
					FROM [DragonAssr].[dbo].[DragonAssr_STD] Table_A
					INNER JOIN [DragonAssr].[dbo].[DragonAssr] Table_B
					ON	Table_A.RecordId = Table_B.RecordId

				'
			print @sql
			exec (@sql)
