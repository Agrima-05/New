SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankDeedBuyermailInput](@tableName varchar(40)) -- @tableName = 'Deed_Buyermail' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + ' 
    [DeedUniqueID] [bigint] NOT NULL,
	[BuyerMailFullAddress] [varchar](116) NULL,
	[BuyerMailHouseNbr] [varchar](32) NULL,
	[BuyerMailLeftDirection] [varchar](2) NULL,
	[BuyerMailStreetName] [varchar](100) NULL,
	[BuyerMailRightDirection] [varchar](2) NULL,
	[BuyerMailMode] [varchar](10) NULL,
	[BuyerMailUnitType] [varchar](20) NULL,
	[BuyerMailUnitNumber] [varchar](15) NULL,
	[BuyerMailCity] [varchar](55) NULL,
	[BuyerMailState] [varchar](2) NULL,
	[BuyerMailZip4] [varchar](4) NULL,
	[BuyerMailZip5] [varchar](9) NULL,
	[BuyerMailCarrierCode] [varchar](4) NULL,
	[BuyerMailDPVCount] [varchar](5) NULL,
	[BuyerMailDPVFootnote] [varchar](4) NULL,
	[BuyerMailLACS] [varchar](1) NULL,
	[BuyerMailLACSLinkInd] [varchar](1) NULL,
	[BuyerMailDPCheckDigit] [varchar](1) NULL,
	[BuyerMailDPCheckCode] [varchar](2) NULL,
	[BuyerMailCensusBlock] [varchar](4) NULL,
	[BuyerMailCensusTract] [varchar](6) NULL,
	[BuyerMailStdMatchCode] [varchar] (30) NULL,
	[BuyerMailGeoCodeResults] [varchar] (30) NULL,
	[BuyerMailGeoErrorCode] [varchar](1) NULL,
	[BuyerMailGeoStatusCode] [varchar](1) NULL,
	[FIPS] [varchar](5) NULL,
	[PMB] [varchar](30) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT DeedUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([BuyerMailFullAddress], '''') addressLine ,isnull(BuyerMailCity, '''') as city  ,isnull(BuyerMailState, '''') as state  ,
isnull(BuyerMailZip5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY BuyerMailZip5 desc'  

exec (@sql)  

