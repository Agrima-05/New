SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================

CREATE PROCEDURE [dbo].[d001_LoadDragonBatch_Updates_V3_FromTable]
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)

		IF(SELECT COUNT(*) FROM DragonAssr.dbo.PullDragonREFIDs) = 0
		BEGIN
			RETURN;
		END

		BEGIN
	
				DECLARE @2 varchar(255) = 'micsmith@firstam.com; klowe@firstam.com', 
				@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject2 varchar(50) = 'Dragon Assr Load Started Update from PullDragonREFIDs',
				@t_body2 varchar(2000) = 'The Dragon Assr Data Load process from PullDragonREFIDs has started.'


				SET NOCOUNT ON;
				DECLARE @t_getdate2 datetime = GETDATE()
				SET @t_body2 = @t_body2 + ' : ' + Try_Cast(@t_getdate2 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					-- @recipients = @t_recipients,
					@recipients = @2,
					@profile_name = @t_profile_name2,
					@subject = @t_subject2,
					@body = @t_body2
---------------------------------------------------------------------------------------------------------------------
		TRUNCATE TABLE DragonProcessingTrackerUpdt
		DROP TABLE IF EXISTS #REF_IDS
		DROP TABLE IF EXISTS #TAXUpdateFIPS


		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 1 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		SELECT RIGHT([name],5) as FIPS into #FIPS
		FROM sys.tables with(NOLOCK) WHERE [name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]'
			Union All
		Select RIGHT('0' + Try_Cast(FIPS as varchar),5) FIPS from dbo.Dragon_Flank_Refreshes with(NOLOCK) group by RIGHT('0' + Try_Cast(FIPS as varchar),5)

		Drop table if exists #REF_IDs
		Select RIGHT('0' + cast(Fips as varchar),5) FipsCode,[REF_ID],[CREATED],[UPDATED],[TAX_YEAR],[TAX_AMOUNT] into #REF_IDs from [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] a with(NOLOCK)
		WHERE source_type = 'G' and  (Try_Cast([CREATED] as datetime) > GETDATE()-5 OR Try_Cast([UPDATED] as datetime) > GETDATE()-5)
		and FIPS not in(Select Fips from #FIPS)

		CREATE Unique INDEX ix_FIPSREFID on #REF_IDs(FIPScode,REF_ID)

		DROP TABLE IF EXISTS #TAXUpdateFIPS
		Select a.*,b.RecordsinTaxroll
			INTO #TAXUpdateFIPS
		 from (Select FIPScode,Count(*) CNT from #REF_IDs group by FipsCode) a JOIN Global.dbo.County b with(NOLOCK) on a.FipsCode = b.FIPSCode
		Where CNT BETWEEN b.RecordsinTaxroll - (b.RecordsinTaxroll - (b.RecordsinTaxroll *.75)) and b.RecordsinTaxroll + (b.RecordsinTaxroll - (b.RecordsinTaxroll *.75))

		Select * INTO #TAXUpdates
		from #REF_IDs 
		WHERE FipsCode in(Select FipsCode from #TAXUpdateFIPS)
		
		DELETE FROM #REF_IDs 
		WHERE FipsCode in(Select FipsCode from #TAXUpdateFIPS)

		UPDATE DragonAssr.[dbo].[Dragon_Refresh_Tracker]
		SET [RunRefresh] = 'Y'
		WHERE FIPS in(Select distinct FIPScode from #TAXUpdates)

		INSERT INTO DragonAssr.[dbo].[PullDragonREFIDs](FIPS,REF_ID)
		Select b.FIPS,a.REF_ID
		from #REF_IDs a JOIN data.dbo.Property b with(NOLOCK) on a.FipsCode = b.FIPS and a.REF_ID = b.DTDB_Ref_ID
		WHERE (Try_Cast([CREATED] as date) > Try_Cast(FADateReceived as Date) OR Try_Cast([UPDATED] as Date) > Try_Cast(FADateReceived as Date))
		ORDER BY FIPS,REF_ID,[CREATED],[UPDATED]

		INSERT INTO DragonAssr.[dbo].[PullDragonREFIDs_Archive]
		Select *,GETDATE() from DragonAssr.[dbo].[PullDragonREFIDs]

		DROP TABLE IF EXISTS dbo.Dragon_Flank_Batch_ASSR_Updt
		
		SELECT Distinct a.*,0 as MatchCode,convert(varchar(5),'') as FipsCode,convert(bigint,0) as PropertyID
		INTO dbo.Dragon_Flank_Batch_ASSR_Updt
		  FROM [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] a 
		  JOIN DragonAssr.[dbo].[PullDragonREFIDs] b
		  on a.FIPS = convert(int,b.FIPS)
			and a.[REF_ID] = b.[REF_ID]

		CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsRefID] ON [dbo].[Dragon_Flank_Batch_ASSR_Updt]
		([FIPS] ASC,[REF_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 1 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 2 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[002_remove_Extra_Ascii_from_table] 'Dragon_Flank_Batch_ASSR_Updt'

	----- CLEAN LEAD ZEROS
		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_HOUSE_NBR = Global.dbo.DeleteLeadZeros(SITUS_HOUSE_NBR)
		WHERE SITUS_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_STREET_NAME = Global.dbo.DeleteLeadZeros(SITUS_STREET_NAME)
		WHERE SITUS_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET SITUS_UNIT_NBR = Global.dbo.DeleteLeadZeros(SITUS_UNIT_NBR)
		WHERE SITUS_UNIT_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_HOUSE_NBR = Global.dbo.DeleteLeadZeros(MAIL_HOUSE_NBR)
		WHERE MAIL_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_STREET_NAME = Global.dbo.DeleteLeadZeros(MAIL_STREET_NAME)
		WHERE MAIL_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET MAIL_UNIT_NBR = Global.dbo.DeleteLeadZeros(MAIL_UNIT_NBR)
		WHERE MAIL_UNIT_NBR like '00%'

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 2 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 3 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

	----- FILL IN FIPSCODE AND PROPERTYID

		UPDATE a
		SET Fipscode = RIGHT('0' + convert(varchar(5),FIPS),5)
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a
		WHERE isNULL(Fipscode,'') like ''

		UPDATE a
		SET PropertyID = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	

		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.FipsCode = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.UnformattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.UnFormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET PropertyID = b.PropertyID
		FROM dbo.[Dragon_Flank_Batch_ASSR_Updt] a JOIN Data.dbo.Property b with(NOLOCK)
		ON a.FIPSCODE = b.FIPS
		and a.[UNFORMATTED_APN] = b.TaxAccountNumber
		WHERE isNULL(a.PropertyID,0) = 0 

		update dbo.[Dragon_Flank_Batch_ASSR_Updt]
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR] with(NOLOCK)
		WHERE PropertyID is not null
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)


		UPDATE a
		SET PropertyID = b.PropertyID
		FROM dbo.Dragon_Flank_Batch_ASSR_Updt a JOIN Data.dbo.Property b with(NOLOCK)
		ON a.FIPSCODE = b.FIPS
		and a.Formatted_APN = b.FormattedAPN
		WHERE a.PropertyID is NULL
		or a.propertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR_Updt] with(NOLOCK)
		WHERE PropertyID is not NULL
		GROUP BY FIPScode,PropertyID
		HAVING COUNT(*) > 1)


		update dbo.Dragon_Flank_Batch_ASSR_Updt
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR_Updt] with(NOLOCK)
		WHERE PropertyID is not null
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)

		DROP TABLE IF EXISTS dbo.DragonAssrCounts

		DECLARE @CertDt Varchar(8) = Convert(varchar(8),GETDATE()-90,112)
		
		EXEC('Select x.FIPSCode,x.RecCount,x.RecordsInTaxroll,x.CERTIFICATION_DATE,CASE WHEN x.RecCount between x.RecordsInTaxroll -(x.RecordsinTaxroll * .10) and x.RecordsInTaxroll +(x.RecordsinTaxroll * .10) THEN ''REFRESH'' ELSE ''UPDATE'' END as RefreshUpdate
		INTO DragonAssrCounts
		FROM(
			SELECT a.FipsCode,COUNT(*) as RecCount,RecordsinTaxroll,'''+@CertDt+''' as CERTIFICATION_DATE
			FROM [dbo].[Dragon_Flank_Batch_ASSR_Updt] a JOIN Global.dbo.County b
			on a.FipsCode = b.FIPSCode
			GROUP BY a.FipsCode,RecordsinTaxroll
			) X
			ORDER BY x.FipsCode
		')

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 3 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 4 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d005_DragonAssrLoad_Update_Looper]

		INSERT INTO DragonProcessingTrackerUpdt
		Select 'STEP 4 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		--Truncate Table dbo.Dragon_Update_Tracker

		UPDATE a
		SET [MaxCreated] = b.MaxCreated
		,[MaxUpdated] = b.MaxUpdated
		,[DateLastUpdate] = GETDATE()
		FROM dbo.Dragon_Update_Tracker a JOIN (
		SELECT [FIPS],Max([CREATED]) as MaxCreated,Max([UPDATED]) as MaxUpdated
		  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR_Updt]
		  GROUP BY FIPS
		  ) b
		ON a.FIPS = b.[FIPS]

		
		
		EXEC [dbo].[d700_Post_Dragon_To_Licensing_UPDATE]

		
		
		Truncate table [DragonAssr].[dbo].[PullDragonREFIDs]

		DROP TABLE IF EXISTS #REF_IDS
		DROP TABLE IF EXISTS #TAXUpdateFIPS

		--DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112);
		DECLARE @DFB as varchar(50) = 'Dragon_Flank_Batch_ASSR_Updt_' + @PULLDT
		DECLARE @DAC as varchar(50) = 'DragonAssrCounts_' + @PULLDT

		EXEC('DROP TABLE IF EXISTS dbo.['+@DFB+']')
		EXEC('DROP TABLE IF EXISTS dbo.['+@DAC+']')

		EXEC sp_rename Dragon_Flank_Batch_ASSR_Updt,@DFB

		EXEC sp_rename DragonAssrCounts,@DAC



			DECLARE @3 varchar(355) = 'micsmith@firstam.com; klowe@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon Assr Load Finished from PullDragonREFIDs',
				@t_body3 varchar(2000) = 'The Dragon Assr Data Load process from PullDragonREFIDs has finished.'


				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + ' : ' + Try_Cast(@t_getdate3 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3

	END


END

