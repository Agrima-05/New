SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_ReRun_Generated_a]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @FipsCode varchar(5)

		DECLARE Gen_a CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE [STATE] NOT in('AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','MI','MT','TX')
			ORDER BY [FIPSCode]


		OPEN Gen_a   
		FETCH NEXT FROM Gen_a INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC [dbo].[CreateFASpotGenerated_a_FAST] @FipsCode

			EXEC('DELETE FROM FASpot_a
			WHERE UCIDFlag = ''D''
			and FIPS = ''' + @FipsCode + '''
			')

			  EXEC('update [dbo].[FASpot_Generated_a]
			  SET [CentroidLatitude] = [ParcelGeometry].STCentroid().STY
			  ,[CentroidLongitude] = [ParcelGeometry].STCentroid().STX
			  WHERE FIPS = ''' + @FipsCode + '''
				')
			  
			  EXEC('update [dbo].[FASpot_Generated_a]
			  SET [CentroidPointGeom] = geography::Point([CentroidLatitude],[CentroidLongitude],  4269)
			  WHERE FIPS = ''' + @FipsCode + '''
			  ')
			
			FETCH NEXT FROM Gen_a INTO @FipsCode   
		END   

		CLOSE Gen_a   
		DEALLOCATE Gen_a 
END
