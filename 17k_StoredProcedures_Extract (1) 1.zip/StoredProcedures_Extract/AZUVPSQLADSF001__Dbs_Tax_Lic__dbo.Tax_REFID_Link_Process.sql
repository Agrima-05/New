SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
CREATE PROCEDURE [dbo].[Tax_REFID_Link_Process] 

AS
BEGIN

	SET NOCOUNT ON;

 		UPDATE [dbo].[Licensing_Deliverable_Dragon]
		SET [Lic_FIPS] = Right('0' + convert(varchar(5),FIPS),5)
		WHERE [Lic_FIPS] is NULL
 
 
 		DECLARE @FipsCode varchar(5)

		DECLARE curMatchREFID CURSOR FOR  
			SELECT [FIPS] 
			FROM [dbo].[Licensing_Deliverable_Dragon]
			GROUP BY [FIPS]
			ORDER BY [FIPS]



		OPEN curMatchREFID   
		FETCH NEXT FROM curMatchREFID INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			
			
			---- Link to Unformatted, Formatted, Original, Alternate APNs and Acct Nbrs
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[UNFORMATTED_APN]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[FORMATTED_APN]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ORIGINAL_APN]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ALTERNATE_APN]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ACCOUNT_NBR]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

			---- UPDATE FROM FLANK THEN BACK TO REF_ID
				UPDATE a
				SET FAPropertyID = b.PropertyID
				,LIC_APN = FormattedAPN
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN Data.dbo.Property b with(NOLOCK)
				ON a.[LIC_FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = replace(b.[FORMATTEDAPN],'-','')
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [ASSR].[dbo].[ASSR] b with(NOLOCK)
				ON a.[LIC_FIPS] = b.[FIPS]
				and a.FAPropertyID = b.LIC_PropertyID
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL



			---- add Right padding  "000" to the UNFORMATTED_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[UNFORMATTED_APN] + '000'
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

			---- add Right padding  "000" to the ORIGINAL_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ORIGINAL_APN] + '000'
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL
			
			---- add Right padding  "00" to the UNFORMATTED_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[UNFORMATTED_APN] + '00'
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

			---- add Right padding  "00" to the ORIGINAL_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ORIGINAL_APN] + '00'
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL
			
			---- add Right padding  "00" to the ORIGINAL_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = b.[ORIGINAL_APN] 
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL
			
			---- add Left padding  "0" to the UNFORMATTED_APN 
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = '0' + b.[UNFORMATTED_APN]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

			
			---- add a "1" to the ASSESSOR_PARCEL_NUMBER for Mendocino County
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and LEFT(a.[ASSESSOR_PARCEL_NUMBER],9) + '1' = b.[UNFORMATTED_APN]
				WHERE b.[FIPS] = 6045 and a.REF_ID is NULL

			---- remove last 2 characters of UnformattedAPN for Mendocino County
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = LEFT(b.[UNFORMATTED_APN],8) + '00'
				WHERE b.[FIPS] = 6045 and a.REF_ID is NULL

			---- Add some 0's to Formatted APN for Nevada County, CA
				UPDATE a
				SET [REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = replace('0' + Substring(b.[FORMATTED_APN],1,6) + '0' + Substring(b.[FORMATTED_APN],8,6),'-','')
				WHERE b.[FIPS] = 6057 and a.REF_ID is NULL


			---- MATCH TO FLANK and Assign REFID
				UPDATE a
				SET [FAPropertyID] = b.[PropertyID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN [Data].[dbo].[Property] b with(NOLOCK)
				ON a.[FIPS] = b.[FIPS]
				and a.[ASSESSOR_PARCEL_NUMBER] = replace(b.[FormattedAPN],'-','')
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL

				UPDATE a
				SET a.[REF_ID] = b.[REF_ID]
				FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN ASSR.dbo.Assr b
				on a.FIPS = b.FIPS
				and a.[FAPropertyID] = b.[LIC_PropertyID]
				WHERE b.[FIPS] = @FipsCode and a.REF_ID is NULL


			FETCH NEXT FROM curMatchREFID INTO @FipsCode   
		END   

		CLOSE curMatchREFID   
		DEALLOCATE curMatchREFID 



		UPDATE a
		SET [FAPropertyID] = [LIC_PropertyID]
		,[Lic_APN] = b.[LIC_APN]
		FROM [dbo].[Licensing_Deliverable_Dragon] a JOIN ASSR.dbo.Assr b
		on a.FIPS = b.FIPS
		and a.REF_ID = b.REF_ID


	IF exists (Select Fips,REF_ID,COUNT(*) RecordCount
		from [DBS_TAX_LIC].[dbo].[Licensing_Deliverable_Dragon]
		WHERE REF_ID is not null and isNULL([CurrentRecord],'') != 'Y'
		GROUP BY  Fips,REF_ID
		HAVING COUNT(*) > 1
		)
	
	BEGIN

		UPDATE a
		SET [CurrentRecord] = 'Y'
		FROM [DBS_TAX_LIC].[dbo].[Licensing_Deliverable_Dragon] a JOIN (
			Select FIPS,REF_ID,MAX([TAX_YEAR_BEGIN]) as MaxBegin from [DBS_TAX_LIC].[dbo].[Licensing_Deliverable_Dragon] group by FIPS,REF_ID) b
		ON a.Fips = b.Fips 
		and a.REF_ID = b.REF_ID
		and a.[TAX_YEAR_BEGIN] = b.MaxBegin

	END




END


