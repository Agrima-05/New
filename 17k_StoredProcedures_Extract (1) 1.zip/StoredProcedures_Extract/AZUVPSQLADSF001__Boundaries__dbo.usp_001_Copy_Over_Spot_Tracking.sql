SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
create PROCEDURE [dbo].[usp_001_Copy_Over_Spot_Tracking]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	Drop Table If Exists [dbo].[SpotTracking]

	Select * 
	INTO [dbo].[SpotTracking]
	from [AZUVPSQLDTDB034].[Spot].[dbo].[SpotTracking] with(NOLOCK)




END

