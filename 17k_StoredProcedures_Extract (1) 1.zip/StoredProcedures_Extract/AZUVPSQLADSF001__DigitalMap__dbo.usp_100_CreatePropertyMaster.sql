SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_100_CreatePropertyMaster] 
AS
BEGIN
	SET NOCOUNT ON;

--USE [DigitalMap]
--GO

--/****** Object:  Table [dbo].[property_master]    Script Date: 2/25/2016 3:13:02 PM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[property_master](
--	[FAPropertyId] [bigint] NOT NULL,
--	[FAPropertyParent] [bigint] NULL,
--	[FIPS] [nvarchar](5) NULL,
--	[APN] [nvarchar](45) NULL,
--	[DuplicateAPN] [nvarchar](2) NULL,
--	[OldAPN] [nvarchar](31) NULL,
--	[FormattedAPN] [nvarchar](45) NULL,
--	[PID] [nvarchar](10) NULL,
--	[TaxAccountNumber] [nvarchar](30) NULL,
--	[DTDB_Ref_ID] [bigint] NULL,
--	[DTDB_MatchFlag] [varchar](1) NULL,
--	[FADeleteFlag] [bit] NULL,
--	[FADeleteFlagDate] [datetime] NULL,
--	[FIPSinteger] [bigint] NULL,
--	[APN_change_date] [datetime2](7) NULL,
--	[FormattedAPNMask] [nvarchar](45) NULL,
--	[TaxAccountNumberMask] [nvarchar](30) NULL
--) ON [PRIMARY]

--GO

--SET ANSI_PADDING OFF
--GO



DROP INDEX [ClusteredIndex-Fips] ON [dbo].[property_master]
truncate table [dbo].[property_master]

Insert into [dbo].[property_master] (
	   [FAPropertyId]
      ,[FAPropertyParent]
      ,[FIPS]
      ,[APN]
      ,[DuplicateAPN]
      ,[OldAPN]
      ,[FormattedAPN]
      ,[PID]
      ,[TaxAccountNumber]
      ,[DTDB_Ref_ID]
      ,[FIPSinteger]
  
	)

SELECT [FAPropertyId]
      ,[FAPropertyParent]
      ,[FIPS]
      ,[APN]
      ,[DuplicateAPN]
      ,[OldAPN]
      ,[FormattedAPN]
      ,[PID]
      ,[TaxAccountNumber]
      ,[DTDB_Ref_ID]
      ,[FIPSinteger]	  
FROM Global.[dbo].Property_master  with(nolock)

RAISERROR ('Done creating tables', 10, 1) WITH NOWAIT

CREATE CLUSTERED INDEX [ClusteredIndex-Fips] ON [dbo].[property_master]
(
	[FIPS] ASC
)

RAISERROR ('Done creating indexes', 10, 1) WITH NOWAIT


END


