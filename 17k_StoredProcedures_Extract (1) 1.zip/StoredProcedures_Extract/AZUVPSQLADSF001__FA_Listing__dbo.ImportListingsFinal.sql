SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[ImportListingsFinal]
AS
	SET XACT_ABORT ON
	BEGIN TRANSACTION

	UPDATE l
	SET Land_Use = a.Land_Use
	FROM fa_listing.tmp.Listing l
	INNER JOIN Assr.dbo.Assr a with(nolock,index(IDX_Assr_Ref_ID)) ON l.REF_ID = a.REF_ID
	WHERE l.Land_Use IS NULL OR l.Land_Use <> a.Land_Use

	SET IDENTITY_INSERT dbo.Listing ON
	MERGE dbo.Listing a
	USING tmp.Listing b
	ON (a.Listing_ID = b.Listing_ID)
	WHEN MATCHED
		THEN UPDATE SET
			a.UPDATE_FLAG_DATE_STD = b.UPDATE_FLAG_DATE_STD
			,a.MLS_LIST_DATE_STD = b.MLS_LIST_DATE_STD
			,a.MLS_STATUS_STD = b.MLS_STATUS_STD
			,a.MLS_Listing_Number = b.MLS_Listing_Number
			,a.MLS_Listing_Agent_CODE = b.MLS_Listing_Agent_CODE
			,a.MLS_OFFICE_CODE = b.MLS_OFFICE_CODE
			,a.Updated = b.Updated
			,a.Fips = b.Fips
			,a.REF_ID = b.REF_ID
			,a.State = b.State
			,a.Current_Listing_Ind = b.Current_Listing_Ind
			,a.Current_Rental_Ind = b.Current_Rental_Ind
			,a.Concurrent_Listed_Ind = b.Concurrent_Listed_Ind
			,a.SOLD_DATE_STD = b.SOLD_DATE_STD
			,a.AddrId = b.AddrId
			,a.MLS_LISTING_AGENT2_CODE = b.MLS_LISTING_AGENT2_CODE
			,a.SEL_AGENT_CODE = b.SEL_AGENT_CODE
			,a.SEL_AGENT2_CODE = b.SEL_AGENT2_CODE
			,a.LISTING_OFFICE2_CODE = b.LISTING_OFFICE2_CODE
			,a.SEL_OFFICE_CODE = b.SEL_OFFICE_CODE
			,a.SEL_OFFICE2_CODE = b.SEL_OFFICE2_CODE
			,a.Rental_Ind = b.Rental_Ind
			,a.LastRow_Id = b.LastRow_Id
			,a.NBR_BEDRMS_STD = b.NBR_BEDRMS_STD
			,a.MLS_LIST_PRICE_STD = b.MLS_LIST_PRICE_STD
			,a.SOLD_PRICE_STD = b.SOLD_PRICE_STD
			,a.BSMT_FIN_SQFT_STD = b.BSMT_FIN_SQFT_STD
			,a.HOME_SIZE_STD = b.HOME_SIZE_STD
			,a.LOT_SIZE_STD = b.LOT_SIZE_STD
			,a.PRICE_PER_SQFT_STD = b.PRICE_PER_SQFT_STD
			,a.YEAR_BUILT_STD = b.YEAR_BUILT_STD
			,a.REO_IND = b.REO_IND
			,a.SHORT_SALE_IND = b.SHORT_SALE_IND
			,a.MLS_STATUS_SUB_TYPE_STD = b.MLS_STATUS_SUB_TYPE_STD
			,a.NBR_BATH_STD = b.NBR_BATH_STD
			,a.NBR_GRG_STD = b.NBR_GRG_STD
			,a.NBR_FIREPLACE_STD = b.NBR_FIREPLACE_STD
			,a.NBR_STORIES_STD = b.NBR_STORIES_STD
			,a.FIREPLACE_DESC_STD = b.FIREPLACE_DESC_STD
			,a.UpdateSeq = b.UpdateSeq
			,a.APX_LOT_DIMENSIONS = b.APX_LOT_DIMENSIONS
			,a.PROPERTY_DETAILS = b.PROPERTY_DETAILS
			,a.APN = b.APN
			,a.APX_LOT_IS_L85 = b.APX_LOT_IS_L85
			,a.COUNTY_NAME = b.COUNTY_NAME
			,a.HOUSE_NBR = b.HOUSE_NBR
			,a.STREET = b.STREET
			,a.CITY = b.CITY
			,a.ZIP = b.ZIP
			,a.OTHER_FTRS = b.OTHER_FTRS -- paul
			,a.PROVIDER_TYPE = b.PROVIDER_TYPE
			,a.Land_Use = b.Land_Use
			,a.Original_UPDATE_FLAG_DATE_STD=b.Original_UPDATE_FLAG_DATE_STD
			,a.MLS_Listing_Number_edited=b.MLS_Listing_Number_edited
	WHEN NOT MATCHED BY TARGET
		THEN INSERT (
			Listing_ID
			,UPDATE_FLAG_DATE_STD
			,MLS_LIST_DATE_STD
			,MLS_STATUS_STD
			,MLS_Listing_Number
			,MLS_Listing_Agent_CODE
			,MLS_OFFICE_CODE
			,Created
			,Updated
			,Fips
			,REF_ID
			,State
			,Current_Listing_Ind
			,Current_Rental_Ind
			,Concurrent_Listed_Ind
			,SOLD_DATE_STD
			,AddrId
			,MLS_LISTING_AGENT2_CODE
			,SEL_AGENT_CODE
			,SEL_AGENT2_CODE
			,LISTING_OFFICE2_CODE
			,SEL_OFFICE_CODE
			,SEL_OFFICE2_CODE
			,Rental_Ind
			,LastRow_Id
			,NBR_BEDRMS_STD
			,MLS_LIST_PRICE_STD
			,SOLD_PRICE_STD
			,BSMT_FIN_SQFT_STD
			,HOME_SIZE_STD
			,LOT_SIZE_STD
			,PRICE_PER_SQFT_STD
			,YEAR_BUILT_STD
			,REO_IND
			,SHORT_SALE_IND
			,MLS_STATUS_SUB_TYPE_STD
			,NBR_BATH_STD
			,NBR_GRG_STD
			,NBR_FIREPLACE_STD
			,NBR_STORIES_STD
			,FIREPLACE_DESC_STD
			,UpdateSeq
			,APX_LOT_DIMENSIONS
			,PROPERTY_DETAILS
			,APN
			,APX_LOT_IS_L85
			,COUNTY_NAME
			,HOUSE_NBR
			,STREET
			,CITY
			,ZIP
			,OTHER_FTRS -- paul
			,PROVIDER_TYPE
			,Land_Use
			,Original_UPDATE_FLAG_DATE_STD
			,MLS_Listing_Number_edited
		)
		VALUES (
			b.Listing_ID
			,b.UPDATE_FLAG_DATE_STD
			,b.MLS_LIST_DATE_STD
			,b.MLS_STATUS_STD
			,b.MLS_Listing_Number
			,b.MLS_Listing_Agent_CODE
			,b.MLS_OFFICE_CODE
			,b.Created
			,b.Updated
			,b.Fips
			,b.REF_ID
			,b.State
			,b.Current_Listing_Ind
			,b.Current_Rental_Ind
			,b.Concurrent_Listed_Ind
			,b.SOLD_DATE_STD
			,b.AddrId
			,b.MLS_LISTING_AGENT2_CODE
			,b.SEL_AGENT_CODE
			,b.SEL_AGENT2_CODE
			,b.LISTING_OFFICE2_CODE
			,b.SEL_OFFICE_CODE
			,b.SEL_OFFICE2_CODE
			,b.Rental_Ind
			,b.LastRow_Id
			,b.NBR_BEDRMS_STD
			,b.MLS_LIST_PRICE_STD
			,b.SOLD_PRICE_STD
			,b.BSMT_FIN_SQFT_STD
			,b.HOME_SIZE_STD
			,b.LOT_SIZE_STD
			,b.PRICE_PER_SQFT_STD
			,b.YEAR_BUILT_STD
			,b.REO_IND
			,b.SHORT_SALE_IND
			,b.MLS_STATUS_SUB_TYPE_STD
			,b.NBR_BATH_STD
			,b.NBR_GRG_STD
			,b.NBR_FIREPLACE_STD
			,b.NBR_STORIES_STD
			,b.FIREPLACE_DESC_STD
			,b.UpdateSeq
			,b.APX_LOT_DIMENSIONS
			,b.PROPERTY_DETAILS
			,b.APN
			,b.APX_LOT_IS_L85
			,b.COUNTY_NAME
			,b.HOUSE_NBR
			,b.STREET
			,b.CITY
			,b.ZIP
			,b.OTHER_FTRS -- paul
			,b.PROVIDER_TYPE
			,b.Land_Use
			,b.Original_UPDATE_FLAG_DATE_STD
			,b.MLS_Listing_Number_edited
		)
	;
	SET IDENTITY_INSERT dbo.Listing OFF

	INSERT INTO ListingChange (Listing_ID, FieldId, ValueDate, UpdateSeq, ChangeDate, Value)
	SELECT lc.Listing_ID, lc.FieldId, lc.ValueDate, lc.UpdateSeq, lc.ChangeDate, lc.Value
	FROM tmp.ListingChange lc
	ORDER BY lc.Listing_ID, lc.ChangeDate, lc.UpdateSeq, lc.FieldId

	MERGE ListingHistory a
	USING (
		SELECT Listing_ID, Created AS UPDATE_FLAG_DATE_STD, 1 AS UpdateSeq, Original_UPDATE_FLAG_DATE_STD
		FROM Listing l
		WHERE Listing_ID IN (
			SELECT TargetMatchId
			FROM tmp.FA_MLS
		)
		UNION
		SELECT DISTINCT Listing_ID, ChangeDate, UpdateSeq + 1, getdate()
		FROM tmp.ListingChange
	) b
	ON (a.Listing_ID = b.Listing_ID AND a.UPDATE_FLAG_DATE_STD = b.UPDATE_FLAG_DATE_STD AND a.UpdateSeq = b.UpdateSeq)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT(Listing_ID, UPDATE_FLAG_DATE_STD, UpdateSeq, Original_UPDATE_FLAG_DATE_STD) VALUES (b.Listing_ID, b.UPDATE_FLAG_DATE_STD, b.UpdateSeq, b.Original_UPDATE_FLAG_DATE_STD);

	;WITH ListingFeaturesCTE AS (
		SELECT *
		FROM ListingFeatures
		WHERE Listing_ID IN (
			SELECT TargetMatchId
			FROM tmp.FA_MLS
		)
	)
	MERGE ListingFeaturesCTE a
	USING tmp.ListingFeatures b
	ON (a.Listing_ID = b.Listing_ID AND a.FeatureValueId = b.FeatureValueId)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT(Listing_ID, FeatureValueId) VALUES (b.Listing_ID, b.FeatureValueId)
	WHEN NOT MATCHED BY SOURCE
		THEN DELETE;

	;WITH ListingSubFeaturesCTE AS (
		SELECT *
		FROM ListingSubFeatures
		WHERE Listing_ID IN (
			SELECT TargetMatchId
			FROM tmp.FA_MLS
		)
	)
	MERGE ListingSubFeaturesCTE a
	USING tmp.ListingSubFeatures b
	ON (a.Listing_ID = b.Listing_ID AND a.FeatureValueId = b.FeatureValueId AND a.SubFeatureValueId = b.SubFeatureValueId)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT(Listing_ID, FeatureValueId, SubFeatureValueId) VALUES (b.Listing_ID, b.FeatureValueId, b.SubFeatureValueId)
	WHEN NOT MATCHED BY SOURCE
		THEN DELETE;

	MERGE ListingFeaturesPivot a
	USING tmp.ListingFeaturesPivot b
	ON (a.Listing_ID = b.Listing_ID)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT(
			Listing_ID
			,APPLIANCES
			,COMMUNITY_FTRS
			,COMPLEX_FTRS
			,COOLING_FTRS
			,ELEMENTARY_SCHOOL
			,ENERGY_INFO
			,EXISTING_STRUCTURES
			,EXTERIOR_CONSTRUCTION
			,EXTERIOR_FTRS
			,FARM_IMPROVEMENT
			,FIREPLACE_FTRS
			,FIREPLACE_FUEL_SOURCE
			,FIREPLACE_LOCATION
			,FIREPLACE_NBR
			,FIREPLACE_PRESENT
			,[Garage Sq Ft]
			,[Heating Availability]
			,HEATING_FTRS
			,HIGH_SCHOOL
			,HOME_SIZE
			,INTERIOR_FTRS
			,LOT_FTRS
			,MASTER_BEDROOM
			,MIDDLE_SCHOOL
			,MLS_AREA
			,MLS_INCLUSIONS
			,NBR_GRG
			,NBR_STORIES
			,NEIGHBORHOOD
			,PARCEL_ACCESS
			,PARKING_FTRS
			,[Pool Accessories]
			,[Pool Amenities]
			,[Pool Fuel Source]
			,[Pool Heating Features]
			,[Pool Location]
			,[Pool Presence]
			,[Pool Size]
			,[Pool Type]
			,POOL_FTRS
			,PRESENT_USE
			,PROPERTY_SUB_TYPE
			,PROPERTY_TYPE
			,RANGE_AIRCONDITIONERS
			,ROOFING
			,SCHOOL_DISTRICT
			,SEWER
			,STYLE
			,SUBDIVISION
			,TOPOGRAPHY
			,UTILITY_PRESENT
			,VIEW_1
			,WATER
			,[Water Heater Availability]
			,[Water Heater Fuel Source]
			,[Water Heater Type]
			,WATER_ACCESS
			,WATER_AMMENITIES
			,WATER_FRONT_FTRS
			,WATER_HEATER
			,WATER_METER
			,WATER_PRESENCE
			,WATER_SOURCE
			,ZONING
			,HEAT_FUEL_TYPE
			,COOL_FUEL_TYPE
			,APPLIANCES_FUEL_TYPE
			,NBR_GRG_TYPE
			,FIREPLACE_FUEL_TYPE
		) VALUES (
			b.Listing_ID
			,b.APPLIANCES
			,b.COMMUNITY_FTRS
			,b.COMPLEX_FTRS
			,b.COOLING_FTRS
			,b.ELEMENTARY_SCHOOL
			,b.ENERGY_INFO
			,b.EXISTING_STRUCTURES
			,b.EXTERIOR_CONSTRUCTION
			,b.EXTERIOR_FTRS
			,b.FARM_IMPROVEMENT
			,b.FIREPLACE_FTRS
			,b.FIREPLACE_FUEL_SOURCE
			,b.FIREPLACE_LOCATION
			,b.FIREPLACE_NBR
			,b.FIREPLACE_PRESENT
			,b.[Garage Sq Ft]
			,b.[Heating Availability]
			,b.HEATING_FTRS
			,b.HIGH_SCHOOL
			,b.HOME_SIZE
			,b.INTERIOR_FTRS
			,b.LOT_FTRS
			,b.MASTER_BEDROOM
			,b.MIDDLE_SCHOOL
			,b.MLS_AREA
			,b.MLS_INCLUSIONS
			,b.NBR_GRG
			,b.NBR_STORIES
			,b.NEIGHBORHOOD
			,b.PARCEL_ACCESS
			,b.PARKING_FTRS
			,b.[Pool Accessories]
			,b.[Pool Amenities]
			,b.[Pool Fuel Source]
			,b.[Pool Heating Features]
			,b.[Pool Location]
			,b.[Pool Presence]
			,b.[Pool Size]
			,b.[Pool Type]
			,b.POOL_FTRS
			,b.PRESENT_USE
			,b.PROPERTY_SUB_TYPE
			,b.PROPERTY_TYPE
			,b.RANGE_AIRCONDITIONERS
			,b.ROOFING
			,b.SCHOOL_DISTRICT
			,b.SEWER
			,b.STYLE
			,b.SUBDIVISION
			,b.TOPOGRAPHY
			,b.UTILITY_PRESENT
			,b.VIEW_1
			,b.WATER
			,b.[Water Heater Availability]
			,b.[Water Heater Fuel Source]
			,b.[Water Heater Type]
			,b.WATER_ACCESS
			,b.WATER_AMMENITIES
			,b.WATER_FRONT_FTRS
			,b.WATER_HEATER
			,b.WATER_METER
			,b.WATER_PRESENCE
			,b.WATER_SOURCE
			,b.ZONING
			,b.HEAT_FUEL_TYPE
			,b.COOL_FUEL_TYPE
			,b.APPLIANCES_FUEL_TYPE
			,b.NBR_GRG_TYPE
			,b.FIREPLACE_FUEL_TYPE
		)
	WHEN MATCHED
		THEN UPDATE SET
			a.APPLIANCES = b.APPLIANCES
			,a.COMMUNITY_FTRS = b.COMMUNITY_FTRS
			,a.COMPLEX_FTRS = b.COMPLEX_FTRS
			,a.COOLING_FTRS = b.COOLING_FTRS
			,a.ELEMENTARY_SCHOOL = b.ELEMENTARY_SCHOOL
			,a.ENERGY_INFO = b.ENERGY_INFO
			,a.EXISTING_STRUCTURES = b.EXISTING_STRUCTURES
			,a.EXTERIOR_CONSTRUCTION = b.EXTERIOR_CONSTRUCTION
			,a.EXTERIOR_FTRS = b.EXTERIOR_FTRS
			,a.FARM_IMPROVEMENT = b.FARM_IMPROVEMENT
			,a.FIREPLACE_FTRS = b.FIREPLACE_FTRS
			,a.FIREPLACE_FUEL_SOURCE = b.FIREPLACE_FUEL_SOURCE
			,a.FIREPLACE_LOCATION = b.FIREPLACE_LOCATION
			,a.FIREPLACE_NBR = b.FIREPLACE_NBR
			,a.FIREPLACE_PRESENT = b.FIREPLACE_PRESENT
			,a.[Garage Sq Ft] = b.[Garage Sq Ft]
			,a.[Heating Availability] = b.[Heating Availability]
			,a.HEATING_FTRS = b.HEATING_FTRS
			,a.HIGH_SCHOOL = b.HIGH_SCHOOL
			,a.HOME_SIZE = b.HOME_SIZE
			,a.INTERIOR_FTRS = b.INTERIOR_FTRS
			,a.LOT_FTRS = b.LOT_FTRS
			,a.MASTER_BEDROOM = b.MASTER_BEDROOM
			,a.MIDDLE_SCHOOL = b.MIDDLE_SCHOOL
			,a.MLS_AREA = b.MLS_AREA
			,a.MLS_INCLUSIONS = b.MLS_INCLUSIONS
			,a.NBR_GRG = b.NBR_GRG
			,a.NBR_STORIES = b.NBR_STORIES
			,a.NEIGHBORHOOD = b.NEIGHBORHOOD
			,a.PARCEL_ACCESS = b.PARCEL_ACCESS
			,a.PARKING_FTRS = b.PARKING_FTRS
			,a.[Pool Accessories] = b.[Pool Accessories]
			,a.[Pool Amenities] = b.[Pool Amenities]
			,a.[Pool Fuel Source] = b.[Pool Fuel Source]
			,a.[Pool Heating Features] = b.[Pool Heating Features]
			,a.[Pool Location] = b.[Pool Location]
			,a.[Pool Presence] = b.[Pool Presence]
			,a.[Pool Size] = b.[Pool Size]
			,a.[Pool Type] = b.[Pool Type]
			,a.POOL_FTRS = b.POOL_FTRS
			,a.PRESENT_USE = b.PRESENT_USE
			,a.PROPERTY_SUB_TYPE = b.PROPERTY_SUB_TYPE
			,a.PROPERTY_TYPE = b.PROPERTY_TYPE
			,a.RANGE_AIRCONDITIONERS = b.RANGE_AIRCONDITIONERS
			,a.ROOFING = b.ROOFING
			,a.SCHOOL_DISTRICT = b.SCHOOL_DISTRICT
			,a.SEWER = b.SEWER
			,a.STYLE = b.STYLE
			,a.SUBDIVISION = b.SUBDIVISION
			,a.TOPOGRAPHY = b.TOPOGRAPHY
			,a.UTILITY_PRESENT = b.UTILITY_PRESENT
			,a.VIEW_1 = b.VIEW_1
			,a.WATER = b.WATER
			,a.[Water Heater Availability] = b.[Water Heater Availability]
			,a.[Water Heater Fuel Source] = b.[Water Heater Fuel Source]
			,a.[Water Heater Type] = b.[Water Heater Type]
			,a.WATER_ACCESS = b.WATER_ACCESS
			,a.WATER_AMMENITIES = b.WATER_AMMENITIES
			,a.WATER_FRONT_FTRS = b.WATER_FRONT_FTRS
			,a.WATER_HEATER = b.WATER_HEATER
			,a.WATER_METER = b.WATER_METER
			,a.WATER_PRESENCE = b.WATER_PRESENCE
			,a.WATER_SOURCE = b.WATER_SOURCE
			,a.ZONING = b.ZONING
			,a.HEAT_FUEL_TYPE = b.HEAT_FUEL_TYPE
			,a.COOL_FUEL_TYPE = b.COOL_FUEL_TYPE
			,a.APPLIANCES_FUEL_TYPE = b.APPLIANCES_FUEL_TYPE
			,a.NBR_GRG_TYPE = b.NBR_GRG_TYPE
			,a.FIREPLACE_FUEL_TYPE = b.FIREPLACE_FUEL_TYPE;

	-- Populate PropertyToListing
	MERGE PropertyToListing a
	USING tmp.PropertyToListing b
	ON (a.Property_ID = b.Property_ID AND a.Listing_ID = b.Listing_ID)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT (Property_ID, Listing_ID) VALUES (b.Property_ID, b.Listing_ID);

	-- Populate ListingRow
	MERGE ListingRow a
	USING tmp.ListingRow b
	ON (a.Row_Id = b.Row_Id)
	WHEN NOT MATCHED BY TARGET
		THEN INSERT (Row_Id, Listing_ID, MatchTypeId, FeaturesMerged) VALUES (b.Row_Id, b.Listing_ID, b.MatchTypeId, b.FeaturesMerged);

	INSERT INTO ImportDate (UPDATE_FLAG_DATE)
	SELECT DISTINCT CONVERT(VARCHAR(10), UPDATE_FLAG_DATE_STD, 121)
	FROM tmp.FA_MLS
	WHERE CONVERT(VARCHAR(10), UPDATE_FLAG_DATE_STD, 121) NOT IN (
		SELECT UPDATE_FLAG_DATE
		FROM ImportDate
	)

	COMMIT TRANSACTION

	DECLARE @RowCount INT = 1
	DECLARE @ErrorCount INT = 0
	WHILE @RowCount > 0
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION
			UPDATE TOP (1000) l
			SET Point = a.Point
			FROM Listing l
			INNER JOIN FA_MLS_Raw_Std_Address a ON l.AddrId = a.Row_Id AND a.Addr_type = 'S'
			WHERE l.Listing_ID IN (
				SELECT Listing_ID
				FROM tmp.Listing
			) AND a.Point IS NOT NULL AND (l.Point IS NULL OR l.Point.STEquals(a.Point) = 0)
			SET @RowCount = @@ROWCOUNT
			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			SET @ErrorCount = @ErrorCount + 1
			IF @@TRANCOUNT > 0
				ROLLBACK;
			IF @ErrorCount > 5
				THROW;
			CONTINUE
		END CATCH
	END

