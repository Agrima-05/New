SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [dbo].[AutoBilling_Process_AUCTION10X_NEW]
as 
BEGIN

--Select * FRom [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where TicketNumber = '3469'

--Delete FRom [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling
--where TicketNumber = '3469'


------Added 20190503 - KL  for AUCTION 10 X Monitor Job------------------------------------------------------------------



insert into [AZUVPSQLDTDB029.datatree.local].CMAS.dbo.AutomatedBilling([AppSource]
	  ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingOption]
      ,[AccountNumber]
      ,[CustomerName]
      ,[CMASProductCode]
      ,[CMASProductName])
       SELECT 'SQL ADS'      --[AppSource]
	   ,[Reference Number] --BatchID
      ,'BATCH'               --[BatchType]
      ,[Order Date]              --[CreateDate]
      ,[Order Date]            --[ImportDate]
      ,COUNT(DISTINCT [Reference Number])   --[TotalRecords]
      ,0                       --[TotalMatched]
      ,0                       --[TotalUnMatched]
      ,0                       --[TotalDuplicate]
      ,0                       --[TotalExpired]
      ,0                       --[TotalInCoverage]
      ,0                       --[TotalNotInCoverage]
      ,0                       --[TotalPropertiesFound]
      ,0                       --[TotalPropertiesNotFound]
      ,'YES'                 --[IsBillable]
      ,0                       --[TotalMultiplePropertiesFound]
      ,0                       --[TotalAddressStandardized]
      ,0                       --[TotalAddressNotStandardized]
       ,COUNT(DISTINCT [Reference Number])  --[TotalWithEventsFound]
      ,0                       --[TotalWithoutEventsFound]
      ,'3469'                 --[TicketNumber]
      ,'3 - Bill for every record that had an event'   --[BillingOption]
      ,'131949'    --[AccountNumber]
      ,'Auction.com' --[CustomerName]
      ,'S20'                      --[CMASProductCode]
      ,'S20 - Custom Solution'  --[CMASProductName]
	--Select * 
	from  zCust_Auction.dbo.[AUCTION_BILLING] A --Where RecordFlag = 'A'
	Group by [Order Date], [Reference Number]
	Order by A.[Order Date]

	

	--Select [Order Date], count(*) From zCust_Auction.dbo.[AUCTION_BILLING]
	--Group by [Order Date]
	--Order by [Order Date]

	--Select * From zCust_Auction.dbo.[AUCTION_BILLING]
	--where [Reference Number] in (
	--Select [Reference Number] from (
	--Select [Reference Number], count(*) as TOTAL from  zCust_Auction.dbo.[AUCTION_BILLING]
	--Group by [Reference Number]
	--Having count(*) > 1)A)
	--Order by [Reference Number]


	--Select * From zCust_Auction.dbo.[AUCTION_BILLING]
	--where [Order Date] >= Getdate()-35
	--Order by [Order Date] desc

	--Select * From zCust_Auction.dbo.[AUCTION_BILLING_HIST]
	--where DATE_BILLED >= Getdate()-35
	--Order by DATE_BILLED desc, [Order Date]


INSERT INTO zCust_Auction.dbo.[AUCTION_BILLING_HIST]([Order Date]
      ,[UserID]
      ,[Product]
      ,[Reference Number]
      ,[Group Name]
      ,[Search Criteria]
      ,[Pricing]
      ,[DATE_BILLED])
SELECT       [Order Date]
      ,[UserID]
      ,[Product]
      ,[Reference Number]
      ,[Group Name]
      ,[Search Criteria]
      ,[Pricing]
       ,convert(date,Getdate())
FROM       zCust_Auction.dbo.[AUCTION_BILLING]



Truncate table zCust_Auction.dbo.[AUCTION_BILLING]

--Select * From zCust_Auction.dbo.[AUCTION_BILLING_HIST]






---------------------------------------------------------PROCESS BILLING FILE----------------------------------------------------------------------------------------
-- Update the automated billing table where Share Point ID equals automated billing ticket number.
		UPDATE AB
		SET 
		--AB.CreateDate = MA.Created,
		AB.BillingOption = MA.Billing_X0020_Type,
		AB.CustomerName = MA.Client_x0020_Name,
		AB.AccountNumber = MA.Billing_x0020_Number,
		AB.[CMAS_PRODUCT_SHAREPOINT] = REPLACE(MA.Product,';#',''),
		AB.Title = MA.Title,
		AB.ContractExecuted = MA.Contract_x0020_Executed,
		AB.Status = MA.CUrrent_x0020_Status,
		AB.SOW = cast(cast(left(MA.SOW,3) as money) as int) ,
		AB.WO = cast(cast(left(MA.WO,3) as money) as int) 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		WHERE AB.BillingDate IS  NULL
		AND AB.TicketNumber   in (3469)


		--Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] 
		--where TicketNumber   in (3469)
		--Order by BillingDate 

		

	-------Update CreateDate where null
		UPDATE AB
		SET 
		AB.CreateDate = MA.Created
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[SpMatchAndAppend] MA (nolock)
		ON MA.Id = AB.TicketNumber
		where AB.CreateDate is null
		AND AB.TicketNumber   in (3469)

	-----------------Determine number of products & split them out------------------
		
		Update A
		Set 
		A.NUM_PRODUCTS = (Select ((len(product) - Len(Replace(Product,';#','')))/2)-1)
		,A.PRODUCT1 = (Select left((Replace(Product,';#','')),charindex(';#',Product,3)-3))
		,A.PRODUCT2 = (Select case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then '' else 
			Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END)
		,A.PRODUCT3 = (Select case when (Case when charindex(';#',Product,charindex(';#',Product,3)+3) = 0 then 0 else 
			charindex(';#',Product,(charindex(';#',Product,charindex(';#',Product,3)+3))+3) END) = 0 then '' else 
			Right((Replace(Product,';#','')),len(Product)-charindex(';#',Product,3)-3) END)
		
	
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A
		join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[SpMatchAndAppend]  as B with(NOLOCK)
		on A.ticketNumber = B.ID
		where A.NUM_PRODUCTS is null
		AND LEN(Product) - LEN(REPLACE(Product, ';', ''))-1 <= 3
		AND A.TicketNumber   in (3469)	




		Update A
		Set 
		[CMASProductName] = [PRODUCT1]
		,[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where [CMASProductName] is null
		AND TicketNumber   in (3469)	


			
		

		----------------------TWO products on one ticket - ADD NEW RECORD-------------
		Insert into [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]([AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,[CMASProductCode]      ,[CMASProductName]
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      ,[TotalBillableUnits]      ,[ContractExecuted]      ,[CMAS_PRODUCT_SHAREPOINT],Status,WO)

	  Select
	  [AppSource]      ,[BatchId]      ,[BatchType]      ,[CreateDate]      ,[ImportDate]      ,[TotalRecords]      ,[TotalMatched]
      ,[TotalUnMatched]      ,[TotalDuplicate]      ,[TotalExpired]      ,[TotalInCoverage]      ,[TotalNotInCoverage]      ,[TotalPropertiesFound]      ,[TotalPropertiesNotFound]      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]      ,[TotalAddressStandardized]      ,[TotalAddressNotStandardized]      ,[TotalWithEventsFound]      ,[TotalWithoutEventsFound]      ,[TicketNumber]
      ,[BillingDate]      ,[ExtractionDate]      ,[BillingOption]      ,[AccountNumber]      ,[DaysToMonitor]      ,[CustomerName]      ,[ClientName]      ,left(PRODUCT2,3)
	  ,PRODUCT2
      ,[OracleProductCode]      ,[OracleProductName]      ,[Title]      ,[DocImageCounts]      ,[MonitorEndDate]      
	  ,Case when PRODUCT2 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END  
	  
	  ,[ContractExecuted]     ,[CMAS_PRODUCT_SHAREPOINT],Status,WO
	  FROm [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
	  where [NUM_PRODUCTS] = 2
	  and Status = '15-Closed'
	  and CustomerName not like '1Tract '
	  AND  [BillingOption] not like 'N/A - Non-billable'
	  AND PRODUCT2 not like 'Counts'
	   AND PRODUCT2 not like 'Bulk%'
	    And Billingoption not like 'Monthly Fee'
	  AND TicketNumber   in (3469)	
	  And BillingDate is null


	
		
		
		Update A
		Set 
		[TotalBillableUnits] = Case when PRODUCT1 like 'S50%' then [DocImageCounts] else [TotalBillableUnits]   END 
		--Select * 
		From [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] as A 
		where ([CMASProductName] like 'S50%' or PRODUCT1 like 'S50%')
		and [TotalBillableUnits] is null
		  AND TicketNumber   in (3469)	
		

	

	  -- Update CMASProductCode with from CMASProductName
		UPDATE AB
		SET AB.CMASProductCode = case when LEFT([CMASProductName],6) like 'S__ - ' and [CMASProductName] not like '%Bulk%'	then substring([CMASProductName],1,3)
		else [CMASProductName] end
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE 
		(AB.CMASProductCode IS NULL or AB.CMASProductCode = '')
		 and Status = '15-Closed'
		  AND TicketNumber   in (3469)	
		AND AB.BillingDate is null


		UPDATE AB
		SET AB.CMASProductCode = [CMASProductName] 
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling] AB (nolock) 
		WHERE CMASProductCode like 'Bul' 
		and CMASProductCode  <> [CMASProductName]
		 and Status = '15-Closed'
		 AND AB.BillingDate is null
		   AND TicketNumber   in (3469)	



		
	-- Update the automated billing table with the Oracle product code and name based on the lookup table.
		UPDATE AB
		SET AB.OracleProductCode = AP.OracleProductCode,
		AB.OracleProductName = AP.OracleProductName
		 --SELECT *
		FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AB (nolock) 
		JOIN [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[Lkup_AutomatedProduct] AP (nolock) 
		ON AB.CMASProductCode = AP.CMASProductCode
		where AB.Status = '15-Closed'
		  AND TicketNumber   in (3469)	
		AND AB.BillingDate is null
		

	

	-- Update TotalBillableUnits based on BillingOption
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.automatedbilling
		SET TotalBillableUnits = case
		when substring(BillingOption,1,1) = '1' then TotalRecords
		when substring(BillingOption,1,1) = '2' then TotalMatched
		when substring(BillingOption,1,1) = '3' and CMASProductCode != 'S10' then TotalWithEventsFound
		when substring(BillingOption,1,1) = '3' and CMASProductCode = 'S10' then TotalPropertiesFound
		when substring(BillingOption,1,1) = '4' then TotalRecords + TotalWithEventsFound
		when substring(BillingOption,1,1) like '%Monitor%' then TotalPropertiesFound
		else 0 end 
		where CMASProductCode != 'S50'
		and Status = '15-Closed'
		  AND TicketNumber   in (3469)	
		AND BillingDate is null


		
		
		   --Select * From [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		   --where  TicketNumber   in (3469)	

		   --Update [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
		   --Set TotalWithEventsFound = 1
		   --where  TicketNumber   in (3469)	


		   --Select * From  zCust_Auction.dbo.[AUCTION_BILLING]
		   --where [Reference Number] in (
		   --Select [Reference Number] from (
		   --Select [Reference Number], count(*) as TOTAL from  zCust_Auction.dbo.[AUCTION_BILLING] A --Where RecordFlag = 'A'
		   --Group by [Reference Number]
		   --having count(*) > 1)A)
		   --Order by [Reference Number]
		

		

		-- Update Billing date to getdate()
		UPDATE [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling]
		SET 
		BillingDate = GETDATE()
		,PROCESSED_YN = 'Y'
		WHERE 
		[AccountNumber] IS NOT NULL 
		AND [BillingOption] IS NOT NULL 
		AND [CMASProductCode] IS NOT NULL 
		AND [ContractExecuted] = 'Yes' 
		AND OracleProductCode is not NULL
		AND [BatchType] is not null
		AND STATUS like '15-Closed'
		and BillingDate is null
		AND TotalBillableUnits > 0
		   AND TicketNumber   in (3469)	
				



	
INSERT INTO [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] (
       [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,[ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO)
SELECT [Id]
      ,[AppSource]
      ,[BatchId]
      ,[BatchType]
      ,[CreateDate]
      ,[ImportDate]
      ,[TotalRecords]
      ,[TotalMatched]
      ,[TotalUnMatched]
      ,[TotalDuplicate]
      ,[TotalExpired]
      ,[TotalInCoverage]
      ,[TotalNotInCoverage]
      ,[TotalPropertiesFound]
      ,[TotalPropertiesNotFound]
      ,[IsBillable]
      ,[TotalMultiplePropertiesFound]
      ,[TotalAddressStandardized]
      ,[TotalAddressNotStandardized]
      ,[TotalWithEventsFound]
      ,[TotalWithoutEventsFound]
      ,[TicketNumber]
      ,[BillingDate]
      ,GETDATE() -- [ExtractionDate]
      ,[BillingOption]
      ,[AccountNumber]
      ,[DaysToMonitor]
      ,[CustomerName]
      ,[ClientName]
      ,[CMASProductCode]
      ,[CMASProductName]
      ,[OracleProductCode]
      ,[OracleProductName]
      ,[Title]
      ,[DocImageCounts]
      ,[MonitorEndDate]
      ,[TotalBillableUnits]
      ,[ContractExecuted]
	  ,SOW
	  ,WO
 FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBilling]
	WHERE 
	(BillingDate IS NOT NULL and PROCESSED_YN = 'Y')
	 AND TicketNumber   in (3469)	




 
	--DELETE A
	----Select * 
	--FROM [AZUVPSQLDTDB029.datatree.local].[CMAS].dbo.[AutomatedBilling] AS A
	--inner join [AZUVPSQLDTDB029.datatree.local].[CMAS].[dbo].[AutomatedBillingHistory] as B on 
	--A.TicketNumber = B.TicketNumber
	--and 
	--A.BillingDate = B.BillingDate
	--and 
	--ISNULL(A.TotalRecords,'') = ISNULL(B.TotalRecords,'')
	--and
	--ISNULL(A.TotalBillableUnits,'') = ISNULL(B.TotalBillableUnits,'')
	--AND
	--A.BatchID = B.BatchID
 --   WHERE A.BillingDate IS NOT NULL 
	-- AND A.TicketNumber   in (3469)	

	




END








