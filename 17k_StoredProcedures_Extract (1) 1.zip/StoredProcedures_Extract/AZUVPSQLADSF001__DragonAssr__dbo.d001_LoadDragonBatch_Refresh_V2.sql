SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================

CREATE PROCEDURE [dbo].[d001_LoadDragonBatch_Refresh_V2]
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)

		BEGIN
	
				DECLARE @2 varchar(255) = 'micsmith@firstam.com;klowe@firstam.com;jeschmeyer@firstam.com', 
				@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject2 varchar(50) = 'Dragon Assr Refresh Pull Started',
				@t_body2 varchar(2000) = 'The Dragon Assr Data Pull process has started.'


				SET NOCOUNT ON;
				DECLARE @t_getdate2 datetime = GETDATE()
				SET @t_body2 = @t_body2 + ' : ' + cast(@t_getdate2 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					-- @recipients = @t_recipients,
					@recipients = @2,
					@profile_name = @t_profile_name2,
					@subject = @t_subject2,
					@body = @t_body2
---------------------------------------------------------------------------------------------------------------------
		TRUNCATE TABLE DragonAssr.dbo.DragonProcessingTracker

		INSERT INTO DragonAssr.dbo.DragonProcessingTracker
		Select 'STEP 1 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		Insert into Dragon_Refresh_Tracker(Fips,State,County,RunRefresh,NEW)
		Select c.FIPSCode,c.State,c.[County Name],'Y','Y'
		FROM Global.dbo.County c 
				join (Select Fips from [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR with(NOLOCK) where source_type = 'G' group by Fips) b
				on c.Fipscodenum = b.FIPS

		INSERT INTO dbo.DragonRefreshesToCheck(FIPS,CREATED)
		Select FIPS,MAX(CREATED) CREATED 
		from dragonassr.dbo.Dragon_Flank_Refreshes
		GROUP BY FIPS

		UPDATE a
		SET a.RunNow = 'Y'
		FROM dbo.DragonRefreshesToCheck a JOIN (Select FIPS,Max(CREATED) as MaxCreated FROM [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR WHERE FIPS in(Select FIPS from dbo.DragonRefreshesToCheck) Group by FIPS) b
		ON a.FIPS = b.FIPS
		WHERE b.MaxCreated >= a.CREATED

		Update a
			SET a.runRefresh = 'Y'
			,a.Created = b.CREATED
			FROM dragonassr.dbo.Dragon_Refresh_Tracker a
			JOIN (Select distinct FIPS,CREATED from dbo.DragonRefreshesToCheck WHERE RunNow = 'Y') b
			on convert(int,a.FIPS) = b.FIPS

			TRUNCATE TABLE dbo.DragonRefreshesToCheck

			DROP TABLE IF EXISTS DragonAssr.dbo.Dragon_Flank_Batch_ASSR_temp
			Truncate Table DragonAssr.dbo.Dragon_Flank_Batch_ASSR

			DROP INDEX IF EXISTS [ix_FipsFormatted] ON DragonAssr.dbo.[Dragon_Flank_Batch_ASSR]

			CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsFormatted] ON [dbo].[Dragon_Flank_Batch_ASSR]
			(
				[FIPS] ASC,
				[APN_SEQUENCE_NBR] ASC,
				[FORMATTED_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			DROP INDEX IF EXISTS [ix_FipsUnFormattedAPN] ON DragonAssr.dbo.[Dragon_Flank_Batch_ASSR]

			-- Select * from dbo.Dragon_Refresh_Tracker where RunRefresh = 'Y'

			SELECT a.*,0 as MatchCode,convert(varchar(5),'') as FipsCode,convert(bigint,0) as PropertyID
			INTO DragonAssr.dbo.Dragon_Flank_Batch_ASSR_Temp
			  FROM [AZUVPSQLDTDB029.DATATREE.LOCAL].ASSR.dbo.ASSR a with(NOLOCK) JOIN DragonAssr.dbo.Dragon_Refresh_Tracker b
			  on a.FIPS = convert(int,b.FIPS)
			  WHERE b.[RunRefresh] = 'Y'
				--and a.CREATED >= b.Created

			INSERT INTO DragonAssr.dbo.Dragon_Flank_Batch_ASSR
			Select * from DragonAssr.dbo.Dragon_Flank_Batch_ASSR_Temp

			TRUNCATE TABLE DragonAssr.dbo.Dragon_Flank_Batch_ASSR_Temp
			Delete from DragonAssr.dbo.Dragon_Flank_Refreshes where FIPS in(Select distinct FIPS from DragonAssr.dbo.Dragon_Flank_Batch_ASSR)

			CREATE NONCLUSTERED INDEX [ix_FipsUnFormattedAPN] ON DragonAssr.dbo.[Dragon_Flank_Batch_ASSR]
			([FIPS] ASC,
				[UNFORMATTED_APN] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

			IF(SELECT COUNT(*) FROM DragonAssr.dbo.Dragon_Flank_Batch_ASSR) = 0
			BEGIN
				RETURN;
			END

		INSERT INTO DragonAssr.dbo.DragonProcessingTracker
		Select 'STEP 1 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

			EXEC [dbo].[002_remove_Extra_Ascii_from_table] 'Dragon_Flank_Batch_ASSR'

		----- CLEAN LEAD ZEROS
			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET SITUS_HOUSE_NBR = Global.dbo.DeleteLeadZeros(SITUS_HOUSE_NBR)
			WHERE SITUS_HOUSE_NBR like '00%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET SITUS_STREET_NAME = Global.dbo.DeleteLeadZeros(SITUS_STREET_NAME)
			WHERE SITUS_STREET_NAME like '00%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET SITUS_UNIT_NBR = Global.dbo.DeleteLeadZeros(SITUS_UNIT_NBR)
			WHERE SITUS_UNIT_NBR like '00%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET MAIL_HOUSE_NBR = Global.dbo.DeleteLeadZeros(MAIL_HOUSE_NBR)
			WHERE MAIL_HOUSE_NBR like '00%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET MAIL_STREET_NAME = Global.dbo.DeleteLeadZeros(MAIL_STREET_NAME)
			WHERE MAIL_STREET_NAME like '00%'

			UPDATE dbo.[Dragon_Flank_Batch_ASSR]
			SET MAIL_UNIT_NBR = Global.dbo.DeleteLeadZeros(MAIL_UNIT_NBR)
			WHERE MAIL_UNIT_NBR like '00%'

		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

	----- FILL IN FIPSCODE AND REF_ID AND PROPERTYID
		UPDATE a
		SET Fipscode = RIGHT('0' + convert(varchar(5),FIPS),5)
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a
		WHERE isNULL(Fipscode,'') like ''

		DROP INDEX IF EXISTS [ix_FipsCodeFormattedAPN] ON [dbo].[Dragon_Flank_Batch_ASSR]
		DROP INDEX IF EXISTS [ix_FipsCodeUnFormattedAPN] ON [dbo].[Dragon_Flank_Batch_ASSR]
		DROP INDEX IF EXISTS [ix_FipsCodeREFID] ON [dbo].[Dragon_Flank_Batch_ASSR]

		CREATE NONCLUSTERED INDEX [ix_FipsCodeFormattedAPN] ON [dbo].[Dragon_Flank_Batch_ASSR]
		([FipsCode] ASC,
			[FORMATTED_APN] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		CREATE NONCLUSTERED INDEX [ix_FipsCodeUnFormattedAPN] ON [dbo].[Dragon_Flank_Batch_ASSR]
		([FipsCode] ASC,
			[UNFORMATTED_APN] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		CREATE NONCLUSTERED INDEX [ix_FipsCodeREFID] ON [dbo].[Dragon_Flank_Batch_ASSR]
		([FipsCode] ASC,
			[REF_ID] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		

		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.FipsCode = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.UnformattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.UnFormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET PropertyID = b.PropertyID
		FROM dbo.Dragon_Flank_Batch_ASSR a JOIN Data.dbo.Property b with(NOLOCK)
		ON a.FIPSCODE = b.FIPS
		and a.[UNFORMATTED_APN] = b.TaxAccountNumber
		WHERE isNULL(a.PropertyID,0) = 0 

		update dbo.Dragon_Flank_Batch_ASSR
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR] with(NOLOCK)
		WHERE PropertyID is not null
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)

		--DROP TABLE IF EXISTS dbo.DragonAssrCounts

		--DECLARE @CertDt Varchar(8) = Convert(varchar(8),GETDATE()-90,112)


		
		--EXEC('Select x.FIPSCode,x.RecCount,x.RecordsInTaxroll,x.CERTIFICATION_DATE,CASE WHEN x.RecCount between x.RecordsInTaxroll -(x.RecordsinTaxroll * .10) and x.RecordsInTaxroll +(x.RecordsinTaxroll * .10) THEN ''REFRESH'' ELSE ''UPDATE'' END as RefreshUpdate
		--INTO DragonAssrCounts
		--FROM(
		--	SELECT a.FipsCode,COUNT(*) as RecCount,RecordsinTaxroll,'''+@CertDt+''' as CERTIFICATION_DATE
		--	FROM [dbo].[Dragon_Flank_Batch_ASSR] a JOIN Global.dbo.County b
		--	on a.FipsCode = b.FIPSCode
		--	GROUP BY a.FipsCode,RecordsinTaxroll
		--	) X
		--	ORDER BY x.FipsCode
		--')

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 


		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

			EXEC [dbo].[d005_DragonAssrLoad_Refresh_Looper]

		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 

			Select FIPScode,[CERTIFICATION_DATE],COUNT(*) as CNT 
			INTO #CertDt
			from DragonAssr.[dbo].[Dragon_Flank_Batch_ASSR] GROUP BY FIPSCode,[CERTIFICATION_DATE]

			Select a.Fipscode,[CERTIFICATION_DATE],Cnt 
			INTO #CertDtUSE
			from #CertDt a JOIN (Select FiPSCode,Max(Cnt) maxCnt from #CertDt group by Fipscode) b
			on a.fipscode = b.fipscode
			and a.cnt = b.maxcnt

					UPDATE a
					SET a.CertificationDate = convert(varchar(8),cast(b.[CERTIFICATION_DATE] as Date),112)
					FROM Global.dbo.County a JOIN #CertDtUSE b
					ON a.Fipscode = b.Fipscode

			DROP TABLE IF EXISTS #CertDt
			DROP TABLE IF EXISTS #CertDtUSE

			UPDATE  a
			SET Created =  MaxCreate
				  ,Updated = MaxUpdate
				  ,DateLastRefresh = Getdate()
			FROM dbo.Dragon_Refresh_Tracker a JOIN (
				SELECT FipsCode, Max([CREATED]) MaxCreate,Max([UPDATED]) MaxUpdate
				  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR]
				  GROUP BY FipsCode
				  )b 
			ON a.FIPS = b.FipsCode
			  WHERE [RunRefresh] = 'Y'


			UPDATE a
			SET a.SrcProperty = 'DRG'
			,a.SrcPropertyStartDate = convert(varchar(8),Getdate(),112)
			FROM Global.dbo.County a JOIN [DragonAssr].[dbo].[Dragon_Refresh_Tracker] b 
			ON a.FIPSCode = b.Fips
			WHERE [RunRefresh] = 'Y'
				and a.SrcProperty != 'DRG'

			DELETE FROM dbo.DragonRefreshesToCheck
			WHERE FIPS in(Select FIPS from DragonAssr.dbo.Dragon_Refresh_Tracker WHERE [RunRefresh] = 'Y')

			UPDATE DragonAssr.dbo.Dragon_Refresh_Tracker
			  SET [RunRefresh] = 'D'
				,[DateLastRefresh] = Getdate()
			  WHERE [RunRefresh] = 'Y'


			DECLARE @3 varchar(355) = 'micsmith@firstam.com;klowe@firstam.com;jeschmeyer@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon Assr Pull Finished',
				@t_body3 varchar(2000) = 'The Dragon Assr Data pull process has finished. Run d800 only after jobs finish'


				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + ' : ' + cast(@t_getdate3 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3

	END


END

