SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[ASP_counts] -- add @table default all tables
as  
BEGIN

-- SSIS run package: Quarterly_ASP.Projects.Quarterly_ASP.Packages.RunASP.dtsx
------------------------------------------------------------------------------------------------------------------------------------------------
-- Check for minimum ASP dates per component
set nocount on
select min(faaddressparsedsitus) as assignment_situs_ASP_min_date from data.dbo.assignment with (nolock) --
select min(faaddressparsedsitus) as building_situs_ASP_min_date from data.dbo.building with (nolock) --
select min(faaddressparsedbuyermail) as deed_Buyermail_ASP_min_date from data.dbo.deed with (nolock) where BuyerMailForeignAddrInd IS NULL -- 
select min(faaddressparsedsellermail) as deed_sellermail_ASP_min_date from data.dbo.deed with (nolock) where SellerMailForeignAddrInd IS NULL -- 
select min(faaddressparsedsitus) as deed_situs_ASP_min_date from data.dbo.deed with (nolock) -- 
select min(FAAddressParsedMailing) as foreclosure_mailing_ASP_min_date from data.dbo.foreclosure with (nolock) where MailForeignAddrInd IS NULL -- 
select min(faaddressparsedsitus) as foreclosure_situs_ASP_min_date from data.dbo.foreclosure with (nolock) -- 
select min(FAAddressParsedTrustee) as foreclosure_trustee_ASP_min_date from data.dbo.foreclosure with (nolock) where TrusteeForeignAddrInd IS NULL -- 
select min(faaddressparsedborrower) as mortgage_borrower_ASP_min_date from data.dbo.mortgage with (nolock) where BorrowerMailForeignAddrInd IS NULL -- 
select min(faaddressparsedlender) as mortgage_lender_ASP_min_date from data.dbo.mortgage with (nolock) where LenderMailForeignAddrInd IS NULL -- 
select min(faaddressparsedsitus) as mortgage_situs_ASP_min_date from data.dbo.mortgage with (nolock) -- 
select min(faaddressparsedmailing) as property_mailing_ASP_min_date from data.dbo.property with (nolock) where MailForeignAddrInd IS NULL -- 
select min(faaddressparsedsitus) as property_situs_ASP_min_date from data.dbo.property with (nolock) -- 
select min(faaddressparsedsitus) as release_situs_ASP_min_date from data.dbo.release with (nolock) -- 
set nocount off 

------------------------------------------------------------------------------------------------------------------------------------------------
-- SELECT TOP (1000) * FROM [Addr].[dbo].[STDTrigger] order by [TriggerId] desc

/* Set indiviual componenets to run. Runs best with 3 or less in parallel
select * from AddressSTD.dbo.Quarterly_asp_process_list A
update A set process = 'F' from AddressSTD.dbo.Quarterly_asp_process_list A
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Assignment_Situs' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Building_Situs'
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Deed_Buyermail' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Deed_Sellermail' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Deed_Situs' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Foreclosure_Mailing' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Foreclosure_Situs'  
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Foreclosure_Trustee' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Mortgage_Borrower' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Mortgage_Lender'
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Mortgage_Situs'
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Property_Mailing' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Property_Situs' 
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Release_Situs'
update A set process = 'T' from AddressSTD.dbo.Quarterly_asp_process_list A where project = 'Property_MailingCAN'
*/

/*
--monthly trigger clean up.
SELECT TOP 100 * FROM [Addr].[dbo].[STDTrigger] order by [TriggerId] desc 
SELECT TOP 100 * FROM [Addr].[dbo].[STDTrigger] order by [TriggerId] 
SELECT count(*) FROM [Addr].[dbo].[STDTrigger] 
SELECT count(*) FROM [Addr].[dbo].[STDTrigger] where CreatedDateTime < DATEADD(day, -45, getdate())
SELECT TOP 100 * FROM [Addr].[dbo].[STDTrigger] where CreatedDateTime < DATEADD(day, -45, getdate()) order by [TriggerId] desc
--delete FROM [Addr].[dbo].[STDTrigger] where CreatedDateTime < DATEADD(day, -45, getdate())
*/

------------------------------------------------------------------------------------------------------------------------------------------------
/* Check after updates assignments

-- situs -------------------------------------------------------------------------------------------------------------
select top 10000 faaddressparsedsitus,* from data.dbo.assignment with (nolock) where faaddressparsedsitus > '2026-08-12 08:30:00.000' and faaddressparsedsitus != '2099-12-31 00:00:00.000' --order by faaddressparsedsitus desc
select count(*) as assignment_situs_ASP_not_parsed from data.dbo.assignment with (nolock) where faaddressparsedsitus is null -- 
select count(*) as assignment_situs_ASP from data.dbo.assignment with (nolock) where faaddressparsedsitus is not null --

-- additonal checks if needed
select top 10000 faaddressparsedsitus,* from data.dbo.property with (nolock) where faaddressparsedsitus > Convert(datetime, '2026-01-08 03:00:00.000') and FAAddressParsedSitus != '2099-12-31 00:00:00.000' -- and MailForeignAddrInd IS NULL 
select count(*) as property_situs_ASP_not_parsed from data.dbo.property with (nolock) where faaddressparsedsitus is null
select count(*) as property_situs_ASP from data.dbo.property with (nolock) where faaddressparsedsitus is not null

select top 1000 * from data.dbo.building with (nolock) where faaddressparsedsitus > '2020-07-09 05:30:00.000' and faaddressparsedsitus != '2099-12-31 00:00:00.000' and len(SitusStdFullStreetAddress) > 0
    order by faaddressparsedsitus desc
select count(*) as building_situs_ASP_not_parsed from data.dbo.building with (nolock) where faaddressparsedsitus is null
select count(*) as building_situs_ASP from data.dbo.building with (nolock) where faaddressparsedsitus is not null

select top 10000 faaddressparsedsitus,* from data.dbo.deed with (nolock) where faaddressparsedsitus > '2026-01-07 01:20:00.000' and faaddressparsedsitus != '2099-12-31 00:00:00.000' 
select count(*) as deed_situs_ASP_not_parsed from data.dbo.deed with (nolock) where faaddressparsedsitus is null
select count(*) as deed_situs_ASP from data.dbo.deed with (nolock) where faaddressparsedsitus is not null

select top 1000 * from data.dbo.foreclosure with (nolock) where faaddressparsedsitus > '2020-03-16 11:15:00.000' order by faaddressparsedsitus desc 
select count(*) as foreclosure_situs_ASP_not_parsed from data.dbo.foreclosure with (nolock) where faaddressparsedsitus is null
select count(*) as foreclosure_situs_ASP from data.dbo.foreclosure with (nolock) where faaddressparsedsitus is not null

select top 1000 * from data.dbo.mortgage with (nolock) where faaddressparsedsitus > '2020-03-16 11:15:00.000' -- and len([SitusFullStreetAddress]) > 0
select top 10000 faaddressparsedsitus,* from data.dbo.mortgage with (nolock) where faaddressparsedsitus > '2021-04-15 08:40:00.000' and faaddressparsedsitus != '2099-12-31 00:00:00.000' --order by faaddressparsedsitus desc
select count(*) as mortgage_situs_ASP_not_parsed from data.dbo.mortgage with (nolock) where faaddressparsedsitus is null
select count(*) as mortgage_situs_ASP from data.dbo.mortgage with (nolock) where faaddressparsedsitus is not null

select top 1000 faaddressparsedsitus,* from data.dbo.release with (nolock) where faaddressparsedsitus > Convert(datetime, '2020-04-27 12:15:00.000') and faaddressparsedsitus != '2099-12-31 00:00:00.000' 
select count(*) as release_situs_ASP_not_parsed from data.dbo.release with (nolock) where faaddressparsedsitus is null
select count(*) as release_situs_ASP from data.dbo.release with (nolock) where faaddressparsedsitus is not null

-- non situs -------------------------------------------------------------------------------------------------------------
select top 1000 faaddressparsedmailing,fadatereceived,mailingstdfullstreetaddress,* from data.dbo.property with (nolock) where faaddressparsedmailing > Convert(datetime, '2020-01-01 04:00:00.000' ) and len(mailingstdfullstreetaddress) > 1
select count(*) as property_mailing_ASP_not_parsed from data.dbo.property with (nolock) where faaddressparsedmailing is null and MailForeignAddrInd is null
select count(*) as property_mailing_ASP from data.dbo.property with (nolock) where faaddressparsedmailing is not null and MailForeignAddrInd is null 

select top 1000 * from data.dbo.deed with (nolock) where faaddressparsedbuyermail > '2021-05-25 03:20:00.000' and len(buyermailfulladdress) > 1 and faaddressparsedbuyermail != '2099-12-31 00:00:00.000' order by faaddressparsedbuyermail desc 
select count(*) as deed_Buyermail_ASP_not_parsed from data.dbo.deed with (nolock) where faaddressparsedbuyermail is null and BuyerMailForeignAddrInd is null
select count(*) as deed_Buyermail_ASP from data.dbo.deed with (nolock) where FAAddressParsedBuyermail is not null and BuyerMailForeignAddrInd is null

select top 1000 d.faaddressparsedsellermail,* from data.dbo.deed d with (nolock) where d.faaddressparsedsellermail > '2026-01-05 02:00:00.000' and d.faaddressparsedsellermail != '2099-12-31 00:00:00.000' order by d.faaddressparsedsellermail desc
select count(*) as deed_Sellermail_ASP_not_parsed from data.dbo.deed with (nolock) where faaddressparsedsellermail is null and SellerMailForeignAddrInd is null
select count(*) from data.dbo.deed with (nolock) where SellerMailFullAddress is not null
 
select top 1000 * from data.dbo.foreclosure with (nolock) where FAAddressParsedMailing > '2020-03-16 11:15:00.000' and len(MailingFullStreetAddress) > 0 and MailForeignAddrInd is null
select count(*) as foreclosure_mailing_ASP_not_parsed from data.dbo.foreclosure with (nolock) where FAAddressParsedMailing is null and MailForeignAddrInd is null
select count(*) as foreclosure_mailing_ASP from data.dbo.foreclosure with (nolock) where FAAddressParsedMailing is not null and MailForeignAddrInd is null

select top 1000 * from data.dbo.foreclosure with (nolock) where FAAddressParsedTrustee > '2020-03-16 11:15:00.000' 
select count(*) as foreclosure_trustee_ASP_not_parsed from data.dbo.foreclosure with (nolock) where FAAddressParsedTrustee is null and TrusteeForeignAddrInd is null
select count(*) as foreclosure_trustee_ASP from data.dbo.foreclosure with (nolock) where FAAddressParsedTrustee is not null and TrusteeForeignAddrInd is null

select top 1000 * from data.dbo.mortgage with (nolock) where faaddressparsedborrower > '2020-03-16 11:15:00.000' and len([BorrowerFullMailAddress]) > 0 order by faaddressparsedborrower desc
select count(*) as mortgage_borrower_ASP_not_parsed from data.dbo.mortgage with (nolock) where faaddressparsedborrower is null and BorrowerMailForeignAddrInd is null
select count(*) as mortgage_borrower_ASP from data.dbo.mortgage with (nolock) where faaddressparsedborrower is not null and BorrowerMailForeignAddrInd is null

select top 1000 m.faaddressparsedlender,* from data.dbo.mortgage m with (nolock) where m.faaddressparsedlender > '2020-10-15 13:45:00.000' and len([lenderFullMailAddress]) > 0 order by m.faaddressparsedlender desc
select count(*) as mortgage_lender_ASP_not_parsed from data.dbo.mortgage with (nolock) where faaddressparsedlender is null and lenderMailForeignAddrInd is null
select count(*) as mortgage_lender_ASP from data.dbo.mortgage with (nolock) where faaddressparsedlender is not null and lenderMailForeignAddrInd is null
*/


------------------------------------------------------------------------------------------------------------------------------------------------
/* Check or set daily load flag to turn ASP on or off
select * from staging.dbo.md_ssis_config
update staging.dbo.md_ssis_config
set staging_running = 'F' -- T stops ASP and F let's it run
*/


------------------------------------------------------------------------------------------------------------------------------------------------
/* Check component counts, plug in date as needed
select 'Building Situs' as tableName, 
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.building) as total 
from data.dbo.building with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-05-31 04:00:00.000' )

select 'Property Situs' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.property) as total 
from data.dbo.property with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-05-31 04:00:00.000' )

select 'Deed Buyer' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.deed) as total 
from data.dbo.deed with (nolock) where FAAddressParsedBuyermail > Convert(datetime, '2016-06-24 04:00:00.000' )

select 'Mortgage Lender' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.mortgage) as total 
from data.dbo.mortgage with (nolock) where FAAddressParsedLender > Convert(datetime, '2016-06-23 06:00:00.000' )

select 'Assignment Situs' as tableName, 
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.Assignment) as total 
from data.dbo.Assignment with (nolock) where FAAddressParsedSitus > Convert(datetime, '2017-04-12 09:00:00.000' )

select 'Property Mailing' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.property) as total 
from data.dbo.property with (nolock) where FAAddressParsedMailing > Convert(datetime, '2016-04-19 04:00:00.000' )

select 'Mortgage Borrower' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.mortgage) as total 
from data.dbo.mortgage with (nolock) where FAAddressParsedBorrower > Convert(datetime, '2016-06-23 06:00:00.000' )

select 'Mortgage Situs' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.mortgage) as total 
from data.dbo.mortgage with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-04-09 04:00:00.000' )

select 'Deed Situs' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.deed) as total 
from data.dbo.deed with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-06-24 04:00:00.000' )

select 'Release Situs' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.Release) as total 
from data.dbo.Release with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-05-25 04:00:00.000' )

select 'Foreclosure Trustee' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.Foreclosure) as total 
from data.dbo.Foreclosure with (nolock) where FAAddressParsedTrustee > Convert(datetime, '2016-05-25 04:00:00.000' )

select 'Deed Seller' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.deed) as total 
from data.dbo.deed with (nolock) where FAAddressParsedSellermail > Convert(datetime, '2016-04-11 04:00:00.000' )

select 'Foreclosure Situs' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.Foreclosure) as total 
from data.dbo.Foreclosure with (nolock) where FAAddressParsedSitus > Convert(datetime, '2016-05-25 04:00:00.000' )

select 'Foreclosure Mailing' as tableName,
replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') as done,
(select replace(CONVERT(varchar, CAST(count(fips) AS money), 1),'.00','') from data.dbo.Foreclosure) as total 
from data.dbo.Foreclosure with (nolock) where FAAddressParsedMailing > Convert(datetime, '2016-04-09 04:00:00.000' )
*/

/* null addressparsed field
select count(*) from data.dbo.assignment with (nolock) where faaddressparsedsitus between '2020-03-16 00:0:00.000' and '2020-03-31 00:0:00.000' -- 34435824
select faaddressparsedsitus,* from data.dbo.assignment with (nolock) where faaddressparsedsitus between '2020-03-16 00:0:00.000' and '2020-03-31 00:0:00.000' -- 34435824
--  update data.dbo.assignment set faaddressparsedsitus = null, FAUSERID = 'MelissaGeoCodeIssue' where faaddressparsedsitus between '2020-03-16 00:0:00.000' and '2020-03-31 00:0:00.000' -- running

select count(*) from data.dbo.building with (nolock) where faaddressparsedsitus between '2020-03-16 00:0:00.000' and '2020-03-31 00:0:00.000' -- 
--  update data.dbo.building set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --

select count(*) from data.dbo.deed with (nolock) where faaddressparsedbuyermail between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and BuyerMailForeignAddrInd IS NULL -- 
--  update data.dbo.deed set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedbuyermail between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and BuyerMailForeignAddrInd IS NULL --	

select count(*) from data.dbo.deed with (nolock) where faaddressparsedsellermail between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and SellerMailForeignAddrInd IS NULL -- 
--  update data.dbo.deed set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsellermail between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and SellerMailForeignAddrInd IS NULL --	
			 
select count(*) from data.dbo.deed with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 
--  update data.dbo.deed set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --

select count(*) from data.dbo.foreclosure with (nolock) where FAAddressParsedMailing between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and MailForeignAddrInd IS NULL -- 
--  update data.dbo.foreclosure set FAAddressParsedMailing = null, fatimestamp = '2020-03-25' where FAAddressParsedMailing between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and MailForeignAddrInd IS NULL --

select count(*) from data.dbo.foreclosure with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 
--  update data.dbo.foreclosure set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --

select count(*) from data.dbo.foreclosure with (nolock) where FAAddressParsedTrustee between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and TrusteeForeignAddrInd IS NULL -- 
--  update data.dbo.foreclosure set FAAddressParsedTrustee = null, fatimestamp = '2020-03-25' where FAAddressParsedTrustee between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and TrusteeForeignAddrInd IS NULL --

select count(*) from data.dbo.mortgage with (nolock) where faaddressparsedborrower between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and BorrowerMailForeignAddrInd IS NULL -- 
--  update data.dbo.mortgage set faaddressparsedborrower = null, fatimestamp = '2020-03-25' where faaddressparsedborrower between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and BorrowerMailForeignAddrInd IS NULL --

select count(*) from data.dbo.mortgage with (nolock) where faaddressparsedlender between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and LenderMailForeignAddrInd IS NULL -- 
--  update data.dbo.mortgage set faaddressparsedlender = null, fatimestamp = '2020-03-25' where faaddressparsedlender between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and LenderMailForeignAddrInd IS NULL --

select count(*) from data.dbo.mortgage with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 
--  update data.dbo.mortgage set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --

select count(*) from data.dbo.property with (nolock) where faaddressparsedmailing between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and MailForeignAddrInd IS NULL -- 
--  update data.dbo.property set faaddressparsedmailing = null, fatimestamp = '2020-03-25' where faaddressparsedmailing between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' and MailForeignAddrInd IS NULL --

select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --





--select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-24 12:00:00.000' -- 60,297,763 -- 31838933
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-22 00:00:00.000' -- 1,559,817
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-22 00:00:00.000' and '2020-03-22 12:00:00.000' -- 13,393,262
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-22 12:00:00.000' and '2020-03-22 18:00:00.000' -- 13481435
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-22 18:00:00.000' and '2020-03-23 00:00:00.000' -- 18776350
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-23 00:00:00.000' and '2020-03-24 12:00:00.000' -- 13062583
--  update data.dbo.property set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --
select count(*) from data.dbo.property with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 

-- 20200324 evening
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-22 00:0:00.000' --  1559817
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-22 00:00:00.000' and '2020-03-22 12:0:00.000' -- 13393262
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-22 12:00:00.000' and '2020-03-22 18:0:00.000' -- 13481435
select count(*) from data.dbo.property with (nolock) where FAUserId = '20200324 Melissa Geo Fix' and faaddressparsedsitus is null -- ‭14,953,079‬ -- 0 -- 13,481,435 -- 0
select top 1000 SitusCensusBlock,SitusCensusTract,SitusStdCity,SitusStdState,SitusStdZIP5,SitusStdZIP4,SitusGeoCodeResults,SitusGeoErrorCode,SitusGeoStatusCode,* from data.dbo.property with (nolock) where FAUserId = '20200324 Melissa Geo Fix'
select top 1000 SitusCensusBlock,SitusCensusTract,FAUserId,SitusStdCity,SitusStdState,SitusStdZIP5,SitusStdZIP4,SitusGeoCodeResults,SitusGeoErrorCode,SitusGeoStatusCode,* from data.dbo.property with (nolock) where SitusStdCity = 'West Hills' and SitusStdState = 'CA' and SitusStdZIP5 = '91304' and SitusStdFullStreetAddress = '8314 Mariposa Ct'
-- 20200324 evening

-- 20200325
--update top (5000000) data.dbo.property set fatimestamp = '2020-03-25', FAUserId = '20200324 Melissa Geo Fix Delivered' where FAUserId = '20200324 Melissa Geo Fix' --

-- 20200325 evening
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-22 18:00:00.000' and '2020-03-23 00:00:00.000' -- 18776350
update data.dbo.property set faaddressparsedsitus = null, FAUserId = '20200324 Melissa Geo Fix' where faaddressparsedsitus between '2020-03-23 00:00:00.000' and '2020-03-24 12:0:00.000' -- 13062583
select count(*) from data.dbo.property with (nolock) where FAUserId = '20200324 Melissa Geo Fix' and faaddressparsedsitus is null -- ‭14,953,079‬ -- 0 -- 13,481,435 -- 0 -- 14987117
select top 1000 SitusCensusBlock,SitusCensusTract,SitusStdCity,SitusStdState,SitusStdZIP5,SitusStdZIP4,SitusGeoCodeResults,SitusGeoErrorCode,SitusGeoStatusCode,* from data.dbo.property with (nolock) where FAUserId = '20200324 Melissa Geo Fix'
select top 1000 SitusCensusBlock,SitusCensusTract,FAUserId,SitusStdCity,SitusStdState,SitusStdZIP5,SitusStdZIP4,SitusGeoCodeResults,SitusGeoErrorCode,SitusGeoStatusCode,* from data.dbo.property with (nolock) where SitusStdCity = 'West Hills' and SitusStdState = 'CA' and SitusStdZIP5 = '91304' and SitusStdFullStreetAddress = '8314 Mariposa Ct'
-- 20200325 evening

select count(*) from data.dbo.property with (nolock) where FAUserId = '20200324 Melissa Geo Fix' 






select count(*) from data.dbo.release with (nolock) where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' -- 
--  update data.dbo.release set faaddressparsedsitus = null, fatimestamp = '2020-03-25' where faaddressparsedsitus between '2020-03-16 00:00:00.000' and '2020-03-31 00:0:00.000' --
 */

END

