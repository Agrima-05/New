SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20181022
-- =============================================
CREATE PROCEDURE [dbo].[usp_name_parser_unifiedV10_3] @tableName varchar(255), @RowCounts varchar(1) = 'Y', @MailingLabel varchar(1) = 'N'

AS
BEGIN

SET CONCAT_NULL_YIELDS_NULL OFF



--------------------------------------------------------------------- Section variables and syntax ---------------------------------------------------------------------
IF @RowCounts = 'N'
    BEGIN
    -- added for v7 to suppress count results
	SET NOCOUNT ON
	END
ELSE
    BEGIN
    -- added for v7 to not suppress count results
    SET NOCOUNT OFF
	END

declare @sql varchar(max) = ''

-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3' -- row counts and no mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'N' -- no row counts and no mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'Y' -- row counts and no mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'Y', @MailingLabel = 'Y' -- row counts and mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'Y', @MailingLabel = 'N' -- row counts and no mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'N', @MailingLabel = 'Y' -- no row counts and mailing label
-- SYNTAX -- EXEC usp_name_parser_unifiedV10_3 @tableName = 'NameWork_V10_3', @RowCounts = 'N', @MailingLabel = 'N' -- no row counts and no mailing label

/* create index on work table syntax 
CREATE NONCLUSTERED INDEX [Fips] ON [dbo].[NameWork_V10_3] ([Fips]) WITH (FILLFACTOR = 70)
CREATE NONCLUSTERED INDEX [FipsID] ON [dbo].[NameWork_V10_3] ([Fips],[ID]) WITH (FILLFACTOR = 70) 
CREATE NONCLUSTERED INDEX [ID] ON [dbo].[NameWork_V10_3] ([ID]) WITH (FILLFACTOR = 70)
*/

--set @sql = 'select ''A'',Name1First,Name1Work,Name1Last,Name2First,Name2Work,Name2Last,Name1fmt,Name2fmt,* from [dbo].['+@tableName+']' exec(@sql) -- testing display

--declare @tableName varchar(255) = 'NameWork_V10_3' -- , @RowCounts varchar(1) = 'Y', @MailingLabel varchar(1) = 'N' -- testing errors
--declare @sql varchar(max) = ''



--------------------------------------------------------------------- Section pre clean Name1 and Name2 ---------------------------------------------------------------------
   -- v10.2 added Check for non-ASCII characters in Name1
   /* -- test select non-ascii SQL
   declare @t_count int 
   select @t_count = count(*) from [dbo].[NameWork_V10_3] WHERE Name1 COLLATE Latin1_General_100_BIN2 LIKE '%[' + CHAR(0)+ '-' +CHAR(31) + CHAR(127)+ '-' +CHAR(255)+']%'
   select @t_count
   select Name1,Name2 from [dbo].[NameWork_V10_3] WHERE Name1 COLLATE Latin1_General_100_BIN2 LIKE '%[' + CHAR(0)+ '-' +CHAR(31) + CHAR(127)+ '-' +CHAR(255)+']%' or
                                                        Name2 COLLATE Latin1_General_100_BIN2 LIKE '%[' + CHAR(0)+ '-' +CHAR(31) + CHAR(127)+ '-' +CHAR(255)+']%'
   */
   declare @t_count1 int
   --declare @tableName varchar(255) = 'NameWork_V10_3'
   --declare @sql varchar(max) = ''
   set @sql = 'declare @t_count1 int 
               select @t_count1 = count(*) from [dbo].['+@tableName+'] WHERE Name1 COLLATE Latin1_General_100_BIN2 LIKE ''%['' + CHAR(0)+ ''-'' +CHAR(31) + CHAR(127)+ ''-'' +CHAR(255)+'']%''
               if @t_count1 > 0 
			   begin
				  select ''Name1 has a non-ASCII character(s)'' as WARNING_INFO
				  select Name1 from [dbo].['+@tableName+'] WHERE Name1 COLLATE Latin1_General_100_BIN2 LIKE ''%['' + CHAR(0)+ ''-'' +CHAR(31) + CHAR(127)+ ''-'' +CHAR(255)+'']%''
   				  return
			   end' 
   --print(@sql) 
   exec(@sql) 

   -- v10.2 added Check for non-ASCII characters in Name2
   declare @t_count2 int
   --declare @tableName varchar(255) = 'NameWork_V10_3'
   --declare @sql varchar(max) = ''
   set @sql = 'declare @t_count2 int 
               select @t_count2 = count(*) from [dbo].['+@tableName+'] WHERE Name2 COLLATE Latin1_General_100_BIN2 LIKE ''%['' + CHAR(0)+ ''-'' +CHAR(31) + CHAR(127)+ ''-'' +CHAR(255)+'']%''
               if @t_count2 > 0 
			   begin
                  select ''Name2 has a non-ASCII character(s)'' as WARNING_INFO
				  select Name2 from [dbo].['+@tableName+'] WHERE Name2 COLLATE Latin1_General_100_BIN2 LIKE ''%['' + CHAR(0)+ ''-'' +CHAR(31) + CHAR(127)+ ''-'' +CHAR(255)+'']%''
                  return
			   end' 
   --print(@sql) 
   exec(@sql) 

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ''''
   where Name2 is null'
   exec(@sql) -- v10.1 added section to change NULL Name2 to blank value. where? "([Name2] is not null and [Name2] not like '''')"

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(Name1,'':'','','')
   where Name1 like ''%:%'''
   exec(@sql) -- v10.2 -- Added to fix : rather than ,  --  BR 20210321

   -- doesn't fix issue Added V10.2 for spaces around Name1 (HAGSTROM , CRAIG) then creating a Name2fmt value when were isn't a Name2
   set @sql = 'update [dbo].['+@tableName+'] 
   set Name1 = replace(Name1,'', '','','')
   where Name1 like ''%, %'''
   exec(@sql) 

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ''O'' + substring(Name1,3,50)
   where Name1 like ''O %'''
   exec(@sql) -- v10.2 -- Added to fix O brian etc  --  BR 20210321 (ISSUE FIPS 53009)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ''O'' + substring(Name1,4,50)
   where Name1 like ''O  %'''
   exec(@sql) -- v10.2 -- Added to fix O brian etc  --  GM 20220929 (ISSUE FIPS 53009)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(Name1,2,99)
   where Name1 like ''&%'''
   exec(@sql) -- v10.1 added section to handle Name1 and Name2 starting with an &. This issue cause the following error: Invalid length parameter passed to the LEFT or SUBSTRING function.

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = substring(Name2,2,99)
   where Name2 like ''&%'''
   exec(@sql) -- v10.1 added section to handle Name1 and Name2 starting with an &. This issue cause the following error: Invalid length parameter passed to the LEFT or SUBSTRING function.

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] =  ltrim(rtrim(substring(name2,4,99)))
   from [dbo].['+@tableName+']
   where substring(name2,4,4) like substring(name1,1,4) and name2 like''de %'''
   exec(@sql) -- v10.2 -- Step Added to Handle DE and DE LA
  
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] =  ''DE'' + substring(name1,1,(len(ltrim(rtrim(name1))) -3))
   from [dbo].['+@tableName+']
   where name1 like''% de'' and substring(name1,1,2) not like''de'''
   exec(@sql) -- v10.2 -- Step Added to Handle DE and DE LA

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] =  substring(name1,1,(len(ltrim(rtrim(name1))) -3))
   from [dbo].['+@tableName+']
   where name1 like''% de'' and substring(name1,1,2) like''de'''
   exec(@sql) -- v10.2 -- Step Added to Handle DE and DE LA

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] =  ''DE'' + substring(name2,1,(len(ltrim(rtrim(name2))) -3))
   from [dbo].['+@tableName+']
   where name2 like''% de'' and substring(name2,1,2) not like''de'''
   exec(@sql) -- v10.2 -- Step Added to Handle DE and DE LA

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] =  substring(name2,1,(len(ltrim(rtrim(name2))) -3))
   from [dbo].['+@tableName+']
   where name2 like''% de'' and substring(name2,1,2) like''de'''
   exec(@sql) -- v10.2 -- Step Added to Handle DE and DE LA

   --  Step Added to take out AKA, NKA, FKA
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] = case when [Name1] like ''AKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''AKA'',[Name1]))))) 
	   when [Name1] like ''% AKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''AKA'',[Name1]) -1)))) 
	   when [Name1] like ''FKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''FKA'',[Name1]) -1)))) 
	   when [Name1] like ''% FKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''FKA'',[Name1]) -1)))) 
	   when [Name1] like ''NKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''NKA'',[Name1]) -1)))) 
	   when [Name1] like ''% NKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''NKA'',[Name1]) -1))))
	   when [Name1] like ''% A K A %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''A K A'',[Name1]) -1))))
	   else [Name1] end
	   ,[KnownAs] = case when [Name1] like ''AKA %'' then Rtrim(ltrim(substring([Name1],(charindex(''AKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% AKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''AKA'',[Name1]) +4),40))) 
	   when [Name1] like ''FKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''FKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% FKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''FKA'',[Name1]) +4),40))) 
	   when [Name1] like ''NKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''NKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% NKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''NKA'',[Name1]) +4),40)))
	   when [Name1] like ''% A K A %'' then  Rtrim(ltrim(substring([Name1],(charindex(''A K A'',[Name1]) +6),40)))
	   else null end
   from [dbo].['+@tableName+']'
   exec(@sql)
     
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] = case when [Name2] like ''AKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''AKA'',[Name1]))))) 
	   when [Name2] like ''% AKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''AKA'',[Name2]) -1)))) 
	   when [Name2] like ''FKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''FKA'',[Name2]) -1)))) 
	   when [Name2] like ''% FKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''FKA'',[Name2]) -1)))) 
	   when [Name2] like ''NKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''NKA'',[Name2]) -1)))) 
	   when [Name2] like ''% NKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''NKA'',[Name2]) -1))))
	   else [Name2] end
      ,[KnownAs] = case when [Name2] like ''AKA %'' then Rtrim(ltrim(substring([Name2],(charindex(''AKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% AKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''AKA'',[Name2]) +4),40))) 
	   when [Name2] like ''FKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''FKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% FKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''FKA'',[Name2]) +4),40))) 
	   when [Name2] like ''NKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''NKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% NKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''NKA'',[Name2]) +4),40)))
	   else null end
   from [dbo].['+@tableName+']'
   exec(@sql)

   -- Parse Care of Name  --  added BR 20170830  --   Moved up in processing 20180511
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c/o'',[name1])-1)))), COName = ltrim(rtrim(substring([name1],(charindex(''c/o'',[name1])+3),80)))
   where Name1 like ''%c/o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c\o'',[name1])-1)))), COName = ltrim(rtrim(substring([name1],(charindex(''c\o'',[name1])+3),80)))
   where Name1 like ''%c\o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''c/o'',[name2])-1)))), COName = ltrim(rtrim(substring([name2],(charindex(''c/o'',[name2])+3),80)))
   where Name2 like ''%c/o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''c\o'',[name2])-1)))), COName = ltrim(rtrim(substring([name2],(charindex(''c\o'',[name2])+3),80)))
   where Name2 like ''%c\o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null, COName = ltrim(rtrim(substring([name2],(charindex(''REM:'',[name2])+4),80)))
   where Name2 like ''REM:%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null, COName = ltrim(rtrim(substring([name2],(charindex(''MT:'',[name2])+3),80)))
   where Name2 like ''MT:%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null, COName = ltrim(rtrim(substring([name2],(charindex(''M/TO:'',[name2])+5),80)))
   where Name2 like ''M/TO:%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],(charindex('':'',[name2])+1),80)))
   where Name2 like '':%'''
   exec(@sql) -- v8.7 added missing exec(@sql) 

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''&'',[name2])-2))))
   where Name2 like ''% &'''
   exec(@sql) -- v8.7 added missing exec(@sql) plus fix substring

   -- Added V7 20180830 by GM for no spaces around & and after setting corp because some Name1 and Name2 could have close to 100 characters and multiple &.
   set @sql = 'update [dbo].['+@tableName+'] 
   set Name1 = left(replace(replace(Name1,'' & '',''&''),''&'','' & ''),100), Name2 = left(replace(replace(Name2,'' & '',''&''),''&'','' & ''),100)
   where Name1 like ''%&%'' or Name2 like ''%&%'''
   exec(@sql) 

   -- Added V8.5 20191021 by GM for no spaces around , and after setting corp because some Name1 and Name2 could have close to 100 characters and multiple ,.
   set @sql = 'update [dbo].['+@tableName+'] 
   set Name1 = left(replace(replace(Name1,'' , '','',''),'','','' , ''),100), Name2 = left(replace(replace(Name2,'' , '','',''),'','','' , ''),100)
   where Name1 like ''%,%'' or Name2 like ''%,%'''
   exec(@sql) 

   -- Added V8.5 20191021 by GM for no spaces around - and after setting corp because some Name1 and Name2 could have close to 100 characters and multiple -. removed in 10.1 because of hyphen names
   --set @sql = 'update [dbo].['+@tableName+'] 
   --set Name1 = left(replace(replace(Name1,'' - '',''&''),''-'','' & ''),100), Name2 = left(replace(replace(Name2,'' - '',''&''),''-'','' & ''),100)
   --where Name1 like ''%-%'' or Name2 like ''%-%'''
   --exec(@sql) 



--------------------------------------------------------------------- Section accommodate vesting, relationship, and percentage ownership ---------------------------------------------------------------------
   -- [ParsedTokenName1]
   set @sql = 'update [dbo].['+@tableName+']
   set [ParsedTokenName1] = substring(substring(name1, (CHARINDEX(''('',name1)) + 1,  (CHARINDEX('')'',name1)) - (CHARINDEX(''('',name1)) -1  ),1,40),
   Name1 = substring(Replace(name1,substring(Name1, (CHARINDEX(''('',Name1)),  (CHARINDEX('')'',Name1)) - (CHARINDEX(''('',Name1))+1),''''),1,100)
   where name1 like ''%(%)%'' and name1 not like ''%)%(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship], [OwnerRights] = [Vesting], [OwnerEtalInd] = [ETAL Ind], [Name1Percent] = [Percentage]
   from [dbo].['+@tableName+'] t Join [dbo].[lkup_ParsedToken] p on p.[token] = t.[ParsedTokenName1]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship]
   from [dbo].['+@tableName+'] t Join [dbo].[lkup_VestingSourceCrossRef] p on p.[SourceCodeBK] = t.[NameIDCode] where [OwnerRelationship] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRights] = [Ownership] 
   from [dbo].['+@tableName+'] t Join [dbo].[lkup_VestingSourceCrossRef] p on p.[SourceCodeBK] = t.[NameIDCode] where [OwnerRights] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerEtalInd] = [EtalInd]
   from [dbo].['+@tableName+'] t Join [dbo].[lkup_VestingSourceCrossRef] p on p.[SourceCodeBK] = t.[NameIDCode] where [OwnerEtalInd] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [NameIDCode] = COALESCE([OwnerRights],[OwnerRelationship])
   where [NameIDCode] is null and ([OwnerRights] is not null or[OwnerRelationship] is not null)'
   exec(@sql)

   -- [ParsedTokenName2]
   set @sql = 'update [dbo].['+@tableName+']
   set [ParsedTokenName2] = substring(substring(name1, (CHARINDEX(''('',name2)) + 1,  (CHARINDEX('')'',name2)) - (CHARINDEX(''('',name2)) -1  ),1,40),
   Name2 = substring(Replace(name2,substring(Name2, (CHARINDEX(''('',Name2)),  (CHARINDEX('')'',Name2)) - (CHARINDEX(''('',Name2))+1),''''),1,100)
   where name2 like ''%(%)%'' and name2 not like ''%)%(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship], [OwnerRights] = [Vesting], [OwnerEtalInd] = [ETAL Ind], [Name2Percent] = [Percentage]
   from [dbo].['+@tableName+'] t Join [dbo].[lkup_ParsedToken] p on p.[token] = t.[ParsedTokenName2]'
   exec(@sql)



--------------------------------------------------------------------- Section Processing corporate Name1 and Name2 ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim([Name1])), Name2 = ltrim(rtrim([Name2])), COName = ltrim(rtrim([COName]))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(Replace(Replace(ltrim(rtrim([Name1])),'';'','' & ''),''  '','' ''),1,100)
   where Name1 like ''%;%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = substring(Replace(Replace(ltrim(rtrim([Name2])),'';'','' & ''),''  '','' ''),1,100)
   where Name2 like ''%;%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(Replace([Name1],'' SURV'',''''),1,100)
   where Name1 like ''% SURV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = substring(Replace([Name2],'' SURV'',''''),1,100)
   where Name2 like ''% SURV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   where [Name1] Like ''%See ACCT%'' or [Name1] Like ''%See-ACCT%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y'', [Name1TrustInd] = ''Y''
   where [NameIDCode] in (''TR'',''TS'',''RT'',''RL'',''LV'',''LE'',''LT'',''IR'',''IL'',''FL'',''FM'',''FR'',''ES'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name1],1,(charindex('' '',[name1])))
   where [BeginsWith] is not null and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name1]),1,(charindex('' '',reverse([name1])))))
   where [EndsWith] is not null	and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on [name1] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name1]))
   where [Only] is not null and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Name1])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name2],1,(charindex('' '',[name2])))
   where [BeginsWith] is not null and ([Name2] is not null and [Name2] not like '''') and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name2]),1,(charindex('' '',reverse([name2])))))
   where [EndsWith] is not null and ([Name2] is not null and [Name2] not like '''') and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on [name2] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name2]))
   where [Only] is not null and ([Name2] is not null and [Name2] not like '''') and Name2CorpInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Corp_Name] c on ltrim(rtrim([Name2])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and ([Name2] is not null and [Name2] not like '''') and Name2CorpInd is NULL'
   exec(@sql)

   -- Added v8.6 Name1 change ' or ' to ' & ' to fix the ' or ' format issue. This skips the 9 sections below for ' or '.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] = REPLACE([Name1],'' or '','' & '')
   where [Name1] like ''% or %'' and name1corpind is null'
   exec(@sql)

   -- Added v8.6 Name2 change ' or ' to ' & ' to fix the ' or ' format issue. This skips the 9 sections below for ' or '.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] = REPLACE([Name2],'' or '','' & '')
   where [Name2] like ''% or %'' and name2corpind is null'
   exec(@sql)

   -- Added v8.6 Name1 change ' and ' to ' & ' to fix the ' and ' format issue.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] = REPLACE([Name1],'' and '','' & '')
   where [Name1] like ''% and %'' and name1corpind is null'
   exec(@sql)

   -- Added v8.6 Name2 change ' and ' to ' & ' to fix the ' and ' format issue.
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] = REPLACE([Name2],'' and '','' & '')
   where [Name2] like ''% and %'' and name2corpind is null'
   exec(@sql)



--------------------------------------------------------------------- Section process trusts ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name1],1,(charindex('' '',[name1])))
   where [BeginsWith] is not null and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name1]),1,(charindex('' '',reverse([name1])))))
   where [EndsWith] is not null and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on [name1] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name1]))
   where [Only] is not null and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Name1])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2TrustInd] = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name2],1,(charindex('' '',[name2])))
   where [BeginsWith] is not null and ([Name2] is not null and [Name2] not like '''') and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name2]),1,(charindex('' '',reverse([name2])))))
   where [EndsWith] is not null and ([Name2] is not null and [Name2] not like '''') and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on [name2] like ''% '' + ltrim(rtrim([EndsWith]))
   where [EndsWith] is not null and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Only])) = ltrim(rtrim([Name2]))
   where [Only] is not null and ([Name2] is not null and [Name2] not like '''') and Name2TrustInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+'] join [dbo].[lkup_Trust_Name] c on ltrim(rtrim([Name2])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
   where [ContainsIn] is not null and [ContainsIn] not like '''' and ([Name2] is not null and [Name2] not like '''') and Name2TrustInd is NULL'
   exec(@sql)

   --  Added 20180608 to handle instances of Assessee name 1 and Assessee Name 2 in Assessee Name 1 field
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] = ltrim(rtrim(substring([Name1],1,(charindex(''&'',[Name1])-1)))), [Name2] = ltrim(rtrim(substring([Name1],(charindex(''&'',[Name1])+1),80)))
   where [Name1TrustInd] is null and [Name1CorpInd] is null and ([Name1] like ''%&%'') and Name2 is NULL'
   exec(@sql)

   --ADDED 20170928 Same Last Name Twice FIX
   EXEC('update [dbo].['+@tableName+']
   SET [Name1] = CASE WHEN dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&'') like ''%&%&%''
      THEN [dbo].[Before2ndCharacter](dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&''),''&'')
      ELSE dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&'') END
   WHERE [Name1] Like ''% %'' and [Name1CorpInd] is null and Name1fmt like ''%,%'' 
      AND SUBSTRING([Name1],CharIndex('' '',[Name1])+1,LEN([Name1])) Like ''% '' + ltrim(rtrim(replace(Substring([Name1],1,CharIndex('' '',[Name1])),'','',''''))) + ''%''')



--------------------------------------------------------------------- Section corp indicator ---------------------------------------------------------------------
   -- V8 where name1 x<space>&<space> and name2 len greater than 1 : set name1 = name2 and null name2
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Name2, Name2 = NULL
   where substring(Name1,2,1) = '' '' and substring(Name1,3,1) = ''&'' and substring(Name1,4,1) = '' '' and len(Name2) > 1'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set NameFormatType = ''2''
   where  Name2CorpInd is null and Name1 like ''%,%'' and NameFormatType = ''1'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(Name1,''3rd'',''III''), Name1Generation = ''III''
   where  Name1CorpInd is null and (Name1 like ''% 3rd''  or (Name1 like ''% 3rd &'') or (Name1 like ''% 3rd %''))'
   exec(@sql)

   -- v10.2 UofA added 4th gen
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(Name1,''4th'',''IV''), Name1Generation = ''IV''
   where  Name1CorpInd is null and (Name1 like ''% 4th''  or (Name1 like ''% 4th &'') or (Name1 like ''% 4th %''))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(ltrim(rtrim([Name1] + '' '' + [Name2])),1,100)
   where  Name2CorpInd is null and Name1 like ''% &'''
   exec(@sql)



--------------------------------------------------------------------- Section Name1 OwnerRelationship OwnerETALInd ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''%single'', '''' ), OwnerRelationship = ''SI''
   Where [Name1] like ''%single'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''% Married'', '''' ), OwnerRelationship = ''MA''
   Where [Name1] like ''%Married'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etal'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''etal% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etal'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% etal%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etux'', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''etux% %'''
   exec(@sql)
 
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et als'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et als'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et als'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et als%'''
   exec(@sql)
  
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et al'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et al%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et uxs'', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''et uxs'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et ux'', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''et ux% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etux'', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''% etux'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et ux'', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''% et ux'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''ETAL'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% ETAL'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et al'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et al'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et als'', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et als'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et ux '', '''' ), OwnerETALInd = ''EU''
   where Name1 like ''% et ux %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et al '', '''' ), OwnerETALInd = ''EA''
   where Name1 like ''% et al %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etvir'', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''etvir %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et virs'', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''et virs'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et vir'', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''et vir %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''etvir'', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''% etvir'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et vir'', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''% et vir'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''et vir '', '''' ), OwnerETALInd = ''EV''
   where Name1 like ''% et vir %'''
   exec(@sql)

   -- v8.7 added to handle " ET "
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], '' et '', '' & '' ), OwnerETALInd = ''EA''
   where Name1 like ''% et %'' and (Name1 not like ''% et vir%'' and Name1 not like ''% et al%'' and Name1 not like ''% et als%'' and Name1 not like ''% et ux%'')'
   exec(@sql)

   -- remove EA for EACH on name1 percent
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = REPLACE(Name1,'' EA '','' '')
   where Name1 like ''%[0-9][%]%'' and Name1 like ''% EA %'''
   exec(@sql)

   -- [DragonNameTest].[dbo].[StringReplaceRegEx] requires function StringReplaceRegEx and assembly StringUtil GM v7.1
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = [dbo].[StringReplaceRegEx] (name1, ''\d+\s*%'','''')
   where name1 like ''%[0-9][%]%'''
   exec(@sql)

   -- handle all fractions name1 option GM v7.1 & remove EA for EACH on name1 fraction
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = REPLACE(Name1,'' EA '','' '')
   where Name1 like ''%[0-9]/[0-9]%'' and Name1 like ''% EA %'''
   exec(@sql)

   -- [DragonNameTest].[dbo].[StringReplaceRegEx] requires function StringReplaceRegEx and assembly StringUtil GM v7.1
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = [dbo].[StringReplaceRegEx] ([Name1],''\d/\d*'','''')
   where Name1 like ''%[0-9]/[0-9]%'''
   exec(@sql)

   -- handle all percents name2 option GM v7.1 & remove EA for EACH on name1 percent
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = REPLACE(Name2,'' EA '','' '')
   where Name2 like ''%[0-9][%]%'' and Name2 like ''% EA %'''
   exec(@sql)

   -- [DragonNameTest].[dbo].[StringReplaceRegEx] requires function StringReplaceRegEx and assembly StringUtil GM v7.1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = [dbo].[StringReplaceRegEx] (name2, ''\d+\s*%'','''')
   where name2 like ''%[0-9][%]%'''
   exec(@sql)

   -- handle all fractions name2 option GM v7.1 & remove EA for EACH on name2 fraction
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = REPLACE(Name2,'' EA '','' '')
   where Name2 like ''%[0-9]/[0-9]%'' and Name2 like ''% EA %'''
   exec(@sql)

   -- [DragonNameTest].[dbo].[StringReplaceRegEx] requires function StringReplaceRegEx and assembly StringUtil GM v7.1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = [dbo].[StringReplaceRegEx] ([Name2],''\d/\d*'','''')
   where Name2 like ''%[0-9]/[0-9]%'''
   exec(@sql)

--------------------------------------------------------------------- Section clean up garbage ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace([Name1],''()'',''''),''  '','' ''),''(H)'',''''),''(W)'',''''),''(SOL)'',''''),''(SO)'',''''),''(JT)'',''''),''(TRE)'',''''),''(CPR)'',''''),''(JNT)'',''''),''(CP)'',''''),''(TRE'',''''),''(TIC)'',''''),''(COM)'',''''),''(NOT)'',''''),''(OT-JT)'',''''),''(OT)'',''''),''( TIC)'',''''),''(55%)'',''''),''(45%'',''''),''  '','''')
   where Name1 like ''%(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9]/[0-9]'', '''' )
   where Name1 like ''%[0-9]/[0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9]/[0-9][0-9]'', '''' )
   where Name1 like ''%[0-9]/[0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9]/[0-9][0-9][0-9]'', '''' )
   where Name1 like ''%[0-9]/[0-9][0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9][0-9]/[0-9][0-9]'', '''' )
   where Name1 like ''%[0-9][0-9]/[0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9][0-9]/[0-9][0-9][0-9]'', '''' )
   where Name1 like ''%[0-9][0-9]/[0-9][0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''[0-9][0-9][0-9]/[0-9][0-9][0-9]'', '''' )
   where Name1 like ''%[0-9][0-9][0-9]/[0-9][0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(name1,(charindex('')'',name1)+1),50)))
   where name1 like ''(%)%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,2,50)))
   where name1 like ''(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = replace(Name2,''3rd'',''III'')
   where  Name2CorpInd is null and (Name2 like ''% 3rd''  or (Name2 like ''% 3rd &'') or (Name2 like ''% 3rd &%''))'
   exec(@sql)

   -- v10.2 UofA added 4th gen
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = replace(Name2,''4th'',''IV'')
   where  Name2CorpInd is null and (Name2 like ''% 4th''  or (Name2 like ''% 4th &'') or (Name2 like ''% 4th &%''))'
   exec(@sql)

   -- v7 added substring to handle truncate issue GM
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = substring(ltrim(rtrim([Name1] + '' '' + [Name2])),1,100)
   where  Name2CorpInd is null and Name1 like ''% &'' and Name2 is not null'
   exec(@sql)



--------------------------------------------------------------------- Section Name2 OwnerRelationship OwnerETALInd ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''%single'', '''' ), [OwnerRelationship] = ''SI''
   where Name2 like ''%single %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''% Married'', '''' ), [OwnerRelationship] = ''MA''
   where Name2 like ''%Married %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''etal'', '''' ), OwnerETALInd = ''EA''
   where Name2 like ''etal% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''etux'', '''' ), OwnerETALInd = ''EU''
   where Name2 like ''etux% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''T/E'', '''' ), [OwnerRights] = ''TE''
   where Name2 like ''T/E% %'' or Name2 like ''%T/E'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''etux'', '''' ), OwnerETALInd = ''EU''
   where Name2 like ''% etux'''
   exec(@sql)

   -- v8.7 added to handle " ET "
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], '' et '', '' & '' ), OwnerETALInd = ''EA''
   where Name2 like ''% et %'' and (Name2 not like ''% et vir%'' and Name2 not like ''% et al%'' and Name2 not like ''% et als%'' and Name2 not like ''% et ux%'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''1/4'', '''' ), [Name2Percent] = ''1/4''
   where Name2 like ''%1/4%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''1/2'', '''' ), [Name2Percent] = ''1/2''
   where Name2 like ''%1/2%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''1/3'', '''' ), [Name2Percent] = ''1/3''
   where Name2 like ''%1/3%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''[0-9]/[0-9]'', '''' )
   where Name2 like ''%[0-9]/[0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''[0-9]/[0-9][0-9]'', '''' )
   where Name2 like ''%[0-9]/[0-9][0-9]%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring(Name2,(charindex('')'',Name2)+1),50)))
   where Name2 like ''(%)%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring(Name2,2,50)))
   where Name2 like ''(%'''
   exec(@sql)



--------------------------------------------------------------------- Section Parsing Name1 by Space delimiter into 12 separate fields ---------------------------------------------------------------------
   SET CONCAT_NULL_YIELDS_NULL ON
   SET ANSI_WARNINGS ON -- "UPDATE failed because the following SET options have incorrect settings: 'ANSI_WARNINGS'" issue if ANSI_WARNINGS OFF v7

      EXEC('DECLARE @delimiter VARCHAR(50)
			SET @delimiter = '' ''

			SELECT CONVERT(bigint, ID) as ID,Name1,
					CAST(''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Name1,''>'','' ''),''<'','' ''),''&'','' AND ''),''+'','' AND ''),''.'',''''),''/'',''''),''  '','' ''), @delimiter , ''</M><M>'') + ''</M>'' AS XML) AS [Name XML]
				INTO #NameSplit
				FROM  dbo.['+@tableName+']
				WHERE Name1CorpInd is null and Name1 like ''% %''
				order by ID

			UPDATE d 
			SET d.N1 = replace(replace(x.N1,'','',''''),''.'','''')
			,d.N2 = replace(replace(x.N2,'','',''''),''.'','''')
			,d.N3 = replace(replace(x.N3,'','',''''),''.'','''')
			,d.N4 = replace(replace(x.N4,'','',''''),''.'','''')
			,d.N5 = replace(replace(x.N5,'','',''''),''.'','''')
			,d.N6 = replace(replace(x.N6,'','',''''),''.'','''')
			,d.N7 = replace(replace(x.N7,'','',''''),''.'','''')
			,d.N8 = replace(replace(x.N8,'','',''''),''.'','''')
			,d.N9 = replace(replace(x.N9,'','',''''),''.'','''')
			,d.N10 = replace(replace(x.N10,'','',''''),''.'','''')
			,d.N11 = replace(replace(x.N11,'','',''''),''.'','''')
			,d.N12 = replace(replace(x.N12,'','',''''),''.'','''')
			FROM [dbo].['+@tableName+'] d JOIN 
			(
				SELECT ID,Name1
					 ,[Name XML].value(''/M[1]'', ''varchar(50)'') as N1
					 ,[Name XML].value(''/M[2]'', ''varchar(50)'') as N2
					 ,[Name XML].value(''/M[3]'', ''varchar(50)'') as N3
					 ,[Name XML].value(''/M[4]'', ''varchar(50)'') as N4
					 ,[Name XML].value(''/M[5]'', ''varchar(50)'') as N5
					 ,[Name XML].value(''/M[6]'', ''varchar(50)'') as N6
					 ,[Name XML].value(''/M[7]'', ''varchar(50)'') as N7
					 ,[Name XML].value(''/M[8]'', ''varchar(50)'') as N8
					 ,[Name XML].value(''/M[9]'', ''varchar(50)'') as N9
					 ,[Name XML].value(''/M[10]'', ''varchar(50)'') as N10
					 ,[Name XML].value(''/M[11]'', ''varchar(50)'') as N11
					 ,[Name XML].value(''/M[12]'', ''varchar(50)'') as N12
				FROM #NameSplit
			) x 
			on d.ID = x.ID
			
			DROP TABLE #NameSplit
			')

   SET CONCAT_NULL_YIELDS_NULL OFF



--------------------------------------------------------------------- Section clean hyphenated Last Name ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   SET [N1] = ltrim(rtrim(substring([N1],1,(charindex(''-'',[N1]) -1))))
   where [N1] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N1_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N1]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N2] = ltrim(rtrim(substring([N2],1,(charindex(''-'',[N2]) -1))))
   where [N2] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N2_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N2]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N3] = ltrim(rtrim(substring([N3],1,(charindex(''-'',[N3]) -1))))
   where [N3] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N3_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N3]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N4] = ltrim(rtrim(substring([N4],1,(charindex(''-'',[N4]) -1))))
   where [N4] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N4_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N4]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N5] = ltrim(rtrim(substring([N5],1,(charindex(''-'',[N5]) -1))))
   where [N5] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N5_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N5]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N6] = ltrim(rtrim(substring([N6],1,(charindex(''-'',[N6]) -1))))
   where [N6] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N6_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N6]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N7] = ltrim(rtrim(substring([N7],1,(charindex(''-'',[N7]) -1))))
   where [N7] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N7_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N7]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N8] = ltrim(rtrim(substring([N8],1,(charindex(''-'',[N8]) -1))))
   where [N8] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N8_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N8]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N9] = ltrim(rtrim(substring([N9],1,(charindex(''-'',[N9]) -1))))
   where [N9] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N9_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N9]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N10] = ltrim(rtrim(substring([N10],1,(charindex(''-'',[N10]) -1))))
   where [N10] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N10_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N10]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N11] = ltrim(rtrim(substring([N11],1,(charindex(''-'',[N11]) -1))))
   where [N11] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N11_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N11]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N12] = ltrim(rtrim(substring([N12],1,(charindex(''-'',[N12]) -1))))
   where [N12] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [N12_Prob] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[N12]'
   exec(@sql)



--------------------------------------------------------------------- Section Calculate Name Formats ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(Name1))'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(Name2))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1TokenFirst = ltrim(rtrim(replace(substring([Name1],1,(charindex('' '',[Name1]))),'','',''''))), Name1TokenLast = ltrim(rtrim(reverse(substring(reverse(replace(Replace(Replace(Replace([Name1],'' iii'',''''),'' ii'',''''),'' jr'',''''),'' sr'','''')), 0, charindex('' '',reverse(replace(Replace(Replace(Replace([Name1],'' iii'',''''),'' ii'',''''),'' jr'',''''),'' sr'','''')))))))
   where Name1 is not null and Name1CorpInd is null'
   exec(@sql)

   -- Clean Hyphenated Last Name
   set @sql = 'update [dbo].['+@tableName+']
   SET [Name1TokenFirst] = ltrim(rtrim(substring([Name1TokenFirst],1,(charindex(''-'',[Name1TokenFirst]) -1))))
   where [Name1TokenFirst] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name1TokenLast] = ltrim(rtrim(substring([Name1TokenLast],1,(charindex(''-'',[Name1TokenLast]) -1))))
   where [Name1TokenLast] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name1Token1SurnameInd] = ''Y'', Name1Token1SurnameProbabilty = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name1TokenFirst]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name1Token2SurnameInd] = ''Y'', Name1Token2SurnameProbabilty = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name1TokenLast]'
   exec(@sql)

   -- v8.5 set NameFormatType equal 2 if Name1TokenFirst equal Name2TokenFirst are the same meaning that is their last name.
   set @sql = 'update [dbo].['+@tableName+']
   SET [NameFormatType] = 2
   where Name1TokenFirst = Name2TokenFirst and Name1TokenFirst is not null'
   exec(@sql)

   -- v8.5 don't over write NameFormatType with probability if already set. Added where clause. -- removed where clause in v10.2 because caused issues with some counties.
   set @sql = 'update [dbo].['+@tableName+']
   SET [NameFormatType] = case
   when isnull([Name1Token1SurnameProbabilty],0) > isnull([Name1Token2SurnameProbabilty],0) then 2
   when isnull([Name1Token1SurnameProbabilty],0) < isnull([Name1Token2SurnameProbabilty],0) then 1
   else 2 end'
   --where [NameFormatType] is null or ([NameFormatType] != ''1'' and [NameFormatType] != ''2'' and [NameFormatType] != ''3'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TokenFirst = ltrim(rtrim(replace(substring([Name2],1,(charindex('' '',[Name2]))),'','',''''))), Name2TokenLast = ltrim(rtrim(reverse(substring(reverse(replace(Replace(Replace(Replace([name2],'' iii'',''''),'' ii'',''''),'' jr'',''''),'' sr'','''')), 0, charindex('' '',reverse(replace(Replace(Replace(Replace([name2],'' iii'',''''),'' ii'',''''),'' jr'',''''),'' sr'','''')))))))
   where Name2 is not null and Name2CorpInd is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2TokenFirst] = ltrim(rtrim(substring([Name2TokenFirst],1,(charindex(''-'',[Name2TokenFirst]) -1))))
   where [Name2TokenFirst] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2TokenLast] = ltrim(rtrim(substring([Name2TokenLast],1,(charindex(''-'',[Name2TokenLast]) -1))))
   where [Name2TokenLast] like ''%-%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2Token1SurnameInd] = ''Y'', Name2Token1SurnameProbabilty = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name2TokenFirst]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2Token2SurnameInd] = ''Y'', Name2Token2SurnameProbabilty = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name2TokenLast]'
   exec(@sql)

   -- v8.5 set Name2FormatType equal 2 if Name1TokenFirst equal Name2TokenFirst are the same meaning that is their last name.
   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2FormatType] = 2
   where Name1TokenFirst = Name2TokenFirst and Name1TokenFirst is not null'
   exec(@sql)

   -- v8.5 don't over write Name2FormatType with probability if already set. Added where clause. -- removed where clause in v10.2 because caused issues with some counties.
   set @sql = 'update [dbo].['+@tableName+']
   SET [Name2FormatType] = case
   when isnull([Name2Token1SurnameProbabilty],0) > isnull([Name2Token2SurnameProbabilty],0) then 2
   when isnull([Name2Token1SurnameProbabilty],0) < isnull([Name2Token2SurnameProbabilty],0) then 1
   else 2 end'
   --where [Name2FormatType] is null or ([Name2FormatType] != ''1'' and [Name2FormatType] != ''2'' and [Name2FormatType] != ''3'')'
   exec(@sql)



--------------------------------------------------------------------- Section make each county Name Format the same, count > 99 ---------------------------------------------------------------------
   DECLARE @pct as varchar(5) = '.95'
   Set @sql = 'UPDATE n
   SET n.NameFormatType = CASE WHEN (pct > ' + @pct + ' and ((select count(*) from ['+@tableName+']) > 99)) THEN z.NameFormatType ELSE n.NameFormatType END
   FROM ['+@tableName+'] n JOIN (
                SELECT FIPS,NameFormatType, CountFmtType,TotalCount,convert(money,convert(money,CountFmtType)/convert(money,TotalCount))  as pct  FROM(   
                                SELECT  t.FIPS,NameFormatType,CountFmtType,TotalCount
                                ,ROW_NUMBER() OVER(PARTITION BY t.FIPS ORDER BY CountFmtType DESC) AS RowNum
                                FROM (Select FIPS,NameFormatType,COUNT(*) as CountFmtType FROM ['+@tableName+']
                                WHERE FIPS is NOT NULL
                                GROUP BY FIPS,NameFormatType) t JOIN (Select Fips,Count(*) as TotalCount from ['+@tableName+'] group by Fips) z
                                on t.Fips = z.fips 
                ) CountyFormat
   WHERE RowNum = 1) z
   on n.FIPS = z.FIPS'
   exec(@sql)

   --v8.2 added set Name2FormatType = 2 versus 1 -- v8.5 count > 99
   Set @sql = 'UPDATE n
   SET n.Name2FormatType = CASE WHEN (pct > ' + @pct + ' and ((select count(*) from ['+@tableName+']) > 99)) THEN z.Name2FormatType ELSE n.Name2FormatType END
   FROM ['+@tableName+'] n JOIN (
                SELECT FIPS,Name2FormatType, CountFmtType,TotalCount,convert(money,convert(money,CountFmtType)/convert(money,TotalCount))  as pct  FROM(   
                                SELECT  t.FIPS,Name2FormatType,CountFmtType,TotalCount
                                ,ROW_NUMBER() OVER(PARTITION BY t.FIPS ORDER BY CountFmtType DESC) AS RowNum
                                FROM (Select FIPS,Name2FormatType,COUNT(*) as CountFmtType FROM ['+@tableName+']
                                WHERE FIPS is NOT NULL
                                GROUP BY FIPS,Name2FormatType) t JOIN (Select Fips,Count(*) as TotalCount from ['+@tableName+'] group by Fips) z
                                on t.Fips = z.fips
                ) CountyFormat
   WHERE RowNum = 1) z
   on n.FIPS = z.FIPS'
   exec(@sql)



--------------------------------------------------------------------- Section set nameformattype & NameRealtionship ---------------------------------------------------------------------
   --Step 1-1 Update NameFormat N
   set @sql = 'update [dbo].['+@tableName+']
   set nameformattype =''3'' --, nameformattype2 = ''N''
   where [Name1] like ''%,%'' and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set nameformattype =''1'' --, nameformattype2 = ''N''
   where [Name1] not like ''%,%'' and name1corpind is null and nameformattype = ''n'' and fips In (''26163'', ''36047'', ''36119'', ''46013'', ''46117'', ''49045'', ''53009'', ''55019'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set nameformattype =''2'' --, nameformattype2 = ''N''
   where [Name1] not like ''%,%'' and name1corpind is null and nameformattype = ''n'' and fips In (''16055'', ''22055'', ''28015'', ''29143'', ''39047'', ''46115'', ''55079'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set nameformattype =''2'' --, nameformattype2 = ''N''
   where [Name1] like ''%&%&%'' and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set nameformattype =''1'' --, nameformattype2 = ''N''
   where [Name1] is not null and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

   --Step 2 Prepend Name1
   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''('',[Name1],1)),40), [Name1Work] = ltrim(rtrim(Substring([Name1],1,(Charindex(''('',[Name1],1)-1))))
   where [Name1] like ''%(%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   Set [NameRealtionship] = Substring([Name1],(Charindex(''h/w'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''h/w'',[Name1],1)-1)), [OwnerRelationship] = ''HW''
   where [Name1] like ''%h/w%'' and name1corpind is null'
   exec(@sql)

   -- v8.5 type-o w/h instead of h/w (Husband Wife)
   set @sql = 'update '+@tableName+'
   Set [NameRealtionship] = Substring([Name1],(Charindex(''w/h'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''w/h'',[Name1],1)-1)), [OwnerRelationship] = ''HW''
   where [Name1] like ''%w/h%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''s/c'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''s/c'',[Name1],1)-1)), [OwnerRelationship] = ''SC''
   where [Name1] like ''%s/c%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''r/s'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''r/s'',[Name1],1)-1)), [OwnerRights] = ''RS''
   where [Name1] like ''%r/s%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''t/c'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''t/c'',[Name1],1)-1)), [OwnerRights] = ''TC''
   where [Name1] like ''%t/c%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''r/t'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''r/t'',[Name1],1)-1)), [OwnerRights] = ''RT''
   where [Name1] like ''%r/t%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex(''j/t'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex(''j/t'',[Name1],1)-1)), [OwnerRights] = ''JT''
   where [Name1] like ''%j/t%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex('' jt'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex('' jt'',[Name1],1)-1)), [OwnerRights] = ''JT''
   where [Name1] like ''% jt %'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex('' jt'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex('' jt'',[Name1],1)-1)), [OwnerRights] = ''JT''
   where [Name1] like ''% jt'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex('' lc'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex('' lc'',[Name1],1)-1)), [OwnerRights] =  ''JT''
   where [Name1] like ''% lc%'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex('' h w'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex('' h w'',[Name1],1)-1)), [OwnerRelationship] = ''HW''
   where [Name1] like ''% h w %'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name1],(Charindex('' h w'',[Name1],1)),40), [Name1Work] = Substring([Name1],1,(Charindex('' h w'',[Name1],1)-1)), [OwnerRelationship] = ''HW''
   where [Name1] like ''% h w'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''etux'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''etux'',[Name1],1)+4),40), OwnerEtalInd = ''EU''
   where [Name1] like ''% etux %'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''et ux'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''et ux'',[Name1],1)+4),40), OwnerEtalInd = ''EU''
   where [Name1] like ''% et ux'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''etal'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''etal'',[Name1],1)+4),40), OwnerEtalInd = ''EA''
   where [Name1] like ''% etal %'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''et al'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''et al'',[Name1],1)+4),40), OwnerEtalInd = ''EA''
   where [Name1] like ''% et al'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''et als'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''et als'',[Name1],1)+4),40), OwnerEtalInd = ''EA''
   where [Name1] like ''% et als'' and name1corpind is null'
   exec(@sql)

   -- v8.1
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''etvir'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''etvir'',[Name1],1)+5),40), OwnerEtalInd = ''EV''
   where [Name1] like ''% etvir %'' and name1corpind is null'
   exec(@sql)

   -- v8.1
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''et vir'',[Name1],1)-1)), [NameRealtionship] = Substring([Name1],(Charindex(''et vir'',[Name1],1)+5),40), OwnerEtalInd = ''EV''
   where [Name1] like ''% et vir'' and name1corpind is null'
   exec(@sql)

   --Prepend Name2
   set @sql = 'update '+@tableName+'
   Set [NameRealtionship] = Substring([Name2],(Charindex(''('',[Name2],1)),40), [Name2Work] = ltrim(rtrim(Substring([Name2],1,(Charindex(''('',[Name2],1)-1))))
   where [Name2] like ''%(%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''h/w'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''h/w'',[Name2],1)-1)), OwnerRelationship = ''HW''
   where [Name2] like ''%h/w%'' and name2corpind is null'
   exec(@sql)
 
   -- v8.5 type-o w/h instead of h/w (Husband Wife)
   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''w/h'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''w/h'',[Name2],1)-1)), OwnerRelationship = ''HW''
   where [Name2] like ''%w/h%'' and name2corpind is null'
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''s/c'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''s/c'',[Name2],1)-1)), OwnerRights = ''SC''
   where [Name2] like ''%s/c%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''r/s'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''r/s'',[Name2],1)-1)), OwnerRights = ''RS''
   where [Name2] like ''%r/s%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''r/t'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''r/t'',[Name2],1)-1)), OwnerRights = ''RT''
   where [Name2] like ''%r/t%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''t/c'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''t/c'',[Name2],1)-1)), OwnerRights = ''TC''
   where [Name2] like ''%t/c%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex(''j/t'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex(''j/t'',[Name2],1)-1)), OwnerRights = ''JT''
   where [Name2] like ''%j/t%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex('' jt'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex('' jt'',[Name2],1)-1)), OwnerRights = ''JT''
   where [Name2] like ''% jt %'' and name2corpind is null' -- V10.1 changed from ''% jt%'' to ''% jt %'' and added "and name2corpind is null"
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex('' jt'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex('' jt'',[Name2],1)-1)), OwnerRights = ''JT''
   where [Name2] like ''% jt'' and name2corpind is null' -- V10.1 changed from name1corpind to name2corpind
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex('' lc'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex('' lc'',[Name2],1)-1)), OwnerRelationship = ''LC''
   where [Name2] like ''% lc%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex('' H W'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex('' h w'',[Name2],1)-1)), OwnerRelationship = ''HW''
   where [Name2] like ''% h w%'''
   exec(@sql)

   set @sql = 'update '+@tableName+'
   set [NameRealtionship] = Substring([Name2],(Charindex('' H W'',[Name2],1)),40), [Name2Work] = Substring([Name2],1,(Charindex('' h w'',[Name2],1)-1)), OwnerRelationship = ''HW''
   where [Name2] like ''% h w'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''etux'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''etux'',[Name2],1)+4),40), OwnerEtalInd = ''EU''
   where [Name2] like ''%etux%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''et ux'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''et ux'',[Name2],1)+4),40), OwnerEtalInd = ''EU''
   where [Name2] like ''%et ux'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''etal'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''etal'',[Name2],1)+4),40), OwnerEtalInd = ''EA''
   where [Name2] like ''%etal%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''et al'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''et al'',[Name2],1)+4),40), OwnerEtalInd = ''EA''
   where [Name2] like ''%et al'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''et als'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''et als'',[Name2],1)+4),40), OwnerEtalInd = ''EA''
   where [Name2] like ''%et als'''
   exec(@sql)

   -- v8.1
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''etvir'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''etvir'',[Name2],1)+5),40), OwnerEtalInd = ''EV''
   where [Name2] like ''%etvir%'''
   exec(@sql)

   -- v8.1
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = Substring([Name2],1,(Charindex(''et vir'',[Name2],1)-1)), [NameRealtionship] = Substring([Name2],(Charindex(''et vir'',[Name2],1)+5),40), OwnerEtalInd = ''EV''
   where [Name2] like ''%et vir'''
   exec(@sql)



--------------------------------------------------------------------- Section step 3 Name Format ---------------------------------------------------------------------
   --Format 1
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''&'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex(''&'',[Name1],1)+2),40))
   where [Name1] like ''%&%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' and '',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('' and '',[Name1],1)+4),40))
   where [Name1] like ''% and %'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' or '',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('' or '',[Name1],1)+4),40))
   where [Name1] like ''% or %'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''/'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex(''/'',[Name1],1)+1),40))
   where [Name1] like ''%/%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('':'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('':'',[Name1],1)+1),40))
   where [Name1] like ''%:%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('';'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('';'',[Name1],1)+1),40))
   where [Name1] like ''%;%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = [Name1]
   where name1corpind is null and nameformattype = ''1'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
   where name1corpind is null and nameformattype = ''1'' and (Name1Work like ''mc %'' or Name1Work like ''de %''or Name1Work like ''la %'' or Name1Work like ''di %'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
   where name1corpind is null and nameformattype = ''1'' and (Name1Work like ''mac %'' or Name1Work like ''von %'' or Name1Work like ''van %'' or Name1Work like ''del %'')'
   exec(@sql)



--------------------------------------------------------------------- Section remove second Name from Name1Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
   where [Name1Work] like ''%&%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% and %'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% or %'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%/%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%:%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%;%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = [Name1Work]
   where name1corpind is null and nameformattype = ''1'' and Name1Work is Not null'
   exec(@sql)

   --Second Name
   set @sql = 'update [dbo].['+@tableName+'] 
   set [Name2Work] = Name2
   where name2corpind is null and nameformattype = ''1'' and [Name2Work] is null and name2 is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+'] 
   set [Name2Work] = null
   where name2corpind is null and nameformattype = ''1'' and ([Name2] Like ''aka %'' or [Name2] Like ''fka %'' or [Name2] Like ''DBA %'' or [Name2] Like ''nka %'' ) and name2 is not null'
   exec(@sql)

   --Remove Additional Names from Name2Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
   where [Name2Work] like ''%&%'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
   where [Name2Work] like ''% and %'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
   where [Name2Work] like ''% or %'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null' -- v8.6 fixed nameformattype = ''1'' put back name2formattype = ''1''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
   where [Name2Work] like ''%/%'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
   where [Name2Work] like ''%:%'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
   where [Name2Work] like ''%;%'' and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   --Format 2
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''&'',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex(''&'',[Name1],1)+2),40)
   where [Name1] like ''%&%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex('' and '',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex('' and '',[Name1],1)+4),40)
   where [Name1] like ''% and %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex('' or '',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex('' or '',[Name1],1)+4),40)
   where [Name1] like ''% or %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex(''/'',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex(''/'',[Name1],1)+1),40)
   where [Name1] like ''%/%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex('':'',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex('':'',[Name1],1)+1),40)
   where [Name1] like ''%:%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring([Name1],1,(Charindex('';'',[Name1],1)-1)), [Name2Work] = Substring([Name1],(Charindex('';'',[Name1],1)+1),40)
   where [Name1] like ''%;%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] =  substring([Name1],0,80)
   where name1corpind is null and nameformattype = ''2'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
   where name1corpind is null and nameformattype = ''2'' and (Name1Work like ''mc %'' or Name1Work like ''de %'' or Name1Work like ''la %'' or Name1Work like ''di %'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
   where name1corpind is null and nameformattype = ''2'' and (Name1Work like ''mac %'' or Name1Work like ''von %'' or Name1Work like ''van %''or Name1Work like ''del %'')'
   exec(@sql)

   --Remove Second Name from Name1Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
   where [Name1Work] like ''%&%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% and %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% or %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%/%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%:%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%;%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   --Second Name
   set @sql = 'update [dbo].['+@tableName+'] 
   set [Name2Work] = substring(Name2,0,80)
   where name2corpind is null and nameformattype = ''2'' and [Name2Work] is null and name2 is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = null
   where name2corpind is null and nameformattype = ''2'' and ([Name2] Like ''aka %''or [Name2] Like ''fka %'' or [Name2] Like ''DBA %'' or [Name2] Like ''nka %'' ) and name2 is not null'
   exec(@sql)

   --Remove Additional Names from Name2Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
   where [Name2Work] like ''%&%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
   where [Name2Work] like ''% and %'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
   where [Name2Work] like ''% or %'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null' -- v8.6 fixed nameformattype = ''2'' put back name2formattype = ''2''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
   where [Name2Work] like ''%/%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
   where [Name2Work] like ''%:%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
   where [Name2Work] like ''%;%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   --Format 3
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''&'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex(''&'',[Name1],1)+2),40))
   where [Name1] like ''%&%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' and '',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('' and '',[Name1],1)+4),40))
   where [Name1] like ''% and %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' or '',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('' or '',[Name1],1)+4),40))
   where [Name1] like ''% or %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''/'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex(''/'',[Name1],1)+1),40))
   where [Name1] like ''%/%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('':'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('':'',[Name1],1)+1),40))
   where [Name1] like ''%:%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('';'',[Name1],1)-1))), [Name2Work] = ltrim(Substring([Name1],(Charindex('';'',[Name1],1)+1),40))
   where [Name1] like ''%;%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = [Name1]
   where name1corpind is null and nameformattype = ''3'' and Name1Work is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
   where name1corpind is null and nameformattype = ''3'' and (Name1Work like ''mc %'' or Name1Work like ''de %''or Name1Work like ''la %'' or Name1Work like ''di %'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
   where name1corpind is null and nameformattype = ''3'' and (Name1Work like ''mac %'' or Name1Work like ''von %''or Name1Work like ''van %'' or Name1Work like ''del %'')'
   exec(@sql)

   --Remove Second Name from Name1Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
   where [Name1Work] like ''%&%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% and %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
   where [Name1Work] like ''% or %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%/%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%:%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1))), [Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
   where [Name1Work] like ''%;%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Work] = [Name1Work]
   where name1corpind is null and nameformattype = ''3'' and Name1Work is Not null'
   exec(@sql)

   --Second Name
   set @sql = 'update [dbo].['+@tableName+'] 
   set [Name2Work] = Name2
   where name2corpind is null and nameformattype = ''3'' and [Name2Work] is null and name2 is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+'] 
   set [Name2Work] = null
   where name2corpind is null and nameformattype = ''3'' and ([Name2] Like ''aka %''or [Name2] Like ''fka %'' or [Name2] Like ''DBA %'' or [Name2] Like ''nka %'' ) and name2 is not null'
   exec(@sql)

   --Remove Additional Names from Name2Work
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
   where [Name2Work] like ''%&%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
   where [Name2Work] like ''% and %'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
   where [Name2Work] like ''% or %'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null' -- v8.6 fixed nameformattype = ''2'' changed back name2formattype = ''3''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
   where [Name2Work] like ''%/%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
   where [Name2Work] like ''%:%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
   where [Name2Work] like ''%;%'' and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
   exec(@sql)



--------------------------------------------------------------------- Section step 4 Generations ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''SR'',Name1Work = Substring(Name1Work,1,(Charindex('' SR'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% SR'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''SR'', Name1Work = Substring(Name1Work,1,(Charindex('' SR'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% SR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''SR'', Name1Work = Replace(Name1Work,''SR'','''')
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% SR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''JR'', Name1Work = Substring(Name1Work,1,(Charindex('' JR'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% JR'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''JR'', Name1Work = Substring(Name1Work,1,(Charindex('' JR.'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% JR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''JR'', Name1Work = Replace(Name1Work,''JR.'','''')
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% JR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''II'', Name1Work = Substring(Name1Work,1,(Charindex('' II'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is  not null and Name1Work like ''% II'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''IV'', Name1Work = Substring(Name1Work,1,(Charindex('' IV'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% IV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''III'', Name1Work = Substring(Name1Work,1,(Charindex('' III'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% III'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''MD'', Name1Work = Substring(Name1Work,1,(Charindex('' MD'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% MD'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''RET'', Name1Work = Substring(Name1Work,1,(Charindex('' RET'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% RET'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''REV'', Name1Work = Substring(Name1Work,1,(Charindex('' REV'',Name1Work,1)-1))
   Where name1corpind is null and Name1Work is not null and Name1Work like ''% REV'''
   exec(@sql)

   --Second Name
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''SR'',Name2Work = Substring(Name2Work,1,(Charindex('' SR'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is not null and Name2Work like ''% SR'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''SR'', Name2Work = Substring(Name2Work,1,(Charindex('' SR.'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is not null and Name2Work like ''% SR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''SR'', Name2Work = Replace(Name2Work,'' SR.'','''')
   Where name2corpind is null and Name2Work is not null and Name2Work like ''% SR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''JR'', Name2Work = Substring(Name2Work,1,(Charindex('' JR'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% JR'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''JR'', Name2Work = Substring(Name2Work,1,(Charindex('' JR.'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% JR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''JR'', Name2Work = Replace(Name2Work,''JR.'','''')
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% JR.'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''II'', Name2Work = Substring(Name2Work,1,(Charindex('' II'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% II'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''IV'', Name2Work = Substring(Name2Work,1,(Charindex('' IV'',Name2Work,1)-1))
   Where name2corpind is null and Name1Work is  not null and Name2Work like ''% IV'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''III'', Name2Work = Substring(Name2Work,1,(Charindex('' III'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% III'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''MD'', Name2Work = Substring(Name2Work,1,(Charindex('' MD'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% MD'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''RET'', Name2Work = Substring(Name2Work,1,(Charindex('' RET'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% RET'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''REV'', Name2Work = Substring(Name2Work,1,(Charindex('' REV'',Name2Work,1)-1))
   Where name2corpind is null and Name2Work is  not null and Name2Work like ''% REV'''
   exec(@sql)



--------------------------------------------------------------------- Section step 5 Name Breakout ---------------------------------------------------------------------
   --Format 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
   where Name1Work like ''%,%'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   Set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)),Name1Work = rtrim(ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)))
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Last is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Name1Work, Name1Work = null
   where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work not like ''% %'' and len(Name1Work) > 1 and Name1 not like ''% & %''' -- v8.7 added (and Name1 not like ''% & %'')
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Middle = Name1Work, Name1Work = null
   where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and len(Name1Work) = 1'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Middle = REVERSE(RIGHT(REVERSE (Name1Work), len(Name1Work) - NULLIF(charindex('' '', REVERSE(Name1Work)),0)))
   where name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = REVERSE( LEFT( REVERSE(Name1Work), CHARINDEX('' '', REVERSE(Name1Work))-1 ) )
   where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work like ''% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Name1Work
   where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work not like ''% %'' and Name1 not like ''% & %''' -- v8.7 added (and Name1 not like ''% & %'')
   exec(@sql)
   
   -- v8.5 changed back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = REVERSE( LEFT( REVERSE(Name2Work), CHARINDEX('' '', REVERSE(Name2Work))-1 ) )
   where name2corpind is null and nameformattype = ''1'' and Name2Work is not null and Name2Work like ''% %'''
   exec(@sql)

   -- v8.5 changed back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Name2Last
   where name2corpind is null and nameformattype = ''1'' and (Name1Last is null or Name1Last = '''')'
   exec(@sql)

   -- v8.5 changed back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set  Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = rtrim(ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40)))
   where Name2Work like ''% %'' and name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
   exec(@sql)

   -- v8.5 changed back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = REVERSE(RIGHT(REVERSE (Name2Work), len(Name2Work) - NULLIF(charindex('' '', REVERSE(Name2Work)),0)))
   where name2corpind is null and nameformattype = ''1'' and Name2Work is not null and Name1 not like ''% & %''' -- v8.7 added (and Name1 not like ''% & %'')
   exec(@sql)

   -- v8.5 start adding name2 format type 1
   -- v8.5 added for name2formattype = 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = substring(substring(Name2Work,(Charindex('' '',Name2Work)),99),1,100)
   where name2corpind is null and name2formattype = ''1'' and Name2Work like ''% %'' and Name2Last is null'
   exec(@sql)

   -- v8.5 added for name2formattype = 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work))), Name2Work = null
   where name2corpind is null and name2formattype = ''1'' and Name2Work like ''% %'' and Name2First is null'
   exec(@sql)

   -- v8.5 name2 format type 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
   where Name2Work like ''% %'' and name2corpind is null and name2formattype = ''1'' and Name2Work is not null and (Name2Work like ''JR %'' or Name2Work like ''SR %'' or Name2Work like ''III %'' or Name2Work like ''IV %'' or Name2Work like ''II %'')'
   exec(@sql)

   -- v8.5 name2 format type 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(stuff(Name2Work,1,charindex('' '',Name2Work),''''))
   where name2corpind is null and name2formattype = ''1'' and Name2Work like ''% %'' and Name2First is null' -- v8.7 added (and Name2First is null)
   exec(@sql)

   -- v8.5 name2 format type 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Work, Name2Work = null
   where name2corpind is null and name2formattype = ''1'' and Name2Work not like ''% %'' and Name2First is null'
   exec(@sql)

   -- v8.5 name2 format type 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Work = ltrim(rtrim(Name2Last))
   where name2corpind is null and name2formattype = ''1'' and Name2Work is null and ltrim(rtrim(Name2Last)) like ''% %'''
   exec(@sql)

   -- v8.5 name2 format type 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = substring(substring(Name2Work,(Charindex('' '',Name2Work)+1),99),1,100), Name2Middle = Substring(Name2Work,1,(Charindex('' '',Name2Work)-1))
   where name2corpind is null and name2formattype = ''1'' and Name2Work is not null and Name2Last like ''% %'' and name2work like ''% %''' -- 10.1 add 'and name2work like ''% %'''
   exec(@sql)

   --Format 2
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
   where Name1Work like ''%,%'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null and Name1Last is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null and (Name1Work like ''JR %'' or Name1Work like ''SR %'' or Name1Work like ''III %'' or Name1Work like ''IV %'' or Name1Work like ''II %'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)), Name1Middle = Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = [Name1Work]
   where name1corpind is null and nameformattype = ''2'' and Name1first is null'
   exec(@sql)

   --  Bill Addedd to handle a particular BK Occurrance 20180919
   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Substring(Name2Work,1,(Charindex('','',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('','',Name2Work,1)+1),40))
   where name2corpind is null and name2formattype = ''2'' and Name2Work like ''%,%'''
   exec(@sql)

   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
   where name2corpind is null and name2formattype = ''2'' and Name2Work like ''% %'' and Name2Last is null'
   exec(@sql)

   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
   where Name2Work like ''% %'' and name2corpind is null and name2formattype = ''2'' and Name2Work is not null and (Name2Work like ''JR %'' or Name2Work like ''SR %'' or Name2Work like ''III %'' or Name2Work like ''IV %'' or Name2Work like ''II %'')'
   exec(@sql)

   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype -- v8.7 added and Name2First is null
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(stuff(Name2Work,1,charindex('' '',Name2Work),''''))
   where name2corpind is null and name2formattype = ''2'' and Name2Work like ''% %'' and Name2First is null'
   exec(@sql)

   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Work, Name2Work = null
   where name2corpind is null and name2formattype = ''2'' and Name2Work not like ''% %'' and Name2First is null'
   exec(@sql)

   -- v8.5 not changing back to what v7.0 had: v7.1 through 8.4 name2formattype => v7.0 and v8.5 nameformattype
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Name2Work
   where name2corpind is null and name2formattype = ''2''and Name2Work is not null and Name1 not like ''% & %'''  -- v8.7 added (and Name1 not like ''% & %'')
   exec(@sql)

   -- v8.7 fix Name2Middle
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
   where name2corpind is null and name2formattype = ''2'' and Name2Work like ''% %'' and Name2Middle like ''% %'''
   exec(@sql)

   --Format 3
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
   where Name1Work like ''%,%'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)), Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null and Name1Last is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)), Name1Middle = Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)
   where Name1Work like ''% %'' and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = [Name1Work]
   where name1corpind is null and nameformattype = ''3'' and Name1first is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
   where name2corpind is null and nameformattype = ''3'' and Name2Work like ''% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
   where name2corpind is null and nameformattype = ''3'' and Name2Work like ''% %'''
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Work, Name2Work = null
   where name2corpind is null and nameformattype = ''3'' and Name2Work not like ''% %'' and Name2First is null'
   exec(@sql)



--------------------------------------------------------------------- Section set NULL where there are blanks ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = null
   where [Name1first] like '''''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Middle = null
   where [Name1Middle] like '''''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = null
   where [Name1Last] like '''''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = null
   where [Name2first] like '''''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = null
   where [Name2Middle] like '''''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   Set Name2Last = null
   where [Name2Last] like '''''
   exec(@sql)



--------------------------------------------------------------------- Section rearrange name ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Name1Middle, Name1Middle = Name1last, Name1Last =Name1First
   where Len(Name1last) = 1 and [Name1first] is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Middle, Name2Middle = Name2last, Name2Last =Name2First
   where Len(Name2last) = 1 and [Name2first] is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Last, Name2Middle = Name2First, Name2Last = Name2Middle
   where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Middle] = [Name1Last]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Null, Name2Last = Name2Middle
   where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Middle] = [Name2Last]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Last, Name2Middle = Name2First, Name2Last = Name2Middle
   where Len(Name2First) = 1 and [Name2Last] is not null and len([Name2Middle]) >3'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2Last, Name2Middle = Name2First, Name2Last = Null
   where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Last] not like ''&'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Name1Last
   where (Name2Last is null and len(ltrim(rtrim(Name2First))) > 1) or (Name2Last like '':'' and len(ltrim(rtrim(Name2First))) > 1) or (Name2Last Like '''' and len(ltrim(rtrim(Name2First))) > 1)'
   exec(@sql)

   -- V8 setting duplicate Name1first and Name1last
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Name1last, Name1Middle = Name1first, Name1Last =Name2Last
   where Nameformattype = ''1'' and Len(Name1last) > 1 and [Name1first] is null and Name2Last is not null and len(Name1) != len(Name1First)'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2last, Name2Last = Name1Last
   where Nameformattype = ''1'' and Len(Name1last) > 1 and [Name2first] is null and Name2Last is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Name2last, Name2Last = Name1Last
   where Len(Name1last) > 1 and [Name2first] is null and Name2Last is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1last = Name2last
   where (Len(ltrim(rtrim(Name1last))) = 0 or Name1last is null) and Name2Last is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2last = Name1last
   where (Len(ltrim(rtrim(Name1last))) > 0 or Name1last is not null) and (Len(ltrim(rtrim(Name2Last))) = 0 or Name2last is null) and (Len(ltrim(rtrim(Name2first))) > 0 or Len(ltrim(rtrim(Name2middle))) > 0)'
   exec(@sql)

   -- Added New 20160424  --  Removed for testing and possible deployment 20181019 -- added back in v8.5
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Name1last, Name1Middle = Name1First, Name1last = Name2last
   where (Len(ltrim(rtrim(Name1First))) = 1 and Name1last is not null) and Name2Last is not null'
   exec(@sql)

   -- Addedd to correct double last names 20171117
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Ltrim(Rtrim(Name1work))
   where ltrim(rtrim(Name1First)) = ltrim(rtrim(Name1Last)) and (Name1work is not null and Name1Work not like '''')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Ltrim(Rtrim(Name2work))
   where ltrim(rtrim(Name2First)) = ltrim(rtrim(Name2Last)) and (Name2work is not null and Name2Work not like '''')'
   exec(@sql)

   -- v8.6 added to fix type 3 name1first with two names
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Substring(Name1First,(Charindex('' '',Name1First,1)+1),40)
   where Name1First like ''% %'' and name1corpind is null and nameformattype = ''3'' and Name1First is not null'
   exec(@sql)

   -- Added the below to correct double last names in Name 2
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Null
   where ltrim(rtrim(Name2First)) = ltrim(rtrim(Name2Middle)) and (Name2work is not null and Name2Work not like '''')'
   exec(@sql)



--------------------------------------------------------------------- Section step 6 Cleanup mc, de, la, di, mac, von, van, del etc.  ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Last] = [Name1Middle] + [Name1Last]
   where name1corpind is null and ([Name1Middle] like ''mc'' or [Name1Middle] like ''de'' or [Name1Middle] like ''la'' or [Name1Middle] like ''di'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Last] = [Name1Middle] + [Name1Last]
   where name1corpind is null and ([Name1Middle] like ''mac'' or [Name1Middle] like ''von'' or [Name1Middle] like ''van'' or [Name1Middle] like ''del'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Last] = [Name2Middle] + [Name2Last]
   where name2corpind is null and ([Name2Middle] like ''mc'' or [Name2Middle] like ''de'' or [Name2Middle] like ''la'' or [Name2Middle] like ''di'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Last] = [Name2Middle] + [Name2Last]
   where name2corpind is null and ([Name2Middle] like ''mac'' or [Name2Middle] like ''von'' or [Name2Middle] like ''van'' or [Name2Middle] like ''del'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Replace(Name1First,'','','''') 
   where Name1First like ''%,'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Middle = Replace(Name1Middle,'','','''')
   where Name1Middle like ''%,'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Replace(Name1last,'','','''') 
   where Name1Last like ''%,'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Replace(Name2last,'','','''') 
   where Name2Last like ''%,'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Middle = Replace(Name1Middle,''.'','''') 
   where Name1Middle like ''%.'' and name1corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Replace(Name2Middle,''.'','''') 
   where Name2Middle like ''%.'' and name2corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Middle = Replace(Name2Middle,''&'','''') 
   where Name2Middle like ''&'' and name2corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Replace(Name2last,''&'','''') 
   where Name2Last like ''&'' and name2corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Replace(Name2last,'':'','''') 
   where Name2Last like '':'' and name2corpind is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2First] = Substring([Name2Middle],1,(Charindex('' '',[Name2Middle],1)-1)), [Name2Middle] = Substring([Name2Middle],(Charindex('' '',[Name2Middle],1)+4),40)
   where Name2Last = Name2first and Name2Middle like ''% %'''
   exec(@sql)
 
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2First] = [Name2Middle], [Name2Middle] = Null
   where Name2Last = Name2first and Name2Middle not like ''% %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1Middle] = Null
   where [Name1Middle] like ''%&%'' or [Name1Middle] like ''&%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Middle] = Null
   where [Name2Middle] like ''%&%'' or [Name2Middle] like ''&%'''
   exec(@sql)



--------------------------------------------------------------------- Section probability test for Surname ---------------------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1LastProb] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name1Last]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2LastProb] = [SurNameProbability]
   from [dbo].['+@tableName+'] n join zSurname_Master s on s.SurnameName = n.[Name2Last]'
   exec(@sql)

   --  added 20181019  Probability Fix Name 2 Surname proplem introduced by the following statement
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Last] = [Name2First], [Name2First] = [Name2Last], [Name2Middle] = [Name2Middle]
   where [Name2LastProb] < .1 and [Name2Last] <> [Name1Last] and Name2First = Name1Last'
   exec(@sql)

   --  added 20171116  Probability Fix Name 2 Surname
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2Last] = [Name1Last], [Name2First] = [Name2Last], [Name2Middle] = [Name2First]
   where [Name2LastProb] < .1 and [Name2Last] <> [Name1Last]'
   exec(@sql)

   --  Addedd to correct double last names 20171117
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Ltrim(Rtrim(Name1work))
   where ltrim(rtrim(Name1First)) = ltrim(rtrim(Name1Last)) and (Name1work is not null and Name1Work not like '''')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Ltrim(Rtrim(Name2work))
   where ltrim(rtrim(Name2First)) = ltrim(rtrim(Name2Last)) and (Name2work is not null and Name2Work not like '''')'
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''JR'', Name1Last = Substring(Name1Last,1,(Charindex('' JR'',Name1Last,1)-1))
   where name1corpind is null and Name1Last is not null and Name1Last like ''% JR'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''JR'', Name2Last = Substring(Name2Last,1,(Charindex('' JR'',Name2Last,1)-1))
   where name2corpind is null and Name2Last is not null and Name2Last like ''% JR'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''SR'', Name1Last = Substring(Name1Last,1,(Charindex('' SR'',Name1Last,1)-1))
   where name1corpind is null and Name1Last is not null and Name1Last like ''% SR'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''SR'', Name2Last = Substring(Name2Last,1,(Charindex('' SR'',Name2Last,1)-1))
   where name2corpind is null and Name2Last is not null and Name2Last like ''% SR'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''II'', Name1Last = Substring(Name1Last,1,(Charindex('' II'',Name1Last,1)-1))
   where name1corpind is null and Name1Last is not null and Name1Last like ''% II'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''II'', Name2Last = Substring(Name2Last,1,(Charindex('' II'',Name2Last,1)-1))
   where name2corpind is null and Name2Last is not null and Name2Last like ''% II'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''III'', Name1Last = Substring(Name1Last,1,(Charindex('' III'',Name1Last,1)-1))
   where name1corpind is null and Name1Last is not null and Name1Last like ''% III'''
   exec(@sql)

   -- v8.5 add to address a surname followed by a comma
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''III'', Name2Last = Substring(Name2Last,1,(Charindex('' III'',Name2Last,1)-1))
   where name2corpind is null and Name2Last is not null and Name2Last like ''% III'''
   exec(@sql)

   -- v10.2 add to address a surname followed by a comma (UofA)
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Generation = ''IV'', Name1Last = Substring(Name1Last,1,(Charindex('' IV'',Name1Last,1)-1))
   where name1corpind is null and Name1Last is not null and Name1Last like ''% IV'''
   exec(@sql)

   -- v10.2 add to address a surname followed by a comma (UofA)
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Generation = ''IV'', Name2Last = Substring(Name2Last,1,(Charindex('' IV'',Name2Last,1)-1))
   where name2corpind is null and Name2Last is not null and Name2Last like ''% IV'''
   exec(@sql)

   -- v8.5 clean up spaces and commas
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Replace(Name1First,'',  '','''')
   Where name1corpind is null and Name1First like '',  %'''
   exec(@sql)

   -- v8.5 clean up spaces and commas
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = Replace(Name2First,'',  '','''')
   where name2corpind is null and Name2First like '',  %'''
   exec(@sql)

   -- v8.5 clean up spaces and commas
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Work = Replace(Name1Work,'',  '','''')
   where name1corpind is null and Name1Work like '',  %'''
   exec(@sql)

   -- v8.5 clean up spaces and commas
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Work = Replace(Name2Work,'',  '','''')
   where name2corpind is null and Name2Work like '',  %'''
   exec(@sql)

   -- v8.7 added to fix missing Name1First where Name1Work not null and Name1 has &
   set @sql = 'update [dbo].['+@tableName+']
   set Name1First = Name1Work
   where name1corpind is null and nameformattype = ''1'' and Name1First is null and Name1Work is not null and Name1Work not like ''% %'' and Name1 like ''% & %'''
   exec(@sql)

--------------------------------------------------------------------- Section format concatenated names ---------------------------------------------------------------------
   -- truncate substring fix V8
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = substring((ltrim(rTrim(([Name1Last] + '' '' + [Name1first] + '' '' + [Name1Middle])))),1,100)
   where [Name1CorpInd] is null and [Name1Middle] is not null'
   exec(@sql)

   -- truncate substring fix V8
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = substring((ltrim(rTrim(([Name1Last] + '' '' + [Name1first])))),1,100)
   where [Name1CorpInd] is null and [Name1Middle] is null'
   exec(@sql)

   -- truncate substring fix V8
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2fmt] = substring((ltrim(rtrim((ltrim(rTrim(([Name2Last] + '' '' + [Name2first]))) + '' '' + [Name2Middle])))),1,100)
   where [Name2CorpInd] is null and [Name2Middle] is not null'
   exec(@sql)

   -- truncate substring fix V8
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2fmt] = substring((ltrim(rtrim((ltrim(rTrim(([Name2Last] + '' '' + [Name2first]))))))),1,100)
   where [Name2CorpInd] is null and [Name2Middle] is null'
   exec(@sql)

   -- ADDED 20160419 this was missing to code to fix nulls in Name1fmt and Name2fmt
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = (ltrim(rTrim(([name1]))))
   where [Name1CorpInd] is null and [Name1fmt] is null and [name1] is not null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name2fmt] = (ltrim(rTrim(([name2]))))
   where [Name2CorpInd] is null and [Name2fmt] is null and [name2] is not null'
   exec(@sql)

   --CleanGarbage
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2fmt] = null
   where [Name2fmt] like ''&%'' or [Name2fmt] like ''%&%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], '','', '''' )
   where [Name1CorpInd] = ''Y'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace([Name1], ''.'', '''' )
   where [Name1CorpInd] = ''Y'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], '','', '''' )
   where [Name2CorpInd] = ''Y'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''.'', '''' )
   where [Name2CorpInd] = ''Y'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace([Name2], ''.'', '''' )
   where [Name2CorpInd] = ''Y'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Fmt = Replace([Name2Fmt], ''  '', '' '' )
   where [Name2Fmt] like ''%  %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1Fmt = Replace([Name1Fmt], ''  '', '' '' )
   where [Name1Fmt] like ''%  %'''
   exec(@sql)

   -- Addedd to Clean Last Name where empty  --  Addedd 20171206
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Last = Ltrim(rtrim([Name1First])), [Name1First] = null
   where ([Name1Last] is null or [Name1Last] like '''') and ([Name1First] is not null or [Name1First] not like '''')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Last = Ltrim(rtrim([Name2First])), [Name2First] = null
   where ([Name2Last] is null or [Name2Last] like '''') and ([Name2First] is not null or [Name2First] not like '''')'
   exec(@sql)

   -- Final Clean Up Name 1 and Name 2 ---  Added 20151117
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace(Replace([Name1], ''  '', '' '' ), ''  '', '' '' )
   where [Name1] like ''%  %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace(Replace([Name2], ''  '', '' '' ), ''  '', '' '' )
   where [Name2] like ''%  %'''
   exec(@sql)

   --  Final Clean Up formatted Name 1 and Name 2 ---  Added 20180510
   set @sql = 'update [dbo].['+@tableName+']
   set Name1Fmt = Replace(Replace([Name1Fmt], '':'', '''' ), '' ,'', '''' )'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Fmt = Replace(Replace([Name2Fmt], '':'', '''' ), '' ,'', '''' )'
   exec(@sql)

   --  Added 20180608 to clean up single name in Name2Work
   -- truncate substring V8
   set @sql = 'update [dbo].['+@tableName+']
   set Name2Fmt = substring(ltrim(rtrim([Name1Last] + '' '' + [Name2Work])),1,100)
   where ltrim(rtrim([Name2Work])) not like ''% %'' and [Name2First] is null and [Name2Middle] is null and [Name2Last] is null and ([Name2fmt] like '''' or [Name2fmt] is null)'
   exec(@sql)

   --  Added to Fix Name 2 Double   --  20190821 BR
   set @sql = 'update [dbo].['+@tableName+']
   set Name2First = substring(Name2Middle,1,20), Name2Middle = substring(Name2First,1,1), [N12] = ''X''
   where right(name2first,4) like Right(name2last,4)'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Fmt = substring(ltrim(rtrim([Name2Last] + '' '' + [Name2First] + '' '' +[Name2Middle])),1,100)
   where [N12] = ''X'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2Fmt = Null, name2first = null, name2middle = null, name2last = null
   where name2fmt like ''[a-z] %'' and name2corpind is null'
   exec(@sql)

   -- Added V7 20180807 by GM for lkup_Trust_Name_Exclude
   set @sql = 'update [dbo].['+@tableName+'] 
   set Name1CorpInd = ''Y'', Name1TrustInd = ''N''
   from [dbo].['+@tableName+'] t join [dbo].[lkup_Trust_Name_Exclude] c on ltrim(rtrim(c.[ContainsIn])) = ltrim(rtrim(t.[Name1]))
   where c.[ContainsIn] is not NULL and t.[Name1] is not NULL' 
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+'] 
   set Name2CorpInd = ''Y'', Name2TrustInd = ''N''
   from [dbo].['+@tableName+'] t
   join [dbo].[lkup_Trust_Name_Exclude] c
   on ltrim(rtrim(c.[ContainsIn])) = ltrim(rtrim(t.[Name2]))
   where c.[ContainsIn] is not NULL and t.[Name2] is not NULL'
   exec(@sql)

   -- V8 fix duplication in Name1Last and matching Name1First and Name1Last
   SET CONCAT_NULL_YIELDS_NULL ON
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = CASE WHEN dbo.AfterLastCharacter(Name1,'' '') in (''Jr'',''Sr'',''II'',''III'',''Dr'') 
                    THEN [dbo].[AfterLast2Characters](Name1,'' '') 
                    ELSE dbo.AfterLastCharacter(Name1,'' '') 
                    END + '' '' + dbo.Before1stCharacter(Name1,'' ''), [Name2fmt] = NULL
   WHERE [Name1fmt] like ''% %'' and Name1 like ''% % %'' AND dbo.Before1stCharacter([Name1fmt],'' '') = dbo.After1stCharacter([Name1fmt],'' '')'
   exec(@sql)
   SET CONCAT_NULL_YIELDS_NULL OFF
    
   -- V8 fix duplication in Name1Last and matching Name1First and Name1Last
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = dbo.Before1stCharacter(Name1fmt,'' ''), [Name2fmt] = NULL
   WHERE [Name1fmt] like ''% %'' AND dbo.Before1stCharacter([Name1fmt],'' '') = dbo.After1stCharacter([Name1fmt],'' '')'
   exec(@sql)

   -- V10.1 UPPER case all fields
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1fmt] = UPPER([Name1fmt]), [Name2fmt] = UPPER([Name2fmt]), 
       [Name1First] = UPPER([Name1First]), [Name2First] = UPPER([Name2First]),
	   [Name1Middle] = UPPER([Name1Middle]), [Name2Middle] = UPPER([Name2Middle]),
	   [Name1Last] = UPPER([Name1Last]), [Name2Last] = UPPER([Name2Last])'
   exec(@sql)

--------------------------------------------------------------------- Section mailing label begins ---------------------------------------------------------------------
   -- also see stored procedure usp_name_parser_unified_trustV10 
   IF @MailingLabel = 'Y'
   BEGIN
   -- added for v8.3 skip Mailing Label process
   -- V8 start
      set @sql = 'update [dbo].['+@tableName+']
	  set Name1TypeInd = ''Corp''
	  where  Name1CorpInd = ''Y'''
	  exec(@sql)

	  set @sql = 'update [dbo].['+@tableName+']
	  set Name2TypeInd = ''Corp''
	  where  Name2CorpInd = ''Y'''
	  exec(@sql) 

	  set @sql = 'update [dbo].['+@tableName+']
	  set Name1TypeInd = ''Trust''
	  where  Name1TrustInd = ''Y'''
	  exec(@sql) 

	  set @sql = 'update [dbo].['+@tableName+']
	  set Name2TypeInd = ''Trust''
	  where  Name2TrustInd = ''Y'''
	  exec(@sql) 

	  set @sql = 'update [dbo].['+@tableName+']
	  set Name1TypeInd = ''Individual''
	  where  Name1CorpInd is null and Name1TrustInd is null and len(Name1fmt) > 0'  
	  exec(@sql)

	  set @sql = 'update [dbo].['+@tableName+']
	  set Name2TypeInd = ''Individual''
	  where  Name2CorpInd is null and Name2TrustInd is null and len(Name2fmt) > 0'
	  exec(@sql)

	  --print '*** Build second work table (temp table) V8 ***'
	  set @sql = '--print ''*** Create and load #temp table V8 ***'';
                  SELECT * INTO #NameWorkTrust FROM [dbo].['+@tableName+'] where Name1TrustInd = ''Y'' or Name2TrustInd = ''Y'';
				  --print ''*** NULL Trust and Corp Ind fields in #temp table V8 ***'';
				  UPDATE #NameWorkTrust SET Name1CorpInd = NULL, Name2CorpInd = NULL, Name1TrustInd = NULL, Name2TrustInd = NULL;
			   
				  --print ''*** add indexes to temp table #NameWorkTrust V8.2 ***'';
				  CREATE NONCLUSTERED INDEX [Fips] ON #NameWorkTrust (Fips) WITH (FILLFACTOR = 70);
				  CREATE NONCLUSTERED INDEX [FipsID] ON #NameWorkTrust (Fips, ID) WITH (FILLFACTOR = 70);
				  CREATE NONCLUSTERED INDEX [ID] ON #NameWorkTrust (ID) WITH (FILLFACTOR = 70);

				  --print ''*** Run second name parser sp on #temp table V8 ***'';
				  EXEC usp_name_parser_unified_trustV10 @tableName = #NameWorkTrust, @RowCounts = ''N'';
			   
				  --print ''*** Update Name Parser work table with MailLabelName 1 values (no Name2fmt) V8 ***'';
				  update a set a.MailingLabelName = b.Name1fmt 
					  from [dbo].['+@tableName+'] a join #NameWorkTrust b on a.id = b.id 
					  where b.Name2fmt = '''' or b.Name2fmt is NULL or rtrim(ltrim(b.Name1last)) = rtrim(ltrim(b.Name2));
			   
				  --print ''*** Update Name Parser work table with MailLabelName 2 values (both Name1Last and Name2Last present but different) V8 ***'';
				  update a set a.MailingLabelName = substring(rtrim(ltrim(b.Name1fmt)) + '' & '' + rtrim(ltrim(b.Name2fmt)),1,100) 
					  from [dbo].['+@tableName+'] a join #NameWorkTrust b on a.id = b.id 
					  where (b.Name2fmt != '''' or b.Name2fmt is not NULL) and b.Name1last != b.Name2last;
			   
				  --print ''*** Update Name Parser work table with MailLabelName 3 values (both Name1Last and Name2Last present and same but no name2 first name) V8 ***'';
				  --update a set a.MailingLabelName = substring(rtrim(ltrim(b.Name1First)) + '' '' + rtrim(ltrim(b.Name1Middle)) + '' & '' + rtrim(ltrim(b.Name2fmt)),1,100) 
				  update a set a.MailingLabelName = substring(rtrim(ltrim(b.Name1First)) + '' & '' + rtrim(ltrim(b.Name2fmt)),1,100) 
					  from [dbo].['+@tableName+'] a join #NameWorkTrust b on a.id = b.id 
					  where (b.Name2fmt != '''' or b.Name2fmt is not NULL) and b.Name1last = b.Name2last and rtrim(ltrim(b.Name1last)) != rtrim(ltrim(b.Name2));

				  ---- test temp table start
				  --print ''*** Create and load #temp table V8 ***'';
				  --SELECT * INTO NameWorkTrust_V8 FROM [dbo].['+@tableName+'] where Name1TrustInd = ''Y'' or Name2TrustInd = ''Y'';
				  --print ''*** NULL Trust and Corp Ind fields in #temp table V8 ***'';
				  --UPDATE NameWorkTrust_V8 SET Name1CorpInd = NULL, Name2CorpInd = NULL, Name1TrustInd = NULL, Name2TrustInd = NULL;
				  --print ''*** Run second name parser sp on #temp table V8 ***'';
				  --EXEC usp_name_parser_unified_trustV10 @tableName = NameWorkTrust_V8, @RowCounts = ''N'';
				  --print ''*** Update Name Parser work table with MailingLabelName 1 values (no Name2fmt) V8 ***'';
				  --update a set a.MailingLabelName = b.Name1fmt 
				  --    from [dbo].['+@tableName+'] a join NameWorkTrust_V8 b on a.id = b.id 
				  --    where b.Name2fmt = '''' or b.Name2fmt is NULL;
				  --print ''*** Update Name Parser work table with MailingLabelName 2 values (both Name1Last and Name2Last present but different) V8 ***'';
				  --update a set a.MailingLabelName = substring(rtrim(ltrim(b.Name1fmt)) + '' & '' + rtrim(ltrim(b.Name2fmt)),1,100) 
				  --    from [dbo].['+@tableName+'] a join NameWorkTrust_V8 b on a.id = b.id 
				  --    where (b.Name2fmt != '''' or b.Name2fmt is not NULL) and b.Name1last != b.Name2last;
				  --print ''*** Update Name Parser work table with MailingLabelName 3 values (both Name1Last and Name2Last present and same but no name2 first name) V8 ***'';
				  --update a set a.MailingLabelName = substring(rtrim(ltrim(b.Name1First)) + '' '' + rtrim(ltrim(b.Name1Middle)) + '' & '' + rtrim(ltrim(b.Name2fmt)),1,100) 
				  --    from [dbo].['+@tableName+'] a join NameWorkTrust_V8 b on a.id = b.id 
				  --    where (b.Name2fmt != '''' or b.Name2fmt is not NULL) and b.Name1last = b.Name2last;
				  ---- test temp table end
				   			   
				  --print ''*** Drop #temp table V8 ***'';
				  --select top 1000 MailingLabelName,Name1,Name1fmt,Name2,Name2fmt,Name1Last,Name2Last,* from #NameWorkTrust
				  ---Select * from #NameWorkTrust
				  DROP TABLE #NameWorkTrust'
	  exec(@sql)

	  --print '*** Populate all non-trust records V8 ***'
	  set @sql = '--print ''*** Populate all non-trust records V8 ***'';

				  --print ''*** Update Name Parser work table with MailingLabelName 4 values (no Name2fmt) V8 ***'';
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = rtrim(ltrim(substring((rtrim(ltrim(Name1First)) + '' '' + rtrim(ltrim(Name1Last))),1,100)))
				  from [dbo].['+@tableName+'] 
				  where (MailingLabelName is null or MailingLabelName = '''') and (Name2fmt = '''' or Name2fmt is NULL) and (Name1First <> '''' or Name1First is not NULL) and (Name1Last <> '''' or Name1Last is not NULL);
				  ---  BR Added Name1First and Name2Last requirement  20251119

				  --print ''*** Update Name Parser work table with MailingLabelName 5 values (both Name1Last and Name2Last present but different) V8 ***'';
				  update [dbo].['+@tableName+']  
				  set MailingLabelName = rtrim(ltrim(substring(rtrim(ltrim(Name1First)) + '' '' + Name1Last + '' & '' + rtrim(ltrim(Name2First)) + '' '' + Name2Last,1,100)))
				  from [dbo].['+@tableName+'] 
				  where (MailingLabelName is null or MailingLabelName = '''') and (Name2First != '''' or Name2First is not NULL) and (Name2Last != '''' or Name2Last is not NULL)and (Name1First <> '''' or Name1First is not NULL) and (Name1Last <> '''' or Name1Last is not NULL) and Name1last != Name2last;
				  --- BR Changed Name2 requirement to Name2First and Name2Last and Name1first and Name1last requirement 20251119
				  
				  --print ''*** Update Name Parser work table with MailingLabelName 6 values (both Name1Last and Name2Last present and same but no name2 first name) V8 and V8.2 ***'';
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = rtrim(ltrim(substring(rtrim(ltrim(Name1First)) + '' & '' + rtrim(ltrim(Name2First)) + '' '' + Name1Last,1,100)))
				  from [dbo].['+@tableName+']
				  where (MailingLabelName is null or MailingLabelName = '''') and (Name2fmt != '''' or Name2fmt is not NULL) and Name1last = Name2last and (rtrim(ltrim(Name1last)) != rtrim(ltrim(Name2)) or Name2 is null);

				  --print ''*** Update Name Parser work table with MailingLabelName 7 values (corp) V8 ***'';
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = rtrim(ltrim(substring(rtrim(ltrim(Name1)),1,100)))
				  from [dbo].['+@tableName+']
				  where (MailingLabelName is null or MailingLabelName = '''') and (Name1fmt = '''' or Name1fmt is NULL);

				  --print ''*** Update Name Parser work table with MailingLabelName 8 values (any missed criteria) V8 ***'';
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = rtrim(ltrim(substring(rtrim(ltrim(Name1)),1,100)))
				  from [dbo].['+@tableName+']
				  where (MailingLabelName is null or MailingLabelName = '''');'
	  exec(@sql)

	  --print '*** Fix AMERICAN FIRST to FIRST AMERICAN *** and *** FAMILY TRUST ***'
	  set @sql = '--print ''*** Fix AMERICAN FIRST to FIRST AMERICAN trust ***'';
				  update [dbo].['+@tableName+']  
				  set MailingLabelName = ''FIRST AMERICAN''
				  from [dbo].['+@tableName+']   
				  where MailingLabelName = ''AMERICAN FIRST'' and Name1TypeInd = ''Trust'';'
	  exec(@sql)
	  set @sql = '--print ''*** Fix AMER FIRST to FIRST AMER trust ***'';
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = ''FIRST AMER''
				  from [dbo].['+@tableName+'] 
				  where MailingLabelName = ''AMER FIRST'' and Name1TypeInd = ''Trust'';'
	  exec(@sql)

	  set @sql = '--print ''*** & MailingLabelName ***''; -- V8.2 added
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = substring(ltrim(MailingLabelName),3,100)
				  from [dbo].['+@tableName+'] 
				  where ltrim(MailingLabelName) like ''& %'';'
	  exec(@sql)

	  set @sql = '--print ''*** FAMILY TRUST MailingLabelName Name1 ***''; -- V8.4 added
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = substring(MailingLabelName,1,93) + '' FAMILY''
				  from [dbo].['+@tableName+'] 
				  where Name1TypeInd = ''Trust'' and Name1 like ''%FAMILY TRUST%'';'
	  exec(@sql)

	  set @sql = '--print ''*** the beginning  MailingLabelName ***''; -- V8.4 added
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = REPLACE(MailingLabelName,''the '','' '')
				  from [dbo].['+@tableName+'] 
				  where Name1TypeInd = ''Trust'' and MailingLabelName like ''the %'';'
	  exec(@sql)

	  set @sql = '--print ''*** the middle MailingLabelName ***''; -- V8.4 added
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = REPLACE(MailingLabelName,'' the '','' '')
				  from [dbo].['+@tableName+'] 
				  where Name1TypeInd = ''Trust'' and MailingLabelName like ''% the %'';'
	  exec(@sql)

	  set @sql = '--print ''*** the ending MailingLabelName ***''; -- V8.4 added
				  update [dbo].['+@tableName+'] 
				  set MailingLabelName = REPLACE(MailingLabelName,'' the'','' '')
				  from [dbo].['+@tableName+'] 
				  where Name1TypeInd = ''Trust'' and MailingLabelName like ''% the'';'
	  exec(@sql)

   PRINT 'Completed Mailing Label Process'   
   END -- end skip Mailing Label process

   ELSE
      BEGIN
      PRINT 'Skipped Mailing Label Process'
	  END

-- V8 end

SET CONCAT_NULL_YIELDS_NULL ON


END



