SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER OFF

-- =============================================
-- KEEP PropertyID/REF_ID UPDATED
-- =============================================
CREATE PROCEDURE [dbo].[usp_Post_Update_PropIDRefID]
AS
BEGIN
	SET NOCOUNT ON;

Truncate table DBS_Tax_Lic.[dbo].sp_Tracking

/****************  SECTION 1  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 1,Getdate()

EXEC DBS_Tax_Lic.[dbo].[000_remove_Extra_Ascii_from_table]

DROP TABLE DBS_Tax_Lic.[dbo].[Matching_WORK_APNS]

Select FIPS,PropertyID,formattedAPN,convert(varchar(45),Replace(replace(replace(UnformattedAPN,' ',''),'-',''),'.','')) as UnformattedAPN,TaxAccountNumber,SitusStdFullStreetAddress
INTO DBS_Tax_Lic.[dbo].[Matching_WORK_APNS]
FROM data.dbo.Property with(NOLOCK)

CREATE NONCLUSTERED INDEX [ix_FipsUnFormAPN] ON [dbo].[Matching_WORK_APNS]
([FIPS] ASC,[UnformattedAPN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


UPDATE DBS_Tax_Lic.dbo.Licensing_Deliverable
SET LIC_FIPS = Right('0' + convert(varchar(5),FIPS),5)
WHERE LIC_FIPS is null

Truncate Table DBS_Tax_Lic.dbo.Matching_Work_II

INSERT INTO DBS_Tax_Lic.dbo.Matching_Work_II
SELECT a.FIPS,a.PAYEE_PARCEL_NUMBER,a.ASSESSOR_PARCEL_NUMBER,a.REF_ID,a.FAPropertyID,a.LIC_APN,a.LIC_FIPS
FROM DBS_Tax_Lic.dbo.Licensing_Deliverable a
Where Updated > GETDATE()-7 and  REF_ID is NULL

UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 1


/****************  SECTION 2  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 2,Getdate()

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.Unformatted_APN 
WHERE a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.formatted_APN
WHERE a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.P_ID_IRIS_FRMTD
WHERE a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.ALTERNATE_APN
WHERE a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.ACCOUNT_NBR
WHERE a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.ORIGINAL_APN
WHERE a.REF_ID is null

UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 2


/****************  SECTION 3  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 3,Getdate()



UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.Unformatted_APN + ' ' + ALTERNATE_APN
WHERE a.REF_ID is null

UPDATE a
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN [DBS_Tax_Lic].[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.UnFormattedAPN
WHERE a.FAPropertyID is null

UPDATE a
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.ASSESSOR_PARCEL_NUMBER,' ','') = b.UNFORMATTED_APN
WHERE a.REF_ID is null

UPDATE a
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.dbo.Matching_WORK_APNS b with(NOLOCK)
on a.FIPS = b.FIPS
and Substring(replace(replace(Substring(PAYEE_PARCEL_NUMBER,5,25),'-  ','-00'),'  -','-00-'),1,14) = b.FormattedAPN
WHERE a.FIPS = 36059 and a.FAPropertyID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.ASSESSOR_PARCEL_NUMBER,3,50) + '00' = b.Unformatted_APN 
WHERE a.FIPS = 01061 and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.ASSESSOR_PARCEL_NUMBER,3,50) + '0' = b.Unformatted_APN 
WHERE a.FIPS = 01063 and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.ASSESSOR_PARCEL_NUMBER,3,50) = b.Unformatted_APN 
WHERE a.FIPS in(01071,01073) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = b.ORiginal_APN 
WHERE a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and ltrim(rtrim(LEFT(a.Assessor_Parcel_Number,9))) = b.Unformatted_APN 
WHERE a.FIPS in(04003,04021) and a.REF_ID is null


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 3


/****************  SECTION 4  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 4,Getdate()


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and ltrim(rtrim(LEFT(a.Assessor_Parcel_Number,8))) = b.Unformatted_APN 
WHERE a.FIPS in(04025,04013) and a.REF_ID is null

update a
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on CASE WHEN Right(a.Assessor_Parcel_Number,2) = '00' THEN Substring(a.Assessor_Parcel_Number,1,8)
	ELSE Substring(a.Assessor_Parcel_Number,1,9) END = b.UnformattedAPN
WHERE a.Fips = 04021 and b.FIPS = '04021'
and FAPropertyID is NULL

update a
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on CASE WHEN Right(a.Assessor_Parcel_Number,1) Like '[0-9]' THEN Substring(a.Assessor_Parcel_Number,1,9)
	ELSE Substring(a.Assessor_Parcel_Number,1,10) END = b.UnformattedAPN
WHERE a.Fips = 04025 and b.FIPS = '04025'
and FAPropertyID is NULL



UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and ltrim(rtrim(LEFT(a.Assessor_Parcel_Number,9))) = b.Unformatted_APN 
WHERE a.FIPS in(06019) and a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and ltrim(rtrim(CASE WHEN LEFT(a.Assessor_Parcel_Number,10) LIKE '%00' THEN LEFT(a.Assessor_Parcel_Number,8) ELSE LEFT(a.Assessor_Parcel_Number,10) END)) = b.Unformatted_APN 
WHERE a.FIPS in(06029) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(ltrim(rtrim(LEFT(a.Assessor_Parcel_Number,10))),'-','') = b.Unformatted_APN 
WHERE a.FIPS in(06033,06059) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and Substring(a.Assessor_Parcel_Number,3,50) = b.Unformatted_APN 
WHERE a.FIPS in(06075) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and LEFT(a.Assessor_Parcel_Number,8) = b.Unformatted_APN 
WHERE a.FIPS in(06077) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and LEFT(REPLACE(a.Assessor_Parcel_Number,'-',''),9) = b.Unformatted_APN 
WHERE a.FIPS in(06097) and a.REF_ID is null


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 4


/****************  SECTION 5  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 5,Getdate()

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and LEFT(a.Assessor_Parcel_Number,1) + Substring(a.Assessor_Parcel_Number,4,20) = b.UNFORMATTED_APN 
WHERE Assessor_Parcel_Number like '%  %' and a.FIPS in(08001,08013,08014,08029,08039,08045,08049,08067,08083,08085,08097,08107,08119,08123) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and LEFT(a.Assessor_Parcel_Number,1) + Substring(a.Assessor_Parcel_Number,4,20) = b.ACCOUNT_NBR 
WHERE Assessor_Parcel_Number like '%  %' and  a.FIPS in(08007,08019,08043,08087,08103,08113) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and LEFT(a.Assessor_Parcel_Number,8) = b.UNFORMATTED_APN 
WHERE a.FIPS in(08065) and a.REF_ID is null


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.Assessor_Parcel_Number,'-','') = b.ACCOUNT_NBR 
WHERE a.FIPS in(12023) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.Assessor_Parcel_Number,2,40) = b.ACCOUNT_NBR 
WHERE a.FIPS in(12057) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.Assessor_Parcel_Number,'/','.') = b.FORMATTED_APN 
WHERE a.FIPS in(12061) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(substring(a.Assessor_Parcel_Number,2,40),'-','') = b.UNFORMATTED_APN 
WHERE a.FIPS in(12097) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and CASE WHEN Assessor_Parcel_Number LIKE '%/%/%' THEN REPLACE(SUBSTRING(Assessor_Parcel_Number,8,50),'/','') ELSE SUBSTRING(Assessor_Parcel_Number,7,50) END = b.UNFORMATTED_APN 
WHERE a.FIPS in(12103) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and REPLACE(REPLACE(Assessor_Parcel_Number,'-',''),'/','') = b.UNFORMATTED_APN 
WHERE a.FIPS in(12111) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.Assessor_Parcel_Number,3,40) = b.UNFORMATTED_APN 
WHERE a.FIPS in(01013) and a.REF_ID is null


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 5


/****************  SECTION 6  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 6,Getdate()



UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and REPLACE(a.ASSESSOR_PARCEL_NUMBER,' ','0') = b.Unformatted_APN + ALTERNATE_APN
WHERE a.REF_ID is null and a.FIPS in(01047)


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number + '0' = b.Unformatted_APN 
WHERE a.REF_ID is null and a.FIPS in(01099)


UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.Assessor_Parcel_Number,2,40) = b.UNFORMATTED_APN 
WHERE a.FIPS in(02170) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.Assessor_Parcel_Number,1,9) = b.UNFORMATTED_APN 
WHERE a.FIPS in(06065) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = substring(b.UNFORMATTED_APN,2,9)
WHERE a.FIPS in(08069) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(Assessor_Parcel_Number,4,10) = ALTERNATE_APN
WHERE a.FIPS in(08089) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and substring(a.Assessor_Parcel_Number,2,20) = b.UNFORMATTED_APN 
WHERE a.FIPS in(12057) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.Assessor_Parcel_Number,'-','') = substring(b.ALTERNATE_APN,2,30)
WHERE a.FIPS in(12051) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.Assessor_Parcel_Number,' ','') = substring(b.ALTERNATE_APN,1,4) + '00000' + substring(b.ALTERNATE_APN,5,20)
WHERE a.FIPS in(13035) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(a.Assessor_Parcel_Number,' ','') = replace(b.ORIGINAL_APN,' ','')
WHERE a.FIPS in(13039,13211,13227,13241) and a.REF_ID is null


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 6


/****************  SECTION 7  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 7,Getdate()



UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(replace(a.Assessor_Parcel_Number,'-',''),' ','') = b.UNFORMATTED_APN
WHERE a.FIPS in(13069) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = global.dbo.DeleteLeadZeros_II(CASE WHEN global.dbo.Before1stCharacter(FORMATTED_APN,'-') LIKE '%0' THEN LEFT(FORMATTED_APN,4) ELSE global.dbo.Before1stCharacter(FORMATTED_APN,'-') END)
	+ '-' + global.dbo.DeleteLeadZeros_II(global.dbo.before1stCharacter(global.dbo.After1stCharacter(global.dbo.After1stCharacter(FORMATTED_APN,'-'),'-'),'-'))
	+ case when global.dbo.After1stCharacter(global.dbo.After1stCharacter(global.dbo.After1stCharacter(FORMATTED_APN,'-'),'-'),'-') like '000' THEN '' ELSE '-' + global.dbo.DeleteLeadZeros_II(global.dbo.After1stCharacter(global.dbo.After1stCharacter(global.dbo.After1stCharacter(FORMATTED_APN,'-'),'-'),'-')) END
WHERE a.FIPS in(13131) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(replace(replace(replace(a.Assessor_Parcel_Number,'       ','-'),'      ','-'),'     ','-'),' ','-') = b.FORMATTED_APN
WHERE a.FIPS in(13159) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(replace(Assessor_Parcel_Number,'   ',' '),'  ',' ') = b.UnformattedAPN
WHERE a.FIPS in(13169) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(replace(Assessor_Parcel_Number,'R00','R'),'M00','M') = b.UnformattedAPN
WHERE a.FIPS in(35043) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and Convert(int,Assessor_Parcel_Number) = convert(int,taxaccountNumber)
WHERE a.FIPS in(35029) and b.fips = '35029' and a.REF_ID is null

UPDATE a
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and replace(replace(a.ASSESSOR_PARCEL_NUMBER,' ',''),'-','') = b.UnformattedAPN
WHERE a.FIPS in(13277) and a.REF_ID is null

UPDATE a
SET REF_ID = b.REF_ID
,a.FAPropertyID = Lic_PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = substring(b.ALTERNATE_APN,3,6) + LEFT(b.ALTERNATE_APN,2) + Substring(b.ALTERNATE_APN,9,50)
WHERE a.FIPS in(12093) and a.REF_ID is null

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and ASSESSOR_PARCEL_NUMBER = '000' + b.UnformattedAPN 
WHERE a.FIPS = 48439 and a.REF_ID is null

UPDATE a 
SET REF_ID = b.REF_ID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN [AZUVPSQLDTDB029.datatree.local].Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS
and a.ASSESSOR_PARCEL_NUMBER = b.TAX_CODE_AREA + b.Unformatted_APN
WHERE a.REF_ID is null and a.FIPS in(42003)

UPDATE a
SET a.FAPRopertyID = b.PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS
and Global.dbo.DeleteLeadZeros(Substring(Payee_Parcel_Number,5,3)) + '-' + Substring(Payee_Parcel_Number,8,1) + '-' + Global.dbo.DeleteLeadZeros(Substring(Payee_Parcel_Number,9,5)) = b.FormattedAPN
WHERE FAPropertyID is NULL and a.FIPS = 42003 and b.FIPS = '42003'



UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 7


/****************  SECTION 8  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 8,Getdate()



	Select FIPS,REF_ID,ORIGINAL_APN 
	INTO #NJApn
	FROM [zCust_ADS__00_SharedProcs].[dbo].[MandA_DTDB] with(NOLOCK) WHERE FIPS between 34000 and 34999

	CREATE NONCLUSTERED INDEX [Idx_fipsOrigAPN] ON #NJApn
	([Fips],[ORIGINAL_APN])

	UPDATE a 
	SET REF_ID = b.REF_ID
	FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN #NJApn b
	on a.FIPS = b.FIPS
	and LTRIM(RTRIM(Right(Assessor_Parcel_Number,2) + Left(Assessor_Parcel_Number,26))) = b.ORIGINAL_APN
	WHERE a.REF_ID is null and a.FIPS between 34000 and 34999

	DROP TABLE #NJApn

UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_PARCEL_NUMBER = b.TaxAccountNumber 
WHERE a.FAPropertyID is null


UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and Global.dbo.DeleteLeadZeros(a.Assessor_PARCEL_NUMBER) = b.TaxAccountNumber 
WHERE a.FAPropertyID is null and Assessor_PARCEL_NUMBER like '0%' and b.TaxAccountNumber is not null and b.TaxAccountNumber not like ''
and a.FIPS = '48055' 

UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.Assessor_PARCEL_NUMBER = b.FormattedAPN + '0'
WHERE a.FAPropertyID is null and Assessor_PARCEL_NUMBER like '0%' and b.TaxAccountNumber is not null and b.TaxAccountNumber not like ''
and a.FIPS = '48213' 

UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.Assessor_PARCEL_NUMBER = '00.' + REPLACE([FormattedAPN],'-','.') 
WHERE a.FAPropertyID is null and Assessor_PARCEL_NUMBER like '0%' and b.TaxAccountNumber is not null and b.TaxAccountNumber not like ''
and a.FIPS = '48339' 

-- UPDATE a 
--SET a.FAPropertyID = PropertyID
--FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN xmsmith.dbo.graysoncountyTX_II M
-- on a.Payee_Parcel_Number = M.Payee_Parcel_Number
-- where a.FIPS = 48181 and  a.FAPropertyID is null

 UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.PAYEE_PARCEL_NUMBER = [FormattedAPN] + '-0-000000'
WHERE a.FIPS = 48199  and a.FAPropertyID is null and Assessor_PARCEL_NUMBER like '0%' and b.TaxAccountNumber is not null and b.TaxAccountNumber not like ''

UPDATE a
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.PAYEE_PARCEL_NUMBER = LEFT(Global.dbo.StripNonNumerics([FormattedAPN]),3) + '-' + SUBSTRING(Global.dbo.StripNonNumerics([FormattedAPN]),4,3) + '-' + SUBSTRING(Global.dbo.StripNonNumerics([FormattedAPN]),7,3) + '-' + SUBSTRING(Global.dbo.StripNonNumerics([FormattedAPN]),10,3)
WHERE a.FIPS = 23005  and a.FAPropertyID is null

--UPDATE a 
--SET a.FAPropertyID = PropertyID
--FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN xmsmith.dbo.graysoncountyTX_II M
-- on a.Payee_Parcel_Number = M.Payee_Parcel_Number
-- where a.FIPS = 48181 and  a.FAPropertyID is null

 UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.PAYEE_PARCEL_NUMBER = [FormattedAPN] + '-0-000000'
WHERE a.FAPropertyID is null 
and a.FIPS = '48199' 



UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 8


/****************  SECTION 9  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 9,Getdate()



 UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.Assessor_Parcel_Number = Substring([FormattedAPN],2,20)
WHERE a.FAPropertyID is null 
and a.FIPS = '48121' 

--UPDATE a 
--SET a.FAPropertyID = PropertyID
--FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
--on a.FIPS = b.FIPS 
--and a.Assessor_Parcel_Number = REPLACE([FormattedAPN],'-',' ')
--WHERE a.FAPropertyID is null 

UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and SubString(REPLACE([FormattedAPN],'-',' '),4,25) =  a.Assessor_Parcel_Number
WHERE a.FIPS = '26163' and b.FIPS = '26163' and a.FAPropertyID is null 

UPDATE a 
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS
and left(taxAccountNumber,1) + '00' + Substring(taxAccountNumber,2,10) = Assessor_Parcel_Number
WHERE a.FIPS = '35061' and b.FIPS = '35061' and a.FAPropertyID is null 


update a
SET a.FAPropertyID = PropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and Global.dbo.DeleteLeadZeros([FormattedAPN]) =  replace(a.Assessor_Parcel_Number,'R','')
WHERE a.FIPS = '05051' and b.FIPS = '05051' and a.FAPropertyID is null 

------------------------------------------------------------------------------------------------------------


UPDATE b
SET  b.REF_ID = CASE WHEN a.REF_ID is NULL THEN b.REF_ID ELSE a.REF_ID END
,b.FAPropertyID = a.FAPropertyID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.dbo.Licensing_Deliverable b
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = b.Assessor_Parcel_Number
WHERE b.FAPropertyID is NULL and a.FAPropertyID is not null

UPDATE b
SET  b.FAPropertyID = CASE WHEN a.FAPropertyID is NULL THEN b.FAPropertyID ELSE a.FAPropertyID END
,b.REF_ID = a.REF_ID
FROM DBS_Tax_Lic.dbo.Matching_Work_II a JOIN DBS_Tax_Lic.dbo.Licensing_Deliverable b
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = b.Assessor_Parcel_Number
WHERE b.REF_ID is NULL and a.REF_ID is not null

UPDATE a 
SET FAPropertyID = LIC_PropertyID
from DBS_Tax_Lic.dbo.Licensing_Deliverable a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.REF_ID = b.REF_ID
WHERE a.FAPropertyID is NULL and a.REF_ID is not null and b.LIC_PropertyID is not null

UPDATE a 
SET a.REF_ID = b.REF_ID
from DBS_Tax_Lic.dbo.Licensing_Deliverable a JOIN Assr.dbo.Assr b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.FAPropertyID = b.LIC_PropertyID
WHERE a.REF_ID is NULL and a.FAPropertyID is not null and b.LIC_PropertyID is not null

UPDATE a
SET Lic_APN = b.FormattedAPN
FROM DBS_Tax_Lic.dbo.Licensing_Deliverable a JOIN DBS_Tax_Lic.[dbo].[Matching_WORK_APNS] b with(NOLOCK)
on a.FIPS = b.FIPS 
and a.FAPropertyID = b.PropertyID
WHERE a.LIC_APN is NULL

--UPDATE a 
--SET REF_ID = b.DTDB_Ref_ID
--,a.FAPropertyID = PropertyID
--,a.Lic_APN = b.FormattedAPN
--,a.UPDATED = convert(varchar(10),Getdate(),120)
--from dbo.Licensing_Deliverable a JOIN 
--(Select FIPS, PropertyID, FormattedAPN,DTDB_UNFORMATTED_APN,DTDB_Ref_ID 
--,CASE WHEN LEN(replace(replace(FormattedAPN,'-',''),' ','0'))=13 THEN replace(replace(FormattedAPN,'-',''),' ','0') + '0' ELSE replace(replace(FormattedAPN,'-',''),' ','0') END APN
--FROM data.dbo.Property with(NOLOCK) WHERE FIPS = '47157') b
--on a.Lic_FIPS = b.FIPS
--and a.ASSESSOR_PARCEL_NUMBER = APN
--WHERE a.Lic_FIPS = '47157'
--and FAPropertyID is NULL

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
,a.Lic_APN = b.FormattedAPN
,a.UPDATED = convert(varchar(10),Getdate(),120)
from dbo.Licensing_Deliverable a JOIN data.dbo.Property b with(NOLOCK)
on a.Lic_FIPS = b.FIPS
and a.ASSESSOR_PARCEL_NUMBER = DTDB_UNFORMATTED_APN
WHERE a.Lic_FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and b.FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and FAPropertyID is NULL

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
,a.Lic_APN = b.FormattedAPN
,a.UPDATED = convert(varchar(10),Getdate(),120)
from dbo.Licensing_Deliverable a JOIN data.dbo.Property b with(NOLOCK)
on a.Lic_FIPS = b.FIPS
and a.ASSESSOR_PARCEL_NUMBER = Substring(DTDB_FORMATTED_APN,4,25)
WHERE a.Lic_FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and b.FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and FAPropertyID is NULL

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
,a.Lic_APN = b.FormattedAPN
,a.UPDATED = convert(varchar(10),Getdate(),120)
from dbo.Licensing_Deliverable a JOIN data.dbo.Property b with(NOLOCK)
on a.Lic_FIPS = b.FIPS
and a.ASSESSOR_PARCEL_NUMBER = Substring(DTDB_FORMATTED_APN,4,25) + ' 000'
WHERE a.Lic_FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and b.FIPS in('47019','47115','47119','47139','47157','47159','47187','47189') 
and FAPropertyID is NULL

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
,a.UPDATED = convert(varchar(10),Getdate(),120)
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and a.Assessor_Parcel_Number = substring(b.UnformattedAPN,2,9)
WHERE a.FIPS = 08069 and b.FIPS = '08069' and a.REF_ID is null

UPDATE a 
SET REF_ID = b.DTDB_Ref_ID
,a.FAPropertyID = PropertyID
,a.UPDATED = convert(varchar(10),Getdate(),120)
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
on a.FIPS = b.FIPS
and b.FormattedAPN = Left(ASSESSOR_PARCEL_NUMBER,1) + Right(ASSESSOR_PARCEL_NUMBER,6)
WHERE a.FIPS = 08077 and b.FIPS = '08077' and a.REF_ID is null

UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
	ON a.Lic_FIPS = b.FIPS
		AND Global.dbo.DeleteLeadZeros(a.ASSESSOR_PARCEL_NUMBER) = b.OldAPN
WHERE LIC_FIPS = '53029' and a.REF_ID is NULL

UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
	ON a.Lic_FIPS = b.FIPS
		AND a.ASSESSOR_PARCEL_NUMBER = b.OldAPN
WHERE LIC_FIPS = '30111' and b.FIPS = '30111' and a.REF_ID is NULL

UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
	ON a.Lic_FIPS = b.FIPS
		AND LEFT(ASSESSOR_PARCEL_NUMBER,1) + RIGHT(ASSESSOR_PARCEL_NUMBER,7) = b.UnformattedAPN
WHERE LIC_FIPS = '08013' and a.REF_ID is NULL


UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
	ON a.Lic_FIPS = b.FIPS
		AND Global.dbo.DeleteLeadZeros(a.ASSESSOR_PARCEL_NUMBER) = b.FormattedAPN
WHERE LIC_FIPS = '41009' and a.REF_ID is NULL

UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
from Dbs_Tax_Lic.dbo.Licensing_Deliverable a JOIN data.dbo.Property b with(NOLOCK)
on ASSESSOR_PARCEL_NUMBER = replace(Substring(TaxAccountNumber,2,15),'-','')
where Lic_FIPS = '12123' and b.FiPS = '12123'
and a.FAPropertyID is NULL

UPDATE a
SET a.Lic_APN = DTDB_FORMATTED_APN
	,FAPropertyID = PropertyID
	,REF_ID = DTDB_REF_ID
FROM dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
	ON a.Lic_FIPS = b.FIPS
		AND SUBSTRING(ASSESSOR_PARCEL_NUMBER,4,25) = b.UnformattedAPN
WHERE LIC_FIPS = '55025' and a.REF_ID is NULL


UPDATE a
SET a.FAPropertyID = b.PropertyID
,a.REF_ID = b.DTDB_Ref_ID
,a.Lic_APN = b.FormattedAPN
,a.UPdated = GETDATE()
from Dbs_Tax_Lic.dbo.Licensing_Deliverable a JOIN Data.dbo.Property b with(NOLOCK)
ON PAYEE_PARCEL_NUMBER = RIGHT('0000000' + OldAPN,7)
where Lic_FIPS = '40125' and b.FIPS = '40125'
and FAPropertyID is NULL
and isNULL(OldAPN,'') not like ''


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 9


/****************  SECTION 10  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 10,Getdate()


UPDATE a
Set TOTAL_BASE_TAX_AMOUNT = BASE_TAX_AMOUNT_1+BASE_TAX_AMOUNT_2
,TOTAL_NET_TAX_AMOUNT_DUE = NET_TAX_AMOUNT_DUE_1+NET_TAX_AMOUNT_DUE_2
 from DBS_Tax_Lic.dbo.Licensing_Deliverable a
 WHERE (isNULL(BASE_TAX_AMOUNT_1,0)> 0)
 and (isNULL(BASE_TAX_AMOUNT_2,0)> 0)
 and TOTAL_BASE_TAX_AMOUNT is NULL
 and FREQUENCY_SDESC like 'Semi-Annual'

UPDATE a
Set TOTAL_BASE_TAX_AMOUNT = BASE_TAX_AMOUNT_1*2
,TOTAL_NET_TAX_AMOUNT_DUE = NET_TAX_AMOUNT_DUE_1*2
 from DBS_Tax_Lic.dbo.Licensing_Deliverable a
 WHERE (isNULL(BASE_TAX_AMOUNT_1,0)> 0)
 and (isNULL(BASE_TAX_AMOUNT_2,0)= 0)
 and TOTAL_BASE_TAX_AMOUNT is NULL
 and FREQUENCY_SDESC like 'Semi-Annual'

UPDATE a
Set TOTAL_BASE_TAX_AMOUNT = BASE_TAX_AMOUNT_1+BASE_TAX_AMOUNT_2+BASE_TAX_AMOUNT_3+BASE_TAX_AMOUNT_4
,TOTAL_NET_TAX_AMOUNT_DUE = NET_TAX_AMOUNT_DUE_1+NET_TAX_AMOUNT_DUE_2+NET_TAX_AMOUNT_DUE_3+NET_TAX_AMOUNT_DUE_4
 from DBS_Tax_Lic.dbo.Licensing_Deliverable a
 WHERE (isNULL(BASE_TAX_AMOUNT_1,0)> 0 and isNULL(BASE_TAX_AMOUNT_1,0)<9999999)
 and (isNULL(BASE_TAX_AMOUNT_2,0)> 0 and isNULL(BASE_TAX_AMOUNT_2,0)<9999999)
 and (isNULL(BASE_TAX_AMOUNT_3,0)> 0 and isNULL(BASE_TAX_AMOUNT_3,0)<9999999)
 and (isNULL(BASE_TAX_AMOUNT_4,0)> 0 and isNULL(BASE_TAX_AMOUNT_4,0)<9999999)
 and TOTAL_BASE_TAX_AMOUNT is NULL
 and FREQUENCY_SDESC like 'Quarterly'

UPDATE a
Set TOTAL_BASE_TAX_AMOUNT = BASE_TAX_AMOUNT_1+BASE_TAX_AMOUNT_2+BASE_TAX_AMOUNT_3
,TOTAL_NET_TAX_AMOUNT_DUE = NET_TAX_AMOUNT_DUE_1+NET_TAX_AMOUNT_DUE_2+NET_TAX_AMOUNT_DUE_3
 from DBS_Tax_Lic.dbo.Licensing_Deliverable a
WHERE (isNULL(BASE_TAX_AMOUNT_1,0)> 0)
 and (isNULL(BASE_TAX_AMOUNT_2,0)> 0)
 and (isNULL(BASE_TAX_AMOUNT_3,0)> 0)
 and TOTAL_BASE_TAX_AMOUNT is NULL
 and FREQUENCY_SDESC like 'Tri-Annual'

UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 10


/****************  SECTION 11  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 11,Getdate()




	---- RESET Current Record

		Select distinct FIPS as FIPSCODE INTO #FIPStoUse 
		from DBS_Tax_Lic.dbo.licensing_Deliverable with(NOLOCK) 
		--WHERE Lic_FIPS in('32510') 
		WHERE Updated >= (Select * from dbo.MaxUpdated)

		Create index [ix_fips] ON #FIPStoUse(FIPSCODE)

		UPDATE a
		SET CurrentRecord = NULL
		FROM DBS_Tax_Lic.dbo.licensing_Deliverable a JOIN #FIPStoUse b on a.FIPS = b.FIPSCODE

		Drop table DBS_Tax_Lic.dbo.CurrentRecord

		Select FIPS,FAPropertyID,Max(Tax_Year_Begin) MaxYr
		INTO DBS_Tax_Lic.dbo.CurrentRecord
		From DBS_Tax_Lic.dbo.Licensing_Deliverable a JOIN #FIPStoUse b on a.FIPS = b.FIPSCODE
		Group by FIPS,FAPropertyID

		CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsPropIDMaxYr] ON DBS_Tax_Lic.dbo.[CurrentRecord]
		([FIPS] ASC,	[FAPropertyID] ASC,	[MaxYr] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		UPDATE a
		SET CurrentRecord = 'Y'
		FROM DBS_Tax_Lic.dbo.licensing_Deliverable a JOIN DBS_Tax_Lic.dbo.CurrentRecord b
		on a.fips = b.fips
		and a.FAPropertyID = b.FAPropertyID
		and a.Tax_Year_Begin = b.MaxYr

		DROP TABLE IF EXISTS #FIPStoUse

	----- Refresh Indexes

		DROP INDEX [ix_LicFIPS_PropID] ON [dbo].[Licensing_Deliverable]
		DROP INDEX [ix_LicFips_PropID_Incl_Current] ON [dbo].[Licensing_Deliverable]
		DROP INDEX [ix_Updated] ON [dbo].[Licensing_Deliverable]


		CREATE NONCLUSTERED INDEX [ix_LicFIPS_PropID] ON [dbo].[Licensing_Deliverable]
		([FAPropertyID] ASC,[Lic_FIPS] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		CREATE NONCLUSTERED INDEX [ix_Updated] ON [dbo].[Licensing_Deliverable]
		([UPDATED] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		CREATE NONCLUSTERED INDEX [ix_LicFips_PropID_Incl_Current] ON [dbo].[Licensing_Deliverable]
		([FAPropertyID] ASC,[Lic_APN] ASC
		)
		INCLUDE ( 	[CurrentRecord]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		----- ADDED 20190105 to update Delinquency Tax data with previously Matched Licensing Deliverable Data

		UPDATE [DBS_TAX_LIC].[dbo].[Delinquency_Tax] 
		SET  Lic_FIPS = Right('0' + convert(varchar(5),FIPS),5)
		WHERE isNULL(Lic_FIPS,'') like ''

		UPDATE a
		SET a.Lic_APN = b.Lic_APN
		,a.REF_ID = b.REF_ID
		,a.FAPropertyID = b.FAPropertyID
		  FROM [DBS_TAX_LIC].[dbo].[Delinquency_Tax] a JOIN [DBS_TAX_LIC].[dbo].[Licensing_Deliverable] b with(NOLOCK)
			on a.Fips = b.Fips
				and a.Payee_Parcel_Number = b.Payee_Parcel_Number
		WHERE a.FAPropertyID is null
		and b.FAPropertyID is not null


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 11


/****************  SECTION 12  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 12,Getdate()


	----- Added dup check logic 20190225

		DROP INDEX [ix_LicFips_PropID_Incl_Current] ON [dbo].[Licensing_Deliverable]

		CREATE NONCLUSTERED INDEX [ix_LicFips_PropID_Incl_Current] ON [dbo].[Licensing_Deliverable]
		([Lic_FIPS] ASC,[FAPropertyID] ASC)
		INCLUDE([CurrentRecord]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


		IF Exists(Select [Lic_FIPS],FAPropertyID,COUNT(*) as DupCnt
				FrOM [DBS_Tax_LIC].[dbo].[Licensing_Deliverable] with(NOLOCK)
				WHERE FAPropertyID is not NULL and CurrentRecord = 'Y'
				GROUP BY [Lic_FIPS],FAPropertyID 
				HAVING COUNT(*) > 1)

			BEGIN
				UPDATE a
				SET FAPropertyID = NULL
				--,REF_ID = NULL
				,LIC_APN = NULL
				FROM [DBS_Tax_LIC].[dbo].[Licensing_Deliverable] a  JOIN (Select [Lic_FIPS],FAPropertyID,Min(CREATED) as MinDt,COUNT(*) as DupCnt
				FrOM [DBS_Tax_LIC].[dbo].[Licensing_Deliverable] with(NOLOCK)
				WHERE FAPropertyID is not NULL and CurrentRecord = 'Y'
				GROUP BY [Lic_FIPS],FAPropertyID 
				HAVING COUNT(*) > 1) b
				on a.[Lic_FIPS] = b.[Lic_FIPS]
				and a.FAPropertyID = b.FAPropertyID
				and a.CREATED = b.MinDt

			END 

		DECLARE @FipsCode varchar(5)

		DECLARE SetAsOfDt CURSOR FOR  
			SELECT distinct [FIPS] 
			FROM dbo.Delinquency_Tax
				WHERE [CREATED] > GetDate()-1
					or [UPDATED] > GetDate()-1
			ORDER BY [FIPS]


		OPEN SetAsOfDt   
		FETCH NEXT FROM SetAsOfDt INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC('update a
				SET Source_As_Of_Date = b.Source_As_Of_Date
				from dbo.Licensing_Deliverable a JOIN (Select Fips, Payee_parcel_Number,MAX(Source_As_Of_Date) as Source_As_Of_Date FROM Delinquency_Tax WHERE Fips = ' + @FipsCode + ' Group by Fips,Payee_Parcel_Number) b
				on a.FIPS = b.Fips
				and a.PAYEE_PARCEL_NUMBER = b.Payee_Parcel_Number
				where a.Fips = ' + @FipsCode + '
					and a.[Source_As_Of_Date] is NULL 
						or a.[Source_As_Of_Date] <> b.[Source_As_Of_Date]
			')

			
			FETCH NEXT FROM SetAsOfDt INTO @FipsCode   
		END   

		CLOSE SetAsOfDt   
		DEALLOCATE SetAsOfDt 

	----- reset systemProperty table to isDBSTaxRunning = N 

		update [dbo].[Licensing_Deliverable]
		SET [BILL_NUMBER_1] = replace([BILL_NUMBER_1],'|',',')
		WHERE [BILL_NUMBER_1] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update [dbo].[Licensing_Deliverable]
		SET [BILL_NUMBER_2] = replace([BILL_NUMBER_2],'|',',')
		WHERE [BILL_NUMBER_2] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update [dbo].[Licensing_Deliverable]
		SET [BILL_NUMBER_3] = replace([BILL_NUMBER_3],'|',',')
		WHERE [BILL_NUMBER_1] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update [dbo].[Licensing_Deliverable]
		SET [BILL_NUMBER_1] = replace([BILL_NUMBER_1],'|',',')
		WHERE [BILL_NUMBER_1] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update [dbo].[Licensing_Deliverable]
		SET [Payee_Owner_of_Record] = replace([Payee_Owner_of_Record],'|',',')
		WHERE [Payee_Owner_of_Record] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update [dbo].[Licensing_Deliverable]
		SET [Payee_Owner_Property_Address] = replace([Payee_Owner_Property_Address],'|',',')
		WHERE [Payee_Owner_Property_Address] Like '%|%'
			AND ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)

		update Dbs_Tax_Lic.dbo.licensing_deliverable
		Set FAPropertyID = NULL
		,REF_ID = NULL
		,Lic_APN = NULL
		,UPDATED = GETDATE()
		WHERE FAPropertyID in(Select FAPropertyID 
		FROM Dbs_Tax_Lic.dbo.Licensing_Deliverable 
			WHERE ([CREATED] > GetDate()-1 or [UPDATED] > GetDate()-1)
		group by FAPropertyID Having Count(*) > 5)


		UPDATE [Jobs].[dbo].[SystemProperty] set Value = 'N', UpdateDate = Getdate() WHERE Name = 'IsDBSTaxRunning'



UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 12


				--DECLARE @2 varchar(255) = 'micsmith@firstam.com; jeschmeyer@firstam.com; klowe@firstam.com', 
				--@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				--@t_subject2 varchar(50) = 'DBSTAX update complete and Flag Set',
				--@t_body1 varchar(2000) = 'DBSTax update process is complete and jobs flag is set.'
				----@t_count2 varchar(25) = convert(varchar(25), (Select COUNT(*) from [FEMA].[dbo].[LicFlood_Batch]))

				--SET NOCOUNT ON;
				--DECLARE @t_getdate2 datetime = GETDATE()
				--SET @t_body1 = @t_body1 + ' : ' + cast(@t_getdate2 as varchar(20))

				--EXEC msdb.dbo.sp_send_dbmail
				--	-- @recipients = @t_recipients,
				--	@recipients = @2,
				--	@profile_name = @t_profile_name2,
				--	@subject = @t_subject2,
				--	@body = @t_body1



/****************  SECTION 13  *******************/
Insert into DBS_Tax_Lic.[dbo].sp_Tracking([Section],[Start])
Select 13,Getdate()



	----- Update Property with data

		EXEC DBS_Tax_Lic.dbo.Roll_DBS_Tax_To_Property


		TRUNCATE table DBS_Tax_Lic.dbo.CurrentRecord
		TRUNCATE table DBS_Tax_Lic.[dbo].[Matching_WORK_APNS]

		DROP TABLE IF EXISTS dbo.MaxUpdated
		Select convert(varchar(10),Max(Updated),120) MaxUpdt 
		INTO dbo.MaxUpdated
		from DBS_Tax_Lic.dbo.licensing_Deliverable with(NOLOCK)


UPDATE DBS_Tax_Lic.[dbo].[sp_Tracking]
SET [FINISH] = Getdate()
WHERE [Section] = 13



END


