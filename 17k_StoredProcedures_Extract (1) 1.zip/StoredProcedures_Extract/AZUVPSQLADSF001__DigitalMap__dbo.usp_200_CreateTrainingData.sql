SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_200_CreateTrainingData] 
AS
BEGIN
	SET NOCOUNT ON;

--/****** Object:  Table [dbo].[m_FA_DMTraining]    Script Date: 2/24/2016 8:00:31 AM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[m_FA_DMTraining](
--	[PropertyID] [bigint] NULL,
--	[TaxAccountNumber] [nvarchar](30) NULL,
--	[FormattedAPN] [nvarchar](45) NULL,
--	[FIPS] [varchar](5) NULL,
--	[PARCELAPN] [varchar](50) NULL,
--	[TaxAccountPattern] [varchar](500) NULL,
--	[FormattedApnPattern] [varchar](500) NULL
--) ON [PRIMARY]

--GO

--SET ANSI_PADDING OFF
--GO



Insert into [DigitalMap].[dbo].m_FA_DMTraining ([PropertyID]
      ,p.TaxAccountNumber 
	  ,p.FormattedAPN
      ,d.[FIPS]      
      ,[PARCELAPN]	  )
SELECT FAPropertyId
      ,p.TaxAccountNumber 
	  ,p.FormattedAPN
      ,d.[FIPS]      
      ,[PARCELAPN]	  
FROM [DigitalMap].[dbo].[FADigitalMap] d with(nolock) inner join Global.[dbo].Property_master p with(nolock) on d.Fips = p.Fips and d.PropertyID = p.FAPropertyId
where PARCELAPN <> ''

RAISERROR ('Done creating tables', 10, 1) WITH NOWAIT



END


