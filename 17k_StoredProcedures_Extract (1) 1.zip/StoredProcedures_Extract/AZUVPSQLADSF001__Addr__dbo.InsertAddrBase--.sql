SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE proc [dbo].[InsertAddrBase--] (@tableName varchar (20)) as
declare @stdTable varchar (20) = rtrim(@tableName) + '_std'
declare @sql varchar(max) = ''
set identity_insert [AddrBase].[dbo].[CL_Address_Base] on
set @sql = '
INSERT INTO [AddrBase].[dbo].[CL_Address_Base](
			addrid
           ,[FIPS]
           ,[REF_ID]
           ,[HOUSE_NBR]
           ,[HOUSE_NBR_#2]
           ,[HOUSE_NBR_SUFFIX]
           ,[DIRECTION]
           ,[STREET_NAME]
           ,[MODE]
           ,[QUADRANT]
           ,[UNIT_NBR]
           ,[CITY]
           ,[STATE]
           ,[ZIP_CODE]
           ,[CARRIER_CODE]
           ,[Address_Type]
           ,[HouseNumber]
           ,[STD_FIPS]
           ,[STD_StreetNumber]
           ,[STD_PreDirection]
           ,[STD_StreetName]
           ,[STD_Suffix]
           ,[STD_PostDirection]
           ,[STD_UnitType]
           ,[STD_Unit]
           ,[STD_City]
           ,[STD_State]
           ,[STD_Zip]
           ,[STD_Plus4]
           ,[STD_CarrierRoute]
           ,[CountyName]
           ,[DPBC]
           ,[PrivateMailbox]
           ,[Pmsa]
           ,[Msa]
           ,[ZipType]
           ,[Urbanization]
           ,[CongressionalDistrict]
           ,[CountryCode]
           ,[CityAbbreviation]
           ,[AddressTypeCode]
           ,[AddressTypeString]
           ,[DPVCount]
           ,[DPVFootnotes]
           ,[CMRA]
           ,[ELotNumber]
           ,[ELotOrder]
           ,[LACS]
           ,[LACSLinkIndicator]
           ,[EWSFlag]
           ,[RBDI]
           ,[SuiteLinkReturnCode]
           ,[DeliveryPointCheckDigit]
           ,[DeliveryPointCode]
           ,[CensusBlock]
           ,[CensusTract]
           ,[PlaceCode]
           ,[PlaceName]
           ,[CBSACode]
           ,[CBSALevel]
           ,[CBSATitle]
           ,[CBSADivisionCode]
           ,[CBSADivisionLevel]
           ,[CBSADivisionTitle]
           ,[Latitude]
           ,[Longitude]
           ,[Verified]
           ,[Geocoded]
           ,[AddressMatchResults]
           ,[GeoErrorCode]
           ,[GeoStatusCode]
           ,[STD_Flag]
           ,[updated_date]
           ,[created]
           ,[GeoCodeResults])

SELECT 
		a.AddrID
      ,a.FIPS
      ,a.REF_ID
      ,a.HOUSE_NBR
      ,a.HOUSE_NBR_#2
      ,a.HOUSE_NBR_SUFFIX
      ,a.DIRECTION
      ,a.STREET_NAME
      ,a.MODE
      ,a.QUADRANT
      ,a.UNIT_NBR
      ,a.CITY
      ,a.STATE
      ,a.ZIP_CODE
      ,a.CARRIER_CODE
      ,a.Address_Type
      ,a.HouseNumber
      ,b.FIPS
      ,b.StreetNumber
      ,b.PreDirection
      ,b.StreetName
      ,b.Suffix
      ,b.PostDirection
      ,b.UnitType
      ,b.Unit
      ,b.City
      ,b.State
      ,b.Zip
      ,b.Plus4
      ,b.CRRT
      ,b.CountyName
      ,''''
      ,b.PMB
      ,b.PMSA
      ,b.MSA
      ,b.ZipType
      ,b.Urbanization
      ,b.CongressionalDistrict
      ,b.CountryCode
      ,b.CityAbbreviation
      ,b.AddressTypeCode
      ,b.AddressTypeString
      ,b.DPV_Count
      ,b.DPV_Footnotes
      ,b.CMRA
      ,b.ELOT_Number
      ,b.ELOT_Order
      ,b.LACS
      ,b.LACS_LinkIndicator
      ,b.EWS_Flag
      ,b.RBDI
      ,b.SuiteLinkReturnCode
      ,b.DeliveryPointCheckDigit
      ,b.DeliveryPointCode
      ,b.CensusBlock
      ,b.CensusTract
      ,b.PlaceCode
      ,b.PlaceName
      ,b.CBSA_Code
      ,b.CBSA_Level
      ,b.CBSA_Title
      ,b.CBSA_DivisionCode
      ,b.CBSA_DivisionLevel
      ,b.CBSA_DivisionTitle
      ,b.Latitude
      ,b.Longitude
      ,b.Verified
      ,b.Geocoded
      ,b.AddressMatchResults
      ,b.GeoErrorCode
      ,b.GeoStatusCode  
      ,0
      ,a.updated_date
      ,a.created
      ,b.GeoCodeResults
  
  FROM Addr06.dbo.' + @tableName + ' a join Addr06.dbo.' + @stdTable + ' b
	on a.AddrID = b.ID
	'
exec (@sql)  
set identity_insert [AddrBase].[dbo].[CL_Address_Base] off



