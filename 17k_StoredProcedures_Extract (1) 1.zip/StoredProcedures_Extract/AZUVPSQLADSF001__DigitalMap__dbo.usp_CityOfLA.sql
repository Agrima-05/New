SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[usp_CityOfLA] 
AS
BEGIN

truncate table	[DigitalMap].[dbo].[ParcelBoundaryAll_HJ_06037]
insert into [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_06037]
select * from [DigitalMap].[dbo].[vParcelBoundaryAll_HJ] where Fips = '06037'

drop table 
	  [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_CitiOfLA]

SELECT [FADigitalMapMasterId]
      ,[PropertyID]
      ,[APN]
      ,[FIPS]
	  ,[Latitude]
      ,[Longitude]
      
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN]
      ,[FAGeoStatusCode]
      ,[LatLonGeometry]
      ,[DmDate]
      ,[MatchCode]
      ,[UpdateFlag]
      ,[RefId]
      ,[PRCLDMPID]
      ,[PROPDMPID]
      ,[ParcelGeometry4269]
      ,[ParcelPointGeometry4269]
      ,[Id]
      ,[FATimestamp]
      ,[GeomWKT]
      ,[UCIDFlag]
      ,[PointWKT]
	  into
	  -- drop table 
	  [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_CitiOfLA]
  FROM [DigitalMap].[dbo].[ParcelBoundaryAll_HJ_06037] s with(index([SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269]))
    inner join xGtrang.dbo.CityOfLa c on s.[ParcelGeometry4269].STIntersects(c.GEOM) = 1
	where s.PropertyId is not null

END
