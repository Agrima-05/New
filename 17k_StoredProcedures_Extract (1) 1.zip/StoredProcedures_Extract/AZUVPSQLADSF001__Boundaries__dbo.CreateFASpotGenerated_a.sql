SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[CreateFASpotGenerated_a] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;


drop table If Exists [Boundaries].[dbo].[Property_Compare_a]

EXEC('SELECT [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[UnformattedAPN]
	  ,CountyLandUseDescription
	  ,StdLandUseCode
      ,[SitusStdFullStreetAddress]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[LotSizeSqFt]
      ,[LotSizeAcres]
	  ,[FAEstLotSqFt]
	  ,[FALatitude]
	  ,[FALongitude]
      ,[TPLatitude]
      ,[TPLongitude]
      ,[FARooftopLatitude]
      ,[FARooftopLongitude]
	  ,DTDB_Ref_ID
      ,[DTDB_FORMATTED_APN]
      ,[DTDB_UNFORMATTED_APN]
      ,[SPOT_ID]
	  ,cast(cast([FARooftopLongitude] as decimal(20,6)) as varchar(20)) as FARTLong
	  ,cast(cast([FARooftopLatitude] as decimal(20,6)) as varchar(20)) as FARTLat
	  ,cast(cast([FALongitude] as decimal(20,6)) as varchar(20)) as FALong
	  ,cast(cast([FALatitude] as decimal(20,6)) as varchar(20)) as FALat
	  ,cast(cast([TPLongitude] as decimal(20,6)) as varchar(20)) as TPLong
	  ,cast(cast([TPLatitude] as decimal(20,6)) as varchar(20)) as TPLat
into [Boundaries].dbo.Property_Compare_a
  FROM [Data].[dbo].[Property] with (nolock)
  where fips = ''' + @fips + ''' and FAUCIDFlag <> ''D''  
  order by fips,propertyid
  ')

  alter table [Boundaries].[dbo].[Property_Compare_a]
  add [InRegrid] varchar(5),[InSPOT] varchar(5),[SPOTID_SpatialMatch] bigint, [SPOT_SpatialMatchCode] varchar(5), [SPOT_PROPERTYID] bigint, [UniqueGuid] varchar(max)

CREATE NONCLUSTERED INDEX [ix_FipsPropID] ON [Boundaries].[dbo].[Property_Compare_a]
([FIPS] ASC,[PropertyID] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)



  EXEC('update [Boundaries].[dbo].[Property_Compare_a]
  Set [InSPOT] = ''Y''
      ,SPOT_ID = r.FADigitalMapMasterId
	  ,UniqueGuid = r.[UniqueGuid]  
  from [Boundaries].[dbo].[Property_Compare_a] p
  join [Boundaries].[dbo].[FASpot_a] r
  on r.fips = p.fips
  and r.PropertyID = p.propertyid
  where r.fips = ''' + @fips + '''
  ')


  -----------  STEP 2


-----------------------------

Drop table if Exists [Boundaries].[dbo].[FASpot_PropertyCompare_a]

EXEC('SELECT [FADigitalMapMasterId]
      ,[PropertyID]
      ,[APN]
      ,[FIPS]
      ,[Longitude]
      ,[Latitude]
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN]
      ,[FAGeoStatusCode]
      ,[LatLonGeometry]
      ,[DmDate]
      ,[MatchCode]
      ,[UpdateFlag]
      ,[RefId]
      ,[PRCLDMPID]
      ,[PROPDMPID]
      ,[ParcelGeometry4269]
      ,[ParcelPointGeometry4269]
      ,[Id]
      ,[FATimestamp]
      ,[GeomWKT]
      ,[UCIDFlag]
      ,[PointWKT]
      ,[IsCondo]
      ,[InHJ]
      ,[InUpdate]
      ,[NumberofPolygons]
      ,[InDM]
      ,[LoadDate]
	  ,[UniqueGuid]
	  ,[CreatedDate]
	  ,[UpdatedDate]
	  ,[Area]
	  ,[SqFt]
	  ,[ParcelGeometry4269].MakeValid().STArea() as [STArea]
into [Boundaries].[dbo].[FASpot_PropertyCompare_a]
  FROM [Boundaries].[dbo].[FASpot_a]
  where fips = ''' + @fips + '''
  and GeoSource != ''Points''
  ')

  -------------------------------------

/****** Object:  Index [PK_Temp]    Script Date: 9/12/2023 5:33:47 PM ******/
ALTER TABLE [Boundaries].[dbo].[FASpot_PropertyCompare_a] ADD  CONSTRAINT [PK_Temp_a] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


-----------------------------------

--SET ARITHABORT ON
--SET CONCAT_NULL_YIELDS_NULL ON
--SET QUOTED_IDENTIFIER ON
--SET ANSI_NULLS ON
--SET ANSI_PADDING ON
--SET ANSI_WARNINGS ON
--SET NUMERIC_ROUNDABORT OFF

CREATE SPATIAL INDEX [SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269] ON [dbo].[FASpot_PropertyCompare_a]
([ParcelGeometry4269])USING  GEOMETRY_GRID 
WITH (BOUNDING_BOX =(-162, 18, -45, 66), GRIDS =(LEVEL_1 = HIGH,LEVEL_2 = HIGH,LEVEL_3 = HIGH,LEVEL_4 = HIGH), 
CELLS_PER_OBJECT = 8192, PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

-------------
CREATE NONCLUSTERED INDEX [xSPOTID] ON [Boundaries].[dbo].[FASpot_PropertyCompare_a]
([FIPS] ASC,[FADigitalMapMasterId] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

CREATE UNIQUE NONCLUSTERED INDEX [xPropID] ON [Boundaries].[dbo].[Property_Compare_a]
([PropertyID] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


CREATE NONCLUSTERED INDEX [xSTArea] ON [Boundaries].[dbo].[FASpot_PropertyCompare_a]
([STArea] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

CREATE NONCLUSTERED INDEX [xInSPOT] ON [Boundaries].[dbo].[Property_Compare_a]
([InSPOT] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

-------------

update h
Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
,[SPOT_SpatialMatchCode] = 'FART'
,[SPOT_PROPERTYID] = a.propertyID
,[UniqueGuid] = a.[UniqueGuid]
FROM [Boundaries].[dbo].[Property_Compare_a] h 
join [Boundaries].[dbo].[FASpot_PropertyCompare_a] a
on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT(' + h.FARTLong + ' ' + h.FARTLat + ')',4269)) = 1
where h.[InSPOT] is null 
	and h.[FARooftopLongitude] is not null 
		and [ParcelGeometry4269].MakeValid().STArea() > 0
 

update h
Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
,[SPOT_SpatialMatchCode] = 'FA'
,[SPOT_PROPERTYID] = a.propertyID
,[UniqueGuid] = a.[UniqueGuid]
FROM [Boundaries].[dbo].[Property_Compare_a] h 
join [Boundaries].[dbo].[FASpot_PropertyCompare_a] a
on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT(' + h.FALong + ' ' + h.FALat + ')',4269)) = 1
where h.[InSPOT] is null 
	and h.[FALongitude] is not null 
		and [ParcelGeometry4269].MakeValid().STArea() > 0 
			and [SPOTID_SpatialMatch] is null
 

---- Removed 20240610 due to Timeshare issues
--update h
--Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
--,[SPOT_SpatialMatchCode] = 'FATP'
--,[SPOT_PROPERTYID] = a.propertyID
--,[UniqueGuid] = a.[UniqueGuid]
--FROM [Boundaries].[dbo].[Property_Compare_a] h 
--join [Boundaries].[dbo].[FASpot_PropertyCompare_a] a
--on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT(' + h.TPLong + ' ' + h.TPLat + ')',4269)) = 1
--where h.[InSPOT] is null 
--	and h.[TPLongitude] is not null 
--		and [ParcelGeometry4269].MakeValid().STArea() > 0 
--			and [SPOTID_SpatialMatch] is null

 
 -----------
  EXEC('update p
  Set SPOT_ID = coalesce(c.[Spot_ID],[SPOTID_SpatialMatch])
  from data.dbo.property p
  join [Boundaries].[dbo].[Property_Compare_a] c
  on c.fips = p.fips
  and c.propertyid = p.propertyid
  where p.fips = ''' + @fips + '''
  ')
  ----------



		EXEC('DELETE FROM [Boundaries].[dbo].[FASpot_Generated_a]
		WHERE [FIPS] = ''' + @fips + '''
		')


  INSERT INTO [Boundaries].[dbo].[FASpot_Generated_a]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InUpdate]
           ,[NumberofPolygons]
           ,[InDM]
           ,[LoadDate]
		   ,[UniqueGuid]
	       ,[CreatedDate]
	       ,[UpdatedDate]
	       ,[Area]
	       ,[SqFt])

 Select     [FADigitalMapMasterId]
           ,p.[PropertyID]
           ,p.formattedAPN
           ,p.[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,p.[DTDB_Ref_ID]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,GetDate()  --[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InUpdate]
           ,[NumberofPolygons]
           ,[InDM]
           ,[LoadDate]
		   ,c.[UniqueGuid]
	       ,c.[CreatedDate]
	       ,c.[UpdatedDate]
	       ,c.[Area]
	       ,c.[SqFt]
From [Boundaries].[dbo].[FASpot_PropertyCompare_a] c
join [Boundaries].[dbo].[Property_Compare_a] p
on p.fips = c.fips
and p.SPOTID_SpatialMatch = c.[FADigitalMapMasterId]

---------
drop table If Exists [Boundaries].[dbo].[FASpot_DeletesFlag_a]

EXEC('SELECT s.fips, s.FADigitalMapMasterId
Into [Boundaries].[dbo].[FASpot_DeletesFlag_a]
  FROM [Boundaries].[dbo].[FASpot_Generated_a] g
  join [Boundaries].[dbo].[FASpot_PropertyCompare_a] s
  on s.fips = g.fips
  and s.[FADigitalMapMasterId] = g.[FADigitalMapMasterId]
  where g.fips = ''' + @Fips + ''' and s.propertyid is null
  ')

CREATE INDEX ix_FipsMastID on [Boundaries].[dbo].[FASpot_DeletesFlag_a](Fips,FADigitalMapMasterId)

  EXEC('update [Boundaries].[dbo].[FASpot_a]
  Set UCIDFlag = ''D''
  ,FATimestamp = GetDate()
  from [Boundaries].[dbo].[FASpot_a] s
  join [Boundaries].[dbo].[FASpot_DeletesFlag_a] d
  on d.fips = s.fips
  and d.FADigitalMapMasterId = s.FADigitalMapMasterId
  WHERE s.Fips = ''' + @Fips + '''
  ')


END

