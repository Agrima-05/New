SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE Proc [dbo].[UpdateTriggerFlag]  

(  

 @TriggerId int  

 , @Flag Char(1) = 'R'  

 , @ProcessingMachineName VARCHAR(256) = null 

)  

AS  

/*  

--Start Tesing  

Declare @TriggerId int, @Flag Char(1)  

Select @TriggerId = 1, @Flag = 'R'  

--End Testing  

*/  

Begin  

 SET NOCOUNT ON  

   

 Update AT  

  Set AT.Process_Flag = @Flag  

   , AT.LastUpdatedDateTime = GETDATE()  

   , AT.CompletedDateTime = CASE WHEN @Flag = 'C' THEN GETDATE() ELSE NULL END  

 From STDTrigger as AT  

 Where AT.TriggerID = @TriggerId  

End   


