SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankMortgageBorrowerInput](@tableName varchar(40)) -- @tableName = 'Mortgage_Borrower' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + '  
	[MortgageUniqueID] [bigint] NOT NULL,
	[BorrowerFullMailAddress] [varchar](116) NULL,
	[BorrowerMailHouseNbr] [varchar](30) NULL,
	[BorrowerMailLeftDirection] [varchar](2) NULL,
	[BorrowerMailStreetName] [varchar](60) NULL,
	[BorrowerMailRightDirection] [varchar](2) NULL,
	[BorrowerMailMode] [varchar](10) NULL,
	[BorrowerMailUnitNumber] [varchar](15) NULL,
	[BorrowerMailCity] [varchar](55) NULL,
	[BorrowerMailState] [varchar](2) NULL,
	[BorrowerMailZip5] [varchar](9) NULL,
	[BorrowerMailZip4] [varchar](4) NULL,
	[BorrowerMailUnitType] [varchar](20) NULL,
	[BorrowerMailCarrierCode] [varchar](4) NULL,
	[BorrowerMailDPVCount] [varchar](5) NULL,
	[BorrowerMailDPVFootnote] [varchar](4) NULL,
	[BorrowerMailLACS] [varchar](1) NULL,
	[BorrowerMailLACSLinkInd] [varchar](1) NULL,
	[BorrowerMailDPCheckDigit] [varchar](1) NULL,
	[BorrowerMailDPCheckCode] [varchar](2) NULL,
	[BorrowerMailCensusBlock] [varchar](4) NULL,
	[BorrowerMailCensusTract] [varchar](6) NULL,
	[BorrowerMailGeoCodeResults] [varchar](30) NULL,
	[BorrowerMailMatchCode] [varchar](30) NULL,
	[BorrowerMailGeoErrorCode] [varchar](1) NULL,
	[BorrowerMailGeoStatusCode] [varchar](1) NULL,
	[FIPS] [varchar](5) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT MortgageUniqueID as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([BorrowerFullMailAddress], '''') addressLine ,isnull(BorrowerMailCity, '''') as city  ,isnull(BorrowerMailState, '''') as state  ,
isnull(BorrowerMailZip5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY BorrowerMailZip5 desc'  

exec (@sql)  

