SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================

CREATE PROCEDURE [dbo].[d001_LoadDragonBatch_Updates_V2_Updated]
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)

		BEGIN
	
				DECLARE @2 varchar(255) = 'micsmith@firstam.com; jeschmeyer@firstam.com; klowe@firstam.com', 
				@t_profile_name2 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject2 varchar(50) = 'Dragon DTDB Update Assr Load Started',
				@t_body2 varchar(2000) = 'The Dragon update From DTDB assr has started running.'


				SET NOCOUNT ON;
				DECLARE @t_getdate2 datetime = GETDATE()
				SET @t_body2 = @t_body2 + ' : ' + cast(@t_getdate2 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					-- @recipients = @t_recipients,
					@recipients = @2,
					@profile_name = @t_profile_name2,
					@subject = @t_subject2,
					@body = @t_body2
---------------------------------------------------------------------------------------------------------------------
		TRUNCATE TABLE DragonProcessingTracker

		INSERT INTO DragonProcessingTracker
		Select 'STEP 1 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		DELETE FROM a
		FROM [dbo].[Dragon_Flank_Updates] a JOIN Data.dbo.Property b with(NOLOCK)
		on a.FIPS = convert(int,b.fips)
		and a.REF_ID = b.DTDB_Ref_ID
		Where cast(a.CREATED as Date) < cast(b.FADateReceived as Date)


		DROP TABLE if exists [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SELECT * INTO [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl_template]

			CREATE UNIQUE NONCLUSTERED INDEX [ix_FipsRefID] ON [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
			([FIPS] ASC,[REF_ID] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				
		Select Distinct FIPS 
		INTO #FIPS
		FROM (SELECT RIGHT([name],5) as FIPS FROM sys.tables with(NOLOCK) WHERE [name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]'
							Union All
						 Select RIGHT('0' + cast(FIPS as varchar),5) FIPS from dbo.Dragon_Flank_Refreshes with(NOLOCK) group by RIGHT('0' + cast(FIPS as varchar),5)) FIPS

			CREATE INDEX [ix_Fips] on #FIPS(FIPS)

		SELECT top 1 * INTO #ASSR FROM [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] x with(NOLOCK) 

		CREATE UNIQUE INDEX ix_REFID on #ASSR(REF_ID)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		TRUNCATE TABLE #ASSR

		INSERT INTO #ASSR
		Select x.* 
		FROM [AZUVPSQLDTDB029.datatree.local].[Assr].[dbo].[Assr] x with(NOLOCK) 
				JOIN Global.dbo.County g on x.Fips = g.fipscodenum
				WHERE Fips not in(Select FIPS FROM #FIPS) and source_Type = 'G' 
				and ((UPDATED > GETDate()-3 or CREATED > GetDate()-3)
					OR (REF_ID in(Select REF_ID FROM [dbo].[Dragon_Flank_Updates] WHERE REF_ID is NOT NULL)))



			CREATE INDEX [ix_FipsRefID] on #ASSR(FIPS,REF_ID)

		DROP TABLE if exists [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl_TEMP]

			SELECT a.*,0 as MatchCode,RIGHT('0' + cast(a.FIPS as varchar),5) as FipsCode,b.PropertyID as PropertyID
			INTO [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl_TEMP]
			  From #ASSR a
				join [Data].[dbo].[Property] as b with(NOLOCK) 
					ON a.Fips = cast(b.fips as int)	 and a.REF_ID = b.DTDB_REF_ID
				WHERE (UPDATED > FADateReceived or CREATED > FADateReceived)
				and a.FIPS not in(Select FIPS from #FIPS)

		Drop table #FIPS
		Drop table #ASSR


		INSERT INTO [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SELECT * FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl_TEMP]


		INSERT INTO DragonProcessingTracker
		Select 'STEP 1 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 


				Truncate table [dbo].[Dragon_Flank_Updates]
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[002_remove_Extra_Ascii_from_table] 'Dragon_Flank_Batch_ASSR_UpdtTbl'

	----- CLEAN LEAD ZEROS
		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET SITUS_HOUSE_NBR = Global.dbo.DeleteLeadZeros(SITUS_HOUSE_NBR)
		WHERE SITUS_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET SITUS_STREET_NAME = Global.dbo.DeleteLeadZeros(SITUS_STREET_NAME)
		WHERE SITUS_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET SITUS_UNIT_NBR = Global.dbo.DeleteLeadZeros(SITUS_UNIT_NBR)
		WHERE SITUS_UNIT_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET MAIL_HOUSE_NBR = Global.dbo.DeleteLeadZeros(MAIL_HOUSE_NBR)
		WHERE MAIL_HOUSE_NBR like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET MAIL_STREET_NAME = Global.dbo.DeleteLeadZeros(MAIL_STREET_NAME)
		WHERE MAIL_STREET_NAME like '00%'

		UPDATE dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET MAIL_UNIT_NBR = Global.dbo.DeleteLeadZeros(MAIL_UNIT_NBR)
		WHERE MAIL_UNIT_NBR like '00%'

		INSERT INTO DragonProcessingTracker
		Select 'STEP 2 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

	----- FILL IN FIPSCODE AND PROPERTYID

		UPDATE a
		SET Fipscode = RIGHT('0' + convert(varchar(5),FIPS),5)
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a
		WHERE isNULL(Fipscode,'') like ''

		UPDATE a
		SET PropertyID = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	

		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.FipsCode = b.fips
		and a.REF_ID = b.DTDB_Ref_ID
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET a.[PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.UnformattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.FormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.UnFormattedAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[FORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET [PropertyID] = b.PropertyID
		FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN [Data].dbo.[Property] b with(NOLOCK)
		on a.Fips = b.fips
		and a.[UNFORMATTED_APN] = b.OLDAPN
		WHERE isNULL(a.PropertyID,0) = 0 
	
		UPDATE a
		SET PropertyID = b.PropertyID
		FROM dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN Data.dbo.Property b with(NOLOCK)
		ON a.FIPSCODE = b.FIPS
		and a.[UNFORMATTED_APN] = b.TaxAccountNumber
		WHERE isNULL(a.PropertyID,0) = 0 

		update dbo.[Dragon_Flank_Batch_ASSR_UpdtTbl]
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR] with(NOLOCK)
		WHERE PropertyID is not null
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)



		--DROP TABLE dbo.Dragon_CertDates


		--SELECT Fipscode,convert(DATE,Max(CASE WHEN isNULL(TAX_YEAR,'') like '' THEN ASSESSED_YEAR ELSE TAX_YEAR END ) + '0101') as CERTIFICATION_DATE
		--INTO dbo.Dragon_CertDates
		--  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
		--  WHERE isNULL(TAX_YEAR,'') NOT like '' or isNULL(ASSESSED_YEAR,'') NOT like ''
		--  GROUP BY Fipscode
		--  ORDER BY Fipscode
  	

		update dbo.Dragon_Flank_Batch_ASSR_UpdtTbl
		SET PropertyID = NULL
		WHERE PropertyID in(Select PropertyID from [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] with(NOLOCK)
		WHERE isNULL(PropertyID,0) <> 0
		GROUP BY PropertyID
		HAVING COUNT(*) > 1)

		DROP TABLE If Exists dbo.DragonAssrCounts

		DECLARE @CertDt Varchar(8) = Convert(varchar(8),GETDATE()-90,112)
		
		EXEC('Select x.FIPSCode,x.RecCount,x.RecordsInTaxroll,x.CERTIFICATION_DATE,CASE WHEN x.RecCount between x.RecordsInTaxroll -(x.RecordsinTaxroll * .10) and x.RecordsInTaxroll +(x.RecordsinTaxroll * .10) THEN ''REFRESH'' ELSE ''UPDATE'' END as RefreshUpdate
		INTO dbo.DragonAssrCounts
		FROM(
			SELECT a.FipsCode,COUNT(*) as RecCount,RecordsinTaxroll,'''+@CertDt+''' as CERTIFICATION_DATE
			FROM [dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl] a JOIN Global.dbo.County b
			on a.FipsCode = b.FIPSCode
			GROUP BY a.FipsCode,RecordsinTaxroll
			) X
			ORDER BY x.FipsCode
		')

		INSERT INTO DragonProcessingTracker
		Select 'STEP 3 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Start' as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d005_DragonAssrLoad_UpdateTbl_Looper]

		INSERT INTO DragonProcessingTracker
		Select 'STEP 4 Finish' as ProcessingStep,GETDATE() as ProcessingStartTime 
---------------------------------------------------------------------------------------------------------------------

		--Truncate Table dbo.Dragon_Update_Tracker

		UPDATE a
		SET [MaxCreated] = b.MaxCreated
		,[MaxUpdated] = b.MaxUpdated
		,[DateLastUpdate] = GETDATE()
		FROM dbo.Dragon_Update_Tracker a JOIN (
		SELECT [FIPS],Max([CREATED]) as MaxCreated,Max([UPDATED]) as MaxUpdated
		  FROM [DragonAssr].[dbo].[Dragon_Flank_Batch_ASSR_UpdtTbl]
		  GROUP BY FIPS
		  ) b
		ON a.FIPS = b.[FIPS]

		IF(Select Count(*) from (Select PropertyID from [DragonAssr].[dbo].[PropertyWorkUpdateTbl] group by propertyid having count(*) > 1) info) > 0
		BEGIN

			DECLARE @4 varchar(355) = 'micsmith@firstam.com', 
			--DECLARE @4 varchar(355) = 'micsmith@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', 
				@t_profile_name4 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject4 varchar(50) = 'DUPLICATE IN DRAGON UPDATE',
				@t_body4 varchar(2000) = 'Duplicate in Dragon update table [DragonAssr].[dbo].[PropertyWorkUpdateTbl].  Remove the duplicate then run EXEC [dbo].[d700_Post_Dragon_To_Licensing_UpdateTbl].'

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @4,
					@profile_name = @t_profile_name4,
					@subject = @t_subject4,
					@body = @t_body4

			RETURN;
		END

		EXEC [dbo].[d700_Post_Dragon_To_Licensing_UpdateTbl]
		
		
		--DECLARE @PULLDT as varchar(8) = convert(varchar(8),GETDATE(),112)
		DECLARE @LoadDT as varchar(10) = convert(varchar(10),GETDATE()+1,120)
		DECLARE @DFB as varchar(50) = 'Dragon_Flank_Batch_ASSR_UpdtTbl_' + @PULLDT
		DECLARE @DAC as varchar(50) = 'DragonAssrCounts_' + @PULLDT

		EXEC sp_rename Dragon_Flank_Batch_ASSR_UpdtTbl,@DFB
		EXEC sp_rename DragonAssrCounts,@DAC

			--DECLARE @3 varchar(355) = 'micsmith@firstam.com', 
			DECLARE @3 varchar(355) = 'micsmith@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon DTDB Update Assr Load Finished',
				@t_body3 varchar(2000) = 'The Dragon update From DTDB assr has finished and is loaded into dbo.Property with FATimestamp = ' + @LoadDT

				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + '  Have a Great Day!'

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3

	END


END

