SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.ReleaseStateItemExclusive(
	@SessionId nvarchar(88) NOT NULL,
	@LockCookie int NOT NULL
) WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()

	UPDATE dbo.Sessions
	SET
		Expires = DATEADD(minute, Timeout, @Now),
		Locked = 0
	WHERE SessionId = @SessionId AND LockCookie = @LockCookie
END

