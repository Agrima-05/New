SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_100d_ASP_Property_Situs_to_Licensing_UPDATE]
AS
BEGIN
	UPDATE
		LIC
	SET
		LIC.[SitusStdFullStreetAddress] = UPPER(SL.[SitusStdFullStreetAddress]),
		LIC.[SitusStdHouseNbr] = SL.[SitusStdHouseNbr],
		LIC.[SitusStdDirectionLeft] = SL.[SitusStdDirectionLeft],
		LIC.[SitusStdStreet] = CASE WHEN SL.[SitusStdStreet] like '&%' THEN ltrim(rtrim(Substring(SL.[SitusStdStreet],2,Len(SL.[SitusStdStreet])))) ELSE SL.[SitusStdStreet] END,
		LIC.[SitusStdMode] = SL.[SitusStdMode],
		LIC.[SitusStdDirectionRight] = SL.[SitusStdDirectionRight],
		LIC.[SitusStdUnitNbr] = SL.[SitusStdUnitNbr],
		LIC.[SitusStdCity] = SL.[SitusStdCity],
		LIC.[SitusStdState] = SL.[SitusStdState],
		LIC.[SitusStdZIP5] = SL.[SitusStdZIP5],
		LIC.[SitusStdZIP4] = SL.[SitusStdZIP4],
		LIC.[SitusLatitude] = SL.[SitusLatitude],
		LIC.[SitusLongitude] = SL.[SitusLongitude],
		LIC.[SitusStdCarrierCode] = SL.[SitusStdCarrierCode],
		LIC.[SitusCensusTract] = SL.[SitusCensusTract],
		LIC.[SitusCensusTractBlock] = SL.[SitusCensusTractBlock],
		LIC.[SitusStdUnitType] = SL.[SitusStdUnitType],
		LIC.[SitusStdMatchCode] = SL.[SitusStdMatchCode],
		LIC.[SitusDPVCount] = SL.[SitusDPVCount],
		LIC.[SitusDPVFootnote] = SL.[SitusDPVFootnote],
		LIC.[SitusLACS] = SL.[SitusLACS],
		LIC.[SitusLACSLinkInd] = SL.[SitusLACSLinkInd],
		LIC.[SitusDPCheckDigit] = SL.[SitusDPCheckDigit],
		LIC.[SitusDPCheckCode] = SL.[SitusDPCheckCode],
		LIC.[SitusCensusBlock] = SL.[SitusCensusBlock],
		LIC.[SitusGeoErrorCode] = SL.[SitusGeoErrorCode],
		LIC.[SitusGeoStatusCode] = SL.[SitusGeoStatusCode],
		LIC.[SitusGeoCodeResults] = SL.[SitusGeoCodeResults],
		LIC.[FAAddressParsedSitus] = CURRENT_TIMESTAMP
	FROM
		[DragonAssr].[dbo].[PropertyWorkUpdate] LIC
	INNER JOIN
		[DragonAssr].[dbo].[a_ASP_IN_UPDATE_STD] SL
	ON 
		LIC.DTDB_Ref_ID = SL.[DTDB_REF_ID]


END

