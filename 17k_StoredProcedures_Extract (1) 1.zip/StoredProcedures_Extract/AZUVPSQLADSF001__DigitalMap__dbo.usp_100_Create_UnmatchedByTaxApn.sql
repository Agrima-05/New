SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[usp_100_Create_UnmatchedByTaxApn] 
AS
BEGIN
	SET NOCOUNT ON;

--DROP TABLE [dbo].[FADMNoMatched]

--/****** Object:  Table [dbo].[FADigitalMapParcelNoPoint]    Script Date: 2/23/2016 4:46:25 PM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[m_FADMNoMatched](
--	[PropertyID] [bigint] NULL,
--	[APN] [varchar](45) NULL,
--	[FIPS] [varchar](5) NULL,
--	[Latitude] [float] NULL,
--	[Longitude] [float] NULL,
--	[ParcelGeography] [geography] NULL,
--	[ParcelGeometry] [geometry] NULL,
--	[ParcelPointGeography] [geography] NULL,
--	[ParcelPointGeometry] [geometry] NULL,
--	[EstLotSizeSqFt] [bigint] NULL,
--	[AddressScore] [varchar](1) NULL,
--	[GeoSource] [varchar](30) NULL,
--	[PARCELAPN] [varchar](50) NULL,
--	[MatchedBy] [varchar](50) NULL,
--	[PARCELAPNMask] [varchar](50) NULL
--) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

--GO

INSERT INTO [dbo].[m_FADMNoMatched] 
	(
	  [PropertyID]
      ,[APN]
      ,[FIPS]
      ,[Latitude]
      ,[Longitude]
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN])
	Select [PropertyID]
      ,[APN]
      ,[FIPS]
      ,[Latitude]
      ,[Longitude]
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN]
	from FADigitalMap with(nolock) where PropertyId is null

END

