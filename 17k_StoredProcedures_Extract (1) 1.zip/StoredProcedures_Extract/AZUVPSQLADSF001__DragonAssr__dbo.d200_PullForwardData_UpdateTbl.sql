SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- Description:	Pull Forward Property INFO
-- =============================================
CREATE PROCEDURE [dbo].[d200_PullForwardData_UpdateTbl] 

AS
BEGIN

	SET NOCOUNT ON;

		--Print 'query1'
	BEGIN TRANSACTION

		UPDATE a
		SET a.[FAAddressParsedSitus] = b.[FAAddressParsedSitus]
		,a.[SitusCensusBlock] = b.[SitusCensusBlock]
		,a.[SitusCensusTract] = b.[SitusCensusTract]
		,a.[SitusCensusTractBlock] = b.[SitusCensusTractBlock]
		,a.[SitusDPCheckCode] = b.[SitusDPCheckCode]
		,a.[SitusDPCheckDigit] = b.[SitusDPCheckDigit]
		,a.[SitusDPVCount] = b.[SitusDPVCount]
		,a.[SitusDPVFootnote] = b.[SitusDPVFootnote]
		,a.[SitusGeoCodeResults] = b.[SitusGeoCodeResults]
		,a.[SitusGeoErrorCode] = b.[SitusGeoErrorCode]
		,a.[SitusGeoStatusCode] = b.[SitusGeoStatusCode]
		,a.[SitusLACS] = b.[SitusLACS]
		,a.[SitusLACSLinkInd] = b.[SitusLACSLinkInd]
		,a.[SitusLatitude] = b.[SitusLatitude]
		,a.[SitusLongitude] = b.[SitusLongitude]
		,a.[SitusStdCarrierCode] = b.[SitusStdCarrierCode]
		,a.[SitusStdCity] = CASE WHEN isNULL(b.[SitusStdCity],'') LIKE '' THEN a.[SitusStdCity] ELSE b.[SitusStdCity] END
		,a.[SitusStdDirectionLeft] = b.[SitusStdDirectionLeft]
		,a.[SitusStdDirectionRight] = b.[SitusStdDirectionRight]
		,a.[SitusStdFullStreetAddress] = b.[SitusStdFullStreetAddress]
		,a.[SitusStdHouseNbr] = b.[SitusStdHouseNbr]
		,a.[SitusStdHouseNbr2] = b.[SitusStdHouseNbr2]
		,a.[SitusStdHouseNbrSuffix] = b.[SitusStdHouseNbrSuffix]
		,a.[SitusStdMatchCode] = b.[SitusStdMatchCode]
		,a.[SitusStdMode] = b.[SitusStdMode]
		,a.[SitusStdState] = CASE WHEN isNULL(b.[SitusStdState],'') LIKE '' THEN a.[SitusStdState] ELSE b.[SitusStdState] END
		,a.[SitusStdStreet] = b.[SitusStdStreet]
		,a.[SitusStdUnitNbr] = b.[SitusStdUnitNbr]
		,a.[SitusStdUnitType] = b.[SitusStdUnitType]
		,a.[SitusStdZIP4] = CASE WHEN isNULL(b.[SitusStdZIP4],'') LIKE '' THEN a.[SitusStdZIP4] ELSE b.[SitusStdZIP4] END
		,a.[SitusStdZIP5] =  CASE WHEN isNULL(b.[SitusStdZIP5],'') LIKE '' THEN a.[SitusStdZIP5] ELSE b.[SitusStdZIP5] END
		FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
			and a.PropertyID = b.PropertyID
		WHERE ((isNULL(b.[SitusStdFullStreetAddress],'') not like '' and b.[SitusStdFullStreetAddress] = a.[SitusStdFullStreetAddress])
				OR (isNULL(b.[SitusStdFullStreetAddress],'') not like '' and isNULL(a.[SitusStdFullStreetAddress],'') like ''))
			AND isNULL(a.[SitusStdUnitNbr],'') like ''
		AND b.[SitusStdCarrierCode] NOT like ''
		AND a.[SitusStdZip5] = b.[SitusStdZIP5]



	COMMIT TRANSACTION 

		----Pull Forward  Mailing Standardized Address:
		--Print 'query2'

	BEGIN TRANSACTION

		UPDATE a
		SET a.[FAAddressParsedMailing] = b.[FAAddressParsedMailing]
		,a.[MailForeignAddrInd] = b.[MailForeignAddrInd]
		,a.[MailingCareOfName] = b.[MailingCareOfName]
		,a.[MailingCensusBlock] = b.[MailingCensusBlock]
		,a.[MailingCensusTract] = b.[MailingCensusTract]
		,a.[MailingDPCheckCode] = b.[MailingDPCheckCode]
		,a.[MailingDPCheckDigit] = b.[MailingDPCheckDigit]
		,a.[MailingDPVCount] = b.[MailingDPVCount]
		,a.[MailingDPVFootnote] = b.[MailingDPVFootnote]
		,a.[MailingGeoCodeResults] = b.[MailingGeoCodeResults]
		,a.[MailingGeoErrorCode] = b.[MailingGeoErrorCode]
		,a.[MailingGeoStatusCode] = b.[MailingGeoStatusCode]
		,a.[MailingLACS] = b.[MailingLACS]
		,a.[MailingLACSLinkInd] = b.[MailingLACSLinkInd]
		,a.[MailingOptOut] = b.[MailingOptOut]
		,a.[MailingOptOutDate] = b.[MailingOptOutDate]
		,a.[MailingStdCarrierCode] = b.[MailingStdCarrierCode]
		,a.[MailingStdCity] = b.[MailingStdCity]
		,a.[MailingStdDirectionLeft] = b.[MailingStdDirectionLeft]
		,a.[MailingStdDirectionRight] = b.[MailingStdDirectionRight]
		,a.[MailingStdFullStreetAddress] = b.[MailingStdFullStreetAddress]
		,a.[MailingStdHouseNbr] = b.[MailingStdHouseNbr]
		,a.[MailingStdHouseNbr2] = b.[MailingStdHouseNbr2]
		,a.[MailingStdHouseNbrSuffix] = b.[MailingStdHouseNbrSuffix]
		,a.[MailingStdMatchCode] = b.[MailingStdMatchCode]
		,a.[MailingStdMode] = b.[MailingStdMode]
		,a.[MailingStdState] = b.[MailingStdState]
		,a.[MailingStdStreet] = b.[MailingStdStreet]
		,a.[MailingStdUnitNbr] = b.[MailingStdUnitNbr]
		,a.[MailingStdUnitType] = b.[MailingStdUnitType]
		,a.[MailingStdZIP4] = b.[MailingStdZIP4]
		,a.[MailingStdZIP5] = b.[MailingStdZIP5]
		FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID
		WHERE isNULL(b.[MailingStdFullStreetAddress],'') not like '' 
			AND a.[MailingStdFullStreetAddress] = b.[MailingStdFullStreetAddress]
				AND isNULL(a.[MailingStdUnitNbr],'') like ''
		AND b.[MailingStdCarrierCode] NOT Like ''
		AND a.[MailingStdZIP5] = b.[MailingStdZIP5]


	COMMIT TRANSACTION 

		--Print 'query3'

		UPDATE [dbo].[PropertyWorkUpdateTbl] 
		SET [FAAddressParsedMailing] = GETDATE()
		where [FAAddressParsedMailing] is NULL
			and [MailingStdFullStreetAddress] is null and [MailingStdState] is null


	--COMMIT TRANSACTION 

		--Print 'query1'

	UPDATE a
	SET a.SchoolDistrictName = b.SchoolDistrictName
	,a.FALatitude = b.FALatitude
	,a.FALongitude = b.FALongitude
	,a.TPLatitude = b.TPLatitude
	,a.TPLongitude = b.TPLongitude
	,a.TPGeoStatusCode = b.TPGeoStatusCode
	--,a.SumCommercialUnits = b.SumCommercialUnits
	,a.FAGeoStatusCode = b.FAGeoStatusCode
	,a.FAEstLotSqFt  = b.FAEstLotSqFt
	,a.MailingOptOut = b.MailingOptOut 
	,a.MailingOptOutDate  = b.MailingOptOutDate 
	,a.AssessorLkupToken0 = b.AssessorLkupToken0
	,a.AssessorLkupToken1 = b.AssessorLkupToken1
	,a.AssessorLkupToken2 = b.AssessorLkupToken2
	,a.GarageFinishSqFt = b.GarageFinishSqFt 
	,a.GarageUnFinSqFt = b.GarageUnFinSqFt 
	,a.AtticSqFt = b.AtticSqFt
	,a.AtticFinishSqFt = b.AtticFinishSqFt
	,a.AtticUnfinSqFt = b.AtticUnfinSqFt
	,a.HouseFacingDirection = b.HouseFacingDirection -- GM added 20190226
	,a.FARooftopLatitude = b.FARooftopLatitude -- GM added 20190226
	,a.FARooftopLongitude = b.FARooftopLongitude -- GM added 20190226
	,a.BuildingEstFootprintSqFt = b.BuildingEstFootprintSqFt -- GM added 20190314
	,a.BathTotalCalcEst = b.BathTotalCalcEst -- GM added 20190415
	,a.DQOZ_TractType = b.DQOZ_TractType -- GM added 20190416
	,a.DQOZ_ACSDataSource = b.DQOZ_ACSDataSource -- GM added 20190416
	,a.VacantScore = b.VacantScore -- GM added 20190715
	,a.[LotUsableSize] = b.[LotUsableSize] -- MAS added 20190930
	,a.[BedroomsEst] = b.[BedroomsEst] -- GM added 20191001
	,a.FASubdivisionName = b.FASubdivisionName -- GM added 20200427
	,a.FAComplexNbrUnits = b.FAComplexNbrUnits -- GM added 20200427
	,a.SchoolTaxDistrict1Code = b.SchoolTaxDistrict1Code
	,a.SchoolTaxDistrict1Ind = b.SchoolTaxDistrict1Ind
	,a.FASubdivisionNameID = b.FASubdivisionNameID -- GM added 20201027
	,a.FASubdivisionPhase = b.FASubdivisionPhase -- GM added 20201113
	,a.ElevatorCode = b.ElevatorCode -- GM added 20201210
	,a.FAEstimatedMultiPolygonFlag = b.FAEstimatedMultiPolygonFlag -- GM added 20201210
	,a.FAEstimatedNumberofBuildings = b.FAEstimatedNumberofBuildings -- GM added 20201210
	,a.Poverty = b.Poverty -- GM added 20210303
	,a.UnEmployment = b.UnEmployment -- GM added 20210303
	,a.PopulationLoss = b.PopulationLoss -- GM added 20210303
	,a.RemoteRural = b.RemoteRural -- GM added 20210303
	,a.Distressed = b.Distressed -- GM added 20210303
	,a.UnderServed = b.UnderServed -- GM added 20210303
	,a.ConformingLoanLimitYear = b.ConformingLoanLimitYear -- GM added 20211119
	,a.ConformingLoanLimit = b.ConformingLoanLimit -- GM added 20211119
	,a.PriorConformingLoanLimitYear = b.PriorConformingLoanLimitYear -- GM added 20211119
	,a.PriorConformingLoanLimit = b.PriorConformingLoanLimit -- GM added 20211119
	,a.MTG1InterestRateSrce = b.MTG1InterestRateSrce -- GM added 20220607
	,a.MTG2InterestRateSrce = b.MTG2InterestRateSrce -- GM added 20220607
	,a.MTG3InterestRateSrce = b.MTG3InterestRateSrce -- GM added 20220607
	,a.MTG4InterestRateSrce = b.MTG4InterestRateSrce -- GM added 20220607
	,a.CS_FORMATTED_APN = b.CS_FORMATTED_APN -- GM added 20210718
	,a.CS_UNFORMATTED_APN = b.CS_UNFORMATTED_APN -- GM added 20210718
	,a.SPOT_ID = b.SPOT_ID
	FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID 

		--Print 'query4'


	UPDATE a
	SET a.[TaxRateCodeArea] = b.[TaxRateCodeArea]  
	FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID 
	WHERE a.[TaxRateCodeArea] is NULL and b.[TaxRateCodeArea] is NOT NULL
		--Print 'query5'

	----UPDATE a
	----SET a.[TaxDeliquentYear1] = b.[TaxDeliquentYear1]  
	----FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
	----	on a.FIPS = b.FIPS
	----	and a.PropertyID = b.PropertyID 
	----WHERE a.[TaxDeliquentYear1] is NULL and b.[TaxDeliquentYear1] is NOT NULL

	----	--Print 'query6'

	----UPDATE a
	----SET a.[TaxDeliquentValue1] = b.[TaxDeliquentValue1] 
	----FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
	----	on a.FIPS = b.FIPS
	----	and a.PropertyID = b.PropertyID 
	----WHERE a.[TaxDeliquentValue1] is NULL and b.[TaxDeliquentValue1] is NOT NULL

	----	--Print 'query7'

	UPDATE a
	SET a.[TaxExemptionCode] = b.[TaxExemptionCode] 
	,a.[TaxexemptInd] = 1
	FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		and a.PropertyID = b.PropertyID 
	WHERE isNULL(a.[TaxExemptionCode],'') like '' and isNULL(b.[TaxExemptionCode],'') not like ''

	
		--Print 'query8'

		UPDATE [dbo].[PropertyWorkUpdateTbl]  
		SET LotSizeAcres = RIGHT('0000000000' + Convert(varchar(10),convert(bigint,(Convert(Money,convert(bigint,LotSizeSqFt))/43560)*1000)),10)
		WHERE LotSizeAcres like '0000000000' and isNULL(LotSizeSqFt,0) > 0

		--Print 'query9'

		UPDATE [dbo].[PropertyWorkUpdateTbl] 
		SET LotSizeSqFt = convert(int,convert(Bigint,(Convert(Money,convert(Money,ltrim(rtrim(LotSizeAcres))))/1000)*43560))
		WHERE LotSizeAcres != '0000000000' and isNULL(ltrim(rtrim(LotSizeSqFt)),'') = ''
		and convert(Bigint,(Convert(Money,convert(Money,ltrim(rtrim(LotSizeAcres))))/1000)*43560) < 1000000000

		--Select LotSizeAcres,convert(bigint,LotSizeAcres)
		--from [dbo].[PropertyWorkUpdateTbl]
		--order by LotSizeAcres desc

		--Print 'query10'

            UPDATE p
            SET p.StoriesNbrCode = g.FACode
            from [dbo].[PropertyWorkUpdateTbl]  p JOIN [Global].dbo.lkup_StoriesCode g
            on p.[StoriesCode] = g.BKFSCode

  
		--Print 'query11'

			update [dbo].[PropertyWorkUpdateTbl] 
			SET  [SitusStdFullStreetAddress] = NULL
				  ,[SitusStdHouseNbr] = NULL
				  ,[SitusStdHouseNbr2] = NULL
				  ,[SitusStdHouseNbrSuffix] = NULL
				  ,[SitusStdDirectionLeft] = NULL
				  ,[SitusStdStreet] = NULL
				  ,[SitusStdMode] = NULL
				  ,[SitusStdDirectionRight] = NULL
				  ,[SitusStdUnitNbr] = NULL
				  ,[SitusStdZIP4] = NULL
				  ,[FAAddressParsedSitus] = NULL
				WHERE SitusStdFullStreetAddress like 'PO Box%' 
					OR SitusStdFullStreetAddress like 'P O Box%' 
		--Print 'query12'

		UPDATE a
		SET a.SubdivisionName = b.SubdivisionName
		FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		 and a.PropertyID = b.PropertyID
		WHERE isNULL(a.SubdivisionName,'') like ''
			 and isNULL(b.SubdivisionName,'') not like ''
		--Print 'query13'

		UPDATE a
		SET a.Municipality = b.Municipality
		FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		on a.FIPS = b.FIPS
		 and a.PropertyID = b.PropertyID
		WHERE isNULL(a.Municipality,'') like ''
			 and isNULL(b.Municipality,'') Not like ''

		--Print 'query14'
		UPDATE [dbo].[PropertyWorkUpdateTbl] 
		SET StyleCode = CASE WHEN StdLandUseCode = '1004' THEN 29 --Condo
			WHEN StdLandUseCode = '1101' THEN 31 --Duplex
			WHEN StdLandUseCode = '1103' THEN 32 --Quadplex
			WHEN StdLandUseCode = '1006' THEN 33 --Mobile Home
			WHEN StdLandUseCode = '1110' THEN 34 --MultiFam
			WHEN StdLandUseCode = '1002' THEN 35 --Townhouse
			WHEN StdLandUseCode = '1102' THEN 36 --Triplex
			WHEN StdLandUseCode = '1003' THEN 30 --Cluster
			WHEN StdLandUseCode = '1017' THEN 37 --Patio Home
			WHEN StdLandUseCode = '1007' THEN 38 --Row Home
			WHEN StoriesCode Like 'B/L%' THEN 40 --Bi-Level
			WHEN StoriesCode Like 'T/L%' THEN 39 --Tri-Level
			WHEN StoriesCode Like 'S/L%' THEN 41 --Split-Level
			WHEN StoriesCode Like 'S/F%' THEN 42 --Split-Foyer
			END
		 WHERE StyleCode is null
		 and StdLandUseCode in('1004','1101','1103','1006','1110','1002','1102','1003','1017','1007')

		--Print 'query15'
			UPDATE [dbo].[PropertyWorkUpdateTbl] 
			SET MailingOptOut = 1,
			MailingOptOutDate = Convert(varchar(8),GETDATE(),112)
			WHERE FIPS IN ('17017','17109','17193','20001','20003','20005','20007','20009','20013','20015','20017','20019',
				'20021','20023','20025','20027','20029','20031','20033','20035','20039','20041','20043','20045','20047','20049',
				'20051','20053','20055','20057','20059','20061','20063','20065','20067','20069','20071','20073','20075','20077',
				'20079','20081','20083','20085','20087','20089','20093','20095','20097','20099','20101','20103','20105','20107',
				'20109','20111','20113','20115','20117','20119','20121','20123','20125','20127','20129','20131','20133','20135',
				'20137','20139','20141','20143','20145','20147','20149','20151','20153','20155','20157','20159','20161','20163',
				'20165','20167','20169','20171','20175','20177','20179','20181','20183','20185','20187','20189','20191','20193',
				'20195','20197','20199','20201','20203','20205','20207','20209','26009','26055','26097','26123','26129','29083',
				'30087','30105','49023','20037','20011','30033','30005','30099','30003','30015','30103','30095','30109','30037',
				'01081','30083','30017','30093','30019','30041','30079','30071','30085','30025','53071','30011','30091','30077',
				'30107','30065','26039','20173','26027','20091','21177','30075','30073','45011','30097','16033','30069','30035',
				'21197','30001','16035','30059','16039','30051','30089','16071','30043','30101','16061','16025','16057','16047',
				'16029','30067','16059','30007','16031','16049','16087','16063','30009','16003','16007','53009','16067','16009',
				'16073','16037','30039','16079','16043','16023','16077','30055','16045','16015','30045','30061','30053','16069',
				'30057','16065','30021','16021','16053','30023','16041','16011','30029','16081','17029','45029','16051','16017',
				'30027','16085','26151','30047','16075','16013','30049','30081','26159','26045','17169','30013','16083','16019',
				'30031','16005','30063','29047','16055','42101','16027','30111','16001','49035','48413')
			AND (MailingOptOut <> 1 or MailingOptOut is NULL)

		--Print 'query16'
			UPDATE a 
			SET MailingOptOut = 1
			,MailingOptOutDate = Convert(varchar(8),GETDATE(),112)
			FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN DMA.dbo.DMAData_Out b
			on a.FIPS = b.FIPS
			and a.PropertyID = b.PropertyId
			WHERE (MailingOptOut <> 1 or MailingOptOut is NULL)


		----- ADDED 20181106 to persist Property Characteristics that disappear.	
			
		--Print 'query17'
		UPDATE a
		SET a.[AirConditioningCode] = CASE WHEN (isNULL(a.[AirConditioningCode],'') Like '' or a.[AirConditioningCode] Like '0.00' or a.[AirConditioningCode] Like '0') THEN Convert(varchar(10),b.[AirConditioningCode]) ELSE a.[AirConditioningCode] END
		,a.[AirConditioningTypeCode] = CASE WHEN (isNULL(a.[AirConditioningTypeCode],'') Like '' or a.[AirConditioningTypeCode] Like '0.00' or a.[AirConditioningTypeCode] Like '0') THEN Convert(varchar(10),b.[AirConditioningTypeCode]) ELSE a.[AirConditioningTypeCode] END
		,a.[Amenities] = CASE WHEN (isNULL(a.[Amenities],'') Like '' or a.[Amenities] Like '0.00' or a.[Amenities] Like '0') THEN Convert(varchar(10),b.[Amenities]) ELSE a.[Amenities] END
		,a.[AtticFinishSqFt] = CASE WHEN (isNULL(a.[AtticFinishSqFt],'') Like '' or a.[AtticFinishSqFt] Like '0.00' or a.[AtticFinishSqFt] Like '0') THEN Convert(varchar(10),b.[AtticFinishSqFt]) ELSE a.[AtticFinishSqFt] END
		,a.[AtticSqFt] = CASE WHEN (isNULL(a.[AtticSqFt],'') Like '' or a.[AtticSqFt] Like '0.00' or a.[AtticSqFt] Like '0') THEN Convert(varchar(10),b.[AtticSqFt]) ELSE a.[AtticSqFt] END
		,a.[BasementCode] = CASE WHEN (isNULL(a.[BasementCode],'') Like '' or a.[BasementCode] Like '0.00' or a.[BasementCode] Like '0') THEN Convert(varchar(10),b.[BasementCode]) ELSE a.[BasementCode] END
		,a.[BasementFinishedCode] = CASE WHEN (isNULL(a.[BasementFinishedCode],'') Like '' or a.[BasementFinishedCode] Like '0.00' or a.[BasementFinishedCode] Like '0') THEN Convert(varchar(10),b.[BasementFinishedCode]) ELSE a.[BasementFinishedCode] END
		,a.[Bath1QTR] = CASE WHEN (isNULL(a.[Bath1QTR],0) Like '0' or a.[Bath1QTR] Like '0.00' or a.[Bath1QTR] Like '0') THEN Convert(varchar(10),b.[Bath1QTR]) ELSE a.[Bath1QTR] END
		,a.[Bath3QTR] = CASE WHEN (isNULL(a.[Bath3QTR],0) Like '0' or a.[Bath3QTR] Like '0.00' or a.[Bath3QTR] Like '0') THEN Convert(varchar(10),b.[Bath3QTR]) ELSE a.[Bath3QTR] END
		,a.[BathFixturesNbr] = CASE WHEN (isNULL(a.[BathFixturesNbr],0) Like '0'  or a.[BathFixturesNbr] Like '0.00' or a.[BathFixturesNbr] Like '0') THEN Convert(varchar(10),b.[BathFixturesNbr]) ELSE a.[BathFixturesNbr] END
		,a.[BathFull] = CASE WHEN (isNULL(a.[BathFull],0) Like '0' or a.[BathFull] Like '0.00' or a.[BathFull] Like '0') THEN Convert(varchar(10),b.[BathFull]) ELSE a.[BathFull] END
		,a.[BathHalf] = CASE WHEN (isNULL(a.[BathHalf],0) Like '0' or a.[BathHalf] Like '0.00' or a.[BathHalf] Like '0') THEN Convert(varchar(10),b.[BathHalf]) ELSE a.[BathHalf] END
		,a.[BathsParcialNbr] = CASE WHEN (isNULL(a.[BathsParcialNbr],0) Like '0' or a.[BathsParcialNbr] Like '0.00' or a.[BathsParcialNbr] Like '0') THEN Convert(varchar(10),b.[BathsParcialNbr]) ELSE a.[BathsParcialNbr] END
		,a.[Bedrooms] = CASE WHEN (isNULL(a.[Bedrooms],0) Like '0' or a.[Bedrooms] Like '0.00' or a.[Bedrooms] Like '0') THEN Convert(varchar(10),b.[Bedrooms]) ELSE a.[Bedrooms] END
		,a.[BuildingArea] = CASE WHEN (isNULL(a.[BuildingArea],0) Like 0 or a.[BuildingArea] Like '0.00' or a.[BuildingArea] Like '0') THEN Convert(varchar(10),b.[BuildingArea]) ELSE a.[BuildingArea] END
		,a.[BuildingAreaInd] = CASE WHEN (isNULL(a.[BuildingAreaInd],'') Like '' or a.[BuildingAreaInd] Like '0.00' or a.[BuildingAreaInd] Like '0') THEN b.[BuildingAreaInd] ELSE a.[BuildingAreaInd] END
		,a.[BuildingClassCode] = CASE WHEN (isNULL(a.[BuildingClassCode],'') Like '' or a.[BuildingClassCode] Like '0.00' or a.[BuildingClassCode] Like '0') THEN Convert(varchar(10),b.[BuildingClassCode]) ELSE a.[BuildingClassCode] END
		,a.[BuildingConditionCode] = CASE WHEN (isNULL(a.[BuildingConditionCode],'') Like '' or a.[BuildingConditionCode] Like '0.00' or a.[BuildingConditionCode] Like '0') THEN Convert(varchar(10),b.[BuildingConditionCode]) ELSE a.[BuildingConditionCode] END
		,a.[BuildingQualityCode] = CASE WHEN (isNULL(a.[BuildingQualityCode],'') Like '' or a.[BuildingQualityCode] Like '0.00' or a.[BuildingQualityCode] Like '0') THEN Convert(varchar(10),b.[BuildingQualityCode]) ELSE a.[BuildingQualityCode] END
		,a.[ConstructionTypeCode] = CASE WHEN (isNULL(a.[ConstructionTypeCode],'') Like '' or a.[ConstructionTypeCode] Like '0.00' or a.[ConstructionTypeCode] Like '0') THEN Convert(varchar(10),b.[ConstructionTypeCode]) ELSE a.[ConstructionTypeCode] END
		,a.[DeckCode] = CASE WHEN (isNULL(a.[DeckCode],'') Like '' or a.[DeckCode] Like '0.00' or a.[DeckCode] Like '0') THEN Convert(varchar(10),b.[DeckCode]) ELSE a.[DeckCode] END
		,a.[DrivewayCode] = CASE WHEN (isNULL(a.[DrivewayCode],'') Like '' or a.[DrivewayCode] Like '0.00' or a.[DrivewayCode] Like '0') THEN Convert(varchar(10),b.[DrivewayCode]) ELSE a.[DrivewayCode] END
		,a.[EasementInd] = CASE WHEN (isNULL(a.[EasementInd],'') Like '' or a.[EasementInd] Like '0.00' or a.[EasementInd] Like '0') THEN Convert(Varchar(3),b.[EasementInd]) ELSE a.[EasementInd] END
		,a.[EffectiveYearBuilt] = CASE WHEN (isNULL(a.[EffectiveYearBuilt],'') Like '' or a.[EffectiveYearBuilt] Like '0.00' or a.[EffectiveYearBuilt] Like '0' or a.[EffectiveYearBuilt] < b.[EffectiveYearBuilt]) THEN Convert(varchar(4),b.[EffectiveYearBuilt]) ELSE a.[EffectiveYearBuilt] END
		,a.[ElectricityCode] = CASE WHEN (isNULL(a.[ElectricityCode],'') Like '' or a.[ElectricityCode] Like '0.00' or a.[ElectricityCode] Like '0') THEN Convert(varchar(10),b.[ElectricityCode]) ELSE a.[ElectricityCode] END
		,a.[ExteriorWallsCode] = CASE WHEN (isNULL(a.[ExteriorWallsCode],'') Like '' or a.[ExteriorWallsCode] Like '0.00' or a.[ExteriorWallsCode] Like '0') THEN Convert(varchar(10),b.[ExteriorWallsCode]) ELSE a.[ExteriorWallsCode] END
		,a.[FireplaceCode] = CASE WHEN (isNULL(a.[FireplaceCode],'') Like '' or a.[FireplaceCode] Like '0.00' or a.[FireplaceCode] Like '0') THEN Convert(varchar(10),b.[FireplaceCode]) ELSE a.[FireplaceCode] END
		,a.[FloorCoverCode] = CASE WHEN (isNULL(a.[FloorCoverCode],'') Like '' or a.[FloorCoverCode] Like '0.00' or a.[FloorCoverCode] Like '0') THEN Convert(varchar(10),b.[FloorCoverCode]) ELSE a.[FloorCoverCode] END
		,a.[FloorTypeCode] = CASE WHEN (isNULL(a.[FloorTypeCode],'') Like '' or a.[FloorTypeCode] Like '0.00' or a.[FloorTypeCode] Like '0') THEN Convert(varchar(10),b.[FloorTypeCode]) ELSE a.[FloorTypeCode] END
		,a.[FoundationInd] = CASE WHEN (isNULL(a.[FoundationInd],'') Like '' or a.[FoundationInd] Like '0.00' or a.[FoundationInd] Like '0') THEN Convert(varchar(10),b.[FoundationInd]) ELSE a.[FoundationInd] END
		,a.[FrameCode] = CASE WHEN (isNULL(a.[FrameCode],'') Like '' or a.[FrameCode] Like '0.00' or a.[FrameCode] Like '0') THEN Convert(varchar(10),b.[FrameCode]) ELSE a.[FrameCode] END
		,a.[Garage] = CASE WHEN (isNULL(a.[Garage],'') Like '' or a.[Garage] Like '0.00' or a.[Garage] Like '0') THEN Convert(varchar(10),b.[Garage]) ELSE a.[Garage] END
		,a.[GarageFinishSqFt] = CASE WHEN (isNULL(a.[GarageFinishSqFt],'') Like '' or a.[GarageFinishSqFt] Like '0.00' or a.[GarageFinishSqFt] Like '0') THEN Convert(varchar(10),b.[GarageFinishSqFt]) ELSE a.[GarageFinishSqFt] END
		,a.[GarageParkingNbr] = CASE WHEN (isNULL(a.[GarageParkingNbr],'') Like '' or a.[GarageParkingNbr] Like '0.00' or a.[GarageParkingNbr] Like '0') THEN Convert(varchar(10),b.[GarageParkingNbr]) ELSE a.[GarageParkingNbr] END
		,a.[GarageUnFinSqFt] = CASE WHEN (isNULL(a.[GarageUnFinSqFt],'') Like '' or a.[GarageUnFinSqFt] Like '0.00' or a.[GarageUnFinSqFt] Like '0') THEN Convert(varchar(10),b.[GarageUnFinSqFt]) ELSE a.[GarageUnFinSqFt] END
		,a.[HeatCode] = CASE WHEN (isNULL(a.[HeatCode],'') Like '' or a.[HeatCode] Like '0.00' or a.[HeatCode] Like '0') THEN Convert(varchar(10),b.[HeatCode]) ELSE a.[HeatCode] END
		,a.[HeatingFuelTypeCode] = CASE WHEN (isNULL(a.[HeatingFuelTypeCode],'') Like '' or a.[HeatingFuelTypeCode] Like '0.00' or a.[HeatingFuelTypeCode] Like '0') THEN Convert(varchar(10),b.[HeatingFuelTypeCode]) ELSE a.[HeatingFuelTypeCode] END
		,a.[InteriorWallsCode] = CASE WHEN (isNULL(a.[InteriorWallsCode],'') Like '' or a.[InteriorWallsCode] Like '0.00' or a.[InteriorWallsCode] Like '0') THEN Convert(varchar(10),b.[InteriorWallsCode]) ELSE a.[InteriorWallsCode] END
		,a.[OtherRooms] = CASE WHEN (isNULL(a.[OtherRooms],'') Like '' or a.[OtherRooms] Like '0.00' or a.[OtherRooms] Like '0') THEN Convert(varchar(5),b.[OtherRooms]) ELSE a.[OtherRooms] END
		,a.[PatioCode] = CASE WHEN (isNULL(a.[PatioCode],'') Like '' or a.[PatioCode] Like '0.00' or a.[PatioCode] Like '0') THEN Convert(varchar(10),b.[PatioCode]) ELSE a.[PatioCode] END
		,a.[PavingCode] = CASE WHEN (isNULL(a.[PavingCode],'') Like '' or a.[PavingCode] Like '0.00' or a.[PavingCode] Like '0') THEN Convert(varchar(10),b.[PavingCode]) ELSE a.[PavingCode] END
		,a.[PoolCode] = CASE WHEN (isNULL(a.[PoolCode],'') Like '' or a.[PoolCode] Like '0.00' or a.[PoolCode] Like '0') THEN Convert(varchar(10),b.[PoolCode]) ELSE a.[PoolCode] END
		,a.[PorchCode] = CASE WHEN (isNULL(a.[PorchCode],'') Like '' or a.[PorchCode] Like '0.00' or a.[PorchCode] Like '0') THEN Convert(varchar(10),b.[PorchCode]) ELSE a.[PorchCode] END
		,a.[QualityCode] = CASE WHEN (isNULL(a.[QualityCode],'') Like '' or a.[QualityCode] Like '0.00' or a.[QualityCode] Like '0') THEN Convert(varchar(10),b.[QualityCode]) ELSE a.[QualityCode] END
		,a.[RoofCoverCode] = CASE WHEN (isNULL(a.[RoofCoverCode],'') Like '' or a.[RoofCoverCode] Like '0.00' or a.[RoofCoverCode] Like '0') THEN Convert(varchar(10),b.[RoofCoverCode]) ELSE a.[RoofCoverCode] END
		,a.[RoofTypeCode] = CASE WHEN (isNULL(a.[RoofTypeCode],'') Like '' or a.[RoofTypeCode] Like '0.00' or a.[RoofTypeCode] Like '0') THEN Convert(varchar(10),b.[RoofTypeCode]) ELSE a.[RoofTypeCode] END
		,a.[SewerCode] = CASE WHEN (isNULL(a.[SewerCode],'') Like '' or a.[SewerCode] Like '0.00' or a.[SewerCode] Like '0') THEN Convert(varchar(10),b.[SewerCode]) ELSE a.[SewerCode] END
		,a.[ShapeCode] = CASE WHEN (isNULL(a.[ShapeCode],'') Like '' or a.[ShapeCode] Like '0.00' or a.[ShapeCode] Like '0') THEN Convert(varchar(10),b.[ShapeCode]) ELSE a.[ShapeCode] END
		,a.[StoriesCode] = CASE WHEN (isNULL(a.[StoriesCode],'') Like '' or a.[StoriesCode] Like '0.00' or a.[StoriesCode] Like '0') THEN Convert(varchar(10),b.[StoriesCode]) ELSE a.[StoriesCode] END
		,a.[StoriesNbrCode] = CASE WHEN (isNULL(a.[StoriesNbrCode],'') Like '' or a.[StoriesNbrCode] Like '0.00' or a.[StoriesNbrCode] Like '0') THEN Convert(varchar(10),b.[StoriesNbrCode]) ELSE a.[StoriesNbrCode] END
		,a.[StyleCode] = CASE WHEN (isNULL(a.[StyleCode],'') Like '' or a.[StyleCode] Like '0.00' or a.[StyleCode] Like '0') THEN Convert(varchar(10),b.[StyleCode]) ELSE a.[StyleCode] END
		,a.[SumAboveGradeLivingSqFt] = CASE WHEN (isNULL(a.[SumAboveGradeLivingSqFt],0) Like '0' or a.[SumAboveGradeLivingSqFt] Like '0.00' or a.[SumAboveGradeLivingSqFt] Like '0') THEN b.[SumAboveGradeLivingSqFt] ELSE a.[SumAboveGradeLivingSqFt] END
		,a.[SumAdjAreaSqFt] = CASE WHEN (isNULL(a.[SumAdjAreaSqFt],0) Like '0' or a.[SumAdjAreaSqFt] Like '0.00' or a.[SumAdjAreaSqFt] Like '0') THEN b.[SumAdjAreaSqFt] ELSE a.[SumAdjAreaSqFt] END
		,a.[SumBasementSqFt] = CASE WHEN (isNULL(a.[SumBasementSqFt],0) Like '0' or a.[SumBasementSqFt] Like '0.00' or a.[SumBasementSqFt] Like '0') THEN b.[SumBasementSqFt] ELSE a.[SumBasementSqFt] END
		,a.[SumBuildingsNbr] = CASE WHEN (isNULL(a.[SumBuildingsNbr],0) Like '0' or a.[SumBuildingsNbr] Like '0.00' or a.[SumBuildingsNbr] Like '0') THEN b.[SumBuildingsNbr] ELSE a.[SumBuildingsNbr] END
		,a.[SumBuildingSqFt] = CASE WHEN (isNULL(a.[SumBuildingSqFt],0) Like '0' or a.[SumBuildingSqFt] Like '0.00' or a.[SumBuildingSqFt] Like '0') THEN b.[SumBuildingSqFt] ELSE a.[SumBuildingSqFt] END
		,a.[SumGarageSqFt] = CASE WHEN (isNULL(a.[SumGarageSqFt],0) Like '0' or a.[SumGarageSqFt] Like '0.00' or a.[SumGarageSqFt] Like '0') THEN b.[SumGarageSqFt] ELSE a.[SumGarageSqFt] END
		,a.[SumGrossAreaSqFt] = CASE WHEN (isNULL(a.[SumGrossAreaSqFt],0) Like '0' or a.[SumGrossAreaSqFt] Like '0.00' or a.[SumGrossAreaSqFt] Like '0') THEN b.[SumGrossAreaSqFt] ELSE a.[SumGrossAreaSqFt] END
		,a.[SumGroundFloorSqFt] = CASE WHEN (isNULL(a.[SumGroundFloorSqFt],0) Like '0' or a.[SumGroundFloorSqFt] Like '0.00' or a.[SumGroundFloorSqFt] Like '0') THEN b.[SumGroundFloorSqFt] ELSE a.[SumGroundFloorSqFt] END
		,a.[SumLivingAreaSqFt] = CASE WHEN (isNULL(a.[SumLivingAreaSqFt],0) Like '0' or a.[SumLivingAreaSqFt] Like '0.00' or a.[SumLivingAreaSqFt] Like '0') THEN b.[SumLivingAreaSqFt] ELSE a.[SumLivingAreaSqFt] END
		,a.[SumResidentialUnits] = CASE WHEN (isNULL(a.[SumResidentialUnits],0) Like '0' or a.[SumResidentialUnits] Like '0.00' or a.[SumResidentialUnits] Like '0') THEN b.[SumResidentialUnits] ELSE a.[SumResidentialUnits] END
		,a.[TotalRooms] = CASE WHEN (isNULL(a.[TotalRooms],'') Like '' or a.[TotalRooms] Like '0.00' or a.[TotalRooms] Like '0') THEN Convert(varchar(10),b.[TotalRooms]) ELSE a.[TotalRooms] END
		,a.[ViewCode] = CASE WHEN (isNULL(a.[ViewCode],'') Like '' or a.[ViewCode] Like '0.00' or a.[ViewCode] Like '0') THEN Convert(varchar(10),b.[ViewCode]) ELSE a.[ViewCode] END
		,a.[ViewInd] = CASE WHEN (isNULL(a.[ViewInd],'') Like '' or a.[ViewInd] Like '0.00' or a.[ViewInd] Like '0') THEN convert(varchar(3),b.[ViewInd]) ELSE a.[ViewInd] END
		,a.[ViewQualityCode] = CASE WHEN (isNULL(a.[ViewQualityCode],'') Like '' or a.[ViewQualityCode] Like '0.00' or a.[ViewQualityCode] Like '0') THEN Convert(varchar(10),b.[ViewQualityCode]) ELSE a.[ViewQualityCode] END
		,a.[WallExteriorCode] = CASE WHEN (isNULL(a.[WallExteriorCode],'') Like '' or a.[WallExteriorCode] Like '0.00' or a.[WallExteriorCode] Like '0') THEN Convert(varchar(10),b.[WallExteriorCode]) ELSE a.[WallExteriorCode] END
		,a.[WallheightCode] = CASE WHEN (isNULL(a.[WallheightCode],'') Like '' or a.[WallheightCode] Like '0.00' or a.[WallheightCode] Like '0') THEN Convert(varchar(10),b.[WallheightCode]) ELSE a.[WallheightCode] END
		,a.[WaterAccessableInd] = CASE WHEN (isNULL(a.[WaterAccessableInd],'') Like '' or a.[WaterAccessableInd] Like '0.00' or a.[WaterAccessableInd] Like '0') THEN convert(varchar(3),b.[WaterAccessableInd]) ELSE a.[WaterAccessableInd] END
		,a.[WaterCode] = CASE WHEN (isNULL(a.[WaterCode],'') Like '' or a.[WaterCode] Like '0.00' or a.[WaterCode] Like '0') THEN Convert(varchar(10),b.[WaterCode]) ELSE a.[WaterCode] END
		,a.[WaterFeatureInd] = CASE WHEN (isNULL(a.[WaterFeatureInd],'') Like '' or a.[WaterFeatureInd] Like '0.00' or a.[WaterFeatureInd] Like '0') THEN Convert(varchar(3),b.[WaterFeatureInd]) ELSE a.[WaterFeatureInd] END
		,a.[WaterfrontCode] = CASE WHEN (isNULL(a.[WaterfrontCode],'') Like '' or a.[WaterfrontCode] Like '0.00' or a.[WaterfrontCode] Like '0') THEN Convert(varchar(10),b.[WaterfrontCode]) ELSE a.[WaterfrontCode] END
		,a.[WaterfrontFeet] = CASE WHEN (isNULL(a.[WaterfrontFeet],'') Like '' or a.[WaterfrontFeet] Like '0.00' or a.[WaterfrontFeet] Like '0') THEN Convert(varchar(10),b.[WaterfrontFeet]) ELSE a.[WaterfrontFeet] END
		,a.[WaterfrontQualityCode] = CASE WHEN (isNULL(a.[WaterfrontQualityCode],'') Like '' or a.[WaterfrontQualityCode] Like '0.00' or a.[WaterfrontQualityCode] Like '0') THEN Convert(varchar(10),b.[WaterfrontQualityCode]) ELSE a.[WaterfrontQualityCode] END
		,a.[YearBuilt] = CASE WHEN (isNULL(a.[YearBuilt],'') Like '' or a.[YearBuilt] Like '0.00' or a.[YearBuilt] Like '0' or a.[YearBuilt] < b.[YearBuilt]) THEN Convert(varchar(4),b.[YearBuilt]) ELSE a.[YearBuilt] END
		,a.[Zoning] = CASE WHEN (isNULL(a.[Zoning],'') Like '' or a.[Zoning] is NULL or a.[Zoning] Like '0.00' or a.[Zoning] Like '0') THEN b.[Zoning] ELSE a.[Zoning] END
		 FROM  [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID		


		------ ADDED 20181211 To Fill Basement Finish MAS
		--Print 'query18'
		UPDATE a 
		SET [BasementFinishedCode] = [BsmtFinID]
		FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN Global.dbo.Lkup_BasementFinish b
		on a.BasementCode = b.[FACode]
		Where [BasementFinishedCode] is NULL and [BasementCode] is not null


		--Print 'query19'
		UPDATE [dbo].[PropertyWorkUpdateTbl] 
		SET [BasementFinishedCode] = CASE WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 15 AND 35 THEN 4
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 36 AND 65 THEN 5
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 66 AND 85 THEN 6
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 > 86 THEN 7
			END
		WHERE [BasementFinishedCode] is NULL and [BasementFinishSqFt] > 0



			 ---- SanDiego Zoning

		--Print 'query20'
			  UPDATE a
			  SET a.Zoning = b.Zoning
			  FROM [dbo].[PropertyWorkUpdateTbl]  a JOIN  Data.dbo.SanDiegoZoning b
			  on a.PropertyID = b.PropertyID
			  Where a.Fips = '06073'


		--Print 'query1'
		UPDATE a
		SET a.[LotSizeSqFt] = CASE WHEN (a.[LotSizeSqFt] is NULL or a.[LotSizeSqFt] Like '0') THEN b.[LotSizeSqFt] ELSE a.[LotSizeSqFt] END
		,a.[LotSizeAcres] = CASE WHEN (isNULL(a.[LotSizeAcres],'') Like '' or a.[LotSizeAcres] is NULL or a.[LotSizeAcres] Like '0000000000' or a.[LotSizeAcres] Like '0') THEN b.[LotSizeAcres] ELSE a.[LotSizeAcres] END
		,a.[LotSizeFrontageFeet] = CASE WHEN (isNULL(a.[LotSizeFrontageFeet],'') Like '' or a.[LotSizeFrontageFeet] is NULL or a.[LotSizeFrontageFeet] Like '0000000000' or a.[LotSizeFrontageFeet] Like '0') THEN b.[LotSizeFrontageFeet] ELSE a.[LotSizeFrontageFeet] END
		,a.[LotSizeDepthFeet] = CASE WHEN (isNULL(a.[LotSizeDepthFeet],'') Like '' or a.[LotSizeDepthFeet] is NULL or a.[LotSizeDepthFeet] Like '0000000000' or a.[LotSizeDepthFeet] Like '0') THEN b.[LotSizeDepthFeet] ELSE a.[LotSizeDepthFeet] END
		 FROM  [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID
		

		--Print 'query21'
		UPDATE [dbo].[PropertyWorkUpdateTbl] 
		SET [LotSizeFrontageFeet] = CASE WHEN (isNULL([LotSizeFrontageFeet],'') Like '' or [LotSizeFrontageFeet] is NULL or [LotSizeFrontageFeet] Like '0000000000' or [LotSizeFrontageFeet] Like '0') THEN NULL ELSE [LotSizeFrontageFeet] END
		,[LotSizeDepthFeet] = CASE WHEN (isNULL([LotSizeDepthFeet],'') Like '' or [LotSizeDepthFeet] is NULL or [LotSizeDepthFeet] Like '0000000000' or [LotSizeDepthFeet] Like '0') THEN NULL ELSE [LotSizeDepthFeet] END

		--Print 'query22'
		UPDATE a
		SET a.OldAPN = b.OldAPN
		,a.OldApnIndicator = b.OldApnIndicator
		FROM  [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID
		WHERE a.OldAPN is NULL

		--Print 'query23'
		UPDATE a
		SET a.Zoning = CASE WHEN isNULL(a.[Zoning],'') Like '' THEN b.Zoning ELSE a.[Zoning] END
			,a.SiteInfluenceCode = CASE WHEN isNULL(a.[SiteInfluenceCode],'') Like '' THEN b.SiteInfluenceCode ELSE a.[SiteInfluenceCode] END
			,a.NeighborhoodCode = CASE WHEN isNULL(a.[NeighborhoodCode],'') Like '' THEN b.NeighborhoodCode ELSE a.[NeighborhoodCode] END
			,a.TopographyCode = CASE WHEN isNULL(a.[TopographyCode],'') Like '' THEN b.TopographyCode ELSE a.[TopographyCode] END
			,a.MobileHomeInd = CASE WHEN isNULL(a.[MobileHomeInd],'') Like '' THEN b.MobileHomeInd ELSE a.[MobileHomeInd] END
			,a.LotCode = CASE WHEN isNULL(a.[LotCode],'') Like '' THEN b.LotCode ELSE a.[LotCode] END
			,a.LotNumber = CASE WHEN isNULL(a.[LotNumber],'') Like '' THEN b.LotNumber ELSE a.[LotNumber] END
			,a.LandLot = CASE WHEN isNULL(a.[LandLot],'') Like '' THEN b.LandLot ELSE a.[LandLot] END
			,a.Block = CASE WHEN isNULL(a.[Block],'') Like '' THEN b.Block ELSE a.[Block] END
			,a.Section = CASE WHEN isNULL(a.[Section],'') Like '' THEN b.Section ELSE a.[Section] END
			,a.District = CASE WHEN isNULL(a.[District],'') Like '' THEN b.District ELSE a.[District] END
			,a.LegalUnit = CASE WHEN isNULL(a.[LegalUnit],'') Like '' THEN b.LegalUnit ELSE a.[LegalUnit] END
			,a.Municipality = CASE WHEN isNULL(a.[Municipality],'') Like '' THEN b.Municipality ELSE a.[Municipality] END
			,a.LegalSection = CASE WHEN isNULL(a.[LegalSection],'') Like '' THEN b.LegalSection ELSE a.[LegalSection] END
			,a.LegalTownship = CASE WHEN isNULL(a.[LegalTownship],'') Like '' THEN b.LegalTownship ELSE a.[LegalTownship] END
			,a.LegalRange = CASE WHEN isNULL(a.[LegalRange],'') Like '' THEN b.LegalRange ELSE a.[LegalRange] END
			,a.Meridian = CASE WHEN isNULL(a.[Meridian],'') Like '' THEN b.Meridian ELSE a.[Meridian] END
			,a.LegalQuarter = CASE WHEN isNULL(a.[LegalQuarter],'') Like '' THEN b.LegalQuarter ELSE a.[LegalQuarter] END
			,a.LegalQuarterQuarter = CASE WHEN isNULL(a.[LegalQuarterQuarter],'') Like '' THEN b.LegalQuarterQuarter ELSE a.[LegalQuarterQuarter] END
			,a.LegalDescription = CASE WHEN isNULL(a.[LegalDescription],'') Like '' THEN b.LegalDescription ELSE a.[LegalDescription] END
			,a.AssessorsMapRef1 = CASE WHEN isNULL(a.[AssessorsMapRef1],'') Like '' THEN b.[AssessorsMapRef1] ELSE a.[AssessorsMapRef1] END
			,a.AssessorsMapRef2 = CASE WHEN isNULL(a.[AssessorsMapRef2],'') Like '' THEN b.[AssessorsMapRef2] ELSE a.[AssessorsMapRef2] END
			,a.SubdivisionName = CASE WHEN isNULL(a.[SubdivisionName],'') Like '' THEN b.[SubdivisionName] ELSE a.[SubdivisionName] END
			,a.SubdivisionPhaseNbr = CASE WHEN isNULL(a.[SubdivisionPhaseNbr],'') Like '' THEN b.[SubdivisionPhaseNbr] ELSE a.[SubdivisionPhaseNbr] END
			,a.SubdivisionTractNbr = CASE WHEN isNULL(a.[SubdivisionTractNbr],'') Like '' THEN b.[SubdivisionTractNbr] ELSE a.[SubdivisionTractNbr] END
			,a.SubdivisionPlatBook = CASE WHEN isNULL(a.[SubdivisionPlatBook],'') Like '' THEN b.[SubdivisionPlatBook] ELSE a.[SubdivisionPlatBook] END
			,a.SubdivisionPlatPage = CASE WHEN isNULL(a.[SubdivisionPlatPage],'') Like '' THEN b.[SubdivisionPlatPage] ELSE a.[SubdivisionPlatPage] END
			,a.NewRecordType = CASE WHEN isNULL(a.[NewRecordType],'') Like '' THEN b.[NewRecordType] ELSE a.[NewRecordType] END
			,a.SwiSCodeNY = CASE WHEN isNULL(a.[SwiSCodeNY],'') Like '' THEN b.[SwiSCodeNY] ELSE a.[SwiSCodeNY] END
		 FROM  [dbo].[PropertyWorkUpdateTbl]  a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID


		--Print 'query24'
		UPDATE a 
		SET [BasementFinishedCode] = [BsmtFinID]
		FROM dbo.PropertyWorkUpdateTbl a JOIN Global.dbo.Lkup_BasementFinish b
		on a.BasementCode = b.[FACode]
		Where [BasementCode] is not null


		--Print 'query25'
		UPDATE dbo.PropertyWorkUpdateTbl
		SET [BasementFinishedCode] = CASE WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 15 AND 35 THEN 4
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 36 AND 65 THEN 5
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 BETWEEN 66 AND 85 THEN 6
			WHEN convert(money,[BasementFinishSqFt])/Convert(money,[SumBasementSqFt])*100 > 86 THEN 7
			END
		WHERE [BasementFinishSqFt] > 0

		--Print 'query26'
		UPDATE a
		SET a.TaxAmount = b.TaxAmount
		,a.TaxYear = b.TaxYear 
		FROM dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
			on a.Fips = b.fips and a.PropertyID = b.PropertyID
		WHERE (isNULL(b.TaxYear,'') not like '' and isNULL(a.TaxYear,'') like '')	
			OR (isNULL(a.TaxYear,'') not like '' and isNULL(b.TaxYear,'') not like '' and b.TaxYear > a.TaxYear)


			--Print 'query27'
	UPDATE a
		SET [AssdLandValue] = b.[AssdLandValue] 
		,[AssdImprovementValue] = b.[AssdImprovementValue]
		,[AssdTotalValue] = b.[AssdTotalValue] 
		  ,[AssdYear] = b.[AssdYear] 
		 FROM  dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID
		WHERE a.AssdYear < b.AssdYear 
		or (a.AssdYear is NULL and b.AssdYear is NOT NULL)
		or (a.AssdYear = b.AssdYear and isNULL(a.AssdTotalValue,'') = '' and isNULL(b.AssdTotalValue,0)>0)

		UPDATE a
		SET [MarketValueLand] = b.[MarketValueLand]
		,[MarketValueImprovement] = b.[MarketValueImprovement] 
		,[MarketTotalValue] = b.[MarketTotalValue] 
		  ,[MarketValueYear] = b.[MarketValueYear]
		 FROM  dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID
		WHERE a.[MarketValueYear] < b.[MarketValueYear] 
		or (a.[MarketValueYear] is NULL and b.[MarketValueYear] is NOT NULL)
		or (a.[MarketValueYear] = b.[MarketValueYear] and isNULL(a.[MarketTotalValue],'') = '' and isNULL(b.[MarketTotalValue],0)>0)

		UPDATE a
		SET [ApprLandValue] = b.[ApprLandValue] 
		,[ApprImprovementValue] = b.[ApprImprovementValue]
		,[ApprTotalValue] = b.[ApprTotalValue]
		  ,[ApprYear] = b.[ApprYear]
		 FROM  dbo.PropertyWorkUpdateTbl a JOIN data.dbo.Property b with(NOLOCK)
		ON a.Fips = b.Fips and a.PropertyID = b.PropertyID
		WHERE a.[ApprYear] < b.[ApprYear] 
		or (a.[ApprYear] is NULL and b.[ApprYear] is NOT NULL)
		or (a.[ApprYear] = b.[ApprYear] and isNULL(a.[ApprTotalValue],'') = '' and isNULL(b.[ApprTotalValue],0)>0)


		UPDATE dbo.PropertyWorkUpdateTbl
		SET BathTotalCalc = convert(money,convert(money,bathfull) 
			+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
				+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
					+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end)
		Where convert(money,bathfull)  < 50
		and BathTotalCalc <> convert(money,convert(money,bathfull) 
			+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
				+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
					+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end)

		----UPDATE dbo.PropertyWorkUpdateTbl
		----SET BathTotalCalc = CEILING(convert(Money,BathFixturesNbr)/3)
		----WHERE convert(money,isNULL(BathTotalCalc,0)) = 0
		----and convert(Money,isNULL(BathFixturesNbr,0)) > 0
		----and CEILING(convert(Money,BathFixturesNbr)/3) < 999


		UPDATE dbo.PropertyWorkUpdateTbl
		SET BathTotalCalc = null where BathTotalCalc = '0.00'

		UPDATE a 
		SET [BuildingArea] = NULL
		,SumBuildingSqFt = NULL
		,SumGrossAreaSqFt = NULL
		FROM DragonAssr.dbo.PropertyWorkUpdateTbl a JOIN (
			select fips,[BuildingArea]
			from DragonAssr.dbo.PropertyWork with(nolock)
			where convert(bigint,convert(Money,buildingarea)) > 2000000
			group by fips,[BuildingArea],SumBuildingSqFt,SumGrossAreaSqFt
			having count(*) > 10
			) b
		ON a.FIPS = b.fips 
		and a.BuildingArea = b.BuildingArea

		UPDATE DragonAssr.dbo.PropertyWorkUpdateTbl
		 Set UnformattedAPN = Replace(Replace(Replace(Replace(Replace(Replace(Replace(FormattedAPN,'.',''),'-',''),'\',''),' ',''),'_',''),':',''),'/','')
		 WHERE UnformattedAPN is NULL

		update DragonAssr.dbo.PropertyWorkUpdateTbl 
		SET DTDB_FORMATTED_APN = FormattedAPN
		,DTDB_UNFORMATTED_APN = UnFormattedAPN
		Where DTDB_Ref_ID is NULL and DTDB_FORMATTED_APN is NULL


		 UPdate DragonAssr.dbo.PropertyWorkUpdateTbl
			SET SumResidentialUnits = NULL
		 Where StdLandUseCode = '1001'
			and convert(Money,SumResidentialUnits) > 1
			and isNULL(SitusStdUnitNbr,'') like ''

		UPDATE DragonAssr.dbo.PropertyWorkUpdateTbl
			SET SumResidentialUnits = NULL
		Where StdLandUseCode in('1101','1102','1103')
			and convert(Money,SumResidentialUnits) > 50

		UPDATE DragonAssr.dbo.PropertyWorkUpdateTbl
			SET EffectiveYearBuilt = NULL
		WHERE EffectiveYearBuilt < YearBuilt

		update a
		Set DTDB_Ref_ID = NULL
		,DTDB_FORMATTED_APN = NULL
		,DTDB_UNFORMATTED_APN = NULL 
		FROM DragonAssr.dbo.PropertyWorkUpdateTbl a JOIN (
			Select fips,DTDB_Ref_ID from DragonAssr.dbo.PropertyWorkUpdateTbl with(NOLOCK)
			where DTDB_Ref_ID is not null
			group by fips,DTDB_Ref_ID 
			having Count(*) > 1) b
		on a.Fips = b.Fips
		and a.DTDB_REF_ID = b.DTDB_REF_ID

			update A
			SET A.SumGroundFloorSqFt = CASE WHEN SumGroundFloorSqFt < 0 THEN NULL ELSE SumGroundFloorSqFt END
			,A.SumBasementSqFt = CASE WHEN SumBasementSqFt < 0 THEN NULL ELSE SumBasementSqFt END
			,A.BasementUnfinSqFt = CASE WHEN BasementUnfinSqFt < 0 THEN NULL ELSE BasementUnfinSqFt END
			,FATimestamp = '2025-03-11'
			,FAUserId = 'Fix Negative Sqft'
			From DragonAssr.dbo.PropertyWorkUpdateTbl A
			where FAUCIDFlag not like 'D'
			and (sumgroundfloorsqft < 0
			OR sumbasementsqft < 0 
			OR BasementUnfinSqFt < 0)

			UPDATE a 
			SET a.LotSizeSqFt = FAEstLotSqFt
			,a.LotSizeAcres = RIGHT('0000000000' + convert(varchar(10),cast(CAST(round((cast(FAEstLotSqFt as Money)/43560)*1000,0) as varchar(15)) as numeric(10,0))),10)
			,a.FAUserID = 'Fixed lot SqFt with EstSqFt'
			From DragonAssr.dbo.PropertyWorkUpdateTbl a
			where cast(lotsizeacres as bigint) > 100 and cast(lotsizeacres as bigint) < 5000000 --and Cast(LotSizeSqFt as Money) != cast(LAND_SQUARE_FOOTAGE as Money)
			and FAEstLotSqFt is not null and FAEstLotSqFt < 2000000000
			and cast(lotSizesqft as bigint) > FAEstLotSqFt * 10
			and a.PropertyClassID like 'R' 
			and a.FAEstLotSqFt > 5000


END

