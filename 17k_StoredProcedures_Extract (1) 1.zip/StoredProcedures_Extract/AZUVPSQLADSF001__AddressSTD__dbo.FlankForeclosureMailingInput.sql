SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankForeclosureMailingInput](@tableName varchar(40)) -- @tableName = 'Foreclosure_Mailing' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = ' 
    create table ' + rtrim(@tableName) + '_STD (' + ' 
	[ForeclosureUniqueID] [bigint] NOT NULL,
	[MailingFullStreetAddress] [varchar](164) NULL,
	[MailingHouseNbr] [varchar](30) NULL,
	[MailingDirectionLeft] [varchar](2) NULL,
	[MailingStreet] [varchar](60) NULL,
	[MailingMode] [varchar](10) NULL,
	[MailingDirectionRight] [varchar](2) NULL,
	[MailingUnitNbr] [varchar](15) NULL,
	[MailingCity] [varchar](55) NULL,
	[MailingState] [varchar](2) NULL,
	[MailingZIP5] [varchar](9) NULL,
	[MailingZIP4] [varchar](4) NULL,
	[MailingCarrierCode] [varchar](4) NULL,
	[MailingUnitType] [varchar](20) NULL,
	[MailingMatchCode] [varchar](30) NULL,
	[MailingCensusBlock] [varchar](4) NULL,
	[MailingCensusTract] [varchar](6) NULL,
	[MailingDPCheckCode] [varchar](2) NULL,
	[MailingDPCheckDigit] [varchar] (1) NULL,
	[MailingDPVCount] [varchar](5) NULL,
	[MailingDPVFootnote] [varchar](4) NULL,
	[MailingGeoErrorCode] [varchar](1) NULL,
	[MailingGeoStatusCode] [varchar](1) NULL,
	[MailingGeoCodeResults] [varchar](30) NULL,
	[MailingLACS] [varchar](1) NULL,
	[MailingLACSLinkInd] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT ForeclosureUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([MailingFullStreetAddress], '''') addressLine ,isnull(MailingCity, '''') as city  ,isnull(MailingState, '''') as state  ,
isnull(MailingZIP5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY MailingZIP5 desc'  

exec (@sql)  

