SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[FlankMortgageslFISSitusInput](@tableName varchar(40)) -- @tableName = 'Mortgage_sl_FIS_Situs' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + '  
	[MortgageUniqueID] [bigint] NOT NULL, 
	[SitusFullStreetAddress] [varchar](116) NULL,
	[SitusHouseNbr] [varchar](30) NULL,
	[SitusDirectionLeft] [varchar](2) NULL,
	[SitusStreet] [varchar](60) NULL,
	[SitusMode] [varchar](10) NULL,
	[SitusDirectionRight] [varchar](2) NULL,
	[SitusUnitNbr] [varchar](15) NULL,
	[SitusCity] [varchar](55) NULL,
	[SitusState] [varchar](2) NULL,
	[SitusZIP5] [varchar](9) NULL,
	[SitusZIP4] [varchar](4) NULL,
	[SitusLatitude] [numeric] (10,6)  NULL,
	[SitusLongitude] [numeric] (10,6)  NULL,
	[SitusCarrierCode] [varchar](4) NULL,
	[SitusCensusTractBlock] [varchar](20) NULL,	
	[SitusUnitType] [varchar](20) NULL,
	[SitusMatchCode] [varchar](30) NULL,
	[SitusDPVCount] [varchar](5) NULL,
	[SitusDPVFootnote] [varchar](4) NULL,
	[SitusLACS] [varchar](1) NULL,
	[SitusLACSLinkInd] [varchar](1) NULL,
	[SitusDPCheckDigit] [varchar](1) NULL,
	[SitusDPCheckCode] [varchar](2) NULL,
	[SitusCensusBlock] [varchar](4) NULL,
	[SitusCensusTract] [varchar](6) NULL,
	[SitusGeoCodeResults] [varchar](30) NULL,
	[SitusGeoErrorCode] [varchar](1) NULL,
	[SitusGeoStatusCode] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 

set @sql = '  
SELECT MortgageUniqueID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([SitusFullStreetAddress], '''') addressLine ,isnull(SitusCity, '''') as city  ,isnull(SitusState, '''') as state  ,
isnull(SitusZIP5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY SitusZIP5 desc'  

exec (@sql)  

