SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_ASP_AddressMaster_to_AddressSTD] @limit int = 100000
AS
BEGIN

truncate table [AddressMaster].[dbo].[AddressMaster_ASP]
--SET IDENTITY_INSERT [AddressMaster].[dbo].[AddressMaster_ASP] on;
INSERT INTO [AddressMaster].[dbo].[AddressMaster_ASP]
(
       [RecordID]
	  ,[AddressLine]
      ,[City]
      ,[State]
      ,[ZIP]
)
SELECT top (@limit)
       [AddressMasterID]
	  --,Case when [SitusStdUnitNbr] is not null then rtrim([SitusStdFullStreetAddress]) + isNULL()+ ' ' + ltrim([SitusStdUnitNbr]) else [SitusStdFullStreetAddress] end as [SitusStdFullStreetAddress]
	  ,Case when (isNULL([Suite],'') Not Like '' and [AddressLine] not like '%' + [Suite]) then rtrim(rtrim([AddressLine] + ' ' + isNULL([SuiteType],'#')) + ' ' + ltrim([Suite])) else [AddressLine] end as [AddressLine]
      ,[City]
      ,[State]
      ,[ZIP]
FROM [AddressMaster].[dbo].[Address_Master] with (nolock) where FAAddressParsed is null and FAUCIDFlag != 'D' and Latitude = 0 --and CountyFips between '48001' and '48999'
--where AddressMasterId in ('3950554','3950585','3950608','3950578','3950631','3950561','3950590','3950570','3950616','3950599')
----where AddressMasterId in ('4647783','4265636','4265628','4265619','4265612','4265604','4265595','4265585','4265577','4265466')
--where AddressMasterId in ('4647783','4265636','4265628','4265619','4265612','4265604','4265595','4265585','4265577','4265466')

INSERT INTO  [Addr].[dbo].[STDTrigger] (AppName,TableName,ProcessTypeCode,Process_Flag,CreatedDateTime,LastUpdatedDateTime) VALUES
 ('AddressMaster_ASP','AddressMaster_ASP','B','R',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)

END

