SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create   procedure [dbo].[AG_Role_Status]
as 
IF SERVERPROPERTY ('IsHadrEnabled') = 1
BEgin
TRUNCATE TABLE [DBA_StorageMonitor].[dbo].[AG_Server_status]
END
BEGIN
INSERT INTO [DBA_StorageMonitor].[dbo].[AG_Server_status]
SELECT RCS.replica_server_name as ServerName-- SQL cluster node name
  , AGC.name as AG_Name-- Availability Group
   , ARS.role_desc as AG_Role -- Replica Role
 , AGL.dns_name as ListnerName -- Listener Name
FROM
 master.sys.availability_groups_cluster AS AGC
  INNER JOIN master.sys.dm_hadr_availability_replica_cluster_states AS RCS
   ON
    RCS.group_id = AGC.group_id
  INNER JOIN master.sys.dm_hadr_availability_replica_states AS ARS
   ON
    ARS.replica_id = RCS.replica_id
  INNER JOIN master.sys.availability_group_listeners AS AGL
   ON
    AGL.group_id = ARS.group_id
WHERE replica_server_name = @@servername
-- ARS.role_desc = 'PRIMARY'
END


