SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_350_PrepareMatchableData] 
AS
BEGIN
	SET NOCOUNT ON;

  --)Calculate Alpha, Digit, Special Char mask for match candidates
 update  DigitalMap..m_FADMNoMatched set PARCELAPNMask = DigitalMap.dbo.GetApnMask(PARCELAPN) 
 update  DigitalMap..property_master set FormattedAPNMask = DigitalMap.dbo.GetApnMask(FormattedAPN), TaxAccountNumberMask = DigitalMap.dbo.GetApnMask(TaxAccountNumber) 
 --update  DigitalMap..property_master set TaxAccountNumberMask = DigitalMap.dbo.GetApnMask(TaxAccountNumber) 



END


