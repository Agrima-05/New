SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

			CREATE procedure [dbo].[usp_102_sp_Generic_usePost] (@tableName varchar(40)) 
			as  
			declare @sql varchar(max) = ''

				set @sql = '
				   UPDATE  AddressSTD.[dbo].[Generic_use_STD]
				   --set [FullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[StreetNumber])) + '' '' +  AddressSTD.[dbo].[Generic_use_STD].[PreDir])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER( AddressSTD.[dbo].[Generic_use_STD].[StreetName]))))) + '' '' + ltrim(rtrim(UPPER( AddressSTD.[dbo].[Generic_use_STD].[StreetType]))) + '' '' +  AddressSTD.[dbo].[Generic_use_STD].[PostDir]))))  + '' '' + ltrim(rtrim(ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[SuiteType])) + '' '' + (ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Suite])))))))
				    
					set [FullStreetAddress] = 
					ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[StreetNumber])) + '' '' +  
					AddressSTD.[dbo].[Generic_use_STD].[PreDir])) + '' '' + 
					ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER( AddressSTD.[dbo].[Generic_use_STD].[StreetName]))))) + '' '' + 
					ltrim(rtrim(UPPER( AddressSTD.[dbo].[Generic_use_STD].[StreetType]))) + '' '' +  
					AddressSTD.[dbo].[Generic_use_STD].[PostDir]))))  + '' '' + 
					ltrim(rtrim(ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[SuiteType])) + '' '' + 
					(ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Suite])))))))
					 + '' '' + (ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PMB])))
					
					,[CountyFips]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CountyFips]))
					,[StreetNumber]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[StreetNumber]))
					,[PreDir]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PreDir]))
					,[StreetName]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[StreetName]))
					,[StreetType]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[StreetType]))
					,[PostDir]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PostDir]))
					,[SuiteType]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[SuiteType]))
					,[Suite]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Suite]))
					,[City]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[City]))
					,[State]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[State]))
					,[Zip]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Zip]))
					,[Plus4]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Plus4]))
					,[CarrierRoute]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CarrierRoute]))
					,[CountyName]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CountyName]))
					,[PrivateMailbox]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PrivateMailbox]))
					,[Pmsa]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Pmsa]))
					,[Msa]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Msa]))
					,[ZipType]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[ZipType]))
					,[Urbanization]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Urbanization]))
					,[CongressionalDistrict]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CongressionalDistrict]))
					,[CityAbbreviation]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CityAbbreviation]))
					,[AddressTypeCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[AddressTypeCode]))
					,[AddressTypeString]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[AddressTypeString]))
					,[DPVCount]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[DPVCount]))
					,[DPVFootnotes]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[DPVFootnotes]))
					,[CMRA]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CMRA]))
					,[ELotNumber]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[ELotNumber]))
					,[ELotOrder]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[ELotOrder]))
					,[Lacs]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Lacs]))
					,[LACSLinkIndicator]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[LACSLinkIndicator]))
					,[EWSFlag]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[EWSFlag]))
					,[RBDI]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[RBDI]))
					,[SuiteLinkReturnCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[SuiteLinkReturnCode]))
					,[DeliveryPointCheckDigit]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[DeliveryPointCheckDigit]))
					,[DeliveryPointCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[DeliveryPointCode]))
					,[Verified]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Verified]))
					,[AddressMatchResults]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[AddressMatchResults]))
					,[CensusBlock]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CensusBlock]))
					,[CensusTract]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CensusTract]))
					,[PlaceCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PlaceCode]))
					,[PlaceName]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[PlaceName]))
					,[CBSACode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSACode]))
					,[CBSALevel]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSALevel]))
					,[CBSATitle]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSATitle]))
					,[CBSADivisionCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSADivisionCode]))
					,[CBSADivisionLevel]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSADivisionLevel]))
					,[CBSADivisionTitle]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CBSADivisionTitle]))
					,[Latitude]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Latitude]))
					,[Longitude]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Longitude]))
					,[Geocoded]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[Geocoded]))
					,[GeoErrorCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[GeoErrorCode]))
					,[GeoStatusCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[GeoStatusCode]))
					,[GeoCodeResults]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[GeoCodeResults]))
					,[CountryCode]  = ltrim(rtrim( AddressSTD.[dbo].[Generic_use_STD].[CountryCode]))


				 From  AddressSTD.[dbo].[Generic_use_STD]

				 	UPDATE
						Table_A
					SET
						Table_A.raw_id = Table_B.raw_id
					FROM
						 AddressSTD.[dbo].[Generic_use_STD] Table_A
					INNER JOIN
						 AddressSTD.[dbo].[Generic_use] Table_B
					ON
						Table_A.RecordId = Table_B.RecordId

				'
			print @sql
			exec (@sql)
