SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_FieldUpdatesFromProperty_MS_II--]
AS

BEGIN
	SET NOCOUNT ON;

	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update II', @t_body = 'Started.'

	DECLARE @FipsCode varchar(5)

	BEGIN
	    UPDATE AM 
        SET CountyFips = '0' + CountyFips 
	    from addressmaster.dbo.Address_Master AM 
	    where len(CountyFips) = 4 
	END


	-- NonUSPSAddressIndicator ------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode] desc
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.NonUSPSAddressIndicator = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS03%'' and (A.NonUSPSAddressIndicator is null or A.NonUSPSAddressIndicator != ''Y'')
				  ')

			EXEC('UPDATE A set A.NotCurrentlyDeliverable = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS17%'' and (A.NotCurrentlyDeliverable is null or NotCurrentlyDeliverable != ''Y'')
				  ')

			EXEC('UPDATE A set A.DsfVacant = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS16%'' and (A.DsfVacant is null or A.DsfVacant != ''Y'')
				  ')

			EXEC('UPDATE A set A.Ref_ID = ASSR.REF_ID, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A with (nolock) 
				  join Assr.dbo.Assr ASSR with (nolock) 
				  on A.propertyid  = ASSR.Lic_PropertyID and A.CountyFips = ASSR.Lic_Fips
				  where A.CountyFips = '''+@FipsCode+''' and ASSR.LIC_FIPS = '''+@FipsCode+''' and A.Ref_ID is null
				  ')
				  
			EXEC('UPDATE A 
					SET Longitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL)
					, Latitude = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)
					, FATimestamp = getdate()
				  FROM AddressMaster.dbo.Address_Master A 
				  JOIN data.dbo.property P with (nolock) 
					on A.CountyFips = '''+@FipsCode+''' and A.propertyid = P.propertyid
				  JOIN DigitalMap.dbo.BuildingFootprint D with (nolock)
					on A.CountyFips = '''+@FipsCode+''' and A.propertyid = D.propertyid
				  WHERE A.CountyFips = '''+@FipsCode+''' 
					AND 
						(A.Longitude != coalesce(D.FARooftopLongitude, P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
							A.Latitude != coalesce(D.FARooftopLatitude, P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL))
				  ')

			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END


    -- send completed email -----------------------------------------------------------------------------------------------------------------------------
	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update II', @t_body = 'Successfully Completed.'

END
