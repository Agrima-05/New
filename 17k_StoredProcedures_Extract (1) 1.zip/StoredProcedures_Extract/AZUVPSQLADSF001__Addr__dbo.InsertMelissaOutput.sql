SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[InsertMelissaOutput]  
           (@ID int,
           @FIPS int,
           @StreetNumber char(20),
           @PreDirection char(2),
           @StreetName char(50),
           @Suffix char(4),
           @PostDirection char(2),
           @UnitType char(10),
           @Unit char(15),
           @City char(55),
           @State char(2),
           @Zip char(9),
           @Plus4 char(4),
           @CarrierRoute char(4),
           @CountyName char(35),
           @DPBC char(12),
           @PrivateMailbox char(4),
           @Pmsa char(2),
           @Msa char(70),
           @ZipType char(2),
           @Urbanization char(6),
           @CongressionalDistrict char(2),
           @CountryCode char(10),
           @CityAbbreviation char(13),
           @AddressTypeCode char(1),
           @AddressTypeString char(60),
           @DPVCount char(5),
           @DPVFootnotes char(4),
           @CMRA char(1),
           @ELotNumber char(5),
           @ELotOrder char(2),
           @LACS char(1),
           @LACSLinkIndicator char(1),
           @EWSFlag char(1),
           @RBDI char(1),
           @SuiteLinkReturnCode char(1),
           @DeliveryPointCheckDigit char(1),
           @DeliveryPointCode char(2),
           @CensusBlock char(4),
           @CensusTract char(6),
           @PlaceCode char(7),
           @PlaceName char(60),
           @CBSACode char(5),
           @CBSALevel char(30),
           @CBSATitle char(50),
           @CBSADivisionCode char(5),
           @CBSADivisionLevel char(30),
           @CBSADivisionTitle char(50),
           @Latitude numeric(10,6),
           @Longitude numeric(10,6),
           @Verified bit,
           @Geocoded bit,
           @AddressMatchResults char(30),
           @GeoErrorCode char(1),
           @GeoStatusCode char(1),
           @HouseNumber varchar(50),
           @tableName varchar(30))
as
declare @tableNameSTD varchar(max) = rtrim(@tableName) + '_STD'
declare @sql nvarchar(max) = ''
declare @ParmDef nvarchar(max)
set @ParmDef = '
	@P_ID int,
	@P_FIPS int,
	@P_StreetNumber char(20),
	@P_PreDirection char(2),
	@P_StreetName char(50),
	@P_Suffix char(4),
	@P_PostDirection char(2),
	@P_UnitType char(10),
	@P_Unit char(15),
	@P_City char(55),
	@P_State char(2),
	@P_Zip char(9),
	@P_Plus4 char(4),
	@P_CarrierRoute char(4),
	@P_CountyName char(35),
	@P_DPBC char(12),
	@P_PrivateMailbox char(4),
	@P_Pmsa char(2),
	@P_Msa char(70),
	@P_ZipType char(2),
	@P_Urbanization char(6),
	@P_CongressionalDistrict char(2),
	@P_CountryCode char(10),
	@P_CityAbbreviation char(13),
	@P_AddressTypeCode char(1),
	@P_AddressTypeString char(60),
	@P_DPVCount char(5),
	@P_DPVFootnotes char(4),
	@P_CMRA char(1),
	@P_ELotNumber char(5),
	@P_ELotOrder char(2),
	@P_LACS char(1),
	@P_LACSLinkIndicator char(1),
	@P_EWSFlag char(1),
	@P_RBDI char(1),
	@P_SuiteLinkReturnCode char(1),
	@P_DeliveryPointCheckDigit char(1),
	@P_DeliveryPointCode char(2),
	@P_Verified bit,
	@P_AddressMatchResults char(30),
	@P_HouseNumber varchar(30)'

set @sql = '
INSERT INTO ' + @tableNameSTD + '
           (ID
           ,Fips
           ,HouseNumber
           ,StreetNumber
           ,PreDirection
           ,StreetName
           ,Suffix
           ,PostDirection
           ,UnitType
           ,Unit
           ,City
           ,State
           ,Zip
           ,Plus4
           ,CRRT
           ,CountyName
           ,PMB
           ,PMSA
           ,MSA
           ,ZipType
           ,Urbanization
           ,CongressionalDistrict
           ,CountryCode
           ,CityAbbreviation 
           ,AddressTypeCode
           ,AddressTypeString
           ,DPV_Count 
           ,DPV_Footnotes
           ,CMRA
           ,ELOT_Number
           ,ELOT_Order
           ,LACS
           ,LACS_LinkIndicator
           ,EWS_Flag
           ,RBDI
           ,SuiteLinkReturnCode
           ,DeliveryPointCheckDigit
           ,DeliveryPointCode
           ,Verified
           ,AddressMatchResults)
     VALUES
           (@P_ID, 
           @P_FIPS,
           @P_HouseNumber, 
           @P_StreetNumber,
           @P_PreDirection,
           @P_StreetName,
           @P_Suffix,
           @P_PostDirection,
           @P_UnitType, 
           @P_Unit, 
           @P_City, 
           @P_State,
           @P_Zip, 
           @P_Plus4,
           @P_CarrierRoute ,
           @P_CountyName ,
           @P_PrivateMailbox ,
           @P_Pmsa ,
           @P_Msa ,
           @P_ZipType ,
           @P_Urbanization ,
           @P_CongressionalDistrict ,
           @P_CountryCode ,
           @P_CityAbbreviation ,
           @P_AddressTypeCode,
           @P_AddressTypeString,
           @P_DPVCount,
           @P_DPVFootnotes ,
           @P_CMRA ,
           @P_ELotNumber ,
           @P_ELotOrder ,
           @P_LACS ,
           @P_LACSLinkIndicator ,
           @P_EWSFlag ,
           @P_RBDI ,
           @P_SuiteLinkReturnCode ,
           @P_DeliveryPointCheckDigit ,
           @P_DeliveryPointCode ,
           @P_Verified, 
           @P_AddressMatchResults)
'
execute sp_executesql @sql, @ParmDef, 
	@P_ID = @ID,
	@P_FIPS = @FIPS,
	@P_StreetNumber = @StreetNumber,
	@P_PreDirection = @PreDirection,
	@P_StreetName = @StreetName,
	@P_Suffix = @Suffix,
	@P_PostDirection = @PostDirection,
	@P_UnitType = @UnitType,
	@P_Unit = @Unit,
	@P_City = @City,
	@P_State = @State,
	@P_Zip = @Zip,
	@P_Plus4 = @Plus4,
	@P_CarrierRoute = @CarrierRoute,
	@P_CountyName = @CountyName,
	@P_DPBC = @DPBC,
	@P_PrivateMailbox = @PrivateMailbox ,
	@P_Pmsa = @Pmsa,
	@P_Msa = @Msa,
	@P_ZipType= @ZipType,
	@P_Urbanization = @Urbanization,
	@P_CongressionalDistrict = @CongressionalDistrict,
	@P_CountryCode = @CountryCode,
	@P_CityAbbreviation = @CityAbbreviation,
	@P_AddressTypeCode = @AddressTypeCode,
	@P_AddressTypeString = @AddressTypeString,
	@P_DPVCount = @DPVCount,
	@P_DPVFootnotes = @DPVFootnotes,
	@P_CMRA = @CMRA,
	@P_ELotNumber = @ELotNumber,
	@P_ELotOrder = @ELotOrder,
	@P_LACS = @LACS,
	@P_LACSLinkIndicator = @LACSLinkIndicator,
	@P_EWSFlag = @EWSFlag,
	@P_RBDI = @RBDI,
	@P_SuiteLinkReturnCode = @SuiteLinkReturnCode,
	@P_DeliveryPointCheckDigit = @DeliveryPointCheckDigit,
	@P_DeliveryPointCode = @DeliveryPointCode,
	@P_Verified = @Verified,
	@P_AddressMatchResults = @AddressMatchResults,
	@P_HouseNumber = @HouseNumber;

/*
	@P_CensusBlock char(4),
	@P_CensusTract char(6),
	@P_PlaceCode char(7),
	@P_PlaceName char(60),
	@P_CBSACode char(5),
	@P_CBSALevel char(30),
	@P_CBSATitle char(50),
	@P_CBSADivisionCode char(5),
	@P_CBSADivisionLevel char(30),
	@P_CBSADivisionTitle char(50),
	@P_Latitude numeric(10,6),
	@P_Longitude numeric(10,6),
	@P_Geocoded bit,
	@P_GeoErrorCode char(1),
	@P_GeoStatusCode char(1),
	@P_tableName varchar(30)'


	@P_CensusBlock = @CensusBlock,
	@P_CensusTract = @CensusTract,
	@P_PlaceCode = @PlaceCode,
	@P_PlaceName = @PlaceName,
	@P_CBSACode = @CBSACode,
	@P_CBSALevel = @CBSALevel,
	@P_CBSATitle = @CBSATitle,
	@P_CBSADivisionCode = @CBSADivisionCode,
	@P_CBSADivisionLevel = @CBSADivisionLevel,
	@P_CBSADivisionTitle = @CBSADivisionTitle,
	@P_Latitude = @Latitude,
	@P_Longitude = @Longitude,
	@P_Geocoded = @Geocoded,
	@P_GeoErrorCode = @GeoErrorCode,
	@P_GeoStatusCode = @GeoStatusCode,
	@P_tableName = @tableName,
*/


