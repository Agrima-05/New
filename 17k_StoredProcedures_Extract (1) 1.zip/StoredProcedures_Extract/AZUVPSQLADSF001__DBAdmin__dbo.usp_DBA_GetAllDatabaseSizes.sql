SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





/*
	Name:		usp_DBA_GetAllDatabaseSizes
	Author:		Raju Permandla
	Version:	16.0 (SQL 2022 Version 1)
	Purpose:	Insert information into tables in DBAdmin database about sizes of all the databases in the server instance
	Usage:		EXEC usp_DBA_GetAllDatabaseSizes
				EXEC usp_DBA_GetAllDatabaseSizes @Version = 1
	Comments:	
				Walk through usp_DBA_GetAllDatabaseSizes:
				1.) Create temporary tables to sum up information about the database.
				2.) Determine the record type and populate the variable.
				2.) Create the DBA_Database_Sizes table if it doesn't exist. If it exists the same table is used.
				3.) Check the structure of the table to verify it is correct and change if necessary.
				4.) Get list of databases on the server.
				5.) Calculate the data size, log size and the total database size.
				6.) After calculations finally insert them into the DBA_Database_Sizes table.

*/ 
CREATE PROCEDURE [dbo].[usp_DBA_GetAllDatabaseSizes]
	@Version bit = 0
AS

	DECLARE @Name sysname, @SQL nvarchar(1000), @RUNDATE datetime, @TYPE varchar(5), @ProcVersion varchar(5), @Print varchar(125);

	SET NOCOUNT ON;

	--Stored Procedure Version
	SET @ProcVersion = '11.1';
	IF @Version = 1
		BEGIN
			PRINT @@SERVERNAME + ', usp_DBA_GetAllDatabaseSizes, ' + @ProcVersion;
			RETURN;
		END

	SET @Print = cast(getdate() AS varchar(20)) + ' Starting DBAdmin.dbo.usp_DBA_GetAllDatabaseSizes';
	PRINT @Print + ' ' + replicate('=',125-len(@Print));
	SET @Print = 'Stored Procedure Version ' + @ProcVersion;
	PRINT @Print + ' ' + replicate('=',125-len(@Print));

	--Create temorary tables
	CREATE TABLE #LogSpace (
		[DBNAME]	varchar(100),
		[LOGSIZE]	float,
		[PRCNTUSED]	float,
		[STATUS]	int
	);

	CREATE TABLE #DataSpace (
		[FILEID]	int,
		[FILEGRP]	int,
		[TOTEXT]	int,
		[USDEXT]	int,
		[LFILENM]	varchar(1000),
		[PFILENM]	varchar(1000)
	);

	CREATE TABLE #Databases (
		[DATABASE_NAME] sysname NOT NULL,
		[DBSIZE]	numeric(15,4) NOT NULL,
		[LOGSIZE]	numeric(15,4)  NULL,
		[USEDDBSIZE]	numeric(15,4) NULL,
		[FREEDBSIZE]	numeric(15,4) NULL,
		[USEDLOGSIZE]	numeric(15,4) NULL,
		[FREELOGSIZE]	numeric(15,4) NULL,
		[DATABASESIZE]	numeric(15,4) NULL
	);

	--Get the current datetime
	SELECT @RUNDATE = getdate();

	--Determine the type (DWMQY) Day, Week, Month, Quarter, Year
	--Daily
	SET @TYPE = 'D'; --always daily
	--Week end
	IF (datepart(dw,@RUNDATE) = 7) SET @TYPE = @TYPE + 'W';
	--Month end so it Monthly
	IF ( (month(@RUNDATE) = 1 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 2 AND DAY(@RUNDATE) = 28) OR
				(month(@RUNDATE) = 3 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 4 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 5 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 6 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 7 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 8 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 9 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 10 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 11 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 12 AND DAY(@RUNDATE) = 31) ) SET @TYPE = @TYPE + 'M';
	--End of Quarter
	IF ( (month(@RUNDATE) = 3 AND DAY(@RUNDATE) = 31) OR
				(month(@RUNDATE) = 6 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 9 AND DAY(@RUNDATE) = 30) OR
				(month(@RUNDATE) = 12 AND DAY(@RUNDATE) = 31) ) SET @TYPE = @TYPE + 'Q';
	--Year end
	IF (datepart(d,@RUNDATE) = 31 AND datepart(m,@RUNDATE) = 12) SET @TYPE = @TYPE + 'Y';

	----------------------------------------------------------Get size information----------------------------------------------------------
	INSERT INTO #LogSpace EXEC ('DBCC SQLPERF(LOGSPACE)');

	--Create a cursor of database names
	DECLARE c1 CURSOR FOR SELECT [NAME] FROM master.sys.databases ORDER BY [NAME];

	OPEN c1;
	FETCH NEXT FROM c1 INTO @Name;
	WHILE @@fetch_status <> -1
		BEGIN
			--Get the filestats on each database
			SELECT @SQL = 'USE ' + quotename(@Name) + ' DBCC SHOWFILESTATS';
			--Errors when a database is in an abnormal state such as mirroring

			BEGIN TRY
				INSERT INTO #DataSpace EXEC (@SQL);
			END TRY
			BEGIN CATCH
				PRINT @@ERROR;
				PRINT ERROR_MESSAGE();
				GOTO MOVE_ON;
			END CATCH

			--Insert row for each database with data size
			SELECT @SQL = 'INSERT INTO #Databases ( [DATABASE_NAME], [DBSIZE] ) SELECT '''+ @Name + ''', sum(convert(dec(15),size))';
			SELECT @SQL = @SQL + ' from ' + quotename(@Name) + '.sys.sysfiles where (status & 64 = 0)';

			EXEC (@SQL);

			-- Update the record to set the log size
			SELECT @SQL = 'UPDATE #Databases SET [LOGSIZE] = ( SELECT cast(sum([size]) AS numeric(15,4)) FROM';
			SELECT @SQL = @SQL + ' ' + quotename(@Name) + '.sys.sysfiles WHERE (' + quotename(@Name);
			SELECT @SQL = @SQL + '.sys.sysfiles.[status] & 64 <> 0)) FROM ' + QuoteName(@Name);
			SELECT @SQL = @SQL + '.sys.sysfiles ,#Databases WHERE [DATABASE_NAME] = ''' + @Name + '''';
	
			EXEC (@SQL);

			-- Update the same record to add the total database size. 
			SELECT @SQL = 'UPDATE #Databases SET [DATABASESIZE] = (	SELECT cast(sum([size]) AS numeric(15,4)) FROM';
			SELECT @SQL = @SQL + ' ' + quotename(@Name) + '.sys.sysfiles ) FROM ' + QuoteName(@Name);
			SELECT @SQL = @SQL + '.sys.sysfiles ,#Databases where [DATABASE_NAME] = ''' + @Name + '''';
		
			EXEC (@SQL);

			-- Update the same record to add the used log size. 
			SELECT @SQL = 'UPDATE #Databases SET [USEDLOGSIZE] = ( SELECT [LOGSIZE] * ([PRCNTUSED]/100) FROM';
			SELECT @SQL = @SQL + ' #LogSpace WHERE [DBNAME] = ''' + @Name + ''') WHERE [DATABASE_NAME] = ''' + @Name + '''';
		
			EXEC (@SQL);

			-- Update the same record to add the free log size. 
			SELECT @SQL = 'UPDATE #Databases SET [FREELOGSIZE] = ( SELECT [LOGSIZE] - ([LOGSIZE] * ([PRCNTUSED]/100)) FROM';
			SELECT @SQL = @SQL + ' #LogSpace WHERE [DBNAME] = ''' + @Name + ''') WHERE [DATABASE_NAME] = ''' + @Name + '''';
		
			EXEC (@SQL);

			-- Update the same record to add the used database size. 
			SELECT @SQL = 'UPDATE #Databases SET [USEDDBSIZE] = ( SELECT (cast(sum([USDEXT]) AS numeric(15,4))*32)/512 FROM';
			SELECT @SQL = @SQL + ' #DataSpace) WHERE [DATABASE_NAME] = ''' + @Name + '''';

			EXEC (@SQL);

			SELECT @SQL = 'UPDATE #Databases SET [FREEDBSIZE] = ( SELECT (cast(sum([TOTEXT] - [USDEXT]) AS numeric(15,4))*32)/512 FROM';
			SELECT @SQL = @SQL + ' #DataSpace) WHERE [DATABASE_NAME] = ''' + @Name + '''';

			EXEC (@SQL);

	MOVE_ON:
			--clear the dataspace table
			DELETE FROM #DataSpace;
		
			--get the next @Name
			FETCH NEXT FROM c1 INTO @Name;
		END

	CLOSE c1;
	DEALLOCATE c1;

	set dateformat mdy 
	--************************************** Insert data into DBA_Database_Sizes table **************************************
	INSERT INTO DBAdmin.dbo.DBA_Database_Sizes (
		[RUN_DATE],
		[RUN_DT],
		[TYPE],
		[SERVER_NAME],
		[DATABASE_NAME],
		[TOTALDB_SIZE_MEGS],
		[DATA_FILE_SIZE_MEGS],
		[DATA_SIZE_USED_MEGS],
		[DATA_SIZE_FREE_MEGS],
		[LOG_FILE_SIZE_MEGS],
		[LOG_SIZE_USED_MEGS],
		[LOG_SIZE_FREE_MEGS]
	)
	(
	SELECT
	  convert(varchar(10),@RUNDATE,101),
		[RUN_DT] = @RUNDATE,
		[TYPE] = @TYPE,
		@@servername,
		[DATABASE_NAME],
		[DATABASE_SIZE_MEGS] = (([DATABASESIZE]*8)/1024.0),
		[DATA_SIZE_MEGS] = (([DBSIZE]*8)/1024.0),/* Convert data size from 8192 byte pages to K and to K to Megs*/
		[USEDDBSIZE] ,
		[FREEDBSIZE],
		[LOG_SIZE_MEGS] = (([LOGSIZE]*8)/1024.0),/* Convert log size from 8192 byte pages to K and K to Megs*/
		[USEDLOGSIZE],
		[FREELOGSIZE]
	FROM #Databases
	);

	SET @Print = cast(getdate() AS varchar(20)) + ' Finished DBAdmin.dbo.usp_DBA_GetAllDatabaseSizes';
	PRINT @Print + ' ' + replicate('=',125-len(@Print));

	DROP TABLE #Databases;
	DROP TABLE #DataSpace;
	DROP TABLE #LogSpace;




