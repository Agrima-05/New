SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

			CREATE procedure [dbo].[usp_102_sp_DragonAssrPost_UpdateTbl] (@tableName varchar(40)) 
			as  
			declare @sql varchar(max) = ''

				set @sql = '
				   UPDATE  [DragonAssr].[dbo].[DragonAssr_UpdateTbl_STD]
				   set [FullStreetAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetNumber])) + '' '' +  DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PreDir])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetName]))))) + '' '' + ltrim(rtrim(UPPER( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetType]))) + '' '' +  DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PostDir]))))  + '' '' + ltrim(rtrim(ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[SuiteType])) + '' '' + (ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Suite])))))))
					,[CountyFips]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CountyFips]))
					,[StreetNumber]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetNumber]))
					,[PreDir]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PreDir]))
					,[StreetName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetName]))
					,[StreetType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[StreetType]))
					,[PostDir]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PostDir]))
					,[SuiteType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[SuiteType]))
					,[Suite]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Suite]))
					,[City]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[City]))
					,[State]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[State]))
					,[Zip]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Zip]))
					,[Plus4]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Plus4]))
					,[CarrierRoute]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CarrierRoute]))
					,[CountyName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CountyName]))
					,[PrivateMailbox]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PrivateMailbox]))
					,[Pmsa]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Pmsa]))
					,[Msa]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Msa]))
					,[ZipType]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[ZipType]))
					,[Urbanization]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Urbanization]))
					,[CongressionalDistrict]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CongressionalDistrict]))
					,[CityAbbreviation]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CityAbbreviation]))
					,[AddressTypeCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[AddressTypeCode]))
					,[AddressTypeString]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[AddressTypeString]))
					,[DPVCount]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[DPVCount]))
					,[DPVFootnotes]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[DPVFootnotes]))
					,[CMRA]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CMRA]))
					,[ELotNumber]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[ELotNumber]))
					,[ELotOrder]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[ELotOrder]))
					,[Lacs]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Lacs]))
					,[LACSLinkIndicator]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[LACSLinkIndicator]))
					,[EWSFlag]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[EWSFlag]))
					,[RBDI]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[RBDI]))
					,[SuiteLinkReturnCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[SuiteLinkReturnCode]))
					,[DeliveryPointCheckDigit]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[DeliveryPointCheckDigit]))
					,[DeliveryPointCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[DeliveryPointCode]))
					,[Verified]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Verified]))
					,[AddressMatchResults]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[AddressMatchResults]))
					,[CensusBlock]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CensusBlock]))
					,[CensusTract]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CensusTract]))
					,[PlaceCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PlaceCode]))
					,[PlaceName]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[PlaceName]))
					,[CBSACode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSACode]))
					,[CBSALevel]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSALevel]))
					,[CBSATitle]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSATitle]))
					,[CBSADivisionCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSADivisionCode]))
					,[CBSADivisionLevel]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSADivisionLevel]))
					,[CBSADivisionTitle]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CBSADivisionTitle]))
					,[Latitude]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Latitude]))
					,[Longitude]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Longitude]))
					,[Geocoded]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[Geocoded]))
					,[GeoErrorCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[GeoErrorCode]))
					,[GeoStatusCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[GeoStatusCode]))
					,[GeoCodeResults]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[GeoCodeResults]))
					,[CountryCode]  = ltrim(rtrim( DragonAssr.[dbo].[DragonAssr_UpdateTbl_STD].[CountryCode]))


				 From  [DragonAssr].[dbo].[DragonAssr_UpdateTbl_STD]

				 	UPDATE
						Table_A
					SET
						Table_A.raw_id = Table_B.raw_id
					FROM
						 [DragonAssr].[dbo].[DragonAssr_UpdateTbl_STD] Table_A
					INNER JOIN
						 [DragonAssr].[dbo].[DragonAssr_UpdateTbl] Table_B
					ON
						Table_A.RecordId = Table_B.RecordId

				'
			print @sql
			exec (@sql)
