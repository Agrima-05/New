SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d005_DragonAssrLoad_Update_Looper]
AS
BEGIN
	SET NOCOUNT ON;


	TRUNCATE TABLE [dbo].[PropertyWorkUpdate]

		DECLARE @Date varchar(8)

	SET @Date = convert(varchar(8),Getdate(),112)

			EXEC [dbo].[d050_RunDragonAssrProcess_UPDATE] @Date



END
