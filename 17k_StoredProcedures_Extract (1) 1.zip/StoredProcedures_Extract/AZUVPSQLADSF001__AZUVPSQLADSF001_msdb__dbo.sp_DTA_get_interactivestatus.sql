SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
create procedure sp_DTA_get_interactivestatus
	@SessionID int 

as 
begin
	declare @retval  int							
	set nocount on

	exec @retval =  sp_DTA_check_permission @SessionID

	if @retval = 1
	begin
		raiserror(31002,-1,-1)
		return(1)
	end	
	select InteractiveStatus from [dbo].[DTA_input] where SessionID = @SessionID
end	

GRANT EXECUTE ON [dbo].[sp_DTA_get_interactivestatus] TO [public] AS [dbo]
