SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[001_Licensing_Legal_Update]

AS
BEGIN

		DROP TABLE DragonAssr.dbo.Licensing_Legal_PULL

		SELECT [fips]
			  ,[ref_id]
		INTO DragonAssr.dbo.Licensing_Legal_PULL
		  FROM [AZUVPSQLDTDB029.datatree.local].[LegalDescription].[dbo].[legal_desc_nationwide] 

		CREATE NONCLUSTERED INDEX [ix_REF_ID] ON [dbo].[Licensing_Legal_PULL]
		([ref_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		  DROP TABLE DragonAssr.dbo.Licensing_Legal_PULL_These

		  Select a.* INTO DragonAssr.dbo.Licensing_Legal_PULL_These
		  FROM  DragonAssr.dbo.Licensing_Legal_PULL a LEFT OUTER JOIN DragonAssr.dbo.Licensing_Legal b
		  ON a.ref_id = b.ref_id
		  WHERE b.ref_id is NULL

		  CREATE NONCLUSTERED INDEX [ix_FIPS_REF_ID] ON [dbo].[Licensing_Legal_PULL_These]
		([FIPS] ASC, [ref_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


		INSERT INTO dbo.Licensing_Legal([fips]
			  ,[ref_id]
			  ,[type]
			  ,[recording_date]
			  ,[document_number]
			  ,[doc_type]
			  ,[recording_date2]
			  ,[cmt_id]
			  ,[hist_sr_title_co_name]
			  ,[arms_length_id]
			  ,[hist_sr_tran_type]
			  ,[legal_desc])
		SELECT RIGHT('0' + convert(varchar(5),a.[fips]),5)
			  ,a.[ref_id]
			  ,a.[type]
			  ,a.[recording_date]
			  ,a.[document_number]
			  ,a.[doc_type]
			  ,a.[recording_date2]
			  ,a.[cmt_id]
			  ,a.[hist_sr_title_co_name]
			  ,a.[arms_length_id]
			  ,a.[hist_sr_tran_type]
			  ,a.[legal_desc]
		  FROM [AZUVPSQLDTDB029.datatree.local].[LegalDescription].[dbo].[legal_desc_nationwide] a with(NOLOCK) JOIN DragonAssr.dbo.Licensing_Legal_PULL_These b
		  on a.fips = b.Fips
		  and a.ref_id = b.ref_id



		update a 
		SET PropertyID = b.PropertyID
		FROM dbo.Licensing_Legal a JOIN data.dbo.Property b with(NOLOCK)
		on a.fips = b.fips
		and a.ref_id = b.DTDB_Ref_ID
END

