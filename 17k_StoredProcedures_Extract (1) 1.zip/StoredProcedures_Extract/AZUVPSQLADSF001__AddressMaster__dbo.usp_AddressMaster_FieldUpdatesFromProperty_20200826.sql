SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_FieldUpdatesFromProperty_20200826]
AS

BEGIN
	SET NOCOUNT ON;

	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Started.'

	DECLARE @FipsCode varchar(5)
	--DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
	-- EXEC AddressMaster.dbo.usp_AddressMaster_FieldUpdatesFromProperty

    -- PropertyID -------------------------------------------------------------------------------------------------------------------------------------
    /*
	select top 1000000 PropertyID,[PropertyIDMandA],[PropertySpatial],coalesce([PropertyIDMandA],[PropertySpatial],null) as PropertyID
	    from AddressMaster.[dbo].Address_Master with (nolock) where PropertyID != coalesce([PropertyIDMandA],[PropertySpatial],null)
	select count(*) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyID != coalesce([PropertyIDMandA],[PropertySpatial],null) -- 114071
	select CountyFips,count(CountyFips) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyID != coalesce([PropertyIDMandA],[PropertySpatial],null) group by CountyFips order by CountyFips
	*/
    -- select count(*) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyIDMandA is null and PropertySpatial is null -- 119,897,083
    -- select count(*) from AddressMaster.[dbo].Address_Master with (nolock) where PropertyID is null and (PropertyIDMandA is not null or PropertySpatial is not null) -- 87712513 -- 0
	--select top 100 PropertyID,[PropertyIDMandA],[PropertySpatial],coalesce([PropertyIDMandA],[PropertySpatial],null) as PropertyID,* from AddressMaster.[dbo].Address_Master with (nolock)
	--declare @t_cnt INT = 0;
	--WHILE @t_cnt < 91
	--BEGIN 
	--BEGIN TRANSACTION t_loop;
	--UPDATE top (1000000) A SET PropertyID = coalesce([PropertyIDMandA],[PropertySpatial],null) from AddressMaster.[dbo].Address_Master A 
	--	where PropertyID is null and (PropertyIDMandA is not null or PropertySpatial is not null); -- done
	--SET @t_cnt = @t_cnt + 1;
	--select @t_cnt;
	--COMMIT TRANSACTION t_loop
	--END

    -- Fix an issue with FIPS having 4 characters during quarterly process -- added 20200116 ------------------------------------------------------ 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
	    UPDATE AM 
        SET CountyFips = '0' + CountyFips 
	    from addressmaster.dbo.Address_Master AM 
	    where len(CountyFips) = 4 
	END


    -- CommunityName ------------------------------------------------------------------------------------------------------------------------------ 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.CommunityName = F.communityname, FATimestamp = getdate()  
	                  from AddressMaster.dbo.Address_Master A 
					  join fema.dbo.faflood F with (nolock) 
					  on A.CountyFips = F.FIPS and A.propertyid = F.propertyid 
					  where A.CountyFips = '''+@FipsCode+''' and F.FIPS = '''+@FipsCode+''' and A.CommunityName is null and (F.CommunityName is not null and F.CommunityName != '''')
				      ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	UPDATE A set A.CommunityName = F.CommunityName, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A with (nolock)
		join fema.dbo.faflood F with (nolock) on F.propertyid = A.propertyid 
		where A.CommunityName is null and (F.CommunityName is not null and F.CommunityName != '')

	UPDATE A set A.CommunityName = F.CommunityName, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A with (nolock)
		join fema.dbo.faflood F with (nolock) on F.fips = A.countyfips and F.propertyid = A.propertyid 
		where a.CommunityName <> F.CommunityName


	-- Municipality -------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' and A.Municipality is null and (P.Municipality is not null and P.Municipality != '''')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A with (nolock)
		join data.dbo.property P with (nolock) on P.propertyid = A.propertyid 
		where A.Municipality is null and (P.Municipality is not null and P.Municipality != '')

	UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A with (nolock)
		join data.dbo.property P with (nolock) on P.fips = A.countyfips and P.propertyid = A.propertyid 
		where a.Municipality <> p.Municipality


	-- SubdivisionName ------------------------------------------------------------------------------------------- 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
	    --DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' and A.SubdivisionName is null and (P.SubdivisionName is not null and P.SubdivisionName != '''')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A
		join data.dbo.property P with (nolock) on P.propertyid = A.propertyid 
		where A.SubdivisionName is null and (P.SubdivisionName is not null and P.SubdivisionName != '') 

	UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A 
		join data.dbo.property P with (nolock) on P.fips = A.countyfips and P.propertyid = A.propertyid 
		where A.SubdivisionName <> P.SubdivisionName


	-- PropertyClassID -------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' and A.PropertyClassID is null and (P.PropertyClassID is not null and P.PropertyClassID != '''')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A
		join data.dbo.property P with (nolock) on P.propertyid = A.propertyid 
		where A.PropertyClassID is null and (P.PropertyClassID is not null and P.PropertyClassID != '') 

	UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate() from AddressMaster.dbo.Address_Master A 
		join data.dbo.property P with (nolock) on P.fips = A.countyfips and P.propertyid = A.propertyid 
		where a.[PropertyClassID] <> p.[PropertyClassID]


	-- NonUSPSAddressIndicator ------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.NonUSPSAddressIndicator = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS03%'' and (A.NonUSPSAddressIndicator is null or A.NonUSPSAddressIndicator != ''Y'')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END


    -- NotCurrentlyDeliverable -------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN -- 2nd run done
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.NotCurrentlyDeliverable = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS17%'' and (A.NotCurrentlyDeliverable is null or NotCurrentlyDeliverable != ''Y'')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END


	-- DsfVacany / VacantIndicator ------------------------------------------------------------------------------------------- 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.DsfVacant = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS16%'' and (A.DsfVacant is null or A.DsfVacant != ''Y'')
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END


	-- Filler Ref_ID ------------------------------------------------------------------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.Ref_ID = ASSR.REF_ID, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A with (nolock) 
				  join Assr.dbo.Assr ASSR with (nolock) 
				  on A.propertyid  = ASSR.Lic_PropertyID and A.CountyFips = ASSR.Lic_Fips
				  where A.CountyFips = '''+@FipsCode+''' and A.Ref_ID is null
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END


	-- EffectiveDate ------------------------------------------------------------------------------------------------------------------------------
	---- Comment out after the quarterly process starts.
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	/*
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set FAEffectiveDate = ''20190101'', FAUCIDFlag = ''I'', FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A with (nolock) 
				  where A.CountyFips = '''+@FipsCode+''' and A.FAEffectiveDate is null
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
	*/

	-- Longitude and Latitude -----------------------------------------------------------------------------------------------------------------------------
	-- ,FALongitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL)
	-- ,FALatitude  = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL) 
	-- FARooftop=GTmagic, FA=DMP, Situs=Melissa, TP=BK
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	-- LoadDate = Date loaded to be processed by Melissa
	-- FATimestamp = Last time the record was updated
	-- FAEffectiveDate = Date record loaded into Address Master
	-- FAAddressParsed = Date record was processed through ASP

	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] WHERE FIPSCode < '60000' ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set Longitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL), Latitude = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL), FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = '''+@FipsCode+''' and A.propertyid = P.propertyid
				  join DigitalMap.dbo.BuildingFootprint D with (nolock)
				  on A.CountyFips = '''+@FipsCode+''' and A.propertyid = D.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and 
						A.Longitude != coalesce(D.FARooftopLongitude, P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
						A.Latitude != coalesce(D.FARooftopLatitude, P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	UPDATE A set Longitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL), Latitude = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL), FATimestamp = getdate()
		from AddressMaster.dbo.Address_Master A 
		join data.dbo.property P with (nolock) 
		on A.propertyid = P.propertyid
		join DigitalMap.dbo.BuildingFootprint D with (nolock)
		on A.propertyid = D.propertyid
		where A.Longitude != coalesce(D.FARooftopLongitude, P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
			  A.Latitude != coalesce(D.FARooftopLatitude, P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)

	/* Consdt approach manually ran
	BEGIN -- done
		DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] with (nolock) WHERE FIPSCode < '60000' ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
            EXEC('Update a set a.ConsdtLatitude = case when p.FARooftopLatitude is not null then p.FARooftopLatitude
                             when p.FAGeoStatusCode = ''Parcels'' then p.FALatitude
                             when p.SitusGeoCodeResults = ''GS05'' then p.SitusLatitude
                             when p.SitusGeoCodeResults = ''GS06'' then p.SitusLatitude
                             else a.Latitude end,
                         a.ConsdtLongitude = case when p.FARooftopLatitude is not null then p.FARooftopLongitude
                             when p.FAGeoStatusCode = ''Parcels'' then p.FALongitude
                             when p.SitusGeoCodeResults = ''GS05'' then p.SitusLongitude
                             when p.SitusGeoCodeResults = ''GS06'' then p.SitusLongitude
                             else a.longitude end, 
						 a.ConsdtSource = case when P.FARooftopLatitude is not null then ''TrueRoof''
                             when p.FAGeoStatusCode = ''Parcels'' then ''DMP-RT''
                             when p.SitusGeoCodeResults = ''GS05'' then ''Mel''
                             when p.SitusGeoCodeResults = ''GS06'' then ''Mel''
                             else ''Default'' end,
						FATimestamp = getdate()
                 FROM [AddressMaster].[dbo].[Address_Master] a inner join Data.dbo.Property p  with (nolock) on a.PropertyId = p.PropertyID
				 WHERE a.CountyFips = '''+@FipsCode+''' and p.FIPS = '''+@FipsCode+'''
				 ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
	*/

    -- send completed email -----------------------------------------------------------------------------------------------------------------------------
	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Successfully Completed.'

END
