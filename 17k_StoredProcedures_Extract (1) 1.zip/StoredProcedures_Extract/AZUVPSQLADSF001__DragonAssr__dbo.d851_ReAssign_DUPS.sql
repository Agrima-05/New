SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- Description:	Pull Forward Property INFO
-- =============================================
CREATE PROCEDURE [dbo].[d851_ReAssign_DUPS] @Fips varchar(5)--, @date varchar(8)

AS
BEGIN

	SET NOCOUNT ON;

	--DECLARE @Fips varchar(5) = '40027'
	DECLARE @date varchar(8)
	Select @date = convert(varchar(8),Getdate(),112)

				EXEC('Delete From a
				From global.dbo.property_master a JOIN (
						Select Fips,FAPropertyParent,Max(APN) MaxAPN
						from global.dbo.property_master 
						where Fips in('''+@Fips+''')
						and FAPropertyParent in(Select PropertyID from DragonAssr.dbo.PropertyWork_'+@Fips+' with(NOLOCK)
						where Fips in('''+@Fips+''')
							group by Fips,PropertyID
							having count(*) > 1)
						GROUP BY FIPS,FAPropertyParent
						) b
				ON a.FIPS = b.FIPS
				and a.FAPropertyParent = b.FAPropertyParent
				and a.APN = b.MaxAPN


			UPDATE a
				SET a.PropertyID = 99999999999
				FROM DragonAssr.dbo.PropertyWork_'+@Fips+' a
				WHERE a.PropertyID is null
			
			UPDATE a
				SET a.PropertyID = 99999999999
				FROM DragonAssr.dbo.PropertyWork_'+@Fips+' a JOIN (Select FIPS,PropertyID from DragonAssr.dbo.PropertyWork_'+@Fips+' with(NOLOCK)
							where Fips in('''+@Fips+''')
							group by Fips,PropertyID
							having count(*) > 1) b
				ON a.FIPS = b.FIPS
				and a.PropertyID = b.PropertyID

					BEGIN
							DECLARE @PropertyId_max1 bigint;
							DECLARE @u_PropertyID bigint;
							DECLARE @u_FIPS varchar(5);
							DECLARE @u_APN varchar(45);
							DECLARE @u_PID varchar(10);
							DECLARE @u_APNSeqNbr varchar(2);
							DECLARE @u_OldAPN varchar(31);
							DECLARE @u_FormattedAPN varchar(45);
							DECLARE @u_TaxAcctNbr varchar(45);
							DECLARE @u_RefID bigint;

								DECLARE c_Property_PropertyID CURSOR FOR 
									SELECT [PropertyID],[FIPS],[FormattedAPN],CASE WHEN [APNSeqNbr] = ''1'' THEN NULL ELSE [APNSeqNbr] END,OldAPN,[FormattedAPN],[VendorPID]
									,TaxAccountNumber,DTDB_REF_ID
									FROM DragonAssr.dbo.PropertyWork_'+@Fips+' WHERE PropertyID = 99999999999
									;

								SET @PropertyId_max1 = (SELECT max(FAPropertyId) FROM [Global].[dbo].[Property_Master] WITH (NOLOCK)) + 1;

								OPEN c_Property_PropertyID

								FETCH NEXT FROM c_Property_PropertyID INTO @u_PropertyID, @u_FIPS, @u_APN, @u_APNSeqNbr, @u_OldAPN
									, @u_FormattedAPN,@u_PID,@u_TaxAcctNbr,@u_RefID;
								WHILE @@FETCH_STATUS = 0
								BEGIN
									INSERT into global.dbo.Property_Master(FAPropertyId
									,FAPropertyParent
									,Fips
									,APN
									,DuplicateAPN
									,OldAPN
									,FormattedAPN
									,PID
									,TaxAccountNumber
									,DTDB_Ref_ID
									,FIPSinteger
									,Active
									,TruePropertyID
									,TrueAPN
									,DTDB_MatchFlag
									,[APN_change_date])
									VALUES (
										@PropertyId_max1
									   ,@PropertyId_max1
									   ,@u_FIPS
									   ,@u_APN
									   ,@u_APNSeqNbr
									   ,@u_OldAPN
									   ,@u_FormattedAPN
									   ,@u_PID
									   ,@u_TaxAcctNbr
									   ,@u_RefID
									   ,@u_FIPS
									   ,''Y''
									   ,@PropertyId_max1
									   ,@u_FormattedAPN
									   ,''D''
									   ,GETDATE())

								SET @PropertyId_max1 = @PropertyId_max1 + 1;

								FETCH NEXT FROM c_Property_PropertyID INTO @u_PropertyID, @u_FIPS, @u_APN, @u_APNSeqNbr, @u_OldAPN
									, @u_FormattedAPN,@u_PID,@u_TaxAcctNbr,@u_RefID;
								END;

								CLOSE c_Property_PropertyID;
								DEALLOCATE c_Property_PropertyID
						END


					UPDATE a
					SET PropertyID = b.FAPropertyId
					,FAUserID = ''New Parcel''
					FROM DragonAssr.dbo.PropertyWork_'+@Fips+' a JOIN Global.dbo.property_master b
					on a.FIPS = b.FIPS
					and a.FormattedAPN = b.APN
					WHERE b.Fips = '''+@Fips+'''
					AND PropertyID = 99999999999
			
					UPDATE a
					SET PropertyID = b.FAPropertyId
					,FAUserID = ''New Parcel''
					FROM DragonAssr.dbo.PropertyWork_'+@Fips+' a JOIN Global.dbo.property_master b
					on a.FIPS = b.FIPS
					and a.FormattedAPN = b.APN
					WHERE b.Fips = '''+@Fips+'''
					AND PropertyID <> FAPropertyID

				')
END


