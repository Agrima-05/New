SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create procedure [dbo].[usp_102_sp_AddressMaster_ASPPost] (@tableName varchar(40)) 
as  
declare @sql varchar(max) = ''

    set @sql = '
        UPDATE AddressMaster.[dbo].[AddressMaster_ASP_STD]
        set [AddressLine] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetNumber])) + '' '' + AddressMaster.[dbo].[AddressMaster_ASP_STD].[PreDir])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetName])))) + '' '' + ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetType])) + '' '' + AddressMaster.[dbo].[AddressMaster_ASP_STD].[PostDir]))))  + '' '' + ltrim(rtrim(ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[SuiteType])) + '' '' + (ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Suite])))))))
            ,[CountyFips]  = CASE WHEN len(ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CountyFips]))) = 4 THEN ''0'' + ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CountyFips])) ELSE ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CountyFips])) END
            ,[StreetNumber]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetNumber]))
            ,[PreDir]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[PreDir]))
            ,[StreetName]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetName]))
            ,[StreetType]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[StreetType]))
            ,[PostDir]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[PostDir]))
            ,[SuiteType]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[SuiteType]))
            ,[Suite]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Suite]))
            ,[City]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[City]))
            ,[State]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[State]))
            ,[Zip]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Zip]))
            ,[Plus4]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Plus4]))
            ,[CarrierRoute]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CarrierRoute]))
            ,[CountyName]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CountyName]))
            ,[PrivateMailbox]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[PrivateMailbox]))
            ,[Pmsa]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Pmsa]))
            ,[Msa]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Msa]))
            ,[ZipType]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[ZipType]))
            ,[Urbanization]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Urbanization]))
            ,[CongressionalDistrict]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CongressionalDistrict]))
            ,[CityAbbreviation]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CityAbbreviation]))
            ,[AddressTypeCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[AddressTypeCode]))
            ,[AddressTypeString]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[AddressTypeString]))
            ,[DPVCount]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DPVCount]))
            ,[DPVFootnotes]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DPVFootnotes]))
            ,[CMRA]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CMRA]))
            ,[ELotNumber]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[ELotNumber]))
            ,[ELotOrder]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[ELotOrder]))
            ,[Lacs]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Lacs]))
            ,[LACSLinkIndicator]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[LACSLinkIndicator]))
            ,[EWSFlag]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[EWSFlag]))
            ,[RBDI]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[RBDI]))
            ,[SuiteLinkReturnCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[SuiteLinkReturnCode]))
            ,[DeliveryPointCheckDigit]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DeliveryPointCheckDigit]))
            ,[DeliveryPointCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DeliveryPointCode]))
            ,[Verified]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Verified]))
            ,[AddressMatchResults]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[AddressMatchResults]))
            ,[CensusBlock]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CensusBlock]))
            ,[CensusTract]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CensusTract]))
            ,[PlaceCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[PlaceCode]))
            ,[PlaceName]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[PlaceName]))
            ,[CBSACode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSACode]))
            ,[CBSALevel]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSALevel]))
            ,[CBSATitle]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSATitle]))
            ,[CBSADivisionCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSADivisionCode]))
            ,[CBSADivisionLevel]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSADivisionLevel]))
            ,[CBSADivisionTitle]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CBSADivisionTitle]))
            ,[Latitude]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Latitude]))
            ,[Longitude]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Longitude]))
            ,[Geocoded]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Geocoded]))
            ,[GeoErrorCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[GeoErrorCode]))
            ,[GeoStatusCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[GeoStatusCode]))
            ,[GeoCodeResults]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[GeoCodeResults]))
            ,[CountryCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[CountryCode]))
                                  
			,[CityStateZip]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[City])) + '', '' + ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[State])) + '' '' + ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[Zip]))
			,[TimeZoneCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[TimeZoneCode]))
			,[TimeZone]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[TimeZone]))
			,[LACSLinkReturnCode]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[LACSLinkReturnCode]))
			,[AddressMatchResultString]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[AddressMatchResultString]))
			,[DsfNoStats]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DsfNoStats]))
			,[DsfDNA]  = ltrim(rtrim(AddressMaster.[dbo].[AddressMaster_ASP_STD].[DsfDNA]))
    From AddressMaster.[dbo].[AddressMaster_ASP_STD]
    '
    print @sql
    exec (@sql)

exec AddressMaster.dbo.usp_ASP_AddressMaster_to_AddressMaster
