SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[999Temp] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

-----------STEP 1

  update [Boundaries].[dlvry].[Structure_BATCH_REFRESH_ALL]
  Set PropertyID = p.Propertyid
  from [Boundaries].[dlvry].[Structure_BATCH_REFRESH_ALL] a
  join data..property p with (nolock)
  on p.fips = a.fips
  and p.dtdb_ref_id = a.refID
  where a.fips = @fips

INSERT INTO [Boundaries].[dbo].[zz_300GetStructure_Run]
           ([Fips],[DateTime])
 Select @fips,GetDate()

END

