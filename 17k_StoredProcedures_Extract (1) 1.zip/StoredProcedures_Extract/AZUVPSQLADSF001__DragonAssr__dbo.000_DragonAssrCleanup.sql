SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[000_DragonAssrCleanup]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @name varchar(50)
		DECLARE @Create datetime
		DECLARE @DATE varchar(8) = Convert(varchar(8),GetDate()-5,112)
		--PRINT @Date
		DECLARE CleanUpData CURSOR FOR  
			Select [name],create_date from sys.tables 
					where [name] like '%_2026[0-9][0-9][0-9][0-9]'
					and RIGHT([name],8) < @DATE


		OPEN CleanUpData   
		FETCH NEXT FROM CleanUpData INTO @name,@Create

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @name

			EXEC('DROP TABLE ' + @name + '')


			FETCH NEXT FROM CleanUpData INTO @name,@Create   
		END   

		CLOSE CleanUpData   
		DEALLOCATE CleanUpData 

END
