SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[DragonTaxUpdate]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
				-- interfering with SELECT statements.
				SET NOCOUNT ON;

Declare @Dt as varchar(8)
SET @Dt = Convert(varchar(8),GETDATE(),112)

Declare @name as varchar(50)
Declare @name2 as varchar(50)
SET @Name2 = 'dbo.Licensing_Deliverable_Dragon_CA_' + @Dt
SET @Name = 'dbo.Licensing_Deliverable_Bkup_' + @Dt



EXEC('select * 
INTO ' + @Name + '
from dbo.Licensing_Deliverable with(NOLOCK)
WHERE FIPS in(Select Distinct FIPS FROM [dbo].[Licensing_Deliverable_Dragon])
')

--EXEC('Select FIPS,COUNT(*) from ' + @Name + ' group by fips order by fips')
--Select FIPS,COUNT(*) from  dbo.Licensing_Deliverable WHERE FIPS in(6003,6027,6063,6099) group by fips order by fips

Delete from dbo.Licensing_Deliverable
where FIPS in(Select Distinct FIPS FROM [dbo].[Licensing_Deliverable_Dragon])

INSERT INTO dbo.Licensing_Deliverable([BillingId]
      ,[FIPS]
      ,[PAYEE_CODE]
      ,[PAYEE_PARCEL_NUMBER]
      ,[ASSESSOR_PARCEL_NUMBER]
      ,[TAX_YEAR_BEGIN]
      ,[TAX_YEAR_END]
      ,[FREQUENCY_SDESC]
      ,[INSTALLMENT_NUMBER_1]
      ,[BILL_NUMBER_1]
      ,[BASE_TAX_AMOUNT_1]
      ,[NET_TAX_AMOUNT_DUE_1]
      ,[CREDIT_BALANCE_1]
      ,[TAX_PAID_DATE_1]
      ,[TAX_PAID_IND_1]
      ,[ASSUMED_PAID_IND_1]
      ,[MULTIPLE_JURISDICTION_IND_1]
      ,[INSTALLMENT_NUMBER_2]
      ,[BILL_NUMBER_2]
      ,[BASE_TAX_AMOUNT_2]
      ,[NET_TAX_AMOUNT_DUE_2]
      ,[CREDIT_BALANCE_2]
      ,[TAX_PAID_DATE_2]
      ,[TAX_PAID_IND_2]
      ,[ASSUMED_PAID_IND_2]
      ,[MULTIPLE_JURISDICTION_IND_2]
      ,[INSTALLMENT_NUMBER_3]
      ,[BILL_NUMBER_3]
      ,[BASE_TAX_AMOUNT_3]
      ,[NET_TAX_AMOUNT_DUE_3]
      ,[CREDIT_BALANCE_3]
      ,[TAX_PAID_DATE_3]
      ,[TAX_PAID_IND_3]
      ,[ASSUMED_PAID_IND_3]
      ,[MULTIPLE_JURISDICTION_IND_3]
      ,[INSTALLMENT_NUMBER_4]
      ,[BILL_NUMBER_4]
      ,[BASE_TAX_AMOUNT_4]
      ,[NET_TAX_AMOUNT_DUE_4]
      ,[CREDIT_BALANCE_4]
      ,[TAX_PAID_DATE_4]
      ,[TAX_PAID_IND_4]
      ,[ASSUMED_PAID_IND_4]
      ,[MULTIPLE_JURISDICTION_IND_4]
      ,[EARLIEST_DELINQUENT_YEAR]
      ,[TOTAL_DELINQ_AMOUNT]
      ,[NO_OF_DELINQ_PAYMENTS_IN_SYSTEM]
      ,[TOTAL_BASE_TAX_AMOUNT]
      ,[TOTAL_NET_TAX_AMOUNT_DUE]
      ,[CREATED]
      ,[UPDATED]
      ,[FAPropertyID]
      ,[REF_ID]
      ,[Lic_APN]
      ,[Lic_FIPS]
      ,[Payee_Owner_of_Record]
      ,[Payee_Owner_Property_Address]
      ,[CurrentRecord])
Select [BillingId]
      ,[FIPS]
      ,[PAYEE_CODE]
      ,[PAYEE_PARCEL_NUMBER]
      ,[ASSESSOR_PARCEL_NUMBER]
      ,[TAX_YEAR_BEGIN]
      ,[TAX_YEAR_END]
      ,[FREQUENCY_SDESC]
      ,[INSTALLMENT_NUMBER_1]
      ,[BILL_NUMBER_1]
      ,[BASE_TAX_AMOUNT_1]
      ,[NET_TAX_AMOUNT_DUE_1]
      ,[CREDIT_BALANCE_1]
      ,[TAX_PAID_DATE_1]
      ,[TAX_PAID_IND_1]
      ,[ASSUMED_PAID_IND_1]
      ,[MULTIPLE_JURISDICTION_IND_1]
      ,[INSTALLMENT_NUMBER_2]
      ,[BILL_NUMBER_2]
      ,[BASE_TAX_AMOUNT_2]
      ,[NET_TAX_AMOUNT_DUE_2]
      ,[CREDIT_BALANCE_2]
      ,[TAX_PAID_DATE_2]
      ,[TAX_PAID_IND_2]
      ,[ASSUMED_PAID_IND_2]
      ,[MULTIPLE_JURISDICTION_IND_2]
      ,[INSTALLMENT_NUMBER_3]
      ,[BILL_NUMBER_3]
      ,[BASE_TAX_AMOUNT_3]
      ,[NET_TAX_AMOUNT_DUE_3]
      ,[CREDIT_BALANCE_3]
      ,[TAX_PAID_DATE_3]
      ,[TAX_PAID_IND_3]
      ,[ASSUMED_PAID_IND_3]
      ,[MULTIPLE_JURISDICTION_IND_3]
      ,[INSTALLMENT_NUMBER_4]
      ,[BILL_NUMBER_4]
      ,[BASE_TAX_AMOUNT_4]
      ,[NET_TAX_AMOUNT_DUE_4]
      ,[CREDIT_BALANCE_4]
      ,[TAX_PAID_DATE_4]
      ,[TAX_PAID_IND_4]
      ,[ASSUMED_PAID_IND_4]
      ,[MULTIPLE_JURISDICTION_IND_4]
      ,[EARLIEST_DELINQUENT_YEAR]
      ,[TOTAL_DELINQ_AMOUNT]
      ,[NO_OF_DELINQ_PAYMENTS_IN_SYSTEM]
      ,[TOTAL_BASE_TAX_AMOUNT]
      ,[TOTAL_NET_TAX_AMOUNT_DUE]
      ,[CREATED]
      ,GETDATE() as [UPDATED]
      ,[FAPropertyID]
      ,[REF_ID]
      ,[Lic_APN]
      ,[Lic_FIPS]
      ,[Payee_Owner_of_Record]
      ,[Payee_Owner_Property_Address]
      ,[CurrentRecord]
FROM Licensing_Deliverable_Dragon


EXEC('select * 
INTO ' + @Name2 + '
from [dbo].[Licensing_Deliverable_Dragon]
')

TRUNCATE Table Licensing_Deliverable_Dragon

END

