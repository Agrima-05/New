SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[InsertAddress--] (@fips int ) as 
Insert addr.dbo.DMaddr1231
(
	   [PARCEL_APN]
      ,[FIPS]
      ,[STREET_NUMBER]
      ,[PRE_DIRECTIONAL]
      ,[PREFIX]
      ,[STREET_NAME]
      ,[SUFFIX]
      ,[POST_DIRECTIONAL]
      ,[UNIT_TYPE]
      ,[UNIT]
      ,[CITY_NAME]
      ,[STATE_ABBR]
      ,[ZIP]
      ,[ZIP4]
      ,[X_COORD]
      ,[Y_COORD])
select 
       [PARCEL_APN]
      ,[FIPS]
      ,[STREET_NUMBER]
      ,[PRE_DIRECTIONAL]
      ,[PREFIX]
      ,[STREET_NAME]
      ,[SUFFIX]
      ,[POST_DIRECTIONAL]
      ,[UNIT_TYPE]
      ,[UNIT]
      ,[CITY_NAME]
      ,[STATE_ABBR]
      ,[ZIP]
      ,[ZIP4]
      ,[X_COORD]
      ,[Y_COORD]
 From Address_20121231.dbo.Address1231
 where fips = @fips


