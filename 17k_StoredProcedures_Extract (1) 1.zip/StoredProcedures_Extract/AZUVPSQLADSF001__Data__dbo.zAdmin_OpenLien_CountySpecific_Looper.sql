SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[zAdmin_OpenLien_CountySpecific_Looper] 
AS
BEGIN
	SET NOCOUNT OFF;

UPDATE JOBS.dbo.SystemProperty
SET [Value] = 'Y'
,[UpdateDate] = GETDATE()
WHERE [Name] = 'IsOpenLienRunning'

		DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT [FIPSCode] 
			FROM [Global].dbo.[County]
			WHERE FIPSCode in('17031','32003','48029','48085','48113','48201','48439')
			--WHERE FIPSCode in('01081','04013','06037','06065','17031','32003','48029','48085','48113','48201','48439')
			ORDER BY [FIPSCode]


		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC [dbo].[zAdmin_OpenLien_Freedom_NoNameCheck_CountySpecific] @FipsCode

			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 


UPDATE JOBS.dbo.SystemProperty
SET [Value] = 'N'
,[UpdateDate] = GETDATE()
WHERE [Name] = 'IsOpenLienRunning'




END


