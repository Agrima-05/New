SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
CREATE PROCEDURE [dbo].[cleanDatabase]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @TblName varchar(50)

		DECLARE curCleanDB CURSOR FOR  
			SELECT [name] FROM sys.tables with(NOLOCK)
			WHERE [name] like '%[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
				AND RIGHT([name],8) < Convert(varchar(8),Getdate()-30,112)
			ORDER BY [name]

		OPEN curCleanDB   
		FETCH NEXT FROM curCleanDB INTO @TblName

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @TblName

			EXEC('DROP TABLE dbo.' + @TblName + '')

			FETCH NEXT FROM curCleanDB INTO @TblName   
		END   

		CLOSE curCleanDB   
		DEALLOCATE curCleanDB 

END

