SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE Proc [dbo].[GetAddrFlatFileTriggerList]
AS
BEGIN
	Declare @tab as Table (TriggerId int
							, FullPath Varchar(max)
							, ProcessTypeCode Char(1)
							, Process_Flag Char(1)
							, CreatedDateTime DateTime
							, LastUpdatedDateTime DateTime
							, CompletedDateTime DateTime)

	Insert Into @tab (TriggerId, FullPath, ProcessTypeCode, Process_Flag, CreatedDateTime
						, LastUpdatedDateTime, CompletedDateTime)
	Select Top 1 T.TriggerId, T.FullPath, T.ProcessTypeCode, T.Process_Flag
				, T.CreatedDateTime, T.LastUpdatedDateTime, T.CompletedDateTime
	From STDFlatFileTrigger as T
	Where T.Process_Flag = 'R'
	Order by T.TriggerId
	
	Update AT
		Set AT.Process_Flag = 'I'
			, AT.LastUpdatedDateTime = GETDATE()
	From @tab as T
		Inner Join STDFlatFileTrigger as AT
			On T.TriggerId = AT.TriggerId

	Select T.TriggerId
		, FullPath = ISNULL(T.FullPath, '')
		, T.ProcessTypeCode as ProcessTypCode
		, T.Process_Flag as ProcessFlag
		, T.CreatedDateTime
		, T.LastUpdatedDateTime
		, T.CompletedDateTime
	From @tab T
	ORDER BY T.TriggerId ASC
END



