SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_201_TrainData] 
AS
BEGIN
	SET NOCOUNT ON;

	update m_FA_DMTraining set TaxAccountPattern = dbo.CreatePattern(PARCELAPN, TaxAccountNUmber, 0, 1), 
	FormattedApnPattern =  dbo.CreatePattern(PARCELAPN, FormattedAPN, 0, 1) where PARCELAPN <> ''



END


