SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[UpdateTH2016](@fips as varchar(5))
AS
BEGIN

update [Data_Archive].[dbo].[ValueHist_Review]
  Set
       [AssdLandValue2016] = [AssdLandValue]
      ,[AssdImprovementValue2016] = [AssdImprovementValue]
      ,[AssdTotalValue2016] = [AssdTotalValue]
      ,[AssdYear2016] = [AssdYear]
      ,[MarketValueLand2016] = [MarketValueLand]
      ,[MarketValueImprovement2016] = [MarketValueImprovement]
      ,[MarketTotalValue2016] = [MarketTotalValue]
      ,[MarketValueYear2016] = [MarketValueYear]
from [Data_Archive].[dbo].[ValueHist_Review] r
join [Data_Archive].[dbo].[ValueHist_2016] v
on v.fips = r.fips
and v.PropertyID = r.propertyid
where r.fips = @fips 
--v.AssdYear = '2016'

INSERT INTO [Data_Archive].[dbo].[ValueHist_2016_Run]
           ([FIPS]
           ,[cnt])
 Select @fips, 1

END

