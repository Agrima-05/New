SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_check_db_disk_space_index] --(@T_DATABASE varchar(255))
AS
BEGIN

--use @T_DATABASE;

SET NOCOUNT ON

-- get database name and report date --
SELECT substring('########## ' + DB_NAME() + ' ########## Report Date: ' + cast(GETDATE() as varchar(20)),1,80)

-- Allocated_Space, Available_Space, Available_% -- 
;WITH t(s) AS
(
  SELECT CONVERT(DECIMAL(18,2), SUM(cast(size as bigint))*8/1024.0)
   FROM sys.database_files
   WHERE [type] % 2 = 0
), 
d(s) AS
(
  SELECT CONVERT(DECIMAL(18,2), SUM(total_pages)*8/1024.0)
   FROM sys.partitions AS p
   INNER JOIN sys.allocation_units AS a 
   ON p.[partition_id] = a.container_id
)
SELECT 
  Allocated_Space = t.s, 
  Available_Space = t.s - d.s,
  [Available_%] = CONVERT(DECIMAL(5,2), (t.s - d.s)*100.0/t.s)
FROM t CROSS APPLY d;

-- list disk space --
SELECT substring(name,1,30),size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS int)/128.0 AS AvailableSpaceInMB FROM sys.database_files; -- space per data files

-- List table sizes --
SELECT 
    substring(t.NAME,1,30) AS TableName,
    substring(s.Name,1,10) AS SchemaName,
    p.rows AS RowCounts,
    SUM(a.total_pages) * 8 AS TotalSpaceKB, 
    SUM(a.used_pages) * 8 AS UsedSpaceKB, 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 AS UnusedSpaceKB
FROM sys.tables t
INNER JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN sys.schemas s ON t.schema_id = s.schema_id
WHERE t.NAME NOT LIKE 'dt%' AND t.is_ms_shipped = 0 AND i.OBJECT_ID > 255 
GROUP BY t.Name, s.Name, p.Rows
ORDER BY t.Name

-- Check fragmentation percentage --
SELECT substring(OBJECT_NAME(ind.OBJECT_ID),1,30) as TableName, 
       substring(ind.name,1,50) AS IndexName, 
	   substring(indexstats.index_type_desc,1,30) AS IndexType, 
       indexstats.avg_fragmentation_in_percent 
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) indexstats 
INNER JOIN sys.indexes ind (nolock)
ON ind.object_id = indexstats.object_id 
AND ind.index_id = indexstats.index_id 
--WHERE indexstats.avg_fragmentation_in_percent > 0 
ORDER BY indexstats.avg_fragmentation_in_percent DESC

-- build index command to rebuild --
DECLARE @SchemaName VARCHAR(256)DECLARE @TableName VARCHAR(256)
DECLARE @IndexName VARCHAR(256)
DECLARE @TSQLDropIndex VARCHAR(256)
DECLARE CursorIndexes CURSOR FOR
 SELECT schema_name(t.schema_id), t.name,  i.name 
 FROM sys.indexes i
 INNER JOIN sys.tables t ON t.object_id= i.object_id
 WHERE i.type>0 and t.is_ms_shipped=0 and t.name<>'sysdiagrams'
 --and (is_primary_key=0 and is_unique_constraint=0)
OPEN CursorIndexes
FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName
WHILE @@fetch_status = 0
BEGIN
 --SET @TSQLDropIndex = 'ALTER INDEX '+QUOTENAME(@SchemaName)+ '.' + QUOTENAME(@TableName) + '.' +QUOTENAME(@IndexName) + ' REBUILD'
 SET @TSQLDropIndex = 'ALTER INDEX ' + QUOTENAME(@IndexName) + ' ON ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName) + ' REBUILD;'
 SELECT substring(@TSQLDropIndex,1,140)
 -- PRINT @TSQLDropIndex
 FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName
END
CLOSE CursorIndexes
DEALLOCATE CursorIndexes 

SET NOCOUNT OFF

END

