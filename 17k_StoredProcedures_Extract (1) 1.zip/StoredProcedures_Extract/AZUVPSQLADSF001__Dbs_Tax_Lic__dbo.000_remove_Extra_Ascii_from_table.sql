SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[000_remove_Extra_Ascii_from_table] 
AS
BEGIN
	SET NOCOUNT ON;

			DROP INDEX IF EXISTS [ix_Updated] ON [dbo].[Licensing_Deliverable]

			CREATE NONCLUSTERED INDEX [ix_Updated] ON [dbo].[Licensing_Deliverable]
			(
				[UPDATED] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	DECLARE @colName VARCHAR(255)
	DECLARE @prec VARCHAR(255)
	DECLARE @sqlCmd VARCHAR(max)
	DECLARE @Table varchar(100) = 'Licensing_Deliverable'

	DECLARE db_cursor CURSOR FOR  

	SELECT c.name ColumnName
	FROM sys.columns c with(NOLOCK) INNER JOIN
		 sys.tables t with(NOLOCK) ON c.object_id = t.object_id INNER JOIN
		 sys.schemas s with(NOLOCK) ON t.schema_id = s.schema_id
	where t.name = @table 
	and c.System_type_id not in(40,42,48,52,56,61,62,104,106,108,127)
	--and c.Name >= 'Party3_Name1_last_Company_Name'
	order by ColumnName

	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @colName   

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		BEGIN
				EXEC('UPDATE Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = data.dbo.RemoveNonASCII(['+@colName+'])
				WHERE ['+@colName+'] is not null AND UPDATED > GETDATE()-3 AND
				((patindex(''%['' + char(0) + ''-'' + char(31) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0)
				OR (patindex(''%['' + char(127) + ''-'' + char(255) + '']%'', ['+@colName+'] COLLATE Latin1_General_BIN2) > 0))')

				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''|'','''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%|%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''{'','''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%{%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],''}'','''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%}%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(34),'''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%'' + char(34) + ''%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(39),'''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%'' + char(39) + ''%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(13),'''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%'' + char(13) + ''%''')
				
				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = replace(['+@colName+'],char(10),'''')
				WHERE ['+@colName+'] is NOT NULL AND UPDATED > GETDATE()-3 AND ['+@colName+'] LIKE ''%'' + char(10) + ''%''')

				EXEC('update Dbs_Tax_Lic.dbo.'+@table+' set ['+@colName+'] = NULL where ['+@colName+'] = ''*'' AND UPDATED > GETDATE()-3')

		END
		FETCH NEXT FROM db_cursor INTO @colName
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

END

