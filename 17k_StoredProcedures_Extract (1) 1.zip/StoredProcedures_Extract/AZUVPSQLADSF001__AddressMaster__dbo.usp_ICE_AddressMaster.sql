SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author: Gary Mathes
-- Create date: 20180713
-- Description:	ICE report for infutor assessment data
-- =============================================
CREATE PROCEDURE [dbo].[usp_ICE_AddressMaster]
AS
BEGIN
	SET NOCOUNT ON;

-- EXEC AddressMaster.[dbo].[usp_ICE_AddressMaster]

-- delete ICE data
TRUNCATE TABLE [AddressMaster].[dbo].[z_ICE_AddressMaster]

-- populate each fields counts
-- Create new ICE reports
INSERT INTO [AddressMaster].[dbo].[z_ICE_AddressMaster]
	  ([CountyFips]
		--        ,[State]
		--        ,[CountyName]
	  ,[TotalCnt]
      ,[AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      --,[CountyFips]
      ,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
	  ,[Id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
      ,[MatchCodeMandA]
      ,[MatchCodeSpatial]
      ,[PropertyID]
      ,[PropertyIDMandA]
      ,[PropertySpatial]
      ,[MatchMethodSpatial]
      ,[AddressHash]
      --,[FATimestamp]
      ,[FAUserId]
      ,[FAUCIDFlag]
      ,[NonUSPSAddressIndicator]
      ,[NotCurrentlyDeliverable]
      ,[CommunityName]
      ,[Municipality]
      ,[PostalCommunity]
      ,[SubdivisionName]
      ,[PropertyClassID]
      --,[FAEffectiveDate]
      --,[FAExpirationDate]
      ,[Ref_ID]
      ,[AddressMasterID])
Select
		CountyFips
		--,County.[State]
		--,County.[CountyName]
	  ,sum(CASE WHEN (len(ltrim(rtrim(state))) > 0 and state <> '0') THEN 1 ELSE 0 END) AS TotalCnt
	  ,sum(CASE WHEN (len(ltrim(rtrim(AddressLine))) > 0 and AddressLine <> '0') THEN 1 ELSE 0 END) AS AddressLine
      ,sum(CASE WHEN (len(ltrim(rtrim(Address2))) > 0 and Address2 <> '0') THEN 1 ELSE 0 END) AS Address2
      ,sum(CASE WHEN (len(ltrim(rtrim(CityStateZip))) > 0 and CityStateZip <> '0') THEN 1 ELSE 0 END) AS CityStateZip
      ,sum(CASE WHEN (len(ltrim(rtrim(PreDir))) > 0 and PreDir <> '0') THEN 1 ELSE 0 END) AS PreDir
      ,sum(CASE WHEN (len(ltrim(rtrim(StreetNumber))) > 0 and StreetNumber <> '0') THEN 1 ELSE 0 END) AS StreetNumber
      ,sum(CASE WHEN (len(ltrim(rtrim(StreetName))) > 0 and StreetName <> '0') THEN 1 ELSE 0 END) AS StreetName
      ,sum(CASE WHEN (len(ltrim(rtrim(PostDir))) > 0 and PostDir <> '0') THEN 1 ELSE 0 END) AS PostDir
      ,sum(CASE WHEN (len(ltrim(rtrim(StreetType))) > 0 and StreetType <> '0') THEN 1 ELSE 0 END) AS StreetType
      ,sum(CASE WHEN (len(ltrim(rtrim(SuiteType))) > 0 and SuiteType <> '0') THEN 1 ELSE 0 END) AS SuiteType
      ,sum(CASE WHEN (len(ltrim(rtrim(Suite))) > 0 and Suite <> '0') THEN 1 ELSE 0 END) AS Suite
      ,sum(CASE WHEN (len(ltrim(rtrim(City))) > 0 and City <> '0') THEN 1 ELSE 0 END) AS City
      ,sum(CASE WHEN (len(ltrim(rtrim(Zip))) > 0 and Zip <> '0') THEN 1 ELSE 0 END) AS Zip
      ,sum(CASE WHEN (len(ltrim(rtrim(Plus4))) > 0 and Plus4 <> '0') THEN 1 ELSE 0 END) AS Plus4
      ,sum(CASE WHEN (len(ltrim(rtrim(PrivateMailbox))) > 0 and PrivateMailbox <> '0') THEN 1 ELSE 0 END) AS PrivateMailbox
      ,sum(CASE WHEN (len(ltrim(rtrim(Pmsa))) > 0 and Pmsa <> '0') THEN 1 ELSE 0 END) AS Pmsa
      ,sum(CASE WHEN (len(ltrim(rtrim(Msa))) > 0 and Msa <> '0') THEN 1 ELSE 0 END) AS Msa
      ,sum(CASE WHEN (len(ltrim(rtrim(ZipType))) > 0 and ZipType <> '0') THEN 1 ELSE 0 END) AS ZipType
      ,sum(CASE WHEN (len(ltrim(rtrim(Urbanization))) > 0 and Urbanization <> '0') THEN 1 ELSE 0 END) AS Urbanization
      ,sum(CASE WHEN (len(ltrim(rtrim(TimeZoneCode))) > 0 and TimeZoneCode <> '0') THEN 1 ELSE 0 END) AS TimeZoneCode
      ,sum(CASE WHEN (len(ltrim(rtrim(TimeZone))) > 0 and TimeZone <> '0') THEN 1 ELSE 0 END) AS TimeZone
      ,sum(CASE WHEN (len(ltrim(rtrim(CongressionalDistrict))) > 0 and CongressionalDistrict <> '0') THEN 1 ELSE 0 END) AS CongressionalDistrict
      ,sum(CASE WHEN (len(ltrim(rtrim(CountryCode))) > 0 and CountryCode <> '0') THEN 1 ELSE 0 END) AS CountryCode
      --,sum(CASE WHEN (len(ltrim(rtrim(CountyFips))) > 0 and CountyFips <> '0') THEN 1 ELSE 0 END) AS CountyFips
      ,sum(CASE WHEN (len(ltrim(rtrim(CountyName))) > 0 and CountyName <> '0') THEN 1 ELSE 0 END) AS CountyName
      ,sum(CASE WHEN (len(ltrim(rtrim(CityAbbreviation))) > 0 and CityAbbreviation <> '0') THEN 1 ELSE 0 END) AS CityAbbreviation
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressTypeString))) > 0 and AddressTypeString <> '0') THEN 1 ELSE 0 END) AS AddressTypeString
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressTypeCode))) > 0 and AddressTypeCode <> '0') THEN 1 ELSE 0 END) AS AddressTypeCode
      ,sum(CASE WHEN (len(ltrim(rtrim(DPVFootNotes))) > 0 and DPVFootNotes <> '0') THEN 1 ELSE 0 END) AS DPVFootNotes
      ,sum(CASE WHEN (len(ltrim(rtrim(CarrierRoute))) > 0 and CarrierRoute <> '0') THEN 1 ELSE 0 END) AS CarrierRoute
      ,sum(CASE WHEN (len(ltrim(rtrim(ELotOrder))) > 0 and ELotOrder <> '0') THEN 1 ELSE 0 END) AS ELotOrder
      ,sum(CASE WHEN (len(ltrim(rtrim(ELotNumber))) > 0 and ELotNumber <> '0') THEN 1 ELSE 0 END) AS ELotNumber
      ,sum(CASE WHEN (len(ltrim(rtrim(Lacs))) > 0 and Lacs <> '0') THEN 1 ELSE 0 END) AS Lacs
      ,sum(CASE WHEN (len(ltrim(rtrim(LACSLinkIndicator))) > 0 and LACSLinkIndicator <> '0') THEN 1 ELSE 0 END) AS LACSLinkIndicator
      ,sum(CASE WHEN (len(ltrim(rtrim(LACSLinkReturnCode))) > 0 and LACSLinkReturnCode <> '0') THEN 1 ELSE 0 END) AS LACSLinkReturnCode
      ,sum(CASE WHEN (len(ltrim(rtrim(EWSFlag))) > 0 and EWSFlag <> '0') THEN 1 ELSE 0 END) AS EWSFlag
      ,sum(CASE WHEN (len(ltrim(rtrim(RBDI))) > 0 and RBDI <> '0') THEN 1 ELSE 0 END) AS RBDI
      ,sum(CASE WHEN (len(ltrim(rtrim(SuiteLinkReturnCode))) > 0 and SuiteLinkReturnCode <> '0') THEN 1 ELSE 0 END) AS SuiteLinkReturnCode
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressMatchResults))) > 0 and AddressMatchResults <> '0') THEN 1 ELSE 0 END) AS AddressMatchResults
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressMatchResultString))) > 0 and AddressMatchResultString <> '0') THEN 1 ELSE 0 END) AS AddressMatchResultString
      ,sum(CASE WHEN (len(ltrim(rtrim(DeliveryPointCheckDigit))) > 0 and DeliveryPointCheckDigit <> '0') THEN 1 ELSE 0 END) AS DeliveryPointCheckDigit
      ,sum(CASE WHEN (len(ltrim(rtrim(DeliveryPointCode))) > 0 and DeliveryPointCode <> '0') THEN 1 ELSE 0 END) AS DeliveryPointCode
      ,sum(CASE WHEN (len(ltrim(rtrim(Latitude))) > 0 and Latitude <> '0') THEN 1 ELSE 0 END) AS Latitude
      ,sum(CASE WHEN (len(ltrim(rtrim(Longitude))) > 0 and Longitude <> '0') THEN 1 ELSE 0 END) AS Longitude
      ,sum(CASE WHEN (len(ltrim(rtrim(GeoErrorCode))) > 0 and GeoErrorCode <> '0') THEN 1 ELSE 0 END) AS GeoErrorCode
      ,sum(CASE WHEN (len(ltrim(rtrim(GeoStatusCode))) > 0 and GeoStatusCode <> '0') THEN 1 ELSE 0 END) AS GeoStatusCode
      ,sum(CASE WHEN (len(ltrim(rtrim(GeoCodeResults))) > 0 and GeoCodeResults <> '0') THEN 1 ELSE 0 END) AS GeoCodeResults
      ,sum(CASE WHEN (len(ltrim(rtrim(CensusTract))) > 0 and CensusTract <> '0') THEN 1 ELSE 0 END) AS CensusTract
      ,sum(CASE WHEN (len(ltrim(rtrim(CensusBlock))) > 0 and CensusBlock <> '0') THEN 1 ELSE 0 END) AS CensusBlock
      ,sum(CASE WHEN (len(ltrim(rtrim(PlaceCode))) > 0 and PlaceCode <> '0') THEN 1 ELSE 0 END) AS PlaceCode
      ,sum(CASE WHEN (len(ltrim(rtrim(PlaceName))) > 0 and PlaceName <> '0') THEN 1 ELSE 0 END) AS PlaceName
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSACode))) > 0 and CBSACode <> '0') THEN 1 ELSE 0 END) AS CBSACode
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSALevel))) > 0 and CBSALevel <> '0') THEN 1 ELSE 0 END) AS CBSALevel
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSATitle))) > 0 and CBSATitle <> '0') THEN 1 ELSE 0 END) AS CBSATitle
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSADivisionCode))) > 0 and CBSADivisionCode <> '0') THEN 1 ELSE 0 END) AS CBSADivisionCode
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSADivisionTitle))) > 0 and CBSADivisionTitle <> '0') THEN 1 ELSE 0 END) AS CBSADivisionTitle
      ,sum(CASE WHEN (len(ltrim(rtrim(CBSADivisionLevel))) > 0 and CBSADivisionLevel <> '0') THEN 1 ELSE 0 END) AS CBSADivisionLevel
      ,sum(CASE WHEN (len(ltrim(rtrim(CMRA))) > 0 and CMRA <> '0') THEN 1 ELSE 0 END) AS CMRA
      ,sum(CASE WHEN (len(ltrim(rtrim(Verified))) > 0 and Verified <> '0') THEN 1 ELSE 0 END) AS Verified
      ,sum(CASE WHEN (len(ltrim(rtrim(Geocoded))) > 0 and Geocoded <> '0') THEN 1 ELSE 0 END) AS Geocoded
      ,sum(CASE WHEN (len(ltrim(rtrim(LoadDate))) > 0 and LoadDate <> '0') THEN 1 ELSE 0 END) AS LoadDate
      ,sum(CASE WHEN (len(ltrim(rtrim(DsfNoStats))) > 0 and DsfNoStats <> '0') THEN 1 ELSE 0 END) AS DsfNoStats
      ,sum(CASE WHEN (len(ltrim(rtrim(DsfVacant))) > 0 and DsfVacant <> '0') THEN 1 ELSE 0 END) AS DsfVacant
      ,sum(CASE WHEN (len(ltrim(rtrim(DsfDNA))) > 0 and DsfDNA <> '0') THEN 1 ELSE 0 END) AS DsfDNA
	  ,sum(CASE WHEN (len(ltrim(rtrim(id))) > 0 and  id <> '0') THEN 1 ELSE 0 END) AS Id
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressKey))) > 0 and AddressKey <> '0') THEN 1 ELSE 0 END) AS AddressKey
      ,sum(CASE WHEN (len(ltrim(rtrim(Company))) > 0 and Company <> '0') THEN 1 ELSE 0 END) AS Company
      ,sum(CASE WHEN (len(ltrim(rtrim(MelissaAddressKey))) > 0 and MelissaAddressKey <> '0') THEN 1 ELSE 0 END) AS MelissaAddressKey
      ,sum(CASE WHEN (len(ltrim(rtrim(MelissaAddressKeyBase))) > 0 and MelissaAddressKeyBase <> '0') THEN 1 ELSE 0 END) AS MelissaAddressKeyBase
      ,sum(CASE WHEN (len(ltrim(rtrim(SuiteStatus))) > 0 and SuiteStatus <> '0') THEN 1 ELSE 0 END) AS SuiteStatus
      ,sum(CASE WHEN (len(ltrim(rtrim(MatchCodeMandA))) > 0 and MatchCodeMandA <> '0') THEN 1 ELSE 0 END) AS MatchCodeMandA
      ,sum(CASE WHEN (len(ltrim(rtrim(MatchCodeSpatial))) > 0 and MatchCodeSpatial <> '0') THEN 1 ELSE 0 END) AS MatchCodeSpatial
      ,sum(CASE WHEN (len(ltrim(rtrim(PropertyID))) > 0 and PropertyID <> '0') THEN 1 ELSE 0 END) AS PropertyID
      ,sum(CASE WHEN (len(ltrim(rtrim(PropertyIDMandA))) > 0 and PropertyIDMandA <> '0') THEN 1 ELSE 0 END) AS PropertyIDMandA
      ,sum(CASE WHEN (len(ltrim(rtrim(PropertySpatial))) > 0 and PropertySpatial <> '0') THEN 1 ELSE 0 END) AS PropertySpatial
      ,sum(CASE WHEN (len(ltrim(rtrim(MatchMethodSpatial))) > 0 and MatchMethodSpatial <> '0') THEN 1 ELSE 0 END) AS MatchMethodSpatial
      ,sum(CASE WHEN (len(ltrim(rtrim(AddressHash))) > 0 and AddressHash <> '0') THEN 1 ELSE 0 END) AS AddressHash
	  --,sum(CASE WHEN (len(ltrim(rtrim(FATimestamp))) > 0 and FATimestamp <> '0') THEN 1 ELSE 0 END) AS FATimestamp
	  ,sum(CASE WHEN (len(ltrim(rtrim(FAUserId))) > 0 and FAUserId <> '0') THEN 1 ELSE 0 END) AS FAUserId
	  ,sum(CASE WHEN (len(ltrim(rtrim(FAUCIDFlag))) > 0 and FAUCIDFlag <> '0') THEN 1 ELSE 0 END) AS FAUCIDFlag
	  ,sum(CASE WHEN (len(ltrim(rtrim(NonUSPSAddressIndicator))) > 0 and NonUSPSAddressIndicator <> '0') THEN 1 ELSE 0 END) AS NonUSPSAddressIndicator
	  ,sum(CASE WHEN (len(ltrim(rtrim(NotCurrentlyDeliverable))) > 0 and NotCurrentlyDeliverable <> '0') THEN 1 ELSE 0 END) AS NotCurrentlyDeliverable
	  ,sum(CASE WHEN (len(ltrim(rtrim(CommunityName))) > 0 and CommunityName <> '0') THEN 1 ELSE 0 END) AS CommunityName
	  ,sum(CASE WHEN (len(ltrim(rtrim(Municipality))) > 0 and Municipality <> '0') THEN 1 ELSE 0 END) AS Municipality
	  ,sum(CASE WHEN (len(ltrim(rtrim(PostalCommunity))) > 0 and PostalCommunity <> '0') THEN 1 ELSE 0 END) AS PostalCommunity
	  ,sum(CASE WHEN (len(ltrim(rtrim(SubdivisionName))) > 0 and SubdivisionName <> '0') THEN 1 ELSE 0 END) AS SubdivisionName
	  ,sum(CASE WHEN (len(ltrim(rtrim(PropertyClassID))) > 0 and PropertyClassID <> '0') THEN 1 ELSE 0 END) AS PropertyClassID
	  --,sum(CASE WHEN (len(ltrim(rtrim(FAEffectiveDate))) > 0 and FAEffectiveDate <> '0') THEN 1 ELSE 0 END) AS FAEffectiveDate
	  --,sum(CASE WHEN (len(ltrim(rtrim(FAExpirationDate))) > 0 and FAExpirationDate <> '0') THEN 1 ELSE 0 END) AS FAExpirationDate
	  ,sum(CASE WHEN (len(ltrim(rtrim(Ref_ID))) > 0 and Ref_ID <> '0') THEN 1 ELSE 0 END) AS Ref_ID
	  ,sum(CASE WHEN (len(ltrim(rtrim(AddressMasterID))) > 0 and AddressMasterID <> '0') THEN 1 ELSE 0 END) AS AddressMasterID
	  from [AddressMaster].[dbo].[Address_Master] with (nolock)
group by CountyFips
order by CountyFips

Update A
SET A.[State] = C.[State], A.[CountyName] = C.[County Name], A.[DATERUN] = GETDATE()
FROM [AddressMaster].[dbo].[z_ICE_AddressMaster] A INNER JOIN Global.dbo.County C ON A.CountyFips = C.[FIPSCODE]

INSERT INTO [AddressMaster].[dbo].[z_ICE_AddressMaster_Hist]
	  ([CountyFips]
	  ,[State]
	  ,[CountyName]
	  ,[TotalCnt]
      ,[AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      --,[CountyFips]
      --,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
	  ,[Id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
      ,[MatchCodeMandA]
      ,[MatchCodeSpatial]
      ,[PropertyID]
      ,[PropertyIDMandA]
      ,[PropertySpatial]
      ,[MatchMethodSpatial]
      ,[AddressHash]
      --,[FATimestamp]
      ,[FAUserId]
      ,[FAUCIDFlag]
      ,[NonUSPSAddressIndicator]
      ,[NotCurrentlyDeliverable]
      ,[CommunityName]
      ,[Municipality]
      ,[PostalCommunity]
      ,[SubdivisionName]
      ,[PropertyClassID]
      --,[FAEffectiveDate]
      --,[FAExpirationDate]
      ,[Ref_ID]
      ,[AddressMasterID]
      ,[DATERUN])
Select
	   [CountyFips]
	  ,[State]
	  ,[CountyName]
	  ,[TotalCnt]
      ,[AddressLine]
      ,[Address2]
      ,[CityStateZip]
      ,[PreDir]
      ,[StreetNumber]
      ,[StreetName]
      ,[PostDir]
      ,[StreetType]
      ,[SuiteType]
      ,[Suite]
      ,[City]
      ,[Zip]
      ,[Plus4]
      ,[PrivateMailbox]
      ,[Pmsa]
      ,[Msa]
      ,[ZipType]
      ,[Urbanization]
      ,[TimeZoneCode]
      ,[TimeZone]
      ,[CongressionalDistrict]
      ,[CountryCode]
      --,[CountyFips]
      --,[CountyName]
      ,[CityAbbreviation]
      ,[AddressTypeString]
      ,[AddressTypeCode]
      ,[DPVFootNotes]
      ,[CarrierRoute]
      ,[ELotOrder]
      ,[ELotNumber]
      ,[Lacs]
      ,[LACSLinkIndicator]
      ,[LACSLinkReturnCode]
      ,[EWSFlag]
      ,[RBDI]
      ,[SuiteLinkReturnCode]
      ,[AddressMatchResults]
      ,[AddressMatchResultString]
      ,[DeliveryPointCheckDigit]
      ,[DeliveryPointCode]
      ,[Latitude]
      ,[Longitude]
      ,[GeoErrorCode]
      ,[GeoStatusCode]
      ,[GeoCodeResults]
      ,[CensusTract]
      ,[CensusBlock]
      ,[PlaceCode]
      ,[PlaceName]
      ,[CBSACode]
      ,[CBSALevel]
      ,[CBSATitle]
      ,[CBSADivisionCode]
      ,[CBSADivisionTitle]
      ,[CBSADivisionLevel]
      ,[CMRA]
      ,[Verified]
      ,[Geocoded]
      ,[LoadDate]
      ,[DsfNoStats]
      ,[DsfVacant]
      ,[DsfDNA]
	  ,[Id]
      ,[AddressKey]
      ,[Company]
      ,[MelissaAddressKey]
      ,[MelissaAddressKeyBase]
      ,[SuiteStatus]
      ,[MatchCodeMandA]
      ,[MatchCodeSpatial]
      ,[PropertyID]
      ,[PropertyIDMandA]
      ,[PropertySpatial]
      ,[MatchMethodSpatial]
      ,[AddressHash]
      --,[FATimestamp]
      ,[FAUserId]
      ,[FAUCIDFlag]
      ,[NonUSPSAddressIndicator]
      ,[NotCurrentlyDeliverable]
      ,[CommunityName]
      ,[Municipality]
      ,[PostalCommunity]
      ,[SubdivisionName]
      ,[PropertyClassID]
      --,[FAEffectiveDate]
      --,[FAExpirationDate]
      ,[Ref_ID]
      ,[AddressMasterID]
      ,[DATERUN]
from [AddressMaster].[dbo].[z_ICE_AddressMaster]
order by CountyFips

END

