SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[usp_DeDupByFIPS] @FipsCode varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

		--DECLARE @FipsCode varchar(5)
		DECLARE @StateAbbrev varchar(2)



	---------------DEDUP PROCESS--------------------

		----- 100 Find SPOT Dups

			drop table If Exists [Boundaries].[dbo].Dups_FASpot
			  select fips, propertyid, count(propertyid) as cnt
			  into [Boundaries].[dbo].Dups_FASpot
			  from [Boundaries].[dbo].[FASpot] with(NOLOCK)
			  where FIPS = @FipsCode
			  and ucidflag <> 'D' and geosource like 'parcel%'
			  group by fips, propertyid
			  having count(propertyid) > 1

			drop table If Exists [Boundaries].[dbo].Dups_FASpot_a
			  select fips, propertyid, count(propertyid) as cnt
			  into [Boundaries].[dbo].Dups_FASpot_a
			  from [Boundaries].[dbo].[FASpot_a] with(NOLOCK)
			  where FIPS = @FipsCode
			  and ucidflag <> 'D' and geosource like 'parcel%'
			  group by fips, propertyid
			  having count(propertyid) > 1

			drop table If Exists [Boundaries].[dbo].Dups_FASpot_Generated
			  select fips, propertyid, count(propertyid) as cnt
			  into [Boundaries].[dbo].Dups_FASpot_Generated
			  from [Boundaries].[dbo].[FASpot_Generated] with(NOLOCK)
			  where FIPS = @FipsCode
			  and ucidflag <> 'D' and geosource like 'parcel%'
			  group by fips, propertyid
			  having count(propertyid) > 1


			drop table If Exists [Boundaries].[dbo].Dups_FASpot_Generated_a
			  select fips, propertyid, count(propertyid) as cnt
			  into [Boundaries].[dbo].Dups_FASpot_Generated_a
			  from [Boundaries].[dbo].[FASpot_Generated_a] with(NOLOCK)
			  where FIPS = @FipsCode
			  and ucidflag <> 'D' and geosource like 'parcel%'
			  group by fips, propertyid
			  having count(propertyid) > 1

			CREATE INDEX ix_FipsPropID on dbo.Dups_FASpot(fips, propertyid)
			CREATE INDEX ix_FipsPropID on dbo.Dups_FASpot_a(fips, propertyid)
			CREATE INDEX ix_FipsPropID on dbo.Dups_FASpot_Generated(fips, propertyid)
			CREATE INDEX ix_FipsPropID on dbo.Dups_FASpot_Generated_a(fips, propertyid)

		---- 300 Get SPOT full Record Dups

			drop table [Boundaries].[dbo].[FASpot_Dup]
			  Select s.*
			  into [Boundaries].[dbo].[FASpot_Dup]
			  from [Boundaries].[dbo].[FASpot] s with(NOLOCK)
			  join [Boundaries].[dbo].[Dups_FASpot] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  where s.FIPS = @FipsCode
			  and UCIDFlag <> 'D' and geosource like 'parcel%'

			  Drop Table [Boundaries].[dbo].[FASpot_a_Dup]
			  Select s.*
			  into [Boundaries].[dbo].[FASpot_a_Dup]
			  from [Boundaries].[dbo].[FASpot_a] s with(NOLOCK)
			  join [Boundaries].[dbo].[Dups_FASpot_a] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  where s.FIPS = @FipsCode
			  and UCIDFlag <> 'D' and geosource like 'parcel%'

			  drop table [Boundaries].[dbo].[FASpot_Generated_Dup]
			  Select s.*
			  into [Boundaries].[dbo].[FASpot_Generated_Dup]
			  from [Boundaries].[dbo].[FASpot_Generated] s with(NOLOCK)
			  join [Boundaries].[dbo].[Dups_FASpot_Generated] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  where s.FIPS = @FipsCode
			  and UCIDFlag <> 'D' and geosource like 'parcel%'

			  Drop Table [Boundaries].[dbo].[FASpot_Generated_a_Dup]
			  Select s.*
			  into [Boundaries].[dbo].[FASpot_Generated_a_Dup]
			  from [Boundaries].[dbo].[FASpot_Generated_a] s with(NOLOCK)
			  join [Boundaries].[dbo].[Dups_FASpot_Generated_a] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  where s.FIPS = @FipsCode
			  and UCIDFlag <> 'D' and geosource like 'parcel%'

		----- 400-Delete Dups in SPOT tables

			Delete from s
			  from [Boundaries].[dbo].[FASpot] s
			  join [Boundaries].[dbo].[Dups_FASpot] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  WHERE s.FIPS = @FipsCode 

			Delete From s
			  from [Boundaries].[dbo].[FASpot_a] s
			  join [Boundaries].[dbo].[Dups_FASpot_a] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  WHERE s.FIPS = @FipsCode 
			   

			Delete From s
			  from [Boundaries].[dbo].[FASpot_Generated] s
			  join [Boundaries].[dbo].[Dups_FASpot_Generated] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  WHERE s.FIPS = @FipsCode 
			   

			Delete From s
			  from [Boundaries].[dbo].[FASpot_Generated_a] s
			  join [Boundaries].[dbo].[Dups_FASpot_Generated_a] d with(NOLOCK)
			  on d.fips = s.fips
			  and d.propertyid = s.propertyid
			  WHERE s.FIPS = @FipsCode 
			   

		-----601 ReAppend Single record FASpot
		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot] ON

			INSERT INTO [Boundaries].[dbo].[FASpot]([FADigitalMapMasterId]
			  ,[PropertyID]
			  ,[APN]
			  ,[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType])
			SELECT [FADigitalMapMasterId]
			  ,a.[PropertyID]
			  ,[APN]
			  ,a.[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType]
			FROM [Boundaries].[dbo].[FASpot_Dup] a
				JOIN (Select FIPS,PropertyID,MAX(Id) MaxID FROM [Boundaries].[dbo].[FASpot_Dup] GROUP BY FIPS,PropertyID) b
			ON a.FIPS = b.FIPS
				and a.PropertyID = b.PropertyID 
					and a.Id = b.MaxID

		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot] OFF
		----- 602 ReAppend Single record SPOT_a 
		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_a] ON


			INSERT INTO [Boundaries].[dbo].[FASpot_a]([FADigitalMapMasterId]
			  ,[PropertyID]
			  ,[APN]
			  ,[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType])
			SELECT [FADigitalMapMasterId]
			  ,a.[PropertyID]
			  ,[APN]
			  ,a.[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType]
			FROM [Boundaries].[dbo].[FASpot_a_Dup] a
				JOIN (Select FIPS,PropertyID,MAX(Id) MaxID FROM [Boundaries].[dbo].[FASpot_a_Dup] GROUP BY FIPS,PropertyID) b
			ON a.FIPS = b.FIPS
				and a.PropertyID = b.PropertyID 
					and a.Id = b.MaxID

		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_a] OFF

		----- 603 ReAppend Single record SPOT_Generated 
		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_Generated] ON


			INSERT INTO [Boundaries].[dbo].[FASpot_Generated]([FADigitalMapMasterId]
			  ,[PropertyID]
			  ,[APN]
			  ,[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType])
			SELECT [FADigitalMapMasterId]
			  ,a.[PropertyID]
			  ,[APN]
			  ,a.[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType]
			FROM [Boundaries].[dbo].[FASpot_Generated_Dup] a
				JOIN (Select FIPS,PropertyID,MAX(Id) MaxID FROM [Boundaries].[dbo].[FASpot_Generated_Dup] GROUP BY FIPS,PropertyID) b
			ON a.FIPS = b.FIPS
				and a.PropertyID = b.PropertyID 
					and a.Id = b.MaxID

		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_Generated] OFF

		----- 604 ReAppend Single record SPOT_Generated_a
		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_Generated_a] ON

			INSERT INTO [Boundaries].[dbo].[FASpot_Generated_a]([FADigitalMapMasterId]
			  ,[PropertyID]
			  ,[APN]
			  ,[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType])
			SELECT [FADigitalMapMasterId]
			  ,a.[PropertyID]
			  ,[APN]
			  ,a.[FIPS]
			  ,[Longitude]
			  ,[Latitude]
			  ,[ParcelGeography]
			  ,[ParcelGeometry]
			  ,[ParcelPointGeography]
			  ,[ParcelPointGeometry]
			  ,[EstLotSizeSqFt]
			  ,[AddressScore]
			  ,[GeoSource]
			  ,[PARCELAPN]
			  ,[FAGeoStatusCode]
			  ,[LatLonGeometry]
			  ,[DmDate]
			  ,[MatchCode]
			  ,[UpdateFlag]
			  ,[RefId]
			  ,[PRCLDMPID]
			  ,[PROPDMPID]
			  ,[ParcelGeometry4269]
			  ,[ParcelPointGeometry4269]
			  ,[Id]
			  ,[FATimestamp]
			  ,[GeomWKT]
			  ,[UCIDFlag]
			  ,[PointWKT]
			  ,[IsCondo]
			  ,[InHJ]
			  ,[InUpdate]
			  ,[NumberofPolygons]
			  ,[InDM]
			  ,[LoadDate]
			  ,[UniqueGuid]
			  ,[CreatedDate]
			  ,[UpdatedDate]
			  ,[Area]
			  ,[SqFt]
			  ,[InSPOT]
			  ,[GeoAccuracy]
			  ,[ParcelGeometry3857]
			  ,[PointGeometry3857]
			  ,[FeatureType]
			FROM [Boundaries].[dbo].[FASpot_Generated_a_Dup] a
				JOIN (Select FIPS,PropertyID,MAX(Id) MaxID FROM [Boundaries].[dbo].[FASpot_Generated_a_Dup] GROUP BY FIPS,PropertyID) b
			ON a.FIPS = b.FIPS
				and a.PropertyID = b.PropertyID 
					and a.Id = b.MaxID

		SET IDENTITY_INSERT [Boundaries].[dbo].[FASpot_Generated_a] OFF



END



