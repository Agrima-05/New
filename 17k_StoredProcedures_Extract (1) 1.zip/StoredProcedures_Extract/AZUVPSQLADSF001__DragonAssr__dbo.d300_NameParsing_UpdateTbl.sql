SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- ===============================================================
-- Description:	Roll up Last and Prior Sale data to Property Table
-- ===============================================================
CREATE PROCEDURE [dbo].[d300_NameParsing_UpdateTbl]
AS
BEGIN

exec [NameParser].[dbo].[Dragon01_PropertyWorkUpdateTbl_to_Namework]
exec [NameParser].[dbo].[usp_name_parser_unified_daily] 'DragonPropertyWorkUpdateTbl_assessee', @RowCounts = 'N', @MailingLabel = 'Y'
exec [NameParser].[dbo].[Dragon02_namework_to_DragonPropertyWorkUpdateTbl]


END

