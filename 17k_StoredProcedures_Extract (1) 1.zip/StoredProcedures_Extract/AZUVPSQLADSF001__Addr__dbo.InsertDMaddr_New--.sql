SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[InsertDMaddr_New--] (@fips int ) 
as

INSERT INTO  Addr . dbo . DMaddr_New 
          (   ID 
          ,   PARCEL_APN 
          ,  FIPS 
          ,  STREET_NUMBER 
          ,  PRE_DIRECTIONAL 
          ,  PREFIX 
          ,  STREET_NAME 
          ,  SUFFIX 
          ,  POST_DIRECTIONAL 
          ,  UNIT_TYPE 
          ,  UNIT 
          ,  CITY_NAME 
          ,  STATE_ABBR 
          ,  ZIP 
          ,  ZIP4 
          ,  X_COORD 
          ,  Y_COORD 
          ,  STD_FIPS 
          ,  STD_StreetNumber 
          ,  STD_PreDirection 
          ,  STD_StreetName 
          ,  STD_Suffix 
          ,  STD_PostDirection 
          ,  STD_UnitType 
          ,  STD_Unit 
          ,  STD_City 
          ,  STD_State 
          ,  STD_Zip 
          ,  STD_Plus4 
          ,  STD_CRRT 
          ,  STD_CountyName 
          ,  STD_PMB 
          ,  STD_PMSA 
          ,  STD_MSA 
          ,  STD_ZipType 
          ,  STD_Urbanization 
          ,  STD_CongressionalDistrict 
          ,  STD_CountryCode 
          ,  STD_CityAbbreviation 
          ,  STD_AddressTypeCode 
          ,  STD_AddressTypeString 
          ,  STD_DPV_Count 
          ,  STD_DPV_Footnotes 
          ,  STD_CMRA 
          ,  STD_ELOT_Number 
          ,  STD_ELOT_Order 
          ,  STD_LACS 
          ,  STD_LACS_LinkIndicator 
          ,  STD_EWS_Flag 
          ,  STD_RBDI 
          ,  STD_SuiteLinkReturnCode 
          ,  STD_DeliveryPointCheckDigit 
          ,  STD_DeliveryPointCode 
          ,  STD_CensusBlock 
          ,  STD_CensusTract 
          ,  STD_PlaceCode 
          ,  STD_PlaceName 
          ,  STD_CBSA_Code 
          ,  STD_CBSA_Level 
          ,  STD_CBSA_Title 
          ,  STD_CBSA_DivisionCode 
          ,  STD_CBSA_DivisionLevel 
          ,  STD_CBSA_DivisionTitle 
          ,  STD_Latitude 
          ,  STD_Longitude 
          ,  STD_AddressMatchResults 
          ,  STD_Verified 
          ,  STD_Geocoded 
          ,  STD_GeoErrorCode 
          ,  STD_GeoStatusCode 
          ,  Parcel 
          ,  points )
          -- , Ref_Id
   
SELECT
            d.ID 
          , D.PARCEL_APN 
          , d.FIPS 
          , d.STREET_NUMBER 
          , d.PRE_DIRECTIONAL 
          , d.PREFIX 
          , d.STREET_NAME 
          , d.SUFFIX 
          , d.POST_DIRECTIONAL 
          , d.UNIT_TYPE 
          , d.UNIT 
          , d.CITY_NAME 
          , d.STATE_ABBR 
          , d.ZIP 
          , d.ZIP4 
          , d.X_COORD 
          , d.Y_COORD 
          , S.FIPS 
          , S.StreetNumber 
          , S.PreDirection 
          , S.StreetName 
          , S.Suffix 
          , S.PostDirection 
          , S.UnitType 
          , S.Unit 
          , S. City 
          , S. State 
          , S. Zip 
          , S. Plus4 
          , S. CRRT 
          , S. CountyName 
          , S. PMB 
          , S. PMSA 
          , S. MSA 
          , S. ZipType 
          , S. Urbanization 
          , S. CongressionalDistrict 
          , S. CountryCode 
          , S. CityAbbreviation 
          , S. AddressTypeCode 
          , S. AddressTypeString 
          , S. DPV_Count 
          , S. DPV_Footnotes 
          , S. CMRA 
          , S. ELOT_Number 
          , S. ELOT_Order 
          , S. LACS 
          , S. LACS_LinkIndicator 
          , S. EWS_Flag 
          , S. RBDI 
          , S. SuiteLinkReturnCode 
          , S. DeliveryPointCheckDigit 
          , S. DeliveryPointCode 
          , S. CensusBlock 
          , S. CensusTract 
          , S. PlaceCode 
          , S. PlaceName 
          , S. CBSA_Code 
          , S. CBSA_Level 
          , S. CBSA_Title 
          , S. CBSA_DivisionCode 
          , S. CBSA_DivisionLevel 
          , S. CBSA_DivisionTitle 
          , S. Latitude 
          , S. Longitude 
          , S. AddressMatchResults 
          , S. Verified 
          , S. Geocoded 
          , S. GeoErrorCode 
          , S. GeoStatusCode 
           , PA.Parcel 
           , Po.Point 
          -- , Ref_Id 
FROM dm_missing.dbo.dmaddr_STD  S 
inner  join dm_missing.dbo.DMAddr d  on s.id=d.ID
full outer join Parcels_New.dbo.Parcels Pa on d.fips = Pa.fips and d.PARCEL_APN = PA.APN
full outer join Points_new.dbo.Points Po on d.FIPS  = Po.FIPS  and d.PARCEL_APN = PO.APN
where d.fips = @fips
and len (PARCEL_APN)<>0


