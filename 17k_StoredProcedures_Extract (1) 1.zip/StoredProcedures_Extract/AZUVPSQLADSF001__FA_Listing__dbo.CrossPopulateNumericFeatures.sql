SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[CrossPopulateNumericFeatures]
	@PropagateAll BIT = 0
AS
	SET @PropagateAll = ISNULL(@PropagateAll, 0)

	SELECT *
	INTO #FeatureValuesNumeric
	FROM FeatureValuesNumeric
	WHERE @PropagateAll = 1 OR Updated > Propagated OR Propagated IS NULL

	-- Calculate NBR_GRG_STD
	SELECT lf.Listing_ID, MAX(v.NumericValue) AS NumericValue
	INTO #NBR_GRG
	FROM #FeatureValuesNumeric v
	INNER JOIN ListingFeatures lf ON v.FeatureValueId = lf.FeatureValueId
	WHERE v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId IN (SELECT Id FROM FeatureTypes WHERE Name IN ('NBR_GRG', 'PARKING_FTRS')))
	GROUP BY lf.Listing_ID

	ALTER TABLE #NBR_GRG ADD PRIMARY KEY (Listing_ID)

	-- Calculate NBR_FIREPLACE_STD
	SELECT lf.Listing_ID, MAX(v.NumericValue) AS NumericValue
	INTO #NBR_FIREPLACE
	FROM #FeatureValuesNumeric v
	INNER JOIN ListingFeatures lf ON v.FeatureValueId = lf.FeatureValueId
	WHERE v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'FIREPLACE_NBR'))
	GROUP BY lf.Listing_ID

	ALTER TABLE #NBR_FIREPLACE ADD PRIMARY KEY (Listing_ID)

	-- Calculate NBR_STORIES_STD
	SELECT lf.Listing_ID, MAX(v.NumericValue) AS NumericValue
	INTO #NBR_STORIES
	FROM #FeatureValuesNumeric v
	INNER JOIN ListingFeatures lf ON v.FeatureValueId = lf.FeatureValueId
	WHERE v.FeatureValueId IN (SELECT Id FROM FeatureValues WHERE FeatureTypeId = (SELECT Id FROM FeatureTypes WHERE Name = 'NBR_STORIES'))
	GROUP BY lf.Listing_ID

	ALTER TABLE #NBR_STORIES ADD PRIMARY KEY (Listing_ID)

	UPDATE l
	SET NBR_GRG_STD = n.NumericValue
	FROM Listing l
	INNER JOIN #NBR_GRG n ON l.Listing_ID = n.Listing_ID
	WHERE NBR_GRG_STD <> CAST(n.NumericValue AS SMALLINT)

	UPDATE l
	SET NBR_FIREPLACE_STD = n.NumericValue
	FROM Listing l
	INNER JOIN #NBR_FIREPLACE n ON l.Listing_ID = n.Listing_ID
	WHERE NBR_FIREPLACE_STD <> CAST(n.NumericValue AS SMALLINT)

	UPDATE l
	SET NBR_STORIES_STD = n.NumericValue
	FROM Listing l
	INNER JOIN #NBR_STORIES n ON l.Listing_ID = n.Listing_ID
	WHERE NBR_STORIES_STD <> CAST(n.NumericValue AS NUMERIC(8, 2))

	-- Update Propagated timestamp on FeatureValuesNumeric
	UPDATE n
	SET Propagated = GETDATE()
	FROM FeatureValuesNumeric n
	INNER JOIN #FeatureValuesNumeric n2 ON n.FeatureValueId = n2.FeatureValueId
	WHERE n.Updated = n2.Updated OR (n.Updated IS NULL AND n2.Updated IS NULL) -- This will help avoid a race condition

