SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[CreateFASpotGenerated_FAST] @Fips varchar(5)
AS
BEGIN

	SET NOCOUNT ON;

Delete from dbo.FASpot_Generated
where fips = @Fips

-----------STEP 1

drop table if Exists [Boundaries].[dbo].[Property_Compare]

SELECT [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[UnformattedAPN]
	  ,CountyLandUseDescription
	  ,StdLandUseCode
      ,[SitusStdFullStreetAddress]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[LotSizeSqFt]
      ,[LotSizeAcres]
	  ,[FAEstLotSqFt]
	  ,[FALatitude]
	  ,[FALongitude]
      ,[TPLatitude]
      ,[TPLongitude]
      ,[FARooftopLatitude]
      ,[FARooftopLongitude]
	  ,DTDB_Ref_ID
      ,[DTDB_FORMATTED_APN]
      ,[DTDB_UNFORMATTED_APN]
      ,[SPOT_ID]
into [Boundaries].dbo.Property_Compare
  FROM [Data].[dbo].[Property] with (nolock)
  where fips = @fips and FAUCIDFlag <> 'D' --and FAGeoStatusCode  -- , '31155','06037','17031','48453'
  order by fips,propertyid

  alter table [Boundaries].[dbo].[Property_Compare]
  add [InRegrid] varchar(5),[InSPOT] varchar(5),[SPOTID_SpatialMatch] bigint, [SPOT_SpatialMatchCode] varchar(5), [SPOT_PROPERTYID] bigint, [UniqueGuid] varchar(max)

CREATE NONCLUSTERED INDEX [xFARootop] ON [Boundaries].[dbo].[Property_Compare]
([FARooftopLatitude] ASC,[FARooftopLongitude] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

CREATE NONCLUSTERED INDEX [FAGeo] ON [Boundaries].[dbo].[Property_Compare]
([FALatitude] ASC,[FALongitude] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

CREATE NONCLUSTERED INDEX [TPGeo] ON [Boundaries].[dbo].[Property_Compare]
([TPLatitude] ASC,[TPLongitude] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-182153] ON [Boundaries].[dbo].[Property_Compare]
([FIPS] ASC,[PropertyID] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

---------------
  update [Boundaries].[dbo].[Property_Compare]
  Set [InRegrid] = 'Y'
  from [Boundaries].[dbo].[Property_Compare] p
  join [Boundaries].[dbo].[FARegrid] r
  on r.fips = p.fips
  and r.PropertyID = p.propertyid

  update [Boundaries].[dbo].[Property_Compare]
  Set [InSPOT] = 'Y'
      ,SPOT_ID = r.FADigitalMapMasterId
	  ,UniqueGuid = r.[UniqueGuid]  
  from [Boundaries].[dbo].[Property_Compare] p
  join [Boundaries].[dbo].[FASpot] r
  on r.fips = p.fips
  and r.PropertyID = p.propertyid
  where r.GeoSource like 'Parcel%'


  -----------  STEP 2


-----------------------------

Drop table if Exists [Boundaries].[dbo].[FASpot_PropertyCompare]

SELECT [FADigitalMapMasterId]
      ,[PropertyID]
      ,[APN]
      ,[FIPS]
      ,[Longitude]
      ,[Latitude]
      ,[ParcelGeography]
      ,[ParcelGeometry]
      ,[ParcelPointGeography]
      ,[ParcelPointGeometry]
      ,[EstLotSizeSqFt]
      ,[AddressScore]
      ,[GeoSource]
      ,[PARCELAPN]
      ,[FAGeoStatusCode]
      ,[LatLonGeometry]
      ,[DmDate]
      ,[MatchCode]
      ,[UpdateFlag]
      ,[RefId]
      ,[PRCLDMPID]
      ,[PROPDMPID]
      ,[ParcelGeometry4269]
      ,[ParcelPointGeometry4269]
      ,[Id]
      ,[FATimestamp]
      ,[GeomWKT]
      ,[UCIDFlag]
      ,[PointWKT]
      ,[IsCondo]
      ,[InHJ]
      ,[InUpdate]
      ,[NumberofPolygons]
      ,[InDM]
      ,[LoadDate]
	  ,[UniqueGuid]
	  ,[CreatedDate]
	  ,[UpdatedDate]
	  ,[Area]
	  ,[SqFt]
into [Boundaries].[dbo].[FASpot_PropertyCompare]
  FROM [Boundaries].[dbo].[FASpot]
  where fips = @Fips
  and GeoSource <> 'points'

  -------------------------------------

/****** Object:  Index [PK_Temp]    Script Date: 9/12/2023 5:33:47 PM ******/
EXEC('ALTER TABLE [Boundaries].[dbo].[FASpot_PropertyCompare] ADD  CONSTRAINT [PK_Temp_1] PRIMARY KEY CLUSTERED 
([Id] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
')

-----------------------------------

SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF

/****** Object:  Index [SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269]    Script Date: 9/12/2023 5:31:55 PM ******/
CREATE SPATIAL INDEX [SpatialIndex-allHighHighHighHigh8192ParcelGeometry4269] ON boundaries.[dbo].[FASpot_PropertyCompare]
([ParcelGeometry4269])USING  GEOMETRY_GRID 
WITH (BOUNDING_BOX =(-162, 18, -45, 66), GRIDS =(LEVEL_1 = HIGH,LEVEL_2 = HIGH,LEVEL_3 = HIGH,LEVEL_4 = HIGH), 
CELLS_PER_OBJECT = 8192, PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [Primary]

-------------
CREATE NONCLUSTERED INDEX [xSPOTID] ON [Boundaries].[dbo].[FASpot_PropertyCompare]
([FIPS] ASC,[FADigitalMapMasterId] ASC)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

-------------

--CREATE NONCLUSTERED INDEX [x.SPOTID] ON [Boundaries].[dbo].[Property_Compare]
--([FIPS] ASC,[SPOTID_SpatialMatch] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

-------------

update [Boundaries].[dbo].[Property_Compare]
Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
,[SPOT_SpatialMatchCode] = 'FART'
,[SPOT_PROPERTYID] = a.propertyID
,[UniqueGuid] = a.[UniqueGuid]
FROM[Boundaries].[dbo].[Property_Compare] h
join [Boundaries].[dbo].[FASpot_PropertyCompare] a
on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT('+cast(cast(h.[FARooftopLongitude] as decimal(20,6)) as varchar(20))+' '+ cast(cast(h.[FARooftopLatitude] as decimal(20,6)) as varchar(20)) +')',4269)) = 1
--andh.Geom.STArea()/ParcelGeometry4269.STArea()+0.000000000001between0.7and1.3
where h.Fips = @fips and
 h.[InSPOT] is null and h.[FARooftopLongitude] is not null and [ParcelGeometry4269].STArea() > 0
 --in ('06025','06037','06059','06071','06065','06111')

update [Boundaries].[dbo].[Property_Compare]
Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
,[SPOT_SpatialMatchCode] = 'FA'
,[SPOT_PROPERTYID] = a.propertyID
,[UniqueGuid] = a.[UniqueGuid]
FROM[Boundaries].[dbo].[Property_Compare] h
join [Boundaries].[dbo].[FASpot_PropertyCompare] a
on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT('+cast(cast(h.[FALongitude] as decimal(20,6)) as varchar(20))+' '+ cast(cast(h.[FALatitude] as decimal(20,6)) as varchar(20)) +')',4269)) = 1
--andh.Geom.STArea()/ParcelGeometry4269.STArea()+0.000000000001between0.7and1.3
where h.Fips = @fips and
 h.[InSPOT] is null and h.[FALongitude] is not null 
 and [ParcelGeometry4269].STArea() > 0 
 and [SPOTID_SpatialMatch] is null
 --in ('06025','06037','06059','06071','06065','06111')

--update [Boundaries].[dbo].[Property_Compare]
--Set [SPOTID_SpatialMatch] = [FADigitalMapMasterId]
--,[SPOT_SpatialMatchCode] = 'FATP'
--,[SPOT_PROPERTYID] = a.propertyID
--,[UniqueGuid] = a.[UniqueGuid]
--FROM[Boundaries].[dbo].[Property_Compare] h
--join [Boundaries].[dbo].[FASpot_PropertyCompare] a
--on a.[ParcelGeometry4269].STContains(geometry::STGeomFromText('POINT('+cast(cast(h.[TPLongitude] as decimal(20,6)) as varchar(20))+' '+ cast(cast(h.[TPLatitude] as decimal(20,6)) as varchar(20)) +')',4269)) = 1
----andh.Geom.STArea()/ParcelGeometry4269.STArea()+0.000000000001between0.7and1.3
--where h.Fips = '06065' and
-- h.[InSPOT] is null and h.[TPLongitude] is not null and [ParcelGeometry4269].STArea() > 0 and [SPOTID_SpatialMatch] is null
-- --in ('06025','06037','06059','06071','06065','06111')

 -----------
  update data..property
  Set SPOT_ID = coalesce(c.[Spot_ID],[SPOTID_SpatialMatch])
  from data..property p
  join [Boundaries].[dbo].[Property_Compare] c
  on c.fips = p.fips
  and c.propertyid = p.propertyid
  where p.fips = @fips

  ----------

  INSERT INTO [Boundaries].[dbo].[FASpot_Generated]
           ([FADigitalMapMasterId]
           ,[PropertyID]
           ,[APN]
           ,[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,[RefId]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InUpdate]
           ,[NumberofPolygons]
           ,[InDM]
           ,[LoadDate]
		   ,[UniqueGuid]
	       ,[CreatedDate]
	       ,[UpdatedDate]
	       ,[Area]
	       ,[SqFt])

 Select     [FADigitalMapMasterId]
 --,p.CountyLandUseDescription
           ,p.[PropertyID]
           ,p.formattedAPN
           ,p.[FIPS]
           ,[Longitude]
           ,[Latitude]
           ,[ParcelGeography]
           ,[ParcelGeometry]
           ,[ParcelPointGeography]
           ,[ParcelPointGeometry]
           ,[EstLotSizeSqFt]
           ,[AddressScore]
           ,[GeoSource]
           ,[PARCELAPN]
           ,[FAGeoStatusCode]
           ,[LatLonGeometry]
           ,[DmDate]
           ,[MatchCode]
           ,[UpdateFlag]
           ,p.[DTDB_Ref_ID]
           ,[PRCLDMPID]
           ,[PROPDMPID]
           ,[ParcelGeometry4269]
           ,[ParcelPointGeometry4269]
           ,GetDate()  --[FATimestamp]
           ,[GeomWKT]
           ,[UCIDFlag]
           ,[PointWKT]
           ,[IsCondo]
           ,[InHJ]
           ,[InUpdate]
           ,[NumberofPolygons]
           ,[InDM]
           ,[LoadDate]
		   ,c.[UniqueGuid]
	       ,c.[CreatedDate]
	       ,c.[UpdatedDate]
	       ,c.[Area]
	       ,c.[SqFt]
From [Boundaries].[dbo].[FASpot_PropertyCompare] c
join [Boundaries].[dbo].[Property_Compare] p
on p.fips = c.fips
and p.SPOTID_SpatialMatch = c.[FADigitalMapMasterId]
where p.fips = @fips
order by propertyid

---------
drop table [Boundaries].[dbo].[FASpot_DeletesFlag]

SELECT s.fips, s.FADigitalMapMasterId
Into [Boundaries].[dbo].[FASpot_DeletesFlag]
  FROM [Boundaries].[dbo].[FASpot_Generated] g
  join [Boundaries].[dbo].[FASpot_PropertyCompare] s
  on s.fips = g.fips
  and s.[FADigitalMapMasterId] = g.[FADigitalMapMasterId]
  where s.fips = @fips and s.propertyid is null

  CREATE INDEX ix_fipsMastId on [Boundaries].[dbo].[FASpot_DeletesFlag](Fips,FADigitalMapMasterId)


  update [Boundaries].[dbo].[FASpot]
  Set UCIDFlag = 'D'
  ,FATimestamp = GetDate()
  from [Boundaries].[dbo].[FASpot] s
  join [Boundaries].[dbo].[FASpot_DeletesFlag] d
  on d.fips = s.fips
  and d.FADigitalMapMasterId = s.FADigitalMapMasterId

  update s
  Set UCIDFlag = 'D'
  ,FATimestamp = GetDate()
  from [Boundaries].[dbo].[FASpot] s
  join [Boundaries].[dbo].[FASpot_Generated] d
  on s.fips = d.fips
  and s.PropertyID = d.PropertyID
  WHERE s.UCIDFlag != 'D'


END

