SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Run Dragon Assessor Proc
-- =============================================
CREATE PROCEDURE [dbo].[d050_RunDragonAssrProcess_UPDATE] @Date varchar(8)
AS
BEGIN

	SET NOCOUNT ON;


---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd100 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d100_AppendDragonAssrToPropertyWORK_UPDATE] 

		INSERT INTO DragonProcessingTracker
		Select 'd100 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd200 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d200_PullForwardData_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd200 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd300 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d300_NameParsing_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd300 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd400 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d400_last_and_prior_sale_rollup_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd400 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd500 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d500_Ownership_Update_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd500 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd530 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d530_Update_Foreign_Addr_Flag_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd530 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd540 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d540_RunASP_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd540 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd545 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d545_RunASP_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd545 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd550 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d550_VacancyBankOwned_UPDATE]

		INSERT INTO DragonProcessingTracker
		Select 'd550 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'd600 Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		EXEC [dbo].[d600_OpenLien_V3_Update]

		INSERT INTO DragonProcessingTracker
		Select 'd600 Update Finish ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

---------------------------------------------------------------------------------------------------------------------
		--Declare @Date varchar(8) = convert(varchar(8),Getdate()+1,112)

		INSERT INTO DragonProcessingTracker
		Select 'Rename Update Start ' + @Date as ProcessingStep,GETDATE() as ProcessingStartTime 

		update DragonAssr.dbo.PropertyWorkUpdate
		SET OwnerStd1LastName = NULL 
		where OwnerStd1LastName = OwnerStd1CorpName

		update DragonAssr.dbo.PropertyWorkUpdate
		SET OwnerStd2LastName = NULL 
		where OwnerStd2LastName = OwnerStd2CorpName

		UPDATE DragonAssr.dbo.PropertyWorkUpdate
		SET [FIPS] = Ltrim(Rtrim([FIPS]))
      ,[PropertyID] = Ltrim(Rtrim([PropertyID]))
      ,[FormattedAPN] = Ltrim(Rtrim([FormattedAPN]))
      ,[APNSeqNbr] = Ltrim(Rtrim([APNSeqNbr]))
      ,[UnformattedAPN] = Ltrim(Rtrim([UnformattedAPN]))
      ,[OldAPN] = Ltrim(Rtrim([OldAPN]))
      ,[OLDAPNSeqNbr] = Ltrim(Rtrim([OLDAPNSeqNbr]))
      ,[TaxAccountNumber] = Ltrim(Rtrim([TaxAccountNumber]))
      ,[RecordType] = Ltrim(Rtrim([RecordType]))
      ,[VendorPID] = Ltrim(Rtrim([VendorPID]))
      ,[SitusStdFullStreetAddress] = Ltrim(Rtrim([SitusStdFullStreetAddress]))
      ,[SitusStdHouseNbr] = Ltrim(Rtrim([SitusStdHouseNbr]))
      ,[SitusStdHouseNbr2] = Ltrim(Rtrim([SitusStdHouseNbr2]))
      ,[SitusStdHouseNbrSuffix] = Ltrim(Rtrim([SitusStdHouseNbrSuffix]))
      ,[SitusStdDirectionLeft] = Ltrim(Rtrim([SitusStdDirectionLeft]))
      ,[SitusStdStreet] = Ltrim(Rtrim([SitusStdStreet]))
      ,[SitusStdMode] = Ltrim(Rtrim([SitusStdMode]))
      ,[SitusStdDirectionRight] = Ltrim(Rtrim([SitusStdDirectionRight]))
      ,[SitusStdUnitNbr] = Ltrim(Rtrim([SitusStdUnitNbr]))
      ,[SitusStdCity] = Ltrim(Rtrim([SitusStdCity]))
      ,[SitusStdState] = Ltrim(Rtrim([SitusStdState]))
      ,[SitusStdZIP5] = Ltrim(Rtrim([SitusStdZIP5]))
      ,[SitusStdZIP4] = Ltrim(Rtrim([SitusStdZIP4]))
      ,[SitusStdCarrierCode] = Ltrim(Rtrim([SitusStdCarrierCode]))
      ,[SitusCensusTract] = Ltrim(Rtrim([SitusCensusTract]))
      ,[SitusCensusTractBlock] = Ltrim(Rtrim([SitusCensusTractBlock]))
      ,[SitusStdUnitType] = Ltrim(Rtrim([SitusStdUnitType]))
      ,[SitusStdMatchCode] = Ltrim(Rtrim([SitusStdMatchCode]))
      ,[LotSizeSqFt] = Ltrim(Rtrim([LotSizeSqFt]))
      ,[LotSizeAcres] = Ltrim(Rtrim([LotSizeAcres]))
      ,[LotSizeFrontageFeet] = Ltrim(Rtrim([LotSizeFrontageFeet]))
      ,[LotSizeDepthFeet] = Ltrim(Rtrim([LotSizeDepthFeet]))
      ,[LotIrregularInd] = Ltrim(Rtrim([LotIrregularInd]))
      ,[LotUsableSize] = Ltrim(Rtrim([LotUsableSize]))
      ,[PropertyClassID] = Ltrim(Rtrim([PropertyClassID]))
      ,[StdLandUseCode] = Ltrim(Rtrim([StdLandUseCode]))
      ,[StateLandUseCode] = Ltrim(Rtrim([StateLandUseCode]))
      ,[CountyLandUseCode] = Ltrim(Rtrim([CountyLandUseCode]))
      ,[CountyLandUseDescription] = Ltrim(Rtrim([CountyLandUseDescription]))
      ,[TimeshareCode] = Ltrim(Rtrim([TimeshareCode]))
      ,[Zoning] = Ltrim(Rtrim([Zoning]))
      ,[SiteInfluenceCode] = Ltrim(Rtrim([SiteInfluenceCode]))
      ,[NeighborhoodCode] = Ltrim(Rtrim([NeighborhoodCode]))
      ,[TopographyCode] = Ltrim(Rtrim([TopographyCode]))
      ,[MobileHomeInd] = Ltrim(Rtrim([MobileHomeInd]))
      ,[LotCode] = Ltrim(Rtrim([LotCode]))
      ,[LotNumber] = Ltrim(Rtrim([LotNumber]))
      ,[LandLot] = Ltrim(Rtrim([LandLot]))
      ,[Block] = Ltrim(Rtrim([Block]))
      ,[Section] = Ltrim(Rtrim([Section]))
      ,[District] = Ltrim(Rtrim([District]))
      ,[LegalUnit] = Ltrim(Rtrim([LegalUnit]))
      ,[Municipality] = Ltrim(Rtrim([Municipality]))
      ,[LegalSection] = Ltrim(Rtrim([LegalSection]))
      ,[LegalTownship] = Ltrim(Rtrim([LegalTownship]))
      ,[LegalRange] = Ltrim(Rtrim([LegalRange]))
      ,[Meridian] = Ltrim(Rtrim([Meridian]))
      ,[LegalQuarter] = Ltrim(Rtrim([LegalQuarter]))
      ,[LegalQuarterQuarter] = Ltrim(Rtrim([LegalQuarterQuarter]))
      ,[LegalDescription] = Ltrim(Rtrim([LegalDescription]))
      ,[AssessorsMapRef1] = Ltrim(Rtrim([AssessorsMapRef1]))
      ,[AssessorsMapRef2] = Ltrim(Rtrim([AssessorsMapRef2]))
      ,[SubdivisionName] = Ltrim(Rtrim([SubdivisionName]))
      ,[SubdivisionPhaseNbr] = Ltrim(Rtrim([SubdivisionPhaseNbr]))
      ,[SubdivisionTractNbr] = Ltrim(Rtrim([SubdivisionTractNbr]))
      ,[SubdivisionPlatBook] = Ltrim(Rtrim([SubdivisionPlatBook]))
      ,[SubdivisionPlatPage] = Ltrim(Rtrim([SubdivisionPlatPage]))
      ,[NewRecordType] = Ltrim(Rtrim([NewRecordType]))
      ,[SwiSCodeNY] = Ltrim(Rtrim([SwiSCodeNY]))
      ,[MailingCareOfName] = Ltrim(Rtrim([MailingCareOfName]))
      ,[MailingStdFullStreetAddress] = Ltrim(Rtrim([MailingStdFullStreetAddress]))
      ,[MailingStdHouseNbr] = Ltrim(Rtrim([MailingStdHouseNbr]))
      ,[MailingStdHouseNbr2] = Ltrim(Rtrim([MailingStdHouseNbr2]))
      ,[MailingStdHouseNbrSuffix] = Ltrim(Rtrim([MailingStdHouseNbrSuffix]))
      ,[MailingStdDirectionLeft] = Ltrim(Rtrim([MailingStdDirectionLeft]))
      ,[MailingStdStreet] = Ltrim(Rtrim([MailingStdStreet]))
      ,[MailingStdMode] = Ltrim(Rtrim([MailingStdMode]))
      ,[MailingStdDirectionRight] = Ltrim(Rtrim([MailingStdDirectionRight]))
      ,[MailingStdUnitNbr] = Ltrim(Rtrim([MailingStdUnitNbr]))
      ,[MailingStdCity] = Ltrim(Rtrim([MailingStdCity]))
      ,[MailingStdState] = Ltrim(Rtrim([MailingStdState]))
      ,[MailingStdZIP5] = Ltrim(Rtrim([MailingStdZIP5]))
      ,[MailingStdZIP4] = Ltrim(Rtrim([MailingStdZIP4]))
      ,[MailingStdCarrierCode] = Ltrim(Rtrim([MailingStdCarrierCode]))
      ,[MailingStdUnitType] = Ltrim(Rtrim([MailingStdUnitType]))
      ,[MailingStdMatchCode] = Ltrim(Rtrim([MailingStdMatchCode]))
      ,[MailingOptOut] = Ltrim(Rtrim([MailingOptOut]))
      ,[MailingOptOutDate] = Ltrim(Rtrim([MailingOptOutDate]))
      ,[OwnerOccupied] = Ltrim(Rtrim([OwnerOccupied]))
      ,[AbsenteeOwner] = Ltrim(Rtrim([AbsenteeOwner]))
      ,[OwnerStdNAME1FULL] = Ltrim(Rtrim([OwnerStdNAME1FULL]))
      ,[OwnerStdNAME2FULL] = Ltrim(Rtrim([OwnerStdNAME2FULL]))
      ,[OwnerStdNAME3FULL] = Ltrim(Rtrim([OwnerStdNAME3FULL]))
      ,[OwnerStdNAME4FULL] = Ltrim(Rtrim([OwnerStdNAME4FULL]))
      ,[OwnerEtALIndicator] = Ltrim(Rtrim([OwnerEtALIndicator]))
      ,[OwnerStd1CorpInd] = Ltrim(Rtrim([OwnerStd1CorpInd]))
      ,[OwnerStd1LastName] = Ltrim(Rtrim([OwnerStd1LastName]))
      ,[OwnerStd1FirstName] = Ltrim(Rtrim([OwnerStd1FirstName]))
      ,[OwnerStd1MiddleName] = Ltrim(Rtrim([OwnerStd1MiddleName]))
      ,[OwnerStd1Suffix] = Ltrim(Rtrim([OwnerStd1Suffix]))
      ,[OwnerStd1CorpName] = Ltrim(Rtrim([OwnerStd1CorpName]))
      ,[OwnerStd1OwnershipRights] = Ltrim(Rtrim([OwnerStd1OwnershipRights]))
      ,[OwnerStd1RelationshipType] = Ltrim(Rtrim([OwnerStd1RelationshipType]))
      ,[Owner1DoNotParse] = Ltrim(Rtrim([Owner1DoNotParse]))
      ,[OwnerStd2CorpInd] = Ltrim(Rtrim([OwnerStd2CorpInd]))
      ,[OwnerStd2LastName] = Ltrim(Rtrim([OwnerStd2LastName]))
      ,[OwnerStd2FirstName] = Ltrim(Rtrim([OwnerStd2FirstName]))
      ,[OwnerStd2MiddleName] = Ltrim(Rtrim([OwnerStd2MiddleName]))
      ,[OwnerStd2Suffix] = Ltrim(Rtrim([OwnerStd2Suffix]))
      ,[OwnerStd2CorpName] = Ltrim(Rtrim([OwnerStd2CorpName]))
      ,[OwnerStd2OwnershipRights] = Ltrim(Rtrim([OwnerStd2OwnershipRights]))
      ,[OwnerStd2RelationshipType] = Ltrim(Rtrim([OwnerStd2RelationshipType]))
      ,[Owner2DoNotParse] = Ltrim(Rtrim([Owner2DoNotParse]))
      ,[OwnerStd3CorpInd] = Ltrim(Rtrim([OwnerStd3CorpInd]))
      ,[OwnerStd3LastName] = Ltrim(Rtrim([OwnerStd3LastName]))
      ,[OwnerStd3FirstName] = Ltrim(Rtrim([OwnerStd3FirstName]))
      ,[OwnerStd3MiddleName] = Ltrim(Rtrim([OwnerStd3MiddleName]))
      ,[OwnerStd3Suffix] = Ltrim(Rtrim([OwnerStd3Suffix]))
      ,[OwnerStd3CorpName] = Ltrim(Rtrim([OwnerStd3CorpName]))
      ,[OwnerStd3OwnershipRights] = Ltrim(Rtrim([OwnerStd3OwnershipRights]))
      ,[OwnerStd3RelationshipType] = Ltrim(Rtrim([OwnerStd3RelationshipType]))
      ,[Owner3DoNotParse] = Ltrim(Rtrim([Owner3DoNotParse]))
      ,[OwnerStd4CorpInd] = Ltrim(Rtrim([OwnerStd4CorpInd]))
      ,[OwnerStd4LastName] = Ltrim(Rtrim([OwnerStd4LastName]))
      ,[OwnerStd4FirstName] = Ltrim(Rtrim([OwnerStd4FirstName]))
      ,[OwnerStd4MiddleName] = Ltrim(Rtrim([OwnerStd4MiddleName]))
      ,[OwnerStd4Suffix] = Ltrim(Rtrim([OwnerStd4Suffix]))
      ,[OwnerStd4CorpName] = Ltrim(Rtrim([OwnerStd4CorpName]))
      ,[OwnerStd4OwnershipRights] = Ltrim(Rtrim([OwnerStd4OwnershipRights]))
      ,[OwnerStd4RelationshipType] = Ltrim(Rtrim([OwnerStd4RelationshipType]))
      ,[Owner4DoNotParse] = Ltrim(Rtrim([Owner4DoNotParse]))
      ,[AssesseeStd1Name] = Ltrim(Rtrim([AssesseeStd1Name]))
      ,[AssesseeStd2Name] = Ltrim(Rtrim([AssesseeStd2Name]))
      ,[AssesseeNameIndicator] = Ltrim(Rtrim([AssesseeNameIndicator]))
      ,[AssesseeNameIndicator2] = Ltrim(Rtrim([AssesseeNameIndicator2]))
      ,[Amenities] = Ltrim(Rtrim([Amenities]))
      ,[DrivewayCode] = Ltrim(Rtrim([DrivewayCode]))
      ,[EasementInd] = Ltrim(Rtrim([EasementInd]))
      ,[QualityCode] = Ltrim(Rtrim([QualityCode]))
      ,[ViewInd] = Ltrim(Rtrim([ViewInd]))
      ,[ViewCode] = Ltrim(Rtrim([ViewCode]))
      ,[ViewQualityCode] = Ltrim(Rtrim([ViewQualityCode]))
      ,[WaterAccessableInd] = Ltrim(Rtrim([WaterAccessableInd]))
      ,[WaterFeatureInd] = Ltrim(Rtrim([WaterFeatureInd]))
      ,[WaterfrontCode] = Ltrim(Rtrim([WaterfrontCode]))
      ,[WaterfrontFeet] = Ltrim(Rtrim([WaterfrontFeet]))
      ,[WaterfrontQualityCode] = Ltrim(Rtrim([WaterfrontQualityCode]))
      ,[BuildingArea] = Ltrim(Rtrim([BuildingArea]))
      ,[BuildingAreaInd] = Ltrim(Rtrim([BuildingAreaInd]))
      ,[TotalRooms] = Ltrim(Rtrim([TotalRooms]))
      ,[Bedrooms] = Ltrim(Rtrim([Bedrooms]))
      ,[BathTotalCalc] = Ltrim(Rtrim([BathTotalCalc]))
      ,[BathFull] = Ltrim(Rtrim([BathFull]))
      ,[BathsParcialNbr] = Ltrim(Rtrim([BathsParcialNbr]))
      ,[BathHalf] = Ltrim(Rtrim([BathHalf]))
      ,[Bath1QTR] = Ltrim(Rtrim([Bath1QTR]))
      ,[Bath3QTR] = Ltrim(Rtrim([Bath3QTR]))
      ,[BathFixturesNbr] = Ltrim(Rtrim([BathFixturesNbr]))
      ,[OtherRooms] = Ltrim(Rtrim([OtherRooms]))
      ,[AirConditioningCode] = Ltrim(Rtrim([AirConditioningCode]))
      ,[AirConditioningTypeCode] = Ltrim(Rtrim([AirConditioningTypeCode]))
      ,[BasementCode] = Ltrim(Rtrim([BasementCode]))
      ,[BasementFinishedCode] = Ltrim(Rtrim([BasementFinishedCode]))
      ,[BuildingClassCode] = Ltrim(Rtrim([BuildingClassCode]))
      ,[BuildingConditionCode] = Ltrim(Rtrim([BuildingConditionCode]))
      ,[BuildingQualityCode] = Ltrim(Rtrim([BuildingQualityCode]))
      ,[ConstructionTypeCode] = Ltrim(Rtrim([ConstructionTypeCode]))
      ,[DeckCode] = Ltrim(Rtrim([DeckCode]))
      ,[ElectricityCode] = Ltrim(Rtrim([ElectricityCode]))
      ,[ExteriorWallsCode] = Ltrim(Rtrim([ExteriorWallsCode]))
      ,[FireplaceCode] = Ltrim(Rtrim([FireplaceCode]))
      ,[FloorCoverCode] = Ltrim(Rtrim([FloorCoverCode]))
      ,[FloorTypeCode] = Ltrim(Rtrim([FloorTypeCode]))
      ,[FoundationInd] = Ltrim(Rtrim([FoundationInd]))
      ,[FrameCode] = Ltrim(Rtrim([FrameCode]))
      ,[Garage] = Ltrim(Rtrim([Garage]))
      ,[GarageParkingNbr] = Ltrim(Rtrim([GarageParkingNbr]))
      ,[HeatCode] = Ltrim(Rtrim([HeatCode]))
      ,[HeatingFuelTypeCode] = Ltrim(Rtrim([HeatingFuelTypeCode]))
      ,[InteriorWallsCode] = Ltrim(Rtrim([InteriorWallsCode]))
      ,[PavingCode] = Ltrim(Rtrim([PavingCode]))
      ,[PatioCode] = Ltrim(Rtrim([PatioCode]))
      ,[PoolCode] = Ltrim(Rtrim([PoolCode]))
      ,[PorchCode] = Ltrim(Rtrim([PorchCode]))
      ,[RoofCoverCode] = Ltrim(Rtrim([RoofCoverCode]))
      ,[RoofTypeCode] = Ltrim(Rtrim([RoofTypeCode]))
      ,[SewerCode] = Ltrim(Rtrim([SewerCode]))
      ,[ShapeCode] = Ltrim(Rtrim([ShapeCode]))
      ,[StoriesCode_OLD] = Ltrim(Rtrim([StoriesCode_OLD]))
      ,[StoriesNbrCode_OLD] = Ltrim(Rtrim([StoriesNbrCode_OLD]))
      ,[StyleCode] = Ltrim(Rtrim([StyleCode]))
      ,[WallExteriorCode] = Ltrim(Rtrim([WallExteriorCode]))
      ,[WallheightCode] = Ltrim(Rtrim([WallheightCode]))
      ,[WaterCode] = Ltrim(Rtrim([WaterCode]))
      ,[YearBuilt] = Ltrim(Rtrim([YearBuilt]))
      ,[EffectiveYearBuilt] = Ltrim(Rtrim([EffectiveYearBuilt]))
      ,[AssdYear] = Ltrim(Rtrim([AssdYear]))
      ,[TaxRateCodeArea] = Ltrim(Rtrim([TaxRateCodeArea]))
      ,[TaxYear] = Ltrim(Rtrim([TaxYear]))
      ,[TaxAmount] = Ltrim(Rtrim([TaxAmount]))
      ,[TaxDeliquentYear1] = Ltrim(Rtrim([TaxDeliquentYear1]))
      ,[TaxDeliquentValue1] = Ltrim(Rtrim([TaxDeliquentValue1]))
      ,[TaxExemptionCode] = Ltrim(Rtrim([TaxExemptionCode]))
      ,[SchoolTaxDistrict1Code] = Ltrim(Rtrim([SchoolTaxDistrict1Code]))
      ,[SchoolTaxDistrict1Ind] = Ltrim(Rtrim([SchoolTaxDistrict1Ind]))
      ,[SchoolTaxDistrict2Code] = Ltrim(Rtrim([SchoolTaxDistrict2Code]))
      ,[SchoolTaxDistrict2Ind] = Ltrim(Rtrim([SchoolTaxDistrict2Ind]))
      ,[SchoolTaxDistrict3Code] = Ltrim(Rtrim([SchoolTaxDistrict3Code]))
      ,[SchoolTaxDistrict3Ind] = Ltrim(Rtrim([SchoolTaxDistrict3Ind]))
      ,[FADeleteFlag] = Ltrim(Rtrim([FADeleteFlag]))
      ,[FADeleteFlagDate] = Ltrim(Rtrim([FADeleteFlagDate]))



END

