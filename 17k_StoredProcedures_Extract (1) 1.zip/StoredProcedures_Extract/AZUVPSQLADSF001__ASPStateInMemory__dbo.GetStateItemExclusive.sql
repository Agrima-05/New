SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.GetStateItemExclusive(
	@SessionId nvarchar(88) NOT NULL,
	@Locked bit OUTPUT,
	@LockAge int OUTPUT,
	@LockCookie int OUTPUT,
	@Initialized bit OUTPUT,
	@Item varbinary(7000) OUTPUT
) WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')

	DECLARE @Now AS datetime2 NOT NULL = GETUTCDATE()
	DECLARE @LockDate AS datetime2
	DECLARE @ItemSize bigint NOT NULL = 0

	UPDATE dbo.Sessions
	SET
		Expires = DATEADD(minute, Timeout, @Now), 
		@Initialized = Initialized,
		Initialized = 1,
		@Locked = Locked,
		Locked = 1,
		@LockDate = LockDate,
		@LockCookie = LockCookie,
		@ItemSize = ItemSize,
		@Item = Item
	WHERE SessionId = @SessionId

	IF @@ROWCOUNT = 0
	BEGIN
		SET @Locked = 0
		SET @LockAge = 0
		SET @LockCookie = 0
		SET @Initialized = 0
		SET @Item = NULL

		RETURN;
	END

	IF @Locked = 0
	BEGIN
		SET @LockCookie = @LockCookie + 1

		UPDATE dbo.Sessions
		SET LockDate = @Now,
			@LockAge = 0,
			LockCookie = @LockCookie
		WHERE SessionId = @SessionId

		IF @ItemSize > 7000
		BEGIN
			-- Results have to be sorted by client.
			SELECT SessionItemId, Item
			FROM dbo.SessionItems
			WHERE SessionId = @SessionId
		END
	END
	ELSE
	BEGIN
		SET @LockAge = DATEDIFF(second, @LockDate, @Now)
		SET @Item = NULL
	END
END

