SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20180928
-- =============================================
CREATE PROCEDURE [dbo].[usp_Subdivision_unifiedV01] @tableName varchar(255)

AS
BEGIN

SET CONCAT_NULL_YIELDS_NULL OFF

declare @sql varchar(max) = ''

---  Clean Words

   set @sql = 'update [dbo].['+@tableName+']
   set N1 = null
   ,N2 = null
   ,N3 = null
   ,N4 = null
   ,N5 = null
   ,N6 = null
   ,N7 = null
   ,N8 = null
   ,N9 = null
   ,N10 = null
   ,N11 = null
   ,N12 = null
   from [dbo].['+@tableName+']'
   exec(@sql)	

----  Clean Garbage

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace(Replace(Replace(Replace(Name1,'''''''',''''),''#'',''''),''.'','' ''),''/'','' '')
   from [dbo].['+@tableName+']'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(name1,1,(len(name1)-1))
   from [dbo].['+@tableName+']
   where Name1 like ''%[a-z][0-9]'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = case when name1 like ''Plat of %'' then Replace(Name1,''Plat of '','''')
   when name1 like ''REPLAT OF %'' then Replace(Name1,''REPLAT OF '','''')
   when name1 like ''Extension OF %'' then Replace(Name1,''Extension OF '','''')
   when name1 like ''extn OF %'' then Replace(Name1,''extn OF '','''')
   else name1 end
   from [dbo].['+@tableName+']'
   exec(@sql)
   
----  Clean Beginning Tokens

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,14,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Subdivision of%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,12,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Subdivision%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,4,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Sub %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,12,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Section [a-z][a-z][a-z] %'' or Name1 like ''Section [0-9][0-9][0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,11,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Section [a-z][a-z][a-z] %'' or Name1 like ''Section [0-9][0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,10,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Section [a-z][a-z][a-z] %'' or Name1 like ''Section [0-9][0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,8,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Sec [a-z][a-z][a-z] %'' or Name1 like ''Sec [0-9][0-9][0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,7,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Sec [a-z][a-z][a-z] %'' or Name1 like ''Sec [0-9][0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,6,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''Sec [a-z] %'' or Name1 like ''Sec [0-9] %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,10,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''a part of %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring(Name1,8,100)))
   from [dbo].['+@tableName+']
   where Name1 like ''part of %'''
   exec(@sql)

-------  Standardize Names

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(name1,''MTN'',''MOUNTAIN'')
   from [dbo].['+@tableName+']
   where Name1 like ''%MTN%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(replace(name1,''EST'',''ESTATES'')))
   from [dbo].['+@tableName+']
   where LTRIM(RTRIM(Name1)) like ''% EST'' OR Name1 like ''% EST %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(name1,''estate'',''ESTATES'')
   from [dbo].['+@tableName+']
   where LTRIM(RTRIM(Name1)) like ''% estate'' OR Name1 like ''% estate %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(name1,''town home'',''TOWNHOMES'')
   from [dbo].['+@tableName+']
   where LTRIM(RTRIM(Name1)) like ''% town home'' OR Name1 like ''% town home %'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(name1,''town homes'',''TOWNHOMES'')
   from [dbo].['+@tableName+']
   where LTRIM(RTRIM(Name1)) like ''% town homes'' OR Name1 like ''% town homes %'''
   exec(@sql)

------- Parsing Name1 by Space delimiter into 12 separage fields
SET CONCAT_NULL_YIELDS_NULL ON

		EXEC('DECLARE @delimiter VARCHAR(50)
			SET @delimiter = '' ''

			SELECT CONVERT(bigint, ID) as ID,Name1
					,CAST(''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Name1,''>'','' ''),''<'','' ''),''&'','' AND ''),''+'','' AND ''),''.'',''''),''/'',''''),''  '','' ''),''-'','' ''), @delimiter , ''</M><M>'') + ''</M>'' AS XML) AS [Name XML]
				INTO #NameSplit2
				FROM  dbo.['+@tableName+']
				WHERE Name1 like ''% %''
				order by ID

			UPDATE d 
			SET d.N1 = replace(replace(x.N1,'','',''''),''.'','''')
			,d.N2 = replace(replace(x.N2,'','',''''),''.'','''')
			,d.N3 = replace(replace(x.N3,'','',''''),''.'','''')
			,d.N4 = replace(replace(x.N4,'','',''''),''.'','''')
			,d.N5 = replace(replace(x.N5,'','',''''),''.'','''')
			,d.N6 = replace(replace(x.N6,'','',''''),''.'','''')
			,d.N7 = replace(replace(x.N7,'','',''''),''.'','''')
			,d.N8 = replace(replace(x.N8,'','',''''),''.'','''')
			,d.N9 = replace(replace(x.N9,'','',''''),''.'','''')
			,d.N10 = replace(replace(x.N10,'','',''''),''.'','''')
			,d.N11 = replace(replace(x.N11,'','',''''),''.'','''')
			,d.N12 = replace(replace(x.N12,'','',''''),''.'','''')
			FROM [dbo].['+@tableName+'] d JOIN 
			(
				SELECT ID,Name1
					 ,[Name XML].value(''/M[1]'', ''varchar(50)'') as N1
					 ,[Name XML].value(''/M[2]'', ''varchar(50)'') as N2
					 ,[Name XML].value(''/M[3]'', ''varchar(50)'') as N3
					 ,[Name XML].value(''/M[4]'', ''varchar(50)'') as N4
					 ,[Name XML].value(''/M[5]'', ''varchar(50)'') as N5
					 ,[Name XML].value(''/M[6]'', ''varchar(50)'') as N6
					 ,[Name XML].value(''/M[7]'', ''varchar(50)'') as N7
					 ,[Name XML].value(''/M[8]'', ''varchar(50)'') as N8
					 ,[Name XML].value(''/M[9]'', ''varchar(50)'') as N9
					 ,[Name XML].value(''/M[10]'', ''varchar(50)'') as N10
					 ,[Name XML].value(''/M[11]'', ''varchar(50)'') as N11
					 ,[Name XML].value(''/M[12]'', ''varchar(50)'') as N12
				FROM #NameSplit2
			) x 
			on d.ID = x.ID
			
			DROP TABLE #NameSplit2
			')

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = case when n6 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''subdivision'' then n1 + '' '' + n2
			when n2 like ''subdivision'' then n1
			when n6 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''subdiv'' then n1 + '' '' + n2
			when n2 like ''subdiv'' then n1
			when n6 like ''subd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''subd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''subd'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''subd'' then n1 + '' '' + n2
			when n2 like ''subd'' then n1
			when n6 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''s\d'' then n1 + '' '' + n2
			when n2 like ''s\d'' then n1
			when n6 like ''s/d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''s/d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''s/d'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''s/d'' then n1 + '' '' + n2
			when n2 like ''s/d'' then n1
			when n6 like ''plat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''plat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''plat'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''plat'' then n1 + '' '' + n2
			when n2 like ''plat'' then n1
			when n6 like ''extension'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''extension'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''extension'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''extension'' then n1 + '' '' + n2
			when n2 like ''extension'' then n1
			when n6 like ''pud'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''pud'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''pud'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''pud'' then n1 + '' '' + n2
			when n2 like ''pud'' then n1
			when n6 like ''lots'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''lots'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''lots'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''lots'' then n1 + '' '' + n2
			when n2 like ''lots'' then n1
			when n6 like ''lot'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''lot'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''lot'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''lot'' then n1 + '' '' + n2
			when n2 like ''lot'' then n1
			when n7 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 +  '' '' + n6
			when n6 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''sub'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''sub'' then n1 + '' '' + n2
			when n2 like ''sub'' then n1
			when n6 like ''dev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''dev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''dev'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''dev'' then n1 + '' '' + n2
			when n2 like ''dev'' then n1
			when n6 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''condominiums'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''condominiums'' then n1 + '' CONDO''
			when n6 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''condominium'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''condominium'' then n1 + '' CONDO''
			when n6 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''condos'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''condos'' then n1 + '' CONDO''
			when n6 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''condo'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''condo'' then n1 + '' CONDO''
			when n6 like ''cond'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''cond'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''cond'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''cond'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''cond'' then n1 + '' CONDO''
			when n6 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''con'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''con'' then n1 + '' CONDO''
			when n6 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''cnd'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''cnd'' then n1 + '' CONDO''
			when n6 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
	        when n5 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
	        when n4 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
	        when n3 like ''CN'' then n1 + '' '' + n2 + '' CONDO''
			when n2 like ''CN'' then n1 + '' CONDO''
			when n6 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TOWNHOMES''
	        when n5 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TOWNHOMES''
	        when n4 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' TOWNHOMES''
	        when n3 like ''twnhm'' then n1 + '' '' + n2 + '' TOWNHOMES''
			when n2 like ''twnhm'' then n1 + '' TOWNHOMES''
			when n6 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TOWNHOME''
	        when n5 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TOWNHOME''
	        when n4 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' TOWNHOME''
	        when n3 like ''twnhm'' then n1 + '' '' + n2 + '' TOWNHOME''
			when n2 like ''twnhm'' then n1 + '' TOWNHOME''
			when n6 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TWNHMS''
	        when n5 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TWNHMS''
	        when n4 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' TWNHMS''
	        when n3 like ''twnhm'' then n1 + '' '' + n2 + '' TWNHMS''
			when n2 like ''twnhm'' then n1 + '' TWNHMS''
			when n6 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TWNHMS''
	        when n5 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TWNHMS''
	        when n4 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' TWNHMS''
	        when n3 like ''twnhms'' then n1 + '' '' + n2 + '' TWNHMS''
			when n2 like ''twnhms'' then n1 + '' TWNHMS''
			when n6 like ''tract'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''tract'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''tract'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''tract'' then n1 + '' '' + n2
			when n2 like ''tract'' then n1
			when n6 like ''unit'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
	        when n5 like ''unit'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''unit'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''unit'' then n1 + '' '' + n2
			when n2 like ''unit'' then n1
			when n6 like ''annex'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''annex'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''annex'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''annex'' then n1 + '' '' + n2
			when n2 like ''annex'' then n1
			when n6 like ''addition'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''addition'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''addition'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''addition'' then n1 + '' '' + n2
			when n2 like ''addition'' then n1
			when n6 like ''addn'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''addn'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''addn'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''addn'' then n1 + '' '' + n2
			when n2 like ''addn'' then n1
			when n6 like ''add'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''add'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''add'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''add'' then n1 + '' '' + n2
			when n2 like ''add'' then n1
			when n6 like ''add.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''add.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''add.'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''add.'' then n1 + '' '' + n2
			when n2 like ''add.'' then n1
			when n6 like ''resub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''resub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''resub'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''resub'' then n1 + '' '' + n2
			when n2 like ''resub'' then n1
			when n6 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''(replat)'' then n1 + '' '' + n2
			when n2 like ''(replat)'' then n1
			when n6 like ''replat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''replat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''replat'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''replat'' then n1 + '' '' + n2
			when n2 like ''replat'' then n1
			when n6 like ''repl'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''repl'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''repl'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''repl'' then n1 + '' '' + n2
			when n2 like ''repl'' then n1
			when n6 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''rplt'' then n1 + '' '' + n2
			when n2 like ''rplt'' then n1
			when n6 like ''rp'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''rp'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''rp'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''rp'' then n1 + '' '' + n2
			when n2 like ''rp'' then n1
			when n6 like ''block'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''block'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''block'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''block'' then n1 + '' '' + n2
			when n2 like ''block'' then n1
			when n6 like ''blks'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''blks'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''blks'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''blks'' then n1 + '' '' + n2
			when n2 like ''blks'' then n1
			when n6 like ''blk'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''blk'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''blk'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''blk'' then n1 + '' '' + n2
			when n2 like ''blk'' then n1
			when n6 like ''rep'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''rep'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''rep'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''rep'' then n1 + '' '' + n2
			when n2 like ''rep'' then n1
			when n6 like ''ext'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''ext'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''ext'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''ext'' then n1 + '' '' + n2
			when n2 like ''ext'' then n1
			when n6 like ''amd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''amd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''amd'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''amd'' then n1 + '' '' + n2
			when n2 like ''amd'' then n1
			when n6 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''amd.'' then n1 + '' '' + n2
			when n2 like ''amd.'' then n1
			when n6 like ''phase'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''phase'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''phase'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''phase'' then n1 + '' '' + n2
			when n2 like ''phase'' then n1
			when n6 like ''ph'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''ph'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''ph'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''ph'' then n1 + '' '' + n2
			when n2 like ''ph'' then n1
			when n6 like ''p-'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''p-'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''p-'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''p-'' then n1 + '' '' + n2
			when n2 like ''p-'' then n1
			when n6 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''p[0-9]'' then n1 + '' '' + n2
			when n2 like ''p[0-9]'' then n1
			when n6 like ''secs'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''secs'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''secs'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''secs'' then n1 + '' '' + n2
			when n2 like ''secs'' then n1
			when n6 like ''section'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''section'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''section'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''section'' then n1 + '' '' + n2
			when n2 like ''section'' then n1
			when n6 like ''sec'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''sec'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''sec'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''sec'' then n1 + '' '' + n2
			when n2 like ''sec'' then n1
			when n6 like ''rev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''rev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''rev'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''rev'' then n1 + '' '' + n2
			when n2 like ''rev'' then n1
			when n6 like ''map'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''map'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''map'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''map'' then n1 + '' '' + n2
			when n2 like ''map'' then n1
			when n6 like ''tr'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''tr'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''tr'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''tr'' then n1 + '' '' + n2
			when n2 like ''tr'' then n1
			when n6 like ''no'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''no'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''no'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''no'' then n1 + '' '' + n2
			when n2 like ''no'' then n1
			when n6 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2
			when n2 like ''[0-9][0-9][0-9]%'' then n1
			when n6 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''[0-9][0-9]%'' then n1 + '' '' + n2
			when n2 like ''[0-9][0-9]%'' then n1
			when n6 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''[0-9][a-z]%'' then n1 + '' '' + n2
			when n2 like ''[0-9][a-z]%'' then n1
			when n6 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''[0-9]'' then n1 + '' '' + n2
			when n2 like ''[0-9]'' then n1
			when n6 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''[a-z]'' then n1 + '' '' + n2
			--when n2 like ''[a-z]'' then n1
			when n6 like ''1st'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''1st'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''1st'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''1st'' then n1 + '' '' + n2
			when n2 like ''1st'' then n1
			when n6 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''2nd'' then n1 + '' '' + n2
			when n2 like ''2nd'' then n1
			when n6 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''3rd'' then n1 + '' '' + n2
			when n2 like ''3rd'' then n1
			when n6 like ''4th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''4th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''4th'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''4th'' then n1 + '' '' + n2
			when n2 like ''4th'' then n1
			when n6 like ''5th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''5th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''5th'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''5th'' then n1 + '' '' + n2
			when n2 like ''5th'' then n1
			when n6 like ''6th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''6th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''6th'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''6th'' then n1 + '' '' + n2
			when n2 like ''6th'' then n1
			when n6 like ''7th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''7th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''7th'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''7th'' then n1 + '' '' + n2
			when n2 like ''7th'' then n1
			when n6 like ''first'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''first'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''first'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''first'' then n1 + '' '' + n2
			when n2 like ''first'' then n1
			when n6 like ''second'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''second'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''second'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''second'' then n1 + '' '' + n2
			when n2 like ''second'' then n1
			when n6 like ''third'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''third'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''third'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''third'' then n1 + '' '' + n2
			when n2 like ''third'' then n1
			when n6 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''fourth'' then n1 + '' '' + n2
			when n2 like ''fourth'' then n1
			when n6 like ''forth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''forth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''forth'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''forth'' then n1 + '' '' + n2
			when n2 like ''forth'' then n1
			when n6 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''fifth'' then n1 + '' '' + n2
			when n2 like ''fifth'' then n1
			when n6 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''sixth'' then n1 + '' '' + n2
			when n2 like ''sixth'' then n1
			when n6 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''seventh'' then n1 + '' '' + n2
			when n2 like ''seventh'' then n1
			when n6 like ''i'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''i'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''i'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''i'' then n1 + '' '' + n2
			when n2 like ''i'' then n1
			when n6 like ''ii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''ii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''ii'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''ii'' then n1 + '' '' + n2
			when n2 like ''ii'' then n1
			when n6 like ''iii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''iii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''iii'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''iii'' then n1 + '' '' + n2
			when n2 like ''iii'' then n1
			when n6 like ''iv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''iv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''iv'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''iv'' then n1 + '' '' + n2
			when n2 like ''iv'' then n1
			when n6 like ''v'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''v'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''v'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''v'' then n1 + '' '' + n2
			--when n2 like ''v'' then n1
			when n6 like ''vi'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''vi'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''vi'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''vi'' then n1 + '' '' + n2
			when n2 like ''vi'' then n1
			when n6 like ''vii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''vii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''vii'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''vii'' then n1 + '' '' + n2
			when n2 like ''vii'' then n1
			when n6 like ''viii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''viii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''viii'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''viii'' then n1 + '' '' + n2
			when n2 like ''viii'' then n1
			when n6 like ''x'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
			when n5 like ''x'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
	        when n4 like ''x'' then n1 + '' '' + n2 + '' '' + n3
	        when n3 like ''x'' then n1 + '' '' + n2
			when n2 like ''x'' then n1
	  else Name1 end
   from [dbo].['+@tableName+']'
    exec(@sql)

----  Added to Append Condo
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim([Name1] + '' '' + ''CONDO''))
   from [dbo].['+@tableName+']
   where [landuse] = ''1004'' and [Name1] not like ''%condo%'''
   exec(@sql)

-----  Clean Words

--   set @sql = 'update [dbo].['+@tableName+']
--   set N1 = null
--   ,N2 = null
--   ,N3 = null
--   ,N4 = null
--   ,N5 = null
--   ,N6 = null
--   ,N7 = null
--   ,N8 = null
--   ,N9 = null
--   ,N10 = null
--   ,N11 = null
--   ,N12 = null
--   from [dbo].['+@tableName+']'
--   exec(@sql)	    
			
--			EXEC('DECLARE @delimiter VARCHAR(50)
--			SET @delimiter = '' ''

--			SELECT CONVERT(bigint, ID) as ID,Name1
--					,CAST(''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Name1,''>'','' ''),''<'','' ''),''&'','' AND ''),''+'','' AND ''),''.'',''''),''/'',''''),''  '','' ''),''-'','' ''), @delimiter , ''</M><M>'') + ''</M>'' AS XML) AS [Name XML]
--				INTO #NameSplit2
--				FROM  dbo.['+@tableName+']
--				WHERE Name1 like ''% %''
--				order by ID

--			UPDATE d 
--			SET d.N1 = replace(replace(x.N1,'','',''''),''.'','''')
--			,d.N2 = replace(replace(x.N2,'','',''''),''.'','''')
--			,d.N3 = replace(replace(x.N3,'','',''''),''.'','''')
--			,d.N4 = replace(replace(x.N4,'','',''''),''.'','''')
--			,d.N5 = replace(replace(x.N5,'','',''''),''.'','''')
--			,d.N6 = replace(replace(x.N6,'','',''''),''.'','''')
--			,d.N7 = replace(replace(x.N7,'','',''''),''.'','''')
--			,d.N8 = replace(replace(x.N8,'','',''''),''.'','''')
--			,d.N9 = replace(replace(x.N9,'','',''''),''.'','''')
--			,d.N10 = replace(replace(x.N10,'','',''''),''.'','''')
--			,d.N11 = replace(replace(x.N11,'','',''''),''.'','''')
--			,d.N12 = replace(replace(x.N12,'','',''''),''.'','''')
--			FROM [dbo].['+@tableName+'] d JOIN 
--			(
--				SELECT ID,Name1
--					 ,[Name XML].value(''/M[1]'', ''varchar(50)'') as N1
--					 ,[Name XML].value(''/M[2]'', ''varchar(50)'') as N2
--					 ,[Name XML].value(''/M[3]'', ''varchar(50)'') as N3
--					 ,[Name XML].value(''/M[4]'', ''varchar(50)'') as N4
--					 ,[Name XML].value(''/M[5]'', ''varchar(50)'') as N5
--					 ,[Name XML].value(''/M[6]'', ''varchar(50)'') as N6
--					 ,[Name XML].value(''/M[7]'', ''varchar(50)'') as N7
--					 ,[Name XML].value(''/M[8]'', ''varchar(50)'') as N8
--					 ,[Name XML].value(''/M[9]'', ''varchar(50)'') as N9
--					 ,[Name XML].value(''/M[10]'', ''varchar(50)'') as N10
--					 ,[Name XML].value(''/M[11]'', ''varchar(50)'') as N11
--					 ,[Name XML].value(''/M[12]'', ''varchar(50)'') as N12
--				FROM #NameSplit2
--			) x 
--			on d.ID = x.ID
			
--			DROP TABLE #NameSplit2
--			')
--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = case when n6 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''subdivision'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''subdivision'' then n1 + '' '' + n2
--			when n2 like ''subdivision'' then n1
--			when n6 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''subdiv'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''subdiv'' then n1 + '' '' + n2
--			when n2 like ''subdiv'' then n1
--			when n6 like ''subd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''subd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''subd'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''subd'' then n1 + '' '' + n2
--			when n2 like ''subd'' then n1
--			when n6 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''s\d'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''s\d'' then n1 + '' '' + n2
--			when n2 like ''s\d'' then n1
--			when n6 like ''pud'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''pud'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''pud'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''pud'' then n1 + '' '' + n2
--			when n2 like ''pud'' then n1
--			when n6 like ''lots'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''lots'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''lots'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''lots'' then n1 + '' '' + n2
--			when n2 like ''lots'' then n1
--			when n6 like ''lot'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''lot'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''lot'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''lot'' then n1 + '' '' + n2
--			when n2 like ''lot'' then n1
--			when n7 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 +  '' '' + n6
--			when n6 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''sub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''sub'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''sub'' then n1 + '' '' + n2
--			when n2 like ''sub'' then n1
--			when n6 like ''dev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''dev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''dev'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''dev'' then n1 + '' '' + n2
--			when n2 like ''dev'' then n1
--			when n6 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''condominiums'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''condominiums'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''condominiums'' then n1 + '' CONDO''
--			when n6 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''condominium'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''condominium'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''condominium'' then n1 + '' CONDO''
--			when n6 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''condos'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''condos'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''condos'' then n1 + '' CONDO''
--			when n6 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''condo'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''condo'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''condo'' then n1 + '' CONDO''
--			when n6 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''con'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''con'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''con'' then n1 + '' CONDO''
--			when n6 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''cnd'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''cnd'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''cnd'' then n1 + '' CONDO''
--			when n6 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' CONDO''
--	        when n5 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' CONDO''
--	        when n4 like ''CN'' then n1 + '' '' + n2 + '' '' + n3 + '' CONDO''
--	        when n3 like ''CN'' then n1 + '' '' + n2 + '' CONDO''
--			when n2 like ''CN'' then n1 + '' CONDO''
--			when n6 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TWNHMS''
--	        when n5 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TWNHMS''
--	        when n4 like ''twnhm'' then n1 + '' '' + n2 + '' '' + n3 + '' TWNHMS''
--	        when n3 like ''twnhm'' then n1 + '' '' + n2 + '' TWNHMS''
--			when n2 like ''twnhm'' then n1 + '' TWNHMS''
--			when n6 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5 + '' TWNHMS''
--	        when n5 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' TWNHMS''
--	        when n4 like ''twnhms'' then n1 + '' '' + n2 + '' '' + n3 + '' TWNHMS''
--	        when n3 like ''twnhms'' then n1 + '' '' + n2 + '' TWNHMS''
--			when n2 like ''twnhms'' then n1 + '' TWNHMS''
--			when n6 like ''tract'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''tract'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''tract'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''tract'' then n1 + '' '' + n2
--			when n2 like ''tract'' then n1
--			when n6 like ''unit'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--	        when n5 like ''unit'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''unit'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''unit'' then n1 + '' '' + n2
--			when n2 like ''unit'' then n1
--			when n6 like ''annex'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''annex'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''annex'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''annex'' then n1 + '' '' + n2
--			when n2 like ''annex'' then n1
--			when n6 like ''addition'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''addition'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''addition'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''addition'' then n1 + '' '' + n2
--			when n2 like ''addition'' then n1
--			when n6 like ''addn'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''addn'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''addn'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''addn'' then n1 + '' '' + n2
--			when n2 like ''addn'' then n1
--			when n6 like ''add'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''add'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''add'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''add'' then n1 + '' '' + n2
--			when n2 like ''add'' then n1
--			when n6 like ''add.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''add.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''add.'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''add.'' then n1 + '' '' + n2
--			when n2 like ''add.'' then n1
--			when n6 like ''resub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''resub'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''resub'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''resub'' then n1 + '' '' + n2
--			when n2 like ''resub'' then n1
--			when n6 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''(replat)'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''(replat)'' then n1 + '' '' + n2
--			when n2 like ''(replat)'' then n1
--			when n6 like ''replat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''replat'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''replat'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''replat'' then n1 + '' '' + n2
--			when n2 like ''replat'' then n1
--			when n6 like ''repl'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''repl'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''repl'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''repl'' then n1 + '' '' + n2
--			when n2 like ''repl'' then n1
--			when n6 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''rplt'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''rplt'' then n1 + '' '' + n2
--			when n2 like ''rplt'' then n1
--			when n6 like ''rp'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''rp'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''rp'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''rp'' then n1 + '' '' + n2
--			when n2 like ''rp'' then n1
--			when n6 like ''block'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''block'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''block'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''block'' then n1 + '' '' + n2
--			when n2 like ''block'' then n1
--			when n6 like ''blks'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''blks'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''blks'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''blks'' then n1 + '' '' + n2
--			when n2 like ''blks'' then n1
--			when n6 like ''blk'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''blk'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''blk'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''blk'' then n1 + '' '' + n2
--			when n2 like ''blk'' then n1
--			when n6 like ''rep'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''rep'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''rep'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''rep'' then n1 + '' '' + n2
--			when n2 like ''rep'' then n1
--			when n6 like ''ext'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''ext'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''ext'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''ext'' then n1 + '' '' + n2
--			when n2 like ''ext'' then n1
--			when n6 like ''amd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''amd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''amd'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''amd'' then n1 + '' '' + n2
--			when n2 like ''amd'' then n1
--			when n6 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''amd.'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''amd.'' then n1 + '' '' + n2
--			when n2 like ''amd.'' then n1
--			when n6 like ''phase'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''phase'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''phase'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''phase'' then n1 + '' '' + n2
--			when n2 like ''phase'' then n1
--			when n6 like ''ph'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''ph'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''ph'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''ph'' then n1 + '' '' + n2
--			when n2 like ''ph'' then n1
--			when n6 like ''p-'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''p-'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''p-'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''p-'' then n1 + '' '' + n2
--			when n2 like ''p-'' then n1
--			when n6 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''p[0-9]'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''p[0-9]'' then n1 + '' '' + n2
--			when n2 like ''p[0-9]'' then n1
--			when n6 like ''secs'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''secs'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''secs'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''secs'' then n1 + '' '' + n2
--			when n2 like ''secs'' then n1
--			when n6 like ''section'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''section'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''section'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''section'' then n1 + '' '' + n2
--			when n2 like ''section'' then n1
--			when n6 like ''sec'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''sec'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''sec'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''sec'' then n1 + '' '' + n2
--			when n2 like ''sec'' then n1
--			when n6 like ''rev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''rev'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''rev'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''rev'' then n1 + '' '' + n2
--			when n2 like ''rev'' then n1
--			when n6 like ''map'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''map'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''map'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''map'' then n1 + '' '' + n2
--			when n2 like ''map'' then n1
--			when n6 like ''tr'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''tr'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''tr'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''tr'' then n1 + '' '' + n2
--			when n2 like ''tr'' then n1
--			when n6 like ''no'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''no'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''no'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''no'' then n1 + '' '' + n2
--			when n2 like ''no'' then n1
--			when n6 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''[0-9][0-9][0-9]%'' then n1 + '' '' + n2
--			when n2 like ''[0-9][0-9][0-9]%'' then n1
--			when n6 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''[0-9][0-9]%'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''[0-9][0-9]%'' then n1 + '' '' + n2
--			when n2 like ''[0-9][0-9]%'' then n1
--			when n6 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''[0-9][a-z]%'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''[0-9][a-z]%'' then n1 + '' '' + n2
--			when n2 like ''[0-9][a-z]%'' then n1
--			when n6 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''[0-9]'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''[0-9]'' then n1 + '' '' + n2
--			when n2 like ''[0-9]'' then n1
--			when n6 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''[a-z]'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''[a-z]'' then n1 + '' '' + n2
--			--when n2 like ''[a-z]'' then n1
--			when n6 like ''1st'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''1st'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''1st'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''1st'' then n1 + '' '' + n2
--			when n2 like ''1st'' then n1
--			when n6 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''2nd'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''2nd'' then n1 + '' '' + n2
--			when n2 like ''2nd'' then n1
--			when n6 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''3rd'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''3rd'' then n1 + '' '' + n2
--			when n2 like ''3rd'' then n1
--			when n6 like ''4th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''4th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''4th'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''4th'' then n1 + '' '' + n2
--			when n2 like ''4th'' then n1
--			when n6 like ''5th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''5th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''5th'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''5th'' then n1 + '' '' + n2
--			when n2 like ''5th'' then n1
--			when n6 like ''6th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''6th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''6th'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''6th'' then n1 + '' '' + n2
--			when n2 like ''6th'' then n1
--			when n6 like ''7th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''7th'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''7th'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''7th'' then n1 + '' '' + n2
--			when n2 like ''7th'' then n1
--			when n6 like ''first'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''first'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''first'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''first'' then n1 + '' '' + n2
--			when n2 like ''first'' then n1
--			when n6 like ''second'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''second'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''second'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''second'' then n1 + '' '' + n2
--			when n2 like ''second'' then n1
--			when n6 like ''third'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''third'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''third'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''third'' then n1 + '' '' + n2
--			when n2 like ''third'' then n1
--			when n6 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''fourth'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''fourth'' then n1 + '' '' + n2
--			when n2 like ''fourth'' then n1
--			when n6 like ''forth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''forth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''forth'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''forth'' then n1 + '' '' + n2
--			when n2 like ''forth'' then n1
--			when n6 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''fifth'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''fifth'' then n1 + '' '' + n2
--			when n2 like ''fifth'' then n1
--			when n6 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''sixth'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''sixth'' then n1 + '' '' + n2
--			when n2 like ''sixth'' then n1
--			when n6 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''seventh'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''seventh'' then n1 + '' '' + n2
--			when n2 like ''seventh'' then n1
--			when n6 like ''i'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''i'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''i'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''i'' then n1 + '' '' + n2
--			when n2 like ''i'' then n1
--			when n6 like ''ii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''ii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''ii'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''ii'' then n1 + '' '' + n2
--			when n2 like ''ii'' then n1
--			when n6 like ''iii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''iii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''iii'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''iii'' then n1 + '' '' + n2
--			when n2 like ''iii'' then n1
--			when n6 like ''iv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''iv'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''iv'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''iv'' then n1 + '' '' + n2
--			when n2 like ''iv'' then n1
--			when n6 like ''v'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''v'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''v'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''v'' then n1 + '' '' + n2
--			--when n2 like ''v'' then n1
--			when n6 like ''vi'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''vi'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''vi'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''vi'' then n1 + '' '' + n2
--			when n2 like ''vi'' then n1
--			when n6 like ''vii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''vii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''vii'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''vii'' then n1 + '' '' + n2
--			when n2 like ''vii'' then n1
--			when n6 like ''viii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''viii'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''viii'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''viii'' then n1 + '' '' + n2
--			when n2 like ''viii'' then n1
--			when n6 like ''x'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4 + '' '' + n5
--			when n5 like ''x'' then n1 + '' '' + n2 + '' '' + n3 + '' '' + n4
--	        when n4 like ''x'' then n1 + '' '' + n2 + '' '' + n3
--	        when n3 like ''x'' then n1 + '' '' + n2
--			when n2 like ''x'' then n1
--	  else Name1 end
--   from [dbo].['+@tableName+']'
--    exec(@sql)
--SET CONCAT_NULL_YIELDS_NULL ON


END



