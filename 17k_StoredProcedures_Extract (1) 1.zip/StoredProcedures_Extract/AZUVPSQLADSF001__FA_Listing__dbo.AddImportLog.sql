SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE dbo.AddImportLog
	@LogTimestamp DATETIME
	,@Level VARCHAR(MAX)
	,@Logger VARCHAR(MAX)
	,@Message VARCHAR(MAX)
AS
	INSERT INTO dbo.ImportLog (LogTimestamp, [Level], Logger, [Message])
	VALUES (@LogTimestamp, @Level, @Logger, @Message)

