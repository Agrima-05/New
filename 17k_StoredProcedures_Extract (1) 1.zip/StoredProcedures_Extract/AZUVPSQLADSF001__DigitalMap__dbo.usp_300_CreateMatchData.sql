SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_300_CreateMatchData] 
AS
BEGIN
	SET NOCOUNT ON;

--SET ANSI_PADDING ON
--GO

--CREATE TABLE [dbo].[m_PatternCount](
--	[Fips] [varchar](5) NULL,
--	[Pattern] [varchar](500) NULL,
--	[Count] [int] NULL,
--	[OccurrenceRatio] [float] NULL,
--	[TotalSamplesInPool] [int] NULL,
--	[SourcePattern] [varchar](100) NULL,
--	[DestPattern] [varchar](100) NULL,
--	[MatchRule] [varchar](300) NULL,
--	[SourceMatchedPattern] [varchar](100) NULL,
--	[DestMatchedPattern] [varchar](100) NULL,
--	[DestColumnName] [varchar](50) NULL,
--) ON [PRIMARY]

--GO

--SET ANSI_PADDING OFF
--GO

--1) Create Traning stats	
SELECT Fips, COUNT(*) as Count INTO #FA_DMTrainingStats from [dbo].m_FA_DMTraining with(nolock) group by Fips


--2)Collect distinct patterns and store in PatternCount table
insert into [dbo].[m_PatternCount] (Fips, Pattern, Count, DestColumnName)
select Fips, FormattedApnPattern, Count(*) as Count, 'FormattedApn' from [dbo].m_FA_DMTraining with(nolock) group by Fips, FormattedApnPattern

insert into [dbo].[m_PatternCount] (Fips, Pattern, Count, DestColumnName)
select Fips, TaxAccountPattern, Count(*) as Count, 'TaxAccountNumber' from [dbo].m_FA_DMTraining with(nolock) group by Fips, TaxAccountPattern


--3) Calculate pattern matched stats
update c set c.TotalSamplesInPool = s.Count,c.OccurrenceRatio  =  (c.Count * 1.0) / s.Count
  FROM [dbo].[m_PatternCount] c left join [dbo].#FA_DMTrainingStats s on c.Fips = s.Fips



--4) Decode   SourceMatchedPattern and DestMatchedPattern. These pattern are pattern of Alphas, Digits and Special Char with indication of which characters were matched.
update c set 
c.SourceMatchedPattern = substring([Pattern], 3, patindex('%|%', [Pattern]) - 3 ),
c.DestMatchedPattern = substring([Pattern],  patindex('%|D%', [Pattern]) + 3, patindex('%>%', [Pattern]) - patindex('%|D%', [Pattern]) -3 )
  FROM [dbo].[m_PatternCount] c --left join #FA_DMTrainingStats s on c.Fips = s.Fips
    


--  update c set 
--c.SourcePattern = substring([Pattern], 3, patindex('%|%', [Pattern]) - 3 ),
--c.DestPattern = substring([Pattern],  patindex('%|D%', [Pattern]) + 3, patindex('%>%', [Pattern]) - patindex('%|D%', [Pattern]) -3 )
--  FROM [dbo].[PatternCount] c left join #FA_DMTrainingStats s on c.Fips = s.Fips


--5) Decode   SourcePattern and SourcePattern. These pattern are pattern of Alphas, Digits and Special Char WITHOUT indication of which characters were matched.  
  update c set 
c.SourcePattern = [dbo].GetRawPatternFromMatchPattern(SourceMatchedPattern),
c.DestPattern = [dbo].GetRawPatternFromMatchPattern(DestMatchedPattern)
  FROM [dbo].[m_PatternCount] c --left join #FA_DMTrainingStats s on c.Fips = s.Fips

  --6) Decode Match Rules
  update c set c.MatchRule =  substring([Pattern],  patindex('%>%', [Pattern]) + 1,1000)
  --select top 100 substring([Pattern],  patindex('%>%', [Pattern]) + 1,1000)
  FROM [dbo].[m_PatternCount] c --left join #FA_DMTrainingStats s on c.Fips = s.Fips


END


