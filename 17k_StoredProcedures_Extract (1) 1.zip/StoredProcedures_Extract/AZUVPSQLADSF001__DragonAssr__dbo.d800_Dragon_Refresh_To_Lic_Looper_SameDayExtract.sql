SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d800_Dragon_Refresh_To_Lic_Looper_SameDayExtract]
AS
BEGIN
	SET NOCOUNT ON;

				DECLARE @1 varchar(355) = 'micsmith@firstam.com; jeschmeyer@firstam.com;klowe@firstam.com', 
				@t_profile_name1 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject1 varchar(50) = 'Dragon Assr Load Started',
				@t_body1 varchar(2000) = 'The Dragon Assr Data Load process has Started.'


				SET NOCOUNT ON;
				DECLARE @t_getdate1 datetime = GETDATE()
				SET @t_body1 = @t_body1 + ' : ' + cast(@t_getdate1 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @1,
					@profile_name = @t_profile_name1,
					@subject = @t_subject1,
					@body = @t_body1



		DROP TABLE IF EXISTS dbo.ReRunThese

		select [name] 
		into dbo.ReRunThese 
		from (SELECT RIGHT(a.[name],5) [name]
			FROM sys.tables a JOIN (select o.[name],i.rowcnt from sysobjects o JOIN sysindexes I
					ON o.id = i.id
					where o.type = 'u'
					and i.indid IN (0,1)
					and i.rowcnt =0
					) b
			ON a.[name] = b.[name]
			WHERE a.[name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]' and rowcnt =0) info

		DECLARE @FipsCode varchar(5)

		DECLARE curDropEmpty CURSOR FOR  
			SELECT RIGHT(a.[name],5)
			FROM sys.tables a JOIN (select o.[name],i.rowcnt from sysobjects o JOIN sysindexes I
					ON o.id = i.id
					where o.type = 'u'
					and i.indid IN (0,1)
					and i.rowcnt =0
					) b
			ON a.[name] = b.[name]
			WHERE a.[name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]' and rowcnt = 0
			ORDER BY a.[name]

		OPEN curDropEmpty   
		FETCH NEXT FROM curDropEmpty INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode + ' NO Records'

			EXEC('DROP TABLE IF EXISTS PropertyWork_' + @FipsCode + '')
			
			UPDATE dbo.Dragon_Refresh_Tracker
			SET [RunRefresh] = 'N'
			WHERE FIPS = @FipsCode

	
			FETCH NEXT FROM curDropEmpty INTO @FipsCode   
		END   

		CLOSE curDropEmpty   
		DEALLOCATE curDropEmpty 


		--DECLARE @FipsCode varchar(5)

		DECLARE curProcessRefreshes CURSOR FOR  
			SELECT RIGHT(a.[name],5)
			FROM sys.tables a JOIN (select o.[name],i.rowcnt from sysobjects o JOIN sysindexes I
					ON o.id = i.id
					where o.type = 'u'
					and i.indid IN (0,1)
					) b
			ON a.[name] = b.[name]
			WHERE a.[name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]' and rowcnt >0
				--and a.name like '%06003'
			ORDER BY a.[name]

		OPEN curProcessRefreshes   
		FETCH NEXT FROM curProcessRefreshes INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC('Update a
			SET [StdLandUseCode] = c.[FlankCode]
			,a.[PropertyClassID] = c.[PropClassID]
			,a.[CountyLandUseDescription] = c.[Code_Desctiprtion]
			from PropertyWork_' + @FipsCode + ' a
			JOIN [AZUVPSQLDTDB029.DATATREE.LOCAL].[Assr].dbo.[Assr] b with(NOLOCK)
			on a.DTDB_REF_ID = b.REF_ID
			JOIN dbo.LandUseLookup C on b.[Land_Use] = c.[Value]
			where b.Fips = ' + @FipsCode + ' 
			and (a.StdLandUseCode is NULL OR a.StdLandUseCode <> c.FlankCode)
			')

			EXEC [dbo].[d850_Post_Dragon_To_Licensing_REFRESH_SameDayExtract] @FipsCode

				UPDATE Property
				SET BathTotalCalc = convert(money,bathfull) 
							+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
								+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
									+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end
				from [Data].[dbo].[Property] with(NOLOCK)
				where FIPS = @FipsCode and
				(FASourceInd = 'D' and (convert(money,bathfull) 
							+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
								+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
									+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end != BathTotalCalc))
				and convert(money,bathfull) 
							+ (Case When BathHalf is not null then convert(money,BathHalf) * .5 Else 0 End) 
								+ Case When Bath3QTR is not null then convert(money,Bath3QTR) * .75 Else 0 End 
									+ Case when Bath1QTR is not null then convert(money,Bath1QTR) *.25 Else 0 end < 100
				and [BathsParcialNbr] > 0
				and BathFull<100
				and cast([BathFull] as money) + (cast([BathsParcialNbr] as money) / 2) >= 1


			UPDATE dbo.Dragon_Refresh_Tracker
			SET [PushedToProduction] = GetDate()
			,RunRefresh = 'D'
			WHERE FIPS = @FipsCode

			INSERT INTO DATA.dbo.DailyPropID_II
			SELECT FIPS,FAPropertyID,Convert(varchar(8),GETDATE()+1,112),'D'
			FROM DATA.dbo.Deed with(NOLOCK)
			WHERE FIPS = @FipsCode
				AND FADateReceived >= (SELECT DateLastRefresh-30 FROM dbo.Dragon_Refresh_Tracker WHERE FIPS = @FipsCode)
				AND FAPropertyId is not null
			
			
			FETCH NEXT FROM curProcessRefreshes INTO @FipsCode   
		END   

		CLOSE curProcessRefreshes   
		DEALLOCATE curProcessRefreshes 


				DECLARE @3 varchar(355) = 'micsmith@firstam.com; jeschmeyer@firstam.com;klowe@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon Assr Load Finished',
				@t_body3 varchar(2000) = 'The Dragon Assr Data Load process has finished.'


				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + ' : ' + cast(@t_getdate3 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3


END
