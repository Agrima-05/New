SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE procedure [dbo].[CLAddrAddPoint--] (@fips int) as

insert CLAddrPoints (AddrID, fips, ref_id, latitude, longitude)
select addrid, Fips, ref_id, latitude, longitude
from CL_Address_Base where FIPS = @fips and Latitude > 0 and Longitude < 0 and Address_Type = 'S'


