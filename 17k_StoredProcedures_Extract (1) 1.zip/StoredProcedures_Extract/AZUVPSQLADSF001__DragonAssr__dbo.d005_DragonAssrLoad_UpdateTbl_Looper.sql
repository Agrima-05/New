SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d005_DragonAssrLoad_UpdateTbl_Looper]
AS
BEGIN
	SET NOCOUNT ON;


	TRUNCATE TABLE [dbo].[PropertyWorkUpdateTbl]

		DECLARE @Date varchar(8)

	SET @Date = convert(varchar(8),Getdate()+1,112)

			EXEC [dbo].[d050_RunDragonAssrProcess_UPDATETbl] @Date



END
