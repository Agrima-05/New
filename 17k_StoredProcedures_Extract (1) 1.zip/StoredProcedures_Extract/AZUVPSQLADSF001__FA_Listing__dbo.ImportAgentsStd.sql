SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[ImportAgentsStd]
AS
	-- Unlink records that are now mismatched due to MatchId changes
	UPDATE a
	SET MLS_Listing_Agent_CODE_STD = NULL
	FROM MLS_Listing_Agent a
	INNER JOIN MLS_Listing_Agent b ON a.MatchId = b.MLS_Listing_Agent_CODE
	WHERE a.MLS_Listing_Agent_CODE_STD <> b.MLS_Listing_Agent_CODE_STD

	-- First try to match to an existing standard record
	UPDATE a
	SET MLS_Listing_Agent_CODE_std = b.MLS_Listing_Agent_CODE_std
	FROM MLS_Listing_Agent a
	INNER JOIN MLS_Listing_Agent b ON a.MatchId = b.MLS_Listing_Agent_CODE
	WHERE (a.MLS_Listing_Agent_CODE_std IS NULL AND b.MLS_Listing_Agent_CODE_std IS NOT NULL) OR a.MLS_Listing_Agent_CODE_std <> b.MLS_Listing_Agent_CODE_std

	-- Add orphaned records (caused by above update) to AgentStdMerge table
	INSERT INTO AgentStdMerge
	SELECT
		a.MLS_Listing_Agent_CODE_STD
		,b.MLS_Listing_Agent_CODE_STD
		,GETDATE()
	FROM MLS_Listing_Agent_Std a
	INNER JOIN MLS_Listing_Agent b ON a.MLS_LISTING_AGENT_CODE_ORIG = b.MLS_Listing_Agent_CODE
	WHERE a.MLS_Listing_Agent_CODE_STD NOT IN (
		SELECT MLS_Listing_Agent_CODE_STD
		FROM MLS_Listing_Agent
	) AND a.MLS_Listing_Agent_CODE_STD NOT IN (
		SELECT MLS_Listing_Agent_CODE_STD_From
		FROM AgentStdMerge
	)

	-- Delete orphaned records
	DELETE
	FROM MLS_Listing_Agent_Std
	WHERE MLS_Listing_Agent_CODE_STD NOT IN (
		SELECT MLS_Listing_Agent_CODE_STD
		FROM MLS_Listing_Agent
	)

	SELECT
		ROW_NUMBER() OVER (PARTITION BY MatchId ORDER BY [Weight] DESC, MLS_Listing_Agent_CODE DESC) AS RowNum
		,*
	INTO #AgentStd
	FROM (
		SELECT
			 a.[MLS_Listing_Agent_CODE]
			,a.[MatchId]
			,CASE WHEN a.MLS_LISTING_AGENT_NAME > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.MLS_LISTING_AGENT_ADDRESS > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.MLS_LISTING_AGENT_LICENSE_NBR > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE1 > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE2 > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE3 > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE4 > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.AGENT_PHONE5 > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.MLS_LISTING_AGENT_COMPANY > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.MLS_LISTING_AGENT_EMAIL > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.First_Name > '' THEN 1 ELSE 0 END
				+ CASE WHEN a.Last_Name > '' THEN 1 ELSE 0 END
			AS [Weight]
		FROM [MLS_Listing_Agent] a
		WHERE MLS_Listing_Agent_CODE_std IS NULL
	) b

	INSERT INTO MLS_Listing_Agent_std (
		 [MLS_LISTING_AGENT_CODE_ORIG]
		,[MLS_Listing_Agent_CHECKSUM]
		,[MLS_LISTING_AGENT_LICENSE_NBR]
		,[MLS_LISTING_AGENT_NAME]
		,[MLS_LISTING_AGENT_ADDRESS]
		,[AGENT_PHONE]
		,[AGENT_PHONE1]
		,[AGENT_PHONE2]
		,[AGENT_PHONE3]
		,[AGENT_PHONE4]
		,[AGENT_PHONE5]
		,[AGENT_PHONE_TYPE]
		,[AGENT_PHONE1_TYPE]
		,[AGENT_PHONE2_TYPE]
		,[AGENT_PHONE3_TYPE]
		,[AGENT_PHONE4_TYPE]
		,[AGENT_PHONE5_TYPE]
		,[MLS_LISTING_AGENT_COMPANY]
		,[MLS_LISTING_AGENT_EMAIL]
		,[First_Name]
		,[Last_Name]
		,[MLS_LISTING_AGENT_NAME_nochar]
		,[MLS_LISTING_AGENT_DESIGNATION]
		,[MLS_Listing_Agent_NickName]
		,[Suffix_STD]
		,[Created]
		,[MLS_LISTING_AGENT_EMAIL_STD]
	)
	SELECT
		 a.MatchId AS [MLS_LISTING_AGENT_CODE_ORIG]
		,a.[MLS_Listing_Agent_CHECKSUM]
		,a.[MLS_LISTING_AGENT_LICENSE_NBR]
		,a.[MLS_LISTING_AGENT_NAME]
		,a.[MLS_LISTING_AGENT_ADDRESS]
		,a.[AGENT_PHONE]
		,a.[AGENT_PHONE1]
		,a.[AGENT_PHONE2]
		,a.[AGENT_PHONE3]
		,a.[AGENT_PHONE4]
		,a.[AGENT_PHONE5]
		,a.[AGENT_PHONE_TYPE]
		,a.[AGENT_PHONE1_TYPE]
		,a.[AGENT_PHONE2_TYPE]
		,a.[AGENT_PHONE3_TYPE]
		,a.[AGENT_PHONE4_TYPE]
		,a.[AGENT_PHONE5_TYPE]
		,a.[MLS_LISTING_AGENT_COMPANY]
		,a.[MLS_LISTING_AGENT_EMAIL]
		,a.[First_Name]
		,a.[Last_Name]
		,a.[MLS_LISTING_AGENT_NAME_nochar]
		,a.[MLS_LISTING_AGENT_DESIGNATION]
		,a.[MLS_Listing_Agent_NickName]
		,a.[Suffix_STD]
		,a.Created
		,a.[MLS_LISTING_AGENT_EMAIL_STD]
	FROM [MLS_Listing_Agent] a
	INNER JOIN #AgentStd s ON s.MLS_Listing_agent_CODE = a.MLS_Listing_agent_CODE
	WHERE s.RowNum = 1

	-- Link the normal agents to the standard agents
	UPDATE a
	SET MLS_Listing_Agent_CODE_std = s.MLS_Listing_Agent_CODE_STD
	FROM MLS_Listing_Agent a
	INNER JOIN MLS_Listing_Agent_Std s ON a.MatchId = s.MLS_Listing_Agent_CODE_ORIG
	WHERE a.MLS_Listing_Agent_CODE_std IS NULL

