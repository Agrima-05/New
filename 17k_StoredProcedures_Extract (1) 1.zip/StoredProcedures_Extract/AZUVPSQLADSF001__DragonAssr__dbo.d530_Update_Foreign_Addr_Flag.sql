SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================

CREATE PROCEDURE [dbo].[d530_Update_Foreign_Addr_Flag]
AS
BEGIN
SET NOCOUNT ON;

	---------Updates MailForeignAddrInd flag in Property from Mailing Address data---------

		---- FLAG Foreign Addresses
		UPDATE [DragonAssr].[dbo].[PropertyWork] 
		SET MailForeignAddrInd = 'C'
		Where (MailingStdState Not in(Select [State] from Global.dbo.StateNames) or MailingStdState is NULL or MailingStdState like '')
				AND MailForeignAddrInd is null AND isNULL(MailingStdCarrierCode,'') = ''
					AND (MailingStdState in('AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT','ON')
					 OR MailingStdFullStreetAddress Like '%Canada%' OR MailingStdFullStreetAddress Like '%BC%'
					  OR MailingStdFullStreetAddress Like '%AB' OR MailingStdFullStreetAddress Like '%CALGARY%'
					   OR MailingStdFullStreetAddress Like '%ALBERTA%' OR MailingStdFullStreetAddress Like '%ONTARIO%'
						OR MailingStdFullStreetAddress Like '%VANCOUVER%' OR MailingStdFullStreetAddress Like '%BRITISH CO%'
						 OR MailingStdFullStreetAddress Like '%EDMONTON%' OR MailingStdFullStreetAddress Like '%OTTAWA%'
						  OR MailingStdCity Like '%Canad%' OR MailingStdCity Like '%CALGARY%'
						   OR MailingStdCity Like '%ALBERTA%' OR MailingStdCity Like '%ONTARI%'
							OR MailingStdCity Like '%VANCOUVER%' OR MailingStdCity Like '%BRITISH COL%'
							 OR MailingStdCity Like '% BC %' OR MailingStdCity Like '% AB %'
							  OR MailingStdCity Like '%TORONTO%' OR MailingStdCity Like '%EDMONTON%'
							   OR MailingStdCity Like '%OTTAWA%' OR MailingStdCity Like '%AJAX%'
								OR MailingStdCity Like '%SURREY%' OR MailingStdCity Like '%LAVAL%'
								 OR MailingStdCity Like '%WATERLOO%' OR MailingStdCity Like '%WINNIPEG%'
								  OR MailingStdCity Like '%SASKATOON%' OR MailingStdCity Like 'CAN'
								   OR MailingStdCity Like '%UNIONVILLE ON%' OR MailingStdStreet like '%MILTON ON%'
								    OR MailingStdCity in('ALBERT','BELLEVILLE','BELFOUNTAIN','BEACHON','BAYON','CLOSE','COCHRANE','CRESCENT','KELOWNA','LANGLEY','MEDICINE HAT','PORT ALBERNI','REGINA')
								     OR MailingStdStreet Like '%Mississauga%' OR MailingStdStreet like '%Winnepeg%'
								      OR MailingStdStreet Like '% QC %' OR MailingStdStreet like '% SK %' OR MailingStdStreet like '% ON %' OR MailingStdStreet like '% AB %')


		UPDATE [DragonAssr].[dbo].[PropertyWork] 
		SET MailForeignAddrInd = 'Y'
		Where (MailingStdState Not in(Select [State] from Global.dbo.StateNames) 
					OR MailingStdState is NULL OR MailingStdState like '')
				AND isNULL(MailingStdFullStreetAddress,'') Not like ''
					AND MailForeignAddrInd is null 
						AND ltrim(rtrim(MailingStdCarrierCode)) like ''
							AND MailingStdCity in('BERLIN','SCOTTLAND','BRAZIL','ITALY','HAMINA','MEXICO','INDIES','FRANKFUR','ITALY','TOKYO','HEUSENSTAMM','TSIMSHA TSUI KLN HONG'
							,'NICOSIA','RECKLINGHAUSEN','SUANSON','NAPLES','DUSSELDORF','IRELAND','ENGELBERG','LONDON','CHINA','INDIES','SELANGOR','THOR','BENITO'
							,'JIANG','HANOI','SIANTAN','NUEVA','BERGERIE','KYOTO','YUAN','PRAGUE 1 CZECH','FIFE','HAMBURG','TAIPEI','REPUBLIC OF MACEDONIA','EUTINGEN'
							,'CHOSICA LIMA 15 PERU','FUJISAWA KANAGAWA JAPAN','SHOFU','INDONESIA','CHULIN HSINCHU COUNTY TAIWAN','UNITED','KONG','GATINEAU','HAYATO'
							,'HUIZEN','MOSCOW','GRAND CAYMAN','BATUR','NEW ZEALAND','KOREA','AUSTRALIA VIC 3145','PASEO LABRANZA','VIC','REPULSE BAY HONG KONG'
							,'GIVOT OLGA HADERA','HITCHIN','KANAG','SURRY','AMSTERDAM','LONDON ENGLAND NW 80EJ UNITED','SCHLOSSWEG','ST CROIX','TOYONAKA CITY'
							,'AUSTRALIA','SHANSH','ITALY','SAN LORENZO','GORYO','TONBRIDGE','CONTRE','NEW ZEALAND','TAMPS','GUARANIVILLA','ABALANG','JALISCO'
							,'VERACRUZ','CHIANGAMAI','PHILIPPINES','TAIPEI TAIWAN','MIDLEVELS HONGKON','ECOLAND DAVAO CITY','SOUTH WALES','WOOLBRIDGE'
							,'KOBE SHI HYOGO','EDINGEN NECKARHAUSEN','DUBAI','BEIJING','OENSINGEN','WIESENTHEID','SANTIAGO','PRINCIPAUTE DE MONACO','MONTREAL'
							,'GIBATAYIM ISRAEL','ISRAEL','WERRIBEE VICTORIA','TECAMACHALCO','NIEDERANVAN LUXEMBURG','PARIS FRANCE','NUEVO','WINDSOR BERKSHIRE'
							,'URMSTON MANCHESTER','NISHI','TAIWAN','AFRICA','ENGLAND','FRANCE','JAMAICA','CARACAS','BERMUDA','BIRKENHEAD'',CANELONES URUGUAY'
							,'SCOTLAND','LIVERPOOL''ADELE','ADOLPHE','AMERICA','ANTILLES','ARAB','ARABIA','ARAGUA','ARGENTINA','AUS','AUSTR','AUSTRAILIA','AUSTRIA'
							,'BAHAMAS','BAIE','BANGKOK','BEDFORDSHIRE','BELGIUN','BERKSHIRE','BOLIVAR','CAYMAN ISLANDS','CHO','CHUO','GERMANY')

		UPDATE [DragonAssr].[dbo].[PropertyWork] 
		SET MailForeignAddrInd = 'Y'
		Where (MailingStdState Not in(Select [State] from Global.dbo.StateNames) or MailingStdState is NULL)
				AND isNULL(MailingStdFullStreetAddress,'') Not like ''
					AND MailForeignAddrInd is null 
						AND ltrim(rtrim(MailingStdCarrierCode)) like ''
							AND (MailingStdCity like '%CHINA%' or MailingStdCity Like '%CAYMANS ISLANDS%' or MailingStdCity Like '%SWITZERLAND%'
							 OR MailingStdCity Like '%ZURICH%' or MailingStdCity Like '%LONDON%' or MailingStdCity Like '%ZHEJIANG%' or MailingStdCity Like '%GR UK%'
							  OR MailingStdCity Like '%RICHMOND HILL ON%' or MailingStdCity Like '%MINHANG%' or MailingStdCity Like '% UK %' 
							   OR MailingStdCity Like '%LAHORE PAKISTAN%' or MailingStdCity Like '%MEX MX%' or MailingStdCity Like '%HU13 OEG%'
							   OR MailingStdCity Like 'CHIDDINGFOLD%' )

		UPDATE [DragonAssr].[dbo].[PropertyWork] 
		SET MailForeignAddrInd = 'Y'
		Where (MailingStdState Not in(Select [State] from Global.dbo.StateNames) or MailingStdState is NULL)
				AND isNULL(MailingStdFullStreetAddress,'') Not like ''
					AND MailForeignAddrInd is null 
						AND ltrim(rtrim(MailingStdCarrierCode)) like ''
							AND (MailingStdStreet like  '% U K%' or MailingStdStreet like  '%UNITED KINGDOM%' or MailingStdStreet like '%JAPAN TOKYO%' or MailingStdStreet like '%CAPRI NAPLES%' or MailingStdStreet like '%LES GRAMENTETS%' or MailingStdStreet like '%YAMANASHI%' or MailingStdStreet like '%LENGKOK%' or MailingStdStreet like '%LONDON%'
							 OR MailingStdStreet like '%GUADALAJARA%' OR MailingStdStreet like '%PARAGUAY%' or MailingStdStreet like '%VICTORIA AU%' or MailingStdStreet like '%EL SALVADOR%'
							  OR MailingStdStreet like '%DE LA JARA%' OR MailingStdStreet like '%CHESHIRE ENGLAND%'
							   OR MailingStdStreet like '%LUNG MEI%' OR MailingStdStreet like '%SERAI BUKIT BANDARAYA%'
						        OR MailingStdStreet like '%TRINIDAD & T%' OR MailingStdStreet like '%Netherlands%'
						         OR MailingStdStreet like '%Singapore%' OR MailingStdStreet like '%TEL AVIV%'
						          OR MailingStdStreet like '%BELGIUM%' OR MailingStdStreet like '% JAPAN %'
							       OR MailingStdStreet like '%JUAREZ CHIH%' OR MailingStdStreet like '%PHILIPPIN%'
							        OR MailingStdStreet like '% ISRAEL%' OR MailingStdStreet like '%HONGKONG%')

		UPDATE [DragonAssr].[dbo].[PropertyWork] 
		SET MailForeignAddrInd = 'C'
		Where MailForeignAddrInd is NULL 
				AND (MailingStdState in('NS','QC','ON','ON','AB','NL','NT','MB')
					OR MailingStdZIP5 like '% %')


END

