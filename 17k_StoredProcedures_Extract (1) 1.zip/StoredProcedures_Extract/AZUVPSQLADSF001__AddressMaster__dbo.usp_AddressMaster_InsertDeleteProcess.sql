SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_InsertDeleteProcess] @t_state_abbr varchar(2)
AS

BEGIN
	SET NOCOUNT ON;
	IF LEN(@t_state_abbr) != 2 set @t_state_abbr = 'XX'
	DECLARE @TableName varchar(20), @Server varchar(100)
	DECLARE @FipsCode varchar(5)
	-- EXEC [SNACPSQLADSF002.datatree.local].AddressMaster.dbo.usp_AddressMaster_InsertDeleteProcess @t_state_abbr = 'NJ' -- from server 24 or 25
	-- EXEC AddressMaster.dbo.usp_AddressMaster_InsertDeleteProcess @t_state_abbr = 'MD' -- from Licensing server

	-- FLAG delete archive records from servers 006 (24) and 007 (25)
	BEGIN 
		--DECLARE @TableName varchar(20), @Server varchar(100)
		DECLARE CurLoopProc CURSOR FOR SELECT [TableName], [Server] FROM [AddressMaster].[dbo].[State_abbr] where state = @t_state_abbr ORDER BY [TableName] 
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @TableName, @Server
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @Server + ' : ' + @TableName + '_Archive_Addresses'
			EXEC('UPDATE A SET [FATimestamp] = getdate(), 
							   [FAUserId] = ''AddressMaster'', 
							   [FAUCIDFlag] = ''D'', 
							   [FAExpirationDate] = getdate()
				  FROM [AddressMaster].[dbo].[Address_Master] A
				  JOIN ['+@Server+'].[AddressMaster].[dbo].['+@TableName+'_Archive_Addresses] B with (nolock) 
 				  ON A.[AddressHash] = B.[AddressHash] 
				  WHERE A.[CountyFips] = CASE WHEN len(B.[CountyFips]) = 4 THEN ''0'' + B.[CountyFips] ELSE B.[CountyFips] END 
				  ')
			FETCH NEXT FROM CurLoopProc INTO @TableName, @Server  
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
		-- select * from  [AddressMaster].[dbo].[Address_Master] where [FAUCIDFlag] = 'D'
	END

	-- INSERT new records from servers 006 (24) and 007 (25)
	BEGIN 
		--DECLARE @TableName varchar(20), @Server varchar(100)
		DECLARE CurLoopProc CURSOR FOR SELECT [TableName], [Server] FROM [AddressMaster].[dbo].[State_abbr] where state = @t_state_abbr ORDER BY [TableName] 
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @TableName, @Server
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @Server + ' ; ' + @TableName + '_New_Addresses' 
			IF @t_state_abbr != 'CT' Begin --ONLY CT has ALT_FIPS
				EXEC('INSERT [AddressMaster].[dbo].[Address_Master] (
					   [AddressLine] -- Address Master layout FullStreetAddress 
					  ,[Address2]
					  ,[CityStateZip]
					  ,[PreDir] -- Address Master layout PreDirectional
					  ,[StreetNumber] -- Address Master layout StreetNumber
					  ,[StreetName] -- Address Master layout Street
					  ,[PostDir] -- Address Master layout PostDirectional
					  ,[StreetType] -- Address Master layout StreetType
					  ,[SuiteType] -- Address Master layout UnitType
					  ,[Suite]  -- Address Master layout UnitNbr
					  ,[City]
					  ,[State] -- Address Master layout State
					  ,[Zip] -- Address Master layout ZIP5
					  ,[Plus4] -- Address Master layout ZIP4
					  ,[PrivateMailbox]
					  ,[Pmsa]
					  ,[Msa]
					  ,[ZipType]
					  ,[Urbanization]
					  ,[TimeZoneCode]
					  ,[TimeZone]
					  ,[CongressionalDistrict]
					  ,[CountryCode]
					  ,[CountyFips] -- Address Master layout FIPS
					  ,[CountyName] -- Address Master layout County
					  ,[CityAbbreviation]
					  ,[AddressTypeString]
					  ,[AddressTypeCode] -- Address Master layout AddressType
					  ,[DPVFootNotes]
					  ,[CarrierRoute]
					  ,[ELotOrder]
					  ,[ELotNumber]
					  ,[Lacs]
					  ,[LACSLinkIndicator]
					  ,[LACSLinkReturnCode]
					  ,[EWSFlag]
					  ,[RBDI]
					  ,[SuiteLinkReturnCode]
					  ,[AddressMatchResults]
					  ,[AddressMatchResultString]
					  ,[DeliveryPointCheckDigit]
					  ,[DeliveryPointCode]
					  ,[Latitude] -- Address Master layout Latitude
					  ,[Longitude] -- Address Master layout Longitude
					  ,[GeoErrorCode]
					  ,[GeoStatusCode]
					  ,[GeoCodeResults]
					  ,[CensusTract]
					  ,[CensusBlock]
					  ,[PlaceCode]
					  ,[PlaceName] -- Address Master layout PlaceName
					  ,[CBSACode]
					  ,[CBSALevel]
					  ,[CBSATitle]
					  ,[CBSADivisionCode]
					  ,[CBSADivisionTitle]
					  ,[CBSADivisionLevel]
					  ,[CMRA]
					  ,[Verified]
					  ,[Geocoded]
					  ,[LoadDate]
					  ,[DsfNoStats]
					  ,[DsfVacant] -- Address Master layout VacantIndicator
					  ,[DsfDNA]
					  ,[id]
					  ,[AddressKey]
					  ,[Company]
					  ,[MelissaAddressKey]
					  ,[MelissaAddressKeyBase]
					  ,[SuiteStatus]
					  ,[MatchCodeMandA]
					  ,[MatchCodeSpatial]
					  ,[PropertyID]
					  ,[PropertyIDMandA]
					  ,[PropertySpatial]
					  ,[MatchMethodSpatial]
					  ,[AddressHash]
					  ,[FATimestamp] -- Address Master layout LastUpdate
					  ,[FAUserId]
					  ,[FAUCIDFlag]
					  ,[NonUSPSAddressIndicator] -- Address Master layout NonUSPSAddressIndicator
					  ,[NotCurrentlyDeliverable] -- Address Master layout NotCurrentlyDeliverable
					  ,[FAEffectiveDate] -- Address Master layout EffectiveDate
					  ,[DPVCount])
				  SELECT
					   [AddressLine]
					  ,[Address2]
					  ,[CityStateZip]
					  ,[PreDir]
					  ,[StreetNumber]
					  ,[StreetName]
					  ,[PostDir]
					  ,[StreetType]
					  ,[SuiteType]
					  ,[Suite]
					  ,[City]
					  ,[State]
					  ,[Zip]
					  ,[Plus4]
					  ,[PrivateMailbox]
					  ,[Pmsa]
					  ,[Msa]
					  ,[ZipType]
					  ,[Urbanization]
					  ,[TimeZoneCode]
					  ,[TimeZone]
					  ,[CongressionalDistrict]
					  ,[CountryCode]
					  ,case when len([CountyFips]) = 4 then RIGHT(''0''+CAST([CountyFips] AS VARCHAR(4)),5) else convert(varchar(5),[CountyFips]) end -- [CountyFips]
					  ,[CountyName]
					  ,[CityAbbreviation]
					  ,[AddressTypeString]
					  ,[AddressTypeCode]
					  ,[DPVFootNotes]
					  ,[CarrierRoute]
					  ,[ELotOrder]
					  ,[ELotNumber]
					  ,[Lacs]
					  ,[LACSLinkIndicator]
					  ,[LACSLinkReturnCode]
					  ,[EWSFlag]
					  ,[RBDI]
					  ,[SuiteLinkReturnCode]
					  ,[AddressMatchResults]
					  ,[AddressMatchResultString]
					  ,[DeliveryPointCheckDigit]
					  ,[DeliveryPointCode]
					  ,case when isnumeric(Latitude) = 0 then NULL else [Latitude] end -- [Latitude]
					  ,case when isnumeric(Longitude) = 0 then NULL else [Longitude] end -- [Longitude]
					  ,[GeoErrorCode]
					  ,[GeoStatusCode]
					  ,[GeoCodeResults]
					  ,[CensusTract]
					  ,[CensusBlock]
					  ,[PlaceCode]
					  ,[PlaceName]
					  ,[CBSACode]
					  ,[CBSALevel]
					  ,[CBSATitle]
					  ,[CBSADivisionCode]
					  ,[CBSADivisionTitle]
					  ,[CBSADivisionLevel]
					  ,[CMRA]
					  ,[Verified]
					  ,[Geocoded]
					  ,[LoadDate]
					  ,[DsfNoStats]
					  ,case when [AddressMatchResults] like ''%AS16%'' or [DsfVacant] = ''Y'' then ''Y'' else null end -- [DsfVacant]
					  ,[DsfDNA]
					  ,[id]
					  ,[AddressKey]
					  ,[Company]
					  ,[MelissaAddressKey]
					  ,[MelissaAddressKeyBase]
					  ,[SuiteStatus]
					  ,[MatchCodeMandA]
					  ,[MatchCodeSpatial]
					  ,[PropertyID]
					  ,[PropertyIDMandA]
					  ,[PropertySpatial]
					  ,[MatchMethodSpatial]
					  ,[AddressHash]
					  ,getdate() -- [FATimestamp]
					  ,''AddressMaster'' -- [FAUserId]
					  ,''I'' -- [FAUCIDFlag]
					  ,case when [AddressMatchResults] like ''%AS03%'' then ''Y'' else null end -- [NonUSPSAddressIndicator]
					  ,case when [AddressMatchResults] like ''%AS17%'' then ''Y'' else null end -- [NotCurrentlyDeliverable]
					  ,getdate() -- [FAEffectiveDate]
					  ,[DPVCount]
				  FROM ['+@Server+'].[AddressMaster].[dbo].['+@TableName+'_New_Addresses]
				  ')
				end
				else
				Begin
				EXEC('INSERT [AddressMaster].[dbo].[Address_Master] (
					   [AddressLine] -- Address Master layout FullStreetAddress 
					  ,[Address2]
					  ,[CityStateZip]
					  ,[PreDir] -- Address Master layout PreDirectional
					  ,[StreetNumber] -- Address Master layout StreetNumber
					  ,[StreetName] -- Address Master layout Street
					  ,[PostDir] -- Address Master layout PostDirectional
					  ,[StreetType] -- Address Master layout StreetType
					  ,[SuiteType] -- Address Master layout UnitType
					  ,[Suite]  -- Address Master layout UnitNbr
					  ,[City]
					  ,[State] -- Address Master layout State
					  ,[Zip] -- Address Master layout ZIP5
					  ,[Plus4] -- Address Master layout ZIP4
					  ,[PrivateMailbox]
					  ,[Pmsa]
					  ,[Msa]
					  ,[ZipType]
					  ,[Urbanization]
					  ,[TimeZoneCode]
					  ,[TimeZone]
					  ,[CongressionalDistrict]
					  ,[CountryCode]
					  ,[CountyFips] -- Address Master layout FIPS
					  ,[CountyName] -- Address Master layout County
					  ,[CityAbbreviation]
					  ,[AddressTypeString]
					  ,[AddressTypeCode] -- Address Master layout AddressType
					  ,[DPVFootNotes]
					  ,[CarrierRoute]
					  ,[ELotOrder]
					  ,[ELotNumber]
					  ,[Lacs]
					  ,[LACSLinkIndicator]
					  ,[LACSLinkReturnCode]
					  ,[EWSFlag]
					  ,[RBDI]
					  ,[SuiteLinkReturnCode]
					  ,[AddressMatchResults]
					  ,[AddressMatchResultString]
					  ,[DeliveryPointCheckDigit]
					  ,[DeliveryPointCode]
					  ,[Latitude] -- Address Master layout Latitude
					  ,[Longitude] -- Address Master layout Longitude
					  ,[GeoErrorCode]
					  ,[GeoStatusCode]
					  ,[GeoCodeResults]
					  ,[CensusTract]
					  ,[CensusBlock]
					  ,[PlaceCode]
					  ,[PlaceName] -- Address Master layout PlaceName
					  ,[CBSACode]
					  ,[CBSALevel]
					  ,[CBSATitle]
					  ,[CBSADivisionCode]
					  ,[CBSADivisionTitle]
					  ,[CBSADivisionLevel]
					  ,[CMRA]
					  ,[Verified]
					  ,[Geocoded]
					  ,[LoadDate]
					  ,[DsfNoStats]
					  ,[DsfVacant] -- Address Master layout VacantIndicator
					  ,[DsfDNA]
					  ,[id]
					  ,[AddressKey]
					  ,[Company]
					  ,[MelissaAddressKey]
					  ,[MelissaAddressKeyBase]
					  ,[SuiteStatus]
					  ,[MatchCodeMandA]
					  ,[MatchCodeSpatial]
					  ,[PropertyID]
					  ,[PropertyIDMandA]
					  ,[PropertySpatial]
					  ,[MatchMethodSpatial]
					  ,[AddressHash]
					  ,[FATimestamp] -- Address Master layout LastUpdate
					  ,[FAUserId]
					  ,[FAUCIDFlag]
					  ,[NonUSPSAddressIndicator] -- Address Master layout NonUSPSAddressIndicator
					  ,[NotCurrentlyDeliverable] -- Address Master layout NotCurrentlyDeliverable
					  ,[FAEffectiveDate] -- Address Master layout EffectiveDate
					  ,[DPVCount]
					  ,alt_fips)
				  SELECT
					   [AddressLine]
					  ,[Address2]
					  ,[CityStateZip]
					  ,[PreDir]
					  ,[StreetNumber]
					  ,[StreetName]
					  ,[PostDir]
					  ,[StreetType]
					  ,[SuiteType]
					  ,[Suite]
					  ,[City]
					  ,[State]
					  ,[Zip]
					  ,[Plus4]
					  ,[PrivateMailbox]
					  ,[Pmsa]
					  ,[Msa]
					  ,[ZipType]
					  ,[Urbanization]
					  ,[TimeZoneCode]
					  ,[TimeZone]
					  ,[CongressionalDistrict]
					  ,[CountryCode]
					  ,case when len([CountyFips]) = 4 then RIGHT(''0''+CAST([CountyFips] AS VARCHAR(4)),5) else convert(varchar(5),[CountyFips]) end -- [CountyFips]
					  ,[CountyName]
					  ,[CityAbbreviation]
					  ,[AddressTypeString]
					  ,[AddressTypeCode]
					  ,[DPVFootNotes]
					  ,[CarrierRoute]
					  ,[ELotOrder]
					  ,[ELotNumber]
					  ,[Lacs]
					  ,[LACSLinkIndicator]
					  ,[LACSLinkReturnCode]
					  ,[EWSFlag]
					  ,[RBDI]
					  ,[SuiteLinkReturnCode]
					  ,[AddressMatchResults]
					  ,[AddressMatchResultString]
					  ,[DeliveryPointCheckDigit]
					  ,[DeliveryPointCode]
					  ,case when isnumeric(Latitude) = 0 then NULL else [Latitude] end -- [Latitude]
					  ,case when isnumeric(Longitude) = 0 then NULL else [Longitude] end -- [Longitude]
					  ,[GeoErrorCode]
					  ,[GeoStatusCode]
					  ,[GeoCodeResults]
					  ,[CensusTract]
					  ,[CensusBlock]
					  ,[PlaceCode]
					  ,[PlaceName]
					  ,[CBSACode]
					  ,[CBSALevel]
					  ,[CBSATitle]
					  ,[CBSADivisionCode]
					  ,[CBSADivisionTitle]
					  ,[CBSADivisionLevel]
					  ,[CMRA]
					  ,[Verified]
					  ,[Geocoded]
					  ,[LoadDate]
					  ,[DsfNoStats]
					  ,case when [AddressMatchResults] like ''%AS16%'' or [DsfVacant] = ''Y'' then ''Y'' else null end -- [DsfVacant]
					  ,[DsfDNA]
					  ,[id]
					  ,[AddressKey]
					  ,[Company]
					  ,[MelissaAddressKey]
					  ,[MelissaAddressKeyBase]
					  ,[SuiteStatus]
					  ,[MatchCodeMandA]
					  ,[MatchCodeSpatial]
					  ,[PropertyID]
					  ,[PropertyIDMandA]
					  ,[PropertySpatial]
					  ,[MatchMethodSpatial]
					  ,[AddressHash]
					  ,getdate() -- [FATimestamp]
					  ,''AddressMaster'' -- [FAUserId]
					  ,''I'' -- [FAUCIDFlag]
					  ,case when [AddressMatchResults] like ''%AS03%'' then ''Y'' else null end -- [NonUSPSAddressIndicator]
					  ,case when [AddressMatchResults] like ''%AS17%'' then ''Y'' else null end -- [NotCurrentlyDeliverable]
					  ,getdate() -- [FAEffectiveDate]
					  ,[DPVCount]
					  ,alt_fips
				  FROM ['+@Server+'].[AddressMaster].[dbo].['+@TableName+'_New_Addresses]
				  ')
				End
			FETCH NEXT FROM CurLoopProc INTO @TableName, @Server  
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
		-- select * from  [AddressMaster].[dbo].[Address_Master] where [FATimestamp] > '2019-07-01' and [FAUCIDFlag] != 'D'
	END


	-- UPDATE CommunityName
	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] WHERE [State] = @t_state_abbr ORDER BY [FIPSCode] -- [FIPSCode] < '60000'
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.CommunityName = F.communityname  
				  from AddressMaster.dbo.Address_Master A 
				  join fema.dbo.LicFlood F with (nolock)
				  on F.propertyid = A.propertyid 
				  where A.CountyFips = '''+@FipsCode+''' and A.FATimestamp > DATEADD(day, -1, getdate())
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	-- UPDATE Municipality & SubdivisionName & PropertyClassID
	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] WHERE [State] = @t_state_abbr ORDER BY [FIPSCode] -- [FIPSCode] < '60000'
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.Municipality = P.Municipality, A.SubdivisionName = P.SubdivisionName, A.PropertyClassID = P.PropertyClassID 
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on P.propertyid = A.propertyid 
				  where A.CountyFips = '''+@FipsCode+''' and A.FATimestamp > DATEADD(day, -1, getdate())
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	-- UPDATE Filler Ref_ID
	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] WHERE [State] = @t_state_abbr ORDER BY [FIPSCode] -- [FIPSCode] < '60000'
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set A.Ref_ID = ASSR.REF_ID 
				  from AddressMaster.dbo.Address_Master A
				  join Assr.dbo.Assr ASSR with (nolock) 
				  on A.propertyid  = ASSR.Lic_PropertyID and A.CountyFips = ASSR.Lic_Fips
				  where A.CountyFips = '''+@FipsCode+''' and A.FATimestamp > DATEADD(day, -1, getdate())
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	BEGIN 
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] WHERE [State] = @t_state_abbr ORDER BY [FIPSCode] -- [FIPSCode] < '60000'
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set 
			      --Longitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude,P.TPLongitude, NULL), 
				  --Latitude = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL)

				  A.ConsdtLatitude = coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL),
	              A.ConsdtLongitude = coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL),
                  A.ConsdtSource = case when P.FARooftopLongitude is not null then ''R''
                                   when P.FALongitude is not null or P.TPLongitude is not null then ''P''
                                   else P.SitusGeoStatusCode end
				  from AddressMaster.dbo.Address_Master A 
				  join data.dbo.property P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  --join DigitalMap.dbo.BuildingFootprint D with (nolock)
				  --on A.CountyFips = '''+@FipsCode+''' and A.propertyid = D.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and 
				        (A.ConsdtLatitude is null or A.ConsdtLatitude != coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude) or
	                    A.ConsdtLongitude != coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude)) and
						--A.Longitude != coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
						--A.Latitude != coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL) and 
						A.FATimestamp > DATEADD(day, -1, getdate())
				  ')
			----UPdate postal community where NULL -- moved to weekly process.
			--EXEC('update AddressMaster.dbo.Address_Master set postalCommunity = city where postalcommunity = null and CountyFips = '''+@FipsCode+'')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

END


