SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- ===============================================================
-- Description:	Roll up Last and Prior Sale data to Property Table
-- ===============================================================
create PROCEDURE [dbo].[d300_NameParsing]
AS
BEGIN

exec [NameParser].[dbo].[Dragon01_PropertyWork_to_Namework]
exec [NameParser].[dbo].[usp_name_parser_unified_daily] 'DragonPropertyWork_assessee', @RowCounts = 'N', @MailingLabel = 'Y'
exec [NameParser].[dbo].[Dragon02_namework_to_DragonPropertyWork]


END

