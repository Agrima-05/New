SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
create PROCEDURE [dbo].[d999_DragonAssr_RemovedAPNs]
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @FipsCode varchar(5)
		DECLARE @Records int

		DECLARE curDRGmissing CURSOR FOR  
			SELECT [Fipscode],[RecordsinTaxroll]
			FROM [Global].[dbo].[County]
			ORDER BY [FipsCode]


		OPEN curDRGmissing   
		FETCH NEXT FROM curDRGmissing INTO @FipsCode,@Records

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

			EXEC('

				Select [FORMATTED_APN] into #x from [azuvpSQLDTDB029.datatree.local].assr.dbo.assr with(NOLOCK) where fips = ' + @FipsCode + ' 

				create index ix_x on #x([FORMATTED_APN])

				IF(SELECT CAST(COUNT(*) as MONEY) FROM [Data].[dbo].[Property] WHERE [FIPS] = ''' + @FipsCode + ''' and [FAUCIDFlag] != ''D'' and [FormattedAPN] not in(Select [FORMATTED_APN] from #x)) > ' + @Records + '/4 

				UPDATE [Data].[dbo].[Property]
				SET [FAUCIDFlag] = ''D''
				,[FATimestamp] = convert(varchar(10),getdate()+1,120)
				where [FIPS] = ''' + @FipsCode + ''' and [FAUCIDFlag] != ''D''
				and [FormattedAPN] not in(Select [FORMATTED_APN] from #x)

				Drop table #x
				')

			
			FETCH NEXT FROM curDRGmissing INTO @FipsCode,@Records
		END   

		CLOSE curDRGmissing   
		DEALLOCATE curDRGmissing 


END
