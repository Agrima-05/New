SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.usp_send_USPS_to_SQL004_and_SQL005

AS
BEGIN
	EXEC ('
    USE [USPS];
	DROP TABLE IF EXISTS ZIP4_new;
    CREATE TABLE [dbo].[ZIP4_new](
	[CopyrightDetailCode] [varchar](1) NULL,
	[ZIPCode] [varchar](5) NULL,
	[UpdateKeyNumber] [varchar](10) NULL,
	[ActionCode] [varchar](1) NULL,
	[RecordTypeCode] [varchar](1) NULL,
	[CarrierRouteID] [varchar](4) NULL,
	[StreetPreDirectionalAbbreviation] [varchar](2) NULL,
	[StreetName] [varchar](28) NULL,
	[StreetSuffixAbbreviation] [varchar](4) NULL,
	[StreetPostDirectionalAbbreviation] [varchar](2) NULL,
	[AddressPrimaryLowNumber] [varchar](10) NULL,
	[AddressPrimaryHighNumber] [varchar](10) NULL,
	[AddressPrimaryOddEvenCode] [varchar](1) NULL,
	[BuildingorFirmName] [varchar](40) NULL,
	[AddressSecondaryAbbreviation] [varchar](4) NULL,
	[AddressSecondaryLowNumber] [varchar](8) NULL,
	[AddressSecondaryHighNumber] [varchar](8) NULL,
	[AddressSecondaryOddEvenCode] [varchar](1) NULL,
	[LowZIPSectorNumber] [varchar](2) NULL,
	[LowZIPSegmentNumber] [varchar](2) NULL,
	[HighZIPSectorNumber] [varchar](2) NULL,
	[HighZIPSegmentNumber] [varchar](2) NULL,
	[BaseAlternateCode] [varchar](1) NULL,
	[LACSStatusIndicator] [varchar](1) NULL,
	[GovernmentBuildingIndicator] [varchar](1) NULL,
	[FinanceNumber] [varchar](6) NULL,
	[StateAbbreviation] [varchar](2) NULL,
	[CountyNumber] [varchar](3) NULL,
	[CongressionalDistrictNumber] [varchar](2) NULL,
	[MunicipalityCityStateKey] [varchar](6) NULL,
	[UrbanizationCityStateKey] [varchar](6) NULL,
	[PreferredLastLineCityStateKey] [varchar](8) NULL,
	[StateNumber] [varchar](2) NULL,
	[Fips] [varchar](5) NULL,
	[PreferredLastLineCityStateName] [varchar](28) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
') AT [azuvpsqladsf004.datatree.local];

EXEC ('
    USE [USPS];
	DROP TABLE IF EXISTS ZIP4_new;
    CREATE TABLE [dbo].[ZIP4_new](
	[CopyrightDetailCode] [varchar](1) NULL,
	[ZIPCode] [varchar](5) NULL,
	[UpdateKeyNumber] [varchar](10) NULL,
	[ActionCode] [varchar](1) NULL,
	[RecordTypeCode] [varchar](1) NULL,
	[CarrierRouteID] [varchar](4) NULL,
	[StreetPreDirectionalAbbreviation] [varchar](2) NULL,
	[StreetName] [varchar](28) NULL,
	[StreetSuffixAbbreviation] [varchar](4) NULL,
	[StreetPostDirectionalAbbreviation] [varchar](2) NULL,
	[AddressPrimaryLowNumber] [varchar](10) NULL,
	[AddressPrimaryHighNumber] [varchar](10) NULL,
	[AddressPrimaryOddEvenCode] [varchar](1) NULL,
	[BuildingorFirmName] [varchar](40) NULL,
	[AddressSecondaryAbbreviation] [varchar](4) NULL,
	[AddressSecondaryLowNumber] [varchar](8) NULL,
	[AddressSecondaryHighNumber] [varchar](8) NULL,
	[AddressSecondaryOddEvenCode] [varchar](1) NULL,
	[LowZIPSectorNumber] [varchar](2) NULL,
	[LowZIPSegmentNumber] [varchar](2) NULL,
	[HighZIPSectorNumber] [varchar](2) NULL,
	[HighZIPSegmentNumber] [varchar](2) NULL,
	[BaseAlternateCode] [varchar](1) NULL,
	[LACSStatusIndicator] [varchar](1) NULL,
	[GovernmentBuildingIndicator] [varchar](1) NULL,
	[FinanceNumber] [varchar](6) NULL,
	[StateAbbreviation] [varchar](2) NULL,
	[CountyNumber] [varchar](3) NULL,
	[CongressionalDistrictNumber] [varchar](2) NULL,
	[MunicipalityCityStateKey] [varchar](6) NULL,
	[UrbanizationCityStateKey] [varchar](6) NULL,
	[PreferredLastLineCityStateKey] [varchar](8) NULL,
	[StateNumber] [varchar](2) NULL,
	[Fips] [varchar](5) NULL,
	[PreferredLastLineCityStateName] [varchar](28) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
') AT [azuvpsqladsf005.datatree.local];

insert into [azuvpsqladsf004.datatree.local].usps.dbo.zip4_new select * from usps.dbo.ZIP4 with (nolock)
insert into [azuvpsqladsf005.datatree.local].usps.dbo.zip4_new select * from usps.dbo.ZIP4 with (nolock)
END

