SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_100d_ASP_Property_Mailing_to_Licensing]
AS
BEGIN
	UPDATE
		LIC
	SET
		LIC.[MailingStdFullStreetAddress] = UPPER(SL.[SitusStdFullStreetAddress]),
		LIC.[MailingStdHouseNbr] = SL.[SitusStdHouseNbr],
		LIC.[MailingStdDirectionLeft] = SL.[SitusStdDirectionLeft],
		LIC.[MailingStdStreet] = CASE WHEN SL.[SitusStdStreet] like '&%' THEN ltrim(rtrim(Substring(SL.[SitusStdStreet],2,Len(SL.[SitusStdStreet])))) ELSE SL.[SitusStdStreet] END,
		LIC.[MailingStdMode] = SL.[SitusStdMode],
		LIC.[MailingStdDirectionRight] = SL.[SitusStdDirectionRight],
		LIC.[MailingStdUnitNbr] = SL.[SitusStdUnitNbr],
		LIC.[MailingStdCity] = SL.[SitusStdCity],
		LIC.[MailingStdState] = SL.[SitusStdState],
		LIC.[MailingStdZIP5] = SL.[SitusStdZIP5],
		LIC.[MailingStdZIP4] = SL.[SitusStdZIP4],
		LIC.[MailingStdCarrierCode] = SL.[SitusStdCarrierCode],
		LIC.[MailingCensusTract] = SL.[SitusCensusTract],
		LIC.[MailingStdUnitType] = SL.[SitusStdUnitType],
		LIC.[MailingStdMatchCode] = SL.[SitusStdMatchCode],
		LIC.[MailingDPVCount] = SL.[SitusDPVCount],
		LIC.[MailingDPVFootnote] = SL.[SitusDPVFootnote],
		LIC.[MailingLACS] = SL.[SitusLACS],
		LIC.[MailingLACSLinkInd] = SL.[SitusLACSLinkInd],
		LIC.[MailingDPCheckDigit] = SL.[SitusDPCheckDigit],
		LIC.[MailingDPCheckCode] = SL.[SitusDPCheckCode],
		LIC.[MailingCensusBlock] = SL.[SitusCensusBlock],
		LIC.[MailingGeoErrorCode] = SL.[SitusGeoErrorCode],
		LIC.[MailingGeoStatusCode] = SL.[SitusGeoStatusCode],
		LIC.[MailingGeoCodeResults] = SL.[SitusGeoCodeResults],
		LIC.[FAAddressParsedMailing] = CURRENT_TIMESTAMP
	FROM
		[DragonAssr].[dbo].[PropertyWork] LIC
	INNER JOIN
		[DragonAssr].[dbo].[a_ASP_IN_STD] SL
	ON 
		LIC.DTDB_Ref_ID = SL.[DTDB_Ref_ID]

	UPDATE LIC
	SET LIC.MailingFIPS = FZ.FIPS
		FROM 
			[DragonAssr].[dbo].[PropertyWork] LIC
		INNER JOIN
			[USPS].[dbo].[FIPS_ZIP] FZ
		ON 
			LIC.MailingStdZIP5 = FZ.ZIPCode

END

