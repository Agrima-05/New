SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankForeclosureTrusteePost] (@tableName varchar(40)) -- @tableName = 'Foreclosure_Trustee' (from Addr.dbo.STDTrigger.TableName and not used in the SP)
as  
declare @sql varchar(max) = ''

-- Trim all fields, make some fields uppdercase, rebuild TrusteeFullStreetAddress and TrusteeCensusTractBlock fields
    set @sql = '
	   UPDATE [AddressSTD].[dbo].[Foreclosure_Trustee_STD]
	   --set [TrusteeFullAddress] = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeHouseNbr])) + '' '' + [AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionLeft])) + '' '' + ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeStreet]))))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeMode]))) + '' '' + [AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionRight]))))  + '' '' + ltrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeUnitType])) + '' '' + (ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeAptNumber])))))))
       set [TrusteeFullAddress] = ltrim(rtrim(rtrim(rtrim(rtrim(rtrim(rtrim(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeHouseNbr])) + '' '' + [AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionLeft]) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeStreet])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeMode])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionRight])))) + '' '' + ltrim(rtrim(UPPER([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeUnitType])))) + '' '' + ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeAptNumber]))))
	   ,[TrusteeCity] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeCity])))
       ,[TrusteeState] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeState]))
       ,[TrusteeZIP5] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeZIP5]))
       ,[TrusteeZIP4] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeZIP4]))
       ,[TrusteeHouseNbr]  = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeHouseNbr]))
       ,[TrusteeDirectionLeft] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionLeft]))
       ,[TrusteeStreet] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeStreet])))
       ,[TrusteeMode] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeMode])))
       ,[TrusteeDirectionRight] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDirectionRight]))
       ,[TrusteeUnitType] = UPPER(ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeUnitType])))
       ,[TrusteeAptNumber] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeAptNumber]))
       ,[TrusteeCensusBlock] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeCensusBlock]))
	   ,[TrusteeCensusTract] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeCensusTract]))
	   ,[TrusteeDPCheckCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDPCheckCode]))		
       ,[TrusteeDPCheckDigit] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDPCheckDigit]))
       ,[TrusteeDPVCount] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDPVCount]))
       ,[TrusteeDPVFootnote] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeDPVFootnote]))
       ,[TrusteeGeoErrorCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeGeoErrorCode]))
       ,[TrusteeGeoStatusCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeGeoStatusCode]))	
       ,[TrusteeGeoCodeResults] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeGeoCodeResults]))	
       ,[TrusteeLACS] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeLACS]))
       ,[TrusteeLACSLinkInd] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeLACSLinkInd]))	
	   ,[TrusteeCarrierCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeCarrierCode]))
       ,[TrusteeMatchCode] = ltrim(rtrim([AddressSTD].[dbo].[Foreclosure_Trustee_STD].[TrusteeMatchCode]))
    From [AddressSTD].[dbo].[Foreclosure_Trustee_STD]
    '
print @sql
exec (@sql)
exec global.dbo.usp_ASP_Foreclosure_Trustee_to_Licensing

