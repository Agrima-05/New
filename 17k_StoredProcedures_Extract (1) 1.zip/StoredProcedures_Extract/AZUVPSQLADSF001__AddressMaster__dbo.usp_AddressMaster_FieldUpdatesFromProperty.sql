SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_AddressMaster_FieldUpdatesFromProperty]
AS

-- EXEC [AddressMaster].[dbo].[usp_AddressMaster_FieldUpdatesFromProperty]

BEGIN
	SET NOCOUNT ON;

	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com;micsmith@firstam.com;afowler@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Started.'

	DECLARE @FipsCode varchar(5)

    -- Fix an issue with FIPS having 4 characters during quarterly process -- added 20200116 ------------------------------------------------------ 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
	    UPDATE AM 
        SET CountyFips = '0' + CountyFips 
	    from addressmaster.dbo.Address_Master AM 
	    where len(CountyFips) = 4 
	END
	
	-- CommunityName -- Municipality -- SubdivisionName -- PropertyClassID ------------------------------------------------------------------------- 
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]

	-- Temp Table Address_Master_TempFAFlood
	--drop table AddressMaster.dbo.Address_Master_TempFAFlood
	IF OBJECT_ID('AddressMaster.dbo.Address_Master_TempFAFlood', 'U') IS NOT NULL DROP TABLE AddressMaster.dbo.Address_Master_TempFAFlood;

	Select FIPS, propertyid, communityname, LicTimestamp into AddressMaster.dbo.Address_Master_TempFAFlood from fema.dbo.LicFlood with (nolock) -- time 2:50 
	CREATE NONCLUSTERED INDEX [IDX_Fips_PropertyID] ON AddressMaster.dbo.Address_Master_TempFAFlood (FIPS, propertyid) -- time 1:02
	CREATE NONCLUSTERED INDEX [IDX_Fips] ON AddressMaster.dbo.Address_Master_TempFAFlood (FIPS) -- time 0:41
	CREATE NONCLUSTERED INDEX [IDX_FATimeStamp] ON AddressMaster.dbo.Address_Master_TempFAFlood (LicTimestamp) -- time 0:41

	-- Temp Table Address_Master_TempProperty
	--drop table AddressMaster.dbo.Address_Master_TempProperty
	IF OBJECT_ID('AddressMaster.dbo.Address_Master_TempProperty', 'U') IS NOT NULL DROP TABLE AddressMaster.dbo.Address_Master_TempProperty;
	Select FIPS, propertyid, Municipality, SubdivisionName, PropertyClassID, DTDB_Ref_ID, FALatitude, FALongitude, SitusLatitude, SitusLongitude, TPLatitude, TPLongitude, FARooftopLongitude, FARooftopLatitude, SitusGeoStatusCode, FATimestamp into AddressMaster.dbo.Address_Master_TempProperty from Data.dbo.Property with (nolock) -- time 12:20
	CREATE NONCLUSTERED INDEX [IDX_Fips_PropertyID] ON AddressMaster.dbo.Address_Master_TempProperty (FIPS, propertyid) -- time 1:13
	CREATE NONCLUSTERED INDEX [IDX_Fips] ON AddressMaster.dbo.Address_Master_TempProperty (FIPS) -- time 0:48
	CREATE NONCLUSTERED INDEX [IDX_FATimestamp] ON AddressMaster.dbo.Address_Master_TempProperty (FATimestamp) -- time 0:48

--REMOVED Just Added The Fields To TempProperty

	---- Temp Table Address_Master_TempBuildingFootprint
	--drop table AddressMaster.dbo.Address_Master_TempBuildingFootprint
	--Select FIPS, propertyid, FARooftopLongitude, FARooftopLatitude into AddressMaster.dbo.Address_Master_TempBuildingFootprint from Data.dbo.Property with (nolock) -- time 6:11
	--CREATE NONCLUSTERED INDEX [IDX_Fips_PropertyID] ON AddressMaster.dbo.Address_Master_TempBuildingFootprint (FIPS, propertyid) -- time 1:05
	--CREATE NONCLUSTERED INDEX [IDX_Fips] ON AddressMaster.dbo.Address_Master_TempBuildingFootprint (FIPS) -- time 0:51

	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   

			PRINT @FipsCode
			EXEC('UPDATE A set A.CommunityName = F.communityname, FATimestamp = getdate()  
	              from AddressMaster.dbo.Address_Master A 
				  join AddressMaster.dbo.Address_Master_TempFAFlood F with (nolock) -- join fema.dbo.licflood F with (nolock) 
				  on A.CountyFips = F.FIPS and A.propertyid = F.propertyid 
				      where A.CountyFips = '''+@FipsCode+''' and F.FIPS = '''+@FipsCode+''' 
					  and (A.CommunityName is null  or A.CommunityName <> F.CommunityName)
					  and ISNULL(F.CommunityName,'''') NOT LIKE ''''
				      and (A.FATimestamp > dateadd(day, -30, getdate()) OR F.LicTimestamp > dateadd(day, -30, getdate()))
					  ')
			
			EXEC('UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join AddressMaster.dbo.Address_Master_TempProperty P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					  and (A.Municipality is null or A.Municipality <> P.Municipality)
					  and ISNULL(P.Municipality, '''') NOT LIKE ''''
				      and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))
					  ')			

			EXEC('UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  join AddressMaster.dbo.Address_Master_TempProperty P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					  and (A.SubdivisionName is null OR A.SubdivisionName <> P.SubdivisionName)
					  and ISNULL(P.SubdivisionName, '''') NOT LIKE ''''
				      and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))
					  ')

			EXEC('UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A 
				  join AddressMaster.dbo.Address_Master_TempProperty P with (nolock) 
				  on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  where A.CountyFips = '''+@FipsCode+''' and P.FIPS = '''+@FipsCode+''' 
					  and (A.PropertyClassID is null OR a.[PropertyClassID] <> p.[PropertyClassID])
					  and ISNULL(P.PropertyClassID, '''') NOT LIKE ''''
				      and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))
					  ')

			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END

	-- NonUSPSAddressIndicator -- NotCurrentlyDeliverable -- DsfVacant -- Ref_ID -- Longitude and Latitude -----------------------------------------------------------------------
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode

			EXEC('UPDATE A set A.NonUSPSAddressIndicator = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS03%'' and (A.NonUSPSAddressIndicator is null or A.NonUSPSAddressIndicator != ''Y'')
				  and A.FATimestamp > dateadd(day, -30, getdate())
				  ')

			EXEC('UPDATE A set A.NotCurrentlyDeliverable = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS17%'' and (A.NotCurrentlyDeliverable is null or NotCurrentlyDeliverable != ''Y'')
				  and A.FATimestamp > dateadd(day, -30, getdate())
				  ')

			EXEC('UPDATE A set A.DsfVacant = ''Y'', FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A 
				  where A.CountyFips = '''+@FipsCode+''' and A.AddressMatchResults like ''%AS16%'' and (A.DsfVacant is null or A.DsfVacant != ''Y'')
				  and A.FATimestamp > dateadd(day, -30, getdate())
				  ')

			EXEC('UPDATE A set A.Ref_ID = ASSR.DTDB_Ref_ID, FATimestamp = getdate() 
				  from AddressMaster.dbo.Address_Master A with (nolock) 
				  join AddressMaster.dbo.Address_Master_TempProperty ASSR with (nolock) 
				  on A.propertyid  = ASSR.propertyid and A.CountyFips = ASSR.FIPS
				  where A.CountyFips = '''+@FipsCode+''' and ASSR.FIPS = '''+@FipsCode+''' and A.Ref_ID is null
				  and (A.FATimestamp > dateadd(day, -30, getdate()) OR ASSR.FATimestamp > dateadd(day, -30, getdate()))
				  ')

	        -- Longitude and Latitude Info -------------------------------------------------------------------------------------------------------------------------
	        -- ,FALongitude = coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL)
	        -- ,FALatitude  = coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL) 
	        -- FARooftop=GTmagic, FA=DMP, Situs=Melissa, TP=BK
	        -- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	        -- LoadDate = Date loaded to be processed by Melissa
	        -- FATimestamp = Last time the record was updated
	        -- FAEffectiveDate = Date record loaded into Address Master
	        -- FAAddressParsed = Date record was processed through ASP				  

---- REMOVED JOIN TO TempBuildingFootPrint Dont Need It Just TempProperty
			EXEC('UPDATE A SET 
			      --Longitude = coalesce(P.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL),
				  --Latitude = coalesce(P.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL),
				  A.ConsdtLatitude = coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL),
	              A.ConsdtLongitude = coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL),
                  A.ConsdtSource = case when P.FARooftopLongitude is not null then ''R''
                                   when P.FALongitude is not null or P.TPLongitude is not null then ''P''
                                   else P.SitusGeoStatusCode end,			
				  FATimestamp = getdate()
				  FROM AddressMaster.dbo.Address_Master A 
				  JOIN AddressMaster.dbo.Address_Master_TempProperty P with (nolock) on A.CountyFips = P.FIPS and A.propertyid = P.propertyid
				  --JOIN AddressMaster.dbo.Address_Master_TempBuildingFootprint D with (nolock) on A.CountyFips = '''+@FipsCode+''' and A.propertyid = D.propertyid
				  WHERE A.CountyFips = '''+@FipsCode+''' and 
				        (A.ConsdtLatitude != coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL) or
	                    A.ConsdtLongitude != coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL)) and
						--A.Longitude != coalesce(D.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
						--A.Latitude != coalesce(D.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL) and
				       (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))
				  ')

			-- only needed after new data is added.
			EXEC('UPDATE A SET 
				A.ConsdtLatitude = Latitude,
				A.ConsdtLongitude = Longitude,
				A.ConsdtSource = GeoStatusCode,                 
				FATimestamp = getdate()
				FROM AddressMaster.dbo.Address_Master A 
				WHERE A.CountyFips = ''' + @FipsCode + ''' and 
				(A.ConsdtLatitude is NULL or A.ConsdtLongitude is NULL or A.ConsdtSource is NULL)
				')

            -- UPdate postal community where NULL -- moved to weekly process. -----------------------------------------------------------------------------------------------------------------------------
	        --DECLARE @FipsCode varchar(5) = '01001'
			EXEC('update AddressMaster.dbo.Address_Master set postalCommunity = city where postalcommunity = null and CountyFips = '''+@FipsCode+'''')

		FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END	   	  

	-- EffectiveDate ------------------------------------------------------------------------------------------------------------------------------
	---- Comment out after the quarterly process starts.
	-- for counts see [usp_AddressMaster_FieldUpdatesFromPropertyCounts]
	/*
	BEGIN
		--DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
			EXEC('UPDATE A set FAEffectiveDate = ''20190101'', FAUCIDFlag = ''I'', FATimestamp = getdate()
				  from AddressMaster.dbo.Address_Master A with (nolock) 
				  where A.CountyFips = '''+@FipsCode+''' and A.FAEffectiveDate is null
				  ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
	*/

	/* Consdt approach manually ran
	BEGIN -- done
		DECLARE @FipsCode varchar(5)
		DECLARE CurLoopProc CURSOR FOR SELECT [FIPSCode] FROM [Global].dbo.[County] with (nolock) WHERE FIPSCode < '60000' ORDER BY [FIPSCode]
		OPEN CurLoopProc   
		FETCH NEXT FROM CurLoopProc INTO @FipsCode
		WHILE @@FETCH_STATUS = 0   
		BEGIN   
			PRINT @FipsCode
            EXEC('Update a set a.ConsdtLatitude = case when p.FARooftopLatitude is not null then p.FARooftopLatitude
                             when p.FAGeoStatusCode = ''Parcels'' then p.FALatitude
                             when p.SitusGeoCodeResults = ''GS05'' then p.SitusLatitude
                             when p.SitusGeoCodeResults = ''GS06'' then p.SitusLatitude
                             else a.Latitude end,
                         a.ConsdtLongitude = case when p.FARooftopLatitude is not null then p.FARooftopLongitude
                             when p.FAGeoStatusCode = ''Parcels'' then p.FALongitude
                             when p.SitusGeoCodeResults = ''GS05'' then p.SitusLongitude
                             when p.SitusGeoCodeResults = ''GS06'' then p.SitusLongitude
                             else a.longitude end, 
						 a.ConsdtSource = case when P.FARooftopLatitude is not null then ''TrueRoof''
                             when p.FAGeoStatusCode = ''Parcels'' then ''DMP-RT''
                             when p.SitusGeoCodeResults = ''GS05'' then ''Mel''
                             when p.SitusGeoCodeResults = ''GS06'' then ''Mel''
                             else ''Default'' end,
						FATimestamp = getdate()
                 FROM [AddressMaster].[dbo].[Address_Master] a inner join Data.dbo.Property p  with (nolock) on a.PropertyId = p.PropertyID
				 WHERE a.CountyFips = '''+@FipsCode+''' and p.FIPS = '''+@FipsCode+'''
				 ')
			FETCH NEXT FROM CurLoopProc INTO @FipsCode   
		END   
		CLOSE CurLoopProc   
		DEALLOCATE CurLoopProc 
	END
	*/

    -- FIPS miss match and PropertyID matches ----------------------------------------------------------------------
    -- CommunityName ----------------------------------------------------------------------------------------------- 
	UPDATE A set A.CommunityName = F.CommunityName, FATimestamp = getdate() -- done
	    -- select count(*) -- 52785
		from AddressMaster.dbo.Address_Master A with (nolock)
		join AddressMaster.dbo.Address_Master_TempFAFlood F with (nolock) 
		on F.propertyid = A.propertyid 
		where (A.CommunityName is null  or A.CommunityName <> F.CommunityName) 
		    and ISNULL(F.CommunityName,'') NOT LIKE ''
			and (A.FATimestamp > dateadd(day, -30, getdate()) OR F.LicTimestamp > dateadd(day, -30, getdate()))

	-- Municipality ------------------------------------------------------------------------------------------------
	UPDATE A set A.Municipality = P.Municipality, FATimestamp = getdate() -- done
	    -- select count(*) -- 46087
		from AddressMaster.dbo.Address_Master A with (nolock)
		join AddressMaster.dbo.Address_Master_TempProperty P with (nolock) 
		on P.propertyid = A.propertyid 
		where (A.Municipality is null or A.Municipality <> P.Municipality)
		    and ISNULL(P.Municipality, '') NOT LIKE ''
			and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))

	-- SubdivisionName --------------------------------------------------------------------------------------------- 
	UPDATE A set A.SubdivisionName = P.SubdivisionName, FATimestamp = getdate() -- done
	    -- select count(*) -- 49004
		from AddressMaster.dbo.Address_Master A
		join AddressMaster.dbo.Address_Master_TempProperty P with (nolock)  
		on P.propertyid = A.propertyid 
		where (A.SubdivisionName is null OR A.SubdivisionName <> P.SubdivisionName)
		    and ISNULL(P.SubdivisionName, '') NOT LIKE ''
			and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))
		
	-- PropertyClassID ---------------------------------------------------------------------------------------------
	UPDATE A set A.PropertyClassID = P.PropertyClassID, FATimestamp = getdate() -- done
	    -- select count(*) -- 73570
		from AddressMaster.dbo.Address_Master A
		join AddressMaster.dbo.Address_Master_TempProperty P with (nolock)  
		on P.propertyid = A.propertyid 
		where (A.PropertyClassID is null OR a.[PropertyClassID] <> p.[PropertyClassID])
		    and ISNULL(P.PropertyClassID, '') NOT LIKE ''
			and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))

	-- Longitude and Latitude -----------------------------------------------------------------------------------------------------------------------------
	UPDATE A 
	    set 
		    --Longitude = coalesce(P.FARooftopLongitude,P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL), 
		    --Latitude = coalesce(P.FARooftopLatitude,P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL), 
			A.ConsdtLatitude = coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL),
	        A.ConsdtLongitude = coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL),
            A.ConsdtSource = case when P.FARooftopLongitude is not null then 'R'
                             when P.FALongitude is not null or P.TPLongitude is not null then 'P'
                             else P.SitusGeoStatusCode end,
			FATimestamp = getdate()
		-- select count(*) -- 0
		from AddressMaster.dbo.Address_Master A 
		JOIN AddressMaster.dbo.Address_Master_TempProperty P with (nolock) 
		on A.propertyid = P.propertyid
		--join DigitalMap.dbo.BuildingFootprint D with (nolock)
		--on A.propertyid = D.propertyid
		where A.ConsdtLatitude != coalesce(P.FARooftopLatitude,P.FALatitude, P.TPLatitude, P.SitusLatitude, NULL) or
	          A.ConsdtLongitude != coalesce(P.FARooftopLongitude,P.FALongitude, P.TPLongitude, P.SitusLongitude, NULL)
		    --(A.Longitude != coalesce(P.FARooftopLongitude, P.FALongitude, P.SitusLongitude, P.TPLongitude, NULL) or 
		    --A.Latitude != coalesce(P.FARooftopLatitude, P.FALatitude, P.SitusLatitude, P.TPLatitude, NULL))
			--and (A.FATimestamp > dateadd(day, -30, getdate()) OR P.FATimestamp > dateadd(day, -30, getdate()))

    -- send completed email -----------------------------------------------------------------------------------------------------------------------------
	EXEC Global.dbo.EmailDone 'gmathes@firstam.com;jeschmeyer@firstam.com;klowe@firstam.com;micsmith@firstam.com;afowler@firstam.com', @t_subject = 'Address Master Property Field Update', @t_body = 'Successfully Completed.'

END
