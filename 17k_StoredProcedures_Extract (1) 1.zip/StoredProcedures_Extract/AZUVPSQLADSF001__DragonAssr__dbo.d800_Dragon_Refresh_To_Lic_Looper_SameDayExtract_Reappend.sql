SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- =============================================
CREATE PROCEDURE [dbo].[d800_Dragon_Refresh_To_Lic_Looper_SameDayExtract_Reappend]
AS
BEGIN
	SET NOCOUNT ON;


	DECLARE @FipsCode varchar(5)

		DECLARE FmtDocPost CURSOR FOR  
			SELECT RIGHT([name],5)
			FROM sys.tables
			WHERE [name] like 'PropertyWork_[0-9][0-9][0-9][0-9][0-9]'
			and RIGHT([name],5) in('04005','06037','06039','06041','06047','06053','06055','06057')
			ORDER BY [name]

		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode



			EXEC [dbo].[d850_Post_Dragon_To_Licensing_REFRESH_SameDayExtract] @FipsCode

			UPDATE dbo.Dragon_Refresh_Tracker
			SET [PushedToProduction] = GetDate()
			,RunRefresh = 'D'
			WHERE FIPS = @FipsCode

			
			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 



				DECLARE @3 varchar(355) = 'micsmith@firstam.com', 
				@t_profile_name3 varchar(30) = 'FAOH-DL-DBS_Fulfillment',
				@t_subject3 varchar(50) = 'Dragon Assr Load Finished',
				@t_body3 varchar(2000) = 'The Dragon Assr Data Load process has finished.'


				SET NOCOUNT ON;
				DECLARE @t_getdate3 datetime = GETDATE()
				SET @t_body3 = @t_body3 + ' : ' + cast(@t_getdate3 as varchar(20))

				EXEC msdb.dbo.sp_send_dbmail
					@recipients = @3,
					@profile_name = @t_profile_name3,
					@subject = @t_subject3,
					@body = @t_body3


END
