SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE procedure [dbo].[FlankPropertyMailingCANInput](@tableName varchar(40)) -- @tableName = 'Property_MailingCAN' (from Addr.dbo.STDTrigger.TableName)
as  
declare @sql varchar(max) = ''  

-- Create table_STD
set @sql = '  
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' + '''' + rtrim(@tableName) + '_STD' + '''' + ') AND type in (N''U''))  
DROP TABLE ' + rtrim(@tableName) + '_STD'  
print(@sql)
exec (@sql)  
print(2)
    set @sql = '  
    create table ' + rtrim(@tableName) + '_STD (' + '  
	[PropertyID] [bigint] NOT NULL,
	[MailingStdFullStreetAddress] [varchar](116) NULL,
	[MailingStdHouseNbr] [varchar](30) NULL,
	[MailingStdDirectionLeft] [varchar](2) NULL,
	[MailingStdStreet] [varchar](60) NULL,
	[MailingStdMode] [varchar](5) NULL, 
	[MailingStdDirectionRight] [varchar](2) NULL,
	[MailingStdUnitNbr] [varchar](15) NULL,
	[MailingStdCity] [varchar](55) NULL,
	[MailingStdState] [varchar](2) NULL,
	[MailingStdZIP5] [varchar](9) NULL,
	--[MailingStdZIP4] [varchar](9) NULL,
	[MailingStdCarrierCode] [varchar](4) NULL,
	[MailingStdUnitType] [varchar](20) NULL,
	[MailingStdMatchCode] [varchar](30) NULL,
	[MailingDPVCount] [varchar](5) NULL,
	[MailingDPVFootnote] [varchar](4) NULL,
	[MailingLACS] [varchar](1) NULL,
	[MailingLACSLinkInd] [varchar](1) NULL,
	[MailingDPCheckDigit] [varchar](1) NULL,
	[MailingDPCheckCode] [varchar](2) NULL,
	[MailingCensusBlock] [varchar](4) NULL,
	[MailingCensusTract] [varchar](6) NULL,
	[MailingGeoCodeResults] [varchar](30) NULL,
	[MailingGeoErrorCode] [varchar](1) NULL,
	[MailingGeoStatusCode] [varchar](1) NULL)
    '  
print @sql
exec (@sql)
print (3)
 
--Fixed Leading Zeros for Unit_Number Column. Used SubString and PatIndex function for that. 
set @sql = '  
SELECT PropertyID  as id  ,  '''' as HouseNumber
	  , 0 as FIPS, isnull([MailingStdFullStreetAddress], '''') addressLine ,isnull(MailingStdCity, '''') as city  ,isnull(MailingStdState, '''') as state  ,
isnull(MailingStdZIP5, '''') as zip  
FROM ' + @tableName +   
   ' WITH (NOLOCK) ORDER BY MailingStdZIP5 desc'  

exec (@sql)  

